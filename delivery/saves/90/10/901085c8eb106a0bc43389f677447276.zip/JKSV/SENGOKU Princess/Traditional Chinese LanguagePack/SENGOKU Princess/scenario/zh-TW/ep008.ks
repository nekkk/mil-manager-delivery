
*start

;//==============================
;//謙信の所へ潜入　勝利した場合

*select04_win|

*root_2|再次見到對方

;#################################################
*Ep008|再一次見面。
;#################################################

[SCENE id=8]


[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_07"]


;//【ＢＧ】『城＿室内』（夜）


謙信不知道我在那裡，叫他的臣子們談各種事情。
[cpg]

我可以說，我的目標已經實現了。有了這個，與謙信的戰鬥就可以解決了。
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

我已經發現了我想知道的東西。沒有必要徘徊不前。
[cpg]

刺殺他不是我的職責，我也沒有必要這樣做。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『山道』（朝）******************************************************

我已經取得了一些成就。她似乎沒有認出我，所以她不可能是在撒謊。
[cpg]

我興致勃勃地回到了信玄大人那裡。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

當我回到她的住處時，她表揚了我。
[cpg]

只要聽到她說我做得很好，我就很高興。
[cpg]

這值得我冒生命危險。 ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

信玄大人把我留在他身邊。
[cpg]

當然，這並不意味著我只是站在他身邊什麼都不做。我會考慮我可以做什麼。
[cpg]

信玄大人的臣子們教我如何站在戰場上，政治，等等。
[cpg]


[window target=false]
[BG f="b_13_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

我有很多東西要學。在這個時代，這個時代有常識。
[cpg]

學習一些東西比我整天無所事事地度過更有成就感。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

在那些日子裡，有時會發生一些不正常的情況。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Ranmaru461"]
[OnName num="ranmaru"]
'嘿，你......，不打算回信長大人那裡去了？
[cpg cn=true]


蘭丸大人來拜訪我和信玄大人。
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Singen218"]
[OnName num="shingen"]
'你打算怎麼做？　我打算留下來。
[cpg cn=true]


[OnName num="keitarou"]
'不，......，我不會回到信長大人身邊。
[cpg cn=true]


我搖了搖頭。蘭丸小姐看起來很遺憾。
[cpg]

[FACE method="change_3" pos="4/5"]

[VOICE f="Ranmaru462"]
[OnName num="ranmaru"]
'信長大人還在等你。
[cpg cn=true]


[OnName num="keitarou"]
'對信玄大人來說也是如此。他需要我'。
[cpg cn=true]


蘭丸大人似乎無法放棄。
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我從來沒有被如此需要過。
[cpg]

我來自未來，但我從未被如此善待過。
[cpg]

所以，當我把這件事告訴信玄大人時...
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen219"]
[OnName num="shingen"]
'這還不是全部。你有一種神秘的魅力。
[cpg cn=true]


她一邊回答一邊非常靠近我，"你有一種神秘的魅力。
[cpg]


;//========================================
;//●ＣＧ（主人公の体に両手を突いているヒロイン）ev_69
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_69_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="keitarou"]
'...... 是這樣嗎？
[cpg cn=true]


我感覺每個人都在這麼說，但我到底有什麼魅力呢？
[cpg]

在我看來，這只是因為我來自一個不同的時代。
[cpg]

[OnName num="keitarou"]
'我不覺得我沒有辜負任何人的期望。然而蘭丸大人卻想把我帶回去。
[cpg cn=true]



[VOICE f="Singen220"]
[OnName num="shingen"]
'是的，你是對的。也許你應該有更多的信心。
[cpg cn=true]


[OnName num="keitarou"]
...... 你是什麼意思？ "
[cpg cn=true]



[VOICE f="Singen221"]
[OnName num="shingen"]
'你在戰場上打得很好。我的意思是，你應該意識到，你只有在你的名聲好的時候才會好。
[cpg cn=true]


這個女人的眼睛似乎在訴說著一種不尋常的心境。
[cpg]


;//移植前シーンカット

諸侯們都知道我們的關係。我想說這不是一個問題。 ......
[cpg]

但我肯定他們是嫉妒的。我必須為它工作。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

與謙信的另一場戰爭即將開始。
[cpg]

我將作為一名將軍站在戰場上，領導士兵。
[cpg]

[OnName num="keitarou"]
那我們可以走了嗎？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Singen248"]
[OnName num="shingen"]
'是的。我會再見到你的，我們會一見如故。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（昼）******************************************************

當我們在一起時，沒有什麼可害怕的。
[cpg]

我和信玄大人雖然相距甚遠，但我們的心是一體的。
[cpg]


[STOPBGM]
[window target=false]
[BG f="b_09_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（夕方）******************************************************

[SE f=se019]
;//【ＳＥ】『剣戟』

我意識到，作為一名軍事指揮官，我已經變得更加強大。
[cpg]

當我為信玄大人戰鬥時，他在與謙信的戰鬥中逐漸佔了上風。
[cpg]

如果事情像這樣發展下去，就會與我所知道的歷史有些不同。
[cpg]

我記得，這場戰鬥應該是沒有結果的。
[cpg]

但由於我的緣故，這場戰鬥可能會發生傾斜。
[cpg]

如果未來被改變了，我不知道會發生什麼。這可能是我從未存在過。
[cpg]

為了防止這種情況，我做了一些事情，比如在最後一刻操縱戰爭局勢......，而沒有打敗謙信。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen249"]
[OnName num="shingen"]
'......，你做得非常好。你有打仗的天賦'。
[cpg cn=true]


[OnName num="keitarou"]
'是這樣的嗎？你不是信玄大人的對手。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen250"]
[OnName num="shingen"]
這並不令人驚訝。如果有比我強的軍閥這麼容易，我就麻煩了。
[cpg cn=true]


我明白了。你是這樣的軍閥，你把你的名字留在了未來。
[cpg]


;//ブラックアウト

;//移植前シーンカット
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

時間在流逝。無法解決的戰鬥仍在繼續。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen280"]
[OnName num="shingen"]
'我派出去戰鬥的忍者已經回來了，看來下一場戰鬥將是一場全面的戰爭。
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


全面戰爭。這是否意味著信玄大人或謙信大人都會輸？
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Singen281"]
[OnName num="shingen"]
下一次，將決定是我還是謙信滅亡。
[cpg cn=true]


我已準備好為信玄大人付出一切。
[cpg]

[OnName num="keitarou"]
信玄大人。我與你同在。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen282"]
[OnName num="shingen"]
謝謝你。我以前說過，我對你沒有吸引力，但我收回這句話。
[cpg cn=true]


他們對我有一定的幫助。這是我已經知道的事情。
[cpg]

繼續為信玄大人而戰是一回事。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen283"]
[OnName num="shingen"]
'...... 不錯的夕陽，不是嗎？每當太陽落山時，我總是想知道今天的日落是否會是最後一次'。
[cpg cn=true]


即使像信玄大人這樣優秀的人也會感到害怕。
[cpg]

不過，我還是不想看到她看起來很焦慮。
[cpg]

[OnName num="keitarou"]
'這不會發生，我親愛的。只要我在這裡'。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Singen284"]
[OnName num="shingen"]
'我想要永生。如果我在這場戰鬥中倖存下來，我也會得到這些嗎？
[cpg cn=true]


[FACE method="bows_4" pos="2/3"]

[VOICE f="Singen285"]
[OnName num="shingen"]
'但即使我贏得這場戰鬥，...... kehoh, kohoh。
[cpg cn=true]


[OnName num="keitarou"]
你沒事吧，信玄大人？信玄大人。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Singen286"]
[OnName num="shingen"]
'......，即使我贏得了與謙信的這場戰鬥，我也終究無法贏得對疾病的勝利。
[cpg cn=true]


;//ブラックアウト

;//移植前シーンカット

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

你越想珍惜它，時間就會越快過去。決定性戰鬥的日子很快就到了。
[cpg]

一個矛盾的情況是，我們要想獲得和平，唯一的辦法就是戰鬥。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

我希望我是在，比如說，現在，而不是在這個時代遇到她。
[cpg]

結核病本來是可以被治癒的。我可以想像的東西是沒有盡頭的。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『戦場』（朝）******************************************************

然後，到了決定性戰鬥的日子。
[cpg]

[FG f="CHA02_p3_02_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Singen314"]
[OnName num="shingen"]
'我可以做到，我們走吧。我今天會完成。 "
[cpg cn=true]


[OnName num="keitarou"]
是的，我會做的。交給我吧。 "
[cpg cn=true]


但我不能讓這場戰鬥結束。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（昼）******************************************************

[SE f=se019]
;//【ＳＥ】『剣戟』

我以自己的判斷力控制了戰爭局勢，因為歷史如果得到解決，就會改變。
[cpg]

而與謙信的戰鬥最後也沒有解決。 ......。
[cpg]

不過，我一定給他造成了很大的痛苦。
[cpg]

如果有的話，信玄大人仍然有優勢。
[cpg]

如果他再傾斜的話，他就快要失去謙信了。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Singen315"]
[OnName num="shingen"]
'你已經做得很好了。優秀的工作'。
[cpg cn=true]


[OnName num="keitarou"]
'謝謝你。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Singen316"]
[OnName num="shingen"]
'但這有一些不自然的地方。我不相信戰鬥已經傾斜到如此程度，而且還沒有解決。
[cpg cn=true]


[OnName num="keitarou"]
這就是.......
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen317"]
[OnName num="shingen"]
我知道大部分的情況。等一切都解決了，你就麻煩了。
[cpg cn=true]


我聽著她說，無法回話。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen318"]
[OnName num="shingen"]
'如果你來自未來，你有我無法想像的情況，我敢肯定。
[cpg cn=true]


[OnName num="keitarou"]
'我很抱歉，.......'
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Singen319"]
[OnName num="shingen"]
'不需要道歉。不要遺憾，我很感激。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen320"]
[OnName num="shingen"]
謝謝你。真的，這要感謝你。 ......謙信不會那麼容易攻擊我們。不過，還有一件需要擔心的事情已經過去了。
[cpg cn=true]


[OnName num="keitarou"]
你在想你的病嗎？
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Singen321"]
[OnName num="shingen"]
'是的。我確定我沒有死在戰場上？
[cpg cn=true]


這一部分是一個模糊的記憶。但如果信玄和謙信的戰斗在歷史事實中沒有定論，他一定是在某個地方病死的.......。
[cpg]

[OnName num="keitarou"]
'我害怕失去你。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Singen322"]
[OnName num="shingen"]
'......，即使你這麼說。 '我的生活是任何人都無法控制的。
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット

;//移植前シーンカット

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（昼）******************************************************

第二天，我離開城堡，眺望小鎮。
[cpg]

這是信玄大人所保護的城鎮。即使它不像五代時期那樣熱鬧，它仍然是一個有很多優點的城鎮。 ......
[cpg]

毫無疑問，人們仍在這裡生活。我感覺到了。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen377"]
[OnName num="shingen"]
......，我希望他們能夠專心於自己的幸福，沒有任何顧慮。 "
[cpg cn=true]


信玄大人和謙信之間的戰鬥仍未解決。
[cpg]

信玄大人可能覺得他最終必須殺死他們，因為他們已經是多年的敵人了。
[cpg]

也許謙信也有同樣的願望，而他們彼此之間存在矛盾。
[cpg]

[OnName num="keitarou"]
'我有點討厭它。這是無法幫助的事情嗎？
[cpg cn=true]


這種事情在我所處的現代社會也可能發生。
[cpg]

每個人都在為他人著想，希望世界和平，但這不可能實現。
[cpg]

在全國范圍內或在個人范圍內可能都是如此。
[cpg]

人們希望彼此相愛，但這往往不會發生。
[cpg]

[OnName num="keitarou"]
'人們的愛怎麼能如此扭曲呢？
[cpg cn=true]


[OnName num="keitarou"]
'我們想要的東西，或者我們都應該希望的東西，不是那麼容易實現的。
[cpg cn=true]


當我和信玄大人談起這些想法時...
[cpg]

[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen378"]
[OnName num="shingen"]
'是的，那是真的。你和我能夠相愛，一定是個奇蹟。
[cpg cn=true]

[STOPBGM]
信玄大人回答說，但不久之後，他又說。
[cpg]

[FACE method="bows_4" pos="2/3"]

[VOICE f="Singen379"]
[OnName num="shingen"]
'葛浩！ '。　Gohoho！ "
[cpg cn=true]


[OnName num="keitarou"]
你沒事吧，信玄大人？
[cpg cn=true]


她突然咳嗽起來，用手摀住嘴。她的手掌沾滿了血。
[cpg]

這種神奇的愛是否也將被奪走？
[cpg]

肺結核的疾病正在將我們撕裂。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

[OnName num="keitarou"]
'......，沒關係。當然，信玄大人的病會被治癒的。 "
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen381"]
[OnName num="shingen"]
'我不能。是我，我知道我在說什麼。
[cpg cn=true]


[OnName num="keitarou"]
'即使信玄大人放棄了，我也不會。
[cpg cn=true]


信玄大人體弱多病，想放棄這個孩子。
[cpg]

但我一直鼓勵他。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


生孩子很困難，即使生了，我也不知道信玄大人是否安全。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen382"]
[OnName num="shingen"]
'也許你是對的。僅有愛可能是不夠的。
[cpg cn=true]


[OnName num="keitarou"]
'我說的不是這個。我說的是愛本身被扭曲了。
[cpg cn=true]


[OnName num="keitarou"]
'我認為信玄大人的愛根本就不是這樣的。
[cpg cn=true]


我對信玄大人說這樣的話，他感到很虛弱。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen383"]
[OnName num="shingen"]
'......，我不需要任何安慰。
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

而她的願望實現了。
[cpg]


;//========================================
;//●ＣＧ（妊娠しているヒロインが前のめりで主人公に近づく）ev_29
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//備考　：ヒロインは妊娠四ヶ月くらいです
;//========================================


[BGM f="bg_05"]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]



她的肚子腫了起來。對我們來說沒有什麼是不可能的。
[cpg]


[VOICE f="Singen384"]
[OnName num="shingen"]
'也許我生孩子的時候就是我死的時候。
[cpg cn=true]


[OnName num="keitarou"]
'話說回來，你不必擔心......。
[cpg cn=true]



[VOICE f="Singen385"]
[OnName num="shingen"]
'我不知道？　你沒有證據來支持這一點'。
[cpg cn=true]


[OnName num="keitarou"]
據我所知，歷史上沒有人因為生孩子而死亡。
[cpg cn=true]


說到這裡，我不能說我......，因為她基本上一開始就是個男人，所以我覺得很安全。
[cpg]


;**【ＣＧ】 ev_29_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSingen003"]
[OnName num="shingen"]
......"
[cpg cn=true]


她本該為生下孩子而感到高興，但她還是有些憂鬱。
[cpg]

信玄大人的肚子膨脹了，快樂的日子過去了。
[cpg]

就像她說的，我也有一種感覺，一切都會過去。
[cpg]

信玄大人患有肺結核。即使她能生孩子，......
[cpg]

她可能比我先死。這是我不得不考慮的事情，即使我不願意。
[cpg]


;//移植前シーンカット

;//ブラックアウト

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

謙信和我僵持了一下。
[cpg]

我和信玄大人已經關注了很久了。我不可能不去管它。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen436"]
[OnName num="shingen"]
'在你的時代，它是一個國家，日本，不是嗎？
[cpg cn=true]


[OnName num="keitarou"]
是的，這是正確的。你也沒有軍隊。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen437"]
[OnName num="shingen"]
我很羨慕你。在這個時代，一個國家可以沒有士兵而存在，這是不可想像的。
[cpg cn=true]


信玄大人的話讓我感到很沮喪。
[cpg]

[OnName num="keitarou"]
'我所處的世界也不會改變。它正在改變它的形式，而像戰爭這樣的事情不斷發生'。
[cpg cn=true]


她想要的和平終究沒有實現。
[cpg]

'如果我能回到以前的時代，我不會想在閒置中生活。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen438"]
[OnName num="shingen"]
'難道你不願意回到以前的樣子嗎？
[cpg cn=true]


我稍微沉思了一下，想了想。
[cpg]

[OnName num="keitarou"]
'我會的。我想把治療肺結核的藥帶回來，拯救你們。
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

想到信玄大人，我回答道。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen439"]
[OnName num="shingen"]
'你說這種話。但對我的病來說已經太晚了。
[cpg cn=true]


[OnName num="keitarou"]
'那不是真的，在我的時代，應該有治療肺結核的藥物。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

信玄大人是否相信我的話？
[cpg]

無論是哪種方式，都是一樣的，因為沒有辦法返回到今天。
[cpg]

我最多只能做到認真地愛她。 ......
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sSingen004"]
[OnName num="shingen"]
'只要我和景太郎在一起，我就可以忘記一切。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen465"]
[OnName num="shingen"]
'還有我自己的死亡。當我和慶太郎在一起的時候，我可以忘記一切，甚至是我自己的死亡，以及這個孩子是否會平安出生。
[cpg cn=true]


[OnName num="keitarou"]
'你沒有什麼可擔心的。我反复說著同樣的話。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Singen466"]
[OnName num="shingen"]
是的。如果你說了，我想我可能不用擔心了。
[cpg cn=true]


畢竟，她將不可避免地感到脆弱。我想支持她。
[cpg]

可能是我，而不是信玄大人，正在尋找一個可靠的聯繫。 ......
[cpg]


;//ブラックアウト

;//移植前シーンカット

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）

我想知道我們還有多少時間可以分享。
[cpg]

信玄大人的肚子繼續咆哮著。而且她的結核病越來越嚴重。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

是時候了，她終於快要生了。
[cpg]

我一直都在她身邊。再加上結核病，她已經不怎麼起床了。
[cpg]

;//[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen491"]
[OnName num="shingen"]
'......，對不起，讓你擔心了。
[cpg cn=true]


[OnName num="keitarou"]
'不要道歉。我確實擔心，但我這樣做是因為我想這樣做。
[cpg cn=true]


;//[FACE method="shock_4" pos="2/3"]

[VOICE f="Singen492"]
[OnName num="shingen"]
'所以...... keh, geez.
[cpg cn=true]


;//[FACE method="change_6" pos="2/3"]

[VOICE f="Singen493"]
[OnName num="shingen"]
你即將有一個孩子。我希望你能見到你的孩子。
[cpg cn=true]


[OnName num="keitarou"]
不要擔心。這正是你需要擔心的問題。
[cpg cn=true]


信玄大人沒有回報。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

我祈禱著。我一次又一次地祈禱。願她平安。
[cpg]

願孩子能安全出生。如果我願意，我願意用我的生命換取她的生命。
[cpg]

也許這個願望得到了回應，她生下了......。
[cpg]

她生下了一個孩子。我和信玄大人想要的孩子在這個世界上誕生了。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

;//[SE f=se000]
;//【ＳＥ】『赤子の泣き声』

[OnName num="keitarou"]
我很高興。 ......，我真的，真的很高興。 "
[cpg cn=true]


我們的孩子是個男孩。他正在歡快地哭泣。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen494"]
[OnName num="shingen"]
'我以前從未見過你哭。
[cpg cn=true]


[OnName num="keitarou"]
'我是那麼的高興。我們真的要成為一個家庭'。
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]

[VOICE f="Singen495"]
[OnName num="shingen"]
'是的。 ...... Geehaw, kehaw!　哈.......'。
[cpg cn=true]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

母親和孩子都是安全的。然而，信玄大人的肺結核並沒有痊癒。
[cpg]

我不知道信玄大人是否有可能繼續看著這個孩子長大。
[cpg]


[window target=false]
[BG f="b_13_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

幾個月和幾天過去了。我們的孩子已經長大了，而與謙信的戰鬥仍然沒有得到解決。
[cpg]

今天，蘭丸大人從信長大人那裡過來。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="2/3" time=800]

[VOICE f="Ranmaru463"]
[OnName num="ranmaru"]
'...... 你是父親？我無法想像那是什麼樣子的'。
[cpg cn=true]


[OnName num="keitarou"]
'我也沒有想像，但我終於開始感覺到了。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru464"]
[OnName num="ranmaru"]
 信玄大人還好嗎？
[cpg cn=true]


[OnName num="keitarou"]
這就是.......
[cpg cn=true]



[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

信玄大人的情況並不樂觀。如果他的情況繼續下去，他的壽命將不足五年。
[cpg]

想像一下與她死後的離別是很痛苦的。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Singen496"]
[OnName num="shingen"]
'蘭丸_......，你來了。
[cpg cn=true]


[FACE method="bow_4" pos="4/5"]

[VOICE f="Ranmaru465"]
[OnName num="ranmaru"]
'是的。你的健康狀況如何？ "
[cpg cn=true]


[FACE method="shake_4" pos="2/5"]

[VOICE f="Singen497"]
[OnName num="shingen"]
......，不那麼好，不那麼好。我不得不振作起來。
[cpg cn=true]


信玄大人看起來非常虛弱。我不希望看到她這樣的臉。
[cpg]

我想不惜一切代價救她。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


而有一條道路可能使這成為可能。
[cpg]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

隨著我們的孩子長大，她發展了神奇的能力。
[cpg]

這是傳說中的事。也就是說，超越時間的力量。
[cpg]

他有能力使他所接觸的物體在他的思想狀態下消失。
[cpg]

這可能是讓他們飛向未來。利用這種力量，我也許能回到今天。
[cpg]

也許。也許。 ......
[cpg]

[OnName num="keitarou"]
'信玄大人。我也許能給你帶來治療你的肺結核的藥。 "
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Singen498"]
[OnName num="shingen"]
'...... 我們在談論時間旅行，不是嗎？
[cpg cn=true]


我已經向信玄大人解釋過很多次了。在時間上來回走，即使在我的時代也沒有做過，但......。
[cpg]

我有一個想法，那就是我們的孩子在做什麼。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Singen499"]
[OnName num="shingen"]
'我還是很迷茫。不能保證你會回到未來，再次回到這裡。
[cpg cn=true]


[OnName num="keitarou"]
我會回來的。我甚至可以為你發明一台時間機器。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen500"]
[OnName num="shingen"]
什麼是時間機器？
[cpg cn=true]


信玄大人咯咯笑著。但他的臉色並不好。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

我沒有時間再花時間來做決定了。如果我現在不離開，我可能就做不到了。
[cpg]

[OnName num="keitarou"]
'......，那我就走了。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen501"]
[OnName num="shingen"]
'你真的要去。請確保你回來。
[cpg cn=true]


[OnName num="keitarou"]
'是的，我會的。我保證。 "
[cpg cn=true]


我拉著我孩子的手，我求他。
[cpg]

[OnName num="keitarou"]
我希望你能提醒我，就像你一直做的那樣。我希望你能讓我消失。
[cpg cn=true]


不知怎的，我有種感覺，這個孩子也明白我的意圖。
[cpg]

最後，我看著信玄大人，閉上了眼睛。
[cpg]


;//画面ゆがむ

[SE f=se018]
;//【ＳＥ】『タイムリープ　シンセ系の効果音』

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0xffffffff} time=2000]
[FACE method="change_4" pos="2/3"]
[WAIT time=500]
[WAIT time=2000]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1500]

[BG f="black.ui" time=1000]

[WAIT time=2000]
[BG f="b_11_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『博物館＿現代』（夕方）******************************************************

;//画面元に戻る

[OnName num="keitarou"]
'...... 這個地方。
[cpg cn=true]


在我回到過去之前，我已經回到了今天。
[cpg]

我環顧四周。我又回到了現在，而本該裝飾的折疊屏風本身已經消失了。
[cpg]

[OnName num="classmate_A"]
怎麼了，景太郎？你去哪裡了？
[cpg cn=true]


[OnName num="classmate_B"]
'......，你的肌肉變得更發達了嗎？　這是我的想像嗎？
[cpg cn=true]


甚至一個小時都沒有過去。自從我來到這裡，一切都沒有改變，除了折疊式屏幕。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


這一切都是幻覺嗎？它是真的嗎？
[cpg]

我在無法確認的情況下與家人團聚了。
[cpg]

但信玄大人和我們的孩子還在過去。
[cpg]

沒有辦法回去治愈信玄大人的肺結核。 ......。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『博物館＿現代』（昼）******************************************************

然後我開始參觀城堡和博物館，彷彿被什麼東西附身了。
[cpg]

從歷史事實來看，信玄是否留下了任何子女？我認識的信玄有孩子。
[cpg]

我查了一下，發現他有一些後人。這一點我已經發現了。
[cpg]

我離開博物館，想像著如果我沒有和信玄大人生下孩子，就不會發生這種事。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

然後我離開博物館，走了一會兒。
[cpg]

我只是情不自禁地再次見到她。
[cpg]

但還是......，也許。
[cpg]

[WAIT time=1100]

;//以降セリフ名前欄を「少女」と置き換えてください
[STOPBGM]


[VOICE f="Singen502"]
[OnName num="girl"]
'......，我在哪裡見過你嗎？
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（街を歩くヒロイン。主人公の方を向いてびっくりしている）ev_67
;//人物１：ヒロイン２　服装１：制服
;//場所　：現代＿街
;//時間　：昼
;//備考　：信玄本人ではなく、末裔です
;//========================================


;**【ＣＧ】 ev_67_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

[BGM f="bg_05"]


女孩看了看我，顯得很驚訝。
[cpg]

她的外表與信玄大人非常相似。
[cpg]

[OnName num="keitarou"]
你是 .......
[cpg cn=true]



[VOICE f="Singen503"]
[OnName num="girl"]
那個女孩看著我，顯得很驚訝。我不知道為什麼。
[cpg cn=true]


甚至他們說話的方式也完全一樣。我發現自己流下了眼淚。
[cpg]


[VOICE f="Singen504"]
[OnName num="girl"]
我想我......，看到你在什麼地方流淚了。
[cpg cn=true]



;//ブラックアウト

;//ＥＮＤ　ヒロイン２ルート

[SCENE id=13]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="epend.ks" target="*start"]

;//==============================





