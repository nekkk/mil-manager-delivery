
*start
;//姫武将　全年齢移植用シナリオ

;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり

;//信長　　　　　　着衣
;//信玄　　　　　　着衣
;//謙信　　　　　　着衣
;//光秀　　　　　　着衣
;//蘭丸　　　　　　着衣

;//上記以外のキャラクターには音声がありません

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//信長　　　　　　一人称「私（わたし）」　信玄呼び「信玄」　謙信呼び「謙信」
;//　　　　　　　　光秀呼び「光秀」　蘭丸呼び「蘭丸」　景太郎呼び「景太郎」
;//信玄　　　　　　一人称「私（わたし）」　信長呼び「信長」　謙信呼び「謙信」
;//　　　　　　　　光秀呼び「光秀」　蘭丸呼び「蘭丸」　景太郎呼び「景太郎」
;//謙信　　　　　　一人称「わたくし」　信長呼び「信長」　信玄呼び「信玄」
;//　　　　　　　　光秀呼び「光秀」　蘭丸呼び「蘭丸」　景太郎呼び「景太郎さん」
;//光秀　　　　　　一人称「私（わたし）」　信長呼び「信長様」　信玄呼び「信玄様」
;//　　　　　　　　謙信呼び「謙信」　蘭丸呼び「蘭丸」　景太郎呼び「景太郎さん」
;//蘭丸　　　　　　一人称「あたし」　信長呼び「信長様」　信玄呼び「信玄様」
;//　　　　　　　　謙信呼び「謙信」　光秀呼び「光秀」　景太郎呼び「景太郎」

;//景太郎　　　　　一人称「俺」　信長呼び「信長様」　信玄呼び「信玄様」
;//　　　　　　　　謙信呼び「謙信」　光秀呼び「光秀様」　蘭丸呼び「蘭丸様」
;//　　　　　　　　ただし、謙信ルートでは謙信を「謙信様」と呼ぶ

;//以下、残したＣＧを列挙いたします
;//信長 ev_01 ev_07 ev_24 ev_47 ev_68 紹介ページのCG
;//信玄 ev_29 ev_56 ev_67 ev_69
;//謙信 ev_48 ev_57 ev_58 ev_63
;//光秀 ev_34 ev_53 紹介ページのCG
;//蘭丸 ev_14 ev_36 紹介ページのCG


;//////////////////////////////////////
;///////////////以下本編///////////////
;//////////////////////////////////////


;#################################################
*Ep000|穿外國服裝的人。
;#################################################

[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]

[stflag Selectflg1=0]
[stflag Selectflg2=0]
[stflag Selectflg3=0]
[stflag Selectflg4=0]



[SCENE id=0]

;//ブラックアウト
[window target=true]
[BG f="black.ui" time=1000]
[WAIT time=1000]

不是單純的睡眠。不過，我還是敢於把它與睡眠相比較：......
[cpg]

這就像在通宵達旦之後，在睡了大約12個小時之後。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『森の中』（夕方）******************************************************

[OnName num="keitarou"]
'這是......？
[cpg cn=true]


我當時完全失去了知覺。我在一個完全未知的地方。
[cpg]

我在一個森林裡。我試圖追踪我模糊的記憶，但我的意識太過混沌。
[cpg]

須藤景太郎。我可以記住我的名字。
[cpg]

我記得在我睡著之前。我當時正在學校旅行，我想，發生了什麼事......。
[cpg]

[OnName num="keitarou"]
'......，我的頭很痛。
[cpg cn=true]


我不知道為什麼，我不能永遠呆在那裡，我在森林裡行走。
[cpg]


[SE f=se027]
;//【ＳＥ】『山道歩く』

;//ブラックアウト
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

我甚至不知道我已經睡了多久。
[cpg]

這種感覺是，我已經睡了相當長的時間，正如我先前所想的那樣。
[cpg]

但奇怪的是，我並不餓。我想知道我是否被置於睡眠狀態，而不是被睡了。
[cpg]


[window target=false]
[free time=1000]
[BG f="b_10_3.ui" time=1000]
[WAIT time=2000]
[window target=true]

;//【ＢＧ】『村』（夕方）******************************************************

[OnName num="keitarou"]
'這是個村莊，.......
[cpg cn=true]


但這是一個可怕的農村。我想知道我是否被傳送到了其他地方。
[cpg]

我正這麼想著，一個看起來像村民的人向我走來。
[cpg]

[OnName num="villager"]
'你是......？　你的穿著很奇怪。
[cpg cn=true]


[OnName num="keitarou"]
'......，這附近不是有一個博物館嗎？
[cpg cn=true]


[OnName num="villager"]
一個博物館？　那是什麼？
[cpg cn=true]


模糊的意識正在被恢復。
[cpg]

彷彿見到人們並與他們交談使我意識到這不是一個夢。
[cpg]

[OnName num="keitarou"]
'嗯，讓我看看。我當時在博物館裡，我想'。
[cpg cn=true]



發生了什麼事？如果我不好好記住，那就真的很糟糕了。
[cpg]

我在哪裡？你不可能走太遠。
[cpg]

[OnName num="keitarou"]
'是的，我是。我聽到有聲音從折疊式屏幕上傳來'。
[cpg cn=true]


有關於戰國時期和其他方面的展覽，我聽到其中一個屏幕上傳來的聲音。
[cpg]

我想這是一個女孩的聲音，但從折疊式屏幕上聽到的聲音很奇怪。
[cpg]

[OnName num="keitarou"]
...... 不可能。 "
[cpg cn=true]

[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

記憶是相通的。事實上，這個聲音是一個女孩的聲音，這很奇怪，但它是有意義的。
[cpg]

我觸摸著折疊式屏幕，彷彿被拉了進去。從那裡開始，我就失去了知覺。
[cpg]

而這個村莊不僅僅是農村。
[cpg]

建築風格過於古老，這意味著。
[cpg]

[OnName num="villager"]
怎麼了？　你看起來很蒼白。 "
[cpg cn=true]


我有一個假設。難道說這個地方是。
[cpg]

[OnName num="keitarou"]
"戰國時期......？"
[cpg cn=true]


他點點頭，彷彿不認識我嘀咕的話語。
[cpg]

[OnName num="villager"]
總之，如果你沒有地方可去，就在這裡過夜。
[cpg cn=true]


[free time=1000]
[BG f="b_10_4.ui" time=1000]
[WAIT time=2000]
[window target=true]

;//【ＢＧ】『村』（夜）******************************************************

心煩意亂。雖然我是這樣，但我本能地知道不要急於行動。
[cpg]

我有很多問題想問，但我現在不應該著急。
[cpg]

我決定在一家私人住宅過夜。
[cpg]

還向我提供了一些食物作為晚餐。我很感激，但食物太簡單了。
[cpg]

我想知道這個地方是否真的很現代？　我想知道這是否真的是現在的日子。
[cpg]

[OnName num="villager_A"]
但是，這仍然是一件奇怪的和服。
[cpg cn=true]


[OnName num="villager_B"]
也許這就是傳說中關於他的說法。
[cpg cn=true]


[OnName num="keitarou"]
'羅爾......？
[cpg cn=true]


[OnName num="villager_C"]
'有這樣一件事。 '穿著外國的衣服的人。 '穿異國服裝的人，以公主軍閥為紐帶，將生下吃天的兒子。
[cpg cn=true]


什麼是 "公主軍閥"？我從來沒有聽說過它。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

那地方沒有電，更沒有手機信號。
[cpg]

此外，步行到最近的城鎮需要很長的時間。
[cpg]

這是一個很難相信的情況，但似乎每個人都沒有說謊。
[cpg]

[SE f=se027]
;//【ＳＥ】『山道歩く』

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『森の中』（夜）******************************************************

然後，在深夜。我聽到了奇怪的聲音，並向森林走去。 ......
[cpg]

;//しばらく、信長の名前欄を「謎の少女」と隠してください

他們在那裡，一些人穿得像戰士，......
[cpg]

有一個女孩，她是如此美麗，以至於我不能不佩服她。出於某種原因，她拿著一把劍。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Nobunaga001"]
[OnName num="mysterious_girl"]
'你是誰？告訴我你的名字。 "
[cpg cn=true]


[OnName num="keitarou"]
'我是須藤，...... 須藤景太郎，但你是誰？
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga002"]
[OnName num="mysterious_girl"]
你不知道我是誰嗎？你為什麼在這裡？
[cpg cn=true]


她看起來像一個老公主，但也像一個軍閥。
[cpg]

你說的公主軍閥，是指這個人......？
[cpg]


;//ここから、信長の名前を隠さないでください

[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga003"]
[OnName num="nobunaga"]
'我是織田信長。你，你叫景太郎'。
[cpg cn=true]


這對我來說太突然了，我無法在腦海中把它搞清楚。
[cpg]

首先，織田信長不僅已經去世，而且生活在幾百年前。
[cpg]

第二，那個織田信長不可能是個女孩。
[cpg]

[OnName num="keitarou"]
這很荒唐。 ......
[cpg cn=true]

[STOPBGM]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga004"]
[OnName num="nobunaga"]
'有什麼你不同意的嗎？　好吧，不管有沒有，你只有一件事要做。 "
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
那個自稱信長的女孩向我伸出了她的劍。
[cpg]

[BGM f="bg_06"]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga005"]
[OnName num="nobunaga"]
'你能駕馭一把劍嗎？如果你不能，你現在不擁有它，你可能會死。
[cpg cn=true]


[OnName num="keitarou"]
你是什麼意思？ "
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga006"]
[OnName num="nobunaga"]
我被強盜包圍了。我無法單獨與他們戰鬥。如果你只是站在那裡，你很有可能會被殺死。
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


我無法相信這一點。我是在做夢嗎？
[cpg]

那個女孩問你是否能駕馭一把劍。這是真的，沒有什麼是我不能處理的。
[cpg]

我屬於劍道俱樂部。我仍然認為我很擅長這個。 ......
[cpg]

但當涉及到向人揮拳時，情況就不同了。
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Nobunaga007"]
[OnName num="nobunaga"]
'它來了。那裡已經有一個標誌了'。
[cpg cn=true]



[SE f=se022]
;//【ＳＥ】『草木揺れる』

當我在考慮該怎麼做時，我當然能感覺到有人在靠近。
[cpg]

我認為。擺脫這種情況的最好辦法是什麼？
[cpg]


;////////////////////////////////////////////////////

;//オレは姫武将を孕ませたい！　マップシステムに関して

;//体験版及び本編中に、ゲーム性を持たせるためマップを用いたパートを用意します。
;//マップパートでは選択肢によって、勝利、敗北の二種類に分かれます

;//マップパートでは、

;//１→２→３
;//↓　↓　↓
;//４→５→６
;//↓　↓　↓
;//７→８→９

;//という形で９マスあり「１」のマスからスタートし「９」までたどり着けばクリアとなります
;//下に進むか右に進むかという形で二択あり、合計四回選択します
;//ルートは全六種類になります
;//（選択肢は「南へ進む」「東へ進む」の二種類となります）

;//賊が「２」「６」「７」に待ち構えているという設定で
;//二度通ると敗北となります
;//今回のイベントでは、敗北でゲームオーバーとなりますが、ストーリーが分岐する場合もあります

;////////////////////////////////////////////////////


;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※最初の戦闘　開始時（１のマスにいる場合のシナリオ）※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※

;//ブラックアウト
;//【ＢＧ】『森の中』（夜）
;//ヒロイン１の立ち絵を表示してください

[OnName num="keitarou"]
'總之，我們離開這裡吧。
[cpg cn=true]

她點點頭。 '我們不知道匪徒在哪裡。
[cpg]

我想我看到一些灌木叢向東移動。 ......
[cpg]




;//■選択肢
[switch]
[case "'我們將繼續向南。"]
	[swap]
	[jump target="*select01_4"]
[case "向東走。"]
	[swap]
	[jump target="*select01_2"]
[endswitch]

1，向南行進。
2，向東行進。


;//==============================
;//１、南へ進む

;//同じイベント中の「４のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「２のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※２のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_2|'穿外國服裝的人。

[stflag Selectflg1=1]


[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


[OnName num="keitarou"]
'¡ !　請退開！ "
[cpg cn=true]


匪徒出現了。他們向我撲來。
[cpg]


[SE f=se019]
;//【ＳＥ】『剣戟』

經過一場劍鬥，我打傷了那個強盜。
[cpg]

他們往回跑，我也不去追他們。
[cpg]

我已經沒有力氣了。如果我再遇到他們，他們可能會很危險。 ......
[cpg]


;//■選択肢
[switch]
[case "向南前進。"]
	[swap]
	[jump target="*select01_5"]
[case "向東走。"]
	[swap]
	[jump target="*select01_3"]
[endswitch]

1，向南走。
2、向東走。


;//==============================
;//１、南へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「３のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※３のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_3|那個穿外國斗篷的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン１の立ち絵を表示してください

東面的道路與其說是森林，不如說是陡峭的山峰。
[cpg]

如果發生這種情況，我們別無選擇，只能繼續南下。
[cpg]

我看著她，她擔心地看著我，很累。
[cpg]

[OnName num="keitarou"]
'......，我不會有事的。別擔心。 "
[cpg cn=true]



;//■選択肢
[switch]
[case "向南行進"]
	[swap]
	[jump target="*select01_6"]
[endswitch]

1，向南行進。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※４のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_4|那個穿外國斗篷的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

這真是太安靜了。沒有看到強盜。
[cpg]

謹慎行事。在這種情況下，沒有安全的把握。
[cpg]

我感覺到來自南方的存在，但我不確定我是否應該繼續朝這個方向走。
[cpg]


;//■選択肢
[switch]
[case "向南前進。"]
	[swap]
	[jump target="*select01_7"]
[case "繼續向東走。"]
	[swap]
	[jump target="*select01_5"]
[endswitch]

1，向南行進。
2，向東行進。


;//==============================
;//１、南へ進む

;//同じイベント中の「７のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※５のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_5|那個穿外國斗篷的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン１の立ち絵を表示してください

我們現在是在森林中一個稍微開放的地方。
[cpg]

她很緊張，但看起來並不累。
[cpg]

我想知道是否只有我一個人感到緊張。 ......
[cpg]


;//■選択肢
[switch]
[case "向南行進。"]
	[swap]
	[jump target="*select01_8"]
[case "向東走。"]
	[swap]
	[jump target="*select01_6"]
[endswitch]

1，向南行進。
2，向東行進。


;//==============================
;//１、南へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※６のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_6|穿著外國斗篷的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[if exp={getFlagValue("Selectflg1") == 1 }]
[jump target="*select01_6_2t"]
[endif]

[jump target="*select01_6_2f"]


;//==============================
;//２のマスを通っていた場合

*select01_6_2t|那個穿外國斗篷的人。

再次，土匪從灌木叢中出現。
[cpg]

我措手不及，我以最快的速度走上前去保護她。
[cpg]

[OnName num="keitarou"]
'什麼！ ......'
[cpg cn=true]

[SE f=se020]
;//【ＳＥ】『刀振るう』

[window target=false]
[free time=500]
[BG f="red.ui" time=500]
[WAIT time=500]
[BG f="b_08_4.ui" time=500]
[WAIT time=500]
[window target=true]


當我意識到自己受了致命傷時，已經太晚了。
[cpg]


;//ブラックアウト
[SE f=se016]
;//【ＳＥ】『倒れる』
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

我為什麼在這裡？她是誰？
[cpg]

一切的真相仍未揭曉，而我也耗盡了力量。 ......
[cpg]


;//ゲームオーバー

[jump storage="epend.ks" target="*back_title"]


;//==============================
;//２のマスを通っていない場合

*select01_6_2f|穿著異國他鄉服裝的人

[OnName num="keitarou"]
'嘿!　請留步！ "
[cpg cn=true]


一個強盜出現了。他們向我撲來。
[cpg]


[SE f=se019]
;//【ＳＥ】『剣戟』

經過一場劍鬥，我打傷了那個強盜。
[cpg]

他們往回跑，我也不去追他們。
[cpg]

我已經沒有力氣了。如果我再遇到他們，他們可能會很危險。 ......
[cpg]


;//■選択肢
[switch]
[case "向南行進。"]
	[swap]
	[jump target="*select01_9"]
[endswitch]

1，向南行進。


;//==============================
;//１、南へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※７のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_7|'穿上外國土地的服裝的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[SE f=se022]
;//【ＳＥ】『草木揺れる』

[OnName num="keitarou"]
'Psst!　請留步！ "
[cpg cn=true]


匪徒出現了。他們向我撲來。
[cpg]


[SE f=se019]
;//【ＳＥ】『剣戟』

經過一場劍鬥，我打傷了那個強盜。
[cpg]

他們往回跑，我也不去追他們。
[cpg]

我已經沒有力氣了。如果我再遇到他們，他們可能會很危險。 ......
[cpg]


;//■選択肢
[switch]
[case "向東行進。"]
	[swap]
	[jump target="*select01_8"]
[endswitch]

1，向東行進。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※８のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_8|穿著外國衣服的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン１の立ち絵を表示してください

我們快穿過森林了。看起來我們會設法挽救我們的生命。
[cpg]

即便如此，我們也不能放鬆警惕。她仍然很警覺。
[cpg]


;//■選択肢
[switch]
[case "向東走。"]
	[swap]
	[jump target="*select01_9"]
[endswitch]

1，向東行進。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※９のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_9|穿外國服裝的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//マップシステム終了。下記のシナリオへ進む

如果我不殺她，她可能會殺我。我已經準備好了。
[cpg]

我揮舞著我的劍，打算給那個從灌木叢中出現的人造成致命的傷害。
[cpg]


[SE f=se020]
;//【ＳＥ】『刀振るう』

鮮血飛濺。感覺不是很深的傷口，但足以讓他無法戰鬥。
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Nobunaga009"]
[OnName num="nobunaga"]
這很好。別猶豫了。 "
[cpg cn=true]


我可以感覺到腎上腺素在我體內湧動。他繼續揮舞著他的劍。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『森の中』（夜）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga010"]
[OnName num="nobunaga"]
'你很會用劍。我以前從未見過這樣的劍。
[cpg cn=true]


結果是，我們得到了拯救。土匪們幾乎都被武士和信長打敗了。
[cpg]

[OnName num="keitarou"]
'...... Hon'ble really, Oda Nobunaga, is it?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Nobunaga011"]
[OnName num="nobunaga"]
'你說我粗魯。但現在你卻救了我的命？
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga012"]
[OnName num="nobunaga"]
'的確，我是織田信長。假設我在撒謊，就沒有任何好處了'。
[cpg cn=true]


她又這樣稱呼自己。 '你看起來不像是在撒謊。
[cpg]

她甚至讓我拿著劍，砍死強盜。我不認為這都是一個陷阱。
[cpg]

但如果她真的是織田信長，那我就有大麻煩了。
[cpg]

[OnName num="keitarou"]
'這是一個時間滑塊......？　不，是一個平行世界'。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga013"]
[OnName num="nobunaga"]
'...... 什麼？　這是一個陌生的術語。
[cpg cn=true]


我還認為這是一個平行世界，因為信長不是一個人。
[cpg]

或者說，被認為是男性的歷史是錯誤的。 ...... 當我在思考這個問題的時候，一個自稱信長的女孩插話進來。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga014"]
[OnName num="nobunaga"]
讓我們回到城堡去。對不起，佔用了你們這麼多時間，伙計們。
[cpg cn=true]


她向戰士們呼喊。城堡是......，真的是城堡嗎？
[cpg]

[OnName num="keitarou"]
'哪裡是城堡？
[cpg cn=true]


我可能是在問一個愚蠢的問題。
[cpg]

但我忍不住要問。我只想知道它在哪裡，有多少年了。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga015"]
[OnName num="nobunaga"]
'是清洲城。難道你也不知道嗎？ "
[cpg cn=true]


清洲城。僅僅通過聽到這個名字，有些人可能就能知道這是哪一年。
[cpg]

但我不知道。如果要我說，我隱約知道它在哪裡。 ......
[cpg]

它離我搬家前所在的博物館並不遙遠，這是肯定的。
[cpg]

這足以證實這一事件不是一個夢。
[cpg]

[OnName num="keitarou"]
'現在是哪一年？
[cpg cn=true]


信長回答說，臉上帶著疑惑的表情。
[cpg]

[FACE method="shake_5" pos="2/3"]

[VOICE f="Nobunaga016"]
[OnName num="nobunaga"]
'你是誰，你不知道現在是什麼時候？
[cpg cn=true]

;//様は年号を言うが、俺はそれ聞いてもやっぱりピンとこない。いつ頃だろう。
他告訴我那一年，但我還是無法理解。是什麼時候的事？
[cpg]

我可以猜到，這一定是戰國時期，但我不知道信長將來會變成什麼樣子。 ......
[cpg]


;//ブラックアウト
[SE f=se014]
;//【ＳＥ】『歩く』

[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=1]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

我們走了一會兒。我對戰士們的行走速度感到驚訝，儘管他們的武器相當重。
[cpg]

信長正在領導這種形式。這也很令人驚訝，......，儘管她是個女孩。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga017"]
[OnName num="nobunaga"]
'景太郎。你說你不知道現在是哪一年，是什麼意思？　還有，這身衣服是怎麼回事？
[cpg cn=true]


我很快就被叫了出去。他還問我問題，彷彿我就是那個回到過去的人。
[cpg]

[OnName num="keitarou"]
'我也還沒有完全想明白。但......，等我安頓好了，我會告訴你一切。 "
[cpg cn=true]


告訴他們我所知道的事情可能是個壞主意。
[cpg]

如果未來被改變，我的存在會發生什麼？
[cpg]

我無法想像如果時間悖論真的發生，會發生什麼。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

我走了相當長的時間。夜間行走很困難，但我到達了......。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga018"]
[OnName num="nobunaga"]
我們在這裡。清洲城"。
[cpg cn=true]


[OnName num="keitarou"]
...... 是驚人的。它看起來像是剛剛建成的。
[cpg cn=true]


在晚上很難看到，但你還是可以看出來。
[cpg]

當我想到城堡時，我想像的是一個古老的結構，但這時的情況並非如此。
[cpg]

[OnName num="keitarou"]
'所以這種技術在這個時間段存在。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga019"]
[OnName num="nobunaga"]
那麼你的意思是什麼呢？你是說這個時間段嗎？
[cpg cn=true]


[OnName num="keitarou"]
'...... 不，我是說......'
[cpg cn=true]

[free time=1000]

正當我不知所措的時候，我聽到城堡里傳來一個聲音。
[cpg]


;//しばらく、蘭丸の名前を「少女」と置き換えてください
;//girl

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="4/5" time=800]

[VOICE f="Ranmaru001"]
[OnName num="girl"]
'你安全嗎!　信長大人！ '
[cpg cn=true]


另一個女孩出現在去城堡的路上。
[cpg]

[FACE method="shock_4" pos="4/5"]

[VOICE f="Ranmaru002"]
[OnName num="girl"]
'我一直在找你......，請你離開城堡時告訴我。
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga020"]
[OnName num="nobunaga"]
'對不起，我睡不著，因為我的心在狂跳。我正走在我的心所到之處，她就在那裡。
[cpg cn=true]


另一個拿著劍的女孩。這在這個世界上是一件正常的事情嗎？
[cpg]

如果像信長這樣強大的軍閥是一個女孩，可能還有其他的例子。
[cpg]

[OnName num="keitarou"]
你是誰......？ "
[cpg cn=true]


我問她。我問她，也許她認識這位將軍。
[cpg]


;//ここから蘭丸の名前を置き換えないでください

[FACE method="change_7" pos="4/5"]

[VOICE f="Ranmaru003"]
[OnName num="ranmaru"]
我是森蘭丸，....... 你是誰？
[cpg cn=true]


[OnName num="keitarou"]
我是須藤景太郎。
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru004"]
[OnName num="ranmaru"]
景太郎 ......?　信長大人，他是誰？
[cpg cn=true]


首先要做的是找出問題所在。
[cpg]

[FACE method="shake_7" pos="2/5"]

[VOICE f="Nobunaga021"]
[OnName num="nobunaga"]
'這我也不知道。我甚至不能讓景太郎本人和我說話。
[cpg cn=true]


我什麼都答不上來，這是事實。
[cpg]

[FACE method="change_5" pos="4/5"]

[VOICE f="Ranmaru005"]
[OnName num="ranmaru"]
在城堡裡有這樣一個人，安全嗎？ "
[cpg cn=true]


蘭丸的問題是一個公平的問題。我相信你會這樣想的，不是嗎？
[cpg]

這是一個人們殺人遠比今天多的時代。
[cpg]

我認為可以說這是一個人們難以信任他人的時代。然而。
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="Nobunaga022"]
[OnName num="nobunaga"]
景太郎保護了我。我沒有向他宣誓效忠，但他救了我的命。 "
[cpg cn=true]


蘭丸嗤之以鼻。看著我，他說。
[cpg]

[FACE method="change_7" pos="4/5"]

[VOICE f="Ranmaru006"]
[OnName num="ranmaru"]
'...... 是這樣的嗎？這樣一個看起來很弱的東西.......'
[cpg cn=true]


我認為這確實很不禮貌，但他們確實看起來比女孩們更強壯。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************


我想到的是，當你看到城堡裡的女人時，你就會知道你要去見她。在此期間，我想。
[cpg]

自稱信長的人和自稱蘭丸的人看起來都老得可以稱為女孩。
[cpg]

更重要的是，他們在年齡上似乎相差不遠。
[cpg]

蘭丸比她小一點，也可能和她同齡。
[cpg]

從歷史事實來看，情況不應該是這樣的。這張圖片莫名其妙地告訴我們，信長和蘭丸的年齡比對方大很多。
[cpg]

我知道我已經誤入了一個與歷史現實不同的世界。
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Nobunaga023"]
[OnName num="nobunaga"]
怎麼了？　你似乎陷入了沉思。
[cpg cn=true]


[OnName num="keitarou"]
'不，我只是有點......，對一些事情感到好奇。
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]

[VOICE f="Nobunaga024"]
[OnName num="nobunaga"]
我明白了。你可以稍後告訴我你在想什麼，你是誰。
[cpg cn=true]


他們是非常寬容的。也許我勇敢地戰鬥是件好事。
[cpg]

信長的形像是一個脾氣粗暴的人，但......。
[cpg]

我認為她是一個更高尚的人，而不僅僅是一個脾氣粗暴的人。
[cpg]


[SE f=se024]
;//【ＳＥ】『床歩く』

[free time=1000]

在通道的中間，我與信長分開，走得更遠。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru007"]
[OnName num="ranmaru"]
'這邊走。跟著我。
[cpg cn=true]


[SE f=se024]
;//【ＳＥ】『床歩く』

;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru008"]
[OnName num="ranmaru"]
'暫時睡在這裡。你現在被當作客人對待。 "
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


它是相當寬敞的。他們要給我一個這樣的房間。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru009"]
[OnName num="ranmaru"]
他們怎麼能把這樣的房間分配給一個身份不明的人呢？ "
[cpg cn=true]


而蘭丸似乎也是這麼想的。
[cpg]

[OnName num="keitarou"]
'我很抱歉.......'
[cpg cn=true]


我盡可能快地道歉了。我感覺蘭丸在某種程度上不喜歡我。
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Ranmaru010"]
[OnName num="ranmaru"]
'沒有什麼可道歉的。 '這是信長大人的主意，所以一定有其道理。
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru011"]
[OnName num="ranmaru"]
'我明天會問你的背景和東西。現在，現在就休息。
[cpg cn=true]


[OnName num="keitarou"]
謝謝你。 "
[cpg cn=true]


我向她表示感謝，並看著蘭丸離開。
[cpg]


[SE f=se025]
;//【ＳＥ】『ふすま閉まる』
[free time=1000]

你是孤獨的，你感覺到你遇到了很多麻煩。
[cpg]

我真的不知道發生了什麼事。 ......
[cpg]

與其說是我回到了過去，不如說是我回到了過去本身。
[cpg]

織田信長是個女人的事實。
[cpg]

與我所處的今天真的有聯繫嗎？
[cpg]

我聽說日本的歷史還有很多方面沒有被理解。
[cpg]

即使是這樣，日本統治者的性別有可能不同嗎？
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我無法正常思考任何問題。我很累，睡得很好。 ......
[cpg]

第二天早上：......
[cpg]


[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿城内』（朝）******************************************************

被邀請到城堡後的第二天。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru012"]
[OnName num="ranmaru"]
'信長大人要見你。跟著我。 "
[cpg cn=true]


蘭丸來到了他的房間。
[cpg]

[OnName num="keitarou"]
'...... 是。
[cpg cn=true]


我仍然很困，但我不能呆在床上。
[cpg]


[window target=false]
[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************

[SE f=se024]
;//【ＳＥ】『床歩く』

蘭丸帶我在陌生的建築中散步。
[cpg]

我再次意識到，我真的穿越到了過去。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru013"]
[OnName num="ranmaru"]
'......，你昨晚睡覺了嗎？
[cpg cn=true]


[OnName num="keitarou"]
'是啊，好在.......'
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru014"]
[OnName num="ranmaru"]
'你的膽子可真大。如果我不知道自己要做什麼，我就無法入睡。
[cpg cn=true]


我還不太確定我是否安全。我還不確定我是否安全。
[cpg]

但我確實太累了，以至於我睡著了。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（朝）******************************************************

我走到的地方可能是信長的房間。
[cpg]

這個房間比我所在的房間要豪華幾步。
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="Nobunaga025"]
[OnName num="nobunaga"]
蘭丸。你在外面等著。 "
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru015"]
[OnName num="ranmaru"]
'但是......，只要我們不知道他的身份，我們就不知道他可能會做什麼。
[cpg cn=true]


蘭丸似乎很擔心信長。我沒有任何武器。
[cpg]

[FACE method="shake_3" pos="2/5"]

[VOICE f="Nobunaga026"]
[OnName num="nobunaga"]
'沒有什麼可擔心的。
[cpg cn=true]

[free time=1000]

蘭丸猶豫了片刻，然後推辭了。
[cpg]

信長隨後走過來，認真地看著我。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga027"]
[OnName num="nobunaga"]
'你在燈光明亮的地方看起來更不尋常。
[cpg cn=true]


[OnName num="keitarou"]
'......，我想是的。
[cpg cn=true]


'在這個時代，校服是一種很不尋常的裝束。
[cpg]


;//下記のセリフ、台本では
;//「お前はどこから来たんだ？　言葉は通じるようだが、服装はこの国のものではないように見えるが……」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga028"]
[OnName num="nobunaga"]
你來自哪裡？　你似乎會說這種語言。
[cpg cn=true]


[OnName num="keitarou"]
那是......."
[cpg cn=true]


當我的回答支支吾吾時，信長說：'我不知道你是誰，但我不能呆在城堡裡。
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga029"]
[OnName num="nobunaga"]
'我不能允許一個身份不明的人留在城堡裡。回答我'。
[cpg cn=true]


我覺得我別無選擇，只能回答。在這個時代，如果沒有一個盟友就被扔出去，那就糟糕了。
[cpg]

我沒有選擇，只能誠實地回答。無論你是否相信我，......
[cpg]

[OnName num="keitarou"]
'......，我來自另一個時代。來自比現在更遠的未來。 "
[cpg cn=true]


說'時間旅行'首先就不應該表達出橫排的字樣。
[cpg]

[OnName num="keitarou"]
'把它稱為時間旅行會不會更好，......，或者在這個時間段有這樣的概念？
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Nobunaga030"]
[OnName num="nobunaga"]
'來自另一個時間段，...... hmm。
[cpg cn=true]


信長陷入了深思。他沒有嘲笑我，也沒有因為我說了實話而生氣。
[cpg]

[OnName num="keitarou"]
'你無法想像我說這話時在說什麼。在這個時代，甚至不應該有這樣的創造力'。
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga031"]
[OnName num="nobunaga"]
'不，這不是一個我不理解的故事。如果我回到平安時代，我就會因為我的滑稽裝束而被人嘲笑'。
[cpg cn=true]


據說，信長是一個非常敏銳的人。
[cpg]

他......，她可能能夠理解戰國時期的人所不能理解的事情。
[cpg]

在一個本來沒有時間滑坡概念的時代，信長是非常敏銳的。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga032"]
[OnName num="nobunaga"]
"你是說，在你的時代，他們可以隨意做那種事？　這很有趣。
[cpg cn=true]


[OnName num="keitarou"]
是的，它是。我穿越時空更多是一種巧合，或者說我沒有這種技術。 ......。
[cpg cn=true]


[OnName num="keitarou"]
我在博物館裡摸到了一個折疊屏，被帶到了這個世界。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga033"]
[OnName num="nobunaga"]
'這聽起來越來越有道理。如果他被捲入超自然現象，就可以解釋為什麼他在這樣的時候獨自前來。
[cpg cn=true]


信長並沒有懷疑。相反，他思維敏捷，理解得太快了。
[cpg]

[OnName num="keitarou"]
'你相信我嗎？
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga034"]
[OnName num="nobunaga"]
'是的，我知道。 '是的，我相信他們，如果他們來自未來，我想把他們留在身邊。
[cpg cn=true]


...... 我明白了。這樣想很自然嗎？
[cpg]

我知道信長的事。為人處世，在本能寺事變中自殺。
[cpg]

我知道，如果我跟隨信長，未來可能會改變。
[cpg]

換句話說，也許未來會有信長執掌國家大權，統治日本的時候，......。
[cpg]

但就在我這樣想的時候。
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga035"]
[OnName num="nobunaga"]
'只是不要告訴我未來的事。而且不要告訴其他人。 "
[cpg cn=true]


[OnName num="keitarou"]
為什麼？　我也許能夠幫助你。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga036"]
[OnName num="nobunaga"]
如果你知道未來，你可以做任何你想做的事。我不想成為一個懦夫。
[cpg cn=true]


...... 是這樣想的嗎？信長似乎想要一場公平的戰鬥，即使是在他的生命受到威脅的情況下。
[cpg]

但我確實想成為有用的人。這種生活是互利的。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga037"]
[OnName num="nobunaga"]
'換個話題，你知道我們生活在什麼樣的時代嗎？
[cpg cn=true]


[OnName num="keitarou"]
'在某種程度上。不過，歷史從來不是我的強項。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga038"]
[OnName num="nobunaga"]
'關於這一點，你必須從蘭丸那裡得到一個解釋。在任何情況下，你都是有趣的。
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


然後我得到了一頓飯。
[cpg]

至少信長在努力讓我活著。
[cpg]

我不知道蘭丸對此有何感想，但我知道我受到了某種程度的慷慨對待。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru016"]
[OnName num="ranmaru"]
'搞什麼鬼，你......！　你突然來了，信長大人喜歡你'。
[cpg cn=true]


蘭丸在我們移動時對我說了這句話。
[cpg]

[OnName num="keitarou"]
我很抱歉。
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]

[VOICE f="Ranmaru017"]
[OnName num="ranmaru"]
不要馬上道歉!　你甚至不知道什麼是錯的。
[cpg cn=true]


我不確定我是否願意。
[cpg]

我相信蘭丸是在本能寺與信長一起喪生的。
[cpg]

它叫做一蓮獸，或者是我最親近的人。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

儘管他很煩躁，蘭丸還是向我解釋了這一時期的情況。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru018"]
[OnName num="ranmaru"]
'室町幕府，至少你知道。 '不管是多少。
[cpg cn=true]


[OnName num="keitarou"]
'不，不，...... 那個。
[cpg cn=true]


'信長阻止我告訴你，我來自另一個時代。
[cpg]

[OnName num="keitarou"]
'我已經告訴了信長，但我不知道我是否能告訴你所有的事情。
[cpg cn=true]


蘭姆魯改變了他血腥的想法，說。
[cpg]

[FACE method="shock_3" pos="2/3"]

[VOICE f="Ranmaru019"]
[OnName num="ranmaru"]
'信長大人，對!　如果你要叫我，就用'Sama'叫我！ '
[cpg cn=true]


他說了一句話，似乎當然是對的。
[cpg]

信長大人是對的，不是嗎？我才是那個被保住性命的人。
[cpg]

[OnName num="keitarou"]
'......，我已經告訴了信長大人，但我不知道能不能把一切都告訴蘭丸大人。
[cpg cn=true]


[FACE method="change_5" pos="2/3"]

[VOICE f="Ranmaru020"]
[OnName num="ranmaru"]
'管他呢，那是......，很好。
[cpg cn=true]


蘭丸大人吃了一驚，但還是告訴了我這個時期的情況。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru021"]
[OnName num="ranmaru"]
'幕府失去了權力。說得很簡單，守護神們消失了。
[cpg cn=true]


[OnName num="keitarou"]
'守護封建領主......？
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru022"]
[OnName num="ranmaru"]
你真的不知道，是嗎？好吧，我告訴你。 "
[cpg cn=true]


我甚至在普通教育水平上都不了解日本歷史。我對歷史真的很不擅長。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru023"]
[OnName num="ranmaru"]
'他們被稱為戰國大名的東西所取代。就像他們的名字不同一樣，他們的性質也完全不同。
[cpg cn=true]


[OnName num="keitarou"]
他們被稱為千石，所以他們在戰鬥，不是嗎？
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru024"]
[OnName num="ranmaru"]
'他們在打......？　為什麼是過去式呢？
[cpg cn=true]


哦，不。這也很有趣。
[cpg]

[OnName num="keitarou"]
我們在戰鬥，不是嗎？
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru025"]
[OnName num="ranmaru"]
好吧，......，我不知道我明天是否還能活著。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru026"]
[OnName num="ranmaru"]
它隨時都可能死亡。甚至信長大人也不能說它不會。
[cpg cn=true]


世界正處於戰爭狀態。在這個敵人和盟友明顯分裂的時代，甚至那些站在你這邊的人也可能會殺死你。
[cpg]

我們已經來到了一個可怕的地方。我以為我在某種程度上已經做好了準備，但再想一想，這是件大事。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

我換上了這個時代的和服，因為我認為如果我永遠穿著校服會很顯眼。
[cpg]

我想這是戰士會穿的那種東西。如果是信長大人的命令，他是不是想把我變成一個武士？
[cpg]

不過，我不用擔心吃和穿的問題，這還是有幫助的。
[cpg]

沒想到信長大人對我有好感。
[cpg]

我認為當時我誠實地告訴他一切是好事。
[cpg]

[OnName num="keitarou"]
'我想知道我在...... 元的時候會是什麼樣子。
[cpg cn=true]


我情不自禁地自言自語。這是我忍不住要想的事情。
[cpg]

如果時間在另一邊以同樣的方式流動，這將是一個大問題。我將被視為失踪。
[cpg]

這意味著我最好盡快回來。 ......。
[cpg]

但是，當我真的像這樣穿越時空時，時間怎麼可能在現在以同樣的方式流逝呢？
[cpg]

當然，我們不知道我們將在什麼時候返回。在任何情況下，我都必須抓緊時間嗎？
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

我從未被放出過城堡，甚至沒有被放出過城堡。
[cpg]


[STOPBGM]
[window target=false]
[BG f="b_06_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

我沒有電話或其他東西。如果我整天呆在城堡裡，我會感到窒息的。
[cpg]

[OnName num="keitarou"]
'但是，這樣做可以嗎？我可能會跑掉。
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru027"]
[OnName num="ranmaru"]
'那是信長大人的意思。比起你逃跑的風險，有些事情他想照顧的更好。 ......
[cpg cn=true]


值得珍惜的東西。我不知道，我想知道是否有人在期待我做什麼。
[cpg]

但我也告訴他不要談論來自未來，也不要談論發生在未來的事情。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru028"]
[OnName num="ranmaru"]
'該死，為什麼這傢伙...... 信長大人在想什麼？
[cpg cn=true]


蘭丸大人似乎非常喜歡信長大人。他似乎把他的嫉妒指向了我。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我讓蘭丸大人跟著我，我又來到了城堡鎮。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『街』（朝）******************************************************

然而，在城堡鎮上什麼都沒有。
[cpg]

在這個時代，似乎不存在像江戶時代那樣具有一定富裕程度的城鎮。
[cpg]

我想這一定是真的。這意味著和平時期並沒有持續那麼久。
[cpg]

[OnName num="keitarou"]
'......，這裡什麼都沒有。
[cpg cn=true]



;//下記のセリフ、台本の「街」がシナリオでは「町」に変わっています

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru029"]
[OnName num="ranmaru"]
'那裡似乎沒有什麼東西？　'這是一個如此豐富的城鎮，它是如此的罕見。
[cpg cn=true]


我不是在說那些比我那個時代更矮的建築......。
[cpg]

這就像在看一部時代劇的佈景，但更有生活氣息和真實感。
[cpg]

[OnName num="keitarou"]
'是的，它是這樣。在這個時代，這很正常，或者......'。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru030"]
[OnName num="ranmaru"]
'在這個時代，......，你說這句話是什麼意思？
[cpg cn=true]


儘管這些話是無意中說出來的，但蘭丸大人並沒有錯過。
[cpg]

這個時代的軍閥們應該都是相當聰明的人。
[cpg]

他們一定在努力避免錯過我說的任何話。
[cpg]

如果這也與保護他們心愛的領主有關，那就更是如此了。
[cpg]

[OnName num="keitarou"]
'不。什麼都沒有。 "
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru031"]
[OnName num="ranmaru"]
'......，你是個有趣的人。
[cpg cn=true]


蘭丸大人很懷疑，但沒有再對我說什麼。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（昼）******************************************************

[SE f=se014]
;//【ＳＥ】『歩く』

然後我在城堡鎮周圍看了一會兒。
[cpg]

我想這是一個驚喜，但他太大了，不可能有任何驚喜。這一次我明白這是真的。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

之後，信長大人叫我去她的房間。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga039"]
[OnName num="nobunaga"]
'進展如何？你已經習慣了嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
是的，嗯......有一點。
[cpg cn=true]


我可以肯定地認為，信長大人喜歡我。
[cpg]

僅僅是被允許呆在這個城堡裡就是一個相當大的成就。
[cpg]

但是，......，有件事一直讓我有點困擾。
[cpg]

[OnName num="keitarou"]
信長大人，你知道圍繞公主軍閥的傳說嗎？
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga040"]
[OnName num="nobunaga"]
'當然了。 '穿著外國的衣服的人。 '穿異域服裝的人，以戰神公主為紐帶，將生出吃天的兒子。 '......，對嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
你知道嗎？
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga041"]
[OnName num="nobunaga"]
這裡的人都知道。但我不知道這意味著什麼。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Nobunaga042"]
[OnName num="nobunaga"]
那個穿外國斗篷的人可能是......。
[cpg cn=true]


[OnName num="keitarou"]
如果是這樣，那麼戰神公主...
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Nobunaga043"]
[OnName num="nobunaga"]
...... 的確，如果他們知道你是誰，各種軍閥，還有女人，可能會找你。 "
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


我想了一會兒。你將會有一個兒子，或者......
[cpg]

為了在這個世界上生存，我願意做任何事情。
[cpg]

此外，如果和軍閥在一起的孩子有神奇的力量，我也許能回到現代世界。
[cpg]

我覺得這就是我的角色所在。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga044"]
[OnName num="nobunaga"]
'但話說回來，你怎麼看？ '但是怎麼辦呢？作為來自未來的人，一定會有一些不便之處。
[cpg cn=true]


[OnName num="keitarou"]
這已經是......."
[cpg cn=true]


我甚至不知道該說些什麼，這太難了。
[cpg]

我不認為我可以從電話中回去向她解釋移動電話甚至是普通電話。
[cpg]

這個時期的人是如何與他人交流的？
[cpg]

[FACE method="shake_7" pos="2/3"]

[VOICE f="Nobunaga045"]
[OnName num="nobunaga"]
'我希望蘭丸沒有意識到我是來自未來。
[cpg cn=true]


[OnName num="keitarou"]
'可能吧，我想他會沒事的。
[cpg cn=true]


'我差點就對他破口大罵了，不過我相信他一定會沒事的。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga046"]
[OnName num="nobunaga"]
'話雖如此，......，有件事我想告訴你。
[cpg cn=true]


信長大人這時變得有些嚴肅。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga047"]
[OnName num="nobunaga"]
'看來，凱和越後終於打起來了。這可能會變成一場對峙，......."
[cpg cn=true]


他說。我不明白。
[cpg]

[OnName num="keitarou"]
'...... Kai and Echigo, is it?
[cpg cn=true]


我反問道，儘管我隱約知道凱和越後在哪裡。
[cpg]

原因是信長大人在這裡，所以應該從這裡向東......，對嗎？
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga048"]
[OnName num="nobunaga"]
我想你不明白。地名有變化嗎？
[cpg cn=true]


信長大人太有洞察力了。
[cpg]

[OnName num="keitarou"]
'你很了解它，不是嗎？ ......？
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Nobunaga049"]
[OnName num="nobunaga"]
'這個國家沒有處於無休止的戰爭狀態。未來將是一樣的'。
[cpg cn=true]


我想到的是，這兩個國家的人都不知道該怎麼辦。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga050"]
[OnName num="nobunaga"]
'武田和上杉，你能看出嗎？
[cpg cn=true]


[OnName num="keitarou"]
'哦。武田謙信 ...... 不，信玄？
[cpg cn=true]


我是根據模糊的記憶說的。信長大人笑了一下。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga051"]
[OnName num="nobunaga"]
這兩者是混在一起的，不是嗎？但你的意思是這兩個人將在未來被提及？
[cpg cn=true]


武田信玄和上杉謙信。這兩個人是武田信玄和上杉謙信，我以前至少聽說過這些名字。
[cpg]

但我甚至不知道他們中的哪一個與織田家更親近，或者他們之間的關係是否不好。
[cpg]

[OnName num="keitarou"]
'......，顯然仍有他們的名字。雖然沒有信長大人那麼多，'。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga052"]
[OnName num="nobunaga"]
'我想是的。他不可能是我的對手。
[cpg cn=true]


信長大人是一個相當自信的人。他似乎毫不懷疑自己就是那個名字會留在未來的人。
[cpg]

而且他一定有能力或......，有作為軍事指揮官的才能來配合。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga053"]
[OnName num="nobunaga"]
但如果剩下這麼多名字，我想你知道從現在開始誰會贏。
[cpg cn=true]


如果你問我，我不知道。它將如何被......？
[cpg]

'我甚至不知道那兩個人之間的戰鬥是否曾經解決。我甚至不知道。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga054"]
[OnName num="nobunaga"]
但不要告訴我。提前了解戰爭的狀況是違反我的原則的。 "
[cpg cn=true]


[OnName num="keitarou"]
'不，不，......，不要擔心這個問題。我也不知道。
[cpg cn=true]


[FACE method="change_5" pos="2/3"]

[VOICE f="Nobunaga055"]
[OnName num="nobunaga"]
什麼？你不關心歷史嗎？　還是你在未來如此遙遠，以至於過去是模糊的？
[cpg cn=true]


兩者都是正確的。無論怎樣，我都不能告訴你什麼。
[cpg]

我對這兩所房子的生存狀況一無所知。 ......。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga056"]
[OnName num="nobunaga"]
'我想，無論在多遠的未來，這些女人都會成為人人皆知的軍閥，但我聽說情況並非如此。
[cpg cn=true]


信長大人還說了一句話，有點令人不安。
[cpg]

[OnName num="keitarou"]
'他們，你是說......，那兩個也是女人？
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga057"]
[OnName num="nobunaga"]
'是的，他們是。你關心什麼？
[cpg cn=true]


我並不好奇，因為根據我所知道的歷史，他們兩人都是男人。
[cpg]

我是說，所有的軍事指揮官都是男人。我也許也不應該這麼說。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga058"]
[OnName num="nobunaga"]
'......，這是一個好機會。凱......，我希望你去找武田。
[cpg cn=true]


[OnName num="keitarou"]
我？ "
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
信長大人點了點頭。我不知道他是什麼意思。
[cpg]

[OnName num="keitarou"]
你是什麼意思，你要告訴他什麼？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga059"]
[OnName num="nobunaga"]
不，這不是我在這裡的原因。我只想讓你成為一個好僕人。
[cpg cn=true]


[OnName num="keitarou"]
那是什麼樣的......？
[cpg cn=true]


我不明白信長大人想做什麼。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga060"]
[OnName num="nobunaga"]
我不知道信長大人想做什麼。
[cpg cn=true]


顯然，他想教我戰國時期是怎麼回事。然後他繼續說。
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga061"]
[OnName num="nobunaga"]
'最終，我將使你成為軍閥。你必須為此做好準備。 "
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


我甚至無法想像。我是個軍閥？
[cpg]

我甚至無法想像，我將會領導一支軍隊。
[cpg]

此外，在這之前還有一些問題。
[cpg]

[OnName num="keitarou"]
當你說你正在去武田的路上，你確定要我親自去那裡嗎？ "
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Nobunaga062"]
[OnName num="nobunaga"]
'啊。我們的目標是，讓所有的人都知道，我們的目標是，讓所有的人都知道，我們的目標是，讓所有的人都知道。
[cpg cn=true]


'我不認為有問題或什麼，我認為這是個大問題。因為......
[cpg]

[OnName num="keitarou"]
'你不覺得我可能......，站在武田那邊嗎？
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga063"]
[OnName num="nobunaga"]
'如果發生這種情況，我將盡我所能粉碎你。這就是為什麼我會讓蘭丸和你一起去。 "
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga064"]
[OnName num="nobunaga"]
'如果你不想死，你必須為我服務。如果你不想死，就為我服務，我所有的敵人都會滅亡。
[cpg cn=true]


我顫抖著，但信長大人對我笑了。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga065"]
[OnName num="nobunaga"]
如果你認為背叛我有好處，這就是所有的事情了。我甚至不認為我看起來那麼弱。
[cpg cn=true]


我明白了。我一直在思考這個問題。
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[OnName num="keitarou"]
'......，你的麻煩大了......'。
[cpg cn=true]


我將成為一個軍閥？也許這就是在這個世界上生存的方式。
[cpg]

如果你是信長大人的手下，但你不是軍閥，你可能要作為士兵作戰。
[cpg]

如果只是呆在她身邊什麼都不做，那是不可接受的。
[cpg]

信長大人是個女人，是個軍事指揮官，所以我作為一個男人，就更應該如此。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

從那天起，就開始為出發做準備。
[cpg]

我必須要走一段時間嗎？還是我得騎馬？
[cpg]

無論哪種方式，它看起來都是一個很大的工作。我能夠做到嗎？
[cpg]


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

當我在思考的時候，夜幕降臨。
[cpg]

幾個小時似乎在異常漫長的時間裡過去了。
[cpg]

沒有什麼可以打發時間的東西，城堡裡到處都是陌生人。
[cpg]

此外，我覺得信長大人因為喜歡我而嫉妒我。
[cpg]

所以我沒有和任何人交談，也沒有考慮到未來。
[cpg]

這一定是一個相當大的舉措。這是一個沒有汽車，沒有其他東西的時代。
[cpg]

[OnName num="keitarou"]
我們將不得不這樣做。 ......
[cpg cn=true]


我懷著焦慮的心情自言自語。我擅長運動，我認為我的身體素質很好，但我不知道我會做得多好。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

然後，在出發的那天。
[cpg]

自然，我不可能帶著一個小隊出去，所以那裡有不少戰士。
[cpg]

一切都準備好了。我們所要做的就是步行。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru032"]
[OnName num="ranmaru"]
'好的。那我們就出去吧。 "
[cpg cn=true]


即便如此，蘭丸大人是個女孩，......，身體苗條，似乎沒有能力走遠路。
[cpg]

[OnName num="keitarou"]
......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru033"]
[OnName num="ranmaru"]
它是什麼？　盯著我。 "
[cpg cn=true]


[OnName num="keitarou"]
'不，沒有什麼.......'
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se014]
;//【ＳＥ】『歩く』

但到了開始走的時候，蘭丸大人就比較艱難了。
[cpg]

他當然是，因為他在這個時代以軍閥的身份生活。
[cpg]

而四處走動，已經超出了艱難這個詞的範疇，是對生命的威脅。
[cpg]

我從來沒有真正想像過，但在那些日子裡，馬只在特殊場合使用。
[cpg]


[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

夜裡很難受。我無法入睡。
[cpg]

我晚上睡不著覺，但我不能把我疲憊的身體帶到明天。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru034"]
[OnName num="ranmaru"]
我想我沒有......，因為我認為我很健康。 "
[cpg cn=true]


[OnName num="keitarou"]
'對不起，對不起.......'
[cpg cn=true]


我想知道蘭丸大人單薄的身體哪裡有這樣的能量。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

白天，黑夜，白天，黑夜，越來越多的時間過去了。
[cpg]

我的時間感越來越奇怪，我說話越來越少。
[cpg]

我想盡快到達我的目的地，但很難走得快。
[cpg]

而且每個人都走得非常快。如果我被甩在後面，那就完蛋了。
[cpg]


[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]

;//【ＢＧ】『山道』（夜）******************************************************

如果我沒有加入體育俱樂部，我現在就已經死了。
[cpg]

我意識到，我很幸運，因為我積累了一些肌肉。
[cpg]

在這個時代，除了你的身體，你能依靠的東西不多：......
[cpg]



[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]


;//【ＢＧ】『山道』（昼）******************************************************

然後，在你走投無路時，......
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『街』（夕方）******************************************************

[OnName num="keitarou"]
"......"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru035"]
[OnName num="ranmaru"]
我們在這裡。景太郎，你還好嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
......，我都快崩潰了。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru036"]
[OnName num="ranmaru"]
你不能在這個......，戰場是一個更艱難的地方。 "
[cpg cn=true]


是的，這就對了。我很確定這也是它的特點。
[cpg]

但我想就在今天好好睡一覺。 ......
[cpg]


[SE f=se014]
;//【ＳＥ】『歩く』


;//ブラックアウト
[free time=1000]
[BG f="b_13_4.ui" time=1000]
[WAIT time=1100]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

我們到達了城堡，我睡得像泥巴一樣。
[cpg]

武田信玄，這個我從未見過的人。
[cpg]

我決定把困難的事情留給蘭丸大人，她有足夠的力量：......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（朝）******************************************************



而在第二天早上。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen001"]
[OnName num="shingen"]
'很高興見到你。你是信長景太郎提到的那個人嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
'是的，我是。謝謝你昨天讓我住在這裡。
[cpg cn=true]


與信玄一對一，沒有蘭丸大人在場。
[cpg]

不，信玄大人，我應該給你打電話。如果信長大人派我來，那我們一定是友好關係。
[cpg]

此時可能沒有信長大人或信玄大人的優勢地位。
[cpg]

但至少在我看來，他們在雲層之上。
[cpg]

[OnName num="keitarou"]
'......，你說戰爭可能要開始了。
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Singen002"]
[OnName num="shingen"]
'這就對了。這不會很快決定的'。
[cpg cn=true]


川中島之戰。我知道這麼多。
[cpg]

信玄和劍心在那裡打過架，不是嗎？而且他們已經鬥爭了相當長的時間。
[cpg]

看來我們現在正處於中間階段。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen003"]
[OnName num="shingen"]
你我之間，......，我不認為我想打這樣的仗。
[cpg cn=true]


[OnName num="keitarou"]
嗯？ "
[cpg cn=true]


是這樣的嗎？　如果是這樣，感覺有點糟糕。
[cpg]

這意味著歷史上曾經發生過的最重要的戰役之一將被丟失。
[cpg]

這將改變未來，所以即使我們回到原來的時間，也可能不是我所知道的那個日本。
[cpg]

[OnName num="keitarou"]
'哇，我不知道。如果我們戰鬥，我們可能很容易獲勝'。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen004"]
[OnName num="shingen"]
'你沒有依據，......，但如果你支持我，我就接受。
[cpg cn=true]


信玄大人這麼一說，我就有點放心了。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen005"]
[OnName num="shingen"]
'那麼，關於你。我聽說有傳言說你從另一個世界混進來了？
[cpg cn=true]


[OnName num="keitarou"]
'......，你對這個問題知道得很多。
[cpg cn=true]


'我聽說了一些傳言，在這個時代有可能嗎？
[cpg]

不知怎的，我以為信長是在故意造謠我。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen006"]
[OnName num="shingen"]
'的確，你身上有一種浮力。 ...... Gohoho，gohoho。
[cpg cn=true]


[OnName num="keitarou"]
你沒事吧！ "
[cpg cn=true]


信玄大人突然咳嗽起來。它立即停止了，但是。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen007"]
[OnName num="shingen"]
'打擾一下。我有結核病。不要擔心'。
[cpg cn=true]


[OnName num="keitarou"]
'......，我不知道你有這個。
[cpg cn=true]


結核病。結核病，在這個時代是一種不治之症。
[cpg]

仔細想想，雖然我知道信玄大人和謙信之間有矛盾，但我不記得他們中的任何一個打敗了對方。
[cpg]

也許信玄大人是病死的。 ......
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Singen008"]
[OnName num="shingen"]
'這是什麼？你似乎在說什麼。
[cpg cn=true]


[OnName num="keitarou"]
...... 不。 "
[cpg cn=true]


我想，但沒有大聲說出來。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[OnName num="keitarou"]
啊，蘭丸大人。
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru037"]
[OnName num="ranmaru"]
你見過信玄大人嗎？　進展如何？
[cpg cn=true]


[OnName num="keitarou"]
怎麼樣，我聽說了。 ......
[cpg cn=true]


沒有什麼複雜的事情可談。
[cpg]

我甚至不知道信玄大人對我有多少了解。
[cpg]

[OnName num="keitarou"]
他是一個很難讀懂的人。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru038"]
[OnName num="ranmaru"]
'我想是的。我有同樣的印象。
[cpg cn=true]


信長大人是相當容易理解的。她沒有來回走動。
[cpg]

 我覺得和信玄大人有一種對比。
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

傍晚時分，我還在城堡裡。
[cpg]

我挺累的，很難馬上回到信長大人那裡。
[cpg]

我將在城堡裡待上一段時間。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru039"]
[OnName num="ranmaru"]
'景太郎。你感覺如何？
[cpg cn=true]


[OnName num="keitarou"]
我的腿仍然很疼。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru040"]
[OnName num="ranmaru"]
我明白了。我很抱歉，但你很快又要離開了。
[cpg cn=true]


我沮喪地聽著這段對話。然後我聽到了一個來自...... 的消息
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]


[VOICE f="Singen009"]
[OnName num="shingen"]
晚上好。景太郎，我可以說句話嗎？ "
[cpg cn=true]


[FACE method="change_7" pos="4/5"]

[VOICE f="Ranmaru041"]
[OnName num="ranmaru"]
'信玄大人，......，你想要什麼？
[cpg cn=true]


蘭丸大人看起來很驚慌。
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Singen010"]
[OnName num="shingen"]
'...... 蘭丸也在這裡，不是嗎？嗯，很好。
[cpg cn=true]


然後，信玄大人不看蘭丸大人，而是看我。
[cpg]

我有重要的事情要告訴你。說著，信玄大人向我走來。
[cpg]

我覺得信玄大人的臉上有一種性感的表情。
[cpg]

我不知道為什麼會有這樣的表達。
[cpg]

她是...... 可怕的美麗。你說我是個漂泊者，但她不就是那個人嗎？
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Singen011"]
[OnName num="shingen"]
你不想為我服務，是嗎？　我不像信長那樣殘暴和苛刻。 "
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="4/5" time=1]
她對我輕聲說。然後她向我走來。
[cpg]

[FACE method="change_2" pos="2/5"]
她把她的手放在我的耳朵上。然後他狡黠地笑了笑。
[cpg]

我遇到了麻煩，我不知道該說什麼。
[cpg]

事實上，他用 "我不覺得我可以利用你 "這句話來觸動我，......。
[cpg]

如果我為你服務，這是否意味著你也會做這些事？
[cpg]

我的腦海中出現了很多想法。在為我服務之前，她可能試圖約我出去。
[cpg]

但看到這樣的姿態，蘭丸大人就生氣了。
[cpg]

[FACE method="shock_3" pos="4/5"]

[VOICE f="Ranmaru042"]
[OnName num="ranmaru"]
'嘿!　連信玄大人都聽不到。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]

[VOICE f="Singen012"]
[OnName num="shingen"]
'我是在開玩笑。我不打算認真地說，那是不可能的。
[cpg cn=true]


我想了想，不知如何回答。
[cpg]


;//■選択肢
[switch]
[case "我什麼都不回答。"]
	[swap]
	[jump target="*select_shingen01"]
[case "我感謝他。"]
	[swap]
	[jump target="*select_shingen02"]
[endswitch]

第一，我什麼都不回答。
二，我感謝你。


;//==============================
;//１、何も答えない

*select_shingen01|'穿上外國土地的服裝的人。

[OnName num="keitarou"]
'......'
[cpg cn=true]


[FACE method="shake_6" pos="2/5"]

[VOICE f="Singen013"]
[OnName num="shingen"]
'不要給我這種表情。這只是意味著我關心你。
[cpg cn=true]


我沒有回答。我對信長大人心存感激。 ......
[cpg]



[stflag Cha2flg=0]

[jump target="*select_shingen03"]


;//ヒロイン２ルートへの可能性が無くなる

;//==============================
;//２、お礼を言う

*select_shingen02|'穿上異地的袍子的人。

[OnName num="keitarou"]
'謝謝你。
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]

[VOICE f="Ranmaru043"]
[OnName num="ranmaru"]
'即使是景太郎。 ......！　你真的要背叛我們嗎？ "
[cpg cn=true]


蘭丸大人盯著我。但信玄大人卻在對他微笑。
[cpg]

我不知道我是否能為信玄大人服務......
[cpg]


[stflag Cha2flg=1]


[jump target="*select_shingen03"]

;//ヒロイン２ルートへの可能性が残る

;//==============================

*select_shingen03|穿著異國他鄉的袍子的人

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

更多的時間過去了，到了晚上。我做了一個夢。
[cpg]


;//ブラックアウト

;//夢の中であるため、色調をグレースケールにしてください
;//＠
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

有一個女人，既不是信長大人，也不是信玄大人。
[cpg]

她穿得像個尼姑。我想知道她是誰。 ......
[cpg]

[OnName num="samurai"]
'劍聖大人。我們仍然可以戰鬥，你願意嗎？ "
[cpg cn=true]


我聽到了'Kenshin-sama'這句話。我在做夢，但我可以很清楚地聽到它。
[cpg]

[FACE method="bow_4" pos="2/3"]

[VOICE f="Kensin001"]
[OnName num="kenshin"]
是的。我現在不能退縮。
[cpg cn=true]


這名婦女的表情看起來相當疲憊。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Kensin002"]
[OnName num="kenshin"]
'......，這樣的戰鬥能持續多長時間？
[cpg cn=true]


那個人，謙信,......，不知為何在歷史上有勇者的形象，但是。
[cpg]

無論是信玄大人還是謙信，似乎都沒有那麼好戰。
[cpg]


;//ブラックアウト

;//色調を戻してください

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（朝）******************************************************

[OnName num="keitarou"]
......"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru044"]
[OnName num="ranmaru"]
'你醒過來了。你在做夢，但你做了一個夢嗎？ "
[cpg cn=true]


'你做了個噩夢？我不覺得那是一個多麼糟糕的夢。
[cpg]

但......，這是個有點讓人無法忍受的夢。
[cpg]

[OnName num="keitarou"]
不，這沒什麼。 "
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

肌肉疼痛終於緩解了，也恢復了一點力量。
[cpg]

蘭丸大人甚至看起來都不累。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru045"]
[OnName num="ranmaru"]
'看來我們明天左右又要離開了。同時，你應該做好準備。 "
[cpg cn=true]


[OnName num="keitarou"]
'...... 是。
[cpg cn=true]


我只能回答，'是的'。我並不熱衷於再次走這條路。 ......
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

那天晚上，我也是被信玄大人邀請來的。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen014"]
[OnName num="shingen"]
'是的。你做了一個這樣的夢。 ......
[cpg cn=true]


[OnName num="keitarou"]
'是的，......，她似乎處於某種苦惱之中。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen015"]
[OnName num="shingen"]
'是的，她是個修女，這是肯定的。你可能已經看到了真正的她。
[cpg cn=true]


我當然不知道劍聖是一個宗教愛好者。
[cpg]

很奇怪，我看到她是個修女。
[cpg]

我已經回到了過去。
[cpg]

如果我身上再發生任何奇怪的事情，我也不會感到驚訝。 ......
[cpg]

[FACE method="bow_7" pos="2/3"]

[VOICE f="Singen016"]
[OnName num="shingen"]
'她可能因為她而陷入痛苦之中。她可能真的不想和我打。 "
[cpg cn=true]


也許這就是戰爭的意義所在。我必須為我的生活而奮鬥。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen017"]
[OnName num="shingen"]
'所以你真的不打算為我服務？
[cpg cn=true]


[OnName num="keitarou"]
'因為我為...... 信長大人服務。
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

在我回答這個問題時，信玄大人向我走來。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen018"]
[OnName num="shingen"]
'信長......，她不允許你和她發生肢體衝突。她是一個禁慾主義者。但我不是。 "
[cpg cn=true]


這變得有點好笑。當她走近時，我無法推開她。
[cpg]

[OnName num="keitarou"]
'你是什麼意思？
[cpg cn=true]


我明知故問地問她。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen019"]
[OnName num="shingen"]
'難道你不明白嗎？
[cpg cn=true]


我知道。也許信玄大人知道我來自未來。
[cpg]

她很虛弱。考慮到這一點，她不可能不告訴我就讓我離開。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Singen020"]
[OnName num="shingen"]
'我將不惜一切代價讓我活著。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Singen021"]
[OnName num="shingen"]
'但是......，正如你所看到的，她很虛弱，所以她將無法生育。
[cpg cn=true]


信玄大人把她的臉湊得很近，嘴唇幾乎要碰到。
[cpg]

我想，她一定知道自己的長相很好。
[cpg]

[OnName num="keitarou"]
'......，你應該更好地照顧自己。對我來說，做這個......。 "
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Singen022"]
[OnName num="shingen"]
'這是因為我確實照顧了你。我不認為我的選擇是錯誤的'。
[cpg cn=true]


...... 我要做什麼呢？我需要和某人在一起，任何人，有一天。
[cpg]

他們說，我和公主軍閥之間的孩子會有神奇的力量。
[cpg]

如果是這樣，我真的需要回到未來。
[cpg]

但......，信玄大人是否適合做這個夥伴？
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


最後，由於無法給出答案，我沒有接受信玄大人的邀請。
[cpg]


;//移植前シーンカット

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

她看起來有點悲傷。但這也是沒辦法的事，我還沒準備好。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen065"]
[OnName num="shingen"]
'我做這些事情是因為是你。你可能已經猜到了'。
[cpg cn=true]


[OnName num="keitarou"]
'......'
[cpg cn=true]


我陷入了沉默。她正在努力爭取我的支持。
[cpg]

當然，我欠信長大人一個人情。我不應該在這裡如此輕易地與她調情。
[cpg]

我想了想，想出了一個答案。
[cpg]


;//※ストーリーが分岐
;//　１を選んだ場合、ヒロイン１、ヒロイン４、ヒロイン５ルートへ
;//　２を選んだ場合、ヒロイン２、ヒロイン３ルートへ

;//※ただし、以前の選択肢で「１、何も答えない」を選んでいた場合、この選択肢は発生せず１を選んだことになる



[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*select_root145"]
[endif]

;//■選択肢
[switch]
[case "我不打算為她服務。"]
	[swap]
	[jump target="*select_root145"]
[case "我將為信玄服務。"]
	[swap]
	[jump target="*select_root23"]
[endswitch]

1、我不打算為他服務。
2、我將為信玄服務。


*select_root145
[jump storage="ep001.ks" target="*start"]

*select_root23
[jump storage="ep006.ks" target="*start"]
