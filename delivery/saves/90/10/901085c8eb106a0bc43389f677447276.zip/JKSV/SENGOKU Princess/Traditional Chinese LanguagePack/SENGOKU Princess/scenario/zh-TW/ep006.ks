
*start

;//==============================
;//２、信玄に仕える

*select_root23|對信玄大人的忠誠。

;#################################################
*Ep006|對信玄大人的忠誠。
;#################################################
;//ブラックアウト

[SCENE id=6]


[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]


[OnName num="keitarou"]
我是.......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen074"]
[OnName num="shingen"]
我是什麼？讓我聽聽你的回答。 "
[cpg cn=true]


我想，我和信玄大人在一起比和信長大人在一起要好。
[cpg]

如果歷史事實是真實的，她就不會在戰場上被殺。
[cpg]

我記得，她死於疾病。與謙信的戰鬥也是沒有結果的，不是嗎？ ......
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="4/5" time=800]

[VOICE f="Ranmaru457"]
[OnName num="ranmaru"]
'嘿，......，你到底在說什麼？
[cpg cn=true]


蘭丸大人很驚訝，但我卻很堅定。
[cpg]

[OnName num="keitarou"]
'是的。我將為信玄大人服務。
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]

[VOICE f="Singen075"]
[OnName num="shingen"]
'我很高興。你已經下定決心。
[cpg cn=true]


[FACE method="change_3" pos="4/5"]

[VOICE f="Ranmaru458"]
[OnName num="ranmaru"]
我一直在跟踪你，想阻止你。你知道這意味著什麼嗎？
[cpg cn=true]


[FACE method="change_3" pos="4/5"]

[VOICE f="Ranmaru459"]
[OnName num="ranmaru"]
即使你和我不成為敵人，我也不能離開你。
[cpg cn=true]


[OnName num="keitarou"]
但你不會殺我，對嗎？
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
對我來說，這是一個決定性的決定。我相信蘭丸大人知道這一點。
[cpg]

[OnName num="keitarou"]
別擔心，我不會攻擊信長大人。我不會攻擊信玄大人。
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru460"]
[OnName num="ranmaru"]
'你會後悔的，.......圭太郎。
[cpg cn=true]


但是蘭丸大人沒有再說話。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

從那天起，我就要為信玄大人服務。
[cpg]

蘭丸大人離開了。我有一段時間不會再見到她了。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen076"]
[OnName num="shingen"]
'真的，你是一個讀心者，不是嗎？我想知道她是否為我感到遺憾。
[cpg cn=true]


[OnName num="keitarou"]
'我不明白你為什麼離我這麼近。為什麼？
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen077"]
[OnName num="shingen"]
我不知道。我不認為一見鍾情足以讓你信服。
[cpg cn=true]


信玄大人看向遠方。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen078"]
[OnName num="shingen"]
我決心要活下去。在這樣的時代，誰不願意呢？
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen079"]
[OnName num="shingen"]
'讓我告訴你一些事情。我沒有被你或任何東西吸引。
[cpg cn=true]


[OnName num="keitarou"]
...... 我明白了。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Singen080"]
[OnName num="shingen"]
我需要你，是指我想交更多的朋友。但這就是全部。 "
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Singen081"]
[OnName num="shingen"]
我聽說......，你有奇怪的傳言，我不能讓你一個人呆著。
[cpg cn=true]


也許對信玄大人來說，她知道未來很重要。
[cpg]

她比大多數人更了解死亡。
[cpg]

當她說她不喜歡我這樣的時候，我無話可說。
[cpg]

這很自然。甚至在我看來，這也很好。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen082"]
[OnName num="shingen"]
'我體弱多病，所以我已經放棄了孩子，但......，我會做這些事情來維持你們的關係。
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

然後，信玄大人把他的嘴唇放在我的嘴唇上。
[cpg]

[OnName num="keitarou"]
'......，在這樣的地方，這不是好事。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Singen083"]
[OnName num="shingen"]
'如果不是在這樣的地方，會不會更好？
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

我吻她。我確定她在那裡。
[cpg]

;//移植前シーンカット
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

與其說是我和信玄大人之間的聯繫越來越緊密......，不如說是我逐漸了解了她的性格。
[cpg]

她仍然很悲觀，已經放棄了孩子。我想以某種方式鼓勵她。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen136"]
[OnName num="shingen"]
'我想知道你是否不打算上戰場。
[cpg cn=true]


[OnName num="keitarou"]
...... 你是什麼意思？　你想讓我成為一名士兵嗎？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Singen137"]
[OnName num="shingen"]
'不，我沒有。我想讓你成為一個配得上我的軍事指揮官。
[cpg cn=true]


信玄大人與謙信戰鬥了很長時間。
[cpg]

所謂的川中島之戰。信玄大人一定多次經歷過死亡。
[cpg]

[OnName num="keitarou"]
信玄大人將在未來留下。 ......
[cpg cn=true]


我想我說的時候已經說漏嘴了。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Singen138"]
[OnName num="shingen"]
'所以你畢竟是來自未來。我聽說了一些傳言。 "
[cpg cn=true]


我倍感驚訝。第一，你知道這件事，第二，你相信它。
[cpg]

[OnName num="keitarou"]
'......，你相信我嗎？這種事情'。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen139"]
[OnName num="shingen"]
是的，我也這麼認為。我以為你沒有跳出框框思考問題。
[cpg cn=true]


當我來到這個時代，除了信長大人，我不能告訴任何人我來自未來。
[cpg]

但信玄大人馬上就相信了我。這讓我多少有些高興。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


然後，幾個月過去了。另一場戰爭即將發生。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『戦場』（昼）******************************************************

即使在今天，人們也知道，信玄大人作為軍事指揮官的才能是相當大的。
[cpg]

對謙信來說也是如此。
[cpg]

[OnName num="keitarou"]
'......，我不相信我在做這個。
[cpg cn=true]


我也要在戰場上。作為一名指揮官。
[cpg]

信玄大人教會了我們如何在戰場上四處走動的基礎知識。
[cpg]

他們是優秀的士兵。他甚至告訴我，在最壞的情況下，我不需要做任何事情。
[cpg]

但這並不意味著我可以只聽他們的話。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f=se019]
;//【ＳＥ】『つばぜり合い』
[WAIT time=1100]

我取得了一些軍事上的成功，但戰鬥始終沒有解決。
[cpg]

這麼容易解決，是不是很奇怪？
[cpg]

這是一場將被載入日本歷史的戰鬥。它也因一場從未解決的戰鬥而聞名。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen140"]
[OnName num="shingen"]
你的工作做得很好。
[cpg cn=true]


[OnName num="keitarou"]
"...... 不。一想到我殺了人，我的手還是會發抖。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Singen141"]
[OnName num="shingen"]
'是的，它是這樣。 '當我想到你是個殺人犯時，我做不到。
[cpg cn=true]


信玄大人似乎已經猜到我在想什麼。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen142"]
[OnName num="shingen"]
我想知道在你生活的世界裡是否有戰爭？
[cpg cn=true]


[OnName num="keitarou"]
'不，它是和平的。我想把信玄大人帶到那個時代。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
信玄笑了。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

從那時起，信玄大人的話就沒有什麼變化。
[cpg]

你不能和我生孩子。即使我可以，我生完孩子後會安全嗎？
[cpg]

即使沒有，他也說他隨時都有可能死亡。
[cpg]

我並不是因為聽了她的話而感到沮喪。相反，它讓我思考。
[cpg]

我開始思考如何在這個時候利用我的生命。
[cpg]


[window target=false]
[BG f="b_13_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

後來，有一天的下午 在城堡外的一個小地方，我從信玄大人那裡聽到了這個故事。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen143"]
[OnName num="shingen"]
'我想僱傭一個忍者。你怎麼看？ "
[cpg cn=true]


[OnName num="keitarou"]
...... 忍者，嗯？
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Singen144"]
[OnName num="shingen"]
'你很了解他們。我也被稱為忍者。
[cpg cn=true]


我思索著。我知道，武田信玄是戰國時期僱傭忍者最多的封建主。
[cpg]

[OnName num="keitarou"]
'...... 會很好，不是嗎？
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen145"]
[OnName num="shingen"]
'是的。如果你這麼說，我想知道忍者是否在某種程度上是有效的。
[cpg cn=true]


我沒有那方面的詳細知識。
[cpg]

我無法給你一個直接的答案，但只要它出現在歷史上，它一定在某種程度上起了作用。
[cpg]

[OnName num="keitarou"]
在戰國時期，不是有一種非常類似於忍者的東西嗎？守園人......？
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Singen146"]
[OnName num="shingen"]
'是的，他們是。我不知道，我從來沒有聽說過它。
[cpg cn=true]


我告訴信玄大人，想知道那是否是在江戶時代。
[cpg]

[OnName num="keitarou"]
'這就是所謂的隱蔽性。 '他們是從事間諜活動的人。
[cpg cn=true]


忍者、朝臣和其他各種形式的類似間諜的人都被傳到了未來。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen147"]
[OnName num="shingen"]
'...... 右。我已經下定決心了'。
[cpg cn=true]


聽到這裡，信玄大人似乎下定了決心。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Singen148"]
[OnName num="shingen"]
'我認為你是從事間諜工作的合適人選。你知道未來。
[cpg cn=true]


[OnName num="keitarou"]
'...... me?
[cpg cn=true]


當他這麼說時，我很糾結。
[cpg]

如果我在這裡成為一名情報人員，我可能會被抓到，並被謙信方面收編。
[cpg]

如果你想接近信玄大人，最好不要接受。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen149"]
[OnName num="shingen"]
你怎麼看？你會去找謙信的地方嗎？
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


我想了想是否接受，並給出了我的答案。
[cpg]



;//１、受け入れる２、受け入れない　があった場所　必要無し　このままシナリオは進行


[OnName num="keitarou"]
'好的。如果你想讓我成為一個秘密特工，我就會成為。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen150"]
[OnName num="shingen"]
'你這麼快就回答了。這讓人放心。
[cpg cn=true]


我決定接受。我想听從信玄大人的話，雖然我也想知道自己是否能勝任這項工作。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

從那一天起，我開始準備。
[cpg]

我有一次不得不離開信玄大人的地方。儘管那是不可避免的，......
[cpg]

我也不能不為我最終的回歸做準備。
[cpg]

我曾經作為指揮官帶過兵，打過仗。
[cpg]

考慮到這一點，沒有理由......，但我還是很緊張。
[cpg]

[OnName num="keitarou"]
我別無選擇，只能...... 做。
[cpg cn=true]


這正是信玄大人的願望。我沒有選擇，只能對此作出回應。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

信玄大人已經僱傭了忍者。我是第一個與他們匯合的人。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen151"]
[OnName num="shingen"]
他是忍者的領袖。他有一定的技能。
[cpg cn=true]


[OnName num="ninja"]
'很高興見到你。要加入我們的人，慶太郎大人，是你，對嗎？
[cpg cn=true]


他們似乎對我有些尊敬，因為我原本就站在戰場上。
[cpg]

[OnName num="keitarou"]
'......，這些人是誰？
[cpg cn=true]


[OnName num="ninja"]
'他們是女忍者。
[cpg cn=true]


他們沒有穿成這樣。我想到的第一件事是，婦女們的穿著並不像那樣，而是像一個女人。
[cpg]

仔細觀察後，似乎這些人是作為行走的女巫潛伏在周圍，即不屬於神社的女祭司。
[cpg]

[OnName num="keitarou"]
'這不是我所知道的，是嗎？
[cpg cn=true]


[OnName num="ninja"]
'可能是這樣的。我將把我所有的知識傳授給你。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen152"]
[OnName num="shingen"]
'這很令人鼓舞。我認為這對慶太郎來說將是一個很好的經驗。
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


他將學習與他所知不同的東西，他將學習如何成為一個隱身的忍者。
[cpg]

這可能不是像漫畫中那樣使用忍術。
[cpg]

他只需牢記，他不會被發現或註意到。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

雖然他暫時沒有直接去謙信的地方，但他潛入的時機終將到來。
[cpg]

[OnName num="keitarou"]
我想我們要和你說再見了，有一段時間了。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen153"]
[OnName num="shingen"]
是的。確保你能活著回來。
[cpg cn=true]


我很遺憾地說再見。信玄大人可能也有同感。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen154"]
[OnName num="shingen"]
嘿，我想請你幫個忙。
[cpg cn=true]


[OnName num="keitarou"]
它是什麼？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="sSingen001"]
[OnName num="shingen"]
這是除了你之外我無法要求別人的東西。
[cpg cn=true]


信玄大人帶來了一件和服。 '一件和服，或者說，這個。
[cpg]

[OnName num="keitarou"]
'忍者的服裝，是嗎？
[cpg cn=true]


信玄大人點了點頭。我想知道她要用它來做什麼。 ......
[cpg]

她開始要求看我換成這樣。
[cpg]

[OnName num="keitarou"]
信玄大人，你不會是打算自己去當忍者吧？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
當我問她時，她搖了搖頭。
[cpg]

她只是對這種服裝感興趣。
[cpg]

我不知道這是否因為她也是個女人。她可能希望你看到她穿得和平時不一樣。 ......
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（忍び装束のヒロイン。座っている）ev_56
;//人物１：ヒロイン２　服装１：忍装束
;//場所　：城＿室内
;//時間　：夜
;//========================================

[SE f=se001]
;//【ＳＥ】『衣擦れ』

[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_56_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]



我離開房間一次，在她換完衣服後再進去。
[cpg]

信玄大人看起來有點尷尬。
[cpg]

[OnName num="keitarou"]
'這很適合你。
[cpg cn=true]


我不知道我是否可以這樣說。但她似乎很高興。
[cpg]

信玄大人說她願意不惜一切代價來吸引我的注意。
[cpg]

我看著她，想知道這畢竟是事情的真相。
[cpg]


;**【ＣＧ】 ev_56_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSingen002"]
[OnName num="shingen"]
'我把我的......，所以我不能穿著這身衣服吻你。
[cpg cn=true]


當她說她不喜歡我這樣的時候，我無話可說。
[cpg]


;//移植前シーンカット
;//【ＢＧ】『城＿室内』（夜）
;//ブラックアウト
;//移植前シーンカット

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

無論我和信玄大人談了多少，都不夠。
[cpg]

但這一天已經臨近，我將在去往謙信家的路上。
[cpg]

我再次下定決心，我要活著回去。
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

於是，我向謙信居住的城堡走去。
[cpg]

我將找出他的行軍方式，還是刺殺謙信本人？
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen203"]
[OnName num="shingen"]
'以高超的技巧。
[cpg cn=true]


[OnName num="keitarou"]
是的，我是。我將回報你的幫助。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Singen204"]
[OnName num="shingen"]
和間諜活動一樣，別忘了，你活著回來，就欠我一個人情。
[cpg cn=true]


[OnName num="keitarou"]
我明白。那就好。
[cpg cn=true]


我和忍者們一起離開。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

沿著山路行走的忍者速度非常快。
[cpg]

我以前也這樣想過，但這個時代的人走得非常快。
[cpg]

[OnName num="ninja"]
'你已經累了嗎？如果你想休息，你最好快點說。
[cpg cn=true]


[OnName num="keitarou"]
'...... 不，我很好。我很好。
[cpg cn=true]


在某種程度上，你必須逼迫自己，認為這是為了增強你的體能。
[cpg]


[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

睡在山路中間也是我還不習慣的事情。
[cpg]

忍者們輪流站崗。我不是其中的一員。
[cpg]

每個人都在為我著想。我想部分原因是我直接為信玄大人服務。
[cpg]

我為自己感到羞愧，但同時我也認為我一定會有所作為。
[cpg]


[window target=false]
[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

幾天過去了。我終於趕到了城堡。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

[OnName num="ninja"]
'我們要闖進去。你準備好了嗎，慶太郎大人？
[cpg cn=true]


[OnName num="keitarou"]
是的，我已經準備好了。我盡量不拖後腿。
[cpg cn=true]


[OnName num="ninja"]
很好。如果逼不得已，我有可能會丟下你而逃跑。
[cpg cn=true]


[OnName num="ninja"]
反過來也是如此。如果我們失敗了，你可以直接跑掉。
[cpg cn=true]


[OnName num="keitarou"]
...... 是的。
[cpg cn=true]


我們必須這樣做。現在已經沒有回頭路了。
[cpg]


;//ブラックアウト


;//※ストーリーが分岐
;//　勝利した場合、ヒロイン２ルートへ
;//　敗北した場合、ヒロイン３ルートへ


;//伏兵の代わりに「音の鳴るマス」という部分があります
;//伏兵と同様、二度通ることで敗北判定となります
;//音の鳴るマスは、２、３、７、８に配置されています

;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※謙信の所へ潜入　開始時（１のマスにいる場合のシナリオ）※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※

;//ブラックアウト

;//[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_07"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

;//ヒロイン３の立ち絵を表示してください

我們前往謙信的住處，躲在她居住的城堡閣樓裡。
[cpg]

有一些地方的材料似乎是不同的。 ......，是在東方的方向。
[cpg]

我想知道在這個時期是否有頑童裝飾品這種東西。
[cpg]

是否有可能把它種在閣樓上？謹慎行事。
[cpg]


;//■選択肢
[switch]
[case "向南前進。"]
	[swap]
	[jump target="*select04_4"]
[case "繼續向東走。"]
	[swap]
	[jump target="*select04_2"]
[endswitch]

1，向南前進。
2，向東行進。


;//==============================
;//１、南へ進む

;//同じイベント中の「４のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「２のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※２のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_2|忠於信玄大人。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン３の立ち絵を表示してください

[SE f=se029]
;//【ＳＥ】『木材きしむ』

;//qwe
[stflag Selectflg4=1]


我聽到木頭吱吱作響。我停下來，驚慌失措。
[cpg]

就在我下面的謙信，正抬頭看著我。我可以通過縫隙看到他: ......
[cpg]

這一邊沒有光，所以他應該看不到我們。
[cpg]

但我能聽到聲音。最好的辦法是保持警覺。
[cpg]


;//■選択肢
[switch]
[case "繼續向南走。"]
	[swap]
	[jump target="*select04_5"]
[case "向東行進。"]
	[swap]
	[jump target="*select04_3"]
[endswitch]

一，向南走。
[cpg]

二，向東前進。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「３のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※３のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_3|對信玄大人的忠誠。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン３の立ち絵を表示してください

[if exp={getFlagValue("Selectflg4") == 1 }]
[jump target="*select04_3_t"]
[endif]

[jump target="*select04_3_f"]


;//==============================
;//２のマスか７のマスを通っている場合

*select04_3_t|對信玄大人的忠誠。

[SE f=se029]
;//【ＳＥ】『木材きしむ』

[WAIT time=1000]

[FACE method="change_3" pos="2/3"]

謙信又看了看我。
[cpg]

我看到他在為人們打電話。按照這種速度，我們甚至有可能回不來了。
[cpg]

[OnName num="keitarou"]
'這不是好事。 ......
[cpg cn=true]


躲在閣樓上，我甚至可能失去逃跑的路線。
[cpg]

我決定趁著還能逃跑。
[cpg]


;//敗北判定となる
;//「謙信の所へ潜入　二度音の鳴るマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン３ルートへ続く

[jump target="*select04_lose"]


;//==============================
;//２のマス、７のマスいずれも通っていない場合

*select04_3_f|對信玄大人的忠誠。


[SE f=se029]
;//【ＳＥ】『木材きしむ』

[stflag Selectflg4=1]

[WAIT time=1000]

[FACE method="change_7" pos="2/3"]

我聽到木頭吱吱作響的聲音。我驚慌失措，停了下來。
[cpg]

就在我下面的謙信，正抬頭看著我。我可以通過縫隙看到他: ......
[cpg]

這一邊沒有光，所以他應該看不到我們。
[cpg]

但我能聽到聲音。最好的辦法是保持警覺。
[cpg]


;//■選択肢
[switch]
[case "向南前進。"]
	[swap]
	[jump target="*select04_6"]
[endswitch]

1，向南行進。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※４のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_4|忠於信玄大人。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

小心翼翼地前進，以免發出聲音。
[cpg]

......，聽一聽，聽一聽，聽一聽謙信。
[cpg]

現在，地板在向南的方向上改變了顏色。你必須要小心。
[cpg]


;//■選択肢
[switch]
[case "繼續向南走。"]
	[swap]
	[jump target="*select04_7"]
[case "繼續向東走。"]
	[swap]
	[jump target="*select04_5"]
[endswitch]

1，向南行進。
[cpg]

2，向東行進。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「７のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※５のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_5|對信玄大人的忠誠。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

可以聽到謙信的獨白。也許他正試圖給某人打電話。
[cpg]

這是因為他感覺到了我的存在，還是他在和別人談論即將到來的戰鬥？
[cpg]

如果是後者，我就不能不聽。
[cpg]


;//■選択肢
[switch]
[case "向南前進。"]
	[swap]
	[jump target="*select04_8"]
[case "向東走。"]
	[swap]
	[jump target="*select04_6"]
[endswitch]

1，向南前進。
[cpg]

2，向東行駛。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※６のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_6|對信玄大人的忠誠。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

最後，我們已經走了這麼遠，可以近距離地看到謙信。
[cpg]

我不能鬆懈，直到最後。我在慢慢地走。 ......
[cpg]


;//■選択肢
[switch]
[case "向南行進"]
	[swap]
	[jump target="*select04_9"]
[endswitch]

1，向南前進。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※７のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_7|對信玄大人的忠誠。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン３の立ち絵を表示してください

[SE f=se029]
;//【ＳＥ】『木材きしむ』

[stflag Selectflg4=1]

[WAIT time=1000]

[FACE method="change_7" pos="2/3"]


我聽到木頭吱吱作響的聲音。我停下來，驚慌失措。
[cpg]

就在我下面的謙信，正抬頭看著我。我可以通過縫隙看到他: ......
[cpg]

這一邊沒有光，所以他應該看不到我們。
[cpg]

但我能聽到聲音。最好的辦法是保持警覺。
[cpg]


;//■選択肢
[switch]
[case "繼續向東走。"]
	[swap]
	[jump target="*select04_8"]
[endswitch]

1，向東行進。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※８のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_8|對信玄大人的忠誠。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン３の立ち絵を表示してください

[if exp={getFlagValue("Selectflg4") == 1 }]
[jump target="*select04_8_t"]
[endif]

[jump target="*select04_8_f"]


;//==============================
;//２のマスか７のマスを通っている場合

*select04_8_t|對信玄大人的忠誠。

[SE f=se029]
;//【ＳＥ】『木材きしむ』

[WAIT time=1000]

[FACE method="change_3" pos="2/3"]

謙信又看了看我。
[cpg]

我看到他在為人們打電話。按照這種速度，我們甚至有可能回不來了。
[cpg]

[OnName num="keitarou"]
'這不是好事。 ......
[cpg cn=true]


躲在閣樓上，我甚至可能失去逃跑的路線。
[cpg]

我決定趁著還能逃跑。
[cpg]


;//敗北判定となる
;//「謙信の所へ潜入　二度音の鳴るマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン３ルートへ続く

[jump target="*select04_lose"]


;//==============================
;//２のマス、７のマスいずれも通っていない場合

*select04_8_f|對信玄大人的忠誠。


[SE f=se029]
;//【ＳＥ】『木材きしむ』

[stflag Selectflg4=1]

[WAIT time=1000]

[FACE method="change_7" pos="2/3"]


我聽到木頭吱吱作響的聲音。我驚慌失措，停了下來。
[cpg]

就在我下面的謙信，正抬頭看著我。我可以通過縫隙看到他: ......
[cpg]

這一邊沒有光，所以他應該看不到我們。
[cpg]

但我能聽到聲音。最好的辦法是保持警覺。
[cpg]


;//■選択肢
[switch]
[case "繼續向東走。"]
	[swap]
	[jump target="*select04_9"]
[endswitch]

1，向東行進。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※９のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_9|對信玄大人的忠誠。



;//勝利判定

;//謙信の所へ潜入　勝利した場合
;//と書いてあるところまで飛ぶ（ヒロイン２ルートに入る


[jump target="*select04_win"]



*select04_lose
[jump storage="ep007.ks" target="*start"]



*select04_win
[jump storage="ep008.ks" target="*start"]

