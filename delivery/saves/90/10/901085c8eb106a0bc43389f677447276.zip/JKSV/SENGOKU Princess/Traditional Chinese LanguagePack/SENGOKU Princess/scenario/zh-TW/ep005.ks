
*start

;//==============================
;//桶狭間の戦い　二度伏兵のマスを通った場合

*select03_lose|奧克哈紮馬之戰

*root_4|即使你知道這是一種背叛。

;#################################################
*Ep005|即使你知道這是一種背叛。
;#################################################

[SCENE id=5]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我離開戰場的部分原因是光秀大人讓我這樣做。
[cpg]

最後，我沒能看到做出決定的那一刻，但......
[cpg]

有人告訴我，信長大人已經贏得了奧克哈紮馬。
[cpg]

我再次想起了她的才華。即使我原來不在那裡，也可能是一樣的。
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

信長大人取得了勝利，但心情不是很好。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="3/3" time=800]

[VOICE f="Ranmaru450"]
[OnName num="ranmaru"]
'這是個很好的計劃。我只能說，它是......，才會有如此好的效果。 "
[cpg cn=true]


[OnName num="keitarou"]
我......，無法戰鬥到最後。我很抱歉。 "
[cpg cn=true]


我不得不誠實地表示歉意。當然，我應該站在戰場上。
[cpg]



;//このセリフは削除
;//信長「私は不本意だ。景太郎が参戦しなかったからな」


我現在的處境是，我只是被保住了性命。
[cpg]

[FACE method="change_1" pos="1/3"]

[VOICE f="Mituhide058"]
[OnName num="mitsuhide"]
'好吧，景太郎，讓我們讓你學習一下政治。
[cpg cn=true]


[FACE method="change_6" pos="1/3"]

[VOICE f="Mituhide059"]
[OnName num="mitsuhide"]
這也是報答的一種方式。
[cpg cn=true]


光秀大人跟進了。他在為我著想。 ......
[cpg]

或者說，光秀大人認為他比信長大人更聽我的話。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

[OnName num="keitarou"]
'謝謝你.......因為給了我一個援助之手'。
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide060"]
[OnName num="mitsuhide"]
'不，不，不要擔心這麼多。
[cpg cn=true]


與信長大人相比，光秀大人的心情很好。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide061"]
[OnName num="mitsuhide"]
我很高興你對我比對信長大人更有吸引力。
[cpg cn=true]


畢竟，這就是事情的真相。看來，光秀大人是在看我是否會強迫自己去做這件事。
[cpg]

當然，我也有一部分人想跟著光秀大人，......。
[cpg]

[OnName num="keitarou"]
'...... 真心的，還有一種感覺是我不敢再打了。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide062"]
[OnName num="mitsuhide"]
'什麼都可以。對我來說，你是一個重要的人。我不想失去你。 "
[cpg cn=true]


說這話時，光秀大人拉著我的手。他轉向我。 ......
[cpg]

不知道這意味著什麼，我把目光移開。
[cpg]

不，我真的知道。光秀大人也關心我。
[cpg]

這一次是以聽從光秀大人的形式。它是......
[cpg]


這可能意味著光秀大人比信長大人更重要。
[cpg]

[OnName num="keitarou"]
'別這麼盯著我。
[cpg cn=true]


光秀大人聽到我的話，沒有放開我的手。
[cpg]

[FACE method="shake_2" pos="2/3"]

談到這個問題，我想說的是："我想說的是：'我是一個人，我是一個人，我是一個人，我是一個人，我是一個人，我是一個人，我是一個人，我是一個人'。
[cpg]


;//ブラックアウト

[SE f=se000]
;//【ＳＥ】『通路歩く』

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

然後光秀先生拉著我的手，把我帶到他的房間。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_09"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide063"]
[OnName num="mitsuhide"]
'景太郎先生。信長大人很喜歡你，對嗎？
[cpg cn=true]


[OnName num="keitarou"]
是的，是的。 ...... 好吧。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide064"]
[OnName num="mitsuhide"]
不是說這是原因。 ......
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

她說，把她的嘴唇放在我的嘴唇上，同時握住我的手。
[cpg]

我很驚訝，拉開了距離。
[cpg]

[OnName num="keitarou"]
'你想做什麼？
[cpg cn=true]


光秀大人在向我示好。她是想把我這個受信長大人寵愛的人抓在手裡嗎？
[cpg]

首先要做的是射殺馬匹。 ......。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide065"]
[OnName num="mitsuhide"]
'你不逃開我，反而把我推開。
[cpg cn=true]


[OnName num="keitarou"]
......，這是......."
[cpg cn=true]


我對自己的決定並不完全滿意。在某種程度上，我沒有去參加戰鬥，回想著光秀大人的話。
[cpg]


;//ブラックアウト

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide066"]
[OnName num="mitsuhide"]
信長大人不會做這樣的事情。
[cpg cn=true]


[OnName num="keitarou"]
'這當然是，......
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide067"]
[OnName num="mitsuhide"]
'我相信他會的。我願意為他做任何事。
[cpg cn=true]



;//移植前シーンカット

我堅持著這種不會消退的感覺，並決定請她離開。
[cpg]

不出所料，這段關係突然變得太短。
[cpg]

[OnName num="keitarou"]
'......，你應該更好地照顧自己。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide094"]
[OnName num="mitsuhide"]
'我正在努力，你知道。好吧，如果你不喜歡，我會改變它的。
[cpg cn=true]



[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

又是一天。我看到光秀先生正在照料他的盆景。
[cpg]

[OnName num="keitarou"]
'你非常熱心。盆景真的那麼有趣嗎？
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide095"]
[OnName num="mitsuhide"]
'是的。對我來說，它似乎代表了世界的興衰。
[cpg cn=true]


世界的興衰。她似乎看到了這樣的事情。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Mituhide096"]
[OnName num="mitsuhide"]
...... 你怎麼看？　你認為信長大人會繼續統治嗎？ "
[cpg cn=true]


光秀大人在照料盆景樹時問道。
[cpg]

[OnName num="keitarou"]
是的。
[cpg cn=true]


我回答說，但我知道光秀大人會背叛我。
[cpg]

唯一知道一切的人是我和試圖發動叛亂的光秀大人。
[cpg]

當我這樣想的時候，光秀大人一環顧四周。在確認沒有人之後。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide097"]
[OnName num="mitsuhide"]
'我對這一點多少有些了解。你知道我正在試圖發動一場叛亂。
[cpg cn=true]


他告訴了我一切。
[cpg]

[OnName num="keitarou"]
這是......"
[cpg cn=true]


我退縮了，但我無法否認。
[cpg]

我什麼都說不出來。我甚至不知道如何正確回答。
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Mituhide098"]
[OnName num="mitsuhide"]
我不知道你從哪裡來。而且你對我的警惕性異常高。
[cpg cn=true]



;//下記のセリフ、台本では
;//「何か、魔法めいた力で、景太郎さんは未来を知っているようだ。違いますか」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください

[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide099"]
[OnName num="mitsuhide"]
'你似乎知道未來，景太郎先生。不是嗎？
[cpg cn=true]


你幾乎是對的。和信長大人一樣，他也相當敏銳。
[cpg]

蘭丸大人甚至直到這裡才意識到。 ......
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide100"]
[OnName num="mitsuhide"]
'然而，他仍然不告訴我。在那裡，他聞起來就像我。 "
[cpg cn=true]


他觸及了我的真實感受。
[cpg]

我當然不能說光秀大人會背叛我。
[cpg]

如果我這樣做了，光秀大人就會被處決。我擔心，如果有任何證據被發現。
[cpg]

[OnName num="keitarou"]
'...... 你在多大程度上看透了這一點？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide101"]
[OnName num="mitsuhide"]
'沒有達到信長大人的要求，但大部分是這樣。但如果是真的，我就會更喜歡你。
[cpg cn=true]


我沒有反駁什麼。我確實很關心光秀大人。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide102"]
[OnName num="mitsuhide"]
'我認為我真的很不周到。但有你在我身邊，我可以做任何事。
[cpg cn=true]


光秀大人停止照料盆景，拉著我的手。
[cpg]

令人印象深刻的是，他的手在顫抖。
[cpg]

他突然顯示出他的弱點。他似乎對違抗信長大人感到恐懼。
[cpg]

[OnName num="keitarou"]
'光秀大人......'
[cpg cn=true]


這就是光秀大人的工作。這可能都是一種行為。
[cpg]

;//＠それでもこのままでは折れてしまいそうな光秀様を見て、俺は心を動かされた。
即便如此，看到看起來像要崩潰的光秀先生這樣，我的心也被感動了。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************


;//☆
;//[VOICE f="sMitsuhide001"]
;//[OnName num="mitsuhide"]
;//「……景太郎さん。私は貴方のことを、好きなのだと思います」
;//[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
我告訴光秀大人，我真的很喜歡他。
[cpg]

他說了這麼多。光秀大人看起來很嚴肅。
[cpg]

[OnName num="keitarou"]
'你不應該隨便說這種話。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide104"]
[OnName num="mitsuhide"]
'這聽起來像我說得很輕巧嗎？　我會說多少次，直到它聽起來很嚴肅'。
[cpg cn=true]


[OnName num="keitarou"]
'......'
[cpg cn=true]


光秀大人走到我耳邊，低聲說。我對此的感覺很複雜。
[cpg]


;//移植前シーンカット

並不是說我對光秀大人沒有任何感情。當然那是事實。
[cpg]

相反，它只是愛。但即便如此，我仍然對...... 信長大人心懷感激。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Mituhide129"]
[OnName num="mitsuhide"]
有什麼不對嗎？　景太郎先生，你看起來好像很痛苦的樣子。
[cpg cn=true]


[OnName num="keitarou"]
編號：......
[cpg cn=true]


此外，光秀大人知道他將與秀吉作戰，而且會輸。
[cpg]

無論你選擇誰，信長大人還是光秀大人，你們都不可能一起度過餘生。
[cpg]

即使我感到無常，我......
[cpg]

[OnName num="keitarou"]
光秀大人。我也愛你。 "
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

我選擇了光秀大人。她有點驚訝，然後看起來很高興。
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide130"]
[OnName num="mitsuhide"]
'是的。謝謝你。 "
[cpg cn=true]



;//移植前シーンカット

我覺得光秀大人是想用這種愛來支配我。
[cpg]

我不認為如果我對她有完全的感情，就不會發生這種情況。
[cpg]

這就是我對她的迷戀。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide152"]
[OnName num="mitsuhide"]
'我愛你，...... 景太郎先生。我們將永遠在一起'。
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


她把目光投向了被信長大人看中的我。
[cpg]

有可能所有這些都是計算的結果。
[cpg]

但知道這一點後，我無法遠離她。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

最後，我也會成為一個叛徒嗎？
[cpg]

只要我不能阻止光秀大人，就可以說我同樣有罪。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru451"]
[OnName num="ranmaru"]
...... 景太郎，嗯？你看起來不怎麼好。
[cpg cn=true]


[OnName num="keitarou"]
蘭丸大人，......，這沒什麼。
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru452"]
[OnName num="ranmaru"]
我希望如此。你和光秀最近花了很多時間在一起。
[cpg cn=true]


......，沒事的。我相信蘭丸大人沒有註意到。
[cpg]

[OnName num="keitarou"]
'這有什麼問題嗎？
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru453"]
[OnName num="ranmaru"]
不，不，這沒什麼。我只是想，"你怎麼能和這樣的人約會？"
[cpg cn=true]


[OnName num="keitarou"]
光秀大人看起來像嗎？
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Ranmaru454"]
[OnName num="ranmaru"]
他笑得很開心，但看起來並不像真的在笑。
[cpg cn=true]


在我看來是這樣的。我知道這一切的真相，我也在一定程度上知道光秀大人的想法。 ......
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『街』（夕方）******************************************************

傍晚時分的城堡小鎮。我是被信長大人帶到這裡的。
[cpg]


;//下記のセリフ、台本では「街」ですがシナリオでは「町」になっています

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga670"]
[OnName num="nobunaga"]
'看一看。我從未見過如此平靜的城鎮。
[cpg cn=true]


[OnName num="keitarou"]
'我肯定你有。當信長大人出生時，戰爭可能已經開始了。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga671"]
[OnName num="nobunaga"]
是的，但它即將結束。但這即將結束。
[cpg cn=true]


信長大人似乎並不懷疑這一點。
[cpg]

事實上，還有一次動亂。事實上，信長大人還有一波動亂要參與其中。
[cpg]

我只是不能讓自己說出來。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我回到我的房間，試圖休息，但我的情緒有些不穩定。
[cpg]

光秀大人和我以後想做什麼？
[cpg]

即使是她也應該活不長。跟隨她真的可以嗎？
[cpg]

另一方面，她可能會在本能寺事件後採取行動接管國家。
[cpg]

我不能阻止她這樣做。當我在想，。
[cpg]


[VOICE f="Mituhide153"]
[OnName num="mitsuhide"]
'景太郎先生。是我。 "
[cpg cn=true]


[OnName num="keitarou"]
啊，請進來......."
[cpg cn=true]



[SE f=se025]
;//【ＳＥ】『ふすま開く』


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]


光秀大人已經到了。
[cpg]

[OnName num="keitarou"]
'你睡不著嗎？
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide154"]
[OnName num="mitsuhide"]
'我不禁想到了未來。但我認為我可以和你一起做。
[cpg cn=true]


當然，這一點是毫無疑問的。我將站在光秀大人這一邊。
[cpg]

但你無法改變你的命運。光秀大人不能打倒天堂......
[cpg]

那麼我們就只有一個辦法來獲得幸福。
[cpg]

背叛信長大人。這是現在唯一的辦法，因為我們無法通過任何方式改變未來。
[cpg]

在此基礎上，我們不能試圖接管國家。否則，光秀大人就會死。
[cpg]

[OnName num="keitarou"]
'......'
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide155"]
[OnName num="mitsuhide"]
'你在想什麼。現在，你不需要考慮其他的事情'。
[cpg cn=true]


光秀大人這樣說，但我的心情很複雜。
[cpg]

最終，我需要告訴他我們獲得幸福的唯一途徑。但是。
[cpg]

出賣了信長大人，我還能說服她嗎？
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide156"]
[OnName num="mitsuhide"]
'景太郎先生。看著我。
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

光秀大人這樣說，並走近我。然後他吻了我。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide157"]
[OnName num="mitsuhide"]
'...... 未來，你知道。即使是我也不能平靜地對待它。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide158"]
[OnName num="mitsuhide"]
但我仍然很高興能和你在一起。
[cpg cn=true]


;//移植前シーンカット

我被她迷住了。這一點是毫無疑問的。
[cpg]

光秀大人說他喜歡我，但我認為他真的有點強人所難。
[cpg]

她甚至想用愛來維繫我。
[cpg]

知道了這一點，我就無法甩掉她。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

隨著時間的推移，我從信長大人的諸侯那裡學到了越來越多的政治知識。
[cpg]

信長大人可能認為，一個和平的世界即將到來。
[cpg]

事實上，如果她掌握了韁繩，並保持這種方式，甚至有可能。 ......
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

最終，信長大人統一了全國。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="3/3" time=800]


[VOICE f="Nobunaga672"]
[OnName num="nobunaga"]
'......，到目前為止已經過了很長時間，不是嗎？
[cpg cn=true]


[FACE method="bow_2" pos="3/3"]

[VOICE f="Ranmaru455"]
[OnName num="ranmaru"]
是的，它有。但你終於實現了你的願望，不是嗎？
[cpg cn=true]


信長大人看了看光秀大人。光秀大人仍然微笑著。
[cpg]

[FACE method="bow_2" pos="1/3"]

[VOICE f="Mituhide181"]
[OnName num="mitsuhide"]
我很高興能成為你的附庸。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga673"]
[OnName num="nobunaga"]
我明白了。我也很高興能有一個優秀的臣子。
[cpg cn=true]


信長大人在笑，但我不知道他是不是真的在笑。
[cpg]

我也在思考如何堅持自己的立場。
[cpg]

如果我和光秀大人一起生活，我會走什麼路？
[cpg]

我至少會背叛信長大人和蘭丸大人。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga674"]
[OnName num="nobunaga"]
'景太郎似乎並不......，太高興了。
[cpg cn=true]


[OnName num="keitarou"]
'不。我很高興'。
[cpg cn=true]


難怪他能在這裡看穿我。我會做一個假笑，但我肯定他能看穿我。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

最近，光秀大人甚至想和我生個孩子。
[cpg]

如果我從現在開始要發動叛亂，我就不希望肚子裡有孩子。 ......。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Mituhide182"]
[OnName num="mitsuhide"]
'從現在起，我將無法安靜地生活。我想在我還可以的時候和你生個孩子。 "
[cpg cn=true]


[OnName num="keitarou"]
'......，我明白了。
[cpg cn=true]


她要做什麼？她對自己的生命有任何懷疑嗎？
[cpg]

我不能把一切都告訴她。我的心情很複雜。
[cpg]


;//移植前シーンカット

儘管她生性冷漠，但對我卻表現出毫不吝嗇的感情。
[cpg]

我不知道她的真實感情在哪裡。我想這是因為信長大人在某種程度上信任我。
[cpg]

我理解想把我留在她身邊的心理。這也可能會讓人更容易開始叛亂。但......
[cpg]

我不知道她現在的行為是否真的有這樣的計算。
[cpg]

[OnName num="keitarou"]
'...... 光秀大人。你真的要背叛信長大人嗎？
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Mituhide204"]
[OnName num="mitsuhide"]
'是的。怎麼了？ "
[cpg cn=true]


光秀大人毫不猶豫地這樣說。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Mituhide205"]
[OnName num="mitsuhide"]
我將讓蘭丸也死去。讓她活著是不安全的。
[cpg cn=true]


他從未在信長大人和其他人面前表現出這種可怕的本性。
[cpg]

本野寺事件即將發生。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Mituhide206"]
[OnName num="mitsuhide"]
'......，我真的不想背叛她。
[cpg cn=true]


是的，她是。為什麼她一開始就想背叛我們？
[cpg]

[OnName num="keitarou"]
光秀大人，你是......，想自己接管國家？
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Mituhide207"]
[OnName num="mitsuhide"]
'不。我的真正目的是恢復幕府。我不尋求上升到頂峰。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide208"]
[OnName num="mitsuhide"]
你知道我曾經為足利義昭大人服務嗎？
[cpg cn=true]


[OnName num="keitarou"]
不，......，我從未聽說過你。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Mituhide209"]
[OnName num="mitsuhide"]
義昭大人下了命令，這整個事情。
[cpg cn=true]


這是否意味著對光秀大人來說，他是比信長大人更值得追隨的人？
[cpg]

然而，我無話可說。
[cpg]

我並不關心原因。難道是她對足利義昭這個人的崇拜超過了信長大人？
[cpg]

還是她認為信長大人的統治不能像現在這樣繼續下去？
[cpg]

現在這已經無關緊要了。無論叛亂者有什麼意圖，都是一樣的。
[cpg]

我不能說什麼，因為害怕改變未來。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

不管是光秀大人的意願改變，還是我說服他，未來最終都會被改變的。
[cpg]

無論他想做什麼樣的思考，都是一樣的。
[cpg]

信長大人注定會死。蘭丸大人也是如此。 ......
[cpg]

當你改變這一點時，可能會是一個我沒有出生的未來。
[cpg]

對我的家人和其他人也是如此。我必須千方百計地避免這種情況。
[cpg]

所以我沒有選擇，只能保持沉默。
[cpg]

如果有什麼是我可以改變的，那就是關於光秀先生的未來。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide210"]
[OnName num="mitsuhide"]
這是個美好的夜晚，不是嗎？它很安靜。 "
[cpg cn=true]


[OnName num="keitarou"]
'...... 是的。
[cpg cn=true]



;//ブラックアウト

她沒有說一句話，而是慢慢向我靠近。
[cpg]


;//========================================
;//●ＣＧ（主人公の体に手を突いているヒロイン）ev_34
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿縁側の通路
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



我也沒有拒絕她。
[cpg]


[VOICE f="Mituhide211"]
[OnName num="mitsuhide"]
我從來沒有真正平靜過。
[cpg cn=true]



[VOICE f="Mituhide212"]
[OnName num="mitsuhide"]
無論信長大人如何讚美我，無論我為他做了多少事，我都感到空虛。
[cpg cn=true]


[OnName num="keitarou"]
我相信這是真的。
[cpg cn=true]



[VOICE f="Mituhide213"]
[OnName num="mitsuhide"]
另一方面，你知道我的真實本性，但不知為何你一直保持沉默。
[cpg cn=true]



[VOICE f="Mituhide214"]
[OnName num="mitsuhide"]
沒有人比你更支持我了。
[cpg cn=true]


她無所畏懼，或者說，她毫不猶豫地在我面前談論背叛信長大人的事。
[cpg]

也許她真的想被關注。
[cpg]

也許她希望有人能阻止她。
[cpg]

但我無法判斷她的真實想法，因為它被隱藏在幾層掩飾之下。
[cpg]

[OnName num="keitarou"]
光秀大人。我還是不知道你在想什麼。
[cpg cn=true]


;**【ＣＧ】 ev_34_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Mituhide238"]
[OnName num="mitsuhide"]
'我肯定你不知道。我不認為你能找到我自己即將失去視力的東西'。
[cpg cn=true]


我相信，......，她有太多複雜的情況。
[cpg]

而光秀先生很聰明，把它們全部重疊起來，使它們加起來。
[cpg]

我以為這是她用頭腦而不是用心靈行事的結果。
[cpg]

只要她能再一次找回自己的心，......
[cpg]

我想知道我在那裡灰心喪氣會是什麼樣子。
[cpg]


;//移植前シーンカット

;//ブラックアウト

;//qwe

[window target=false]
[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

[OnName num="keitarou"]
'......，我也開始失去......，不知道自己想做什麼。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide239"]
[OnName num="mitsuhide"]
'這是不可能的，是嗎？這是不可能的。只是活在當下。
[cpg cn=true]



;//移植前シーンカット

;//ブラックアウト

;//移植前シーンカット

這是我最後一次能夠平靜地與她做愛。命運的時刻已經來臨了。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

這是我最後一次見到信長大人和蘭丸大人。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Nobunaga675"]
[OnName num="nobunaga"]
'...... 怎麼了？你似乎比平時更陰沉。 "
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


我甚至不能回答說這沒什麼。
[cpg]

我不能在這裡透露一切。
[cpg]

[FACE method="shake_7" pos="4/5"]

[VOICE f="Ranmaru456"]
[OnName num="ranmaru"]
'別擔心。信長大人，我們走吧。 "
[cpg cn=true]


蘭丸大人今天似乎是蘭丸大人。與信長大人和光秀大人相比，他很沉悶。
[cpg]

但這是我們最後一次看到她這樣的情況。
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="Nobunaga676"]
[OnName num="nobunaga"]
景太郎。我不知道你發生了什麼，但要振作起來。
[cpg cn=true]


我甚至無法回答這些話。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


那是一個糟糕的夜晚。我感覺我被吸進了黑暗中。
[cpg]

我所能做的就是什麼都不做，但由於什麼都不做，就好像我被困住了。
[cpg]


[VOICE f="Mituhide285"]
[OnName num="mitsuhide"]
'......，現在我們將能夠重新建立幕府。
[cpg cn=true]


本能寺正在燒紅。我讓信長大人和蘭丸大人去死。
[cpg]

儘管感到內疚，但我也不明白自己的真實意圖。
[cpg]

除了光秀大人，沒有其他人了。我認為除了和她在一起，沒有其他辦法。
[cpg]

但......，這條路也不容易。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

一夜之後，光秀大人身邊只有她的盟友。
[cpg]

自然是這樣。如果有任何人哪怕是對信長大人稍有忠誠，她就會有危險。
[cpg]

[OnName num="keitarou"]
'......，它非常小心，不是嗎？你是否想到了一切，包括你將如何表現？
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide286"]
[OnName num="mitsuhide"]
我想一旦我決定做這樣的事情，我就會很快從那裡開始。我不認為我是徹底的。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Mituhide287"]
[OnName num="mitsuhide"]
我只是......，不知道我是否是決定自己要做什麼的人了。
[cpg cn=true]


光秀大人一定經歷了很多衝突。
[cpg]

他們正在研究我根本無法想像的想法。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide288"]
[OnName num="mitsuhide"]
'...... 更多的是，我有好消息要告訴你。我前幾天看了一個醫生。 ......"
[cpg cn=true]


光秀大人揉著我的肚子，告訴我我有了孩子。
[cpg]

我對此並不完全滿意。我知道將要發生什麼。
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

從那裡，其他的將軍們開始行動，包圍光秀大人。
[cpg]

按照這種速度，光秀先生再次被殺只是時間問題。
[cpg]

但至少這是我所知道的歷史事實。
[cpg]

這很奇怪，我覺得還有一些時間可以利用。
[cpg]

通常情況下，光秀大人不會被當作曾經奪取過國家的人對待。
[cpg]

她在叛亂中倖存下來的時間應該是那麼短。
[cpg]

正如我所想的那樣，這與我所知道的歷史有一點不同。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

光秀大人的肚子正在擴大。自從她生下這個孩子以來，大約四個月過去了。
[cpg]

我還活著，她也還活著。我不知道我還剩下多少時間。
[cpg]

我想知道光秀大人現在在想什麼。
[cpg]

我確信他知道我的心態，但最可怕的一定是光秀先生本人。
[cpg]


;//ブラックアウト

[window target=false]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我仍然有復雜的感覺。
[cpg]

愛上殺死信長大人和蘭丸大人的她是正確的嗎？
[cpg]

而從現在開始，連她自己也不會安全了。
[cpg]

[OnName num="keitarou"]
'......，也許我應該把一切都告訴光秀大人。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Mituhide293"]
[OnName num="mitsuhide"]
'是的，這就對了。我很高興你願意向我透露，因為看來你對我還有一些秘密。
[cpg cn=true]


我知道我不想失去她。為此，我只能做一件事。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Mituhide317"]
[OnName num="mitsuhide"]
我想我將會遇到秀吉。而且也是在不遠的將來。
[cpg cn=true]


[OnName num="keitarou"]
'......，我明白了。
[cpg cn=true]


也許她會死在那裡。
[cpg]

我知道這不應該被接受......，但這是歷史事實。
[cpg]

我想知道我被允許透露多少信息。
[cpg]

信長大人說他不想知道未來的事情，但是光秀大人呢？
[cpg]

如果他知道自己會死，他可能會努力避免。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夕方）******************************************************

我感到很不安。我很煩惱，但答案必須盡快到來。
[cpg]

沒有人可以諮詢。信長大人和蘭丸大人已經不在這個世界上了。
[cpg]

是光秀大人殺了他們。這是令人難以置信的。
[cpg]

如果你不背叛，你就會被背叛，如果你不殺，你就會被殺。我知道是這樣一個時代。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[window target=true]


...... 而我做了一個決定。
[cpg]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide318"]
[OnName num="mitsuhide"]
它是什麼？你想和我談談嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
'是的，......，我想告訴你我知道的一切。
[cpg cn=true]


光秀大人的確是認真的。他可能認為他終於可以從我這裡聽到真相了。
[cpg]

[OnName num="keitarou"]
'我來自未來。你不會相信的，但這是真的'。
[cpg cn=true]


[OnName num="keitarou"]
而且也不是由我來以任何重大方式改變未來。
[cpg cn=true]


事實上，我已經搬到了未來，以至於我從未改變過它。
[cpg]

[FACE method="bow_7" pos="2/3"]

[VOICE f="Mituhide319"]
[OnName num="mitsuhide"]
'......，這很難讓人相信，但這樣一來，你知道我要背叛你，並對此保持沉默也就說得通了。
[cpg cn=true]


光秀大人似乎很滿意。我繼續說。
[cpg]

[OnName num="keitarou"]
如果這種情況繼續下去，光秀大人就會被秀吉打敗。難道你現在也不打算逃跑嗎？ "
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide320"]
[OnName num="mitsuhide"]
不，我不知道。但如果我將來贏了，你就會有麻煩了。
[cpg cn=true]


這當然是真的。如果未來發生變化，這可能意味著我將不會出生。
[cpg]

[OnName num="keitarou"]
'如果我不這樣做，未來就會改變。也許這將是一個我永遠不會出生的世界。 "
[cpg cn=true]


我繼續往下講。我不能只是袖手旁觀。
[cpg]

[OnName num="keitarou"]
如果要開戰，我將不惜一切代價阻止你。
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Mituhide321"]
[OnName num="mitsuhide"]
'......，我明白了。但我只有一件事可以做。
[cpg cn=true]


即便如此，看來光秀大人的意願並沒有改變。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Mituhide322"]
[OnName num="mitsuhide"]
'我們已經犧牲了太多，不能再回頭了。我現在不打算把王國交給秀吉。
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我終究還是無法阻止光秀大人嗎？
[cpg]

我想知道是否有什麼我可以做的。 ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

我多次試圖勸說光秀大人，並談了我要做的事。
[cpg]

但光秀大人的決心似乎很堅定。
[cpg]

[OnName num="keitarou"]
'......，你是否要打仗，通過各種方式？
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Mituhide323"]
[OnName num="mitsuhide"]
是的，我就是要這樣做。
[cpg cn=true]


;//ブラックアウト

;//移植前シーンカット
[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我直接和她上床了。
[cpg]

剩下的時間已經不多。我壓抑著自己的不耐煩，認為我不能讓他知道我的真實感受。
[cpg]

真正的感情，換句話說，是讓光秀大人逃跑的感情，即使這意味著綁架她。
[cpg]


[window target=false]
[BG f="b_07_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

而在早晨，......，我是第一個醒來的人。
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ微エロ（事後。二人で同じ布団に入っている。眠そうにしながら目を覚ますヒロイン）ev_53
;//人物１：ヒロイン４　服装１：裸
;//人物ex：主人公　　　服装ex：裸
;//場所　：城＿室内
;//時間　：朝
;//備考　：ヒロインは妊娠六ヶ月くらいです
;//========================================


[BGM f="bg_09"]
;**【ＣＧ】 ev_53_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Mituhide348"]
[OnName num="mitsuhide"]
...... 早晨？
[cpg cn=true]


[OnName num="keitarou"]
是的。請起身。
[cpg cn=true]


;//＠二人とも、裸のまま眠ってしまっていた。
我們都赤身裸體地睡著了。
[cpg]

這段平靜的時間即將被奪走。
[cpg]

這是一種無法抗拒的感覺。我想不惜一切代價保護她。
[cpg]


[VOICE f="Mituhide349"]
[OnName num="mitsuhide"]
'你有一張可怕的臉，不是嗎？你有什麼心事嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
'...... 我已經說了我能說的一切。
[cpg cn=true]



[VOICE f="Mituhide350"]
[OnName num="mitsuhide"]
不要擔心。我不會輸。 "
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


我無話可說。
[cpg]

再說什麼也沒用了。然後......
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

然後，我策劃了一下。
[cpg]

有些士兵比光秀大人更願意跟著我。
[cpg]

即使他們不知道，當我向他們解釋整個情況時，他們也會明白.......。
[cpg]

沒有人會相信來自未來的如此離奇的事情？
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Mituhide351"]
[OnName num="mitsuhide"]
'...... 你想做什麼？
[cpg cn=true]


[OnName num="soldier_A"]
'我很抱歉。現在，請跟隨景太郎大人。
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]

[VOICE f="Mituhide352"]
[OnName num="mitsuhide"]
你是什麼意思？景太郎先生。
[cpg cn=true]


[OnName num="soldier_B"]
......
[cpg cn=true]


我們有三個人，包括我。這是防止她逃跑所需的最低數量。
[cpg]

[OnName num="keitarou"]
我要離開城堡。我別無選擇，只能這樣做'。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

我帶著光秀大人，從城堡裡逃了出來。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Mituhide353"]
[OnName num="mitsuhide"]
我相信這是毫無意義的。一旦我走了，所有人都會注意到，他們會來找我。
[cpg cn=true]


[OnName num="keitarou"]
'...... 儘管如此，我還是不能放棄。我不想放棄你'。
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夕方）******************************************************

我們無法快速行動。畢竟，光秀大人已經懷孕了。
[cpg]

即使你說你要逃跑，他們追上你也只是時間問題。
[cpg]

但是，我仍然不能什麼都不做。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Mituhide354"]
[OnName num="mitsuhide"]
如果......，你如此堅持，我可能真的要失去它了!
[cpg cn=true]


[OnName num="keitarou"]
是的，我知道。根據我知道的歷史，下一個掌權的人是秀吉。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Mituhide355"]
[OnName num="mitsuhide"]
'但你現在不能逃跑。正如我之前所說，我已經做出了太多的犧牲'。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

[OnName num="mitsuhide_vassal"]
他在那裡!　在這裡！ "
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


逃跑的嘗試沒有持續一天。他們當晚就追上了我們。
[cpg]

我想我為自己爭取了足夠的時間，但這個時代的人腳步很快。
[cpg]

我想到了這一點，但我也意識到，我還是不能永遠逃避下去。
[cpg]

也許我終究無能為力。
[cpg]

我心中充滿了這種無助的感覺。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

我被帶到了城堡，當我回來時，已經是早上了。
[cpg]

光秀先生一定知道所有的事情。不過，他還是認為我現在沒有辦法逃脫。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Mituhide356"]
[OnName num="mitsuhide"]
'不會有下一次了。如果你再做同樣的事，我甚至要處決你。
[cpg cn=true]


光秀山將無法離開那些試圖與他們的主子一起逃亡的人。
[cpg]

在士兵面前這麼說也是對我的一種威懾。
[cpg]

下次他想綁架光秀山時，可能真的打算處決他。
[cpg]

現在我似乎不得不在我的生命和光秀先生的生命之間進行權衡。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

真讓人吃驚。我甚至不需要去稱量天平。
[cpg]

我的意願已經決定了。光秀大人的生命比我的要重得多。
[cpg]

從她的臣子的角度來看，會是這樣，而從我的角度來看，更是如此。
[cpg]

從她自己的角度來看呢？　我無法想像那麼遠。 ......
[cpg]

但我以為這樣就萬事大吉了。
[cpg]


;//ブラックアウト

當我以為自己會死的時候，我仍然無法停止顫抖。
[cpg]

但我很高興，我遇到了比自己更重要的東西。
[cpg]

與光秀大人的愛情不是這樣的......，別人可以取代。
[cpg]

即使與我自己的生活相比也是如此。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************

[OnName num="keitarou"]
'...... 這種方式。光秀大人。 "
[cpg cn=true]


我正準備再次把光秀大人帶出去。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Mituhide357"]
[OnName num="mitsuhide"]
'......，你是一個永不改變的人。我知道你不會這麼容易就崩潰。
[cpg cn=true]


[OnName num="keitarou"]
'是的。如果你想，你可以殺了我。
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]

[VOICE f="Mituhide358"]
[OnName num="mitsuhide"]
我這樣說也不是為了威脅。我這樣說也不是為了威脅。
[cpg cn=true]


光秀大人帶著痛苦的表情對我說，幾乎是流著淚。
[cpg]

[OnName num="keitarou"]
'這並不重要。反正你的附庸會追上你，但我不能忍受失去你而不做點什麼。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Mituhide359"]
[OnName num="mitsuhide"]
'......，我明白了。我不想和你說再見。
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我將嘗試第二次將光秀大人帶走。
[cpg]

這是一份願意讓自己被殺的聲明。
[cpg]

第二次也是如此，把光秀帶出去，最後也不會成真。我知道。
[cpg]

我將被處決。我也知道這一點。
[cpg]

[OnName num="mitsuhide_vassal"]
你，......，意識到你做了什麼嗎？
[cpg cn=true]


[OnName num="keitarou"]
我理解。如果你不知道，你就不能做。
[cpg cn=true]


[OnName num="mitsuhide_vassal"]
我會想你的。但現在是不可避免的。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide360"]
[OnName num="mitsuhide"]
這就夠了。你不想假裝它從未發生過，是嗎，景太郎先生？
[cpg cn=true]


[OnName num="keitarou"]
...... 是的。
[cpg cn=true]


我沒有逃跑和躲藏。以我的生命作為交換，如果我能夠給她帶來哪怕是一個小小的消息。
[cpg]

或者，如果它沒有到達她那裡，如果它不意味著我讓她白白死去。
[cpg]

真的，這就是我想要的一切。 ......
[cpg]


;//背景と別の場所なので、上下に黒帯を入れるなどしてください

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

他們把我帶回去，把我關在監獄裡。
[cpg]

我被處決的日子就要到了。奇怪的是，我感到很平靜。
[cpg]

我再也沒有看到光秀先生的臉了。
[cpg]

她可能也很難看到我。這很好。
[cpg]


;//ホワイトアウト
[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1100]

我不害怕任何東西。最可怕的是，我無法下定決心。
[cpg]

我......，這一切都很好。
[cpg]

[window target=false]
[WAIT time=1000]

;//ここから一人称ではなく三人称に変わります
;//文章を画面中央に表示するなどして、雰囲気を変えてください


;//ゆっくりとブラックアウト
[BG f="black.ui" time=1000]
[WAIT time=1000]

[STOPBGM]
[WAIT time=1000]
[window target=true]


....... 之後
[cpg]

景太郎被處決後，光秀有了一個孩子。
[cpg]

儘管在孩子身上看到了景太郎的臉，光秀還是勇敢地戰鬥。
[cpg]


[VOICE f="Mituhide361"]
[OnName num="mitsuhide"]
'...... 景太郎先生。我也......."
[cpg cn=true]


現在景太郎走了，他毫不猶豫地贏得這場戰鬥。
[cpg]

他用盡全力與秀吉發生衝突，但光秀被打敗了。
[cpg]


[VOICE f="Mituhide362"]
[OnName num="mitsuhide"]
'我，即使是我，也不懼怕任何東西。
[cpg cn=true]


正是因為景太郎不在那裡，光秀才能夠全力以赴地戰鬥。
[cpg]

如果他在全力以赴之後不能獲勝，光秀也不後悔。
[cpg]


;//ＥＮＤ　ヒロイン４ルート

[SCENE id=11]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="epend.ks" target="*start"]

