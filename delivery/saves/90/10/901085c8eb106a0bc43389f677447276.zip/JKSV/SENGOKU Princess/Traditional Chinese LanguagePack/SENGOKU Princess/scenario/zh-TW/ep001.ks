
*start

;//==============================
;//１、仕えるつもりはない

*select_root145|對信長的忠誠


;#################################################
*Ep001|對信長大人的忠誠。
;#################################################

[SCENE id=1]

[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]

[stflag Selectflg1=0]
[stflag Selectflg2=0]
[stflag Selectflg3=0]
[stflag Selectflg4=0]


[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]


[OnName num="keitarou"]
'......，我很抱歉，但我沒有意願為你服務。
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

信玄大人怔了一會兒，然後把頭轉向一邊。
[cpg]

[FACE method="bow_4" pos="2/3"]

[VOICE f="Singen067"]
[OnName num="shingen"]
'...... 是的。這真是太可惜了。 "
[cpg cn=true]


他看起來很誇張地悲傷。
[cpg]

但它看起來不像是在演戲。他一定是真的喜歡我。
[cpg]

[OnName num="keitarou"]
'我很抱歉。但信長大人也在等我回來。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen068"]
[OnName num="shingen"]
'你不需要道歉。這意味著我還不夠好。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

她覺得我有什麼吸引人的地方？
[cpg]

你知道我是來自未來嗎？
[cpg]

信長大人敢於散佈這樣的謠言，這可能嗎？ ......
[cpg]

我腦子裡有很多想法。你甚至有可能再也見不到信玄大人了。
[cpg]

但我又想，我將為信長大人服務。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（朝）******************************************************

然後早晨就來了。那是出發的日子。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru046"]
[OnName num="ranmaru"]
...... 景太郎，你是不是被信玄大人誤導了？
[cpg cn=true]


[OnName num="keitarou"]
你為什麼這麼想？ "
[cpg cn=true]


我回答說，盡量讓自己顯得平靜。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru047"]
[OnName num="ranmaru"]
不，信玄大人可能是想讓你站在他那邊。
[cpg cn=true]


這句話很有意思。我以為蘭丸大人不評價我。
[cpg]

[OnName num="keitarou"]
'......，你怎麼會這樣想？
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru048"]
[OnName num="ranmaru"]
不要重複說同一件事。只是信長大人這麼說而已。
[cpg cn=true]


看來，信長大人也提前看清了形勢。
[cpg]

甚至有可能他們會問我從哪裡來。
[cpg]

如果我在那裡回答的話，信長可能已經想到了。
[cpg]

;//ブラックアウト

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

然後再走山路。如果我真的沒有更多的耐力，如果我忽視了俱樂部的活動，我就無法走路。
[cpg]



[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

此外，還有可能會出現土匪。
[cpg]

這個時代真的是充滿了不便。 ......。
[cpg]


[window target=false]
[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

幾天和幾夜過去了。這是回程，而不是去的路上，而且你在往返的過程中已經疲憊不堪。
[cpg]

然後，在我失去意識的時候...
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

最後，城堡出現在視野中。知道我又回家了，我鬆了一口氣。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru049"]
[OnName num="ranmaru"]
'你真的沒有任何耐力，是嗎？
[cpg cn=true]


[OnName num="keitarou"]
...... 蘭丸大人瘦弱的身體比我有更多的耐力，這真是個奇蹟。
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Ranmaru050"]
[OnName num="ranmaru"]
'不要把我當做那些女人之一。即使這樣，我相信信長大人在某種程度上還是信任我。
[cpg cn=true]


我想事情就是這樣的。身體健康是一切的先決條件。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

當我們在搬家後筋疲力盡時，信長大人叫我。
[cpg]

我擔心我可能會和她說話，在這種失勢的情況下說些無禮的話，但我還是走了過去。
[cpg]



;//========================================
;//●ＣＧ（紹介ページヒロイン１のＣＧ）ev_91
;//人物１：ヒロイン１　服装１：着衣
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//備考　：可能であれば背景を足してください
;//========================================


[free time=1000]
;**【ＣＧ】 ev_91_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Nobunaga066"]
[OnName num="nobunaga"]
'你已經回來了，很好。你在某種程度上為我著想'。
[cpg cn=true]


信長大人似乎很欣賞我沒有和信玄大人調情的事實。
[cpg]

[OnName num="keitarou"]
'......，這是.......
[cpg cn=true]


我不能說這是因為我害怕你。
[cpg]

[OnName num="keitarou"]
'無論如何，都很難走。 '在我的時代，就不會有這麼多的步行。
[cpg cn=true]



[VOICE f="Nobunaga067"]
[OnName num="nobunaga"]
'我想我也應該體驗一下這個時期的交通手段等等。
[cpg cn=true]



[VOICE f="Nobunaga068"]
[OnName num="nobunaga"]
'也許在未來，馬匹會更加發達。在未來，馬匹可能會更加發達，而且可能會有更多的馬匹。
[cpg cn=true]


在這個時代，馬匹是非常有價值的。它們不能被輕易使用。
[cpg]

除此之外，信長大人還看到，在未來會有更多的運輸工具。
[cpg]

當然，這不是馬，而是...... 汽車，我不認為他會得到這個消息。
[cpg]


[VOICE f="sNobunaga001"]
[OnName num="nobunaga"]
'順便說一句，你不喝酒？
[cpg cn=true]


[OnName num="keitarou"]
'...... 不太擅長。
[cpg cn=true]


我明白了，"信長大人說，看起來有點悲傷。
[cpg]

她可能是個相當愛喝酒的人，不知為何，這很適合她。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我又睡了一會兒，疲憊不堪。
[cpg]

我沒有時間再去想什麼，也沒有時間去做夢。
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

然後第二天早上，我比往常更晚醒來。
[cpg]

我的肌肉又疼了。如果這些日子繼續下去，我總有一天會受傷。 ......
[cpg]


[window target=false]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

但這並不意味著我有什麼特別的工作要做。
[cpg]

我有足夠的時間來考慮這個和那個。
[cpg]

我怎樣才能回到我的世界？
[cpg]

如果屏幕是觸發器，在這個世界上是否有對應的東西？
[cpg]

在我這樣想的時候，我遇到了另一個女孩。
[cpg]

她正在照看她的盆景。她一看到我，就轉過身來，深深地鞠了一躬。
[cpg]


;//光秀の名前を「少女」と隠してください

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mituhide001"]
[OnName num="girl"]
'很高興見到你。我聽說過很多關於你的事情。你當然有一種神秘的氣氛。
[cpg cn=true]


[OnName num="keitarou"]
'...... 很高興見到你。我的名字是須藤景太郎。
[cpg cn=true]



;//ここから光秀の名前を隠さないでください

[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide002"]
[OnName num="mitsuhide"]
我的名字是明智光秀。我也為信長大人服務。 "
[cpg cn=true]


光秀明智......，她也是一名軍事指揮官。
[cpg]

一個應該背叛信長大人的人。
[cpg]

但是，像光秀這樣優秀的將軍仍然應該有自己的城堡，不是嗎？
[cpg]

[OnName num="keitarou"]
......為什麼，在這樣的地方？
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
我想知道 "為什麼在這裡 "這句話是否足以傳達這個信息。光秀大人正茫然地盯著。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide003"]
[OnName num="mitsuhide"]
'信長大人喜歡盆景。我被召集到這裡是為了談論盆景。
[cpg cn=true]


[OnName num="keitarou"]
Heh. ......
[cpg cn=true]


這多少有些令人驚訝。信長大人會對這樣的事情感興趣。
[cpg]

[OnName num="keitarou"]
我明白了。這聽起來不像是信長大人。 "
[cpg cn=true]


我想知道，說這樣的話是否有點不禮貌。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide004"]
[OnName num="mitsuhide"]
是這樣的嗎？　正是因為我們生活在這樣一個時代，我認為與生物接觸很重要。
[cpg cn=true]


光秀大人說，盆景是一種生物。
[cpg]

這就是即使在這個時代也存在的那種思維。自然如此。 ......
[cpg]

相反，正因為是戰國時期，我們才可能感受到植物中的生物性。
[cpg]

在現代，即使是觀賞性植物也是人工的。
[cpg]

[OnName num="keitarou"]
'......，可能是這樣的。
[cpg cn=true]


說話的同時，我想了想。如果有一天這個人殺了信長，他會告訴信長嗎？
[cpg]

但如果我這樣做，我就會改變未來。我不知道會發生什麼。
[cpg]


[free time=1]
[WAIT time=1]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Ranmaru051"]
[OnName num="ranmaru"]
'啊，光秀...... 在這裡？
[cpg cn=true]


當我在想這個問題的時候，蘭丸大人來到我身邊。
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="Mituhide005"]
[OnName num="mitsuhide"]
'這是什麼？　蘭丸，你想從我這裡得到什麼？
[cpg cn=true]


蘭丸大人和光秀大人互相呼喚。
[cpg]

在這個時代的等級制度方面，情況如何？
[cpg]

難道說，這兩個人都不佔優勢嗎？首先，他們的立場是完全不同的。
[cpg]

[FACE method="shake_7" pos="4/5"]

[VOICE f="Ranmaru052"]
[OnName num="ranmaru"]
兩者在這個時代的地位是不一樣的。信長大人要見你，你覺得你來城堡是為了什麼？
[cpg cn=true]


蘭丸大人的話中帶著刺。不知為何，我可以猜到他們三人之間的關係。
[cpg]

光秀大人和蘭丸大人都為信長大人服務。
[cpg]

除此之外，蘭丸喜歡信長大人，所以也許他把光秀大人視為對手。
[cpg]

如果是這樣的話，他們互相呼喚是有道理的。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide006"]
[OnName num="mitsuhide"]
'我明白。然後，讓我們再次見面。景太郎先生。
[cpg cn=true]


[OnName num="keitarou"]
是的，是的。
[cpg cn=true]


你叫我 "先生"，而蘭丸大人叫我 "先生"。我當時有點緊張。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

在我無所事事的時候，戰國的世界正在急劇變化。
[cpg]

我聽說一個叫斎藤道三的人已經死了。
[cpg]

我知道他是一個軍事指揮官，但我並不清楚他與信長大人有什麼樣的關係。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Nobunaga069"]
[OnName num="nobunaga"]
'我明白了。這樣的意願，.......'
[cpg cn=true]


我第一次看到他時，覺得太快了，但事情發展得太快了。
[cpg]

我仍然認為這與我知道的歷史不同。
[cpg]

[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru053"]
[OnName num="ranmaru"]
我們應該如何處理......？信長大人。 "
[cpg cn=true]


據說，他留下了一份遺囑，說他將把美濃國交給信長大人。
[cpg]

死因沒有具體提及，但可能不是死於疾病。
[cpg]

如果他在戰鬥中死亡......，我不知道信長大人是否知道自己的死亡。
[cpg]

[FACE method="shake_7" pos="2/5"]

[VOICE f="Nobunaga070"]
[OnName num="nobunaga"]
'至於我，是以失去支持的形式。現在我們該怎麼做？ "
[cpg cn=true]


光秀大人和蘭丸大人都顯得很緊張。
[cpg]

在這一生中，我從未經歷過如此緊張的情況。
[cpg]

這並不奇怪,......，涉及生命和死亡的問題在現代世界並不存在。
[cpg]

[FACE method="bow_3" pos="2/5"]

[VOICE f="Nobunaga071"]
[OnName num="nobunaga"]
'看來柴田勝家也出現了一些令人不安的動作。我們要不要從這裡出擊？ "
[cpg cn=true]


我不知道這個柴田勝己是誰。
[cpg]

我瞥了一眼蘭丸大人，但她仍然沉默不語。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru054"]
[OnName num="ranmaru"]
事情變得有點棘手了。但現在看起來已經沒有回頭路了。
[cpg cn=true]


當我和蘭丸大人走在走廊上時，她正在談論這個問題。
[cpg]

[OnName num="keitarou"]
'戰爭，是嗎？
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Ranmaru055"]
[OnName num="ranmaru"]
'百分之九十九的時間都會如此。我也要離開了'。
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


我無法想像那是什麼樣子的。信長大人和蘭丸大人正在帶兵。
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

我回到我指定的房間，思索著。
[cpg]

柴田胜江。我從這個名字中追尋我朦朧的記憶。
[cpg]

伊瑙這個名字也來自信長大人的故事。是否有一場名為伊瑙之戰的戰鬥？
[cpg]

不。 ......，事實上，我甚至不需要好好回憶。信長大人不應該經歷失敗。
[cpg]

或者他至少可能已經從戰場上逃走了。
[cpg]

無論如何，他在接管國家之前並沒有死。我知道這麼多。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夕方）******************************************************

我無法站穩腳跟，所以我走出了城堡，待了一會兒。
[cpg]

也許是看到了我，光秀大人來找我了。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Mituhide007"]
[OnName num="mitsuhide"]
我不知道你有什麼問題，景太郎先生。你看起來很蒼白。
[cpg cn=true]


[OnName num="keitarou"]
哦，那是.......
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide008"]
[OnName num="mitsuhide"]
...... 不，這是沒辦法的事。 ....... 這意味著你也可能在戰場上"。
[cpg cn=true]


我不這麼認為。信長大人還說，他要讓我當軍事指揮官。
[cpg]

[OnName num="keitarou"]
'別擔心。我不期望你只是讓我活著，而不做任何事情'。
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Mituhide009"]
[OnName num="mitsuhide"]
'我認為牢記這一點很重要，但請不要過度。
[cpg cn=true]


光秀山說，並顯得很擔心。
[cpg]

我應該...... 做什麼？
[cpg]

如果信長大人讓你出去打仗，我會去......？
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

那天晚上。信長大人叫我，我正在去她房間的路上。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga072"]
[OnName num="nobunaga"]
'你也會出征戰場嗎？　你可以揮舞著劍，不是嗎？
[cpg cn=true]


她說出了我所擔心的事情。
[cpg]

我在這裡如何回答是很重要的。光秀大人曾說，沒有必要把自己逼得太緊。
[cpg]

但我也想滿足信長大人的期望。 ......
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga073"]
[OnName num="nobunaga"]
'你不需要馬上回答。如果你不想殺人，那也沒關係。 "
[cpg cn=true]


經過一些猶豫，我給出了我的答案。
[cpg]

[OnName num="keitarou"]
'......，我也要出去。我現在有免費的飯吃了。 "
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga074"]
[OnName num="nobunaga"]
你很勇敢，這很好。我就指望你了。 "
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

那天我無法入睡，因為我的眼睛很模糊。
[cpg]

但我下定決心。我不打算再跑了。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru056"]
[OnName num="ranmaru"]
"嘿，景太郎。我聽說你要參加井岡山之戰？
[cpg cn=true]


[OnName num="keitarou"]
是的。 ......，那麼...
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru057"]
[OnName num="ranmaru"]
多麼不可靠的答案。
[cpg cn=true]


我不太確定，但我問蘭丸大人她有什麼要說的。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru058"]
[OnName num="ranmaru"]
信長大人要讓你成為軍事指揮官。這意味著他將把一定數量的部隊交給你。
[cpg cn=true]


[OnName num="keitarou"]
'......，我將負責人們的生活？
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Ranmaru059"]
[OnName num="ranmaru"]
當然了。我知道，光秀也知道。 "
[cpg cn=true]


...... 是這樣的，不是嗎？我們的生活中，有很多人都在為自己的生活而奔波，有很多人都在為自己的生活而奔波，有很多人都在為自己的生活而奔波，有很多人都在為自己的生活而奔波。
[cpg]

如果我做不到呢？
[cpg]


[free time=1]
[WAIT time=1]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="4/5" time=800]

[VOICE f="Mituhide010"]
[OnName num="mitsuhide"]
'這是什麼？　你們兩個人在進行私人談話嗎？
[cpg cn=true]


然後，光秀大人來了。我想到的是，你們兩個人的關係並不簡單。
[cpg]

[FACE method="shake_7" pos="4/5"]

[VOICE f="Ranmaru060"]
[OnName num="ranmaru"]
'你，......，這就對了。教導景太郎了解孫子兵法。
[cpg cn=true]


[FACE method="change_7" pos="2/5"]

[VOICE f="Mituhide011"]
[OnName num="mitsuhide"]
'在這種情況下，我認為蘭丸比我更適合這個角色。 ......，但這很好。
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

然後，光秀大人和蘭丸大人教我基本的戰場戰術。
[cpg]

基本戰略是由信長大人制定的。我只需要遵循它。 ......
[cpg]

我想知道這樣的事情是否可以。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

然後，在戰爭開始的前一天晚上。我很焦慮，無法入睡。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga075"]
[OnName num="nobunaga"]
...... 景太郎。
[cpg cn=true]


[OnName num="keitarou"]
什麼？　信長大人......？ "
[cpg cn=true]


信長大人在我的房間裡看望我。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga076"]
[OnName num="nobunaga"]
'你睡不著，是嗎？
[cpg cn=true]


[OnName num="keitarou"]
'是的，好吧，......，我以前從未發生過這樣的事情。
[cpg cn=true]


我半坐起來，說。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga077"]
[OnName num="nobunaga"]
'我在戰鬥前也睡不著。無論我做多少次，這都是我從未習慣的事情。
[cpg cn=true]


[OnName num="keitarou"]
'像信長大人這樣的人也是這樣嗎？
[cpg cn=true]


我說，信長大人微微皺起了眉頭。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga078"]
[OnName num="nobunaga"]
他說："我不知道你是誰，但我知道你是誰。"他說："我不知道你是誰，但我知道你是誰。"他說："我不知道你是誰，但我知道你是誰。你認為我是一個無意識的怪物嗎？
[cpg cn=true]


聽到......，這倒是讓人有些放心。信長大人是這麼說的。
[cpg]

這就是他們對我們的重視程度。
[cpg]

[OnName num="keitarou"]
'......'
[cpg cn=true]


儘管如此，我們兩個人之間仍然存在著一種奇怪的沉默氣氛。
[cpg]


[FACE method="change_2" pos="2/3"]
信長大人正轉向我並微笑著。
[cpg]

[OnName num="keitarou"]
'那麼，那張臉......，是什麼意思？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
沒什麼，信長大人說。她的笑容有點性感。
[cpg]

我想知道他們是否對我有任何感情。
[cpg]

那是一張讓我覺得的臉。 ......。
[cpg]

[OnName num="keitarou"]
'如果沒什麼，那就好了。
[cpg cn=true]


但我也忍不住這麼想。我想和信長大人發生什麼？
[cpg]

我為什麼說我要去打仗？我覺得有些深層的心理學在我沒有意識到的地方起作用了。
[cpg]

信長大人是一個如此迷人的人，我是這樣想的。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

然後我們離開了城堡。每個人都統一穿著厚重的盔甲。
[cpg]

他們的臉是不同的。我想，一場戰鬥真的要開始了。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga079"]
[OnName num="nobunaga"]
'我們走吧。
[cpg cn=true]


信長大人看起來很平靜，很鎮定。據她說，這應該是我們不習慣的事情。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


在信長大人的帶領下，我們出發了。
[cpg]

我們要對抗的對手是柴田勝家。我甚至不知道這個軍閥的名字。
[cpg]

但我們要摧毀他。即使我不親手做，我也會成為其中的一員。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（昼）******************************************************

而......，戰爭即將開始。
[cpg]

據說，這場戰鬥也是一場家族頭銜的爭奪戰。
[cpg]

我以為他的姓氏是不同的......，但似乎他不是為總督而戰的人。
[cpg]

很可能是一個叫柴田勝家的人引誘他參與總督府的鬥爭。
[cpg]

如果他不這樣做，他就會更公開地反叛，或者在任何情況下......。
[cpg]

對於信長大人來說，他是一個敵人。他已經成為一個必須被消滅的對手。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Nobunaga080"]
[OnName num="nobunaga"]
'活著回來。景太郎'。
[cpg cn=true]


這一個詞就意味著他可能會死。
[cpg]

[OnName num="keitarou"]
'...... 當然了。
[cpg cn=true]


[free time=1000]

我回答說，並與信長大人暫時分開了。
[cpg]

他們事先被告知將有什麼樣的陣容。
[cpg]

我所要做的很簡單。正如她所說，要活著回來。
[cpg]

當然，我不能不參加戰鬥。即便如此，我還有第二個角色要扮演。
[cpg]

光秀大人和蘭丸大人都告訴我，我的首要任務是保護自己的生命。
[cpg]



;//※後のルート分岐に影響
;//　勝利した場合、ヒロイン１ルートへの可能性が残る
;//　敗北した場合、ヒロイン５ルートへの可能性が残る


;//稲生の戦い　マップシステム開始
;//伏兵マスは２、３、７です

;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※稲生の戦い　開始時（１のマスにいる場合のシナリオ）※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

蘭丸大人似乎非常緊張。她甚至說，這不是我該做的。
[cpg]

她說，如果我想保住性命，就應該留在城堡裡，但這是因為她關心我，不是嗎？
[cpg]

如果我聽從蘭丸大人的話，我可能不必在這場戰鬥中戰鬥到最後。
[cpg]

當然，我不能死，所以這將意味著退縮。 ......
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（昼）******************************************************

而戰鬥已經開始。不是我要帶路，而是我不知道伏擊者在哪裡。
[cpg]

南面的道路是開放的，但東面的道路則被植被所覆蓋。
[cpg]

我應該走哪條路？　無論我離未來有多遠，我都不知道那麼多。
[cpg]

信長大人也在這個戰場上。如果我做出錯誤的決定，我也會讓信長大人的生命陷入危險。
[cpg]

不過，我從光秀大人和蘭丸大人那裡學到了一定的軍事戰術。
[cpg]

我不能把一切都交給她。她在某些方面考驗我，而我必須做出一些決定。
[cpg]


;//■選択肢
[switch]
[case "向南前進。"]
	[swap]
	[jump target="*select02_4"]
[case "繼續向東走。"]
	[swap]
	[jump target="*select02_2"]
[endswitch]

1，向南走。
[cpg]

二，向東前進。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「４のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「２のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※２のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_2|對信長大人的忠誠。


[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

我帶領軍隊，但我有一種不好的感覺。
[cpg]

這就是為什麼我要求信長大人留下來。當我繼續前進的時候，我說：......
[cpg]

[OnName num="keitarou"]
'該死的......，我知道你還在這裡。
[cpg cn=true]


埋伏的士兵在潛伏著。我不是第一個站在他們面前的人，但......
[cpg]

士兵們正在受傷。儘管我沒有排在隊伍的最前面，但這是我不忍直視的一幕。
[cpg]

我應該準備好因我而流的血。
[cpg]

然後，經過一番拼殺，伏擊的士兵又向東移動。
[cpg]


;//■選択肢
[switch]
[case "向南行進。"]
	[swap]
	[jump target="*select02_5"]
[case "向東行進。"]
	[swap]
	[jump target="*select02_3"]
[endswitch]

1，向南行進。
[cpg]

2，向東推進。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「３のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※３のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_3|對信長大人的忠誠。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

我帶領我的部隊走向他們，追擊伏擊者。
[cpg]

但有更多的伏擊部隊潛伏在那裡。
[cpg]


;//敗北判定となる
;//「稲生の戦い　二度伏兵のマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン５ルートへの可能性が残る


[jump target="*select02_lose"]


;//※※※※※※※※※※※※※※※※※※※※
;//※※※４のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_4

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

當我們繼續行進時，我們發現南方現在是一座山。
[cpg]

如果我們按順序走，我們應該向東推進，但我們不知道會發生什麼。
[cpg]

我們想盡可能不受訓練地到達敵人的大本營，但該怎麼做呢？
[cpg]


;//■選択肢
[switch]
[case "向南前進。"]
	[swap]
	[jump target="*select02_7"]
[case "繼續向東走"]
	[swap]
	[jump target="*select02_5"]
[endswitch]

1，向南前進。
[cpg]

2，繼續向東走
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「７のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※５のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_5|對信長大人的忠誠

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン１の立ち絵を表示してください

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]


當我們向前行進時，信長大人跟著我們。
[cpg]

她不能往前走。相反，我們必須保護她。
[cpg]

[OnName num="keitarou"]
'我將帶頭。這很好'。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga009"]
[OnName num="nobunaga"]
'這很好。別猶豫了。
[cpg cn=true]

看到我的判斷，信長大人點了點頭。不知道到目前為止我是否站得住腳。
[cpg]

而且漸漸地，敵人的防線越來越近。視野是相當開闊的。
[cpg]

除非我把這裡的將軍幹掉，否則就不是我所知道的歷史了。
[cpg]

無論我做不做，我都必須贏得這場戰鬥。
[cpg]


;//■選択肢
[switch]
[case "向南前進。"]
	[swap]
	[jump target="*select02_8"]
[case "向東走。"]
	[swap]
	[jump target="*select02_6"]
[endswitch]

一，向南前進。
[cpg]

二，向東推進。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※６のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_6|對信長大人的忠誠

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

在我們行進的過程中，光秀大人也加入了我們。
[cpg]

[OnName num="keitarou"]
'我不相信你會參加這場戰鬥。儘管有蘭丸大人，......"
[cpg cn=true]


據我所知，光秀大人沒有參加這場戰鬥。
[cpg]

當我提到這一點時，光秀-大人說。
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mituhide016"]
[OnName num="mitsuhide"]
我明白了。我是不是不夠？ "
[cpg cn=true]

我被誤解了。他似乎認為我被比作蘭丸大人。
[cpg]

[OnName num="keitarou"]
'不，我不是這個意思 .......
[cpg cn=true]


敵人的營地就在眼前。我無法使自己平靜下來。
[cpg]

在一個生死攸關的地方，要保持冷靜是很難的。
[cpg]

但我已經決定了要走的方向。我決定做好準備。
[cpg]


;//■選択肢
[switch]
[case "我要去南方了。"]
	[swap]
	[jump target="*select02_9"]
[endswitch]

1，繼續向南走。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※７のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_7|對信長大人的忠誠。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

我帶領我的部隊，但我有一種不好的感覺。
[cpg]

這就是為什麼我要求信長大人留下來。當我繼續前進時，我看到......
[cpg]

[OnName num="keitarou"]
'該死的......，我知道你還在這裡。
[cpg cn=true]


埋伏的士兵在潛伏著。我不是第一個站在他們面前的人，但......
[cpg]

士兵們正在受傷。儘管我沒有排在隊伍的最前面，但這是我不忍直視的一幕。
[cpg]

我應該準備好因我而流的血。
[cpg]

[OnName num="keitarou"]
'......，不知何故，你設法堅持了下來，......'
[cpg cn=true]


然後，經過一場比武，我把埋伏的士兵一個個打敗了。
[cpg]


;//■選択肢
[switch]
[case "向東行進"]
	[swap]
	[jump target="*select02_8"]
[endswitch]

1、向東推進。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※８のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_8|對信長大人的忠誠

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン５の立ち絵を表示してください

當我們繼續前進時，我們遇到了蘭丸大師。
[cpg]

她看起來很安全，但她的臉與平時不同。
[cpg]

;//蘭丸「こっちだ。ついてきな」
敵人的營地就在那裡。我無法讓自己平靜下來。
[cpg]

在一個生死攸關的地方，不可能保持冷靜。
[cpg]

但我已經決定了要走的方向。我很堅定。
[cpg]


;//■選択肢
[switch]
[case "我要去東部。"]
	[swap]
	[jump target="*select02_9"]
[endswitch]

1，我向東推進。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※９のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_9|對信長大人的忠誠。

[jump target="*select02_win"]


;//マップシステム終了。下記のシナリオへ進む

;//==============================
;//稲生の戦い　９のマスに到達した場合


*select02_win|對信長大人的忠誠。

[stflag Selectflg2=1]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（夕方）******************************************************

[SE f=se019]
;//【ＳＥ】『刀　打ち合う』

在兵力上有明顯的差別。另一方的人數幾乎是另一方的兩倍。
[cpg]

即便如此，這也是戰略的意義所在。
[cpg]

這不是一個戰場，一個人與一個人的衝突，他們肯定會互相消磨。
[cpg]

我只是按照吩咐推進我的部隊，但信長的軍隊仍然獲勝。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

我想這意味著我也有軍功。
[cpg]

那是一種感覺不真實的東西。我甚至不知道它是否真的發生了。
[cpg]

我是無私的。即使我自己不揮舞劍，也會有士兵在我的命令下受傷。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Nobunaga081"]
[OnName num="nobunaga"]
'你做得很好。繼續做好工作，成為一個更強大的人'。
[cpg cn=true]


[OnName num="keitarou"]
......，我什麼都沒做。
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga082"]
[OnName num="nobunaga"]
不要謙虛。我說的是實話。
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

無論他得到多少讚美，他都沒有心情去聽。
[cpg]

如果有的話，我的心比戰前更不安了。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我殺了一個人，甚至有可能傷害了一個盟友。
[cpg]

我必須在這種情況下保持冷靜嗎？
[cpg]

信長大人、光秀大人和蘭丸大人一定有類似的經歷。
[cpg]

或者說，......，他們應該比我更有責任感。
[cpg]

我睡不著。我已經很久沒有睡覺了，今天又睡不著了。
[cpg]

當我處於這樣的精神狀態時，有人來探望我。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga083"]
[OnName num="nobunaga"]
'景太郎。你在睡覺嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
'...... 不'。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga084"]
[OnName num="nobunaga"]
'你打得非常好。我以為你可能會跑掉。
[cpg cn=true]


[OnName num="keitarou"]
'我沒有做任何值得表揚的事情。牽涉到另一個人的生死，......，仍然讓我心驚膽戰。 "
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga085"]
[OnName num="nobunaga"]
'未來將比現在更和平。從這樣的時代走來，能夠馬上戰鬥，這是一種天賦。 "
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
 信長大人走近燒傷處，撫摸著我的頭髮。
[cpg]

[OnName num="keitarou"]
'信長大人，......，你在做什麼......？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga086"]
[OnName num="nobunaga"]
'我也不太了解自己。但現在我終於明白，在我心中沒有解決的問題。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga087"]
[OnName num="nobunaga"]
現在我知道你是一個能勇敢戰鬥的人，我明白了我的感受。 "
[cpg cn=true]


信長大人是非常牽強的。但......
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（寝ている主人公に近づくヒロイン。キスをする）ev_47
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_47_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]



我可以從她的行動中看出。她在想什麼？她把她的臉靠近我。
[cpg]

[OnName num="keitarou"]
'不!　'你一定是信長大人。
[cpg cn=true]



[VOICE f="Nobunaga088"]
[OnName num="nobunaga"]
'就當是一種禮節吧。不要想太多了'。
[cpg cn=true]


信長大人一邊說一邊把她的嘴唇送到我面前。
[cpg]


;**【ＣＧ】 ev_47_a ***********************
[CG id=1 index=1 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sNobunaga002"]
[OnName num="nobunaga"]
'吸'。
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


在我的生活中，我第一次說不出話來。或者說，如果我說了什麼就不好嗎？
[cpg]

[OnName num="keitarou"]
'...... 可以了嗎？信長大人，做這個。 "
[cpg cn=true]


;**【ＣＧ】 ev_47_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNobunaga003"]
[OnName num="nobunaga"]
'我不會對任何人這樣做。我對愛情不感興趣，但我對愛情的興趣不......。
[cpg cn=true]


[OnName num="keitarou"]
我明白了。
[cpg cn=true]



[VOICE f="sNobunaga004"]
[OnName num="nobunaga"]
我想，我被你吸引了。我自己也想知道。
[cpg cn=true]


是信長大人，他已經在說一些幾乎像懺悔的話了。
[cpg]


[VOICE f="Nobunaga110"]
[OnName num="nobunaga"]
生活在這個時代的人，很少有人能在戰場上指揮。
[cpg cn=true]



[VOICE f="Nobunaga111"]
[OnName num="nobunaga"]
'此外，他一定是從未來來的。他一定是生活在一個和平的時代'。
[cpg cn=true]


[OnName num="keitarou"]
'...... 那是真的。
[cpg cn=true]



[VOICE f="Nobunaga112"]
[OnName num="nobunaga"]
'我依靠你，我知道我可以依靠你。你取得了再多的勇敢也無法做到的成就'。
[cpg cn=true]


這真是浪費口舌。我甚至覺得很尷尬。
[cpg]


;//ブラックアウト

;//移植前シーンカット

[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************


[VOICE f="sNobunaga005"]
[OnName num="nobunaga"]
'我想知道這種感覺是什麼。我是最糊塗的人'。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="sNobunaga006"]
[OnName num="nobunaga"]
'我希望......，和你生個孩子，你知道的。
[cpg cn=true]


信長大人很有魄力。我有些不解。
[cpg]

[OnName num="keitarou"]
你為什麼要對我如此費盡心思，......？
[cpg cn=true]


不，不是那樣。不是這樣的。有件事你需要更加小心。
[cpg]

[OnName num="keitarou"]
如果你現在懷上了孩子，這將是一件大事。 "
[cpg cn=true]


信長大人聽到這句話，表情變得陰沉。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga140"]
[OnName num="nobunaga"]
'......，是的，沒錯。如果你是一個男人，你可以有多少個孩子，但我是一個女人。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga141"]
[OnName num="nobunaga"]
'如果我帶著孩子，我將無法站在戰場上。但我不能讓血流盡。
[cpg cn=true]


信長大人似乎很不耐煩。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga142"]
[OnName num="nobunaga"]
'只是，我沒有接近你，因為我不想斷絕你的血脈。
[cpg cn=true]


這一定是他的真實意圖。考慮到這一點，我繼續傾聽。
[cpg]

我可以想像，信長大人可能是個天生的苦行僧。
[cpg]

我想他只是喜歡我。
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

;//移植前シーンカット

畢竟，我們當時沒有什麼可做的了。
[cpg]

[OnName num="keitarou"]
'你應該再考慮一下。你知道，關於它是否真的是我。
[cpg cn=true]



[VOICE f="Nobunaga167"]
[OnName num="nobunaga"]
'......，無論我想多少次，我都有同樣的感覺，但如果你這麼說，我不會強迫你。
[cpg cn=true]


信長大人似乎覺得自己被迂迴地拒絕了，顯得很傷心。
[cpg]

[jump target="*jump_select02_end"]


;//==============================
;//稲生の戦い　二度伏兵のマスを通った場合

*select02_lose|對信長大人的忠誠

[stflag Selectflg2=0]


我領導的部隊已經筋疲力盡。
[cpg]

當然，這並不是說我們人多勢眾。這不是一場我們無法贏得的戰鬥。
[cpg]

但我不知道如果我不這樣做，我自己是否能達到將軍的要求。
[cpg]

[OnName num="keitarou"]
'該死的......，我不得不撤退了。
[cpg cn=true]


我把自己的生命放在第一位，看著當時的情況，決定退縮。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Mituhide012"]
[OnName num="mitsuhide"]
'我聽說了。景太郎先生出乎意料地膽小'。
[cpg cn=true]


[OnName num="keitarou"]
'......，說你喜歡的。
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide013"]
[OnName num="mitsuhide"]
'我不認為有什麼，但信長大人會因此而恨你。
[cpg cn=true]


就在我們談論這些的時候，信長大人來了。
[cpg]


[free time=800]
[WAIT time=800]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="4/5" time=800]


[VOICE f="Nobunaga169"]
[OnName num="nobunaga"]
'景太郎不是一個懦夫。有幾種情況。
[cpg cn=true]


[OnName num="keitarou"]
信長大人
[cpg cn=true]


信長大人甚至對我進行了跟踪。
[cpg]

 有一個環境的事實意味著它來自另一個時代。
[cpg]

我真的覺得自己無法忍受。我不知道是否會有那麼一天，我也能打敗敵人的將軍。
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]


最後，是信長大人贏得了井岡山之戰。
[cpg]

我不在那裡。但我不用問也知道。
[cpg]

她不可能會輸。因為我有這種信念，所以我能夠退縮。 ......。
[cpg]

在這場戰鬥中取得最大成功的是蘭姆魯大人。
[cpg]

她似乎心情很好，被信長大人所愛慕。
[cpg]


[jump target="*jump_select02_end"]




*jump_select02_end|奧克哈紮馬之戰
[jump storage="ep002.ks" target="*start"]

