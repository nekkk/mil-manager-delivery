
*start

;//==============================
;//稲生の戦いで勝利していた場合

*root_1|天堂下的織田信長

;#################################################
*Ep003|天下的織田信長。
;#################################################

[SCENE id=3]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru091"]
[OnName num="ranmaru"]
'不，這算什麼。這種沉默'。
[cpg cn=true]


蘭丸大人首先打破了沉默。一種微妙的尷尬氣氛在我們之間流動。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru092"]
[OnName num="ranmaru"]
'總之!　我將不惜一切代價支持信長大人'。
[cpg cn=true]


蘭丸大人看著遠方說。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru093"]
[OnName num="ranmaru"]
但我想說的是，你可以做的不僅僅是支持他們。
[cpg cn=true]


[OnName num="keitarou"]
你是什麼意思？ "
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru094"]
[OnName num="ranmaru"]
'我是說，你也可以成為信長大人的丈夫。這就是他喜歡你的程度。
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru095"]
[OnName num="ranmaru"]
真的，請。你是唯一的一個。我只是自己做不到。 "
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

那天晚上，信長大人給我打電話。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga267"]
[OnName num="nobunaga"]
你已經習慣於住在城堡裡了，不是嗎？
[cpg cn=true]


[OnName num="keitarou"]
是的，好吧，......，我能為你做什麼？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga268"]
[OnName num="nobunaga"]
我能為你做什麼？我只是想確認一下。
[cpg cn=true]


它是什麼？　它是什麼？
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru096"]
[OnName num="ranmaru"]
'......，我還想確定一件事。景太郎和信長大人是......，......."
[cpg cn=true]


不僅是信長大人，蘭丸大人和光秀大人也在那裡。
[cpg]

[FACE method="shake_7" pos="2/5"]

[VOICE f="Mituhide027"]
[OnName num="mitsuhide"]
他說："我不知道，我不知道。"他說："我不知道。"他說："我不知道。"他說："我不知道。蘭丸。
[cpg cn=true]


[FACE method="shock_3" pos="4/5"]

[VOICE f="Ranmaru097"]
[OnName num="ranmaru"]
但......，我對它很好奇。
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Mituhide028"]
[OnName num="mitsuhide"]
'景太郎先生不屬於任何人。不是嗎？ "
[cpg cn=true]


說這話的時候，光秀大人就是光秀大人，我覺得他想獨占我。
[cpg]

 蘭丸大人對我想不出什麼辦法。
[cpg]

這就像一個后宮的情況。從幕後來看，這可能是他在控制整個國家。 ......
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Nobunaga269"]
[OnName num="nobunaga"]
'呼'。
[cpg cn=true]


信長大人隨後做了一些非常不重要的小談話。
[cpg]

她想確保，我猜，我被所有人喜歡。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_04"]


;//【ＢＧ】『城＿室内』（夜）******************************************************

然後我回到了我的房間。我想到了與信長大人的未來。
[cpg]

蘭丸大人認可我。這就是為什麼我不需要猶豫了。
[cpg]

自從蘭丸大人告訴我之後，我就意識到了成為信長大人丈夫的夢想。
[cpg]

然而，信長大人最終會在本能寺事件中死去。
[cpg]

我必須不惜一切代價避免這種情況。我想和信長大人一起生活。
[cpg]

無眠之夜。我的房間被......
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga270"]
[OnName num="nobunaga"]
'景太郎。你已經睡著了嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
...... 號。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga271"]
[OnName num="nobunaga"]
'哦，是的。從那時起，我一直在思考你的意思......。
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Nobunaga272"]
[OnName num="nobunaga"]
在我身上發生了一些事情，不是嗎？
[cpg cn=true]


信長大人說到了問題的核心。
[cpg]


;//ブラックアウト

;//移植前シーンカット

;//========================================
;//●ＣＧ（主人公に迫るヒロイン。主人公の体に触れている）ev_01
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//備考　：ヒロイン１の部屋は城内の一室です
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]



她接近我。我想到的第一件事是，我不是一個好的人。
[cpg]


[VOICE f="sNobunaga013"]
[OnName num="nobunaga"]
景太郎的身體仍然很有肌肉。我再次被提醒，他是一個男人。
[cpg cn=true]


[OnName num="keitarou"]
信長大人 ......
[cpg cn=true]



[VOICE f="sNobunaga014"]
[OnName num="nobunaga"]
繼續聽。
[cpg cn=true]



[VOICE f="Nobunaga273"]
[OnName num="nobunaga"]
你不需要馬上回答。你可能也迷路了'。
[cpg cn=true]


信長大人似乎理解我對改變未來的恐懼。
[cpg]

我現在所處的時代可能會消失。我再也不能回家了。
[cpg]


;**【ＣＧ】 ev_01_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNobunaga015"]
[OnName num="nobunaga"]
'但我希望你能幫我這個忙。景太郎, ......
[cpg cn=true]



[VOICE f="sNobunaga016"]
[OnName num="nobunaga"]
我想和你生個孩子。
[cpg cn=true]


[OnName num="keitarou"]
...... 信長大人
[cpg cn=true]


信長大人似乎深愛著我。
[cpg]


;//移植前シーンカット

;//ブラックアウト

[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************


[VOICE f="Nobunaga323"]
[OnName num="nobunaga"]
'......，我不想讓任何人看到我這樣在這裡。
[cpg cn=true]


[OnName num="keitarou"]
'這就對了，.......
[cpg cn=true]


我從來沒有這麼高興過。但這種幸福有一天會失去。
[cpg]

我想我別無選擇，只能採取行動。她終於要告訴我一切了。
[cpg]

她將在本能寺事件中死去。我要防止這種情況，我說。
[cpg]

也許未來會被扭曲。知道如果我這樣做，我不知道會有什麼反作用。
[cpg]

[STOPBGM]


[OnName num="keitarou"]
'信長大人。我有重要的事情要告訴你。
[cpg cn=true]

[BGM f="bg_04"]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga324"]
[OnName num="nobunaga"]
它是什麼？　是不是你對我隱瞞了很久的事情？
[cpg cn=true]


[OnName num="keitarou"]
'你什麼都知道，不是嗎？這就對了。 "
[cpg cn=true]


我深吸一口氣，讓自己平靜下來。然後我說出了這句話。
[cpg]

[OnName num="keitarou"]
'信長大人。我要告訴光秀大人：.......'。
[cpg cn=true]


此刻我正準備說，'注意光秀大人'。
[cpg]


[transition target={true} rule="moya.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1000]

我的身體逐漸變得透明和半透明。
[cpg]

[FACE method="shock_5" pos="2/3"]

[VOICE f="Nobunaga325"]
[OnName num="nobunaga"]
'什麼！ ？　關於......，那是什麼？
[cpg cn=true]


當我在 "給光秀大人 "這句話之後沒有說什麼，我的身體就恢復了正常。
[cpg]

[OnName num="keitarou"]
'哦，所以這就是你的意思.......'。
[cpg cn=true]


我有一個想法。通過改變未來，你會改變未來發生的事情。
[cpg]

這意味著將有一個我不會出生的未來。
[cpg]

我本應來自那個未來，但我注定要消失。
[cpg]

[OnName num="keitarou"]
......，哈哈。
[cpg cn=true]


顯然，我救不了信長大人。意識到這一點，我開始乾笑。
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga326"]
[OnName num="nobunaga"]
'景太郎，你是什麼意思？解釋一下'。
[cpg cn=true]


[OnName num="keitarou"]
'......'
[cpg cn=true]


我沒有向信長大人解釋，當時只是保持沉默。
[cpg]

我第一次見到他的時候，他有點緊張。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

信長大人隨後回到了他的房間。
[cpg]

早上來了。無論我有多大的麻煩，我都累了，睡著了。
[cpg]

[OnName num="keitarou"]
'...... 上午或......'
[cpg cn=true]


當我醒來的時候，信長大人不在那裡，我感到很焦急。
[cpg]

我們不知道本能寺事件何時會發生。
[cpg]

首先，在我所在的這個世界上，時間比歷史上的事實要快。
[cpg]

下一次我醒來的時候，有可能就再也見不到他了。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru098"]
[OnName num="ranmaru"]
'景太郎。你醒了，你一直在做惡夢。
[cpg cn=true]


[OnName num="keitarou"]
'......蘭丸大人
[cpg cn=true]


看到她讓我感覺更安全一些。
[cpg]

蘭丸大人一定是在本能寺事變中跟隨信長大人。
[cpg]

這意味著，至少在她在這裡的時候是可以的。 ......
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru099"]
[OnName num="ranmaru"]
你看起來很蒼白。你沒有睡好嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
不，我不介意。
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Ranmaru100"]
[OnName num="ranmaru"]
...... 我不介意，但不要在信長大人面前做這種表情。他一定很擔心。
[cpg cn=true]


我不知道我的臉上是否有這種表情。如果是這樣的話，我必須要堅定。
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

我在城堡裡坐不住了，所以我到了外面。
[cpg]

我想可以說，它是和平的。國家正在統一。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_01_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（昼）******************************************************

當我看到城堡小鎮上熙熙攘攘的人群時，我覺得這種平靜似乎會永遠持續下去。
[cpg]

但這是一個錯誤。她永遠不會像這樣統治日本。
[cpg]

我覺得不甘心。我應該怎麼做？
[cpg]


[window target=false]
[BG f="b_01_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************

我想她，信長大人，想要的就是這種和平。
[cpg]

然而，這一定也是鎮民們一直在等待的東西。
[cpg]

為什麼本應貢獻最大的信長大人要遭受這樣的不幸？
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


起初我認為我必須和光秀大人談談，但最後如果我讓她勸阻我，也是一樣的。
[cpg]

我將會消失，我將會結束在一個我不會出生的未來。
[cpg]

這就是以大方式改變歷史的意義。 ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『村』（夜）******************************************************

當我被傳送到這個時間段時，我已經來到了我所在的第一個村莊，因為我有心事。
[cpg]

這個傳說真的是傳說嗎？如果是自發的，連信長大人都知道。
[cpg]

我覺得它已經被人們添加到了。這似乎是被刻意納入的東西。
[cpg]

[OnName num="villager"]
'......，是你，對嗎？已經有一段時間了。
[cpg cn=true]


[OnName num="keitarou"]
你能告訴我更多關於這個傳說嗎？ "
[cpg cn=true]


[OnName num="villager"]
'我不知道你要我告訴你什麼，但傳說就是傳說。我不比你知道的更多。
[cpg cn=true]


[OnName num="keitarou"]
'我對它感到不舒服。感覺不像是傳說。
[cpg cn=true]


[OnName num="villager"]
...... 是的，那是真的。它可能是可疑的。
[cpg cn=true]


村民們沉默了一會兒，然後說。
[cpg]

[OnName num="villager"]
'我只是在想像我將要告訴你的事情。帶著這個想法聽我說。
[cpg cn=true]


[OnName num="villager"]
'從現在開始，在未來很長一段時間內。如果我們能夠操縱時間，......
[cpg cn=true]


[OnName num="villager"]
'也許有這樣一種情況，即壓製過去發生的異常現象。
[cpg cn=true]


[OnName num="keitarou"]
'......，這就是我被傳喚到這裡的原因嗎？
[cpg cn=true]


[OnName num="villager"]
'好吧，聽我說。你如何恢復一個已經不再按照歷史運作的偉人？
[cpg cn=true]


[OnName num="villager"]
對於一個知道一點未來...... 歷史的人來說，可能比來自未來的、知道這一切的人改變它更自然地行動。 "
[cpg cn=true]


我默默地聽著。這個人可能是偽裝成這個時代的人類的未來主義者。
[cpg]

[OnName num="villager"]
'這就像把細胞植入受損的內部器官。你明白嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
我不能改變歷史，是你的意思。
[cpg cn=true]


[OnName num="villager"]
我將把這個問題留給你來決定。這也是我叫你來的部分原因。
[cpg cn=true]



;//ブラックアウト
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

...... 這是個瘋狂的故事。但這並不是一個我不理解的故事。
[cpg]

植入細胞。好吧，完全是人造的東西當然會有出錯的地方。
[cpg]

也許歷史能被連接起來是因為那些對歷史一無所知的人的意願。
[cpg]

如果是這樣的話，......，我應該怎麼做？
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夕方）******************************************************

我正在去她房間的路上，信長大人叫我。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Nobunaga327"]
[OnName num="nobunaga"]
'我有蘭丸的消息。她有些不對勁。 "
[cpg cn=true]


[OnName num="keitarou"]
'......'
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga328"]
[OnName num="nobunaga"]
'有一天，你的身體似乎是透明的。除非我弄錯了。
[cpg cn=true]


[OnName num="keitarou"]
這就是.......
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga329"]
[OnName num="nobunaga"]
如果你不能告訴我一切，你就不必告訴我。但至少現在要做你正常的景太郎。 "
[cpg cn=true]


信長大人似乎知道她正處於危險之中。
[cpg]

我詛咒自己不能救她，但我至少想滿足她的願望，成為正常的我。 ......
[cpg]


;//========================================
;//●ＣＧ（主人公を抱きしめるヒロイン）ev_68
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿ヒロイン１の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_68_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="keitarou"]
'信長大人，......，我愛你。
[cpg cn=true]



[VOICE f="Nobunaga330"]
[OnName num="nobunaga"]
'我知道，但敢於說出來是很尷尬的。
[cpg cn=true]


這段時間不會無限期地持續下去。相反，很快，我們將被分開。
[cpg]

我只是想忘記我的焦慮，只是現在。
[cpg]


[VOICE f="sNobunaga017"]
[OnName num="nobunaga"]
......景太郎。別用那種眼神看我。
[cpg cn=true]


我看起來很悲傷嗎？我看起來很後悔嗎？
[cpg]

剛才我確實想讓信長大人放心。
[cpg]


;//移植前シーンカット
;//ブラックアウト
;//移植前シーンカット
;//ブラックアウト

[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夕方）******************************************************


[VOICE f="Nobunaga377"]
[OnName num="nobunaga"]
...... 嘿。景太郎。
[cpg cn=true]


[OnName num="keitarou"]
它是什麼？　信長大人。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga378"]
[OnName num="nobunaga"]
'我想有一天能擁有你的孩子。當和平的時間到來時。 "
[cpg cn=true]


[OnName num="keitarou"]
'......，是的，沒錯。如果那是真的，那就像一個夢。
[cpg cn=true]


在與信長大人擁抱的時候，我們談論這樣的事情。
[cpg]

但只有我知道，這是一個未完成的願望。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga379"]
[OnName num="nobunaga"]
'我以前從未如此想要一個人。景太郎是第一個'。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga380"]
[OnName num="nobunaga"]
'你能滿足我的願望嗎？　景太郎'。
[cpg cn=true]


我無法回答任何問題。和她生個孩子是可能的，但是。
[cpg]

我可能無法以任何方式與她一起撫養孩子。
[cpg]

而我卻不能大聲說出來。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我不能說任何重要的事情。
[cpg]

但我沒有選擇。沒有其他辦法。
[cpg]

為了改變未來，我幾乎消失了，這是事實。
[cpg]

簡而言之，我必須在兩個......。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

晚上。走在走廊上，我看到了光秀大人。
[cpg]

[OnName num="keitarou"]
'...... 光秀大人。
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide029"]
[OnName num="mitsuhide"]
'晚上好。有什麼不對嗎？ "
[cpg cn=true]


她要去殺信長大人。我的心情很複雜。
[cpg]

光秀大人會做這種事嗎？　不，我有這種感覺已經有一段時間了。
[cpg]

[OnName num="keitarou"]
'不，沒什麼。
[cpg cn=true]


她曾經走近我，與我調情。
[cpg]

她一定是認真的。如果不是這樣，我的失踪就沒有任何解釋。
[cpg]

[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide030"]
[OnName num="mitsuhide"]
我第一次見到她時，我想："景太郎先生，你似乎遇到了什麼麻煩。如果我沒意見，我就听著'。
[cpg cn=true]


光秀大人這麼說，但和她說也沒用。
[cpg]

如果我勸阻她背叛信長大人，那也是一樣的。
[cpg]

我將不可避免地消失，我知道我可能無法勸阻她。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我回到了我的房間。我獨自一人在思考。
[cpg]

我的腦海中只有糟糕的想像。我和信長大人在一起的日子是如此的愉快，以至於太多。
[cpg]

但......，我將別無選擇，只能接受嗎？
[cpg]

這是我所知道的歷史上最大的事件。如果是這樣，這一定是命運。
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

很快，早晨就會到來。我沒有選擇，只能珍惜這一天。
[cpg]

這也很難。因為我知道即將到來的命運。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

彷彿一切都從我手中溢出來。
[cpg]

我被信長大人叫住了，雖然我們在交談，但我還是有些心不在焉。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga381"]
[OnName num="nobunaga"]
......，我有點發懵。與本案有關嗎？ "
[cpg cn=true]


信長大人一定是在說，我幾乎消失了。
[cpg]

[OnName num="keitarou"]
我很好。我很好。 "
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="sNobunaga018"]
[OnName num="nobunaga"]
'......，我明白了。
[cpg cn=true]


聽到我的回答，信長大人從他的房間裡看出來並說。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="sNobunaga019"]
[OnName num="nobunaga"]
'仔細想想，這個被戰爭蹂躪的世界已經改變了。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga404"]
[OnName num="nobunaga"]
'一定程度的和平已經到來。這要歸功於你'。
[cpg cn=true]


這完全是誇大其詞。我什麼都沒做。
[cpg]

[OnName num="keitarou"]
我對你沒有用處，信長大人。
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga405"]
[OnName num="nobunaga"]
沒有。我是指情感支持。服兵役是一回事，服兵役是另一回事。
[cpg cn=true]


這些話對我來說真的太好聽了。他說："我想，如果我是一個人，那我就不會有任何幫助。"他說："我想，如果我是一個人，那我就不會有任何幫助。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

今天和昨天是一樣的。明天和今天一樣。
[cpg]

快樂的時光很快就過去了。就像它以一種可怕的方式匆匆而過。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

我不能再這樣下去了。但我不能告訴他們一切。
[cpg]

她走出城堡，去呼吸一些新鮮空氣。在那裡，她來到了。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga406"]
[OnName num="nobunaga"]
'......，不知為何我有一種感覺，景太郎在這裡。
[cpg cn=true]


我轉過身來，無法對她微笑。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga407"]
[OnName num="nobunaga"]
'你看起來和以前一樣不慌不忙。
[cpg cn=true]


如果我不說，信長大人就會在本能寺事件中死去。
[cpg]

另一方面，如果我告訴你將會發生什麼，我將會消失。
[cpg]

不僅如此，我那些應該在未來的家人和朋友也會消失。
[cpg]

不，......，這並不重要。重要的是。
[cpg]

無論是哪種方式，我們都注定不會自己團結起來。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga408"]
[OnName num="nobunaga"]
'我仍然認為他們在隱藏什麼。我知道這都是你不能告訴我的事情。 ......
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga409"]
[OnName num="nobunaga"]
'但這並不意味著一切都不能被隱藏，顯然。
[cpg cn=true]


信長大人比其他人更了解我。
[cpg]

縱觀歷史，我們不難發現，在過去的幾十年裡，我們一直都是以 "人 "為中心，而不是以 "物 "為中心。 "人 "是指 "人"，"物 "是指 "人"。我張開嘴沉思著。
[cpg]

[OnName num="keitarou"]
'...... 信長大人。你是......."
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我不能告訴你一切。但我不能隱藏一切。信長大人是對的。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************


[VOICE f="Nobunaga410"]
[OnName num="nobunaga"]
這是否意味著，由於某種原因，我將會死亡，儘管我將在天堂的統治之下？
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Nobunaga411"]
[OnName num="nobunaga"]
'如果這個事實被改寫，將要出生的你就會消失。
[cpg cn=true]


[OnName num="keitarou"]
'...... 這就是我的意思。我們就是不能在一起'。
[cpg cn=true]


信長大人的表情很悲傷。
[cpg]

但這並不意味著他感到驚訝。我想他知道這一點。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga412"]
[OnName num="nobunaga"]
'我明白。你可以默默地看著我的結局。沒有你，我就沒有理由活下去'。
[cpg cn=true]


[OnName num="keitarou"]
'哦，不，......！
[cpg cn=true]


我沒料到他會說那麼多。我被嚇了一跳。
[cpg]

[OnName num="keitarou"]
'這恰恰相反。如果不是因為你，我就不是我了。
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]

我以強烈的語氣告訴她，但信長大人搖了搖頭。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga413"]
[OnName num="nobunaga"]
'我一生都很孤獨。你在這一切中出現，是一盞明燈'。
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=1000]

說著，信長大人走過來，擁抱了我。
[cpg]

淚水順著我的臉頰流了下來。我發現自己在哭。
[cpg]


;//ブラックアウト

;//移植前シーンカット

;//========================================
;//●ＣＧ（屋外でヒロインが主人公を抱きしめる）ev_24
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：屋外＿城近く
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_24_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Nobunaga414"]
[OnName num="nobunaga"]
'景太郎。我很高興遇到你。
[cpg cn=true]


[OnName num="keitarou"]
我也很高興認識你。我不希望認為......，你已經走了。
[cpg cn=true]



[VOICE f="Nobunaga415"]
[OnName num="nobunaga"]
我不想再去想它了。現在，讓我們確保我們有一個和平的時刻。
[cpg cn=true]


我們將確保彼此的存在。她還活著。
[cpg]

我決定不去想未來她會離開的事情，就在這一刻，就像信長大人說的那樣。
[cpg]

那天的月亮和星星都很美，但一切似乎都在增強信長大人。
[cpg]

我擁抱了她。好像她哪裡也不去。
[cpg]

我還確保我不能去任何地方。
[cpg]

我們倆緊緊地擁抱在一起。
[cpg]


;//移植前シーンカット

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

回到城堡後，我們想留在一起。
[cpg]

我們不是正式的夫妻，但人們仍然會知道我們的關係。
[cpg]

我覺得蘭丸，尤其是蘭丸，告訴了我很多關於我們的事情。
[cpg]


;//ブラックアウト


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我們還是不能睡在一起。
[cpg]

如果早上有人來，看到我和信長大人睡在一起，那就太可怕了。
[cpg]

所以我又獨自睡覺了。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

我在早晨醒來。蘭丸大人來叫我起床。
[cpg]

[OnName num="keitarou"]
'早上好，.......'
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru101"]
[OnName num="ranmaru"]
'好一張臉。你一定做了一個非常可怕的夢。
[cpg cn=true]


最近，它一直是這樣的。當我想到未來時，我忍不住要這樣做。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]


數月和數日過去了。正在作出決定。
[cpg]

本野寺事件何時發生？這與我知道的歷史不同。
[cpg]

幾十年後應該發生的事情可能明天就會發生。
[cpg]


[window target=false]
[BG f="b_03_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（朝）******************************************************

我正在去找信長大人的路上。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga464"]
[OnName num="nobunaga"]
'...... 我聽說你有事情要告訴我。怎麼了？ "
[cpg cn=true]


談論什麼。這很明顯。我將幫助她。我想幫助她，但......
[cpg]

它將改變未來。當然，對我來說，她是我想保護的人，即使我不得不交換一切。
[cpg]

......，但我已經迷失了方向。
[cpg]

[OnName num="keitarou"]
'我想拯救信長大人。但......."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Nobunaga465"]
[OnName num="nobunaga"]
'別這麼說。信玄不是也告訴你不要留下我一個人嗎？ "
[cpg cn=true]


我還是想保護信長大人。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga466"]
[OnName num="nobunaga"]
我現在最害怕的事情是獨自生活。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga467"]
[OnName num="nobunaga"]
'嘿，景太郎。告訴我你會永遠在我身邊。
[cpg cn=true]


我不知道如果我可以這樣說會有多好。但我不能。
[cpg]

[OnName num="keitarou"]
我不能肯定地說。
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Nobunaga468"]
[OnName num="nobunaga"]
...... 我明白了。
[cpg cn=true]


信長大人似乎已經明白了我的意圖。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の廊下』（昼）******************************************************

我還不能做出決定。但如果有什麼不同的話，那就是我們什麼時候會分道揚鑣，就是這樣。
[cpg]

信長大人不知道我在本能寺會被出賣。
[cpg]

因此，當我們前往本之島時，他會對我說些什麼。那時再阻止他還不算太晚。
[cpg]

當然，它可能會更早。唯一的區別是我消失的時候。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru102"]
[OnName num="ranmaru"]
'景太郎。你跟信長大人說了些什麼？
[cpg cn=true]


[OnName num="keitarou"]
...... 總有一天，我會把一切都告訴蘭丸大人。
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]

[VOICE f="Ranmaru103"]
[OnName num="ranmaru"]
我是唯一剩下的人。我擔心你會離開。
[cpg cn=true]


甚至蘭丸大人也在為我擔心。
[cpg]

我是個幸運的人。我現在不怕死，這有什麼奇怪的？
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_01_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************

我莫名其妙地發現自己來到了城堡小鎮，那裡的人們正匆匆忙忙地進行著他們的日常生活。
[cpg]

在我的時代，人們沒有如此激烈地生活。
[cpg]

我想今天對死亡的恐懼已經不存在了。
[cpg]

當然，我不認為這是件壞事。我想這是和平的標誌。
[cpg]

但正是在我的時代，我感到了人生的目標感。
[cpg]

這並不是說我享受可能死亡的快感或類似的東西。
[cpg]

我不知道我什麼時候會死，所以我必須珍惜這一刻。
[cpg]

當我想到這一點時，生活的想法就會閃現出來。
[cpg]

信長大人還活著。他還活著。
[cpg]

如果我不保護他呢？這就是我當時的心理狀態。
[cpg]


[window target=false]
[BG f="b_01_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（夜）******************************************************

希望，......，我想純粹地作為這個時代的人生活。
[cpg]

但這樣一來，信長大人就不能被救了嗎？
[cpg]

我也不可能認識到本能寺事件的發生。我不知道哪個會讓我更高興。
[cpg]


;//ブラックアウト

[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

我又一次去了信長大人的地方。我打算告訴他一切。
[cpg]


[OnName num="keitarou"]
'信長大人。你是在反叛。
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[OnName num="keitarou"]
是叛逆殺死了你，......."
[cpg cn=true]


我的身體正變得有點透明。我還是很害怕。
[cpg]

我想我當時嚇得渾身發抖。縱觀歷史，我們不難發現，在過去的幾十年裡，我們一直都是以 "人 "為本位，以 "物 "為本位，以 "人 "為本位。
[cpg]

[FACE method="change_3" pos="2/3"]
而就在我準備說出光秀大人的名字時。
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=1000]
她吻了我。她覆蓋了我的嘴唇。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga469"]
[OnName num="nobunaga"]
'...... Fuu。我還是不讓你說。 "
[cpg cn=true]


[OnName num="keitarou"]
信長大人, ......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga470"]
[OnName num="nobunaga"]
'我總是希望我可以再做一次。儘管我知道這是不可能的。
[cpg cn=true]


她似乎仍然想要我。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga471"]
[OnName num="nobunaga"]
'我知道你認為這可能是最後一次，但在某個地方......。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga472"]
[OnName num="nobunaga"]
'我仍然希望我可以和你聯繫。我想知道為什麼'。
[cpg cn=true]


信長大人的聲音逐漸變得含淚。然後，我意識到。
[cpg]

我在哭，信長大人也在哭。我不想把這場愛情想成是一場悲劇。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga473"]
[OnName num="nobunaga"]
'即使你已經做了決定，我還沒有。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga474"]
[OnName num="nobunaga"]
請。留在我身邊。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我總是認為這是最後一次。
[cpg]

我有同樣的感覺。這是最後一次了。
[cpg]

我希望有一天，當時間真的來到最後一次時，我將無怨無悔。
[cpg]


;//移植前シーンカット

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

最初，信長大人似乎把所有時間都花在了政治和戰爭上。
[cpg]

但現在他已經完全不同了。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Nobunaga497"]
[OnName num="nobunaga"]
'我從來沒有想到我會對多彩的愛情如此斤斤計較。
[cpg cn=true]


[OnName num="keitarou"]
'......，你會想和我有個孩子嗎？
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga498"]
[OnName num="nobunaga"]
'當然不是。即使我最終會死。
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

然後，早晨又來了。我在走廊上遇到蘭丸大人。
[cpg]


[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************



[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru104"]
[OnName num="ranmaru"]
'...... 景太郎
[cpg cn=true]


[OnName num="keitarou"]
'是的，先生？　蘭丸大師。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru105"]
[OnName num="ranmaru"]
你在想什麼？　你不會告訴我任何事情，對嗎？
[cpg cn=true]


[OnName num="keitarou"]
沒有。這是因為它不是那麼容易說的。
[cpg cn=true]


蘭丸大人沒有再追究。
[cpg]

這對我來說是一種解脫。 ......
[cpg]


[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]


[VOICE f="Nobunaga499"]
[OnName num="nobunaga"]
怎麼了？你們兩個在談論什麼？ "
[cpg cn=true]


信長大人的聲音傳來，我們轉過身來。
[cpg]

[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru106"]
[OnName num="ranmaru"]
'怎麼了？　信長大人，你看起來有點沮喪。
[cpg cn=true]


蘭丸大人真的是一個能注意到最小事情的人。
[cpg]

[STOPBGM]

[FACE method="change_4" pos="2/5"]

[VOICE f="Nobunaga500"]
[OnName num="nobunaga"]
'......，我最近不太舒服。也許...... ugh"。
[cpg cn=true]


信長大人握住他的嘴。
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

不久之後，我發現信長大人懷上了一個孩子。
[cpg]

我不知道要到什麼時候才能發生本能寺事件。
[cpg]

她能生下孩子嗎？我們甚至不知道這一點。 ......
[cpg]

我甚至不知道信長大人掌權和叛亂之間有多少時間。
[cpg]

如果是這樣的話，我應該馬上告訴她一切。 ......
[cpg]

但我又不知道和我在一起的孩子是否會存在？
[cpg]

至少......，我希望我和她的孩子能活著。
[cpg]

沒有它，我就無法生活。
[cpg]

否則，我將不得不告訴她叛亂的情況，並重新安排歷史。
[cpg]


;//ブラックアウト





[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

然後我們成為了丈夫和妻子。
[cpg]

這並不以任何方式改變我們的關係。我仍然稱信長大人為'Sama-sama'。
[cpg]

我想這就像過去軍閥的妻子們一樣。
[cpg]

到目前為止，信長大人的權力更大。 ......
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夕方）******************************************************

她的肚子越來越大了。
[cpg]

時間在流逝。我不知道她什麼時候會死。 ......
[cpg]

不過，我還是希望她能有個孩子。
[cpg]

[OnName num="keitarou"]
'...... 信長大人,......
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Nobunaga501"]
[OnName num="nobunaga"]
'不要給我這種表情。在這個孩子出生後再做所有的決定也不遲。
[cpg cn=true]


那麼可能就太晚了。我的內心是一片混亂，百感交集。
[cpg]

當我要開始哭的時候，信長大人向我走來。
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga502"]
[OnName num="nobunaga"]
'你很弱。但我不是也很堅強嗎？
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

他把他的手放在我的臉頰上。然後他吻了我。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[VOICE f="Nobunaga503"]
[OnName num="nobunaga"]
'我希望我能忘記所有困難的事情。
[cpg cn=true]


信長大人這樣說，並要求我。
[cpg]

沒有理由拒絕。我寧願感受到她離我很近。
[cpg]


;//移植前シーンカット
[BG f="b_06_2.ui" time=1000]
[WAIT time=1100]


我感覺她也意識到了自己的死亡。我做不到，但我能做的也不多。
[cpg]

要么我消失，要么信長大人死亡。
[cpg]

如果我消失，未來將被改變。
[cpg]

這不可能只是我的問題。我不能做出這樣的決定。 ......
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

又過了兩個月。我正在去往光秀大人家的路上。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Mituhide031"]
[OnName num="mitsuhide"]
你跟我有什麼關係？ "
[cpg cn=true]


[OnName num="keitarou"]
...... 我不再試圖阻止你了。
[cpg cn=true]


[OnName num="keitarou"]
'即使我試圖阻止你，你也無法阻止我。但至少......"
[cpg cn=true]


我想知道三秀大人如何看待我。
[cpg]

你是否認為在某種程度上你有一種預感？
[cpg]

還是他也知道我是來自未來？
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide032"]
[OnName num="mitsuhide"]
'我們是在談論孩子嗎？　不用擔心。 "
[cpg cn=true]


[OnName num="keitarou"]
'誒，......'
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Mituhide033"]
[OnName num="mitsuhide"]
'我也不是一個惡魔。即使孩子活下來，我也不認為會像她那樣構成威脅。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide034"]
[OnName num="mitsuhide"]
我不會做這麼可怕的事，我會考慮你的感受。
[cpg cn=true]


光秀大人的話讓我感到安心，但我還是忍不住......。
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Mituhide035"]
[OnName num="mitsuhide"]
別擋我的路。顯然，由於某種原因，我不能這樣做。
[cpg cn=true]


[OnName num="keitarou"]
"......""
[cpg cn=true]


我只說了這一點。
[cpg]

她告訴我不要擋她的路。不過，她說她會等到孩子出生。
[cpg]

我不知道真正的本能寺事件是什麼樣的。
[cpg]

但信長大人不可能沒有孩子。
[cpg]

因此，未來將是一樣的，包括在那裡。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[SE f=se024]
;//【ＳＥ】『通路歩く』

我在城堡裡走來走去，有一種不安的感覺。
[cpg]

我知道誰要殺她。而且這還不是全部。
[cpg]

我甚至可以拯救信長大人。不過，我還是無法選擇。
[cpg]

我害怕自己會消失。我現在不得不承認這一點。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru107"]
[OnName num="ranmaru"]
"......，你又是這個樣子。"
[cpg cn=true]


[OnName num="keitarou"]
蘭丸大人，......，這沒什麼。
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru108"]
[OnName num="ranmaru"]
'你不會再對我說什麼了，是嗎？我知道。 "
[cpg cn=true]


蘭丸大人看起來有點吃驚。
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Ranmaru109"]
[OnName num="ranmaru"]
'只是不要誤會，你並不孤單。
[cpg cn=true]


如果本能寺事件像歷史事實中那樣發生，她也會死。
[cpg]

它不會像蘭丸大人說的那樣。我將是孤獨的。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

我獨自一人，回到了我的房間。
[cpg]

已經做出了決定。只要她生下孩子，......
[cpg]


[VOICE f="Nobunaga526"]
[OnName num="nobunaga"]
'景太郎。你在這裡嗎？ "
[cpg cn=true]


信長大人在那裡拜訪了我。我回答說。
[cpg]

[OnName num="keitarou"]
'是的。它是什麼？
[cpg cn=true]


[SE f=se025]
;//【ＳＥ】『ふすま開く』

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[WAIT time=1100]


[VOICE f="Nobunaga527"]
[OnName num="nobunaga"]
'完全沒有。我只是想看看你。
[cpg cn=true]


[OnName num="keitarou"]
'......，我明白了。
[cpg cn=true]


信長大人仍然對我有這種想法。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga528"]
[OnName num="nobunaga"]
'當我一個人的時候，我往往會變得多愁善感，這可不行。
[cpg cn=true]


[OnName num="keitarou"]
'我也是。我想接近信長大人'。
[cpg cn=true]


[OnName num="keitarou"]
'你知道.......'我聽說，悲傷的感覺並不是一種不愉快的情緒。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Nobunaga529"]
[OnName num="nobunaga"]
'也許是這樣。相反，它是相反的。
[cpg cn=true]


[OnName num="keitarou"]
'是的。這更像是你沉浸其中的東西，顯然。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga530"]
[OnName num="nobunaga"]
好吧，那麼......，你不可能永遠停留在悲傷中。 "
[cpg cn=true]


信長轉向我，揉著肚子。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga531"]
[OnName num="nobunaga"]
'景太郎。你和這個孩子有一個未來'。
[cpg cn=true]


我無法回答。我沒有足夠的決心立即給出答案。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga532"]
[OnName num="nobunaga"]
我沒有選擇，只能說："記住我。這就是我所要求的。
[cpg cn=true]



;//移植前シーンカット

不可言喻的情緒在我心中湧動。但我無法說話。
[cpg]

[OnName num="keitarou"]
'...... 信長大人。我是.......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga556"]
[OnName num="nobunaga"]
怎麼了？　你還在迷路嗎？ "
[cpg cn=true]

;//裸になった彼女を見つめながら、また振り切ったはずの感情が湧いてくる。
當我盯著她時，我本該甩掉的感覺又出現了。
[cpg]

我還在為此事耿耿於懷。但我不能讓她做決定。
[cpg]

首先，她不應該讓我活著。
[cpg]

我的一句話就能解決一切問題。
[cpg]

光秀大人背叛了我。就憑這一個字，......
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga557"]
[OnName num="nobunaga"]
'你很害怕。我知道你的感受。 "
[cpg cn=true]


我發現自己在顫抖。我仍然害怕我將會消失。
[cpg]

[FACE method="shake_2" pos="2/3"]

[VOICE f="Nobunaga558"]
[OnName num="nobunaga"]
'想都別想。你已經為我做得夠多了。 "
[cpg cn=true]



;//ブラックアウト

這很容易讓人相信她的話。但這是不夠的。
[cpg]

一點都不足夠。如果我不能幫助她，那就沒有意義了。
[cpg]

我無法說出最後一個字，儘管我想到了這一點。
[cpg]


;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

又過了幾個月，她的肚子腫得更大了。
[cpg]

整個城堡都在騷動，因為一個貴族要生孩子了。
[cpg]


[window target=false]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

然而，信長本人卻不以為然。
[cpg]

她保持著冷靜的表情，似乎在說她周圍的人都太吵了。 ......
[cpg]


[window target=false]
[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************


[VOICE f="Nobunaga581"]
[OnName num="nobunaga"]
'不要為我擔心。不過我不認為我有那麼害怕。 "
[cpg cn=true]


[OnName num="keitarou"]
'......，我認為有點害怕是可以的。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga582"]
[OnName num="nobunaga"]
'也許你是對的。但分娩疼痛是我無法適應的。我從來沒有過這樣的痛苦，甚至在戰場上也沒有過。 "
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


當我看到信長大人的柔和表情時，我的心情很複雜。
[cpg]

如果她生下孩子，光秀大人會毫不留情地採取行動。
[cpg]

到那時，如果我們什麼都不做，信長大人會......。
[cpg]

[STOPBGM]

[FACE method="shock_4" pos="2/3"]

[VOICE f="Nobunaga583"]
[OnName num="nobunaga"]
'Ugh ...... kuuuuh!
[cpg cn=true]


[OnName num="keitarou"]
'怎麼了？　信長大人，你還好嗎？ "
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我不能在她出生時在場。
[cpg]

我想在這個時代可能是這樣的，但我沒有心情去想。
[cpg]

我不認為這是說母親和孩子都很健康的方式。
[cpg]

但這意味著信長大人自己和新生兒都很健康。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１』（夜）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Ranmaru110"]
[OnName num="ranmaru"]
'恭喜你，信長大人。 ......，這是一個可愛的孩子。
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]

[VOICE f="Nobunaga584"]
[OnName num="nobunaga"]
'這是我和景太郎的孩子。這是很自然的'。
[cpg cn=true]


信長大人笑著說這話。首先想到的是，這個女人是個母親。
[cpg]

我必須保護她。我試圖堅定地講出來，但我的聲音在顫抖。
[cpg]

[OnName num="keitarou"]
'...... 信長大人。我是.......'。
[cpg cn=true]


[FACE method="shake_6" pos="2/5"]

[VOICE f="Nobunaga585"]
[OnName num="nobunaga"]
'這就夠了。景太郎，如果你迷路了，那一定意味著你是那麼害怕。
[cpg cn=true]

[FACE method="bow_6" pos="2/5"]
信長大人看了看蘭丸大人。和......
[cpg]


[STOPBGM]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga586"]
[OnName num="nobunaga"]
'只要有你，我就不怕死。所以我不會再從你那裡聽到任何關於未來的消息。 "
[cpg cn=true]


他說。蘭丸大人接近我。
[cpg]

[OnName num="keitarou"]
'蘭丸大人，什麼......
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru111"]
[OnName num="ranmaru"]
'我也不太了解。我不太了解，但這是信長大人的命令，所以不要覺得不好。
[cpg cn=true]


我想到的是，當我看到一個女人的時候，我很驚訝，轉過身來看到她。我很驚訝，轉過身去。 ......
[cpg]


;//ブラックアウト
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=1]
[WAIT time=1500]

[FACE method="in" pos="4/7"]


當我意識到信長大人的意圖時，已經太晚了。
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

即使信長大人自己死了，他也是為了救我。
[cpg]

我被鎖在城堡的一個房間裡。我無法向外邁出半步。
[cpg]

我不能再告訴她未來了。 ...... 不。
[cpg]

[OnName num="keitarou"]
'我知道你有一個望風的人!　聽我說！ "
[cpg cn=true]


[OnName num="keitarou"]
信長大人將在本能寺被出賣！ ？　有人，請告訴她。
[cpg cn=true]


有守衛。
[cpg]


[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

回想起來，沒有時間猶豫了。
[cpg]

不過，在看到孩子和她在一起後，我還是想消失。
[cpg]

信長大人一定也看穿了這一點。
[cpg]

[OnName num="keitarou"]
'...... 光秀大人
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Mituhide036"]
[OnName num="mitsuhide"]
'你的麻煩大了。你到底是誰？
[cpg cn=true]


[OnName num="keitarou"]
'請......，信長大人，如果我失去你，我將......
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide037"]
[OnName num="mitsuhide"]
顯然，你也知道我的動機。但信長大人並不聽我的，而是......。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Mituhide038"]
[OnName num="mitsuhide"]
他不想和你接觸，而你正在聞到它。好像你不怕死一樣。 "
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


我憎恨光秀大人。但這並不是說殺了她就能解決一切問題。
[cpg]

最終，未來將被改變。這是不可避免的。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide039"]
[OnName num="mitsuhide"]
'只是，景太郎先生。我不認為她的決心會白費。
[cpg cn=true]


[OnName num="keitarou"]
'那個......，是什麼意思？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide040"]
[OnName num="mitsuhide"]
如果她有比自己更想保護的東西，那就是你，她不應該活著嗎？
[cpg cn=true]


光秀大人正在策劃一切。我認為她一定是一個邪惡的人。
[cpg]

但......，她這樣對我說。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide041"]
[OnName num="mitsuhide"]
'逆時代潮流而動是很難的。即使對我來說也是如此。 "
[cpg cn=true]


;//[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide042"]
[OnName num="mitsuhide"]
'不過，你也不應該絕望。我們都不應該'。
[cpg cn=true]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

然後，城堡裡突然開始騷動起來。
[cpg]

大家都在說本能寺已經被燒毀了。
[cpg]

警衛們都走了。我到外面去了。
[cpg]

我意識到，信長大人已經不在這個世界上了。
[cpg]

蘭丸大人一定是陪著他。光秀先生從現在開始就會有敵意。
[cpg]

我再也沒有可以依靠的人了。
[cpg]

[OnName num="keitarou"]
...... 儘管如此，我還得活著嗎？信長大人。
[cpg cn=true]


我已經想把一切都扔掉了。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

信長大人在準備工作中非常謹慎。他盡可能地避免與兒童一起工作。
[cpg]

信長大人自己也不知道她會在本能寺被殺。
[cpg]

但在她死後，他似乎告訴他的家臣帶著孩子跑了。
[cpg]

而且無論我從這裡做什麼，歷史都不會有太大的改變。看來他已經看了那麼遠，並且已經安排好了釋放我。
[cpg]

[OnName num="vassal"]
'我們逃跑吧，景太郎大人。如果你在這裡被殺，信長大人所做的一切就都白費了。
[cpg cn=true]


如果你留在這裡，你可能會殺死我和我的孩子。現在唯一能做的就是逃亡。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の廊下』（昼）******************************************************

在我們逃跑的城堡裡，我和信長大人抱著孩子。
[cpg]

我無法停止哭泣。她彷彿在替我哭泣，因為我的眼淚也已經乾涸了。
[cpg]

當時，信長大人的附庸已經到來。
[cpg]

[OnName num="vassal"]
'我有一封信長大人寫給景太郎大人的信，.......'
[cpg cn=true]


我一定看起來很糟糕。臣子猶豫著要不要把它交出來。
[cpg]

[OnName num="keitarou"]
'讓我看看.......'
[cpg cn=true]


我把信拿在手裡。一張小紙片被折疊起來。
[cpg]


;//ブラックアウト

;//可能であればここから一連の音声にリバーブをかけてください

[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[WAIT time=1500]

[FACE method="in" pos="4/7"]


[VOICE f="Nobunaga587"]
[OnName num="nobunaga"]
'景太郎，謝謝你做的一切。我一點也不想死'。
[cpg cn=true]



[VOICE f="Nobunaga588"]
[OnName num="nobunaga"]
'不過，我還是能從你的態度中看到這一切。
[cpg cn=true]



[VOICE f="Nobunaga589"]
[OnName num="nobunaga"]
'我想我已經不在這個世界上了。我將要寫的東西是毫無根據的'。
[cpg cn=true]



[VOICE f="Nobunaga590"]
[OnName num="nobunaga"]
'還是要活下去。如果你活著，你會再次找到幸福。
[cpg cn=true]



[free time=1000]
[WAIT time=1100]

;//【ＢＧ】『城＿縁側の廊下』（昼）******************************************************

...... 信長大人並沒有選擇一個他活下來而我消失不見的未來。
[cpg]

[OnName num="keitarou"]
'信長大人，.......'
[cpg cn=true]


我叫著那個我不知道叫了多少次的名字，我再叫一次。
[cpg]

我現在唯一能做的就是無論如何都要活下去，為信長大人感到高興。
[cpg]

這就對了。我知道所有的未來。如果我改成偏離這一點的歷史，我將在第一時間消失。
[cpg]

我現在應該跟隨的人不是秀吉就是家康。 ......
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

我決定生活在一個被戰爭蹂躪的世界裡，同時思考。
[cpg]

我不會死。我不會消失。
[cpg]

為了信長大人，為了我的孩子們，......，我將活得最精彩。
[cpg]

我將活下去。
[cpg]



;//ＥＮＤ　ヒロイン１ルート
;//＠
[SCENE id=9]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="epend.ks" target="*start"]

