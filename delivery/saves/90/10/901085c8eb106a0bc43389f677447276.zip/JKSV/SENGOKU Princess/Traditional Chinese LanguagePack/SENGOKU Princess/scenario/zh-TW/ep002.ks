*start


;#################################################
*Ep002|奧克哈紮馬之戰
;#################################################

[SCENE id=2]


[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]

[stflag Selectflg1=0]
[stflag Selectflg2=0]
[stflag Selectflg3=0]
[stflag Selectflg4=0]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

時間過去了一段時間，日子似乎平靜而黯淡。
[cpg]

我不能什麼都不做，但當我做家務等事情時，周圍的人都會阻止我。
[cpg]

我想這是因為我是信長大人身邊的人。
[cpg]

而且在那個年代，做飯和其他雜事都是由婦女來做的，這是眾所周知的。 ......。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Nobunaga170"]
[OnName num="nobunaga"]
'你看起來很無聊。景太郎。 "
[cpg cn=true]


[OnName num="keitarou"]
'...... 或 ......'
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]

[VOICE f="Ranmaru061"]
[OnName num="ranmaru"]
如果你不忙，我可以給你一些劍術訓練。
[cpg cn=true]


蘭丸大人建議。這是一件相當令人欣慰的事情。
[cpg]

[OnName num="keitarou"]
是的，我是。我對自己的劍術還是很有信心的。
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]

[VOICE f="Ranmaru062"]
[OnName num="ranmaru"]
'...... 你怎麼敢在我面前說這種話？
[cpg cn=true]


不知道這意味著什麼，我看著信長大人。
[cpg]

[FACE method="bow_2" pos="2/5"]

[VOICE f="Nobunaga171"]
[OnName num="nobunaga"]
蘭丸用長矛更好，但他用劍也相當好。
[cpg cn=true]


[OnName num="keitarou"]
'我明白了。 '那麼我就更有動力去做了。
[cpg cn=true]


[FACE method="change_3" pos="4/5"]

[VOICE f="Ranmaru063"]
[OnName num="ranmaru"]
'你說......？
[cpg cn=true]


然後決定我們要進行徒手搏鬥，所以我們必須做好準備。
[cpg]

有人告訴我，在這個時期，神奈仍然存在。我聽說他們已經很老了。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru064"]
[OnName num="ranmaru"]
'如果你如此自信，你就不需要護具。
[cpg cn=true]


[OnName num="keitarou"]
'......，我不能對你輕易下手。這樣做還行嗎？ "
[cpg cn=true]



;//ブラックアウト

;//戦闘シーン　武器を振るうようなエフェクトなどつけられたらお願いします

;//========================================
;//●ＣＧ（紹介ページヒロイン５のＣＧ）ev_95
;//人物１：ヒロイン５　服装１：着衣
;//場所　：城＿外観
;//時間　：昼
;//備考　：可能であれば背景を足してください
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;**【ＣＧ】 ev_95_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]



[SE f=se028]
;//【ＳＥ】『竹刀打ち合う』

[BG f="white.ui" time=100]
[WAIT time=100]
;**【ＣＧ】 ev_95_0 ***********************
[CG id=2 index=0 time=100]
;***************************************
[WAIT time=100]

在這個時代，信長大人被公認為是一個熟練的戰士。而我則是像其他地方一樣的劍道俱樂部成員。
[cpg]

但各時代之間存在著差距。我認為這將是一個很好的搭配，當我們互相撞擊的時候，我......
[cpg]


[VOICE f="Ranmaru065"]
[OnName num="ranmaru"]
'啊!　賽亞啊！ "
[cpg cn=true]


蘭丸大人的太極圖是如此的筆直。也有許多初步的運動。
[cpg]

我想，自從劍道變得更像一項運動以來，它的質量可能已經發生了變化。
[cpg]

能在實際戰鬥中使用的劍術可能更多的是揮舞重劍的力量或類似的東西。
[cpg]

還是說男女之間根本就有區別？ ......，這就像沒有比賽。
[cpg]


[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************


[VOICE f="Ranmaru066"]
[OnName num="ranmaru"]
'哈，哈，哈'。
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


我覺得打一個沒有穿防護裝備的女孩不舒服，所以我在沙沙地打了一會兒神棍。
[cpg]

看到蘭丸大人即將耗盡力量，信長大人饒有興趣地看著。
[cpg]

[FACE method="bow_7" pos="2/5"]

[VOICE f="Nobunaga172"]
[OnName num="nobunaga"]
'把你的耳朵借給我聽一下。景太郎'。
[cpg cn=true]


[OnName num="keitarou"]
'是的，怎麼了，......？
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]

[VOICE f="Nobunaga173"]
[OnName num="nobunaga"]
'你不是生活在一個比現在更和平的時代嗎？你怎麼能駕馭這樣的一把劍？ "
[cpg cn=true]


[OnName num="keitarou"]
'......，這是.......'
[cpg cn=true]


'你是說，因為我們生活在一個和平的時代，所以有些事情我們可以做？
[cpg]

[OnName num="keitarou"]
'即使在今天，劍道，這種劍術仍然存在。我想這意味著它以自己的方式進化了，假設你不使用真正的劍。
[cpg cn=true]

[FACE method="shake_4" pos="4/5"]
[FACE method="change_1" pos="2/5"]

蘭丸大人看起來很沮喪。想到這裡，我不應該對一個女孩的對手這樣做。
[cpg]

在這樣想的時候，信長大人顯得很感動。總的來說，我想知道進行徒手搏鬥是否是一個好主意。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

時間就這樣進一步流逝。
[cpg]

有好幾次，我不得不從一個城堡搬到另一個城堡，以適應信長大人。在某種程度上，我習慣了四處走動。
[cpg]

我們在城堡裡聽說，他終於要統一歐瓦里......。
[cpg]

這個時期的地名和我所在的時期的地名不太相符。
[cpg]

對信長大人來說，一個叫岩倉城的地方似乎是他的下一個目標，但我甚至不知道誰在那裡。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夕方）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Nobunaga174"]
[OnName num="nobunaga"]
'從現在開始，我打算接管這個國家。我將結束這場戰鬥。
[cpg cn=true]


我和蘭丸被傳喚到信長大人的房間。
[cpg]

[FACE method="bow_2" pos="4/5"]

[VOICE f="Ranmaru067"]
[OnName num="ranmaru"]
'當然了。信長大人，我毫不懷疑你會成為這片土地的統治者。
[cpg cn=true]


蘭丸大人現在是、過去是、將來可能也是一心一意為信長大人服務。
[cpg]

[FACE method="shake_3" pos="2/5"]

[VOICE f="Nobunaga175"]
[OnName num="nobunaga"]
我不知道在世界統一之後還有什麼。我不認為和平會很快到來。
[cpg cn=true]


我一直在想我是否應該說些什麼。
[cpg]

她會遇到什麼樣的結局？ ......
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

我敢肯定，如果放任不管，信長大人會在本能寺事件中自殺，因為我知道這段歷史。
[cpg]

但我可以改變這一點嗎？
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

我遇到光秀先生的時候，我的心情還很複雜。
[cpg]

[OnName num="keitarou"]
'你又在照顧...... 盆景嗎？
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide014"]
[OnName num="mitsuhide"]
'是的。你也想試試嗎？
[cpg cn=true]


[OnName num="keitarou"]
'不，我是......
[cpg cn=true]


在閒聊的時候。光秀大人突然改變了話題。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide015"]
[OnName num="mitsuhide"]
你對信長大人有什麼看法？
[cpg cn=true]


[OnName num="keitarou"]
是的，...... 我仍然會說是一個可靠的人。 "
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Mituhide016"]
[OnName num="mitsuhide"]
是這樣的嗎？我對你來說還不夠好嗎？ "
[cpg cn=true]


她的話，如果從正常意義上講，就是指你願意為我服務嗎？
[cpg]

但我知道光秀大人的野心。所以我不能說什麼。
[cpg]

[OnName num="keitarou"]
'......，至少，我現在只為信長大人服務。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide017"]
[OnName num="mitsuhide"]
'我喜歡你，我的夫人。我們聞起來都一樣。
[cpg cn=true]


[OnName num="keitarou"]
同樣的氣味？ "
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide018"]
[OnName num="mitsuhide"]
'是的，我知道。事實上，你難道不厭倦為別人服務嗎？
[cpg cn=true]


光秀大人正在展示他的野心的一瞥。也許他認為我看穿了這一切。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide019"]
[OnName num="mitsuhide"]
我會以平等的態度對待你。我不會把你當成我的僕人。
[cpg cn=true]


[OnName num="keitarou"]
你是什麼意思？光秀大人沒有宣誓效忠信長大人？
[cpg cn=true]


當我問光秀大人時，她笑了一下。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide020"]
[OnName num="mitsuhide"]
我不這麼認為。沒有人比我對信長大人更有用。
[cpg cn=true]


我無法讀懂她的真實意圖。我知道她喜歡我，但......
[cpg]

也許她想讓我在她背叛我時跟隨她的朋友。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我必須要考慮一下。即使是和以前一樣。 ......
[cpg]

這一次不僅僅是為了生存。
[cpg]

在這裡，它是關於我們的人和我們所做的事。我不禁對這一點感到擔憂。
[cpg]


[window target=false]
[BG f="b_07_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

這並不是說我的時間太少，以至於我無法思考任何問題。
[cpg]

事實上，我有足夠多的東西。我必須思考，思考，思考，想出答案。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

時間流逝，但它比這更快。
[cpg]

比我知道的歷史要快得多。一個叫今川義元的軍閥和信長大人發生了衝突。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Mituhide021"]
[OnName num="mitsuhide"]
他將帶領多少部隊？
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga176"]
[OnName num="nobunaga"]
'他不會放過任何一個人。這將是一場全面的戰鬥。 "
[cpg cn=true]


奧克哈紮馬之戰。我不是一個歷史愛好者，但我知道這場戰鬥。
[cpg]

我還記得，信長將贏得這場戰鬥。我清楚地知道，我們不可能在這場戰鬥中失敗。
[cpg]

[FACE method="change_3" pos="2/5"]

[VOICE f="Nobunaga177"]
[OnName num="nobunaga"]
我要發動一場突襲。你怎麼看，蘭丸？ "
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="4/5" time=800]

[VOICE f="Ranmaru068"]
[OnName num="ranmaru"]
'突然襲擊？ ......，我認為我們應該公平公正地戰鬥。
[cpg cn=true]


沒有。我想知道是否是這樣的情況...... 在我的印像中，奧凱哈紮馬應該是日本歷史上最著名的突襲之一。
[cpg]

這意味著，如果你迎面撞上他們，你可能會輸。
[cpg]

[FACE method="change_3" pos="2/5"]

[VOICE f="Nobunaga178"]
[OnName num="nobunaga"]
'那景太郎呢？　你有什麼要說的嗎？
[cpg cn=true]


[OnName num="keitarou"]
'......，我認為突襲是個好辦法。
[cpg cn=true]


[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga179"]
[OnName num="nobunaga"]
我相信你會這麼說。你會這麼說的'。
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
蘭丸大人瞪了我一眼，但我沒有選擇。
[cpg]

信長大人一定知道我來自未來，他一定在聽我說什麼。
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga180"]
[OnName num="nobunaga"]
你呢，景太郎？你會去戰鬥的，對嗎？
[cpg cn=true]


我想了想。我想到的第一件事是，該公司的總裁是天津分公司的一名成員。
[cpg]

首先，即使沒有我，信長也會接管這個國家。 ......。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

他說他不會在信長大人面前回答，但會和光秀大人單獨呆在一起。 ......
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide022"]
[OnName num="mitsuhide"]
'你不必強迫自己參加戰鬥。你對我來說是那麼重要。 "
[cpg cn=true]


光秀大人說。選擇是跟隨信長大人還是光秀大人。
[cpg]

我應該怎麼做？我應該選擇誰？
[cpg]


畢竟，我想幫助...... 信長大人。他是第一個認出我的人。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Mituhide023"]
[OnName num="mitsuhide"]
'景太郎先生？　你要去哪裡？
[cpg cn=true]


我將原路返回，回到信長大人身邊。
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga181"]
[OnName num="nobunaga"]
'怎麼了？　你下定決心了嗎？
[cpg cn=true]


[OnName num="keitarou"]
'是的。 '是的，我也要去。我想幫助信長大人'。
[cpg cn=true]


信長大人看起來很滿意。
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga182"]
[OnName num="nobunaga"]
'這很有希望。我指望著你。
[cpg cn=true]


他對我說了這些話。我也感到高興。
[cpg]

既然我已經說了這些，就沒有回頭路可走了。
[cpg]

就我而言，這場戰鬥應該解決一切問題。
[cpg]

即使將來有小規模的戰鬥，大部分的戰鬥也會在奧克哈紮馬解決。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

信長大人正在為即將到來的戰鬥計劃一次突襲。
[cpg]

我將是執行它的人。這是一個重要的角色。
[cpg]

如果我不小心，我可能會死在這裡。
[cpg]

但信長大人對這種恐懼的感受一定更強烈。
[cpg]

想到這裡，我很奇怪地沒有害怕。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『戦場』（昼）******************************************************

奧克哈紮馬之戰。我知道，信長大人是出其不意地贏得了它。
[cpg]

我記得，兵力上的差異接近十倍。因為我們有3000人，他們有30000人......？
[cpg]

我們能在這麼大的數字面前獲勝嗎？在擔心這個問題的同時，......
[cpg]

我只相信信長大人。
[cpg]



;//※ストーリーが分岐
;//　勝利した場合、ヒロイン１、ヒロイン５ルートへ
;//　敗北した場合、ヒロイン４ルートへ


;//伏兵は２、５、８に配置されています

;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※桶狭間の戦い　開始時（１のマスにいる場合のシナリオ）※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


光秀大人說她不希望我被強迫去戰鬥。
[cpg]

如果我聽從她的建議，我是否應該敢於考慮撤回自己？
[cpg]

我認為這仍然是你要站在哪一邊的問題，信長大人的還是光秀大人的。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（夜）******************************************************

;//ヒロイン１の立ち絵を表示してください

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]


信長大人插話了。她說，在他們行軍至此的過程中，今川的軍隊經常將他們的伏擊部隊排成一列。
[cpg]

當然，並非所有的人都可能是這樣，但我們必須意識到這一點。
[cpg]

我下定決心並前進。
[cpg]


;//■選択肢
[switch]
[case "向南行進。"]
	[swap]
	[jump target="*select03_4"]
[case "繼續向東走。"]
	[swap]
	[jump target="*select03_2"]
[endswitch]

1，往南走。
2，向東行進。


;//==============================
;//１、南へ進む

;//同じイベント中の「４のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「２のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※２のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_2|奧克哈紮馬之戰


[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


前方潛伏著一個埋伏。我大膽地面對他們。
[cpg]


[SE f=se019]
;//【ＳＥ】『つばぜり合い』

我打敗了伏擊者，但我不能放鬆警惕。如果我們再遇到他們，我們就會有危險了。
[cpg]

我們小心翼翼地前進。 ......
[cpg]

[stflag Selectflg3=1]


;//■選択肢
[switch]
[case "向南前進。"]
	[swap]
	[jump target="*select03_5"]
[case "向東走。"]
	[swap]
	[jump target="*select03_3"]
[endswitch]

1，向南走。

2、向東走。


;//==============================
;//１、南へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「３のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※３のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_3|奧克哈紮馬之戰

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン４の立ち絵を表示してください

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/3" time=800]


在我們前進的過程中，我們與光秀女士相遇。
[cpg]

她的臉上有一種不贊同的表情。因為我沒有聽從光秀大人的話。
[cpg]

[OnName num="keitarou"]
'突襲似乎進展順利。光秀大人'。
[cpg cn=true]


光秀大人仍然顯得很不滿意。但這並不意味著我們現在不能退縮。
[cpg]


;//■選択肢
[switch]
[case "向南行進。"]
	[swap]
	[jump target="*select03_6"]
[endswitch]

1，向南推進。


;//==============================
;//１、南へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※４のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_4|奧克哈紮馬之戰

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン５の立ち絵を表示してください

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

在路上，我們與蘭丸大人碰面。
[cpg]

蘭丸大人正在英勇地戰鬥。儘管她是一個苗條的女孩，......
[cpg]

我很佩服她，但我知道我不能只佩服她，所以我向前看。
[cpg]


;//■選択肢
[switch]
[case "我往南走。"]
	[swap]
	[jump target="*select03_7"]
[case "向東走。"]
	[swap]
	[jump target="*select03_5"]
[endswitch]

1，向南走。
2、向東走。


;//==============================
;//１、南へ進む

;//同じイベント中の「７のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※５のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※


*select03_5|奧克哈紮馬之戰

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[if exp={getFlagValue("Selectflg3") == 1 }]
[jump target="*select03_5_t"]
[endif]

[jump target="*select03_5_f"]


;//==============================
;//２のマスを通っていた場合

*select03_5_t|奧克哈紮馬之戰

再往前走，又有一個伏擊。
[cpg]

[OnName num="keitarou"]
'該死的......，如果我們繼續這樣走下去......。
[cpg cn=true]


我已經耗盡了我的部隊，以至於我沒有選擇，只能撤退。
[cpg]

我不能再往前走了。我想我必須把它交給信長大人。
[cpg]


;//敗北判定となる
;//「桶狭間の戦い　二度伏兵のマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン４ルートへの可能性が残る

[jump target="*select03_lose"]


;//==============================
;//２のマスを通っていない場合

*select03_5_f|奧克哈紮馬之戰

前方潛伏著一個埋伏。我大膽地與他們對抗。
[cpg]


[SE f=se019]
;//【ＳＥ】『つばぜり合い』

我打敗了伏擊者，但我不能放鬆警惕。如果我們再遇到他們，我們就會有危險了。
[cpg]

我們小心翼翼地前進。 ......
[cpg]

[stflag Selectflg3=1]


;//■選択肢
[switch]
[case "向南前進。"]
	[swap]
	[jump target="*select03_8"]
[case "向東走。"]
	[swap]
	[jump target="*select03_6"]
[endswitch]

1，向南走。
[cpg]

2、向東走。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※６のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_6|奧克哈紮馬之戰

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


;//ヒロイン４の立ち絵を表示してください

與光秀先生一起，我們繼續前進。
[cpg]

她有些不高興，似乎不贊成我在這裡。
[cpg]

但我已經決定為信長大人服務。我不會從這裡轉身離開。
[cpg]


;//■選択肢
[switch]
[case "我要去南方了。"]
	[swap]
	[jump target="*select03_9"]
[endswitch]

1，向南推進。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※７のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_7|奧克哈紮馬之戰

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

最後，這場漫長的戰鬥即將結束。
[cpg]

到目前為止，我們還沒有遇到任何伏擊兵。這意味著我們的突襲很可能會很順利。
[cpg]


;//■選択肢
[switch]
[case "向東行進"]
	[swap]
	[jump target="*select03_8"]
[endswitch]

1，向東推進。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※８のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_8|奧克哈紮馬之戰

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[if exp={getFlagValue("Selectflg3") == 1 }]
[jump target="*select03_8_t"]
[endif]

[jump target="*select03_8_f"]


;//==============================
;//２あるいは５のマスを通っていた場合

*select03_8_t|奧克哈紮馬之戰

再往前走，又有一個伏擊。
[cpg]

[OnName num="keitarou"]
'該死的......，如果我繼續這樣走下去......。
[cpg cn=true]


我已經耗盡了我的部隊，以至於我沒有選擇，只能撤退。
[cpg]

我不能再往前走了。我想我必須把它交給信長大人。
[cpg]


;//敗北判定となる
;//「桶狭間の戦い　二度伏兵のマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン４ルートへの可能性が残る

[jump target="*select03_lose"]


;//==============================
;//２、５いずれののマスを通っていない場合

*select03_8_f|奧克哈紮馬之戰


前方潛伏著一個埋伏。我大膽地與他們對抗。
[cpg]


[SE f=se019]
;//【ＳＥ】『つばぜり合い』

我打敗了伏擊者，但我不能放鬆警惕。如果我們再遇到他們，我們就會有危險了。
[cpg]

我們小心翼翼地前進。 ......
[cpg]

[stflag Selectflg3=1]


;//■選択肢
[switch]
[case "繼續向東走。"]
	[swap]
	[jump target="*select03_9"]
[endswitch]

1，向東推進。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※９のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_9|奧克哈紮馬之戰


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（夕方）******************************************************

[SE f=se019]
;//【ＳＥ】『刀打ち合う』

一切都是戰鬥，直到敵人的將軍今川義元被打敗。
[cpg]

不一定要打敗所有的士兵，或許那可能不足以取勝。
[cpg]

什麼事情，信長大人已經想到了。
[cpg]

我們所要做的就是按照指示行動，戰鬥的進展是有利的。
[cpg]


[window target=false]
[BG f="b_09_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（夜）******************************************************

而在擊敗今川義元後，敵人已經失去了戰鬥意志。
[cpg]

這事就這麼定了。如果我們贏了，就意味著信長大人已經接管了這個國家。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Mituhide024"]
[OnName num="mitsuhide"]
'每次我都會愛上信長大人的計劃。我很自豪能成為他的附庸。
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
信長大人聽了光秀大人的話，點了點頭啊。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga183"]
[OnName num="nobunaga"]
'現在失眠的一個種子已經消失了，我必須感謝你。
[cpg cn=true]


[OnName num="keitarou"]
'不客氣。我只做了我能做的事。
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga184"]
[OnName num="nobunaga"]
不要謙虛。你已經成長為一個男人了，景太郎。
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


我在思考未來。信長大人贏得了大江山之戰。 ......。
[cpg]

清算的日子終於來臨了。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

我想不出別的辦法。
[cpg]

我甚至可以否定這個世界，認為它與我所知道的歷史毫無關係。
[cpg]

但無論我怎麼想，命運都不會改變，未來會到來。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

不過，當戰鬥結束後緊張氣氛消散時，蘭丸大人還是來看望我。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Ranmaru069"]
[OnName num="ranmaru"]
...... 景太郎。我可以說句話嗎？
[cpg cn=true]


[OnName num="keitarou"]
蘭丸大人，...... 有什麼問題嗎？
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru070"]
[OnName num="ranmaru"]
我想感謝你。我已經很久沒有說過了。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru071"]
[OnName num="ranmaru"]
謝謝你。多虧了你，信長大人似乎能更輕鬆地戰鬥。
[cpg cn=true]


[OnName num="keitarou"]
不可能。這是信長大人自己的力量。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru072"]
[OnName num="ranmaru"]
當你這樣站在信長大人面前時，你必須像...... 我。 "
[cpg cn=true]


蘭丸大人不再像以前那樣吃醋了。
[cpg]

相反，她很感激......，我以前從未見過她做出這樣的表情。
[cpg]

[OnName num="keitarou"]
'蘭丸大人對信長大人也是一心一意的，不是嗎？
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

'是的，'蘭丸大人回答，然後繼續說。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru073"]
[OnName num="ranmaru"]
'沒有什麼比被信長大人稱讚和崇拜更快樂的了。
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

我們越來越接近國家的統一。信長大人正處於無人能阻止他的境地。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga185"]
[OnName num="nobunaga"]
'我正在考慮與武田結成聯盟。他們不會拒絕。 "
[cpg cn=true]


[OnName num="keitarou"]
...... 是的。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga186"]
[OnName num="nobunaga"]
怎麼了？你看起來很不開心。
[cpg cn=true]


我已經想了很久了。到目前為止，沒有多少時間了。
[cpg]

我認為，原來的歷史發展得比較慢。
[cpg]

[OnName num="keitarou"]
'我已經想了很久，這段歷史與我所知道的歷史不同。
[cpg cn=true]


[OnName num="keitarou"]
'可能信長大人是個女人，但時間的流逝太快了。
[cpg cn=true]


這可能與蘭丸大人和信長大人之間沒有太大的年齡差異有關。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga187"]
[OnName num="nobunaga"]
'但我贏得了奧克哈紮馬。現在，對我來說，接管國家都不是不可能。
[cpg cn=true]


這當然是真的，我不認為從現在開始，接管國家的未來會改變。
[cpg]

如果要......，本能寺事件怎麼辦？
[cpg]

如果在叛亂發生前採取措施，未來可能會改變。
[cpg]

那麼信長大人是否能夠繼續生活下去，想：......
[cpg]

[OnName num="keitarou"]
'是的。這就對了。 "
[cpg cn=true]


現在，他只是向信長大人宣誓效忠。
[cpg]

[if exp={getFlagValue("Selectflg2") == 1 }]
[jump target="*select03_ex"]
[endif]


[jump target="*select03_end"]


;//==============================
;//稲生の戦いで勝利していた場合のみ下記のシナリオを通る

*select03_ex|奧克哈紮馬之戰。

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga188"]
[OnName num="nobunaga"]
'嗯。景太郎，你還是有些緊張'。
[cpg cn=true]


[OnName num="keitarou"]
'不，我不是這個意思。 ......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga189"]
[OnName num="nobunaga"]
'我需要為你打破緊張的局面，我想。
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

說著，她走近我。
[cpg]

[OnName num="keitarou"]
'信長大人，......，這是沒有用的。這對我來說是如此的浪費時間。
[cpg cn=true]


[OnName num="keitarou"]
'此外，你甚至不會知道誰在看。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga190"]
[OnName num="nobunaga"]
'......，我明白了。如果你拒絕，我不會強迫你'。
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

...... 我拒絕了信長大人的邀請。
[cpg]

這有點讓人心碎。但這也是沒辦法的事。
[cpg]

我也沒有準備好。
[cpg]


[window target=false]
[BG f="b_06_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夕方）******************************************************

但很快我就不能再毫無準備了。
[cpg]

我不是被信長大人召喚的，而是被他的一個臣子召喚的。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

諸侯們都是男人。而且他們有神秘的面孔。
[cpg]

[OnName num="vassal_A"]
'聽著，景太郎。信長大人，如你所知，讓男人遠離'。
[cpg cn=true]


[OnName num="keitarou"]
'是的。 ......，我相信他是個大忙人。
[cpg cn=true]


[OnName num="vassal_B"]
'啊。但我不能再這麼說了。
[cpg cn=true]


[OnName num="vassal_A"]
我聽說，作為一個男人，景太郎受到信長大人的青睞，這一點很不尋常。
[cpg cn=true]


我想知道....... 我想知道外面是否有比我更信任我的男人。
[cpg]

蘭丸大人和光秀大人是女性。
[cpg]

[OnName num="vassal_A"]
所以，我想請你幫個忙。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

因此，我已經被安排到......
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="sNobunaga007"]
[OnName num="nobunaga"]
'一個繼承人。我也要考慮這個問題嗎？
[cpg cn=true]


[OnName num="keitarou"]
'...... 是。
[cpg cn=true]


我只能給出一個愚蠢的回答。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="sNobunaga008"]
[OnName num="nobunaga"]
'但如果對方是景太郎，我就不介意了。
[cpg cn=true]


[OnName num="keitarou"]
但...... 信長大人。
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="sNobunaga009"]
[OnName num="nobunaga"]
你不必認真遵守你說的或做的任何事情。可以說，我不能生孩子。
[cpg cn=true]


...... 信長大人似乎仍然不打算生孩子。
[cpg]


;//ブラックアウト

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『街』（昼）******************************************************

第二天。不知怎的，我在房間裡坐不住了，我走到了城堡鎮。
[cpg]

戰國時期的一個城鎮。它與今天的人不同。
[cpg]

它與魅力無關，目之所及，建築都很低矮。
[cpg]

不過，還是有人類的生命。我想這是信長大人的職責，要保護這個。
[cpg]

還是說這也是我的角色？當我邊走邊想的時候，我看到......
[cpg]


;//========================================
;//●ＣＧ（紹介ページヒロイン４のＣＧ）ev_
;//人物１：ヒロイン４　服装１：着衣
;//場所　：城下町
;//時間　：昼
;//備考　：可能であれば背景を足してください
;//========================================


[free time=1000]
;**【ＣＧ】 ev_00_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]



我看到了光秀大人。蘭丸大人也在附近。
[cpg]


[VOICE f="Mituhide025"]
[OnName num="mitsuhide"]
看來信長大人最近對你很有好感。
[cpg cn=true]



[VOICE f="Ranmaru074"]
[OnName num="ranmaru"]
'嗯，是的。 '嗯，不只是最近，而是一直都在。你吃醋了嗎？
[cpg cn=true]


我決定從後面聽一聽這段對話。
[cpg]


[VOICE f="Mituhide026"]
[OnName num="mitsuhide"]
不，我只是覺得如果我不像你那樣思考，我會很高興。
[cpg cn=true]



[VOICE f="Ranmaru075"]
[OnName num="ranmaru"]
'......，你是什麼意思？
[cpg cn=true]


從外面看，這是一場為同一個人服務的兩個人之間的小規模衝突。
[cpg]

但對我來說，誰知道未來，這聽起來是完全不同的細微差別。
[cpg]

我當時無法開口說話。
[cpg]

...... 但話說回來，光秀大師也會到茶館這樣的地方來。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

[OnName num="keitarou"]
......"
[cpg cn=true]


從外面看城堡。小鎮沒有燈光，所以月亮和星星都格外美麗。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga215"]
[OnName num="nobunaga"]
睡不著嗎？景太郎。
[cpg cn=true]


[OnName num="keitarou"]
...... 信長大人也是？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga216"]
[OnName num="nobunaga"]
'不。我在思考未來。我已經投入了太多的工作，所以我需要休息一下'。
[cpg cn=true]


信長大人可能正在考慮如何從現在開始治理日本。
[cpg]

我甚至無法想像。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga217"]
[OnName num="nobunaga"]
我們從現在開始需要思考的問題，與我們為贏得戰爭而需要採取的措施不同。你永遠不知道誰會恨你。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga218"]
[OnName num="nobunaga"]
甚至我也害怕死亡。接下來會發生什麼......
[cpg cn=true]


她並沒有在表情上表現出來。不過，我還是能看出她很擔心。
[cpg]

[OnName num="keitarou"]
只要我在這裡，信長大人就會保護你。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga219"]
[OnName num="nobunaga"]
'啊。我也會保護你。
[cpg cn=true]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]


[VOICE f="Nobunaga220"]
[OnName num="nobunaga"]
'......，不要在這裡被人看到。
[cpg cn=true]



[SE f=se027]
;//【ＳＥ】『茂みを歩く』

我被信長大人帶進了森林灌木叢。
[cpg]


;//========================================
;//●ＣＧ（接近してキスをする）ev_07
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：森の茂み
;//時間　：夜
;//========================================



[BGM f="bg_09"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]



;//移植前シーンカット

進入森林灌木叢後，她正要吻我的嘴。
[cpg]


[VOICE f="sNobunaga010"]
[OnName num="nobunaga"]
'Chuu......, nn.
[cpg cn=true]


當我在撫摸她時，我不能再高興了。
[cpg]

我不需要別的東西。如果我不能回到原來的時間，我也不在意。
[cpg]

我真希望這段時間能永遠持續下去。
[cpg]


;**【ＣＧ】 ev_07_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNobunaga011"]
[OnName num="nobunaga"]
我希望......，與你生孩子。 "
[cpg cn=true]


不過，當她這麼說時，我還是很猶豫。
[cpg]

如果你在這個時間段和她有了孩子，你將最終無法返回。
[cpg]

[OnName num="keitarou"]
'這是......
[cpg cn=true]



[VOICE f="sNobunaga012"]
[OnName num="nobunaga"]
'......，你不必現在就給我一個答案。
[cpg cn=true]


我採取了相信信長大人的話的形式。
[cpg]

這種關係仍將在模糊中繼續下去。
[cpg]


;//移植前シーンカット

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『森の中』（夜）******************************************************

那是一段可愛的時光。我覺得我已經沒有多少時間了。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga262"]
[OnName num="nobunaga"]
'我們是否應該盡快回去，......，現在是什麼時候？
[cpg cn=true]


不過，我們還是互相尋找對方，以至於忘記了時間。
[cpg]

我可以為她做什麼？
[cpg]

我可以防止即將發生的事情嗎？
[cpg]


;//==============================

*select03_end|奧克哈紮馬之戰

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

然後。壞消息傳到我們這裡。
[cpg]

信玄大人非常虛弱。
[cpg]

她患有肺結核。一個在這個時代無法治癒的疾病。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

蘭丸大人和我奉信長大人之命前往信玄大人居住的城堡。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru076"]
[OnName num="ranmaru"]
'你變得更強壯了，是嗎？
[cpg cn=true]


[OnName num="keitarou"]
我已經開始習慣了.......
[cpg cn=true]


蘭丸大人的催促越來越少，也許在某種程度上認可了我的努力。
[cpg]

我什至懷念那些日子。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru077"]
[OnName num="ranmaru"]
然而，那個信玄大人。她是無敵的，似乎是不朽的。
[cpg cn=true]


[OnName num="keitarou"]
'我想這是真的，沒有人能夠戰勝疾病。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru078"]
[OnName num="ranmaru"]
'...... 是這樣的嗎？我很奇怪地感到孤獨。
[cpg cn=true]


[OnName num="keitarou"]
'這不是一個好兆頭。你還不應該這麼說'。
[cpg cn=true]


蘭丸大人看起來真的很孤獨。
[cpg]

我想，他和信玄大人一定認識很久了。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

山路沒有像以前那樣困擾我了。
[cpg]

我已經經歷了比我的份額更多的shuraku。
[cpg]

然後，通過持續的山路，......
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_01_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（夜）******************************************************

我們來到了城堡鎮。我就快到信玄大人那裡了。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru079"]
[OnName num="ranmaru"]
...... 信玄大人可能已經睡著了。 "
[cpg cn=true]


於是決定明天去信玄大人那裡。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（朝）******************************************************

第二天早上。信玄大人的臉色比我們之前見到他時還要蒼白。
[cpg]

他躺在地上，呼吸緩慢。他可能已經病得起不來了。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Singen069"]
[OnName num="shingen"]
'你讓我很擔心。如果我再強壯一點就好了。 "
[cpg cn=true]


信玄大人比我想像的還要虛弱。就連蘭丸大人也是一副不忍直視的樣子。
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru080"]
[OnName num="ranmaru"]
'信玄大人，......，醫生是怎麼說的？
[cpg cn=true]


[FACE method="shake_4" pos="2/5"]

[VOICE f="Singen070"]
[OnName num="shingen"]
'他們說他撐不了多久了。他無法停止咳嗽。 ......
[cpg cn=true]


蘭丸大師眼裡含著淚水。如果信長大人知道這件事，一定會很鬱悶。
[cpg]

然後，信玄大人拉著我的手。那是一隻出乎意料的冰冷的手。
[cpg]

[FACE method="bow_4" pos="2/5"]

[VOICE f="Singen071"]
[OnName num="shingen"]
'信長......，她是.......'
[cpg cn=true]


[OnName num="keitarou"]
'這是什麼？　是要告訴信長大人嗎？
[cpg cn=true]


[FACE method="bow_6" pos="2/5"]

[VOICE f="Singen072"]
[OnName num="shingen"]
不要讓她一個人呆著。如果她不能快樂，我也不能死。
[cpg cn=true]


信玄大人在說出他對信長大人的愛時，顯得很苦惱。
[cpg]

這與其說是身體上的痛苦，不如說是精神上的痛苦。
[cpg]

她可能害怕這樣死了，就不知道信長大人會怎麼樣了。
[cpg]

[FACE method="shake_6" pos="4/5"]

[VOICE f="Ranmaru081"]
[OnName num="ranmaru"]
'別擔心。信玄大人不會死。 "
[cpg cn=true]


[FACE method="change_2" pos="2/5"]

[VOICE f="Singen073"]
[OnName num="shingen"]
 蘭丸。你真是太善良了。支持信長。
[cpg cn=true]


蘭丸大人終於流下了眼淚。
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

就在第二天晚上，她去世了。我和蘭丸大人都在場。
[cpg]

當時，蘭丸大人像個孩子一樣哭泣。
[cpg]

我在想我應該對信長大人說些什麼。 ......
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

我們按原路返回。我在想和蘭丸大人一樣的事情。
[cpg]

我不想看到信長大人情緒低落。
[cpg]

但我不能不告訴他真相。 ......
[cpg]


[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

晚上，當我們安營扎寨時，我被蘭丸大人的聲音吵醒了。
[cpg]

[OnName num="keitarou"]
'...... 蘭丸大人。
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru082"]
[OnName num="ranmaru"]
'什麼？我沒有哭'。
[cpg cn=true]


天太黑看不清楚，但我覺得蘭丸大人在哭。
[cpg]

那麼，也許喚醒我的聲音也是一個啜泣的聲音。
[cpg]

...... 這是一個人們的生活比較輕鬆的時候嗎？會不會相當重，只有一個區別？
[cpg]

對我來說，信長大人的生命是不可替代的。
[cpg]

信玄大人的死讓我想起了即將到來的事情。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

然後，我走出山路：......
[cpg]

很久以來，我第一次回到了信長大人的地方。
[cpg]

僅此一點就使我感到有些欣慰。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

我正在去找信長大人的路上，準備告訴他一切。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Nobunaga263"]
[OnName num="nobunaga"]
'我明白了。信玄已經死了？
[cpg cn=true]


信長大人的眼睛是渾濁的。我找不到任何話可以說。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga264"]
[OnName num="nobunaga"]
'為了她，我必須活下去。
[cpg cn=true]


[OnName num="keitarou"]
'是的。如果信長大人也死了，我就.......'
[cpg cn=true]


信長大人看起來有點驚訝。
[cpg]

[FACE method="change_5" pos="2/3"]

[VOICE f="Nobunaga265"]
[OnName num="nobunaga"]
你為什麼這麼說？到目前為止，我還沒有得過任何嚴重的疾病。
[cpg cn=true]


[OnName num="keitarou"]
'......，這是真的，但是......'
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga266"]
[OnName num="nobunaga"]
'你不必擔心。我將在太陽底下，不是嗎？　還是你在隱瞞什麼？
[cpg cn=true]


我無法回答，不知道歪曲歷史是否真的是個好主意。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

城堡內。在走廊裡，我遇到了蘭丸大師。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru083"]
[OnName num="ranmaru"]
'我都告訴你了，不是嗎？我告訴信長大人.......'
[cpg cn=true]


[OnName num="keitarou"]
'是的。
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Ranmaru084"]
[OnName num="ranmaru"]
我明白了。我不能告訴他。我又要哭了'。
[cpg cn=true]


蘭丸大人在自嘲中這樣說。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru085"]
[OnName num="ranmaru"]
'但是謝謝你.......自從你來之後，信長大人已經改變了很多。
[cpg cn=true]


[OnName num="keitarou"]
是這樣嗎，......？ "
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru086"]
[OnName num="ranmaru"]
'他是一個更冷酷的人，除了他自己的成功之外，對任何事情都不貪婪。但現在他不同了，......，而且更親切。 "
[cpg cn=true]


我不明白，蘭丸大人是比我更看重信長大人的人。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru087"]
[OnName num="ranmaru"]
'我認為他可能和其他人一樣貪婪，希望被人們喜歡，......，雖然我不能說什麼好話。
[cpg cn=true]


蘭丸大人似乎在用她自己的方式思考信長大人。
[cpg]

她甚至可能在想，她的心態變化可能會在未來影響日本。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru088"]
[OnName num="ranmaru"]
'我喜歡老信長大人，但我更喜歡現在的信長大人。我得感謝你'。
[cpg cn=true]


蘭丸大人似乎在感謝我。
[cpg]

[OnName num="keitarou"]
'蘭丸大人也變了。我想他更多的是在嫉妒我。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru089"]
[OnName num="ranmaru"]
我不喜歡你，但我也不喜歡你。除了信長大人，我沒有別的人了。
[cpg cn=true]


我想我們都認為，除了為信長大人服務，沒有其他辦法。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru090"]
[OnName num="ranmaru"]
你和我有點像，不是嗎？
[cpg cn=true]


我第一次見到她時，她的表情與第一次見到她時不同。
[cpg]

他們看起來相當自信。這也不僅僅是一種相似性。
[cpg]

我們可以稱他們為戰友，還是說這種關係不止於此？
[cpg]

我想了想，怎麼......，我不能這麼輕易地說出來。
[cpg]

[OnName num="keitarou"]
'......，也許我們是。
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

我們互相凝視了一會兒。
[cpg]

蘭丸大人現在不能告訴我，他對我沒有任何想法。
[cpg]

但這並不意味著你不能如此輕易地觸摸它們。
[cpg]

而且我知道這裡的一個詞有很大的分量。
[cpg]

我不能粗心地推開她，也不能把她拉近。
[cpg]

如果我在這裡說一些接受她的話，我很可能會做......，因為它是的東西。
[cpg]

我們都感覺到了這一點，但不能說什麼。
[cpg]


;//※ストーリーが分岐
;//　稲生の戦いで勝利していた場合のみ、ヒロイン１ルートへ
;//　稲生の戦いで敗北していた場合のみ、ヒロイン５ルートへ


[if exp={getFlagValue("Selectflg2") == 1 }]
[jump target="*root_1"]
[endif]

[jump target="*root_5"]


*root_1
[jump storage="ep003.ks" target="*start"]


*root_5
[jump storage="ep004.ks" target="*start"]


*select03_lose
*root_4
[jump storage="ep005.ks" target="*start"]


