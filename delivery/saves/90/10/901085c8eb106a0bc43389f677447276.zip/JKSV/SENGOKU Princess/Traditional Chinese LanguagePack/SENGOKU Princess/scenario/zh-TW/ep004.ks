
*start

;//==============================
;//稲生の戦いで敗北していた場合

*root_5|吸引了志同道合的人

;#################################################
*Ep004|'我們互相吸引，我們很相似。
;#################################################

[SCENE id=4]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru112"]
[OnName num="ranmaru"]
'嘿。景太郎。
[cpg cn=true]


[OnName num="keitarou"]
怎麼了，......？ "
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru113"]
[OnName num="ranmaru"]
我一直都在嫉妒你。信長大人喜歡你。
[cpg cn=true]


[OnName num="keitarou"]
是這樣的嗎？
[cpg cn=true]


但我已經意識到了這一點。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru114"]
[OnName num="ranmaru"]
我一直在想。我怎麼能讓你離開信長大人呢？ "
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

[SE f=se014]
;//【ＳＥ】『地面歩く』

說著，蘭丸大人帶著我走出了城堡。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru115"]
[OnName num="ranmaru"]
我不認為我有任何其他選擇。這並不是我想做的。
[cpg cn=true]


[OnName num="keitarou"]
你在說什麼呢？　蘭丸大師。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="sRanmaru001"]
[OnName num="ranmaru"]
我不打算愛上你。我不會愛上你的，蘭丸大人。
[cpg cn=true]

[STOPBGM]

[FG f="CHA05_p5_01_a.ui" method="change_2"  pos="2/3" time=1000]
說著，蘭丸大人走到我面前，親吻了我.......。
[cpg]


;//移植前シーンカット
;//【ＢＧ】『城＿縁側の廊下』（夜）

[FACE method="change_6" pos="2/3"]


[VOICE f="sRanmaru002"]
[OnName num="ranmaru"]
搞什麼鬼？不要做這種表情。
[cpg cn=true]


我們分開嘴唇後，她看起來有點尷尬。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我在自己的房間裡，有點困惑，這時蘭丸大人走到我身邊。
[cpg]

為信長大人服務是我的全部工作。這可能沒有錯。
[cpg]

但如果蘭丸大人也是這樣，也許我們互相吸引是很自然的。
[cpg]

最後，我想這是關於我做什麼和我想做什麼。 ......
[cpg]

我有點糾結，不知道該不該順著蘭丸大人的意思去做。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

有一天，我被信長大人叫住，走向他的房間。
[cpg]

在那裡，蘭丸大人也在，氣氛變得很微妙。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Nobunaga591"]
[OnName num="nobunaga"]
'怎麼了，你們兩個。你們的臉都紅了。
[cpg cn=true]


[OnName num="keitarou"]
'不，不。沒有什麼。
[cpg cn=true]


[FACE method="shock_3" pos="4/5"]
我第一次見到她時，她有點生氣。
[cpg]

[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga592"]
[OnName num="nobunaga"]
'......，好了，這就對了。我希望你們兩個會比以前更努力工作。我希望你們兩個比以前更努力地工作。 "
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

然後我被蘭丸大人帶到了她的房間。
[cpg]

她問我要做什麼。換句話說，她想知道......，我是否會和某人在一起。
[cpg]

[OnName num="keitarou"]
'那是出乎意料的。即使你這麼說'。
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru140"]
[OnName num="ranmaru"]
'這很好。只要回答我'。
[cpg cn=true]


她似乎無法直視我的眼睛。硬幣的另一面是，這是她非常想听到的東西。
[cpg]

[OnName num="keitarou"]
現在，為信長大人服務是最重要的。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru141"]
[OnName num="ranmaru"]
......真的很像對方。也許這就是我們被對方吸引的原因。
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

然後蘭丸大人走過來。
[cpg]


[VOICE f="Ranmaru142"]
[OnName num="ranmaru"]
信長大人和我都是女人。但和你在一起，我們可以有...... 的孩子。
[cpg cn=true]


[OnName num="keitarou"]
'......，你對每個人都這麼做？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="sRanmaru003"]
[OnName num="ranmaru"]
不可能。沒有人知道這件事。
[cpg cn=true]



;//ブラックアウト

;//========================================
;//●ＣＧ（立っているヒロイン。目を閉じてキスを待つ）ev_14
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="sRanmaru004"]
[OnName num="ranmaru"]
...... 我還是不怎麼好，是嗎？
[cpg cn=true]


我想知道....... 當然，比正常情況下更積極一些？
[cpg]

[OnName num="keitarou"]
即使那是真的，我也認為蘭丸大人是個可愛的人。
[cpg cn=true]



[VOICE f="Ranmaru168"]
[OnName num="ranmaru"]
'你再說一遍，......，這種事。
[cpg cn=true]


;**【ＣＧ】 ev_14_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1000]


她這樣說，閉上眼睛，等待我吻她。
[cpg]

我不能就這樣算了，所以我把嘴唇湊過去。
[cpg]


[VOICE f="sRanmaru005"]
[OnName num="ranmaru"]
'......'
[cpg cn=true]



;//移植前シーンカット

;//ブラックアウト

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


之後，蘭丸大人和我談到了未來。
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru169"]
[OnName num="ranmaru"]
'我們會比以前更忙。
[cpg cn=true]


[OnName num="keitarou"]
'我相信我們會的。我對政治一無所知。
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru170"]
[OnName num="ranmaru"]
景太郎應該一點一點地學習。信長大人也希望如此。
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
在我們交談時，我看到信長大人在遠處。
[cpg]

[FACE method="shake_6" pos="2/3"]
蘭丸大人的臉變紅了。看來他仍然喜歡她。
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="4/5" time=800]

[VOICE f="Nobunaga593"]
[OnName num="nobunaga"]
'你這傢伙。我聽說你們倆這些天相處得很好。
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]

[VOICE f="Ranmaru171"]
[OnName num="ranmaru"]
'是的!　我對信長大人很忠誠。
[cpg cn=true]



[FACE method="bow_2" pos="2/5"]
信長大人笑了起來。我猜他認為她喜歡他是理所當然的。
[cpg]

我想了想。我為信長大人服務，但最終我沒有站在戰場上。
[cpg]

如果受信長青睞的不是自己，那麼站在戰場上的就是蘭丸了。
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga594"]
[OnName num="nobunaga"]
從現在起，我將要求你為我做很多工作。我請求你的合作。 "
[cpg cn=true]

[free time=1000]
信長大人說完就走了。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Ranmaru172"]
[OnName num="ranmaru"]
信長大人，你今天也很漂亮。 ......。
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


我想了一會兒，陷入了沉默。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru173"]
[OnName num="ranmaru"]
這到底是什麼？你那張臉是什麼意思？
[cpg cn=true]


[OnName num="keitarou"]
蘭丸大人是如何看待信長大人的？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru174"]
[OnName num="ranmaru"]
'嗯，我喜歡他多於我可以說的......。我甚至不打算大聲說出來。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

然後是晚上。光秀大人來拜訪我的房間。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide043"]
[OnName num="mitsuhide"]
景太郎先生。你要去睡覺了嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
'不，...... 一點點就可以了。
[cpg cn=true]


[STOPBGM]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

光秀大人走近我，在我耳邊低聲說。
[cpg]

[BGM f="bg_08"]


[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide044"]
[OnName num="mitsuhide"]
最近，你越來越受到信長大人的青睞。
[cpg cn=true]


[OnName num="keitarou"]
'是的，好的，......
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide045"]
[OnName num="mitsuhide"]
我相信這意味著你將有一個光明的未來。你將來可能會成為一個大人物。
[cpg cn=true]


我第一次見到她時，她有點緊張，我有點害怕。試圖接近我。 ......
[cpg]

我不認為她的言行有什麼聯繫，但我想在她心中是一致的。
[cpg]

光秀大人想讓被信長大人看重的我站在她那邊。
[cpg]

[OnName num="keitarou"]
'不，請不要。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Mituhide046"]
[OnName num="mitsuhide"]
你為什麼拒絕？ "
[cpg cn=true]


[OnName num="keitarou"]
'你必須只和你真正喜歡的人做這些事情。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

聽到我的話後，光秀大人顯得有些失望。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


他立即如法炮製，這次我想去睡覺。 ......
[cpg]

[OnName num="nobunaga_vassal"]
景太郎大人。我可以談一下嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
這是什麼，......？　我已經很困了。
[cpg cn=true]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga595"]
[OnName num="nobunaga"]
什麼？　我已經很困了。
[cpg cn=true]


[OnName num="keitarou"]
是的，......，我也是。
[cpg cn=true]


信長大人的臣子們安排我被帶到信長大人的房間。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga596"]
[OnName num="nobunaga"]
你是什麼意思？你來找我，對嗎？
[cpg cn=true]


[OnName num="keitarou"]
'是的，但是......，那個...... 臣子說你在尋找織田家的繼承人。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="sNobunaga020"]
[OnName num="nobunaga"]
他問你？　你的負擔太重了。
[cpg cn=true]


我當然這麼想，但當信長大人告訴我時，我感到很羞愧。
[cpg]

[OnName num="keitarou"]
'但......，我有別的人愛。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga598"]
[OnName num="nobunaga"]
'你是說蘭丸。然後你可以像這樣回到你的房間。
[cpg cn=true]


[OnName num="keitarou"]
'我這麼說，但如果你現在回家，諸侯們會怎麼說......？
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga599"]
[OnName num="nobunaga"]
'我明白了。我不打算借給你被褥。　不過，我不能藉給你一個被褥。
[cpg cn=true]


[OnName num="keitarou"]
...... 我會的。
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我會的。 " 他沒有和信長大人睡在同一個被褥上，而是在榻榻米上過夜。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（朝）******************************************************

我早上醒來後意識到。這有點像后宮的情況。
[cpg]

這是一個夢幻般的情況，被三個人所追捧。
[cpg]

我處於一個在幕後控制世界的位置。我對此絲毫不感到高興。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga600"]
[OnName num="nobunaga"]
上午好。景太郎，你睡得好嗎？
[cpg cn=true]


[OnName num="keitarou"]
是的，嗯，我的......，身體很痛。
[cpg cn=true]



;//ブラックアウト

[window target=false]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の廊下』（朝）******************************************************

我走到走廊上，和信長大人一起走。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga601"]
[OnName num="nobunaga"]
今天又是個好天氣，不是嗎？
[cpg cn=true]


[OnName num="keitarou"]
是的，真的。
[cpg cn=true]


希望我們能一直談論這些其他的事情。
[cpg]

如果事情繼續下去，信長大人將在本能寺事件中死去。
[cpg]

即使我在那一刻想到蘭丸大人的感受，我也別無選擇，只能做一些事情。
[cpg]

我必須盡可能地避免改變未來，但這也是沒辦法的事。
[cpg]

為了避免信長大人的死亡，我別無選擇，只能告訴光秀大人他的背叛行為。
[cpg]

[OnName num="keitarou"]
信長大人。告訴光秀大人.......
[cpg cn=true]

[STOPBGM]

在我準備說 "小心 "的那一刻，我的身體發生了變化。
[cpg]


[transition target={true} rule="moya.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1000]

[BGM f="bg_08"]

[FACE method="shock_5" pos="2/3"]
我的身材變得半透明。我的皮膚變得透明，信長大人驚訝地看到我的身材。
[cpg]

當我不再說什麼時，這個數字又恢復了正常。
[cpg]

[OnName num="keitarou"]
'現在那是.......
[cpg cn=true]


畢竟，似乎如果我在這裡改變了未來，那將是一個我沒有出生的未來。
[cpg]

所以我從未來來，我要消失。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga602"]
[OnName num="nobunaga"]
'這算什麼魔術呢？　這也是未來的技術嗎？
[cpg cn=true]


信長大人這麼說，但我認為他其實是知道的。
[cpg]

我正試圖改變歷史，而我即將為此付出代價。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

[SE f=se014]
;//【ＳＥ】『地面歩く』

離開城堡的那一刻，我想到了未來。
[cpg]

我覺得，我無法改變信長大人在本能寺事件中自殺的未來。
[cpg]

如果我改變它，我不知道我這個應該來自未來的人將會發生什麼。事實上，發生了一個現象，我的身體變得透明。
[cpg]

但我想知道蘭丸大人會怎麼樣。
[cpg]

我記得本能寺事件發生時，蘭丸大人就在那裡，他應該是戰死了。
[cpg]

拯救信長大人和拯救蘭丸大人是不同的。
[cpg]

救出蘭丸大人，未來也不會有什麼不同。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

當我回到屋裡時，蘭丸大人正在房間裡等我。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru175"]
[OnName num="ranmaru"]
'你去哪裡了？我一直在等你。
[cpg cn=true]


[OnName num="keitarou"]
'對不起，......，我可以幫你嗎？
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
蘭丸大人在煩躁不安。她看著我，想說些什麼。
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（主人公に迫るヒロイン。服を着ているように修正してください）ev_36
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


然後蘭丸大人向我走來。
[cpg]


[VOICE f="Ranmaru176"]
[OnName num="ranmaru"]
你知道嗎？我畢竟是個瘋子。
[cpg cn=true]



[VOICE f="sRanmaru006"]
[OnName num="ranmaru"]
當我想到景太郎時，我無法控制自己。
[cpg cn=true]


[OnName num="keitarou"]
'......，我明白了。
[cpg cn=true]


但她仍然可能仍然愛著信長大人。
[cpg]


[VOICE f="Ranmaru178"]
[OnName num="ranmaru"]
我想知道我應該做什麼。在這樣的時候，我已經厭倦了對愛情和浪漫的困惑。
[cpg cn=true]


[OnName num="keitarou"]
'每個人都是這樣的。在這裡，我想告訴大家的是，在我們的生活中，有很多事情是需要我們去做的，比如說，在我們的生活中，有很多事情是需要我們去做的。
[cpg cn=true]



[VOICE f="Ranmaru179"]
[OnName num="ranmaru"]
...... 我想知道是否每個人都會對顏色感到興奮。我想這不僅僅是我。
[cpg cn=true]


我們再一次交換了吻，我不知道有多少次。
[cpg]


;//移植前シーンカット

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

即使你和她一起度過一個快樂的時刻，你的心也不會平靜。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru202"]
[OnName num="ranmaru"]
怎麼了？景太郎。你看起來很奇怪。 "
[cpg cn=true]


[OnName num="keitarou"]
'不，沒什麼。 ......
[cpg cn=true]


正確的未來是蘭丸大人被打敗並被殺死的那個。這意味著......
[cpg]

蘭丸大人要活著的事實意味著他不能在更大程度上參與歷史。
[cpg]

我想了想，不知道是否應該告訴蘭丸大人這件事。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

就在我們絞盡腦汁的時候，殺死信長大人和蘭丸大人的事件，即本能寺事件，肯定每分鐘都在逼近。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

我感覺好像晚上睡不著覺一樣。
[cpg]

由於無法入睡，我在城堡周圍散步。然後......
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Mituhide047"]
[OnName num="mitsuhide"]
'怎麼了？你在這個時候散步？ "
[cpg cn=true]


[OnName num="keitarou"]
'不，我只是睡不著。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide048"]
[OnName num="mitsuhide"]
'我明白了。 '我和你很相似。
[cpg cn=true]


光秀。這個人將殺死蘭丸大人和信長大人。
[cpg]

那麼，勸阻光秀大人會不會更好呢？
[cpg]

不，它不是。這就等於我告訴他們他們背叛的未來。
[cpg]

這些婦女可能沒有按照迄今為止的歷史事實行事，但在不同的層面上，未來將發生變化。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide049"]
[OnName num="mitsuhide"]
'看。月亮是那麼的美麗'。
[cpg cn=true]


[OnName num="keitarou"]
'......，這是真的。
[cpg cn=true]


光秀大人從未在我面前透露過他的真實本性。月亮很美，他說，簡直就是月亮。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『街』（昼）******************************************************

而有一天。我和蘭丸大人在城堡的小鎮上。
[cpg]


;//下記のセリフ、台本では「街」ですがシナリオでは「町」になっています

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru203"]
[OnName num="ranmaru"]
'鎮民們如此平和，這很好。這是我以前從未見過的'。
[cpg cn=true]


[OnName num="keitarou"]
'沒錯，......，因為戰爭的世界就要結束了。
[cpg cn=true]


但我知道我還沒有完成。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru204"]
[OnName num="ranmaru"]
你知道，有些人因為戰爭而不愛他們所愛的人。有些人可能被撕碎了。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru205"]
[OnName num="ranmaru"]
如果這些人能夠誠實地生活，我就別無他求了。 "
[cpg cn=true]


蘭丸大人說的事情讓我很難過。知道她正在經歷的事情，我不禁為她感到難過。
[cpg]

[OnName num="keitarou"]
......蘭丸大人。你應該珍惜與信長大人在一起的時間。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru206"]
[OnName num="ranmaru"]
'......?　你這話是什麼意思？
[cpg cn=true]


[OnName num="keitarou"]
'我的意思是，它是這樣的。我知道會發生什麼。
[cpg cn=true]


蘭丸大人似乎還是猜不透。
[cpg]

[OnName num="keitarou"]
'如果你喜歡信長大人，你最好大聲說出來。
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Ranmaru207"]
[OnName num="ranmaru"]
'那麼，你是什麼意思？
[cpg cn=true]


'我不能像這樣做。我別無選擇，只能推蘭丸大人的背。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夕方）******************************************************

我正在帶她回城堡。
[cpg]


;//下記のセリフ、台本では「街」ですがシナリオでは「町」になっています

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru208"]
[OnName num="ranmaru"]
突然間發生了什麼事？我甚至還沒有好好看過這個鎮子呢。
[cpg cn=true]


[OnName num="keitarou"]
我有更重要的事情要做。
[cpg cn=true]


[OnName num="keitarou"]
'你愛信長大人，對嗎？那麼就沒有時間猶豫或害羞了。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru209"]
[OnName num="ranmaru"]
你說我們沒有時間是什麼意思？信長大人已經佔領了這個國家，似乎不太可能再有什麼戰鬥了。 "
[cpg cn=true]


;//ブラックアウト
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

我們兩個人一起去了信長大人的房間。你需要做的第一件事是確保你對你所做的事情有充分的了解。
[cpg]

[OnName num="keitarou"]
'聽著。 '告訴信長大人你的感受。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="sRanmaru007"]
[OnName num="ranmaru"]
'為什麼，突然.......'
[cpg cn=true]


我催促她，有點強硬。
[cpg]


[window target=false]
[STOPBGM]
[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/5" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="4/5" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

[SE f=se025]
;//【ＳＥ】『ふすま開く』

[FACE method="change_7" pos="2/5"]

[VOICE f="Nobunaga603"]
[OnName num="nobunaga"]
'什麼？你們兩個人一起。
[cpg cn=true]


[OnName num="keitarou"]
蘭丸大人有話要對你說。
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]

[VOICE f="Ranmaru211"]
[OnName num="ranmaru"]
'嗯，等等，......，為什麼一定要現在？
[cpg cn=true]


我不能向蘭丸大人解釋一切。如果我告訴他時限已經臨近，他不會理解。
[cpg]

如果他真的明白，可能是改變未來的時候了。
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Nobunaga604"]
[OnName num="nobunaga"]
'怎麼了？　你想告訴我什麼呢？ "
[cpg cn=true]


信長大人看向蘭丸大人。蘭丸大人挺直了腰桿。
[cpg]

[FACE method="change_6" pos="4/5"]

[VOICE f="Ranmaru212"]
[OnName num="ranmaru"]
'啊，讓我看看...........信長大人。謝謝你一直以來把我留在你身邊。
[cpg cn=true]


[FACE method="shake_4" pos="2/5"]

[VOICE f="Nobunaga605"]
[OnName num="nobunaga"]
你想說什麼？你想要什麼？
[cpg cn=true]


[OnName num="keitarou"]
"......蘭丸大人。我不是一個粉絲。
[cpg cn=true]


我要給蘭丸大人打氣。蘭丸大人正在努力傳達他堆積的感情 ......
[cpg]

但最後一句話沒有說出來。
[cpg]

[FACE method="shock_4" pos="4/5"]

[VOICE f="Ranmaru213"]
[OnName num="ranmaru"]
'我......，想的是信長大人。
[cpg cn=true]

[FACE method="change_4" pos="4/5"]

[OnName num="keitarou"]
......"
[cpg cn=true]


漫長的沉默。是信長大人打破了它。
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga606"]
[OnName num="nobunaga"]
你想說你喜歡他嗎？
[cpg cn=true]


[FACE method="shock_4" pos="4/5"]

[VOICE f="Ranmaru214"]
[OnName num="ranmaru"]
不!　不，恐怕不行'。
[cpg cn=true]


蘭丸大人先聲奪人，急忙糾正了他。但是。
[cpg]

[FACE method="shake_6" pos="2/5"]

[VOICE f="sNobunaga021"]
[OnName num="nobunaga"]
'我很清楚這一點。你認為我是誰？ "
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]

[VOICE f="Ranmaru215"]
[OnName num="ranmaru"]
'Nah... ......'
[cpg cn=true]


蘭丸大人變紅了。看來，他早就意識到了這一點。
[cpg]

[FACE method="change_6" pos="2/5"]

[VOICE f="Nobunaga608"]
[OnName num="nobunaga"]
我不能再假裝視而不見了。我也想對你的感受作出回應。
[cpg cn=true]


信長大人似乎接受了他的想法。
[cpg]

[FACE method="change_2" pos="4/5"]
我很高興看到蘭丸大人的臉亮了起來。
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Nobunaga609"]
[OnName num="nobunaga"]
'但你突然願意坦白的意義何在？
[cpg cn=true]


[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru216"]
[OnName num="ranmaru"]
'景太郎說了一些我不明白的話，好像他沒有多少時間。 ......。
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
'嗯，'信長大人說，正在思索。
[cpg]

自然，我不能告訴她一切。
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga610"]
[OnName num="nobunaga"]
'那麼？　你想要什麼？　你想讓我做什麼？ "
[cpg cn=true]


[FACE method="shock_4" pos="4/5"]
信長大人這麼說的時候，蘭丸大人反應過來了。
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru217"]
[OnName num="ranmaru"]
我希望能留在信長大人的身邊。 ......
[cpg cn=true]


[OnName num="keitarou"]
然後就會和以前一樣了。
[cpg cn=true]


信長大人點頭表示同意。
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="sNobunaga022"]
[OnName num="nobunaga"]
這些年來，你為我服務得很好。至少現在，我想給你你想要的東西。
[cpg cn=true]


蘭丸大人的臉變紅了，他看起來好像想說什麼。
[cpg]

[FACE method="change_6" pos="4/5"]

[VOICE f="Ranmaru218"]
[OnName num="ranmaru"]
'好吧，那麼......，.......'
[cpg cn=true]


她接近信長大人。 '我可能已經打斷了你。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

我決定離開這個房間。我甚至沒有想過要在女孩之間闖蕩。
[cpg]

我想我至少可以快速瀏覽一下.......
[cpg]

說我實現了蘭丸大人的願望也不是不可以，......，但我還是不想。
[cpg]


;//移植前シーンカット

;//ブラックアウト
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（朝）******************************************************

還有後來的。信長大人問我這樣的問題。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga643"]
[OnName num="nobunaga"]
你為什麼派蘭丸來找我？ "
[cpg cn=true]


[OnName num="keitarou"]
為什麼你的意思是......？
[cpg cn=true]


我不能告訴你真相。我以為我是。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga644"]
[OnName num="nobunaga"]
我不能告訴你真相。如果是，請告訴我。
[cpg cn=true]


信長大人如願以償，極為敏銳。我不能談論它。
[cpg]

[OnName num="keitarou"]
'不，沒什麼。什麼都沒有。 "
[cpg cn=true]


我沒有欺騙他，而是撒了謊。但是。
[cpg]

[FACE method="shake_7" pos="2/3"]

[VOICE f="Nobunaga645"]
[OnName num="nobunaga"]
'你不能告訴我。當然，如果我不在我應該死的時候死，那可能是一個你不出生的未來。
[cpg cn=true]


真的，你可以看到一切。 ......，我想知道信長大人的感知力如何。
[cpg]


;//ブラックアウト

[window target=false]

[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

我帶著一顆不平靜的心回到我的工作中去。
[cpg]

今天，我被一個臣子教導政治知識。
[cpg]

有一天我可能會成為負責人......。
[cpg]


[window target=false]
[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

我知道那個未來永遠不會到來。
[cpg]

信長大人將在本能寺事變中自殺。那麼，一個和平的世界仍然是很遙遠的事情。
[cpg]

如果是這樣的話，我需要學習的不是政治，而是如何在當下生存。
[cpg]


;//ブラックアウト

即使我這樣想，也沒有人可以教我這樣做。
[cpg]

我不得不考慮如何自己走動。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

不管怎麼說，這是蘭丸大人。我必須獨自去救蘭丸大人。
[cpg]

我想這樣做是出於純粹的愛，也是因為我在考慮未來。
[cpg]

戰爭的世界並不那麼甜蜜，我可以獨自生活。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Nobunaga646"]
[OnName num="nobunaga"]
怎麼了，你發呆了。你在想什麼嗎？
[cpg cn=true]


[OnName num="keitarou"]
不，不。
[cpg cn=true]


在這兩個人之間，信長大人和蘭丸大人越來越親密。而這還不是全部。
[cpg]

[FACE method="change_6" pos="4/5"]

[VOICE f="Ranmaru247"]
[OnName num="ranmaru"]
謝謝你，景太郎。我有很長一段時間找不到勇氣。
[cpg cn=true]


我和蘭丸大人之間的距離也越來越近。
[cpg]

[OnName num="keitarou"]
'如果你愛她，你應該珍惜這種感覺。當你在.......'
[cpg cn=true]


我不經意間讓我的話語有了些許疏漏。
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru248"]
[OnName num="ranmaru"]
'......，你說的 "趁早 "是什麼意思？
[cpg cn=true]


[FACE method="change_1" pos="2/5"]

[VOICE f="sNobunaga023"]
[OnName num="nobunaga"]
'我想你的意思是，在夜裡。
[cpg cn=true]


信長大人欺騙了我，但這是一個很好的選擇。
[cpg]


;//移植前シーンカット

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

我知道我，或者說蘭丸大人的愛情的結局。
[cpg]

我無法改變未來。我已經知道，我將會消失。 ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

蘭丸大人還不知道真相。
[cpg]

我不能告訴她。這對她來說是一個太殘酷的事實。
[cpg]

當我走在路上思考時，我遇到了光秀大人。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide050"]
[OnName num="mitsuhide"]
'最近，你似乎對蘭丸很著迷。
[cpg cn=true]


光秀大人。我想知道她是否就是原來在這個城堡裡的那個人。
[cpg]

我想她可能在另一個城堡裡。我不太了解歷史事實是什麼，但......
[cpg]

不知何故，我覺得選擇權留給了我，她在這裡。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Mituhide051"]
[OnName num="mitsuhide"]
'餵？　你能聽到我嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
'哦，嗯，......，那是什麼？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide052"]
[OnName num="mitsuhide"]
'你是如此高高在上。你那麼喜歡蘭丸嗎？
[cpg cn=true]


[OnName num="keitarou"]
'...... 是的。
[cpg cn=true]


我甚至認為我討厭光秀先生。
[cpg]

我們要記住的是，你不能只看一眼照片就說："我不打算這樣做。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_09"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

有很多事情需要考慮。我們別無選擇，只能拯救蘭丸大人，但......。
[cpg]

這能使我不消失嗎？我還不知道。
[cpg]

除此之外，還有一個問題，就是在那之後我將如何與蘭丸大人一起度過我的時間。
[cpg]


[VOICE f="Ranmaru259"]
[OnName num="ranmaru"]
景太郎。你在嗎？
[cpg cn=true]


[OnName num="keitarou"]
是的。我可以幫你嗎？
[cpg cn=true]


[SE f=se025]
;//【ＳＥ】『ふすま開く』
[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]


蘭丸大人走進房間。然後，他有點臉紅，說。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru260"]
[OnName num="ranmaru"]
'嗯，謝謝你，.......
[cpg cn=true]


[OnName num="keitarou"]
'為了什麼？
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru261"]
[OnName num="ranmaru"]
我比以往任何時候都更快樂。景太郎為我安排了一切。
[cpg cn=true]


...... 蘭丸大人似乎還沒有意識到這個事實。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="sRanmaru008"]
[OnName num="ranmaru"]
'所以，......，我想感謝你。
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
說著，他走近我。
[cpg]

[OnName num="keitarou"]
'你確定嗎？　你要到我這裡來'。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru263"]
[OnName num="ranmaru"]
'沒有理由不這樣做。我不知道怎麼感謝你才好。
[cpg cn=true]


原本，他們是相似的。他崇拜信長大人，努力工作，幫助她接管國家。
[cpg]

;//ブラックアウト
;//移植前シーンカット
;//【ＢＧ】『城＿室内』（昼）

蘭丸大人可能相信......，情況會繼續保持下去。
[cpg]

但現實是，信長大人不會活得太久。
[cpg]


;//ブラックアウト

而蘭丸大人一定感覺到了我為什麼看起來如此沮喪。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru286"]
[OnName num="ranmaru"]
...... 嘿。信長大人會發生什麼？
[cpg cn=true]


蘭丸大人感覺到我的態度，就這樣問我。
[cpg]

我不知道該如何回答，但我告訴了我能說的。
[cpg]

[OnName num="keitarou"]
我不能告訴你一切。我不能告訴你一切，因為在我沒有出生的未來，它可能會發生變化。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru287"]
[OnName num="ranmaru"]
我有一種預感，但我不能告訴你。你是來自未來。
[cpg cn=true]


蘭丸大人似乎對這一點認識頗深。
[cpg]

我很沮喪，為了保護我自己，我不能告訴他們所有的信息。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru288"]
[OnName num="ranmaru"]
'畢竟，有人背叛了你？或者是一個意外？ "
[cpg cn=true]


[OnName num="keitarou"]
'......，我不能告訴你。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru289"]
[OnName num="ranmaru"]
'所以你的意思是你不能告訴我發生了什麼事？
[cpg cn=true]


而信長大人比蘭丸大人更聰明。她可能早就注意到了。
[cpg]

我為自己無能為力而感到遺憾。
[cpg]

[OnName num="keitarou"]
'我很抱歉。我無法控制自己。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru290"]
[OnName num="ranmaru"]
不要道歉。這不是你的錯。
[cpg cn=true]



[SE f=se024]
;//【ＳＥ】『通路歩く』

我們都陷入了沉默。這時，腳步聲走近了。
[cpg]


[free time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]


[VOICE f="Mituhide053"]
[OnName num="mitsuhide"]
怎麼了，有一張神秘的臉？
[cpg cn=true]


光秀大人來了，跟我們說話。蘭丸大人回答說，對即將發生的事情視而不見。
[cpg]

[FACE method="bow_7" pos="4/5"]

[VOICE f="Ranmaru291"]
[OnName num="ranmaru"]
'啊。光秀或......，你也是，這個時候你在這里幹什麼？ '
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Mituhide054"]
[OnName num="mitsuhide"]
'不要為我擔心。我想到的第一件事是，你們兩個人看起來很了不起。
[cpg cn=true]


[OnName num="keitarou"]
'......'
[cpg cn=true]


我想到的是，你們兩個人在一起的時候，我也是這樣想的。
[cpg]

我恨光秀大人，但我對她無能為力。
[cpg]

即使我可以讓她改變主意，也和事先告訴她一樣。
[cpg]

;//＠いずれにせよ信長様が長らく国を治めることになり、未来が変わる。
無論如何，信長大人將長期統治國家，未來將發生變化。
[cpg]

[FACE method="change_6" pos="2/5"]

[VOICE f="Mituhide055"]
[OnName num="mitsuhide"]
'不要看起來很害怕。你的眼睛看起來好像是在看你所珍視的人的複仇者'。
[cpg cn=true]


這並沒有錯。或者說，這正是它的本質。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

信長大人現在是一個人的世界。即使我們不能救她，也許我們至少可以救出蘭丸大人。
[cpg]

信長大人將不可避免地無法獲救。這將是歷史的一個重大改變。
[cpg]

因為他的性格，信長大人也很難作為一個普通人在某個地方生存。
[cpg]

但是蘭丸大人呢？
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

今天，我把所有的時間都用來學習政治，以便成為未來的軍閥。
[cpg]

即使你認為這是無用的......，你也無法向任何人解釋為什麼它是無用的。
[cpg]

我不能告訴任何人，信長大人的統治會被推翻。
[cpg]


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[OnName num="keitarou"]
'......，我今天很累。
[cpg cn=true]


我沒有時間做這個。但我們還應該做什麼？
[cpg]

我只是想不出讓信長大人活著的辦法。
[cpg]

如果是這樣的話，我們至少要救出蘭丸大人。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Ranmaru292"]
[OnName num="ranmaru"]
'幹得好。紮下太多的根是不好的。 "
[cpg cn=true]


我想知道他們是否是這樣看待我的。我對學習政治不屑一顧。
[cpg]

[OnName num="keitarou"]
'...... 蘭丸大人。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru293"]
[OnName num="ranmaru"]
怎麼了，......，你那張神秘的臉？
[cpg cn=true]


[OnName num="keitarou"]
'我只想讓你快樂。我似乎無法擁有這一切。
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Ranmaru294"]
[OnName num="ranmaru"]
這就是故事。會不會有一個大事件？
[cpg cn=true]


就連蘭丸大人也顯得有些愁眉苦臉。
[cpg]

你一定覺得很沮喪，因為你無法從我嘴裡套出故事。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="sRanmaru009"]
[OnName num="ranmaru"]
'......，讓我們暫時忘掉它吧。只要你在我身邊，我就不想要別的東西。
[cpg cn=true]


[OnName num="keitarou"]
我不這麼認為。我覺得你也喜歡信長大人。 "
[cpg cn=true]


我第一次看到她的時候，我覺得她有點花花腸子。還有。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru296"]
[OnName num="ranmaru"]
'不要對我吝嗇。
[cpg cn=true]


他只是說。是的，這是件不必要的事。 ......。
[cpg]


;//ブラックアウト


蘭丸大人可能認為，我和信長大人都很重要。
[cpg]

我仍然認為鼓勵蘭丸大人的懺悔並不是一個錯誤。
[cpg]

在結合之前就死去並被分開，這太殘酷了。
[cpg]

;//移植前シーンカット
;//【ＢＧ】『城＿室内』（夜）
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

我再一次證實了我的內心感受。
[cpg]

我只想拯救她。這就是全部。
[cpg]


[FO pos="4/7" time=1000]
[WAIT time=1100]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru318"]
[OnName num="ranmaru"]
我想成為你的妻子。我想和你一起度過我的餘生。 ......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru319"]
[OnName num="ranmaru"]
在你的知識中，我也死了嗎？ "
[cpg cn=true]


如果我在這裡點頭，我真的會。
[cpg]

我沒有選擇，只能否認。我已經下定決心，她是我唯一會讓其活著的人。
[cpg]

[OnName num="keitarou"]
不，我只救蘭丸大人。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
蘭丸大人微微一笑，但她的眼神很悲傷。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru320"]
[OnName num="ranmaru"]
'......，我希望這些日子能永遠持續下去。
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
這句話似乎來自我的心底。我再次擁抱蘭丸大人。
[cpg]



[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru321"]
[OnName num="ranmaru"]
'別這樣，......，如果你現在擁抱我，你會想哭的。
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_09"]

;//【ＢＧ】『城＿室内』（朝）******************************************************

我們都睡著了，當天亮的時候，...... 蘭丸大人說。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru344"]
[OnName num="ranmaru"]
'...... 景太郎。現在可能不是說這個的時候，但......
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru345"]
[OnName num="ranmaru"]
如果你說我們沒有時間了，我必須告訴你一些事情。我現在想說的是，我很平靜。
[cpg cn=true]


[OnName num="keitarou"]
'......，這是什麼？
[cpg cn=true]


我有一些想法，我打算說什麼。
[cpg]


;//下記のセリフ、台本では
;//「あんたと結婚したい。あたしの夫になってくれ……景太郎」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru346"]
[OnName num="ranmaru"]
'做我的丈夫，...... 景太郎。
[cpg cn=true]


...... 在這個時代，有向女人求婚這種事嗎？
[cpg]

還是因為她仍然是個軍閥？
[cpg]

我們可能總是會有些不同。
[cpg]

如果我成為軍閥，我想我不可能馬上就像蘭丸大人那樣出色。
[cpg]

這就是為什麼我會用她的頭銜來稱呼她，這也是她向我求婚的原因，儘管.......。
[cpg]

[OnName num="keitarou"]
'謝謝你。你確定你想要我嗎？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="sRanmaru010"]
[OnName num="ranmaru"]
'不，不是的。它必須是你。
[cpg cn=true]



;//ブラックアウト

而我成為蘭丸大人的丈夫。
[cpg]

在保留對信長大人的愛的同時，蘭丸大人已經決定成為我的妻子。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

;//下記のセリフ、台本では
;//「めでたいことだな。蘭丸がついに結婚することになるとは」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="3/3" time=800]


[VOICE f="Nobunaga660"]
[OnName num="nobunaga"]
這是件幸福的事，不是嗎？
[cpg cn=true]



[FACE method="bow_1" pos="3/3"]

[VOICE f="Mituhide056"]
[OnName num="mitsuhide"]
是的，真的。蘭丸對信長大人忠心耿耿，所以我認為他將長期保持單身。
[cpg cn=true]


信長大人真誠地祝賀蘭丸大人。
[cpg]

但光秀大人有點諷刺。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru348"]
[OnName num="ranmaru"]
'啊，光秀，在你面前我很高興。光秀，我在你之前就已經讓你高興了。
[cpg cn=true]


蘭丸大人回答說，他挺起了胸膛。光秀大人聳了聳肩。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru349"]
[OnName num="ranmaru"]
'...... 所以，景太郎。我有話要對你說。
[cpg cn=true]


[OnName num="keitarou"]
它是什麼？
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
我想我有孩子了，"蘭丸用很小的聲音說。蘭丸大人用低沉的聲音說。
[cpg]

[FACE method="change_5" pos="1/3"]

信長大人驚訝了一會兒，然後笑了。
[cpg]

[FACE method="bow_2" pos="1/3"]

[VOICE f="Nobunaga661"]
[OnName num="nobunaga"]
'我明白了。對你有好處，你將成為一個母親。
[cpg cn=true]


她似乎和她一樣高興。
[cpg]

蘭丸大人在得到信長大人的祝賀後，一定處於夢幻狀態。
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Ranmaru351"]
[OnName num="ranmaru"]
'是的。我將把你作為信長大人的孩子來撫養。
[cpg cn=true]


[OnName num="keitarou"]
這有點...... 過分，不是嗎？
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru352"]
[OnName num="ranmaru"]
這意味著你也要做父親了，景太郎。你感覺到了嗎？
[cpg cn=true]


[OnName num="keitarou"]
不，......，還沒有，真的沒有。
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru353"]
[OnName num="ranmaru"]
我不這麼認為。我也還沒有感覺到。
[cpg cn=true]


[OnName num="keitarou"]
但即便如此，我也沒有想到你會說你是信長大人的孩子。
[cpg cn=true]


蘭丸大人微微一笑，回答道。
[cpg]

[FACE method="shake_2" pos="2/3"]

[VOICE f="Ranmaru354"]
[OnName num="ranmaru"]
這是一種感覺，這就是我的感覺。當然，我也愛你。
[cpg cn=true]


'你當然知道。儘管我知道，但當它被付諸於文字時，我感到很尷尬。
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

我和蘭丸大人在一起的時間就像沙子從我手中灑落一樣過去了。
[cpg]

自從她受孕以來，已經過去了四個月。她的腹部膨脹了。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

本野寺事件。我不知道信長大人佔領了這個國家之後，需要多長時間才能實現。
[cpg]

但是，如果蘭丸大人的生命有危險，我不能只是坐在那裡想。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru355"]
[OnName num="ranmaru"]
...... 你看起來像是在思考什麼。
[cpg cn=true]


[OnName num="keitarou"]
沒有，什麼都沒有。
[cpg cn=true]


;//移植前シーンカット

我必須把她從叛亂中救出來。
[cpg]

這是我們有朝一日一定要談的事情。
[cpg]

[OnName num="keitarou"]
蘭丸大人。能否給我一點時間？
[cpg cn=true]


當我用嚴肅的語氣說時，蘭丸大人也變得有些緊張。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru380"]
[OnName num="ranmaru"]
它是什麼？
[cpg cn=true]


[OnName num="keitarou"]
'......，這是關於未來。
[cpg cn=true]


[OnName num="keitarou"]
信長大人將在其中死去的事件將從現在開始發生。你將會被捲入其中。
[cpg cn=true]


蘭丸大人已經知道這一點。
[cpg]

不過，我還是忍不住說了出來。
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Ranmaru381"]
[OnName num="ranmaru"]
你是說你要在那裡救我？
[cpg cn=true]


[OnName num="keitarou"]
是的，歷史沒有什麼變化，我們只是生存......。我打算這麼做，但你願意嗎，蘭丸大人？ "
[cpg cn=true]


蘭丸大人很平靜，很鎮定，沒有瀕臨流淚。
[cpg]

她並不是沒有想過這個問題。事實上，她可能比我想得更多。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru382"]
[OnName num="ranmaru"]
在過去，我會說得不一樣。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru383"]
[OnName num="ranmaru"]
她可能會說她會和信長大人一起死。但現在我想和你有一個幸福的未來。
[cpg cn=true]


她似乎已經下定了決心。
[cpg]

我希望得到幸福。我不知道這樣的和平是否從現在開始就在等待著我，仍然......。
[cpg]

[OnName num="keitarou"]
'我明白。我也不會再猶豫了。 "
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Ranmaru384"]
[OnName num="ranmaru"]
'啊。我很抱歉到現在為止我一直都很煩惱。
[cpg cn=true]


[OnName num="keitarou"]
我不是在向你道歉，蘭丸大人。這也是我的問題。
[cpg cn=true]


在某些時候，我都快哭了。蘭丸大人用他的手指為我擦拭眼淚。
[cpg]

[FACE method="shake_2" pos="2/3"]

[VOICE f="Ranmaru385"]
[OnName num="ranmaru"]
'......，會沒事的。我們會沒事的。
[cpg cn=true]


;//ブラックアウト

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[SE f=se024]
;//【ＳＥ】『通路歩く』

;//蘭丸と信長の立ち絵は表示しないでください

有一天，我聽到蘭丸大人和信長大人的談話。
[cpg]




[VOICE f="Ranmaru407"]
[OnName num="ranmaru"]
'信長大人，......，關於有關的事情。
[cpg cn=true]


我聽到蘭丸大人的聲音從房間的方向傳來。我聽了。
[cpg]


[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="4/5" time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

[VOICE f="Ranmaru408"]
[OnName num="ranmaru"]
'看來，離別的時間已經很近了。你有他的消息嗎？
[cpg cn=true]


[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga662"]
[OnName num="nobunaga"]
'我沒有聽說，但他好像已經告訴我了。我有一個想法。
[cpg cn=true]


信長大人似乎並不害怕自己的死亡。
[cpg]

我想知道他怎麼會有這樣的心理狀態，但這似乎是事實。
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru409"]
[OnName num="ranmaru"]
'我很抱歉，.......我不能為你做任何事。
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga663"]
[OnName num="nobunaga"]
不要道歉。我沒有做錯什麼。 "
[cpg cn=true]


蘭丸大人正與信長大人流著淚交談。
[cpg]

[FACE method="change_2" pos="2/5"]

[VOICE f="Nobunaga664"]
[OnName num="nobunaga"]
這很有趣。蘭丸，到目前為止，沒有什麼能取代與你一起在這場戰爭中生存的日子......。
[cpg cn=true]


[FACE method="shock_4" pos="4/5"]

[VOICE f="Ranmaru410"]
[OnName num="ranmaru"]
...... 我也是。
[cpg cn=true]


蘭丸終於哭了出來，似乎認為自己終究不想失去信長大人。
[cpg]

我一直在聽他們說，沒有進去。
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru411"]
[OnName num="ranmaru"]
'信長大人。我應該怎麼做？　我不想失去景太郎和信長大人。
[cpg cn=true]


短暫的沉默。然後。
[cpg]

[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga665"]
[OnName num="nobunaga"]
'你仍然很虛弱。如果你想和他單獨生活在一起，那還不夠好。
[cpg cn=true]


信長大人平靜地說道。
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru412"]
[OnName num="ranmaru"]
'我很虛弱。 '沒有信長大人，我還是活不下去。
[cpg cn=true]


我覺得我不能留下來，但我知道我無論如何也不能改變未來。
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

末日開始了。一個巨大的變化即將到來。
[cpg]

我和蘭丸大人之間的關係將不會保持不變。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru413"]
[OnName num="ranmaru"]
...... 信長大人正在向本能寺進發。
[cpg cn=true]


[OnName num="keitarou"]
我明白了。 ......
[cpg cn=true]


我甚至不能說，信長大人會在那裡被出賣。但是。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru414"]
[OnName num="ranmaru"]
嘿，景太郎。最近，光秀的行為很怪異。 "難道是......"
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


在歷史上，蘭丸大人從未意識到叛亂的存在。
[cpg]

所以我認為我說的很多話已經產生了影響。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru415"]
[OnName num="ranmaru"]
如果你不在那裡，我也會死的，沒有什麼可炫耀的。 "
[cpg cn=true]


即便如此，蘭丸大人也只是這麼說。
[cpg]

他似乎無意於幫助信長大人。在這個過程中，你會發現，在你的生活中，有很多事情是你無法想像的。
[cpg]

[OnName num="keitarou"]
'蘭丸大人。我將保護你。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Ranmaru416"]
[OnName num="ranmaru"]
這是很自然的。如果你不這麼說，我選擇你就沒有意義了。
[cpg cn=true]


;//ブラックアウト
;//移植前シーンカット


命運的時刻終於來臨了。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

此後不久。
[cpg]

光秀大人的叛亂甚至被傳到了城堡裡。和......
[cpg]

信長大人在本能寺事變中自殺。
[cpg]

蘭丸大人在悄悄地哭。我相信你已經為此做好了準備，但即便如此，你仍然必須感到強烈的失落感。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru441"]
[OnName num="ranmaru"]
'從現在開始，我們應該如何生活？
[cpg cn=true]


[OnName num="keitarou"]
'如果我們要活過戰爭，我們應該跟隨秀吉或家康。 ......
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]

[VOICE f="Ranmaru442"]
[OnName num="ranmaru"]
我想知道是誰殺了光秀。誰殺了光秀？她和誰打了一架，或者她會接手嗎？ "
[cpg cn=true]


[OnName num="keitarou"]
'不。不，他應該和秀吉交手，而且輸了。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru443"]
[OnName num="ranmaru"]
那麼......，這就是我們應該求助的地方。讓我們馬上加入他們，我們不能自己去對抗他們。
[cpg cn=true]


蘭丸大人比以前更冷靜了。他沒有因為失去信長大人而心煩意亂。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

而我們決定與秀吉匯合。
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

當我們到達城堡時，蘭丸大人告訴我這樣的事情。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru444"]
[OnName num="ranmaru"]
'儘管發生了這種情況，我很高興我選擇了你。
[cpg cn=true]


蘭丸大人的眼睛在看向未來。我不可能是唯一被遺棄的人。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


此後的幾個月和幾天都在流逝。我覺得他們好像在慢慢地過去。
[cpg]

在我為信長大人報了仇之後，這一天到來了。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[SE f=se000]
;//【ＳＥ】『赤ちゃんの泣き声』

蘭丸大人正在微笑著給嬰兒餵奶。
[cpg]

我成了父親，蘭丸大人成了母親。
[cpg]

一切都不能停留在一個地方。
[cpg]

蘭丸大人似乎知道這一點。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru445"]
[OnName num="ranmaru"]
'當這個孩子長大了，愛上了，你知道。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru446"]
[OnName num="ranmaru"]
'我不希望那個未來，她可能會死，離開她所愛的人，你呢？
[cpg cn=true]


[OnName num="keitarou"]
'...... 是的。是的。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru447"]
[OnName num="ranmaru"]
'我將邊走邊編。光秀也是我的敵人，但這不是我必須打敗他的唯一原因。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru448"]
[OnName num="ranmaru"]
我希望未來每個人都能誠實地對待自己的愛情。什麼是......"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru449"]
[OnName num="ranmaru"]
如果我說我只想要和平，也許這就是我想要的一切。
[cpg cn=true]


[OnName num="keitarou"]
'不。我認為這是一個不可改變的事實'。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

她有堅強的意志。她比我堅強得多。
[cpg]

她在失去信長大人之前的那個軟弱的女友已經不復存在。
[cpg]


;//ブラックアウト


;//＠

;//ＥＮＤ　ヒロイン５ルート

[SCENE id=10]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="epend.ks" target="*start"]


