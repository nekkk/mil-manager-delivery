
*start

;//==============================
;//謙信の所へ潜入　二度音の鳴るマスを通った場合

*select04_lose|忠於信玄公。

*root_3|忠誠度受到考驗

;#################################################
*Ep007|忠誠度受到了考驗。
;#################################################

[SCENE id=7]


[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin003"]
[OnName num="kenshin"]
歡迎來到我的城堡。也許你是信玄的手下。 "
[cpg cn=true]


謙信不是唯一在那裡的人。除謙信外，其他士兵都站著保護她。
[cpg]

他們拿著劍。我們的武器不是他們的對手。
[cpg]

[OnName num="ninja"]
'該死的......！
[cpg cn=true]


她試圖拉回來，但是。
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin004"]
[OnName num="kenshin"]
'他們一定認為我們的武器不夠用了。我的手下告訴我們，忍者已經潛入了。
[cpg cn=true]


有士兵圍著我們轉，要把我們按倒。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

我們中的每一個人都被抓住了。一些忍者因為抵抗而被殺。
[cpg]

我也不例外。即使是現在，我也無法從監獄裡出來。
[cpg]

按照這種速度，我將被殺死或被折磨。或者兩者都有。
[cpg]

[OnName num="keitarou"]
'...... 不。沒有。 "
[cpg cn=true]


我必須不惜一切代價活著出去。這是我對信玄大人的承諾。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin005"]
[OnName num="kenshin"]
你很魯莽，是嗎？我們決不能被低估。
[cpg cn=true]


然後謙信就來了。我不由自主地站起來，用手抓住格柵。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin006"]
[OnName num="kenshin"]
'你有什麼遺言嗎？
[cpg cn=true]


我決定打出我剩下的唯一一張牌。
[cpg]

[OnName num="keitarou"]
'......，我一直在信玄大人身邊，我知道她有什麼計劃。
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Kensin007"]
[OnName num="kenshin"]
'我明白了。每個人都這麼說。我不認為我可以相信你說的話。
[cpg cn=true]


謙信不聽。
[cpg]

但我有辦法證明，我確實一直在信玄身邊。
[cpg]

[OnName num="keitarou"]
'我的名字是景太郎。這個名字聽起來很熟悉嗎？有可能是信玄大人敢於傳播謠言。 "
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin008"]
[OnName num="kenshin"]
'...... 景太郎。你是那個人嗎？
[cpg cn=true]


我也欠信玄大人的情。但現在，我必須把拯救自己的生命放在首位。
[cpg]

此外，如果他活著，他可能會再次見到信玄大人。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin009"]
[OnName num="kenshin"]
'我想最好是放棄對你的處決，就這一次。我聽說過一些傳言。
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

我在監獄裡度過了一個不眠之夜。
[cpg]

和我一起潛入的人都會被殺死。
[cpg]

這是很自然的，但我還是有些措手不及。
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿外観＿謙信』（昼）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

我很難入睡，我不知道自己是醒著還是睡著了。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin010"]
[OnName num="kenshin"]
'你好。景太郎先生。 "
[cpg cn=true]


[OnName num="keitarou"]
'......!'
[cpg cn=true]


但在一瞬間，我的睡意被吹散了。謙信已經出現了。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin011"]
[OnName num="kenshin"]
'你不需要這麼害怕。我已經決定相信你所說的。
[cpg cn=true]


謙信在監獄裡告訴我。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Kensin012"]
[OnName num="kenshin"]
'看來你的存在是有傳聞的。我不知道這些細節。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin013"]
[OnName num="kenshin"]
'顯然，你起初是和信長在一起。從那時起我就听說了你的事。
[cpg cn=true]


[OnName num="keitarou"]
你會幫助我們嗎？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin014"]
[OnName num="kenshin"]
'他們是不應該被保留生命的人。但如果殺了他，那就太可惜了。
[cpg cn=true]


[OnName num="keitarou"]
謝謝你，......."
[cpg cn=true]


各種各樣的想法都在我的腦海中閃現。
[cpg]

在感謝謙信的同時，我也會背叛信玄大人。我想知道這是否可以。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin015"]
[OnName num="kenshin"]
'但我還不能讓你出獄。你永遠不知道他何時會背叛你。
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我在沒有燈光的監獄里呆了一段時間。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

我不知道他什麼時候會殺我，但我知道他不會很快殺我。
[cpg]

我當時沒有心情。我不覺得自己還活著。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin016"]
[OnName num="kenshin"]
'這是個美好的夜晚。甚至月光也不能照到這個監獄。
[cpg cn=true]


[OnName num="keitarou"]
'......謙信大人.
[cpg cn=true]


我發現自己在叫她的名字。我再也不能說她只是一個敵人了。
[cpg]

[OnName num="keitarou"]
我不再是一個單純的敵人了。我不會跑掉。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Kensin017"]
[OnName num="kenshin"]
'你意識到你做了什麼嗎？　你進去的時候沒有想到你會被殺嗎？
[cpg cn=true]


我沒有什麼可說的。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin018"]
[OnName num="kenshin"]
'我已經告訴你很多次了，你不需要害怕。
[cpg cn=true]


[OnName num="keitarou"]
'......，你不可以。我被困在這樣的地方。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Kensin019"]
[OnName num="kenshin"]
'如果你想讓我離開這裡，這是一個交易。如果我把你從這裡弄出去，那就成交了。
[cpg cn=true]


[OnName num="keitarou"]
它是......
[cpg cn=true]


我迷路了。我已經迷失了方向，但現在唯一的生存之道可能就是背叛信玄大人。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin020"]
[OnName num="kenshin"]
你就不能至少告訴我們信玄接下來打算做什麼嗎？讓我們交換一下這個信息。
[cpg cn=true]


在這裡，說謊和說真話有很大區別。
[cpg]

我們能不能撒個大謊，等著信玄大人來救我們？ ......
[cpg]

謙信大人說。如果你服從我，我甚至會給你一個獎勵：.......
[cpg]

當然，這種話並不能改變我的忠誠。
[cpg]

然而，我的情緒卻在不斷波動。
[cpg]

如果謙信大人這麼說，我應該跟隨她嗎？
[cpg]

我甚至不知道'獎勵'這個詞是什麼意思。 ......
[cpg]

我為信玄大人撒謊嗎？我有兩個選擇：為了謙信大人的利益，說出真相。
[cpg]


;//■選択肢
[switch]
[case "說謊"]
	[swap]
	[jump target="*root_3_bad"]
[case "說出真相"]
	[swap]
	[jump target="*root_3_true"]
[endswitch]

1、說謊話
2，說實話。


;//==============================
;//１、嘘をつく

*root_3_bad|魯莽的忠誠。




[OnName num="keitarou"]
'......，信玄大人正在計劃一次突襲。而且我知道日期和時間。 "
[cpg cn=true]


經過一番思考，我崩潰了，撒了謊。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin021"]
[OnName num="kenshin"]
'是這樣的嗎？如果他計劃進行這樣的突然襲擊，......，那麼我們就反擊他。 "
[cpg cn=true]


我決定告訴他們一些與實際入侵計劃完全不同的事情，讓他們把城堡變薄。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Kensin022"]
[OnName num="kenshin"]
'謝謝你，告訴我這麼重要的事情。我應該獎勵你嗎？
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

他們還把我從監獄裡放了出來。
[cpg]

在一些士兵的包圍下，被謙信大人帶走，我很感動。
[cpg]


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[OnName num="keitarou"]
'......，哈哈......'
[cpg cn=true]


我終於被釋放了。當然，這個房間是有警衛的。
[cpg]

我又不能試圖逃跑。即便如此，我的感覺還是很不同。
[cpg]

緊張的氣氛鬆動了，我很久以來第一次睡得像泥巴一樣。 ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

在我意識到我所說的一切都是謊言之前，還需要一些時間。
[cpg]

或者說，戰爭有可能被顛覆，信玄大人將發動進攻。
[cpg]

如果那樣的話，我就完成了我作為一個忍者的角色。
[cpg]

我不知道是否會有那麼好的結果，但我賭的是這種可能性。
[cpg]


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

第二天晚上，謙信大人來看我。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin023"]
[OnName num="kenshin"]
'我們現在正準備攔截你們。如果我們贏得這場戰鬥，那將是對你的感謝。
[cpg cn=true]


謙信大人看起來好像不知道該不該相信我。
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（隣り合う二人。キスをする）ev_57
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_57_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Kensin024"]
[OnName num="kenshin"]
'你說過我會獎勵你的，不是嗎？
[cpg cn=true]


說著，他在我身上蹭了蹭。
[cpg]

[OnName num="keitarou"]
'謙信大人，......，什麼.......'。
[cpg cn=true]



[VOICE f="Kensin025"]
[OnName num="kenshin"]
'我真的很感謝你，我親愛的。當然，如果你說的是真的'。
[cpg cn=true]


她說。如果你說實話，我會給你一個獎勵。
[cpg]

看來，這即將成為現實。 ......。
[cpg]


[VOICE f="sKensin001"]
[OnName num="kenshin"]
'Chuu.......'
[cpg cn=true]


她的嘴唇碰到了我的嘴唇。
[cpg]


;//移植前シーンカット

;//ブラックアウト

;//移植前シーンカット

那個吻是有罪的。 ......
[cpg]

事實上，信玄大人不可能像他那樣進行攻擊。
[cpg]

謙信大人正試圖攔截一個不應該來的敵人。
[cpg]

同時，只要信玄大人能來......。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

並等待著他，但結果卻不是這樣的。
[cpg]

事實上，他們在任何時間內都沒有攻擊我們。
[cpg]

信玄大人既沒有被攔截，也沒有來救我。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin078"]
[OnName num="kenshin"]
'你是什麼意思？　你在撒謊嗎？ "
[cpg cn=true]


謙信大人問我。我急忙找了個藉口。
[cpg]

[OnName num="keitarou"]
'他一定以為我知道這些信息，所以敢於出賣我。
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Kensin079"]
[OnName num="kenshin"]
'......，這是有可能的，但那樣你就沒用了，不是嗎？
[cpg cn=true]


你說得很對。我怎麼能從這裡生存下去呢？
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

如果我什麼都不做，謙信大人就會放棄我。
[cpg]

如果發生這種情況，那麼將是死亡的時候。我別無選擇，只能在這種情況發生之前逃離這裡。
[cpg]

這是我甚至不需要考慮的事情。信玄大人是否願意幫助我，是在此之前的一個問題。
[cpg]

從我目前看到的情況來看，我知道守衛變化時的周期。
[cpg]

我將在那一刻嘗試逃跑。 ......
[cpg]

[OnName num="keitarou"]
......"
[cpg cn=true]



;//ブラックアウト

[SE f=se030]
;//【ＳＥ】『床走る』

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

我曾多次潛入城堡。我對這個城堡是什麼樣的結構有一些了解。
[cpg]

[OnName num="soldier"]
'等等!　嘿，誰在那裡？
[cpg cn=true]


儘管如此，這仍然是相當艱難的。畢竟，我沒有武器。
[cpg]

沒有武器，我就不能拿他們。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin080"]
[OnName num="kenshin"]
'我知道你會背叛我。你甚至為了保住性命而對我撒謊。 "
[cpg cn=true]


最後擋在我面前的是謙信大人。
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Kensin081"]
[OnName num="kenshin"]
'在這種情況下，你是魯莽而不是勇敢。我對你感到很失望。
[cpg cn=true]


我不能說什麼。我只是一想到將要發生的事情就感到害怕。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

我最終被抓住並被關進監獄。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

在監獄裡，我以為這一次我會被殺死。
[cpg]

沒有理由再讓我活著。我從未想過這會發生。 ......
[cpg]

儘管這是我應得的，但我回想起來，我應該從一開始就在信玄大師身邊工作。
[cpg]

或者說，我應該說實話，而不是撒謊。
[cpg]

現在想來，這一切都很不可能。
[cpg]


[window target=false]
[BG f="b_14_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（昼）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

中午時分，謙信大人來拜訪我。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin082"]
[OnName num="kenshin"]
'你感覺如何？
[cpg cn=true]


[OnName num="keitarou"]
'......'
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Kensin083"]
[OnName num="kenshin"]
'我在問你，你有什麼感覺，欺騙了別人。你為什麼不回答我？
[cpg cn=true]


我仍然保持沉默。
[cpg]


;//ブラックアウト

;//移植前シーンカット

;//ブラックアウト

;//========================================
;//●ＣＧ（主人公を足蹴にするヒロイン）ev_58
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：裸
;//場所　：牢の中
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_58_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]



;//移植前シーンカット


[VOICE f="sKensin002"]
[OnName num="kenshin"]
我可以不關心你的生活。
[cpg cn=true]



[VOICE f="sKensin003"]
[OnName num="kenshin"]
'你願意為忠誠而死嗎？　這就是你真正想要的嗎？
[cpg cn=true]


我試圖保持一顆堅強的心。
[cpg]

她說得沒錯，我對信玄大人的忠誠是我唯一的依靠。
[cpg]


[VOICE f="sKensin004"]
[OnName num="kenshin"]
'你願意為我工作嗎？
[cpg cn=true]


我保持沉默。我沒有回答。
[cpg]


[VOICE f="Kensin141"]
[OnName num="kenshin"]
'我很佩服你直到最後也不背叛我的精神，但這不會讓你活得太久。
[cpg cn=true]



[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

謙信先生離開後再也沒有來看過我。
[cpg]

最後，直到最後，他都沒有交待。
[cpg]

在監獄裡，我等待著信玄大人來救我。
[cpg]

但我也知道，川中島之戰沒有結果。
[cpg]

就這樣，我消失在歷史的陰影裡。 ......。
[cpg]


;//ブラックアウト

;//ＥＮＤ　バッドエンドルート

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="epend.ks" target="*back_title"]


;//==============================
;//２、本当のことを言う

*root_3_true|相信的心。



[OnName num="keitarou"]
"我明白。......我向你宣誓效忠。"
[cpg cn=true]


我決定轉向謙信大人，告訴他真相。
[cpg]

[OnName num="keitarou"]
我知道信玄大人會如何責備我，但我知道更重要的事情。
[cpg cn=true]


沒有理由再把它藏起來了。我甚至無法掩蓋我來自未來的事實。
[cpg]

[OnName num="keitarou"]
'我是來自未來。起初我是在信長大人那裡。 ......。
[cpg cn=true]


[FACE method="shake_5" pos="2/3"]

[VOICE f="Kensin142"]
[OnName num="kenshin"]
'這突然間是什麼？　沒有人會相信這樣的謊言，即使是為了生存。
[cpg cn=true]


[OnName num="keitarou"]
這是真的。我還知道，這次川中島之戰沒有結果。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin143"]
[OnName num="kenshin"]
...... 如果是真的，我想不出還有誰比你更有用。到目前為止，我沒有理由相信它。
[cpg cn=true]


我還向他透露了信玄大人的所有計劃。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我被放出了監獄，並把細節告訴了謙信大人。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin144"]
[OnName num="kenshin"]
'你是說他們從前面來了。然後我們就可以從我們這邊發動突然襲擊'。
[cpg cn=true]


[OnName num="keitarou"]
'...... 是的。我想是的。
[cpg cn=true]


我的話即將改變戰爭局勢。
[cpg]

從這一天起，我對待他們的態度也發生了變化。
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Kensin145"]
[OnName num="kenshin"]
'最終，我還是要背叛信玄。我已經等待這一刻很久了'。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（朝）******************************************************

我決定為謙信大人服務。
[cpg]

我告訴他真相，包括我的身份。謙信大人正試圖智取信玄大人的策略。
[cpg]

我從未被帶到過戰場。我猜這意味著他是一個有風險的人。
[cpg]

無論如何，我不得不與信玄大人反目。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夕方）******************************************************

川中島之戰並沒有以一次沖突而結束。
[cpg]

這次我加入謙信大人的行列，是一個不正常的現象。漫長的戰鬥可能在此結束。 ......
[cpg]

最後，這場戰鬥沒有得到解決。謙信大人沒有打敗信玄大人就回來了。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Kensin146"]
[OnName num="kenshin"]
'...... 困難，不是嗎？這是否意味著我們畢竟是不共戴天的敵人？ "
[cpg cn=true]


謙信大人看起來很失望。
[cpg]

我第一次了解到信玄的策略是唯一一次。
[cpg]

我認為這將是一個錯過的機會。
[cpg]

[FACE method="bow_6" pos="2/3"]

[VOICE f="Kensin147"]
[OnName num="kenshin"]
但你怎麼能在最後一刻決定站在我這邊？
[cpg cn=true]


[OnName num="keitarou"]
因為......，這是我必須要做的。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin148"]
[OnName num="kenshin"]
'你在站在我這邊時有任何猶豫嗎？
[cpg cn=true]


如果我在這裡點頭，我就是在撒謊。我閉口不談。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Kensin149"]
[OnName num="kenshin"]
我很高興他在所有的考慮後選擇了我。
[cpg cn=true]

[STOPBGM]

但後來，謙信大人收拾了我。
[cpg]

[BGM f="bg_09"]

[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin150"]
[OnName num="kenshin"]
'如果我說沒有神或佛，那真的是真的。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Kensin151"]
[OnName num="kenshin"]
所以，我比別人更看重信仰。 ...... 我也相信你所說的。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Kensin152"]
[OnName num="kenshin"]
你有一種奇怪的魅力。你有一種奇怪的魅力，以至於即使你告訴我你來自未來，我也會相信你。 "
[cpg cn=true]


[OnName num="keitarou"]
'......謙信大人'。
[cpg cn=true]


我不能就這樣迴避她。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Kensin153"]
[OnName num="kenshin"]
'被這樣面對著，你不覺得有什麼嗎？
[cpg cn=true]


[OnName num="keitarou"]
'不是我不覺得有什麼，而是......。
[cpg cn=true]


我為信玄大人服務。然而，我也愛著謙信大人，這實在是太懦弱了。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Kensin154"]
[OnName num="kenshin"]
'你在想你以前的領主，是嗎？但我認為你現在做的是最好的選擇。 "
[cpg cn=true]



;//ブラックアウト

;//========================================
;//●ＣＧ（主人公のすぐ前にいるヒロイン）ev_48
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_48_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]



;//移植前シーンカット

[OnName num="keitarou"]
'我不能......，突然愛上你。這很瘋狂。
[cpg cn=true]



[VOICE f="Kensin178"]
[OnName num="kenshin"]
'是的，它是。但如果是這樣的話，那麼我約你出去就是瘋了。
[cpg cn=true]


[OnName num="keitarou"]
不，......，我不是那個意思。
[cpg cn=true]



[VOICE f="Kensin179"]
[OnName num="kenshin"]
我知道。我知道我快瘋了。
[cpg cn=true]


謙信大人似乎真的很感激。
[cpg]

而且我的感覺似乎還不止於此。
[cpg]


[VOICE f="Kensin180"]
[OnName num="kenshin"]
我想我是被你吸引了。以及你背叛信玄的事實。 ......
[cpg cn=true]



[VOICE f="Kensin181"]
[OnName num="kenshin"]
'你有一種不屬於這個世界的氣息。他不像其他男人'。
[cpg cn=true]


...... 這一點是毫無疑問的。我不是這個時期的人。
[cpg]


;//ブラックアウト

;//移植前シーンカット

[window target=false]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

不過，我還是想知道，我這樣做是否正確。
[cpg]

可能還有其他崇拜謙信大人的諸侯。如果她像她一樣美麗，他們可能會被她吸引，即使他們不是諸侯。
[cpg]

當我拋開這些人，說出我對....... 的擔憂時
[cpg]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin203"]
[OnName num="kenshin"]
'你不需要擔心這個問題。
[cpg cn=true]


這位謙信大人的女士回答說。
[cpg]

[OnName num="keitarou"]
'即使你這麼說，我還是......，要讓你吃醋。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="sKensin005"]
[OnName num="kenshin"]
'你不喜歡我是因為我會讓你吃醋？
[cpg cn=true]


......，是的，這是正確的。這就是我應該做的，照顧這種感覺嗎？
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（昼）******************************************************

[SE f=se019]
;//【ＳＥ】『剣戟』

然後，謙信大人和信玄大人再次發生衝突。
[cpg]

我不在那裡。這意味著謙信大人還沒有完全信任我。
[cpg]

謙信大人是信玄大人戰略的支持者。如我所料，這次也沒有解決。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿謙信』（夕方）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Kensin205"]
[OnName num="kenshin"]
'堅不可摧是這個詞的意思，不是嗎？另一方可能也在想同樣的事情。
[cpg cn=true]


謙信大人似乎感到很沮喪。
[cpg]

然而，當這場戰鬥結束後，我將失去我的兩位領主中的一位。
[cpg]

我所能做的，也是我所想做的，就是在這場戰鬥中保持平衡。
[cpg]

它將不會被解決。兩位將軍都不會被殺。我想選擇這條道路。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Kensin206"]
[OnName num="kenshin"]
'如果發生這種情況，......，我別無選擇，只能再一次把你送回信玄。
[cpg cn=true]


[OnName num="keitarou"]
......，你是什麼意思？ "
[cpg cn=true]


我很驚訝，聽到這麼意外的事情，我忍不住發出了赤裸裸的聲音。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin207"]
[OnName num="kenshin"]
首先要做的是再次從信玄那裡獲得信息。 '你會再次從信玄那裡提取信息嗎？
[cpg cn=true]


[OnName num="keitarou"]
'如果我這樣做，你不認為我將再次加入信玄大人嗎？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin208"]
[OnName num="kenshin"]
'我不這麼認為。你和我不再是陌生人了。
[cpg cn=true]


謙信大人自信的這麼說，我也是這麼想的。
[cpg]

我再也無法動彈，回到信玄大人身邊，為謙信大人報仇......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

話雖如此，我也不想為信玄大人報仇。
[cpg]

我想這是自然心理學。謙信大人可能是考慮到這一點才派我去的。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

我再次回到信玄大人身邊。
[cpg]

與旅行不同，我的同伴們都走了。但我不能被嚇倒。
[cpg]


[window target=false]
[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

我想信玄大人會很高興看到我回來。但我不能再站在她那邊了。
[cpg]

我就像謙信大人的雙重間諜。我和信玄大人之間的關係將不再一樣了。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『山道』（夜）******************************************************

而幾天過去了。我已經走了這麼久，我怕我會崩潰。 ......
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_13_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

我終於找到了信玄大人。
[cpg]

[OnName num="soldier_A"]
"你是......！　嘿，你是誰？
[cpg cn=true]


[OnName num="soldier_B"]
你還活著!　天哪，我必須告訴信玄大人。 ......
[cpg cn=true]



[SE f=se016]
;//【ＳＥ】『地面に倒れ込む』

我鬆了一口氣，就這樣倒在了地上。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

下一次我醒來的時候，我在我的房間裡。
[cpg]

信玄大人就在那裡。這段時間他一直在我身邊。
[cpg]

[OnName num="keitarou"]
'...... 信玄大人，好久不見了。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen205"]
[OnName num="shingen"]
是的，已經有很長一段時間了。真的'。
[cpg cn=true]


她說，幾乎是流著淚。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Singen206"]
[OnName num="shingen"]
'我很高興你是安全的。我以為你已經被殺了。
[cpg cn=true]


[OnName num="keitarou"]
'我不是那麼容易死的，你知道。
[cpg cn=true]


我在說這種毫無根據的話時也開始哭了。
[cpg]

我畢竟不想失去信玄大人。我不能在這裡背叛她。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

我知道只有一件事我必須做。
[cpg]

盡量減少信玄大人和謙信大人之間的衝突。這是我能做的一切。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Singen207"]
[OnName num="shingen"]
'...... 是的。謙信不是做這種事的人，......."
[cpg cn=true]


[OnName num="keitarou"]
是的，她說她會的。她說他現在處於防守狀態。
[cpg cn=true]


我決定告知他們，我們有完善的防禦措施，同時告知他們，我們無意入侵他們。
[cpg]

如果我回去找謙信大人，我也要對她說同樣的話。
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Singen208"]
[OnName num="shingen"]
'感謝你在偵查中的辛勤工作。我知道我可以依靠你。
[cpg cn=true]


[OnName num="keitarou"]
'我想去多少次都可以。我相信這次我會更早回來。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen209"]
[OnName num="shingen"]
我指望著你。如果你讓我擔心，我不會原諒你。
[cpg cn=true]


[OnName num="keitarou"]
沒有。我會處理好的。
[cpg cn=true]


我不只是去執行偵察任務。
[cpg]

我得回去找謙信大人，告訴他那邊的情況。
[cpg]

避免這兩者發生衝突是我的使命。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

離我們下次出發的時間已經不多了。
[cpg]

信玄大人也想擺脫這種局面。
[cpg]

但我不能讓這種情況發生。
[cpg]

我不能說我是站在信玄或謙信一邊的。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen210"]
[OnName num="shingen"]
'你又要去了，是嗎？我會想你的。
[cpg cn=true]


[OnName num="keitarou"]
別擔心。信玄大人不在，我是不會走的。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Singen211"]
[OnName num="shingen"]
我相信你。請安全地回來。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

沿著山路走了很多次之後，我的腿和背已經變得很強壯。
[cpg]

同時，我也有一種感覺，我絲毫不會被打敗。
[cpg]

我覺得在謙信大人那裡，讓我長大了。
[cpg]


[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

沿著山路前行。無論我走多少次，這都是一段很長的距離，但我不認為它像以前那樣困難。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_14_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

然後我又回到了謙信大人的地方。
[cpg]

[OnName num="keitarou"]
'...... 你又回來了，......'
[cpg cn=true]


我也沒想到會是我來做這件事。
[cpg]

這正如謙信大人所希望的那樣。彷彿她在控制我。
[cpg]

但這是一種...... 奇怪的感覺，好像還不錯。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin209"]
[OnName num="kenshin"]
'你回來的很好。我很高興見到你，景太郎先生。
[cpg cn=true]


[OnName num="keitarou"]
'......，我已經把信息送到信玄大人那裡，讓他無法攻擊。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin210"]
[OnName num="kenshin"]
'你也用 "先生 "的頭銜來稱呼她，對嗎？好吧，你不需要停下來。
[cpg cn=true]


[OnName num="keitarou"]
我很抱歉。但對我來說，她也是.......
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin211"]
[OnName num="kenshin"]
我想我在某種程度上對他們有所虧欠。 "你為他服務，當然了。
[cpg cn=true]


而我在信玄大人那裡也說了同樣的話，雖然我是在嘲諷謙信大人。
[cpg]

[OnName num="keitarou"]
'信玄大人是在防守。如果我們現在進攻，就會被打回來。
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Kensin212"]
[OnName num="kenshin"]
'...... 是這樣的嗎？他有沒有可能從另一邊進攻？
[cpg cn=true]


[OnName num="keitarou"]
'我想這是不可能的。另一方也很警惕，他們處於防守狀態。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin213"]
[OnName num="kenshin"]
'這很好。我將信任他們。
[cpg cn=true]


謙信大人這麼說，但我不知道他是否能......，看穿這一切。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

然後我不得不在城堡裡休息。
[cpg]

如果我呆在一個地方，我就不必經歷這些麻煩了。
[cpg]

但現在事情發展到這一步，我別無選擇，只能將謊言堅持到底。
[cpg]

[OnName num="kenshin_vassal"]
'這對你來說也很難。你一定是在偵查信玄的住處。
[cpg cn=true]


[OnName num="keitarou"]
是的，嗯，......
[cpg cn=true]


我相信信玄大人的臣子們也會這樣告訴你。這是一個蝙蝠眼的情況，不管是哪種情況。
[cpg]

但......，我們現在必須這樣做。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[BG f="b_14_3.ui" time=1500]
[WAIT time=3000]
[BG f="b_14_4.ui" time=1500]
[WAIT time=3000]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

我很擔心我無法像這裡一樣度過難關。
[cpg]

即使他們發現了真相，他們也不會殺我。
[cpg]

儘管我明白這一點，但我很難入睡。然後...
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin214"]
[OnName num="kenshin"]
...... 景太郎先生。你睡不著嗎？
[cpg cn=true]


[OnName num="keitarou"]
謙信大人就是這樣的人。怎麼了？
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Kensin215"]
[OnName num="kenshin"]
我還在和信玄對著幹，你知道的。當我想到將要發生的事情時，我無法保持平靜。
[cpg cn=true]


[OnName num="keitarou"]
我相信你是對的。
[cpg cn=true]


我有點覺得我沒有做出正確的反應。
[cpg]

我所講的謊言影響的不僅僅是她。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin216"]
[OnName num="kenshin"]
掌管士兵的人，就是掌管諸侯和在他們手下作戰的士兵。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin217"]
[OnName num="kenshin"]
'因為我的生命並不屬於我一個人。
[cpg cn=true]


我不能直視她的臉。當我有這樣的感覺時。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Kensin218"]
[OnName num="kenshin"]
你也不例外。我希望能保護你。 "
[cpg cn=true]


[OnName num="keitarou"]
'......謙信大人 ......'
[cpg cn=true]


謙信大人看起來好像在等待什麼。
[cpg]

在這種情況下，什麼都不做可能才是真正的背叛。
[cpg]


;//ブラックアウト
[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

我吻了謙信大人的嘴。
[cpg]

我沒有猶豫，儘管我感到內疚。
[cpg]

;//移植前シーンカット

[OnName num="keitarou"]
......謙信大人。我愛你。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="sKensin006"]
[OnName num="kenshin"]
我也是如此。我也喜歡你。
[cpg cn=true]


我想知道謙信大人對我的喜歡是怎麼來的。
[cpg]

也許是我來自未來，或者是我為信玄大人服務，並毫不猶豫地背叛了他。 ......。
[cpg]

我確定這就是它的目的，但這是他第一次告訴我他喜歡我。
[cpg]


;//移植前シーンカット

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我和謙信大人正在談論未來。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Kensin275"]
[OnName num="kenshin"]
'你怎麼看，景太郎先生？　你反對攻擊信玄的地方嗎？
[cpg cn=true]


[OnName num="keitarou"]
'正如我所說。信玄大人已經做了精心準備。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin276"]
[OnName num="kenshin"]
'......，我明白了。
[cpg cn=true]


謙信大人似乎不相信我，但他似乎相信我。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿謙信』（朝）******************************************************

謙信大人和信玄大人之間的權力平衡是我在操縱他們。
[cpg]

彷彿我在背後操縱著將軍們，在幕後控制著戰爭局勢。
[cpg]

我沒有選擇，只能這樣做。一旦戰爭結束，我們處於合作關係中，未來將被改變。
[cpg]

如果發生這種情況，我不知道我將發生什麼。
[cpg]

如果我不在未來出生，我可能會消失。
[cpg]

另一方面，如果我們中的一個人獲勝，未來仍然會被改變。
[cpg]

我注視著處於不穩定平衡狀態的信玄大人和謙信大人，使他們不至於崩潰。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[BG f="b_01_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『街』（昼）******************************************************

我沒有什麼特別的事情要做，就來到了城堡鎮。
[cpg]

沒有人，甚至是他，會去尋找一場戰鬥。沒有一個人認為這是不可能的。
[cpg]

[OnName num="keitarou"]
'......，這是正確的。這很明顯嗎？ "
[cpg cn=true]


我不禁在心裡想。這就是我知道戰鬥沒有意義的程度。
[cpg]

如果是真的，最好是能帶來合作關係。
[cpg]

我不知道為了自己的方便，繼續維持一個士兵將來可能死亡的局面是否好。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin277"]
[OnName num="kenshin"]
你看起來很苦惱。
[cpg cn=true]


[OnName num="keitarou"]
謙信大人 ...... 你為什麼在這裡？
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Kensin278"]
[OnName num="kenshin"]
'因為我也是，如果我一直呆在城堡裡就會感到窒息。
[cpg cn=true]


謙信大人走到我身邊，我誠實地回答。
[cpg]

[OnName num="keitarou"]
'我不是在尋找戰爭的結束，我是在尋找停滯。
[cpg cn=true]


[OnName num="keitarou"]
'我只能說，有一些情況使戰爭難以結束。 ......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin279"]
[OnName num="kenshin"]
為什麼？　我知道你來自未來，所以你為什麼不告訴我一切？
[cpg cn=true]


[OnName num="keitarou"]
......，是的。
[cpg cn=true]


[OnName num="keitarou"]
如果謙信大人和信玄大人合作，他們可能會改變未來。
[cpg cn=true]


[OnName num="keitarou"]
'如果那樣的話，一個與我現在所處的時代不同的時代可能會到來。如果發生這種情況，我的存在也可能消失。
[cpg cn=true]


謙信大人把手放在下巴上，思考著。
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin280"]
[OnName num="kenshin"]
'所以這就是你一直在想的事情。但你不需要擔心'。
[cpg cn=true]


[OnName num="keitarou"]
'但......，即使有停滯，也會有小規模的衝突。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Kensin281"]
[OnName num="kenshin"]
'的確，有些人可能在那裡失去生命。但你看重的是什麼呢？
[cpg cn=true]


......，的確如此。沒有什麼可以代替自己的生命。
[cpg]

謙信大人可能也有同樣的感受。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夕方）******************************************************

謙信大人知道我的苦惱。在她的帶領下，我再次回到了城堡。
[cpg]

在人前，他向我傳授了政治知識。他說，他不想僅僅利用我的情報，而是最終想給我一個更重的角色。
[cpg]


;//ブラックアウト

這是一個漸進的變化。我可以說這是我想要的那種變化。
[cpg]


;//移植前シーンカット

;//移植前シーンカット

;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

如果。如果我和謙信大人有了孩子。
[cpg]

如果那樣的話，我可能連往返信玄大人的地方都會變得很困難。
[cpg]

但我認為這樣就可以了。我已經準備好為謙信大人服務。
[cpg]

作為一個父親，離開孩子這麼長時間可能是一個問題。
[cpg]

如果是這樣的話，我可能就得停止為信玄大人服務了。
[cpg]


[window target=false]
[BG f="b_07_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

但我還是想保持平衡。
[cpg]

如果我追隨謙信大人，川中島之戰可能就會解決。
[cpg]

這是一個關於我如何表現的問題。
[cpg]

[OnName num="keitarou"]
'那好吧，我走了。
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin337"]
[OnName num="kenshin"]
是的。我將回來提供更多信息。請確保你回來。
[cpg cn=true]


[OnName num="keitarou"]
當然了。我會處理好的。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

我現在已經習慣了這條道路。我不再猶豫地在沒有標誌或任何東西的道路上行走。
[cpg]

如果你不猶豫，你就不會浪費你的時間。
[cpg]

我覺得我現在可以做任何事情。
[cpg]

欺騙信玄大人，避免與謙信大人發生衝突。
[cpg]

我以為我可以做一些事情，如果我冷靜地想一想，這將是相當困難的。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

然後，我將再次回到信玄大人的地方。
[cpg]

他不再像以前那樣一來就倒下了。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen212"]
[OnName num="shingen"]
'你已經變了，我親愛的。
[cpg cn=true]


[OnName num="keitarou"]
'自從我和她一起躲起來之後，......，已經有很長一段時間了。
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Singen213"]
[OnName num="shingen"]
那麼你似乎很奇怪的自信。
[cpg cn=true]


[OnName num="keitarou"]
不，我不知道。
[cpg cn=true]

[STOPBGM]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen214"]
[OnName num="shingen"]
我不這麼認為。而且我還聽到了關於這個的傳言。
[cpg cn=true]


那個女人說她聽到了一些傳言，並提到謙信大人已經生了一個孩子。
[cpg]


;//下記のセリフ、台本では
;//「謙信が妊娠したらしいわね。彼女、独り身のはずなのだけど」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください

[FACE method="change_7" pos="2/3"]

[VOICE f="Singen215"]
[OnName num="shingen"]
她應該是單身。
[cpg cn=true]


我幾乎要大聲喊出來了，但還是忍住了。
[cpg]

[OnName num="keitarou"]
'那是...... 一個快樂的故事，不是嗎？
[cpg cn=true]


我說："這是個快樂的故事。
[cpg]

[FACE method="shake_7" pos="2/3"]

[VOICE f="Singen216"]
[OnName num="shingen"]
我說："這有什麼好高興的？我們應該是敵人。
[cpg cn=true]


信玄大人說得很有道理。信玄大人可能真的知道這一切。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『山道』（夜）******************************************************

我在信玄大人的地方和謙信大人的地方之間來回走動。
[cpg]

我對自己在為誰工作變得越來越模糊。
[cpg]

我是兩個本質上是敵人的人的中間人。這種事情是......
[cpg]

在過去的歷史中，可能是由婦女完成的。
[cpg]

如果軍閥是男人，也許約束他們是女人的職責。
[cpg]

而我現在代禱的兩個人是女性。作為一個男人，我的角色是要約束他們嗎？
[cpg]

在思考這個問題的同時，我出發去了謙信大人的地方。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（昼）******************************************************

信玄大人可能是對的。我一定是變了。
[cpg]

更確切地說，與現在的我相比，我已經改變了很多。
[cpg]

與這些婦女見面，鍛煉了我的身心。
[cpg]

我可能已經變得或多或少有點男人味了。我可能是多麼的過度自信。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se025]
;//【ＳＥ】『ふすま開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

過了很久，我回到謙信大人那裡時，她的肚子已經腫了起來。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Kensin338"]
[OnName num="kenshin"]
這是一個和你在一起的孩子。你應該給它命名。
[cpg cn=true]


[OnName num="keitarou"]
你為什麼不給它起個名字呢，謙信大人？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin339"]
[OnName num="kenshin"]
這很好。沒有你，我就不會有孩子。
[cpg cn=true]


[OnName num="keitarou"]
這對我來說也是一樣。如果沒有你，就不可能有這樣的結果。
[cpg cn=true]


多麼重複的論調啊！然而，謙信大人決定為他們命名。
[cpg]


[window target=false]
[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

可愛的時間慢慢過去。
[cpg]

我無法相信......，謙信大人肚子裡的孩子是誰。
[cpg]

所有接近她的諸侯都知道，我可以告訴他們。
[cpg]

這就是為什麼我和謙信大人正式成為夫妻。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

而謙信大人和信玄大人也不再有大的衝突。
[cpg]

當然，我們並沒有和解。謙信大人明白這一點。
[cpg]

他可能不會這樣做，因為他想的是我。
[cpg]

我不知道他有多相信我來自未來，但我不知道他有多相信。 ......。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin340"]
[OnName num="kenshin"]
'你是來自未來。多遠的未來？ "
[cpg cn=true]


[OnName num="keitarou"]
'非常之遠。你一定是在五百年後。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Kensin341"]
[OnName num="kenshin"]
'我明白了。這一定是個好時機。
[cpg cn=true]


[OnName num="keitarou"]
是的。是的，這是一個和平的時代，容易生活，沒有衝突。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Kensin342"]
[OnName num="kenshin"]
你認為你願意回來嗎，景太郎先生？
[cpg cn=true]


...... 我記得我聽到這個消息的時候。
[cpg]

我第一次來到這個時代，就听到了這個傳說。
[cpg]

我聽說軍閥和我生的孩子可能有神奇的力量。
[cpg]

命運的時刻正在來臨嗎？如果是這樣，我就得為之負責。
[cpg]


;//ブラックアウト

她的肚子隨著時間的推移而長大。
[cpg]

我的第一個目的是回到今天，或者在這個時代為自己創造一個位置。 ......
[cpg]

現在說實話，我很高興能有一個孩子。
[cpg]


;//移植前シーンカット

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

那天晚上我們睡在一起。
[cpg]

這段相處的時間是最可愛的事情。
[cpg]

遲早有一天，我們會有三個人。我們的孩子要出生了。 ......
[cpg]

這確實是難以想像的，但我們想看看等待我們的是什麼樣的未來。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************

信玄大人和謙信大人之間的戰鬥還未結束。
[cpg]

我確信這將永遠不會被解決。
[cpg]

[OnName num="keitarou"]
...... 那些穿著外國袍子的人。
[cpg cn=true]


[OnName num="keitarou"]
'以公主戰神的紐帶，我將給你一個吃天的兒子。 ......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin391"]
[OnName num="kenshin"]
怎麼了？　它是什麼？
[cpg cn=true]


[OnName num="keitarou"]
你沒聽說過嗎，謙信大人？　這是我來到這個時代的第一個村莊的一個傳統。
[cpg cn=true]


[OnName num="keitarou"]
我的孩子和謙信大人的孩子可能有超越時間的力量。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Kensin392"]
[OnName num="kenshin"]
既然你提到了，......，你想念你的祖國嗎？
[cpg cn=true]


[OnName num="keitarou"]
沒有。不，恰恰相反。即使我可以回到未來，我也不會回去。
[cpg cn=true]


[OnName num="keitarou"]
'我想和謙信大人一起生活。我想把它全部看完。 "
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Kensin393"]
[OnName num="kenshin"]
'謝謝你，.......我們的孩子會很高興'。
[cpg cn=true]


謙信女士的臉上露出了平和的表情。
[cpg]

她正在成為一個母親，而我正在成為一個父親。我們的思維方式正在發生變化，這並不令人驚訝。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

幾天的通行證。她的肚子越長越大。
[cpg]

我不再回到信玄大人身邊了。
[cpg]

我想她一定意識到了真相。
[cpg]

我一直打算留在謙信大人的身邊。
[cpg]

[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Kensin394"]
[OnName num="kenshin"]
'景太郎先生。看看它已經變得多麼腫大了。
[cpg cn=true]


[OnName num="keitarou"]
'是的，我明白了。我想知道女性的身體。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Kensin395"]
[OnName num="kenshin"]
我不是一個陌生人。很快你也將成為一名父親。
[cpg cn=true]


;//移植前シーンカット

我想到的第一件事是，這段愛情是從一個非常奇怪的地方開始的。
[cpg]

雖然我們一直是敵人，但我和謙信大人卻奇怪地被對方吸引。
[cpg]

我可能因此而被召喚到這個時代，以便我們在這場戰鬥中都不會被打敗。
[cpg]

[OnName num="keitarou"]
'我希望這種和平將永遠持續下去。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin421"]
[OnName num="kenshin"]
'與其說是和平，......，還不如說是沒有衝突。
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
說完這句話後，謙信大人立即把頭轉了下來。
[cpg]

[OnName num="keitarou"]
'...... 謙信大人?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Kensin422"]
[OnName num="kenshin"]
'我剛剛有了一個胎動。我肚子裡的孩子似乎在告訴我，它也是。
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

又過了幾個月，謙信大人和我生了一個孩子。
[cpg]

聽說母親和孩子都很安全，我鬆了一口氣。
[cpg]

我......，不會再回到現在了。我已經決定永遠留在這裡。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿外観＿謙信』（昼）******************************************************

我不知道我們的孩子是否有任何神奇的力量。
[cpg]

但現在這並不重要。
[cpg]

我可能是為了見謙信大人而來到這個時間段。
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ非エロ（座って、子供をあやすヒロイン。隣に主人公がいる）ev_63
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿縁側の通路
;//時間　：昼
;//備考　：子供は一歳に満たない赤ん坊です
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_63_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Kensin423"]
[OnName num="kenshin"]
'好吧，...... 唷，你看起來有點像景太郎先生。
[cpg cn=true]


[OnName num="keitarou"]
'我有嗎？　'我覺得我看起來像謙信大人。
[cpg cn=true]


;//＠
;//[VOICE f="Kensin424"]
;//[OnName num="kenshin"]
;//「その、謙信様というのはやめてくれませんか？　もう夫婦だというのに」
;//[cpg cn=true]

也許是因為我稱他們為 "大人"，儘管他們現在是夫妻，但謙信大人的心情似乎有點不好。
[cpg]

;//＠
;//[OnName num="keitarou"]
;//「確かにそうですが……慣れてしまって」
;//[cpg cn=true]

[OnName num="keitarou"]
'......，我很抱歉，......，我已經習慣了。
[cpg cn=true]



[VOICE f="Kensin425"]
[OnName num="kenshin"]
'已經。景太郎。
[cpg cn=true]


[OnName num="keitarou"]
'謙信......-大人。
[cpg cn=true]



[VOICE f="Kensin426"]
[OnName num="kenshin"]
'......，這將需要一些時間來解決。
[cpg cn=true]


謙信大人在笑。 '我不是真的生氣。
[cpg]


[VOICE f="Kensin427"]
[OnName num="kenshin"]
'這很好，很安靜。不久前，因為與信玄的戰鬥，城堡裡的氣氛很緊張'。
[cpg cn=true]



[VOICE f="Kensin428"]
[OnName num="kenshin"]
'不,......，即使再發生衝突，與景太郎，......。
[cpg cn=true]


我們在未來可能會繼續遇到困難。
[cpg]

但我確信已經沒有什麼可擔心的了。
[cpg]


;//ブラックアウト

;//ＥＮＤ　ヒロイン３ルート

[SCENE id=12]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="epend.ks" target="*start"]


;//==============================

