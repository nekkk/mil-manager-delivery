
*start

;////////////////////////////////////////////////////////////////////
;//以下、ヒロイン４のイベント
;////////////////////////////////////////////////////////////////////






;//////////////////////////////////
;//ヒロイン４一回目のイベント
;//『理想の見た目バトル』
;//////////////////////////////////



;//==============================
;//ヒロイン４一回目のイベント　前置き
;//☆ヒロインのイベント前置き
*HiStory4_01|理想の見た目バトル


;#################################################
*Ep005|The Battle for the Ideal Look
;#################################################

;//[SCENE id=5]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





School classroom. At the end of class, I approached my teacher.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue016"]
[OnName num="kozue"]
He said, "What, ......?　You want to see my room?"
[cpg cn=true]


[OnName num="takuma"]
Yes. What is your room like?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue017"]
[OnName num="kozue"]
He said, "That's very direct......, but I don't give my students a home."
[cpg cn=true]


[OnName num="takuma"]
"Is that so......?　But you said you'd take me up on the offer.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kozue018"]
[OnName num="kozue"]
That's true.
[cpg cn=true]


[OnName num="takuma"]
'Well, then, it's good enough to go up to my house, isn't it?　If you don't, we won't have any competition.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue019"]
[OnName num="kozue"]
If you insist that much, I have no choice. ......
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





So, I got the appointment ...... and all I have to do is wait for the day.
[cpg]


I wonder what kind of plain clothes the teacher will be wearing. I have a bad feeling about this.
[cpg]


I might as well prepare some clothes in advance.
[cpg]



;//==============================
;//ヒロイン４一回目のイベント　バトルパート
;//☆ヒロインのイベントバトルパート


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





I came to the teacher's house as if I was going to force my way in.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue020"]
[OnName num="kozue"]
"Well, come on up, then."
[cpg cn=true]


[OnName num="takuma"]
"Yes. Yes, I'm sorry to bother you.
[cpg cn=true]


I did so and went up to the teacher's room.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





The room was a little messy.
[cpg]


The actual "I'm sorry, I'm sorry, I'm sorry, I'm sorry.
[cpg]


[OnName num="takuma"]
「……」
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue021"]
[OnName num="kozue"]
'......Why do you look like that?'
[cpg cn=true]


I came over to your house, but I guess there are things I should do first.
[cpg]


Sensei, I'm pretty slutty. ...... I'm far from a sexy teacher.
[cpg]


[OnName num="takuma"]
'Sensei. Shall we go shopping for clothes?"
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Kozue022"]
[OnName num="kozue"]
What?　What's going on all of a sudden?
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『ショッピングモール店内』（昼）******************************************************





There were many things I wanted to do in the teacher's room, but that was before that.
[cpg]


If you wear jerseys in your daily life, you can't call it sexy.
[cpg]


Some maniacs might call it sexy. But I don't.
[cpg]

[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="takuma"]
I'll pick out your clothes for you. Please put it on.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue023"]
[OnName num="kozue"]
Why are we suddenly talking about this ......?"
[cpg cn=true]


[OnName num="takuma"]
"Sensei, it's not good that you wear jerseys in your daily clothes. I'll look after it for you.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue024"]
[OnName num="kozue"]
I don't mind, but I won't wear it unless I like it.
[cpg cn=true]


[OnName num="takuma"]
If I bring you something you like, will you wear something else?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue025"]
[OnName num="kozue"]
'Fine, but if I bring you something misguided, there are things I want you to wear, Shikata-ju-kun.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue026"]
[OnName num="kozue"]
I'm sure you'll accept that. ......?　Yes, it's another match.
[cpg cn=true]


I want it to be. I know what the teacher likes.
[cpg]



;//++++++++++++++++++++++++++
;//バトル開始画面
;//++++++++++++++++++++++++++


[SE f="se006"]
;//【ＳＥ】『バトル開始』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_bs4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『ショッピングモール店内』（昼）******************************************************

;//[CutBG g="sys_cut_bwin4"]



;//++++++++++++++++++++++++++
;//バトル画面を表示
;//++++++++++++++++++++++++++


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]


But I can't just suddenly dress him in something that stands out, can I?
[cpg]


I pick out what I'm going to give him, thinking about what I'm going to give him.
[cpg]



;//アイテム選択　『地味な服』を選んだ時は勝った場合へ進む
;//それ以外のものを選んだ場合負けた場合へ進む
*battle_item_select_00|理想の見た目バトル

[if exp={getFlagValue("getItemNum_01") == 9}]
[jump target="*battle_win_41"]
[endif]


[jump target="*battle_lose_41"]

;//[SelectItem n=9 w=*battle_win_41 l=*battle_lose_41]
どれを使おう…
[cpg]
;//[endswitch]



;//==============================
;//勝った場合　※正しいアイテムを選んだ場合
*battle_win_41|理想の見た目バトル

[stflag HiWinFlg_04 = 1]


[OnName num="takuma"]
How about this one?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Kozue027"]
[OnName num="kozue"]
...... Sure, it's kinda nice."
[cpg cn=true]


I dared to bring a modest dress at first.
[cpg]


Once I convinced the teacher. I was so excited that I decided to wear a few different outfits to the school.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





[OnName num="takuma"]
I asked him, "Don't you wear this kind of clothes?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue028"]
[OnName num="kozue"]
"What? Are you serious?
[cpg cn=true]


I think it's a little too hard for a teacher.
[cpg]


But if I recommended it to him, he might wear it. ......
[cpg]


[OnName num="takuma"]
I'm sure you'll look great in it. I guarantee it.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Kozue029"]
[OnName num="kozue"]
"Are you sure ......?"
[cpg cn=true]


[OnName num="takuma"]
I won the game earlier, didn't I? You'll do what I say, won't you?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue030"]
[OnName num="kozue"]
That's true, but you can also go to .......
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[FADEOUTBGM]

[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





The next day.
[cpg]



;//========================================
;//●ＣＧ（セクシーな服を着るヒロイン。周りの視線が集中する）ev_70
;//人物１：ヒロイン４　服装１：スーツ。露出の多め
;//場所　：学園教室
;//時間　：夕方
;//備考　：セクシーな女教師という感じになっていくヒロイン
;//========================================



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_co"]
;**【ＣＧ】 ev_70_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Kozue031"]
[OnName num="kozue"]
I knew it...I can't ...... dress like this!
[cpg cn=true]


[OnName num="takuma"]
I can't wear this. We made a promise.
[cpg cn=true]


In truth, it wasn't so much a promise as it was a promise.
[cpg]



[VOICE f="Kozue032"]
[OnName num="kozue"]
The truth is, it's not so much a promise as it is a promise. I did, but... but this is... unexpected.
[cpg cn=true]


But I made a promise. The teacher would not back down now.
[cpg]


[OnName num="takuma"]
'Huh...I'm disappointed. Sensei was a liar, wasn't he? So sad...so sad..."
[cpg cn=true]


I try to make the teacher not back down even more by taking that kind of attitude.
[cpg]



[VOICE f="Kozue033"]
[OnName num="kozue"]
I wish you would stop blatantly accusing me...God damn it! I understand! I understand!
[cpg cn=true]


I was pleased to hear him say, "I understand.
[cpg]


[OnName num="takuma"]
That's the way it should be.
[cpg cn=true]



[VOICE f="Kozue034"]
[OnName num="kozue"]
"Oh...depressing."
[cpg cn=true]



;//場面切り替え



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ev_70_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;**【ＣＧ】 ev_70_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="Kozue035"]
[OnName num="kozue"]
"They're watching me...they're watching me so much."
[cpg cn=true]



[VOICE f="Kozue036"]
[OnName num="kozue"]
The other teachers were confused, too.
[cpg cn=true]


The teacher was attracting a lot of stares. Especially from boys.
[cpg]


Especially from boys and girls. The teacher is especially noticed by the boys and girls.
[cpg]



[VOICE f="Kozue037"]
[OnName num="kozue"]
I knew I didn't look good in this outfit..."
[cpg cn=true]


They probably thought they couldn't just look at him. One of the boys spoke up.
[cpg]


[OnName num="male_student"]
Sensei, what's going on all of a sudden?"
[cpg cn=true]


Sensei was at a loss for an answer when he was spoken to.
[cpg]



[VOICE f="Kozue038"]
[OnName num="kozue"]
No, this is just... a change of pace? I was just..."
[cpg cn=true]


Sensei making a painful excuse.
[cpg]


However, the people around him were more friendly than he had expected.
[cpg]


Surprisingly, he was well received not only by the boys, but also by the girls.
[cpg]


[OnName num="female_student_1"]
Sensei, it's definitely better this way.
[cpg cn=true]


[OnName num="female_student_2"]
"Yes, yes. It's so hot!" "What?
[cpg cn=true]



[VOICE f="Kozue039"]
[OnName num="kozue"]
"What? Really?
[cpg cn=true]


[OnName num="female_student_3"]
"I feel like it's easier to talk to you now, sir.
[cpg cn=true]



[VOICE f="Kozue040"]
[OnName num="kozue"]
When you say so,......, it makes me a little happy. Thank you.
[cpg cn=true]


There was an exchange like this. Finally, the teacher is pleased.
[cpg]



[VOICE f="Kozue041"]
[OnName num="kozue"]
Â "Â"
[cpg cn=true]


[OnName num="takuma"]
Â "How are you doing?"
[cpg cn=true]



[VOICE f="Kozue042"]
[OnName num="kozue"]
Â "Eh, ah~...that ...... well...it wasn't bad, right?"
[cpg cn=true]


The teacher was fooling around like that, but his expression was honest.
[cpg]


The only thing that has changed is the clothes, but I feel ...... that they have become a little bit sexier.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I need to keep building on these things. I want her to be my ideal teacher.
[cpg]



;//++++++++++++++++++++++++++
;//勝利画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba4w.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se007"]
;//【ＳＥ】『バトル勝利』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト
;//☆次は負けた場合のイベント

[jump target="*before_select_chara"]
;//==============================
;//負けた場合　※正しいアイテムを選ばなかった場合
*battle_lose_41|理想の見た目バトル





...... no, I can't think of a good one.
[cpg]


While I was fidgeting, the teacher took me somewhere else.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue043"]
[OnName num="kozue"]
'I promise,' he said. You couldn't bring me something I'd like.
[cpg cn=true]


[OnName num="takuma"]
What's this?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue044"]
[OnName num="kozue"]
"It's a belt for your abs. It buttons on and off.
[cpg cn=true]


[OnName num="takuma"]
......
[cpg cn=true]


No. I lost the game. It was a teacher's hobby, but I couldn't resist.
[cpg]


I could tell he wanted to make me into a muscular man.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue045"]
[OnName num="kozue"]
I'll buy it for you. You'll work out for me, won't you?
[cpg cn=true]


[OnName num="takuma"]
"...... yes."
[cpg cn=true]



;//++++++++++++++++++++++++++
;//敗北画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba4l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se008"]
;//【ＳＥ】『バトル敗北』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト


[jump target="*before_select_chara"]
;//ヒロイン４一回目のイベント　ここまで
;//☆ここから次のイベント






;//////////////////////////////////
;//ヒロイン４二回目のイベント
;//『トレーニングバトル』
;//////////////////////////////////



;//==============================
;//ヒロイン４二回目のイベント　前置き
;//☆ヒロインのイベント前置き
*HiStory4_02|トレーニングバトル

;#################################################
*Ep009|トレーニングバトル
;#################################################

;//[SCENE id=9]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue046"]
[OnName num="kozue"]
"Hey, Shikata-kun, are you interested in a training gym? Aren't you interested in a training gym?
[cpg cn=true]


[OnName num="takuma"]
What is it, suddenly?
[cpg cn=true]


To be honest, I'm not interested. But I guess the teacher is.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue047"]
[OnName num="kozue"]
I'll take you there next time. I'll take you there next time.
[cpg cn=true]


You're up to something bad, doctor. ......
[cpg]


I thought about what I could do to prepare myself for the battle that was bound to ensue.
[cpg]


I know you're going to be training, so I'd like something to prepare me for that.
[cpg]



;//==============================
;//ヒロイン４二回目のイベント　バトルパート
;//☆ヒロインのイベントバトルパート


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





[FG f="CHA04_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue048"]
[OnName num="kozue"]
Here it is. It was just built recently.
[cpg cn=true]


[OnName num="takuma"]
「……」
[cpg cn=true]


The place where he and I had our date was a training gym.
[cpg]


[FG f="CHA04_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue049"]
[OnName num="kozue"]
I'd like to work out there. I want to see how your muscles have grown.
[cpg cn=true]


[OnName num="takuma"]
It's okay. How about we go to ...... and see who loses the first time he gets tired?
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue050"]
[OnName num="kozue"]
"You said that, didn't you?　I'm not that physically weak.
[cpg cn=true]



;//++++++++++++++++++++++++++
;//バトル開始画面
;//++++++++++++++++++++++++++


[SE f="se006"]
;//【ＳＥ】『バトル開始』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_bs4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

;//[CutBG g="sys_cut_bwin4"]



;//++++++++++++++++++++++++++
;//バトル画面を表示
;//++++++++++++++++++++++++++

[FG f="CHA04_p3_02_a.ui" method="change_1"  pos="2/3" time=800]



[OnName num="takuma"]
Then, let's start training.
[cpg cn=true]


Well, what am I going to do? I'm not going to use anything here. ......
[cpg]



;//アイテム選択　『栄養ドリンク』を選んだ時は勝った場合へ進む
;//それ以外のものを選んだ場合負けた場合へ進む
*battle_item_select_00|Training Battle

[if exp={getFlagValue("getItemNum_02") == 14}]
[jump target="*battle_win_42"]
[endif]

[if exp={getFlagValue("getItemNum_01") == 14}]
[jump target="*battle_win_42"]
[endif]

[jump target="*battle_lose_42"]

;//[SelectItem n=14 w=*battle_win_43 l=*battle_lose_43]
Which one should I use...
[cpg]
;//[endswitch]



;//==============================
;//勝った場合　※正しいアイテムを選んだ場合
*battle_win_42|トレーニングバトル

[stflag HiWinFlg_04 = 1]


I took a nutritional drink and went for the upcoming battle.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



From there, we would both train together. The nutritional drink had made me full of energy and stamina.
[cpg]


As a result, the teacher was exhausted before I was.
[cpg]


[FG f="CHA04_p5_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kozue051"]
[OnName num="kozue"]
Ha, ha, I can't take it anymore......."
[cpg cn=true]


The teacher is breathing hard while wiping sweat off his face. You're getting a little sexy.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[FG f="CHA04_p1_02_a.ui" method="change_7"  pos="2/3" time=800]

On the way home, he was tired enough to give me a shoulder ...... to lean on, still strangely sexy.
[cpg]

At first I promised I'd do what you said, but I don't need it anymore.
[cpg]

I'm happy just to see her like this.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//++++++++++++++++++++++++++
;//勝利画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba4w.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se007"]
;//【ＳＥ】『バトル勝利』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト
;//☆次は負けた場合のイベント

[jump target="*before_select_chara"]
;//==============================
;//負けた場合　※正しいアイテムを選ばなかった場合
*battle_lose_42|トレーニングバトル



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I had done no preparation and had no choice but to train properly.
[cpg]


I was battered before the teacher. I was feeling miserable.
[cpg]


[FG f="CHA04_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue052"]
[OnName num="kozue"]
He said, "You're no good, Shikata-kun. From now on, you must do muscle training every day, okay?
[cpg cn=true]


[OnName num="takuma"]
But..."
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue053"]
[OnName num="kozue"]
You were out of shape before me, so you have to keep your promise."
[cpg cn=true]


I couldn't refuse him. I'm one step closer to becoming the muscular man the teacher wants me to be. ......
[cpg]



;//++++++++++++++++++++++++++
;//敗北画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba4l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se008"]
;//【ＳＥ】『バトル敗北』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト


[jump target="*before_select_chara"]
;//ヒロイン４二回目のイベント　ここまで
;//☆ここから次のイベント




;//////////////////////////////////
;//ヒロイン４三回目のイベント
;//『掃除バトル』
;//////////////////////////////////



;//==============================
;//ヒロイン３四回目のイベント　前置き
;//☆ヒロインのイベント前置き
*HiStory4_03|掃除バトル


;#################################################
*Ep013|掃除バトル
;#################################################

;//[SCENE id=13]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************



[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

I was taking a class from my teacher. I suddenly remembered something.
[cpg]

It was a while ago, but her room was a mess.
[cpg]


[OnName num="takuma"]
「……」
[cpg cn=true]


I don't think teachers look that messy when you take another look at them.
[cpg]



[SE f="se000"]
;//【ＳＥ】『学園のチャイム』





[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue054"]
[OnName num="kozue"]
So, that's enough for today.
[cpg cn=true]


I want to fix the teacher's sloppiness. But there's no opportunity for that. ......
[cpg]


No, if you don't have a chance, why don't you just make one? It occurred to me.
[cpg]



;//==============================
;//ヒロイン４三回目のイベント　バトルパート
;//☆ヒロインのイベントバトルパート


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



;//上下に黒帯を入れてください


;//[lbox on]


I was invited to the teacher's house.
[cpg]


I thought it would be about training or something like that, but I started the conversation.
[cpg]


[OnName num="takuma"]
"Sensei, isn't your room too dirty? Isn't your room too dirty?
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue055"]
[OnName num="kozue"]
He said, "I'm going to be direct with you, ....... I'm aware of it, but ......
[cpg cn=true]


[OnName num="takuma"]
I'll help you clean it up. I'll help you.
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue056"]
[OnName num="kozue"]
It's not right for a student to help you.
[cpg cn=true]


[OnName num="takuma"]
I'll help you clean up. Let's have a game.　Let's see who can clean the room better.
[cpg cn=true]


[OnName num="takuma"]
We'll split the room in half, and each of us will clean our own room, and the one who can clean it better than ...... will win.
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue057"]
[OnName num="kozue"]
"......, if I win, will you do what I say?"
[cpg cn=true]


[OnName num="takuma"]
Of course. If it's the other way around, you know what I mean?
[cpg cn=true]



;//[lbox off]


;//++++++++++++++++++++++++++
;//バトル開始画面
;//++++++++++++++++++++++++++


[SE f="se006"]
;//【ＳＥ】『バトル開始』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_bs4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

;//[CutBG g="sys_cut_bwin4"]



;//++++++++++++++++++++++++++
;//バトル画面を表示
;//++++++++++++++++++++++++++

[FG f="CHA04_p3_02_a.ui" method="change_1"  pos="2/3" time=800]



So, what shall we do? I don't have that many tools for cleaning. ......
[cpg]


Okay. I decided to use it.
[cpg]



;//アイテム選択　『掃除機』を選んだ時は勝った場合へ進む
;//それ以外のものを選んだ場合負けた場合へ進む
*battle_item_select_00|掃除バトル

[if exp={getFlagValue("getItemNum_03") == 12}]
[jump target="*battle_win_43"]
[endif]

[if exp={getFlagValue("getItemNum_02") == 12}]
[jump target="*battle_win_43"]
[endif]

[if exp={getFlagValue("getItemNum_01") == 12}]
[jump target="*battle_win_43"]
[endif]

[jump target="*battle_lose_43"]

;//[SelectItem n=12 w=*battle_win_44 l=*battle_lose_44]
Which one should I use?
[cpg]
;//[endswitch]



;//==============================
;//勝った場合　※正しいアイテムを選んだ場合
*battle_win_43|掃除バトル

[stflag HiWinFlg_04 = 1]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


......I know what I'm supposed to use at a time like this, but if we're fighting over one vacuum cleaner, there's no way I'm going to win.
[cpg]

I carefully cleaned with the vacuum cleaner.
[cpg]


As a result, the side I cleaned was cleaner. The teacher seemed to be pretty clumsy. ......
[cpg]

;//========================================
;//●ＣＧ（掃除中、バランスを崩すヒロイン）ev_71
;//人物１：ヒロイン４　服装１：私服
;//場所　：ヒロイン４の部屋
;//時間　：昼
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_71_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Kozue058"]
[OnName num="kozue"]
Kya......!"
[cpg cn=true]


Even now, I'm trying to move things and almost losing my balance.
[cpg]

[OnName num="takuma"]
I'm fine, sir."
[cpg cn=true]


[VOICE f="Kozue059"]
[OnName num="kozue"]
"I'm fine......, that was a close call."
[cpg cn=true]


If it were just a look, I'd say she's a sexy teacher.
[cpg]

But I'm glad that I got to see this kind of thing.
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

And then we finished the game. The result was obvious.

[OnName num="takuma"]
How about this? Will you admit defeat?"
[cpg cn=true]



[VOICE f="Kozue060"]
[OnName num="kozue"]
I don't have a choice.
[cpg cn=true]


I wonder if they'll listen to one thing I say. Then ......
[cpg]

[OnName num="takuma"]
Can I come back and clean up in a while?"
[cpg cn=true]


[VOICE f="Kozue061"]
[OnName num="kozue"]
...... yeah."
[cpg cn=true]


I stepped in and said it a bit, but she didn't mind.
[cpg]


;//移植のためシーンをカットしています

;//++++++++++++++++++++++++++
;//勝利画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba4w.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se007"]
;//【ＳＥ】『バトル勝利』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト
;//☆次は負けた場合のイベント

[jump target="*before_select_chara"]
;//==============================
;//負けた場合　※正しいアイテムを選ばなかった場合
*battle_lose_43|Cleaning Battle



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I couldn't think of any tools that I could ...... use.
[cpg]


As it was, I cleaned the room by hand.
[cpg]


But there are limits to what you can do by hand.
[cpg]


I'm not a good cleaner to begin with. ......
[cpg]


[FG f="CHA04_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue062"]
[OnName num="kozue"]
"Is this ...... a win for me?"
[cpg cn=true]


[OnName num="takuma"]
「……」
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue063"]
[OnName num="kozue"]
I'm not a good cleaner. Oh, yeah.
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue064"]
[OnName num="kozue"]
Here. It's a protein, and you're supposed to take it on a regular basis.
[cpg cn=true]


[OnName num="takuma"]
No, no. ......
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue065"]
[OnName num="kozue"]
"You won't admit defeat?　This was a match, wasn't it?"
[cpg cn=true]


I was being pushed more and more by the teacher. If I didn't do something, I would end up being tainted by her ideals.
[cpg]



;//++++++++++++++++++++++++++
;//敗北画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba4l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se008"]
;//【ＳＥ】『バトル敗北』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト


;//[jump target="*before_select_chara"]
;//ヒロイン４三回目のイベント　ここまで
;//☆ここから次のイベント



*before_select_chara|
[if exp={getFlagValue("Count_Selected") == 3}]
[jump storage="epResalt.ks" target="*Go_to_Resalt"]
[endif]
[jump storage="ep001.ks" target="*before_select_chara"]

;////////////////////////////////////////////////////////////////////
;//以下、ヒロイン４分岐後のシナリオ
;////////////////////////////////////////////////////////////////////


;//==============================
;//三回のバトルを終えて勝利数が１以下であり、このヒロインを３回以上選んでいる場合
*Hiroin_Root_4_1|従順な彼女の男


;#################################################
*Ep026|The Obedient Girlfriend's Man
;#################################################

;//[SCENE id=26]
[SCENE id=14]

;//////////////////////////////////
;//ヒロイン４現実ルート開始
;//////////////////////////////////




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン４の部屋』（昼）******************************************************





Then the months passed and ......
[cpg]


[FG f="CHA04_p5_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kozue066"]
[OnName num="kozue"]
Shikata-kun, you're amazing. You look so different.
[cpg cn=true]


[OnName num="takuma"]
Haha, thanks..."
[cpg cn=true]


In the end, I was often caught by the teacher's invitation and continued to listen to her.
[cpg]


As a result, I became her muscular, obedient man.
[cpg]


[FG f="CHA04_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue067"]
[OnName num="kozue"]
She said, "Oh, my God, that's great. This is it. Very nice."
[cpg cn=true]


That alone made me feel that all my hard work was worth it.
[cpg]


[OnName num="takuma"]
Thank you.
[cpg cn=true]


The teacher, by the way, hasn't changed much. The appearance is still plain.
[cpg]


No, but...he really has a sexy side inside, and I'm the only one who knows that about him.
[cpg]


Maybe that's...okay.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Our relationship was no longer going to change in any way.
[cpg]


Then another day, today, the teacher came to my house.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





I told my parents it was like tutoring.
[cpg]


The parents were happy because the teacher was going to teach them directly.
[cpg]


[FG f="CHA04_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue068"]
[OnName num="kozue"]
He said, "This is your room, isn't it? Oh, you've got all your muscle training stuff here.
[cpg cn=true]


Of course, it was the teacher who said that. I didn't do it voluntarily.
[cpg]


[OnName num="takuma"]
"Yes, I did. I'm working out just like you said.
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue069"]
[OnName num="kozue"]
I'm glad. You're a good boy. Good boy.
[cpg cn=true]


He pats me on the head.
[cpg]


[OnName num="takuma"]
"Heh heh heh."
[cpg cn=true]


Heh, no. I'm really not okay with that.
[cpg]


But the thought of getting another reward today makes me obedient.
[cpg]


;//移植のためシーンをカットしています

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



So, after a while, me and the teacher go to ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[FG f="CHA04_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue070"]
[OnName num="kozue"]
I forgot to tell you. Here's a souvenir."
[cpg cn=true]


[OnName num="takuma"]
"This is..."
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue071"]
[OnName num="kozue"]
"It's a protein. It's from overseas.
[cpg cn=true]


Something with a logo that didn't look like it was made in Japan. I was convinced that it was from overseas.
[cpg]


I was convinced, but accepting it was another matter.
[cpg]


[OnName num="takuma"]
"Well, I think that's enough..."
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue072"]
[OnName num="kozue"]
No, you should be more muscular. You have to be more muscular! You're going to hate ......."
[cpg cn=true]


I guess I was still at the point where I could be called thin and macho, but the teacher seemed to want more than that.
[cpg]


[OnName num="takuma"]
I'll do my best!
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue073"]
[OnName num="kozue"]
'Heh. Yeah, good luck with that.
[cpg cn=true]


I'm the one who's on her ass. She is in a superior position.
[cpg]


Everything is done by her will. I can't go against her.
[cpg]


But at the same time, it means that I don't have to think about anything by myself.
[cpg]


Maybe this kind of life is not so bad...
[cpg]




;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

;//ＥＮＤ　ヒロイン４現実ルート


;//[SCENE id=37]
[SCENE id=25]

[jump storage="epend.ks" target="*start"]





;//==============================
;//三回のバトルを終えて勝利数が２以上である場合
*Hiroin_Root_4_2|セクシーな先生


;#################################################
*Ep027|Sexy teacher
;#################################################

;//[SCENE id=27]
[SCENE id=15]

;//////////////////////////////////
;//ヒロイン４理想ルート開始
;//////////////////////////////////






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



My teacher became a sexy woman, just as I wanted her to be.
[cpg]


Everything changed, from her makeup to her clothes. Even her gestures seemed to have changed.
[cpg]


This was evident in the reactions of those around me.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue074"]
[OnName num="kozue"]
"Hey, you can't run in the hallway.
[cpg cn=true]


[OnName num="male_student_1"]
Excuse me."
[cpg cn=true]


A male student was embarrassed by the teacher's warning.
[cpg]


[OnName num="male_student_2"]
She has become beautiful, hasn't she?
[cpg cn=true]


The change in her appearance was so noticeable that even the male students and teachers at the school couldn't help but notice.
[cpg]


The male students and teachers of the school were also glued to her.
[cpg]


I spent my days thinking, "I'm okay with this.
[cpg]


[OnName num="takuma"]
Sensei.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue075"]
[OnName num="kozue"]
Oh, Shikata-kun. What's wrong?
[cpg cn=true]


I called out to the teacher.
[cpg]


[OnName num="takuma"]
After school.
[cpg cn=true]


I gently whisper in his ear. The teacher will understand everything.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kozue076"]
[OnName num="kozue"]
"Eh...... yeah, okay."
[cpg cn=true]


The teacher blushes a little. I'm looking forward to after school.
[cpg]


[OnName num="takuma"]
I'll be nice to you. Don't worry."
[cpg cn=true]


She generally listens to what I say.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


It is no exaggeration to say that she is now my ideal teacher.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


[OnName num="takuma"]
She has changed, hasn't she?
[cpg cn=true]


[OnName num="takuma"]
She used to be sober, but now she looks different.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue077"]
[OnName num="kozue"]
'I wonder so. ...... Have I changed that much?
[cpg cn=true]


[OnName num="takuma"]
I've changed. I think you've changed a lot.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue078"]
[OnName num="kozue"]
"...... Heh. If you're happy, I'm happy too.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





And then, another day. Me and my teacher came to my room.
[cpg]


Parents are coming home late today. We can do whatever we want ......, but there's something I'm curious about first.
[cpg]
[FG f="CHA04_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="takuma"]
I have a few questions. Why did you agree to play with me in the first place?
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue079"]
[OnName num="kozue"]
That's because ...... Iiogashi asked me to. He seemed really worried about you.
[cpg cn=true]


[OnName num="takuma"]
Was that so?
[cpg cn=true]


[FG f="CHA04_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kozue080"]
[OnName num="kozue"]
And ...... it's a little bit of a weakness, or ...... to be seen in such an embarrassing place.
[cpg cn=true]


[OnName num="takuma"]
What?
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue081"]
[OnName num="kozue"]
No, it's really nothing!
[cpg cn=true]


I knew he was vulnerable. I guess I can't ask for details.
[cpg]


I think it's probably not that big of a weakness for the teacher to worry about.
[cpg]


But I should be thankful to Sakura. But what I love most right now is you.
[cpg]


[FG f="CHA04_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue082"]
[OnName num="kozue"]
Speaking of which, are you done with the dream?
[cpg cn=true]


[OnName num="takuma"]
Yes, thanks to you. Thanks to you.
[cpg cn=true]


Yes, before I knew it, I had stopped having that dream.
[cpg]


I had to get used to the idea that I could manage to be in a relationship with someone else.
[cpg]


The illness occurred when I was struggling with the inability to idealize others in the first place.
[cpg]




;//ブラックアウト

;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************





The next day. On a weekday afternoon, the teacher and I pass each other in the hallway.
[cpg]


[FG f="CHA04_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue083"]
[OnName num="kozue"]
「……」
[cpg cn=true]


He smiles and waves. No one around us can guess what it means.
[cpg]


No one knows about our relationship. This also led to a strange sense of immorality.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************





Then, after school ......
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kozue084"]
[OnName num="kozue"]
Hey, Shikata-kun,......, are you free after this?
[cpg cn=true]


[OnName num="takuma"]
Yes. Perhaps my parents will come home."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue085"]
[OnName num="kozue"]
Then, you can't ......
[cpg cn=true]


[OnName num="takuma"]
I'll introduce you to my girlfriend then.
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue086"]
[OnName num="kozue"]
Oh, God. Not until you graduate, okay?
[cpg cn=true]


Me and the teacher are heading to my place again.
[cpg]



;//ブラックアウト

;//========================================
;//●ＣＧ（ベッドに倒れているヒロイン。近づく主人公）ev_80
;//人物１：ヒロイン４　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_80_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]

We flirt together. I feel him by my side.
[cpg]

[VOICE f="Kozue087"]
[OnName num="kozue"]
I'm thankful that I met Shikata-kun.
[cpg cn=true]


[OnName num="takuma"]
Heh. Why is that?
[cpg cn=true]


[VOICE f="Kozue088"]
[OnName num="kozue"]
I feel like I've grown a step more as a teacher than as a woman.
[cpg cn=true]


[VOICE f="Kozue089"]
[OnName num="kozue"]
It's the same with my studies. It's not enough for a teacher to want her students to be like this.
[cpg cn=true]


I think it might be something like that.
[cpg]


I was me and I thought I was a little more capable of leading women than I had been when we first started dating.
[cpg]


This is probably an indication that the teacher wanted a somewhat more forceful man.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[FG f="CHA04_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue090"]
[OnName num="kozue"]
'And yet, there really isn't ...... anyone here, is there?
[cpg cn=true]


[OnName num="takuma"]
Yes," she said. The only people I live with are my two parents, and even they are like this when they come home late.
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue091"]
[OnName num="kozue"]
I'd like to cook for you if you like.　I'll cook for you, if you don't mind using the ingredients in the fridge.
[cpg cn=true]


The teacher, I noticed, was no longer sloppy.
[cpg]


Rather, I feel like a solid adult woman.
[cpg]


[OnName num="takuma"]
"Oh, then there's something I want you to do."
[cpg cn=true]


[FG f="CHA04_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue092"]
[OnName num="kozue"]
"What is it, ......?　What is it?
[cpg cn=true]



;//========================================
;//●ＣＧ（水着エプロン。恥ずかしそうにしながらも幸せそうなヒロイン）ev_77
;//人物１：ヒロイン４　服装１：水着エプロン
;//場所　：主人公の家＿キッチン
;//時間　：夜
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_77_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Kozue093"]
[OnName num="kozue"]
Is this what you want me to do at ......?
[cpg cn=true]


[OnName num="takuma"]
"Yes. You look great.
[cpg cn=true]



[VOICE f="Kozue094"]
[OnName num="kozue"]
I wonder if it's true. ......, I'm just embarrassed.
[cpg cn=true]


[OnName num="takuma"]
"Isn't it good that you're embarrassed, too?"
[cpg cn=true]



[VOICE f="Kozue095"]
[OnName num="kozue"]
I'm not going to cook like this. This is so hard to cook with."
[cpg cn=true]


[OnName num="takuma"]
It's cute. You're so cute.
[cpg cn=true]



[VOICE f="Kozue096"]
[OnName num="kozue"]
"...... so?"
[cpg cn=true]


Sensei seems not to be satisfied. I'm going to make her even prettier.
[cpg]


I want to make her so cute that no man will look back at her when she walks down the street.
[cpg]


And that lover is unquestionably me.
[cpg]




;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

;//ＥＮＤ　ヒロイン４理想ルート

[system end4=true]
;//[SCENE id=38]
[SCENE id=26]
[jump storage="epend.ks" target="*start"]



;//==============================

