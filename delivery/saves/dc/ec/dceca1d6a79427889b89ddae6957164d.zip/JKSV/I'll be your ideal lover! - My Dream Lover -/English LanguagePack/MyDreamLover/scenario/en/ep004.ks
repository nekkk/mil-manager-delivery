
*start

;////////////////////////////////////////////////////////////////////
;//以下、ヒロイン３のイベント
;////////////////////////////////////////////////////////////////////






;//////////////////////////////////
;//ヒロイン３一回目のイベント
;//『お菓子作りバトル』
;//////////////////////////////////



;//==============================
;//ヒロイン３一回目のイベント　前置き
;//☆ヒロインのイベント前置き
*HiStory3_01|お菓子作りバトル


;#################################################
*Ep004|Sweets Making Battle
;#################################################

;//[SCENE id=4]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************





[OnName num="takuma"]
Iyo. Mono no"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono054"]
[OnName num="monono"]
Oh, senior. Thanks."
[cpg cn=true]


Mono leaves without bowing. There is no affection or anything.
[cpg]

[free time=1000]

I'd like to go up to her house somehow.
[cpg]


Well, how can I do that?　I need some kind of trigger.
[cpg]


I should talk about something I can only do at home.
[cpg]


Cooking, for example, is something that can only be done at home.
[cpg]



;//==============================
;//ヒロイン３一回目のイベント　バトルパート
;//☆ヒロインのイベントバトルパート


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


One day in class.
[cpg]

I was thinking about how to make Mono the ideal junior.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono055"]
[OnName num="monono"]
"Hello?　Are you listening, senpai?
[cpg cn=true]


[OnName num="takuma"]
"Yeah, I'm here. I'm listening.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono056"]
[OnName num="monono"]
I bought a new cookbook. It's not a cookbook. It's more like a pastry book.
[cpg cn=true]


[OnName num="takuma"]
"......." That's surprising.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono057"]
[OnName num="monono"]
What is it?　Do I look like I can't do that?
[cpg cn=true]


[OnName num="takuma"]
I'd like to see you cook. Can I come visit you sometime?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono058"]
[OnName num="monono"]
I'm sure you'll be able to find a way. You can't make sweets anyway, can you?
[cpg cn=true]


[OnName num="takuma"]
"That's rude. Then, do you want to play?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono059"]
[OnName num="monono"]
"Yes. Okay, the one who makes the best pastry wins.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono060"]
[OnName num="monono"]
How about we agree that the loser has to do as he says?
[cpg cn=true]


[OnName num="takuma"]
"Yes, I'll take it. I'll take it.
[cpg cn=true]



;//++++++++++++++++++++++++++
;//バトル開始画面
;//++++++++++++++++++++++++++


[SE f="se006"]
;//【ＳＥ】『バトル開始』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_bs3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

;//[CutBG g="sys_cut_bwin3"]



;//++++++++++++++++++++++++++
;//バトル画面を表示
;//++++++++++++++++++++++++++




Then, one day off. We got together at her house and had a baking contest.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono061"]
[OnName num="monono"]
"Hello, senior. Senpai."
[cpg cn=true]


I've already thought of the item I'm going to confront her with. I choose it ......
[cpg]



;//アイテム選択　『砂糖を混ぜたホイップクリーム』を選んだ時は勝った場合へ進む
;//それ以外のものを選んだ場合負けた場合へ進む
*battle_item_select_00|Candy making battle

[if exp={getFlagValue("getItemNum_01") == 10}]
[jump target="*battle_win_31"]
[endif]

[jump target="*battle_lose_31"]

;//[SelectItem n=10 w=*battle_win_31 l=*battle_lose_31]
どれを使おう…
[cpg]
;//[endswitch]



;//==============================
;//勝った場合　※正しいアイテムを選んだ場合
*battle_win_31|お菓子作りバトル

[stflag HiWinFlg_03 = 1]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





[OnName num="takuma"]
I've already thought of the items I'm going to confront her with. I bought the ingredients.
[cpg cn=true]


[FG f="CHA03_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono062"]
[OnName num="monono"]
Really?　You are strangely clever, aren't you?
[cpg cn=true]


[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono063"]
[OnName num="monono"]
"Well, let's make a cake. ......
[cpg cn=true]


I prepared whipped cream mixed with sugar in advance.
[cpg]


The actuality of the particulars is that the actuality of the particulars is not really a problem.
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono064"]
[OnName num="monono"]
'Whew,...... this is all done. What's your senior's?
[cpg cn=true]


[OnName num="takuma"]
I'm making sweet potatoes. I'm pretty good at it.
[cpg cn=true]


[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono065"]
[OnName num="monono"]
I'm surprised that you're the one who made ...... the sweet potato.
[cpg cn=true]


[FG f="CHA03_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono066"]
[OnName num="monono"]
Then, I'll start with the one I made. ......
[cpg cn=true]


[FG f="CHA03_p5_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Monono067"]
[OnName num="monono"]
Oh, it's so sweet!　What is this? Why is it so sweet?
[cpg cn=true]


[OnName num="takuma"]
"You must have mixed up the amounts.　Mine tastes good.
[cpg cn=true]


[FG f="CHA03_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono068"]
[OnName num="monono"]
Oh no, I can't believe I lost at cooking. ......
[cpg cn=true]


;//移植のためシーンをカットしています


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


The loser listens to the winner. That was the deal. ......
[cpg]

[OnName num="takuma"]
'Well then, I guess I'll have to ask you to arrange my next date with you.
[cpg cn=true]


;//[FACE method="change_4" pos="2/3"]
[VOICE f="Monono069"]
[OnName num="monono"]
...... "I don't have a choice."
[cpg cn=true]


This was about all I could come up with.
[cpg]

More than that, I had a longing for something like a dodgy junior, so just being able to get close to that was a bonus.
[cpg]


;//++++++++++++++++++++++++++
;//勝利画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba3w.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se007"]
;//【ＳＥ】『バトル勝利』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト
;//☆次は負けた場合のイベント

[jump target="*before_select_chara"]
;//==============================
;//負けた場合　※正しいアイテムを選ばなかった場合
*battle_lose_31|お菓子作りバトル



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





It was supposed to be ......, but I didn't have just the right stuff on hand.
[cpg]


The first thing that comes to mind is the fact that the two of them are not only good at what they do, but they are also very good at what they do.
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono070"]
[OnName num="monono"]
The first thing that comes to my mind is that I want to make a cake. What are you trying to make?
[cpg cn=true]


[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono071"]
[OnName num="monono"]
Is it a sweet potato, judging from the ingredients?　Well, I win no matter what I make.
[cpg cn=true]


Then, he finishes making the pastry.
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono072"]
[OnName num="monono"]
Yes, it's ready. Shall we eat?
[cpg cn=true]


[FG f="CHA03_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono073"]
[OnName num="monono"]
"Well, ...... today's is so-so. I don't feel like I'm losing to my seniors.
[cpg cn=true]


[OnName num="takuma"]
"Damn, ......."
[cpg cn=true]


[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono074"]
[OnName num="monono"]
The first thing to do is to make sure that you have a good time. It's not inedible, but it's not tasty either.
[cpg cn=true]


[FG f="CHA03_p5_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono075"]
[OnName num="monono"]
I won, didn't I?　If you have an excuse, I'm all ears.
[cpg cn=true]


In the end, I was promised to be the errand boy for the next week.
[cpg]



;//++++++++++++++++++++++++++
;//敗北画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba3l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se008"]
;//【ＳＥ】『バトル敗北』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト


[jump target="*before_select_chara"]
;//ヒロイン３一回目のイベント　ここまで
;//☆ここから次のイベント


;//////////////////////////////////
;//ヒロイン３二回目のイベント
;//『怪談バトル』
;//////////////////////////////////



;//==============================
;//ヒロイン３二回目のイベント　前置き
;//☆ヒロインのイベント前置き
*HiStory3_02|Ghost Story Battle


;#################################################
*Ep008|怪談バトル
;#################################################

;//[SCENE id=8]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************


Today, too, I was thinking of ways to make Mono a cute junior.
[cpg]

Mono lacks the cuteness of a junior.
[cpg]

But I guess even she has her weaknesses.
[cpg]

I'd like to see the side of her that is afraid of things like bugs and ghosts .......
[cpg]


;//==============================
;//ヒロイン３二回目のイベント　バトルパート
;//☆ヒロインのイベントバトルパート


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************




[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono076"]
[OnName num="monono"]
What is it?"
[cpg cn=true]


[OnName num="takuma"]
I'd like to see the side of her that's afraid of bugs, ghosts,  things like that. I hear it's haunted.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono077"]
[OnName num="monono"]
I'm going to ask you one more time, what is that? If it's haunted, I'll never go there.
[cpg cn=true]


[OnName num="takuma"]
Are you afraid of them?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Monono078"]
[OnName num="monono"]
No way. Don't worry, I'm not afraid of them.
[cpg cn=true]

[OnName num="takuma"]
Then it's settled then.
[cpg cn=true]


It seems I was able to stimulate his competitive nature.
[cpg]



;//++++++++++++++++++++++++++
;//バトル開始画面
;//++++++++++++++++++++++++++



[SE f="se006"]
;//【ＳＥ】『バトル開始』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_bs3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[CutBG g="sys_cut_bwin3"]



;//++++++++++++++++++++++++++
;//バトル画面を表示
;//++++++++++++++++++++++++++


So, I snuck into the school at night.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]



[OnName num="takuma"]
The atmosphere was perfect. Let's have a ghost story then.
[cpg cn=true]


[VOICE f="Monono079"]
[OnName num="monono"]
Why do you say ...... that such things bring in the spirits?
[cpg cn=true]


[OnName num="takuma"]
I've come this far, I'd like to see the real thing.
[cpg cn=true]


The actual "Ghost Story" is a great way to get a good look at the world of ghosts and spirits. All right,......, this is the time to use this.
[cpg]


;//アイテム選択　『ろうそく』を選んだ時は勝った場合へ進む
;//それ以外のものを選んだ場合負けた場合へ進む
*battle_item_select_00|怪談バトル

[if exp={getFlagValue("getItemNum_02") == 15}]
[jump target="*battle_win_32"]
[endif]

[if exp={getFlagValue("getItemNum_01") == 15}]
[jump target="*battle_win_32"]
[endif]

[jump target="*battle_lose_32"]

;//[SelectItem n=3 w=*battle_win_32 l=*battle_lose_32]
どれを使おう…
[cpg]
;//[endswitch]



;//==============================
;//勝った場合　※正しいアイテムを選んだ場合
*battle_win_32|怪談バトル

[stflag HiWinFlg_03 = 1]


[OnName num="takuma"]
I've prepared these for you. It's not just a candle, it's something used in séances. ......
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Monono080"]
[OnName num="monono"]
"No!　Don't do that, you'll get in trouble if it catches fire.
[cpg cn=true]


It seems to be a thing not to say directly that you are afraid of ghosts.
[cpg]

Then, after lighting a candle and creating a very scary atmosphere,......
[cpg]

[OnName num="takuma"]
I'm going to start telling a ghost story. I'll do this ...... Hey, don't cover your ears."
[cpg cn=true]


;//========================================
;//●ＣＧ（へたりこんでいるヒロイン。時間帯を夜にしてください）ev_48
;//人物１：ヒロイン３　服装１：制服
;//場所　：学園廊下
;//時間　：夜
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]

;**【ＣＧ】 ev_48_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Monono081"]
[OnName num="monono"]
"Oh no!　I just heard a noise over there.
[cpg cn=true]


[OnName num="takuma"]
Maybe it's a ghost.
[cpg cn=true]


;**【ＣＧ】 ev_48_a ***********************
[CG id=11 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Monono082"]
[OnName num="monono"]
Let's get out of here. I mean, put out the fire.
[cpg cn=true]


[OnName num="takuma"]
It's gonna be dark.
[cpg cn=true]


;**【ＣＧ】 ev_48_b ***********************
[CG id=11 index=2 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Monono083"]
[OnName num="monono"]
That's .......
[cpg cn=true]


I had never seen her like this before. I watched her with amusement. ......
[cpg]


I feel like I'm getting a little bit closer to being a cute junior.
[cpg]

;//++++++++++++++++++++++++++
;//勝利画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba3w.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se007"]
;//【ＳＥ】『バトル勝利』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト
;//☆次は負けた場合のイベント

[jump target="*before_select_chara"]
;//==============================
;//負けた場合　※正しいアイテムを選ばなかった場合
*battle_lose_32|怪談バトル


but I was so unprepared I didn't know what to use.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Monono084"]
[OnName num="monono"]
'Let's go home now!　I'll give you a sermon when I get back."
[cpg cn=true]


[OnName num="takuma"]
Wait, a sermon? ......
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Monono085"]
[OnName num="monono"]
I guess you started out with a motive of scaring people and wanting to see their unexpected side.
[cpg cn=true]


I had to leave the school by the hand. ......
[cpg]


;//++++++++++++++++++++++++++
;//敗北画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba3l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se008"]
;//【ＳＥ】『バトル敗北』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト


[jump target="*before_select_chara"]
;//ヒロイン３二回目のイベント　ここまで
;//☆ここから次のイベント




;//////////////////////////////////
;//ヒロイン３三回目のイベント
;//『料理バトル』
;//////////////////////////////////



;//==============================
;//ヒロイン３三回目のイベント　前置き
;//☆ヒロインのイベント前置き
*HiStory3_03|Cooking Battle


;#################################################
*Ep0012|料理バトル
;#################################################

;//[SCENE id=12]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************


It has been rumored for a long time that Mono is a good cook.
[cpg]

I guess it is one of her strong points. If that's the case, then ......
[cpg]

I want to show her that I'm even better than that and show her that I'm her senior.
[cpg]

After that thought occurred to me, I decided to study cooking a little more.
[cpg]



;//==============================
;//ヒロイン３三回目のイベント　バトルパート
;//☆ヒロインのイベントバトルパート





[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Monono086"]
[OnName num="monono"]
Cooking competition?　You sound like a child when you say that, senior. Was it always like that?
[cpg cn=true]


She was even harsher than usual. He was even harsher than usual.
[cpg]

[OnName num="takuma"]
I won't lose. Let's compete in the kitchen of my house.
[cpg cn=true]


I invite him to my house in the confusion of the moment. But he didn't say anything.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Monono087"]
[OnName num="monono"]
"I don't know. I don't like kitchens where I don't know how to win.
[cpg cn=true]


......Maybe the battle has already begun?
[cpg]

If she refuses before I invite her to my house, it's not a battle.
[cpg]



;//++++++++++++++++++++++++++
;//バトル開始画面
;//++++++++++++++++++++++++++


[SE f="se006"]
;//【ＳＥ】『バトル開始』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_bs3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************

;//[CutBG g="sys_cut_bwin3"]



;//++++++++++++++++++++++++++
;//バトル画面を表示
;//++++++++++++++++++++++++++

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]


I think. There must have been something useful at a time like this.
[cpg]


;//アイテム選択　『読むだけで交渉上手になる本』を選んだ時は勝った場合へ進む
;//それ以外のものを選んだ場合負けた場合へ進む
*battle_item_select_00|料理バトル

[if exp={getFlagValue("getItemNum_03") == 6}]
[jump target="*battle_win_33"]
[endif]

[if exp={getFlagValue("getItemNum_02") == 6}]
[jump target="*battle_win_33"]
[endif]

[if exp={getFlagValue("getItemNum_01") == 6}]
[jump target="*battle_win_33"]
[endif]

[jump target="*battle_lose_33"]

;//[SelectItem n=4 w=*battle_win_33 l=*battle_lose_33]
Which one should I use...
[cpg]
;//[endswitch]



;//==============================
;//勝った場合　※正しいアイテムを選んだ場合
*battle_win_33|料理バトル

[stflag HiWinFlg_03 = 1]

I remember. I bought a book the other day.
[cpg]

Negotiate with the right type. If you're like her, it's better to flatter her.
[cpg]

[OnName num="takuma"]
If it's someone like her, you're at a disadvantage if you're competing in a different kitchen.
[cpg cn=true]


[OnName num="takuma"]
Also, I genuinely want to try your cooking.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Monono088"]
[OnName num="monono"]
"......, what's that?"
[cpg cn=true]


I felt like I was hitting on her. But she's blushing.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Monono089"]
[OnName num="monono"]
I had no choice, I couldn't refuse her if she told me that much.
[cpg cn=true]



;//ブラックアウト

After that, we had a cooking showdown, but I got something more important than that win or loss.
[cpg]

That is ...... I was suddenly seduced and saw things blush.
[cpg]

Maybe, but I think the thing has been on edge for a long time.
[cpg]

I try to be my perfect self, so I'm vulnerable to this kind of surprise. ......
[cpg]

[OnName num="takuma"]
I think, "I don't know. You have to love your imperfect self too."
[cpg cn=true]


When I talked to him a little bit about that, he said, "I don't like you.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Monono090"]
[OnName num="monono"]
I told him a little about that, and he blushed and said, "I don't like you, senpai.
[cpg cn=true]


I blushed and replied, "I don't like my senpai.
[cpg]

;//++++++++++++++++++++++++++
;//勝利画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba3w.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se007"]
;//【ＳＥ】『バトル勝利』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト
;//☆次は負けた場合のイベント

[jump target="*before_select_chara"]
;//==============================
;//負けた場合　※正しいアイテムを選ばなかった場合
*battle_lose_33|料理バトル



In the end, I couldn't convince him and it became a problem before the battle.
[cpg]

Or maybe it's my own fault, I don't know.
[cpg]


;//++++++++++++++++++++++++++
;//敗北画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba3l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se008"]
;//【ＳＥ】『バトル敗北』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト


;//[jump target="*before_select_chara"]
;//ヒロイン３三回目のイベント　ここまで
;//☆ここから次のイベント


*before_select_chara|
[if exp={getFlagValue("Count_Selected") == 3}]
[jump storage="epResalt.ks" target="*Go_to_Resalt"]
[endif]
[jump storage="ep001.ks" target="*before_select_chara"]

;////////////////////////////////////////////////////////////////////
;//以下、ヒロイン３分岐後のシナリオ
;////////////////////////////////////////////////////////////////////


;//qwe

;//==============================
;//三回のバトルを終えて勝利数が１以下であり、このヒロインを３回以上選んでいる場合
*Hiroin_Root_3_1|ふぬけな人


;#################################################
*Ep022|Dumbass
;#################################################

;//[SCENE id=22]
[SCENE id=10]
;//////////////////////////////////
;//ヒロイン３現実ルート開始
;//////////////////////////////////



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





Days have passed since then.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono091"]
[OnName num="monono"]
I always wanted a boyfriend like this. A man who would do what I wanted. ......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono092"]
[OnName num="monono"]
And a man like you, a moron, is the best.
[cpg cn=true]


I couldn't deny anything. The first thing to do is to make sure that you have a good time with your family and friends.
[cpg]


I thought it wasn't supposed to be like this, but we kept going out.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_to"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

Then, when we were having lunch together at the school.
[cpg]


A rather handsome male student came up to me and said, "Hey, Kosaka-san.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="male_student"]
Hey, Kosaka-san. Why are you dating this guy?
[cpg cn=true]


He was rude from the start, but I couldn't say anything.
[cpg]


[OnName num="male_student"]
Kosaka-san is cute, good at studying and sports, and there must be a more suitable man for her.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono093"]
[OnName num="monono"]
I was just trying to say that I was the one.　I'm telling you, I only have my senpai.
[cpg cn=true]


[OnName num="takuma"]
The ...... of things.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono094"]
[OnName num="monono"]
"It's rare to find a man who's such a dope. It's a good thing I'm leading him.
[cpg cn=true]


I guess that's why they chose me. ......
[cpg]


The actual "I'm not a fan of the way you do it," he said, "but I'm not a fan of the way you do it either.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono095"]
[OnName num="monono"]
"Senior. Would you like to come to my house today?"
[cpg cn=true]


[OnName num="takuma"]
"Yes,......?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono096"]
[OnName num="monono"]
Yes. I think you must be getting lonely.
[cpg cn=true]


I can't deny it.
[cpg]


[OnName num="takuma"]
You don't seem like a junior, do you?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono097"]
[OnName num="monono"]
I'm not supposed to be like a senior.
[cpg cn=true]


Indeed. Maybe I made the wrong choice little by little. ......
[cpg]


I'm just being led on by something that is so far from my ideal image of a junior.
[cpg]



;//ブラックアウト

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************



Then we are alone in her room.
[cpg]

She is looking at me with a passionate gaze.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono098"]
[OnName num="monono"]
'...... senpai, will you always love me?'
[cpg cn=true]


[OnName num="takuma"]
"Of course I will,......."
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono099"]
[OnName num="monono"]
I'm so happy,......, I love you, too.
[cpg cn=true]


What does it mean to say that I love them?
[cpg]


 Like a pet, maybe.
[cpg]


The next morning, the first thing I did was to go to the bathroom.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_to"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





The next morning. The next morning, I headed off to the school with the thing again.
[cpg]


[OnName num="female_student_A"]
The next morning, I was on my way to the school with Mono again.
[cpg cn=true]


[OnName num="female_student_B"]
Really. Kosaka-san could have picked cooler boys."
[cpg cn=true]


I could hear the gossip. I was filled with a sense of shame.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono100"]
[OnName num="monono"]
I love seniors who aren't cool. I love seniors who aren't cool.
[cpg cn=true]


I didn't answer anything and just walked away.
[cpg]


I couldn't make Mamoru into my ideal junior. But I can't break up with her now.
[cpg]


In fact, I loved Mono and ...... she probably does too.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono101"]
[OnName num="monono"]
Would you go buy me lunch? Senior."
[cpg cn=true]


[OnName num="takuma"]
"...... what can I get you?"
[cpg cn=true]


I can't say why me here. I can't say.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono102"]
[OnName num="monono"]
"I'll leave it to your sense of taste."
[cpg cn=true]


[OnName num="takuma"]
"Aren't you going to complain no matter what I buy you,......?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono103"]
[OnName num="monono"]
"Of course not. I think he wants to be abused too.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono104"]
[OnName num="monono"]
But he's still devoted to me, isn't he?
[cpg cn=true]


[OnName num="takuma"]
That's ......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono105"]
[OnName num="monono"]
I'm sure no one knows how to treat senpai better than I do. Hmm.
[cpg cn=true]


[OnName num="takuma"]
......
[cpg cn=true]


I couldn't say anything else. I'm a lover, but not an equal.
[cpg]


I didn't know where this ...... came from anymore.
[cpg]




;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

;//ＥＮＤ　ヒロイン３現実ルート


;//[SCENE id=34]
[SCENE id=22]
[jump storage="epend.ks" target="*start"]





;//==============================
;//三回のバトルを終えて勝利数が２以上である場合
*Hiroin_Root_3_2|可愛い後輩


;#################################################
*Ep023|Cute junior.
;#################################################

;//[SCENE id=23]
[SCENE id=11]

;//////////////////////////////////
;//ヒロイン３理想ルート、および中立ルート開始
;//////////////////////////////////



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





And then. I was a cute junior.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Monono106"]
[OnName num="monono"]
'Senior. I made that ...... lunch box."
[cpg cn=true]


[OnName num="takuma"]
"Oh, really? Then I'll have it.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono107"]
[OnName num="monono"]
"Heh heh heh. I'm a little nervous about this.
[cpg cn=true]


[OnName num="takuma"]
"I only have one set of ...... chopsticks."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Monono108"]
[OnName num="monono"]
What?　Really? I have to go to the store.
[cpg cn=true]


She is friendly and a little clumsy. I was able to make Mono the ideal figure.
[cpg]


[OnName num="takuma"]
I said, "Well, okay. You feed me."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono109"]
[OnName num="monono"]
That's going to take a long time. ......
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





The distance between us shortened rapidly. And then ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************




[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="takuma"]
You know, Mono. How did you get on ...... with me?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono110"]
[OnName num="monono"]
"You want to talk about the old days?　I'm not going to tell you.
[cpg cn=true]


[OnName num="takuma"]
If Cherry Blossom had just asked me to do it, I wouldn't have done it.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono111"]
[OnName num="monono"]
I'm not sure I'd ...... be able to say no to a request like that. If you ask me to do something like that, I can't say no. ......
[cpg cn=true]


[OnName num="takuma"]
...... what kind of request was it?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono112"]
[OnName num="monono"]
The first thing you need to do is to get a good idea of what you're looking for. I was asked to do so by Iyengashi, and that's all I'm saying.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Monono113"]
[OnName num="monono"]
The actuality that the actuality is that you can't get a lot of these things. The actual a lot of people are going to be able to get a lot more information on the web.
[cpg cn=true]


The actual a lot of the time, the actual a lot of the time, the actual a lot of the time, the actual a lot of the time, the actual a lot of the time, the actual a lot of the time.
[cpg]


Then there was silence for a while.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono114"]
[OnName num="monono"]
"Senpai, we are already dating, aren't we? We are already dating, right?
[cpg cn=true]


[OnName num="takuma"]
"Well, that's how it is. ...... but neither of us has confessed to each other.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono115"]
[OnName num="monono"]
"That's right,......."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Monono116"]
[OnName num="monono"]
"I'm sorry, ....... I'm sorry . I like you.
[cpg cn=true]


[OnName num="takuma"]
"Yeah, me too. I love you too, Mono.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono117"]
[OnName num="monono"]
"I love you, ...... senior. I'm going to give you everything I have.
[cpg cn=true]




;//ブラックアウト

;//移植のためシーンをカットしています

;//========================================
;//●ＣＧ（寝ているヒロインに近づく主人公。至近距離）ev_56
;//人物１：ヒロイン３　服装１：制服（はだけ）
;//人物ex：主人公　　　服装ex：制服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_56_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]

We cuddled for a while.
[cpg]


[VOICE f="Monono118"]
[OnName num="monono"]
I'd like to have as many children as possible," he said.
[cpg cn=true]


[OnName num="takuma"]
I'd love to have as many as I can. How about you?
[cpg cn=true]


;**【ＣＧ】 ev_56_a ***********************
[CG id=12 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Monono119"]
[OnName num="monono"]
If you want, I can have as many as you want. I'll do my best.
[cpg cn=true]


[VOICE f="Monono120"]
[OnName num="monono"]
I want to give you everything you want.
[cpg cn=true]


I want to give you everything you want, senior.
[cpg]


There was no remnant of his sharp tongue until now.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************





We were a couple that stood out even in the school.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono121"]
[OnName num="monono"]
I said to her, "Hello, senpai. I've been looking for you.
[cpg cn=true]


I was so spoiled by her.
[cpg]


[OnName num="takuma"]
I said, "Sorry, I have to go to the bathroom. I had to go to the bathroom.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono122"]
[OnName num="monono"]
"Don't apologize. Come on, let's have dinner together.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono123"]
[OnName num="monono"]
I made lunch again today.
[cpg cn=true]


[OnName num="takuma"]
I see. I'm looking forward to ......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono124"]
[OnName num="monono"]
By the way, senior, are you okay with the dream yet?
[cpg cn=true]


[OnName num="takuma"]
"Yeah,......, I think I'm okay now."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]


The stress from not being able to change her into your ideal or something like that was probably the cause.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





We were on our way home together. Then, the thing asked me this question.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono125"]
[OnName num="monono"]
Which do you like better, short or long hair?
[cpg cn=true]


[OnName num="takuma"]
If it's ...... Mono's, I think long hair would suit you too.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono126"]
[OnName num="monono"]
Heh, heh. I see. ...... heh."
[cpg cn=true]


He smiles and tries to find out what I like.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





After that, the two of them came to my room together.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Monono127"]
[OnName num="monono"]
I always think, "I hope these happy days will last forever.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono128"]
[OnName num="monono"]
I sometimes feel uneasy. I wonder if it's okay to be this happy.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono129"]
[OnName num="monono"]
But ...... probably no one can interfere with that, right?
[cpg cn=true]


[OnName num="takuma"]
Of course. Of course, we are invincible in a sense right now.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono130"]
[OnName num="monono"]
What's that,......?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono131"]
[OnName num="monono"]
But, yes,...... if you say we are so happy that no one can get in our way, then maybe we are.
[cpg cn=true]


;//移植のためシーンをカットしています
;//ブラックアウト

;//[Live2d target=8]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono132"]
[OnName num="monono"]
I'm going to ...... tell you the truth.
[cpg cn=true]


[OnName num="takuma"]
What is it?　What? Suddenly you changed your mind.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono133"]
[OnName num="monono"]
I was going to lead you on at first.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono134"]
[OnName num="monono"]
I liked men with more imperfections and openings.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono135"]
[OnName num="monono"]
Of course, I love my current senpai, too,......, but I'm just saying that I had such ambitions.
[cpg cn=true]


So that's how it was. What should I do?
[cpg]


I know it's not going to change much now. ......
[cpg]





;//■選択肢
[switch]
[case "I'd rather be the perfect guy."]
	[swap]
	[jump target="*Hiroin_Root_3_21"]
[case "I want to be the boyfriend that thing wants me to be"]
	[swap]
	[jump target="*Hiroin_Root_3_22"]
[endswitch]


;//■選択肢
;//１、むしろ完璧な男になりたい
;//２、もののが望む彼氏になりたい



;//==============================
;//１、むしろ完璧な男になりたい

;#################################################
*Ep024|完璧な男になりたい
;#################################################
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

*Hiroin_Root_3_21|I want to be the perfect man


;//[SCENE id=24]
[SCENE id=12]

;//////////////////////////////////
;//ヒロイン３理想ルートに分岐
;//////////////////////////////////





Hearing her words, I thought the opposite.
[cpg]


I want to be the perfect guy and make Mono more affectionate.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono136"]
[OnName num="monono"]
What's the matter, senpai? You're thinking about something, aren't you?
[cpg cn=true]


[OnName num="takuma"]
No, it's nothing. Nothing.
[cpg cn=true]



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono137"]
[OnName num="monono"]
You don't have to think about ...... deep things anymore.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono138"]
[OnName num="monono"]
That was just something I said.
[cpg cn=true]


[OnName num="takuma"]
"......, okay."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono139"]
[OnName num="monono"]
"More than that, maybe we need to take care of the present.
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


;//そんなことを言いながら、俺たちは交わった。
We spent the rest of the evening talking like that.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono140"]
[OnName num="monono"]
;//「気持ちよかったですよ。先輩」
Senior."
[cpg cn=true]



[OnName num="takuma"]
Of the "...... stuff. You said you were looking for an imperfect man.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono141"]
[OnName num="monono"]
"Yes. What's wrong?
[cpg cn=true]


[OnName num="takuma"]
I'd rather be the opposite. I'll be the perfect man.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





So I decided to devote myself to my studies.
[cpg]


My youth, which had been so dull, was now completely transformed.
[cpg]


I spent my days off studying. I don't have a girlfriend next to me.
[cpg]


When I have a girlfriend, I can't help but be motivated by sexual desire. ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono142"]
[OnName num="monono"]
'I have no idea what studying is like when you're a year apart.'
[cpg cn=true]


I thought, "I'm not going to be able to do that," but the thing was coming to my room.
[cpg]


[OnName num="takuma"]
Let me concentrate on my studies. ......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono143"]
[OnName num="monono"]
I don't think so. I want to be pampered by you.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono144"]
[OnName num="monono"]
I want to be pampered by you.　You see, my hair has grown a little longer.
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Monono145"]
[OnName num="monono"]
I do all of this for you, senior. So, please give me a reward.
[cpg cn=true]


I must not give in to my desires here. I know that, but ......
[cpg]


[OnName num="takuma"]
"......, I don't have a choice."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono146"]
[OnName num="monono"]
I did it. Then it's settled."
[cpg cn=true]


;//========================================
;//●ＣＧ（密着する二人。幸せそうなヒロイン）ev_62
;//人物１：ヒロイン３　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_62_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


I stroked her hair.
[cpg]


[VOICE f="Monono147"]
[OnName num="monono"]
I know I'm disturbing my senpai, but I can't stop, can I?
[cpg cn=true]


[OnName num="takuma"]
For me, you are temptation itself.
[cpg cn=true]


[VOICE f="Monono148"]
[OnName num="monono"]
She said, "You say that a lot. I'm not the only one who sees it that way.
[cpg cn=true]


;**【ＣＧ】 ev_62_a ***********************
[CG id=13 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Monono149"]
[OnName num="monono"]
'Even I have a part of me that I'm holding back,...... so please respond to me properly.'
[cpg cn=true]


The actuality of the particulars is that they are not really a lot of.
[cpg]


;//移植のためシーンをカットしています



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



The days go by. The examinations are getting closer and closer. ......
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





 What I strive for has changed because of what she was able to do.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono150"]
[OnName num="monono"]
I was so happy to see her. Are you okay?"
[cpg cn=true]


[OnName num="takuma"]
"...... I don't know either."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono151"]
[OnName num="monono"]
I don't know either. But I want to go to the same place as you.
[cpg cn=true]


[OnName num="takuma"]
If that's the case, we might be classmates if we are ronin.
[cpg cn=true]


I struggled to keep Mono as a junior.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



;//上下に黒帯を入れてください

;//[lbox on]



Time passed. The time I spent with Mono seemed long and short.
[cpg]


I studied and withstood her temptations.
[cpg]


The days passed quickly. The seasons come full circle, and then ......
[cpg]


The announcement of my acceptance. My number was there.
[cpg]


[OnName num="takuma"]
"Yes, I did it. ......
[cpg cn=true]


I was going to live alone from now on. I imagined life on my own.
[cpg]


I could even bring her into my house. ......
[cpg]



;//[lbox off]

;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト
;//========================================
;//●ＣＧ（いちゃつく二人。密着している）ev_64
;//人物１：ヒロイン３　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//備考　：一人暮らしになって、主人公の部屋が変化しています
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_64_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono152"]
[OnName num="monono"]
"Wow," she said, "this is your room? Is this your room?
[cpg cn=true]


[OnName num="takuma"]
"Yes, it's small, but it's not a good place to make out. It's small, but it's not hard to make out with her.
[cpg cn=true]


;//[FG f="CHA03_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono153"]
[OnName num="monono"]
That's true. If you can't do that, it can't be called a room.
[cpg cn=true]


The woman said calmly, but she was still sweet on the subject.
[cpg]


;//＠Ｃev_64の元の位置


[VOICE f="Monono154"]
[OnName num="monono"]
I like ...... senior's hand.
[cpg cn=true]


[VOICE f="Monono155"]
[OnName num="monono"]
I like your hands because they feel like a man's hands. ......
[cpg cn=true]


I respond to her pampering.
[cpg]

We love this kind of time. But still, we can't stay students forever.
[cpg]

I felt it while in the midst of my youth.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





And then...
[cpg]


One year later, Mono came to my school.
[cpg]


Mono and I will always be seniors and juniors.
[cpg]


But the moment came when I could no longer say so.
[cpg]



;//ここから、作中での時間が経過していますので立ち絵を表示しないでください



;//上下に黒帯を入れてください

;//[lbox on]



After I became a member of society, he proposed to me. Once I did it, we would no longer be seniors and juniors.
[cpg]


We would no longer be mere lovers. We will be closer to a married couple.
[cpg]


I had prepared the situation in my own way. Even the rings are ......
[cpg]


I'm sure that whatever I do will please her if it's from ...... now.
[cpg]


Still, I wanted to be the one making the effort.
[cpg]



[VOICE f="Monono156"]
[OnName num="monono"]
"This ...... might be ......."
[cpg cn=true]


The first time I saw the ring, Mono was about to start crying.
[cpg]


[OnName num="takuma"]
I'm going to marry you. Mono."
[cpg cn=true]



[VOICE f="Monono157"]
[OnName num="monono"]
'......Ugh, gusu, uuuaan.'
[cpg cn=true]


I started crying quite loudly. I wonder if I was that happy.
[cpg]



[VOICE f="Monono158"]
[OnName num="monono"]
I ...... have always, always loved you, Takuma.
[cpg cn=true]


I've heard that many times. But I guess that's all there is to it.
[cpg]



;//[lbox off]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





The once cold one is nowhere to be found.
[cpg]



[VOICE f="Monono159"]
[OnName num="monono"]
'......Takuma-san. I love you. Always and from now on."
[cpg cn=true]



[VOICE f="Monono160"]
[OnName num="monono"]
Will you make me yours?
[cpg cn=true]


[OnName num="takuma"]
"Yes, I will. I'll take care of it.
[cpg cn=true]


On the day of the wedding, these were not the words we had discussed. But the words came out of my mouth.
[cpg]


I got my ideal. Me and my partner will be together forever.
[cpg]


Is marriage the graveyard of life?　If we're in the grave, we'll definitely stay together.
[cpg]


With that thought in mind, we were cuddling......
[cpg]



[VOICE f="Monono161"]
[OnName num="monono"]
"Mr. Takuma,...... please pat my head."
[cpg cn=true]



[VOICE f="Monono162"]
[OnName num="monono"]
"Your hair has grown, hasn't it......?　It's all because you wanted it to grow.
[cpg cn=true]



[VOICE f="Monono163"]
[OnName num="monono"]
What shall we do next?　I'm looking forward to it.
[cpg cn=true]


Yes, I am. Our future is limitless.
[cpg]

I was dazzled by the way she said, "What shall we do next?
[cpg]


;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

;//ＥＮＤ　ヒロイン３理想ルート


;//[SCENE id=35]
[SCENE id=23]
[system end3=true]

[jump storage="epend.ks" target="*start"]




;//==============================
;//２、もののが望む彼氏になりたい

;#################################################
*Ep025|I want to be the boyfriend I want
;#################################################
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


*Hiroin_Root_3_22|望む彼氏になりたい

;//[SCENE id=25]
[SCENE id=13]

;//////////////////////////////////
;//ヒロイン３中立ルートに分岐
;//////////////////////////////////








If she wants an imperfect man, that's fine too.
[cpg]


I've always been like that, so I don't really need to work on it.
[cpg]


I decided to stop trying to be perfect.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





And so, the sloppy school life continued.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono164"]
[OnName num="monono"]
Wake up. Have you been asleep all night?
[cpg cn=true]


[OnName num="takuma"]
"N...... ah, ah, I didn't sleep. I didn't sleep.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono165"]
[OnName num="monono"]
"You were snoring with all your might. ...... I'm surprised the teacher isn't angry with you."
[cpg cn=true]


 Things were regaining some of Monono previous tone and sharp tongue.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono166"]
[OnName num="monono"]
I've made it again today.
[cpg cn=true]


[OnName num="takuma"]
Oh. Thank you."
[cpg cn=true]


Still, we were lovers. We were natural with each other.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





After class, we were alone at the school ...... after school.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono167"]
[OnName num="monono"]
I'm a senior. I'm sorry to say this,......, but...
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono168"]
[OnName num="monono"]
I've become the kind of senior I like.
[cpg cn=true]


[OnName num="takuma"]
"Really?　I'm just as full of myself as ever.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono169"]
[OnName num="monono"]
"That's the thing. It's not very pretty, but I like it.
[cpg cn=true]


He was still a little tongue-tied. I felt nostalgic about that.
[cpg]

;//移植のためシーンをカットしています


;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************





We stayed together and the time passed.
[cpg]


I'm still living a sloppy life. That was the kind of man Mono wanted.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



;//ここからヒロインの髪は伸びています





Mono has changed. He has become my ideal.
[cpg]


She is now growing her hair long, which is also one of my ideals.
[cpg]


;//[FG f="CHA03_p5_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono170"]
[OnName num="monono"]
She said, "Why don't you tidy up your room more?　It's so sloppy.
[cpg cn=true]


;//[FG f="CHA03_p5_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono171"]
[OnName num="monono"]
I can see the sloppiness in your clothes and so on. When you are my senior, you can tell just by looking at me that I am sloppy.
[cpg cn=true]


But when I gave him a chance, he regained his former tongue.
[cpg]


;//[FG f="CHA03_p5_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono172"]
[OnName num="monono"]
What's with the grinning ......?
[cpg cn=true]


[OnName num="takuma"]
No, it's nothing. Nothing.
[cpg cn=true]


I was feeling nostalgic about that, too, and we lived happily ever after.
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





;//========================================
;//●ＣＧ（服をはだけた状態で主人公の膝の上で甘えるヒロイン。髪を伸ばしている）ev_65
;//人物１：ヒロイン３　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_pi"]
;**【ＣＧ】 ev_65_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]

The thing was spoiling me.
[cpg]



[VOICE f="Monono173"]
[OnName num="monono"]
I felt at home on ...... senior's lap, didn't I?
[cpg cn=true]


[OnName num="takuma"]
Don't talk to me like a cat.
[cpg cn=true]



[VOICE f="Monono174"]
[OnName num="monono"]
I'm not a cat. I really feel at home.
[cpg cn=true]



[VOICE f="Monono175"]
[OnName num="monono"]
"Hey, senpai,......, please always be my senpai.
[cpg cn=true]



[VOICE f="Monono176"]
[OnName num="monono"]
I like you even when you're sloppy.
[cpg cn=true]




;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

;//ＥＮＤ　ヒロイン３中立ルート


;//[SCENE id=36]
[SCENE id=24]
[system end3=true]

[jump storage="epend.ks" target="*start"]




;//==============================


