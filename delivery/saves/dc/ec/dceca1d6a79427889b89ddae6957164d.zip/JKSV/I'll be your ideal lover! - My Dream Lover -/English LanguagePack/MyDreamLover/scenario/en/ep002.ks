

*start

;//////////////////////////////////
;//ヒロイン１一回目のイベント
;//『コスプレバトル』
;//////////////////////////////////



;//前置きが始まる前に、キャラクター選択前の共通イベントが発生
;//↓
;//共通イベントが終わった後、キャラクター選択
;//↓
;//その後下記の前置きへ



;//==============================
;//ヒロイン１一回目のイベント　前置き
;//☆ヒロインのイベント前置き
;//[if exp={getFlagValue("HiStoryFlg_01") == 1]

*HiStory1_01|コスプレバトル


;#################################################
*Ep002|Cosplay Battle
;#################################################

;//[SCENE id=2]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura036"]
[OnName num="sakura"]
Otakus are really creepy. I wonder how long they've been around.
[cpg cn=true]


[OnName num="female_student_A"]
It's true. We weren't like this when we were kids.
[cpg cn=true]


[OnName num="female_student_B"]
But, you don't have to go near otaku, do you?　If you're as pretty as Sakura, you can pick out all the guys you want.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura037"]
[OnName num="sakura"]
"Hmmm...well..."
[cpg cn=true]


...... Sakura thinks nerds are creepy. I've kind of noticed that for a while now.
[cpg]


But if I could turn Sakura herself into an otaku.
[cpg]


I had such an ambition.
[cpg]


If I could get her to cosplay, I thought, she'd be hooked.
[cpg]


Wouldn't that be impossible?　No, it's up to me to decide if it's possible or not.
[cpg]


I imagine Sakura in cosplay with a smirk on my face. I thought Sakura looked at me and said, "Gross!
[cpg]



;//バトルパートに続く前に、マップ選択前の共通イベントが発生
;//↓
;//共通イベントが終わった後、マップ選択。アイテムを入手
;//↓
;//その後下記のバトルパートへ



;//==============================
;//ヒロイン１一回目のイベント　バトルパート
;//☆ヒロインのイベントバトルパート


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





It was a holiday. I had just gone out to buy a game.
[cpg]


[OnName num="takuma"]
Ah!
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura038"]
[OnName num="sakura"]
Ah... ......
[cpg cn=true]


I met Sakura. It was not only games, but also many other things.
[cpg]


I was wondering if it would be a bad idea if they knew what I bought. Because I had bought a game with a cute girl in it.
[cpg]


It was obvious from the package. There was a possibility that he would be attracted just by looking at the outside of the package.
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura039"]
[OnName num="sakura"]
I asked him, "Takuma, you're on your way home from shopping, right? What did you buy?"
[cpg cn=true]


[OnName num="takuma"]
「……」
[cpg cn=true]


...... No. I don't see any reason to refuse it here.
[cpg]


 Thinking that I would ideally dye the Sakura, I took a bold stance.
[cpg]


[OnName num="takuma"]
This is the kind of game I'm talking about.
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura040"]
[OnName num="sakura"]
"...... What is this?　Is this a gal game?"
[cpg cn=true]


[OnName num="takuma"]
Strictly speaking, it's an RPG. It's a RPG, technically. It's got a gal game lineage, or maybe that's the main target, but this is purely..." "Oh my God!
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sakura041"]
[OnName num="sakura"]
Kimo ......"
[cpg cn=true]


Too harsh. I add an explanation.
[cpg]


[OnName num="takuma"]
'No, wait!　It just so happens that the game I happen to like is a bishojo type, or at least that's how it's portrayed.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura042"]
[OnName num="sakura"]
"Is there?　Even if there were, would you buy it?
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sakura043"]
[OnName num="sakura"]
"Takuma used to be an otaku .......
[cpg cn=true]


[OnName num="takuma"]
Don't say he was like this. ......
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura044"]
[OnName num="sakura"]
"No, you'd say. It's normal to pull back."
[cpg cn=true]


Sakura looks at me with white eyes. Oh no, this is a problem before making an ideal childhood friend.
[cpg]


If I don't do this, I'm simply going to lose distance from the cherry blossoms.
[cpg]


I have to get rid of her prejudice somehow.
[cpg]


...... and her current attire is pretty much a playful outfit.
[cpg]


[OnName num="takuma"]
I'm going to go to ...... and see if I can get her to play along. Then let's play."
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sakura045"]
[OnName num="sakura"]
What?"
[cpg cn=true]


[OnName num="takuma"]
You said it. You said you'd take me on a game to see if I could turn it into an ideal or not.
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura046"]
[OnName num="sakura"]
"...... Oh, that's what I'm talking about. Okay. What?
[cpg cn=true]



;//++++++++++++++++++++++++++
;//バトル開始画面
;//++++++++++++++++++++++++++


[SE f="se006"]
;//【ＳＥ】『バトル開始』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_bs1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

;//[CutBG g="sys_cut_bwin1"]

;//qwe

;//++++++++++++++++++++++++++
;//バトル画面を表示
;//++++++++++++++++++++++++++

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]



[OnName num="takuma"]
"Hey, Cherry. Sakura, I want you to look at something.
[cpg cn=true]


I decided to pick out something to give to Sakura. What should I do?
[cpg]



;//アイテム選択　『コスプレ衣装』を選んだ時は勝った場合へ進む
;//それ以外のものを選んだ場合負けた場合へ進む
*battle_item_select_00|コスプレバトル




[if exp={getFlagValue("getItemNum_01") == 13}]
[jump target="*battle_win_11"]
[endif]

[jump target="*battle_lose_11"]

;//[SelectItem n=13 w=*battle_win_11 l=*battle_lose_11]
Which one should I use...?
[cpg]
;//[endif]

;//==============================
;//勝った場合　※正しいアイテムを選んだ場合
*battle_win_11|Cosplay Battle

[stflag HiWinFlg_01 = 1]


[OnName num="takuma"]
"...... Childhood friends, you know, are the ones who understand your childhood interests."
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura047"]
[OnName num="sakura"]
Huh?　Then understand my hobbies too. I'm a nerd and my hobbies are creepy.
[cpg cn=true]


Sure. No, we shouldn't break here. ......
[cpg]


[OnName num="takuma"]
"Don't you read manga too?"
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura048"]
[OnName num="sakura"]
I do, but I don't watch anime. But I don't watch anime.
[cpg cn=true]


[OnName num="takuma"]
"Okay, I've made up my mind. Cherry blossoms, cosplay for me.
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura049"]
[OnName num="sakura"]
"What?　Are you serious?
[cpg cn=true]


[OnName num="takuma"]
I'm serious.
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sakura050"]
[OnName num="sakura"]
No, I won't wear it. Even if you ask me on your knees, I won't wear it.
[cpg cn=true]


I'm not going to get down on my knees and ask him to wear it.
[cpg]


[OnName num="takuma"]
I'd like you to change somewhere at the school tomorrow. You'll probably get a lot of attention from the nerdy boys."
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura051"]
[OnName num="sakura"]
"......, that's ......."
[cpg cn=true]


Oh, it's a little shaky.
[cpg]


The cherry blossoms are still hoping to attract the attention of men.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





So, the next day.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura052"]
[OnName num="sakura"]
"...... really do it?　Cosplay?
[cpg cn=true]


[OnName num="takuma"]
Of course I do. I'm bringing my own.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sakura053"]
[OnName num="sakura"]
"Huh, I don't know what to do ......."
[cpg cn=true]


They're wondering about it. I think I can go with one more push.
[cpg]


As I say it, I wonder if he's there. ......
[cpg]


[OnName num="takuma"]
'If I wear that, the nerd boys will go crazy over the cherry blossoms. There are good looking otaku boys sometimes."
[cpg cn=true]


I made up a bunch of stuff to push Sakura's back.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sakura054"]
[OnName num="sakura"]
I really can't help it. ......
[cpg cn=true]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************





Then, after school. The first thing you need to do is to get a good idea of what you're looking for.
[cpg]


We wait in the hallway in front of the small classroom.
[cpg]


I say "we" because I invited some otaku boys to join us.
[cpg]


I thought it would be better for Sakura to be pampered by a few boys than to be seen only by me.
[cpg]


[OnName num="male_student_A"]
I see ...... that Iiogashi is cosplaying ......."
[cpg cn=true]


[OnName num="male_student_B"]
I can't imagine what he'll look like.
[cpg cn=true]


[OnName num="male_student_C"]
I can't imagine what he'll look like in costume.
[cpg cn=true]


The classroom is structurally designed so that you cannot see inside. Unless you suddenly open the door, you cannot peek in while changing clothes.
[cpg]


Then a voice came from the other side of the door.
[cpg]



[VOICE f="Sakura055"]
[OnName num="sakura"]
It was ....... I'm dressed.
[cpg cn=true]



;//========================================
;//●ＣＧ（コスプレ。下からのアングル。恥ずかしそうなヒロイン）ev_01
;//人物１：ヒロイン１　服装１：変身ヒロイン服
;//場所　：学園小教室
;//時間　：夕方
;//========================================



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="takuma"]
Oh, oh, oh.
[cpg cn=true]


[OnName num="male_student_A"]
Oh, my God, you're so cute. ......
[cpg cn=true]



[VOICE f="Sakura056"]
[OnName num="sakura"]
"......, really?　Well, being a nerd is easy.
[cpg cn=true]


[OnName num="male_student_B"]
"No, I think you can really be a cosplayer ......?"
[cpg cn=true]


[OnName num="male_student_C"]
Yes, Iiogashi is very cute.
[cpg cn=true]



[VOICE f="Sakura057"]
[OnName num="sakura"]
Well, it's not a bad feeling to wear cute clothes,.......
[cpg cn=true]


 Sakura is also a little enthusiastic.
[cpg]


[OnName num="takuma"]
"Sakura, can you roll up your clothes?"
[cpg cn=true]



;**【ＣＧ】 ev_01_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sakura058"]
[OnName num="sakura"]
What?　What are you talking about?"
[cpg cn=true]


[OnName num="male_student_A"]
I want to see it!　I want to see!　Ii-Kashi, please!
[cpg cn=true]



[VOICE f="Sakura059"]
[OnName num="sakura"]
"Are you serious ......?　Are you sure you want to do this?
[cpg cn=true]


The cherry blossoms seem to be somewhat enthused by the coaxing.
[cpg]


[OnName num="takuma"]
"Oh. I just want to see prettier cherry blossoms."
[cpg cn=true]



[VOICE f="Sakura060"]
[OnName num="sakura"]
I thought you'd do it if I told you. ......
[cpg cn=true]


And then the cherry blossoms put a hand on the hem.
[cpg]


[OnName num="male_student_B"]
Oh .......
[cpg cn=true]



;**【ＣＧ】 ev_01_b ***********************
[CG id=0 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sakura061"]
[OnName num="sakura"]
Is this okay?"
[cpg cn=true]


She laughed a little and pulled up her clothes.
[cpg]


[OnName num="male_student_C"]
I'm a sight for sore eyes, Iiogashi,......, and pictures are a bad idea.
[cpg cn=true]



[VOICE f="Sakura062"]
[OnName num="sakura"]
I'll stop taking pictures if you do. I'll stop taking pictures.
[cpg cn=true]


Sakura's cheeks are tinted. I wonder if she has lost a little of the nerd creepiness in her.
[cpg]


[OnName num="takuma"]
I'm sure you'll be able to find a way to get a good look at them. Sakura.
[cpg cn=true]



[VOICE f="Sakura063"]
[OnName num="sakura"]
'...... so.'
[cpg cn=true]


Anyway, this mission was a success.
[cpg]



;//++++++++++++++++++++++++++
;//勝利画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba1w.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se007"]
;//【ＳＥ】『バトル勝利』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト
;//☆次は負けた場合のイベント


;//二回目の選択へ


[jump target="*before_select_chara"]
;//==============================
;//負けた場合　※正しいアイテムを選ばなかった場合
*battle_lose_11|コスプレバトル





No good. Not this one. ......
[cpg]


I couldn't think of any way to idealize the cherry blossoms.
[cpg]


[OnName num="takuma"]
I couldn't think of any way to idealize the cherry blossoms. "......, but even you've changed since you were a kid. You've changed since I last saw you.
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura064"]
[OnName num="sakura"]
If you don't want me to meddle in your hobbies, then don't meddle in how people dress either.
[cpg cn=true]


[OnName num="takuma"]
Well, that's ......
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sakura065"]
[OnName num="sakura"]
Promise me. I have my own policy.
[cpg cn=true]


[OnName num="takuma"]
I understand.
[cpg cn=true]


I liked to dress more neatly, but I'm not going to see any more of my childhood friends wearing ...... that.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura066"]
[OnName num="sakura"]
'Yes!　You're not interested in cosplay, are you, Takuma?"
[cpg cn=true]


[OnName num="takuma"]
「え？」
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I don't know how this happened. I don't know but ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





[FG f="CHA01_p5_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura067"]
[OnName num="sakura"]
"Ha-ha-ha, you look great!　I'll take a picture.
[cpg cn=true]


I ended up being forced to dress up in costume.
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura068"]
[OnName num="sakura"]
I was forced to dress up in costume. Do you understand?"
[cpg cn=true]



;//++++++++++++++++++++++++++
;//敗北画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba1l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se008"]
;//【ＳＥ】『バトル敗北』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト



;//二回目の選択へ



;//==============================


[jump target="*before_select_chara"]
;//ヒロイン１一回目のイベント　ここまで
;//☆ここから次のイベント



;//////////////////////////////////
;//ヒロイン１二回目のイベント
;//『観たい映画バトル』
;//////////////////////////////////



;//==============================
;//ヒロイン１二回目のイベント　前置き
;//☆ヒロインのイベント前置き
*HiStory1_02|Battle of the Movies

;#################################################
*Ep006|観たい映画バトル
;#################################################

;//[SCENE id=6]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（昼）******************************************************

I had found some news on my phone.
[cpg]

It was the opening of an animated movie. I didn't pay attention to it, but it was today.
[cpg]

The movie is for geeks, but the voice actors are actors. ......
[cpg]

I wonder if Sakura would watch this movie.
[cpg]

If she does, she might be able to get closer to her otaku girlfriend.
[cpg]

;//==============================
;//ヒロイン１二回目のイベント　バトルパート
;//☆ヒロインのイベントバトルパート


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************
Sakura and I came to see a movie.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura069"]
[OnName num="sakura"]
"Well, shall we buy tickets?
[cpg cn=true]


[OnName num="takuma"]
"Wait a minute. You haven't decided what you're going to see yet.
[cpg cn=true]


She pointed to a poster of a certain title.
[cpg]

[OnName num="takuma"]
She pointed to a poster with a title: "......."
[cpg cn=true]


It was a Japanese movie that looked like a mystery.
[cpg]

Every time I saw an ad for it, I wondered who would watch it, but I guess ...... Sakura would.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sakura070"]
[OnName num="sakura"]
Did you think of something rude just now?"
[cpg cn=true]



[OnName num="takuma"]
Why not?"
[cpg cn=true]


But if she and what she wants to watch are different, we have to do something.
[cpg]


;//++++++++++++++++++++++++++
;//バトル開始画面
;//++++++++++++++++++++++++++


[SE f="se006"]
;//【ＳＥ】『バトル開始』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_bs1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

;//[CutBG g="sys_cut_bwin1"]



;//++++++++++++++++++++++++++
;//バトル画面を表示
;//++++++++++++++++++++++++++

Let's get her to change her mind. What you need to do to do that is ......
[cpg]


;//アイテム選択　『映画のパンフレット』を選んだ時は勝った場合へ進む
;//それ以外のものを選んだ場合負けた場合へ進む
*battle_item_select_00|観たい映画バトル


[if exp={getFlagValue("getItemNum_02") == 1}]
[jump target="*battle_win_12"]
[endif]

[if exp={getFlagValue("getItemNum_01") == 1}]
[jump target="*battle_win_12"]
[endif]

[jump target="*battle_lose_12"]

;//[SelectItem n=1 w=*battle_win_12 l=*battle_lose_12]
どれを使おう…
[cpg]
;//[endif]


;//==============================
;//勝った場合　※正しいアイテムを選んだ場合
*battle_win_12|観たい映画バトル

[stflag HiWinFlg_01 = 1]


I showed her a movie pamphlet.
[cpg]

I don't know about you, but I think you'll change your mind about watching a Japanese movie if you know it's voiced by an actor.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sakura071"]
[OnName num="sakura"]
I said, "...... Hmmm. He's voicing the character.
[cpg cn=true]


[OnName num="takuma"]
"You're interested a little bit?"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sakura072"]
[OnName num="sakura"]
"I don't care who the voice actor is.
[cpg cn=true]


[OnName num="takuma"]
I don't care who they are." "You say that, but you seemed interested in them just now.
[cpg cn=true]


Sakura didn't deny it.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

;//[Live2d target=8]

;//ブラックアウト



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

In the end, Sakura watched the movie without getting up from her seat.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sakura073"]
[OnName num="sakura"]
I was so excited to see the movie," she said, "it's like a patchwork of beautiful scenes.
[cpg cn=true]


[OnName num="takuma"]
I was so happy to see her.　Are you crying, Sakura?
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sakura074"]
[OnName num="sakura"]
I'm not crying!　It's just your imagination!
[cpg cn=true]


;//++++++++++++++++++++++++++
;//勝利画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba1w.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se007"]
;//【ＳＥ】『バトル勝利』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト
;//☆次は負けた場合のイベント

[jump target="*before_select_chara"]
;//==============================
;//負けた場合　※正しいアイテムを選ばなかった場合
*battle_lose_12|観たい映画バトル


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

In the end, I was pushed aside and watched a mystery movie she recommended.
[cpg]


;//ブラックアウト


I didn't understand much of the content, but Sakura seemed to be impressed. ......
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************

Afterwards, she took me to her house for an impression session.
[cpg]

Sakura, who was very excited, said she wanted to recreate a scene from the movie, and what she did was ......
[cpg]


;//========================================
;//●ＣＧ（主人公にのしかかるヒロイン。キス間際までいく）ev_11
;//人物１：ヒロイン１　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_11_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

;//ブラックアウト

[VOICE f="Sakura075"]
[OnName num="sakura"]
'The kissing scene in that movie, it was like this, wasn't it?'
[cpg cn=true]


[OnName num="takuma"]
'...... more and more aggressive girls, or rather, characters like that, lately.
[cpg cn=true]


[VOICE f="Sakura076"]
[OnName num="sakura"]
I'm not sure if I'm going to kiss you like this. I might just kiss you like this."
[cpg cn=true]


[OnName num="takuma"]
You're not going to do it, are you?
[cpg cn=true]


[VOICE f="Sakura077"]
[OnName num="sakura"]
I don't know.
[cpg cn=true]


I guess she was influenced by the movie, and she was refining her character to play me.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

;//++++++++++++++++++++++++++
;//敗北画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba1l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se008"]
;//【ＳＥ】『バトル敗北』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト



;//==============================


[jump target="*before_select_chara"]
;//ヒロイン１二回目のイベント　ここまで
;//☆ここから次のイベント





;//////////////////////////////////
;//ヒロイン１三回目のイベント
;//『もっと！コスプレバトル』
;//////////////////////////////////



;//==============================
;//ヒロイン１三回目のイベント　前置き
;//☆ヒロインのイベント前置き
*HiStory1_03|もっと！コスプレバトル

;#################################################
*Ep010|More! Cosplay Battle
;#################################################

;//[SCENE id=10]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I'm alone in my room, thinking. How to turn Sakura into an otaku.
[cpg]


I think the best way is to make her cosplay.
[cpg]


But I can't do it the way I did it last time. I need a different approach.
[cpg]


Thinking about this and that, I'm thinking about this and that. ......
[cpg]


How can I get Sakura to accept my hobby?
[cpg]


Or ...... how can I get her to lose her resistance to cosplay?
[cpg]



;//==============================
;//ヒロイン三回目のイベント　バトルパート
;//☆ヒロインのイベントバトルパート


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]

On a holiday, I invited Sakura to my room. I invited Sakura to my room.
[cpg]


I already know what I want to do. I think she knows what I'm going to do.
[cpg]


[OnName num="takuma"]
Sakura!　You already know what I want you to do.
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura078"]
[OnName num="sakura"]
"So, you want me to wear this ......?"
[cpg cn=true]


[OnName num="takuma"]
"Yes, I do. I won't let you say I won't wear it!
[cpg cn=true]


This is part of the game. I'm not going to let them tell me I can't wear it.
[cpg]



;//++++++++++++++++++++++++++
;//バトル開始画面
;//++++++++++++++++++++++++++


[SE f="se006"]
;//【ＳＥ】『バトル開始』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_bs1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

;//[CutBG g="sys_cut_bwin1"]



;//++++++++++++++++++++++++++
;//バトル画面を表示
;//++++++++++++++++++++++++++





[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura079"]
[OnName num="sakura"]
What are you getting so excited all on your own ...... I'm too much of a nerd to pull it off."
[cpg cn=true]


Sakura is as cold as ever. But there is romance in getting her to wear this!
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sakura080"]
[OnName num="sakura"]
I can't wear something with so little fabric.
[cpg cn=true]


[OnName num="takuma"]
"That's the point!
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura081"]
[OnName num="sakura"]
Is this really common?　Maybe it's not common.
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura082"]
[OnName num="sakura"]
If you're so sure, show me the proof.
[cpg cn=true]


[OnName num="takuma"]
"Oh, sure, sure. Well, wait a minute.
[cpg cn=true]


I'll find something to show her. Let's see what I have.
[cpg]



;//アイテム選択　『コスプレイヤーの際どい写真集』を選んだ時は勝った場合へ進む
;//それ以外のものを選んだ場合負けた場合へ進む
*battle_item_select_00|もっと！コスプレバトル


[if exp={getFlagValue("getItemNum_03") == 5}]
[jump target="*battle_win_13"]
[endif]

[if exp={getFlagValue("getItemNum_02") == 5}]
[jump target="*battle_win_13"]
[endif]

[if exp={getFlagValue("getItemNum_01") == 5}]
[jump target="*battle_win_13"]
[endif]

[jump target="*battle_lose_13"]

;//[SelectItem n=5 w=*battle_win_14 l=*battle_lose_14]
どれを使おう…
[cpg]
;//[endif]



;//==============================
;//勝った場合　※正しいアイテムを選んだ場合
*battle_win_13|もっと！コスプレバトル

[stflag HiWinFlg_01 = 1]


[OnName num="takuma"]
Look at this."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura083"]
[OnName num="sakura"]
"......, is this a photo book ......?　Wow, it's pretty gory."
[cpg cn=true]


I showed Sakura a photo book of cosplayers. She was looking at them as if she was devouring them.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura084"]
[OnName num="sakura"]
I said, "I didn't know there was such a thing .......
[cpg cn=true]


[OnName num="takuma"]
"Are you convinced?　Then, will you wear it?
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sakura085"]
[OnName num="sakura"]
"Uu...... well, I don't mind pretty clothes.
[cpg cn=true]



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


I let her put on her costume again and I complimented her on it.
[cpg]

;//========================================
;//●ＣＧ（ヒロインにポーズを取らせる。手を上げているポーズ）ev_07
;//人物１：ヒロイン１　服装１：布地の少ないコスプレ
;//人物ex：主人公　　　服装ex：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

;//移植のためシーンをカットしています

[BGM f="bg_h1"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Sakura086"]
[OnName num="sakura"]
I let her put on the costume again and I complimented her on it.　Do I look that good on you?
[cpg cn=true]


[OnName num="takuma"]
I was like, "Yeah, it's really cute, Sakura. "Yeah, it's really cute, Sakura.
[cpg cn=true]


She was posing as I told her to.
[cpg]


;**【ＣＧ】 ev_07_a ***********************
[CG id=2 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Sakura087"]
[OnName num="sakura"]
I'm still a little embarrassed.
[cpg cn=true]


Cherry blossoms stain her cheeks as she says this.
[cpg]


I feel like she's slowly becoming more and more like the otaku girl I want to be.
[cpg]


It's a good feeling. Let's keep it going.
[cpg]



;//++++++++++++++++++++++++++
;//勝利画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba1w.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se007"]
;//【ＳＥ】『バトル勝利』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト
;//☆次は負けた場合のイベント

[jump target="*before_select_chara"]
;//==============================
;//負けた場合　※正しいアイテムを選ばなかった場合
*battle_lose_13|もっと！コスプレバトル





[OnName num="takuma"]
"Well, yeah. ......, uh, ......."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura088"]
[OnName num="sakura"]
I can't deal with your nerdiness anymore.
[cpg cn=true]


Cherry blossoms seem untouchable. Is there nothing that can be done about it?
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura089"]
[OnName num="sakura"]
I'd like to do something normal if I'm going to go through the trouble.
[cpg cn=true]


[OnName num="takuma"]
No, I still want to see you in cosplay!
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sakura090"]
[OnName num="sakura"]
If you're going to impose your ideals on me, you'd better have a good strategy. You're being too pushy.
[cpg cn=true]


You're right. I might have been a little too hasty.
[cpg]


[FG f="CHA01_p5_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sakura091"]
[OnName num="sakura"]
You know what I want, don't you? I know what ...... Takuma wants.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//移植のためシーンをカットしています

Saying that, Sakura comes closer to me.
[cpg]

I was so thrilled by that that I couldn't even think about cosplaying anymore.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





In the end, I couldn't do what I wanted to do.
[cpg]


But if Sakura felt it, that's okay too.
[cpg]



;//++++++++++++++++++++++++++
;//敗北画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba1l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se008"]
;//【ＳＥ】『バトル敗北』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト


;//[jump target="*before_select_chara"]
;//ヒロイン１三回目のイベント　ここまで
;//☆ここから次のイベント






*before_select_chara|
[if exp={getFlagValue("Count_Selected") == 3}]
[jump storage="epResalt.ks" target="*Go_to_Resalt"]
[endif]
[jump storage="ep001.ks" target="*before_select_chara"]


;////////////////////////////////////////////////////////////////////
;//以下、ヒロイン１分岐後のシナリオ
;////////////////////////////////////////////////////////////////////






;//==============================
;//三回のバトルを終えて勝利数が１以下であり、このヒロインを２回以上選んでいる場合
*Hiroin_Root_1_1|A little different from the ideal childhood friend


;//////////////////////////////////
;//ヒロイン１現実ルート開始
;//////////////////////////////////


;#################################################
*Ep014|理想の幼馴染とは少し違う
;#################################################

;//[SCENE id=14]
[SCENE id=2]

......We were successfully married after our confession.
[cpg]


The first thing to do is to make sure that you have a good idea of what you want to do and how you want to do it.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura092"]
[OnName num="sakura"]
How long are you going to make me wait? How long are you making me wait?"
[cpg cn=true]


[OnName num="takuma"]
And that's what happens when you get called out of the blue. ......
[cpg cn=true]


I was running to Sakura, out of breath.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sakura093"]
[OnName num="sakura"]
I was running to Sakura, out of breath. I'm just a friend.
[cpg cn=true]


I'm just a friend. If you're asking if we're lovers, probably not.
[cpg]


I couldn't complain if Sakura was in contact with another guy.
[cpg]


I could not help but be called a convenient boyfriend for Sakura.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se000"]
;//【ＳＥ】『歩く』



The power relationship between me and Sakura was perfectly fixed.
[cpg]


It was after this ...... that it was decided, or rather reminded, that it was something that could not be overturned.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





One day after school. Today, too, Sakura is talking with another boy.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura094"]
[OnName num="sakura"]
He said, "Hey. Isn't it nice?　You just said you want to see my room.
[cpg cn=true]


[OnName num="male_student"]
What? What are you going to do with it?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura095"]
[OnName num="sakura"]
"What are you going to do with it?" "I don't care what you do with it.
[cpg cn=true]


Sakura is happily talking with other boys as if to show me off.
[cpg]


He enjoys my dismay at the sight of it. I know.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura096"]
[OnName num="sakura"]
I know," she said, "but I'm going to go to another boy's house. I might stay over at another boy's house next time.
[cpg cn=true]


[OnName num="takuma"]
"What, ......?"
[cpg cn=true]


I was shaken to the core.
[cpg]


It's just an extension of my usual behavior. I don't know if I'm really going to stay over or not.
[cpg]


If I crossed the line, my relationship with Sakura would fall apart ...... and I'm sure Sakura knows that much.
[cpg]


So I won't do that. There's only one response I can give in the first place.
[cpg]


[OnName num="takuma"]
「……分かった」
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura097"]
[OnName num="sakura"]
"What's up?　Did I mess up?　Sorry, sorry."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura098"]
[OnName num="sakura"]
I'm going to Takuma's house today. So please forgive me."
[cpg cn=true]


[OnName num="takuma"]
......
[cpg cn=true]


I'm being played with. She still likes good looking guys and talks to the guys in the school.
[cpg]


This has isolated her from the girls and she remains a poor ...... cook.
[cpg]


I'm far from my ideal childhood friend.
[cpg]


Rather, I've been tainted by her ideals for me.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[BGM f="bg_sl"]
[WAIT time=100]


Still, I couldn't stop dating Sakura.
[cpg]


I kept going out with her, holding on to my ideals for a long time. ......
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



Cherry blossoms were at my house again today. She left just before evening turned into night, though.
[cpg]


Still, I still don't know how to explain Sakura to my parents.
[cpg]


She must be my girlfriend, but if I introduce her as my girlfriend, Sakura might say she is not.
[cpg]


Sakura is the kind of girl who likes to play with me.
[cpg]


And I was coming to accept that, too: ......
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


To say that she is free-spirited is wrong in one respect and right in another.
[cpg]


She's a girl who likes to play with my feelings. That's the best way to put it.
[cpg]


I headed to the school. Sakura seemed to have already left for the school.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





And when I arrived at the school, I saw Sakura talking with a boy. I saw Sakura talking with a boy.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura099"]
[OnName num="sakura"]
I saw Sakura talking with a boy. How do you take care of it?"
[cpg cn=true]


Sakura is touching the cheek of a guy who is not me. It's painful just to watch it from afar. And yet ......
[cpg]


[OnName num="male_student"]
'Stop it,...... Sakura-san, you have a boyfriend, don't you?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura100"]
[OnName num="sakura"]
'Oh, you mean Takuma?　That's not my boyfriend.
[cpg cn=true]


[OnName num="male_student"]
"Really?　I heard rumors that you were dating.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura101"]
[OnName num="sakura"]
Rumors are just that, rumors. Don't believe it.
[cpg cn=true]


Don't believe it.
[cpg]


But ...... I still loved the cherry blossoms.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





A childhood friend who would not dye me into an ideal. And I, on the contrary, was dyed to the ideal.
[cpg]


I'm a convenient male friend who's always ready to help out.
[cpg]


I went out with her, thinking it was fine.
[cpg]



;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト



;//ＥＮＤ　ヒロイン１現実ルート




;//[SCENE id=28]
[SCENE id=16]

[jump storage="epend.ks" target="*start"]



;//==============================
;//３回のバトルを終えて勝利数が２以上である場合
*Hiroin_Root_1_2|I turned Sakura into an ideal.


;#################################################
*Ep015|桜を理想に変えた
;#################################################

;//[SCENE id=15]
[SCENE id=3]

;//////////////////////////////////
;//ヒロイン１理想ルート、および中立ルート開始
;//////////////////////////////////



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



After that, I succeeded in changing Sakura into my ideal. I succeeded in turning Sakura into my ideal.
[cpg]


;//ここからヒロイン１の髪色は黒


[FG f="CHA01_p5_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura102"]
[OnName num="sakura"]
"Hey, hey, Takuma. What do you think of this?
[cpg cn=true]


[OnName num="takuma"]
"What do you think of ......?　Did you dye it again?
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura103"]
[OnName num="sakura"]
I think it's a good idea. I thought there was no need to dye it.
[cpg cn=true]


[OnName num="takuma"]
Well, ......, it looks good on you.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura104"]
[OnName num="sakura"]
Right?　Phew.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura105"]
[OnName num="sakura"]
"So, Takuma,......, what are you watching this season?
[cpg cn=true]


[OnName num="takuma"]
"Oh, you mean anime?　Let's see,.......
[cpg cn=true]


His hair color changed from brown to black. He became my ideal childhood friend, who would even go along with my nerd talk.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


And that dream that used to annoy me, I don't have it anymore.
[cpg]


If I had to think of a reason why I was cured, I would say that the stress of not having everyone around me be ideal was relieved ...... or something like that.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************

That part is rather unimportant. More importantly, my wish came true.
[cpg]


And afterwards, Sakura confided in me.
[cpg]


[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura106"]
[OnName num="sakura"]
Hey, Takuma. Do you remember?　The beginning, or rather, the first thing that happened.
[cpg cn=true]


[OnName num="takuma"]
What are you talking about?
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura107"]
[OnName num="sakura"]
Not only me, but also my senpai and Mono-chan helped us, didn't they?
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura108"]
[OnName num="sakura"]
I was the one who asked for it.
[cpg cn=true]


[OnName num="takuma"]
I didn't know that. ......
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura109"]
[OnName num="sakura"]
But in the end, you chose me, Takuma. I was so happy.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sakura110"]
[OnName num="sakura"]
"I like ...... you, Takuma. Do you like me, Takuma?
[cpg cn=true]


This is a confession. This is a confession, so abrupt. But my answer is obvious.
[cpg]


[OnName num="takuma"]
Of course I do. There is no one in the world prettier than Sakura.
[cpg cn=true]


[FG f="CHA01_p5_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura111"]
[OnName num="sakura"]
"Ufufu. That's a very nice thing to say.
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************



Then one day, in Sakura's room.
[cpg]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura112"]
[OnName num="sakura"]
"I'm going to serve you some tea.
[cpg cn=true]


[FG f="CHA01_p5_03_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sakura113"]
[OnName num="sakura"]
"Kyaaaah!"
[cpg cn=true]


I was so close, but I couldn't get a hold of her.
[cpg]


[free time=1000]

I almost support her body. but ......
[cpg]


The contents of the drawer were scattered. And the contents of the drawer were.
[cpg]


[OnName num="takuma"]
Is this ...... a manga?"
[cpg cn=true]


Illustrations in the style of girls' manga. It was scattered all over the place.
[cpg]


[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura114"]
[OnName num="sakura"]
"Ah, ah, ah, ...... has been discovered, huh?"
[cpg cn=true]


[OnName num="takuma"]
I'm surprised you have a hobby like this.
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura115"]
[OnName num="sakura"]
It is natural that you don't know about it. I've only recently started.
[cpg cn=true]


 He seemed to be more of an otaku than I imagined.
[cpg]


I looked at him, thinking, "But he's pretty good for someone who just started recently.
[cpg]


[OnName num="takuma"]
I thought to myself, "If I made a ...... comic book and took it to an exhibition, it would probably sell well."
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sakura116"]
[OnName num="sakura"]
No, I can't!　No one would buy my drawings.
[cpg cn=true]


[OnName num="takuma"]
I can help you get it printed and help you sell it, how about it?"
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura117"]
[OnName num="sakura"]
You're so pushy. ...... I told you it's impossible.
[cpg cn=true]


[OnName num="takuma"]
I think you're good enough. I can't draw at all.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura118"]
[OnName num="sakura"]
I'm glad to hear you say that, ...... but..."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************





The first thing to do is to make sure that you have a good idea of what you are going to do.
[cpg]


The day of the sale, the first thing that came to my mind was that it would be a good idea to have a good time.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



;//上下に黒帯を入れてください

;//[lbox on]




Then came the day of the sale. It was an event limited to derivative works of a certain female-oriented work.
[cpg]


Sakura knew better than me where was the best place for the event.
[cpg]


The scale of the event was small, and the sales were not so bad. But ......
[cpg]


[OnName num="female_customer"]
I was very impressed with the quality of the work. Is this your first time participating?"
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura119"]
[OnName num="sakura"]
I've only just started to draw .......
[cpg cn=true]


The first time I did this, it was my first time.
[cpg]

;//[lbox off]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************





[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura120"]
[OnName num="sakura"]
"I had a lot of fun today. Takuma taught me all these things."
[cpg cn=true]


[OnName num="takuma"]
I'm not exaggerating. You had the right stuff, you know.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura121"]
[OnName num="sakura"]
In return, ...... I want to do something for you.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sakura122"]
[OnName num="sakura"]
I need you to stay outside for a minute."
[cpg cn=true]


[free time=1000]


She says so, and I go outside the room and wait. I hear the sound of clothes being worn.
[cpg]


And when I come back ......
[cpg]


;//========================================
;//●ＣＧ（ベッドに倒れ込むヒロイン。コスプレしている）ev_17
;//人物１：ヒロイン１　服装１：アイドル風衣装
;//人物ex：主人公　　　服装ex：私服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//備考　：ヒロイン１の髪色は黒
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//[FG f="CHA01_p5_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura123"]
[OnName num="sakura"]
She says, "Jeez,...... I don't know. It's an idol-like outfit."
[cpg cn=true]


[OnName num="takuma"]
"Did you buy that yourself?"
[cpg cn=true]


;//[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura124"]
[OnName num="sakura"]
I thought it would make Takuma happy. I thought it would make Takuma happy.
[cpg cn=true]


I'm really pleased with the way she turned out. I was even impressed.
[cpg]


[OnName num="takuma"]
Can I take a picture?
[cpg cn=true]


;//[FG f="CHA01_p5_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sakura125"]
[OnName num="sakura"]
"Okay, I'll pose for you."
[cpg cn=true]


She listens to everything I say.
[cpg]

Of course I feel happy about that.
[cpg]

Even now, she's wearing this dress in front of me: ......
[cpg]

But there is another thing I think along with that.
[cpg]


;**【ＣＧ】 ev_17_a ***********************
[CG id=3 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Sakura126"]
[OnName num="sakura"]
"...... more, look only at me."
[cpg cn=true]


[OnName num="takuma"]
'Oh. I know."
[cpg cn=true]


I haven't realized that feeling myself yet. ......
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





Days go by. One day, Sakura and I had this conversation.
[cpg]


[OnName num="takuma"]
Do you also fall in love with two-dimensional characters?
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura127"]
[OnName num="sakura"]
I don't know if it's the same as falling in love. I don't think it's the same as falling in love.
[cpg cn=true]


[OnName num="takuma"]
"Good looking ......?　Me?
[cpg cn=true]


The sense of discomfort in me takes shape. I kept wondering if I had changed into the ideal Sakura wanted me to be.
[cpg]


Sakura was a lover of clean, good-looking men. By changing it to an ideal, I became single-minded about my childhood friend.
[cpg]


I wonder if I am the ideal childhood friend that Sakura thinks I am.
[cpg]





;//■選択肢
[switch]
[case "桜が理想に変わったのでこれでいい"]
	[swap]
	[jump target="*Hiroin_Root_1_21"]
[case "桜の理想の幼なじみになりたい"]
	[swap]
	[jump target="*Hiroin_Root_1_22"]
[endswitch]

;//■選択肢
;//１、桜が理想に変わったのでこれでいい
;//２、桜の理想の幼なじみになりたい



;//==============================
;//１、桜が理想に変わったのでこれでいい



;//////////////////////////////////
;//ヒロイン１理想ルートに分岐
;//////////////////////////////////

;#################################################
*Ep016|桜が理想に変わったのでこれでいい
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

*Hiroin_Root_1_21|I want to be Sakura's ideal childhood friend.


;//[SCENE id=16]
[SCENE id=4]

[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura128"]
[OnName num="sakura"]
What's wrong? You've been quiet.
[cpg cn=true]


[OnName num="takuma"]
"No, it's nothing. Nothing.
[cpg cn=true]


I thought, "I've turned Sakura into my ideal, so that's good enough for me.
[cpg]


I'm not going to change myself, but the cherry blossoms love me.
[cpg]


Then there is nothing more to wish for. ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


;//移植のためシーンをカットしています


A holiday. We are talking about nothing else.
[cpg]


Sakura is gaining popularity among the previously unconfessed, in other words, otaku boys.
[cpg]


[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura129"]
[OnName num="sakura"]
I got a confession the other day," she said. Maybe I'm more popular than I was when I was a flirt.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura130"]
[OnName num="sakura"]
Of course, I've turned down all of them. All I have is Takuma.
[cpg cn=true]


[OnName num="takuma"]
There are guys better looking than me.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura131"]
[OnName num="sakura"]
No, there is no one. You should be more confident, Takuma.
[cpg cn=true]


I'm glad to hear you say that.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************





[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura132"]
[OnName num="sakura"]
I'll see you tomorrow. I'll see you tomorrow.
[cpg cn=true]


[OnName num="takuma"]
"Yeah, see you. See you soon.
[cpg cn=true]


I waved my hand to Sakura as she left, looking forward to seeing her tomorrow. ......
[cpg]


I waved my hand at Sakura as she left.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************





The next day, I would be able to see Sakura right away.
[cpg]


We could see each other every day and it still wouldn't be enough.
[cpg]


I thought about that and told Sakura: ......
[cpg]


[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura133"]
[OnName num="sakura"]
I told her, "Every day isn't enough. Do you want to live together?"
[cpg cn=true]


[OnName num="takuma"]
I'm aiming for that too."
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sakura134"]
[OnName num="sakura"]
I see. ...... Well, I'm glad you said that."
[cpg cn=true]


We talk about the future. It wasn't all about the distant future.
[cpg]


;//移植のためシーンをカットしています


[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura135"]
[OnName num="sakura"]
I want to participate in ...... another event. What do you think, Takuma?
[cpg cn=true]


[OnName num="takuma"]
What do you think?" "I don't care what you think, if you want to go to ......, you should go.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura136"]
[OnName num="sakura"]
I'm going to make my own cosplay costumes this time. I'm thinking of making my own cosplay outfit, but this time it won't be a completely female-oriented event.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura137"]
[OnName num="sakura"]
I've got a lot of things I want to do ......, but I'm afraid Takuma might get mad.
[cpg cn=true]


[OnName num="takuma"]
I'm not that narrow-minded. I'm happy if you can see my lovely girlfriend.
[cpg cn=true]


[FG f="CHA01_p5_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura138"]
[OnName num="sakura"]
"Heh, heh. I see."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





I'm having a good time with my girlfriend. I was too happy just to keep it up.
[cpg]


I wish time would stop, but if it did, there would be no more happiness. ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************





[FG f="CHA01_p3_04_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sakura139"]
[OnName num="sakura"]
"Stay ...... and your fingers will get tired......."
[cpg cn=true]


[OnName num="takuma"]
I know." Do all the people who make cosplay costumes do this ......?"
[cpg cn=true]


[FG f="CHA01_p1_04_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura140"]
[OnName num="sakura"]
The more time I put into it, the more I look forward to the finished product. And I'm going to wear it.
[cpg cn=true]


[OnName num="takuma"]
Yeah. I'm looking forward to it.
[cpg cn=true]


[OnName num="takuma"]
But first, why don't we take a break?"
[cpg cn=true]


I said that and pressed Sakura for a kiss.
[cpg]


[FG f="CHA01_p5_04_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sakura141"]
[OnName num="sakura"]
I'm not going to take a break.
[cpg cn=true]


;//========================================
;//●ＣＧ（ヒロインにキスを迫る主人公）ev_16
;//人物１：ヒロイン１　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Sakura142"]
[OnName num="sakura"]
Don't think I don't like it when you're so pushy.
[cpg cn=true]


[OnName num="takuma"]
Don't you think I like you?"
[cpg cn=true]


;**【ＣＧ】 ev_16_a ***********************
[CG id=4 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Sakura143"]
[OnName num="sakura"]
"...... already."
[cpg cn=true]


I'm going to be able to get a good idea of what you're looking for.
[cpg]

I want to know more about her. I want to know her better than anyone else.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



;//上下に黒帯を入れてください


;//[lbox on]


The day of the event. I was able to get my cosplay on time.
[cpg]


[FG f="CHA01_p5_04_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sakura144"]
[OnName num="sakura"]
I was a little nervous ...... but it's not cosplay if you're nervous, is it?
[cpg cn=true]


[OnName num="takuma"]
"Oh, it's not cosplay if you're nervous, is it? It's not cosplay if you're nervous.
[cpg cn=true]


The face of Sakura is cute and stylish to begin with.
[cpg]


In a blink of an eye, you are surrounded by people.
[cpg]


[FG f="CHA01_p1_04_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura145"]
[OnName num="sakura"]
She was surrounded by people in no time at all.　Let's see... like this?"
[cpg cn=true]


Sakura is becoming more and more of a nerd. The fear that someone will take her away from me is not there.
[cpg]


The ideal childhood friend I was looking for was there.
[cpg]



;//[lbox off]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





On the way home. Sakura and I walked together.
[cpg]


[FG f="CHA01_p3_04_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura146"]
[OnName num="sakura"]
I think I've seen a new world. Takuma, you're going to take responsibility, right?
[cpg cn=true]


[OnName num="takuma"]
"Oh, I'm becoming more and more of a deep geek. I want you to become a deeper and deeper geek.
[cpg cn=true]


[FG f="CHA01_p3_04_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura147"]
[OnName num="sakura"]
I'm trying to drag you into this, aren't I?　But I'd like it if you would.
[cpg cn=true]


[FG f="CHA01_p5_04_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sakura148"]
[OnName num="sakura"]
I'd do anything for Takuma. I want to like you more and maybe even be liked."
[cpg cn=true]




;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

;//ＥＮＤ　ヒロイン１理想ルート

;//[SCENE id=29]
[SCENE id=17]


[system end1=true]

[jump storage="epend.ks" target="*start"]


;//==============================
;//２、桜の理想の幼なじみになりたい

;#################################################
*Ep017|I want to be Sakura's ideal childhood friend.
;#################################################
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

*Hiroin_Root_1_22|桜の理想の幼なじみになりたい





;//[SCENE id=17]
[SCENE id=5]

;//////////////////////////////////
;//ヒロイン１中立ルートに分岐
;//////////////////////////////////



I thought. I want to be Sakura's ideal friend.
[cpg]


I thought that it is not enough to just change Sakura into my ideal.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





Sakura used to try to make me into a convenient good-looking guy.
[cpg]


I was also trying to make Sakura my devoted childhood friend.
[cpg]


[FG f="CHA01_p3_04_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura149"]
[OnName num="sakura"]
I've been trying to be a good looking guy for a long time, and I've been trying to be a good looking guy for a long time.
[cpg cn=true]


[OnName num="takuma"]
Is that so?"
[cpg cn=true]


I've been taking care of my appearance.
[cpg]


[OnName num="takuma"]
If anyone has changed, it's Cherry Blossom. She's a better cook now.
[cpg cn=true]


[FG f="CHA01_p1_04_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura150"]
[OnName num="sakura"]
I'll treat you again. I'll treat you again.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************





[FG f="CHA01_p3_04_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura151"]
[OnName num="sakura"]
I'll treat you again. It's not that Takuma isn't cool.
[cpg cn=true]


[OnName num="takuma"]
Oh, ......
[cpg cn=true]


I also changed my mind about the danger of being in love only for the sake of being in love.
[cpg]


I'm getting out of the shadows a little bit.
[cpg]


;//移植のためシーンをカットしています

I have no qualms about holding her hand in public. I would even kiss her if she asked for it.
[cpg]


I pat Sakura's head. Sakura looked a little happy.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sakura152"]
[OnName num="sakura"]
I'm the only one who can meet Takuma's needs.
[cpg cn=true]


[OnName num="takuma"]
'Oh, ...... really, I am.'
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sakura153"]
[OnName num="sakura"]
'You're strangely honest,......, and it's a bit of a letdown.
[cpg cn=true]


[OnName num="takuma"]
I'm serious about it. I really like cherry blossoms.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sakura154"]
[OnName num="sakura"]
I don't dare to tell you that I like Takuma, okay?
[cpg cn=true]


I'm not going to say that, but it's like I'm saying I like you.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

;//========================================
;//●ＣＧ（主人公に寄り添ってヒロインは嬉しそうに目を閉じている）ev_23
;//人物１：ヒロイン１　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：室内
;//時間　：夜
;//========================================



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_pi"]
;**【ＣＧ】 ev_23_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sakura155"]
[OnName num="sakura"]
"You know, ...... lovers, you know. Maybe we are supposed to change each other for the better.
[cpg cn=true]


[OnName num="takuma"]
I'm not so sure. I'm in trouble because I'm strangely popular.
[cpg cn=true]



[VOICE f="Sakura156"]
[OnName num="sakura"]
"Haha, I'm ...... sure everyone knows we're dating.
[cpg cn=true]


We have become strangely popular with each other. I wondered if this was a good change, too,......
[cpg]


;**【ＣＧ】 ev_23_a ***********************
[CG id=5 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Sakura157"]
[OnName num="sakura"]
I love you, Takuma."
[cpg cn=true]


We both chewed on how happy we were right now.
[cpg]




;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

;//ＥＮＤ　ヒロイン１中立ルート


;//[SCENE id=30]
[SCENE id=18]
[system end1=true]

[jump storage="epend.ks" target="*start"]





;//==============================

