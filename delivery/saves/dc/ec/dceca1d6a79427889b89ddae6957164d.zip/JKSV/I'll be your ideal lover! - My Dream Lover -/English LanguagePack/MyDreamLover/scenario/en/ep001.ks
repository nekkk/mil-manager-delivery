




;//一連の流れ
;//================================================================================


;//一回目のバトル
;//・キャラ選択前の共通イベント
;//　　　↓
;//・キャラ選択
;//　　　↓
;//・前置きの語りや会話
;//　　　↓
;//・マップ選択前の共通イベント
;//　　　↓
;//・探索パート（アイテム集め）
;//　　　↓
;//・バトルパート
;//入手したアイテムを使用する。勝利条件に設定されていたアイテムなら勝利
;//違う場合は失敗となり負け
;//アイテムは今まで入手したものから選択する
;//一回目のイベントなら一つ、五回目なら今までの分から選ぶので五つとなる



;//→勝ち　ヒロインが主人公側に染まる（イベントシーンあり、なしなど状況により）
;//→負け　主人公がヒロイン側に染まる



;//二回目のバトル
;//・キャラ選択前の共通イベント
;//　　　↓
;//・キャラ選択
;//　　　↓
;//〜〜〜〜〜〜〜〜〜
;//※以下ループ



;//ヒロイン１、一回目のイベントに共通イベントなど入るタイミングを表記しています
;//他のシーンで特に表記がなくとも、同じタイミングで共通イベントが入ります


;//三回目のバトルが終わった所でエンディング分岐


;//以下、このシナリオは
;//・選択肢前の共通イベント
;//・アイテム取得イベント
;//・ヒロイン１のバトルイベント
;//・ヒロイン１の分岐後エンディング部分
;//・ヒロイン２のバトルイベント
;//・ヒロイン２の分岐後エンディング部分
;//・ヒロイン３のバトルイベント
;//・ヒロイン３の分岐後エンディング部分
;//・ヒロイン４のバトルイベント
;//・ヒロイン４の分岐後エンディング部分
;//・ハーレムルートとノーマルエンド
;//という順番に書いています


;//以降繰り返し選択
;//選択肢を選ぶ前に共通イベントが入ります。共通イベントは三つあり順繰りに変化します
;//選択肢を選ぶとそのヒロインのイベントが一つ進行します

;//================================================================================


*start|どちらが相手の理想に染まるか

;#################################################
*Ep001|どちらが相手の理想に染まるか
;#################################################

[SCENE id=1]

;//入手したアイテム
[stflag getItem_01 = 0]
;//[stflag getItem_02 = 0]
;//[stflag getItem_03 = 0]
;//[stflag getItem_04 = 0]
[stflag getItem_05 = 0]
[stflag getItem_06 = 0]
[stflag getItem_07 = 0]
[stflag getItem_08 = 0]
[stflag getItem_09 = 0]
[stflag getItem_10 = 0]
[stflag getItem_11 = 0]
[stflag getItem_12 = 0]
[stflag getItem_13 = 0]
[stflag getItem_14 = 0]
[stflag getItem_15 = 0]

;//■「映画館」
;//01映画のパンフレット
;//■「本屋」
;//05コスプレイヤーの際どい写真集
;//06読むだけで交渉上手になる本
;//07美紅似のモデルの写真
;//■「大型スーパー」
;//08手作り弁当
;//09地味な服
;//10砂糖を混ぜたホイップクリーム
;//■「電器屋」
;//11一眼レフ
;//12掃除機
;//■「バラエティショップ」
;//13コスプレ衣装
;//14栄養ドリンク
;//15ろうそく


;//マップ選択時にどのアイテムを選んだか
[stflag getItemNum_01 = 0]
[stflag getItemNum_02 = 0]
[stflag getItemNum_03 = 0]

;//全体で何回選んだか
[stflag Count_Selected = 0]

;//ヒロインを何回選んだか
[stflag HiStoryFlg_01 = 0]
[stflag HiStoryFlg_02 = 0]
[stflag HiStoryFlg_03 = 0]
[stflag HiStoryFlg_04 = 0]

;//ヒロインに何回勝ったか
[stflag HiWinFlg_01 = 0]
[stflag HiWinFlg_02 = 0]
[stflag HiWinFlg_03 = 0]
[stflag HiWinFlg_04 = 0]



;//選択したキャラによってアイテムの入手純が変わるので必要な分岐条件情報
[stflag Selected_cha = 0]


*before_select_chara|どちらが相手の理想に染まるか



[stflag Count_Selected = 1]

;//３回イベントを見ているならリザルトへ
[if exp={getFlagValue("Count_Selected") == 4}]
;//[jump target="*Go_to_Resalt"]
[jump storage="epResalt.ks" target="*Go_to_Resalt"]
[endif]


[if exp={getFlagValue("Count_Selected") == 1}]
[jump target="*before_select_chara_story1"]
[endif]


[if exp={getFlagValue("Count_Selected") == 2}]
[jump target="*before_select_chara_story2"]
[endif]



;//3回目なら
[jump target="*before_select_chara_story3"]


;//////////////////////////////
;//キャラクター選択前の共通イベント
;//パターン１
;//////////////////////////////

*before_select_chara_story1|Which one is dyed to the other's ideal?

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





I can't even get up in the morning, brush my teeth, and wash my face.
[cpg]

I can't even do that. I keep having the dream.
[cpg]

But at the very least, I have to keep up appearances.
[cpg]

With that in mind, I decided who I would turn into my ideal.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[jump target="*Chara_select"]

;//イベント終了



;//////////////////////////////
;//キャラクター選択前の共通イベント
;//パターン２
;//////////////////////////////

*before_select_chara_story2|どちらが相手の理想に染まるか

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[OnName num="takuma"]
I'm off.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





The morning sun was dazzling. As I walked along, the number of students gradually increased.
[cpg]


Some of them were couples, and I thought to myself, "What a bastard.
[cpg]


I didn't ask for a girlfriend, but I'm getting sick like this.
[cpg]


No, but is that a bad thing?　Did it all start with me trying to satisfy myself alone?
[cpg]


Then there's no way out for me if I don't get close to someone, a girl.
[cpg]


[OnName num="takuma"]
...... okay."
[cpg cn=true]


One mumbles and nods. I'm a bad guy from the outside.
[cpg]


But I have to have that much impetus to do it.
[cpg]


I decided to decide who I would turn into my ideal.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[jump target="*Chara_select"]

;//イベント終了



;//////////////////////////////
;//キャラクター選択前の共通イベント
;//パターン３
;//////////////////////////////

*before_select_chara_story3|どちらが相手の理想に染まるか

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





[OnName num="takuma"]
......
[cpg cn=true]


When I wake up in the morning, I suddenly think about what I'm doing.
[cpg]


Converting someone else into an ideal can be replaced with imposing an ideal on them.
[cpg]


I wonder if I should really be doing that.
[cpg]


I think to myself, "I could have had a more normal relationship.
[cpg]


[OnName num="takuma"]
No, I don't. ......
[cpg cn=true]


I'm taking the risk that I can change it too. Then why not?
[cpg]


We are on equal footing. Then I can behave as I like.
[cpg]


Am I turning someone I like into an ideal right now?　Or, am I being converted into an ideal by the person I love?
[cpg]


I can't stop thinking about it. Still, there is only one thing to do.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[jump target="*Chara_select"]

;//イベント終了



;//////////////////////////////
;//各イベント前の選択肢
;//////////////////////////////



*Chara_select|どちらが相手の理想に染まるか


;//フラグリセット
;//[stflag Selected_cha = 0]

I want to be changed into an ideal by...
[cpg]



;//■選択肢
[switch]
[case "Ii Kashi Sakura"]
	[swap]
	[jump target="*Select01_1"]
[case "Miho Subo"]
	[swap]
	[jump target="*Select01_2"]
[case "Mono Kosaka"]
	[swap]
	[jump target="*Select01_3"]
[case "Kadowaki Kozue"]
	[swap]
	[jump target="*Select01_4"]
[endswitch]


;//■選択肢
;//１、井伊樫 桜
;//２、素防 美紅
;//３、高坂 ものの
;//４、門脇 梢
[jump target="*before_select_map_story1"]


;//==============================
;//１、井伊樫 桜
*Select01_1|どちらが相手の理想に染まるか

[stflag Selected_cha = 1]

[stflag HiStoryFlg_01 = 1]

;//ヒロインを選んだ事を記憶
;//ヒロインのイベントが一つ進行

[jump target="*before_select_map"]
;//==============================
;//２、素防 美紅
*Select01_2|どちらが相手の理想に染まるか

[stflag Selected_cha = 2]

[stflag HiStoryFlg_02 = 1]

;//ヒロインを選んだ事を記憶
;//ヒロインのイベントが一つ進行

[jump target="*before_select_map"]
;//==============================
;//３、高坂 ものの
*Select01_3|どちらが相手の理想に染まるか

[stflag Selected_cha = 3]

[stflag HiStoryFlg_03 = 1]

;//ヒロインを選んだ事を記憶
;//ヒロインのイベントが一つ進行

[jump target="*before_select_map"]
;//==============================
;//４、門脇 梢
*Select01_4|どちらが相手の理想に染まるか

[stflag Selected_cha = 4]

[stflag HiStoryFlg_04 = 1]

;//ヒロインを選んだ事を記憶
;//ヒロインのイベントが一つ進行

[jump target="*before_select_map"]
;//==============================




;//以下マップ選択前の共通イベント
;//アイテム取得のためにマップを選択する前、共通で入ります
;//１→２→３→１〜と順繰りに変化していきます


*before_select_map|どちらが相手の理想に染まるか



;//1回目なら
[if exp={getFlagValue("Count_Selected") == 1}]
[jump target="*before_select_map_story1"]
[endif]


;//2回目なら
[if exp={getFlagValue("Count_Selected") == 2}]
[jump target="*before_select_map_story2"]
[endif]


;//3回目なら
[jump target="*before_select_map_story3"]



;//////////////////////////////
;//マップ選択前の共通イベント
;//パターン１
;//////////////////////////////
*before_select_map_story1|どちらが相手の理想に染まるか


;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



I've decided who I'm going to turn into my ideal.
[cpg]


Now it's just a matter of what I need to do to make it happen.
[cpg]


Love is a battle. Without preparation, you can't achieve what you want.
[cpg]


Love is a clash of desires. Either that, or it's a one-sided collision.
[cpg]



[OnName num="takuma"]
"Hmmm... ......"
[cpg cn=true]


I chuckle to myself as I formulate my strategy.
[cpg]


I'm going to need some things to make this desire come true.
[cpg]


I thought so, and I thought about where I was going to go.
[cpg]


[if exp={getFlagValue("Selected_cha") == 1}]
......Somehow, I think I'd rather go to the "variety store" to win the cherry blossoms.
[cpg]
[endif]

[if exp={getFlagValue("Selected_cha") == 2}]
......Somehow, I think I'd rather go to a "bookstore" to win over my seniors.
[cpg]
[endif]

[if exp={getFlagValue("Selected_cha") == 3}]
......Somehow, I think it's better to go to a "large supermarket" to win over the ones.
[cpg]
[endif]

[if exp={getFlagValue("Selected_cha") == 4}]
...... somehow, I think it is better to go to a "large supermarket" to win over a teacher.
[cpg]
[endif]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//イベント終了
[jump target="*before_map"]


;//////////////////////////////
;//マップ選択前の共通イベント
;//パターン２
;//////////////////////////////

*before_select_map_story2|どちらが相手の理想に染まるか

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_to"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





A battle to dye each other into an ideal.
[cpg]


To win it, I was making preparations.
[cpg]


What I want, I can't get right away.
[cpg]


Then I have to get it in order.
[cpg]

No amount of preparation will be enough.
[cpg]

;//もう手に入れたいものは見当ついてる。さあ、探しに行こう。
I already know what I want to get.
[cpg]


[if exp={getFlagValue("Selected_cha") == 1}]
The stuff to win the cherry should be in the "movie theater" or the "big supermarket".
[cpg]
I don't know why ......, but I feel like the more I lose, the better things will happen.
[cpg]
[endif]

[if exp={getFlagValue("Selected_cha") == 2}]
The things to beat seniors should be in "variety stores" or "large supermarkets".
[cpg]
[endif]

[if exp={getFlagValue("Selected_cha") == 3}]
The things to win over the "Mere Old Man" should be in the "variety store" or "electronics store".
[cpg]
[endif]

[if exp={getFlagValue("Selected_cha") == 4}]
The things to win over the teacher should be in the bookstore or variety store.
[cpg]
[endif]


Now, let's go looking for them.
[cpg]

;//どこに行けば、手に入るだろうか……？
;//[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//イベント終了

[jump target="*before_map"]


;//////////////////////////////
;//マップ選択前の共通イベント
;//パターン３
;//////////////////////////////

*before_select_map_story3|どちらが相手の理想に染まるか

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_co"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





I was looking for an item to turn the person I love into my ideal.
[cpg]


What can I get to change her into my ideal?
[cpg]


I couldn't sit still anyway, thinking about this and that.
[cpg]


Time passed in the meantime.
[cpg]


After all, I can't vent on my own, so I can't do nothing.
[cpg]


If I need someone's help, I'll borrow it.
[cpg]


I want to solve everything as soon as possible,...... and with that in mind, I took action.
[cpg]



[if exp={getFlagValue("Selected_cha") == 1}]
For some reason,...... I was convinced that "movie theaters" and "variety stores" were not what I needed to win the cherry blossom.
[cpg]
[endif]

[if exp={getFlagValue("Selected_cha") == 2}]
......Somehow, I was convinced that what I needed to win over my seniors was not in "bookstores" and "large supermarkets".
[cpg]
[endif]

[if exp={getFlagValue("Selected_cha") == 3}]
......Why, I was convinced that "large supermarkets" and "variety stores" did not have what I needed to win over my seniors.
[cpg]
[endif]

[if exp={getFlagValue("Selected_cha") == 4}]
......Why, I was convinced that "large supermarkets" and "variety stores" did not have what it takes to win over the teacher.
[cpg]
[endif]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[jump target="*before_map"]

*before_map|どちらが相手の理想に染まるか



;//イベント終了


;//[ClickMap g="map"]
;//[WAIT time=1]
;//[endswitch]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_map.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]


;//■選択肢
[switch]
[case "Movie theaters."]
	[swap]
	[jump target="*Select_map_01"]
[case "Bookstore."]
	[swap]
	[jump target="*Select_map_02"]
[case "A large supermarket."]
	[swap]
	[jump target="*Select_map_03"]
[case "An electronics store."]
	[swap]
	[jump target="*Select_map_04"]
[case "Variety store."]
	[swap]
	[jump target="*Select_map_05"]
[case ""]
	[swap]
	[jump target="*Select_map_05"]
[endswitch]



;//「映画館」
*Select_map_01|どちらが相手の理想に染まるか
[if exp={getFlagValue("Selected_cha") == 1}]
[jump target="*Select_map_01_1"]
[endif]
[if exp={getFlagValue("Selected_cha") == 2}]
[jump target="*Select_map_01_2"]
[endif]
[if exp={getFlagValue("Selected_cha") == 3}]
[jump target="*Select_map_01_3"]
[endif]
[if exp={getFlagValue("Selected_cha") == 4}]
[jump target="*Select_map_01_4"]
[endif]

*Select_map_01_1|どちらが相手の理想に染まるか
;//■ヒロイン１「映画館」の入手順
;//01映画のパンフレット
[if exp={getFlagValue("getItem_01") == 0}]
[jump target="*Get_item_event_01"]
[endif]


ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]


*Select_map_01_2|どちらが相手の理想に染まるか
;//■ヒロイン２「映画館」の入手順
;//01映画のパンフレット
[if exp={getFlagValue("getItem_01") == 0}]
[jump target="*Get_item_event_01"]
[endif]


ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]


*Select_map_01_3|どちらが相手の理想に染まるか
;//■ヒロイン３「映画館」の入手順
;//01映画のパンフレット
[if exp={getFlagValue("getItem_01") == 0}]
[jump target="*Get_item_event_01"]
[endif]

ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]

*Select_map_01_4|どちらが相手の理想に染まるか
;//■ヒロイン４「映画館」の入手順
;//01映画のパンフレット
[if exp={getFlagValue("getItem_01") == 0}]
[jump target="*Get_item_event_01"]
[endif]


ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]



;//「本屋」
*Select_map_02|どちらが相手の理想に染まるか
[if exp={getFlagValue("Selected_cha") == 1}]
[jump target="*Select_map_02_1"]
[endif]
[if exp={getFlagValue("Selected_cha") == 2}]
[jump target="*Select_map_02_2"]
[endif]
[if exp={getFlagValue("Selected_cha") == 3}]
[jump target="*Select_map_02_3"]
[endif]
[if exp={getFlagValue("Selected_cha") == 4}]
[jump target="*Select_map_02_4"]
[endif]

*Select_map_02_1|どちらが相手の理想に染まるか
;//■ヒロイン１「本屋」の入手順
;//05コスプレイヤーの際どい写真集
[if exp={getFlagValue("getItem_05") == 0}]
[jump target="*Get_item_event_05"]
[endif]
;//06読むだけで交渉上手になる本
[if exp={getFlagValue("getItem_06") == 0}]
[jump target="*Get_item_event_06"]
[endif]
;//07美紅似のモデルの写真
[if exp={getFlagValue("getItem_07") == 0}]
[jump target="*Get_item_event_07"]
[endif]

ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]


*Select_map_02_2|どちらが相手の理想に染まるか
;//■ヒロイン２「本屋」の入手順
;//07美紅似のモデルの写真
[if exp={getFlagValue("getItem_07") == 0}]
[jump target="*Get_item_event_07"]
[endif]
;//06読むだけで交渉上手になる本
[if exp={getFlagValue("getItem_06") == 0}]
[jump target="*Get_item_event_06"]
[endif]
;//05コスプレイヤーの際どい写真集
[if exp={getFlagValue("getItem_05") == 0}]
[jump target="*Get_item_event_05"]
[endif]
It seems that there are no more items that can be obtained here.
[cpg]
[jump target="*before_map"]

*Select_map_02_3|どちらが相手の理想に染まるか
;//■ヒロイン３「本屋」の入手順
;//06読むだけで交渉上手になる本
[if exp={getFlagValue("getItem_06") == 0}]
[jump target="*Get_item_event_06"]
[endif]
;//05コスプレイヤーの際どい写真集
[if exp={getFlagValue("getItem_05") == 0}]
[jump target="*Get_item_event_05"]
[endif]
;//07美紅似のモデルの写真
[if exp={getFlagValue("getItem_07") == 0}]
[jump target="*Get_item_event_07"]
[endif]
ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]

*Select_map_02_4|どちらが相手の理想に染まるか
;//■ヒロイン４「本屋」の入手順
;//05コスプレイヤーの際どい写真集
[if exp={getFlagValue("getItem_05") == 0}]
[jump target="*Get_item_event_05"]
[endif]
;//06読むだけで交渉上手になる本
[if exp={getFlagValue("getItem_06") == 0}]
[jump target="*Get_item_event_06"]
[endif]
;//07美紅似のモデルの写真
[if exp={getFlagValue("getItem_07") == 0}]
[jump target="*Get_item_event_07"]
[endif]
It seems that there are no more items that can be obtained here.
[cpg]
[jump target="*before_map"]



;//「大型スーパー」
*Select_map_03|どちらが相手の理想に染まるか
[if exp={getFlagValue("Selected_cha") == 1}]
[jump target="*Select_map_03_1"]
[endif]
[if exp={getFlagValue("Selected_cha") == 2}]
[jump target="*Select_map_03_2"]
[endif]
[if exp={getFlagValue("Selected_cha") == 3}]
[jump target="*Select_map_03_3"]
[endif]
[if exp={getFlagValue("Selected_cha") == 4}]
[jump target="*Select_map_03_4"]
[endif]

*Select_map_03_1|どちらが相手の理想に染まるか
;//■ヒロイン１「大型スーパー」の入手順
;//08手作り弁当
[if exp={getFlagValue("getItem_08") == 0}]
[jump target="*Get_item_event_08"]
[endif]
;//09地味な服
[if exp={getFlagValue("getItem_09") == 0}]
[jump target="*Get_item_event_09"]
[endif]
;//10砂糖を混ぜたホイップクリーム
[if exp={getFlagValue("getItem_10") == 0}]
[jump target="*Get_item_event_10"]
[endif]
ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]

*Select_map_03_2|どちらが相手の理想に染まるか
;//■ヒロイン２「大型スーパー」の入手順
;//08手作り弁当
[if exp={getFlagValue("getItem_08") == 0}]
[jump target="*Get_item_event_08"]
[endif]
;//09地味な服
[if exp={getFlagValue("getItem_09") == 0}]
[jump target="*Get_item_event_09"]
[endif]
;//10砂糖を混ぜたホイップクリーム
[if exp={getFlagValue("getItem_10") == 0}]
[jump target="*Get_item_event_10"]
[endif]
ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]

*Select_map_03_3|どちらが相手の理想に染まるか
;//■ヒロイン３「大型スーパー」の入手順
;//10砂糖を混ぜたホイップクリーム
[if exp={getFlagValue("getItem_10") == 0}]
[jump target="*Get_item_event_10"]
[endif]
;//08シャンプー
[if exp={getFlagValue("getItem_08") == 0}]
[jump target="*Get_item_event_08"]
[endif]
;//09地味な服
[if exp={getFlagValue("getItem_09") == 0}]
[jump target="*Get_item_event_09"]
[endif]
ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]

*Select_map_03_4|どちらが相手の理想に染まるか
;//■ヒロイン４「大型スーパー」の入手順
;//09地味な服
[if exp={getFlagValue("getItem_09") == 0}]
[jump target="*Get_item_event_09"]
[endif]
;//08手作り弁当
[if exp={getFlagValue("getItem_08") == 0}]
[jump target="*Get_item_event_08"]
[endif]
;//10砂糖を混ぜたホイップクリーム
[if exp={getFlagValue("getItem_10") == 0}]
[jump target="*Get_item_event_10"]
[endif]
ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]




;//「電器屋」
*Select_map_04|どちらが相手の理想に染まるか
[if exp={getFlagValue("Selected_cha") == 1}]
[jump target="*Select_map_04_1"]
[endif]
[if exp={getFlagValue("Selected_cha") == 2}]
[jump target="*Select_map_04_2"]
[endif]
[if exp={getFlagValue("Selected_cha") == 3}]
[jump target="*Select_map_04_3"]
[endif]
[if exp={getFlagValue("Selected_cha") == 4}]
[jump target="*Select_map_04_4"]
[endif]

*Select_map_04_1|どちらが相手の理想に染まるか
;//■ヒロイン１「電器屋」の入手順
;//11一眼レフ
[if exp={getFlagValue("getItem_11") == 0}]
[jump target="*Get_item_event_11"]
[endif]
;//12掃除機
[if exp={getFlagValue("getItem_12") == 0}]
[jump target="*Get_item_event_12"]
[endif]
ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]

*Select_map_04_2|どちらが相手の理想に染まるか
;//■ヒロイン２「電器屋」の入手順
;//11一眼レフ
[if exp={getFlagValue("getItem_11") == 0}]
[jump target="*Get_item_event_11"]
[endif]
;//12掃除機
[if exp={getFlagValue("getItem_12") == 0}]
[jump target="*Get_item_event_12"]
[endif]
ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]

*Select_map_04_3|どちらが相手の理想に染まるか
;//■ヒロイン３「電器屋」の入手順
;//11一眼レフ
[if exp={getFlagValue("getItem_11") == 0}]
[jump target="*Get_item_event_11"]
[endif]
;//12掃除機
[if exp={getFlagValue("getItem_12") == 0}]
[jump target="*Get_item_event_12"]
[endif]
ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]

*Select_map_04_4|どちらが相手の理想に染まるか
;//■ヒロイン４「電器屋」の入手順
;//12掃除機
[if exp={getFlagValue("getItem_12") == 0}]
[jump target="*Get_item_event_12"]
[endif]
;//11一眼レフ
[if exp={getFlagValue("getItem_11") == 0}]
[jump target="*Get_item_event_11"]
[endif]
ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]






;//「バラエティショップ」
*Select_map_05|どちらが相手の理想に染まるか
[if exp={getFlagValue("Selected_cha") == 1}]
[jump target="*Select_map_05_1"]
[endif]
[if exp={getFlagValue("Selected_cha") == 2}]
[jump target="*Select_map_05_2"]
[endif]
[if exp={getFlagValue("Selected_cha") == 3}]
[jump target="*Select_map_05_3"]
[endif]
[if exp={getFlagValue("Selected_cha") == 4}]
[jump target="*Select_map_05_4"]
[endif]


*Select_map_05_1|どちらが相手の理想に染まるか
;//■ヒロイン１「バラエティショップ」の入手順
;//13コスプレ衣装
[if exp={getFlagValue("getItem_13") == 0}]
[jump target="*Get_item_event_13"]
[endif]
;//14栄養ドリンク
[if exp={getFlagValue("getItem_14") == 0}]
[jump target="*Get_item_event_14"]
[endif]
;//15ろうそく
[if exp={getFlagValue("getItem_15") == 0}]
[jump target="*Get_item_event_15"]
[endif]
ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]

*Select_map_05_2|どちらが相手の理想に染まるか
;//■ヒロイン２「バラエティショップ」の入手順
;//13コスプレ衣装
[if exp={getFlagValue("getItem_13") == 0}]
[jump target="*Get_item_event_13"]
[endif]
;//14栄養ドリンク
[if exp={getFlagValue("getItem_14") == 0}]
[jump target="*Get_item_event_14"]
[endif]
;//15ろうそく
[if exp={getFlagValue("getItem_15") == 0}]
[jump target="*Get_item_event_15"]
[endif]
ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]

*Select_map_05_3|どちらが相手の理想に染まるか
;//■ヒロイン３「バラエティショップ」の入手順
;//15ろうそく
[if exp={getFlagValue("getItem_15") == 0}]
[jump target="*Get_item_event_15"]
[endif]
;//13コスプレ衣装
[if exp={getFlagValue("getItem_13") == 0}]
[jump target="*Get_item_event_13"]
[endif]
;//14栄養ドリンク
[if exp={getFlagValue("getItem_14") == 0}]
[jump target="*Get_item_event_14"]
[endif]
ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]

*Select_map_05_4|どちらが相手の理想に染まるか
;//■ヒロイン４「バラエティショップ」の入手順
;//14栄養ドリンク
[if exp={getFlagValue("getItem_14") == 0}]
[jump target="*Get_item_event_14"]
[endif]
;//13コスプレ衣装
[if exp={getFlagValue("getItem_13") == 0}]
[jump target="*Get_item_event_13"]
[endif]
;//15ろうそく
[if exp={getFlagValue("getItem_15") == 0}]
[jump target="*Get_item_event_15"]
[endif]
ここで手に入れられるアイテムはもうないようだ。
[cpg]
[jump target="*before_map"]



;//共通イベントの後、マップ選択
;//選択した場所ごとに、アイテムが手に入ります

;//マップを選択すると、アイテムが一つだけ手に入ります
;//その直前の選択肢で、どのヒロインを選んでいるかによって手に入るアイテムの順番が変わります
;//各キャラ、必要なアイテムほど先に来るように設定しています
;//選んだ段階で手に入れておらず、もっとも順番が早いものだけが手に入ります
;//マップのアイコンにカーソルを合わせた時点で、手に入るアイテムの名前を表示してください

;//以下、ヒロインごとのアイテム入手順を書き並べます
;//上にあるものから順に先に手に入ります
;//既に入手しているアイテムは出現しません





;//ヒロイン１のアイテム入手順
*Get_item_event_00|どちらが相手の理想に染まるか

;//■ヒロイン１「映画館」の入手順
;//01映画のパンフレット
;//■ヒロイン１「本屋」の入手順
;//05コスプレイヤーの際どい写真集
;//06読むだけで交渉上手になる本
;//07美紅似のモデルの写真
;//■ヒロイン１「大型スーパー」の入手順
;//08手作り弁当
;//09地味な服
;//10砂糖を混ぜたホイップクリーム
;//■ヒロイン１「電器屋」の入手順
;//11一眼レフ
;//12掃除機
;//■ヒロイン１「バラエティショップ」の入手順
;//13コスプレ衣装
;//14栄養ドリンク
;//15ろうそく

;//ヒロイン２のアイテム入手順
;//■ヒロイン２「映画館」の入手順
;//01映画のパンフレット
;//■ヒロイン２「本屋」の入手順
;//07美紅似のモデルの写真
;//06読むだけで交渉上手になる本
;//05コスプレイヤーの際どい写真集
;//■ヒロイン２「大型スーパー」の入手順
;//08手作り弁当
;//09地味な服
;//10砂糖を混ぜたホイップクリーム
;//■ヒロイン２「電器屋」の入手順
;//11一眼レフ
;//12掃除機
;//■ヒロイン２「バラエティショップ」の入手順
;//13コスプレ衣装
;//14栄養ドリンク
;//15ろうそく

;//ヒロイン３のアイテム入手順
;//■ヒロイン３「映画館」の入手順
;//01映画のパンフレット
;//■ヒロイン３「本屋」の入手順
;//05コスプレイヤーの際どい写真集
;//06読むだけで交渉上手になる本
;//07美紅似のモデルの写真
;//■ヒロイン３「大型スーパー」の入手順
;//10砂糖を混ぜたホイップクリーム
;//08手作り弁当
;//09地味な服
;//■ヒロイン３「電器屋」の入手順
;//11一眼レフ
;//12掃除機
;//■ヒロイン３「バラエティショップ」の入手順
;//15ろうそく
;//13コスプレ衣装
;//14栄養ドリンク

;//ヒロイン４のアイテム入手順
;//■ヒロイン４「映画館」の入手順
;//01映画のパンフレット
;//■ヒロイン４「本屋」の入手順
;//05コスプレイヤーの際どい写真集
;//06読むだけで交渉上手になる本
;//07美紅似のモデルの写真
;//■ヒロイン４「大型スーパー」の入手順
;//09地味な服
;//08手作り弁当
;//10砂糖を混ぜたホイップクリーム
;//■ヒロイン４「電器屋」の入手順
;//12掃除機
;//11一眼レフ
;//■ヒロイン４「バラエティショップ」の入手順
;//14栄養ドリンク
;//13コスプレ衣装
;//15ろうそく



;//以下アイテム取得イベント

;//==============================
;//イベント用アイテム「映画のパンフレット」
*Get_item_event_01|どちらが相手の理想に染まるか
;//☆アイテム入手イベント
;//入手場所「映画館」


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[stflag getItem_01 = 1]



[if exp={getFlagValue("Count_Selected") == 1 }]
[stflag getItemNum_01 = 1]
[endif]
[if exp={getFlagValue("Count_Selected") == 2 }]
[stflag getItemNum_02 = 1]
[endif]
[if exp={getFlagValue("Count_Selected") == 3 }]
[stflag getItemNum_03 = 1]
[endif]

I go to the movie theater to ask for a pamphlet.
[cpg]

It's almost like a kind of "just for fun," but I like it.
[cpg]

It's not something you can understand just by reading an article on the Internet, and it's not like watching the movie itself. ......
[cpg]

I feel there is such room for imagination there.
[cpg]

[jump target="*After_item_event"]

;//==============================
;//イベント用アイテム「手作り弁当」
*Get_item_event_08|どちらが相手の理想に染まるか
;//☆アイテム入手イベント
;//入手場所「大型スーパー」

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[stflag getItem_08 = 1]

[if exp={getFlagValue("Count_Selected") == 1 }]
[stflag getItemNum_01 = 8]
[endif]
[if exp={getFlagValue("Count_Selected") == 2 }]
[stflag getItemNum_02 = 8]
[endif]
[if exp={getFlagValue("Count_Selected") == 3 }]
[stflag getItemNum_03 = 8]
[endif]


Unusually, I went to the supermarket. There, I was looking for foodstuffs.
[cpg]

I was planning my future plans. The plan was to prepare a homemade lunch box.
[cpg]

I have already thought about how to use it. I know not many people would want to eat a man's homemade food. ......
[cpg]

But that's okay. It's for the fulfillment of my ambition.
[cpg]


[jump target="*After_item_event"]

;//==============================
;//イベント用アイテム「コスプレ衣装」
*Get_item_event_13|どちらが相手の理想に染まるか
;//☆アイテム入手イベント



;//入手場所「バラエティショップ」



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

[stflag getItem_13 = 1]

[if exp={getFlagValue("Count_Selected") == 1 }]
[stflag getItemNum_01 = 13]
[endif]
[if exp={getFlagValue("Count_Selected") == 2 }]
[stflag getItemNum_02 = 13]
[endif]
[if exp={getFlagValue("Count_Selected") == 3 }]
[stflag getItemNum_03 = 13]
[endif]

I'm reaching for one crazy thing right now.
[cpg]


Cosplay costumes. Something that no one, not even the most ordinary person, would touch.
[cpg]


My hands are sweating, and I'm excited in front of the so-called variety store.
[cpg]


I make up my mind. I have a rough idea of how much it costs.
[cpg]


What kind of things will I do with this dress? My fantasies are growing.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I was still overwhelmed when I entered the store.
[cpg]


I accelerated my perverted engine. What am I going to do here?
[cpg]


I had to put it on a girl. I'm going to put it on someone I like. This is nothing to be ashamed of.
[cpg]


In fact, it's the girl who should be embarrassed. Then why not!
[cpg]


Filling my head with fantasies, I head to the cash register, trying not to smile too thinly.
[cpg]


It's a woman's size, so they won't think I'll wear it, probably, it's fine ......
[cpg]

[jump target="*After_item_event"]

;//==============================

;//==============================
;//イベント用アイテム「コスプレイヤーの際どい写真集」
*Get_item_event_05|どちらが相手の理想に染まるか
;//☆アイテム入手イベント

;//入手場所「大型スーパー」


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

[stflag getItem_05 = 1]

[if exp={getFlagValue("Count_Selected") == 1 }]
[stflag getItemNum_01 = 5]
[endif]
[if exp={getFlagValue("Count_Selected") == 2 }]
[stflag getItemNum_02 = 5]
[endif]
[if exp={getFlagValue("Count_Selected") == 3 }]
[stflag getItemNum_03 = 5]
[endif]


I headed to the bookstore to get an item that would help me convince a certain someone.
[cpg]


;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



From the cover, it's pretty racy. It's a photo book of cosplayers.
[cpg]


[OnName num="takuma"]
'Hmmm... ...... just wait and see.'
[cpg cn=true]


I muttered to myself, imagining what I was about to do.
[cpg]


[jump target="*After_item_event"]

;//==============================
;//==============================
;//イベント用アイテム「一眼レフ」
*Get_item_event_11|どちらが相手の理想に染まるか
;//☆アイテム入手イベント



;//入手場所「電器屋」



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[stflag getItem_11 = 1]

[if exp={getFlagValue("Count_Selected") == 1 }]
[stflag getItemNum_01 = 11]
[endif]
[if exp={getFlagValue("Count_Selected") == 2 }]
[stflag getItemNum_02 = 11]
[endif]
[if exp={getFlagValue("Count_Selected") == 3 }]
[stflag getItemNum_03 = 11]
[endif]


An electronics store. I was looking for what I wanted there.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku034"]
[OnName num="miku"]
"Oh, ...... Takuma. Are you looking for something?
[cpg cn=true]


[OnName num="takuma"]
"Oh, thanks. Senior.
[cpg cn=true]


I bumped into him there.
[cpg]


[OnName num="takuma"]
"Hey, I'm looking for my camera.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku035"]
[OnName num="miku"]
"A camera ......?　What's it for?
[cpg cn=true]


[OnName num="takuma"]
"It's something for senpai."
[cpg cn=true]


I said, "It's something to do with my senpai," and I looked for the camera, laughing a little.
[cpg]


With this camera, I would take pictures of my senpai's perversion.
[cpg]


I was so excited that I was going to use it to take pictures of my senior's perversion.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku036"]
[OnName num="miku"]
There's a lot going on these days. ...... so small.
[cpg cn=true]


[OnName num="takuma"]
"Yes, it seems so. ...... Wow, it's expensive."
[cpg cn=true]


But it was a necessary expense. I spent my allowance and got a camera.
[cpg]

[jump target="*After_item_event"]

;//==============================
;//イベント用アイテム「砂糖を混ぜたホイップクリーム」
*Get_item_event_10|どちらが相手の理想に染まるか
;//☆アイテム入手イベント



;//入手場所「大型スーパー」




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

[stflag getItem_10 = 1]

[if exp={getFlagValue("Count_Selected") == 1 }]
[stflag getItemNum_01 = 10]
[endif]
[if exp={getFlagValue("Count_Selected") == 2 }]
[stflag getItemNum_02 = 10]
[endif]
[if exp={getFlagValue("Count_Selected") == 3 }]
[stflag getItemNum_03 = 10]
[endif]


I was on my way to the supermarket. There, I met him.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono051"]
[OnName num="monono"]
"Ah, senpai. Are you shopping?
[cpg cn=true]


[OnName num="takuma"]
"You too. Did you buy something?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono052"]
[OnName num="monono"]
I usually buy ...... daily necessities and so on.
[cpg cn=true]


[OnName num="takuma"]
Don't you usually ask your parents for such things?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono053"]
[OnName num="monono"]
Is that so, senior?　I buy what I use on my own."
[cpg cn=true]


[OnName num="takuma"]
"Mmu...... I see."
[cpg cn=true]


I might have said something pathetic.
[cpg]


But that's okay. I'm here today to buy something I'm going to use on my own too.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





The thing I'm looking for is whipped cream.
[cpg]


After I went to buy it, I mixed the sugar.
[cpg]


It's something you'll need later on. ...... You can't neglect this kind of preparation.
[cpg]

[jump target="*After_item_event"]

;//==============================
;//イベント用アイテム「掃除機」
*Get_item_event_12|どちらが相手の理想に染まるか
;//☆アイテム入手イベント

;//入手場所「電器屋」


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ショッピングモール』（昼）******************************************************

[stflag getItem_12 = 1]

[if exp={getFlagValue("Count_Selected") == 1 }]
[stflag getItemNum_01 = 12]
[endif]
[if exp={getFlagValue("Count_Selected") == 2 }]
[stflag getItemNum_02 = 12]
[endif]
[if exp={getFlagValue("Count_Selected") == 3 }]
[stflag getItemNum_03 = 12]
[endif]

An appliance store in a shopping mall. I've come to look for a vacuum cleaner.
[cpg]


[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue011"]
[OnName num="kozue"]
"Oh, Shikata-kun,......, what a coincidence.
[cpg cn=true]


[OnName num="takuma"]
Hello. Are you shopping for something?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kozue012"]
[OnName num="kozue"]
Yeah," he said, "I'm sorry. My phone charger broke."
[cpg cn=true]


I wonder how easy it is to break a cell phone charger.
[cpg]


I wonder if he might break it, since he is a bit of a slacker .......
[cpg]


[OnName num="takuma"]
It's kind of like a teacher, isn't it?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue013"]
[OnName num="kozue"]
What do you mean ...... Shikata-kun, are you looking at the vacuum cleaner?
[cpg cn=true]


[OnName num="takuma"]
I'm looking for something small and light. I'm looking to see if there are any smaller, lighter ones."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue014"]
[OnName num="kozue"]
Does that mean your vacuum cleaner is broken?
[cpg cn=true]


[OnName num="takuma"]
No, I'm looking for something else.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue015"]
[OnName num="kozue"]
I'm looking at ......?"
[cpg cn=true]


I don't think the doctor understands. Well, that's okay.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I then bought a vacuum cleaner and left the store.
[cpg]

[jump target="*After_item_event"]

;//==============================
;//==============================
;//イベント用アイテム「美紅似のモデルの写真集」
*Get_item_event_07|どちらが相手の理想に染まるか
;//☆アイテム入手イベント

;//入手場所「本屋」

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[stflag getItem_07 = 1]

[if exp={getFlagValue("Count_Selected") == 1 }]
[stflag getItemNum_01 = 7]
[endif]
[if exp={getFlagValue("Count_Selected") == 2 }]
[stflag getItemNum_02 = 7]
[endif]
[if exp={getFlagValue("Count_Selected") == 3 }]
[stflag getItemNum_03 = 7]
[endif]


I came to the bookstore to look for something I wanted.
[cpg]


I saw a photo book of a model who looks like my senior at this store the other day.
[cpg]


I hope they haven't sold out yet. I enter the store with this thought in mind.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





There are sometimes people who look like Senpai.
[cpg]


She may have always been beautiful, but the model in this photo book still looks like her. ......
[cpg]


But the clothes she wears are totally different and her expression is totally different.
[cpg]


I wonder what she would think if I showed this to the senior herself?
[cpg]


She might notice her own qualities. I thought about that.
[cpg]



[jump target="*After_item_event"]

;//==============================
;//==============================
;//イベント用アイテム「読むだけで交渉上手になる本」
*Get_item_event_06|どちらが相手の理想に染まるか
;//☆アイテム入手イベント



;//入手場所「本屋」



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[stflag getItem_06 = 1]

[if exp={getFlagValue("Count_Selected") == 1 }]
[stflag getItemNum_01 = 6]
[endif]
[if exp={getFlagValue("Count_Selected") == 2 }]
[stflag getItemNum_02 = 6]
[endif]
[if exp={getFlagValue("Count_Selected") == 3 }]
[stflag getItemNum_03 = 6]
[endif]


As I headed to the bookstore, something caught my eye.
[cpg]

A book that would make me a better negotiator just by reading it. I think there are more and more books with this kind of title these days.
[cpg]

But the title of the book was straightforward, and I thought that if I read it, I might be able to negotiate better.
[cpg]

I decided to entrust such a gleam of hope to the book.
[cpg]


[jump target="*After_item_event"]

;//==============================
;//イベント用アイテム「地味な服」
*Get_item_event_09|どちらが相手の理想に染まるか
;//☆アイテム入手イベント



;//入手場所「大型スーパー」



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[stflag getItem_09 = 1]

[if exp={getFlagValue("Count_Selected") == 1 }]
[stflag getItemNum_01 = 9]
[endif]
[if exp={getFlagValue("Count_Selected") == 2 }]
[stflag getItemNum_02 = 9]
[endif]
[if exp={getFlagValue("Count_Selected") == 3 }]
[stflag getItemNum_03 = 9]
[endif]


;//上下cに黒帯を入れてください


;//[lbox on]



These days, even supermarkets sell clothes.
[cpg]


I don't find anything that I think is very tasteful or cool, but there are things that I think ......
[cpg]


I found something that I thought the teacher would wear.
[cpg]


[OnName num="takuma"]
I think this one is nice. ......
[cpg cn=true]


The teacher's sense of dress tends to be very plain.
[cpg]


You'll probably like the fact that it's too plain.
[cpg]


And of course, it doesn't end with just putting this on.
[cpg]


This is just a starting point. With this in mind, I decided to buy clothes.
[cpg]

;//[lbox off]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[jump target="*After_item_event"]

;//==============================
;//イベント用アイテム「栄養ドリンク」
*Get_item_event_14|どちらが相手の理想に染まるか
;//☆アイテム入手イベント



;//入手場所「バラエティショップ」



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[stflag getItem_14 = 1]

[if exp={getFlagValue("Count_Selected") == 1 }]
[stflag getItemNum_01 = 14]
[endif]
[if exp={getFlagValue("Count_Selected") == 2 }]
[stflag getItemNum_02 = 14]
[endif]
[if exp={getFlagValue("Count_Selected") == 3 }]
[stflag getItemNum_03 = 14]
[endif]

;//上下に黒帯を入れてください

;//[lbox on]


I went to a variety store in search of an energy drink.
[cpg]

I'm still a nutritional drinker, even though energy drinks are all the rage.
[cpg]

I was told by someone at ...... that I was like an uncle or an old man.　I'm sure Sakura will say something like that.
[cpg]

But that's okay. It's all about attracting the attention of the person I have feelings for.
[cpg]


;//[lbox off]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[jump target="*After_item_event"]


;//==============================
;//==============================
;//イベント用アイテム「ろうそく」
*Get_item_event_15|どちらが相手の理想に染まるか
;//☆アイテム入手イベント
;//入手場所「バラエティショップ」


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

[stflag getItem_15 = 1]

[if exp={getFlagValue("Count_Selected") == 1 }]
[stflag getItemNum_01 = 15]
[endif]
[if exp={getFlagValue("Count_Selected") == 2 }]
[stflag getItemNum_02 = 15]
[endif]
[if exp={getFlagValue("Count_Selected") == 3 }]
[stflag getItemNum_03 = 15]
[endif]

There is a suspicious item sold at a certain variety store.
[cpg]

The name is a candle that attracts spirits.
[cpg]

It looks like an ordinary candle, but I picked it up because of the elaborate packaging.
[cpg]

I wonder if anyone I know is afraid of this kind of thing. ......?
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;////////////////////////////////////////////////////////////////////
;//以下、ヒロイン１のイベント
;////////////////////////////////////////////////////////////////////

*After_item_event|Which one is dyed to the other's ideals?

;//アイテム入手後、選んでいたヒロインのイベントへ行く

[if exp={getFlagValue("Selected_cha") == 1}]
[stflag Selected_cha = -1]
[jump target="*Select_i_01"]
[endif]

[if exp={getFlagValue("Selected_cha") == 2}]
[stflag Selected_cha = -2]
[jump target="*Select_i_02"]
[endif]

[if exp={getFlagValue("Selected_cha") == 3}]
[stflag Selected_cha = -3]
[jump target="*Select_i_03"]
[endif]

[if exp={getFlagValue("Selected_cha") == 4}]
[stflag Selected_cha = -4]
[jump target="*Select_i_04"]
[endif]

;//==============================
;//１、井伊樫 桜
*Select_i_01|

;//[if exp={getFlagValue("HiStoryFlg_01") == 1}]
[if exp={getFlagValue("Count_Selected") == 1}]
;//[jump target="*HiStory1_01"]
[jump storage="ep002.ks" target="*HiStory1_01"]
[endif]

;//[if exp={getFlagValue("HiStoryFlg_01") == 2}]
[if exp={getFlagValue("Count_Selected") == 2}]
;//[jump target="*HiStory1_02"]
[jump storage="ep002.ks" target="*HiStory1_02"]
[endif]


;//[jump target="*HiStory1_03"]
;//[if exp={getFlagValue("Count_Selected") == 3}]
[jump storage="ep002.ks" target="*HiStory1_03"]

;//ヒロイン１のイベントが一つ進行

;//==============================
;//２、素防 美紅
*Select_i_02|

;//[if exp={getFlagValue("HiStoryFlg_02") == 1}]
[if exp={getFlagValue("Count_Selected") == 1}]
;//[jump target="*HiStory2_01"]
[jump storage="ep003.ks" target="*HiStory2_01"]
[endif]

;//[if exp={getFlagValue("HiStoryFlg_02") == 2}]
[if exp={getFlagValue("Count_Selected") == 2}]
;//[jump target="*HiStory2_02"]
[jump storage="ep003.ks" target="*HiStory2_02"]
[endif]


;//[jump target="*HiStory2_03"]
;//[if exp={getFlagValue("Count_Selected") == 3}]
[jump storage="ep003.ks" target="*HiStory2_03"]


;//ヒロイン２のイベントが一つ進行

;//==============================
;//３、高坂 ものの
*Select_i_03|

;//[if exp={getFlagValue("HiStoryFlg_03") == 1}]
[if exp={getFlagValue("Count_Selected") == 1}]
;//[jump target="*HiStory3_01"]
[jump storage="ep004.ks" target="*HiStory3_01"]
[endif]

;//[if exp={getFlagValue("HiStoryFlg_03") == 2}]
[if exp={getFlagValue("Count_Selected") == 2}]
;//[jump target="*HiStory3_02"]
[jump storage="ep004.ks" target="*HiStory3_02"]
[endif]


;//[jump target="*HiStory3_03"]
;//[if exp={getFlagValue("Count_Selected") == 3}]
[jump storage="ep004.ks" target="*HiStory3_03"]

;//ヒロイン３のイベントが一つ進行

;//==============================
;//４、門脇 梢
*Select_i_04|

;//[if exp={getFlagValue("HiStoryFlg_04") == 1}]
[if exp={getFlagValue("Count_Selected") == 1}]
;//[jump target="*HiStory4_01"]
[jump storage="ep005.ks" target="*HiStory4_01"]
[endif]

;//[if exp={getFlagValue("HiStoryFlg_04") == 2}]
[if exp={getFlagValue("Count_Selected") == 2}]
;//[jump target="*HiStory4_02"]
[jump storage="ep005.ks" target="*HiStory4_02"]
[endif]


;//[jump target="*HiStory4_03"]
;//[if exp={getFlagValue("Count_Selected") == 3}]
[jump storage="ep005.ks" target="*HiStory4_03"]


;//ヒロイン４のイベントが一つ進行
;//==============================



