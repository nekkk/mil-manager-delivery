

*start

;//==============================
;//ヒロインを選ぶ選択肢を３回繰り返しつつ、三人のヒロインにそれぞれ一度以上勝利している場合
;//更に、全てのヒロインの理想か中立いずれかのエンディングを見ている場合このエンディングへ
;//いずれか１キャラでも、理想か中立のエンディングを見ていなければこのエンディングではなくノーマルエンドへ
*Hiroin_Root_h|４人へのアプローチ

;#################################################
*Ep039|Approaches to four people
;#################################################

;//[SCENE id=39]
[SCENE id=27]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************





I was repeatedly approaching four women in equal measure.
[cpg]


For every one, I was hitting them with the hope that they would change to my ideals. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura158"]
[OnName num="sakura"]
'Good morning. Takuma."
[cpg cn=true]


[OnName num="takuma"]
'Oh ...... good morning.'
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura159"]
[OnName num="sakura"]
"Let's go to the classroom together, shall we? You know what I mean?
[cpg cn=true]


Then I meet Sakura. She was also the one I had set my ideals against.
[cpg]


I'm not the only one I've treated that way, since I say "she too.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="4/4" time=800]
[VOICE f="Monono177"]
[OnName num="monono"]
......
[cpg cn=true]


I felt a gaze from behind me. I looked back a little, and there he was.
[cpg]


He's obviously looking at me with jealousy. ......
[cpg]


It's bad, I thought, but there was nothing I could do.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_to"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Miku167"]
[OnName num="miku"]
「あ」
[cpg cn=true]


[VOICE f="Sakura160"]
[OnName num="sakura"]
Ah."
[cpg cn=true]


[OnName num="takuma"]
「……」
[cpg cn=true]


Senpai and Sakura met each other. It was also in front of me.
[cpg]


The reason for the subtle silence between us might be that my affair has already been discovered.
[cpg]


Or rather, I'm pretty sure they know. ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Miku168"]
[OnName num="miku"]
"Good morning, ....... Sakura-san."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Sakura161"]
[OnName num="sakura"]
Hello, Suo-senpai. What can I do for you?"
[cpg cn=true]


The sparks are flying. I'm sure that's what I saw.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="4/5" time=800]
[VOICE f="Miku169"]
[OnName num="miku"]
'This one's script......What do you want with Takuma?'
[cpg cn=true]


Senior looked quietly angry.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Sakura162"]
[OnName num="sakura"]
'There's nothing for you, nothing at all. We're childhood friends, we are."
[cpg cn=true]


[OnName num="takuma"]
'Yes, let's go!　Come on, we have to go to class, class is about to start.
[cpg cn=true]


[free time=1000]

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Sakura163"]
[OnName num="sakura"]
We've got to go to class. I'm not going to start yet.
[cpg cn=true]


Oh no. How did this happen? It's my fault. ......
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Miku170"]
[OnName num="miku"]
Takuma may be your childhood friend, but he's my junior.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Sakura164"]
[OnName num="sakura"]
So what?　The length of the relationship is definitely not the same."
[cpg cn=true]


Sakura's smile is conversely frightening. I think this is also typical of cherry blossoms.
[cpg]


[OnName num="takuma"]
 "Well, let's go... Sakura."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Miku171"]
[OnName num="miku"]
Takuma also has a shoulder to lean on, Sakura-san. ......?"
[cpg cn=true]


The words of my senpai pierce my heart. But it doesn't matter what they say.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





So, after the class, it is time for a break.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue097"]
[OnName num="kozue"]
...... Shikata-ju-kun. May I have a word?"
[cpg cn=true]


[OnName num="takuma"]
"Eh ......, what is it?"
[cpg cn=true]


I was summoned by the teacher.
[cpg]


Have I done something to be called out? No, you're doing it to the best of your ability. ......
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue098"]
[OnName num="kozue"]
You ...... seem to be dating not only me, but other female students as well.
[cpg cn=true]


[OnName num="takuma"]
I'm not dating,.......
[cpg cn=true]


I'm not dating yet.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue099"]
[OnName num="kozue"]
I can't ...... have an affair with someone who is me."
[cpg cn=true]


I'm sure you're right. I've done a lot of things with the teacher as well.
[cpg]


As for the teacher, he has lost his virginity,...... most of all, he has lost his virginity, and he is not going to back down.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Kozue100"]
[OnName num="kozue"]
I think the five of us should talk about this.
[cpg cn=true]


[OnName num="takuma"]
"The five of us? ......
[cpg cn=true]


I'm going to bring them all. I think it will be easy to get them all if you wield the power of being a teacher.
[cpg]


Even if not, they will all want to have a proper talk with me. ......
[cpg]


[OnName num="takuma"]
Excuse me!　I have something urgent to do.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Kozue101"]
[OnName num="kozue"]
I'm sorry, I've got some urgent business to attend to.　Wait for me!
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se000"]
;//【ＳＥ】『走る』



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（昼）******************************************************





[OnName num="takuma"]
"Ha, ha. ......
[cpg cn=true]


I've slipped out of the school.
[cpg]


No matter what you think, you can't keep running away.
[cpg]


I have to face them someday. ......
[cpg]


I know that, but I can't do it. I didn't have the courage to do it.
[cpg]


If I did poorly, I might be lynched by the four of them.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





So I ran away. I skipped class and hung around outside the school.
[cpg]


It's also a leisurely way to wander around the city with no purpose. And then I thought, "Oh, there he is!
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono178"]
[OnName num="monono"]
"Ah, there he is, ...... senior."
[cpg cn=true]


[OnName num="takuma"]
"Of what?　How did you get here?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono179"]
[OnName num="monono"]
I'm always watching you.
[cpg cn=true]


What does that mean? Have you been following me since school?
[cpg]


No, if that's the case, it's not right to say, "Oh, there he is.
[cpg]


Does that mean you were imagining where I would be hanging out ......?
[cpg]


[OnName num="takuma"]
Why did you come to me ......?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Monono180"]
[OnName num="monono"]
It's my senior's fault for cheating on me."
[cpg cn=true]


Although they say exactly what they mean. I guess I'll just have to prepare myself for a lynching now.
[cpg]


[OnName num="takuma"]
"......, stop it, violence is not good."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono181"]
[OnName num="monono"]
What?　What are you talking about?
[cpg cn=true]


What?　I was the one who wanted to say, "What do you mean, ?
[cpg]


[OnName num="takuma"]
What do you mean ......?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono182"]
[OnName num="monono"]
I said, "Nothing. I'm admitting that I'm cheating on him.
[cpg cn=true]


[OnName num="takuma"]
"But you want me to go to ......?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Monono183"]
[OnName num="monono"]
I would like you to look only at me, but if you can't, I don't have a choice. But if that's not possible, I don't have a choice.
[cpg cn=true]


You're awfully understanding. Or rather, convenient for me: ......
[cpg]


That's because I've been trying to make him an ideal junior, but I can't believe that he would even allow me to cheat on him.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono184"]
[OnName num="monono"]
I'm fine, but the problem is Suo-senpai and Kadowaki-sensei.
[cpg cn=true]


[OnName num="takuma"]
I knew you'd be mad at those two.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono185"]
[OnName num="monono"]
I am not a big fan of the "Iiokashi" style of play. It's just that it's rare for me or Iiogashi-senpai not to get angry.
[cpg cn=true]


[OnName num="takuma"]
I know," he said.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





The actuality is that the actuality is that the actuality is not really a good thing.
[cpg]


I had to talk to the seniors and the teacher properly. So it looked like the five of us were going to get together after all.
[cpg]


I left Mono and went back to my house in a depressed mood. ......
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[OnName num="takuma"]
I wonder if I overdid it. ......
[cpg cn=true]


I think I did too much. I had too much contact with everyone.
[cpg]


It seems I'm doomed to never escape these women again. ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





The next morning. It's a weekday, so I head back to the school.
[cpg]


It's depressing. All I can think about is how I'll be lectured by the teacher, or how I'll get stabbed by a senior.
[cpg]


But I think I've managed to bring the girls this close to my ideal so far.
[cpg]


Then I wonder if they would accept my cheating ......?
[cpg]


[OnName num="takuma"]
I don't think so. ......
[cpg cn=true]


I talk to myself. My mind was unstable.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（昼）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura165"]
[OnName num="sakura"]
'Good morning. Takuma."
[cpg cn=true]


[OnName num="takuma"]
'Good morning, .......'
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura166"]
[OnName num="sakura"]
What's wrong?　You don't look well. You don't look well.
[cpg cn=true]


[OnName num="takuma"]
"No, ......, I'm fine. I'm fine.
[cpg cn=true]


I must have looked pretty terrible.
[cpg]


It can't be helped that I have so much to worry about. ......
[cpg]


[OnName num="takuma"]
What do you think about ...... me, Sakura?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura167"]
[OnName num="sakura"]
What do you mean?　I don't understand your question.
[cpg cn=true]


[OnName num="takuma"]
"Look, what do you say ...... to other girls too?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura168"]
[OnName num="sakura"]
I don't know what you mean by that. I don't care, after all, Takuma and I spend different amounts of time together.
[cpg cn=true]


Sakura seemed to think she was the best.
[cpg]


This confidence is what makes them forgive you for cheating on them.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Then we go to class.
[cpg]


Lunch break approaches. I wonder if the five of us will get together at that time. ......
[cpg]


What a thought that makes me sick to my stomach.
[cpg]


I should have loved one of them instead of feeling like this.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





Lunch break. Sakura and Monono brought their lunch boxes.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/4" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/4" time=800]

[VOICE f="Sakura169"]
[OnName num="sakura"]
I was so excited to see her. What should I do?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/4" time=800]
[VOICE f="Monono186"]
[OnName num="monono"]
I don't have to eat mine. Or you can eat it at home.
[cpg cn=true]


[OnName num="takuma"]
No, I'll eat both. ......
[cpg cn=true]


I was so apologetic that I said something like that.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/4" time=800]
[VOICE f="Monono187"]
[OnName num="monono"]
'Really?　You don't have to.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/4" time=800]
[VOICE f="Sakura170"]
[OnName num="sakura"]
Then the three of us will play a game of fetch.
[cpg cn=true]


[free time=1000]


The senior staff members were staring at me outside the room while I was talking like this.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="4/4" time=800]
[VOICE f="Miku172"]
[OnName num="miku"]
「……」
[cpg cn=true]


The stares are painful. The cherry blossoms and the things are fine because they are accepting of this situation,.......
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_to"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





The first thing you need to do is to make sure that you have a good understanding of what you're doing and how to do it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/4" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/4" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/4" time=800]
[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="4/4" time=800]


[VOICE f="Kozue102"]
[OnName num="kozue"]
Now, what excuses will you give me?"
[cpg cn=true]


[OnName num="takuma"]
No,......, I don't have any excuse.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/4" time=800]
[VOICE f="Monono188"]
[OnName num="monono"]
I'm sure you're right. It's obviously my senior's fault.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/4" time=800]
[VOICE f="Sakura171"]
[OnName num="sakura"]
But I don't mind. The actuality that there are a lot of people who like Takuma, I'm rather happy.
[cpg cn=true]


Sakura is strangely tolerant. Perhaps it is because she is the most comfortable with herself.
[cpg]


[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="4/4" time=800]
[VOICE f="Kozue103"]
[OnName num="kozue"]
I don't condone cheating, but it doesn't mean I can break up with Shikata-kun,.......
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/4" time=800]
[VOICE f="Miku173"]
[OnName num="miku"]
That's for sure. ......
[cpg cn=true]


The senior seemed to feel the same way as the teacher.
[cpg]


 Even though I can't forgive what I've done, it doesn't seem like I can leave him.
[cpg]


 Somehow, I feel like I'm too sorry.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/4" time=800]
[VOICE f="Sakura172"]
[OnName num="sakura"]
Right?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/4" time=800]
[VOICE f="Miku174"]
[OnName num="miku"]
That's not right. ......!　It's not normal."
[cpg cn=true]


The senior staff members raised their voices. I was just shrugging my shoulders.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/4" time=800]
[VOICE f="Monono189"]
[OnName num="monono"]
But it won't be just for Suo-senpai. That's just the way it is."
[cpg cn=true]


He still didn't seem convinced.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/4" time=800]
[VOICE f="Miku175"]
[OnName num="miku"]
Let me think about it. ...... head, I can't get my head around it."
[cpg cn=true]


He held his head in his hands.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Sakura173"]
[OnName num="sakura"]
Mono-chan also liked Takuma, didn't she?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Monono190"]
[OnName num="monono"]
I'm not going to lose my love for my senpai to anyone. I love my senpai as much as anyone else.
[cpg cn=true]


I was on my way home when I was followed by Sakura and Mononono.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Sakura174"]
[OnName num="sakura"]
Hmmm..."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Monono191"]
[OnName num="monono"]
'Fufufu......'
[cpg cn=true]


They were both smiling, but something about their smiles made me feel scared.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=800]


Then, of course, two of them came up to my room.
[cpg]


[OnName num="takuma"]
I knew it wasn't right, this relationship.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[VOICE f="Sakura175"]
[OnName num="sakura"]
He said, "You have to take responsibility even if things go wrong. It's all Takuma's fault.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Monono192"]
[OnName num="monono"]
That's right.
[cpg cn=true]


Even if you say so, I still think it's strange that I can't prepare my heart.
[cpg]


I didn't expect this to happen, even with the situation I created. ......
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





Then they left and I was alone.
[cpg]


I strangely missed the time alone. ......
[cpg]



[SE f="se000"]
;//【ＳＥ】『携帯電話の着信音』


;//[lbox on]



Then I got a call from my senior.
[cpg]


[OnName num="takuma"]
"Yes, hello. ......
[cpg cn=true]



[VOICE f="Miku176"]
[OnName num="miku"]
Sorry, it's late. It's late.
[cpg cn=true]


[OnName num="takuma"]
No, it's nothing. ...... what is it?
[cpg cn=true]



[VOICE f="Miku177"]
[OnName num="miku"]
I've been thinking about it a lot since then, and I still like Takuma.
[cpg cn=true]


He says what I think he would have said. And then he went on to say this.
[cpg]



[VOICE f="Miku178"]
[OnName num="miku"]
What should I do ......?　I don't want to see Takuma with another girl."
[cpg cn=true]


My heart tightens. The type of cherry blossoms and things are different.
[cpg]


[OnName num="takuma"]
"......I'm sorry.
[cpg cn=true]



[VOICE f="Miku179"]
[OnName num="miku"]
Don't apologize. It's just hard for me too.
[cpg cn=true]


[OnName num="takuma"]
「……」
[cpg cn=true]


Silence for a while. Then.
[cpg]



[VOICE f="Miku180"]
[OnName num="miku"]
"That's what I meant. ...... I'll see you tomorrow."
[cpg cn=true]



[SE f="se000"]
;//【ＳＥ】『携帯電話の通話終了音』

;//[lbox off]



Then the phone hangs up. A painful silence remains.
[cpg]


I wonder what I should have ...... done.
[cpg]


I feel like I have no choice but to enjoy the situation, but I don't feel like I can enjoy it.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





I don't know, and morning comes.
[cpg]


I feel as if I have no choice but to open up. If I worry and worry and worry every day, I'm going to be in over my head.
[cpg]


It can't be helped now. With that feeling, I got ready and started my way to school.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************





A little before the school, I meet a senior.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miku181"]
[OnName num="miku"]
He said, "Good morning, ....... Takuma."
[cpg cn=true]


The senior was also a little sleep-deprived and looked pale.
[cpg]


[OnName num="takuma"]
Senior, are you sleeping okay?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Miku182"]
[OnName num="miku"]
Who do you think is to blame?
[cpg cn=true]


I had no words to reply. ......
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku183"]
[OnName num="miku"]
But that's enough. All I have is Takuma."
[cpg cn=true]


[OnName num="takuma"]
"Well,......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku184"]
[OnName num="miku"]
I have to like him even if he's cheating on me.
[cpg cn=true]


I'm forcing my senpai to do too much. I feel sorry and ......
[cpg]


If that's what you thought, I wouldn't have told you.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura176"]
[OnName num="sakura"]
I never thought the day would come when Takuma would be so popular. I didn't expect it either.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/4" time=800]
[VOICE f="Miku185"]
[OnName num="miku"]
I don't want ...... him to be popular."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/4" time=800]
[VOICE f="Monono193"]
[OnName num="monono"]
I don't want him to be popular. I can't help it.
[cpg cn=true]


[OnName num="takuma"]
「……」
[cpg cn=true]


I was surrounded by three girls during my lunch break.
[cpg]


[OnName num="male_student_A"]
Why the hell is Shikataju so popular,......?
[cpg cn=true]


[OnName num="male_student_B"]
"Is he that good-looking?　He's just average."
[cpg cn=true]


I hear whispering and whispering. Things are being said that shouldn't be said.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/4" time=800]
[VOICE f="Miku186"]
[OnName num="miku"]
I still ...... want to keep Takuma all to myself.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/4" time=800]
[VOICE f="Monono194"]
[OnName num="monono"]
The actuality that you can't say it even if you think it, Suo. I'm the same way.
[cpg cn=true]


I am sorry. I just can't help but feel sorry.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura177"]
[OnName num="sakura"]
Takuma, you're physically strong, so you can do it, right?"
[cpg cn=true]


I couldn't answer that I couldn't do it.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


After all, the cherry blossoms didn't come on to me at that time either. ......
[cpg]


A little while later, after school.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





An empty classroom. I was being lectured by the teacher.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kozue104"]
[OnName num="kozue"]
Shikata-kun. Who are you going to marry in the end?
[cpg cn=true]


[OnName num="takuma"]
That's .......
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue105"]
[OnName num="kozue"]
I'm sorry if you don't know. I'm sorry if you don't know. At my age, I think about a lot of things.
[cpg cn=true]


You make a good point. There's also the question of how I'm going to support myself if I do end up going out with everyone.
[cpg]


And then there is the senior who is watching me and the teacher talking.
[cpg]


I can see him sneaking a peek at me at the entrance of the room.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kozue106"]
[OnName num="kozue"]
......You really can't help it, Shihouju-kun. I wonder why I fell in love with this girl."
[cpg cn=true]


Even the ...... teacher is making me say this.
[cpg]


What's going to happen to me from now on,......?
[cpg]


It seems like there is nothing I can do but think about it. But I can't help thinking about it.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


Yes, it is true. At first, I was working to turn everyone into my ideal.
[cpg]


The ideal childhood friend. The ideal senior. The ideal junior. The ideal teacher.
[cpg]


Now, if all of that has come true, isn't this something to be happy about ......?
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************





I went out into the hallway, unable to get my head around it.
[cpg]


Walking unsteadily, I met Sakura.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura178"]
[OnName num="sakura"]
Oh, here you are. What were you doing, Takuma?
[cpg cn=true]


[OnName num="takuma"]
I've been having a lot of trouble with .......
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura179"]
[OnName num="sakura"]
I see. I'm sure you've been having a secret meeting with another girl.
[cpg cn=true]


He knows. No, is it natural for them to see through it? ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura180"]
[OnName num="sakura"]
I'll go home with you. You look kind of tired, so I'll at least lend you my shoulder."
[cpg cn=true]


[OnName num="takuma"]
No, no,......, I'm fine.
[cpg cn=true]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura181"]
[OnName num="sakura"]
I'm just.... I've been called a lightweight and a lot of other things.
[cpg cn=true]


[OnName num="takuma"]
"......, yeah."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura182"]
[OnName num="sakura"]
But in terms of having a lot of lovers or ...... having fun, you can't beat Takuma, can you?
[cpg cn=true]


That's for sure. No one will say anything bad about Sakura anymore.
[cpg]


They say he's dating four women together,.......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura183"]
[OnName num="sakura"]
'But I think this relationship is good too.
[cpg cn=true]


[OnName num="takuma"]
'You don't have to say that,...... you don't even think it.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura184"]
[OnName num="sakura"]
'I really do think it. Everyone likes me and everyone likes the person I like."
[cpg cn=true]


I don't know if he's serious. I can't decide.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sakura185"]
[OnName num="sakura"]
I like you, Takuma. Even if everyone else is in love with me, I'm the only one who loves Takuma."
[cpg cn=true]


[OnName num="takuma"]
Thanks to ......."
[cpg cn=true]


I didn't have much of a choice in my response anymore. My head wasn't moving properly.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************





The next few days passed.
[cpg]


I was the first person to go on a date like this.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ショッピングモール店内』（昼）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/4" time=800]
[VOICE f="Monono195"]
[OnName num="monono"]
I've never been on a date like this before.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura186"]
[OnName num="sakura"]
Well, it's unusual, isn't it? I've never been on a date like this before.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="4/4" time=800]
[VOICE f="Miku187"]
[OnName num="miku"]
Can I hold your hand?
[cpg cn=true]


I'm not going to return the favor and walk away thinking, "I only have two hands.
[cpg]


I was now on a date with all three of them except for the teacher.
[cpg]


Two hands are like flowers, but more than that.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura187"]
[OnName num="sakura"]
I need to have these dates, too. We need to get to know each other.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="1/4" time=800]
[VOICE f="Monono196"]
[OnName num="monono"]
I agree. I would like to get to know Iyengashi better.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/4" time=800]
[VOICE f="Miku188"]
[OnName num="miku"]
I also want to get to know both of you better.
[cpg cn=true]


The actual "I'm not a fan of the way you do it," he said.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="1/4" time=800]
[VOICE f="Monono197"]
[OnName num="monono"]
I'm hungry. Do you want to eat somewhere?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura188"]
[OnName num="sakura"]
"Yes, I think so. Takuma said he'll buy me a drink.
[cpg cn=true]


[OnName num="takuma"]
What?
[cpg cn=true]


I said, but that reaction was not good here.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura189"]
[OnName num="sakura"]
What? You're not going to buy me a drink?
[cpg cn=true]


[OnName num="takuma"]
I said, "No, no. Leave it to me.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/4" time=800]
[VOICE f="Monono198"]
[OnName num="monono"]
If it's on the house, it would be a waste if we go to a family restaurant. Where shall we go?
[cpg cn=true]


I was enjoying myself watching my reaction. It seemed like he was enjoying watching my reaction.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The days go by with such things happening.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[OnName num="takuma"]
I wonder if my body will last ......
[cpg cn=true]


Such a soliloquy comes out. However, no matter what I plan to do, the future doesn't seem to change much.
[cpg]


For example, if I say that I love only Sakura, will the other three leave me alone?
[cpg]


Probably not. That's what cheating is all about, I thought.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************


It was another weekday, and I had classes at the school.
[cpg]


I can't help but feel uneasy when I think about the future.
[cpg]


If all four of us had children, we would have to raise them.
[cpg]


That might be easier than raising a couple alone, but there are also financial problems. ......
[cpg]


I wonder if I will have to settle this love somewhere.
[cpg]


I was thinking about this, but time was passing without an answer.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************




[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/4" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/4" time=800]

[VOICE f="Sakura190"]
[OnName num="sakura"]
'I'm getting used to the rumors now, aren't I?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/4" time=800]
[VOICE f="Monono199"]
[OnName num="monono"]
'Yes, I have. I don't really care about it.
[cpg cn=true]


I do care. I've heard the rumors for a long time.
[cpg]


I've been hearing rumors that a man like that has four girlfriends.
[cpg]


Or maybe he was the son of a very wealthy family. Or maybe he found out about it.
[cpg]


I was being told all sorts of things, and I was being swept up in every single one of these rumors.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/4" time=800]
[VOICE f="Miku189"]
[OnName num="miku"]
I was being bombarded with rumors.　What's wrong?
[cpg cn=true]


[OnName num="takuma"]
Oh no, it's nothing."
[cpg cn=true]


I was thinking about something dark, and my senpai would immediately see right through it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura191"]
[OnName num="sakura"]
I don't want you to worry too much," he said. Besides, I think we have more problems than you do.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/4" time=800]
[VOICE f="Miku190"]
[OnName num="miku"]
Really, so ...... we are more worried about the future than Takuma.
[cpg cn=true]


That would certainly be true.
[cpg]


Since four of us love one man, you would think that ...... our affection would tilt to someone else or something.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/4" time=800]
[VOICE f="Monono200"]
[OnName num="monono"]
I'm not so sure. I trust my seniors."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura192"]
[OnName num="sakura"]
"Oh, mono-chan,...... that's a sly way of putting it."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





Then, after school. The five of us gathered in an empty classroom.
[cpg]


What kind of gathering is it anymore ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/4" time=800]
[VOICE f="Miku191"]
[OnName num="miku"]
I want Takuma to be more neutral ......."
[cpg cn=true]


[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="4/4" time=800]
[VOICE f="Kozue107"]
[OnName num="kozue"]
No, Mr. Suo. I prefer him more muscular."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/4" time=800]
[VOICE f="Monono201"]
[OnName num="monono"]
He said, "Well, well, well. Why don't you just be a senior as you are?"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



The best way to get the best out of your own home is to get the best out of it. ...... Once again, I feel like I've gone to a terrible place.
[cpg]


The ideal school life that I sought came true in an unexpected way.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/4" time=800]
[VOICE f="Miku192"]
[OnName num="miku"]
The actuality that you can be a lot more than just a good friend.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/4" time=800]
[VOICE f="Monono202"]
[OnName num="monono"]
I'm not. Please tell me you're happy, senpai.
[cpg cn=true]


[OnName num="takuma"]
"I'm ...... happy."
[cpg cn=true]


[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="4/4" time=800]
[VOICE f="Kozue108"]
[OnName num="kozue"]
I feel like I've been made to say it. ...... Well, good.
[cpg cn=true]


I was about to fall asleep.
[cpg]


But now I wondered if it was okay to fall asleep like that.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/4" time=800]
[VOICE f="Sakura193"]
[OnName num="sakura"]
I love you, Takuma. I love you, Takuma. I love you, who loves everyone.
[cpg cn=true]





;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

;//ＥＮＤ　ハーレムエンド


;//[SCENE id=40]
[SCENE id=28]

[jump storage="epend.ks" target="*start"]




;//==============================


;#################################################
*Ep000|Result
;#################################################


*Go_to_Resalt|


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//各ヒロインに２勝以上していたら理想or中立ルート
[if exp={getFlagValue("HiWinFlg_01") == 3}]
[jump storage="ep002.ks" target="*Hiroin_Root_1_2"]
[endif]
[if exp={getFlagValue("HiWinFlg_01") == 2}]
[jump storage="ep002.ks" target="*Hiroin_Root_1_2"]
[endif]

[if exp={getFlagValue("HiWinFlg_02") == 3}]
[jump storage="ep003.ks" target="*Hiroin_Root_2_2"]
[endif]
[if exp={getFlagValue("HiWinFlg_02") == 2}]
[jump storage="ep003.ks" target="*Hiroin_Root_2_2"]
[endif]

[if exp={getFlagValue("HiWinFlg_03") == 3}]
[jump storage="ep004.ks" target="*Hiroin_Root_3_2"]
[endif]
[if exp={getFlagValue("HiWinFlg_03") == 2}]
[jump storage="ep004.ks" target="*Hiroin_Root_3_2"]
[endif]

[if exp={getFlagValue("HiWinFlg_04") == 3}]
[jump storage="ep005.ks" target="*Hiroin_Root_4_2"]
[endif]
[if exp={getFlagValue("HiWinFlg_04") == 2}]
[jump storage="ep005.ks" target="*Hiroin_Root_4_2"]
[endif]


;//３回のバトルを終えて勝利数が１以下であり、このヒロインを２回以上選んでいる場合
[if exp={getFlagValue("HiStoryFlg_01") == 3}]
[if exp={getFlagValue("HiWinFlg_01") >= 1}]
[jump storage="ep002.ks" target="*Hiroin_Root_1_1"]
[endif]
[endif]
[if exp={getFlagValue("HiStoryFlg_01") == 2}]
[if exp={getFlagValue("HiWinFlg_01") >= 1}]
[jump storage="ep002.ks" target="*Hiroin_Root_1_1"]
[endif]
[endif]


[if exp={getFlagValue("HiStoryFlg_02") == 3}]
[if exp={getFlagValue("HiWinFlg_02") >= 1}]
[jump storage="ep003.ks" target="*Hiroin_Root_2_1"]
[endif]
[endif]
[if exp={getFlagValue("HiStoryFlg_02") == 2}]
[if exp={getFlagValue("HiWinFlg_02") >= 1}]
[jump storage="ep003.ks" target="*Hiroin_Root_2_1"]
[endif]
[endif]

[if exp={getFlagValue("HiStoryFlg_03") == 3}]
[if exp={getFlagValue("HiWinFlg_03") >= 1}]
[jump storage="ep004.ks" target="*Hiroin_Root_3_1"]
[endif]
[endif]
[if exp={getFlagValue("HiStoryFlg_03") == 2}]
[if exp={getFlagValue("HiWinFlg_03") >= 1}]
[jump storage="ep004.ks" target="*Hiroin_Root_3_1"]
[endif]
[endif]

[if exp={getFlagValue("HiStoryFlg_04") == 3}]
[if exp={getFlagValue("HiWinFlg_04") >= 1}]
[jump storage="ep005.ks" target="*Hiroin_Root_4_1"]
[endif]
[endif]
[if exp={getFlagValue("HiStoryFlg_04") == 2}]
[if exp={getFlagValue("HiWinFlg_04") >= 1}]
[jump storage="ep005.ks" target="*Hiroin_Root_4_1"]
[endif]
[endif]



;//全てのヒロインに一度以上勝利している場合
;//ヒロイン１
[if exp={getFlagValue("HiWinFlg_01") == 1}]
[stflag battle_win=1]
[endif]
;//ヒロイン２
[if exp={getFlagValue("HiWinFlg_02") == 1}]
[stflag battle_win=1]
[endif]
;//ヒロイン３
[if exp={getFlagValue("HiWinFlg_03") == 1}]
[stflag battle_win=1]
[endif]
;//ヒロイン４
[if exp={getFlagValue("HiWinFlg_04") == 1}]
[stflag battle_win=1]
[endif]

;//別々のヒロインに３回勝ちつつ全キャラで、理想か中立のエンディングどちらかを見ていれば進める
;//このエンディングではなくノーマルエンドへ


[if exp={getFlagValue("battle_win") == 3}]
[if exp={ isSystemFlagsEnabled( "end1", "end2", "end3", "end4") }]
[jump target="*Hiroin_Root_h"]
[endif]
[endif]

;//どれでもない場合　ノーマルエンド
[jump target="*Hiroin_Root_no"]

;//==============================
;//ヒロインを選ぶ選択肢を３回繰り返しつつ、どのエンディングにも該当しない場合
;//全てのエンディングに該当しないケースは
;//いずれのヒロインも三回目を選ばず、ハーレムルートの条件を満たしていない場合です
;//いずれかのヒロインを三回選んでいた場合、そのヒロインの現実ルート、中立ルート、理想ルートのいずれかに到達します
;//・例１
;//ヒロイン１に二回勝利
;//ヒロイン２に二回勝利
;//ヒロイン３に一回勝利
;//という場合、ヒロイン４に勝っていないのでハーレムに分岐しません
;//・例２
;//ヒロイン１に二回勝利
;//ヒロイン２に一回勝利
;//ヒロイン３に一回勝利
;//ヒロイン４に一回敗北
;//という場合、ヒロイン４に勝っていないのでハーレムに分岐しません
;//・例３
;//ヒロイン１に二回勝利
;//ヒロイン２に一回勝利
;//ヒロイン３に一回勝利
;//ヒロイン４に一回勝利
;//ただしいずれかのヒロインで中立か理想ルートを終えていない
;//この場合もハーレムに分岐しません



;#################################################
*Ep000|Graduation of Loneliness
;#################################################

*Hiroin_Root_no|ひとりぼっちの卒業


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



One day at school. I was dumped by my ...... sweetheart.
[cpg]


[OnName num="takuma"]
I said, "Well, wait ......!"
[cpg cn=true]


But she didn't look back. Because I had cheated on her.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





I go to the town alone. I was alone again.
[cpg]


What went wrong?
[cpg]


If I had done it right, I could have built a harem, but I ended up like this: ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************




I can't get back the trust I lost. There were bad rumors about me.
[cpg]


Only time was passing. And then......
[cpg]


And the lonely student was left all alone and graduating.
[cpg]


Where did I go wrong......
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//ＥＮＤ　ノーマルエンド


[jump storage="epend.ks" target="*back_title"]


;//==============================
