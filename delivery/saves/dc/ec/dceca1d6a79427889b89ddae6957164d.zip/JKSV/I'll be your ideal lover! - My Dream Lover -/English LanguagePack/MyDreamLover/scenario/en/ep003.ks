
*start


;////////////////////////////////////////////////////////////////////
;//以下、ヒロイン２のイベント
;////////////////////////////////////////////////////////////////////






;//////////////////////////////////
;//ヒロイン２一回目のイベント
;//『着せ替えバトル』
;//////////////////////////////////



;//==============================
;//ヒロイン２一回目のイベント　前置き
;//☆ヒロインのイベント前置き
*HiStory2_01|着せ替えバトル

;#################################################
*Ep003|着せ替えバトル
;#################################################

;//[SCENE id=3]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************





On the way to school in the morning. I met a senior student.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku037"]
[OnName num="miku"]
She asked, "...... what kind of private clothes does Takuma wear?"
[cpg cn=true]


[OnName num="takuma"]
I think it's normal, but I'm also curious about ...... Takuma's personal clothes.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku038"]
[OnName num="miku"]
The first thing you need to do is to find the right clothes.
[cpg cn=true]


Oops. That sounds date-like. I immediately jumped on the bandwagon.
[cpg]


[OnName num="takuma"]
Then, let's set a date, shall we? Let's see... ......."
[cpg cn=true]



;//==============================
;//ヒロイン２一回目のイベント　バトルパート
;//☆ヒロインのイベントバトルパート


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ショッピングモール店内』（夕方）******************************************************





Me and my senior were at a shopping mall.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku039"]
[OnName num="miku"]
I thought, "This ...... would look good on Takuma.
[cpg cn=true]


[OnName num="takuma"]
"Really? ......?"
[cpg cn=true]


The first thing you need to do is to get a good idea of what you're looking for.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku040"]
[OnName num="miku"]
I want Takuma to be more girly.
[cpg cn=true]


[OnName num="takuma"]
No, you can't do that with this face."
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku041"]
[OnName num="miku"]
I think she's cute enough to look good with her face.
[cpg cn=true]


I'm at a loss for a response and decide to make my senior a cool beauty.
[cpg]


[OnName num="takuma"]
“Senior, don’t these clothes look good on you?”
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku042"]
[OnName num="miku"]
"I can't. ...... why do you choose this kind of clothes?"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku043"]
[OnName num="miku"]
"I can't ...... look good in something like this, it looks like a model would wear it.
[cpg cn=true]


I knew it was not a simple matter.
[cpg]


[OnName num="takuma"]
The first thing you need to do is to find a good fit for your body. The best way to do this is to get a good idea of what you're looking for. I'll do everything in my power to convince you.
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Miku044"]
[OnName num="miku"]
"That's impossible,...... I'll never wear it."
[cpg cn=true]



;//++++++++++++++++++++++++++
;//バトル開始画面
;//++++++++++++++++++++++++++

[SE f="se006"]
;//【ＳＥ】『バトル開始』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_bs2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『ショッピングモール店内』（夕方）******************************************************

;//[CutBG g="sys_cut_bwin2"]



;//++++++++++++++++++++++++++
;//バトル画面を表示
;//++++++++++++++++++++++++++


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]


[OnName num="takuma"]
I'll never wear it." "Wait a minute.
[cpg cn=true]


I came up with something to confront my senpai.
[cpg]



;//アイテム選択　『美紅似のモデルの写真』を選んだ時は勝った場合へ進む
;//それ以外のものを選んだ場合負けた場合へ進む
*battle_item_select_00|Dressing battle.


[if exp={getFlagValue("getItemNum_01") == 7}]
[jump target="*battle_win_21"]
[endif]

[jump target="*battle_lose_21"]

;//[SelectItem n=7 w=*battle_win_21 l=*battle_lose_21]
どれを使おう…
[cpg]
;//[endswitch]


;//==============================
;//勝った場合　※正しいアイテムを選んだ場合
*battle_win_21|着せ替えバトル

[stflag HiWinFlg_02 = 1]


[OnName num="takuma"]
"There's a model who looks like you, senpai. Shall I show you?
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Miku045"]
[OnName num="miku"]
"What, ......?"
[cpg cn=true]


I show him the picture. He was a little surprised.
[cpg]


[OnName num="takuma"]
He said, "You see?　He has good qualities. Let's pick out some clothes.
[cpg cn=true]


[FG f="CHA02_p5_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku046"]
[OnName num="miku"]
"But, but, let's see... ......"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ（普段着ないクールでセクシーな服を着て恥ずかしそうなヒロイン）ev_33
;//人物１：ヒロイン２　服装１：セクシーな服
;//場所　：ショッピングモール店内
;//時間　：夕方
;//========================================



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]

So, I'm going to dress her in cool clothes.
[cpg]


Not just cool. It's a little sexy.
[cpg]



[VOICE f="Miku047"]
[OnName num="miku"]
Ha, I'm embarrassed ...... something, it feels weird."
[cpg cn=true]


He was embarrassed, but he was cute in that way, too.
[cpg]


[OnName num="takuma"]
No, it looks good on you. Really."
[cpg cn=true]



[VOICE f="Miku048"]
[OnName num="miku"]
She said, "Oh, my God, all you do is lie. ......
[cpg cn=true]


[OnName num="takuma"]
I'm not lying. That's right, photo pictures ......."
[cpg cn=true]



[VOICE f="Miku049"]
[OnName num="miku"]
No!　Don't take my picture, it doesn't suit me.
[cpg cn=true]



[VOICE f="Miku050"]
[OnName num="miku"]
I told you not to take a picture of me. ......
[cpg cn=true]


There was such a push and shove, but in the end I was able to dress her as I wanted.
[cpg]



;//++++++++++++++++++++++++++
;//勝利画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba2w.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se007"]
;//【ＳＥ】『バトル勝利』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト
;//☆次は負けた場合のイベント

[jump target="*before_select_chara"]
;//==============================
;//負けた場合　※正しいアイテムを選ばなかった場合
*battle_lose_21|着せ替えバトル





I was the one who forced my senior to do what I wanted, and I was missing the last step.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku051"]
[OnName num="miku"]
I was missing the last step of forcing my taste on my senpai. I'm sure it will look good on you.
[cpg cn=true]


[OnName num="takuma"]
"Like this ......?"
[cpg cn=true]


I put the hair clip on my bangs.
[cpg]


[FG f="CHA02_p5_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku052"]
[OnName num="miku"]
"It's cute. You look like a girl.
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku053"]
[OnName num="miku"]
I want her to be prettier,......, although Takuma is cute to begin with.
[cpg cn=true]


I was getting embarrassed and knew I was becoming tainted with my senpai's taste. ......
[cpg]



;//++++++++++++++++++++++++++
;//敗北画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba2l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=2000]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト


[jump target="*before_select_chara"]
;//ヒロイン２一回目のイベント　ここまで
;//☆ここから次のイベント



;//////////////////////////////////
;//ヒロイン２二回目のイベント
;//『公園デートバトル』
;//////////////////////////////////



;//==============================
;//ヒロイン２二回目のイベント　前置き
;//☆ヒロインのイベント前置き
*HiStory2_02|Park Date Battle

;#################################################
*Ep007|公園デートバトル
;#################################################

;//[SCENE id=7]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





Lunch break. I go to my senior's class for a visit.
[cpg]


My senior is alone today. Hmmm ......
[cpg]


I wish I had a more open personality.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku054"]
[OnName num="miku"]
"Oh, ...... Takuma.
[cpg cn=true]


[OnName num="takuma"]
Hi. Senpai."
[cpg cn=true]


If you get used to people looking at you, will you become more open?
[cpg]

If so, I'll need something to make senpai feel that way.
[cpg]



;//==============================
;//ヒロイン２二回目のイベント　バトルパート
;//☆ヒロインのイベントバトルパート


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『公園』（昼）******************************************************


Today, I invited my senior to a date at the park.
[cpg]

I asked her out under the guise of getting used to being seen by people. ......
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku055"]
[OnName num="miku"]
"Date? ...... even though you're not my girlfriend yet."
[cpg cn=true]


[OnName num="takuma"]
Well, well, that's fine."
[cpg cn=true]


 I try to push through, but she doesn't like being alone in front of other people.
[cpg]

If I don't do this, they'll run away from me before I can become an ideal senior.
[cpg]


;//++++++++++++++++++++++++++
;//バトル開始画面
;//++++++++++++++++++++++++++


[SE f="se006"]
;//【ＳＥ】『バトル開始』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_bs2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『公園』（夕方）******************************************************

;//[CutBG g="sys_cut_bwin2"]



;//++++++++++++++++++++++++++
;//バトル画面を表示
;//++++++++++++++++++++++++++


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]


I will need something to make her stay here.
[cpg]


Now, what shall I give her ......?
[cpg]



;//アイテム選択　『手作り弁当』を選んだ時は勝った場合へ進む
;//それ以外のものを選んだ場合負けた場合へ進む
*battle_item_select_00|公園デートバトル


[if exp={getFlagValue("getItemNum_02") == 8}]
[jump target="*battle_win_22"]
[endif]

[if exp={getFlagValue("getItemNum_01") == 8}]
[jump target="*battle_win_22"]
[endif]

[jump target="*battle_lose_22"]

;//[SelectItem n=4 w=*battle_win_22 l=*battle_lose_22]
Which one shall I use...
[cpg]
;//[endswitch]



;//==============================
;//勝った場合　※正しいアイテムを選んだ場合
*battle_win_22|公園デートバトル

[stflag HiWinFlg_02 = 1]


[OnName num="takuma"]
"By the way, senpai, aren't you hungry?"
[cpg cn=true]


I showed her my lunch box.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku056"]
[OnName num="miku"]
She said, "Why ...... are those things made by boys?"
[cpg cn=true]


I was told that this was the best way to go about it.
[cpg]

The best thing to do is to make a lunch box for her.
[cpg]

If I had made her lunch, she would stay with me until she ate it all.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

The plan worked, and she stayed with me at least until she finished her lunch.
[cpg]


;//========================================
;//●ＣＧ（公園、主人公の隣にいるヒロイン）ev_25
;//人物１：ヒロイン２　服装１：制服
;//人物ex：主人公　　　服装ex：制服
;//場所　：公園
;//時間　：夕方
;//========================================

[BGM f="bg_h1"]

;**【ＣＧ】 ev_25_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Miku057"]
[OnName num="miku"]
She said, "Thank you for ....... I feel like a child having a picnic.
[cpg cn=true]


;**【ＣＧ】 ev_25_a ***********************
[CG id=7 index=1 time=1]
;***************************************
[WAIT time=1]


[OnName num="takuma"]
Maybe so.
[cpg cn=true]


[VOICE f="Miku058"]
[OnName num="miku"]
'But it was delicious. It's ...... a little too much for a boy's food."
[cpg cn=true]


She is usually an honest person, but I think she might have meant it as flattery to say it that way.
[cpg]

But I was satisfied enough. Without a doubt, I feel that my senpai is also accustomed to the way people look at her.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

;//++++++++++++++++++++++++++
;//勝利画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba2w.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se007"]
;//【ＳＥ】『バトル勝利』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト
;//☆次は負けた場合のイベント

[jump target="*before_select_chara"]
;//==============================
;//負けた場合　※正しいアイテムを選ばなかった場合
*battle_lose_22|Park Date Battle

While I was puzzled, he started to pay attention to his surroundings.
[cpg]

[VOICE f="Miku059"]
[OnName num="miku"]
I knew it was impossible.
[cpg cn=true]


And then she ran away without me.
[cpg]


;//移植のためシーンをカットしています

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



My plan did not work. Next time, I'll be better prepared. ......
[cpg]



;//++++++++++++++++++++++++++
;//敗北画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba2l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se008"]
;//【ＳＥ】『バトル敗北』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト


[jump target="*before_select_chara"]
;//ヒロイン２二回目のイベント　ここまで
;//☆ここから次のイベント




;//////////////////////////////////
;//ヒロイン２三回目のイベント
;//『撮影バトル』
;//////////////////////////////////



;//==============================
;//ヒロイン２三回目のイベント　前置き
;//☆ヒロインのイベント前置き
*HiStory2_03|Shooting Battle

;#################################################
*Ep011|撮影バトル
;#################################################

;//[SCENE id=11]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku060"]
[OnName num="miku"]
"I'm going to ......?　To Takuma's room?"
[cpg cn=true]


[OnName num="takuma"]
Yes, I'll be there. How do you like it?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku061"]
[OnName num="miku"]
"I don't mind, but what are you going to do?"
[cpg cn=true]


[OnName num="takuma"]
I don't do anything. Maybe.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku062"]
[OnName num="miku"]
Maybe means ......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miku063"]
[OnName num="miku"]
"I'm not saying I don't want to ...... get into it, but ......
[cpg cn=true]


I was secretly planning to do something.
[cpg]



;//==============================
;//ヒロイン２三回目のイベント　バトルパート
;//☆ヒロインのイベントバトルパート


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[OnName num="takuma"]
Have you ever taken a picture, senior?"
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku064"]
[OnName num="miku"]
It's rare to find someone who hasn't. ......
[cpg cn=true]


[OnName num="takuma"]
I'm into photography these days. I've been into photography lately.
[cpg cn=true]


I lied about being into photography, I really just wanted her to be able to withstand the human gaze.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Miku065"]
[OnName num="miku"]
...... if you let me take a picture of you, too."
[cpg cn=true]


She offered an exchange. I would accept that much.
[cpg]

I nodded in agreement, and she seemed to be willing to accept.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku066"]
[OnName num="miku"]
I don't think I can lose ...... because Takuma is so cute.
[cpg cn=true]


[FG f="CHA02_p5_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku067"]
[OnName num="miku"]
Takuma, you may not be aware of your own cuteness,......, I'll tell you.
[cpg cn=true]


[OnName num="takuma"]
"Yes, let's play. Let's play.
[cpg cn=true]



;//++++++++++++++++++++++++++
;//バトル開始画面
;//++++++++++++++++++++++++++


[SE f="se006"]
;//【ＳＥ】『バトル開始』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_bs2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[WAIT time=500]
[transition target={true} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

;//[CutBG g="sys_cut_bwin2"]



;//++++++++++++++++++++++++++
;//バトル画面を表示
;//++++++++++++++++++++++++++


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]


I'm not aware of my cuteness, that's what I'm saying.
[cpg]


;//アイテム選択　『一眼レフ』を選んだ時は勝った場合へ進む
;//それ以外のものを選んだ場合負けた場合へ進む
*battle_item_select_00|撮影バトル


[if exp={getFlagValue("getItemNum_03") == 11}]
[jump target="*battle_win_23"]
[endif]

[if exp={getFlagValue("getItemNum_02") == 11}]
[jump target="*battle_win_23"]
[endif]

[if exp={getFlagValue("getItemNum_01") == 11}]
[jump target="*battle_win_23"]
[endif]

[jump target="*battle_lose_23"]

;//[SelectItem n=11 w=*battle_win_23 l=*battle_lose_23]
どれを使おう…
[cpg]
;//[endswitch]



;//==============================
;//勝った場合　※正しいアイテムを選んだ場合
*battle_win_23|撮影バトル

[stflag HiWinFlg_02 = 1]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku068"]
[OnName num="miku"]
What is that?
[cpg cn=true]


[OnName num="takuma"]
It's a single-lens reflex camera. It takes beautiful pictures, so please pose properly.
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku069"]
[OnName num="miku"]
Even if you say so, what should I do with ......?
[cpg cn=true]


The senior seems to be pointing the SLR camera at you, intensifying the feeling that you are being photographed.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku070"]
[OnName num="miku"]
'Ugh ......, I'm so embarrassed.'
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku071"]
[OnName num="miku"]
Why do you have a camera like that ......?"
[cpg cn=true]


And then the offense and defense changed. But the older man was already so excited that he couldn't even take a picture of me.
[cpg]

[OnName num="takuma"]
I guess the game was won. Look, you can get a cute shot of my senior looking embarrassed.
[cpg cn=true]


She was blushing red, but she couldn't deny it anymore.
[cpg]

[OnName num="takuma"]
I said, "Next time, I'd like to shoot somewhere on the beach.
[cpg cn=true]


I said, and she did not refuse. So I forced her to make an appointment.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

So, another day. With the camera in the example, we get on the train ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]


It was a holiday and the train was crowded.
[cpg]

;//========================================
;//●ＣＧ（電車で移動。人が多すぎて主人公と密着する）ev_28
;//人物１：ヒロイン２　服装１：制服
;//人物ex：主人公　　　服装ex：制服
;//場所　：電車内
;//時間　：夕方
;//========================================

[BGM f="bg_h1"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Miku072"]
[OnName num="miku"]
We went to ......
[cpg cn=true]


I was impressed by her looking cramped in the crowded train.
[cpg]

I thought that this might be the moment I should take a picture of her, but as expected, I couldn't turn the camera on her. ......
[cpg]

[VOICE f="Miku073"]
[OnName num="miku"]
Takuma...... away, right?
[cpg cn=true]


I thought about holding her hand in the confusion, but decided against it.
[cpg]


;//ブラックアウト

Then we continued shooting after we got to the beach.
[cpg]

I wanted to bring out more of her unselfconscious cuteness. ......
[cpg]


;//移植のためシーンをカットしています




;//++++++++++++++++++++++++++
;//勝利画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba2w.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se007"]
;//【ＳＥ】『バトル勝利』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト
;//☆次は負けた場合のイベント

[jump target="*before_select_chara"]
;//==============================
;//負けた場合　※正しいアイテムを選ばなかった場合
*battle_lose_23|撮影バトル





But even after thinking about it, I couldn't come up with anything ...... that I could use right now.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku074"]
[OnName num="miku"]
I said, "I've prepared. Here, put this on."
[cpg cn=true]


[OnName num="takuma"]
"What is this......?"
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku075"]
[OnName num="miku"]
"Girl's clothes. I thought it would look good on Takuma.
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku076"]
[OnName num="miku"]
"I bought you a bigger size. ...... Here, put it on quickly."
[cpg cn=true]


The first thing you need to do is to make sure that you have a good idea of what you're doing.
[cpg]


[FG f="CHA02_p5_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku077"]
[OnName num="miku"]
"Oh,......, Takuma is dressed as a woman.
[cpg cn=true]


I felt strange and got an erection.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku078"]
[OnName num="miku"]
I was so cute.
[cpg cn=true]


[FG f="CHA02_p5_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku079"]
[OnName num="miku"]
Then I'll take a picture of you. ...... hah, hah."
[cpg cn=true]


In the end, my senpai took better pictures of me than I did.
[cpg]


Even though I was the one taking the pictures, I couldn't really get into the mood. ......
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

They took pictures of me in a pathetic way, but I had become so good at it that I was okay with it.
[cpg]


I had thought it was okay that I lost this match. ......
[cpg]


;//++++++++++++++++++++++++++
;//敗北画面表示
;//++++++++++++++++++++++++++
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="sys_ba2l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=500]
[WAIT time=500]
[SE f="se008"]
;//【ＳＥ】『バトル敗北』
[WAIT time=500]
[WAIT time=500]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[WAIT time=100]
;//ブラックアウト


;//[jump target="*before_select_chara"]
;//ヒロイン２三回目のイベント　ここまで




*before_select_chara|
[if exp={getFlagValue("Count_Selected") == 3}]
[jump storage="epResalt.ks" target="*Go_to_Resalt"]
[endif]
[jump storage="ep001.ks" target="*before_select_chara"]


;////////////////////////////////////////////////////////////////////
;//以下、ヒロイン２分岐後のシナリオ
;////////////////////////////////////////////////////////////////////






;//==============================
;//三回のバトルを終えて勝利数が１以下であり、このヒロインを３回以上選んでいる場合
*Hiroin_Root_2_1|先輩の趣味の加速


;//////////////////////////////////
;//ヒロイン２現実ルート開始
;//////////////////////////////////


;#################################################
*Ep018|Acceleration of senior hobbies
;#################################################

;//[SCENE id=18]
[SCENE id=6]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************





...... Then the days passed.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku080"]
[OnName num="miku"]
"Takuma...... good morning."
[cpg cn=true]


[OnName num="takuma"]
Good morning. Senior."
[cpg cn=true]


The relationship between me and my senpai had not progressed much.
[cpg]


If I say it had progressed, it was that my senpai's hobbies were accelerating. ......
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku081"]
[OnName num="miku"]
"I want to go home ...... with you today. Would you like to come to my house, too, Takuma?"
[cpg cn=true]


[OnName num="takuma"]
"Sure, but I don't want to wear women's clothes anymore.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku082"]
[OnName num="miku"]
"Why ......?　I want you to.
[cpg cn=true]


[OnName num="takuma"]
I don't want you to do that. I don't want you to do that. I don't want you to do that.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku083"]
[OnName num="miku"]
I bought clothes for you.
[cpg cn=true]


Senpai looks disappointed. I am weak when I am faced with a face like that.
[cpg]


[OnName num="takuma"]
I'm sure you'll be able to find a way to get a good deal on it. It's only for a little while.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku084"]
[OnName num="miku"]
Really?　I'm very happy.
[cpg cn=true]


The first thing you need to do is to make sure that you have a good time with your friends and family.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





Nevertheless, ...... seniors still show no signs of becoming popular at all.
[cpg]


I was going to train him to be everyone's favorite senpai,.......
[cpg]


I was supposed to be the guy who looked good in women's clothing.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="takuma"]
"...... senpai, don't you want a friend or something?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku085"]
[OnName num="miku"]
"What ......?　I don't want any friends at all. As long as I have Takuma, I don't need anything else.
[cpg cn=true]


He says that he is happy to hear that, but this is a dangerous situation.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku086"]
[OnName num="miku"]
I am happy to have a cute boyfriend like Takuma. I don't need any other friends.
[cpg cn=true]


[OnName num="takuma"]
「……そうですか」
[cpg cn=true]


I'm no longer the senior image I wanted to have. But there's nothing you can do about it now. ......
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





The first thing you need to do is to make sure that you have a good time.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku087"]
[OnName num="miku"]
I want you to wear underwear today."
[cpg cn=true]


I'm not going to be able to do that. I can't do it.
[cpg]


[OnName num="takuma"]
"You're a pervert, aren't you? ...... Let's not do that.
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku088"]
[OnName num="miku"]
"So ......?　I'm going to ask you to put on some clothes.
[cpg cn=true]


The first thing you need to do is to make sure that you have a good time with your family and friends.
[cpg]


[free time=1000]


[SE f="se000"]
;//【ＳＥ】『服着替える』





I was ...... no longer feeling bad about the situation.
[cpg]


But I also wonder if this was the right thing to do.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku089"]
[OnName num="miku"]
"Or, a cute ...... angel ......."
[cpg cn=true]


She even calls me an angel. I'm glad she's in love with me, but it's not what I wanted.
[cpg]


But it wasn't the development I wanted.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//移植のためシーンをカットしています


As I caught my breath, I knew I was in big trouble.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





I went on with my days, waking up to something I shouldn't have woken up to.
[cpg]


My senpai seemed satisfied. I guess I have no choice but to be satisfied with the way things are.
[cpg]


[FG f="CHA02_p5_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku090"]
[OnName num="miku"]
She's really cute. I want to eat her.
[cpg cn=true]


[OnName num="takuma"]
...... please don't say too much.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku091"]
[OnName num="miku"]
I still want to, but ...... it's about time, my parents are coming home.
[cpg cn=true]


So we decided to split up.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I'm alone in my room thinking.
[cpg]


I think it started out as something trivial. It started with him wanting to pick out my clothes, right?
[cpg]


I had no idea that my senpai was such a pervert. I don't know if there was a way to nurture him more, but I don't know if it was a good thing that he was a pervert.
[cpg]


Without knowing, I drifted off to sleep: ......
[cpg]


While I was sleeping, even in my dreams, my senpai made me dress up as a woman.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I wake up in the morning and head to the school.
[cpg]


I would meet my senpai again. What will they dress me in this time? ......
[cpg]


I found myself looking forward to what they would do to me.
[cpg]


It was quite dangerous. I had been nurtured by the seniors.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku092"]
[OnName num="miku"]
Good morning. Do you want to stop by on your way home today?　Or do you have tomorrow off, so we'll have plenty of time to play ...... tomorrow?"
[cpg cn=true]


I thought about it for a minute. Either way, it won't make much difference.
[cpg]


[OnName num="takuma"]
Then, let's do it tomorrow, shall we?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku093"]
[OnName num="miku"]
I'll get ready for today. Then, I'll do a lot of preparation today.
[cpg cn=true]


Preparations. I guess it's the preparation for putting clothes on me. Thinking so, ......
[cpg]


I'm heading to the school. I'm going to be the first one to get a new job.
[cpg]


It's not like they're a famous couple in the school .......
[cpg]


The first thing that comes to mind is the fact that the two of them are not really friends.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


The day went by without a hitch, and the next day, I went directly to my senior's house.
[cpg]


The next day, I went directly to my senior's house. I already knew the address and the street was familiar to me.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku094"]
[OnName num="miku"]
Then I went to ...... and asked her if there was anything she wanted me to wear.
[cpg cn=true]


[OnName num="takuma"]
...... yes."
[cpg cn=true]


I was no longer disobedient.
[cpg]


I'm also waking up to this bizarre play.
[cpg]


I can say that this is the result of being nurtured by my seniors. I had lost the ability to resist.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku095"]
[OnName num="miku"]
"How about this ......?
[cpg cn=true]


[OnName num="takuma"]
"It's a rather normal outfit.
[cpg cn=true]


However, I was dressed as a woman. I might be losing my senses.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku096"]
[OnName num="miku"]
If I put on this dress and make up, I don't think I will be recognized when I go outside.
[cpg cn=true]


[OnName num="takuma"]
No, no, no, they will!　What are you thinking?
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku097"]
[OnName num="miku"]
"I don't think they'll recognize me. Takuma, you have become a board.
[cpg cn=true]


[OnName num="takuma"]
"Oh, really?
[cpg cn=true]


I don't feel bad anymore. I'm already in trouble.
[cpg]


Something is going haywire. But we couldn't stop ourselves anymore.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『公園』（夕方）******************************************************





And I came to the park dressed as a woman.
[cpg]


The stares around me seemed to pierce me. But I didn't get the feeling that anyone had noticed.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku098"]
[OnName num="miku"]
I thought to myself, "Right?　As long as we don't speak up, they won't notice."
[cpg cn=true]


[OnName num="takuma"]
「……」
[cpg cn=true]


The older man was right, I couldn't make a sound.
[cpg]


If you do, you'll be discovered in one shot. It's a man's voice.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





It was a terrible thing to do. This is really too perverted.
[cpg]


Senpai is so lustful, isn't he? Or is it because I'm dressed as a woman ......?
[cpg]


Either way, I walked back to my senior's house with my face almost on fire.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





[OnName num="takuma"]
Let's not do this kind of thing anymore."
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku099"]
[OnName num="miku"]
Why?"　I felt it, too.
[cpg cn=true]


[OnName num="takuma"]
"......, please don't say that, either."
[cpg cn=true]


In a way, it was a typical exchange between senior and junior.
[cpg]


I'm left in the lead. But I don't think this is a good idea at all.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku100"]
[OnName num="miku"]
I think you should wear something prettier this time when you go out.
[cpg cn=true]


[OnName num="takuma"]
Let's not do that. I'll regret it for the rest of my life if ...... I get tied up too much."
[cpg cn=true]


The senior kept a cool face. This is the feeling that you're not going to change anything. ......
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************





Then, the next weekday. I was going to my senior class.
[cpg]


In the hallway on the way there, I heard this rumor.
[cpg]


[OnName num="male_student_A"]
Hey, do you know her?　The girl I heard you and Mr. Sobo are friends."
[cpg cn=true]


[OnName num="male_student_B"]
"Who?　I haven't seen her.
[cpg cn=true]


[OnName num="male_student_A"]
"No, I haven't seen her either, but I've heard about her through ...... people.
[cpg cn=true]


[OnName num="male_student_A"]
"That Soho was in the park, holding hands with a cute girl."
[cpg cn=true]


[OnName num="takuma"]
What?
[cpg cn=true]


 I almost let out my voice.
[cpg]


I was being watched. No, of course they saw you.
[cpg]


[OnName num="male_student_A"]
People are always asking, "Who was it?"
[cpg cn=true]


[OnName num="male_student_B"]
If you don't know who it was, it wasn't our school, was it?
[cpg cn=true]


[OnName num="male_student_A"]
Maybe so, but I'd like to see him.
[cpg cn=true]


[OnName num="takuma"]
I'd like to see him. ......
[cpg cn=true]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="takuma"]
I heard a rumor.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku101"]
[OnName num="miku"]
Good. I knew it. Everyone thinks she's cute.
[cpg cn=true]


[OnName num="takuma"]
I'm not kidding. I'll never go out in that outfit again.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku102"]
[OnName num="miku"]
"Don't be so boring, ......, just one more time."
[cpg cn=true]


I accept anything my senpai tells me to do.
[cpg]


I'm not afraid of being disliked by my seniors, but cross-dressing has become addictive for me.
[cpg]


I mean, I feel like I made some mistakes earlier .......
[cpg]


It wasn't the seniors that made me popular, it was me.
[cpg]


Where did I go wrong? I wanted to make my senpai popular.
[cpg]


Even if I regret it now, it's too late. ......
[cpg]




;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

;//ＥＮＤ　ヒロイン２現実ルート


;//[SCENE id=31]
[SCENE id=19]

[jump storage="epend.ks" target="*start"]







;//==============================
;//三回のバトルを終えて勝利数が２以上である場合
*Hiroin_Root_2_2|理想のクールビューティ


;#################################################
*Ep019|The Ideal Cool Beauty
;#################################################

;//[SCENE id=19]
[SCENE id=7]

;//////////////////////////////////
;//ヒロイン２理想ルート、および中立ルート開始
;//////////////////////////////////






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





Since then. Senpai became my ideal cool beauty.
[cpg]


And it's not just that she became better looking.
[cpg]


I saw her change everywhere.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku103"]
[OnName num="miku"]
She said, "I've taken up kendo at ......."
[cpg cn=true]


[OnName num="takuma"]
She said, "Heh. What do you think?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku104"]
[OnName num="miku"]
She said I had good muscles. It's weird.
[cpg cn=true]


[OnName num="takuma"]
"That's good. You'll be more popular than ever.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku105"]
[OnName num="miku"]
I'm not that popular.
[cpg cn=true]


[OnName num="takuma"]
I've heard you've been getting love letters from girls as well as boys.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Miku106"]
[OnName num="miku"]
How do you know?
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku107"]
[OnName num="miku"]
Do you remember the first time ...... I was going to get in a match with Takuma?
[cpg cn=true]


[OnName num="takuma"]
I remember. Why did you do that?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku108"]
[OnName num="miku"]
"Mr. Sakura asked me to do it. She bowed down and asked me, so I couldn't refuse. ......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku109"]
[OnName num="miku"]
She seemed to like Takuma a lot.
[cpg cn=true]


[OnName num="takuma"]
I see.
[cpg cn=true]


That's what happened. But that makes sense.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku110"]
[OnName num="miku"]
Speaking of which, what happened to Takuma's illness?"
[cpg cn=true]


[OnName num="takuma"]
He is cured. I can do it by myself normally now.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku111"]
[OnName num="miku"]
I see. I'm glad to hear that.
[cpg cn=true]


After all, I now believe that the illness was given to me by God in order for me to take action.
[cpg]


If I hadn't had the disease, this would not have happened.
[cpg]


I turned my senior into my ideal senior. But that's not the end of the story.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku112"]
[OnName num="miku"]
...... Hey, Takuma.
[cpg cn=true]


[OnName num="takuma"]
What is it?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku113"]
[OnName num="miku"]
"Do you want to go out with ...... us?"
[cpg cn=true]


[OnName num="takuma"]
「……」
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku114"]
[OnName num="miku"]
I'm sorry. I want you to go out with me. I'm not used to confessing my feelings.
[cpg cn=true]


[OnName num="takuma"]
"No, I'm glad. I've been thinking about it for a long time.
[cpg cn=true]


[OnName num="takuma"]
If you're okay with me, let's go out. Senpai.
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku115"]
[OnName num="miku"]
"Yes, it's ....... I'm glad. ......
[cpg cn=true]


Senpai was about to cry. I took her hand and laughed.
[cpg]


Then, senior also laughed at me. ......
[cpg]



;//ブラックアウト

;//[Live2d target=8]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


After that, we talked about nothing else.
[cpg]

But the distance between us was different than before.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Miku116"]
[OnName num="miku"]
Then, I'll see you at ...... school.
[cpg cn=true]


[OnName num="takuma"]
Yes, sir. Um, senpai."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Miku117"]
[OnName num="miku"]
What ......?　What's wrong?
[cpg cn=true]


[OnName num="takuma"]
You can probably speak normally now, can't you?
[cpg cn=true]


[OnName num="takuma"]
I think I'm not as shy as I used to be. What do you think?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku118"]
[OnName num="miku"]
"...... even if you say I can speak normally, how do you feel about it ......?
[cpg cn=true]


Oh, I think he's changing. I think I'm changing a little bit.
[cpg]


[OnName num="takuma"]
She is like that. If you act like a big sister, you'll be more popular."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku119"]
[OnName num="miku"]
I don't know. ...... I don't have that kind of personality.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku120"]
[OnName num="miku"]
"But if Takuma says so, I will. ...... No, I will."
[cpg cn=true]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





Love letters have been received from both men and women to seniors.
[cpg]


The first thing that comes to mind is the fact that the senior is popular even amongst the same sex.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku121"]
[OnName num="miku"]
I'll be at the theater festival soon," she said. I've been told I should run for the lead role.
[cpg cn=true]


Drama festival. It's a big event at our school.
[cpg]


It's not just for the drama club, but it's a pretty big event, almost like a cultural festival.
[cpg]


[OnName num="takuma"]
It's a very popular event. But I'd like to see some of the seniors doing acting too."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku122"]
[OnName num="miku"]
It's a load off my shoulders. ...... haha.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku123"]
[OnName num="miku"]
I was always a loner to begin with. ...... I don't know how it happened.
[cpg cn=true]


[OnName num="takuma"]
I had the qualities to become popular. I was born to be popular.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku124"]
[OnName num="miku"]
I don't think so. ......
[cpg cn=true]


Even now, I can see the fan juniors looking at me outside the classroom.
[cpg]


I felt like he was looking at me with resentment.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku125"]
[OnName num="miku"]
But I don't feel bad about drawing their attention.
[cpg cn=true]

she said, somewhat regally.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************


For the umpteenth time, we were in my senior's room.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku126"]
[OnName num="miku"]
She said, "Hey, Takuma...... likes me, doesn't he?
[cpg cn=true]


[OnName num="takuma"]
I'm sure you like me, don't you? Yes, I do.
[cpg cn=true]


She was checking my feelings, but for some reason she lay down on her own bed.
[cpg]


;//========================================
;//●ＣＧ（ベッドに寝ているヒロインに、迫る主人公）ev_38
;//人物１：ヒロイン２　服装１：私服
;//人物ex：主人公　　　服装ex：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_38_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="takuma"]
'...... tired?'
[cpg cn=true]


[VOICE f="Miku127"]
[OnName num="miku"]
You know what I mean. Or maybe Takuma doesn't have the desire to flirt with someone he likes.
[cpg cn=true]


That's what this means. She'd been waiting for it for a long time, too.
[cpg]

She wasn't just a shy senior in that moment.
[cpg]

Really, she's a sweetheart. ......
[cpg]


;//移植のためシーンをカットしています


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Some time later. The actors for the theater festival were being recruited.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku128"]
[OnName num="miku"]
She said, "Did you hear about ......　About the theater festival?"
[cpg cn=true]


[OnName num="takuma"]
'Mostly. You're talking about boys dressing up as girls and girls dressing up as boys, right?
[cpg cn=true]


They were looking for actors who could switch genders.
[cpg]


[OnName num="takuma"]
I think the current seniors can play the leading roles.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku129"]
[OnName num="miku"]
I've been told by people around me that I have to go on .......
[cpg cn=true]


[OnName num="takuma"]
If you don't, your fans will be disappointed.
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku130"]
[OnName num="miku"]
"I'm weak when people say that. ...... what should I do?"
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku131"]
[OnName num="miku"]
"......Yes, that's right. Well then, if Takuma is auditioning too, I'm in."
[cpg cn=true]


[OnName num="takuma"]
What?
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku132"]
[OnName num="miku"]
Then Takuma will have to dress up as a woman too.
[cpg cn=true]


I'm sure you have your own taste again. I'm going to be in a cross-dressing outfit.
[cpg]



;//■選択肢
[switch]
[case "I refuse."]
	[swap]
	[jump target="*Hiroin_Root_2_21"]
[case "I accept."]
	[swap]
	[jump target="*Hiroin_Root_2_22"]
[endswitch]

;//■選択肢
;//１、断る
;//２、受け入れる



;//==============================
;//１、断る

;#################################################
*Ep020|Leading role
;#################################################

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************

*Hiroin_Root_2_21|主役の座


;//[SCENE id=20]
[SCENE id=8]

;//////////////////////////////////
;//ヒロイン２理想ルートに分岐
;//////////////////////////////////



[OnName num="takuma"]
I don't mind. I want to be in the audience and watch you perform.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miku133"]
[OnName num="miku"]
"It's no use cajoling me,...... I won't do it."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





But he went to the audition and won the lead role.
[cpg]


And he won the lead role with flying colors.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





On a holiday, I was strolling the streets with my senpai. I was strolling the streets with my senpai.
[cpg]


[OnName num="takuma"]
How are you doing?　How are your rehearsals for the festival?
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku134"]
[OnName num="miku"]
"No good. ...... I'm basically shy, after all.
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku135"]
[OnName num="miku"]
I wonder how I can change my temperament.
[cpg cn=true]


She looked distressed, but she wouldn't have participated in the festival if she hadn't been so far.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************





The more I do things for her, the more gutsy she gets.
[cpg]


I think it's going to work out well when I act. ...... That's a good thing.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************




[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku136"]
[OnName num="miku"]
He said, "I think you're doing much better. I think your voice is getting better.
[cpg cn=true]


[OnName num="takuma"]
Let's go train again today, shall we? I'll go with you.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku137"]
[OnName num="miku"]
I'll go with you. I'll go with you. - Okay, will you read to me?
[cpg cn=true]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************



As I watched her practice for the drama festival, her performance got better and better.
[cpg]


I was making her more and more like the perfect senior.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku138"]
[OnName num="miku"]
"I hope you've got most of the lines in your head," she said.
[cpg cn=true]


[OnName num="takuma"]
I was getting her closer and closer to the perfect senior. I was sure she had the lines down to a tee.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku139"]
[OnName num="miku"]
Not even close. The people in the drama club are much better than that.
[cpg cn=true]


Indeed. There is such a thing as a drama club.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（昼）******************************************************



;//上下に黒帯を入れてください

;//[lbox on]



Then came the day of the festival.
[cpg]


The day when the seniors might become even more popular. I watched with bated breath.
[cpg]


The facilitators, props and props crew all gathered together to prepare for the performance.
[cpg]


No major mistakes were made during rehearsals, and the seniors seemed to be in good shape.
[cpg]


But whether that gives the seniors confidence is another matter.
[cpg]


The uneasy feeling is hard to shake off. The real performance is really getting closer.
[cpg]


It seems that people are coming from outside the school quite a bit. This year's cast was so eccentric that it seemed to be easy to attract people.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku140"]
[OnName num="miku"]
I'm so nervous,......, my heart is racing. I don't know what to do.
[cpg cn=true]


I was asked like that, and I quickly responded.
[cpg]


[OnName num="takuma"]
I quickly responded, "Well, write the character for 'person' on your hand. ......
[cpg cn=true]


I said something simple.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku141"]
[OnName num="miku"]
I said, "It's not that kind of superstitious thing. ......."
[cpg cn=true]


My senior asked for something that wasn't superstitious. If there were such a thing, I wouldn't have any trouble.
[cpg]


While talking like this, the show was getting closer and closer.
[cpg]


;//[lbox off]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





The show was about to start. Senpai was not on stage from the beginning, so he waited for a while.
[cpg]


He seemed to be really nervous during the first part of his lines, and I thought he was in trouble. But.
[cpg]



;//========================================
;//●ＣＧ非エロ（演劇祭。男装していて凜々しく演技するヒロイン）ev_44
;//人物１：ヒロイン２　服装１：男装
;//場所　：舞台
;//時間　：昼
;//========================================



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_pi"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Miku142"]
[OnName num="miku"]
"Sonnya...... such and such a betrayal......!"
[cpg cn=true]


As the play progressed, the senior was getting less and less nervous.
[cpg]



[VOICE f="Miku143"]
[OnName num="miku"]
You're trying to trick me!　You are the only one for me!"
[cpg cn=true]


He played the male role beautifully. I think the senior was showing more strength than he should have.
[cpg]


How could she think of herself as a coach?
[cpg]


In any case, she was giving a truly convincing performance.
[cpg]


However, watching a senior acting like this, ......
[cpg]


Really, she looks great in men's clothes. This is what a cool beauty should look like.
[cpg]


I'm happy to have such a lover. ......
[cpg]


I felt that it was somehow a waste of time for this time to pass.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se000"]
;//【ＳＥ】『拍手』





The applause didn't stop after the curtain came down.
[cpg]


I wish I could have been of some help to my senpai, but my aim is to snore.
[cpg]


I just want them to see more good looking seniors.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





Senior year started to have fans, especially girls.
[cpg]


[OnName num="female_student_A"]
Why is that guy the boyfriend of Suo-senpai ......?"
[cpg cn=true]


[OnName num="female_student_B"]
"Shush!　What if they hear you?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku144"]
[OnName num="miku"]
Don't worry about it, Takuma.
[cpg cn=true]


[OnName num="takuma"]
Of course. I want to make you more popular.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku145"]
[OnName num="miku"]
......, you should be a little concerned after all.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





[OnName num="takuma"]
By the way, you look good in men's clothes.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku146"]
[OnName num="miku"]
Everyone tells me that. I don't know if it's that much.
[cpg cn=true]


[OnName num="takuma"]
I don't know if it's that much. I would love to date a senior dressed as a man.
[cpg cn=true]



;//移植のためシーンをカットしています


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku147"]
[OnName num="miku"]
"......You really are a pervert, aren't you, ......Takuma?"
[cpg cn=true]

I've even been called a pervert, but I don't deny it.
[cpg]

;//移植のためシーンをカットしています


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



The happy days for me and my senpai continued. One day, my senior said something like this.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku148"]
[OnName num="miku"]
"......I never thought I could change so much."
[cpg cn=true]


[OnName num="takuma"]
Is that so?　I've said it many times, but my predisposition is ......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku149"]
[OnName num="miku"]
I don't think I could have done this on my own.
[cpg cn=true]


[OnName num="takuma"]
I just turned him into the ideal senior.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku150"]
[OnName num="miku"]
I'm still grateful to you.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku151"]
[OnName num="miku"]
"Thank you ...... for turning me into the person I am today, Takuma.
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku152"]
[OnName num="miku"]
I love you. I love you, I'll always love you. ......
[cpg cn=true]




;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

;//ＥＮＤ　ヒロイン２理想ルート


;//[SCENE id=32]
[SCENE id=20]
[system end2=true]

[jump storage="epend.ks" target="*start"]









;//==============================
;//２、受け入れる

;#################################################
*Ep021|We got what we both wanted.
;#################################################

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************

*Hiroin_Root_2_22|お互いの望みが叶った



;//[SCENE id=21]
[SCENE id=9]

;//////////////////////////////////
;//ヒロイン２中立ルートに分岐
;//////////////////////////////////





[OnName num="takuma"]
"...... got it. I'll get it."
[cpg cn=true]


[FG f="CHA02_p5_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku153"]
[OnName num="miku"]
"Really?　Yay, I get to see Takuma dressed as a woman!
[cpg cn=true]


The senior was in a good mood. It was good to see his face.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（昼）******************************************************





And so, I and my senpai took each other's place as the star of the show.
[cpg]


I don't think I am a very good actor, but my senior was.
[cpg]


Maybe that's what they saw in me. Everyone knows we're dating.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku154"]
[OnName num="miku"]
I think we're going to have a lot of work today. You're going to be practicing a lot.
[cpg cn=true]


[OnName num="takuma"]
I'm prepared for that.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku155"]
[OnName num="miku"]
I can do anything with Takuma. I can do anything with Takuma.
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************





As we fulfilled each other's desires, the older man became more manly and I became more neutral.
[cpg]


Some people around them say they are a couple where it is hard to tell which one is the man and which one is the woman.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku156"]
[OnName num="miku"]
Is there such a rumor?
[cpg cn=true]


[OnName num="takuma"]
There are. There are rumors that I am effeminate, and there are rumors that my senpai is handsome.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku157"]
[OnName num="miku"]
It's strange, isn't it? It's like we've fulfilled each other's desires.
[cpg cn=true]


It's like that, or at least that's what I think it is.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





On the day of the festival.
[cpg]


I was nervous. We had practiced, but we were not in the best condition.
[cpg]



;//ev_44を表示

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_pi"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



My senpai was performing. He was a bit slow and looked like a student.
[cpg]


I was the same way. Perhaps if I had concentrated on turning my seniors into ideal seniors, we might have had a different future.
[cpg]


Still, the curtain came down without any major mistakes.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（夕方）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miku158"]
[OnName num="miku"]
I chewed a lot of ...... lines.
[cpg cn=true]


[OnName num="takuma"]
I was flying. I would have been in trouble if my seniors hadn't followed me.
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku159"]
[OnName num="miku"]
But it was fun. It was fun acting with Takuma. ......
[cpg cn=true]


The first thing you need to do is to make sure that you have a good understanding of what you are doing and how to do it.
[cpg]


 As it was, I went to my Senior's house without saying anything.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku160"]
[OnName num="miku"]
I said, "...... hey. Why don't you try on some more girlie clothes?"
[cpg cn=true]


[OnName num="takuma"]
Again. ...... Enough said."
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku161"]
[OnName num="miku"]
I'm not going to be a part of this. I'm a late bloomer."
[cpg cn=true]


The senior asked for it again and again, but it's not something you can do that often.
[cpg]

I was not a fan of the idea, but I was not a fan of the idea. Or maybe I didn't.
[cpg]

In any case, my senpai wants me.
[cpg]

After the theater festival, I felt our bond became stronger again.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************

;//qwe

I think it's a perverted relationship, but I think it's good that we both want that kind of thing from each other.
[cpg]


Both senpai and I were the way we wanted to be with each other.
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku162"]
[OnName num="miku"]
I was so happy, Takuma. I wonder if it's good that I'm so happy.
[cpg cn=true]


[OnName num="takuma"]
I think it's fine. I am sure that all lovers think so.
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku163"]
[OnName num="miku"]
I think I am the happiest person in the world. I think I am the happiest person in the world.
[cpg cn=true]


I don't think so.
[cpg]


[OnName num="takuma"]
But I don't feel guilty.
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miku164"]
[OnName num="miku"]
I don't feel guilty either. It's just that ......
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku165"]
[OnName num="miku"]
I just feel a little guilty about having such a cute boyfriend.
[cpg cn=true]


[OnName num="takuma"]
You don't feel guilty?
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku166"]
[OnName num="miku"]
"Hmmm. Maybe so,......, but enough is enough."
[cpg cn=true]


The older man puts his lips to mine. I don't need any more words.
[cpg]


Cool girlfriend. Cute boyfriend. We've got what we both want.
[cpg]





;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

;//ＥＮＤ　ヒロイン２中立ルート


;//[SCENE id=33]
[SCENE id=21]
[system end2=true]

[jump storage="epend.ks" target="*start"]





;//==============================


