
*start
;//カスタムcute　シナリオ

;#################################################
*Ep000|The beginning of a page of youth?
;#################################################

[SCENE id=0]

;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//桜　　　制服　私服
;//美紅　　制服　私服
;//ものの　制服　私服
;//梢　　　制服　私服
;//上記以外のキャラクターには音声がありません
;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//桜　一人称「私」　美紅呼び「先輩or周防先輩」　ものの呼び「もののちゃん」
;//　　梢呼び「先生or門脇先生」　宅磨呼び「宅磨」
;//美紅　一人称「私」　桜呼び「桜さん」　ものの呼び「もののさん」
;//　　　梢呼び「先生or門脇先生」　宅磨呼び「宅磨」
;//ものの　一人称「あたし」　桜呼び「井伊樫先輩」　美紅呼び「素防先輩」
;//　　　　梢呼び「先生or門脇先生」　宅磨呼び「先輩」
;//梢　一人称「私」　桜呼び「井伊樫さん」　美紅呼び「素防さん」
;//　　ものの呼び「高坂さん」　宅磨呼び「四方樹くんor宅磨くん」
;//宅磨　一人称「俺」　桜呼び「桜」　美紅呼び「先輩」
;//　　　ものの呼び「ものの」　梢呼び「先生」
;//エンディング付近では例外的に主人公やヒロインが名前呼びになることがあります
;//シナリオで指定している演出関係は
;//【演出】
;//で表記しています

;//入手したアイテム
[stflag getItem_01 = 0]
[stflag getItem_02 = 0]
[stflag getItem_03 = 0]
[stflag getItem_04 = 0]
[stflag getItem_05 = 0]
[stflag getItem_06 = 0]
[stflag getItem_07 = 0]
[stflag getItem_08 = 0]
[stflag getItem_09 = 0]
[stflag getItem_10 = 0]
[stflag getItem_11 = 0]
[stflag getItem_12 = 0]
[stflag getItem_13 = 0]
[stflag getItem_14 = 0]
[stflag getItem_15 = 0]


;//マップ選択時にどのアイテムを選んだか
[stflag getItemNum_01 = 0]
[stflag getItemNum_02 = 0]
[stflag getItemNum_03 = 0]

;//全体で何回選んだか
[stflag Count_Selected = 0]

;//ヒロインを何回選んだか
[stflag HiStoryFlg_01 = 0]
[stflag HiStoryFlg_02 = 0]
[stflag HiStoryFlg_03 = 0]
[stflag HiStoryFlg_04 = 0]

;//ヒロインに何回勝ったか
[stflag HiWinFlg_01 = 0]
[stflag HiWinFlg_02 = 0]
[stflag HiWinFlg_03 = 0]
[stflag HiWinFlg_04 = 0]

;//選択したキャラによってアイテムの入手純が変わるので必要な分岐条件情報
[stflag Selected_cha = 0]


;//////////////////////////////////////
;///////////////以下本編///////////////
;//////////////////////////////////////



[free time=1000]
[BG f="black.ui" time=1000]
[BGM f="bg_pi"]
[WAIT time=100]
;//ブラックアウト

;//[jump target="*before_select_chara"]


;//【演出】
;//画面をうにょうにょ揺らす　夢を見ている演出





I'm having a dream right now.
[cpg]


Sometimes I think I realize, "Oh, this is a dream.
[cpg]


How did I know it was a dream? It is quite simple.
[cpg]


Because I don't have such a lovely girlfriend.
[cpg]

The person in my dream is smiling at me.
[cpg]

I guess she and I are lovers.
[cpg]

I hate myself for realizing that even this dream is not real.
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[SE f="se003"]
;//【ＳＥ】『飛び起きる』





[OnName num="takuma"]
"Huh?
[cpg cn=true]


The familiar ceiling. I know my room too well.
[cpg]


[OnName num="takuma"]
"...... is it a dream?"
[cpg cn=true]


No, I knew it was a dream from the beginning.
[cpg]

Still, I guess I was hoping for it. A future where you really have a girlfriend. ......
[cpg]


;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』

I feel uncomfortable after having a dream like that. And the people around me don't care about me.
[cpg]

I'm feeling even lonelier and lonelier. ......
[cpg]


;//桜と梢の立ち絵を表示

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/2" time=800]


[OnName num="takuma"]
Ah!
[cpg cn=true]


In the corridor of the school, I found the person in question.
[cpg]



[free time=1000]

Oh no, what should I do? I'm so nervous. I wonder if I'm such a girl.
[cpg]



;//ここの会話はあとの何かの伏線にしたい



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Sakura001"]
[OnName num="sakura"]
Well then, sir, I'll take this, please.
[cpg cn=true]


[FG f="CHA04_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Kozue001"]
[OnName num="kozue"]
"Yes. Yes, I certainly received it.
[cpg cn=true]



;//【演出】
;//梢の立ち絵を消す
;//桜の立ち絵が近づいてくる


[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]


After exchanging a few words with the teacher, she starts to walk away.
[cpg]


She walks towards me from the front.
[cpg]


My heart starts to race. What's that?　Hey, hey. What should I do if I'm really nervous about ......?
[cpg]


[OnName num="takuma"]
「……」
[cpg cn=true]


Suddenly, I remembered the word "dream".
[cpg]


It's just a dream, so to speak! It wasn't a dream! It wasn't a dream!
[cpg]


Today's dream may be ...... such a thing.
[cpg]


I have a hunch that I will have a positive ...... dream.
[cpg]


Maybe in a month, maybe in a week, maybe even after school today...
[cpg]


Maybe something like that dream will happen. ...... guffaw.
[cpg]



[FG f="CHA01_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sakura002"]
[OnName num="sakura"]
"...... get out of my way!"
[cpg cn=true]


[OnName num="takuma"]
"......"
[cpg cn=true]


......It was all in my mind. It was only a dream after all.
[cpg]


I was so lost in my fantasy that I didn't even see the look on her face.
[cpg]


It's my fault for standing there in the middle of the hallway. Yeah, it was my fault for standing there in the middle of the hallway.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sakura003"]
[OnName num="sakura"]
Gross.
[cpg cn=true]



;//桜の立ち絵消す
[free time=1000]



I feel like I haven't been talked to in a while. If you can count that.
[cpg]


But it wasn't even a greeting.
[cpg]



...... Well, that's okay. All human beings are strangers.
[cpg]


It's like this ..........
[cpg]


[OnName num="takuma"]
"......Ah, it's my senior!"
[cpg cn=true]


I looked out the window and there was a senior I knew.
[cpg]


I started to run to meet him.
[cpg]



[SE f="se025"]
;//【ＳＥ】『走る』



;//梢の立ち絵を表示





[FG f="CHA04_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Kozue002"]
[OnName num="kozue"]
Don't run in the hallway.
[cpg cn=true]

[free time=1000]

I was told by the teacher, "Don't run in the corridor," but I switched to a fast walk.
[cpg]


It's okay, it's okay. I had my senpai with me.
[cpg]





;//桜の立ち絵を一瞬だけ表示

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/4" time=1000]
[WAIT time=2000]

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************





On the way from the gate to the school building, there was a senior there.
[cpg]


Her name is Miku Suboh.
[cpg]


She is a cool and interesting person.
[cpg]


Combined with her fresh appearance, the word "cool beauty" is appropriate.
[cpg]


[OnName num="takuma"]
Senpa ......"
[cpg cn=true]


Just as I was about to call out to my senpai
[cpg]


The ball from the soccer team's morning practice changed its trajectory in an unexpected direction.
[cpg]


A female student on her way to school was on the other end of the ball.
[cpg]


[OnName num="takuma"]
Look out!"
[cpg cn=true]



;//【演出】
;//ヒロイン２の立ち絵を画面右からスライドして中央で停止。ボールを受け止める感じの演出



[SE f="se023"]
;//【ＳＥ】『ボール受け止める』





[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Miku001"]
[OnName num="miku"]
「……」
[cpg cn=true]


[free time=1000]

[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
;//[t_move pos=C 動揺]

The ball would have surely hit her if it had gone straight. The senior caught it brilliantly.
[cpg]


[OnName num="female_student"]
"Oh, thank you."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku002"]
[OnName num="miku"]
No, it's no big deal.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku003"]
[OnName num="miku"]
"......, no need to thank me."
[cpg cn=true]



;//実際は小石に躓いて女子学生に覆いかぶさる形でぶつかり、たまたま出していた左手にボールが収まっただけ



[SE f="se051"]
;//【ＳＥ】『歓声』





[OnName num="takuma"]
"...... is cool."
[cpg cn=true]


I'm not the only one who gets looks of envy from everyone around me.
[cpg]


Even when she helps others, she is still the same cool beauty with a clear face.
[cpg]


This is probably why he is popular with both men and women alike.
[cpg]


[OnName num="takuma"]
I'm sorry.　Are you okay?
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Miku004"]
[OnName num="miku"]
What?　Uh, yeah..."
[cpg cn=true]


I was already at the entrance of the school, but I was so excited that I went up to her and talked to her.
[cpg]


I was so excited that I went up to her and talked to her.
[cpg]


But the senior was cool enough to give me the courage to do so.
[cpg]


[OnName num="takuma"]
I was so impressed with his athleticism that I had to ask him.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku005"]
[OnName num="miku"]
What?　I'm not at all.
[cpg cn=true]


The first thing to do is to get a good look at the other side of the room. He never flaunts his abilities.
[cpg]


I was a senior.
[cpg]


[OnName num="takuma"]
"Were you involved in any club activities, senpai?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miku006"]
[OnName num="miku"]
"No, I'm in ......."
[cpg cn=true]


[OnName num="takuma"]
"You're athletic even though you're not in any club?　That's amazing.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku007"]
[OnName num="miku"]
......."
[cpg cn=true]


The senior is shy, or maybe he doesn't talk much.
[cpg]


Or am I talking too much one way?
[cpg]


[OnName num="takuma"]
If you join any clubs, let me know. I'll be there to cheer you on."
[cpg cn=true]


The senpai listened to me in silence.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************





Then I headed to my classroom. I said goodbye to my senpai once and for all.
[cpg]


From here on, it's boring, lonely, and lazy time. My youth can be described in such words.
[cpg]


The only thing I do is stare at the girls in my class.
[cpg]


[OnName num="female_student"]
"I'm looking at you again."
[cpg cn=true]


[OnName num="female_student"]
Gross."
[cpg cn=true]


I pretend not to hear. It happens all the time. Girls don't like me.
[cpg]


But no matter what they say, I always follow them with my eyes.
[cpg]


That's fine. It's okay to be a pervert. I have no other pleasure.
[cpg]


Seriously, my life is so boring.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=2100]

;//【ＢＧ】『学園教室』（夕方）******************************************************


[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



;//教室→廊下の順に表示



After school, I go to class. I have no friends, so I go home right away.
[cpg]


Sakura is a classmate, but going home together is too rare an event.
[cpg]



[SE f="se010"]
;//【ＳＥ】『歩く』



;//ものの立ち絵を表示


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]


[OnName num="takuma"]
"Oh!
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono001"]
[OnName num="monono"]
Oh, Shikataju-senpai. Thanks for coming.
[cpg cn=true]


I bumped into a girl in the hallway who was a junior.
[cpg]


[OnName num="takuma"]
The actual "Shikataju senpai" is not ...... this last name, it's hard to say, right?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono002"]
[OnName num="monono"]
I don't think so..."
[cpg cn=true]


My last name is Shihoju. It's a very harsh name, and a bit burdensome.
[cpg]


My girlfriend is Monono Kousaka. She is a cute junior who looks like a small animal.
[cpg]


However, as you can see, she has quite large breasts. Every time I see her, I can't help but stare at her.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono003"]
[OnName num="monono"]
Where are you looking?
[cpg cn=true]


[OnName num="takuma"]
'Wherever you want.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Monono004"]
[OnName num="monono"]
'...... I'll sue you for sexual harassment.
[cpg cn=true]


I can do some things that I could never do or say to my seniors.
[cpg]


I can't read the depths of their hearts, but I think they adore me as a senior...and that's why we can have this exchange.
[cpg]


That's why we can have this exchange.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono005"]
[OnName num="monono"]
By the way, senpai. You were talking with Sobo this morning, weren't you?
[cpg cn=true]


[OnName num="takuma"]
I guess so. She's cool, isn't she?
[cpg cn=true]


He was silent.
[cpg]


[OnName num="takuma"]
What's wrong?　Are you jealous?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono006"]
[OnName num="monono"]
No, I'm just jealous. I just have a weird feeling that she's my senior.
[cpg cn=true]


[OnName num="takuma"]
What's that? That's just how it is.
[cpg cn=true]


It's just an ordinary conversation. This is the kind of relationship between me and Nono.
[cpg]


We don't get too deep into each other's lives, but we're close.
[cpg]


[OnName num="takuma"]
"Are you on your way home?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono007"]
[OnName num="monono"]
"Yes, I am. Yes, I am.
[cpg cn=true]


[OnName num="takuma"]
Then, would you like to go home with me at ......?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono008"]
[OnName num="monono"]
Why are you suddenly using honorifics? It's weird.
[cpg cn=true]


[OnName num="takuma"]
I'm nervous because I've never gone home with a girl before.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono009"]
[OnName num="monono"]
"...... is a lonely life, isn't it?"
[cpg cn=true]


[OnName num="takuma"]
I'm so nervous." "That's so annoying."
[cpg cn=true]


Despite my lightheartedness, I sweat my hands over the fact that I'm inviting a junior to join me.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono010"]
[OnName num="monono"]
Well, that's okay. We just walk together.
[cpg cn=true]


[OnName num="takuma"]
Yes!
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono011"]
[OnName num="monono"]
'...... is so creepy.'
[cpg cn=true]


What a thing to say to my pretty smile. I'm not a cute junior.
[cpg]


But it feels good, so I'll forgive him.
[cpg]


I got the event of going home with the junior who has a baby face and big tits, and I start walking with a happy mood.
[cpg]



[SE f="se010"]
;//【ＳＥ】『歩く』



;//ものの立ち絵と一緒に梢の立ち絵を表示


[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Monono012"]
[OnName num="monono"]
"Bye, teacher.
[cpg cn=true]


[OnName num="takuma"]
Bye.
[cpg cn=true]


[FG f="CHA04_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Kozue003"]
[OnName num="kozue"]
"Bye. Be careful on your way home.
[cpg cn=true]


On my way to the shoe box, I ran into the teacher.
[cpg]


[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Kozue004"]
[OnName num="kozue"]
Oh, that's right," he said, "which way is the library? Which one is the library, ......?　Is this the right floor?
[cpg cn=true]


[OnName num="takuma"]
"Well, it's at the end of this floor, straight ahead..."
[cpg cn=true]


[FG f="CHA04_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Kozue005"]
[OnName num="kozue"]
Thank you. Thank you.
[cpg cn=true]



[SE f="se010"]
;//【ＳＥ】『歩く』



;//梢の立ち絵を消す

[free time=1000]
[WAIT time=1100]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono013"]
[OnName num="monono"]
You're new here, aren't you, sir?
[cpg cn=true]


[OnName num="takuma"]
Yes, I'm an intern. She's a trainee educator, so I'm sure there's a lot she doesn't know.
[cpg cn=true]


Kozue Kadowaki. I'm not a teacher yet, but I'm what we call a teacher.
[cpg]


She is not a teacher yet, but she is someone we should call a teacher.
[cpg]


I haven't talked to her much. At least, I only greet her lightly, like I do now.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]


I felt it again this morning, my heart beating fast.
[cpg]


[OnName num="takuma"]
"Mononono-san. Why don't we go to the arcade?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono014"]
[OnName num="monono"]
You're too busy. Please calm down. I won't go.
[cpg cn=true]


[OnName num="takuma"]
"Oh, no."
[cpg cn=true]


He refused. But it's no surprise.
[cpg]


I've never gone home with her before.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Monono015"]
[OnName num="monono"]
My senior is one who doesn't really understand distance.
[cpg cn=true]


It may be that I'm being told in a roundabout way that I've suddenly become too familiar.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono016"]
[OnName num="monono"]
...Where do you really want to go?"
[cpg cn=true]


[OnName num="takuma"]
"Well, ...... let's see..."
[cpg cn=true]


When asked where they want to go, there are places they can think of.
[cpg]


But a variety of emotions push back those words.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Monono017"]
[OnName num="monono"]
You're too pink in the head, "...... senpai. That won't make the girls like you. Well then."
[cpg cn=true]


[OnName num="takuma"]
Oh..."
[cpg cn=true]



[SE f="se010"]
;//【ＳＥ】『歩く』
[free time=1000]




I went away. While my brain was processing the information, her figure was getting smaller and smaller.
[cpg]


[OnName num="takuma"]
「……」
[cpg cn=true]



I know what I am. I know I'm a total scumbag. I know that.
[cpg]


But I don't have any girls I can connect with to begin with.
[cpg]


Is it wrong to see potential in a girl who is a close friend among them?
[cpg]


I'm trying my best to be cheerful....
[cpg]


[OnName num="takuma"]
Huh... ...... let's go home."
[cpg cn=true]


;//ブラックアウト






[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





After a long day, I came back to my room and sagged as usual.
[cpg]


It's been a mundane, but fulfilling day. ......
[cpg]


[OnName num="takuma"]
How is that possible?
[cpg cn=true]


At the school, he is basically a botch. Even today, he ate lunch alone.
[cpg]


The girls don't like me (I deserve it).
[cpg]


I don't want to live a gray school life like this. I couldn't help it.
[cpg]


I was in a hurry. Part of me was acting like a clown to fool myself into thinking I was in a hurry.
[cpg]


Everyone is saying, "If you get a girlfriend, your life will change! everyone says.
[cpg]


So I decided to do it. Like most people, I want a girlfriend.
[cpg]


[OnName num="takuma"]
I'm tired..."
[cpg cn=true]


Tired of thinking about it, I went to bed in a huff.
[cpg]


;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************





The next morning. On my way to school, I ran into my childhood friend again. Her breasts are huge again today.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura004"]
[OnName num="sakura"]
「……」
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
And she's not very sociable. Nothing has changed from yesterday.
[cpg]

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
I wonder if they are really childhood friends, and I even wonder if the past has been altered.
[cpg]



;//【演出】
;//桜の立ち絵を段階で表示して追い抜く感じの演出




[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
The cherry blossoms walk slowly, and I am in the form of overtaking them. She doesn't even say hello to me.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
We used to be really close. The relationship is now as cold as that of a mature couple.
[cpg]

[free time=1000]
But every time I have a faint hope that she will talk to me today.
[cpg]


In the end, there is no conversation.
[cpg]


[VOICE f="Sakura005"]
[OnName num="sakura"]
"Huh. ......."
[cpg cn=true]


I hear what sounds like a sigh from behind me.
[cpg]


Is it a sigh for me? If so, am I waiting for them to talk to me?
[cpg]


What a surprise. I was imagining things. ......
[cpg]



;//桜の立ち絵を表示



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="male_student"]
Good morning, Sakura.
[cpg cn=true]


Then a male student whom I don't know well appears and talks to Sakura.
[cpg]


I sneak a peek at him.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sakura006"]
[OnName num="sakura"]
"Good morning. Is it true you broke up with your girlfriend again?
[cpg cn=true]


[OnName num="male_student"]
I guess so. But it's not for Sakura to say.
[cpg cn=true]


[OnName num="male_student"]
I know that you've been going from one guy to the next.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura007"]
[OnName num="sakura"]
"I know you've been with a lot of guys," she said. I'm not wrong.
[cpg cn=true]


There are rumors that she is a terrible lover.
[cpg]

The actuality is that she had been with a number of guys. I've also heard that she was two-timing and more.
[cpg]

Well...I don't know what the truth is.
[cpg]


[OnName num="takuma"]
"...... huh."
[cpg cn=true]


It's so empty. I head off to the academy with a sense of hopelessness.
[cpg]


At least it's not ...... her that changes my gray days.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]


Walking quickly, I found Soboho senpai.
[cpg]


There's no way I could ever mistake her for someone else, even from behind. It's an oasis in my heart.
[cpg]


Just by looking at her, the cloudy sky in my mind went away.
[cpg]


[OnName num="takuma"]
"Good morning, senpai!
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Miku008"]
[OnName num="miku"]
Good morning!
[cpg cn=true]


The shoulder of the senior shakes with a jerk. I think I may have been a little too energetic.
[cpg]


I talked to her as I stood next to her.
[cpg]


[OnName num="takuma"]
 “Senior, are you going to join the club after all?”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku009"]
[OnName num="miku"]
It's ...... that."
[cpg cn=true]


He was flinching. I was too passionate about it.
[cpg]


[OnName num="takuma"]
I'd like to see you play sports, though.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku010"]
[OnName num="miku"]
I'd like to see you play sports.
[cpg cn=true]


Today, seniors are cool. And beauty.
[cpg]


The best way to get the most out of this is to get a good quality of life.
[cpg]


The best way to do this is to get a good, clean, and healthy diet. I only need my senpai.
[cpg]


[OnName num="takuma"]
I'm going to take the exam soon..." "What?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Miku011"]
[OnName num="miku"]
"What?
[cpg cn=true]


[OnName num="takuma"]
You're smart, aren't you, senpai?　What's your rank in your grade?
[cpg cn=true]


I don't know exactly, but I heard I'm probably in the top 50 or so.
[cpg]


Last semester, it seems he was out of the ranks because he was sick with a cold.
[cpg]


I heard such a story through rumor.
[cpg]


[OnName num="takuma"]
I heard a rumor that he was out of the top 50 last semester. I'd be happy to study with you sometime..."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku012"]
[OnName num="miku"]
「……」
[cpg cn=true]


[OnName num="takuma"]
"Aiya, I know you're busy, so if you have time..."
[cpg cn=true]


[OnName num="takuma"]
I'd really like it if you have time.
[cpg cn=true]


Suddenly, the thought of yesterday's events came to mind and made me slam on the brakes.
[cpg]


Don't be stubborn.
[cpg]


Be a gentleman. Be as relaxed, graceful, and cool as your senpai.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miku013"]
[OnName num="miku"]
I'm sorry...I'm not good at studying ..........
[cpg cn=true]


[OnName num="takuma"]
What?
[cpg cn=true]


I was stiffened by the unexpected answer.
[cpg]


[OnName num="takuma"]
Oh, really?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku014"]
[OnName num="miku"]
I'm sorry..."
[cpg cn=true]


The senior had a gloomy expression on his face. Damn, I'm such an idiot! I can't believe I made her look like this!
[cpg]


[OnName num="takuma"]
I'm sorry. I was so quick to make a mistake.
[cpg cn=true]


I'm sorry, I took the liberty. I like that about my senpai.
[cpg]


It's nice to see someone who looks perfect but actually has something they're not good at. Yeah, it's good, good. It's called "gap moe.
[cpg]


[OnName num="takuma"]
But I feel a little closer to him because he also has something he's not good at.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miku015"]
[OnName num="miku"]
"Sports...I can't do it either. ......"
[cpg cn=true]


Impossible?　I can't believe my ears for a moment, and then I ask him back.
[cpg]


[OnName num="takuma"]
What do you mean you can't?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku016"]
[OnName num="miku"]
I can't do group activities."
[cpg cn=true]


I couldn't believe my ears for the second time.
[cpg]


But I understood immediately. I see, he is a lone wolf.
[cpg]


He seemed to be kind to those around him, but he kept his distance.
[cpg]


[OnName num="takuma"]
I see. ...... So how about an individual event?　Track and field?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku017"]
[OnName num="miku"]
"......No, so...I can't."
[cpg cn=true]


The reply was stubborn and unchanging. The will of steel.
[cpg]


I didn't know he was that stoic.
[cpg]


Stubborn...but is that part of her charm?
[cpg]


She prefers to be alone. Maybe she is actually irritated that I am talking to her like this.
[cpg]


I almost convinced myself of that.
[cpg]


I wish I could have convinced her.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miku018"]
[OnName num="miku"]
"It's ...... impossible for ...... people to be... full of ...... hi ...... people!"
[cpg cn=true]


[OnName num="takuma"]
What is it?　What's wrong with you, senior!　Do you have a fever?
[cpg cn=true]


;//※先輩はたまに語尾がおかしくなる設定


The senior shakes his head, buzzing at my words.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku019"]
[OnName num="miku"]
I...really...can't...study...or...do...sports.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miku020"]
[OnName num="miku"]
I'm not the ...... person you think I am..."
[cpg cn=true]


Was today...April Fool's Day? Maybe it is.
[cpg]


I can't believe it. Even if I was told so, there is no way I can believe it.
[cpg]


[OnName num="takuma"]
"Ha ha ha. You must be joking."
[cpg cn=true]


He shakes his head again at my words.
[cpg]


You're saying I'm actually athletically challenged?　That's absurd.
[cpg]


Yesterday, you were so brilliantly protecting a female student from a bad ball.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku021"]
[OnName num="miku"]
That... just happened to ...... happen when you fell down.
[cpg cn=true]


[OnName num="takuma"]
「……」
[cpg cn=true]


I don't believe it. I can't believe it...but when I heard that, I suddenly realized that I had been so hunched over.
[cpg]


The first thing that comes to mind is that the senior was such a hunchback.　Did he look like he lacked self-confidence?
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miku022"]
[OnName num="miku"]
I'm sorry, ......."
[cpg cn=true]


[OnName num="takuma"]
No, but look...senior. Don't you remember?　The first time we met..."
[cpg cn=true]


[OnName num="takuma"]
At the intersection, you saved my life.
[cpg cn=true]


Yes, I still remember it clearly.
[cpg]



;//【演出】
;//回想　に入る感じの演出　セピア調でお願いします



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『街』（朝　セピア調）******************************************************





I was about to cross the pedestrian crossing.
[cpg]


[OnName num="takuma"]
"Mmmmmmmmmm..."
[cpg cn=true]



[SE f="se004"]
;//【ＳＥ】『車が走る音』





I wasn't jaywalking. It was the car that did.
[cpg]



[SE f="se005"]
;//【ＳＥ】『ブレーキ音』





I thought I saw the driver's eyes. I thought, "Oh, this is a bad guy.
[cpg]


I instantly thought of death.
[cpg]



;//【演出】
;//画面が傾いて倒れる演出





[OnName num="takuma"]
"Oh my God!
[cpg cn=true]



[SE f="se003"]
;//【ＳＥ】『倒れる』



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//【演出】
;//視界がぼやけている感じの演出
;//美紅立ち絵アップを下から上へ画面を映していって最終的に顔がでる

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『街』（朝　セピア調）******************************************************






[OnName num="takuma"]
Oh, that...?　Excuse me!
[cpg cn=true]


I was being pulled down by a strange woman.
[cpg]


At first I thought I had been hit by a car. But no.
[cpg]


Yes, she saved me from being hit by a car.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku023"]
[OnName num="miku"]
Are you all right ......?
[cpg cn=true]


[OnName num="takuma"]
Oh, yes!　I'm fine!　I'm sorry!
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miku024"]
[OnName num="miku"]
No, ......."
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
As I leave, she leaves the place with a dash.
[cpg]

[free time=1000]


[OnName num="takuma"]
"Oh, ...... thank you!!!!"
[cpg cn=true]


I thanked her as best I could toward the back.
[cpg]


That person is...senpai.
[cpg]



;//回想終了



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園外観』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="takuma"]
I wanted to thank you more.
[cpg cn=true]


That's how we met, senpai and I. That was the beginning of our acquaintance.
[cpg]


The first time I saw her, I was like, "I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku025"]
[OnName num="miku"]
"I'm sorry ...... for that time.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miku026"]
[OnName num="miku"]
I'm sorry I stepped on ...... your heels...I couldn't apologize..."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Miku027"]
[OnName num="miku"]
There were so many people... looking at me... and I was so embarrassed..."
[cpg cn=true]


[OnName num="takuma"]
「………」
[cpg cn=true]


Something.
[cpg]


Something made a noise and I felt it crumble.
[cpg]


[OnName num="takuma"]
Then maybe... really... it was all just a misunderstanding?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miku028"]
[OnName num="miku"]
Yes...yes."
[cpg cn=true]


I was crumbling. The hero in me was crumbling.
[cpg]


The cool beauty who saved my life.
[cpg]


She, she, she, she....
[cpg]


[OnName num="takuma"]
"And..."
[cpg cn=true]


But... But... but... But, but, but, but, but, but, but, but!
[cpg]


[OnName num="takuma"]
There are so many other good things about senpai... so many... so many... so many...
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miku029"]
[OnName num="miku"]
What...?
[cpg cn=true]


[OnName num="takuma"]
"I like your ......... style."
[cpg cn=true]


It's soft like a cushion. The actual "I'm not a fan of the way you look at it, but I'm not a fan of the way you look at it.
[cpg]



[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Miku030"]
[OnName num="miku"]
"Phew ...... ughhhhhhhhhhhh ......"
[cpg cn=true]


Miho Sobo growls low, her face reddening. She glares at us.
[cpg]


This is probably why girls don't like me.
[cpg]



[SE f="se025"]
;//【ＳＥ】『走る』





[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Miku031"]
[OnName num="miku"]
Bye, bye...
[cpg cn=true]


Saying that, she starts to run.
[cpg]



;//【演出】
;//走る美紅
;//立ち絵がちょっとずつだけ前に進む


[free time=1000]

[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/4" time=800]


Slam, slam, slam.
[cpg]


Flop, flop, flop.
[cpg]


[OnName num="takuma"]
「……」
[cpg cn=true]


I know her. I know that figure.
[cpg]


It was an athletic meet when I was in elementary school. The way my father, who was athletically inept, was trying so hard to show me how good he was.
[cpg]


Hopelessly slow.
[cpg]


[OnName num="takuma"]
"........."
[cpg cn=true]


[free time=1000]
[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="1/2" time=800]

That...why am I ...... crying?
[cpg]

[free time=1000]

[FG f="CHA02_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
I run past the senior running with tears streaming down my face with strong steps.
[cpg]

[free time=1000]

;//【演出】
;//美紅を追い抜かす
;//美紅の立ち絵を消す





Welcome back, cloudy sky. Goodbye, sunny skies.
[cpg]


The weather forecast is often wrong.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





The scenery I see has completely changed.
[cpg]


A gray world. It was faded, as if a filter had been applied.
[cpg]


No, it was just that my senior filter had been on and the colors looked vivid.
[cpg]


It was removed. Maybe that's the true state of the world as I see it.
[cpg]


[OnName num="female_student"]
Hey, hey, I know. This morning, I heard the gossip around me.
[cpg cn=true]


I could hear the gossip around me.
[cpg]


[OnName num="female_student"]
What's wrong?
[cpg cn=true]


[OnName num="female_student"]
"On the way to school, he was running like a running machine, loading himself up!
[cpg cn=true]


[OnName num="female_student"]
"Wow, that's amazing! That's so cool!
[cpg cn=true]


[OnName num="female_student"]
"I was only going a little at a time, but I was sweating a lot and out of breath.
[cpg cn=true]


[OnName num="male_student"]
"That's a hard workout. I'm amazed at how hard you work out in the morning.
[cpg cn=true]


[OnName num="male_student"]
"That's because I'm sure I'd be there in no time if I really tried."
[cpg cn=true]


What's with that reaction? Is this the power of the senior filter?
[cpg]


People around me interpret it in a convenient way. I was on your side until a little while ago.
[cpg]


You're all a bunch of flower girls, aren't you?　Let's see what's really going on.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************





What should I do? What should I do?　I can't think straight.
[cpg]


It's as if I've lost the meaning of life. My life is more flimsy than I imagined.
[cpg]


Is it true that I have nothing but what I have?
[cpg]


A cute junior colleague. At least she adores me. ......
[cpg]


Lunch alone was lonely and sad. I'm hanging out in the hallway near the class where Mono is.
[cpg]


At this point in his behavior, he's a pretty dangerous guy, but...
[cpg]



[BGM f="bg_co"]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Monono018"]
[OnName num="monono"]
Hey. Senior, what are you doing here?"
[cpg cn=true]


[OnName num="takuma"]
Oh, yeah. No. ......"
[cpg cn=true]


I've always wanted to meet him, but when I run into him, I don't know what to say.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono019"]
[OnName num="monono"]
'Did you come to see me, by any chance?
[cpg cn=true]


[OnName num="takuma"]
'Well, yes. ......'
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono020"]
[OnName num="monono"]
What...what is that? It's a joke. Don't take it seriously. It's disgusting.
[cpg cn=true]


Aaaaaaahhhhhhh!
[cpg]


It works really well for me right now. It's like salt on the wound.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono021"]
[OnName num="monono"]
But I'm glad. I can't believe that my senpai came to me. Phew!
[cpg cn=true]


It's healed.
[cpg]


The one who smiles is still cute.
[cpg]


Ah, yes. The time is my junior. I still have a girlfriend.
[cpg]


[OnName num="takuma"]
"Mono...let's eat dinner together?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono022"]
[OnName num="monono"]
The way she looks up at me is at the maximum uncomfortable level, but...it's okay. We'll just eat together.
[cpg cn=true]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sc"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]


We move to an empty classroom and eat our lunch together.
[cpg]


The only thing that I really want to do is to be next to her. No conversation is going on.
[cpg]


She must have sensed the mood, because she broached the subject.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono023"]
[OnName num="monono"]
She asked, "So, senpai. Why did you suddenly ask me out?　Did something happen?"
[cpg cn=true]


[OnName num="takuma"]
She said, "U......"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono024"]
[OnName num="monono"]
If there is something wrong, why don't you tell me?　I'm just asking.
[cpg cn=true]


I might be grateful just to hear it.
[cpg]


I was a little lost, but I decided to talk about the story of the senior Sohbou.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



;//【演出】
;//一度画面切り替えして教室を再び表示
;//説明をした、と分かる間の演出



;//【演出】
;//ものの　立ち絵　ポーズ違い（腕組み）　ちょっと冷たい表情
;//もののが割とキツイ事を言うシーンなので立ち絵をそれに合わせて変更





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono025"]
[OnName num="monono"]
I see..." "I see..."
[cpg cn=true]


[OnName num="takuma"]
You're not surprised?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono026"]
[OnName num="monono"]
"I thought so somehow..."
[cpg cn=true]


Seriously. It seems that thing was aware of it.
[cpg]


I was so blindly trusting of my senpai that I had no idea.
[cpg]


[OnName num="takuma"]
Why didn't you tell me?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono027"]
[OnName num="monono"]
Because there's no point in telling me. It would only make one boy unhappy.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono028"]
[OnName num="monono"]
Did you have a good dream?
[cpg cn=true]


[OnName num="takuma"]
Damn...
[cpg cn=true]


They are talking about themselves. I was somewhat annoyed.
[cpg]


But I couldn't say anything back.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono029"]
[OnName num="monono"]
So, what do you want to do in the end? What do you want to do in the end?
[cpg cn=true]


[OnName num="takuma"]
"Eh...oh, I'm ......"
[cpg cn=true]


That's the problem. I don't know what I'm doing.
[cpg]


But I just want to...
[cpg]


[OnName num="takuma"]
I just want to have a fun school life.
[cpg cn=true]


It's very simple. That's all.
[cpg]


But for me, it's as difficult as climbing Mount Everest.
[cpg]


[FADEOUTBGM]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono030"]
[OnName num="monono"]
"Aren't you extremely afraid of being different from everyone else?"
[cpg cn=true]


She starts attacking me.
[cpg]

[BGM f="bg_as"]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono031"]
[OnName num="monono"]
What is fun and what is boring...it depends on each person. We all have different values.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono032"]
[OnName num="monono"]
People with the same values naturally get together. That's how a community is formed.
[cpg cn=true]


[VOICE f="Monono033"]
[OnName num="monono"]
So it's like a group of like-minded people. That's why it's fun to do things together.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono034"]
[OnName num="monono"]
To put it simply, friends, I guess. If you want to make friends, you should look for people who are like you. I think you should start with people of the same sex.
[cpg cn=true]


[OnName num="takuma"]
Ummm, yes. ......
[cpg cn=true]


Would it be a good idea to do so? I'm not quite sure what she's talking about.
[cpg]


The first thing you need to do is to find the right person.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono035"]
[OnName num="monono"]
What do seniors value about school life?　What is your idea of youth?　What on earth is it?
[cpg cn=true]


She spins her words as if she is reading my thoughts.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono036"]
[OnName num="monono"]
Club activities, study, love ......, doing what you can only do now and enjoying your youth.
[cpg cn=true]


[VOICE f="Monono037"]
[OnName num="monono"]
If you can't do that, you are a loser. I don't want to be a loser. I don't want to be a loser. I feel alienated, that I am different from everyone else. I don't even think I'm special. I think I'm a loser.
[cpg cn=true]



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono038"]
[OnName num="monono"]
There are many things you can't do when you grow up. But I didn't do anything during that period.
[cpg cn=true]

[VOICE f="Monono039"]
[OnName num="monono"]
"I don't want to be thought that way later. I don't want to be thought of as being at the bottom of the pile. I hate myself for thinking that."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono040"]
[OnName num="monono"]
I don't see myself in my seniors. That's why it's so flimsy. It's just a blip in the air."
[cpg cn=true]


[OnName num="takuma"]
「……」
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Monono041"]
[OnName num="monono"]
If you don't understand your own thoughts, your own desires... you won't be fulfilled.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono042"]
[OnName num="monono"]
Are you okay?　You look very sad.
[cpg cn=true]


It's no wonder she looks like this. The actuality is that the actuality is that you can't get a lot of these things.
[cpg]


I never thought that a junior would say something like that to me.
[cpg]


[FADEOUTBGM]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Monono043"]
[OnName num="monono"]
Are you scared of ......?
[cpg cn=true]


Yes, I am. I was scared of the unknown person in front of me.
[cpg]


[OnName num="takuma"]
Who are you...who are you...?"
[cpg cn=true]


I don't know who you are. I don't know this. Not the one I know.
[cpg]



;//【演出】
;//ものの立ち絵　元の立ち絵に変更

[BGM f="bg_sc"]
[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]


She smiles.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono044"]
[OnName num="monono"]
As you know, I'm ...... senior's pretty junior.
[cpg cn=true]


Oh, I see. It's the same. I finally understood that it's the same as when I was a senior at Soboho.
[cpg]


It was a side of her that she was showing me. I assumed that this was the kind of person she was.
[cpg]


No...I was interpreting it in my own convenient way.
[cpg]


I knew that, even though there was no way she would show me the depths of her belly.
[cpg]

[free time=1000]

[SE f="se002"]
;//【ＳＥ】『がたがた』





I hurry to put away the lunch I'm about to eat. I don't want to stay here anymore.
[cpg]


As I'm about to leave the classroom, I hear a voice on my back saying, "Oh, yes...
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Monono045"]
[OnName num="monono"]
"Oh, yes, yes..."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Monono046"]
[OnName num="monono"]
I like to look at people who are lower than me.
[cpg cn=true]


She told me about her hobby.
[cpg]


I would have liked to know a little earlier.
[cpg]


[OnName num="takuma"]
The devil..."
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se025"]
;//【ＳＥ】『走る』



I ran out of the classroom.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



[SE f="se003"]
;//【ＳＥ】『ぶつかる』





[OnName num="takuma"]
Ouch. ......
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue006"]
[OnName num="kozue"]
"Ouch ......, are you okay?"
[cpg cn=true]


I bumped into the teacher. The teacher, who was getting up, wouldn't take my hand.
[cpg]


For example, he gave me a slightly naughty vibe and said, "You have to be careful." ......
[cpg]


He could have said a sexy line.
[cpg]


[OnName num="takuma"]
"Damn it!"
[cpg cn=true]



;//梢の立ち絵　驚き、焦る





[FG f="CHA04_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Kozue007"]
[OnName num="kozue"]
What...wait a minute..."
[cpg cn=true]


[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kozue008"]
[OnName num="kozue"]
What's wrong?"
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Why am I falling so far short of my ideal?
[cpg]


The world hates me.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_as"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





Today was quite a shock. I arrived home in a daze, with my soul missing.
[cpg]


From that day on, I started having mysterious dreams.
[cpg]

I would talk to someone or something I didn't know who or what it was.
[cpg]

Is it me in the future, or is it my current deep mind, or is it someone ......
[cpg]

It will say to me, "You're still lonely because you're brooding like that."
[cpg]

...... I may not make it, I may not make it.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_to"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************




A few days from there. I took a break from school and headed to the hospital.
[cpg]

I was depressed because I kept having the dream.
[cpg]

I guess this kind of thing happens often. But the doctors took me seriously.
[cpg]

But ...... that didn't help the situation.
[cpg]


;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



;//【演出】
;//瞬きを目を開ける演出



[OnName num="takuma"]
"Hey, Sakura..."
[cpg cn=true]


I was remembering my former childhood friend. At the same time, I heard a voice from outside.
[cpg]


I was dizzy and was drawn toward the window.
[cpg]


I don't know why it's her.
[cpg]


But when I was in trouble, the first thing that came to mind was Sakura.
[cpg]


Conveniently, selfishly. I found my childhood friend.
[cpg]


I ran out of the room.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



;//【演出】
;//画面を揺らす演出　叫ぶ感じ





[OnName num="takuma"]
"Oh, Sakura!
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sakura008"]
[OnName num="sakura"]
Oh, my God!　I was startled. What's with you all of a sudden?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura009"]
[OnName num="sakura"]
What are you doing dressed like that?　I thought you didn't work today.
[cpg cn=true]


She was surprised to see me running out of the house in my nightgown.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sakura010"]
[OnName num="sakura"]
She was surprised to see me running out of the house in my nightgown.
[cpg cn=true]


I was surprised to see me running out of the house in my nightgown, and she was also surprised to see me.
[cpg]



;//ブラックアウト

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_to"]
;//[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura011"]
[OnName num="sakura"]
I was surprised to see her.　What happened?
[cpg cn=true]


[OnName num="takuma"]
"Well, actually...I'll tell you what happened."
[cpg cn=true]


I told her about the dream I had yesterday. Sakura listened to me in silence.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sakura012"]
[OnName num="sakura"]
I see," she said, "I see. Well, I guess that can happen."
[cpg cn=true]


[OnName num="takuma"]
Sakuraaaa...... help me......"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura013"]
[OnName num="sakura"]
I wish I could help you, but I can't.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sakura014"]
[OnName num="sakura"]
I can't do anything, I'm sorry.
[cpg cn=true]


That's right. I'm not a doctor and I can't ask you to help me.
[cpg]


I couldn't help but ask for help. I couldn't help but to speak my mind.
[cpg]


I didn't care who or what you are, just help me.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura015"]
[OnName num="sakura"]
What about Takuma?
[cpg cn=true]


[OnName num="takuma"]
I don't know. I don't know. ......
[cpg cn=true]


I don't know what to do, but I don't have an answer right now.
[cpg]


I'm in an ongoing state of confusion.
[cpg]


[OnName num="takuma"]
I think if I'm not lonely, I won't have to have that dream .......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sakura016"]
[OnName num="sakura"]
Because you don't want to have that dream?　No?
[cpg cn=true]


[OnName num="takuma"]
"Well, that's..."
[cpg cn=true]


I was slurring my words.
[cpg]

[OnName num="takuma"]
I don't know, but I don't want to be alone. ......
[cpg cn=true]


[OnName num="takuma"]
I want Sakura to be by my side."
[cpg cn=true]


I say something that sounds like a confession. Sakura looks a little embarrassed, but looks at me.
[cpg]


;//【演出】
;//立ち絵を引きからアップへ


[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sakura017"]
[OnName num="sakura"]
Takuma...do you like me?"
[cpg cn=true]


[OnName num="takuma"]
I like you so......... much."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura018"]
[OnName num="sakura"]
I feel like I'm being made to say it.
[cpg cn=true]


I don't miss that there was a pause.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura019"]
[OnName num="sakura"]
The first time you come to me... you probably have at least some feelings for me.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura020"]
[OnName num="sakura"]
Takuma is all about himself.
[cpg cn=true]


Why am I being so angry with him?
[cpg]


It's supposed to be pretty. Why is he being driven away?
[cpg]


Somehow I couldn't look at my childhood friend's face, which looked sadder than mine.
[cpg]


[OnName num="takuma"]
I'm sorry..."
[cpg cn=true]

[FADEOUTBGM]
I decided to leave.
[cpg]



Then, I heard a voice saying.
[cpg]



[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura021"]
[OnName num="sakura"]
"Then let's play ......."
[cpg cn=true]


[BGM f="bg_to"]
[OnName num="takuma"]
"Let's play...?"
[cpg cn=true]


I was about to leave when he said something to me. It was something I didn't understand.
[cpg]


What in the world was he talking about?
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura022"]
[OnName num="sakura"]
If you want something from your partner, you have to take a risk. The more one-sided it is, the more..."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura023"]
[OnName num="sakura"]
If Takuma wins, I get what I want. If he loses, I get what I want. What do you think?
[cpg cn=true]


[OnName num="takuma"]
What's that?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura024"]
[OnName num="sakura"]
"Just like you said. If I win, well... you have to obey my orders for the rest of your life!
[cpg cn=true]


The young friend said with a determined look on her face.
[cpg]


Hey, don't point fingers at people.
[cpg]


[OnName num="takuma"]
If I win...
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sakura025"]
[OnName num="sakura"]
Yes," he said. I'll stay by your side as you wish.
[cpg cn=true]



So you're giving her a chance to become your girlfriend because you feel sorry for her.
[cpg]


Is that normal? No, even if you think it's normal, that's a pretty good concession.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura026"]
[OnName num="sakura"]
"Let's play for what's important to both of us. Can you do that?"
[cpg cn=true]


What could be better than that? It's normal to end up turning me in to the police. ......
[cpg]


[OnName num="takuma"]
"Yeah, okay.
[cpg cn=true]


I'm on the edge. I'm on the precipice.
[cpg]


Even if I don't lose, my life could end. No, it's over.
[cpg]


If I have to take orders for the rest of my life, my life is half over.
[cpg]


Then... let's put it on the line.
[cpg]


My life. My future. My life.
[cpg]


[OnName num="takuma"]
I'll take it!
[cpg cn=true]


I'm over it!　I'm over it!
[cpg]


I'm finally ready to face the end.
[cpg]


I won't lie to myself. I will not lie to my desires anymore.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『空』（夜）******************************************************



;//【演出】
;//下から上に向かってカメラ移動しながら夜空に切り替わる





A battle for willpower, pride, youth...and life.........
[cpg]


Such a battle had begun.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_co"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





A few days later. I was called by Sakura.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sakura027"]
[OnName num="sakura"]
You're here.
[cpg cn=true]


An empty classroom after school. I was supposed to meet her there.
[cpg]

[free time=1000]
[WAIT time=1000]
[OnName num="takuma"]
"What...what's this all about?"
[cpg cn=true]




[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/4" time=800]
[VOICE f="Monono047"]
[OnName num="monono"]
"Hello, senior.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/4" time=800]
[VOICE f="Miku032"]
[OnName num="miku"]
Hello..."
[cpg cn=true]

[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="4/4" time=800]

It was not just the two of us. It was not only Sakura, but also senpai, senpai, and Kozue-sensei were there.
[cpg]


I didn't think it was just the two of them.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/4" time=800]
[VOICE f="Sakura028"]
[OnName num="sakura"]
These three are going to be there too.
[cpg cn=true]


[OnName num="takuma"]
What?
[cpg cn=true]



;//設定
;//心根では宅磨の事をまだ好きな桜
;//宅磨のために力を貸して欲しいと他ヒロインに頭を下げお願いした
;//個別ルート後に上記シーンを追加





I was so upset by their unexpected participation that I couldn't help but be upset.
[cpg]


Maybe it's a happy event for me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/4" time=800]
[VOICE f="Sakura029"]
[OnName num="sakura"]
I told them about Takuma and they said they would help me.
[cpg cn=true]


[OnName num="takuma"]
Oh, you can't just do that!
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/4" time=800]
[VOICE f="Sakura030"]
[OnName num="sakura"]
It's better to have more than one of me, isn't it?
[cpg cn=true]


[OnName num="takuma"]
I'm not going to say anything about it.
[cpg cn=true]


I couldn't say anything back because he was right.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="3/4" time=800]
[VOICE f="Monono048"]
[OnName num="monono"]
He was right, so I couldn't say anything back to him. Why didn't you tell me?
[cpg cn=true]


[OnName num="takuma"]
"You...you..."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/4" time=800]
[VOICE f="Monono049"]
[OnName num="monono"]
I'll give a helping hand to the poor senior who can't sleep because of his dreams.
[cpg cn=true]


The language is still the same. Maybe he's just embarrassed.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/4" time=800]
[VOICE f="Miku033"]
[OnName num="miku"]
Takuma...I will cooperate with you as much as ...... I can."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/4" time=800]
[VOICE f="Sakura031"]
[OnName num="sakura"]
Senior, it's not cooperation, it's competition. Don't forget.
[cpg cn=true]


[FG f="CHA04_p1_01_a.ui" method="change_7"  pos="4/4" time=800]
[VOICE f="Kozue009"]
[OnName num="kozue"]
Why do I have to help you too?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/4" time=800]
[VOICE f="Sakura032"]
[OnName num="sakura"]
Why did you do that?　I'm sorry!
[cpg cn=true]


[FG f="CHA04_p1_01_a.ui" method="change_4"  pos="4/4" time=800]
[VOICE f="Kozue010"]
[OnName num="kozue"]
I'm sorry!　I'll join you!
[cpg cn=true]


Sensei...is Sakura holding something against me?
[cpg]


Hmmm, but... either way, it opens up the possibility of four women for me.
[cpg]


Much better than just one.
[cpg]


[OnName num="takuma"]
So, what's the game in the end?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/4" time=800]
[VOICE f="Sakura033"]
[OnName num="sakura"]
"......, I've been thinking, what about making the other person your dream guy?"
[cpg cn=true]



[OnName num="takuma"]
What do you mean, ......?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/4" time=800]
[VOICE f="Sakura034"]
[OnName num="sakura"]
"Good?　What do you mean?
[cpg cn=true]



;//【演出】
;//システム画面を出しながら絵で説明


[free time=1000]


To summarize Sakura's story.
[cpg]


I propose a game to one of the four of them. At the same time, I make a request to the other person.
[cpg]


The winner gets what they want.
[cpg]


In the end, the winner is the one who drinks more of the other's demands, and is more in line with the other's ideals.
[cpg]


Which of the two will be more in line with the other party's ideals? That is how the final victory or defeat is decided.
[cpg]





[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura035"]
[OnName num="sakura"]
That's what I mean. Do you understand?
[cpg cn=true]


I was about to say, "What's that?
[cpg]

But there was no use in getting my navel bent at this point.
[cpg]

[OnName num="takuma"]
"Yes, I understand."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="3/3" time=800]
[VOICE f="Monono050"]
[OnName num="monono"]
What did you understand?　I don't understand at all.
[cpg cn=true]


I was about to say what I really thought.
[cpg]


In any case, this is how one page of my glorious youth started ......
[cpg]


Did it start ......?
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//【演出】
;//アイキャッチ絵を出して
;//桜のタイトルコール
;//切り替わりを演出



;//導入部分終了
;//==========================================
;//==========================================
;//==========================================
;//==========================================
;//==========================================


[jump storage="ep001.ks" target="*start"]

