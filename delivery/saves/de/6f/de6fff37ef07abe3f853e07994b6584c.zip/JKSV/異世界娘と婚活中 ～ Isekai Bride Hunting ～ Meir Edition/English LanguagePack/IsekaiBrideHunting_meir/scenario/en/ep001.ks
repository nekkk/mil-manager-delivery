

;=========================================================================================

*start

*ep001|A Journey Around the World

[SCENE id=1]

[stflag Cha1flg=1]
[stflag Cha2flg=0]
[stflag Cha3flg=1]
[stflag Cha4flg=0]

[stflag Cha2flg_s=0]
[stflag Cha3flg_s=0]
[stflag Cha4flg_s=0]



[window target=false]

[STOPBGM]

[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[free time=1]
[BG f="b_10_1.ui" time=11]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



And the next morning. I was allowed to stay at Meir's house for a while.
[cpg]


It was natural considering what I had done, but I didn't really feel it.
[cpg]


I was in a daze, thinking about it.
[cpg]


[OnName num="kousuke"]
It's kind of a peaceful place. ......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile004"]
[OnName num="meile"]
It's a holiday today. Everyone is not supposed to be working in the fields today,...... maybe.
[cpg cn=true]


Maybe it's because I've been asleep for so long.
[cpg]


But it's a farming village to see. It's strange to see a beastman farming. ......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile005"]
[OnName num="meile"]
But your brother is a strange man. It's like he has a whiff of our world, or something.
[cpg cn=true]


[OnName num="kousuke"]
What's that? ......
[cpg cn=true]

[window target=false]
[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]


[BG f="b_10_3.ui" time=1000]
[WAIT time=1500]

[WAIT time=100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



The first thing to do is to go around the village and try to find a way to get back to Japan.
[cpg]


It is said that this is a rural area in the land of the beastmen.
[cpg]


The airport is in the city. But ......
[cpg]


I can't help it if I go there. I've been smuggled into Japan twice.
[cpg]


I don't think I can go to the airport and go back to Japan properly.
[cpg]



;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く

[BG f="b_10_3_up_l.ui" time=1000]
[WAIT time=1500]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]

[WAIT time=1000]

[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile006"]
[OnName num="meile"]
You are thinking too much. If you're in trouble, why don't you just ask someone for help?"
[cpg cn=true]


I came back to my house and was greeted by Mail.
[cpg]


[OnName num="kousuke"]
I came back to my house and was greeted by Maille, who asked me, "Where are your parents?　Aren't they on holiday today?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile007"]
[OnName num="meile"]
'They're at church. It's a holiday."
[cpg cn=true]


You go to church in the evening? I wonder if it's a different culture.
[cpg]


[OnName num="kousuke"]
"You're not going to the mail?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile008"]
[OnName num="meile"]
I have more important things to do, you know, like ......."
[cpg cn=true]


He invites me over to his house. I was wondering what was going on.
[cpg]



[window target=false]

[free time=1000]

[WAIT time=1000]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1500]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=100]
;//ブラックアウト

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


[window target=true]


[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1000]


;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

I'm not sure what it is, but I'm sure it's something that I'm going to have to do.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile009"]
[OnName num="meile"]
I've been acting strange ever since I met you.
[cpg cn=true]


[OnName num="kousuke"]
What do you mean, strange?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Meile010"]
[OnName num="meile"]
I've never felt this way before. I've never felt this way before.
[cpg cn=true]


...... again. The first thing to do is to make sure that you have a good idea of what you're getting into. I've never felt this way before.
[cpg]


The most important thing to remember is that you can't just go out and buy a new car.
[cpg]


I'm not a romantic person, but she's in love with me. ......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile011"]
[OnName num="meile"]
"What's wrong, don't you weird-looking ...... people ever get happy when people say these things to you?"
[cpg cn=true]


[OnName num="kousuke"]
No, no,......
[cpg cn=true]


It's not a good idea to be too speculative in different parts of the world when you are going back to Japan after all.
[cpg]


But the original purpose is to get a subhuman wife, right?
[cpg]


If you ask me if Meir is my type, I think she's cute.
[cpg]


Well, what should I do: ......
[cpg]





;//■選択肢
[switch]
[case "I'm going to hit on Meir."]
	[swap]
	[jump target="*IseSel01_1"]
[case "Nothing to do."]
	[swap]
	[jump target="*IseSel01_2"]
[endswitch]




1, seduce the maille.
2, do nothing



;//==============================
;//１、メイルを口説く
*IseSel01_1|A Journey Around the World


;//ヒロイン２が攻略対象になる
[stflag Cha2flg_s=1]



[OnName num="kousuke"]
'You're not talking to ...... anyone, are you?'
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile012"]
[OnName num="meile"]
'Of course. I told you I've never felt this way.
[cpg cn=true]


[OnName num="kousuke"]
I started my journey because I wanted a subhuman wife.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile013"]
[OnName num="meile"]
Then I think we'd be a good match, wouldn't we?
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ
[FG f="CHA02_p7_01_a.ui" method="change_6"  pos="2/3" time=800]


The first time I saw him, I thought he was a good man.
[cpg]


[VOICE f="Meile014"]
[OnName num="meile"]
I'm sure you'll find that it smells ...... good and calms you down.
[cpg cn=true]

;//＠
[FACE method="change_6" pos="2/3"]
[VOICE f="sMeile001"]
[OnName num="meile"]
...... hey, can I go to bed like this?"
[cpg cn=true]


I wonder if I can do this. That's what I thought at the time of Fia.
[cpg]


But there was a part of me that wondered if the sinfulness of it would be any different now. ......
[cpg]

;//Ｈシーンカット


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト

[jump target="*IseSel01_3"]

;//==============================
;//２、何もしない
*IseSel01_2|A Journey Around the World




[OnName num="kousuke"]
"......After all, I'm not even a lover, I can't do it."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile073"]
[OnName num="meile"]
"Eww,...... don't embarrass a girl."
[cpg cn=true]


[OnName num="kousuke"]
I don't care what they say, I won't do it. I'm not that unprincipled."
[cpg cn=true]


I waited for her parents to come home while I had this exchange with Maille.
[cpg]



;//==============================

*IseSel01_3|Traveling Around the World


[window target=false]

[free time=1000]

[WAIT time=1000]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4_up_l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************


[window target=true]



Later, Meir's parents came home.
[cpg]


They served me dinner again. ...... I felt sorry for them, but I knew I had to find a way to get back to Japan as soon as possible.
[cpg]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************


[window target=true]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1500]


Gathering information. To that end, I went to the beastmen's village and asked around,.......
[cpg]


[OnName num="therianthropy_girl_A"]
Hey,......, you smell good.
[cpg cn=true]


[OnName num="therianthropy_girl_B"]
"Really,......, and you don't look like a normal guy.
[cpg cn=true]


I was getting a lot of attention. I had never experienced anything like this before.
[cpg]


[OnName num="therianthropy_girl_A"]
I've never experienced anything like this before.　I have some delicious herbal tea.
[cpg cn=true]


[OnName num="therianthropy_girl_B"]
"Oh, that's not fair!　I'll go first.
[cpg cn=true]


[OnName num="kousuke"]
But tell me how to get back to Japan.
[cpg cn=true]


Unlike the elven countries, they seem to be more uninhibited in their love affairs.
[cpg]


I was thinking that I would never make it back to Japan, but I was also happy to be in a harem-like situation.
[cpg]


[window target=false]
[BG f="b_10_3.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]

[BG f="b_10_3_up_l.ui" time=1000]
[WAIT time=1000]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]
[WAIT time=1000]


Evening comes again. I know that as long as I stay here, I am safe, but if I stay like this, there will be no progress.
[cpg]


[OnName num="meile_mother"]
'Well, ...... if you head north from here, there is a settlement where the harpies live, but it's not there.'
[cpg cn=true]


[OnName num="kousuke"]
I see. ......
[cpg cn=true]


Harpies. They are a race of bird people, aren't they?
[cpg]


If they are located in the northern part of the country, can they return to Japan from there?
[cpg]


[OnName num="kousuke"]
Thank you for telling me. I'm going to head for the harpy settlement.
[cpg cn=true]


[OnName num="meile_mother"]
I see. It's quite a distance, so you might want to bring some food with you.'
[cpg cn=true]


Saying so, Meir's mother prepares a lot of things for us. I'm sorry.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile074"]
[OnName num="meile"]
You're really going!　No, Kosuke, you're going to stay here forever."
[cpg cn=true]


[OnName num="kousuke"]
That's not how it's going to be. ...... The elf's pursuers might be getting closer.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile075"]
[OnName num="meile"]
The other kids will stop too, they all say Kosuke is so cool.
[cpg cn=true]


The most important thing to remember is that you can't just go out and buy a new one. I was thinking ......
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile076"]
[OnName num="meile"]
I'm not sure if it's a good idea, but I'm sure it's a good idea. Please.
[cpg cn=true]


[OnName num="kousuke"]
......, I don't have a choice."
[cpg cn=true]

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1000]

;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]


That's why I stayed at Meir's house today.
[cpg]


[OnName num="kousuke"]
......"
[cpg cn=true]


But I decided to slip out. Some say it's simply bad to stay long.
[cpg]


I'm not sure if it's a good idea to stay longer than I have to, but I don't want the elves to come after me and bother the girls.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[STOPBGM]

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


[WAIT time=1000]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[BG f="b_09_1.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『草原』（朝）******************************************************


[window target=true]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1000]

So, I had left before the mail woke up.
[cpg]


I knew that they would say this and that when we parted.
[cpg]


[OnName num="kousuke"]
But it's a big place. ......
[cpg cn=true]


I didn't even know how far I had to walk to get to the harpy village.
[cpg]


There was something like a sign. I could barely read the numbers.
[cpg]


I could somehow tell how much more I had to walk to reach the next village or town.
[cpg]


It looks like we will have to stay in the field for a day. ......
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[window target=false]

[BG f="b_09_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『草原』（昼）******************************************************


[window target=true]


;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

Walking all day is not easy.
[cpg]


It is hard on my back. If I keep doing this, I'm going to have more chronic diseases by the time I get to Japan.
[cpg]


But now I am being treated as a criminal. Besides, I have to get back to Japan before work starts.
[cpg]


Thinking about it, I couldn't help but walk.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_09_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


[window target=true]



And I had to camp out on the road.
[cpg]


I was afraid of running out of food, but I was even more afraid of being caught by the elves.
[cpg]


[OnName num="kousuke"]
...... hmm?"
[cpg cn=true]


I was about to go to sleep when I felt someone appear in front of me.
[cpg]


As I was thinking ...... in this empty plain, a devilish silhouette appeared.
[cpg]



;//クロロウルードの名前を「悪魔」と隠してください





[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1500]
[WAIT time=2000]
[VOICE f="Clolowlude001"]
[OnName num="devil"]
I thought to myself, "...... what is it? Don't look at me like you're curious.
[cpg cn=true]


No, that's my line. The demon-like silhouette was looking down at me.
[cpg]


[OnName num="kousuke"]
What are you, ......?
[cpg cn=true]



;//クロロウルードの名前を表示してください





[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude002"]
[OnName num="clolowlude"]
I am Chlor-Urudo. I am a demon from the underworld.
[cpg cn=true]


[OnName num="kousuke"]
...... I see."
[cpg cn=true]


I would have been more surprised if it were true, but all I could think was, "I see. I never thought I'd meet a demon. ......
[cpg]


It's something I never thought I'd experience, but I've been through so much already.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude003"]
[OnName num="clolowlude"]
You should be more surprised.
[cpg cn=true]


[OnName num="kousuke"]
I'm sleepy. Not now.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude004"]
[OnName num="clolowlude"]
So you're the guy ...... Chartier was talking about?　Really?
[cpg cn=true]


What is the word after "really"?
[cpg]


[OnName num="kousuke"]
What do you want from me?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude005"]
[OnName num="clolowlude"]
What do you want from me?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude006"]
[OnName num="clolowlude"]
I don't know where you're going, but the country's a big place to ...... walk.
[cpg cn=true]


[OnName num="kousuke"]
Well, that's, well... ......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude007"]
[OnName num="clolowlude"]
I'm a demon, I can do magic. You might be interested in me a little bit, right?
[cpg cn=true]


[OnName num="kousuke"]
You're going to send me back to Japan?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude008"]
[OnName num="clolowlude"]
The magic of transferring is instantaneous. But it also consumes a great deal of magic power, so you can't use it unnecessarily.
[cpg cn=true]


What is it? The most important thing to remember is that you can't just take a few minutes to do a little bit of research.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude009"]
[OnName num="clolowlude"]
I turned my back on her.　You're being too obvious.
[cpg cn=true]


[OnName num="kousuke"]
You're not going to let me go, are you, Chloro?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude010"]
[OnName num="clolowlude"]
Don't call me chloro. Don't call me Chloro.
[cpg cn=true]


[OnName num="kousuke"]
Whatever it is, I've got nothing more to do with you. Let me sleep.
[cpg cn=true]


Coughing, Chloro clears his throat. And ......
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude011"]
[OnName num="clolowlude"]
My ancestors have served the Demon King for generations.
[cpg cn=true]


[OnName num="kousuke"]
A Demon King?　What's a Demon King? I've never heard of such a thing.
[cpg cn=true]


Even though I have merged with another world, I have never known of the existence of a Demon King.
[cpg]


The actuality that there is no such a thing as a "Demon King" is a good thing.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude012"]
[OnName num="clolowlude"]
I wonder if ...... that would be such a reaction. Well, okay."
[cpg cn=true]


What's good about it? I have no idea what's good for me.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude013"]
[OnName num="clolowlude"]
If you go back four generations in my family, you'll find that some demons were queens of demon kings.
[cpg cn=true]


[OnName num="kousuke"]
So, what's the point? I don't understand what you're bragging about.
[cpg cn=true]


I said frankly, but Chloro did not stop speaking.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude014"]
[OnName num="clolowlude"]
''The great astrologer of the demon tribe also does this kind of fortune-telling.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude015"]
[OnName num="clolowlude"]
'He said that I would be the new Demon Queen,...... so I've always had a longing for the new Demon Queen.
[cpg cn=true]


[OnName num="kousuke"]
I don't see what you're talking about. Just get to the point.
[cpg cn=true]


The next day, he still couldn't understand why he was blushing or why he was stuttering.
[cpg]



[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_09_2.ui" time=1000]

[WAIT time=1100]
;//【ＢＧ】『草原』（昼）******************************************************

[window target=true]




The next day, he was still following me.
[cpg]


[OnName num="kousuke"]
What do you want from me after all?
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Clolowlude016"]
[OnName num="clolowlude"]
I'm just trying to figure out. I'm trying to figure out if you're the right person for me.
[cpg cn=true]


[OnName num="kousuke"]
Don't tell me you're in love with me too, ......."
[cpg cn=true]


He didn't answer anything. The actuality is that the actuality is that the actuality is not really a good thing.
[cpg]

[free time=800]

He's acting like he has a thing for me. The most important thing to remember is that you can't just take a chance on a new girl and expect her to be happy.
[cpg]


Last night, he said something about a new Demon Queen. ......
[cpg]


I wonder what the new queen of the Demon King is. I don't know what the new Demon King is referring to either.
[cpg]


[OnName num="kousuke"]
I don't know what you mean by "new Demon King," was it?　If I'm going to be his queen, shouldn't I go to him?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude017"]
[OnName num="clolowlude"]
Yes, that's why I'm following you. That's why I'm following you.
[cpg cn=true]


[OnName num="kousuke"]
"You mean you're in ...... the Harpy settlement?"
[cpg cn=true]


What is it?
[cpg]

[window target=false]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]

[BG f="b_09_4.ui" time=1000]

[WAIT time=1000]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


[window target=true]



The night is coming again. Food is slowly dwindling and I'm feeling impatient,.......
[cpg]

[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
The fact that Kuroro was next to me helped support my feelings a little.
[cpg]


If I was about to starve to death, I thought that Kuroro would take care of it.
[cpg]


[OnName num="kousuke"]
I thought, "...... but why don't you use that magic you call transference magic?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude018"]
[OnName num="clolowlude"]
The reason why I can't send you back to Japan right away is for a number of reasons. You, after all, ......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude019"]
[OnName num="clolowlude"]
You have a strange charm about you. I don't know what you are talking about.
[cpg cn=true]


I don't know what you are talking about. The first thing to do is to find out what the problem is.
[cpg]





;//■選択肢
[switch]
[case "What are pheromones?"]
	[swap]
	[jump target="*IseSel02_1"]
[case "I can't wait to go back to Japan."]
	[swap]
	[jump target="*IseSel02_2"]
[endswitch]



One, what are pheromones?
2, I want to go back to Japan as soon as possible.



;//==============================
;//１、フェロモンって何だ？


*IseSel02_1|Traveling Around the World


;//ヒロイン４が攻略対象になる
[stflag Cha4flg_s=1]



[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude020"]
[OnName num="clolowlude"]
You don't get it?　Well, if you don't know, that's okay. I'm not going to explain it all to you.
[cpg cn=true]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

;//========================================
;//●ＣＧエロ（ヒロインに迫られる。至近距離）ev_07
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：私服
;//場所　：草原
;//時間　：夜
;//========================================

*Scene000|A Journey Around the World

[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]

[STOPBGM]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=100]

She moved her face closer to mine. She sniffed.
[cpg]


[OnName num="kousuke"]
'Hey, ......, you too?
[cpg cn=true]


[VOICE f="Clolowlude021"]
[OnName num="clolowlude"]
I'm sure you've been through a lot. I also ...... am attracted to you.
[cpg cn=true]


The first thing to do is to make sure that you have a good idea of what you're getting into. The most important thing to remember is that you can't just take a look at your own personal personal information.
[cpg]

[OnName num="kousuke"]
I'm not sure how she knows that I'm attracted to you. Just get away from me for now."
[cpg cn=true]

;**【ＣＧ】 ev_07_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sClolowlude002"]
[OnName num="clolowlude"]
I'd like to smell you a little more."
[cpg cn=true]

I'm going to be in over my head if she says that. All these things keep happening. ......
[cpg]



My body is not normal.
[cpg]


The most important thing to remember is that you can't just go out and get a good deal on a good deal on a good deal on a good deal on a good deal of things.
[cpg]


[OnName num="kousuke"]
I'm not sure what you're looking for," he said.
[cpg cn=true]

;**【ＣＧ】 ev_07_b ***********************
[CG id=2 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Clolowlude053"]
[OnName num="clolowlude"]
You don't even know it yourself, do you? How did you manage to live without it?
[cpg cn=true]


[OnName num="kousuke"]
Why don't you just tell me?
[cpg cn=true]


[VOICE f="Clolowlude054"]
[OnName num="clolowlude"]
Chartier will tell you.
[cpg cn=true]


What's the matter with you, ......, you don't want to tell me?
[cpg]


[VOICE f="sClolowlude003"]
[OnName num="clolowlude"]
But ...... if you can still get up, I'd like a little more time to talk.
[cpg cn=true]


[OnName num="kousuke"]
I'd like to know more about you. I want to know about me too."
[cpg cn=true]

;//＠
;[SceneEnd f="sc_005"]

;//ブラックアウト

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="heart.webp" color={0x000000ff} time=1]

[WAIT time=1100]

[BG f="b_09_4.ui" time=1000]

[BGM f="bg_d3"]
[WAIT time=1000]
;//【ＢＧ】『草原』（夜）******************************************************


[window target=true]



After that, Chloro didn't let me sleep. I don't mean that in a funny way.
[cpg]


He seemed to have something he wanted to tell me. Chloro starts talking about Chartier.
[cpg]

[jump target="*IseSel02_3"]

;//==============================
;//２、早く日本に帰りたい

*IseSel02_2|Traveling Around the World



[OnName num="kousuke"]
I want to go back to Japan as soon as possible. Please let me go back.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude086"]
[OnName num="clolowlude"]
It's easy to use the magic of transfer," he said. But I won't let you.
[cpg cn=true]


[OnName num="kousuke"]
What, ......, you have feelings for me?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude087"]
[OnName num="clolowlude"]
Don't be so presumptuous. I'm not ...... wrong, though.
[cpg cn=true]


So what's that ...... nobody seems to be attacking me because I'm subhuman.
[cpg]


Is there something wrong with my body?
[cpg]



;//==============================


*IseSel02_3|A Journey Around the World


[OnName num="kousuke"]
"...... Oh, by the way, you said your name was Chartier. Who's that?"
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Clolowlude088"]
[OnName num="clolowlude"]
You've met him before, haven't you?　She's the one who put you on the airship.
[cpg cn=true]


She's right, isn't she? And it seems that Chloro is acquainted with Chartier. ......
[cpg]


Then there is the fastest way to get back to Japan.
[cpg]


[OnName num="kousuke"]
"If you can, please tell Chartier ...... that I want to go back to Japan."
[cpg cn=true]


[OnName num="kousuke"]
With that airship, you should be able to go back to Japan.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude089"]
[OnName num="clolowlude"]
I can put you on the airship, but I'm afraid it will take you to another country, don't you think?"
[cpg cn=true]


[OnName num="kousuke"]
Why ......?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude090"]
[OnName num="clolowlude"]
Chartier would never let you go back to Japan.
[cpg cn=true]


I don't know what you are talking about. But ......
[cpg]


I would have to go back to Japan in something other than Chartier's flying boat.
[cpg]

[window target=false]

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_09_1.ui" time=1000]
[WAIT time=1100]
;//【ＢＧ】『草原』（朝）******************************************************


[window target=true]



I wanted to ask him many questions. But I couldn't overcome sleepiness, and by the time I woke up, Kuroro was gone.
[cpg]


I walked along the road, still not knowing what was going on.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************



;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1000]


The food was gradually running out. At that time, I came across three beast women who seemed to be on a journey.
[cpg]


[OnName num="kousuke"]
They said, "Please, can you share your food with us?
[cpg cn=true]


[OnName num="therianthropy_girl_A"]
"What is this ...... guy?
[cpg cn=true]


[OnName num="therianthropy_girl_B"]
Do you feel it too?　I feel strange.
[cpg cn=true]


Again. I don't care what you have to say about that anymore, just give me some food. ......
[cpg]



[window target=false]

[BG f="b_09_3.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『草原』（夕方）******************************************************

[window target=true]




I was in a shambles, almost attacked by the occasional beastie, and kept looking for someone who would let me go back to Japan.
[cpg]


Finally, I found ......
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[STOPBGM]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（夕方）******************************************************

[window target=true]




[OnName num="kousuke"]
Here, here ......."
[cpg cn=true]


I arrived at the village where the Harpies live. This must be where the harpies live.
[cpg]


Harpies have wings. If I did well, they might let me go back to Japan.
[cpg]



[SE f="se001"]
;//【ＳＥ】『倒れる』





But then I ran out of energy and collapsed.
[cpg]


I thought dimly that people really collapse when they are tired.
[cpg]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="e_01_3.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





In the meantime, I had a dream. I wasn't asleep, I was in a coma, but I had a dream.
[cpg]


There is someone next to me. I don't know who it is.
[cpg]


I mean, I don't even know who I am. The clothes I see from my point of view are not my sense of style.
[cpg]


The dream is as if I am someone else. It was a hazy, yet strangely deja vu-like scene.
[cpg]


I'm in a place that looks like a castle...... maybe it's not Japan.
[cpg]


I wonder where ...... many subhumans are kneeling down to me.
[cpg]


I was being treated as if I were a king or something.
[cpg]



;//画面白く

[BG f="white.ui" time=1000]
[WAIT time=100]

[STOPBGM]

I wake up in a hazy state of confusion.
[cpg]


The next time I woke up, I was indoors.
[cpg]


Someone's house, tucked into bed.
[cpg]




[window target=false]

[transition target={true} rule="tobira2.png" color={0xffffffff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira2.png" color={0xffffffff} time=1000]

;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く

[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（朝）******************************************************

[window target=true]



[WAIT time=1100]


I got up and went outside and met a harpy woman.
[cpg]


[OnName num="harpy_A"]
She said, "Oh, you're ...... awake, aren't you?
[cpg cn=true]


[OnName num="kousuke"]
'...... you're the one who helped me?
[cpg cn=true]



[OnName num="harpy_A"]
"Well, I found ...... another person, but my room was empty and ......
[cpg cn=true]


I guess you could call that helping, too.
[cpg]


In any case, it seems that harpies are mild-mannered.
[cpg]


I'm glad they're not the kind of people who would strip a fallen person of his or her clothes. But I don't think there is anything to take from me.
[cpg]


[OnName num="kousuke"]
Thank you for your kindness.
[cpg cn=true]



[OnName num="harpy_A"]
"Oh no, I didn't thank you, I just did what I ...... had to do."
[cpg cn=true]


[OnName num="harpy_B"]
Oh!　You're awake, you know who ......
[cpg cn=true]


[OnName num="harpy_C"]
How are you feeling?　Are you hungry?"
[cpg cn=true]


When they see me and her talking, other harpies come up to us. It's all women.
[cpg]


There may have been male harpies, but they never came to me.
[cpg]


I had never been so popular with humans.
[cpg]


I felt something strange, but I didn't know what it was.
[cpg]


[OnName num="harpy_B"]
It's not good to keep to yourself.
[cpg cn=true]


[OnName num="harpy_C"]
Come over to my house and I'll treat you to breakfast.
[cpg cn=true]


[OnName num="harpy_A"]
Hey, hey, hey!
[cpg cn=true]


The first girl I met was also losing, and she was pulling my hand. We were fighting over her hand.
[cpg]


[OnName num="kousuke"]
Don't pull me away. ......
[cpg cn=true]


This strange feeling has been there ever since I arrived here in the land of the subhuman.
[cpg]


Why is this happening? The answer to this question is hard to find.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（昼）******************************************************


;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1100]

After that, I walked around the village of the Harpies for a while.
[cpg]


I tried to make a plan to return to Japan.
[cpg]


The men in the village were sympathetic, but not kind.
[cpg]


Only women. Only women are kind to me. ......
[cpg]


But then, I should have relied on women.
[cpg]


I had a lot to think about, but it looked like I wouldn't have to worry about food for a while.
[cpg]




[window target=false]

[BG f="b_01_3.ui" time=1500]
[WAIT time=1500]
;//【ＢＧ】『ハーピー族の集落』（夕方）******************************************************

[window target=true]


Still, I couldn't find anyone who looked like her family. I wondered about that, so I asked her.
[cpg]

[OnName num="kousuke"]
"Does she live alone?"
[cpg cn=true]


[OnName num="harpy_A"]
Yes, but there's also my parents' house right near .......
[cpg cn=true]


[OnName num="kousuke"]
Why?　Why?"
[cpg cn=true]


[OnName num="harpy_A"]
I have to get married soon. ......
[cpg cn=true]



[OnName num="harpy_A"]
That's why my parents built their house first.
[cpg cn=true]


Is such a thing possible? I don't know, since the culture is probably different from human culture.
[cpg]


[OnName num="kousuke"]
I'm not sure if I can ...... stay at your house again today.
[cpg cn=true]



[OnName num="harpy_A"]
Yes, I do. I'm fine with it.
[cpg cn=true]


The expression on her face is one of embarrassment and her cheeks are strangely reddish.
[cpg]


The actuality is, it's as if she's in love with you. This is not normal, no matter how much I want to say.
[cpg]


[OnName num="kousuke"]
I'm not sure what you're talking about. What kind of state are you in right now?
[cpg cn=true]



[OnName num="harpy_A"]
What do you mean by that?
[cpg cn=true]


[OnName num="kousuke"]
I've seen this happen to subhumans many times before.
[cpg cn=true]


[OnName num="kousuke"]
What's wrong with me?　What do you see in me now?
[cpg cn=true]



[OnName num="harpy_A"]
"...... I can sense something magical in you, you don't seem like a ...... normal human being."
[cpg cn=true]


That's what they would say, but no matter how many times I thought about it, I couldn't remember.
[cpg]




[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=10]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（夜）******************************************************

[window target=true]
[WAIT time=100]

A few days after that. While spending time in the Harpy clan's village, this is what happened.
[cpg]


[OnName num="harpy_A"]
'...... the stars are beautiful, aren't they?
[cpg cn=true]


[OnName num="kousuke"]
Yes, they are. They don't look this beautiful in Japan.
[cpg cn=true]



[OnName num="harpy_A"]
'Um, Kosuke-san,...... I thought there was no such thing as love at first sight in this world.
[cpg cn=true]


See? This is what happens.
[cpg]


[OnName num="harpy_A"]
But when I saw Kosuke, I realized that it really does exist.
[cpg cn=true]


[OnName num="kousuke"]
Love at first sight?
[cpg cn=true]


Love at first sight, love at first sight, isn't that what everyone says?
[cpg]



[OnName num="harpy_A"]
I have a dead brother. Kosuke-san is just like my brother.
[cpg cn=true]



[OnName num="harpy_A"]
It's not that I was in love with my brother, but I feel very at home when I am with ...... you.
[cpg cn=true]


The most important thing to remember is that you can't just take a chance on a new person and expect them to be happy.
[cpg]


I'm not sure if I should accept it here.
[cpg]


Of course, it would be bad to cause trouble, but I was beginning to think that it didn't matter anymore.
[cpg]



I still want a subhuman wife, and my feelings haven't changed.
[cpg]


I don't feel bad about being courted by a girl.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_11_4.ui" time=1000]
[WAIT time=1000]

I couldn't do nothing, but I couldn't think of what to do.
[cpg]

If I were to kiss her, I was afraid something would happen.
[cpg]

[OnName num="harpy_A"]
What do you mean ......?
[cpg cn=true]

[OnName num="kousuke"]
No, if there is magic in my body, it could be transferred or ......
[cpg cn=true]

I'm speaking from my imagination, but I don't think I'm far off.
[cpg]

The actual "I'm not sure what to do with it, but I'm sure you'll be able to find a way to get rid of it.
[cpg]

;//Ｈシーンカット

[STOPBGM]

[WAIT time=1000]


[window target=false]

[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[BGM f="bg_tc"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（朝）******************************************************

[window target=true]



Then, early in the morning, I received some news.
[cpg]


[OnName num="harpy_B"]
Oh my God!　The elves are looking for Kosuke-san!
[cpg cn=true]


[OnName num="harpy_A"]
Is that so?　What on earth are you doing, Kosuke-san?
[cpg cn=true]


[OnName num="kousuke"]
No, it's a little ...... like a crime of passion.
[cpg cn=true]


I told him, "I don't think you'll be convinced. I decided to explain everything.
[cpg]


That I was seen as seducing an elf woman and that I was accused of it.
[cpg]


As I was listening to the story, the first girl I met looked a little glum, but well, that's going to happen,...... I know how you feel.
[cpg]


[OnName num="harpy_C"]
'What should we do, Mr. Kosuke,...... you should run away.
[cpg cn=true]


[OnName num="kousuke"]
I mean escape, but how?
[cpg cn=true]


I'm not sure how, but where would be more correct.
[cpg]



[OnName num="harpy_A"]
'You should run away to ...... Japan. You won't be able to get in right away from the land of the elves.
[cpg cn=true]


If I could do that, I wouldn't be struggling. I was thinking.
[cpg]



[OnName num="harpy_A"]
"Can't we, the Harpies, deliver Kosuke-san to Japan ......?"
[cpg cn=true]


[OnName num="harpy_B"]
I said, "......Yes, that would be a good idea. I don't know what would happen if we were caught by the elves.
[cpg cn=true]


[OnName num="kousuke"]
I'm not sure what would happen if the elves caught us.　I don't have any money.
[cpg cn=true]


[OnName num="harpy_C"]
You can pay for it later. You can pay us later, but for now, you can rely on us.
[cpg cn=true]


They are so kind to me that I don't know why they are doing so much for me.
[cpg]


But maybe ...... Chartier knows the reason.
[cpg]


[OnName num="kousuke"]
But ...... after all, it's impossible to ask them to carry us, we're too far away."
[cpg cn=true]


[OnName num="harpy_A"]
We harpies can use wind magic, so we can fly as fast as an airplane.
[cpg cn=true]


Is that so? That's new news to me. I mean, isn't it too fast to be as fast as an airplane ......?
[cpg]


[OnName num="harpy_B"]
Whatever the case, the sooner we get out of here, the better. What do you think?
[cpg cn=true]


[OnName num="kousuke"]
'Well, can you ask ......?'
[cpg cn=true]


[OnName num="harpy_A"]
Yes, I can. Yes, you can.
[cpg cn=true]



[BG f="black.ui" time=1000]
[STOPBGM]
;//ブラックアウト



[SE f="se001"]
;//【ＳＥ】『羽ばたく』

[WAIT time=2000]


[BG f="b_11_1.ui" time=1000]


[WAIT time=1000]

[BGM f="bg_d1"]


So, with the help of the three harpies, we were on our way back to Japan.
[cpg]


The posture was like being held in a hug. It's like the opposite of a piggyback.
[cpg]


It was wrapped in a unique cloth that looked like a larger version of the kind used for babies.
[cpg]


It was probably not possible to use it as an onbufu because of its wings.
[cpg]


And the fact that there are tools like this means that they may be doing this for a living.
[cpg]


I mean, if he fell, he would die. More to the point, don't harpies get tired?
[cpg]


[OnName num="harpy_A"]
'We don't get tired. We're a species that specializes in that ...... flying thing."
[cpg cn=true]


How is that possible? How is it possible to carry one person and not get tired of flying?
[cpg]


[free time=800]


I thought, "I'm not sure," but I was replaced by another harpy in the middle of the quagmire.
[cpg]


After repeating such a thing several times, Japan came into sight.
[cpg]


I was so relieved from the bottom of my heart that I almost cried.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="101.jpg" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="101.jpg" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（昼）******************************************************


;//＠
[SE f="se011"]
;//【ＳＥ】『人混み』


Probably Kyushu. When I got there, I saw a modern town.
[cpg]



[OnName num="harpy_A"]
......This is Japan. It's so close, but I've never been here."
[cpg cn=true]


[OnName num="harpy_B"]
I know," he said. Shall we do a little sightseeing?
[cpg cn=true]


[OnName num="harpy_C"]
I'd like to take a break.
[cpg cn=true]


[OnName num="kousuke"]
Wait a minute.
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



[SE f="se009"]
;//【ＳＥ】『走る』





I run to the nearest bank. Then I withdraw some money and come back to ......
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[WAIT time=1]
[STOPBGM]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（昼）******************************************************


[window target=true]

[WAIT time=100]


[OnName num="kousuke"]
Thank you for bringing it to me. If you can redeem it over there, use it."
[cpg cn=true]


I gave him so much money that it might not take much to fly, but I also thanked him for saving my life.
[cpg]


[OnName num="harpy_A"]
He said, "Thank you. But I'm glad it's just a feeling."
[cpg cn=true]


[OnName num="kousuke"]
I can't just say it's just a feeling. ...... Really, thank you for saving my life."
[cpg cn=true]



[OnName num="harpy_A"]
'Well then, we'll be here.
[cpg cn=true]


[OnName num="kousuke"]
Then ...... thank you so much for your help.
[cpg cn=true]



;//ブラックアウト

[window target=false]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『街＿現代』（夜）******************************************************

[window target=true]



By the time we got back home, it was midnight.
[cpg]


 It's a date, and I'm going to work from tomorrow...
[cpg]


[OnName num="kousuke"]
It was a close ...... call.
[cpg cn=true]


Really, just in time. I could have let it all go.
[cpg]



[free time=1000]
;//[BG f="black.ui" time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************



I feel like I've been through a lot, and I feel like I've had some good things happen.
[cpg]


In the end, I was able to smuggle myself in and sneak back out again.
[cpg]


I even managed to make it home for the vacations.
[cpg]


I was relieved, but thought about it again. What would it be like to marry a subhuman girl?
[cpg]


After all, differences in culture and race present a formidable barrier. I was chased by the elves.
[cpg]


To put it another way, there are the legal procedures and the customs of the other world's inhabitants. In a word, it is troublesome.
[cpg]


I decided to stay as an ordinary office worker for a while, thinking that I should quit after all.
[cpg]

[STOPBGM]
[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_03_1.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
;//【ＢＧ】『街＿現代』（朝）******************************************************


[window target=true]


The next morning, I headed to work, exhausted.
[cpg]


Work would not wait for me. I whipped my tired body.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





My co-workers asked me if I had lost weight. I guess I had lost weight.
[cpg]


There really was a lot more to it than one word can describe.
[cpg]


But in retrospect, ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

Fear. Maille. Chartier and Chloro......
[cpg]

[free time=800]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

They were all pretty or beautiful, but I guess I'll never see them again.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[free time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『街＿現代』（夕方）******************************************************

[window target=true]
[WAIT time=100]



I should have exchanged contact information with at least one of them. I don't even know if there is such a thing as contact information.
[cpg]


I wonder if they would have called me if I had given them my phone number, but do they have phones?
[cpg]


I returned home with an indescribable feeling.
[cpg]


I did manage to get some work done, but my heart was empty.
[cpg]


But my heart feels inexplicably empty.
[cpg]


I head for home, and when I get there, I find .......
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1500]
[STOPBGM]
;//ブラックアウト





[OnName num="kousuke"]
"......"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Fia056"]
[OnName num="fia"]
"......"
[cpg cn=true]


I froze at the front door. A familiar face was there.
[cpg]


[window target=false]

[free time=1000]
[WAIT time=1500]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************

[window target=true]




[OnName num="kousuke"]
"......, well, come on up.
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Fia057"]
[OnName num="fia"]
Sorry to bother you."
[cpg cn=true]


Fear. Why is she here?
[cpg]


[OnName num="kousuke"]
How did she get here? I mean, why?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Fia058"]
[OnName num="fia"]
"I've been wanting to meet you, Kosuke-san."
[cpg cn=true]


As I thought, she has an unusual way of being popular.
[cpg]


 To be loved so much by someone you only met once.
[cpg]


Even though I was surprised, Fia said that she wanted to meet me for a long time.
[cpg]


[OnName num="kousuke"]
What are you going to do? Are you staying here?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia059"]
[OnName num="fia"]
I'm prepared to stay in the field if you don't want me to.
[cpg cn=true]


[OnName num="kousuke"]
I can't let you do that. ......
[cpg cn=true]


I was feeling indescribable.
[cpg]


I can say that I have a subhuman lover, if not my dream subhuman wife .......
[cpg]


I'm also worried that the elves will come after me here again.
[cpg]


[OnName num="kousuke"]
My room, it's pretty big, isn't it? I think two or three people can stay here.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Fia060"]
[OnName num="fia"]
"Well, then, ......
[cpg cn=true]


[OnName num="kousuke"]
I'm sure two or three people could stay in my room. I won't be able to cover your food or anything for very long.
[cpg cn=true]


Fear smiled broadly and said.
[cpg]


[FACE method="change_2" pos="2/3"]
;;[t_move pos=C 下礼]
[VOICE f="Fia061"]
[OnName num="fia"]
Fia smiled broadly and bowed her head, "Thank you!
[cpg cn=true]


I really don't want to say . I really felt like I had no words to describe how I felt.
[cpg]


What was going to happen now?
[cpg]

[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_03_1.ui" time=1000]
[WAIT time=1500]

[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（朝）******************************************************

[window target=true]



I had left some money for food at home. I have a place to sleep.
[cpg]


I was so excited that I could not help but smile.
[cpg]


I couldn't help but smile. I've never lived with a girl before.
[cpg]



;//※ヒロイン１とヒロイン３は最初から攻略対象となっている

;//■分岐

;//==============================
;//ヒロイン２が攻略対象となっている場合のみイベント発生

[if exp={getFlagValue("Cha2flg_s") == 1 }]
[jump target="*eve_01_1"]
[else]
[jump target="*eve_01_2"]
[endif]


*eve_01_1|A Journey Around the World


[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夕方）******************************************************



;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1000]


As I was thinking this, I met another subhuman.
[cpg]


Not just any subhuman, but the one I met during the trip, she was ......
[cpg]


[BG f="b_03_3_up_l.ui" time=1000]
[WAIT time=1500]

[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile077"]
[OnName num="meile"]
"Oh.
[cpg cn=true]


[OnName num="kousuke"]
"...... email?"
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile078"]
[OnName num="meile"]
I looked for you, Kosuke. I could find her by her scent.
[cpg cn=true]


[OnName num="kousuke"]
No, no, wait. You're not supposed to be able to use magic.
[cpg cn=true]


I still know that Fear figured out where I live. I'm sure he did some magic or something.
[cpg]


But isn't it strange that Meir could do the same thing?
[cpg]


[OnName num="kousuke"]
How did he find me?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile079"]
[OnName num="meile"]
I told you, I found you by smell.
[cpg cn=true]


That's absurd. But he actually found me.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile080"]
[OnName num="meile"]
I came all the way to Japan for you.　I came all the way to Japan for you.
[cpg cn=true]


I couldn't say no, so I headed to his house. ......
[cpg]


Even if I refused, I had to go home. Even if I leave it alone, the mail will come to my house.
[cpg]



;//ブラックアウト
[window target=false]
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************

[window target=true]

;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く
[WAIT time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Fia062"]
[OnName num="fia"]
"Welcome home,...... is that the beastman,......?"
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile081"]
[OnName num="meile"]
Huh?"　Elf ......?　Kosuke, what do you mean?
[cpg cn=true]


The two should be meeting for the first time. The first time they met, they would have done something like this.
[cpg]


[OnName num="kousuke"]
"Well, ...... she's Fia. I told you I was being chased.
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Meile082"]
[OnName num="meile"]
"Oh, yeah. You also followed Kosuke here.
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="Meile083"]
[OnName num="meile"]
I'm Maille. Nice to meet you.
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Fia063"]
[OnName num="fia"]
Yes. ......
[cpg cn=true]


The three of us suddenly had to spend time together in a small room.
[cpg]


 It seemed like I would end up living with Meir, even though I was a little shy…
[cpg]

[window target=false]

[STOPBGM]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（朝）******************************************************

[window target=true]




The most important thing to keep in mind is that you should never be afraid to ask for help. The most important thing to remember is that the best way to get a good night's sleep is to be prepared for the day.
[cpg]


I woke up early in the morning and decided to leave the house before the two of them.
[cpg]


I leave a note. I leave a note for Fia and Meir, telling them to go sightseeing in Japan during the day.
[cpg]


Meir, in particular, would not be able to stand to stay still in a small place.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





The weekdays continue. I'd like to spend time with my subhuman girlfriend, but that's not allowed.
[cpg]


I have work as usual waiting for me. It's been a long holiday weekend, so I've been dizzyingly busy.
[cpg]

[window target=false]

[STOPBGM]
[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]

[transition target={true} rule="39.png" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="39.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************


[window target=true]



At night, I finally get to be with the two of them. ......
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sMeile002"]
[OnName num="meile"]
Hey, Kosuke. Don't you have anything for me?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Fia064"]
[OnName num="fia"]
"Wait, you're a little ...... close."
[cpg cn=true]


 Fia is trying to tear off the Meir that sticks to me.
[cpg]

[free time=800]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/2" time=800]

[VOICE f="sMeile003"]
[OnName num="meile"]
　Don't stop me.
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia065"]
[OnName num="fia"]
I'm not going to stop you. ......
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile086"]
[OnName num="meile"]
You don't like subhumans or beastmen,......?"
[cpg cn=true]


The most important thing to remember is that you can't just take a look at the actual product or service and expect it to be good for you.
[cpg]


 I didn't know what to say.
[cpg]





;//■選択肢
[switch]
[case "I wouldn't answer."]
	[swap]
	[jump target="*IseSel04_1"]
[case "I don't hate them."]
	[swap]
	[jump target="*IseSel04_2"]
[endswitch]



1, I don't answer.
Two, I don't hate it.



;//==============================
;//１、答えない
*IseSel04_1|A Journey Around the World



[OnName num="kousuke"]
"......"
[cpg cn=true]


[FACE method="change_5" pos="1/2"]
[VOICE f="Meile087"]
[OnName num="meile"]
"......"
[cpg cn=true]


[FACE method="change_4" pos="2/2"]
[VOICE f="Fia066"]
[OnName num="fia"]
Oh, um, ...... I don't think Kosuke-san is the kind of person who would discriminate like that."
[cpg cn=true]


[FACE method="change_4" pos="1/2"]
[VOICE f="Meile088"]
[OnName num="meile"]
'Yeah. I know. Right?　Kosuke."
[cpg cn=true]


I couldn't reply. I was a little annoyed that he suddenly barged in.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[if exp={getFlagValue("Cha2flg") == 1 }]
[stflag Cha2flg=-1]
[endif]


;//ヒロイン２は攻略対象でなくなる

[jump target="*IseSel04_3"]

;//==============================
;//２、嫌いじゃない

*IseSel04_2|Traveling Around the World



[OnName num="kousuke"]
'I don't hate you. It can't be."
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Meile089"]
[OnName num="meile"]
Thanks."
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

Meir hugs me and pushes me down.
[cpg]


[FACE method="change_7" pos="1/2"]
[FACE method="change_7" pos="2/2"]
[VOICE f="sMeile004"]
[OnName num="meile"]
I'm not sure how much I want to be with you," he said. Hey, I'd ...... like to be closer to you.
[cpg cn=true]


I was about to say, "Fia's next to me, too.
[cpg]


[FACE method="change_2" pos="2/2"]
[VOICE f="Fia067"]
[OnName num="fia"]
I was about to say, "Oh, um,...... I'm going shopping."
[cpg cn=true]



[move from="2/2" to="5/3" ease="easeInOutSine" time=1000]

[SE f="se004"]
;//【ＳＥ】『ドア閉まる』





Fia left the room, even though she didn't have any money.
[cpg]


[FACE method="change_6" pos="1/2"]
[WAIT time=1]
[move from="1/2" to="2/3" ease="easeInOutSine" time=1000]

[VOICE f="sMeile005"]
[OnName num="meile"]
I said, "Fia, you're so thoughtful."
[cpg cn=true]


[OnName num="kousuke"]
'...... oh.'
[cpg cn=true]




;//ブラックアウト

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]



I wondered if it was okay, but I felt like I was trying to make up for the cost of having him live in the house.
[cpg]

[VOICE f="sMeile006"]
[OnName num="meile"]
'After all, Kosuke smells good, doesn't he?
[cpg cn=true]

[OnName num="kousuke"]
"So you're not aware of that. ......
[cpg cn=true]

[VOICE f="sMeile007"]
'Soooooo ...... soooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo, I can't get enough!
[cpg cn=true]


;//========================================
;//●ＣＧエロ（主人公に迫るヒロイン。体の上に乗っている）ev_01
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：主人公の部屋＿現代
;//時間　：夜
;//========================================

*Scene007|A Journey Around the World

[STOPBGM]


[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[BGM f="bg_h1"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=100]


I thought I said, "I'm not going to let you do this," and the mail was on me!
[cpg]

[OnName num="kousuke"]
I'm not sure if I'm going to be able to do that. You're not back in the wild?"
[cpg cn=true]


;**【ＣＧ】 ev_01_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=100]

I said, and his cheeks puffed up into an angry expression.
[cpg]

[VOICE f="sMeile008"]
[OnName num="meile"]
No, I'm not. You're making fun of me because I'm a beast.
[cpg cn=true]

I was sure that "wild" was not a good word to use for a beastman.
[cpg]

[OnName num="kousuke"]
No, no. ......
[cpg cn=true]

In any case, I don't think they're going to do anything to me.
[cpg]

I'm not ready for that either, I thought, and then he leaned over and put his face close to my chest.
[cpg]


;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile009"]
[OnName num="meile"]
 "Suu, fuuu... I want to stay by your side forever."
[cpg cn=true]

She says something like that and goes back to her original position.
[cpg]

[VOICE f="sMeile010"]
[OnName num="meile"]
I would do anything for you if Fia wasn't here.
[cpg cn=true]

I'd do anything if Fia wasn't here," Meir says suggestively. I ask, puzzled.
[cpg]

[OnName num="kousuke"]
What do you mean, anything?
[cpg cn=true]

She smirks and moves her face closer to mine again.
[cpg]

;**【ＣＧ】 ev_01_b ***********************
[CG id=0 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile011"]
[OnName num="meile"]
You're thinking dirty thoughts, aren't you?
[cpg cn=true]

[OnName num="kousuke"]
It's your fault!
[cpg cn=true]

[VOICE f="sMeile012"]
[OnName num="meile"]
I'm not. I knew it.
[cpg cn=true]

It seems that Maille has a mischievous disposition. No, I kind of knew that, but ......
[cpg]

;//Ｈシーンカット


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_04_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d3"]

[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************


[window target=true]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="4/2" time=1]
[WAIT time=1]



[move from="4/2" to="2/2" ease="easeInOutSine" time=1000]

[VOICE f="Fia068"]
[OnName num="fia"]
Oh, sorry to bother you. ......
[cpg cn=true]


After flirting for a while, Fia came back to the room fearfully.
[cpg]


It's awkward. The first thing to do is to get a good look at the picture.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="sMeile013"]
[OnName num="meile"]
I wish we could spend a little more time alone together.
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="sFia005"]
[OnName num="fia"]
I'm not going to do that, it's not fair to you.
[cpg cn=true]

;//＠
;//フィアが謝ることは何も無いと思うが、それでも謝ってきた。
;//[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]
;//ブラックアウト



[stflag Cha2flg=1]
;//ヒロイン２は攻略対象のまま



;//==============================


*IseSel04_3|

*eve_01_2|A Journey Around the World

;//==============================


;//■分岐


;//==============================

;//ヒロイン４が攻略対象となっている場合のみイベント発生

[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_04_1"]
[else]
[jump target="*eve_04_2"]
[endif]


*eve_04_1|A Journey Around the World

;//■分岐

;//■分岐

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夜）******************************************************





One weekday night. One weekday night, she showed up.
[cpg]


[BG f="b_03_4_up_l.ui" time=1000]
[WAIT time=1500]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]


[OnName num="kousuke"]
"...... you?"
[cpg cn=true]


[VOICE f="Clolowlude091"]
[OnName num="clolowlude"]
'I'm here for you. You should be grateful."
[cpg cn=true]


Chloro had come. I reminded myself that I'd been thoughtful to Chloro as well.
[cpg]


I was still on my way home. I wonder what Fia would think if I took her to the house: ......
[cpg]


What a thought, but it's not a good idea not to bring Chloro up to the house.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude092"]
[OnName num="clolowlude"]
I asked her, "Where is your house?　I'd like you to take me up there if you like."
[cpg cn=true]


I say "if you like," but it's almost a compulsion.
[cpg]


She is a magician. I don't know what will happen if I refuse.
[cpg]



;//ブラックアウト
[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************


[window target=true]



[OnName num="kousuke"]
So you're a demon called Chloro ......?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Clolowlude093"]
[OnName num="clolowlude"]
Yes, a demon. And her name is not Chloro, but Chloro-Urudo.
[cpg cn=true]

;//[free time=800]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Fia075"]
[OnName num="fia"]
......."
[cpg cn=true]


Fear must be stunned. You're probably wondering how many women I've talked to.
[cpg]



*eve_05_2|A Journey Around the World

;//■分岐

;//[free time=800]


[FACE method="change_1" pos="1/2"]
[FACE method="change_1" pos="2/2"]

[VOICE f="Fia077"]
[OnName num="fia"]
'Nice to meet you, ......, Mr. ChloroUrudo.
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude096"]
[OnName num="clolowlude"]
'Yes, nice to meet you. It's nice to hear you call me without abbreviations."
[cpg cn=true]


Chloro, I knew you had a thing about that.
[cpg]



;//ブラックアウト

[STOPBGM]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[free time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（朝）******************************************************


[window target=true]



And before Fia woke up. Chloro woke me up.
[cpg]


*eve_05_3|A Journey Around the World



[OnName num="kousuke"]
...... what?
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Clolowlude097"]
[OnName num="clolowlude"]
I knew your pheromones were alive and well.
[cpg cn=true]


[OnName num="kousuke"]
I told you, I don't know what you're talking about.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clolowlude098"]
[OnName num="clolowlude"]
I don't know," she said. I'm ...... captivated by it.
[cpg cn=true]


Well, this is not good. This is not a good idea.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude099"]
[OnName num="clolowlude"]
Even ...... Fear wouldn't have left you alone.
[cpg cn=true]


[OnName num="kousuke"]
That's not the same thing.
[cpg cn=true]


 Even if I refuse, Kullulu snuggles up to me.
[cpg]

[OnName num="kousuke"]
What if something happens to ...... Fear?
[cpg cn=true]

*eve_06_3|A Journey Around the World


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude122"]
[OnName num="clolowlude"]
I'm just going to show you."
[cpg cn=true]


Chloro was being quite reckless. But if it were the other way around, it might ...... be.
[cpg]


[OnName num="kousuke"]
'...... if we're going to flirt, let's at least do it when no one else is around.'
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sClolowlude004"]
[OnName num="clolowlude"]
So flirting itself is fine?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clolowlude124"]
[OnName num="clolowlude"]
You should be thankful. A beautiful woman like me is pressing you so hard.
[cpg cn=true]


I thought to myself, ...... she is certainly a beautiful person.
[cpg]

;//Ｈシーンカット



;//==============================

*eve_04_2|A Journey Around the World

;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[STOPBGM]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_04_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夕方）******************************************************

[window target=true]




I was to live with a subhuman girl for a while.
[cpg]


Fia was cooking for me, using some Japanese ingredients that I was unfamiliar with.
[cpg]


Despite the unfamiliarity of the situation, I thought it was fine because I was happy.
[cpg]


The cost of living was a little high, but I could manage that much for a while with my savings.
[cpg]


[OnName num="kousuke"]
Fia, what's for dinner today?
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia078"]
[OnName num="fia"]
I tried to make something called "miso soup," but I'm not too confident about ...... it.
[cpg cn=true]


[OnName num="kousuke"]
I'm not so sure about it. I'm not sure about that.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia079"]
[OnName num="fia"]
The other day I saw a TV program called "Miso soup is good for you".
[cpg cn=true]


The elf watches TV. The elf watches TV. It's kind of strange.
[cpg]

[free time=1000]

;//＠
[SE f="se012"]
;//【ＳＥ】テレビをつける（スイッチを押す）

The actuality of the fact that the TV is not really a good idea.
[cpg]


[OnName num="kousuke"]
I turn on the TV. "...... what?"
[cpg cn=true]


I was enjoying my carefree cohabitation. However, the situation had become more serious than I had expected.
[cpg]


What I saw on the TV news was my face.
[cpg]


I was so surprised that I couldn't react. I was so surprised that I couldn't react.
[cpg]


[OnName num="news_caster"]
The wanted man was last seen in the land of the elves at .......
[cpg cn=true]


Wanted criminal. I was surprised at the word "wanted person," but more than that, I was surprised at the ......
[cpg]


It seems that I was being hunted in the land of the elves for a reason other than to catch me for seducing Fia.
[cpg]


The chief of the elves, who appeared on the television, said, "That was the rebirth of the demon king.
[cpg]


[OnName num="elven_chief"]
'That is the reincarnation of the Demon King,...... and the signs have been there for a long time.
[cpg cn=true]


[OnName num="elven_chief"]
'He seems to be a man in his twenties or so, but he must have awakened just now. It is as the prophecy said."
[cpg cn=true]


The prophecy passed down by the elves and the magical detection have determined that I am the reincarnation of the Demon King, it seems.
[cpg]


I am not aware of it at all. I am not aware of it at all, or rather, it is so sudden that I don't understand.
[cpg]


In the first place, I had broken the law and come to the land of the elves, so I was even being hunted. ......
[cpg]


But it seems that if you are the reincarnation of the Demon King, it's a different story.
[cpg]



;//==============================
;//ヒロイン２が攻略対象となっている場合のテキスト

;//■分岐
[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*eve_07_1"]
[else]
[jump target="*eve_07_2"]
[endif]


*eve_07_1|A Journey Around the World

[free time=800]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Meile119"]
[OnName num="meile"]
Kosuke: "Amazing, isn't it?　You are the reincarnation of the Demon King!
[cpg cn=true]


[OnName num="kousuke"]
Wait a minute. I don't know anything about that.
[cpg cn=true]

[jump target="*eve_07_3"]

;//==============================
;//ヒロイン２が攻略対象となっていない場合のテキスト

;//■分岐

*eve_07_2|A Journey Around the World


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia080"]
[OnName num="fia"]
Kosuke-san, ...... is that so?
[cpg cn=true]


[OnName num="kousuke"]
No, no, ...... I don't know either.
[cpg cn=true]



;//==============================

*eve_07_3|A Journey Around the World

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]

[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************





The TV continues the news. It seems that there was an announcement from the land of the elves around noon today, and the news was all over the place even through the middle of the night.
[cpg]


The Demon King has tremendous power, so weapons are useless.
[cpg]


It was even said that the world would be his ...... when he comes into existence.
[cpg]


This means that if he is caught, he won't just be thrown in jail.
[cpg]

[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[OnName num="kousuke"]
What should I do, Fear ...... I don't want to die."
[cpg cn=true]


Fear makes a difficult face. And then.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia081"]
[OnName num="fia"]
Then ...... why don't you go ahead and head for the land of the beastmen?"
[cpg cn=true]


He said, "That's right. Indeed, he was right.
[cpg]


[free time=800]

It would be a bad idea to stay in Japan or to go to the land of the elves.
[cpg]


The slowest pursuers would be in the land of the beastmen. But only slowly.
[cpg]


It's not directly about protecting yourself. ......
[cpg]




;//==============================
;//ヒロイン４が攻略対象となっている場合のテキスト

;//■分岐
[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_08_1"]
[else]
[jump target="*eve_08_2"]
[endif]



*eve_08_1|A Journey Around the World



[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude148"]
[OnName num="clolowlude"]
'It won't do to be frightened now.
[cpg cn=true]


[OnName num="kousuke"]
Did you know about this before, Chloro?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude149"]
[OnName num="clolowlude"]
Yes, of course.
[cpg cn=true]


Was that so? ...... subhumans wanted me because I'm the Demon King?
[cpg]

[jump target="*eve_08_3"]

;//==============================
;//ヒロイン４が攻略対象となっていない場合のテキスト

;//■分岐

*eve_08_2|A Journey Around the World


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia082"]
[OnName num="fia"]
"You look pale, Kosuke-san,.......
[cpg cn=true]


[OnName num="kousuke"]
"......Ah, ah...... that's right."
[cpg cn=true]



;//==============================

*eve_08_3|A Journey Around the World

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_04_4.ui" time=1000]

[WAIT time=1500]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************

[window target=true]



It's night. If I don't sleep, I won't be able to go to work tomorrow, but going to work is also bad.
[cpg]


What am I going to do? I'm in a situation where I won't even be able to eat tomorrow.
[cpg]



[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

[WAIT time=1100]



As I was thinking that, I saw someone visiting my house.
[cpg]


The police. I was scared, but I couldn't not answer the door.
[cpg]


I made up my mind, and before I could unlock the door ......, it was unlocked.
[cpg]


It opened from the outside. I was thinking, "What the hell is that?" when I saw the face of the person who opened the door.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye018"]
[OnName num="schartye"]
What a face! What a face, you must be the Demon King.
[cpg cn=true]


[OnName num="kousuke"]
"You,......, what is it now?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye019"]
[OnName num="schartye"]
I'm not sure I'm allowed to talk to you that way.　Does the Demon Lord not need help?
[cpg cn=true]


[OnName num="kousuke"]
"...... No, no. I'd be grateful if you could help me.
[cpg cn=true]

[free time=800]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Fia083"]
[OnName num="fia"]
Who is this?
[cpg cn=true]


[OnName num="kousuke"]
"This is Chartier. It's a long story. ......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Schartye020"]
[OnName num="schartye"]
To put it simply, he's taken the Witch Queen to many countries.
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Schartye021"]
[OnName num="schartye"]
All of this is in preparation for this day. The Demon King."
[cpg cn=true]


[OnName num="kousuke"]
"......, please don't call me the Mad King.
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Schartye022"]
[OnName num="schartye"]
The land of the beastmen is still in its infancy. You know that, don't you?
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Schartye023"]
[OnName num="schartye"]
Which means that the Mad King can literally be king as well.
[cpg cn=true]


[OnName num="kousuke"]
What do you mean by that, ......?
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Schartye024"]
[OnName num="schartye"]
"If you're a king, you have to be a king and build a kingdom."
[cpg cn=true]




[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[free time=1]
[STOPBGM]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="163.jpg" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_03_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夜）******************************************************


[window target=true]



So, together with the subhumans who came to visit us, we headed for the land of the beastmen.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia084"]
[OnName num="fia"]
I've heard rumors about flying boats,......, but this is the first time I've seen one.
[cpg cn=true]

[VOICE f="sFia006"]
[OnName num="fia"]
How can something so big float?
[cpg cn=true]


[OnName num="kousuke"]
I don't know either. ...... It must be magic or something.
[cpg cn=true]



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye025"]
[OnName num="schartye"]
Don't dawdle. Let's go."
[cpg cn=true]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト
;//【ＢＧ】『空』（夜）******************************************************



[SE f="se005"]
;//【ＳＥ】『魔法発動する音　シンセパッド系』


[WAIT time=1500]



Then we flew out of Japan with the subhuman girl.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
During the trip, Chartier explained to me about my constitution.
[cpg]


Apparently, I have pheromones that make subhumans go into heat, and saliva, for example, contains magical elements.
[cpg]

[VOICE f="sSchartye001"]
[OnName num="schartye"]
The subhumans who are kissed by you may experience an increase in magical power. It's that much magic."
[cpg cn=true]

[OnName num="kousuke"]
That's a lie. ......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSchartye002"]
[OnName num="schartye"]
It is not a lie. The power to charm women mainly, but even men will be pleased with the resurrection of the Demon King if they are subhuman.
[cpg cn=true]


[OnName num="kousuke"]
Is that what it is, ......?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye027"]
[OnName num="schartye"]
It's not a lie. The subhuman is still in a vulnerable position, and that is not good.
[cpg cn=true]


While we are talking about such things, the airship goes.
[cpg]


Even the suspicious passengers are not here today.
[cpg]

[free time=800]


;//==============================
;//ヒロイン４が攻略対象となっていない場合のみイベント発生

;//■分岐
[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_10_2"]
[endif]




[OnName num="kousuke"]
So, ......, where is she?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude150"]
[OnName num="clolowlude"]
...... what?"
[cpg cn=true]


Chloroerudo, who is with Chartier before I know it.
[cpg]


She seems to be an acquaintance of Chartier's.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude151"]
[OnName num="clolowlude"]
I'm here to help. I hope you don't mind.
[cpg cn=true]


For some reason, she says she's going to help me build my country.
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Clolowlude152"]
[OnName num="clolowlude"]
The return of the Demon King is a long-held dream of us subhumans," she said.
[cpg cn=true]


He said the same thing as Chartier.
[cpg]



;//==============================


*eve_10_2|A Journey Around the World


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[STOPBGM]
[BG f="b_10_1.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



Then we arrived in the land of the beastmen. It is not possible to suddenly declare oneself king and become king.
[cpg]


At any rate, we headed for the village where Meir was.
[cpg]



;//==============================
;//ヒロイン２が攻略対象となっていない場合のみイベント発生

;//■分岐
[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*eve_11_2"]
[endif]



Where we were headed, of course, we were to meet Meir once more.
[cpg]


She was surprised, but still looked happy.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile120"]
[OnName num="meile"]
"Kosuke......!　Why are you here?"
[cpg cn=true]


[OnName num="kousuke"]
Oh, ah ......, it's a long story.
[cpg cn=true]


I told her in a few sentences. I told him that I was being hunted even more than before and that I was going to build my own country.
[cpg]


I explained that I was going to build my own country, and he said he would help me with that.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile121"]
[OnName num="meile"]
He said, "You were a demon king, Kosuke. ......!　No wonder I thought you were unusual."
[cpg cn=true]


I couldn't keep up with his high tension. I became rather anxious.
[cpg]


And isn't it too early to accept it?　I haven't caught up with my understanding yet.
[cpg]


Maybe it's just because it's me. ......
[cpg]


;//続くのでリセットで転調



;//==============================

*eve_11_2|A Journey Around the World




;//続くのでリセットで転調
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_1.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


;//==============================

*eve_12_2|A Journey Around the World



Then Chartier cuts in with this.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye028"]
[OnName num="schartye"]
I will gather the people of this village. The Demon Lord himself will not go."
[cpg cn=true]


[OnName num="kousuke"]
"But, but ......
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye029"]
[OnName num="schartye"]
"The Witch Queen will only need to remain calm."
[cpg cn=true]

[free time=800]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Clolowlude153"]
[OnName num="clolowlude"]
That's right. You don't need to be afraid.
[cpg cn=true]


I thought to myself, "No, there is no need for you to be frightened. ......
[cpg]

[STOPBGM]


[free time=1000]
[window target=false]

[BG f="b_10_3.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



The beastmen from all over the village gathered. No, are they from outside the village?
[cpg]


There are so many of them. There are a great many of them, maybe a thousand.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Schartye030"]
[OnName num="schartye"]
Listen up!　The Demon Lord has risen here and now!
[cpg cn=true]


[VOICE f="Clolowlude154"]
[OnName num="clolowlude"]
We are his dependents!　In order to protect the Demon Lord, and by extension, to create a world for the Demon Lord, ......
[cpg cn=true]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye031"]
[OnName num="schartye"]
"What would we do if we did not offer ourselves!　What is our longing?
[cpg cn=true]


There is a strange atmosphere. Fear was a little frightened, but Meir was swallowed up by the air.
[cpg]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye032"]
[OnName num="schartye"]
'Our longing is to conquer this world!
[cpg cn=true]


A cheer breaks out. This is bad. I'm not that good.
[cpg]


[OnName num="therianthropy_A"]
Oh, Lord Demon King,......, I would die for you.
[cpg cn=true]


[OnName num="therianthropy_B"]
I'll fight any battle you want, human or elf!
[cpg cn=true]


[free time=800]

In any case, they seem to be pleased with the Demon King's resurrection, and everyone is worshipping me.
[cpg]


[OnName num="kousuke"]
"...... Oh, yeah. I'm the Demon King, maybe ......."
[cpg cn=true]


I decided to call myself the Demon King, feeling restless.
[cpg]

[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]




That night was like a banquet. It seems that the Demon King is such an important existence for subhumans.
[cpg]


Away from the feast, Chartier and I talked.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye033"]
[OnName num="schartye"]
I think it's time for me to tell you all about it.
[cpg cn=true]


[OnName num="kousuke"]
All? You mean ......?　Is there anything more?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye034"]
[OnName num="schartye"]
It's not a big story. But it's an important story.
[cpg cn=true]


Chartier opens his mouth. She had long since discovered that he was the reincarnation of the Demon King.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye035"]
[OnName num="schartye"]
I took you on this trip because I wanted you to make friends in various places. I didn't return you to Japan right away so that you could make friends in various places.
[cpg cn=true]


Chartier explained. Then Kuroro arrived.
[cpg]


[free time=800]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Clolowlude155"]
[OnName num="clolowlude"]
What?　You two were talking.
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Schartye036"]
[OnName num="schartye"]
We were talking about why we took the Demon King on our trip.
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude156"]
[OnName num="clolowlude"]
'Oh, I see. Well, if I don't explain it to you, you won't understand.
[cpg cn=true]


I was getting more and more perceptive as I was being told.
[cpg]


 Certainly, Fia wouldn't have become a companion if she hadn't headed to the Elven country.
[cpg]


 Even for Meir, if I hadn't met him in person, I might not have been able to get his cooperation right away.
[cpg]


[OnName num="kousuke"]
What would have happened if she had lived in Japan all these years without doing that ......?"
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye037"]
[OnName num="schartye"]
I would not be surprised if he had suddenly been discovered to be the reincarnation of the Demon King and had been killed right then and there.
[cpg cn=true]


I shuddered.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="sSchartye003"]
[OnName num="schartye"]
I'll tell you one more thing. The qualities of a Demon King are awakened through the connection with subhumans.
[cpg cn=true]


[OnName num="kousuke"]
Awakening...... what?"
[cpg cn=true]


If you ask for details, it is said that the soul remembers that it was a Demon King when it falls in love with a subhuman, kisses a subhuman, or something like that.
[cpg]


The theory seems to be that it is because he had built a harem of subhumans in the past.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="sSchartye004"]
[OnName num="schartye"]
The demon king once had countless children with subhuman daughters. What about the current Demon Lord?"
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


I think back. I think back to the last time I saw him.
[cpg]


[FACE method="change_7" pos="2/2"]
[VOICE f="sClolowlude005"]
[OnName num="clolowlude"]
In any case, depending on how many people he has to deal with in the future, his personality will probably change as well.
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Schartye040"]
[OnName num="schartye"]
Oh. Whether you want world domination or peace depends on how much of your nature as a Demon Lord returns.
[cpg cn=true]


[OnName num="kousuke"]
"...... Is it true, Chloro? Is everything you've said true?
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude158"]
[OnName num="clolowlude"]
There's not a single thing you can deny.
[cpg cn=true]


I knew it. ...... My nature changes when I fall in love with a subhuman girl.
[cpg]


If you're too much of a temptation to anyone, your qualities as a demon king will probably be resurrected.
[cpg]


I couldn't imagine if that was a good thing or a bad thing.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude159"]
[OnName num="clolowlude"]
I couldn't imagine if that was a good thing or a bad thing. You're still in danger.
[cpg cn=true]


I felt like I was in a terrible situation, but I was determined to protect myself as the Demon King.
[cpg]



;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[free time=1]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="163.jpg" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_10_1.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



In the morning, everyone's excitement calms down a bit.
[cpg]


Still, everyone seemed to respect me.
[cpg]


Men and women alike bowed deeply when they saw me in front of them.
[cpg]


[OnName num="kousuke"]
'Demon King, Demon King, huh? ......
[cpg cn=true]


But even though I am the Demon King, there is no sign that I can use magic.
[cpg]


I've never used it, so I can't use it. I decided to talk to Fia and Meir about it.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile122"]
[OnName num="meile"]
I don't know much about magic either.
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="Fia085"]
[OnName num="fia"]
I have some knowledge about it.
[cpg cn=true]


[OnName num="kousuke"]
I have some knowledge about magic. I have some knowledge of magic.　Since you are the Demon King, I think you should be able to use it a little.
[cpg cn=true]


It is a matter of image.
[cpg]


So, the three of us, Fia and Meir, talked about magic.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia086"]
[OnName num="fia"]
Magic, like anything else, becomes powerful only when it is combined with ...... effort and talent.
[cpg cn=true]


[OnName num="kousuke"]
What about me? I'm not talking about hard work, but talent?
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Meile123"]
[OnName num="meile"]
The most important thing to remember is that the best way to get the best out of your business is to be a good businessman.
[cpg cn=true]


The most important thing to remember is that you can't just take a look at the actual product or service and expect it to be just as good. The most important thing to remember is that you should never be afraid to ask for help.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia087"]
[OnName num="fia"]
I'm not wrong. Kosuke seems to have ...... tremendous magical qualities."
[cpg cn=true]


I'm not sure if I'm right or not, but I'm sure I'm wrong.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia088"]
[OnName num="fia"]
I'm not sure if Chartier-san or Chlorouloud-san would be better than me teaching him,.......
[cpg cn=true]


[OnName num="kousuke"]
'Well, those two could use some magic.
[cpg cn=true]


The most important thing to remember is that you can find a lot of people who are not familiar with the concept of magic.
[cpg]


So, I was taught magic by Fia, Chartier and Chloro.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=100]
;//ブラックアウト





Fia and Chloro were not so keen, but Chartier was eager to teach me magic.
[cpg]


She didn't talk too fast, but there was so much information in what she said that I was confused.
[cpg]


[WAIT time=500]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye041"]
[OnName num="schartye"]
I was confused.　Shall we talk about how summoning magic works?
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Fia089"]
[OnName num="fia"]
No, let's take a break here. Kosuke-san, you look tired.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye042"]
[OnName num="schartye"]
"Is that so?　I don't understand.
[cpg cn=true]


I was so tired that I deliberately showed it in my attitude. I don't understand even if you suddenly explain everything to me.
[cpg]


But it was a matter of life and death for me, so I took it seriously.
[cpg]


[window target=false]
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]


Several days and nights pass.
[cpg]


I was to stay in a house for ...... guests in the country of the beastmen, in their settlement.
[cpg]


But one of these days, if I don't build a castle or something, I could suddenly find myself in my sleep.
[cpg]

[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





With that in mind, I was successfully performing my first magic trick.
[cpg]



[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』



;//フラッシュ
[BG f="white.ui" time=1000]
[WAIT time=1000]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1000]

;//【ＢＧ】『村＿獣人の国』（昼）******************************************************






Fia, Chartier, and I had a magic class together. But it seems that Fia is not as familiar with it as Chartier.
[cpg]


[OnName num="kousuke"]
'Did this work?
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Fia090"]
[OnName num="fia"]
'Yes. The magic of summoning ...... the ideal demon you envisioned should have been summoned, but this ......
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="sSchartye005"]
[OnName num="schartye"]
'A tentacled creature. Wonderful."
[cpg cn=true]


Tentacles. It's wriggling and squirming.
[cpg]


It's reddish-black and creepy, but I see, this is the demon I sought.
[cpg]


[OnName num="kousuke"]
"......"
[cpg cn=true]

It's hard to say how I feel when I'm told that this kind of demon lived inside my head.
[cpg]

I'm not sure if I like dragons, gryphons, or other cool-looking demons.
[cpg]


I also like horror movies. I like horror movies.
[cpg]



[FACE method="change_7" pos="1/2"]
[VOICE f="sSchartye006"]
[OnName num="schartye"]
I'm the reincarnation of the demon king of old. I can feel the vestiges of him.
[cpg cn=true]


[OnName num="kousuke"]
...... Is that so?
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="sSchartye007"]
[OnName num="schartye"]
The most important thing is that you can control him at will.  Use it as you wish.
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


I even got Chartier's seal of approval.
[cpg]

The tentacled creature was still wriggling around. Fear was frightened at the sight of it.
[cpg]

[FACE method="change_7" pos="2/2"]
[VOICE f="sFia007"]
[OnName num="fia"]
'Yes, when the time comes,......, it might be a fighting force.'
[cpg cn=true]

I was thinking of something completely different.
[cpg]

I was thinking that I could use this to play a prank on those girls.
[cpg]

I don't have my former memories back, but I think I was thinking something similar before I was reincarnated ......
[cpg]


I had such a dim memory in my mind.
[cpg]


[OnName num="kousuke"]
"How do I turn this off ......?"
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Fia091"]
[OnName num="fia"]
Wait a minute, please."
[cpg cn=true]


[FACE method="change_5" pos="1/2"]
[VOICE f="Schartye046"]
[OnName num="schartye"]
'Damn ......, hey, you're getting tangled up.'
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia092"]
[OnName num="fia"]
......, wait a minute, please."
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『触手絡みつく』


[BG f="b_10_2_l.ui" time=1000]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



From there, it was an agony. My magic was too strong and the tentacle creature went out of control.
[cpg]


 It's entwined with Chartier's body and won't let go.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Schartye047"]
[OnName num="schartye"]
'Demon king! ...... what should I do about this?
[cpg cn=true]


[OnName num="kousuke"]
Oh, don't ask me!　Fear, what should I ...... do?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Fia093"]
[OnName num="fia"]
"Wait a minute, you can do the reverse of the summoning. ...... Uh, wait a minute."
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Fia094"]
[OnName num="fia"]
Where did I put the grimoire to erase ......?
[cpg cn=true]


[OnName num="kousuke"]
I don't know!　I don't know!
[cpg cn=true]

[FACE method="change_5" pos="2/2"]
[VOICE f="sFia008"]
[OnName num="fia"]
I'll go look for it!
[cpg cn=true]

[move from="2/2" to="4/2" ease="easeInOutSine" time=1000]




 While saying that, Fia left this place to escape the danger.
[cpg]


I don't know where it is!
[cpg]



;//========================================
;//●ＣＧ（触手に絡まれるヒロイン。逃げだそうとしている）ev_14
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：触手　　　　服装ex：無し
;//場所　：村＿獣人の国
;//時間　：昼
;//========================================

*Scene012|A Journey Around the World

[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=100]


[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[WAIT time=1000]


[VOICE f="sSchartye008"]
[OnName num="schartye"]
I can't untie you.
[cpg cn=true]
[OnName num="kousuke"]
I'm not sure if I'm going to be able to do it," said Chartier.
[cpg cn=true]

[VOICE f="sSchartye009"]
[OnName num="schartye"]
 "It's slimy and doesn't feel good, but..."
[cpg cn=true]

[VOICE f="sSchartye010"]
[OnName num="schartye"]
"But when I think of the demons created by the Demon Lord..."
[cpg cn=true]

[OnName num="kousuke"]
"Don't make any funny noises,.......
[cpg cn=true]

The most important thing to remember is that you should not be afraid to ask for help.
[cpg]

[OnName num="kousuke"]
I don't know what to do, I don't want to do this either.
[cpg cn=true]

;**【ＣＧ】 ev_14_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sSchartye011"]
[OnName num="schartye"]
I don't know. I think the demon king can control it to some extent,.......
[cpg cn=true]


I see. I don't know what to do.
[cpg]

[OnName num="kousuke"]
Wait a minute, Chartier.
[cpg cn=true]

[VOICE f="sSchartye012"]
[OnName num="schartye"]
I can't wait. I can't move.
[cpg cn=true]
[OnName num="kousuke"]
I'm sorry.
[cpg cn=true]

I apologize and try my best to imagine releasing her.
[cpg]

 But that alone wasn't enough to control monsters.
[cpg]

I still don't know how to move her just by thinking about it, so it took a long time until she was released.
[cpg]



;[SceneEnd f="sc_012"]

;[Live2d target=0]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



After all, when I tried, this scene looked familiar. I told this to Chartier.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sSchartye013"]
[OnName num="schartye"]
'I see. I'm sure that repeating this kind of thing over and over again will revive my qualities as a demon king."
[cpg cn=true]

[FACE method="change_6" pos="1/2"]
[VOICE f="sSchartye014"]
[OnName num="schartye"]
I'm sure he'll be able to revive his character as a demon king. I'm not afraid to say what I don't want to say.
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="4/2" time=1]

This was not a change from his previous assertions.
[cpg]

[move from="4/2" to="2/2" ease="easeInOutSine" time=1000]

[VOICE f="Fia095"]
[OnName num="fia"]
I know how to turn it off, Mr. Chartier!　I'll turn it off now, okay?"
[cpg cn=true]


But then, Fia came back.
[cpg]


After that, I found out how to turn off the tentacles safely, and Chartier was released. ......
[cpg]


[STOPBGM]

[free time=1000]
[WAIT time=1000]
[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************

[window target=true]




And a few days passed. I too was gradually increasing the magic I could use.
[cpg]


One day, a messenger came from Japan and the land of the elves.
[cpg]


Fia was the one who answered them. Or rather, I ordered her to do so.
[cpg]


I was afraid to meet them in person. On the other hand, Chartier and Chloro might capture the messenger alive.
[cpg]


The first thing that comes to mind is the fact that the two of you are not the only ones who have been in the same situation.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Fia096"]
[OnName num="fia"]
He said he wouldn't kill them if they ...... surrendered meekly.
[cpg cn=true]


[OnName num="kousuke"]
What do you think of ......?"
[cpg cn=true]



[VOICE f="Meile124"]
[OnName num="meile"]
"Well,...... I don't think we should trust him."
[cpg cn=true]


Maille looks at Chloro.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude160"]
[OnName num="clolowlude"]
He's probably sealed up for life with the elves' mystic arts and can't die.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Schartye070"]
[OnName num="schartye"]
Probably."
[cpg cn=true]


Fear didn't deny it either. Fear did not deny it either. The situation is worse than I imagined.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





From that day on, I decided to set up the Demon King's castle.
[cpg]


But it was a temporary setup. The village where Meir spent his time, where the sheik lived.
[cpg]


The sheikh said he would gladly move in for me, and although it is the most solid house in the settlement, it is ......
[cpg]


Naturally, it is not so well defended as a castle.
[cpg]


Still, he said that if the other side used force, Chartier and Chloro would take care of it.
[cpg]


Not knowing how much I could rely on them, I spent my days just studying magic.
[cpg]



;//==============================
;//ヒロイン２が攻略対象となっている場合のみイベント発生

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*eve_13_1"]
[else]
[jump target="*eve_13_2"]
[endif]



*eve_13_1|Traveling Around the World


;//■分岐
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************





I couldn't sleep and decided to walk around the village at night.
[cpg]


Everyone is rather carefree. This village could have been attacked.
[cpg]


But ...... do they think they would do anything for me?
[cpg]


Or do they think that even if they were to be killed, it would only be me?
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile125"]
[OnName num="meile"]
Ah. Kosuke."
[cpg cn=true]


[OnName num="kousuke"]
Oh, ...... mail, huh?"
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile126"]
[OnName num="meile"]
What's wrong?　You don't look well.
[cpg cn=true]


[OnName num="kousuke"]
No, there's nothing wrong.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile127"]
[OnName num="meile"]
Everyone in my village welcomes you. You should be proud of yourself.
[cpg cn=true]


[OnName num="kousuke"]
You say that, but ...... I'm in danger.
[cpg cn=true]


I'm not sure if that's true or not," Meir prefaced.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile128"]
[OnName num="meile"]
I'm not sure if that's true or not, but I'm sure it's true.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile129"]
[OnName num="meile"]
I'm sure everyone is thinking that this is our chance to change that.
[cpg cn=true]


That's a lot to take on.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile130"]
[OnName num="meile"]
I'm not sure if you're watching ...... Fia.
[cpg cn=true]


[OnName num="kousuke"]
Fia?　What about Fia?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sMeile014"]
[OnName num="meile"]
I'm not the only one. ...... everyone is crazy about you.
[cpg cn=true]


[OnName num="kousuke"]
......, that's true.
[cpg cn=true]


I'm not sure if it's a good idea to have a new one, but it's a good idea to have a new one.
[cpg]


 It may be better to understand.
[cpg]


The most important thing to remember is that you can't just go out and buy a new pair of jeans and a new pair of jeans.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile132"]
[OnName num="meile"]
Hey, Kosuke. Come over here for a minute.
[cpg cn=true]


Meir is asking for something. I knew that, and I took her up on her offer.
[cpg]


[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

[BG f="b_10_4_l.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************



I stayed with her for a while. We were huddled together, feeling the warmth of each other's shoulders.
[cpg]

[FG f="CHA02_p7_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMeile015"]
[OnName num="meile"]
"Hey ...... Kosuke."
[cpg cn=true]

She seemed to be begging for a kiss, but my kisses contain magical elements.
[cpg]

So I didn't want to get Maille into any kind of trouble ......
[cpg]



I decided to stop there today.
[cpg]



[VOICE f="sMeile016"]
[OnName num="meile"]
I don't want to do ...... anything about it. I don't want to do anything.
[cpg cn=true]


[OnName num="kousuke"]
I don't not want to, but there are ...... circumstances.
[cpg cn=true]


I wondered if Meir would be convinced if I explained everything.
[cpg]


I was wondering if he would be convinced, but he nodded his head, looking sad.
[cpg]


;//==============================

*eve_13_2|Traveling Around the World

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





And a few more days pass. My efforts were about to bear fruit.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye071"]
[OnName num="schartye"]
I was able to get a good impression of the place. I guess that's a passing grade.
[cpg cn=true]


[OnName num="kousuke"]
"Huh, huh, how about ......?"
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Fia097"]
[OnName num="fia"]
I'm impressed, Kosuke. It really is a level that no ordinary magician can reach.
[cpg cn=true]


 As a result of my training, I was able to use magic even though it was stuttering.
[cpg]


 Although the number of spells he remembers is small, the power is immense... it seems.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="sFia009"]
[OnName num="fia"]
This is the reincarnation of the Demon King,......, more than you can imagine.
[cpg cn=true]

;//;[FO layer="1/2"]



[FACE method="change_2" pos="1/2"]
[VOICE f="Schartye072"]
[OnName num="schartye"]
The most important thing to remember is that the best way to get the most out of your money is to use the right tools.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude161"]
[OnName num="clolowlude"]
I'm sure it's more than I could have imagined. I'm a little bit more open-minded now.
[cpg cn=true]


[OnName num="kousuke"]
"Oh, yeah, ......?"
[cpg cn=true]


I didn't feel bad. And I wondered if I could protect myself a little ......
[cpg]

[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_3.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



Well, now I could protect myself. The next thing I had to do was ......
[cpg]


[OnName num="kousuke"]
I still want a castle. We're too careless as it is."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Fia098"]
[OnName num="fia"]
"I agree, but ...... there's nowhere ...... to find that kind of manpower."
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[FACE method="change_7" pos="1/2"]

[VOICE f="Meile183"]
[OnName num="meile"]
I don't think it's gone.　Don't you think there are more people in this village?
[cpg cn=true]


[OnName num="kousuke"]
"Indeed. It is true.
[cpg cn=true]


Beastmen and subhumans have been gathering with us.
[cpg]

[FACE method="change_2" pos="2/2"]
[FACE method="change_7" pos="1/2"]
[VOICE f="Fia099"]
[OnName num="fia"]
I wonder why they are gathering. ......
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[FACE method="change_7" pos="1/2"]

[VOICE f="Meile184"]
[OnName num="meile"]
It's been in the news a lot. They want to help Kosuke.
[cpg cn=true]


[OnName num="kousuke"]
I see. ......
[cpg cn=true]


The most important thing to remember is that the best way to get the most out of your money is to be a good friend.
[cpg]


Then let's get them to help us build the castle.
[cpg]


[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************


[window target=true]



So the castle was built little by little.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
Chartier, not me, was in charge of that area.
[cpg]


[OnName num="kousuke"]
"Does Chartier know anything about construction?
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye073"]
[OnName num="schartye"]
No. He is working for the Demon King. I'm not sure if he's a good person or not, but he's a good person.
[cpg cn=true]


[OnName num="kousuke"]
"Is that how it is?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye074"]
[OnName num="schartye"]
It's like that. The Demon Lord himself will only give instructions on really important matters.
[cpg cn=true]


[OnName num="kousuke"]
I understand. I will.
[cpg cn=true]


But I still don't feel it yet.
[cpg]



;//ブラックアウト
[window target=false]
[STOPBGM]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_03_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（昼）******************************************************

[window target=true]




Time is ticking away. The way the world looks at me is changing. It was easy to imagine.
[cpg]


Someone must be watching me, whether it's the fact that I'm gaining power as the Demon King or the fact that I'm starting to build a castle.
[cpg]


[window target=false]

;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_02_2.ui" time=1000]

[WAIT time=1500]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************

[window target=true]




Although the whole country is not trying to destroy me, ......
[cpg]


something close to that was already about to happen.
[cpg]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************





[OnName num="kousuke"]
"The assassin ......?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Fia100"]
[OnName num="fia"]
Yes. Chartier and Chloroerudo told me that they found ......
[cpg cn=true]


It seemed that many assassins had come, especially from the land of the elves, who abhorred the Demon King.
[cpg]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye075"]
[OnName num="schartye"]
For now, Straw and Chlorould are taking care of everything.
[cpg cn=true]


Chartier said this, but he was not in high spirits.
[cpg]


I just hope the castle will be finished soon. ......
[cpg]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_10_4.ui" time=1000]

[WAIT time=1500]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]


;//==============================
;//ヒロイン４が攻略対象となっている場合のみイベント発生
[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_14_1"]
[else]
[jump target="*eve_14_2"]
[endif]


*eve_14_1|A Journey Around the World


[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1500]


;//■分岐

;//室内ですので上下に黒帯を入れてください

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1000]
That night I confided my concerns to Chloro.
[cpg]


She had been assigned a guest bedroom, and I asked for it.
[cpg]


She was just about to go to bed and was rubbing her eyes as she got out of bed.
[cpg]


[OnName num="kousuke"]
I said to her, "I'm sorry, ....... It's the middle of the night.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude162"]
[OnName num="clolowlude"]
You don't have to apologize, and there's nothing to worry about," he said. You seem to have a lot of bad luck.
[cpg cn=true]


I wondered if he was complimenting me or what, but then I remembered that Chloro had originally been coming on to me too.
[cpg]


[OnName num="kousuke"]
 “Are you also attracted to my magic essence right now?”
[cpg cn=true]


Chloro doesn't say anything.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clolowlude163"]
[OnName num="clolowlude"]
I'm not going to let you say it,......," he said.
[cpg cn=true]


I'm not sure what he meant by that. I thought about what he meant.
[cpg]





;//■選択肢
[switch]
[case "I wondered if he was expecting something."]
	[swap]
	[jump target="*IseSel05_1"]
[case "Maybe he's not attracted to himself."]
	[swap]
	[jump target="*IseSel05_2"]
[endswitch]


1, I wonder if he expects something from me.
2. Maybe I'm not attracted to myself.



;//==============================
;//１、何か期待しているのだろうか
*IseSel05_1|A Journey Around the World




[OnName num="kousuke"]
...... chloro. Come to think of it, I haven't bothered you for a long time."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sClolowlude006"]
[OnName num="clolowlude"]
'Yeah. I've been ...... waiting for you."
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


[BG f="b_10_4_l.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************


;//Ｈシーンカット

And then one thing came to my mind.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[OnName num="kousuke"]
"Chloro. I know how to give a good massage.
[cpg cn=true]

[OnName num="kousuke"]
And I want to ask you something else. Do you have any resistance to tentacle creatures?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[VOICE f="Clolowlude187"]
[OnName num="clolowlude"]
What are you talking about, ......?　Tentacles?
[cpg cn=true]


[OnName num="kousuke"]
You know I can summon tentacles now. You know I can summon tentacles.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Clolowlude188"]
[OnName num="clolowlude"]
Don't be silly, you should have done that with Chartier or something.
[cpg cn=true]


The most important thing to remember is that you can't just go out and buy a new one.
[cpg]


The actuality is that you can find a lot of people who are not able to get the same kind of information. But there's also a lot of fun to be had with someone like Chloro who doesn't want to be a part of it.
[cpg]


[OnName num="kousuke"]
All right, I'll summon her. Don't run away.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clolowlude189"]
[OnName num="clolowlude"]
Wait, wait, wait, don't cast the spell!
[cpg cn=true]


In the meantime, I had succeeded in summoning him.
[cpg]


[OnName num="kousuke"]
Don't worry, it's just a massage."
[cpg cn=true]


She was terrified. But even if I tried to escape, I would not be able to.
[cpg]


I decided to just let my tentacles entangle Chloro's body.
[cpg]

[free time=800]

;//========================================
;//●ＣＧ（触手プレイ。マッサージと称している）ev_18
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：触手　　　　服装ex：無し
;//場所　：獣人の国＿室内寝室
;//時間　：夜
;//========================================

*Scene012|A Journey Around the World

[BG f="black.ui" time=1000]
[free time=1000]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sClolowlude007"]
[OnName num="clolowlude"]
Hey, it's really ...... weird.
[cpg cn=true]

[OnName num="kousuke"]
If you move too much, you might stimulate some weird acupuncture points."
[cpg cn=true]

I'm not a massage therapist.
[cpg]

The actual "I'm not sure I'm going to be able to stimulate the ...... acupuncture points with my tentacles, which I'm not used to moving.
[cpg]

 However, it cannot be said that it is a normal massage from the beginning.
[cpg]


;**【ＣＧ】 ev_18_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sClolowlude008"]
[OnName num="clolowlude"]
"Ugh, it feels ...... weird being touched."
[cpg cn=true]

[OnName num="kousuke"]
'I heard the soles of your feet have a lot of pressure points.'
[cpg cn=true]

I'm not sure if I'm going to be able to do that, but I'm going to try.
[cpg]

[VOICE f="sClolowlude009"]
[OnName num="clolowlude"]
"Oh, no, stop, that tickles!"
[cpg cn=true]

[VOICE f="sClolowlude010"]
[OnName num="clolowlude"]
It's so slippery. ...... Really, stop it."
[cpg cn=true]

She tried to shake it off, but continued to be unable to escape.
[cpg]

[VOICE f="sClolowlude011"]
[OnName num="clolowlude"]
I'm not sure if this is a massage, but I'd like you to give me a normal one.
[cpg cn=true]

[OnName num="kousuke"]
I'm probably stronger than I am as a human being. I thought you might be suited for it.
[cpg cn=true]

She accepted it with reluctance, though everything was full of sophistry.
[cpg]

;**【ＣＧ】 ev_18_b ***********************
[CG id=4 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sClolowlude012"]
[OnName num="clolowlude"]
The actual massage is really a very good way to get a good massage. Weird ......."
[cpg cn=true]

[OnName num="kousuke"]
I've summoned one once. I've been able to manipulate it a little bit."
[cpg cn=true]

I enjoyed her reaction for a while as we talked about that.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


[stflag Cha4flg=1]
;//ヒロイン４は攻略対象のまま
;//■分岐

[jump target="*IseSel05_3"]

;//==============================
;//２、自分に惹かれてないのかもしれない

*IseSel05_2|Traveling Around the World



I don't know, maybe Chloro isn't attracted to me.
[cpg]


Maybe he falls in love with me because of pheromones or something, but he doesn't like me himself.
[cpg]


[OnName num="kousuke"]
I'm sorry, I didn't mean to interrupt. I'm sorry for interrupting.
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
With these words, I left Chloro's place.
[cpg]

[FACE method="change_4" pos="2/3"]
I think Chloro had a look on his face that said, "Why?" ......
[cpg]


[if exp={getFlagValue("Cha4flg") == 1 }]
[stflag Cha4flg=-1]
[endif]

;//ヒロイン４は攻略対象でなくなる


;//■分岐

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


;//==============================

*IseSel05_3|

*eve_14_2|A Journey Around the World

;//==============================





After that. The construction of the Demon King's Castle proceeded smoothly.
[cpg]


With all the manpower we had, it didn't take long at all.
[cpg]


I wondered where the supplies were, but there were so many people that it was no trouble to procure them.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************





[OnName num="kousuke"]
It's steadily being built. ......
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile185"]
[OnName num="meile"]
Yes, it's almost finished. It will be completed soon. I don't know if I'd call the castle finished.
[cpg cn=true]


But other than the castle, not much has changed from the original village.
[cpg]


 If there was something like a castle town, it would be cool.
[cpg]

[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





Several days or nights passed, and finally ......
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[OnName num="kousuke"]
...... Nice chair.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye076"]
[OnName num="schartye"]
It suits you well, my Lord.
[cpg cn=true]


I don't feel bad. I guess I really am the Demon Lord.
[cpg]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude210"]
[OnName num="clolowlude"]
I'd like to be dressed like one, too. I'll leave that to you guys.
[cpg cn=true]


[OnName num="kousuke"]
I'll leave that to you guys.
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sFia010"]
[OnName num="fia"]
I'll leave that up to you guys.
[cpg cn=true]

;//;[FO layer="2/2"]


The first thing to do is to make sure that you have a good idea of what you're looking for.
[cpg]

[OnName num="kousuke"]
I'll leave it to you guys to do the rest.
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sMeile017"]
[OnName num="meile"]
I think so.
[cpg cn=true]

The most important thing to keep in mind is that you should not be afraid to ask for help from your friends and family.
[cpg]

[OnName num="kousuke"]
"Rustic and fashionable ......."
[cpg cn=true]

I'm not sure if this is a good idea or not, but it's a good idea. Aside from that, I wonder how long he's been working on it.
[cpg]


I wonder how long he's been making them. It's not something I can prepare right away.
[cpg]


But I thought it looked good on me now.
[cpg]


[OnName num="kousuke"]
I'm going to start wearing it today. I'm going to wear it from today.
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="sFia011"]
[OnName num="fia"]
Yes, it's worth it. It's worth it.
[cpg cn=true]


She laughed. Let's talk about the clothes. ......
[cpg]


It's a pretty big castle. It must be able to house a considerable number of people.
[cpg]


But even this is not enough, the number of subhumans coming to the castle is increasing day by day.
[cpg]


It seemed that subhumans were gathering from other continents and islands across the sea.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="sFia012"]
[OnName num="fia"]
Yes, some have volunteered to be soldiers to protect Mr. Kosuke. What should we do ......?"
[cpg cn=true]


[OnName num="kousuke"]
'There's nothing to be done about it. If you don't use those who are available, I will be killed sooner or later."
[cpg cn=true]


;//;[FO layer="4/4"]

[FACE method="change_2" pos="2/2"]
[VOICE f="Meile186"]
[OnName num="meile"]
I agree. I can't be too carefree about it.
[cpg cn=true]


The first thing to do is to make sure that you have a good idea of what you want to do.
[cpg]


I'm not going to be able to command it by myself.
[cpg]


[OnName num="kousuke"]
I'm going to start dividing up the roles properly.
[cpg cn=true]


[OnName num="kousuke"]
The military is in good hands with Chartier and Chloro, right? Can I leave it to them?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye077"]
[OnName num="schartye"]
I do so without being told. I have a bunch of people who are volunteering to be soldiers.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude211"]
[OnName num="clolowlude"]
...... I will help you as much as I can. It's to protect the Demon King.
[cpg cn=true]


[OnName num="kousuke"]
"Internal affairs are ...... mail?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile187"]
[OnName num="meile"]
I don't know anything about politics. I don't know anything about politics.
[cpg cn=true]

;//;[FO layer="2/2"]

[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile018"]
[OnName num="meile"]
I mean, I've never been in charge of ...... a group of people.
[cpg cn=true]


The mail was not going to listen to me. The most important thing to remember is that you can't afford to lose your money. ......
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Clolowlude212"]
[OnName num="clolowlude"]
 "Are you guys going to defy the Demon King's orders?"
[cpg cn=true]

[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile019"]
[OnName num="meile"]
I'm not really supposed to stand on top of people, though.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Schartye078"]
[OnName num="schartye"]
But for you, the Demon Lord is the hope to raise the status of the subhuman race.
[cpg cn=true]


[OnName num="kousuke"]
Please. You've been my friends from the beginning.
[cpg cn=true]


[OnName num="kousuke"]
I want you to stay by my side as much as possible. Is that too much to ask ......?"
[cpg cn=true]


[FACE method="change_4" pos="1/2"]
[VOICE f="sMeile020"]
[OnName num="meile"]
Ummm... ......, it's hard for me to say no when you act like that.
[cpg cn=true]


[OnName num="kousuke"]
Don't worry, I'm going to put you with an entourage that knows politics. I'm trying to get you an entourage that knows politics.
[cpg cn=true]


I'm sure Chartier will be the one to select such a person.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile021"]
[OnName num="meile"]
"I can't help it.
[cpg cn=true]


[OnName num="kousuke"]
"Okay. It's decided.
[cpg cn=true]



[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Fia103"]
[OnName num="fia"]
Um, I'm ......?
[cpg cn=true]


I've been thinking about that too. I was thinking about that too.
[cpg]


[OnName num="kousuke"]
Fia should be in charge of diplomacy, or ...... more specifically, negotiations with the elven nations.
[cpg cn=true]


The most important thing to remember is that it's not just the elven nations. The human country, Japan, which is right next to us, also sees me as a problem.
[cpg]


 But more than that, the elven country seems to be hostile to the Demon King.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Schartye079"]
[OnName num="schartye"]
It's not surprising. When the other world and this world were still separate, the Elves and the Demon King were at odds with each other.
[cpg cn=true]


[OnName num="kousuke"]
'That's right. Otherwise, it would be strange for them to be in conflict even though they are subhuman.
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Fia104"]
[OnName num="fia"]
'Yes,...... this causal relationship goes back quite far in the past. It's not something that can be managed through discussion.
[cpg cn=true]


[OnName num="kousuke"]
'Even so, I would like to reduce the number of unnecessary fights as much as possible. Fear.
[cpg cn=true]


[OnName num="kousuke"]
I think you're the right person for the job.
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Fia105"]
[OnName num="fia"]
"...... understands."
[cpg cn=true]


It's a handy thing ......
[cpg]

The first thing to do is to get a good idea of what you're looking for.
[cpg]

Before I was assigned to my first job, I was made to put on the outfit.
[cpg]

[FACE method="change_2" pos="1/2"]
[VOICE f="Schartye080"]
[OnName num="schartye"]
Interesting, my dear Demon Lord. It suits you well.
[cpg cn=true]


From now on, I'll have to wear such ostentatious clothes on a daily basis. ...... Well, that's okay.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Meile190"]
[OnName num="meile"]
'Come to think of it, we don't have a name for this country yet, do we?　Are we going to take over the name of the beastman country?"
[cpg cn=true]


[OnName num="kousuke"]
'...... Since we're here, I'd like to give it a different name.'
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia106"]
[OnName num="fia"]
What kind of name would you give it?　Not too much, something that will upset the nerves of other countries. ......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye081"]
[OnName num="schartye"]
"No. I dare to suggest that we should not even fight here. We should dare to suggest that we are willing to fight here.
[cpg cn=true]


Opinions are divided among these women, but ......
[cpg]


[OnName num="kousuke"]
"Simple, it's the land of the Demon King, isn't it?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile191"]
[OnName num="meile"]
I agree. I agree.
[cpg cn=true]


[FACE method="change_7" pos="2/2"]

[VOICE f="Fia107"]
[OnName num="fia"]
"Is that so......?　Doesn't it look a little scary?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye082"]
[OnName num="schartye"]
The opposite. Such a name doesn't maintain the dignity of the city.
[cpg cn=true]


After balancing the various opinions, the name "Land of the Demon King" was decided.
[cpg]


The "Land of the Demon King" was to be a new entity within the Land of the Beastmen.
[cpg]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト
;//【ＢＧ】『空』（夜）******************************************************





Some of the beastmen were against the rule of the Demon King.
[cpg]


The borders of the two countries had not been decided in the first place, so there were now two forces within the beastmen's country.
[cpg]


And my uneasiness did not disappear just because a castle was built.
[cpg]


I was holding the subhuman people in my arms one after the other, and the days passed by while I tried to cover up the fear that I might be killed at any moment.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************





[OnName num="kousuke"]
"Nn......?"
[cpg cn=true]


In the quiet corridor, a singing voice could be heard from somewhere. It was a familiar voice.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia108"]
[OnName num="fia"]
"Ah...... Kosuke-san."
[cpg cn=true]


The voice belonged to Fia.
[cpg]


[OnName num="kousuke"]
Fia. Do you like singing?
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Fia109"]
[OnName num="fia"]
Yes, I do. I like to sing,......, but at a time like this, I didn't want to forget what I like.
[cpg cn=true]


[OnName num="kousuke"]
What's the song called?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia110"]
[OnName num="fia"]
There are many names for it, and I don't know which is the right one,...... but it is a song that has been handed down in the land of the elves since I was a child.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia111"]
[OnName num="fia"]
The song soothes my soul. They are a reminder of a happy past.
[cpg cn=true]


[OnName num="kousuke"]
......
[cpg cn=true]


A happy past. I was a little caught up in the way she said it.
[cpg]


I guessed that Fia might be worried in her own way, so I ......
[cpg]


[OnName num="kousuke"]
Fia, where was your room? Where was your room?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia112"]
[OnName num="fia"]
"Uh,...... it's right around the corner.
[cpg cn=true]


[OnName num="kousuke"]
I'll stay with you if you can't sleep. If you can't sleep, I'll stay with you.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="sFia013"]
[OnName num="fia"]
"I can understand why you can't sleep."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


We both headed to Fia's room.
[cpg]


I snuggled up next to her and stayed with her until she fell asleep. ......
[cpg]

;//Ｈシーンカット



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************





Then I continued to work on my magic.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Fia135"]
[OnName num="fia"]
I'm getting pretty good at it," he said.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye083"]
[OnName num="schartye"]
I'm not at all. No matter how good you are, it usually takes five years to get to this point.
[cpg cn=true]


[OnName num="kousuke"]
Is that what it is ......?"
[cpg cn=true]


The most important thing to remember is that you can now summon not only tentacles, but also simple creatures like slime.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Meile192"]
[OnName num="meile"]
'It's good that Kosuke is now able to defend himself, isn't it?
[cpg cn=true]


[OnName num="kousuke"]
'Yes, it is. 'Because he left it to Chartier and Chloro to take care of him.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude213"]
[OnName num="clolowlude"]
Really. How many assassins have you taken care of ......?
[cpg cn=true]


I shuddered when I heard that, but I was somewhat relieved.
[cpg]


I'll take care of myself. Not only that, but now I have friends.
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_1.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城内＿廊下』（朝）******************************************************





[OnName num="soldier_A"]
I can't believe the Demon Lord is back. ......
[cpg cn=true]


[OnName num="soldier_B"]
"Oh, yes. The day is coming soon when we beastmen will have the right.
[cpg cn=true]


[OnName num="soldier_A"]
I know. I'm not sure how much I've been abused up until now,.......
[cpg cn=true]


I'm not sure if you've seen me.
[cpg]


[OnName num="kousuke"]
......."
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

The actual "I'm not a fan of the way you do it," he said, "but I'm not a fan of the way you do it.
[cpg]


The most important thing to remember is that you can't just take a look at the actual product or service and expect it to be just as good. Probably Chartier.
[cpg]


What can I say, it's not annoying, but it's also a little bit disturbing. ......
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

I go outside again, thinking, "What the heck. I've got Fia with me next to me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia136"]
[OnName num="fia"]
I'm wondering, "Well,......, what can I do for you?"
[cpg cn=true]


[OnName num="kousuke"]
No," he says. I heard there are wild tentacle creatures around here.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia137"]
[OnName num="fia"]
What do you mean, ......?　What are you talking about, Kosuke?
[cpg cn=true]

[OnName num="kousuke"]
I have to study wild creatures in order to use summoning magic.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sFia014"]
[OnName num="fia"]
I'm ...... not good with such creatures.
[cpg cn=true]


[OnName num="kousuke"]
I'm not very good with those creatures. I'm not good with those creatures.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト




As soon as I entered the forest, the creature appeared.
[cpg]

[VOICE f="sFia015"]
[OnName num="fia"]
I was so excited that I was surprised to see it.
[cpg cn=true]

;//========================================
;//●ＣＧ（触手がフィアに絡まる）ev_20
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：触手　　　　服装ex：無し
;//場所　：森
;//時間　：昼
;//備考　：公式サイト一枚目のＣＧです
;//========================================

*Scene016|A Journey Around the World

[BG f="black.ui" time=1000]
[free time=1000]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sFia016"]
[OnName num="fia"]
I can't untie ......!　What power!
[cpg cn=true]

[OnName num="kousuke"]
Wait for me. Now help ...... no ......"
[cpg cn=true]

I thought to myself. I thought to myself, "It would be boring to help Fia out right away.
[cpg]

 On the other hand, if you just say it's boring, she won't be convinced.
[cpg]

[OnName num="kousuke"]
I'd like you to keep her interested for a while while you shake her out of it.
[cpg cn=true]

Fia looks at me with a surprised face.
[cpg]

;**【ＣＧ】 ev_20_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia017"]
[OnName num="fia"]
I'm in real trouble.　I'm in real trouble.
[cpg cn=true]

I know you're in trouble. I know you're in trouble, but I've been trying to come up with an excuse.
[cpg]

[OnName num="kousuke"]
I've got to look at the ecology, or else my repertoire of summonses will be ......
[cpg cn=true]

[VOICE f="sFia018"]
[OnName num="fia"]
It's terrible, Kosuke-san. ......!
[cpg cn=true]

[OnName num="kousuke"]
It may be terrible, but bear with me.
[cpg cn=true]

[VOICE f="sFia019"]
[OnName num="fia"]
It's as if I'm the bait.
[cpg cn=true]

The most important thing to remember is that you should never be afraid to ask for help.
[cpg]

[OnName num="kousuke"]
I'm not sure if it's a good idea or not, but it's a good idea. Just like an octopus.
[cpg cn=true]

;**【ＣＧ】 ev_20_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia020"]
[OnName num="fia"]
Please help me, don't just observe!
[cpg cn=true]

Pretending to examine the tentacled creature, while also observing Fia ......
[cpg]

After that, I rescued her after understanding the ecology of the creature in one way or another.
[cpg]




;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_10_3.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************

[window target=true]




In the meantime, it was getting late in the evening.
[cpg]


It is time to return to the castle. Chartier is the real commander, but it's not a good thing that I'm not at the castle.
[cpg]


[OnName num="kousuke"]
I'm going back to the castle. Fear.
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sFia021"]
[OnName num="fia"]
"...... Yes. Please don't ask me to do this again.
[cpg cn=true]


[OnName num="kousuke"]
I don't know. I can't make any promises.
[cpg cn=true]


Fia gave a subtle look. Well, okay.
[cpg]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Then, I spend the night in my room.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドアノック』





I hear a knock on the door and I answer it.
[cpg]


[OnName num="kousuke"]
Who is it?"
[cpg cn=true]



[VOICE f="Schartye084"]
[OnName num="schartye"]
It's Chartier. May I come in?
[cpg cn=true]


[OnName num="kousuke"]
"......, yeah. Come in.
[cpg cn=true]



[SE f="se002"]
;//【ＳＥ】『ドア開く』





[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSchartye015"]
[OnName num="schartye"]
How are you doing? How have you been with the subhuman girl?
[cpg cn=true]


[OnName num="kousuke"]
Well, you know, just about. ......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sSchartye016"]
[OnName num="schartye"]
I don't want to be so-so. I'm not going to be able to do that.
[cpg cn=true]


 While saying that, Chartier also approaches me.
[cpg]


 I wonder if she has feelings for me too. It just didn't seem like he was being seduced by pheromones.
[cpg]


[OnName num="kousuke"]
'......I've never been this popular.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye087"]
[OnName num="schartye"]
'Why don't you just take it in stride? The Demon King is the Demon King."
[cpg cn=true]


That may be so, but somehow, I can't explain it. ......
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye088"]
[OnName num="schartye"]
I'm so honored to be touched by the Demon King. I'm so happy."
[cpg cn=true]


[OnName num="kousuke"]
"...... I see."
[cpg cn=true]


Chartier says something like that. It's hard to say.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



I can't read her mind. I don't know how much she really means it. ......
[cpg]


;//Ｈシーンカット

;//ブラックアウト

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Then I had a chat with Chartier about other things.
[cpg]


Per Fear, I wondered if she would be jealous, but I couldn't refuse her.
[cpg]


Besides, I had a great reason to wake up as a demon king.
[cpg]


Fia would understand,.......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





The night is dawning. Everything was going well in the land of the Demon King so far.
[cpg]


The number of people increased and the number of things increased. The beastmen were self-sufficient to begin with.
[cpg]


There was never a shortage of food and there was never any discontent.
[cpg]


As the number of people increases, the types of business also increase. Furthermore, as the number of people increases, a place to live will become necessary.
[cpg]


The town was developed. Houses and stores were built and developed.
[cpg]


In the end, I realized that a nation is driven by its people.
[cpg]



;//ブラックアウト

[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=100]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



;//背景が変化　村の背景が徐々に薄くなって城下町になる感じ




[BG f="b_05_2.ui" time=2500]
[WAIT time=2500]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[BGM f="bg_d3"]


[window target=true]



As a result, the area around the Demon King's castle was becoming more and more like a castle town.
[cpg]


The people who had been scattered from one place to another, from one tribe to another, were now gathering here.
[cpg]


Naturally, the Elven nation and Japan would not think well of this. That much is true.
[cpg]


If they are not good, they may march on us. ......
[cpg]


[OnName num="kousuke"]
"...... is it any wonder?"
[cpg cn=true]


Somehow, I was walking with Meir next to me. She was optimistic, but.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile193"]
[OnName num="meile"]
I'm sure that one day that day will come. I'm sure that day will come.
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="4/2" time=800]


She was not the type of person to fool around with reality. I'm not going to say it's going to be peaceful forever.
[cpg]



[SE f="se009"]
;//【ＳＥ】『走る』

[move from="2/3" to="1/2" ease="easeInOutSine" time=1000]

[move from="4/2" to="2/2" ease="easeInOutSine" time=1000]


[STOPBGM]




Then Fia came running in. Out of breath, she didn't look like she was here to give us good news.
[cpg]



[OnName num="kousuke"]
She said, "What's wrong? Fear.
[cpg cn=true]



[VOICE f="Fia160"]
[OnName num="fia"]
...... soldiers from the land of the elves are about to invade."
[cpg cn=true]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************






I hurriedly gathered all four of us together and we discussed the situation.
[cpg]


The Elven nation is finally about to lead their army to attack the Demon King's country. I was afraid that something would happen.
[cpg]

[free time=800]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye110"]
[OnName num="schartye"]
There is nothing to worry about. The difference in strength is clear.
[cpg cn=true]


Chartier said there was no need to worry, but I had a lot to think about.
[cpg]


Will the Elven nation lose? Or the Demon King's country will lose.
[cpg]


Either way, soldiers could end up dying for me.
[cpg]


Whether it is the soldiers of the Demon King's country or the soldiers of the Elven country, there is no way that either of them will be safe.
[cpg]


Is that really the right thing to do? ......
[cpg]


[OnName num="kousuke"]
What do you think, Fear......?
[cpg cn=true]

[free time=800]
[WAIT time=1]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Fia161"]
[OnName num="fia"]
"I, too, seek dialogue with the Elven Nation,......, but it's difficult.
[cpg cn=true]


After all, we have been bickering for years.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Clolowlude214"]
[OnName num="clolowlude"]
I'm not worried about it. I've got a lot of people in my army, and I've got weapons.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Schartye111"]
[OnName num="schartye"]
I've got a lot of people in my army and I've got weapons. There is no way we can lose.
[cpg cn=true]


The actuality is, I don't think I'd like to kill indirectly.
[cpg]

[free time=800]
[WAIT time=1]
[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile194"]
[OnName num="meile"]
You don't look so good. I think you need to cool down a bit."
[cpg cn=true]


[OnName num="kousuke"]
"...... oh."
[cpg cn=true]


*IseSel06_3|
*eve_15_2|A Journey Around the World


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





Morning comes. My anxiety continued to run deep.
[cpg]


Not anxiety, but outright fear.
[cpg]


People will die for me. Subhuman or not, it's the same thing.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude215"]
[OnName num="clolowlude"]
Are you scared?"
[cpg cn=true]


I was discussing it with Kuroro, who was visiting me in my room at the time.
[cpg]


[OnName num="kousuke"]
"I'm not afraid," he said, "but I'm not afraid to say that I'll die more for ...... my life alone.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude216"]
[OnName num="clolowlude"]
It's not just your life anymore. If we lose you, the kingdom of the Demon King will collapse."
[cpg cn=true]


That's a good argument. Indeed, it is true. ......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude217"]
[OnName num="clolowlude"]
Then all of us subhumans will be persecuted even more than before.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude218"]
[OnName num="clolowlude"]
Not only that. Maybe those of us who joined the Demon Lord will be killed.
[cpg cn=true]


It's not that I haven't considered that possibility.
[cpg]


 Not only Kullulu, but also Fia who was originally an elf.
[cpg]


I've come to the point of no return. I knew that, but I was afraid, as Chloro said: ......
[cpg]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************





So I tried to learn new magic.
[cpg]


There was no other way. I would invent a magic that would allow me to do without fighting.
[cpg]


I don't know if there is such a thing, but I just have to find out.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia162"]
[OnName num="fia"]
"......I feel like if there was such a convenient thing, I wouldn't have to go through the trouble. ......
[cpg cn=true]


[OnName num="kousuke"]
"Don't say that, ......, it would be depressing."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Fia163"]
[OnName num="fia"]
I'm sorry.
[cpg cn=true]

[free time=800]

[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Clolowlude219"]
[OnName num="clolowlude"]
I know how Fia feels. Why don't you just fight like a normal person?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye112"]
[OnName num="schartye"]
I don't blame her at all.
[cpg cn=true]


The first thing to do is to make sure that you have the right tools and the right people to help you. The first thing to do is to find the right place.
[cpg]


Anyway, these three people are skilled in magic. The only way is to find out from them.
[cpg]


The castle had just been built, and there was no room for books.
[cpg]


So, we have no choice but to ask them steadily. I asked every wizard in the castle.
[cpg]



[free time=1000]

;//ブラックアウト

[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************



[OnName num="therianthropy_A"]
Is there a beastman who can use magic ......?　I'm sure there are some.
[cpg cn=true]


[OnName num="therianthropy_B"]
But there is no such thing as magic that doesn't require fighting. ......
[cpg cn=true]


[OnName num="therianthropy_C"]
"Oh, I've heard of this kind of magic. I have heard of this kind of magic.
[cpg cn=true]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夕方）******************************************************





So I finally found the magic I was looking for. The magic that they finally found was called "enchantment magic.
[cpg]


The magic that ordinary subhumans could not handle might be used by me, the Demon King.
[cpg]


I heard that it was something that would further enhance my original power to attract subhumans .......
[cpg]


[OnName num="kousuke"]
What do you think? Fear.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Fia164"]
[OnName num="fia"]
I think it might be a blind spot. I think it's a good idea.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye113"]
[OnName num="schartye"]
"I don't agree. It's a coward's idea.
[cpg cn=true]


Ignoring Chartier's words for the moment, I proceeded with my story.
[cpg]


The actuality that the elves are subhuman doesn't change the fact that they abhor the Demon King.
[cpg]


If you are a woman, you must be fascinated by the magical element of the Demon King. Just as Fear is: ......
[cpg]


[OnName num="kousuke"]
Are there any women in the elf army?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Clolowlude220"]
[OnName num="clolowlude"]
There are. I think about half of them are women.
[cpg cn=true]


In the elven tribe, it seems that women ...... are the ones who are skilled in handling magic.
[cpg]


 That's why there are women on the front line, and in fact the general is also a woman.
[cpg]

[STOPBGM]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Once that was decided, I acted quickly.
[cpg]


I couldn't help but hurry. The war was about to start.
[cpg]


It was up to my magic to prevent it from happening.
[cpg]


In the first place, even though I am the Demon King, it doesn't mean that I have become a Demon King in my heart as well.
[cpg]


Up until now, even though I can't be called a good ...... man, I lived as an ordinary businessman.
[cpg]


I can't stand the thought of people dying under my orders or to protect my life.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





I stayed up all night, one or two nights, designing and completing the ...... magic circle.
[cpg]


[OnName num="kousuke"]
"...... done, I think."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia165"]
[OnName num="fia"]
"What do you think ......?　Is it going to work?
[cpg cn=true]


[OnName num="kousuke"]
I can't use it here. We can't use it here, because we don't know what kind of side effects it might have.
[cpg cn=true]


Besides, we can't attract more subhumans in this country than we already do.
[cpg]


[OnName num="kousuke"]
We have one shot at this. We've already declared war on them, and there's nothing we can do to hurry it up.
[cpg cn=true]


As we were discussing this, Maille came strolling up to me and said.
[cpg]

[free time=800]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile195"]
[OnName num="meile"]
What's wrong?　Kosuke, you look like you haven't had enough sleep.
[cpg cn=true]


Kosuke, you look like you haven't had enough sleep," she said. Meir is so carefree that he doesn't know anything about it. ......
[cpg]


I guess he doesn't even think that his life is at stake.
[cpg]


[OnName num="kousuke"]
'I can't let this happen. Let's sneak into the land of the elves.
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Meile196"]
[OnName num="meile"]
Uh-huh. Uh, what's the plan?
[cpg cn=true]


[OnName num="kousuke"]
...... Fear, explain it to him.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





The operation was to be carried out immediately.
[cpg]


The cooperation of the Harpies was enlisted. The actual "I'm not sure what to do with it.
[cpg]


They said it would be no problem at all if I could carry only one person.
[cpg]


In the first place, when I returned to Japan, I was also carried by the Harpies.
[cpg]


[OnName num="kousuke"]
"Then, will you carry me to ......?
[cpg cn=true]

[OnName num="harpy_A"]
Yes, I will. You look tired, Kosuke-sama.
[cpg cn=true]


[OnName num="kousuke"]
Oh, well,......, ah.
[cpg cn=true]


I was tired and fell asleep while the harpies carried me.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************





The most important thing to remember is that you can't just take a few minutes to do a little bit of work.
[cpg]


The actual "I've been a little bit of a fool," he said, "and I've been a little bit of a fool.
[cpg]


[OnName num="suspicious_man"]
I've been waiting for you, sir.
[cpg cn=true]


In the land of the elves, there was a suspicious man whom I had met one day in an airship.
[cpg]


[OnName num="kousuke"]
...... what were you after all?
[cpg cn=true]


[OnName num="suspicious_man"]
I'm like a henchman of Chartier's.
[cpg cn=true]


[OnName num="kousuke"]
You've been in the land of the elves all this time?　Reconnaissance.
[cpg cn=true]


[OnName num="suspicious_man"]
That's about it. Come here quickly.
[cpg cn=true]


 This guy must be having a hard time.
[cpg]


 On the other hand, he doesn't seem to be jealous of me who is holding Chartier.
[cpg]


The actual "I'm not sure what to do with it.
[cpg]


If so, I knew that I could not fail in this mission.
[cpg]

;//qwe

;//上下に黒帯を入れてください
[STOPBGM]
[BGM f="bg_si"]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]



I disguise myself as a member of the military in the land of the elves and sneak in.
[cpg]


I had asked the man in question to get me some armor that looked like it.
[cpg]


I had not thought this through at all. To be honest, it was a big help to have him prepare it for me.
[cpg]


If this plan works, at least the female elves won't be able to attack me.
[cpg]


With half of my army cut to the bone, it would be difficult to attack.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
Fia and a few harpies were with me.
[cpg]


Ostensibly, Fia had come to negotiate with them to avoid a battle.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia166"]
[OnName num="fia"]
"......We wish you luck, Kosuke-san."
[cpg cn=true]


[OnName num="kousuke"]
Oh, and Fear, too. The first thing you need to do is to get out of the way.
[cpg cn=true]


The most important thing to do is to make sure that you have a good time with your family and friends.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]

[WAIT time=100]
[BG f="b_02_2_l.ui" time=1000]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************




I really needed to get to a place where there were a lot of military personnel.
[cpg]


For that purpose, perhaps an inn would be better than a training ground or something like that. And it was nighttime.
[cpg]


I deployed my technique. I had a good idea of where I was going to be, but it wasn't perfect.
[cpg]


Still, if I can avoid a fight, even just a little bit.
[cpg]


[OnName num="elf_soldier"]
What's with the ......?　New guy?
[cpg cn=true]


[OnName num="kousuke"]
Yes, sir!　I'm looking forward to your guidance from now on!
[cpg cn=true]


[OnName num="elf_soldier"]
"......?"
[cpg cn=true]


I could see that he looked doubtful. But he didn't follow me too closely.
[cpg]


I was nervous, but tried not to say anything unnecessary as much as possible.
[cpg]


[OnName num="harpy_A"]
...... With this armor, it's hard to tell if it's a hand or a feather."
[cpg cn=true]


The harpy girl was also wearing elven armor. This way she can accompany me even if she can't fly.
[cpg]


If the magic is activated, maybe I can escape with her.
[cpg]


[OnName num="kousuke"]
When the magic goes off, there will probably be someone chasing me.
[cpg cn=true]


[OnName num="kousuke"]
If you need to escape, I'm counting on you.
[cpg cn=true]


[OnName num="harpy_A"]
I'll leave it to you. I will protect you, Kosuke-sama.
[cpg cn=true]


I'm counting on you. While I was thinking that, I had come to the center of the dormitory.
[cpg]




I had to draw a magic circle. It would not take more than a moment.
[cpg]


If Chartier or Chloro were here, I'm sure one or two people would find me and knock me out. ......
[cpg]


But there was no use thinking about that now. In a great hurry, he drew the magic circle in blood.
[cpg]


The size of the magic circle is not that big. However, my blood is said to have magic power flowing through it.
[cpg]


Even a small magic circle should have a wide range of effects.
[cpg]



[SE f="se014"]
;//【ＳＥ】『地鳴りのような音』



A powerful magic is activated. The earth rumbles. ......
[cpg]


This will definitely be noticed. But I don't care if they notice me.
[cpg]


[STOPBGM]
[BGM f="bg_tc"]



[OnName num="elf_soldier"]
What are you doing?　What are you doing?
[cpg cn=true]


[OnName num="harpy_A"]
Kosuke-sama!
[cpg cn=true]


The magic is already activated. All you have to do now is escape.
[cpg]


[OnName num="kousuke"]
Let's get out of here!
[cpg cn=true]


[window target=false]

[transition target={true} rule="108.jpg" color={0x000000ff} time=1]
[WAIT time=1]
[free time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="108.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『街＿エルフの国』（夜）******************************************************

[window target=true]


[SE f="se009"]
;//【ＳＥ】『走る』


[OnName num="elf_soldier_A"]
He's gone!　That way!
[cpg cn=true]


[OnName num="elf_soldier_B"]
What the hell did the Demon Lord do by himself?
[cpg cn=true]


[OnName num="elf_soldier_A"]
I don't care!　We've got to get him now!
[cpg cn=true]


We're running for our lives. If we get caught, we're really fucked.
[cpg]


But with a few harpies on our side, it was a given that we would be able to escape.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1500]
;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】『羽ばたく』
[BG f="b_11_4.ui" time=1000]

[WAIT time=1500]

[BGM f="bg_si"]
;//【ＢＧ】『空』（夜）******************************************************



I was carried by a harpy who had taken off his armor, and we left the land of the elves and are now on the sea.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kousuke"]
Fear!　You're all right, aren't you?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia167"]
[OnName num="fia"]
'Yes, somehow. Kosuke-san was also safe, wasn't he?
[cpg cn=true]


[OnName num="kousuke"]
'Yeah. I think the magic worked, but ...... there's no way to be sure.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sFia022"]
[OnName num="fia"]
I think it probably worked. The actuality that the magic was only just activated, but it still made my heart beat wildly.
[cpg cn=true]


I see. The actuality that it is so in a short period of time, it seems to be effective.
[cpg]


The actuality is, it's still too early to be reassured. Even though I know that, ......
[cpg]


I had a sense of accomplishment for the time being. I felt like I had fulfilled my role as the Demon King and that too was headed in the direction of a peaceful resolution.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





Exhausted, I slept soundly that day. I woke up in the afternoon.
[cpg]


The good news was immediate. Half of the Elven army could no longer attack the Demon Lord.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile197"]
[OnName num="meile"]
Some of them would rather join the kingdom of the Mad King," he said. It seems that the Elven army can no longer march.
[cpg cn=true]


[OnName num="kousuke"]
Oh, I see. ...... huh."
[cpg cn=true]


I gasped. The immediate danger was averted.
[cpg]


Meir looked like he deserved this to happen, but it was pretty close.
[cpg]


I was relieved now, even more so because I had thought it was a 50-50 chance that it would work out.
[cpg]



[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1500]
[STOPBGM]
;//ブラックアウト


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_05_3_l.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城下町＿魔王の国』（夕方）******************************************************



That evening, I showed up to the guys at the castle, still tired.
[cpg]



[BGM f="bg_mi"]



[OnName num="therianthropy_A"]
Welcome back, Demon Lord!
[cpg cn=true]


[OnName num="therianthropy_B"]
The operation was a great success!　It was a great success!
[cpg cn=true]


[OnName num="kousuke"]
No, no, ...... there's no need to make such a big fuss.
[cpg cn=true]


[OnName num="therianthropy_A"]
Let's have a feast today. Everyone's glad we didn't start a war.
[cpg cn=true]


[OnName num="kousuke"]
"So ...... it's not something to make a big fuss about.
[cpg cn=true]


I was relieved inside, though.
[cpg]


I was relieved inside. That's a good thing.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************





The whole country is celebrating. Some people are even making it an annual holiday.
[cpg]


Everyone is happy or sad about what I'm doing. Well, if I die, this country will be turned upside down. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Fia168"]
[OnName num="fia"]
'......Good for you, Mr. Kosuke.
[cpg cn=true]


[OnName num="kousuke"]
Well. My life depends on it.
[cpg cn=true]


That day's party was going to last all night. ......
[cpg]


[STOPBGM]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I was still tired, so I went back to my room.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye114"]
[OnName num="schartye"]
I don't like this way of doing things," he said. You're gutless."
[cpg cn=true]


[OnName num="kousuke"]
I was still tired, so I walked back to my room. Don't come into my room without permission.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye115"]
[OnName num="schartye"]
It's all right. If it weren't for me, you'd have been assassinated by now.
[cpg cn=true]


[OnName num="kousuke"]
But I'm the one who drove the elves away, didn't I?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye116"]
[OnName num="schartye"]
That must be why they are in a celebratory mood. I don't understand.
[cpg cn=true]


...... Chartier is a hateful man.
[cpg]


But Chartier should have been fascinated by me all along.
[cpg]


But he wasn't as aggressive as the rest of them. Maybe there's something he's holding on to.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye117"]
[OnName num="schartye"]
Look. There was so much extra alcohol left over from the celebration. Maybe subhumans don't like to drink.
[cpg cn=true]


[OnName num="kousuke"]
What about you?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye118"]
[OnName num="schartye"]
I'm strong. Shall we play?
[cpg cn=true]


I'm not that strong, and I'm tired.
[cpg]


[OnName num="kousuke"]
Let's drink to this victory as normal.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye119"]
[OnName num="schartye"]
"So it's not a victory. ......
[cpg cn=true]



[SE f="se00"]
;//【ＳＥ】『乾杯』





From there, we drank together for a while.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye120"]
[OnName num="schartye"]
I'm not that strong, but I'm tired of it. What do you think of me?
[cpg cn=true]


[OnName num="kousuke"]
"I am grateful to ...... you.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye121"]
[OnName num="schartye"]
I see. That's all there is to it.
[cpg cn=true]


The most important thing to remember is that the best way to get the best out of your business is to be a good businessman.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Schartye122"]
[OnName num="schartye"]
I have other feelings.
[cpg cn=true]


She sounded as if she was expecting something.
[cpg]


She, too, is being misled by pheromones. ......
[cpg]


I decide, unsure of what to do.
[cpg]





;//■選択肢
[switch]
[case "I'm too tired to do anything."]
	[swap]
	[jump target="*IseSel07_1"]
[case "Respond to Chartier's feelings."]
	[swap]
	[jump target="*IseSel07_2"]
[endswitch]



1, I'm too tired to say anything.
2, Respond to Chartier's feelings



;//==============================
;//１、疲れているので何も言わない
*IseSel07_1|A Journey Around the World


[OnName num="kousuke"]
......"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sSchartye018"]
[OnName num="schartye"]
Heh. After saying all this, you don't say anything back?"
[cpg cn=true]


Chartier laughs a little ruefully. After that, he said, "You are also free to choose not to accept my invitation.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="sSchartye019"]
[OnName num="schartye"]
The most important thing to remember is that you are free to choose not to accept my invitation. After all, he is the Demon King.
[cpg cn=true]


And then he said nothing more.
[cpg]


I wondered if I had done something wrong ......, but I didn't think it was a good idea to be too suggestive.
[cpg]



;//ヒロイン３は攻略対象でなくなる
[if exp={getFlagValue("Cha3flg") == 1 }]
[stflag Cha3flg=-1]
[endif]

;//■分岐

[jump target="*IseSel07_3"]

;//==============================
;//２、シャルティエの気持ちに応える

*IseSel07_2|A Journey Around the World



[OnName num="kousuke"]
I'm grateful to Chartier. If it weren't for Chartier, I would have been dead long ago."
[cpg cn=true]


Chartier looked happy. He was always ruthless, but he must have been thinking about me the whole time.
[cpg]


I guessed it and nodded my head.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="sSchartye020"]
[OnName num="schartye"]
I was so happy to hear that the demon king would do something like this for me.
[cpg cn=true]


[OnName num="kousuke"]
I'm sure he's thinking about me all the time, and I know he's thinking about me. I'm sure you've been waiting for this.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye150"]
[OnName num="schartye"]
I'm sure it's natural. I'm sure the other girls would have done the same.
[cpg cn=true]


I'm sure ...... they are. I have a lot of people I have to love.
[cpg]


I guess it's all due to the pheromones that attract subhumans.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

;//Ｈシーンカット


;//ブラックアウト


;//ヒロイン３は攻略対象のまま
;//■分岐

;//==============================

*IseSel07_3|A Journey Around the World

;//ブラックアウト
[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]




Then. The fact that the Demon King defeated the soldiers of the Elven Nation became known all over the world.
[cpg]


Not only Japan, but also the whole world is now after me, the Demon King.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile198"]
[OnName num="meile"]
What are you going to do?　Kosuke......
[cpg cn=true]


[OnName num="kousuke"]
"Even if you ask me what I'm going to do. The whole world is against me.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia169"]
[OnName num="fia"]
'In the world, there is a movement to create an allied army. They want us to seal Kosuke-san at any cost. ......"
[cpg cn=true]


I was forced to make a further decision. The whole country is connected and against me.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia170"]
[OnName num="fia"]
"Somehow, we need to let them know that the Demon King is not dangerous. ......
[cpg cn=true]


Fear tries to proceed peacefully. However.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude221"]
[OnName num="clolowlude"]
"Really?　I think he can conquer the world since he has the power of the Demon King.
[cpg cn=true]


Crollo says so. I'm lost again.
[cpg]


[free time=800]

Do I want peace or world domination?
[cpg]


I think it probably depends on what I've done up to this point.
[cpg]


How much have I awakened as a demon king?
[cpg]


In other words, how many subhuman girls have I been invited to ......?
[cpg]


How many have I responded thoughtfully?
[cpg]


As I thought back on these thoughts, I had only one thing on my mind.
[cpg]


;//※攻略ヒロインがどれだけ居るか　によって分岐
;//※全てのヒロインを攻略対象にしている場合、魔王として覚醒　世界を征服するルートへ分岐
;//※そうで無い場合、魔王として覚醒していない　平和を望むルートへ分岐



[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*root_heiwa"]
[endif]


[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*root_heiwa"]
[endif]


[if exp={getFlagValue("Cha4flg") == 0 }]
[jump target="*root_heiwa"]
[endif]

[jump target="*root_mao"]

;//qwe

;//[jump target="*root_heiwa"]

;//==============================
;//攻略対象になっていないヒロインが居る場合


*root_heiwa|A Journey Around the World


[OnName num="kousuke"]
'......I'd like things to go on in peace.'
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude222"]
[OnName num="clolowlude"]
I knew you would say that. You're a fool, Demon Lord.
[cpg cn=true]


[OnName num="kousuke"]
"Call me what you want.
[cpg cn=true]


My desire was to seek peace.
[cpg]


I was told that if I came in contact with too many subhumans, I would awaken as the Demon Lord. ......
[cpg]


Now I wasn't so much tempted without moderation.
[cpg]


After all, I didn't want to be a murderer.
[cpg]


Even though I had become the Demon King, I did not think that I would expand my power from this country to other countries.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I would not kill anyone, and I would gather my wits to make it all go away.
[cpg]


Fear and Meir seemed to take me seriously, but ......
[cpg]


Chartier and Chlorouloud wanted to say that they had not fought hard enough.
[cpg]


A sleepless night. I visit a woman.
[cpg]


I go to ......
[cpg]


;//＠
;//※ここまでの選択肢で攻略対象になっているヒロインのみ選択肢に出てくる
;//※ヒロイン１は必ず選択肢に残る
;//※ヒロイン１しか残っていない場合、選択肢は発生せずヒロイン１ルートへ

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*GoRoot_1"]
[endif]

;//10?0?
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*GoRoot_01"]
[endif]

;//1000?


;//10000	フィアのみなのでフィアルート
[jump storage="ep002.ks" target="*start"]


;//1010?
*GoRoot_01


;//1010
;//■選択肢
[switch]
[case "Fia"]
	[swap]
	[jump storage="ep002.ks" target="*start"]
[case "Chartier"]
	[swap]
	[jump storage="ep004.ks" target="*start"]
[endswitch]



;//11?0?
*GoRoot_1
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*GoRoot_11"]
[endif]


;//1100
;//■選択肢
[switch]
[case "Fia"]
	[swap]
	[jump storage="ep002.ks" target="*start"]
[case "Maille"]
	[swap]
	[jump storage="ep003.ks" target="*start"]
[endswitch]



;//1110?
*GoRoot_11


;//11100
;//■選択肢
[switch]
[case "Fear"]
	[swap]
	[jump storage="ep002.ks" target="*start"]
[case "Maille"]
	[swap]
	[jump storage="ep003.ks" target="*start"]
[case "Chartier"]
	[swap]
	[jump storage="ep004.ks" target="*start"]
[endswitch]



1, Fia
2, Maille
3, Chartier



;//==============================

;//全てのヒロインが攻略対象になっている場合
;//asd
*root_mao|The Demon King



All I wanted was world domination.
[cpg]


I guess I am awakening as a Demon King after having come into contact with so many subhumans.
[cpg]


I wondered what steps I could take to conquer the world.
[cpg]


It may be possible for me to do it by myself.
[cpg]


Still, I wanted to ask for someone's help. I was not sure if I could do it alone.
[cpg]


If I was to go back to the book, it was also a journey to find my subhuman wife.
[cpg]


It would be good to choose one person as a partner.
[cpg]


[STOPBGM]


[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




It was night. I no longer had any doubts about plotting world domination or choosing just one person.
[cpg]


I love only one person. It's ......
[cpg]



;//※全てのヒロインが攻略対象になっているため、必ず全ての選択肢がある


;//■選択肢
[switch]
[case "Fear"]
	[swap]
	[jump storage="ep005.ks" target="*start"]
[case "Maille"]
	[swap]
	[jump storage="ep006.ks" target="*start"]
[case "Chartier"]
	[swap]
	[jump storage="ep007.ks" target="*start"]
[case "Chloro-Urudo"]
	[swap]
	[jump storage="ep008.ks" target="*start"]
[endswitch]


1, Fear
2, Maille
3, Chartier
4, Chloro-Urudo



