
;//==============================
;//２、メイル

*start

*ep006
*IseSel09_2|I'm a Demon Lord・ Meir

[SCENE id=3]


It was Meir. I want her and I to rule this world together.
[cpg]


I don't know if Meir is good at magic, and I don't know what kind of opinion I can get from her. ......
[cpg]


Still, I went to Meir 's room.
[cpg]




;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]

[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************





[OnName num="kousuke"]
“I need your wisdom. Meir "
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile361"]
[OnName num="meile"]
"You're going to ask me? Why me?”
[cpg cn=true]


[OnName num="kousuke"]
“I can't ask anyone else but you. You have to understand.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile362"]
[OnName num="meile"]
“I can't understand. There are a lot of people that are smarter than me.”
[cpg cn=true]


[OnName num="kousuke"]
“That's not the point. I want your advise Meir .”
[cpg cn=true]


I wonder if Meir knows what I'm thinking.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile363"]
[OnName num="meile"]
“I'm not very smart……..I might not be able to come up with anything ……."
[cpg cn=true]


[OnName num="kousuke"]
"That's okay. Meir, you are my ......."
[cpg cn=true]


I didn't say anything else. Meir blushes.
[cpg]


She seemed to have guessed. We don't say it, but we both like each other.
[cpg]


From Meir 's perspective, she owes me her life. It was not that surprising.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile364"]
[OnName num="meile"]
“I don't know much about magic, ...... but maybe that can help me think of something."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. Can you think of anything?”
[cpg cn=true]


Meir and I talked about this and that for a while.
[cpg]


Some of the things Meir said were ridiculous, but some of them were good ideas.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile365"]
[OnName num="meile"]
“The other day, we watered out the elf nation. I wonder if we can apply that to humans as well?”
[cpg cn=true]


[OnName num="kousuke"]
"...... Perhaps……"
[cpg cn=true]


Why do my pheromones only work on demi-humans?
[cpg]


If this were to expand its range to humans, it could be applied to other countries.
[cpg]


Maybe we can create magic on a larger scale.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile366"]
[OnName num="meile"]
“Oh, did I say something helpful;?”
[cpg cn=true]


[OnName num="kousuke"]
"Yes, you did. Well said.”
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Meile367"]
[OnName num="meile"]
“In that case, I want a reward.
[cpg cn=true]



Meir seems a little embarrassed.
[cpg]

[VOICE f="sMeile051"]
[OnName num="meile"]
“I want to feel warmth, a touch.”
[cpg cn=true]

We do not say that we like each other. But there was definitely love.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[BG f="b_06_4_l.ui" time=1000]
[WAIT time=1100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************




I go into Meir 's room. Then I chant a spell.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile368"]
[OnName num="meile"]
“What? What are you doing?”
[cpg cn=true]


[OnName num="kousuke"]
"You want some warmth, right?”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Meile369"]
[OnName num="meile"]
“Wait, wait, wait. I don't want it to be too uncomfortable. ...... Hey, are you listening?”
[cpg cn=true]






;//========================================
;//●ＣＧ（スライムに包み込まれるヒロイン）ev_56
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：スライム　　服装ex：無し
;//場所　：城内＿ヒロイン２の部屋
;//時間　：夜
;//========================================

*Scene045

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]
[WAIT time=1000]


[BGM f="bg_h1"]
;**【ＣＧ】 ev_56_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=100]


In response to Meir , who sensed something negative, I chanted a spell while playing dumb.
[cpg]

[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』
[WAIT time=1000]


And then the demon called the slime was summoned.
[cpg]

[VOICE f="sMeile052"]
[OnName num="meile"]
"Hey, I told you not to……!"
[cpg cn=true]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

The slime is clinging onto Meir.
[cpg]

[OnName num="kousuke"]
"It's a feverish slime, so if you're talking warmth, you've got plenty."
[cpg cn=true]

[VOICE f="sMeile053"]
[OnName num="meile"]
“That's not what I meant.”
[cpg cn=true]

[OnName num="kousuke"]
“Don't be so selfish.”
[cpg cn=true]

;**【ＣＧ】 ev_56_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile054"]
[OnName num="meile"]
“Ugh, it's slimy ...... and gross.”
[cpg cn=true]

[OnName num="kousuke"]
“Don't say too much about what I've summoned.”
[cpg cn=true]

[VOICE f="sMeile055"]
[OnName num="meile"]
"Don't be so mean, ......!"
[cpg cn=true]

She did not like it, but she did not run away from the scene.
[cpg]

Or rather, even if she wanted to escape, she couldn’t.
[cpg]

Once entangled by a slime, it is difficult to move the body freely,.......
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


After playing with it for a while, I release the summoning magic.
[cpg]


[OnName num="kousuke"]
“I'm sorry. You make me want to be playful."
[cpg cn=true]


[VOICE f="sMeile056"]
[OnName num="meile"]
“...... it’s awful.”
[cpg cn=true]



[STOPBGM]

[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_06_4.ui" time=1000]
[WAIT time=200]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile390"]
[OnName num="meile"]
"....... Kosuke ...... Kosuke do you like me?"
[cpg cn=true]


Suddenly, Meir asks.
[cpg]


Is it a casual question, or is it something she wanted to ask from the bottom of her heart?
[cpg]


[OnName num="kousuke"]
"Of course. I love you, Meir ."
[cpg cn=true]

[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]

Meir smiled, satisfied. I stroked her head, and she gets close like a cat.
[cpg]


She and I have developed an unusual relationship.
[cpg]


It's different from Fia , Chartier , and Kullulu .
[cpg]


Maybe this is what you call love.
[cpg]





;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





But I'm trying to manipulate that love.
[cpg]


The magic of fascination. I'm going to make every woman in the world, human or otherwise, mine.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Fia595"]
[OnName num="fia"]
“...... The idea is too far-fetched for me to come up with.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye343"]
[OnName num="schartye"]
“That's true. It's not easy to charm a human woman.”
[cpg cn=true]


[FACE method="change_2" pos="3/3"]
[VOICE f="Clolowlude271"]
[OnName num="clolowlude"]
“But I'm sure Kosuke can do it.”
[cpg cn=true]


[OnName num="kousuke"]
“You get it. Of course I can.”
[cpg cn=true]


If this were to happen, it would lead to world domination.
[cpg]


Even if you consider that most military personnel are men, in the long run, a nation cannot exist without women.
[cpg]


Depending on how you use them, you might be able to treat them like hostages, right?
[cpg]


I was going to gather all the women in the world into the Demon Lord's country.
[cpg]

[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





I'm going to research magic. The magic of fascination is a strange thing, and the degree of liking seems to have a limit.
[cpg]


Even if the magic can lead you to the stage where you don't want to disobey because you like that person,……
[cpg]


From that point on. It seems that there is nothing that magic can do to help one fall in love.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile391"]
[OnName num="meile"]
“So that means that me and Kosuke are connected regardless of magic, right?”
[cpg cn=true]


[OnName num="kousuke"]
“I don't know. There's also the pheromone thing.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile392"]
[OnName num="meile"]
“Tell me that it works.”
[cpg cn=true]


[OnName num="kousuke"]
“But if I can charm them to the point where they can't resist, that's all that matters. This magic is truly invincible, if you use it right.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile393"]
[OnName num="meile"]
“Not that it matters to me, because I'm already mesmerized.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile394"]
[OnName num="meile"]
“Kosuke, magic or pheromones don’t have anything to do with our love right?”
[cpg cn=true]


She' s trying to make me say it. I could only nod.
[cpg]


[OnName num="kousuke"]
“...... Yeah.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile395"]
[OnName num="meile"]
"Hmmm. We'll always be together, Kosuke .
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************




Fia , Chartier , Kullulu The three Uruds are skilled in magic.
[cpg]


I could not proceed with the idea without them.
[cpg]



So I couldn't leave Meir out of the group. The five of us, including me, stayed in the room most of the time.
[cpg]

The opinions of Meir, who had no knowledge of magic, seemed new to Fia and the others.
[cpg]

But with five people in the room, it was a bit cramped, even though it was large.
[cpg]


[STOPBGM]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]

[BG f="b_06_4.ui" time=1000]

[BGM f="bg_d3"]
[WAIT time=1000]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





And at night, I was finally alone .......
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile396"]
[OnName num="meile"]
"Hey, hey, Kosuke. Is there really such a thing as beastmen magic?”
[cpg cn=true]


I was not alone. Meir didn't come back.
[cpg]


[OnName num="kousuke"]
"What's with the sudden question......, I heard there is such magic.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile397"]
[OnName num="meile"]
“I want you to try it. I've been a beast since I was born, you know.”
[cpg cn=true]


[OnName num="kousuke"]
“Well, yeah.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMeile057"]
[OnName num="meile"]
“I'd like to see what happens when you turn into a beast.”
[cpg cn=true]


[OnName num="kousuke"]
“That's an interesting fetish. Maybe……."
[cpg cn=true]

This was different from humans being attracted to beastmen.
[cpg]

In fact, from her point of view, it is more normal to be a beast.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I don't know if there are any side effects to the magic of beastmen or not.
[cpg]


But I thought I'd just try. Because Meir is asking for it.
[cpg]


[OnName num="kousuke"]
“The magic of beastmen……hahaha.”
[cpg cn=true]


The magic of beastmen is really a battle magic.
[cpg]


I can feel my blood boiling. It’s also a strange kind of excitement.
[cpg]


From my skin grows hair…….and I slowly transform into a beastman like form.
[cpg]


And from that point on, my memory was gone.
[cpg]










;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]



[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************

[window target=true]


[SE f="se017"]
;//【ＳＥ】『鳥の鳴き声』



[WAIT time=1000]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye344"]
[OnName num="schartye"]
"You two are getting along great."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Meile446"]
[OnName num="meile"]
"What ......? Oh, this is..."
[cpg cn=true]


My magic was broken, and we were both on the futon together in our human form.
[cpg]


[OnName num="kousuke"]
“Could you please knock next time Chartier?”
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye345"]
[OnName num="schartye"]
“I did. I got worried when you didn't answer.”
[cpg cn=true]


[OnName num="kousuke"]
“…… I see. So, what do you want?”
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Schartye346"]
[OnName num="schartye"]
“My business is with Meir rather than with you, Demon Lord.”
[cpg cn=true]


Meir was flabbergasted at the sudden turn of events.
[cpg]


[FACE method="change_5" pos="2/2"]
[VOICE f="Meile447"]
[OnName num="meile"]
"What? Me?"
[cpg cn=true]


[OnName num="kousuke"]
“What is it? What's going on?”
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye347"]
[OnName num="schartye"]
“It's not that something happened, it's that something's going to happen.”
[cpg cn=true]


[free time=800]
[STOPBGM]


I couldn't see what she was saying. I waited for Chartier to speak.
[cpg]

[BGM f="bg_si"]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Schartye348"]
[OnName num="schartye"]
“Meir ...... do you know what it means for the Demon Lord to acquire further enchantment magic?”
[cpg cn=true]

[FACE method="change_7" pos="2/2"]
[OnName num="kousuke"]
"......"
[cpg cn=true]


Somehow, I've come to understand. I wondered if Meir could remain in love with me.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye349"]
[OnName num="schartye"]
“I don't care too much about his topic, but I also feel sorry.”
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Meile448"]
[OnName num="meile"]
"What does that…… mean?"
[cpg cn=true]


Since Meir doesn't seem to understand yet, I explained.
[cpg]


[OnName num="kousuke"]
“Humans and demi-humans will come on to me.”
[cpg cn=true]


[OnName num="kousuke"]
“Will you be jealous?"
[cpg cn=true]


Meir was silent for a moment and then said,
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Meile449"]
[OnName num="meile"]
“I'm jealous. Of course. I'm already jealous of Fia and Chartier.”
[cpg cn=true]


Is that so? Then why was she helping me develop this magic?
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Meile450"]
[OnName num="meile"]
“But more than that, I want to fulfill your wishes. If you're afraid for your life, I want to solve it."
[cpg cn=true]


Chartier sighed a little and said,
[cpg]


[FACE method="change_2" pos="1/2"]
[VOICE f="Schartye350"]
[OnName num="schartye"]
“I guess I didn't have to worry about it. Just forget it now.”
[cpg cn=true]



[free time=800]


[SE f="se008"]
;//【ＳＥ】『歩く』





And then she left. I was a bit taken aback.
[cpg]


[OnName num="kousuke"]
"......, don't you ever get possessive?"
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile451"]
[OnName num="meile"]
"Yes, I do. But more than that I want you to be happy."
[cpg cn=true]


...... I'm kind of scared that she’s too single-minded. It makes me worried if I'm being the person she wants me to be.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_d2"]
[WAIT time=1000]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************





However, if you think about it, the fact that I chose Meir may also be a story that will make ...... people jealous.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]

[VOICE f="Fia596"]
[OnName num="fia"]
"Oh, Kosuke . Good morning, ...... and Meir ."
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Meile452"]
[OnName num="meile"]
"Yes. Good morning, Fia ."
[cpg cn=true]


I'm sure Fia is jealous of Meir . It's not like she doesn't have any feelings for me.
[cpg]


When I think about it, I'm probably doing something pretty sinful.
[cpg]


But it's impossible to love everyone equally.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia597"]
[OnName num="fia"]
"What's wrong, Kosuke ?"
[cpg cn=true]


[OnName num="kousuke"]
“Oh, no, it's nothing ....... Just ......."
[cpg cn=true]


[OnName num="kousuke"]
“I'm just wondering if maybe I'm guilty of something.”
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Meile453"]
[OnName num="meile"]
“...... Why?”
[cpg cn=true]


[OnName num="kousuke"]
“Everyone is attracted to my pheromones, but I can only respond to one person.”
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="Fia598"]
[OnName num="fia"]
“You don't have to worry about that. You're a Demon Lord, you should be able to stand your ground.”
[cpg cn=true]


[OnName num="kousuke"]
“...... You're right.”
[cpg cn=true]


I know. I want to love Meir as much as I can.
[cpg]



;//ブラックアウト

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





I will continue to research magic. In the meantime, I’ve also been taking care of Meir .
[cpg]

[FG f="CHA02_p7_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sMeile058"]
[OnName num="meile"]
"...... Hey, Kosuke. Can you summon the slime from that time sometime?”
[cpg cn=true]

[OnName num="kousuke"]
"You're the one asking for it. Have you become addicted to it?”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="sMeile059"]
[OnName num="meile"]
"Heh heh."
[cpg cn=true]

As we talk, the magic was nearing completion.
[cpg]








;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





While occasionally flirting with Meir , I did what I had to do.
[cpg]


While loving my beloved, my life was in imminent danger.
[cpg]


[OnName num="kousuke"]
“Okay, it's done. ……"
[cpg cn=true]


The magic of enchantment has been completed. It was possible to create a magic that could encompass this world with my magic power.
[cpg]


[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************





I will need a very large magic circle. It needed to encompass this country and the entire world.
[cpg]


Even though I have a lot of power, it will not be easy.
[cpg]


[OnName num="kousuke"]
“...... It seems like the people in this country will really listen to anything I have to say.”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Meile477"]
[OnName num="meile"]
"I guess so. They love you Kosuke .”
[cpg cn=true]


I had the whole city, the whole country, draw magic circles.
[cpg]


It is difficult to draw something of this scale in blood.
[cpg]


It's also important to have an undisturbed pattern.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye351"]
[OnName num="schartye"]
“The current Demon Lord could probably summon a dragon. He could have used their blood.”
[cpg cn=true]


[OnName num="kousuke"]
“I don't want to play with life like that.”
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Fia599"]
[OnName num="fia"]
“That seems like you Kosuke, but aren’t you summoning demons for women?”
[cpg cn=true]


[OnName num="kousuke"]
“It's different from that. It's different when you take a life.”
[cpg cn=true]


What a controversial thing to say.
[cpg]



;//ブラックアウト
[STOPBGM]


[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[free time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_02_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（夜）******************************************************

[window target=true]




The magic was activated. The ultimate magic of fascination.
[cpg]


From that day on, women all over the world will be fascinated by me and will be aiming for the land of the Demon Lord .......
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_03_4.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『街＿現代』（夜）******************************************************





It does not matter what race you are, of course.
[cpg]


For example, it would have an effect on women in Japan, the neighboring country.
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[transition target={true} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************





The effect began to take place in a few days.
[cpg]


The Demon Lord's country is not that big, but all the women are gathering there.
[cpg]


Buildings were being built and the city became more developed.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile478"]
[OnName num="meile"]
“The other countries seem to be on alert. They can't leave Kosuke alone.”
[cpg cn=true]


[OnName num="kousuke"]
"I guess so, ……."
[cpg cn=true]


But I think I've won the battle.
[cpg]


Without women, the population will only decrease, so other countries will start to take advantage of the deal.
[cpg]


I think we're going to have to start competing with other countries on things that aren't military power.
[cpg]


The country of the Demon Lord is unique, and it would not be possible without magic.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile479"]
[OnName num="meile"]
“The magic of enchantment ...... doesn't work on people who are already enchanted, right?”
[cpg cn=true]


[OnName num="kousuke"]
“Yea that should be the case..... Meir 's face is red, isn't it?”
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile480"]
[OnName num="meile"]
"Heh, they'll figure it out.”
[cpg cn=true]


Meir gets closer to me. She's like an animal, really.
[cpg]


[OnName num="kousuke"]
“She's a cute girl.”
[cpg cn=true]


[VOICE f="sMeile060"]
[OnName num="meile"]
“That's a sweet compliment.”
[cpg cn=true]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】衣擦れ


Afterwards, I give Meir a gentle hug.
[cpg]



Meir looks satisfied ...... She seems to have forgiven me.
[cpg]


And then the night comes again.
[cpg]

[STOPBGM]

[WAIT time=1100]


[BG f="b_05_4.ui" time=1000]

[WAIT time=1100]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************



There were many women in the land of the Demon Lord, and the one closest to me Meir became a target.
[cpg]


[OnName num="kousuke"]
“You must be exhausted. You're in a tight spot."
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile501"]
[OnName num="meile"]
“Why? I don't mind.”
[cpg cn=true]


[OnName num="kousuke"]
“But that doesn't mean you don't think about it.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile502"]
[OnName num="meile"]
“Yeah, but ...... it's also kind of nice to see girls be jealous.”
[cpg cn=true]


For Meir it's an uncharacteristic thing to say. Is it a feeling of superiority?
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile503"]
[OnName num="meile"]
“It's nice when the person you like is liked by everyone.”
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


I guess I've been thinking in a twisted way. Maybe Meir is just as single-minded as they come.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile504"]
[OnName num="meile"]
“Can you use the magic of fascination with guys?”
[cpg cn=true]


[OnName num="kousuke"]
“That’s ……"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile505"]
[OnName num="meile"]
“If we could do that, no one would have anything to fight over. It would be a world where we could all live in peace.”
[cpg cn=true]


...... Of course that's not possible. It's not a magic that you need as a Demon Lord, so you can't make it.
[cpg]


But I didn't want to give up too soon.
[cpg]


I wanted to conquer the world so that there would be no conflict, for Meir’s sake.
[cpg]



;//ブラックアウト
[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





At night, I fell asleep with Meir .
[cpg]


I didn't officially make Meir my queen. Still, ......
[cpg]


I wanted to stay by her side for as long as possible.
[cpg]


That's probably what Meir is thinking as well.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************



[SE f="se017"]
;//【ＳＥ】『鳥の鳴き声』

Then we both wake up. Sometimes I wake Meir up, sometimes it’s the other way around.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile506"]
[OnName num="meile"]
"...... wow, is it morning already ......?"
[cpg cn=true]


Today I was the first one to wake up.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile507"]
[OnName num="meile"]
"Good morning, Kosuke ......."
[cpg cn=true]


[OnName num="kousuke"]
“Oh, good morning.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile508"]
[OnName num="meile"]
“Um, what are we doing today?”
[cpg cn=true]


[OnName num="kousuke"]
“For the time being, I have to deal with politics, instead of magic.”
[cpg cn=true]


Politics is not my thing. But it was not something that could be left to Meir .
[cpg]



;//ブラックアウト
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************





Even so, my position will never change.
[cpg]


After all, most of the people in this country are under the spell of my enchantment.
[cpg]


[OnName num="therianthropy_woman"]
"Oh, Demon Lord!
[cpg cn=true]


[OnName num="human_woman"]
“Good morning! Today is a brand new day. ......"
[cpg cn=true]


What kind of reaction is that? I wonder if Meir really thinks nothing of it.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="1/2" time=800]

When I look at Meir next to her, she is smiling.
[cpg]


If she's okay with this, then I'm okay with it.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]

When I got back to the castle, Meir came close to me more strongly than before.
[cpg]



When I patted her on the head, she seemed really happy.
[cpg]

[OnName num="kousuke"]
“You’re really like an animal.”
[cpg cn=true]

[VOICE f="sMeile061"]
[OnName num="meile"]
“That’s because I’m a beastman.”
[cpg cn=true]

She only uses that term when it suits her. But that is part of her charm.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト



After that, we spend time together in peace.
[cpg]


It's good to have a reward, for overcoming a crisis that threatened your life. ......
[cpg]

[STOPBGM]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




With the magic of enchantment, the immediate crisis was averted.
[cpg]


To a certain extent, the political situation in the country has been stabilized. I'm going to do what I have to do next.
[cpg]

[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="kousuke"]
“I have to do what I have to do next. ...... Would you like to be my queen, Meir ?"
[cpg cn=true]


I'm embarrassed to admit that my proposal was a bit over the top. This is the kind of relationship we had.
[cpg]


It's a bit far-fetched to use the term queen. But I was okay with it.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile532"]
[OnName num="meile"]
"Yes, I will. I'll be your wife, Kosuke.”
[cpg cn=true]


Meir laughed, and I laughed along with her.
[cpg]


[OnName num="kousuke"]
“I knew there was no way you would say no……..but I was a little nervous.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile533"]
[OnName num="meile"]
"I see. You don't have to be nervous.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile534"]
[OnName num="meile"]
"Kosuke ......, I remember something from when I was really little.”
[cpg cn=true]


[OnName num="kousuke"]
“What is it? What do you remember……"
[cpg cn=true]


Hold on. Meir has been asleep for a long time. She never got old. ......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile535"]
[OnName num="meile"]
“I think I met you before you were reincarnated. I think."
[cpg cn=true]


Meir had a disease that caused the body to stop time. It was like a magical curse.
[cpg]


In other words, Meir was born a long time ago.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile536"]
[OnName num="meile"]
“Before I got sick, you came to our village, I think.”
[cpg cn=true]


The young Meir remembers the pre-reincarnated Demon Lord playing with her there.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile537"]
[OnName num="meile"]
“I thought you were cool and I told you that I wanted to be your wife.”
[cpg cn=true]


[OnName num="kousuke"]
“How I you respond to ...... that?”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile538"]
[OnName num="meile"]
“You said that you would be with Chartier, because there was a difference in the lifespan.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile539"]
[OnName num="meile"]
"But we could be together in a different life……..”
[cpg cn=true]


In fact, Meir was never reborn, time stopped and only I was reborn, and now we are together.
[cpg]


[OnName num="kousuke"]
It's a romantic story. You're not making this up, are you?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Meile540"]
[OnName num="meile"]
"Oh, you don't believe me? That's terrible.”
[cpg cn=true]


[OnName num="kousuke"]
“I'm kidding. I think it was fate that brought me to you Meir .”
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile541"]
[OnName num="meile"]
“Yeah, ......, you’re right. It's fate, isn't it?”
[cpg cn=true]


We kiss. For a while, this country will remain peaceful.
[cpg]


Our love has finally blossomed.
[cpg]


Right now, I want to enjoy this moment.
[cpg]



;//ＥＮＤ　ヒロイン２征服ルート

[WAIT time=100]
[jump storage="epend.ks" target="*start"]
[WAIT time=100]
;[s]
[WAIT time=100]
[WAIT time=100]



