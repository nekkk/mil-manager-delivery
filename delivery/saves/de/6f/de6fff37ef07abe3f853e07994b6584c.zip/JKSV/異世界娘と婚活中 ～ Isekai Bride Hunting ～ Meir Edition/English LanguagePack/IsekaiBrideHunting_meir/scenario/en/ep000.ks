*start

*ep000|Prologue

[SCENE id=0]

[OnName num=""]
;//異世界娘発情中　シナリオ
;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり

;//フィア　　　　　着衣
;//メイル　　　　　着衣
;//シャルティエ　　着衣
;//クロロウルード　着衣

;//上記以外のキャラクターには音声がありません

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//フィア　　　　　一人称「わたくし」　メイル呼び「メイルさん」　シャルティエ呼び「シャルティエさん」
;//　　　　　　　　クロロウルード呼び「クロロウルードさん」　康介呼び「康介さん」
;//メイル　　　　　一人称「あたし」　フィア呼び「フィア」　シャルティエ呼び「シャルティエ」
;//　　　　　　　　クロロウルード呼び「クロロ」　康介呼び「康介」
;//シャルティエ　　一人称「わらわ」　フィア呼び「フィア」　メイル呼び「メイル」
;//　　　　　　　　クロロウルード呼び「クロロウルード」　康介呼び「魔王様」　ルートによって「康介」
;//クロロウルード　一人称「わたし」　フィア呼び「フィア」　メイル呼び「メイル」
;//　　　　　　　　シャルティエ呼び「シャルティエ」　康介呼び「康介」→「魔王様」
;//康介　　　　　　一人称「俺」　フィア呼び「フィア」　メイル呼び「メイル」　シャルティエ呼び「シャルティエ」
;//　　　　　　　　クロロウルード呼び「クロロ」

;//以下、残したＣＧを列挙いたします
;//フィア　　　　　ev_31 ev_20 ev_32 ev_51 ev_52 ev_54
;//メイル　　　　　ev_01 ev_33 ev_34 ev_03 ev_56
;//シャルティエ　　ev_14 ev_39 ev_42 ev_63 ev_64
;//クロロウルード　ev_07 ev_18 ev_66 ev_70

;//うち、ev_31は物語冒頭に移動しています

;//////////////////////////////////////
;///////////////以下本編///////////////
;//////////////////////////////////////


[BG f="black.ui" time=1000]
[WAIT time=100]
[BGM f="bg_d3"]
;//ブラックアウト




;//デバッグ用魔方陣確認
;//[cpg]
;//■選択肢
;//[switch]
;//[case "このまま最初から"]
;//	[swap]
;//	[jump target="*konomama"]
;//[case "平和フィア"]
;//	[swap]
;//	[jump storage="ep002.ks" target="*effect"]
;//[case "平和メイル"]
;//	[swap]
;//	[jump storage="ep003.ks" target="*effect"]
;//[case "平和シャルティエ"]
;//	[swap]
;//	[jump storage="ep004.ks" target="*effect"]
;//[endswitch]
;//
;//*konomama|プロローグ




I am on my way home from work. I see the road-side trees and a thought occurrs.
[cpg]

;//[jump target="*asd"]

Even though it’s obvious, I ponder upon how plants are alive as well.
[cpg]


It's the same with all living things. We mate and then leave behind the next generation.
[cpg]


They exist in various places, in various forms, scattered everywhere.
[cpg]


It is the fate of living things to increase in number, while entrusting potential to new life.
[cpg]


If that's the case, then I'm not a part of fate.
[cpg]



[BG f="b_03_3.ui" time=2000]
[WAIT time=2000]
;//【ＢＧ】『街＿現代』（夕方）******************************************************





I’m getting more impatient. There is also the mere fear that I could be alone for the rest of my life.
[cpg]


But I'm ready to put those thoughts to rest. This Golden Week, I will find the love of my life.
[cpg]


I, Kosuke Hazama (Kousuke Hazama), am about to take the first leap.
[cpg]


[OnName num="kousuke"]
“......hold on, I’m almost close ......."
[cpg cn=true]


It’s the end of the work day, just before the start of the big holidays. The holidays at my workplace were quite long.
[cpg]


This time I decide not to go back home to my parents house. Instead, I want to make my parents happy with the result of something else.
[cpg]


I was planning to go on a trip during this holiday.
[cpg]


A trip is a trip to meet people. I was also planning to marry a cute subhuman ......
[cpg]




;//ブラックアウト
;//回想ですのでセピア調にしてください
[STOPBGM]
[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff}  time=1000]
[WAIT time=1100]
[WAIT time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="163.jpg" color={0x000000ff} time=1]
[WAIT time=1000]



[BG f="b_02_5.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************





It was a few decades ago.
[cpg]


This earth has merged with other worlds.
[cpg]


New continents appeared all over the world, and subhumans came to live in this world.
[cpg]


Even the subhumans do not know why they came to this world.
[cpg]


Various studies have been conducted to this day, but nothing is certain.
[cpg]


Islands and continents are popping up all over the world: the land of elves is in the Pacific Ocean, the land of beastmen is in the East China Sea ......, and so on.
[cpg]



;//ブラックアウト


[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_10_5.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





In the beginning, there were many conflicts, but over the years, the subhumans reconciled with the elves.
[cpg]


To begin with, the earth had overwhelming science and technology, and the subhumans also had access to terrifying magic.
[cpg]


If a proper war were to break out, the world would collapse.
[cpg]


So, they made their way toward reconciliation.
[cpg]



;//回想終わり　色調を戻してください



;//ブラックアウト

[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff}  time=1000]
[WAIT time=1100]
[WAIT time=1]

[STOPBGM]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="163.jpg" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_03_3.ui" time=1500]
[WAIT time=1500]
[window target=true]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夕方）******************************************************




[OnName num="elf_woman"]
Japan is very convenient, isn't it? Science is more like magic than magic.
[cpg cn=true]


[OnName num="office_worker"]
I guess that's true. It's easy to live in Japan, isn't it?
[cpg cn=true]


[OnName num="elf_woman"]
"Yes, it is!　I'm so happy to have met you.
[cpg cn=true]


Today, too, I see a couple of subhumans and a human in the city.
[cpg]


This kind of marriage is not called an international marriage. It is commonly called "interworld marriage" or "interracial marriage.
[cpg]


I would think that an international marriage is a marriage between two different countries, but that is still what they call it.
[cpg]


That being the case, many interracial marriages are those in which the couple met overseas.
[cpg]


That's right. It is hard to believe that a single suburbanite would come to Japan if he/she is not married to anyone.
[cpg]


Conversely, if you see an Asian in this country, there is a high possibility that she is married or in love with someone.
[cpg]


Japan, though peaceful, is still a dangerous place these days, and if you are a subhuman, you are bound to stand out in some way.
[cpg]


I've always dreamed of having a cute subhuman wife. ......
[cpg]


To begin with, it is difficult to be married to one of the few subhumans in Japan.
[cpg]


[STOPBGM]
[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=2000]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夕方）******************************************************





But it will soon be Golden Week.
[cpg]


I was already planning to head to the otherworldly continent no matter who stopped me.
[cpg]


That too, to the most popular spot, the land of elves. ......
[cpg]


[OnName num="kousuke"]
"The problem is ...... money, right ......?
[cpg cn=true]


I've been working diligently. I had enough income to save money, but somehow by the end of the month it would be all used up.
[cpg]


Where did I spend so much money ......? I couldn’t think of any significant outlet.
[cpg]


I know that my sloppy nature is keeping me from getting married.
[cpg]


That's why I have to take the plunge. But....
[cpg]


[OnName num="kousuke"]
"Hmmm... ......"
[cpg cn=true]


Staring at my phone, I look up the government's recommended plans for sightseeing trips.
[cpg]


No matter how many times I check, the prices do not seem to go down. In fact, they become more expensive as they get booked up.
[cpg]


It feels like the world doesn’t want me to get married.
[cpg]


Not having a choice is not an option. My impatience is growing.
[cpg]


I am getting hopeful for the trip, but at the same time, I feel defeated.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=10]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1100]

[BG f="b_03_1.ui" time=1500]
[WAIT time=2000]


[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（朝）******************************************************

;//＠
[SE f="se011"]
;//【ＳＥ】『人混み』


Time flies when you're commuting to work and trying to getting things done.
[cpg]


I'll be old before I know it. This was not a joke.
[cpg]




[window target=false]

[BG f="b_03_3.ui" time=2000]
[WAIT time=2000]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夕方）******************************************************

[window target=true]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』


If I'm still single this year, I'll probably be single next year and the following ten years. I can imagine that easily.
[cpg]


Even so, I am troubled by the amount of money I have to spend on travel plans, which makes me want to give up.
[cpg]


As I walk, I stare at the screen of my phone. The prices kept going up and up.
[cpg]



[SE f="se001"]
;//【ＳＥ】『ぶつかる』

[STOPBGM]


[WAIT time=500]


[OnName num="kousuke"]
"Ouch. ......"
[cpg cn=true]


Being too focused on other things, I’m not looking ahead properly.
[cpg]


I drop my phone and rush to pick it up. The screen shows a travel plan.
[cpg]

[BG f="b_03_4_up_l.ui" time=1000]
[WAIT time=1000]
;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]
[WAIT time=1000]

[BGM f="bg_si"]

[OnName num="suspicious_man"]
“...... Are you planning a trip to the land of the elves, mister?”
[cpg cn=true]


A man strange man approaches me with in a suspicious tone.
[cpg]


I think he might be a demi-human. He is wearing a robe and a mask to hide his face, which seems unusual.
[cpg]


As my thoughts wander, an even more suspicious looking woman appears from behind me.
[cpg]



;//シャルティエの立ち絵表示
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1500]


I wonder if she is a vampire. She seems completely indifferent from a normal human being.
[cpg]



;//シャルティエの名前をしばらく「謎の女性」と隠してください
;//かなり長い間名前が判明しませんが、指定があるまで表示しないでください



[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye001"]
[OnName num="mysterious_woman"]
“I can introduce you to an airship that will take you to the land of the elves at a discounted price. What do you think?”
[cpg cn=true]


[OnName num="kousuke"]
"What? ...... Whats going on?"
[cpg cn=true]


I pick up my phone and try to walk away.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye002"]
[OnName num="mysterious_woman"]
“At least listen to the price. Hey!”
[cpg cn=true]


[OnName num="suspicious_man"]
“Look. This flight is not meant for you alone, you know.”
[cpg cn=true]


The man flicks his abacus. Who carries an abacus nowadays? ......
[cpg]


But it's not like I can't read the numbers on an abacus. So I think,
[cpg]


[OnName num="kousuke"]
"Is it really this cheap ......?"
[cpg cn=true]


I am presented with a price that feels like a domestic trip.
[cpg]


[OnName num="kousuke"]
"Is there a return flight?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye003"]
[OnName num="mysterious_woman"]
"Don't be a pussy. I'm sure you're single because of that.”
[cpg cn=true]


[OnName num="kousuke"]
“How dare……”
[cpg cn=true]


I am angry, but I am more shocked by how he knows that I am single.
[cpg]


Am I that dull looking?
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye004"]
[OnName num="mysterious_woman"]
“Anyway, let me just inform you on when and where the amphibian will be leaving.”
[cpg cn=true]


The mysterious woman hands me a note and smiles wryly.
[cpg]

 
[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye005"]
[OnName num="mysterious_woman"]
“I'll look forward to seeing you again.”
[cpg cn=true]

[move from="2/3" to="5/3" ease="easeInOutSine" time=2000]
[WAIT time=2200]

[free]

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]
[BG f="b_03_3.ui" time=1000]
[WAIT time=1000]


The duo disappears into the crowd of people.
[cpg]


[OnName num="kousuke"]
“...... What just happened?”
[cpg cn=true]


If she were someone who makes money from organizing trips, ......
[cpg]


How is it possible that the person I bumped into by accident was a travel planner?
[cpg]


Maybe this is not just a coincidence.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=10]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1100]

[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************


[window target=true]



[OnName num="kousuke"]
“It's not a port ...... Nor an airport.”
[cpg cn=true]


In the note handed to me, the location of the airship is written in beautiful letters.
[cpg]


They had also spotted that I was single……, maybe ......
[cpg]


Was he using magic or something to survey people who wanted to go on the trip?
[cpg]


Suppose he wasn't.
[cpg]


[OnName num="kousuke"]
“Have I seen that man somewhere before….?”
[cpg cn=true]


The woman did look familiar to me. But if someone were to ask me where, then I wouldn’t be able to answer.
[cpg]


This makes me believe in a past life and everything else that seems out of this world.
[cpg]


Either way, I can’t let this opportunity go to waste.
[cpg]


If I can't catch the return flight, I'll probably get fired from my job, but I decide to risk it anyway.
[cpg]



[BG f="black.ui" time=2000]
[WAIT time=2000]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//ブラックアウト





I arrive to the port at night.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=10]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1100]

[BG f="b_11_4.ui" time=1000]
[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『空』（夜）******************************************************

[window target=true]




[OnName num="kousuke"]
"Wow, ......, that really is an amphibian.”
[cpg cn=true]


I can’t tell what kind of power it uses, but it looks like an old-fashioned airship that someone from the past would have invented.
[cpg]


From the outside it looks like a sailing ship floating at sea.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye006"]
[OnName num="mysterious_woman"]
"There you are. I knew you'd come."
[cpg cn=true]


[OnName num="kousuke"]
"...... is this thing really going to fly?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye007"]
[OnName num="mysterious_woman"]
“ Of course it will fly. Did you bring the money?”
[cpg cn=true]


[OnName num="kousuke"]
“Oh, yeah, I brought it in cash, just in case.”
[cpg cn=true]


I pull the money out of my wallet. The woman takes it, without checking the amount.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye008"]
[OnName num="mysterious_woman"]
“I'm sure I got it. Now, come on inside."
[cpg cn=true]


[free time=800]

I enter the airship and I find that it is full of passengers who seem ...... too suspicious to consider them as human.
[cpg]


Half of them were demi-humans. The other half were full human. Some of them look extremely frightened, while others were trying to recompose themselves in this unsettling environment . ......
[cpg]


Am I allowed to be on this ship ......?
[cpg]


[OnName num="suspicious_man"]
“I guess everyone’s here. Time to take off, Chartier?”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye009"]
[OnName num="mysterious_woman"]
“Yeah. You take the steering wheel!.”
[cpg cn=true]



[free time=800]


[SE f="se005"]
;//【ＳＥ】『魔法発動する　シンセパッド系の音』





[OnName num="kousuke"]
Whoa!
[cpg cn=true]


Did the airship just shake? Are we already floating?
[cpg]


But I’m the only one who raises my voice. I wonder what the rest of them were feeling in their gut.
[cpg]


I can’t do anything, now that I'm on board. No matter where we arrive, and no matter where we don’t arrive, there is no more way out.
[cpg]




[BG f="b_11_4.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


;//＠空背景


I had never been on an overseas trip before.
[cpg]


This would be my first trip abroad, but it would also be my first trip to another world.
[cpg]


The other passengers have not say a word, so I decide not to speak either.
[cpg]


The woman named “Charter” and the suspicious man seem to be in another part of the airship.
[cpg]


I can’t even ask them questions to make myself feel at ease.
[cpg]


I think I was on the airship for a few hours, but it felt much longer.
[cpg]




[BG f="b_02_5.ui" time=1500]
[WAIT time=2000]

[WAIT time=100]
;//[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（夜）******************************************************





The land of the elves. As the name suggests, elves make up most of the population there.
[cpg]


They are a race skilled in magic and do not rely much on science and technology.
[cpg]


I've only heard rumors, but I had heard that there are no power plants there.
[cpg]


Of course, they would need to generate some electricity for the tourists, but ......
[cpg]


It seems that everything is simply covered by magic. It's hard to believe, but I wonder if it's true.
[cpg]


I am about to find out: ......
[cpg]



[window target=false]
[transition target={true} rule="39.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[transition target={false} rule="39.png" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_02_1.ui" time=1500]
[WAIT time=2000]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（朝）******************************************************


[window target=true]



[OnName num="kousuke"]
"Are we here ......?"
[cpg cn=true]


I go outside. The sun is shining brightly.
[cpg]


The other passengers are getting out of the airship without saying a word.
[cpg]

[STOPBGM]

Some of them didn't get off. Which means……
[cpg]


[BGM f="bg_tc"]


[OnName num="kousuke"]
"Wait, wait, hold on!”
[cpg cn=true]



[SE f="se005"]
;//【ＳＥ】『魔法発動する　シンセパッド系の音』





The amphibian is about to take off again. This is not the final destination.
[cpg]


We're going to get left behind. And that amphibian is probably not going to come back here.
[cpg]


The amphibian slowly rises towards the sky. Without having the courage to cling onto the ship, it disappears from my sight.
[cpg]


[OnName num="kousuke"]
“……"
[cpg cn=true]


Hold on, this is definitely an illegal entry into the country. And it's an unfamiliar land.
[cpg]


I've probably done something I will regret, haven't I ......?
[cpg]



;//ブラックアウト
[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1500]

[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************



[window target=true]


What happens to a human being when one is pushed to their limit?
[cpg]


In my case,I begin to feel the kind of courage that usually doesn’t come out. I'm sure that's the case for most people.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="kousuke"]
“Hey! Do you understand my language?”
[cpg cn=true]


I had heard that the elves and those skilled in magic can use the magic of automatic translation.
[cpg]


If that were the case, they would be able to understand me as well.
[cpg]



;//フィアの名前を「エルフの女性」と隠してください





[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia001"]
[OnName num="elf_woman"]
"Yes. What is it ……?"
[cpg cn=true]


[OnName num="kousuke"]
"Where am I ?…… the land of the elves?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia002"]
[OnName num="elf_woman"]
“Yes, it's a bit far from the central city of Elf Country…"
[cpg cn=true]


This was still far from the city? It looked like a pretty nice town.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia003"]
[OnName num="elf_woman"]
“Are you here for sightseeing? You look like a human.”
[cpg cn=true]


[OnName num="kousuke"]
“Yeah, I came from Japan.”
[cpg cn=true]



;//ここから、フィアの名前を隠さないでください





[FACE method="change_2" pos="2/3"]
[VOICE f="Fia004"]
[OnName num="fia"]
“You're from Japan? Nice to meet you. My name is Fia ."
[cpg cn=true]


The elfin politely tells me her name. So I introduce myself.
[cpg]


[OnName num="kousuke"]
"I'm Kosuke and ....... How do I get back to Japan from here?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia005"]
[OnName num="fia"]
“Well, ...... it's quite far away, but if you head to the airport, there are flights there.”
[cpg cn=true]


Airport. That might be a bad idea.
[cpg]


After all, I'm in the country illegally. I'm supposed to be in Japan right now, so I'm pretty sure I'll get caught. ......
[cpg]


Am I being too thoughtful? Maybe I could force them somehow to let me go back to Japan.
[cpg]


[OnName num="kousuke"]
“No, that doesn’t seem right......"
[cpg cn=true]


I look down and mumble to myself. The best thing to do would be to go back to Japan without anyone finding me.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia006"]
[OnName num="fia"]
“What's wrong with you? You have a difficult look on your face.”
[cpg cn=true]


[OnName num="kousuke"]
“No, no, it's ...... nothing. Then I'm sorry for keeping you.”
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Fia007"]
[OnName num="fia"]
“...... Oh, um... Wait a minute.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia008"]
[OnName num="fia"]
“If you are in trouble, I can help you. My house is just around the corner. ......"
[cpg cn=true]


......? What's this all about? What kind of a culture invites a foreigner to their home?
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia009"]
[OnName num="fia"]
“If you like, why don't you come and rest for a little? You must be tired from your long journey.”
[cpg cn=true]


I am indeed tired. Although I am still suspicious, I decide to tag along with Fia to her house.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=10]
[free time=10]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_08_2.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】『森の中の集落＿エルフの国』（昼）******************************************************



[window target=true]


We head to a forest-like area outside the city. There is still a path.
[cpg]


We walk along it and arrive at a small open village.
[cpg]


There are several houses lined up ......, and one of them seems to be Fia’s home .
[cpg]



;//室内であるため、上下に黒帯を入れてください

;//[BG f="black.ui" time=1000]
;//[BG f="b_08_2_l.ui" time=1000]
;//[WAIT time=1000]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]
[WAIT time=1000]
[BG f="b_08_2_up_l.ui" time=1000]
[WAIT time=1000]



I am invited into the house. The room is neat and tidy.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Fia010"]
[OnName num="fia"]
"It's a mess, but please have a seat.”
[cpg cn=true]

[free time=800]

So I sit down on a chair.
[cpg]


Chairs seem to be part of their culture, I think to myself.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia011"]
[OnName num="fia"]
"......"
[cpg cn=true]


Fia sit on the chair across from me and stares.
[cpg]


[OnName num="kousuke"]
"Is there something on my face?"
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Fia012"]
[OnName num="fia"]
"No, nothing. No, nothing."
[cpg cn=true]


So she wanders her eyes elsewhere.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia013"]
[OnName num="fia"]
“I'm sorry ....... I'm sorry for inviting you here so suddenly.”
[cpg cn=true]


I can see that Fia is acting weirder little by little.
[cpg]


I don't know why this is happening to me. I would have understood if I were handsome, but I'm not.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia014"]
[OnName num="fia"]
"Have you and I met somewhere before?”
[cpg cn=true]


[OnName num="kousuke"]
“No, I don’t recall ever meeting you ……."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia015"]
[OnName num="fia"]
“I have this feeling that ...... you helped me a long time ago.”
[cpg cn=true]


A long time ago. The old me has never been abroad. It's impossible, I think, as I sip the tea that she offered to me.
[cpg]


[OnName num="kousuke"]
“I have to admit, it was nice of you to let me into your home. ...... I am quite thirsty.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia016"]
[OnName num="fia"]
“I'm glad to hear that.”
[cpg cn=true]


[OnName num="kousuke"]
“I don't know what to do. ...... maybe I should tell you everything.”
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
So, I decide to tell her everything.
[cpg]

[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]


That I had been smuggled into the country and that I had been left behind. Those were the two big events.
[cpg]


I didn't dare mention that I was here to find my destiny.
[cpg]


[BG f="b_08_2_up_l.ui" time=1000]
[WAIT time=1000]

[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia017"]
[OnName num="fia"]
“I see….Maybe now is the time to rely on this country”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia018"]
[OnName num="fia"]
“I think the only way to get help is to talk to the Elf Nation or the Japanese government and ask them for help.”
[cpg cn=true]


[OnName num="kousuke"]
“ I guess that's the only way. ……"
[cpg cn=true]


I wonder what the crime of illegal entry is. I'm sure they'll take more than the cost of a stingy trip.
[cpg]


All I can do is sigh and hold my head in my hands. I couldn’t believe this was happening.
[cpg]


[OnName num="kousuke"]
“I guess I have no other option but to do that ...... Huh.”
[cpg cn=true]


The battery in my cell phone had run out. This means that I cannot contact anyone.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia019"]
[OnName num="fia"]
“Don’t be so hasty. Why don't you stay at my house for a while?”
[cpg cn=true]


[OnName num="kousuke"]
“Are you sure? Are the elves always so open-minded?”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia020"]
[OnName num="fia"]
“I don't think so. ...... But the thing is……"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia021"]
[OnName num="fia"]
“I truly only have good intentions”
[cpg cn=true]


...... I am not quite so sure about that. I feel like there is something behind it.
[cpg]




[window target=false]
[WAIT time=1000]
[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]
;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]

[BG f="b_08_4_up_l.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落＿エルフの国』（夜）******************************************************





However, if she could let me stay, I would be very grateful.
[cpg]


If it were to rain, I would not have been able to stay on the field.
[cpg]


So I was decided to stay at Fia 's house for the night. ......
[cpg]


Fia even served me dinner, and I was touched by her kindness.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia022"]
[OnName num="fia"]
“Here. I hope you like it.”
[cpg cn=true]


[OnName num="kousuke"]
"Why are you being so kind to me?"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
I ask her again, only this time Fia looks embarrassed.
[cpg]


It seems strange that she is embarrassed but at in that moment I did not realize that.
[cpg]

;//qwe

;//ブラックアウト

[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[STOPBGM]

[BG f="black.ui" time=1]
[free time=1]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_02_1.ui" time=1000]

[WAIT time=1100]
[WAIT time=100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（朝）******************************************************

[window target=true]



It’s a new day. I think about what I should do.
[cpg]


There is a part of me that wishes to see the amphibian again, somewhere ......
[cpg]


I want to go back to Japan without anyone knowing, so that I can pretend that nothing had never happened.
[cpg]


[OnName num="kousuke"]
“”What a strange place. ……"
[cpg cn=true]


I walk around the city, further from Fia’s house . It was an interesting place to go sightseeing.
[cpg]


There are no electrical appliances or machinery. It is like medieval Europe.
[cpg]


Not that I have ever seen medieval Europe. ......
[cpg]


But then again, there's nothing really modern around here.
[cpg]


There might be perhaps near the airport or in the tourist areas, just not anywhere else.
[cpg]




[BG f="b_02_2.ui" time=2000]
[WAIT time=2500]

;//[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************





Time passed. I am getting hungry and count the rest of my money in my hand.
[cpg]


I can’t use Japanese currency. Although I might be able to exchange it somewhere......
[cpg]


Fia had given me some money for lunch.
[cpg]


At least an amount of what I thought was enough for lunch. I tried to return the money to Fia , but it was Japanese currency.
[cpg]


I really can't thank her enough for that.
[cpg]


[OnName num="kousuke"]
“Boy am I hungry, ……."
[cpg cn=true]


I walk into a random restaurant. This is the kind of place where if you don’t seem confident, you'll look suspicious.
[cpg]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="b_02_2_l.ui" time=1000]
[WAIT time=100]
;//ブラックアウト

;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く


When I look at this city, I realize that magic had developed more than science.
[cpg]


I can hear the conversation from inside the store. They are talking about how they had seen a doctor at the hospital the other day.
[cpg]


Apparently the hospital uses magic to heal injuries and illnesses,.......
[cpg]


I is amazing that I can understand everything they are saying.
[cpg]


My ears are still the same, which means that any human could hear what they were saying.
[cpg]


There must be some kind of translation magic going on all the time. There must be a lot of tourists here.
[cpg]


Even so, it was pretty amazing.
[cpg]


Or maybe the whole country is under a magic spell? I wonder if it's the same in other countries, such as the Land of the Beasts. ......
[cpg]


[WAIT time=1500]
[window target=false]


[BG f="b_02_3.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『街＿エルフの国』（夕方）******************************************************


[window target=true]



It is evening again. Just walking around the city is exciting, but that is not the purpose of this trip.
[cpg]


Speaking of which, I am not sure anymore if I can achieve the purpose of the trip.
[cpg]


I doubt if I will ever be able to return to Japan, more than meeting a pretty demi-human wife.
[cpg]


I am hungry again. I have no choice but to go back to Fia’s house .
[cpg]


I decide to go back to the village where she lives.
[cpg]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』


[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=2000]
[WAIT time=2100]
[STOPBGM]
[WAIT time=1]
[BG f="black.ui" time=10]
[WAIT time=10]
[transition target={false} rule="101.jpg" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_08_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落＿エルフの国』（夜）******************************************************

[window target=true]


;//上下に黒帯を入れてください


;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]
[BG f="b_08_4_up_l.ui" time=1000]
[WAIT time=1500]



I remember the road better than I thought I would. I end up staying at Fia 's house for the second night.
[cpg]

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
At Fia 's house, we talk about this and that.
[cpg]


[OnName num="kousuke"]
“So Fia, you live alone here?……”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia023"]
[OnName num="fia"]
"Yes. Both my mother and father passed away early.”
[cpg cn=true]


[OnName num="kousuke"]
“I'm so sorry…..I didn't mean to remind you of that.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia024"]
[OnName num="fia"]
“No. It's okay. I can live on my own.”
[cpg cn=true]


Even today, Fia still doesn’t seem much at ease.
[cpg]


It was as if she would always have a big reaction to my casual words.
[cpg]


[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=2000]

[BG f="b_08_4_up_l.ui" time=1000]
[WAIT time=1000]

After dinner, at night. Fia sleeps in her own bed, so I sleep on the floor outside of the bedroom.
[cpg]


Suddenly I hear Fia’s voice.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia025"]
[OnName num="fia"]
“Do you want to sleep in the bed, ...... Kosuke ?"
[cpg cn=true]


[OnName num="kousuke"]
“That’s okay...... I couldn’t let you sleep on the floor.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia026"]
[OnName num="fia"]
“There's enough room for the two of us. Do you want to join me?”
[cpg cn=true]


She was getting quite aggressive. I don’t understand why this is happening.
[cpg]


Am I more handsome to elves? No way.
[cpg]


It doesn't look like their aesthetic senses are all that different. I was reluctant however,…..
[cpg]


[OnName num="kousuke"]
“In that case I couldn’t say no to your offer.”
[cpg cn=true]


I was hoping that the demi-human wife of my fate might be Fia .
[cpg]


[free time=800]

As I cuddle up with Fia , with our backs against each other ......
[cpg]


I feel Fia turn over in her sleep. Facing my body.
[cpg]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ


[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]

;//========================================
;//●ＣＧ（主人公にのしかかっているヒロイン。顔を赤くしている）ev_31
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城内＿主人公の部屋
;//時間　：夜
;//備考　：原作から位置が移動しています
;//========================================

*Scene000|Prologue

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]
[WAIT time=1500]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_31_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]



When I thought I heard a noise, I feel weight on my body.
[cpg]


I don't have to think to tell that it is Fia 's weight.
[cpg]


It took a while to understand the situation, but I can't understand what she is feeling.
[cpg]

[OnName num="kousuke"]
“..... Fia. Doesn’t this seem wrong?”
[cpg cn=true]

;**【ＣＧ】 ev_31_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Fia027"]
[OnName num="fia"]
“I'm sorry. I just can't help myself. ...... I've never felt like this before in my life.”
[cpg cn=true]


It was happening all too fast. I had only just met her yesterday.
[cpg]


It didn’t seem like Fia was the casual type.
[cpg]


Was there a problem on my end? Is there some unseen force at work?
[cpg]

[OnName num="kousuke"]
"Are Elves allowed to do this?"
[cpg cn=true]

In my own imagination, elves have an image of being reserved when it comes to love.
[cpg]

It may be a prejudice associated with their longevity, but ......
[cpg]


[VOICE f="sFia001"]
[OnName num="fia"]
“Yes, ...... it's true, it's not something we’re allowed to do, especially with humans.”
[cpg cn=true]

So it wasn't a prejudice.
[cpg]

[VOICE f="sFia002"]
[OnName num="fia"]
“It's not okay to seduce someone, even my own kind. ……"
[cpg cn=true]

[OnName num="kousuke"]
“Are you saying that ...... you’re really not that type of person?”
[cpg cn=true]

[VOICE f="Fia011"]
[OnName num="fia"]
"......"
[cpg cn=true]


;**【ＣＧ】 ev_31_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]

Fia falls silent and looks down. Her face turns bright red.
[cpg cn=true]

[VOICE f="sFia003"]
[OnName num="fia"]
“I'm sorry. I don't know if I can answer these questions.”
[cpg cn=true]

[VOICE f="sFia004"]
[OnName num="fia"]
“My head is spinning, and I feel like I'm going crazy. ......"
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

She comes closer. She leans forward, and her face, or rather her lips feel closer.
[cpg]

It was bad if anyone were to come and see her on top of my body like this.
[cpg]

In my defense, I'm not the kind of guy who would do anything to a total stranger.
[cpg]


[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


So as a result the whole situation seems like a total loss, when a problem occurrs.
[cpg]
;//Ｈシーンカット


[OnName num="elf_woman"]
" Fia ......? Who are you ......? What are you doing?”
[cpg cn=true]


[OnName num="kousuke"]
"...... what?"
[cpg cn=true]




[window target=false]
[transition target={true} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[STOPBGM]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="encount.png" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_02_2.ui" time=2000]
[WAIT time=2000]

[BGM f="bg_tc"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************


[window target=true]

;//＠
[SE f="se011"]
;//【ＳＥ】『人混み』

Why? Why is this happening?
[cpg]


[OnName num="elf_man"]
“Why don’t you walk. There's no point in trying to escape.”
[cpg cn=true]


We’d been seen. There was nothing we could do about it.
[cpg]


I didn’t know if he was a friend of Fia or a colleague ...... or what Fia did for a living in the first place, but... ...
[cpg]


either way, we were misunderstood. And then the elf men came to get me.
[cpg]


A few men surround me and force me towards the city.
[cpg]


[OnName num="kousuke"]
“What are you going to do with me? ……"
[cpg cn=true]


[OnName num="elf_man"]
“ You will be put on trial for your shameful actions. You might even be executed.”
[cpg cn=true]


Execution. Does that mean death penalty? Isn't that too harsh?
[cpg]


However, there seemed to be a difference when it came to the idea of love and the system of trial. After all, it was a different world until a while ago.
[cpg]


[OnName num="elf_man"]
"Elves don't usually have children with different races. This is a serious crime."
[cpg cn=true]


[OnName num="kousuke"]
“Wait, ......, I didn't do anything.”
[cpg cn=true]


I wonder where Fia is. I wonder if there was any way that she could clear my name?
[cpg]


Or is it possible that this was all a trap......?
[cpg]


[OnName num="elf_man"]
"This is the courthouse. Go inside.”
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


If you go in, there's no way you can escape, I think to myself.
[cpg]



[SE f="se006"]
;//【ＳＥ】『魔法発動する』

[transition target={true} rule="pipo-tr005.png" color={0x000000ff} time=1000]
[WAIT time=1500]
[transition target={false} rule="pipo-tr005.png" color={0x000000ff} time=1000]
[WAIT time=1000]



[OnName num="elf_man"]
"What the hell is this……?"
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="5/3" time=800]


It’s hard to describe, but there was a magical restraint. Something like a glowing ivy stretched out from under my feet.
[cpg]

[move from="5/3" to="3/3" ease="easeInOutSine" time=1000]

[VOICE f="Fia054"]
[OnName num="fia"]
“Kosuke…..you have to run away”
[cpg cn=true]


The elven men stop moving. Did Fia do this?
[cpg]


[OnName num="kousuke"]
" Fia ......."
[cpg cn=true]


[FACE method="change_3" pos="3/3"]
[VOICE f="Fia055"]
[OnName num="fia"]
“Don't worry about me, just run away from here!”
[cpg cn=true]


[OnName num="elf_man"]
“You're covering for this guy? What are you doing?”
[cpg cn=true]


I do as I am told and run from the side of the men who had stopped moving.
[cpg]

;//＠
[SE f="se009"]
;//【ＳＥ】『走る』

;//ブラックアウト


[window target=false]
[transition target={true} rule="108.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=1]
[free time=1]
[WAIT time=200]
[transition target={false} rule="108.jpg" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_02_3_up_l.ui" time=1500]
[WAIT time=2000]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（夕方）******************************************************


[window target=true]



[OnName num="kousuke"]
"Huh, huh, huh."
[cpg cn=true]


With Fia's help, I escaped by the skin of my teeth.
[cpg]


I couldn’t stay in the land of the elves anymore. I had to go back to Japan immediately. ……
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye010"]
[OnName num="mysterious_woman"]
“You've been through hell, haven't you?”
[cpg cn=true]


[OnName num="kousuke"]
“Who are you ……? What’s your name……."
[cpg cn=true]



;//シャルティエの名前を表示してください





[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye011"]
[OnName num="schartye"]
“Oh, I never told you my name. I'm Chartier . I'm a vampire.”
[cpg cn=true]


I remembered the name from the amphibian.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye012"]
[OnName num="schartye"]
“You want to get away, don't you? Do you want to get in this airship?”
[cpg cn=true]


[OnName num="kousuke"]
“You're going to help me? I mean, how do you know I'm running away?”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye013"]
[OnName num="schartye"]
“I've been monitoring the whole thing with the magic of teleportation. It seems like your qualities are real after all."
[cpg cn=true]


Qualities? I had no idea what she was talking about. Still, I'd be forever grateful if she were to help me. ......
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye014"]
[OnName num="schartye"]
"Anyway, in a city like this, we're going to be seen. Let's take a little walk."
[cpg cn=true]


Chartier leads me to the outskirts of the city.
[cpg]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[window target=false]
[free time=2000]
[BG f="black.ui" time=2000]
[WAIT time=2500]

[BG f="b_08_3.ui" time=2000]
[WAIT time=2500]
;//【ＢＧ】『森の中の集落＿エルフの国』（夕方）******************************************************

[window target=true]




[OnName num="suspicious_man"]
“I’m sorry you had to go through all of that sir.”
[cpg cn=true]


The man whom I saw before is also here. Who the hell were these two?
[cpg]


They said they were vampires, but I couldn't understand why they were helping me so much.
[cpg]


There are a number of suspicious passengers on the airship. ......
[cpg]


What was different from the last time is that there are many demi-humans instead of full humans. I also see some elves.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye015"]
[OnName num="schartye"]
“Now we're going to the land of the beastmen.”
[cpg cn=true]


[OnName num="kousuke"]
“Wait a minute! I want to go back to Japan.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye016"]
[OnName num="schartye"]
"That's not going to happen. The next stop has already been decided.”
[cpg cn=true]


I was grateful to escape the land of the elves, but I still wanted to return to Japan.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye017"]
[OnName num="schartye"]
“And anyways we still need you for some work to get finished. We want to revive the Demon Lord. We want you to play a role in that."
[cpg cn=true]


[OnName num="kousuke"]
"Resurrection of the Demon Lord: ......?"
[cpg cn=true]


What does that mean? Am I to be sacrificed?
[cpg]


If that were the case, moving around countries would not make sense.
[cpg]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[SE f="se005"]
;//【ＳＥ】『魔法発動する　シンセパッド系の音』

[WAIT time=2000]


[BG f="b_11_3.ui" time=1000]
[WAIT time=2000]

The airship is moving. The next destination is the land of the beastmen.
[cpg]


I only knew the name of it. I knew that beastmen lived there, but I couldn’t imagine their culture.
[cpg]


The passengers are all quiet this time as well.
[cpg]


I wam still worried. I didn’t know if I’d be safe on land this time.
[cpg]


Again, Chartier and the suspicious man are not in the same room as the passengers. ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=2000]

[BG f="b_10_3.ui" time=1500]
[WAIT time=2000]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



Finally we arrive at a village.
[cpg]


[OnName num="kousuke"]
"...... This is the Land of the Beasts."
[cpg cn=true]


I knew that it was located in the East China Sea, which is pretty close to Japan.
[cpg]


I could cross the sea by boat or something, but ......
[cpg]


The land of the beastmen was a more primitive place than the land of the elves.
[cpg]


There is no mechanical technology and probably no magic, so it is not the best place for tourism.
[cpg]


I wonder if the country is governed properly as a nation. ......
[cpg]


I have no choice but to ask the beastmen for help, or get a ride on one of Chartier 's airships. ......
[cpg]


[STOPBGM]

[SE f="se005"]
;//【ＳＥ】『魔法発動する　シンセパッド系の音』

[WAIT time=2000]


Then the airship was about to take off.
[cpg]


[OnName num="kousuke"]
"Hey, wait a minute!"
[cpg cn=true]


They couldn't hear me. What did Chartier want me to do?
[cpg]



;//ブラックアウト

[STOPBGM]

[window target=false]

[BG f="b_10_4.ui" time=2000]
[WAIT time=2500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************


[window target=true]



I wonder if I should talk to someone or if I would get hurt again.
[cpg]


[OnName num="kousuke"]
“I'm hungry. ……"
[cpg cn=true]


I don't think I've eaten a proper meal today. If this goes on, I might starve to death.
[cpg]


I can see the lights from my house. I knocked on the door with all my might.
[cpg]

[BG f="b_10_4_up_l.ui" time=1000]

[WAIT time=1000]

;//＠
[SE f="se003"]
;//【ＳＥ】ドアノック

[WAIT time=2500]


;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く

[WAIT time=1000]


[OnName num="therianthropy_woman"]
"Um, ......, who are you?"
[cpg cn=true]


A beastly woman who seemed elderly comes out. She has cat ears, and I can tell just by looking at her that she is a demi-human.
[cpg]


[OnName num="kousuke"]
“I'm from Japan, but I'm lost or ...... stranded."
[cpg cn=true]


I explain the whole situation. Then the woman says
[cpg]


[OnName num="therianthropy_woman"]
“If that's the case, why don’t you come in.”
[cpg cn=true]


I am almost moved to tears by the warmth of her heart.
[cpg]



;//[free time=800]
[BG f="black.ui" time=1000]
[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1500]
[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1500]

;//ブラックアウト





The house seems to be occupied by a couple.
[cpg]


I can't find anyone who looks like their son or daughter.
[cpg]


[OnName num="therianthropy_man"]
“You know….. our daughter is suffering from a strange disease, or rather a curse.”
[cpg cn=true]


[OnName num="kousuke"]
"A curse?"
[cpg cn=true]


I was told that a girl named Meir was still sleeping in this house.
[cpg]


Time had stopped for Meir, in her youthful form.
[cpg]


[OnName num="therianthropy_woman"]
“She was cursed…..after entering a forest alone, where no one was allowed to enter.”
[cpg cn=true]


They don't know what the curse is, or who did what.
[cpg]


The girl, Meir, and the beastman couple seemed to have a huge gap in age, yet they claim that she is their daughter.
[cpg]


As I watch them tearfully talk about what had happened, I feel helpless.
[cpg]



[window target=false]

[WAIT time=1]
[transition target={true} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1]
[WAIT time=1000]
[STOPBGM]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



In the morning, I decide to walk around the village of the beasts.
[cpg]


I think to myself, "I need to find a way to get back to Japan ……."
[cpg]


;//＠
[SE f="se009"]
;//【ＳＥ】『走る』

[WAIT time=1000]


[OnName num="therianthropy_youth"]
"Hey, there! Where are you from?”
[cpg cn=true]


[OnName num="kousuke"]
"I'm from Japan. Is something wrong?”
[cpg cn=true]


[OnName num="therianthropy_youth"]
"What exceptional magic ……! Where have you been practicing your powers?
[cpg cn=true]


What a strange thing to say. Why would I have magic?
[cpg]


[OnName num="therianthropy_youth"]
“I can't be still like this. There's a girl in this village named Meir who is bound with an unbreakable curse.”
[cpg cn=true]


[OnName num="kousuke"]
“I know her. Her parents let me stay with them.”
[cpg cn=true]


[OnName num="therianthropy_youth"]
“In that case everything is simple! You might be able to lift the curse!”
[cpg cn=true]


What was that all about? It sounded absurd.
[cpg]


[OnName num="kousuke"]
“Wait a minute. What are you?”
[cpg cn=true]


[OnName num="therianthropy_youth"]
“I'm a magician, although it’s hard to tell. ...... It's rare for a beastman, but that's not important right now.”
[cpg cn=true]


[OnName num="therianthropy_youth"]
“Anyway, you are capable of exceptional magic.”
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


I wonder if that was why Fia was attracted to me. I think about it but can’t come to a conclusion.
[cpg]


If that's the case, maybe I should listen to what he has to say and find out what I can do.
[cpg]



;//ブラックアウト

[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]

[BG f="b_10_2_up_l.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************

[window target=true]


;//上下に黒帯を入れてください

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]

[WAIT time=1500]


I go back to the old couple's house again.
[cpg]


I cut the tip of my finger and draw a simple summoning circle following the instructions of the young man.
[cpg]


Even though it is a simple magic circle, I'm not sure if it works. ......
[cpg]


At first, I wondered what a summoning circle was, but I decided to make a mark with blood.
[cpg]


[OnName num="therianthropy_youth"]
"Follow my lead and cast the spell, okay?"
[cpg cn=true]


[OnName num="kousuke"]
“Ok..…”
[cpg cn=true]


The young man chants a couple of words, or rather a spell that was hard to remember, so I shadow them.
[cpg]


The old couple looks at me nervously. I don't want to betray their expectations.
[cpg]


As I recite the incantation, ......
[cpg]


;//画面徐々に白く

;//＠
[SE f="se006"]
;//【ＳＥ】魔法（できれば回復系）

[transition target={true} rule="amamori3.webp" color={0xffffffff} time=1000]
[WAIT time=2000]


[STOPBGM]

Meir 's body and chest begins to glow.
[cpg]


I continue to chant, wondering if I myself was going to be okay.
[cpg]



[WAIT time=1000]


;//画面元に戻る
[transition target={false} rule="amamori3.webp" color={0xffffffff} time=1000]
[WAIT time=1500]

;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



And then….. as the light subsided,
[cpg]

[BGM f="bg_d1"]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile001"]
[OnName num="meile"]
"......Hmm ......, is that you mother? Father……."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile002"]
[OnName num="meile"]
"You both look so old ......your hair is all white."
[cpg cn=true]


[OnName num="meile_mother"]
"Oh, Meir ! I’m so glad, I’m so glad.”
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[FACE method="change_5" pos="2/3"]
The mother hugs Meir tightly. The father is also in tears.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]



It took a while for the girl, Meir, to understand the situation.
[cpg]


However her parents think that I helped her.
[cpg]


I didn't do anything, I think it was the young man who did something. ......
[cpg]


Still, her parents worshipped me as if I were a God.
[cpg]

[window target=false]

[STOPBGM]
[WAIT time=1500]


[BG f="b_10_2.ui" time=1000]
[WAIT time=1000]


[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************


[window target=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile003"]
[OnName num="meile"]
“I thank you sir……for helping me. You saved my life."
[cpg cn=true]


The girl Meir herself also thanks me. It feels a little awkward.
[cpg]


;//[jump storage="ep001.ks" target="*start"]

;// メイル編
[jump storage="ep001_meir.ks" target="*start"]


;=========================================================================================


