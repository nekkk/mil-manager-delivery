
;//==============================
;//２、ヒロイン２

*start

*ep003
*IseSel08_2|Peace・Meir

[SCENE id=2]

Meir. The first woman that came to my mind was her.
[cpg]


She's always been close to me, and I've always been comfortable with that, but ......
[cpg]


It's not just that. She’s originally from the land of the beasts.
[cpg]


It might be Meir who wanted peace more than anyone else.
[cpg]



;//ブラックアウト
[window target=false]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************


[window target=true]


The next day. I went to Meir .
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile204"]
[OnName num="meile"]
"Oh, Kosuke . What's wrong?"
[cpg cn=true]


[OnName num="kousuke"]
"...... Meir . Can I talk to you for a minute?"
[cpg cn=true]


I told her everything I was feeling.
[cpg]


I want to stop fighting right now. It may not have started yet, but I want to make sure it doesn't happen.
[cpg]


I don't care if I'm not the Demon Lord anymore. That's how I felt.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile205"]
[OnName num="meile"]
"I see. That's what you were thinking?”
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. I want to hear what you have to say. Can you think of a way to get out of this?”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile206"]
[OnName num="meile"]
“I don't know if I can….…”
[cpg cn=true]


[OnName num="kousuke"]
“Please. I don't care what it is, I think I need some ideas from people who don't know as much about magic.”
[cpg cn=true]


I try to persuade her.
[cpg]


But the fact is, it would not help to confide in Chartier or Kullulu .
[cpg]


I'm sure they're against my desire for peace.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile207"]
[OnName num="meile"]
“I wonder if I can help you strip your powers.”
[cpg cn=true]


[OnName num="kousuke"]
"...... that's ......."
[cpg cn=true]


I, for one, would like it best if such a thing were possible.
[cpg]


I wondered if it was possible. Maybe not.
[cpg]


If it were though, people might fight over your power.
[cpg]


[OnName num="kousuke"]
“If you could, that would be ideal. You mean I'll be a normal person again?”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile208"]
[OnName num="meile"]
“Yes. I guess we'll have to ask Chartier and Kullulu if that's possible.”
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Meile209"]
[OnName num="meile"]
“But before that, there’s something that I want to do.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


Meir had a dazed look on her face. She seems to have been affected by my magical element.
[cpg]

[OnName num="kousuke"]
“We can't flirt in public, right?”
[cpg cn=true]


I was in the mood for it. I want to be near her.
[cpg]


[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[window target=true]




I walked out of the castle and headed further out into the city.
[cpg]


Further out of town, into the woods where no one would find us.
[cpg]

[VOICE f="sMeile023"]
[OnName num="meile"]
“I feel at home in the woods.”
[cpg cn=true]

[VOICE f="sMeile024"]
[OnName num="meile"]
“When I'm with you Kosuke , I feel like it's just the two of us.”
[cpg cn=true]

[OnName num="kousuke"]
“Yeah.”
[cpg cn=true]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




Hopefully, it will become that way. I've been in too many positions where it was not my intention to be.
[cpg]

The only thing I really want is Meir .
[cpg]

As we walk, Meir trips over a tree root and nearly falls.
[cpg]

[VOICE f="sMeile025"]
[OnName num="meile"]
"Ouch!"
[cpg cn=true]

[OnName num="kousuke"]
“Oops."
[cpg cn=true]

;//========================================
;//●ＣＧ（後ろからヒロインの手を掴む主人公）ev_33
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：魔王の国＿森の中
;//時間　：昼
;//備考　：公式サイト三枚目のCGです
;//========================================

*Scene012

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile026"]
[OnName num="meile"]
“Thank you, ....... That was a close one."
[cpg cn=true]

[OnName num="kousuke"]
"Oh, yeah, ......."
[cpg cn=true]

I look kind of funny now.
[cpg]

I can feel Meir 's body heat. It’s a little higher than an average demi-human because she was after all a beastman.
[cpg]

Or maybe it was because of this particular situation.
[cpg]

I think again, Meir is quite stylish……
[cpg]

;**【ＣＧ】 ev_33_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile027"]
[OnName num="meile"]
“...... hehe. Kosuke, your hands are warm.”
[cpg cn=true]

[OnName num="kousuke"]
“Is that so? Yours are as well.”
[cpg cn=true]

[VOICE f="sMeile028"]
[OnName num="meile"]
“Maybe so. Beastmen tend to have high body temperature.”
[cpg cn=true]

I wondered if that was true, but a silence continued.
[cpg]

We both felt like we wanted to say something, but couldn't.
[cpg]

[OnName num="kousuke"]
"How long are you going to stay in that position?”
[cpg cn=true]

;**【ＣＧ】 ev_33_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile029"]
[OnName num="meile"]
“Sorry, sorry, I just wanted to hold your hand.”
[cpg cn=true]

[OnName num="kousuke"]
“Well then, let's just hold hands.”
[cpg cn=true]

[VOICE f="sMeile030"]
[OnName num="meile"]
"Yeah. Sure."
[cpg cn=true]

We went back to our normal position.
[cpg]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//Ｈシーンカット


[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Meile233"]
[OnName num="meile"]
"...... Hey, Kosuke . Do you like me?”
[cpg cn=true]


[OnName num="kousuke"]
"Yeah, I like you Meir .”
[cpg cn=true]

[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Meile234"]
[OnName num="meile"]
"I see. ...... I'm glad. I really like you too.”
[cpg cn=true]


I know that Meir likes me. I’m still the Demon Lord.
[cpg]


But what would happen if ...... I was no longer a Demon Lord?
[cpg]


[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************


[window target=true]



[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude232"]
[OnName num="clolowlude"]
"...... Ripping the power from the Demon Lord? That's an interesting idea."
[cpg cn=true]


Later, after consulting with Kullulu, it seemed possible.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude233"]
[OnName num="clolowlude"]
“If anything, it's easier to rip off the Demon Lord's power than to just seal away his magic.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude234"]
[OnName num="clolowlude"]
“If you only seal the magic power, you will be sealing the element that makes you the Demon Lord.”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude235"]
[OnName num="clolowlude"]
“There might be something wrong with the Demon Lord's body. It's dangerous.”
[cpg cn=true]


[OnName num="kousuke"]
“So there's no disadvantage to ripping out the magic power instead of sealing it?”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude236"]
[OnName num="clolowlude"]
“But then only the stripped magic will exist on its own.”
[cpg cn=true]


It's a difficult subject. I'm not really following, and Meir wasn't trying to understand in the first place.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude237"]
[OnName num="clolowlude"]
“I don't know if the magic has a will or not, but it could go out of control on it’s own.”
[cpg cn=true]


[OnName num="kousuke"]
"Oh, yeah? ......?"
[cpg cn=true]


I can't quite picture it. I'm sure it's a big deal.
[cpg]


Only the power will run off on its own. The power that could conquer the world will survive on its own.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************

[window target=true]




We decided to ask for Chartier’s opinion as well.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Schartye180"]
[OnName num="schartye"]
“If we strip off your powers, we also have to find a way to diminish the power itself.”
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye181"]
[OnName num="schartye"]
“It might even turn against us. It's dangerous to hold it back.”
[cpg cn=true]


However, it seems that as long as Chartier and Kullulu are here, it would not be impossible to fight.
[cpg]


[FACE method="change_7" pos="2/2"]
[VOICE f="Meile235"]
[OnName num="meile"]
"Can we win ......?"
[cpg cn=true]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye182"]
[OnName num="schartye"]
"I don't know if I'll win or lose. If I lose, then we might die.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



...... Chartier has also raised other concerns.
[cpg]


If we are successful in fighting and sealing the power of the Demon Lord……
[cpg]


We might loose the means to negotiate with other countries.
[cpg]


;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[window target=true]




I came out to the city. The people of this country have come together for me.
[cpg]


[OnName num="kousuke"]
“…… What am I supposed to do?”
[cpg cn=true]

[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
I murmured. Next to me stood Meir .
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile236"]
[OnName num="meile"]
"Whatever you want to do, Kosuke. That's what makes me happy."
[cpg cn=true]


[OnName num="kousuke"]
"Well, ......."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]


I felt as if I couldn't feel anything at all.
[cpg]

[free time=1000]

I don't know if I can do as I please. And what will happen to this country as a result of me behaving as I please?
[cpg]


I couldn't imagine anything well.
[cpg]


I guess I'm not in a calm mood.......
[cpg]


[VOICE f="Meile237"]
[OnName num="meile"]
"...... Kosuke "
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]


Meir hugged me from behind.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile238"]
[OnName num="meile"]
"I'm here for you. Don't worry."
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





In fact, Meir doesn't have any special powers.
[cpg]


But it felt more reassuring than the words of Chartier or Kullulu .
[cpg]

[STOPBGM]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]



[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
We got back to my room.
[cpg]


[OnName num="kousuke"]
"What if ...... I'm not a Demon Lord anymore?"
[cpg cn=true]


[OnName num="kousuke"]
"You might not be attracted to me anymore. I won't have any pheromones or anything.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile239"]
[OnName num="meile"]
“I told you not to worry. I'll always like you no matter what.”
[cpg cn=true]


[OnName num="kousuke"]
“......, why are you so crazy about me?”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile240"]
[OnName num="meile"]
“I don't know. I think it started with ...... when I came on to you.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sMeile031"]
[OnName num="meile"]
“You didn't mind, you seemed happy. It made me happy too.”
[cpg cn=true]


[OnName num="kousuke"]
“...... I remember…….”
[cpg cn=true]




;//ブラックアウト



;//========================================
;//●ＣＧ（主人公にのしかかるヒロイン）ev_34
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城内＿主人公の部屋
;//時間　：昼
;//========================================

*Scene027

[BG f="black.ui" time=1000]
[free time=1000]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile032"]
[OnName num="meile"]
“I'm pretty sure it was something like this……."
[cpg cn=true]

[OnName num="kousuke"]
“I don't think so. That was after we met.”
[cpg cn=true]

[VOICE f="sMeile033"]
[OnName num="meile"]
“Really? I think I remember it pretty well.”
[cpg cn=true]

[OnName num="kousuke"]
“I'm pretty sure I remember you too.”
[cpg cn=true]

As we talk, I felt her presence very close to me.
[cpg]

Then Meir leaned forward.
[cpg]

;**【ＣＧ】 ev_34_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile034"]
[OnName num="meile"]
“Do you want me to kiss you?”
[cpg cn=true]

[OnName num="kousuke"]
“You better not. I've heard that my saliva contains magical elements.”
[cpg cn=true]

;**【ＣＧ】 ev_34_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=100]

Meir was puzzled and said, “Really?"
[cpg cn=true]

[VOICE f="sMeile035"]
[OnName num="meile"]
“Who told you that?”
[cpg cn=true]

[OnName num="kousuke"]
“I'm pretty sure Chartier told me.”
[cpg cn=true]

[VOICE f="sMeile036"]
[OnName num="meile"]
“If I kiss you, I might fall in love with you even more.”
[cpg cn=true]

[OnName num="kousuke"]
“Want to try it? I don't know what will happen."
[cpg cn=true]

We talked and talked, and in the end we didn't kiss.
[cpg]

It was still early...... I wanted to value Meir.
[cpg]

Of course, taking the right steps wasn’t the only way to show that I cared for her.
[cpg]

But if ...... time is going to pass this quickly, it would be a waste.
[cpg]

That's how I felt.
[cpg]

;//Ｈシーンカット

;//ブラックアウト
[STOPBGM]


*effect|Peace・Meir

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




At night. It was going to take place in my room.
[cpg]

[BG f="e_01_1.ui" time=1000]
[WAIT time=1000]

There is a magic circle on the floor. It was drawn by Fia and Chartier .
[cpg]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1000]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Schartye183"]
[OnName num="schartye"]
“I have to say, I'm not in favor of this.”
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude238"]
[OnName num="clolowlude"]
"Me too. I don't know what this country will be like without you as the Demon Lord."
[cpg cn=true]


[OnName num="kousuke"]
“...... I know, I know. But ……"
[cpg cn=true]

[free time=800]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Meile263"]
[OnName num="meile"]
“But there's also the danger of having a ...... Demon Lord.”
[cpg cn=true]

Meir was not pressured by Chartier and the others.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sFia025"]
[OnName num="fia"]
“I think so too. It's the only way to solve everything peacefully."
[cpg cn=true]

[FACE method="change_1" pos="1/2"]
[VOICE f="sMeile037"]
[OnName num="meile"]
" Fia ......."
[cpg cn=true]


And then my power ...... as a Demon Lord was stripped away.
[cpg]


[free time=800]

I'm in the center of the magic circle. It seems to be easier than sealing the magic power as a Demon Lord.
[cpg]


However, this also means that there is another danger.
[cpg]


The magic power might go out of control.
[cpg]


[STOPBGM]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Schartye184"]
[OnName num="schartye"]
“Let's go. Prepare yourself, Demon Lord."
[cpg cn=true]


Chartier chants a spell. And ......
[cpg]



[SE f="se005"]
;//【ＳＥ】『魔法の音　低め』
[free time=1000]



[BGM f="bg_ma"]

;//画面白く
[BG f="e_01_1.ui" time=1000]
[WAIT time=2000]

[FG f="e_02_2.ui" method="change_1"  pos="3/5" time=1]
[WAIT time=3000]

[BG f="black.ui" time=1000]


;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]


I fell down on the spot. My legs lost their strength.
[cpg]


[SE f="se014"]
;//【ＳＥ】『地鳴りのような音』


[window target=false]
[transition target={true} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=2100]

[BG f="e_01_3.ui" time=1]
[free time=1]
[WAIT time=10]

[WAIT time=200]
[transition target={false} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=1500]

[window target=true]


The only thing that was stripped from my body was my magic power. As expected, the Demon Lord's power is out of control......
[cpg]


A black sphere was bubbling away and floating above my lying body.
[cpg]

;//＠
[SE f="se005"]
;//【ＳＥ】魔法攻撃

Then it shoots a beam of light. It's going to attack Meir and everyone else…..!
[cpg]




[SE f="se005"]
;//【ＳＥ】『バリア　金属音のような感じ』





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye185"]
[OnName num="schartye"]
"Oh, ......, I knew this would happen."
[cpg cn=true]

[stopse g=2]
;//通常se

[SE f="se005"]
;//【ＳＥ】魔法攻撃

[transition target={true} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=1100]

[free time=1]
[BG f="e_01_3.ui" time=1]
[WAIT time=10]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/2" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=1]
;//[FG f="e_02_2.ui" method="change_2"  pos="3/5" time=1]


[WAIT time=200]
[transition target={false} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=1500]


[SE f="se005"]
;//【ＳＥ】『バリア　金属音のような感じ』

[FACE method="change_5" pos="2/2"]
[VOICE f="Clolowlude239"]
[OnName num="clolowlude"]
“What should we do, even if we were to attack, the Demon Lord will ……!"
[cpg cn=true]



[FACE method="change_3" pos="1/2"]
[VOICE f="Fia297"]
[OnName num="fia"]
“We just have to stay calm and protect ourselves.”
[cpg cn=true]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=2100]
[free time=1]
[BG f="black.ui" time=1]


I couldn't do anything about it. I didn’t know what to do.
[cpg]


[WAIT time=1000]

[SE f="se008"]
;//【ＳＥ】『歩く』
[BG f="e_01_3.ui" time=1]

[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=1]


[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1000]


But then, Meir approaches the black ball ...... She gets close to the Demon Lord's power.
[cpg]


[VOICE f="Fia298"]
[OnName num="fia"]
"Meir ! It's dangerous, get away!”
[cpg cn=true]


I was wondering what Meir was trying to do.
[cpg]

[FACE method="change_2" pos="2/3"]


Meir whispers something and then……
[cpg]



The Demon Lord's power subsided as I watched. It stopped attacking.
[cpg]


I don't know what's going on, and I don't know what Meir has done.
[cpg]


But Chartier would not miss the opportunity.
[cpg]



[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]

[free time=1]
[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="1/2" time=1]

[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=1]
[BG f="e_01_3.ui" time=1]



[WAIT time=200]
[transition target={false} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1500]

[window target=true]


[VOICE f="Schartye186"]
[OnName num="schartye"]
"Now!"
[cpg cn=true]


[VOICE f="Fia299"]
[OnName num="fia"]
"Yes."
[cpg cn=true]

[SE f="se005"]
;//【ＳＥ】『バリア　金属音のような感じ』

[FG f="e_02_2.ui" method="change_2"  pos="3/5" time=2000]
[WAIT time=3000]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
;//ブラックアウト



The power of the Demon Lord was sealed with the power of Fia and the others.
[cpg]


In the end, I had no idea what Meir had done. ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye187"]
[OnName num="schartye"]
"Huh, huh, is it done ......?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Fia300"]
[OnName num="fia"]
"Yes ...... maybe, it worked."
[cpg cn=true]


There was nothing left of it. I guess it is more correct to say that it was erased rather than sealed.
[cpg]


[OnName num="kousuke"]
"Did you delete ......?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude240"]
[OnName num="clolowlude"]
“No. It's just a seal. It's just invisible in this world.”
[cpg cn=true]


[OnName num="kousuke"]
“Oh......?”
[cpg cn=true]


I guess I still don't know much about magic.
[cpg]


But I do know one thing for sure though. I am no longer the Demon Lord.
[cpg]



;//ブラックアウト
[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_05_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************

[window target=true]




The people still don't know that the Demon Lord is gone.
[cpg]


Will they be disappointed? This country might as well have lost its reason for existence.
[cpg]


But ...... somehow, it seemed to be inevitable. This is what the Demon Lord himself wanted.
[cpg]


But what did Meir say back there?
[cpg]


[OnName num="kousuke"]
“Meir ...... what did you do back there?”
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile265"]
[OnName num="meile"]
"Nothing. I didn't do anything really.”
[cpg cn=true]


[OnName num="kousuke"]
“That’s not true. Obviously, it stopped attacking us.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile266"]
[OnName num="meile"]
“But ...... you're right. If the Demon Lord's power has been stripped from you, then ……"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile267"]
[OnName num="meile"]
“I was wondered if there was any of your nature left. So…"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile268"]
[OnName num="meile"]
“I said, ‘I love you for who you are as a human being, and I want you to sleep peacefully for now.’”
[cpg cn=true]


[OnName num="kousuke"]
"...... You said that?"
[cpg cn=true]


It seemed that the power of the Demon Lord, had some personality left. So she appealed to it.
[cpg]


[OnName num="kousuke"]
“Thank you. Meir . I can't thank you enough."
[cpg cn=true]


I thanked Meir and thought about what I would do.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile269"]
[OnName num="meile"]
“No need to thank me. Let’s just..."
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMeile038"]
[OnName num="meile"]
“Let's just make out. It's been a long time since you've felt that safe, since no one is trying to kill you.”
[cpg cn=true]


[OnName num="kousuke"]
“...... Well.”
[cpg cn=true]



;//ブラックアウト
[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_07_4.ui" time=1000]

[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************

[window target=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

Meir and I walked back to the castle.
[cpg]


We decided to head to her room. So that the two of us could be alone together.
[cpg]


We have nothing to fear anymore, at least for now.
[cpg]


[OnName num="kousuke"]
“I suppose we should announce that the ...... Demon Lord is no longer in power.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile271"]
[OnName num="meile"]
“I don't know. Maybe someone in the elven lands who is skilled in magic has already figured it out.”
[cpg cn=true]


That's true. They had also figured out that I'm the Demon Lord.
[cpg]


It is possible that it may be the same this time as well,......, I think as I walk into Meir’s room .
[cpg]



[SE f="se002"]
;//【ＳＥ】『ドア開く』




;//ブラックアウト


;//Ｈシーンカット

;//========================================
;//●ＣＧ（キスをするヒロインと主人公）ev_03
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城内＿ヒロイン２の部屋
;//時間　：夜
;//========================================

*Scene031

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
;[Event g="ev_03_0" a=false f=false]
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=100]

The moment happened abruptly. Something I couldn't do the other day.
[cpg]

[OnName num="kousuke"]
"......, that's pretty sudden."
[cpg cn=true]

;**【ＣＧ】 ev_03_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile039"]
[OnName num="meile"]
"Hmm. It is. It's not so sudden, because I couldn't do it the other day.”
[cpg cn=true]

[VOICE f="sMeile040"]
[OnName num="meile"]
“Maybe now I've got your magic.”
[cpg cn=true]

[VOICE f="sMeile041"]
[OnName num="meile"]
“Maybe there will be more miracles like the last one.”
[cpg cn=true]

[OnName num="kousuke"]
“I don't know. It's already a miracle that we're both here.”
[cpg cn=true]

[VOICE f="sMeile042"]
[OnName num="meile"]
“You're starting to sound like a king. I like that.”
[cpg cn=true]

[OnName num="kousuke"]
“Well, ......, I've been a Demon Lord for a long time.”
[cpg cn=true]


;**【ＣＧ】 ev_03_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile043"]
[OnName num="meile"]
“You've been a Demon Lord since the beginning.”
[cpg cn=true]

[VOICE f="sMeile044"]
[OnName num="meile"]
“And now you're not a Demon Lord, you're a king.”
[cpg cn=true]

[OnName num="kousuke"]
“Yeah. That's right.”
[cpg cn=true]

We kissed again while talking about such things.
[cpg]

It's a shame to let such a happy time pass by.
[cpg]

Meir seemed to be thinking the same thing, and wouldn't let me go.
[cpg]


;//Ｈシーンカット



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





The night dawns. I'm no longer the Demon Lord, but I'm still king.
[cpg]

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[window target=true]





All over the world, it was reported that the power of the Demon Lord was gone.
[cpg]


In other words, the world knew that I was no longer a marvel. And this country was no exception.
[cpg]


I thought I would no longer be able to be king, but ......
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





The reality was not that simple. It seems that I have the credit of uniting the demi-humans.
[cpg]


The union had a big importance.
[cpg]


From a former Demon Lord, I turned into a mere king.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile314"]
[OnName num="meile"]
“I wonder what the name of this country will be. ‘The Demon Country’ does not sound right.”
[cpg cn=true]


[OnName num="kousuke"]
"I'm going to change it back to the Land of Beastmen. That's what it used to be.”
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sFia026"]
[OnName num="fia"]
“I think that's a good idea. The beastmen will be familiar with it.”
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude241"]
[OnName num="clolowlude"]
“I can't believe I'm not the Demon Lord anymore.”
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Clolowlude242"]
[OnName num="clolowlude"]
“If I were in that position, I would put my faith in the power of the Demon Lord, no matter the risk.”
[cpg cn=true]


[OnName num="kousuke"]
“It's not that simple, you know. As long as the Demon Lord's power exists, you have to keep fighting.”
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="sFia027"]
[OnName num="fia"]
“I guess that's the way it is. ……"
[cpg cn=true]


Conquering power with power doesn't seem like a good idea in this day and age.
[cpg]


I think I've got what I wanted.
[cpg]


And Meir’s power was essential to that.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Meile315"]
[OnName num="meile"]
"Hey, Kosuke. Are you free today?"
[cpg cn=true]


[OnName num="kousuke"]
"No, not really. ...... I've got a lot of work to do. ……"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sFia028"]
[OnName num="fia"]
“Looks like we're in the way.”
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude243"]
[OnName num="clolowlude"]
“Seems like it……."
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]

;//ブラックアウト



[SE f="se004"]
;//【ＳＥ】『ドア閉まる』

[STOPBGM]
[WAIT time=1000]



[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile316"]
[OnName num="meile"]
“Heh. It's just you and me now.”
[cpg cn=true]


[OnName num="kousuke"]
“Don't you ever get embarrassed?”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sMeile045"]
[OnName num="meile"]
“Why? It's normal for two people who like each other to be together.”
[cpg cn=true]


[OnName num="kousuke"]
“Maybe so, but ...... it’s too obvious.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile318"]
[OnName num="meile"]
“That's fine. I'm ready to be your wife.”
[cpg cn=true]


I am surprised……
[cpg]


[OnName num="kousuke"]
“I think you already know but you're the only one for me.”
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile319"]
[OnName num="meile"]
“......Hmmm. I'm glad.”
[cpg cn=true]

;//Ｈシーンカット

;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]




Peaceful time passed.
[cpg]


There was no longer any reason for anyone to try to kill me.
[cpg]


But I'm still the king. You can find a lot of things to do in order to maintain peace.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile340"]
[OnName num="meile"]
“Kosuke, don't spend all your time working, be with me.”
[cpg cn=true]


[OnName num="kousuke"]
“I'll see you later. ...... A messenger is coming from the land of the elves today.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile341"]
[OnName num="meile"]
“I guess….…promise?”
[cpg cn=true]


Meir is still the same, but maybe I’m also still the same.
[cpg]


I'm not a Demon Lord anymore, but other than that things haven’t really changed……
[cpg]


Meir and me lived happily.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_mi"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************

[window target=true]




At night in the castle town. We take a walk together.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile342"]
[OnName num="meile"]
"It's become a great town, hasn't it? Just a while ago, there was nothing here.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile343"]
[OnName num="meile"]
“I don't think the demi-humans have ever been so united. Kosuke “
[cpg cn=true]


[OnName num="kousuke"]
“I think you're right, ……."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile344"]
[OnName num="meile"]
"It's all thanks to you Kosuke. You may not be the Demon Lord anymore, but you'll always be special to me.”
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile345"]
[OnName num="meile"]
“I won't let you go. Be prepared.”
[cpg cn=true]


[OnName num="kousuke"]
“…… I will.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//ＥＮＤ　ヒロイン２平和ルート

[WAIT time=100]
[jump storage="epend.ks" target="*start"]
[WAIT time=100]
;[s]
[WAIT time=100]
[WAIT time=100]

