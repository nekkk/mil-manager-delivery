
;//==============================
;//３、佐智恵

*start|Sachie's Husband's Unique Hobbies

*select05_3|Sachie's Husband's Unique Hobbies

[SCENE id=8]

It had to be Sachie. I remembered that her husband had a unique hobby.
[cpg]


If that's the case, I should take it to the next level.
[cpg]


;#################################################
*Ep008|Sachie's Husband's Unique Hobbies
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************


The next day I went to Sachie's place. I knew her husband was at work.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sachie171"]
[OnName num="sachie"]
"I'm sorry about the other day. You must have been surprised."
[cpg cn=true]


[OnName num="tomoya"]
"The other day? Ah, you mean the thing with your husband."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sSachie018"]
;//[VOICE f="Sachie172"]
[OnName num="sachie"]
"Yes, that's right. I guess most people would be surprised to hear something like that.……"
;//「うん、そう。普通びっくりするよね、あんなことお願いされたら……」
[cpg cn=true]


[OnName num="tomoya"]
"Oh, I was surprised. But I don't really mind."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sachie173"]
[OnName num="sachie"]
"I'm glad to hear that, I have a favor to ask you today."
[cpg cn=true]

;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************


[OnName num="tomoya"]
"……You want to record us? What prompted this?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sachie192"]
[OnName num="sachie"]
"Do you really want to know why?"
[cpg cn=true]


I was pretty sure I knew, but I wanted to hear it from her.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="sSachie019"]
[OnName num="sachie"]
"My husband wants to see......what we do together."
[cpg cn=true]


[OnName num="tomoya"]
"I see…well, that's pretty much what I thought."
[cpg cn=true]


It might take time, but I was determined to make him regret this.
[cpg]


With this in mind, I got closer to Sachie.
[cpg]


;//========================================
;//●ＣＧエロ（主人公がヒロインに迫る。ヒロインはピースしている）ev_28
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：昼
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="tomoya"]
"Alright Sachie, smile."
[cpg cn=true]


[VOICE f="sSachie020"]
[OnName num="sachie"]
"What……"
[cpg cn=true]


[OnName num="tomoya"]
"You can smile, right? It's what I want."
[cpg cn=true]


[VOICE f="sSachie021"]
[OnName num="sachie"]
"……."
[cpg cn=true]


She even made a peace sign with her fingers and smiled. I found myself grinning uncontrollably.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************


[OnName num="tomoya"]
"Well, the sun is setting.……"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sachie213"]
[OnName num="sachie"]
"Are you leaving already……?"
[cpg cn=true]


[OnName num="tomoya"]
"Yes. I would feel awkward if I saw your husband."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sachie214"]
[OnName num="sachie"]
"I think he would be pleased."
[cpg cn=true]


[OnName num="tomoya"]
"Even so. I'll see you then."
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


I had to steal her from him eventually, but this wasn't the time.
[cpg]


I needed a plan.
[cpg]


There must be some way to make Sachie feel disappointed in her husband.
[cpg]


I felt that would be easier than making her fall in love with me the normal way.
[cpg]


What should I do? After much thought, I came up with a plan.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


The next day. I knocked on Sachie's door, but she was not home.
[cpg]


I had no choice but to wander around for a while. I could have gone to my classes, but I didn't have an important lecture today.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sachie215"]
[OnName num="sachie"]
"Oh, Tomoya…… what's wrong?"
[cpg cn=true]


[OnName num="tomoya"]
"I was looking for you. What were you doing?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Sachie216"]
[OnName num="sachie"]
"Nothing much. I was just seeing my husband off for a little while."
[cpg cn=true]


I see. I'll put an end to that too.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************


She fed me lunch. It was hashed beef and rice that she had made yesterday.
[cpg]


I can tell that she is opening up to me a lot.
[cpg]

I want to be a bigger part in her life.
[cpg]


;//移植のためシーンをカットしています

After that, I stayed with Sachie for a while.
[cpg]

[OnName num="tomoya"]
"Your husband approves of our relationship, right?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Sachie238"]
[OnName num="sachie"]
"Yes……"
[cpg cn=true]


[OnName num="tomoya"]
"I have an idea for a little prank, are you interested?"
[cpg cn=true]


A prank is a simple thing. In conclusion.
[cpg]


[OnName num="tomoya"]
"Sachie, please tell your husband you're going to marry me."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sachie239"]
[OnName num="sachie"]
"What……but if I say that……"
[cpg cn=true]


[OnName num="tomoya"]
"He might be pleased."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sachie240"]
[OnName num="sachie"]
"I think it's going too far, he might get angry."
[cpg cn=true]


[OnName num="tomoya"]
"That's when you can tell him it was just a joke. Don't worry so much."
[cpg cn=true]


The plan was simple.
[cpg]


I'd have Sachie tell him that she was going leave him for me. I figured the shock would be enough for him to show his true colors.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『ヒロイン３の部屋』（夜）******************************************************


We dress up a bit and meet him together.
[cpg]


[OnName num="sachie_husband"]
"What's going on here?"
[cpg cn=true]


[OnName num="tomoya"]
"Actually, Sachie and I have been talking about getting married."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Sachie260"]
[OnName num="sachie"]
"Y-yes, I...I suppose we'll have to get divorced first..."
[cpg cn=true]


Sachie had some difficulty saying her lines.
[cpg]


Sachie must think it's all just a prank.
[cpg]


[OnName num="sachie_husband"]
"You can't be serious……! Please tell me you're joking, Sachie."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sachie261"]
[OnName num="sachie"]
"It's not a joke, I've really fallen in love with Tomoya."
[cpg cn=true]


[OnName num="sachie_husband"]
"It's a lie......it has to be."
[cpg cn=true]


[OnName num="tomoya"]
"It's not a lie, you lost. Just give up."
[cpg cn=true]

;//[free time=500]
;//[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
;//[WAIT time=1000]

I kiss Sachie in front of him.
[cpg]


[FACE method="change_6" pos="2/3"]


What does Sachie think? I bet she thinks it's a bit too much for a prank.
[cpg]

[FADEOUTBGM]

[OnName num="sachie_husband"]
"……"
[cpg cn=true]


He disappeared into the kitchen.
[cpg]



;//ブラックアウト

[BGM f="bg_da"]
[WAIT time=100]

[FACE method="shock_5" pos="2/3"]

He came back with a kitchen knife. Oops, I didn't expect him to crack like this.
[cpg]


Was he going to kill me? As I was thinking that, Sachie stood in front of me.
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Sachie263"]
[OnName num="sachie"]
"No, no…… I can't let you hurt Tomoya."
[cpg cn=true]


[OnName num="sachie_husband"]
"Get out of my way. I can't stand the thought of losing you, Sachie."
[cpg cn=true]


The two of them argued, but he still had the knife in his hand.
[cpg]

If he didn't put it down, someone was going to get hurt.....
[cpg]

[free time=1000]
[BG f="red.ui" time=1000]
[WAIT time=1000]

[OnName num="sachie_husband"]
"Ugh……."
[cpg cn=true]


;//========================================
;//●ＣＧ非エロ（返り血を浴びて驚いているヒロイン。手を見つめて呆然と立ち尽くしている。刃物は持っていない）ev_31
;//人物１：ヒロイン３
;//服装１：私服
;//場所　：ヒロイン３の部屋
;//時間　：夜
;//========================================


;**【ＣＧ】 ev_31_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


Her husband had injured himself as he thrashed around. Blood spattered all over the room.
[cpg]


[VOICE f="Sachie264"]
[OnName num="sachie"]
"Oh.......oh no……"
[cpg cn=true]


[OnName num="tomoya"]
"……we need an ambulance……."
[cpg cn=true]


I was stunned, too. He got injured on his own and was curled up on the floor.
[cpg]


[VOICE f="Sachie265"]
[OnName num="sachie"]
"I didn't want any of this to happen..."
[cpg cn=true]


[SE f="se000"]
;//【ＳＥ】『携帯電話の発信音』


I nervously call emergency services...
[cpg]


[OnName num="tomoya"]
"Hello, someone has been injured by a knife, please come right away!"
[cpg cn=true]


I couldn't have him die here. Not like this.
[cpg]


[window target=false]
[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


……In the end, he survived this ordeal.
[cpg]


He never told anyone how or why he got injured.
[cpg]


Since nobody was pressing charges, there was no way to hold anybody responsible and it was filed away as an accident.
[cpg]


[window target=false]
;//[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


He left the apartment soon after and their divorce was finalized.
[cpg]


That incident made Sachie reconsider her relationship with him. And as for me, she said……
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夜）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Sachie266"]
[OnName num="sachie"]
"……Will you marry me as soon as you graduate?"
[cpg cn=true]


[OnName num="tomoya"]
"What about him?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Sachie267"]
[OnName num="sachie"]
"I don't want to think about him……right now, all I see is you."
[cpg cn=true]


If she doesn't see him, she wouldn't be reminded of him.
[cpg]


It must have been quite traumatic for her.
[cpg]


My plan had worked, but not in the way I'd thought it would. At least now I had Sachie all to myself.
[cpg]


I won't let go of her, we probably were going to get married.
[cpg]


I have to finish college for that. A group to support my return to society, was it?
[cpg]


It seems their efforts paid off in an unexpected way.
[cpg]


;//ＥＮＤ：ヒロイン３ルート3
[SCENE id=14]

[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

