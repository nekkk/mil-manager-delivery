
;//==============================
;//１、自分のものにしたい

*start|Making them mine

*select04_1|Making them mine

[SCENE id=5]

……I wanted them all to myself.
[cpg]


I want to rip them away from their husbands. That was my new goal.
[cpg]


;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I couldn't change anything overnight, but I could start laying the foundation.
[cpg]


;#################################################
*Ep005|I wanted them to be mine.
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（朝）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Erika087"]
[OnName num="erika"]
"……*yaaawn*……What? It's so early in the morning."
[cpg cn=true]


[OnName num="tomoya"]
"Sorry about that. Erika, would you like to go on a date with me?"
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
;//[VOICE f="Erika088"]
[VOICE f="sErika007"]
[OnName num="erika"]
"A date……? Well, that's more than I could ever wish for……but why so suddenly?"
[cpg cn=true]


[OnName num="tomoya"]
"Do I need a reason?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Erika089"]
[OnName num="erika"]
"Okay, just give me a moment to get ready.……"
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


I went to town with Erika.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Erika090"]
[OnName num="erika"]
"I feel like I'm doing something terribly wrong……"
[cpg cn=true]


She says that, but she doesn't seem to dislike it.
[cpg]


We strolled around the city.
[cpg]


I knew only a limited number of good dating spots, so Erika led me around for the second half of the day.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

Time passed and it was time to head home. So, I made a proposal to her.
[cpg]

[OnName num="tomoya"]
"Erika. If your husband doesn't come back from his job, will you be with……me?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Erika113"]
[OnName num="erika"]
"Oh my, is that supposed to be a joke……?"
[cpg cn=true]


I was serious. But she doesn't need to notice that yet.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


The next day. I decided to attend classes today.
[cpg]


It was all to keep this harem lifestyle going. It's an impure motive, but it was better than nothing.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（朝）******************************************************


I hear whispering while I'm attending lectures.
[cpg]


I was not in a good mood, but I was starting to relax.
[cpg]


"I'm not like you guys", was what I thought.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


When I returned home, Mihane was waiting for me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mihane082"]
[OnName num="mihane"]
"Ah, Tomoya, welcome back……."
[cpg cn=true]


[OnName num="tomoya"]
"Have you been waiting for me this whole time?"
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="sMihane003"]
[OnName num="mihane"]
"Yes…… I wanted to see you."
[cpg cn=true]


I couldn't reject her after hearing that. If anything, it motivated me even more.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************

The following day……
[cpg]


[SE f="se003"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=2000]


[OnName num="tomoya"]
"Yes, please wait a moment……."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mihane084"]
[OnName num="mihane"]
"G-good morning…..Tomoya."
[cpg cn=true]


Mihane, who I had just met yesterday, was there.
[cpg]


[OnName num="tomoya"]
"I thought there was a rule about this?"
[cpg cn=true]


I reminded her of her agreement, but Mihane didn't seem to care.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="sMihane004"]
[OnName num="mihane"]
"Please, I want to be with you."
[cpg cn=true]


I didn't know what drove her to this, but I wasn't complaining.
[cpg]


;//========================================
;//●ＣＧエロ（主人公に迫るヒロイン。主人公の手などを消してください）ev_14
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：朝
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]

It was easy to imagine her feeling lonely.
[cpg]

But she has a husband, so this was crossing a line.
[cpg]

[VOICE f="sMihane005"]
[OnName num="mihane"]
"I need you......"
[cpg cn=true]


It was hard for me to reject her when she said this.
[cpg]

[OnName num="tomoya"]
"That makes me happy."
[cpg cn=true]


;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


Just then, the front door opened.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="3/3" time=800]

[VOICE f="Sachie083"]
[OnName num="sachie"]
"Huh, it's open? Hey......what are you doing?"
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Mihane106"]
[OnName num="mihane"]
"Oh…… uh, this is……."
[cpg cn=true]


[FACE method="shake_7" pos="3/3"]
[VOICE f="Sachie084"]
[OnName num="sachie"]
"We agreed that today is my turn. This isn't very fair."
[cpg cn=true]


Mihane looked awkwardly hesitant, yet somewhat happy to be scolded.
[cpg]

I was watching what was going on, while beginning to understand the situation…….
[cpg]

;//[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト
;//移植のためシーンをカットしています

As I had expected, Mihane seemed happy to get attention even, no matter what that entailed.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[FACE method="shake_1" pos="1/3"]
[VOICE f="Erika118"]
[OnName num="erika"]
"I'd better not catch you jumping the line again."
[cpg cn=true]


Despite Erika's scolding, I wasn't entirely convinced that Mihane was going to back down.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


The next day she came to me again.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Mihane123"]
[OnName num="mihane"]
"I'm sorry……. I couldn't help myself."
[cpg cn=true]


[OnName num="tomoya"]
"You just don't learn, do you?"
[cpg cn=true]


I guess she wants to feel a connection with someone.
[cpg]

Even if that means being scolded over and over again……
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


As expected, she became a repeat offender……and got caught again.
[cpg]



[FACE method="shake_7" pos="1/3"]
[VOICE f="sErika008"]
[OnName num="erika"]
"I'm starting to think you enjoy getting caught."
[cpg cn=true]


[FACE method="bow_7" pos="3/3"]
[VOICE f="sSachie007"]
[OnName num="sachie"]
"Tomoya you didn't invite her over, did you?"
[cpg cn=true]


Perhaps Erika and Sachie had realized that Mihane is just lonely.
[cpg]


They were giving her the benefit of the doubt.
[cpg]


;//ブラックアウト
;//移植のためシーンをカットしています


[FACE method="shake_7" pos="3/3"]
[VOICE f="sSachie008"]
[OnName num="sachie"]
"Mihane, since you keep jumping the line we're going to have to skip your turn for a while."
[cpg cn=true]


Sachie laid down the law. It was only natural.
[cpg]


After all, Mihane's actions were a betrayal from Sachie and Erika's point of view.
[cpg]


[OnName num="tomoya"]
"Mihane, what about your husband? Is this really what you want to be doing?"
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Mihane140"]
[OnName num="mihane"]
"……That's……"
[cpg cn=true]


Mihane seemed conflicted. She then goes on to say.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Mihane141"]
[OnName num="mihane"]
"I like you, Tomoya…… but I've known my husband for a long time."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mihane142"]
[OnName num="mihane"]
"It's hard for me to watch him work until he almost collapses…….If I was asked to choose between the two, I don't think I could."
[cpg cn=true]


......I don't like that, I want her to focus on me and me alone.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


A few more days pass. As I gradually returned to college, I didn't mind the things people were saying about me so much anymore.
[cpg]


I'm fine with me just being me. After all, I have a harem of married women waiting for me when I get home.
[cpg]


That made me feel stronger and more confident.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


On my way home, I bumped into Sachie.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sachie090"]
[OnName num="sachie"]
"Lately, you've been only seeing Mihane. Have you forgotten about me?"
[cpg cn=true]


[OnName num="tomoya"]
"……Of course not, but it's not like your husband always comes home exhausted or anything, right?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="sSachie009"]
[OnName num="sachie"]
"Don't make me say it……. I'm know that it's wrong."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="sSachie010"]
[OnName num="sachie"]
"I'm cheating on my husband, I know that."
[cpg cn=true]


I was fully aware that what we were doing was wrong. But even that didn't stop me from inviting her into my room.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="cube.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

And as we spent time alone together, quite a bit of time passed.
[cpg]

[OnName num="tomoya"]
"……I think your husband will be home soon."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sachie111"]
[OnName num="sachie"]
"Don't worry, it's okay."
[cpg cn=true]


[OnName num="tomoya"]
"Are you sure? Don't you think he'll be worried if you're not home?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Sachie112"]
[OnName num="sachie"]
"Really, it's fine. Do you want to come to my room?"
[cpg cn=true]


What was she up to? If I went there now, I would run into her husband.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Though hesitant, I agreed to go to Sachie's place. There……
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン３の部屋』（夜）******************************************************


[OnName num="tomoya"]
"……"
[cpg cn=true]


;//========================================
;//●ＣＧエロ（下からのアングル、主人公のことを紹介するヒロイン。普通に座ってる感じにしてください）ev_18
;//人物１：ヒロイン３
;//服装１：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_00_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSachie011"]
[OnName num="sachie"]
"I'll introduce you. This boy's name is Tomoya."
[cpg cn=true]


[OnName num="sachie_husband"]
"I see. So this is him..."
[cpg cn=true]


As expected, her husband was there. It was very awkward.
[cpg]


Does he know about my relationship with her?
[cpg]


If so, how why keep quiet about it?
[cpg]


[VOICE f="sSachie012"]
[OnName num="sachie"]
"My husband has……some unusual hobbies."
[cpg cn=true]


[VOICE f="sSachie013"]
[OnName num="sachie"]
"He also approves of my relationship with you."
[cpg cn=true]


[OnName num="tomoya"]
"What……?"
[cpg cn=true]


"Unusual hobbies...so you actually want your wife to go out and seduce other men or something...?"
[cpg]

[OnName num="sachie_husband"]
"Yes, you see I came to realize that, although I love being together with Sachie……"
[cpg cn=true]


[OnName num="sachie_husband"]
"It seems that our relationship grows stronger when we are apart."
[cpg cn=true]


I didn't pretend to understand him, but it was a golden opportunity for me.
[cpg]

[VOICE f="sSachie014"]
[OnName num="sachie"]
"So there's nothing to worry about. Do you understand?"
[cpg cn=true]


[OnName num="tomoya"]
"……I think so, yeah."
[cpg cn=true]


;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夜）******************************************************


After that shocking revelation, I left their house.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sachie135"]
[OnName num="sachie"]
"Well, I'll see you later…….Thank you for being so understanding."
[cpg cn=true]


[OnName num="tomoya"]
"No worries….."
[cpg cn=true]


I guess the two will spend the rest of the day together flirting and happy. Just imagining it makes me feel bad.
[cpg]


It's like a hazy, smoke spreading through my mind.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


……I may not be able to make Sachie mine.
[cpg]


I didn't expect that I'd get so attached to her.
[cpg]


Erika's face flashes through my mind.
[cpg]


At least she was alone.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

I fell asleep thinking about her. Then, the following day.
[cpg]


I went to Erika's place right away.
[cpg]


[window target=false]
[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Erika124"]
[OnName num="erika"]
"……What's wrong? You look intense, Tomoya."
[cpg cn=true]


[OnName num="tomoya"]
"Maybe you're right. I want to be that intense person for you."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Erika125"]
[OnName num="erika"]
"What are you saying……? I'm not afraid of you."
[cpg cn=true]


She insists. I get closer to her.
[cpg]


[SE f="se004"]
;//【ＳＥ】『ベッドに押し倒す』


[free time=1000]
[WAIT time=1000]

[VOICE f="Erika126"]
[OnName num="erika"]
"Oh……"
[cpg cn=true]


;//========================================
;//●ＣＧエロ（主人公がヒロインに近づく）ev_19
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：昼
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]

I want to be beside her as much as possible.
[cpg]

I wanted to hug her and even kiss her. That's what I wanted to do, so I get closer to her.
[cpg]

[VOICE f="sErika009"]
[OnName num="erika"]
"……"
[cpg cn=true]


But she did not refuse.
[cpg]

That was her answer.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト

……At least that's what it looked like to me.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************


But then she said something I hadn't expected.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Erika144"]
[OnName num="erika"]
"……My husband. He's coming home soon."
[cpg cn=true]


[OnName num="tomoya"]
"What……?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Erika145"]
[OnName num="erika"]
"He's coming back after he finishes his post."
[cpg cn=true]


[OnName num="tomoya"]
"Oh….then that means….."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Erika146"]
[OnName num="erika"]
"I feel guilty for starting all of this..."
[cpg cn=true]


Guilt. It was too late for guilt.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="sErika010"]
[OnName num="erika"]
"I'm willing to continue this relationship. So……"
[cpg cn=true]


I don't want to be her second choice.
[cpg]


[OnName num="tomoya"]
"That's not enough for me, Erika!"
[cpg cn=true]


;//========================================
;//●ＣＧエロ（キスをする二人）ev_20
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：昼
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sErika011"]
[OnName num="erika"]
"Hey……!"
[cpg cn=true]


She tries to reject me but I let the moment take over.
[cpg]

I forcefully press my lips against hers. But……
[cpg]

There's nothing I can do from here. I can't think of anything I can do.
[cpg]

[VOICE f="sErika012"]
[OnName num="erika"]
"......Let go."
[cpg cn=true]


;//移植のためシーンをカットしています

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[window target=false]
[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************


[OnName num="tomoya"]
"……Is your husband coming home soon"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Erika165"]
[OnName num="erika"]
"Yes……he will be home soon."
[cpg cn=true]


[OnName num="tomoya"]
"I will make you mine and mine alone."
[cpg cn=true]


I can't allow her to belong to someone else. I tell her so.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Erika166"]
[OnName num="erika"]
"But I'm……l……belong to him."
[cpg cn=true]


Erika insists.
[cpg]


It gets on my nerves. But I didn't dare say anything.
[cpg]


Someday. Someday, I'm going to make her mine. With that thought in mind, I walked away.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The next day. I had set my goal on someone else.
[cpg]


;//ヒロインに視点切り替わり


[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************


[SE f="se003"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=2000]


The doorbell rings. Each time it rang, I would feel hopeful.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sachie136"]
[OnName num="sachie"]
"Yes……Oh, Tomoya."
[cpg cn=true]


 I should not wear my heart on my sleeve. I knew that, but I was longing for it.
[cpg]


;//========================================
;//●ＣＧエロ（主人公と対面して、堪えられない感じのヒロイン）ev_21
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：昼
;//========================================
;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_21_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="tomoya"]
"…… You must have been lonely."
[cpg cn=true]


I was like a dog with a treat dangling in front of it.
[cpg]

[VOICE f="sSachie015"]
[OnName num="sachie"]
"Yes……very much."
[cpg cn=true]


If I lose control over my feelings, what will happen to me? The family I had might fall apart.
[cpg]

Despite this, I felt a fire starting to swell inside of me……
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************


My husband approves of my relationship with him. But I was starting to wonder if I was getting too attached.
[cpg]

I don't know. Time passes without any resolution.
[cpg]

[OnName num="tomoya"]
"Well, I'm going to go home now. I'll come back again."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sSachie016"]
[OnName num="sachie"]
"……Yes."
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『ドア閉まる』

;//ブラックアウト
;//主人公に視点切り替わり

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I have a feeling. The situation is changing.
[cpg]


Erika's husband is coming home. Mihane and Sachie are falling for me.
[cpg]


It's time to decide what to do with whom.
[cpg]


Of course, it would be best if I could make them all fall for me. But that's not going to happen.
[cpg]


I had to target one of them.
[cpg]


;//■選択肢
[switch]
[case "Erika"]
	[swap]
	[jump target="*select05_1"]
[case "Mihane"]
	[swap]
	[jump target="*select05_2"]
[case "Sachie"]
	[swap]
	[jump target="*select05_3"]
[endswitch]

1. Erika
2. Mihane
3. Sachie


;//※候補となっているヒロインから選択
;//※ルート分岐。選んだヒロインのルートへと進む
;//※誰も候補になってない場合、ヒロイン１のルートに固定

*select05_1|Making them mine
[jump storage="ep006.ks" target="*start"]

*select05_2|Making them mine
[jump storage="ep007.ks" target="*start"]

*select05_3|Making them mine
[jump storage="ep008.ks" target="*start"]


