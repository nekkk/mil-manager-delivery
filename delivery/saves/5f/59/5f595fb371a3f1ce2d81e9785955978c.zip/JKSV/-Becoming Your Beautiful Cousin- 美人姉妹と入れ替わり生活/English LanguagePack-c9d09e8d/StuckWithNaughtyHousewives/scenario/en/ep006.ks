
;//==============================
;//１、絵梨香

*start|I want to make Erika mine.

*select05_1|I want to make Erika mine.

[SCENE id=6]

I wanted to make Erika mine.
[cpg]


I want to sleep with her. I want to take her from her husband and make her completely mine.
[cpg]


Once I made up my mind, I was ready to take action.
[cpg]


;//移植のためシーンをカットしています
;//移植のためシーンをカットしています


;#################################################
*Ep006|I want to make Erika mine.
;#################################################


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


I was still going to classes, but I spent most of my time thinking about how I could make Erika mine.
[cpg]


[OnName num="woman_A"]
"What's up with that guy, he's smiling. While looking down……"
[cpg cn=true]


[OnName num="woman_B"]
"Oh wow, he's so creepy."
[cpg cn=true]


I didn't care if people around me thought I was creepy.
[cpg]


I had a clear purpose. I'm not like the other guys.
[cpg]


I had erased the memory of being dumped before.
[cpg]


But that didn't mean I was going to waste my time with club activities. I didn't have time to waste.
[cpg]


I wanted to make Erika mine.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


When I returned home, I found that my order had arrived.
[cpg]


It was an aphrodisiac that I had bought from a shady online website. It was supposed to be pretty strong.
[cpg]


I picked it up and went to Erika.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="sErika013"]
[OnName num="erika"]
"……My husband will be home any minute now."
[cpg cn=true]


[OnName num="tomoya"]
"We have about three hours or so. I checked."
[cpg cn=true]


Her husband had been back for some time now.
[cpg]


But I'd already checked his daily routine.
[cpg]


He wouldn't be back for a bit. I decided to threaten Erika.
[cpg]


[OnName num="tomoya"]
"You will obey me, won't you? I don't want your husband to know about what we've been doing, do you?"
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="sErika014"]
[OnName num="erika"]
"……I guess I don't have a choice."
[cpg cn=true]


I secretly put the aphrodisiac in her drink.
[cpg]

I don't know if it actually worked and even if it did, there was no guarantee it would change the way she felt about me.
[cpg]

But……if I kept using it, she might feel a thrill every time she sees me.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト
;//ヒロインに視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************


......Something's changed.
[cpg]

;//========================================
;//●ＣＧエロ（夫と電話するヒロイン。足は普通に寝ている状態にしてください）ev_25
;//人物１：ヒロイン１
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_25_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

I started to feel nervous every time I saw him.
[cpg]

The feeling inside me is so strong that I can't even control myself…….
[cpg]

[VOICE f="sErika015"]
[OnName num="erika"]
"Hm? Oh, I'm sorry. I was just thinking about something."
[cpg cn=true]


Even though I'm talking to my husband, I'm having trouble focusing on him.
[cpg]

That's how much I……
[cpg]


;//主人公に視点切り替わり
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


The days pass by. It didn't take long for her to get pregnant.
[cpg]


Her husband seemed surprised, but he didn't seem to notice my presence.
[cpg]


I don't know the truth. But if I had to guess, I would say it was mine.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


Erika and I are strangers to each other once we leave the room. Even if we see each other, we never say hello.
[cpg]


;//========================================
;//●ＣＧ非エロ（お腹を膨らませたヒロインが旦那と一緒に歩く。手を繋いでいるがどこか上の空な表情）ev_26
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン１の夫
;//服装２：私服
;//場所　：街
;//時間　：夕方
;//備考　：ヒロインは妊娠六ヶ月程度
;//========================================


;**【ＣＧ】 ev_26_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]


Even when we pass each other, we don't talk.
[cpg]


[OnName num="erika_husband"]
"So, my colleague said…… Hey, Erika?"
[cpg cn=true]


[VOICE f="Erika246"]
[OnName num="erika"]
"Huh? Oh, what was it?"
[cpg cn=true]


[OnName num="erika_husband"]
"Are you all right these days? You seem to be in a daze a lot."
[cpg cn=true]


;**【ＣＧ】 ev_26_a ***********************
[CG id=10 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="Erika247"]
[OnName num="erika"]
"It's nothing."
[cpg cn=true]


I passed her with a grin on my face.
[cpg]


I was going to be deeply involved in her life from now on.
[cpg]


I had left too deep of a mark on her.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


More time passed.
[cpg]


I graduated from college and Erika gave birth to a child.
[cpg]


Even so, I still went to see Erika from time to time.
[cpg]


So that she would not forget me. No……
[cpg]


I know she can't forget me no matter what, but just in case.
[cpg]



[window target=false]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************


[OnName num="tomoya"]
"…… It's been a long time, hasn't it Erika?"
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Erika248"]
[OnName num="erika"]
"Yes……"
[cpg cn=true]


A baby, about three months old. It is sleeping.
[cpg]


I smiled when I saw that it had my resemblance.
[cpg]


Her life is intertwined with mine. I lay quietly, just under the surface.
[cpg]


;//ＥＮＤ：ヒロイン１ルート

[SCENE id=12]

[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

