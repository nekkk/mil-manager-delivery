
*start|A Dream Come True

;#################################################
*Ep003|A Dream Come True
;#################################################

[SCENE id=3]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


The morning comes and with it, hunger. I head out to buy food again.
[cpg]


;//========================================
;//●ＣＧ非エロ（三人がマンション前で話し込んでいる。ここまでイベントＣＧが無かったヒロイン３が一番目立つ感じ）ev_03
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：ヒロイン１
;//服装２：私服
;//人物３：ヒロイン２
;//服装３：私服
;//場所　：マンション前
;//時間　：朝
;//========================================
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BGM f="bg_ad"]
[WAIT time=100]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

……I seem to bump into these women often lately.
[cpg]


I try to listen in on their conversation as they gossip.
[cpg]


[VOICE f="Sachie010"]
[OnName num="sachie"]
"What about you, Erika? Your husband is living in a different city for work, right?"
[cpg cn=true]


Erika was the first woman I'd run into. The one who worried about my missing school.
[cpg]


;//ここから絵梨香の名前を隠さないでください


[VOICE f="Erika003"]
[OnName num="erika"]
"Oh, but Mihane, your husband manages to make it home every day, doesn't he? I'm a little envious."
[cpg cn=true]


That would make the last one's name Mihane……All of them had beautiful names.
[cpg]


;//ここから美羽の名前を隠さないでください


[VOICE f="Mihane005"]
[OnName num="mihane"]
"Not really……there are many days he doesn't come home."
[cpg cn=true]


[VOICE f="Sachie011"]
[OnName num="sachie"]
"Oh, what about Tomoya? Something about him makes me want to mother him."
[cpg cn=true]


I jumped a little upon hearing my name. Were they talking about me?
[cpg]


[VOICE f="Erika004"]
[OnName num="erika"]
"Yes, I suppose he's cute, isn't he?"
[cpg cn=true]


Uncomfortable with listening in any longer, I decided to try to move past them.
[cpg]



[window target=false]
[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



[FACE method="bow_1" pos="2/3"]
[VOICE f="Mihane006"]
[OnName num="mihane"]
"Oh, Tomoya!"
[cpg cn=true]


[OnName num="tomoya"]
"……Hi."
[cpg cn=true]


Although I wanted to walk past them, they noticed me and called me over.
[cpg]


[FACE method="bow_2" pos="3/3"]
[VOICE f="Sachie012"]
[OnName num="sachie"]
"You don't have school again today? Want to come and chat with us?"
[cpg cn=true]


[OnName num="tomoya"]
"……I'm not good at socializing."
[cpg cn=true]


I tried to keep my distance, but to no avail.
[cpg]


[FACE method="shake_7" pos="1/3"]
[VOICE f="Erika005"]
[OnName num="erika"]
"Is that why you refuse to go to school?"
[cpg cn=true]


How did she know so much about me?
[cpg]


[OnName num="tomoya"]
"How do you know that much about me?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mihane007"]
[OnName num="mihane"]
"There's a girl who goes to your university living here too."
[cpg cn=true]


I had no idea. Did she hear stories about me from her?
[cpg]


Anyway, I decided I'd have to try and avoid these people as much as I could.
[cpg]


I went out to buy food as planned. And then……
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


By the time I came back, Erika was all alone.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Erika006"]
[OnName num="erika"]
"Oh, hello. Tomoya."
[cpg cn=true]


[OnName num="tomoya"]
"……Hello."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Erika007"]
[OnName num="erika"]
"You may already know this, but my husband and I are living apart right now. He took an assignment abroad."
[cpg cn=true]


[OnName num="tomoya"]
"Oh, I see……why are you telling me this?"
[cpg cn=true]


Somehow, it feels like an invitation.
[cpg]


I could have refused, but I fell for it.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Erika008"]
[OnName num="erika"]
"Do you want to come to my room? There are some things I want to talk to you about."
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************


What was there to say?
[cpg]


I entered her home.
[cpg]


Her husband is away on an assignment for work. So she lives here alone right now.
[cpg]


I felt like I could smell a woman's scent. It was soft and it smelled good……
[cpg]


There was a picture of someone who looked like her husband in her room. So that was him. But I didn't say anything.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Erika009"]
[OnName num="erika"]
"So, where did we leave off?"
[cpg cn=true]


[OnName num="tomoya"]
"I don't think you told me anything...yet."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Erika010"]
[OnName num="erika"]
"Oh, right. I've been alone for a long time."
[cpg cn=true]


[OnName num="tomoya"]
"Okay, but that doesn't mean you should let a complete stranger into your home……"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Erika011"]
[OnName num="erika"]
"You're not a stranger anymore, are you? You're not good at socializing, which is why you can't go to college."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Erika012"]
[OnName num="erika"]
"I think I can teach you a little about how to socialize."
[cpg cn=true]


She had a sweet tone to her voice. Erika's cheeks blush a little.
[cpg]


It really felt like she was trying to seduce me.
[cpg]


It was too much to take in all at once. I wanted to leave.
[cpg]


[OnName num="tomoya"]
"I can't do this......I barely even know you."
[cpg cn=true]


[OnName num="tomoya"]
"Besides, you're already married, this is wrong."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Erika013"]
[OnName num="erika"]
"I know...it's wrong, but..."
[cpg cn=true]


[OnName num="tomoya"]
"If you agree with me, then don't do this."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Erika014"]
[OnName num="erika"]
"Just give it some thought. I'll be waiting for you."
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


……In all honesty, I felt so lonely.
[cpg]


If being with her could heal that, it would be worth it. Maybe I should have taken her up on her offer.
[cpg]


But I couldn't help but hesitate.
[cpg]



;//ブラックアウト
;//ヒロインに視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************

[FACE method="shake_4" pos="2/3"]
......I think I was a little too hasty. 
[cpg]


My name is Erika Naoi and I have been lonely for a long time.
[cpg]


Tomoya is always at home. I'm always at home. I didn't think there'd be any reason for him to hesitate.
[cpg]


But it seems he's a little timid and perhaps the age difference bothers him.
[cpg]


[SE f="se003"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=2000]


Maybe this wasn't going to be as simple as I'd hoped. But just as I was thinking that, the doorbell rang.
[cpg]

[FACE method="change_1" pos="2/3"]

Who could it be? I opened the door, hoping it was Tomoya.
[cpg]


[SE f="se000"]
;//【ＳＥ】『ドア開く』


;//ブラックアウト
;//主人公に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************


[OnName num="tomoya"]
"Hello……."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Erika015"]
[OnName num="erika"]
"Good evening. Have you already eaten?"
[cpg cn=true]


[OnName num="tomoya"]
"I did, just in case."
[cpg cn=true]


I knocked her door again.
[cpg]


Her husband is working in a different city. That means I could visit her whenever I wanted.
[cpg]


It was clear that she wanted me to come over. I was thinking of taking her up on it.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Erika016"]
[OnName num="erika"]
"……It's late, did you need something? Or are you finally up for it."
[cpg cn=true]


Erika closes the distance between us.
[cpg]


I froze and just sat there.
[cpg]


[OnName num="tomoya"]
"……I've been thinking...about what you said earlier."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sErika001"]
[OnName num="erika"]
"Mmm, I'm glad you reconsidered."
[cpg cn=true]


;//移植のためシーンをカットしています

[OnName num="tomoya"]
"I'm not here to do anything...socially unacceptable."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sErika002"]
[OnName num="erika"]
"I know, you want me to teach you how to socialize, right?"
[cpg cn=true]


;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

We just ended up having a casual conversation.
[cpg]

I'd come into this situation expecting something else to happen.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************


[FACE method="bow_2" pos="2/3"]
[VOICE f="Erika035"]
[OnName num="erika"]
"Well, I hope I'll see you again. Come over whenever you like."
[cpg cn=true]


When she smiled at me, I felt glad that I had come.
[cpg]

[OnName num="tomoya"]
"Thank you……."
[cpg cn=true]


I was kind of embarrassed to say that.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I was in a daze when I returned to my room. I collapsed on the bed and stared at the ceiling.
[cpg]


This is not a normal relationship, I thought again.
[cpg]


There must be some other way to fix my shyness.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


The next day, I went out to buy food in the afternoon.
[cpg]


I'm not the type to buy a lot of food at once. Bento boxes don't keep well, so there's no point in buying a bunch at once.
[cpg]


On my way home, I ran into Mihane. It's a little strange how often I see her these days……
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mihane008"]
[OnName num="mihane"]
"Hello Tomoya."
[cpg cn=true]


[OnName num="tomoya"]
"Hi……how is your husband doing?"
[cpg cn=true]


I had enough confidence to ask her about it. Perhaps yesterday's incident had given me some courage.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mihane009"]
[OnName num="mihane"]
"Well. I only see him early in the morning and late at night……"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Mihane010"]
[OnName num="mihane"]
"I want to support him, but so far I've only been able to cook for him and give him a massage every now and again……"
[cpg cn=true]


Was Mihane like that, too?……No, I was overthinking things.
[cpg]


I can't let my thoughts run wild. But after yesterday's events, I started to hold some faint hope.
[cpg]


[OnName num="tomoya"]
"Well, I'll see you around……"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mihane011"]
[OnName num="mihane"]
"Yes. See you around, Tomoya."
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


Later that night. I was headed to her apartment again.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Erika036"]
[OnName num="erika"]
"I'm glad you came again, Tomoya."
[cpg cn=true]


[OnName num="tomoya"]
"……Yes, I'm here again."
[cpg cn=true]


I found myself at her place again, spurred onward by my loneliness.
[cpg]

We don't really do anything, we just talk……
[cpg]

Still, I was starting to feel somewhat more at ease.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************


[OnName num="tomoya"]
"It's getting late……I should get back."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sErika003"]
[OnName num="erika"]
"Okay. See you again."
[cpg cn=true]


After saying this, she looked awkward for some reason.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Erika054"]
[OnName num="erika"]
"I know, it's wrong...isn't it?"
[cpg cn=true]


[OnName num="tomoya"]
"It's...been a lot of help to me."
[cpg cn=true]


She looked kind of sad.
[cpg]

[OnName num="tomoya"]
"I……."
[cpg cn=true]


I'm here for you if you want to talk. The words were at the tip of my tongue, but I didn't have the courage to say them.
[cpg]

[OnName num="tomoya"]
"I'll come again."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="sErika004"]
[OnName num="erika"]
"I'm looking forward to it."
[cpg cn=true]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I went back to my room, fell asleep, and dreamed about college.
[cpg]


[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（夕方）******************************************************


I kept going back to the day I confessed my feelings to that girl.
[cpg]


I ask her to go out with me. Up to this point, it was the same as in my previous dreams.
[cpg]


But the rest of the dream was a little different.
[cpg]


[OnName num="club_girl"]
"But……Tomoya, you like married women, right?"
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


……What a strange dream.
[cpg]


Do I like married women? It's hard to tell.
[cpg]


I care about Erika. But that's all.
[cpg]


I don't think I like her because she is a married woman……
[cpg]

[jump storage="ep004.ks" target="*start"]

;////////////////////////////////////////////////////////////////////////
