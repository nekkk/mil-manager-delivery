
;//==============================
;//全てのヒロインが候補になっている場合

*start|Accepting the Current Relationship

*get_halem|Accepting the Current Relationship

[SCENE id=10]

[OnName num="tomoya"]
"……If you need me to step up, then I'm willing. As long as you're okay with me."
[cpg cn=true]


[FACE method="change_2" pos="1/3"]
[VOICE f="Erika286"]
[OnName num="erika"]
"I trusted you, but it's reassuring to hear you put it into words."
[cpg cn=true]


[FACE method="change_2" pos="3/3"]
[VOICE f="sSachie026"]
[OnName num="sachie"]
"I agree. Why don't all three of us go up together?"
[cpg cn=true]


The three of us? What was she talking about?
[cpg]


[FACE method="change_6" pos="3/3"]
[VOICE f="Sachie298"]
[OnName num="sachie"]
"Let's go to your room, Tomoya."
[cpg cn=true]


[OnName num="tomoya"]
"Wait, wait……"
[cpg cn=true]

;#################################################
*Ep010|Accepting the Current Relationship
;#################################################



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="3/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


I found myself in a situation most could only dream of.
[cpg]


One man and three women. And all of them are married women.
[cpg]


Was I about to have to take on all three of them at the same time?
[cpg]

;//========================================
;//●ＣＧエロ（ヒロイン２はヒロイン１の方を向いているように変えられたら変えてください）ev_35
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：ヒロイン１
;//服装２：私服
;//人物３：主人公
;//服装３：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMihane011"]
[OnName num="mihane"]
"Erika, did you lose weight again?"
[cpg cn=true]


[VOICE f="sErika020"]
[OnName num="erika"]
"Really……? I think it's the same as before."
[cpg cn=true]


It seemed they were more interested in each other than me...for now.
[cpg]

[VOICE f="sMihane012"]
[OnName num="mihane"]
"I got a little fat…… I envy you."
[cpg cn=true]


She says and touches Erika's skin. I'm not sure if I was allowed to watch.
[cpg]


;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


A little time passes. Sachie's husband was probably coming home soon.
[cpg]


I don't know about Mihane's husband. I heard he is always late.
[cpg]


[OnName num="tomoya"]
"Are you okay for time?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sachie300"]
[OnName num="sachie"]
"Are you worried about me? It's okay, don't worry about it."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Sachie301"]
[OnName num="sachie"]
"I'll take responsibility for what I do. I'm not doing anything I'll regret."
[cpg cn=true]


Sachie seemed very determined.
[cpg]


She was fundamentally different from me, because I just went with the flow.
[cpg]


;//========================================
;//●ＣＧエロ（ヒロイン３とヒロイン１、二人から同時に迫られる）ev_36
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：ヒロイン１
;//服装２：私服
;//人物３：主人公
;//服装３：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

[VOICE f="sSachie027"]
[OnName num="sachie"]
"Instead of worrying about me……you should try being more honest with yourself."
[cpg cn=true]


Easier said than done, it was embarrassing.
[cpg]

Plus, I felt guilty.
[cpg]

[VOICE f="sErika021"]
[OnName num="erika"]
"You're still hesitating? It's too late to go back now."
[cpg cn=true]


She had a point, but I wasn't able to just let it go and enjoy the moment like they did.
[cpg]


;//ブラックアウト


It was getting late when they finally left.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I go to sleep, but something's missing. After being with them for so long, my room feels empty.
[cpg]


Things were going well for me.
[cpg]


I'd more or less gotten over my fear of women and I felt confident enough to return to society.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


Morning came. I have to go to Uni.
[cpg]


I got up and brushed my teeth…….
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


It was uncomfortable at first, but I gradually got used to it.
[cpg]


Another day of lectures is over. I was about to leave the campus when……
[cpg]


[OnName num="club_girl"]
"Oh, um……Mikado."
[cpg cn=true]


[OnName num="tomoya"]
"Oh……"
[cpg cn=true]


It was the girl who dumped me. She came up to me.
[cpg]


The people around us seemed surprised. She starts to talk to me.
[cpg]


[OnName num="club_girl"]
"About before......I'm really sorry."
[cpg cn=true]


[OnName num="tomoya"]
"Oh, yeah. Right."
[cpg cn=true]


Her apology meant little to me. It's not like I'd get my credits back, but I didn't bother confronting her about it.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


It was a strange way of apologizing, I though as I walked back to my house.
[cpg]


I found the three of them were having another get together. I wondered what was on the agenda today.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[VOICE f="sSachie028"]
[OnName num="sachie"]
"……Things aren't going well for me either. The other day, my husband looked like he was going to hit me."
[cpg cn=true]


[FACE method="shake_7" pos="1/3"]
[VOICE f="Erika305"]
[OnName num="erika"]
"Is that so……? Are you all right?"
[cpg cn=true]


[FACE method="bow_2" pos="3/3"]
[VOICE f="sSachie029"]
[OnName num="sachie"]
"I'm fine. I think it all stems from love with him."
[cpg cn=true]


I couldn't stop myself from eavesdropping…… Sachie said she was beaten up?
[cpg]


[OnName num="tomoya"]
"Wait a minute. Sachie, that's really bad..."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mihane280"]
[OnName num="mihane"]
"I guess so. It seems I'm not the only one who is having a hard time."
[cpg cn=true]


[FACE method="bow_1" pos="3/3"]
[VOICE f="Sachie316"]
[OnName num="sachie"]
"My husband knows everything. He knows everything about me and Tomoya."
[cpg cn=true]


[OnName num="tomoya"]
"Maybe you should try to hide it a little."
[cpg cn=true]


[FACE method="shake_2" pos="3/3"]
[VOICE f="sSachie030"]
[OnName num="sachie"]
"My husband tells me not to."
[cpg cn=true]


I didn't think she should take those words at face value…… but I couldn't say anything.
[cpg]

[FACE method="bow_1" pos="3/3"]
[VOICE f="sSachie031"]
[OnName num="sachie"]
"More importantly, it's my turn today alright?"
[cpg cn=true]


[OnName num="tomoya"]
"But……I'm worried about you."
[cpg cn=true]


[FACE method="shake_2" pos="3/3"]
[VOICE f="sSachie032"]
[OnName num="sachie"]
"I'm not afraid."
[cpg cn=true]


She was braver than I was. I just went with the flow.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[FACE method="bow_1" pos="2/3"]
[VOICE f="sSachie033"]
[OnName num="sachie"]
"It's been a while since it was just the two of us."
[cpg cn=true]


[OnName num="tomoya"]
"Now that you mention it......"
[cpg cn=true]


I'm suddenly aware of the fact that I'm alone with her.
[cpg]

But she didn't seem to be nervous at all.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト

And so, after spending some time alone together.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[OnName num="tomoya"]
"Shouldn't you be getting back...?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sSachie034"]
[OnName num="sachie"]
"I know……I'd rather spend more time with you, but I guess I need to get back."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sachie342"]
[OnName num="sachie"]
"I'll see you next time."
[cpg cn=true]


[OnName num="tomoya"]
"Yes……Just be careful."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sSachie035"]
[OnName num="sachie"]
"Be careful? Oh, you mean my husband? Don't worry about it."
[cpg cn=true]


I can't help but worry but she seems confident for some reason.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Evening turns into night. I still don't feel like cooking for myself, but I'm motivated enough to cook rice.
[cpg]


So today I'm having rice with side dishes that I bought at the supermarket.
[cpg]


It's been a while since I've had a proper dinner. I decided to prepare for tomorrow.
[cpg]


You never know what might happen on campus……
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


In the morning. I walk towards the university.
[cpg]


I was glad that it was within walking distance. I remembered seeing other students living nearby.
[cpg]


I make my way to class thinking about how bored I'd be.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（昼）******************************************************


The lecture ends. The girl from yesterday approaches me again.
[cpg]


She was waiting for me at the door this time.
[cpg]


[OnName num="club_girl"]
"……Hey, Mikado......can we talk?"
[cpg cn=true]


[OnName num="tomoya"]
"What? Did you come here to apologize again?"
[cpg cn=true]


[OnName num="club_girl"]
"No, I wanted to tell you something. It's important."
[cpg cn=true]


What now?
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


We walked together for a bit. She stops in the middle of an empty hallway. She confesses her feelings to me.
[cpg]


[OnName num="club_girl"]
"So, um…… What do you think?"
[cpg cn=true]


[OnName num="tomoya"]
"……Uhhh…"
[cpg cn=true]


She was incredibly cute. I mean, I'd fallen in love with her once already. Plus, our ages were close.
[cpg]


[OnName num="tomoya"]
"I need some time to think……"
[cpg cn=true]


But I already had a harem.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


I went home a little early while it was still bright outside.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Erika306"]
[OnName num="erika"]
"......You look gloomy, what happened?"
[cpg cn=true]


Gloomy? What was there to be gloomy about? Mihane came closer.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Mihane281"]
[OnName num="mihane"]
"You look happy Tomoya, what's up?"
[cpg cn=true]


I looked happy now? If only I had a mirror. I couldn't imagine what kind of expression I had on my face.
[cpg]


But I guess it was clear to them that I was feeling both happy and conflicted.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_04_3.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[VOICE f="Sachie344"]
[OnName num="sachie"]
"Oh, everybody's here. Was I the only one left out?"
[cpg cn=true]


[OnName num="tomoya"]
"Sorry……"
[cpg cn=true]


[FACE method="bow_7" pos="1/3"]
[VOICE f="Erika317"]
[OnName num="erika"]
"I'm sorry, it's just that Tomoya looked a little down."
[cpg cn=true]


[FACE method="bow_7" pos="3/3"]
[VOICE f="Sachie345"]
[OnName num="sachie"]
"Is that so? What happened?"
[cpg cn=true]


I had to tell them everything. Maybe they'd come up with a good idea.
[cpg]


[OnName num="tomoya"]
"……Umm……"
[cpg cn=true]


[OnName num="tomoya"]
"Well, a girl from college confessed her feelings to me. She's the one who dumped me before."
[cpg cn=true]


What will they say? Would they tell me to give up on her?
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mihane293"]
[OnName num="mihane"]
"Oh my, it looks like your transition back into society is going very well."
[cpg cn=true]


[OnName num="tomoya"]
"Huh……?"
[cpg cn=true]


[FACE method="bow_2" pos="1/3"]
[VOICE f="Erika318"]
[OnName num="erika"]
"You should go out with her. It's healthier that way."
[cpg cn=true]


[OnName num="tomoya"]
"Are you sure……?"
[cpg cn=true]


[FACE method="bow_7" pos="3/3"]
[VOICE f="Sachie346"]
[OnName num="sachie"]
"Well, it's not like we'd be able to stay with you forever."
[cpg cn=true]


In that case, I knew what I had to do.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The next day, on campus.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


[OnName num="club_girl"]
"Mikado, did you make a decision?"
[cpg cn=true]


[OnName num="tomoya"]
"……Call me Tomoya."
[cpg cn=true]


[OnName num="club_girl"]
"Then……."
[cpg cn=true]


[OnName num="tomoya"]
"Yeah, let's go out. I mean, I confessed to you once already."
[cpg cn=true]


She takes my hand, tears welling up in her eyes.
[cpg]


[OnName num="club_girl"]
"I'm so glad….. Tomoya."
[cpg cn=true]


I wasn't afraid of her anymore. The married women in my life had trained me well.
[cpg]


It was worth it, after all. As I thought that……
[cpg]


I hugged her. I guess I'm graduating from the harem.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（夕方）******************************************************


My girlfriend turned out to be pretty clingy. Wherever we go, she's always hanging off of me.
[cpg]


[OnName num="tomoya_lover"]
"Eheheh…...I won't let go of you anymore, Tomoya."
[cpg cn=true]


I felt some lingering resentment towards her.
[cpg]


After all, she was the one who pushed me away and drove me to become a shut-in.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


I don't know if it was part of her androphobia, but her mood swings tended to be extreme.
[cpg]


[OnName num="tomoya_lover"]
"Were you looking at that girl?"
[cpg cn=true]


[OnName num="tomoya"]
"Yeah? Is that a problem?"
[cpg cn=true]


[OnName num="tomoya_lover"]
"Of course it is. We're dating so you have to look at me and me alone."
[cpg cn=true]


It sounded absurd but I went along with her.
[cpg]


After I started dating her, I came to realized a lot of things……
[cpg]


I couldn't help but compare her to the married women I'd been involved with.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Honestly, it's a little hard to spend time with her. I realize that makes me sound like a scumbag, but……
[cpg]

There's no other way to describe it. She was fundamentally different from the other women in my life.
[cpg]

Maybe I'd gotten too comfortable with them.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


As a result we broke up after less than a month.
[cpg]


It was even more difficult to go to University than before, but I didn't care anymore.
[cpg]


I have a harem of married women…… and that's enough. No, it was better than that. It was an ideal situation.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I finished my classes and then headed back home. The door was left unlocked.
[cpg]


I could sense someone was inside. It must have been one of them.
[cpg]


;//========================================
;//●ＣＧ非エロ（机を囲んで座っているヒロイン三人。三人話しているところから、主人公に気づき主人公の方を見る）ev_39
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//人物３：ヒロイン３
;//服装３：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

[BGM f="bg_ad"]
;**【ＣＧ】 ev_39_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Erika319"]
[OnName num="erika"]
"So, what ended up happening regarding the divorce?"
[cpg cn=true]


[VOICE f="Mihane294"]
[OnName num="mihane"]
"Nothing has happened since then. He's just all talk you know."
[cpg cn=true]


[VOICE f="Sachie347"]
[OnName num="sachie"]
"I see. Well, that's good."
[cpg cn=true]


[OnName num="tomoya"]
"…… I'm home."
[cpg cn=true]


[VOICE f="Erika320"]
[OnName num="erika"]
"Welcome back. Should we get started?"
[cpg cn=true]


[OnName num="tomoya"]
"Get started with what? I don't recall letting you in..."
[cpg cn=true]


[VOICE f="Mihane295"]
[OnName num="mihane"]
"Oh, please. We're all here for the same thing."
[cpg cn=true]


She had a point, but was this the right choice?
[cpg]


;//ブラックアウト
;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


My return to society has been fulfilled, but I still want this harem to continue.
[cpg]


It's what I wanted. It's what we wanted.
[cpg]


I'd be happy if we could keep this relationship going for a little while longer.
[cpg]


[OnName num="tomoya"]
"......How long can we keep doing this?"
[cpg cn=true]


[FACE method="shake_7" pos="1/3"]
[VOICE f="Erika328"]
[OnName num="erika"]
"What's wrong, all of a sudden?"
[cpg cn=true]


[OnName num="tomoya"]
"Because this relationship will end once I graduate..."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Mihane305"]
[OnName num="mihane"]
"That's not true, we can make it last as long as you want to."
[cpg cn=true]


……True or not, those were the words I'd wanted to hear.
[cpg]


[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


I'd given up on dating girls my own age.
[cpg]


I wanted to be with these women.
[cpg]


I wanted to be with women who would spoil me forever.
[cpg]


After I graduate from college, I had to consider finding a job nearby so I could stay in this apartment...…
[cpg]


I thought about my options as the evening turned into night.
[cpg]


;//ＥＮＤ：ハーレムエンド１
[SCENE id=15]

[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

