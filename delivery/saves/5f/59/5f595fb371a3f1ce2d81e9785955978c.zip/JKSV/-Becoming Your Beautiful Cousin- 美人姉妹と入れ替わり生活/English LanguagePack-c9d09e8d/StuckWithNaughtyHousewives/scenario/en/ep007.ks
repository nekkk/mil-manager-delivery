
;//==============================
;//２、美羽

*start|Making Mihane mine

*select05_2|Making Mihane mine



[SCENE id=7]


I wanted to make Mihane mine.
[cpg]


She said she can't choose between me and her husband.
[cpg]


I will make her choose. With this thought, I went to sleep.
[cpg]

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2500]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
;//ブラックアウト


The next day. After I went to the university, Mihane visited me at home.
[cpg]

;#################################################
*Ep007|Making Mihane mine
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


;//ヒロインに視点切り替わり


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mihane147"]
[OnName num="mihane"]
"……I'm here, again."
[cpg cn=true]


[OnName num="tomoya"]
"Are you sure? You come here so often. I think you're breaking the rule."
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="sMihane006"]
[OnName num="mihane"]
"It's okay. I don't care what anyone thinks."
[cpg cn=true]


I wanted him. My husband wouldn't pay attention to me.
[cpg]



[FACE method="bow_6" pos="2/3"]
[VOICE f="sMihane007"]
[OnName num="mihane"]
"Please, Tomoya……I'm so lonely."
[cpg cn=true]


I found myself wanting love. I needed to feel it all of the time. That's probably why I started to love two people at the same time.
[cpg]


There is a part of me that wants to push myself to the edge.
[cpg]


;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
;//主人公に視点切り替わり
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I talked with Mihane for a while. Her husband wouldn't be back for a while.
[cpg]

I'd decided that I wanted to make Mihane mine.
[cpg]

I will make her say that I am the only one for her. That she likes me more. That I'm better.
[cpg]

;//========================================
;//●ＣＧエロ（主人公を誘うヒロイン）ev_47
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_47_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sMihane008"]
[OnName num="mihane"]
"……I feel safe with you."
[cpg cn=true]


I don't know if these words are coming from her heart or not.
[cpg]

But it didn't matter, even if she was just trying to get me in a good mood.
[cpg]

[OnName num="tomoya"]
"Yeah. Me too."
[cpg cn=true]


It means that I have become an indispensable part of her life.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


By the time I left home, the sun had set.
[cpg]


[OnName num="tomoya"]
"Is your husband not coming home yet?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mihane191"]
[OnName num="mihane"]
"Not for a bit.……"
[cpg cn=true]


[OnName num="tomoya"]
"I see. You must be lonely."
[cpg cn=true]


I saw Mihane off to her house while having such a conversation.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

The next day, in the after noon. The other two found out that Mihane had broken the rules again.
[cpg]

The three of them had gathered together.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sErika016"]
[OnName num="erika"]
"So what are we going to do? How do we punish her……?"
[cpg cn=true]


[FACE method="bow_7" pos="3/3"]
[VOICE f="sSachie017"]
[OnName num="sachie"]
"I feel like she's going to be happy no matter what we do."
[cpg cn=true]


She was probably right.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

In the end, the two of them scolded her, but I don't think it was going to deter her in the slightest.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[FACE method="shake_7" pos="4/5"]
[VOICE f="Sachie166"]
[OnName num="sachie"]
"I hope she's learned her lesson...but somehow, I doubt it."
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Erika253"]
[OnName num="erika"]
"Yes, she seemed to enjoy it, if anything."
[cpg cn=true]


I agreed. We all know what she's doing. 
[cpg]

[free time=500]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mihane210"]
[OnName num="mihane"]
"……Really, I'm sorry…… It won't happen again."
[cpg cn=true]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Sachie167"]
[OnName num="sachie"]
"I don't know. Maybe we don't need that arrangement anymore."
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Erika254"]
[OnName num="erika"]
"Maybe so…….What should we do?"
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


The solution was put ultimately on hold, and we disbanded for the day.
[cpg]


During that time, all I could think about was her.
[cpg]


I was thinking about her all the time. It was almost like I was in love.
[cpg]


If that was the case, then I needed her to feel the same way. With that thought, I was about to reach the end of the staircase.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夜）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mihane211"]
[OnName num="mihane"]
"What's going on……? What are you doing at this hour?"
[cpg cn=true]


[OnName num="tomoya"]
"What do you mean?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mihane212"]
[OnName num="mihane"]
"We can't do this......he'll be home soon."
[cpg cn=true]


Of course I knew that. Why else would I show up at this time?
[cpg]


[OnName num="tomoya"]
"I know that."
[cpg cn=true]


;//========================================
;//●ＣＧエロ（主人公に抱きしめられるヒロイン）ev_49
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_49_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

I closed the distance between us, knowing her husband would be home any minute now.
[cpg]

[VOICE f="sMihane009"]
[OnName num="mihane"]
"Don't……! If he sees us…"
[cpg cn=true]


If he comes back, then fine. Then our relationship would be stronger.
[cpg]

I really believed that at the time.
[cpg]

[OnName num="mihane_husband"]
"……You……"
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]

And there he was. Mihane turned pale.
[cpg]


;//移植のためシーンをカットしています

[FACE method="shock_4" pos="2/3"]
[VOICE f="Mihane232"]
[OnName num="mihane"]
"It's not what it looks like! He forced himself on me......!"
[cpg cn=true]


[OnName num="mihane_husband"]
"……What!? How……?"
[cpg cn=true]


[OnName num="tomoya"]
"There's no need to lie, Mihane. You're always the one coming to my house."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mihane233"]
[OnName num="mihane"]
"Tomoya, don't say anything more……."
[cpg cn=true]


Mihane is crying and desperately clinging on to him. But I wonder if he can overcome this.
[cpg]


[OnName num="mihane_husband"]
"I'm……going to stay somewhere else tonight."
[cpg cn=true]


He seemed pretty upset about it. Of course, so is Mihane.
[cpg]


But he's so confused that he can't seem to stay here.
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Mihane234"]
[OnName num="mihane"]
"Don't go! Where are you going?"
[cpg cn=true]


Mihane's voice was tearing up.
[cpg]


[OnName num="mihane_husband"]
"That's none of your business!"
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And then he pushed Mihane away.
[cpg]


I was finally able to get Mihane all to myself, or so I thought……
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


Mihane clammed up. She stopped letting me into her house.
[cpg]


I thought that was fine and waited for the right moment. However.
[cpg]


On a holiday the following week, I soon realized that what I had done was a mistake.
[cpg]


[OnName num="tomoya"]
"……What!?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sErika017"]
[OnName num="erika"]
"It's true. Mihane's husband was hospitalized for attempted suicide."
[cpg cn=true]


[OnName num="tomoya"]
"Then, Mihane is……"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Erika256"]
[OnName num="erika"]
"She's long gone. I think she's living with her parents right now."
[cpg cn=true]


[OnName num="tomoya"]
"Do you know where…… Mihane's parents live?"
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Erika257"]
[OnName num="erika"]
"I know, but I'm not sure if I should tell you….."
[cpg cn=true]


……I've made a terrible mistake.
[cpg]


I can't change the past. The problem was no longer about whether I could or could not keep Mihane to myself.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


After that, I repeatedly tried to persuade Erika.
[cpg]


I wanted to know where Mihane so I asked over and over again.
[cpg]


It took time, but she eventually relented.
[cpg]


The situation was about as bad as it could get.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


But still I made my way to Mihane's parents' house. My hand trembled as I pressed the doorbell.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=2000]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Mihane235"]
[OnName num="mihane"]
"……Tomoya."
[cpg cn=true]


[OnName num="tomoya"]
"Mihane……"
[cpg cn=true]


I didn't know what to say. I had come prepared, but seeing her blew it all away.
[cpg]


Her eyes had lost their light. I'd stolen everything from her.
[cpg]


[OnName num="tomoya"]
"……Why did you run away? If your husband wasn't in the picture, you could have loved me instead."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mihane236"]
[OnName num="mihane"]
"I don't about know that anymore…….  "
[cpg cn=true]


She wouldn't accept me, but she wasn't rejecting me.
[cpg]


[OnName num="tomoya"]
"……."
[cpg cn=true]


I couldn't say anything beyond that.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I went home. I thought there was nothing I could do.
[cpg]


But I was wrong. I still love Mihane. I can't keep her unhappy.
[cpg]


It was my turn to bring Mihane back out into the world.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sachie168"]
[OnName num="sachie"]
"......It sounds a lot worse than what I'd heard. Are you doing okay Tomoya?"
[cpg cn=true]


[OnName num="tomoya"]
"I'm fine."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Sachie169"]
[OnName num="sachie"]
"If it gets too hard, you can take it all out on me."
[cpg cn=true]


[OnName num="tomoya"]
"Thank you. But I'm only focused on Mihane."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Sachie170"]
[OnName num="sachie"]
"……I see."
[cpg cn=true]


Maybe Sachie really meant what she said.
[cpg]


But I couldn't run away to her while Mihane was alone and hurting.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



The second time I visited her, Mihane answered the door.
[cpg]


I told her, "I'm here to tell you that I'm starting the association to support Mihane's reintegration into society."
[cpg]


I told her that I would keep coming as many times as I had to until I got her out of here.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mihane237"]
[OnName num="mihane"]
"I can't……It's all over for me."
[cpg cn=true]


[OnName num="tomoya"]
"It's not over yet. Even if it was, we can start all over again."
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Mihane238"]
[OnName num="mihane"]
"Don't say that……. I can't do it anymore."
[cpg cn=true]


She breaks down crying, but I felt like I still had a chance.
[cpg]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（昼）******************************************************


I'd stopped being a shut-in.
[cpg]


I had to graduate from college and get a job as soon as possible.
[cpg]


Mihane had saved me. Now it was my turn to save her.
[cpg]


[OnName num="tomoya"]
"Please wait for me, Mihane……"
[cpg cn=true]


I muttered to myself. I don't care if the people around me feel creeped out or not.
[cpg]


All I can see is her. I think she feels the same way about me.
[cpg]


Then we should be able to face each other.
[cpg]


…… I can't give up on this love.
[cpg]


;//ＥＮＤ：ヒロイン２ルート

[SCENE id=13]

[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

