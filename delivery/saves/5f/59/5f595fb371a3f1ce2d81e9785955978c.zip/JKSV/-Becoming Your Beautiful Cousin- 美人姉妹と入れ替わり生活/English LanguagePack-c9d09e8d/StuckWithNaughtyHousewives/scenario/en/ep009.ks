

;//==============================
;//２、このままでいい

*start|Satisfied with the Present

*select04_2|Satisfied with the Present

[SCENE id=9]

I had no intention of stealing them away from their husbands.
[cpg]


I was satisfied with the way things are. Wanting more would be greedy.
[cpg]


I had to figure out a way to keep this relationship going as long as possible.
[cpg]


;//ブラックアウト
[BG f="b_05_4.ui" time=1000]
[WAIT time=1000]


I have to go to college tomorrow. With this in mind, time passes, night falls, and I fall asleep.
[cpg]


;#################################################
*Ep009|Satisfied with the Present
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


I didn't trust women.
[cpg]


All of this started with one girl's androphobia. Ironic, since I was one bad experience from becoming a gynophobe myself.
[cpg]


But I had a feeling that I could get over it...with some help.
[cpg]


After all, I had three beautiful women to support me.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


When I returned to my room, the door was unlocked. There was someone inside.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sachie268"]
[OnName num="sachie"]
"Welcome back, Tomoya."
[cpg cn=true]


[OnName num="tomoya"]
"…… How did you get in?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sachie269"]
[OnName num="sachie"]
"What do you mean? It was open."
[cpg cn=true]


[OnName num="tomoya"]
"Be that as it may, most people don't try to open other people's doors……"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sachie270"]
[OnName num="sachie"]
"Don't worry, I didn't go looking for your lewd books or anything."
[cpg cn=true]


I should teach her a thing or two about boundaries, but there was something endearing about her forceful personality.
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1500]

Unable to refuse her, I enjoyed our time alone together.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[FACE method="shake_1" pos="2/3"]
[VOICE f="Sachie291"]
[OnName num="sachie"]
"Well, I'd better get back to my place. My husband will be home soon."
[cpg cn=true]


[OnName num="tomoya"]
"…… Won't he find out?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sSachie022"]
[OnName num="sachie"]
"I don't care if he finds out. I am prepared for that."
[cpg cn=true]


[OnName num="tomoya"]
"Why are you so…… concerned about me?"
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="sSachie023"]
[OnName num="sachie"]
"That's……"
[cpg cn=true]


She struggles to find the words. I can understand.
[cpg]

Sachie was coming on to me for a reason.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Reflecting on all that had happened today, I tried to get some sleep.
[cpg]


Would somebody visit me tomorrow? Maybe I should make the first move.……
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


I don't get to see Sachie on the weekends.
[cpg]


Of course, every day was like a weekend to me, but not so for Sachie.
[cpg]


I couldn't meet with her while her husband was at home.
[cpg]


On the other hand, Erika and Mihane probably couldn't see their husbands even on the weekends.
[cpg]


In that case, I should go to them. I headed to the convenience store to buy some food…….
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[SE f="se003"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=2000]


I came back and soon after eating dinner, the doorbell rang.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Erika258"]
[OnName num="erika"]
"Hello, Tomoya."
[cpg cn=true]


[OnName num="tomoya"]
"Hello…… What's up?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Erika259"]
[OnName num="erika"]
"What do you mean? I told you about our group the supporting your rehabilitation, didn't I?"
[cpg cn=true]


[OnName num="tomoya"]
"……Yes."
[cpg cn=true]


It was Erika's turn today. I guess I'd adapted to this strange situation.
[cpg]


[OnName num="tomoya"]
"What about your husband?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Erika260"]
[OnName num="erika"]
"……I'm not sure he still loves me."
[cpg cn=true]


[OnName num="tomoya"]
"I'm sure he does. Have you talked with him?"
[cpg cn=true]


;//========================================
;//●ＣＧエロ（ヒロインが主人公を誘う。元の絵から表情を変えてください）ev_33
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


In the middle of the conversation, she gets undressed.
[cpg]

[VOICE f="sErika018"]
[OnName num="erika"]
"If we talk about it, I get the feeling that I'll have to put up with a lot more things."
[cpg cn=true]


[OnName num="tomoya"]
"But……."
[cpg cn=true]


But...I couldn't refuse her at all.
[cpg]

On the contrary, I'm starting to feel like I wanted to take advantage of her invitation……
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


And after a while, I had Erika return to her room.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sErika019"]
[OnName num="erika"]
"I'm starting to miss you already."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Erika282"]
[OnName num="erika"]
"I'll see you soon. I'll come visit you."
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


That night I went to bed alone.
[cpg]


But I didn't feel lonely. Rather, I feel fulfilled.
[cpg]


I am a little nervous. This relationship can't last forever.
[cpg]


But I had a feeling that it would go on for a while……
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


The next day was Sunday. I ran into Mihane.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

[OnName num="tomoya"]
"What's wrong? You look pale."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mihane239"]
[OnName num="mihane"]
"Oh, Tomoya…… it's nothing."
[cpg cn=true]


She acts normal, but there was something off about her.
[cpg]


She looks tired, like she's holding back a desire.
[cpg]


[OnName num="tomoya"]
"…..You husband didn't get the weekend off?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mihane240"]
[OnName num="mihane"]
"Usually he does, but...he seems busy these days."
[cpg cn=true]


What kind of a company doesn't have Sundays off?
[cpg]


Even if I thought it, I wasn't about to say that out loud.
[cpg]


An awkward silence passes. Mihane was probably on her way back to her apartment room.
[cpg]


[OnName num="tomoya"]
"If you're lonely, I can probably help with that."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Mihane241"]
[OnName num="mihane"]
"What……?"
[cpg cn=true]


[OnName num="tomoya"]
"I mean, it just seemed like you were……"
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Mihane242"]
[OnName num="mihane"]
"……Tomoya, you're so kind."
[cpg cn=true]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（昼）******************************************************


We head to Mihane's room.
[cpg]


She was the one who invited me, all I did was accept her offer.
[cpg]


[OnName num="tomoya"]
"Are you sure you want to do this, Mihane?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Mihane243"]
[OnName num="mihane"]
"What do you mean? You said you were going to help me, didn't you?"
[cpg cn=true]


[OnName num="tomoya"]
"Yes, but your husband……."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="sMihane010"]
[OnName num="mihane"]
"You let me worry about him."
[cpg cn=true]

;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


We talked about many different things.
[cpg]

Of course, we don't just talk. Time passed while we were flirting with each other.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mihane264"]
[OnName num="mihane"]
"See you, Tomoya……."
[cpg cn=true]


[OnName num="tomoya"]
"Yeah, see you soon……."
[cpg cn=true]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[OnName num="tomoya"]
"……"
[cpg cn=true]


I went back to my room, feeling confused.
[cpg]


Can we really keep doing this over and over again?
[cpg]


Being with them feels good. But am I driving them into a corner?
[cpg]


It was too late for regrets, I couldn't stop having relations with them.
[cpg]


I can't leave them now.
[cpg]


I guess knowing this pleasure was the end of it all.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Then one weekday, something happened.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


I was at college during the day.
[cpg]


I don't care about the gossip and whispering around me anymore.
[cpg]


That was fine. The problem became apparent later.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


Mihane looked like she was about to break down and cry. Erika and Sachie were trying to comfort her.
[cpg]



[FACE method="bow_1" pos="1/3"]
[VOICE f="Erika283"]
[OnName num="erika"]
"……It was bound to happen eventually. We were supposed to be prepared for that, weren't we?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mihane265"]
[OnName num="mihane"]
"But...but what if he leaves me?"
[cpg cn=true]


[FACE method="shake_2" pos="3/3"]
[VOICE f="Sachie294"]
[OnName num="sachie"]
"It won't happen anytime soon, there's no proof."
[cpg cn=true]


It seemed there was a problem. I called out to them.
[cpg]


[OnName num="tomoya"]
"What's wrong? I just heard something about a divorce."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mihane266"]
[OnName num="mihane"]
"Oh……it's just that I'm……."
[cpg cn=true]


[FACE method="shake_7" pos="3/3"]
[VOICE f="sSachie024"]
[OnName num="sachie"]
"I'll explain. Mihane's husband found traces that someone else had been in the house."
[cpg cn=true]


Traces. That means me.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mihane267"]
[OnName num="mihane"]
"He's saying that he wants a divorce, and I don't know what to do……"
[cpg cn=true]


[FACE method="bow_2" pos="1/3"]
[VOICE f="Erika284"]
[OnName num="erika"]
"If push comes to shove, why don't you just marry Tomoya?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mihane268"]
[OnName num="mihane"]
"……Well that's, umm…… You're right, but……."
[cpg cn=true]


Oh. So she was okay with that?
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mihane269"]
[OnName num="mihane"]
"I can't stop our current relationship. I don't want Tomoya to hate me."
[cpg cn=true]


[OnName num="tomoya"]
"Mihane, were you that determined to be with me……?"
[cpg cn=true]


[FACE method="bow_3" pos="1/3"]
[VOICE f="Erika285"]
[OnName num="erika"]
"Well of course. Sachie and I are risking everything."
[cpg cn=true]


[FACE method="bow_7" pos="3/3"]
[VOICE f="sSachie025"]
[OnName num="sachie"]
"Yeah. My husband could get angry at any moment."
[cpg cn=true]


I had to think. I was starting to realize how much influence I had over these women.
[cpg]


;//※全てのヒロインが候補になっているかどうかで分岐

[if exp={getFlagValue("Cha1flg") == 1 }]
[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*get_halem"]
[endif]
[endif]
[endif]


*lost_halem|Satisfied with the Present
[jump storage="ep011.ks" target="*lost_halem"]


*get_halem|Satisfied with the Present
[jump storage="ep010.ks" target="*get_halem"]


