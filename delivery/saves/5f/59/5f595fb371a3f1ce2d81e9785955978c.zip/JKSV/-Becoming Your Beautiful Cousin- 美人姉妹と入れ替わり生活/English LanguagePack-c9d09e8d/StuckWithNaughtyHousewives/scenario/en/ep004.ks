
*start|The Truth of Strange Dreams

;#################################################
*Ep004|The Truth of Strange Dreams
;#################################################

[SCENE id=4]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


I do feel lonely. Or, at least, I did.
[cpg]


I didn't mind talking to someone who would be kind to me no matter what.
[cpg]


Specifically, Erika. I felt fairly confident that Mihane and Sachie would also be kind to me.
[cpg]


[SE f="se003"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=2000]


Just as I was thinking that, the doorbell rang. Who could it be? I opened the door.
[cpg]




[SE f="se001"]
;//【ＳＥ】『ドア開ける』

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[OnName num="tomoya"]
"......What are you doing here?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sachie013"]
[OnName num="sachie"]
"I thought you might be free. You are free, aren't you? You're a shut-in."
[cpg cn=true]


[OnName num="tomoya"]
"Well, I'm not busy, but……"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sachie014"]
[OnName num="sachie"]
"But what? You don't have anything in here that you don't want to me to see or anything, right?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sSachie003"]
[OnName num="sachie"]
"Anyway, how have you been? Don't you get lonely by yourself all the time?"
[cpg cn=true]


……I thought it was a little strange.
[cpg]


Following Erika, now even Sachie was acting like this. Am I that good looking?
[cpg]


I don't think I look that bad and maybe there's something about me that arouses their motherly nature……
[cpg]


Even still, it's not like I was particularly good looking. Something didn't add up.
[cpg]


[OnName num="tomoya"]
"You've got a husband, right? You can't do this."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sSachie004"]
[OnName num="sachie"]
"……I know that."
[cpg cn=true]


She's hesitating about something, but she's pushing forward anyways.
[cpg]


Sachie doesn't show such a part of herself so it's hard to tell.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

I spent some time alone with Sachie.
[cpg]

We didn't talk much. There were even times when the silence dragged on.
[cpg]

Even then, it was......exciting.
[cpg]


[OnName num="tomoya"]
"I'll see you then……."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sachie059"]
[OnName num="sachie"]
"Yeah. I'll see you later."
[cpg cn=true]


I didn't mean to imply that we'd meet like this again. At least not intentionally.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


......How long would this situation last?
[cpg]


Erika and Sachie must feel as guilty as I did.
[cpg]


Could these relationships go on like this? How many times would it take before something changed.
[cpg]


It wasn't okay, how could it be? But how could I stop things now?
[cpg]


I was in agony. Why did they have to be married?
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


It is daytime. I wandered around the city.
[cpg]


I do this every now and again, usually when I've been away from the sun for too long.
[cpg]


Sometimes I wander around parks. I was in the mood for it today, so I headed to the park.
[cpg]



;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_08_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


[OnName num="tomoya"]
"Oh….."
[cpg cn=true]


I arrive at the park to find Mihane sitting on the bench, deep in thought.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=1000]

[OnName num="tomoya"]
"I didn't expect to see you here."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mihane012"]
[OnName num="mihane"]
"Oh, Tomoya….. sorry, you had to see me like this."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


We head back to our neighborhood together.
[cpg]


She seemed worried about something earlier. I ask her what happened.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Mihane013"]
[OnName num="mihane"]
"My husband is a really nice guy. But he tends to put work first.……"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mihane014"]
[OnName num="mihane"]
"If things don't change, I don't know what's going to happen to us……. We don't spend much time together anymore."
[cpg cn=true]


In short, she was saying that she was lonely.
[cpg]


But the way she said it was much more subtle than Erika or Sachie.
[cpg]

[FADEOUTBGM]

I could have chosen not to say anything at this point.
[cpg]


But at the same time, I knew I couldn't leave her like this.
[cpg]


[OnName num="tomoya"]
"......Would you be interested in spending some time talking with me?"
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Mihane015"]
[OnName num="mihane"]
"What……?"
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


I invited Mihane up to my room.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMihane001"]
[OnName num="mihane"]
"……Pardon the intrusion."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sMihane002"]
[OnName num="mihane"]
"I'm not sure I should be in your room......just the two of us."
[cpg cn=true]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


;//ブラックアウト
;//[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

As we talked, I could easily pick up on her frustration.
[cpg]

Mihane said she misses her husband because she loves him deeply.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Then, after a while……
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[OnName num="tomoya"]
"…… I think it's time for you to go back home."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mihane057"]
[OnName num="mihane"]
"He's going to be home late today anyway……"
[cpg cn=true]


[OnName num="tomoya"]
"But still, just in case. You wouldn't want him knowing where you've been."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Mihane058"]
[OnName num="mihane"]
"……I guess you're right……"
[cpg cn=true]


She seems to want to stay. She is a lot more promiscuous than she seems.
[cpg]


[OnName num="tomoya"]
"Let's leave it here for today. I'm sure we'll have other opportunities."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mihane059"]
[OnName num="mihane"]
"Well……okay."
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『ドア閉まる』


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

With that, Mihane left.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I had become fairly well acquainted with three married women over a short span of time.
[cpg]


It was odd since they seemed like they were even taking turns.
[cpg]


I decided to ask the next time I saw one of them.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

The next evening.
[cpg]

[window target=false]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[SE f="se003"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=2000]


I was playing games. The doorbell rang repeatedly, so I stopped playing games and went to the front door.
[cpg]

[SE f="se001"]
;//【ＳＥ】『ドアを開ける』


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[WAIT time=2000]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Erika058"]
[OnName num="erika"]
"Hello, Tomoya. You didn't come to my place, so I came to get you."
[cpg cn=true]


[OnName num="tomoya"]
"……"
[cpg cn=true]


I knew it was strange, why would I get so many women visiting me so often?
[cpg]


And it had started suddenly. It was suspicious to say the least.
[cpg]


[OnName num="tomoya"]
"Erika, you know Mihane and Sachie, right?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Erika059"]
[OnName num="erika"]
"Yes, we live in the same apartment."
[cpg cn=true]


[OnName num="tomoya"]
"Isn't that strange? Don't you know anything about what's been going on?"
[cpg cn=true]


I asked her, blurring the truth.
[cpg]


Erika answered.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Erika060"]
[OnName num="erika"]
"…… I knew you'd notice. I bet you thought that it was too sudden."
[cpg cn=true]


So there was something going on. I had to find out more.
[cpg]


[OnName num="tomoya"]
"You're awfully organized, aren't you? I haven't seen any of you fighting over me either."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Erika061"]
[OnName num="erika"]
"To tell you the truth, we got together to form a little group. It's called the 'Association to Support Tomoya's Reintegration into Society'."
[cpg cn=true]


What is that? The name is a bit confusing.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Erika062"]
[OnName num="erika"]
"Tomoya, you had trouble with a girl and refused to go to school, right? So I thought I could help you."
[cpg cn=true]


[OnName num="tomoya"]
"I see."
[cpg cn=true]


I wasn't entirely convinced. There was more to this story than she let on.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Erika063"]
[OnName num="erika"]
"There are rules to our pact as well. I'll tell you about it."
[cpg cn=true]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FACE method="change_1" pos="2/3"]
[WAIT time=1000]

"First of all, we all take turns. There's no jumping the line."
[cpg]

"However, you may comply as long as it's Tomoya who initiates."
[cpg]


[FO pos="4/7" time=1000]
[WAIT time=1000]

[OnName num="tomoya"]
"I had no idea you guys were making such a big deal about me……"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Erika064"]
[OnName num="erika"]
"I'm sorry, we ended up deciding things without you."
[cpg cn=true]


I didn't really mind.
[cpg]

But the arrangement was strange. I don't know who decided this, but wouldn't it be better if one of them had me all to themselves?
[cpg]


[OnName num="tomoya"]
"You weren't thinking of keeping me all to yourself?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Erika065"]
[OnName num="erika"]
"I accidentally mentioned you once. It looked like there was going to be some competition so we had to set some rules early on."
[cpg cn=true]


So their little alliance was to prevent conflict.
[cpg]


I didn't care what it was, but I didn't think there was such a back story to it.
[cpg]


[OnName num="tomoya"]
"So…… what are we going to do today?"
[cpg cn=true]

;//ブラックアウト
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

And we ended up in this situation.
[cpg]


;//========================================
;//●ＣＧエロ（主人公に迫るヒロイン）ev_10
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

[BGM f="bg_h2"]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

[VOICE f="sErika005"]
[OnName num="erika"]
"…..I know I'm the one who suggested we share, but it's a little frustrating not having you all to myself."
[cpg cn=true]


We were alone in my room, the mood was enticing.
[cpg]

But it seems that due to their arrangement, she couldn't go any further.
[cpg]

[OnName num="tomoya"]
"This doesn't feel right, you're a married woman..."
[cpg cn=true]


She didn't seem to have a good response.
[cpg]

;//ブラックアウト
;//ヒロインに視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************


[FACE method="shake_4" pos="2/3"]
[VOICE f="sErika006"]
[OnName num="erika"]
"……"
[cpg cn=true]


I was having trouble controlling my emotions.
[cpg]

I felt awful about it, but I found myself imagining seeing him again.
[cpg]

I need to focus, I had to make dinner. I was about to cook a meal for one.
[cpg]


My heart aches when I see his picture. I have to stop seeing Tomoya.
[cpg]


;//ブラックアウト
;//主人公に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


Morning is coming. I can say that morning and night don't matter to me……
[cpg]


However, I was starting to anticipate that I'd receive another visitor.
[cpg]


The next one would be Mihane or Sachie. That's what I thought.
[cpg]


They had to visit in order, right? There were supposed to be rules to our interactions.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


With that thought in mind, I went out to buy food again.
[cpg]


My activities are becoming more and more monotonous. But I don't mind.
[cpg]


Recent events are more than exciting enough to break through the monotony. You never know who is coming or when.
[cpg]


When I returned home, I found Sachie waiting in front of my room.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSachie005"]
[OnName num="sachie"]
"Good morning."
[cpg cn=true]


[OnName num="tomoya"]
"…..A bit bold of you to wait in front of my room."
[cpg cn=true]


She just smiled wryly. She doesn't deny it.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

She invites me into her home.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************


I realized it was the first time I entered her room.
[cpg]


[OnName num="tomoya"]
"Don't you feel any guilt towards your husband?"
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Sachie063"]
[OnName num="sachie"]
"Don't be so mean, of course I do."
[cpg cn=true]


But she still wants me. I thought it was kind of nice.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sSachie006"]
[OnName num="sachie"]
;//「ずるいよ。絵梨香にもこんなことを言ってるの」
"It's not fair. Did you say things like this to Erika too?"
[cpg cn=true]


[OnName num="tomoya"]
"…..How do you know that?"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[WAIT time=1500]

[FACE method="bow_7" pos="2/3"]
There was a silence for a moment. Sachie mumbles, "Oh shoot" under her breath.
[cpg]


[OnName num="tomoya"]
"It's fine. Erika told me most of what's going on. You made some sort of pact to rehabilitate me, right?"
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Sachie065"]
[OnName num="sachie"]
"Oh, so you've already heard……well, that's a weight off my shoulders."
[cpg cn=true]

;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I spend some time alone with her, but I felt like I couldn't stay long.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


I feel like I am about to be swallowed up. By both Erika and Sachie.
[cpg]


It was as if I was going to be swallowed up by these women and that would be it. I'd never be able to escape them on my own.
[cpg]


I had a choice. Either I'd swallow them up or go, willingly, into their arms.
[cpg]


Either way, I had to make a choice. There wasn't any room to be indecisive……
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


I left my room, thinking I'd take a walk. I found Mihane crouching in front of the door to her apartment.
[cpg]


I wonder if she had some kind of fight with her husband. Or……
[cpg]


[OnName num="tomoya"]
"……What's wrong, Mihane?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mihane060"]
[OnName num="mihane"]
"Oh, Tomoya……."
[cpg cn=true]


She looks drained. Whatever had happened, it seemed serious.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mihane061"]
[OnName num="mihane"]
"I might not be able to stand it any longer……. I'm so lonely, I feel like I'm going to die."
[cpg cn=true]


[OnName num="tomoya"]
"Don't say that. You have me."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Mihane062"]
[OnName num="mihane"]
"But you're a college student and I'm married……. I can't depend on you all the time."
[cpg cn=true]


She says this with a pained expression on her face.
[cpg]


There wasn't problem as long as I'm the one initiating, right?
[cpg]


As I recall, their agreement didn't say anything that would prevent me from making a move.
[cpg]


[OnName num="tomoya"]
"Then what would you do if I told you that I was the one who wanted to talk to you?"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
Mihane looked surprised. Naturally so.
[cpg]


[OnName num="tomoya"]
"It's not breaking any rules if I go to one of you, right?"
[cpg cn=true]


[FACE method="shake_5" pos="2/3"]
[VOICE f="Mihane063"]
[OnName num="mihane"]
"How did you know...?"
[cpg cn=true]


[OnName num="tomoya"]
"I heard about it from Erika. You're a member, right?"
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Mihane064"]
[OnName num="mihane"]
"Yes, but I can't trouble you."
[cpg cn=true]


[OnName num="tomoya"]
"It's a little late for that. Besides, I never said you were troubling me. Come over here."
[cpg cn=true]


I grab her hand and pull her towards me.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//移植のためシーンをカットしています

I was kind of feeling like I had grown up a little…… but a part of me worried that I was being too pushy.
[cpg]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Strangely enough, I've stumbled into a situation where women came of their own accord to me.
[cpg]


On top of that, I get to play games and do whatever I want. You could say that it was like heaven.
[cpg]


However, no matter what I did, they'd never be truly mine.
[cpg]


I can't keep going on like this. I have to do something proactive on my part.
[cpg]


However, the other party is a married woman. If that is the case.
[cpg]

……I renewed my resolve.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


First of all, this harem will not last forever.
[cpg]


Will I still live here after college? That aside.
[cpg]


If I don't go to college first, there is a danger that my parents will cut me off.
[cpg]


If my parents found out that I wasn't going to college, this harem would end. Impure though my motives may be, they were enough to get me out of my room and into the classroom.
[cpg]


;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


I wasn't in the mood to learn anything, but if I didn't attend my lectures, I wouldn't be able to get the credits.
[cpg]


I had no choice but to attend, but I really wasn't in the mood……
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（昼）******************************************************


[OnName num="man"]
"Hey, isn't that the guy……?"
[cpg cn=true]


[OnName num="woman"]
"Yeah, he tried to force himself on a girl with androphobia, right?"
[cpg cn=true]


[OnName num="man"]
"What a loser. Guys like him give us all a bad name."
[cpg cn=true]


[OnName num="woman"]
"It's so true. It's unforgivable."
[cpg cn=true]


Both girls and guys gossip in a way so that I can hear them. I try to walk past them without paying attention, but still it hurts.
[cpg]


I didn't feel like I should go to the club. I went straight back to my house.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


When I returned home, I found all three ladies near my apartment.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Erika086"]
[OnName num="erika"]
"Oh, Tomoya. Welcome home.……? Where's your bag?"
[cpg cn=true]


[OnName num="tomoya"]
"I went to the university."
[cpg cn=true]


What will they say? I wonder if they'll say, "It's strange that you're back so early."
[cpg]


I thought so, but the reaction was rather the opposite.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mihane081"]
[OnName num="mihane"]
"Good, you're finally back on track……"
[cpg cn=true]


[OnName num="tomoya"]
"Hardly…… it was only one day, and I left early."
[cpg cn=true]


[FACE method="shake_2" pos="3/3"]
[VOICE f="Sachie082"]
[OnName num="sachie"]
"But, just being able to go to college means that you've grown. I'm so happy."
[cpg cn=true]


They spoil me……was this the right thing to do?
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


That afternoon I play games in a daze. Other students were still in class, but here I was. As usual.
[cpg]


The three of them praised me. But I feel like I'm going to be swallowed up.
[cpg]


What should I do? Or rather, what did I want to do?
[cpg]


I decided to think about where I want to go…… with them.
[cpg]


;//■選択肢
[switch]
[case "I want them to be mine."]
	[swap]
	[jump target="*select04_1"]
[case "I'll leave the situation the way it is."]
	[swap]
	[jump target="*select04_2"]
[endswitch]


1. I want them to be mine.
2. I'll leave the situation the way it is.

*select04_1|The Truth of Strange Dreams
[jump storage="ep005.ks" target="*select04_1"]

*select04_2|The Truth of Strange Dreams
[jump storage="ep009.ks" target="*select04_2"]
;////////////////////////////////////////////////////////////////////////
