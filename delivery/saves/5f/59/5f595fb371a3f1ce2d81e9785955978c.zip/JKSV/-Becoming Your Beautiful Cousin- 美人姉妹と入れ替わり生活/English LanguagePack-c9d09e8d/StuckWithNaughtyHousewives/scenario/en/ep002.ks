
*start|A Strange Encounter

;#################################################
*Ep002|A Strange Encounter
;#################################################

[SCENE id=2]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


;//暫く佐智恵の名前を？？？と隠してください



On the way home from the convenience store I spotted another, slightly older woman. She was standing in front of the apartment building.
[cpg]


This happens a lot these days. I thought I'd wait until she went somewhere, but it seems she's coming this way.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Sachie001"]
[OnName num="unknown"]
"……Hmmm. So this is him?"
[cpg cn=true]


That was...odd. Was she talking about me?
[cpg]


;//ここから佐智恵の名前を隠さないでください


[FACE method="change_2" pos="2/3"]
[VOICE f="Sachie002"]
[OnName num="sachie"]
"My name is Sachie. Sachie Demoto. What's your name?"
[cpg cn=true]


[OnName num="tomoya"]
"Umm……?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sachie003"]
[OnName num="sachie"]
"I'm sorry, did I surprise you? I'm sorry for asking so bluntly."
[cpg cn=true]


There was that, but it was also weird that she would suddenly introduce herself.
[cpg]


Does she know who I am? If so, who told her?
[cpg]


Maybe it wasn't a coincidence that I've been running into a lot of married women lately. I can't help but wonder.
[cpg]


Would I be overthinking if I thought that the three of them were connected somehow?
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sachie004"]
[OnName num="sachie"]
"You look like a university student. Don't you have classes?"
[cpg cn=true]


[OnName num="tomoya"]
"I don't have any lectures scheduled for today."
[cpg cn=true]


Even if it was around noon on a weekday, such excuses were acceptable for university students.
[cpg]


However, Sachie didn't seem convinced.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sachie005"]
[OnName num="sachie"]
"What, are you thinking of quitting school? Trust me, you don't want to waste your youth like this."
[cpg cn=true]


[OnName num="tomoya"]
"What makes you think that? Do you have any proof?"
[cpg cn=true]


My voice was trembles as I try to defend myself.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Sachie006"]
[OnName num="sachie"]
"Is that so? Then I suppose you're free to help me blow off some steam. My husband, you know……."
[cpg cn=true]


;//[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト


I'd only just met this woman and now I had to listen to her complain.
[cpg]


At first it was about how tired she was from housework……
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[FACE method="shake_7" pos="2/3"]
[VOICE f="sSachie001"]
[OnName num="sachie"]
"My husband never pays any attention to me. My birthday was the other day and guess what he did?……"
[cpg cn=true]


[OnName num="tomoya"]
"……"
[cpg cn=true]


I didn't even try to respond, I was just listening.
[cpg]


What was the point of this? Would you normally talk about such private matters with a total stranger?
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="sSachie002"]
[OnName num="sachie"]
"I wonder if there is a boy somewhere who would take care of me……."
[cpg cn=true]


The fact that she said "boy" was bugging me. I think she might be referring to me.
[cpg]


I thought so, but I couldn't listen any longer and decided to leave.
[cpg]


[OnName num="tomoya"]
"Sorry, I just remembered that I had some errands to run."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sachie009"]
[OnName num="sachie"]
"Oh? Well, go on then."
[cpg cn=true]


She let me go surprisingly easily. I couldn't listen to her talk like this for long.
[cpg]


And I thought to myself,
[cpg]


;//■選択肢
[switch]
[case "She is a strange person."]
	[swap]
	[jump target="*select03_1"]
[case "Maybe she's stressed."]
	[swap]
	[jump target="*select03_2"]
[endswitch]


1. She is a strange person.
2. Maybe she's stressed.


;//==============================
;//１、彼女は妙な人だ

*select03_1|A Strange Encounter


She's a strange person. I wonder what she's trying to do by making me listen to her talk like that.
[cpg]


Is she trying to seduce me? I don't know.
[cpg]

[jump target="*select03_3"]

;//==============================
;//２、彼女も大変なのかもしれない

*select03_2|A Strange Encounter


I wonder if she is waiting for someone to love her.
[cpg]

I walked away thinking that I might be too……
[cpg]

[stflag Cha3flg = 1]

;//佐智恵が候補に


;//==============================

*select03_3|A Strange Encounter


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


Somehow, I can't forget what had happened earlier.
[cpg]


If I had just taken her up on her offer, would I have felt any less lonely?
[cpg]


It's useless to even think about it.
[cpg]


There is no way that something like that could happen. I spent the rest of the day as I usually did.
[cpg]


[jump storage="ep003.ks" target="*start"]

;////////////////////////////////////////////////////////////////////////

