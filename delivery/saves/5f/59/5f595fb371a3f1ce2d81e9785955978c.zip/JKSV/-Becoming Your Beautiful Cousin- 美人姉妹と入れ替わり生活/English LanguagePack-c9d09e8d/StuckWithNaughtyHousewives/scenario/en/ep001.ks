
*start|The power of attraction

;#################################################
*Ep001|The power of attraction
;#################################################

[SCENE id=1]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


The morning comes, but before I know it, it's night time again.
[cpg]


Time seems to stand still, but I can't shake the feeling that it's flowing faster and faster every day.
[cpg]


It seems to spur on my journey of self-degradation, and yet there is an indescribable feeling as if it has stopped……
[cpg]


How many times did I complete this game? My memory is getting fuzzy.
[cpg]


Maybe I'm not getting enough sugar. I head out to buy some juice.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

It seems like the only reason I go out anymore is to get food. But as I was leaving, I saw a strange sight.
[cpg]


;//========================================
;//●ＣＧ非エロ（倒れる夫をしゃがみ込んで支えるヒロイン。心配そうなヒロイン、夫の顔は映らない感じ）ev_02
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：ヒロイン２の夫
;//服装２：スーツ
;//場所　：マンション＿廊下
;//時間　：夜
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_ad"]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//暫く美羽の名前を？？？と隠してください


[VOICE f="Mihane001"]
[OnName num="unknown"]
"Honey, get a grip……."
[cpg cn=true]


[OnName num="man"]
"Don't worry…… I'll be fine .…"
[cpg cn=true]


Another married couple, but the husband seemed ill.
[cpg]


He'd halfway collapsed on the spot. Was he just getting home? At this hour?
[cpg]


The date has already changed. It's past midnight.
[cpg]


[VOICE f="Mihane002"]
[OnName num="unknown"]
"Is the company that hard on you?"
[cpg cn=true]


[OnName num="man"]
"Don't worry…… it's my fault, I'm not the best at what I do."
[cpg cn=true]


I wonder if he's working for one of those exploitative companies that were all over the news these days.
[cpg]


It's none of my business, at least he wasn't a shut-in.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I finish my shopping and head back home.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I feel exhausted when I reach my room. The guy from before probably felt like this too.
[cpg]


But at least he had a reason. He collapsed from exhaustion.
[cpg]


I hadn't done anything, but my body doesn't seem to be moving properly.
[cpg]


Maybe it's because I haven't been getting enough sunlight lately. Whatever……
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


The next day. I saw the woman from the other day again.
[cpg]


There are two of them. This time it was the one who was supporting her husband.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

[FACE method="change_5" pos="2/3"]
[VOICE f="Mihane003"]
[OnName num="unknown"]
"Oh…… the guy from the other day."
[cpg cn=true]


[OnName num="tomoya"]
"…… Hi."
[cpg cn=true]


That's awkward. She was probably on her way home from the supermarket since she had so many bags.
[cpg]


I was on my way to a convenience store.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mihane004"]
[OnName num="unknown"]
"I'm sorry you had to see that…. He seems to be having a really hard time at work."
[cpg cn=true]


[OnName num="tomoya"]
"I see."
[cpg cn=true]


I stammer. I don't feel like I can speak well.
[cpg]


Of course, I hadn't talked to anybody in a long time.
[cpg]


It seemed more and more likely that her husband was working at an exploitative company.
[cpg]


;//■選択肢
[switch]
[case "I'm worried about her."]
	[swap]
	[jump target="*select02_1"]
[case "It's a common story."]
	[swap]
	[jump target="*select02_2"]
[endswitch]

1. I'm worried about her.
2. It's a common story.


;//==============================
;//１、彼女のことが心配だ

*select02_1|The power of attraction


I'm worried about her. I was more worried about her than her husband.
[cpg]


I couldn't help but be drawn to her, she was extremely beautiful.
[cpg]

[stflag Cha2flg = 1]

;//美羽が候補に

[jump target="*select02_3"]

;//==============================
;//２、よくある話だ

*select02_2|The power of attraction


It's a common story. It's nothing to worry about.
[cpg]


These type of companies were even showing up in the news lately. There wasn't anything we could do but wait for the laws to change.
[cpg]


;//==============================
*select02_3|The power of attraction


[jump storage="ep002.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
