
*start|The neighbor's wife
;//人妻不倫もの　シナリオ
;//物語の視点が変わる部分があります。ウィンドウ色を変えるなどして、変化をつけてください
;//視点は主人公視点、ヒロイン視点の二種類です
;//物語は主人公視点からスタートし、切り替わる部分では「（キャラ名）に視点切り替わり」と表記してあります
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//絵梨香　私服
;//美羽　　私服
;//佐智恵　私服

;//以下音声なし
;//智也 店員 サークルの女子 男 女 佐智恵の夫
;//女Ａ 女Ｂ 絵梨香の夫 智也の恋人 智也の母 美羽の夫

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//絵梨香　一人称「私」　美羽呼び「美羽さん」　佐智恵呼び「佐智恵さん」　智也呼び「智也くん」
;//美羽　一人称「私」　絵梨香呼び「絵梨香さん」　佐智恵呼び「佐智恵さん」　智也呼び「智也くん」
;//佐智恵　一人称「私」　美羽呼び「美羽さん」　絵梨香呼び「絵梨香さん」　智也呼び「智也くん」
;//智也　一人称「俺」　絵梨香呼び「絵梨香さん」　美羽呼び「美羽さん」　佐智恵呼び「佐智恵さん」



;#################################################
*Ep000|The neighbor's wife
;#################################################

[SCENE id=0]


[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]


;///////////////////////////ここからが本編です///////////////////////////


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

It was Autumn, and the school festival was approaching.
[cpg]


The seasons didn't matter much to me.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I was playing a game I'd already cleared several times before.
[cpg]


I want to play games all day long. I want to buy new games, but I don't have the money.
[cpg]


That's why I play the same games over and over again. It sounds like a child's way of thinking, but my brain was that of a child.
[cpg]


I lived on the money my parents sent me, never bothering to find a part-time job.
[cpg]


I would cut back on the number of meals I ate just to buy games.
[cpg]


As a result, I've lost 10 kilograms since I entered university.
[cpg]


Cooking for myself is a hassle. I eat boxed lunches and cup noodles from supermarkets and convenience stores.
[cpg]


Of course, buying meals is much more expensive so I'm not really saving much money.
[cpg]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_06_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]



I haven't attended a single lecture since the Fall semester started.
[cpg]


The spring semester was tough. I begged and cried to my professor and got some credits for lectures I didn't attend at all.
[cpg]


I explained to my parents that I'd been sick and that I'd really get in gear to make up the credits I needed to graduate.
[cpg]


Instead, my attendance dropped. By Fall, I'd become even more of a recluse.
[cpg]


There wasn't much time left before I was sure they'd call me home.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

I don't want to leave this apartment. If I go back home, they'll tell me to do something.
[cpg]


They might tell me to get a part-time job or get a driver's license.
[cpg]


I didn't want to do that. I want to continue living a life of self-indulgence.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


Day and night were merging. Sometimes I didn't even know what day it was.
[cpg]


Watching anime kept my biological clock in sync with the world.
[cpg]


But of course, it was late-night anime. I was watching pretty much every episode of every anime that aired each season.
[cpg]


But those days will soon come to an end. I lived each day in fear, wondering what they would say when I returned home.
[cpg]


;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[OnName num="tomoya"]
"It's so bright out..."
[cpg cn=true]


Tomoya Mikado. That's my name.
[cpg]


As an only child, my parents tended to spoil me when I was younger.
[cpg]


I was an honor student until around elementary and junior high school.
[cpg]


But something went wrong around the time I entered high school. I lost the ability to socialize with my peers.
[cpg]


When you are not good at socializing, your motivation to do your schoolwork goes down.
[cpg]


I ended up going to a decent college, but even then it got to the point where I couldn't take it anymore.
[cpg]


Socializing. No matter how far I go, relationships will always torment me.
[cpg]


But time keeps ticking away regardless of if I'm suffering or not.
[cpg]


Growing old and alone wasn't really on my mind.
[cpg]


I am more afraid of not being forced out of my apartment.
[cpg]


I thought I was finally free. I could live the way I wanted.
[cpg]


While indulgent, my parents were otherwise normal people.
[cpg]


They wouldn't allow me to be a shut-in.
[cpg]

[SE f="se032"]
;//【ＳＥ】『コンビニ入店音』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト


[OnName num="staff"]
;//「いらっしゃいませ」
"Welcome!"
[cpg cn=true]


I hear a very unenthused greeting. I am a regular at this convenience store.
[cpg]


They are probably too lazy to say hello properly to me at this point, so I just start looking for a lunch box.
[cpg]


I was a slob. There was no getting around it at this point.
[cpg]


I'd gotten to the point that I found it difficult to care anymore.
[cpg]


I thought it would be fine if I kept on falling.
[cpg]


But society wouldn't allow it.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


When I returned to my apartment, I passed a young woman. Even passing by her was a hassle.
[cpg]


I am a shy person, especially with women.
[cpg]


It all started during my first year at University.
[cpg]


;//回想なのでセピア調にしてください
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（夕方）******************************************************


I'd joined a club for nerds with a surprisingly decent male to female ratio.
[cpg]


I liked this group of shy people with common interests just casually chatting with one another. It didn't take long for me to fall in love with a girl.
[cpg]


But when I confessed my feelings for her, my situation took a sudden turn for the worse.
[cpg]


[OnName num="club_girl"]
"Ugh, no…… I'm scared……"
[cpg cn=true]


[OnName num="tomoya"]
"……Huh?"
[cpg cn=true]


I clearly remember her saying, "I'm scared."
[cpg]


I later learned that the girl who I confessed to was extremely afraid of men.
[cpg]


I was made out to be the bad guy. I'd disturbed the peace in our community.
[cpg]


;//回想はここまでですので色調を戻してください

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


I felt wronged. I ate lunch and watched some random anime to keep my mind off of what had happened.
[cpg]


I can't go back to that place. I don't want to.
[cpg]


I convinced myself that I would never go back there and endured the ensuing loneliness.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


At night, I got hungry again. I decided to go shopping at the supermarket.
[cpg]


I wasn't eating enough to begin with and what little I ate wasn't exactly good for me.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se010"]
;//【ＳＥ】『歩く』

[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


I noticed that the sun was setting earlier than usual as I made my way home.
[cpg]


;//========================================
;//●ＣＧ非エロ（ヒロインがマンションから出てきて、主人公と目が合う。柔らかな笑顔のヒロイン。その後少し心配そうな顔になる）ev_01
;//人物１：ヒロイン１
;//服装１：私服
;//場所　：マンション前
;//時間　：夜
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_ad"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//暫く絵梨香の名前を？？？と隠してください


[VOICE f="Erika001"]
[OnName num="unknown"]
"Oh…… Tomoya, right?"
[cpg cn=true]


[OnName num="tomoya"]
"……Hi"
[cpg cn=true]


She was a married woman from the same apartment building...when was the last time that I'd talked to someone?
[cpg]


I don't even know her name. I try to go back to my room right away,
[cpg]


[VOICE f="Erika002"]
[OnName num="unknown"]
"I haven't seen you carrying a bag lately, are you attending your classes?"
[cpg cn=true]


It was a sore topic for me. Lately, the only time I went outside was to get food.
[cpg]


I didn't respond. And as I went back to my room, I thought……
[cpg]


;//■選択肢
[switch]
[case "She was beautiful."]
	[swap]
	[jump target="*select01_1"]
[case "I don't want to see her again."]
	[swap]
	[jump target="*select01_2"]
[endswitch]


1. She was beautiful.
2. I don't want to see her again.


;//==============================
;//１、綺麗な人だった

*select01_1|The neighbor's wife


She was a beautiful person. She was even kind enough to worry about me, so why was I spending my days in such a pathetic manner?
[cpg]


The others living here might already know that I've become a shut-in.
[cpg]

[stflag Cha1flg = 1]

;//絵梨香が候補に

[jump target="*select01_3"]

;//==============================
;//２、もうあの人とは会いたくない

*select01_2|The neighbor's wife


…… I wouldn't want to see her again if I could avoid her.
[cpg]


After all, I don't want them to know that I'm a shut-in. Thinking so, I went back to my room.
[cpg]


;//==============================

*select01_3|The neighbor's wife

[SE f="se001"]
;//【ＳＥ】『ドア閉まる』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


She was much older and probably married. I felt somewhat intimidated by her.
[cpg]


I would fall into self-loathing. But once a fear is planted, it tends to flourish.
[cpg]


I decided that I'd spend the rest of the day as usual. Playing games and watching anime……
[cpg]

[jump storage="ep001.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
