
;//==============================
;//全てのヒロインが候補になっていない場合

*start|Anxiety about the Future

*lost_halem|Anxiety about the Future

[SCENE id=11]

I felt a little anxious.
[cpg]


I was becoming afraid of ruining their lives.
[cpg]


I couldn't keep this up. I had to stop relying on them all the time.
[cpg]

;#################################################
*Ep011|Anxiety about the Future
;#################################################

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


It didn't take long for my anxieties to get the better of me. Before I knew it, I was back to being a shut-in again.
[cpg]


Relying on them might have given me the courage I needed to return to society.
[cpg]


But this wasn't the right way to do it. I couldn't destroy their lives just to salvage my own.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


I locked myself in my room. One day, Erika knocked on my door.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Erika329"]
[OnName num="erika"]
"……What's wrong? You've been cooped up in your room again lately."
[cpg cn=true]


[OnName num="tomoya"]
"What does it matter? It's not like I'm bothering anyone."
[cpg cn=true]

;//移植のためシーンをカットしています

;//ブラックアウト
[free time=500]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

She forced her way closer to me as I said that.
[cpg]

I know she is trying to cheer me up. But I couldn't accept it.
[cpg]


;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[OnName num="tomoya"]
"You can't do this, Erika. You have a husband."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Erika350"]
[OnName num="erika"]
"......Yeah, I guess you're right."
[cpg cn=true]
[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
Erika backed down rather easily.
[cpg]


[OnName num="tomoya"]
"I'm sorry…..it's not that I don't like you."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Erika351"]
[OnName num="erika"]
"I understand. Don't worry about it."
[cpg cn=true]


What was I trying to do? Keeping them away from me and return to a life of solitude?
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I tell Erika to go back home and go back to my reclusive life.
[cpg]


[SE f="se003"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=2000]


But the bell rings again. Who is it this time?
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


;//俺の部屋を訪れたのは美羽さんだった。相変わらず悩ましい体つきをしている。
Mihane had dropped by to check on me.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mihane306"]
[OnName num="mihane"]
"I hope I didn't scare you with my divorce story."
[cpg cn=true]


[OnName num="tomoya"]
"It did worry me."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mihane307"]
[OnName num="mihane"]
"I'm sorry, it really wasn't as bad as it sounds. You don't have anything to worry about."
[cpg cn=true]


[OnName num="tomoya"]
"……I can't help it. I don't want to destroy your family."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Mihane308"]
[OnName num="mihane"]
"Don't worry, there's no chance he'd ever leave me."
[cpg cn=true]


How can she be so sure? I don't think I'd act the same way if I were her husband.
[cpg]


[OnName num="tomoya"]
"You don't have to do this anymore. I'm just going back to how I was before. That's all."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sMihane013"]
[OnName num="mihane"]
;//「智也くん、もうどうしても社会復帰する気は無いの……？」
"Are you really sure you don't want to come back to society?"
[cpg cn=true]


You could say it all started there. But I couldn't respond.
[cpg]

While felt a little lost as she came on to me.
[cpg]


;//========================================
;//●ＣＧエロ（主人公に迫るヒロイン）ev_42
;//人物１：ヒロイン２
;//服装１：私服（半脱ぎ）
;//人物２：主人公
;//服装２：私服（半脱ぎ）
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_42_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMihane014"]
[OnName num="mihane"]
"Hey......if you go to college, you'll probably get a girlfriend."
[cpg cn=true]


[VOICE f="sMihane015"]
[OnName num="mihane"]
"And with time, you'll be able to make a better relationship than the one you have with us."
[cpg cn=true]


It didn't seem possible, I'd already failed at that part once……
[cpg]

[VOICE f="sMihane016"]
[OnName num="mihane"]
"……"
[cpg cn=true]


Seeing my somber expression, even she starts to feel negative.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[FACE method="change_1" pos="2/3"]
[VOICE f="Mihane331"]
[OnName num="mihane"]
"……You really should go to college, Tomoya."
[cpg cn=true]


[OnName num="tomoya"]
"I don't know……I don't know anymore. What am I even supposed to do?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mihane332"]
[OnName num="mihane"]
"I still think you should go. You might not be able to continue living here……"
[cpg cn=true]


She had a point but I was stuck, frozen with indecision.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[SE f="se031"]
;//【ＳＥ】『携帯電話の着信音』


Then one day I received a phone call from my parents.
[cpg]


It had happened several times before, but I had a really bad feeling about it and was hesitant to answer the phone.
[cpg]


[SE f="se031"]
;//【ＳＥ】『携帯電話の着信音』


I ignored the call, but my phone rang again.
[cpg]


Worried that something had happened, I picked up the phone. Then……
[cpg]


[OnName num="tomoya_mother"]
"Tomoya……! You aren't going to your classes!?"
[cpg cn=true]


[OnName num="tomoya"]
"……That's not true. I'm going."
[cpg cn=true]


[OnName num="tomoya_mother"]
"I got a call from the university! They said you weren't attending your lectures!"
[cpg cn=true]


[OnName num="tomoya"]
"……"
[cpg cn=true]


I knew this day would come. How would I cover it up?
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト


We argued for a while. While I tried to calm my mother down, I tried to get her to keep sending money...
[cpg]


But of course, she wasn't having any of it.
[cpg]


They were cutting me off.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


The next day, I felt sick from all the stress.
[cpg]


What should I do? What was going on with the rent? Did they end the contract?
[cpg]


Either way, they think I can't live without the money they sent me.
[cpg]


And they were right. I have a little bit of money saved up but it wouldn't last long.
[cpg]


This was as far as I could go, I'd have to go back home.
[cpg]


Was this the end of my harem?
[cpg]


No, it can't end yet. I had to think of something...
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sachie354"]
[OnName num="sachie"]
"That's……big news. Are you okay?"
[cpg cn=true]


[OnName num="tomoya"]
"I'm fine. I have a plan."
[cpg cn=true]


I decided to tell Sachie, Erika and Mihane the truth.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mihane333"]
[OnName num="mihane"]
"You say you have a plan, but you need money, don't you?"
[cpg cn=true]


[OnName num="tomoya"]
"I've decided to start working part-time. You don't need to worry."
[cpg cn=true]


[FACE method="shake_7" pos="1/3"]
[VOICE f="Erika352"]
[OnName num="erika"]
"But you had trouble even going to college..."
[cpg cn=true]


That was true. It was hard for a social recluse to suddenly start working.
[cpg]


But I didn't have any other options. I needed money.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]

I immediately applied for a part-time job at the convenience store I always went to.
[cpg]


I passed the interview. I guess they thought that since I was young, I'd be able to learn the job quickly.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


And so, on the first day of my part-time job.
[cpg]


I failed to learn anything and I couldn't even handle the bare minimum of customer service.
[cpg]


I was constantly being scolded. Even the customers got angry with me.
[cpg]


I broke on the first day. I quit as soon as my shift ended.
[cpg]


It was going to be hard to go there to buy food now. My world had become even smaller than it was before.
[cpg]


I walked around in a daze. If the rent is deducted from my account, I won't even be able to buy food.
[cpg]


I wrack my brain, trying to find a solution but I can't come up with any good ideas.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************


[FACE method="bow_7" pos="2/3"]
[VOICE f="Sachie355"]
[OnName num="sachie"]
"I see. That's what I thought."
[cpg cn=true]


[OnName num="tomoya"]
"I'm not sure what I'm going to do. I can't do something soon, I won't be able to see you anymore……"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sachie356"]
[OnName num="sachie"]
"If you're that worried, why don't you talk to Erika about it?"
[cpg cn=true]


At first I had no idea what Sachie was talking about.
[cpg]


But gradually I understood. Sachie was thinking of something outrageous.
[cpg]


It didn't seem like a bad idea.
[cpg]


I could live at Erika's place…….
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sachie357"]
[OnName num="sachie"]
"I don't want you to leave either. Unfortunately, all I can offer you are some ideas."
[cpg cn=true]

;//移植のためシーンをカットしています


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト


It was reassuring. And it seems I was a little bolder than I'd thought.
[cpg]

Fortunately, my parents still seem to be paying for my rent and utilities……
[cpg]


But not being able to buy food was an issue. I guess they thought they could corner me by refusing to send me money for living expenses.
[cpg]


On the other hand, they might be willing to drop it if I can earn that part by myself.
[cpg]


If that's the case, then……
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************


[OnName num="tomoya"]
"……Please let me stay with you until your husband returns."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Erika353"]
[OnName num="erika"]
"Oh, that's not a bad idea at all. I'm glad you thought of me."
[cpg cn=true]


I didn't tell her that it was originally Sachie's proposal.
[cpg]


If anything, she was probably the one who'd put the idea in Sachie's head.
[cpg]


[OnName num="tomoya"]
"So……"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Erika354"]
[OnName num="erika"]
"I'm fine with it. It'll be nice to have you around until my husband comes back."
[cpg cn=true]


[OnName num="tomoya"]
"Thank you."
[cpg cn=true]


I replied cheerfully, but I was confident that she would be okay with it.
[cpg]


I knew Erika well enough, but I also thought she might have guided Sachie into suggesting I live with her.
[cpg]


If that's the case, Erika had done an impressive job of manipulating us……
[cpg]


[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************


From there, I began living together with a married woman.
[cpg]


I knew her husband was away for work, but this felt...unreal.
[cpg]


I mean, the meals I was eating were bought with the money her husband earned...
[cpg]


What would you call this situation……was I a gigolo?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Erika355"]
[OnName num="erika"]
"I made stew, let's eat while it's still hot."
[cpg cn=true]


[OnName num="tomoya"]
"Yes, thank you……."
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************


And at night, I sleep on the same futon as Erika.
[cpg]


Bedding that her husband originally bought for them to sleep together.
[cpg]


It's unbelievable, but I was thankful all the same...
[cpg]

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=3000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************


Since I started living with her, I have come to understand her daily routine.
[cpg]


She started vegetable gardening lately and seems to have really devoted a lot of time into learning it.
[cpg]


She's taught me a lot of things I didn't know, like how to distribute fertilizer.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Erika356"]
[OnName num="erika"]
"I have a lot of free time since I'm alone. Sometimes I take lessons or classes for things I'm interested in."
[cpg cn=true]


[OnName num="tomoya"]
"I didn't know that."
[cpg cn=true]


I guess housewives had a lot of free time when their husbands were away.
[cpg]

[FADEOUTBGM]
[SE f="se003"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=2000]


[free time=1000]


The doorbell rings, interrupting my thoughts.
[cpg]


[VOICE f="Erika357"]
[OnName num="erika"]
"Yes, yes, just a moment, please……Oh, hi."
[cpg cn=true]


[BGM f="bg_ad"]
[WAIT time=100]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[WAIT time=1500]

[VOICE f="Sachie379"]
[OnName num="sachie"]
"Hi, I'm here."
[cpg cn=true]


Sachie came to Erika's place.
[cpg]


I mean, of course she knows I'm here.
[cpg]

[FACE method="shake_1" pos="4/5"]
[VOICE f="Sachie380"]
[OnName num="sachie"]
"The rules are still in place, right? I hope you're okay with sharing, even if he's living with you."
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Erika358"]
[OnName num="erika"]
"Of course, the more the merrier."
[cpg cn=true]


It seems this harem has taken itself to a new level without my realizing it……
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se003"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=2000]


The doorbell rings again.
[cpg]


I could guess who it was.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************




[VOICE f="sMihane017"]
[OnName num="mihane"]
"……Oh, am I interrupting something?"
[cpg cn=true]



[FACE method="bow_2" pos="3/3"]
[VOICE f="sSachie036"]
[OnName num="sachie"]
"We were just talking about how sharing was caring."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Mihane335"]
[OnName num="mihane"]
"I hope you're ready, Tomoya. There's nowhere to run now."
[cpg cn=true]


It seems that living with Erika came with a caveat.
[cpg]


There was nowhere for me to hide. If they wanted me, I didn't have the option of refusing.
[cpg]


[OnName num="tomoya"]
"…..I won't run away."
[cpg cn=true]


[FACE method="bow_2" pos="1/3"]
[VOICE f="sErika022"]
[OnName num="erika"]
"That's what I like to hear."
[cpg cn=true]


I guess this crazy situation will continue for a while longer.
[cpg]


This was what I wanted……
[cpg]


But sometimes I wonder if this was really the right thing to do.
[cpg]

;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]

At night, the two went home. Naturally, Erika and I ended up alone together.
[cpg]


;//【ＢＧ】『ヒロイン１の部屋』（夜）******************************************************



[OnName num="tomoya"]
"…..Thanks for cooking."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Erika377"]
[OnName num="erika"]
"Sure, eat up."
[cpg cn=true]


Fried shrimp, salad and miso soup. I'd spent so long eating nothing but junk food.
[cpg]


I filled my stomach, wondering all the while if all of this was okay.
[cpg]


[OnName num="tomoya"]
"Are you sure this is okay, Erika?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Erika378"]
[OnName num="erika"]
"What? I'm totally fine with it."
[cpg cn=true]


[OnName num="tomoya"]
"Yes, right…… maybe."
[cpg cn=true]


Maybe it's going to be fine. I wasn't a shut-in anymore, I was something else...
[cpg]


It was such a strange situation to be in. What was I...a leech? A pet?
[cpg]


[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I had a harem of married women who poured their affection into me. Erika's husband didn't seem like he was coming home anytime soon.
[cpg]


I was starting to enjoy this strange coziness.
[cpg]


Maybe this was fine. Maybe this was how things were meant to be. Erika certainly didn't seem to mind.
[cpg]


It's hard to find stability when the situation is so absurd, but……
[cpg]


[VOICE f="Erika379"]
[OnName num="erika"]
"Zzzz……"
[cpg cn=true]


She is sleeping next to me. Seeing her sleeping face, I realized that I am happy.
[cpg]


;//ＥＮＤ：ハーレムエンド２
[SCENE id=16]

[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


