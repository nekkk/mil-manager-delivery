
*start|Actions to Collect Evidence

;#################################################
*Ep005|Actions to collect evidence
;#################################################

[SCENE id=5]


;//ＢＫ
;//(Y):流用
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Aki010"]
[OnName num="aki"]
Tohmi-kun?"
[cpg cn=true]

Those words woke me up. I fell asleep in class.
[cpg]

[OnName num="takuma"]
'Huh ...... er, what was it ......?
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Aki011"]
[OnName num="aki"]
I've been really bad lately.
[cpg cn=true]

[OnName num="takuma"]
"Yes, ......."
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

[OnName num="kouya"]
What's wrong with you?　You look like a shell.
[cpg cn=true]

[OnName num="takuma"]
Maybe. ......
[cpg cn=true]

;//(Y):以下追加

[OnName num="takuma"]
I ate 17 eggs yesterday.
[cpg cn=true]

[OnName num="kouya"]
What?
[cpg cn=true]

[OnName num="takuma"]
The video. I was supposed to eat 80 eggs, but I couldn't sleep because of the ...... stomach upset and nausea."
[cpg cn=true]

Koya made sure no one was around and opened his phone. He is watching a video channel that we share.
[cpg]

[OnName num="kouya"]
.......
[cpg cn=true]

;//(Y):以下一部だけ流用

[OnName num="kouya"]
What's up?　Got a girlfriend?
[cpg cn=true]

[OnName num="takuma"]
'......, how do you know?'
[cpg cn=true]

Was I acting that weird?
[cpg]

[OnName num="kouya"]
I was like, "You guessed right. How can you have a girlfriend when you dumped him? What's she like?
[cpg cn=true]

What, was he setting a trap for me? ...... but he'd find out sooner or later.
[cpg]

[OnName num="takuma"]
I wonder if she's older .......
[cpg cn=true]

[OnName num="kouya"]
I'm sure. Maybe a married woman?
[cpg cn=true]

[OnName num="takuma"]
How do you know?
[cpg cn=true]

[OnName num="kouya"]
You guessed right!　If he hears that, he'll cry.
[cpg cn=true]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_00_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

We were talking like idiots. Koya wanted to hear more about it, so we went to his house.
[cpg]

;//(Y):以下は使い回しですが時間がずれてるかもなので注意してください

[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の家＿リビング』（夕方）******************************************************

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sanae010"]
[OnName num="sanae"]
"Oh, my God, welcome. You haven't been here lately, I've missed you.
[cpg cn=true]

[OnName num="takuma"]
'...... Ojamase.'
[cpg cn=true]

I was no longer as nervous about Mr. Sakuranae as I had been before.
[cpg]

Maybe I'm getting a little less romantic.
[cpg]

Either that, or I'm getting used to being around women. It's either one or the other.
[cpg]

[OnName num="kouya"]
I'm not interested in greetings. Let me hear all about it.
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

He asked me in depth in Kouya's room.
[cpg]

;//(Y):一部使い回し・変更

[OnName num="kouya"]
"Wow. ......, that's spectacular. I wouldn't have done that if I were you.
[cpg cn=true]

;//(Y)童貞の語があったのでカット

[OnName num="kouya"]
"Did you think about it, that the police might work better ......?
[cpg cn=true]

[OnName num="takuma"]
"Of course I thought about it. I did think about it.
[cpg cn=true]

[OnName num="takuma"]
His only stronghold is his reputation. That's why you have to attack him. ......
[cpg cn=true]

[OnName num="kouya"]
"Well, don't keep it to yourself," he said. I understand your plan to set it ablaze. If it spreads, he'll be in the shit.
[cpg cn=true]

[OnName num="kouya"]
But if I thought you were a bad guy, you're for real.
[cpg cn=true]

Come to think of it, Koya is a very accurate judge of people.
[cpg]

[OnName num="takuma"]
I'm thinking of doing a video project where I go and ask people for their real names. I'm going to do it.
[cpg cn=true]

[OnName num="kouya"]
I heard you mention it a few days ago. Had you asked him about it?
[cpg cn=true]

[OnName num="takuma"]
He was actually busy with his schedule, so he turned me down. But now that final should be over.
[cpg cn=true]

I had an inkling. He had missed the final. The telecast would be in a few days.
[cpg]

[OnName num="kouya"]
Don't take it easy on yourself, either," he said. We're a pair. Let me have some of that.
[cpg cn=true]

[OnName num="takuma"]
Thank you, Koya.
[cpg cn=true]

[OnName num="takuma"]
Do you need eggs?　About 50 eggs.
[cpg cn=true]

[OnName num="kouya"]
You're a hard sell!　I'm here.
[cpg cn=true]

I checked my smartphone. The channel's audience had grown with eggs. It seems I've got a petite buzz.
[cpg]

In my honest opinion, I don't think there's anything spectacular about egg dunking. .......
[cpg]

--I thought - and then I thought ....... I was buzzed about as a "slacker who prepares 80 eggs and eats only 17.
[cpg]

I didn't want to get buzzed like this. It was almost a stigma.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

On my way to the school, I was pointed at by a group of kindergartners in the neighborhood. They were on their way to a field trip.
[cpg]

[OnName num="kindergarten_child_A"]
Oh, it's the egg moggler!　It's the egg moggler!
[cpg cn=true]

[OnName num="accompanying_teacher"]
"Korra!　Pointing a finger at someone is a form of "shushing!　Excuse me!
[cpg cn=true]

[OnName num="takuma"]
"No problem."
[cpg cn=true]

I feel itchy, thinking how cute ...... is. I realized I had a growing audience.
[cpg]

[OnName num="kindergarten_child_B"]
'Cackle!　Egg munching!　Mr. Left of the Gieselbach Division!"
[cpg cn=true]

[OnName num="kindergarten_child_C"]
That was fun!　What are you going to do next?
[cpg cn=true]

[OnName num="kindergarten_child_D"]
Next time, we'll try again for 80 eggs.
[cpg cn=true]

I ran away. It's not always good to be a buzzkill.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

After school.
[cpg]

Me and Koya were in front of Shiho's house ......, in other words, Dobasaki's house.
[cpg]

[OnName num="kouya"]
I was wondering, "Is your capacity okay?　The sunlight is a little strong. How's the camera?
[cpg cn=true]

[OnName num="takuma"]
"It's fine. If we have to reshoot, they won't reschedule.
[cpg cn=true]

My mouth was dry. Finally, I met him in person.
[cpg]

[OnName num="kouya"]
"Uh-uh. ...... actually, I'm a little sensitive to sunlight.
[cpg cn=true]

Are you okay with that? ...... I rang the chime.
[cpg]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=1100]

[OnName num="dobazaki"]
"Yes, this is Iizuka. This is Iizuka. You must be Tohmi-kun. I heard from Shiho. About the video?
[cpg cn=true]

[OnName num="takuma"]
Yes. Yes.
[cpg cn=true]

[OnName num="dobazaki"]
I'm leaving now."
[cpg cn=true]

And then - he came out.
[cpg]

;(Y)//立ち絵の初出し。

[OnName num="dobazaki"]
He came out. ......
[cpg cn=true]

[OnName num="dobazaki"]
Your clothes look dusty.
[cpg cn=true]

[OnName num="takuma"]
Oh, yes. Oh, yes. Sorry.
[cpg cn=true]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（昼）******************************************************

Then we had a brief discussion about the video.
[cpg]

Koya was almost silent. Shiho-san doesn't seem to be at home. She might be out of the house.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[OnName num="takuma"]
He said, "Hi!　I'm Takuma, on the left of the Gieselbach section!
[cpg cn=true]

[OnName num="kouya"]
This is Koya, on the right!
[cpg cn=true]

[OnName num="takuma"]
"Today, you know!　I asked celebrities their real names. ......
[cpg cn=true]

I think. I don't really like people in the TV culture.
[cpg]

I think that the world of celebrities is created separately from the world we live in, and they don't come down to our side.
[cpg]

[OnName num="takuma"]
Well then!　I'll get right to it!　I wonder if I will be able to get his real name out of him!
[cpg cn=true]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=1000]

[OnName num="takuma"]
I'm sorry!
[cpg cn=true]

[OnName num="dobazaki"]
"Yes, I'm Dobazaki Gorongoro. I'm Dobazaki Gorogoro!
[cpg cn=true]

[OnName num="takuma"]
Thank you very much!　Today, I would like to ask your real name, Mr. Dobazaki Gorongoro.
[cpg cn=true]

[OnName num="dobazaki"]
"My name is Ren Iisoku."
[cpg cn=true]

[OnName num="kouya"]
What?
[cpg cn=true]

I waited. I wanted 'tame' for that one. Even if you suddenly swooped in with your real name like that, it would still be .......
[cpg]

I can't tell you. No, I can't tell you. I can't tell you that. I'll just have to make a video of this.
[cpg]

[OnName num="dobazaki"]
"Is this okay?　When you make the video, you can cut and paste it over there on your own.
[cpg cn=true]

[OnName num="dobazaki"]
"In this case, the people on the show will make it up as they go along."
[cpg cn=true]

[OnName num="takuma"]
"Oh, yes, I understand ....... I'll do it.
[cpg cn=true]

[OnName num="dobazaki"]
We don't have time. We don't have enough time.
[cpg cn=true]

[OnName num="dobazaki"]
Unlike you guys, I'm a big seller.
[cpg cn=true]

[OnName num="kouya"]
Aah!
[cpg cn=true]

[OnName num="dobazaki"]
Oh, no!　Wait a minute!　There's hair on my suit.
[cpg cn=true]

[OnName num="dobazaki"]
I knew it. You're gonna have to reshoot.
[cpg cn=true]

[OnName num="dobazaki"]
"Yeah!　And I'm going to advertise the show at the end. I'm not going to get any profit out of this.
[cpg cn=true]

Ugh... ....... He is a selfish guy.
[cpg]

Koya beside him, the light was gone from his eyes. He had eyes of darkness. Patience.
[cpg]

And. At that time.
[cpg]

[OnName num="rabbit"]
"Kyu~"
[cpg cn=true]

A cute little rabbit was leaning on the fence of the house, looking at me.
[cpg]

[OnName num="dobazaki"]
"What the ......?
[cpg cn=true]

[OnName num="kouya"]
?　Rabbit ......?
[cpg cn=true]

[OnName num="rabbit"]
Kyuu~, Kyuu, Kyuuu~"
[cpg cn=true]

Eh, what a development. The rabbit is munching on weeds growing from the fence.
[cpg]

[OnName num="takuma"]
'Ka, cute ......?
[cpg cn=true]

[OnName num="dobazaki"]
"Oh, no, that's not good.
[cpg cn=true]

[OnName num="dobazaki"]
That creature that got mixed up in our luggage on the Guyana Highlands Undercover Survival Project!
[cpg cn=true]

At that moment, the earth shook.
[cpg]

The rabbit made a crackling sound and transformed.
[cpg]

It transformed into a huge, hairless monster more than 17 meters long. It became a fleshy, red, grotesque monster ......!
[cpg]

It wriggled its six tentacles of flesh and turned into a huge mass that seemed to devour the heavens--and roared.
[cpg]

[OnName num="monster"]
"Gooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo!!!!"
[cpg cn=true]


;//(Y)ここでドバ崎の「絶望」顔を使ってもいいかもしれません

[OnName num="dobazaki"]
Noooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo!
[cpg cn=true]

[OnName num="kouya"]
Run!　Takuma ah!　He was mimicking me!
[cpg cn=true]

[OnName num="takuma"]
Aaahhhh!
[cpg cn=true]

[OnName num="dobazaki"]
If only I'd gone through the quarantine station, none of this would have happened!"
[cpg cn=true]

Entangled in the monster's writhing tentacles, Dobasaki was thrown up into the air.
[cpg]

[window target=false]
[transition target={true} rule="giin3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="giin3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="giin3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="giin3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（昼）******************************************************

He is swung around. Screams go up from the surrounding houses.
[cpg]


[window target=false]
[transition target={true} rule="giin3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="giin3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="giin3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="giin3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[OnName num="kouya"]
Takuma!　Did you shoot that?
[cpg cn=true]

[OnName num="takuma"]
I did!　We've got to get out of here first!
[cpg cn=true]

[SE f="se012"]
;//【ＳＥ】『走る』

;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

We got a genuine buzz with this video.
[cpg]

The Self-Defense Forces, police, the prime minister's office, and the Internet news were in a frenzy, and alarms were blaring from smartphones.
[cpg]

Helicopters flew overhead, trucks loaded with carrots appeared one after another, and we spent a few days like that.
[cpg]



[window target=false]
[transition target={true} rule="uzmaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzmaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Later that evening.
[cpg]

[window target=false]
[transition target={true} rule="uzmaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzmaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[OnName num="takuma"]
"Wow, ...... is getting a lot of viewers!"
[cpg cn=true]

I thought to myself. If I continue to be so popular, I might not even be able to meet with Shiho-san.
[cpg]

;//(Y)以下流用

Today is Saturday and tomorrow is also a holiday. I immediately started to ask Shiho on social networking sites.
[cpg]

In other words, "Would you like to go on a date tomorrow?" That's it. It would be a disaster if my family found out. ......
[cpg]

It's something that happens only in very low probability.
[cpg]

[SE f="se005"]
;//【ＳＥ】『携帯電話の振動音』
[WAIT time=1000]

After a while, I got a reply.
[cpg]

...... In short, they said yes. But I guess he must have hesitated for a while.
[cpg]

;//(Y)2行カット

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep006.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
