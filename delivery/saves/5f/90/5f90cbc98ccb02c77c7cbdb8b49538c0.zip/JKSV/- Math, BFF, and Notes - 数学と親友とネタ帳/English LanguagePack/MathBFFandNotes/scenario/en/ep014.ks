
*start|Date at the end of remedial classes

;#################################################
*Ep014|Date at the end of remedial classes
;#################################################

[SCENE id=14]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************

It is Monday, a national holiday. Today is the end of the long repair work.
[cpg]

I am deeply moved. I didn't think I would understand so much. While I was thinking .......
[cpg]

The teacher who was writing on the board seemed to drop his chalk.
[cpg]

;//========================================
;//●ＣＧ非エロ（目の見ている方向を下にし、服を着せてください）ev_43）
;//人物１：ヒロイン３
;//服装１：スーツ
;//場所　：学校
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_43_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sAki044"]
[OnName num="aki"]
"Aah!"
[cpg cn=true]

The teacher crouched down unintentionally. I was watching from behind.
[cpg]

[OnName num="takuma"]
"......!
[cpg cn=true]

[VOICE f="sAki045"]
[OnName num="aki"]
Oh, is that ......?　Where are you going?
[cpg cn=true]

Her ass is wiggling in front of my eyes. I was blushing.
[cpg]

[VOICE f="sAki046"]
[OnName num="aki"]
Under the desk ...... kuuuuuuh."
[cpg cn=true]

[VOICE f="sAki047"]
[OnName num="aki"]
I'm sorry, I'm sorry, I'm sorry to show you the embarrassing part ...... I can reach it in a little while.
[cpg cn=true]

[OnName num="takuma"]
"......, yes, I'll get it!　I'll get it."
[cpg cn=true]

I couldn't resist and took the chalk from under the desk to the teacher.
[cpg]

It's a reward for me,.......
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

The class went on. Around 11 a.m., I told him about my video channel.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sAki048"]
[OnName num="aki"]
She says, "Wow. ...... such a hobby."
[cpg cn=true]

[OnName num="dobazaki"]
I finally tracked it down!"
[cpg cn=true]

Dobasaki and his TV-watching partner entered the classroom. ...... Eh!
[cpg]

Don't tell me you extended that confession in broad daylight to make the teacher laugh ......?
[cpg]

The teacher was retreating like crazy.
[cpg]

[OnName num="dobazaki"]
'Look at my laugh!　Tokieda!　...... hmm?　You are Tohmi. You were the one taking the class?"
[cpg cn=true]

[OnName num="partner"]
Dobasaki: "Not good, Dobasaki!　I stopped you, didn't I?
[cpg cn=true]

[OnName num="dobazaki"]
Shut up!　I'll do a trick!
[cpg cn=true]

--This is a push for laughter.
[cpg]

After Dobasaki and his partner had said a few words, Dobasaki did his trick.
[cpg]

[OnName num="dobazaki"]
I'm faster than the train!"
[cpg cn=true]

He was rolling around the classroom on his side, bouncing around. The floor was banging.
[cpg]

[OnName num="partner"]
"Oh my gosh!　What am I supposed to do!"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sAki049"]
[OnName num="aki"]
'That's so boring.'
[cpg cn=true]

I froze.
[cpg]

;//========================================
;//●ＣＧ非エロ（横に主人公とヒキ気味の相方）ev_35）
;//人物１：ヒロイン３
;//服装１：スーツ
;//場所　：学校
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

The teacher kicked Dobasaki in the leg and held him down as he still tried to do the rolling trick.
[cpg]

The teacher's eyes were cold.
[cpg]

;//「生徒の前なので、あまりはしたない事はしたくないんですけど。動かないでください」
[VOICE f="sAki050"]
[OnName num="aki"]
I don't want to do anything too immodest," he said. Please don't move.
[cpg cn=true]

[OnName num="dobazaki"]
"Hahi-hi!
[cpg cn=true]

[OnName num="partner"]
I told you!　You're somehow-- no, you're doing something wrong!
[cpg cn=true]

[OnName num="partner"]
You grow up by suffering and accepting hard truths, right?　It's normal for me to be rejected!
[cpg cn=true]

[OnName num="dobazaki"]
"Ugh, ugh!　How can I have you ......?　Laugh at me!
[cpg cn=true]

[VOICE f="sAki051"]
[OnName num="aki"]
Where is the teacher who laughs when someone disrupts class?
[cpg cn=true]

[VOICE f="sAki052"]
[OnName num="aki"]
'What eyes did the loud ...... teacher turn on you in class? I wish you could remember."
[cpg cn=true]

I envy Dobasaki who gets ...... kicked in the foot a bit.
[cpg]

[OnName num="dobazaki"]
"And ...... far-sighted. Help me."
[cpg cn=true]

[OnName num="partner"]
"Do you know each other?　You.
[cpg cn=true]

[OnName num="takuma"]
......
[cpg cn=true]

[OnName num="takuma"]
I don't know you.
[cpg cn=true]

[OnName num="dobazaki"]
"Toomieeeeeeeeee!?"
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

Graduation from a teacher named Dobasaki came sooner than expected.
[cpg]

He was re-arrested on the charge of trespassing - entering the school without an outsider's permission.
[cpg]

Sorry. No promise to mention his name in the video. Dobasaki. Your teachings will live on strong in me.
[cpg]

His partner was not charged with a crime because he was only forced to do so. Poor partner. ......
[cpg]

;//ＢＫ

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

We are now going to the cafe as promised. It's an oversized pudding parfait.
[cpg]

The teacher seemed more in a good mood than offended. Is that what happens when you kick a man in the foot? I'm in love.
[cpg]

;//(Y)流用。一部編集

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Aki199"]
[OnName num="aki"]
I said to him, "......, I'm sorry for keeping you waiting. Shall we go then?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Aki200"]
[OnName num="aki"]
What have you told your parents?
[cpg cn=true]

[OnName num="takuma"]
"I told them I'm going to play with my friends. So I'll be fine for the whole day.
[cpg cn=true]

But still, I didn't realize Tokieda-sensei's casual clothes were like this.
[cpg]

[OnName num="takuma"]
Is it a disguise, by any chance?
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Aki201"]
[OnName num="aki"]
He said, "That's what I meant, more or less. It would be a big problem if another student found out.
[cpg cn=true]

I shouldn't be amused, but it is amusing. I shouldn't be amused, but it is amusing.
[cpg]

;//(Y)新規追加

[FACE method="bow_2" pos="2/3"]
[VOICE f="sAki053"]
[OnName num="aki"]
"It's a reward for the remedial work. A date."
[cpg cn=true]

Oh, you're not aware that I confessed ......?　She smiles mischievously. It's quite mischievous.
[cpg]

;//(Y)場所移動の感覚を出すために一度踏切前を挟みます

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『踏み切り前』（夕方）******************************************************

;//(Y)流用。

;//(Y)元音声を切って下さい

[FACE method="change_1" pos="2/3"]
[VOICE f="sAki054"]
[OnName num="aki"]
Is this your first date?
[cpg cn=true]

It's a lot of firsts. If you put it that way, it's the first time I've been on a date.
[cpg]

I was sure she didn't know that I had never had a girlfriend before.
[cpg]

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

I enjoyed the oversized pudding parfait. The strong and bitter café au lait was also delicious.
[cpg]

[OnName num="takuma"]
It's also good. ...... is very sweet, but the bitterness of the coffee balances it out."
[cpg cn=true]

The custard is not too thick. It is rather light.
[cpg]


But when the caramel is involved, the "tenderness" of the egg comes sweetly and gently, and before you know it, you are craving coffee.
[cpg]

Then, when you drink the bitter coffee, it disappears, and you find yourself craving that sweetness... and so on.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sAki055"]
[OnName num="aki"]
I thought it tasted like love. Every parfait store is different and interesting.
[cpg cn=true]

Love, huh? I think I understand. Once you know the taste, you can't stop.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（夕方）******************************************************

He drives me home and picks me up. I'm a teacher, so they drop me off a little ways from my house.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

The car stopped on the shoulder of the road. I got out. The teacher got out and just stood there.
[cpg]

;//(Y)流用。一部編集

[OnName num="takuma"]
He said, "By the way, it's really rare to see a teacher in his own clothes. I'll have to keep it in my memory.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Aki247"]
[OnName num="aki"]
He said, "You don't have to say that. You see, your parents will be worried if you don't go home.
[cpg cn=true]

[OnName num="takuma"]
I wanted to tell you that I was going to stay over today. But I guess it can't be helped if it's not convenient for the teacher. ......
[cpg cn=true]

[OnName num="takuma"]
See you later.
[cpg cn=true]

;//(Y)流用。一部編集

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

The path home eventually merged with the same school route. ...... I staggered along the school route in the evening.
[cpg]

I should have at least made an appointment for the next one. Perhaps this might be the end of the private lessons.
[cpg]

I don't want ...... to end at such a halfway point.
[cpg]

In a way, I wish I could say it's over, but I still have a lot of things I want to do with my teacher.
[cpg]

;//(Y)新規追加

[OnName num="takuma"]
I had a lot of fun .......
[cpg cn=true]

[OnName num="takuma"]
I thought it was going to be a hell of a remedial session."
[cpg cn=true]

I wonder if Sensei will watch the video?　In the meantime, after sharing Dobasaki's teachings, Koya has also raised a lot of questions.
[cpg]

From now on, normal classes are coming. There are other students. They won't be able to teach me individually.
[cpg]

;//(Y)流用。1行カット

My head wanders. I have no sense of reality.
[cpg]

Is this the end?　So abrupt?　But it all makes sense.
[cpg]

I know, I just can't admit it to myself.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『部室』（夕方）******************************************************

Three days later. Club room.
[cpg]

I was meeting up with Koya and solving math problems when I couldn't come up with any ideas.
[cpg]

[OnName num="male_student_A"]
I asked him, "Hey, Tomi, what the hell happened in that repair work. ......
[cpg cn=true]

[OnName num="takuma"]
I started to understand what I didn't understand. Math is fun.
[cpg cn=true]

[OnName num="male_student_B"]
I'm really impressed with your teacher. I've heard that he teaches very well.
[cpg cn=true]

Yes, that's right. Tokieda-sensei is amazing.
[cpg]

Then, Koya came in.
[cpg]

;//(Y)流用。

[OnName num="kouya"]
"Did you do it? You did?
[cpg cn=true]

[OnName num="takuma"]
What are you talking about?
[cpg cn=true]

I was asked by Koya when he came back. How should I answer?
[cpg]

;//(Y)新規追加

[OnName num="takuma"]
I found out during the remedial period--you can't push laughter.
[cpg cn=true]

[OnName num="takuma"]
'Between classes and such, the teacher wants to go home and is busy.'
[cpg cn=true]

[OnName num="takuma"]
So there's only one time when you can showcase your laughter in the most natural way.
[cpg cn=true]

[OnName num="kouya"]
What do you mean?
[cpg cn=true]

[OnName num="takuma"]
We're going to perform at the school festival.
[cpg cn=true]

[OnName num="takuma"]
I liked what you came up with. I think it's better if we don't take it out of context. Let's go with that one.
[cpg cn=true]

I finished the math problem. The festival was only about a month away.
[cpg]

[OnName num="takuma"]
Let's practice. From now until the festival."
[cpg cn=true]

;//ＢＫ

There was hope. I was still stuck in the aftermath of the remedial work, so I started practicing again for the next hope.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

In the morning. On the way to school. I guessed she had come back because of the arrest of ...... Dobasaki. Shiho was there.
[cpg]

;//(Y)流用。

[FACE method="bow_2" pos="2/3"]
[VOICE f="Shiho391"]
[OnName num="shiho"]
Good morning. You are in a good mood today, too.
[cpg cn=true]

[OnName num="takuma"]
Yes, well. I have someone I like.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Shiho392"]
[OnName num="shiho"]
I see, you have a girlfriend.
[cpg cn=true]

[OnName num="takuma"]
......It's not exactly a girlfriend, but it's something like that.
[cpg cn=true]

With such conversation, I left the house.
[cpg]

;//(Y)ほとんど新規。冒頭1行だけ流用

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************

The morning classes were over and it was lunch break. The teacher is also on lunch break during this time.
[cpg]

[OnName num="takuma"]
"......I hope you'll do the remedial work again,......."
[cpg cn=true]

Studying comedy was tougher than I had expected. That's what happens when you really put your mind to it.
[cpg]

There is no limit to how far you can push yourself.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]

And then the days went by--the day of the festival arrived.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『部室』（昼）******************************************************

[SE f="se027"]
;//【ＳＥ】『喧噪』

[OnName num="takuma"]
The day of the festival arrived!　We are the "Gieselbach part"!
[cpg cn=true]

Koiya and I performed our own material.
[cpg]

Teachers could be seen here and there, and Tokieda-sensei was watching us. Even Ms. Sakuranae was there.
[cpg]

[OnName num="kouya"]
"Burst water pipes are very popular, aren't they?
[cpg cn=true]

[OnName num="takuma"]
That's the topic of conversation when you're in trouble!
[cpg cn=true]

I'm not used to doing comedy with other people, but I'm going to do what I can.
[cpg]

[OnName num="takuma"]
I'm not used to comedy with other people, but I'll do what I can!　Someone decipher it!
[cpg cn=true]

[OnName num="kouya"]
"The result of the decipherment is 'cod roe crawling on the ground.
[cpg cn=true]

[OnName num="takuma"]
"Is it possible that the result of the decipherment is like a cipher again?　I don't know what the string is.
[cpg cn=true]

[OnName num="male_student_A"]
"Damn ......."
[cpg cn=true]

[OnName num="female_student_A"]
"......!　......!
[cpg cn=true]

[OnName num="takuma"]
"Oh, my God!　Mentaiko is moving!
[cpg cn=true]

[OnName num="kouya"]
Actually, it was me... the "crawling cod roe"!
[cpg cn=true]

[OnName num="takuma"]
"Dying message, you said the culprit properly, didn't you?　That's why you wrote it in code!
[cpg cn=true]

[OnName num="male_student_B"]
Ha-ha-ha!"
[cpg cn=true]

[OnName num="female_student_B"]
Aha-ha-ha!"
[cpg cn=true]

Mr. Sanae was laughing. Tokie-sensei was not laughing.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の洗面所』（夜）******************************************************

[OnName num="takuma"]
'...... frustrating.'
[cpg cn=true]

I looked in the mirror and repeated my sometime funny face. However, I didn't feel like speaking out loud.
[cpg]

The thought of it was making me depressed. Weren't we funny?　I escaped to fiddle with my smartphone.
[cpg]

;//========================================
;//●ＣＧ非エロ（スマートフォンの一般的なホーム画面）ev_51_0　再度流用
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

I searched for the name of the school and found that our video had been posted on social networking sites.
[cpg]

Dobasaki's teachings were, in fact, helpful. Thanks to that, the response was positive. What is the response on the internet at ......?
[cpg]

I get a message from Koya.
[cpg]

[OnName num="kouya"]
<I didn't think you were an ...... ice man to not laugh at that. I was so confident.
[cpg cn=true]

[OnName num="takuma"]
I'm a little scared of that guy too."
[cpg cn=true]

He tweeted. He tries to remember how ...... he could make that person laugh.
[cpg]

[OnName num="kouya"]
<You said Dobasaki was arrested. Also>
[cpg cn=true]

[OnName num="kouya"]
<Perhaps if that guy didn't barge in and perform a normal story right in front of him, that guy wouldn't have laughed>.
[cpg cn=true]

[OnName num="takuma"]
I'm sure ...... it's from frustration?
[cpg cn=true]

;//(Y)お笑いで先生を直接的に笑わせようというアプローチは最初から間違っていて、先生が笑う条件は「普通の事を普通にやると先生が笑う＝授業で話に耳を傾けてちゃんと聞く　とか」です。答えはもう示してある（でも耕哉の推測「恋の成就には違うのでは？」でちょっと間違った）

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I wonder if it's because of the setback?　My math grades began to drop. I was back to being a problem child.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]

On such a holiday, I headed to the clubroom when my advisory teacher told me to help clean up after the festival. I saw Ms. Tokieda on the way to .......
[cpg]

;//【ＢＧ】『学園教室』（朝）******************************************************

;//(Y)流用

[FACE method="change_7" pos="2/3"]
[VOICE f="sAki056"]
[OnName num="aki"]
"When you are a teacher at a school, you have to work on your days off too."
[cpg cn=true]

Is that so? I thought, but the silence was indescribable. It was a silence in which we both seemed to be thinking the same thing.
[cpg]

;//(Y)新規追加

--I have winter break. I was wishing I could have that private tutoring session again.
[cpg]

I'm about to graduate.
[cpg]

;//(Y)流用

[OnName num="takuma"]
I was thinking, "...... sensei, is this the end for us?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sAki057"]
[OnName num="aki"]
It's up to you, isn't it?　It's not up to me.
[cpg cn=true]

[OnName num="takuma"]
I'm an adult, but it's not good to put the responsibility on a child.
[cpg cn=true]

The teacher takes out his cell phone. And ......
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sAki058"]
[OnName num="aki"]
Let's exchange numbers. We can meet on your days off when you are available.
[cpg cn=true]

[OnName num="takuma"]
He says, "Yes. ......"
[cpg cn=true]

That's bolder than I thought. A teacher and a student exchanging cell phone numbers is a pretty bad thing.
[cpg]

;//(Y)新規追加

[FACE method="change_2" pos="2/3"]
[VOICE f="sAki059"]
[OnName num="aki"]
"......Thank you for the confession you made to me."
[cpg cn=true]

[OnName num="takuma"]
What?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sAki060"]
[OnName num="aki"]
I mean thank you for liking me.
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="sAki061"]
[OnName num="aki"]
I'm glad to hear you say that. I can't go out with him, but that's the way it is.
[cpg cn=true]


;//(Y)流用

[OnName num="takuma"]
"Sir, the other day you told me about the  website. The other day, that ......
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sAki062"]
[OnName num="aki"]
I know. I forgot about it, too.
[cpg cn=true]

[OnName num="takuma"]
It's not that. I've fallen in love with you even more since then.
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

Ms. Tokieda is getting impatient. He seems wary of being seen telling students he likes them.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sAki063"]
[OnName num="aki"]
He said, "...... is not a good place for this. Let's change the place.
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

And so to the student guidance office. I don't think it's that easy to use this room.
[cpg]

But I guess they can give me any reason, like my extremely poor classroom attitude.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sAki064"]
[OnName num="aki"]
What should I do?　How can I get you to give up on me?
[cpg cn=true]


;//(Y)新規追加

[OnName num="takuma"]
I can't give up on you. You are a wonderful person.
[cpg cn=true]

[OnName num="takuma"]
Wasn't my gag at the school festival funny?
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

The teacher looked surprised.
[cpg]

[OnName num="takuma"]
"I was nearby when you were arguing with Dobasaki of ...... sometime ago. It's my way to school there."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

The teacher looked up to the heavens as if satisfied. Then he mumbled regretfully and looked embarrassed.
[cpg]

;//(Y)ここで離婚の部分が共有されるので、この二人は心情として、ここより後で恋愛について前向きに話し合うことができるようになる（ここが踏まえられていないと「この先生はなんで浮気に前向きなんだろう」とプレイヤーは感じてしまう）

[FACE method="bow_4" pos="2/3"]
[VOICE f="sAki065"]
[OnName num="aki"]
If you're ......, you can also ...... discuss divorce agreements."
[cpg cn=true]

[OnName num="takuma"]
Yes."
[cpg cn=true]

;//(Y)流用

[FACE method="shake_4" pos="2/3"]
[VOICE f="sAki066"]
[OnName num="aki"]
'You have no more timidity, ...... huh?
[cpg cn=true]

Sighs the teacher. Then he said.
[cpg]

;//(Y)新規追加

[FACE method="change_3" pos="2/3"]
[VOICE f="sAki067"]
[OnName num="aki"]
"Get your grades up.
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="sAki068"]
[OnName num="aki"]
And become a teacher."
[cpg cn=true]

[OnName num="takuma"]
Nah!"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="sAki069"]
[OnName num="aki"]
It's no good because you are a student and a teacher. You understand, don't you? Then go to .......
[cpg cn=true]

[OnName num="takuma"]
......
[cpg cn=true]

--That's what they want me to do, get my teaching license.
[cpg]

I wasn't going for an education degree now. I'm going to have to change my path.
[cpg]

[OnName num="takuma"]
I'm going to change my career path. ...... teacher-teacher relationship."
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]

Tokieda-sensei nodded quietly. He didn't say anything else.
[cpg]

But - yes, that's right. Yes, that's right. It all makes sense now that I think about it. Tokieda-sensei smiled once.
[cpg]

It was when my grades in math improved. He was able to do 'normal things, normal hard work.
[cpg]

;//(Y)セピア色にして回想にしてください

;//========================================
;//●ＣＧ非エロ（教員机か、主人公の目の前の机を挟んだ前に座らせてください）ev_38_0　再度流用
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BG f="b_ev_38.ui" time=1000]
[WAIT time=1000]
[window target=true]

[VOICE f="sAki070"]
[OnName num="aki"]
Honestly, I was impressed.
[cpg cn=true]

[VOICE f="sAki071"]
[OnName num="aki"]
I'm doing it because I'm taking it seriously. I try to understand what I don't understand.
[cpg cn=true]


;//(Y)セピア色終了

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep015.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
