
*start|Settlement

;#################################################
*Ep011|Settlement
;#################################################

[SCENE id=11]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

Perhaps because the academy and the university are on the same site, teaching practice, tours, and workshops are assigned early on.
[cpg]

I observed a class in a somewhat familiar place, similar to my own classroom. It's a different classroom by fire. ......
[cpg]

Ms. Tokieda by my side. Yes, I am going to be a math teacher.
[cpg]

[FG f="CHA03_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sAki012"]
[OnName num="aki"]
"...... I didn't think you'd be able to improve your math skills so rapidly just by being away from my class. ......"
[cpg cn=true]

She looked somewhat frustrated. But she wasn't surprised.
[cpg]

I was a problem child,......, wasn't I?
[cpg]

;//(Y)グラフィック要望に追加してあります。詳しくはそちらをご覧ください。

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（夕方）******************************************************

I was walking home. The area was crowded with people.
[cpg]

[OnName num="takuma"]
It's going to snow .......
[cpg cn=true]

Sleet was drizzling and wetting the asphalt.
[cpg]

I saw a businessman waiting for the signal with a cake box. Yes, that's right. Today is Christmas Eve.
[cpg]

[OnName num="takuma"]
Gotta do my math review, ......."
[cpg cn=true]

I don't think I have a good foundation yet. My grades were poor to begin with, so I was worried that I needed to go back and lay the groundwork.
[cpg]

The railroad crossing opens and the flow of people begins to move. Behind me, I heard a squeal.
[cpg]

[FADEOUTBGM]

There was that car.
[cpg]

[OnName num="kouya"]
"Hey!
[cpg cn=true]

[OnName num="takuma"]
Hey!
[cpg cn=true]

[SE f="se000"]
;//【ＳＥ】　ジャンプ

I jumped to the side.
[cpg]

[SE f="se048"]
;//【ＳＥ】　破壊音
[WAIT time=1000]

The car had crashed into a building.
[cpg]

[BGM f="bg_pi"]
[WAIT time=100]

;//[SE f="se000"]
;//【ＳＥ】　悲鳴

Someone had dropped a muffler. Stone chips hit the asphalt. My closed umbrella fell off and was kicked around.
[cpg]

[OnName num="male_student_A"]
"Oh my God!"
[cpg cn=true]

[OnName num="male_student_B"]
'Accident...... wrong, how could you run into a building here......!
[cpg cn=true]

A bang sounded. My hair was torn off. The nails peeled off from the fingers that were raised unintentionally.
[cpg]

Koya has a gun of his own making.
[cpg]

[OnName num="takuma"]
You,......, I knew you were back there.
[cpg cn=true]

[OnName num="kouya"]
I'm here to kill you!　Takuma aaaaaaah!
[cpg cn=true]

I ran toward the railroad crossing. I put my hand in my bag. I was holding the engine starter from inside it.
[cpg]

I was just sad. I mumbled to myself, though I'm sure he couldn't hear me.
[cpg]

[OnName num="takuma"]
'You're back ...... with Mr. Sakuranae.
[cpg cn=true]

[OnName num="takuma"]
I just wanted to see that house, that man.
[cpg cn=true]

[OnName num="kouya"]
"Die!　Go away!"
[cpg cn=true]

I crossed the railroad crossing. I heard a car start to move and gradually increase its speed.
[cpg]

I no longer felt guilty. I hit the engine starter. It was illegally modified.
[cpg]

[OnName num="kouya"]
I don't care anymore!　All I want is for you to go away. ......
[cpg cn=true]

[OnName num="kouya"]
What?
[cpg cn=true]

I turned around. The car slowed and plodded on. The car's engine was off.
[cpg]

[SE f="se055"]
;//【ＳＥ】　電車の音。　ぷおおん

The railroad crossing closed. In the middle of it, Koya's car was parked.
[cpg]

[SE f="se056"]
;//【ＳＥ】『射撃』
[WAIT time=1000]

He fired his homemade gun at me with a bang, bang, bang. It grazed my cheek. At this distance, it doesn't hit me.
[cpg]

[OnName num="takuma"]
You ...... are."
[cpg cn=true]

Koya pulls out his car keys and nearly drops them from his hand. I could see his hands shaking even from here.
[cpg]

[OnName num="takuma"]
I loved you, Mr. Sakuranae. I loved your husband, too. Even me."
[cpg cn=true]

[OnName num="kouya"]
"Aa......aahh!　Aaahhhh!
[cpg cn=true]

[SE f="se055"]
;//【ＳＥ】　電車の音。　ぷおおん

I pressed the disproportionately large switch attached to the back of the engine starter.
[cpg]

Koya put his hand on the door and tried to get out. The door locked.
[cpg]

Screaming, scattered people suddenly saw the car trapped inside the crossing. A train approached.
[cpg]

People's eyes change from fear to pity for the fate of "him".
[cpg]

Fear, no doubt. But it's happening to someone else, and even curiosity is beginning to enter the mix. Koya screams out in grief.
[cpg]

[OnName num="takuma"]
I loved you too, Koya.
[cpg cn=true]

[SE f="se054"]
;//【ＳＥ】　電車の音　破砕音
[WAIT time=1000]

;//画面シェイク

A train ran over a car.
[cpg]

;//(Y)ここの暗転で長めに時間とってください。余韻

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『踏み切り前』（夜）******************************************************

;//(Y)ここのモノローグは長いですがシーンがシーンなので保つと思います

That car was on fire. The train, its entire surface slightly dented, has come to a stop a little further back.
[cpg]

The nearest station staff, police, and firefighters were everywhere. The train doors were opened and people were getting off the tracks.
[cpg]

Onlookers also gathered. Some with smart phones, some taking pictures, but no one taking video.
[cpg]

How many times have you been to these accident scenes?　...... When they see a scene like this, many are hesitant to take a video.
[cpg]

I looked for a suitable building.
[cpg]

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ラブホテル室内』（夜）******************************************************

;//(Y)修正指示のあった箇所です。ラブホテルの背景画像を自分は見ていないのですが、画像によっては「怪しい内装のホテル」とか書いた方が違和感がないかもしれません。画像が一面のピンク！　だったりした場合、ただ「ホテル」だと気になると思うので……

A hotel. But there was no one there but me. I started to disassemble the engine starter.
[cpg]

I took it apart at random and put the small parts into a bag.
[cpg]

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（夜）******************************************************

After throwing it into the river, I returned.
[cpg]

The police were scattered around the perimeter, at least 20 meters away from the center of the accident. No-entry tags were placed at the scene.
[cpg]

[OnName num="policeman_A"]
The man in the car was chasing me!　That guy in the car was chasing you, wasn't he?
[cpg cn=true]

[OnName num="takuma"]
"......"
[cpg cn=true]

[OnName num="policeman_B"]
The perimeter has been closed off, but I was wondering if you could explain the situation to me. You can come in."
[cpg cn=true]

;//捜査は、桜苗さんと出会った交通事故や、学校と比べてひっそりとしていた。
The investigation site was quiet compared to the traffic accident and the school where I once met Ms. Sakurana.
[cpg]

However, they would probably talk to Ms. Sakurana. It was heartbreaking and honest.
[cpg]

[OnName num="takuma"]
''We had a dispute over the distribution of ...... earnings.''
[cpg cn=true]

[OnName num="policeman_A"]
Eh?"
[cpg cn=true]

[OnName num="takuma"]
'I don't know for what reason he came after me. Me and that guy were taking video.
[cpg cn=true]

[OnName num="policeman_A"]
"Oh. That kind of ......."
[cpg cn=true]

[OnName num="takuma"]
Maybe he was holding a grudge over money.
[cpg cn=true]

That's a lie.
[cpg]

[OnName num="takuma"]
"......"
[cpg cn=true]

[OnName num="takuma"]
"May I see the car?"
[cpg cn=true]

;//ＢＫ

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（夜）******************************************************

The car was on fire, and inside it was something I didn't want to see, but I had to.
[cpg]

The consequences of my sins. Something I had fought for and defeated. Something that was once my friend.
[cpg]

[OnName num="policeman_A"]
Are you sure you're okay to look at these things ......?"
[cpg cn=true]

[OnName num="policeman_B"]
"The new guy was throwing up. You're pretty solid for a college kid. ......
[cpg cn=true]

[OnName num="takuma"]
I was prepared for this to happen.
[cpg cn=true]

[OnName num="takuma"]
Please leave me alone for a while."
[cpg cn=true]

The police went away. I stood there for a while.
[cpg]

--The fight was over.
[cpg]

I loved yakisoba bread. We did stupid things together. We got into a real tussle over earnings, a couple of times.
[cpg]

The sticker he put on the game controller at home is stuck on it.
[cpg]

[OnName num="takuma"]
"Koya ......"
[cpg cn=true]

I wish he hadn't ripped off the videos - I really liked his gags the best.
[cpg]

[OnName num="kouya"]
U......A......
[cpg cn=true]

Koya's body twitched.
[cpg]

[OnName num="kouya"]
I was so shocked.
[cpg cn=true]

I jerked back. The gravel on the tracks made a noise.
[cpg]

In the back, the train's headlights flashed. Like a black-and-white horror movie, it revealed the image of a man covered in burning, stinking blood.
[cpg]

He is alive.
[cpg]

[OnName num="kouya"]
Why ...... mother ......?"
[cpg cn=true]

[OnName num="kouya"]
It hurts,...... and it hurts,.......
[cpg cn=true]

I wanted to scream.
[cpg]

I felt the guilt coming back. There were police around. I continued my quiet battle to stifle my voice.
[cpg]

Here was a child.
[cpg]

[OnName num="kouya"]
"...... someone ...... help me ......"
[cpg cn=true]

[OnName num="kouya"]
I'm cold. ......
[cpg cn=true]

I found myself touching Koya's hand. The hand was burnt, blackened, and dripping with blood.
[cpg]

I hugged Koya. I didn't care if my whole body was dirty.
[cpg]

[OnName num="takuma"]
I'm sorry.
[cpg cn=true]

[OnName num="kouya"]
"Mom ......, Dad ......"
[cpg cn=true]

[OnName num="takuma"]
I'm sorry.
[cpg cn=true]

[OnName num="kouya"]
Someone ....... One of us ...... no ......."
[cpg cn=true]

Koya didn't know I was here after all.
[cpg]

The burnt hand crumbled. It was like a badly made toy. No blood flowed.
[cpg]

He was disappearing.
[cpg]

[OnName num="kouya"]
Nothing. ......
[cpg cn=true]

[OnName num="kouya"]
Invisible ......
[cpg cn=true]

[OnName num="takuma"]
"......"
[cpg cn=true]

I was at my limit. I got up and walked out of nowhere.
[cpg]

I passed a police officer. They looked at me but said nothing. What kind of face am I making now?
[cpg]

I am crying now. Where should I go? I didn't want to go home. Not even to Mr. Sakuranae's house.
[cpg]

[OnName num="takuma"]
I would not become the Reverend Dimmesdale.
[cpg cn=true]

;//(Y)いちおう。「忌々しい」が耕哉に対する哀れみの部分を代弁し、殺してしまった自分への嫌悪などを一語で表しています。複雑な心情を表現できた箇所のはずなので編集したり、消したりは避けていただけると……。

I headed for the hotel. ......Yes, that's right. You used it to take that damned machine apart. ......
[cpg]

[OnName num="takuma"]
"Good-bye," he said.
[cpg cn=true]

;//(Y)いちおう。「生きてたら」は、生きているわけないのはわかりきってるので……

[window target=false]
[free time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]

[OnName num="takuma"]
If you're alive, let's shoot another video."
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="amamori1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]


Ms. Sakurana's husband came back from Hungary. Mr. Sakuranao informed me that the funeral would be with his family.
[cpg]

I guess they think I am irrelevant. To be honest, I felt like I wanted to be cursed by Mr. Sakuranao.
[cpg]

After her husband left, I helped her with shopping, operating the computer, and registering the license for the image editing software.
[cpg]

The baby in my belly grew up.
[cpg]

;//(Y)流用

[window target=false]
[free time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の家＿リビング』（昼）******************************************************

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sanae332"]
[OnName num="sanae"]
'...... here again?　Is the school alright?
[cpg cn=true]

;//(Y)追加

[OnName num="takuma"]
It's not a school, it's a university. I think I went there just a few days ago.
[cpg cn=true]

--I was with Kouya.
[cpg]

There was a dark shadow on Ms. Sakuranae's face. She acted like she didn't want to show it in front of me, but I knew everything.
[cpg]

My sin - the abyss into which I had decided to fall. It was right in front of me in the form of Ms. Sakurana.
[cpg]

I am sure that the child I am carrying in my belly will be the same.
[cpg]

;//(Y)戻って流用

[OnName num="takuma"]
I'm sure you'll be fine. When I leave work early, I come to see you without a doubt.
[cpg cn=true]

[OnName num="takuma"]
I've never skipped work for any other reason.
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

;//(Y)カット流用

The day that Sakuranae was going to give birth, I was not in the mood for it.
[cpg]

But I can't do anything. I can't go to the hospital.
[cpg]

So I didn't get to meet her baby until much later.
[cpg]

[free time=1000]
[BG f="b_00_2.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

When I finally met her, I felt more like I had done it than like I thought it was cute.
[cpg]

I had really become a father. I was feeling that way.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の家＿リビング』（昼）******************************************************

[OnName num="aika_daughter"]
"Daa, daa,......
[cpg cn=true]

Ms. Sakuranae's daughter. I was there to see my daughter. And to see Sakurana-san herself, I had come to her house.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="sanae_husband"]
I was so impressed by her daughter's personality. Maybe you have the wrong brother?"
[cpg cn=true]

[OnName num="takuma"]
'How about ......?'
[cpg cn=true]

It's hard to answer. I'm not very good at him.
[cpg]

[OnName num="aika_daughter"]
"PAPA ......"
[cpg cn=true]

Sanae's daughter, Koya's sister, walked toward me and said so.
[cpg]

[OnName num="sanae_husband"]
Did you just call me Dad?　Daddy is over here, ha ha ha."
[cpg cn=true]

I couldn't help but laugh.
[cpg]

[FACE method="change_2" pos="2/3"]
I couldn't laugh, but I couldn't help smiling at her.
[cpg]

I wonder if this is the right thing to do; Sanae's husband is unaware of the truth.
[cpg]

;//(Y)ここからは新規

And about Kouya.
[cpg]

I still wasn't sure how to mention that guy's name. I still feel like I'm treading on thin ice every time I talk about it.
[cpg]

Mr. Sakuranae was trying to fight. I think I gave her a hard fate.
[cpg]

Then I have to do more than that - I have to carry Mr. Sakuranae's burden.
[cpg]

[OnName num="takuma"]
I'm going to support her. I'm going to support you.
[cpg cn=true]

[OnName num="sanae_husband"]
What?
[cpg cn=true]

[OnName num="takuma"]
You have to be happy.
[cpg cn=true]

[OnName num="sanae_husband"]
You don't have to go that far!
[cpg cn=true]

I mentioned Koya unintentionally ...... but he flushed it down the drain. Maybe he is really a nice guy.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

October. The cultural festival that was cancelled last year due to a fire takes place at the university that Koya attended.
[cpg]

Mr. Sakuranae will play the viola.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『踏み切り前』（朝）******************************************************

I have to go through that railroad crossing. I have to pass through that railroad crossing, and on this day of the festival, I have to do it again.
[cpg]

[OnName num="female_student_A"]
Everyone says it was a shame last year, but honestly, it was a lot easier now that the preparation is gone. ......
[cpg cn=true]

[OnName num="female_student_B"]
I know the viola player from last year is going to be there, right?　He said he was late for rehearsal."
[cpg cn=true]

[OnName num="female_student_A"]
He was late for rehearsal. ......, the student who died.
[cpg cn=true]

[OnName num="female_student_B"]
Yeah.
[cpg cn=true]

[OnName num="female_student_B"]
It's kind of scary."
[cpg cn=true]

....... I'm not scared.
[cpg]

Sakura Nae is stronger than I feared. ......
[cpg]

;//========================================
;//●ＣＧ非エロ（ヴィオラを演奏する桜苗。完全新規）ev_52_0）
;//人物１：ヒロイン２
;//服装１：正装。露出少なめ。ただし喪服にも見えるような黒系。
;//人物２：選曲がビオラ・ソロではない場合、他の楽器を弾く男たちも

;//場所　：文化祭の音楽ホールか、屋外広場
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_52_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//(Y)ここで前の自動車事故の現場でも流した、ビオラのクラシック。ビオラ・ソロでない楽曲を流すのなら、その時点でも登場している楽器屋の男たちもいらなくなります。シナリオ上のその部分の行を削ってください。

The performance began.
[cpg]

The men who were at the scene of the horrific accident rushed to see her again today.
[cpg]

Mr. Sakurana's tone is beautiful and sad. Within the sound was the sorrow of that man.
[cpg]

The venue was filled with the audience.
[cpg]

[OnName num="takuma"]
"...... I'm..."
[cpg cn=true]

The students who had been making noise around the venue were now quiet without a word.
[cpg]

A group of parents and their children, who had shown up to tour the university, simply stood and stared at the musicians, motionless.
[cpg]

A female student beside me glanced around, took out a tissue, and began to wipe away her tears.
[cpg]

I noticed that the student in front of me was doing the same.
[cpg]

[OnName num="takuma"]
I'm going to be evil."
[cpg cn=true]

[OnName num="takuma"]
I'm not going to get anyone else involved in some half-assed way.
[cpg cn=true]

[OnName num="takuma"]
I won't even think about being forgiven for my sins."
[cpg cn=true]

All of the anguish that was caged in the sound also contained a great deal of joy.
[cpg]

Immediately, the students around us filled the room with sobs.
[cpg]

Some took out their handkerchiefs. There were sighs, sobs, and tears dripping down somewhere.
[cpg]

I was the only one among them who did not cry.
[cpg]

[SCENE id=17]

;//ＥＮＤ：ヒロイン２ルート
[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
