
*start|Become a teacher and get married

;#################################################
*Ep015|Become a teacher and get hitched
;#################################################

[SCENE id=15]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I no longer needed remediation. I continued my lonely battle at my study desk.
[cpg]

I started working on math again - well, not just math this time. English, chemistry.
[cpg]

[OnName num="takuma"]
I'm going to be a teacher.
[cpg cn=true]

[OnName num="takuma"]
I wondered why adults took up kids' time so easily. ......
[cpg cn=true]

The academy doesn't care if we students agree, they bind us in the classroom.
[cpg]

But what if I myself find a reason to study?　I can happily be bound and gagged.
[cpg]

Maybe, surprisingly, people like me are looking for chains deep down inside.
[cpg]

Sometimes, showing someone the right answer gets them moving. Sometimes it's a directive that gets you moving. Such a signpost was love for me.
[cpg]

Not bad.
[cpg]

;//(Y)お笑いで先生を笑わせるアプローチへの決別をいったん書かねばなりません。短いけども必要なのでカットできない箇所のはず

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『部室』（昼）******************************************************

I left the club. Ostensibly, it was because I started studying for the entrance exam, so everyone around me understood me.
[cpg]

I had lost faith in the power of comedy.
[cpg]

--I had a bad temperament, I guess.　When I got down to it, "Let's make people laugh," it seemed like a pushy sales pitch. ......
[cpg]

;//(Y)受験勉強の重みを書きます
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Winter is here. It was snowing, and even on a night like this, I could hear the laughter of children having a snowball fight.
[cpg]

I went to my study desk. My textbook was spread out, and the notebook beside me was covered in eraser shavings.
[cpg]

[OnName num="sakura_mother"]
Yes, tea. I'm beginning to understand why you like tea.
[cpg cn=true]

[OnName num="takuma"]
Thank you.
[cpg cn=true]

[OnName num="sakura_mother"]
But why are you so eager to study so hard ...... when the exams are coming up?
[cpg cn=true]

[OnName num="takuma"]
It happens."
[cpg cn=true]

My mother left. I picked up the nock pen again. My fingers hurt. My head hurts too. But I have to do it.
[cpg]

[OnName num="takuma"]
English is interesting, too. It's like an all-round subject that requires memory, but also reading comprehension and listening familiarity?"
[cpg cn=true]

[OnName num="takuma"]
"But Jenny here, she's touring New York City on a bus, isn't she?"
[cpg cn=true]

I dreamed. Me and my teacher on a date. The setting was New York City in the early morning. We were walking through the snow.
[cpg]

I bought a bag for the teacher and on the way home...... the teacher almost falls. I support him. ......
[cpg]

[OnName num="takuma"]
"Ha ha ha. It may be a ...... creepy fantasy, but I'd like to make it a reality. ......"
[cpg cn=true]

I silently moved the nock pen. More and more the lead was worn away and less and less paper was left.
[cpg]

Does this count as a page from your youth?　You can find out more about studying for the exams you'll be fighting alone at .......
[cpg]

I--I think it counts.
[cpg]

Learning things is fun in itself. I'm learning through this study that lonely battles are fun.
[cpg]

Maybe it doesn't even matter if I'm in love anymore. No one is forcing me to do this. Let's go as far as we can go.
[cpg]

;//(Y)1月の想定なので日の沈みは早い？　夕方で一応指定


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

[OnName num="teacher"]
"Hey, Toomi. Come here.
[cpg cn=true]

[OnName num="takuma"]
Yes, sir.
[cpg cn=true]

I was called to my classroom by my homeroom teacher. She is a social studies teacher. I was going to pursue a science course, so I had no connection with my homeroom teacher.
[cpg]

[OnName num="male_student_A"]
"What, did he get into trouble ......?"
[cpg cn=true]

[OnName num="male_student_B"]
What did he do during winter break?"
[cpg cn=true]

The homeroom teacher sees this and starts talking quietly.
[cpg]

[OnName num="teacher"]
Your national mock examinations, you're doing very well. ......
[cpg cn=true]

[OnName num="takuma"]
I'm sure you did.
[cpg cn=true]

[OnName num="teacher"]
What's going on?　What the ......?
[cpg cn=true]

I felt like a proud winner. I could clearly see the fear in the teacher's eyes as she looked at me.
[cpg]

[OnName num="teacher"]
What kind of study method did you use?　I teach political philosophy, and I'd like to show my students how to do it. ......
[cpg cn=true]

[OnName num="teacher"]
It's time for exams. I want to make use of it for the younger students, not you guys. I'm sorry, not you.
[cpg cn=true]

[OnName num="takuma"]
No, I don't think I'm talking about how to study. I was just using my time.
[cpg cn=true]

[OnName num="teacher"]
"Well, I see. ...... No. No. That's great. I'm impressed. Appare.
[cpg cn=true]

I went back to my seat. Around me, students were looking at me curiously.
[cpg]

I muttered something to no one in particular.
[cpg]

[OnName num="takuma"]
And I think I may have had a slightly better encounter.
[cpg cn=true]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I had successfully completed the entrance exam. I passed. I was to attend a nearby university that had a department of education.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『部室』（昼）******************************************************

In the club room where I had already left the club, I listened to Koya's joyful excitement. I'm almost like an alumnus. ......
[cpg]

He was excited. And the juniors were celebrating, too.
[cpg]

The setting sun was shining - a page of the school I will never be able to return to. I wanted to remember this sunset.
[cpg]

[SE f="se005"]
;//【ＳＥ】『携帯電話の振動音』
[WAIT time=1000]

[OnName num="takuma"]
Hmm?　Incoming call."
[cpg cn=true]

This time of year, students are allowed to use their smartphones openly.
[cpg]

I'm about to answer the phone - and realize it's an incoming call from my teacher.
[cpg]

[OnName num="takuma"]
It's ......."
[cpg cn=true]

;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I move on in a hurry. I don't want the other students to know we're exchanging phone numbers.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

;//(Y)流用

[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[WAIT time=1000]

[OnName num="takuma"]
Hello? Is there a problem?"
[cpg cn=true]

[VOICE f="Aki269"]
[OnName num="aki"]
Yeah, yeah. Actually, ......, it's hard to say. ......."
[cpg cn=true]

He was not very articulate. I had a bad feeling about this.
[cpg]

[VOICE f="sAki072"]
[OnName num="aki"]
The divorce settlement was off the table.
[cpg cn=true]


;//(Y)新規追加

My eyes widened as if I had been slapped in the face. I felt a sudden thirst in my throat. Now my love affair with the teacher would become adultery.
[cpg]

Just as I was about to get out of the student-teacher relationship. I was trying to achieve a normal love .......
[cpg]

;//(Y)1行流用→2行新規追加→その後は流用
[OnName num="takuma"]
'......What's wrong with that?'
[cpg cn=true]

I explained.
[cpg]

That her husband had recovered financially. And that the doctor's grandmother had suddenly fallen ill and was expected to suffer financially.
[cpg]

I tried my best to help the doctor, but the feeling of ...... swelled up and I had to hold it down.
[cpg]

Money - a problem of something I had no control over - was the next obstacle.
[cpg]

Oh well. I didn't know that was going to happen. Without my knowledge.
[cpg]

I knew this day would come.
[cpg]

The teacher stammers. Of course.
[cpg]

[VOICE f="Aki274"]
[OnName num="aki"]
"I'm sorry for ......, Mr. Tohmi-kun.
[cpg cn=true]

[OnName num="takuma"]
I want to meet and talk with you for the last time. Tomorrow after school, okay?"
[cpg cn=true]

I put the final touches on the conversation like that. The teacher agreed.
[cpg]

;//(Y)流用
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



Then, after school, the teacher came to ....... In an empty after-school classroom.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Aki275"]
[OnName num="aki"]
He said, "......What's the last thing you want to talk about?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aki276"]
[OnName num="aki"]
"I also feel guilty, and I also feel responsible,...... so I'm going to ask you."
[cpg cn=true]

I don't know if I should say it. I'm sure I'll regret it for the rest of my life if I say these words.
[cpg]

[OnName num="takuma"]
I thought, "Please leave your ...... husband and marry me."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

The words that I had been thinking came out so easily. It was a word that came from the heart.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Aki277"]
[OnName num="aki"]
That's ...... such a thing."
[cpg cn=true]

Ms. Tokieda was shaken. But he soon turned serious and said, "I'm sorry, but I can't help it.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Aki278"]
[OnName num="aki"]
I can't do that. I belong to her.
[cpg cn=true]

That's right. That's all right. It was probably a good thing that he refused.
[cpg]

There are some loves that just can't come true, and there are some loves that are happy because they can't come true.
[cpg]

I know that. I know that, but I was so mad.
[cpg]

;//(Y)新規追加

[OnName num="takuma"]
I was trying so hard for you.
[cpg cn=true]

[OnName num="takuma"]
I wanted to be with you."
[cpg cn=true]

I really wanted to be with you. But I know. It was just selfishness on my part.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="sAki073"]
[OnName num="aki"]
I'm sorry. ......
[cpg cn=true]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]

Time passed and I was in deep despair.
[cpg]

;//(Y)流用


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

I found myself graduating from the school. That's really the only way to describe it.
[cpg]

Dry days passed without any contact with teachers. ......
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

After graduating from the school, I finally stopped seeing my teacher.
[cpg]

One year passes since I entered the school. Two years pass. And then, when I was in the third year.
[cpg]

I was just wandering around town. There was no one else there.
[cpg]

I was walking the streets alone. I had a girlfriend by then, but she confessed her feelings to me, and we were just going out.
[cpg]

For me, she was not even a substitute for a teacher.
[cpg]

It's like that. That's why I was alone at that time.
[cpg]

But in the end, I can say that I was glad to be alone.
[cpg]

[OnName num="takuma"]
Ah ......"
[cpg cn=true]

;//========================================
;//●ＣＧ非エロ（街を歩くヒロイン３の家族。ヒロイン３とヒロイン３の夫、二人と手を繋いで歩く娘の後姿。全年齢版と同じです）ev_47
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：ヒロイン３の夫
;//服装２：私服
;//人物３：ヒロイン３の娘
;//服装３：私服
;//場所　：街
;//時間　：昼
;//備考　：娘は三歳くらいのイメージです
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_47_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

The teacher was walking with her daughter.
[cpg]

I can't believe he was passing by this area. What kind of coincidence is that?
[cpg]

I looked at her. I always thought she was your husband's child. ......
[cpg]

;//(Y)唐突に怖いことを言うような印象にするためちょっと編集。願望が出たとわかる

I thought it was my child.
[cpg]

What a coincidence. Was I just being paranoid?
[cpg]

[OnName num="takuma"]
"Ha ha ha ...... funny."
[cpg cn=true]

I feel a dark feeling welling up in me. I can't go to ....... No, no, no, no, no.
[cpg]

I had to wish him well.
[cpg]

I turned around and left without saying a word to the teacher.
[cpg]

;//ＢＫ

;//(Y)ここからはビターエンドになる原文から大きく離れると思います。手間かかりそうですがすいません

;//(Y)セピア色にしてください

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（夕方）******************************************************

[OnName num="dobazaki"]
I turned around and walked away. If everything goes according to plan, it's 'predictable.
[cpg cn=true]

[OnName num="dobazaki"]
You have to make it look like you've created a flow, but then you have to make it 'go off the rails. Suddenly, absurdly.
[cpg cn=true]

[OnName num="dobazaki"]
What is logical can be predicted by logic," he said. The audience can predict logical things by logic. So it crashes as expected for the audience.
[cpg cn=true]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Love was not something he could give up.
[cpg]

My heart ached for a long time. It was painful. I miss that apple pie, that pudding parfait.
[cpg]

I miss my teacher's remedial classes.
[cpg]

[OnName num="takuma"]
If you have a child, you can't fall in love anymore. ......
[cpg cn=true]

In my hand, I have my smartphone. The teacher's phone number is still there.
[cpg]

I was about to graduate from the teaching program. I was already busy. I was just about to enter the workforce - but.
[cpg]


I was about to go off the "normal" path.
[cpg]

[OnName num="takuma"]
Thank you, sir.
[cpg cn=true]

For the first time in years, I opened up the textbooks and notebooks I had used in school.
[cpg]

There, I could still see the notes from the remedial classes that my teacher had taught me.
[cpg]

[OnName num="takuma"]
Thanks to you, I now understand the fun of studying.
[cpg cn=true]

I was about to graduate from college when I started to study.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

I sat down at a table in a cafe. There were two customers in front of me.
[cpg]

[OnName num="kouya"]
......
[cpg cn=true]

[OnName num="dobazaki"]
......
[cpg cn=true]

[OnName num="staff"]
What would you like to order?
[cpg cn=true]

[OnName num="takuma"]
Three extra large pudding parfaits. Three café au lait.
[cpg cn=true]

The waiter backs away.
[cpg]

[OnName num="kouya"]
What a bunch. You called me up from Hungary after all these years."
[cpg cn=true]

[OnName num="kouya"]
The Gieselbach site has been disbanded!
[cpg cn=true]

[OnName num="dobazaki"]
And why did you call me up?　Hey..."
[cpg cn=true]

[OnName num="takuma"]
I'm bringing back the Gieselbach section-- three sections this time.
[cpg cn=true]

[OnName num="takuma"]
If you want a nosebleed, you'll have to get it out of three holes. That's disgusting.
[cpg cn=true]

[OnName num="dobazaki"]
No way!　No way!　I can't go out in the open anymore.
[cpg cn=true]

[OnName num="dobazaki"]
I live in Osaka now. I even have a restraining order against ...... that house.
[cpg cn=true]

[OnName num="takuma"]
Dobasaki is in the back. Dobasaki is in the back. He thinks about video recording and the timing of the laughs. I'm going to use him to the hilt."
[cpg cn=true]

[OnName num="takuma"]
We're going to make the best educational entertainment that makes you laugh and cry."
[cpg cn=true]

[OnName num="kouya"]
"!　...... Takuma. Is it the resurrection ......?"
[cpg cn=true]

;//(Y)ここの「一緒に」は周囲の単語と離すことで強調し、永遠の別れになった桜苗ルートとの対比とするよう意識しています

[OnName num="kouya"]
'Together again. Can we ...... shoot a video?"
[cpg cn=true]

[OnName num="takuma"]
I said yes."
[cpg cn=true]

I opened my smart phone.
[cpg]

;//========================================
;//●ＣＧ非エロ（スマートフォンの一般的なホーム画面）ev_51_0　再度流用
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

The teacher and I had exchanged emails after graduation.
[cpg]

That lovely girl has a certain disease. It is not a serious incurable disease, but she is unable to keep up with the school.
[cpg]

She would go to the hospital regularly and lie in bed with an IV drip.
[cpg]

[OnName num="takuma"]
She says, "I'm at a point in my life where I need to ...... get out of the norm.
[cpg cn=true]

[OnName num="takuma"]
I want to be a clown."
[cpg cn=true]


;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_00_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=1000]

Thinking back, he started studying to make the doctor smile. Even comedy.
[cpg]

What should have been multiple paths that have been there and returned can unexpectedly become one.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

And so, a long time passed - seven or eight years.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『部室』（昼）******************************************************

;//(Y)後輩たちが序盤だけゲーム開始直後のシーンのリフレインをやっているシーン。演出もちょっと意識していただけると助かります

[OnName num="female_student_A"]
Rin, I've got a good idea!　I've got a great idea!
[cpg cn=true]

[OnName num="female_student_B"]
"Hey, Hikari!　Shhh ...... it's study time!"
[cpg cn=true]

This is the club room of the Manzai Club. We're watching a live video feed on the monitor while we study.
[cpg]

[OnName num="female_student_A"]
These two are our graduates, aren't they?
[cpg cn=true]

[OnName num="female_student_C"]
Yes, I heard that another one of them is making the material.
[cpg cn=true]

[OnName num="female_student_B"]
He teaches math and other science subjects in an interesting way, but recently he's been doing a lot of Japanese history.
[cpg cn=true]

[OnName num="female_student_C"]
He's a multi-talented guy.
[cpg cn=true]

[OnName num="female_student_A"]
I bet he studies a lot to make his stories. ......
[cpg cn=true]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_09_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（昼）******************************************************

While waiting for the crossing, a male student stops at a safe place to watch a video.
[cpg]

[SE f="se055"]
;//【ＳＥ】　電車の音。　ぷおおん

[OnName num="male_student"]
'.......'
[cpg cn=true]

[OnName num="male_student"]
"......giggle.............!　......giggle."
[cpg cn=true]

[OnName num="male_student"]
"Oh ...... the railroad crossing was open. ......
[cpg cn=true]

[OnName num="male_student"]
I'm going to be late!"
[cpg cn=true]


;//========================================
;//●ＣＧ非エロ（スマートフォンの一般的なホーム画面）ev_51_0　再度流用
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[OnName num="aki"]
<To Tohmi-kun>
[cpg cn=true]

[OnName num="aki"]
<Thank you. My daughter still goes to the hospital a lot, but she is doing well on her school tests>
[cpg cn=true]

[OnName num="aki"]
<And you've learned a lot about it>
[cpg cn=true]

[OnName num="aki"]
<He said he understood elementary school math because of your videos>.
[cpg cn=true]

At the end of the message, an image file was uploaded.
[cpg]

There, the smiling faces of Dr. Tokieda and his daughter were shown.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ

;//(Y)性の話はできないので愛の話にせざるを得ない全年齢版ではこういうオチでいいかなあという気がします。が、どうだろ……

[SCENE id=18]

;//ＥＮＤ：ヒロイン３ルート
[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
