
*start|School Teacher

;#################################################
*Ep001|School Teacher
;#################################################

[SCENE id=1]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************

[OnName num="male_student_A"]
You don't know what you're talking about. She's just an old woman."
[cpg cn=true]

[OnName num="male_student_B"]
She's not old!　She said that idols are just fine at that age.
[cpg cn=true]

I can hear the conversation in the classroom before the class starts.
[cpg]

I'm talking about liking that guy from Idol or something like that. I can hear how old they are. ......
[cpg]

I'm still not interested in women who are old enough to be called idols.
[cpg]

It seems as if all men except me are pedophiles, but it seems to be the opposite.
[cpg]

Rather, I like older women more than other people. It took me a while to realize this fact.
[cpg]

And there are not as many like-minded people as I thought. I have asked some boys if they are interested in older men.
[cpg]

Most of them answer that they are not interested. And the ones who say they are interested don't like older people as much as I think they do.
[cpg]

I miss not being able to share the same interests.
[cpg]

I think it's strange that men are generally pedophiles and women like older women.
[cpg]

If I could go to the opposite world, I would like to go there. A world full of adult women in the strike zone around my age. ......
[cpg]

I don't know if it's possible. Maybe it's true that a man's attractiveness increases with age.
[cpg]

So, do I have to hold off dating women until I become an uncle......?
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

While I was thinking about this, class started and the lunch break was just about over.
[cpg]

;//========================================
;//●ＣＧ非エロ（ヒロイン３と廊下で出会う。無表情に近い、冷たい顔をしているヒロイン３）ev_06
;//人物１：ヒロイン３
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：学園廊下
;//時間　：昼
;//========================================
[window target=false]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

I almost passed the teacher. She is Aki Tokie.
[cpg]

The guy I confessed to when I was a freshman. There is a considerable age difference and she is already a married woman.
[cpg]

It was a love that was never going to come true, and it was a confession that was never going to work out, but I still tried to go for it.
[cpg]

Of course, the result was a complete failure. She thought I was joking.
[cpg]

I've been feeling awkward towards her ever since, but I'm not sure about the teacher: ......
[cpg]

[VOICE f="Aki001"]
[OnName num="aki"]
"......Toomi-kun?　What are you doing?
[cpg cn=true]

[OnName num="takuma"]
"Oh, um, ......"
[cpg cn=true]

The other side apparently doesn't think anything of it. I guess they've long forgotten about it.
[cpg]

If she's as beautiful as she is, maybe other boys besides me have confessed to her?　I doubt it.
[cpg]

[VOICE f="Aki002"]
[OnName num="aki"]
Class will be starting soon. What if you're late?
[cpg cn=true]

[OnName num="takuma"]
"I'll take care."
[cpg cn=true]

I hurried to the classroom. I didn't want the teacher to think I was an inattentive student.
[cpg]

;//ＢＫ

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

The class is going on and on and on. Boring time is hard to pass, but ......
[cpg]

I feel that the time is a little shorter with Ms. Tokie's class.
[cpg]

By the way, she is a math teacher and I am not good at math.
[cpg]

And maybe I became bad at math because Ms. Tokie is a math teacher.
[cpg]

When I take a class from someone as beautiful as Ms. Tokie, the content doesn't really sink in.
[cpg]

I pay more attention to her voice and her style.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

;//(Y)ちょっと変更・追加してます。

After school. I promised to hang out with Kouya at home.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

Kouya is a good conversationalist. He's got a weird way of looking at people that's very accurate, and his weakness is that he's a habitual storyteller.
[cpg]

We're still distributors to the extent that we're just idiots on the Internet, so we're not required to be professional.
[cpg]

So it's not a problem. We are scum.
[cpg]

I still manage to stop it too. -By the way, there is a reason why I shoot videos with this guy.
[cpg]

He speaks good English. And for some reason, he speaks Hungarian too. He is trilingual.
[cpg]

He can teach my faltering English a little better, so the video will go around the world.
[cpg]

There was another big reason.
[cpg]

The mother of the girl is an incredibly beautiful woman.
[cpg]

Not only is she the mother of one child, but she is the same age as my mother.
[cpg]

Even though she gave birth a little early, her beauty and style were unbelievable.
[cpg]

It was with this ill-intentioned feeling that Koya and I became best friends.
[cpg]

Many boys come to his house to hang out, but I think many of them are there for her.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

Sanae Miyauchi.
[cpg]

She must be beautiful today, too. I thought so as I went over to her house.
[cpg]

;//========================================
;//●ＣＧ非エロ（玄関で出迎えるヒロイン２。微笑んでいる）ev_07
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：ヒロイン２の家＿玄関
;//時間　：夕方
;//========================================

[window target=false]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="Sanae001"]
[OnName num="sanae"]
"Oh, Takuma-kun. You came to visit me again today, didn't you?
[cpg cn=true]

[OnName num="takuma"]
"Yes, I'm ...... sorry to bother you.
[cpg cn=true]

[VOICE f="Sanae002"]
[OnName num="sanae"]
"Do you think she's after me?　No way.
[cpg cn=true]

I cannot deny it. Rather, I am inclined to affirm it.
[cpg]

But now that her child is nearby, I can't say anything like that.
[cpg]

[OnName num="kouya"]
I'm not going to say that," he said. Hey, Takuma.
[cpg cn=true]

[OnName num="takuma"]
"U-Um, um, yes. ......
[cpg cn=true]

I wonder if I'm doing a good job of covering it up. I can hardly say anything.
[cpg]

[VOICE f="Sanae003"]
[OnName num="sanae"]
I can't offer you any hospitality, but take your time.
[cpg cn=true]

I feel that Sakura Nae has a lot of room to grow, as she says she has a child after all.
[cpg]

She is very receptive or ...... this may not be what a man would want from a woman.
[cpg]

But she's a really nice person.
[cpg]

[window target=false]
[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の家＿リビング』（夕方）******************************************************

[OnName num="kouya"]
I've got a new one. I bought a new one."
[cpg cn=true]

[OnName num="takuma"]
What's new?　A game?
[cpg cn=true]

[OnName num="kouya"]
A movie. You wanna watch it?
[cpg cn=true]

[OnName num="takuma"]
"Yeah. You're going to ...... now?　We'll miss dinner.
[cpg cn=true]

[OnName num="kouya"]
Don't say that. I couldn't go to the cinema with two guys, but it was really interesting.
[cpg cn=true]

;//(Y)追加
[OnName num="kouya"]
It's a good way to learn about movies. The other day there was a lot of grotesqueries. The other night was so grotesque that I couldn't eat meat anymore.
[cpg cn=true]

The other day, I couldn't eat meat anymore. I hope this trait is inherited from Ms. Sakuranae.
[cpg]

[OnName num="kouya"]
I'll lend you the movie so you can watch it when you have time.
[cpg cn=true]

[OnName num="takuma"]
"Yeah, okay."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sanae004"]
[OnName num="sanae"]
I hope that this characteristic is inherited from Mr. Sakuranae. I can't believe that Kojiya has such a friend.
[cpg cn=true]

[OnName num="kouya"]
What's wrong with having friends?
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Sanae005"]
[OnName num="sanae"]
I'm not. Then, Takuma, take your time.
[cpg cn=true]

[OnName num="takuma"]
"Oh, yes, I'll be at ...... taking my time."
[cpg cn=true]

[free time=1000]
With him I can talk without being nervous. In front of Mr. Sakuranae, I get too nervous.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

So I ended up watching the movie halfway through and left the screening at a point where I was really curious to see the rest of the film.
[cpg]

I ended up lending the movie to her, but I can't wait to have dinner and watch the rest of the movie.
[cpg]

But I also want to talk to Mr. Sakuranae. ......
[cpg]

With this conflict in my mind, I decided to leave right away.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

On my way home, I met Shiho. She was carrying a supermarket bag in her hand.
[cpg]

[OnName num="takuma"]
I was so excited to see her. Are you on your way home from shopping?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Shiho003"]
[OnName num="shiho"]
'Yes, I am, but ...... where's Takuma-kun?
[cpg cn=true]

[OnName num="takuma"]
He was visiting his friend's house."
[cpg cn=true]

I saw Shiho-san carrying a heavy bag in both hands, and I thought I would help her a little.
[cpg]

We are neighbors, so of course we are going home in the same direction.
[cpg]

[OnName num="takuma"]
I'll carry it too. Shiho-san.
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Shiho004"]
[OnName num="shiho"]
"No problem. I'm fine. ......huff
[cpg cn=true]

Shiho changed the way she was holding the bag while saying, "huff".
[cpg]

It is still heavy. I'll force myself to take care of it. ......
[cpg]

[OnName num="takuma"]
I'll hold on to it. It's a little far from here.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Shiho005"]
[OnName num="shiho"]
I'm sorry.　Thank you ...... sorry.
[cpg cn=true]

So I got a bag. It was so heavy that even a man like me would have a hard time holding it with one hand.
[cpg]

;//(Y)追加

And. When I bent down, I could almost see the inside of her skirt. I thought I saw a scar on her thigh.
[cpg]

I hurriedly looked away. It's not good. ...... but what's the scar now?
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sShiho017"]
[OnName num="shiho"]
I'll hold this one because it's got cherry tomatoes and eggs in it.
[cpg cn=true]

[OnName num="takuma"]
Ah, yes!"
[cpg cn=true]

The word that came out of the mouth of the cherry tomatoes ...... Shiho. The sound is cute. I was inwardly thrilled.
[cpg]

I thought being a housewife was great, I guess I'm used to having luggage.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Shiho006"]
[OnName num="shiho"]
I'm not good at it, but I'm not good at it either. It's not good.
[cpg cn=true]

;//(Y)旦那の設定変更により変更

[OnName num="takuma"]
She seemed busy, didn't she? I wonder how many programs you are going to appear on. Mr. Dobasaki.
[cpg cn=true]

The show I saw at the manzai club was a while ago. If you go back to the filming, it was even earlier.
[cpg]

Only the finals would be held at the end of the year, close to New Year's. There was still time before then. There is still time before then.
[cpg]

During this period, the show seems to steadily gain popularity at local university festivals and shopping malls.
[cpg]

[OnName num="takuma"]
Last time I was in a tournament to participate in a New Year's Day special, where is it now ......?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Shiho007"]
[OnName num="shiho"]
Hokkaido. Hokkaido, that's far away, isn't it?
[cpg cn=true]

I'd have to cross the ocean to say it's far away. ......
[cpg]

[OnName num="takuma"]
You don't miss me?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Shiho008"]
[OnName num="shiho"]
I'll miss you, but that's all I can do. I'm an adult, so I know what I'm talking about.
[cpg cn=true]

Carrying two heavy bags, we headed for home.
[cpg]

The expression on Shiho's face is shadowy. I wish I could do something to make her smile, but ......
[cpg]

;//(Y)追加

[FACE method="change_7" pos="2/3"]

I thought being the wife of a comedian would be a fun life, but apparently not.
[cpg]

I have adored Shiho-san since the bullying incident.
[cpg]

I couldn't get her out of my mind, so when I moved out, I asked my parents for a place--"I want to be next to Ms. Iizoku!" .
[cpg]

That was how I made the connection with her. I didn't have a place at school at that time, and I said, "I'm free next door!
[cpg]

But recently, I have to admit that I was wondering where Shiho-san's coolness had gone.　I have to admit that I have a feeling.
[cpg]

[FACE method="change_1" pos="2/3"]

Shiho-san is my secret first love. I wonder why I find myself in the "I like older guys" category.
[cpg]

I'm sure I like her. ......
[cpg]

I think I joined the manzai club because of my rivalry with Shiho's husband - or "Dobasaki Goron Goron" as he goes by his stage name.
[cpg]

I want to see her smile.
[cpg]

I want to repay her for that ....... I want the technology to do that. That must have been the reason for making the video. ......
[cpg]

I wonder if I'm too heavy a load. I thought to myself as I carried the heavy baggage.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_00_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

And so, I arrived home.
[cpg]

[VOICE f="Shiho009"]
[OnName num="shiho"]
I said, "Bye, then. Thank you for carrying me.
[cpg cn=true]

[OnName num="takuma"]
No, I'll see you at .......
[cpg cn=true]

We waved goodbye. I went back to my place.
[cpg]

I ate dinner and went back to my room to watch the rest of the movie.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="takuma"]
...... hmmm."
[cpg cn=true]

It was a good movie, but the hero was an old man and the heroine was young.
[cpg]

It's not easy to have it the other way around, I thought, but it was interesting, so I'll take that as a good thing.
[cpg]

As I finished the movie and felt indescribably lonely, I suddenly remembered the three people I met today.
[cpg]

Shiho. Ms. Sakurana. Ms. Tokie.
[cpg]

Each of them is a different kind of attractive woman. But they are all married women.
[cpg]

;//(Y)変更。童貞の語をカット

I want to be ...... married to one of the three of them.
[cpg]

It would be impossible for the world to be turned upside down. It's such a dreamy situation.
[cpg]

Or I could try really hard to get them. I don't know.
[cpg]

If something blows up in my face, that might happen.
[cpg]

That's exactly when I was thinking.
[cpg]

[OnName num="takuma"]
"Nn......?"
[cpg cn=true]

;//========================================
;//●ＣＧ非エロ（窓からヒロイン１の部屋が見える。ヒロイン１がベッドに座っているのが見える）ev_08
;//人物１：ヒロイン１
;//服装１：私服
;//場所　：ヒロイン１の部屋（窓越し）
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

The curtains in Shiho's room were open.
[cpg]

Even though we are neighbors, we don't have a window right next to each other. Shiho-san doesn't seem to notice us, but ......
[cpg]

That's careless. But you can only see it from me?
[cpg]

Is it okay then? ...... No, it's not good.
[cpg]

Should I tell Shiho the next time I see her? Or if I don't tell her, will she see me change my clothes?
[cpg]

If she can see me changing clothes, I definitely won't tell her anything.
[cpg]

But there is a possibility that she might notice me. I have to avoid that.
[cpg]

I wonder if I should tell her. ......
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep002.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
