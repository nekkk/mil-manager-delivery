
*start|Time for my final revelation

;#################################################
*Ep007|Time for my final revelation
;#################################################

[SCENE id=7]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

On my way to the school, I was pointed at by a group of kindergarteners in the neighborhood. They seemed to be returning from a field trip.
[cpg]

[OnName num="kindergarten_child_A"]
"Oh, it's the guy from the rabbit shoot!　It's the guy from the rabbit shoot!
[cpg cn=true]

[OnName num="accompanying_teacher"]
Hiiiiiiiiiiii!　Help me, help me, help me, help me, help me!
[cpg cn=true]

[OnName num="accompanying_teacher"]
The necromancer who roused the rabbit from its million-year slumber!　Hogeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee!
[cpg cn=true]

[OnName num="takuma"]
You've got a twist to your tale, don't you?
[cpg cn=true]

[OnName num="kindergarten_child_B"]
Cackle!　Egg munching!　Mr. Gieselbach's left!
[cpg cn=true]

[OnName num="kindergarten_child_C"]
What happened to the 80 eggs?　What about the next 90?"
[cpg cn=true]

[OnName num="kindergarten_child_D"]
'So you were shallow enough to unseal the demon for Baz.
[cpg cn=true]

I ran away. I knew that buzz is not always a good thing.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

;//(Y)一部変更。セックスまわりの反応などは変更しました。

I'm tired of class. I can't wait to go home. I was in such a mood.
[cpg]
[OnName num="male_student_A"]
"Hey, Tomi, I heard!　I heard you dumped the Madonna of the class!"
[cpg cn=true]

Madonna is so old-fashioned. I heard that the other day, too. I wondered if it was a fad.
[cpg]

But then I thought of another possibility.
[cpg]

It was Koya who first mentioned the word "Madonna. In other words, he was the one who spread the word.
[cpg]

;//(Y)追加

[OnName num="male_student_B"]
He said, "I saw that rabbit video!　You've become famous.
[cpg cn=true]

[OnName num="takuma"]
We were just filming. ......
[cpg cn=true]

This is not good. I was going to be famous to help Shiho. And I think that was accomplished .......
[cpg]

But if you go out with her, it seems that popularity will get in the way of ours.
[cpg]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『部室』（昼）******************************************************

[OnName num="takuma"]
Kouya. About the next video, I think it's time to do it."
[cpg cn=true]

[OnName num="kouya"]
"You're going to do it, ......? Have you gathered evidence?
[cpg cn=true]

[OnName num="takuma"]
"Yeah. ...... still that guy, he's being beaten up. He's getting beat up."
[cpg cn=true]

I checked the SD card capacity of my smartphone. The audio and video files are overwhelming the capacity.
[cpg]

This capacity was the amount of pain Shiho was going through.
[cpg]

[OnName num="takuma"]
I had enough viewers to spread the word.
[cpg cn=true]

[OnName num="takuma"]
"I'm going to do a live broadcast. "I'm going to do a live broadcast, and show his misdeeds under the guise of a broadcast accident. Shiho knows what makes him angry.
[cpg cn=true]

[OnName num="kouya"]
He says the goal is to make ...... laugh.
[cpg cn=true]

[OnName num="takuma"]
Yeah.
[cpg cn=true]

[OnName num="kouya"]
The actual goal is to make people laugh. I thought it would be a bit cramped for a club to set a goal on purpose.
[cpg cn=true]

[OnName num="kouya"]
I wonder if that person will smile. ......
[cpg cn=true]

I understand. This could be one-sided hatred.
[cpg]

The actuality that the name of helping the actual Shiho is borrowed, but in reality, it might be a jealousy towards the 'respectable grownup man'.
[cpg]

But the man that Shiho is scared of, hurt by, and sometimes trying to fight...
[cpg]

I want to expose him as the man who is actually not so bad.
[cpg]

[OnName num="takuma"]
I believe it will get better."
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_00_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

What a thing to say. I was on my way to Shiho's house.
[cpg]

Today, Shiho is home alone.
[cpg]

I can't wait to see her. That's all I can say.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿リビング』（夕方）******************************************************

[FACE method="change_2" pos="2/3"]
[VOICE f="Shiho323"]
[OnName num="shiho"]
Takuma-kun, your body is getting better these days.
[cpg cn=true]

;//(Y)この一行だけ変更

[OnName num="takuma"]
Is that so?　I've been eating a lot of eggs. I've been eating a lot of eggs to strengthen my stomach.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Shiho324"]
[OnName num="shiho"]
I was just trying to talk about that. That's not what I wanted to talk about.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Shiho325"]
[OnName num="shiho"]
"But ...... I guess I don't have a choice. I did this to Takuma-kun, didn't I?
[cpg cn=true]

;//(Y)挿入

Well, it's true that if it weren't for Shiho-san, I wouldn't have had to push myself so hard. ......
[cpg]

;//(Y)流用

[OnName num="takuma"]
"...... I don't think I'm responsible for Shiho-san. This is something I want to do."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Shiho326"]
[OnName num="shiho"]
I can't believe you can say that. I'm becoming more manly, yes.
[cpg cn=true]

No, I can't. No matter how many times we have this conversation, nothing will come of it.
[cpg]

I'm still getting my hopes up. I wonder if Shiho-san will be mine.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿リビング』（夕方）******************************************************

We have to break up at dinner time.
[cpg]

It's not so much Shiho's problem, but mine.
[cpg]

After all, if I can't get home by then, my parents will get suspicious about the relationship.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Shiho345"]
[OnName num="shiho"]
I'll be waiting for you at ...... anytime. You can come anytime."
[cpg cn=true]

I know that Shiho-san wants me. There is a mutual dependence on each other.
[cpg]

;//(Y)挿入
That man cannot support her.
[cpg]

;//(Y)流用

Shiho-san is not wrapping herself around me unilaterally.
[cpg]

On the other hand, I cannot support her all the way.
[cpg]

We lean on each other, and if one of us falls down, we fall down.
[cpg]

;//(Y)1行カット

[FACE method="change_7" pos="2/3"]
[VOICE f="Shiho346"]
[OnName num="shiho"]
What's wrong?　You look so gloomy.
[cpg cn=true]

[OnName num="takuma"]
No, it's nothing. It's nothing.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Shiho347"]
[OnName num="shiho"]
Are you thinking about what you're going to ...... do?
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Shiho348"]
[OnName num="shiho"]
Don't worry, he won't be back for a while. So, until then, let's stay together.
[cpg cn=true]

A while. How long is a while?
[cpg]

;//(Y)1行カット
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I wonder how much longer ...... this happiness will last.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
;//(Y)1行流用

And then I returned home. My parents no longer said anything to me.
[cpg]

;//(Y)追加

[window target=false]
[BG f="b_00_2.ui" time=1000]
[WAIT time=3000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『部室』（昼）******************************************************

I thought that I should be very careful with my plans. So I have more opportunities to talk with Koya and Shiho.
[cpg]

;//ＢＫ
;//(Y)流用
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

It was a holiday. I was visiting Koya's house.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の家＿リビング』（昼）******************************************************

[FACE method="change_2" pos="2/3"]
[VOICE f="Sanae011"]
[OnName num="sanae"]
He said, "Hello, hello, welcome. It's been a while.
[cpg cn=true]

[OnName num="takuma"]
"Yes, it has. ......
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Sanae012"]
[OnName num="sanae"]
I was going to visit him more often. Oh, but Takuma, did you have a girlfriend?
[cpg cn=true]

[OnName num="takuma"]
......"
[cpg cn=true]

I glared at Koya, who was standing next to me. He looked at me as if he didn't know me.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sanae013"]
[OnName num="sanae"]
It's a tough love, I know. Don't get discouraged, because once you give up on love, the game is over.
[cpg cn=true]

Mr. Sakuranae will say something that will make you feel like a generation. How can it be a match?
[cpg]

[free time=1000]
[WAIT time=1000]

[OnName num="kouya"]
I've got time today, so let's watch two DVDs. We have time today, so let's watch two DVDs.
[cpg cn=true]

[OnName num="takuma"]
"You'll get tired if you stay so still. ......
[cpg cn=true]

[OnName num="kouya"]
"What? You're still when we're playing the game, right?"
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

And in the evening, after I finished playing with Koya.
[cpg]

It was at the entrance. Koya said something strange.
[cpg]

[OnName num="kouya"]
You know, Takuma. You're supposed to stay at my place today.
[cpg cn=true]

[OnName num="takuma"]
What are you talking about ......?"
[cpg cn=true]

[OnName num="kouya"]
I told your parents that way. Go to Shiho's place.
[cpg cn=true]

[OnName num="takuma"]
Why are you doing this? You are doing it of my own volition, right?
[cpg cn=true]

;//(Y)追加

Lately, my parents have certainly been on my mind. I am away from home too much.
[cpg]

In small talk with Shiho, I even overheard her talking about hiring a detective. ...... detective!　A detective, she said!
[cpg]

Shiho-san laughed and asked me about it in a complicated way. Shiho-san knows why I'm going out,.......
[cpg]

[OnName num="kouya"]
When you actually make things happen--whether for the better or for the worse, it always changes the relationship.
[cpg cn=true]

;//(Y)再び流用

[OnName num="kouya"]
I know you have limited time."
[cpg cn=true]

;//(Y)1行カット

[OnName num="kouya"]
'I'm serious about you, you know. Just tell me if you want to take it away from me or if you want it to stay that way."
[cpg cn=true]

[OnName num="takuma"]
"......"
[cpg cn=true]

;//ＢＫ

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

That's why I called Shiho on the phone.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Shiho349"]
[OnName num="shiho"]
She said, "...... what's the matter, all of a sudden. Don't you have to go home?"
[cpg cn=true]

[OnName num="takuma"]
She said, "I'm supposed to be staying at a friend's house. Don't worry about it.
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Shiho350"]
[OnName num="shiho"]
"What ......?　Why are you going that far?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Shiho351"]
[OnName num="shiho"]
Takuma, you seem to be in a different mood than usual. There is something wrong with you.
[cpg cn=true]

I do. I haven't decided what I want to do with Shiho yet.
[cpg]

Do you want to take her away? Do you want to keep it that way? That's exactly what Koya was talking about.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Shiho352"]
[OnName num="shiho"]
'...... maybe you mean me?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Shiho353"]
[OnName num="shiho"]
No, it's not. Even if it's not, it's about me, right?
[cpg cn=true]

[OnName num="takuma"]
"...... yes.
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（夜）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Shiho354"]
[OnName num="shiho"]
"It's me. I still love my current husband.
[cpg cn=true]

;//(Y)追加

[FACE method="shake_7" pos="2/3"]
[VOICE f="sShiho078"]
[OnName num="shiho"]
Takuma-kun may not understand. He is such a man,......, though.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="sShiho079"]
[OnName num="shiho"]
"I wonder why ...... I wonder why."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="sShiho080"]
[OnName num="shiho"]
I'll help you with the video thing. I can only speak as loudly as I can,....... I'm in pain.
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sShiho081"]
[OnName num="shiho"]
But what do you want to do with him after that? What do I want to do with Takuma-kun? Even now, there are times when I don't know.
[cpg cn=true]

;//(Y)流用

[OnName num="takuma"]
...... I'm sure that's true.
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Shiho355"]
[OnName num="shiho"]
I can't go out with Takuma-kun's girlfriend, or rather, his ...... girlfriend. There's also the age difference."
[cpg cn=true]

I kind of knew. I had never said anything about it.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

One night. Dobasaki came home.
[cpg]

;//========================================
;//●ＣＧ非エロ（スマートフォンの一般的なホーム画面）ev_51_0　再度流用
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

A message from Shiho.
[cpg]

[OnName num="shiho"]
<I told him my fingers are swollen and I'm going to take off my wedding ring right in front of him>.
[cpg cn=true]

[OnName num="shiho"]
<He also turned the bath salts into coffee. No beer in the fridge either. I'm also going to make a pile of city papers.
[cpg cn=true]

[OnName num="shiho"]
<I was disgusted too. He has a >
[cpg cn=true]

[OnName num="shiho"]
<The thought of burning him made me feel excited, even though my body ached.
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="kouya"]
"I told my mother that I was going to shoot a video. She said she might stay here or go home.
[cpg cn=true]

[OnName num="takuma"]
I told her in a direct manner. ......
[cpg cn=true]

Koiya and I were waiting for that moment.
[cpg]

On social networking sites, our channel announced that we might do a live broadcast today.
[cpg]

I blurred it out because I wasn't sure if I could capture the scene, but from Shiho's message, it seemed she was sure.
[cpg]

If this were true, it would have been better not to make such a broadcast. If there was no need, it would have been better.
[cpg]

I don't want to burn other people either.
[cpg]

Maybe I'm just a child because this is the only way I can think of. ......, I think.
[cpg]

[SE f="se045"]
;//【ＳＥ】皿が割れる
[WAIT time=1000]

There was a sound.
[cpg]

We both looked at each other without saying anything. I made the announcement from my computer and smart phone that I had activated.
[cpg]

We checked the volume. We turned on the lights and started the feed.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[OnName num="takuma"]
Yes, hi. ......."
[cpg cn=true]

His voice was low, but clear. But clearly. Nervousness leaked out between my teeth, and I knew the delivery was being conveyed to the viewer.
[cpg]

[OnName num="takuma"]
'We're two guys from the Gieselbach Division. I'll skip the self-introduction!　As ...... announced, we have something we want to broadcast today."
[cpg cn=true]

[OnName num="kouya"]
Can you hear the voice next to you?　Ladies and gentlemen.
[cpg cn=true]

The number of viewers is increasing. Comments of greeting like "Good evening" are streaming in.
[cpg]

And. Mixed in were comments like, "What's that noise?" We suddenly tense up. A real sense of realization.
[cpg]

We are broadcasting ....... Right here, right now.
[cpg]

We are broadcasting something that could change her fate or ours.
[cpg]

The comments begin to mount. Cries are heard from next door and spread across the country through the broadcast.
[cpg]

[OnName num="takuma"]
I wanted to broadcast this one, this one from next door.
[cpg cn=true]

[OnName num="takuma"]
I know I'm going to lose viewers, but ...... that 'Dobasaki Gorogoro' lives next door.
[cpg cn=true]

[OnName num="takuma"]
Is this domestic violence?"
[cpg cn=true]

I said. I said his name. And the name of the violence.
[cpg]

[OnName num="kouya"]
I've been talking to Takuma about it. I also ...... wow!　That's too loud!
[cpg cn=true]

[OnName num="kouya"]
I don't know what to do, so I'd like to ask you, the viewers, for advice!　I wonder if the police will act.
[cpg cn=true]

[OnName num="takuma"]
I've been wondering ...... if they would move because they are the other party."
[cpg cn=true]

The flow of comments has somehow become quicker and quicker. It's getting bad, isn't it?" 'Smells like a fire.' 'I could grasp it, but...' ......
[cpg]

[OnName num="dobazaki"]
'Oh, come on!
[cpg cn=true]

[OnName num="dobazaki"]
I've said it enough times!　How many times do I have to tell you!
[cpg cn=true]

The voices were clearly captured. The number of viewers moved up a digit. Bewilderment spread through the comments.
[cpg]

The number of super chats, paid comments for throwaways, increases. Up to the highest red chat.
[cpg]

Surely one or two of the growing number of viewers are now reposting their comments on social networking sites.
[cpg]

To earn retweets and likes from one of the daily stream of celebrity flame wars, and to consume them for fun.
[cpg]

[OnName num="kouya"]
I wonder if I should talk to the police or the police. I also ...... haha. I don't know what to do. ......
[cpg cn=true]

[OnName num="kouya"]
I don't know what to do. We are so helpless.
[cpg cn=true]

[OnName num="kouya"]
I'm sorry, I'll check social networking sites. I wonder if there are any real victims' voices on .......
[cpg cn=true]

[OnName num="kouya"]
......
[cpg cn=true]

[OnName num="kouya"]
Our URL is spreading like crazy.
[cpg cn=true]

I guess so. I saw this coming. I knew this would happen.
[cpg]



;//ＢＫ
;//(Y)ある程度重めのウェイトがあるといいかな？
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_00_1.ui" time=1000]
[WAIT time=3000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

[OnName num="female_student_A"]
"Hey!　Did you see that?
[cpg cn=true]

[OnName num="female_student_B"]
"It's the worst. ...... I remember my mom and dad laughing at Dobasaki."
[cpg cn=true]

[OnName num="female_student_C"]
"Was that a broadcast accident?　I remember when they were announcing something like that. Was it intentional?
[cpg cn=true]

[OnName num="female_student_A"]
I remember this morning, those two ...... manzai club?　I think it was the  manzai club. They also released an audio clip on social networking sites.
[cpg cn=true]

[OnName num="female_student_B"]
I wonder if they could have gotten someone to move faster.　I wonder if they couldn't have gotten someone to move on it sooner. ......
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『部室』（昼）******************************************************

[OnName num="male_student_A"]
Let's get rid of all of Dobasaki's DVDs.
[cpg cn=true]

[OnName num="male_student_B"]
Yeah.
[cpg cn=true]

[OnName num="male_student_A"]
I don't want to watch them anymore.
[cpg cn=true]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
;//[BG f="b_08_2.ui" time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（昼）******************************************************
;//【ＢＧ】『洗面所』

Also, at a certain house.
[cpg]

[OnName num="man"]
What is this video?　What is this video?
[cpg cn=true]

[OnName num="man"]
"It's a waterproof phone, the first bath phone I've been brave enough to try ...... and the first thing I see is this or that."
[cpg cn=true]

;//ＢＫ

The schedules of TV and Internet programs were disrupted. The airing of the tournament final over the New Year's special was canceled.
[cpg]

Program officials announced on SNS and the official website that "170,000 Defeated Umeboshi" had won the rights to the tournament by default.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************

I could see from my window that weekly newspapers packed the Iizuka house next door on a daily basis. On rare occasions, one or two would come to the Tohmi family as well.
[cpg]

Mom was furious, and I apologized. I would politely decline interviews over the intercom.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

One day I bumped into Dobasaki. Apparently, he was waiting for me.
[cpg]

He had something hidden in his pocket. It must be a weapon.
[cpg]

[OnName num="dobazaki"]
"Hey!　You son of a bitch!
[cpg cn=true]

[OnName num="takuma"]
What is it?　Domestic violence asshole.
[cpg cn=true]

[OnName num="takuma"]
I can't believe you're waiting for me. Why don't you go apologize to the authorities?
[cpg cn=true]

[OnName num="takuma"]
I don't think you have much time before you're arrested. Why don't you do what you have to do while you still can? Let's disperse gracefully.
[cpg cn=true]

[OnName num="dobazaki"]
"Kkiiiiiiiiieeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee!
[cpg cn=true]

[OnName num="press_A"]
Ah!　There he is!　Dobazaki!　He was running away from here!
[cpg cn=true]

[OnName num="press_B"]
Mike!　Microphone on!
[cpg cn=true]

[OnName num="press_C"]
There's the accused distributor!　Take a picture with him!
[cpg cn=true]

[OnName num="takuma"]
"Oh my gosh!　I'm scared!　He's got something in his pocket!　Help me!
[cpg cn=true]

With trembling hands, Dobasaki removed the knife from his grip.
[cpg]

Oh, it's a piece of evidence. ......
[cpg]

[OnName num="press_A"]
Oh, my God, a knife!　It's a knife!　Take a picture!"
[cpg cn=true]

[OnName num="press_B"]
'Mr. Dobasaki!　There's a revelation about a story about you having an affair. Is it true!"
[cpg cn=true]

I guess I'm a terrible guy.
[cpg]

I can't forgive anyone who hurts the person I love.
[cpg]

[OnName num="dobazaki"]
"You ...... you. Don't you have a conscience or ...... conscience or ...... conscience!　Did you plan this whole thing ......?
[cpg cn=true]

[OnName num="dobazaki"]
I'm not. I... .........
[cpg cn=true]

[OnName num="dobazaki"]
I... I lost ...... everything.
[cpg cn=true]

[OnName num="takuma"]
Go ahead and fall down there. You sowed all this yourself, didn't you?"
[cpg cn=true]

[OnName num="press_C"]
"Cheating ...... yeah!　More than 20 people!　That's the kind of coverage you're getting now!　You were an idol, weren't you?
[cpg cn=true]

[OnName num="press_A"]
"You didn't know about that?　You didn't hear anything about it from the top?
[cpg cn=true]

[OnName num="press_A"]
"...... Actually, there are some illegal ...... charges of possession of some illegal ........."
[cpg cn=true]

[OnName num="press_B"]
'Yeah!　I wonder if it's okay to talk like this between rival stations......"
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sShiho082"]
[OnName num="shiho"]
Wow, what a commotion."
[cpg cn=true]

There, before I knew it, Shiho was there.
[cpg]

......!　It seems like a bad idea to meet Dobasaki now. ......
[cpg]

[OnName num="takuma"]
Shiho-san!　Watch out!　That guy has a knife, just in case!"
[cpg cn=true]

[OnName num="dobazaki"]
"Shiho oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo!"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sShiho083"]
[OnName num="shiho"]
Your divorce papers have been accepted."
[cpg cn=true]

She announced quietly.
[cpg]

Oh, I see. ...... she is indeed that strong Shiho-san who rescued me from the bully that time.
[cpg]

[OnName num="policeman_A"]
Police. Ren Iizuka. You were on TV under the stage name Dobasaki Gorogoro."
[cpg cn=true]

[OnName num="press_A"]
"Whoa!　It's the police!　Show me, show me!
[cpg cn=true]

[OnName num="policeman_B"]
Well, ...... it's hard to say here, but there are some charges against you.
[cpg cn=true]

[OnName num="dobazaki"]
You know, ......, .........
[cpg cn=true]

[OnName num="policeman_B"]
Specifically, violations of the Methamphetamine Control Act.
[cpg cn=true]

About four police surrounded Dobasaki. Dobasaki resisted, but was handcuffed.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="sShiho084"]
[OnName num="shiho"]
Dobasaki resisted, but was handcuffed. I'm surprised myself.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sShiho085"]
[OnName num="shiho"]
I'll return the favor by cheating on you. You, my ex-husband.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="sShiho086"]
[OnName num="shiho"]
Right?　Takuma-kun.
[cpg cn=true]

[OnName num="dobazaki"]
Hey!　Hey!　You can't be serious!
[cpg cn=true]

[OnName num="dobazaki"]
My cheating is right!
[cpg cn=true]

[OnName num="dobazaki"]
But cheating on someone other than me!　I won't allow it!
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="sShiho087"]
[OnName num="shiho"]
I don't need this wedding ring anymore. Takuma-kun, sell it as you like and give me some pocket money."
[cpg cn=true]

[OnName num="takuma"]
"Yes, are you sure you want to do that ......?　I don't know how much money it will bring in.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="sShiho088"]
[OnName num="shiho"]
I'm sure that's not what he's going to do. I'm sure ...... it's an eye-popping amount of money for Takuma-kun."
[cpg cn=true]

Dobazaki was dragged away by the police. He was ranting something to the end.
[cpg]

Shiho-san - her eyes are dark, but she is definitely smiling - a dark smile of revenge.
[cpg]

The wound's healing marks were a little, a little raw.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sShiho089"]
[OnName num="shiho"]
'Oh, this?'
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sShiho090"]
[OnName num="shiho"]
There's a law called the Law for the Prevention of Spousal Violence and the Protection of Victims.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sShiho091"]
[OnName num="shiho"]
I talked to the hospital, and they called the police because of this scar.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sShiho092"]
[OnName num="shiho"]
"Well, that's why. From now on, I'm going to say that Takuma-kun took me from you.
[cpg cn=true]

[free time=300]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sShiho093"]
[OnName num="shiho"]
Will you make me happy?
[cpg cn=true]

[OnName num="takuma"]
I will.
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

After that...
[cpg]

[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『部室』（昼）******************************************************

I was unaware of it at the time, but it seems that I had suffered some psychological shock.
[cpg]

One of the comments from a viewer who watched the video of me and Koya was this: "He looks like he's smiling, but he's not.
[cpg]

--I looked like I was smiling, but I wasn't smiling in my heart.
[cpg]

I was somewhat disappointed after seeing that, so I left the comic club. I didn't take any videos after that.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

A few years later, I took a job as a domestic violence counselor in a certain city.
[cpg]

With a ring shining on my left ring finger - I would take phone calls and give advice.
[cpg]

I spent my days visiting places like private shelters, police stations, and government offices.
[cpg]


;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

In the course of my work, I sometimes miss the days when I used to shoot videos and make fools of myself in the Comedy Club.
[cpg]

What was the goal of the Manzai Club?
[cpg]

;//(Y)セピア色
[window target=false]
[free time=1000]
[BG f="b_07_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『部室』（昼）******************************************************

[OnName num="kouya"]
I heard that the goal of the club is to make ...... people laugh.
[cpg cn=true]

;//(Y)ここにできたらCGが欲しいです。笑顔で泣いている誰か知らない女性の人、みたいな

;//========================================
;//●ＣＧ非エロ（笑顔で救われたように泣いている女性。）ev_53

;//人物１：モブ女性
;//服装１：私服
;//場所　：DV相談センター窓口
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_53_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[OnName num="woman"]
Thank you very much. Thank you very much.
[cpg cn=true]

Oops. I was in the middle of work. I was at work.
[cpg]

[OnName num="woman"]
I was scared until now. But after the divorce and the move, Arisa got her energy back.
[cpg cn=true]

[OnName num="woman"]
She has more friends now. Sometimes, when she sees male parents at class visits, she looks lonely. ......
[cpg cn=true]

[OnName num="woman"]
But I'm able to live a life I couldn't imagine before.
[cpg cn=true]

[OnName num="woman"]
"Thank you. ...... for helping us."
[cpg cn=true]

He smiled.
[cpg]

Oh, what the heck.
[cpg]

You can make people laugh, can't you? Me.
[cpg]


;//ＢＫ

[SCENE id=16]

;//ＥＮＤ：ヒロイン１ルート
[jump storage="epend.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

