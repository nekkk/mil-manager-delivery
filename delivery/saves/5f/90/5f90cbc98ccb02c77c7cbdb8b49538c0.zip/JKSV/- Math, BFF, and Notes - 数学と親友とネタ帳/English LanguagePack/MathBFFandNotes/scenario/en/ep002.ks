
*start|Friend's Mother

;#################################################
*Ep002|Friend's Mother
;#################################################

[SCENE id=2]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

After much hesitation, I decided to go to bed that day.
[cpg]

By tomorrow, I didn't think it was worth mentioning.
[cpg]

Besides, those curtains are not always open.
[cpg]

It just happened to be open today. I guess that's what it means.
[cpg]

Thinking this, I changed from my pajamas into my school uniform. It's a daily routine, even though I think it's a hassle.
[cpg]

Who came up with the idea of a school uniform?　I wonder if it is the work of a pedophile.
[cpg]

On the other hand, I am impressed to see a teacher wearing a suit.
[cpg]

I guess people have a good impression of whatever they are interested in.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


Speaking of morning routine, it is also a routine to see Mom and Shiho talking.
[cpg]

[OnName num="takuma"]
"Good morning, Shiho-san.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Shiho010"]
[OnName num="shiho"]
Good morning. Thank you for yesterday.
[cpg cn=true]

[OnName num="sakura_mother"]
What?　Takuma, did something happen yesterday?
[cpg cn=true]

[OnName num="takuma"]
"Just a little bit. I was on my way home from a friend's house. ......
[cpg cn=true]

;//[FACE method="change_1" pos="2/3"]

[OnName num="sakura_mother"]
Oh, that story.
[cpg cn=true]

What the heck. You were already talking about this? Well, I guess so.
[cpg]

[OnName num="takuma"]
Okay, I'm off.
[cpg cn=true]

[OnName num="sakura_mother"]
Okay, okay, see you.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Shiho011"]
[OnName num="shiho"]
"See you later, Takuma-kun."
[cpg cn=true]

I don't care what my mother says to me, but when Shiho says the same thing to me, it makes me shiver.
[cpg]

I find it troubling that you like older people.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************

When I arrived at the school and was about to go to class, unfortunately, my homeroom teacher was not even a woman.
[cpg]

Unfortunately, my homeroom teacher, even though she is a woman, is a new teacher. She is too young to feel like a teacher.
[cpg]

She is a little out of my strike zone. She seems to be popular with the boys, though.
[cpg]

I think Ms. Tokieda is a hundred times prettier.
[cpg]

There are people who sympathize with me, but they usually say, "Both are my type.
[cpg]

I like Tokieda-sensei.
[cpg]

[OnName num="kouya"]
I like Dr. Tokieda. "......You're really weird, aren't you?
[cpg cn=true]

[OnName num="takuma"]
"Do you think I'm strange ......?"
[cpg cn=true]

I think there are a certain number of them. I like older people.
[cpg]

The problem with me is that the ones I like are usually married or have children.
[cpg]

If I were to have any kind of relationship, there would definitely be a husband involved.
[cpg]

I wonder if I'll be compared to him. ......
[cpg]

;//(Y)追加
But I am still a student. I have nothing to be proud of. I have not yet entered society.
[cpg]

I don't have a concrete vision of how I can beat the men who are shining brightly in society. Only their competitive spirit is ahead of them.
[cpg]

Maybe I'm shooting a video to gain the only ability that might allow me to win.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

Morning class, math.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Aki003"]
[OnName num="aki"]
"This section will be on the exam, so please memorize it."
[cpg cn=true]

I can't remember. Your beauty is too dazzling.
[cpg]

You're really beautiful. ...... I think a teacher who has some popularity is supposed to motivate students.
[cpg]

If it's enough to make them enthralled, maybe their grades will drop like mine did.
[cpg]

I wonder if my case is just unusual.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Aki004"]
[OnName num="aki"]
Now, let's look at this problem ......, Mr. Tohmi-kun.
[cpg cn=true]

[OnName num="takuma"]
Yes, sir!
[cpg cn=true]

Of course I can't solve it. I've been looking too much at your bust.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

[OnName num="kouya"]
Hey, Takuma, are you coming to my place today too?
[cpg cn=true]

[OnName num="takuma"]
Yes, but I think I've had enough of movies. But I think I've had enough of movies.
[cpg cn=true]

[OnName num="kouya"]
"Well, let's just have fun today. Play a game or something.
[cpg cn=true]

[OnName num="male_student"]
"Oh, me too, me too. It's okay, right, Miyuji?
[cpg cn=true]

[OnName num="kouya"]
I'm inviting Takuma.
[cpg cn=true]

You don't have to be such a haggling kind of guy. It's no fun to talk like this among men.
[cpg]

But I'm not having a good time here with the girls in the mix.
[cpg]

I don't like girls because I don't know what they're thinking.
[cpg]

I think they might say bad things behind my back. ...... is just my own image.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

[SE f="se001"]
;//【ＳＥ】『歩く』

[OnName num="kouya"]
I'm like, "Hey, you should watch some foreign movies. It's fun.
[cpg cn=true]

[OnName num="male_student"]
I can't do it. I can't. All the actors' faces look the same to me.
[cpg cn=true]

[OnName num="kouya"]
You get used to it and you can tell them apart.
[cpg cn=true]

They were having such a conversation. I was a little nervous walking around because I was about to meet Ms. Sakuranae.
[cpg]

[OnName num="male_student"]
I was a little nervous about the prospect of meeting her.
[cpg cn=true]

[OnName num="takuma"]
......"
[cpg cn=true]

I think so!　I would like to agree with her, but she has her son, Koya, with her.
[cpg]

It's a little hard to say. Should I reply with at least a modest affirmation?
[cpg]

[OnName num="kouya"]
"Really?　What's so good about that old lady?"
[cpg cn=true]

[OnName num="male_student"]
I'm not saying she's good, I'm just saying she's beautiful.
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア開け』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の家＿リビング』（夕方）******************************************************

[OnName num="takuma"]
"Oh, hello.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sanae006"]
[OnName num="sanae"]
Welcome. I'm glad to see you've made new friends.
[cpg cn=true]

[OnName num="male_student"]
......, what's wrong?
[cpg cn=true]

I want to freeze up. If I go to Kouya's room like this, I won't be able to talk to Sakuranae-san.
[cpg]

I want to have a conversation with her somehow. I desperately search for a topic of conversation.
[cpg]

[OnName num="takuma"]
Do you watch movies and stuff like Kouya, too, Sanae?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sanae007"]
[OnName num="sanae"]
I'm not much of a movie guy. I'm not much of a movie ......"
[cpg cn=true]

Silence. Without a word, Koya goes to his room.
[cpg]

[OnName num="male_student"]
What's wrong? Freeze."
[cpg cn=true]

He said the same thing twice. I gave up and went to his room.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（夕方）

And there in his room, we played video games. We played video games. I wanted to talk to her more.
[cpg]

[OnName num="kouya"]
I was in the other room, and while he was saying, "Excuse me, I have to go to the restroom.
[cpg cn=true]

I was just about to go to the restroom when the other boy spoke to me.
[cpg]

[OnName num="male_student"]
I was just about to go to the bathroom when the other guy spoke to me. She's really pretty.
[cpg cn=true]

I think so!　I thought to myself, "This is a chance for us to be in sync and hold each other's hands.
[cpg]

Right now, Koya is not here either. I don't know if we are like-minded or not, but how shall I reply?
[cpg]

;//■選択肢
[switch]
[case "I think she's beautiful too."]
	[swap]
	[jump target="*select02_1"]
[case "I think she's too old."]
	[swap]
	[jump target="*select02_2"]
[endswitch]

1, I think she's beautiful, too.
2, I think she's too old.

;//==============================
;//１、俺も美人だと思う
*select02_1|Friend's mother

;//後の分岐時に桜苗が候補になる
[stflag Cha2flg = 1]

[OnName num="takuma"]
"Oh, me too. I think so, she's very beautiful, like an actress.
[cpg cn=true]

I guess I was a little too enthusiastic, but the guy seemed to be pulling a face.
[cpg]

[OnName num="male_student"]
She even said, "Are you in love with her?"
[cpg cn=true]

He even said, "You're in love with her? He was almost right, but I didn't say so.
[cpg]

[jump target="*select02_3"]
;//==============================
;//２、年上すぎると思う
*select02_2|My friend's mother.

[OnName num="takuma"]
She's too old for you. You're your classmate's mother, aren't you?"
[cpg cn=true]

[OnName num="male_student"]
Well, yes, that's true. "Well, I'm not sure if I'll make it.
[cpg cn=true]

What a rude thing to say. I thought so inwardly, but ......
[cpg]

I couldn't affirm that right away. I guess I don't really like Sakuranae that much after all.
[cpg]

;//==============================
*select02_3|My friend's mother

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の家＿リビング』（夕方）******************************************************

And on the way home. I had another chance to talk with her.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sanae008"]
[OnName num="sanae"]
She said, "I'm sorry. I really couldn't care less.
[cpg cn=true]

[free time=1000]

Behind her, there is a man sitting on the sofa.
[cpg]

......That's Koya's father, or Sakurana-san's husband. ......
[cpg]

;//(Y)変更

From what I heard, he worked at the Japanese Embassy in Hungary and then became a university professor teaching international law over there.
[cpg]

Now he is back home on sabbatical (research leave). He is a kind and gentle man. He is too perfect.
[cpg]

Mr. Sakuranae's partner--I'm jealous. I hate ...... it. It's kind of mushy around the heart.
[cpg]

[OnName num="sanae_husband"]
Takuma, is that you? Long time no see.
[cpg cn=true]

[OnName num="takuma"]
It's been a while.
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sanae009"]
[OnName num="sanae"]
What's wrong?　Takuma, are you sick?
[cpg cn=true]

[OnName num="takuma"]
No, no. It's nothing.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[OnName num="male_student"]
Well then, I'm sorry to bother you.
[cpg cn=true]

[OnName num="kouya"]
Oh, come again. Come again.
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

On the way home, I walk alone because the road is different from that boy's road.
[cpg]

That's what it means to fall in love with a ...... married woman.
[cpg]

When I saw him, I froze.
[cpg]

;//(Y)変更

Even Shiho has a husband named Dobasaki. When she gets back from Hokkaido, she'll be on that show, and it's the finals.
[cpg]

I'm thinking of collaborating with her on a video, but to be honest, there was a part of me that didn't want to see her.
[cpg]

To be honest, I'm not interested even if the number of followers on my channel increases. I only want Shiho to see me.
[cpg]

Shiho-san is watching a professional comedian up close - I, who still lacks confidence, can't even tell her about the channel.
[cpg]

[OnName num="takuma"]
"...... damn."
[cpg cn=true]

Whatever. Do something about this feeling that has nowhere to go. ......
[cpg]

As I'm thinking that, in front of my house. I saw Shiho-san working on her vegetable garden.
[cpg]

;//(Y)追加。家庭菜園の細部を書き込むとキャラが深まる＋こうしたところから作中世界に入りやすくなるはずですが、時期設定によっては矛盾が出ます。問題あればプチトマトを別のものに変えるなど

The vegetable garden had cherry tomatoes. She was buying them when she carried her luggage, and she likes them. ......
[cpg]

Plants, huh? I think it's the hobby of a mame and kind person. My elementary sweet potatoes turned into a twisted spiral drill.
[cpg]

That was a screwy spiral drill, and even the two people who grew them on either side of me were screwy spiral drills. They were screaming that they were infected.
[cpg]

When I wrote the name of the student next to me on a math test and got a zero on it, I was nicknamed "Predator.
[cpg]

It means that he preys on the people around him. I'd like you to give that nickname to a woman who is older than me.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho012"]
[OnName num="shiho"]
Ah, Takuma-kun. Welcome back to ...... What's wrong?　Are you sick?"
[cpg cn=true]

You're saying the same thing as Mr. Sakuranae. I wonder if she's that pale.
[cpg]

I guess it's not so much the ...... complexion, but the expression on your face.
[cpg]

[OnName num="takuma"]
I'm having a bit of trouble."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Shiho013"]
[OnName num="shiho"]
I don't know.　If it's okay with me, I'll listen.
[cpg cn=true]

I can't say. I can't tell you because it's exactly you, Shiho, who says she'll listen if it's okay with me.
[cpg]

[OnName num="takuma"]
She said, "It's okay to tell me at ....... I can solve it by myself."
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[SE f="se029"]
;//【ＳＥ】『ベッドきしむ』

As soon as I left, I plopped down on my bed.
[cpg]

I can't help it. I don't know how to go after attractive women.
[cpg]

I don't know how to confess my feelings to a girl in my class because I don't like her. Because I don't like her.
[cpg]

I can't tell her because I like her. What should I do with this feeling that seems contradictory or not?
[cpg]

[OnName num="sakura_mother"]
"Takuma, dinner is ready!
[cpg cn=true]

[OnName num="takuma"]
I'm going to ...... later."
[cpg cn=true]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep003.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
