
*start|To Be Married to Tokieda Sensei

;#################################################
*Ep013|To be united with Dr. Tokieda
;#################################################

[SCENE id=13]

;//(Y)流用。

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

The next morning. There was no such thing as Shiho-san and my mother talking today.
[cpg]

But I don't have time to look at Shiho-san anymore.
[cpg]

I have to get married with Ms. Tokieda. That intention was strong.
[cpg]

;//(Y)別シーンからの原文流用。

[FACE method="change_7" pos="2/3"]
[VOICE f="Shiho389"]
[OnName num="shiho"]
'...... You look kind of manly today, too.
[cpg cn=true]

[OnName num="takuma"]
Yes, I do. Because I consciously do."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Shiho390"]
[OnName num="shiho"]
"I see. ...... I don't know about that, but good luck.
[cpg cn=true]


;//(Y)新規追加

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（朝）******************************************************

The railroad crossing was closing. I waited for it to open,...... and then I saw something strange.
[cpg]

[OnName num="takuma"]
I said, "Hmm?　That's ......."
[cpg cn=true]

[OnName num="dobazaki"]
So how do I get you to go out with me?
[cpg cn=true]

--What?　It's Dobasaki Korogoro. He should have been arrested. He was yelling at the car.
[cpg]

No way, did he pay a lot of bail?
[cpg]

[OnName num="female_student_A"]
Hey, that ......."
[cpg cn=true]

[OnName num="female_student_B"]
What?　I've seen that ...... something really cool, but who is it?"
[cpg cn=true]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=1000]
[VOICE f="sAki019"]
[OnName num="aki"]
Enough!"
[cpg cn=true]

I heard a shout from inside the car. I huffed and ...... huffed, "What, sir!
[cpg]

[SE f="se055"]
;//【ＳＥ】　電車の音。　ぷおおん

A train is passing by. The crossing was still not open.
[cpg]

[OnName num="dobazaki"]
I love you!"
[cpg cn=true]

It was in broad daylight - a confession. The sound of the train passing by drowned it out, but those of us around us heard it.
[cpg]

[OnName num="takuma"]
'Nah ......!
[cpg cn=true]

Is the teacher hitting on me?　This.
[cpg]

I pulled out my smartphone. There was news of a major sewer construction project in the area.
[cpg]

So, the teacher changed his route to school, and now he's being hit on?　I was disgusted with Dobasaki.
[cpg]

[OnName num="dobazaki"]
I have plenty of money," he said. My family has money.
[cpg cn=true]

[OnName num="dobazaki"]
If you follow me--"
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="sAki020"]
[OnName num="aki"]
He's persistent.
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="sAki021"]
[OnName num="aki"]
I'm certainly going through with the divorce!　But--"
[cpg cn=true]

I've never heard of that. You're divorcing me?
[cpg]

But the information that mattered to me was what I heard right after.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="sAki022"]
[OnName num="aki"]
There is only one condition for the kind of man I will fall in love with!　I told you that, didn't I?
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="sAki023"]
[OnName num="aki"]
He has to make me laugh!"
[cpg cn=true]

The railroad crossing opened. The car immediately drove off, just under the speed limit.
[cpg]

A disappointed and nodding Dobasaki was left behind, while male students and businessmen surreptitiously took pictures of him.
[cpg]

[FACE method="change_3" pos="2/3"]

I thought of Shiho's smile. Behind that cute smile hides "I'm at peace without him.
[cpg]

[OnName num="dobazaki"]
That ain't ...... something to show!"
[cpg cn=true]

This confession was the worst choice of place and the worst thing to do in broad daylight, but I guess that's how cornered he is right now.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I quickly headed to the school. ......I'm sorry Dobasaki, but I've heard good things about you.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************

;//(Y)新規追加

[FACE method="bow_1" pos="2/3"]
[VOICE f="sAki024"]
[OnName num="aki"]
I'm sorry to hear that, but I've heard good things about Dobasaki. For coming to make up the work."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="sAki025"]
[OnName num="aki"]
I called out to the other students with low scores, but Takuma was the only one who showed up.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sAki026"]
[OnName num="aki"]
'......'
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sAki027"]
[OnName num="aki"]
'I'll let bygones be bygones for yesterday.
[cpg cn=true]

I was shocked. I guess he decided it was better to say it clearly this time. I've already confessed to him twice,.......
[cpg]

But sure enough. If she's going to be followed around by a guy like that, she must want to have a few laughs. Divorce talk must be stressful too.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="sAki028"]
[OnName num="aki"]
"I'm a little tired for a reason, ...... sorry."
[cpg cn=true]

[OnName num="takuma"]
No, ...... yes. I understand. I'm sorry.
[cpg cn=true]

I'm sorry. ....... It makes sense. I'm a student, come to think of it.
[cpg]

;//(Y)年上との恋愛ならば「自分は無能で、対象は有能」という不都合な事実を避けては通れないはずです。学生のプレイヤーとかがムッと来るかもしれない箇所ではありますが、インターネットで普段から「有能な他人」が見られる現代にあってはどうしても、多くのプレイヤーは比較して自己肯定感が低くなっている状態で過ごしているはずで、それを事実として受け入れた上での「じゃあどうするか」の話をしないと心を掴めないと思います。多くのプレイヤーにとっては納得して受け入れられる範囲だと思います。ドバ崎の一方的な告白も挟みましたしよくない反面教師として扱える

I have a future, I'm studying, which means I have no skills at the moment - painful but true.
[cpg]

I have nothing to offer her. I can't give her anything, and yet it's too convenient for her to accept me.
[cpg]

To be accepted, you must first be able to give her something.
[cpg]

For example, a smile.
[cpg]

;//(Y)流用。ちょっと書き換え

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Aki055"]
[OnName num="aki"]
Er, so here's the answer: ......
[cpg cn=true]

My eyes are drawn to the buttocks of the teacher who writes on the blackboard for just one of me.
[cpg]

I feel the urge to pounce on it right now.
[cpg]

But I mustn't do that. Of course I shouldn't.
[cpg]

I'm losing my cool. I can't believe I'm thinking this. ......
[cpg]

;//(Y)新規追加

[OnName num="takuma"]
"Smile,...... first and foremost. Otherwise you don't even qualify."
[cpg cn=true]

;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

My goal changed from confessing to Tokieda-sensei to making him laugh for the time being.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の洗面所』（夜）******************************************************

Night. I looked in the mirror and made all kinds of funny faces.
[cpg]

[OnName num="takuma"]
"Ho-ho-ho!　Fuyuyuu!　Gyu-hyuu!"
[cpg cn=true]

I pulled my mouth, pinched my cheeks, and made strange noises.
[cpg]

[OnName num="takuma"]
'Kihyohh!　Yihihihihi!　Yihihihihihihihi!　All for a smile!　All for a smile!
[cpg cn=true]

Then the mother came in.
[cpg]

[OnName num="sakura_mother"]
"C'aaaaaaah!　What's going on?　What's going on?　Don't make any funny noises!
[cpg cn=true]

[OnName num="takuma"]
I'm in the comedy club, Mom!　This is part of our club activities!
[cpg cn=true]

[OnName num="sakura_mother"]
I see. I see."
[cpg cn=true]

[OnName num="takuma"]
I see.　You're so easily convinced?　You must have always been thought of as a strange person, right?　Me.
[cpg cn=true]

[OnName num="sakura_mother"]
That's right.
[cpg cn=true]

[OnName num="sakura_mother"]
The moment you were born, you said, "I only eat peperoncino pasta. You.
[cpg cn=true]

I had never heard that before. My mother left.
[cpg]

Thinking back, it is true that I love peperoncino. I don't want to eat anything else.
[cpg]

[OnName num="takuma"]
"Who the hell ...... am I?"
[cpg cn=true]

I returned to my thoughts. I took out my ...... smart phone and searched for images of comedians in the funny face lineage.
[cpg]

[OnName num="takuma"]
'It's all about impact and how you blow it.
[cpg cn=true]

Love that doesn't make you crazy is not love. I'll give up any amount of dignity.
[cpg]

[OnName num="takuma"]
What's funny?
[cpg cn=true]

[OnName num="takuma"]
How many interesting things are there around you?　What can we learn from any situation ......?"
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************

The next morning, Saturday. I arrived at the school as usual. I didn't even see the teacher. There was just construction yesterday.
[cpg]

Including today's repairs, we'll do repairs on Sunday and Monday (a holiday) and then we'll be done.
[cpg]

;//========================================
;//●ＣＧ非エロ（教員机か、主人公の目の前の机を挟んだ前に座らせてください）ev_38）
;//人物１：ヒロイン３
;//服装１：スーツ
;//場所　：学校
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_38_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sAki029"]
[OnName num="aki"]
I'll start classes today. ...... Takuma-kun."
[cpg cn=true]

[OnName num="takuma"]
Yes, sir.
[cpg cn=true]

[VOICE f="sAki030"]
[OnName num="aki"]
"Honestly, I reviewed it."
[cpg cn=true]

[OnName num="takuma"]
"Bust?"
[cpg cn=true]

I was praised at an unexpected time. Why?　Why all of a sudden ......?
[cpg]

[VOICE f="sAki031"]
[OnName num="aki"]
Because you are taking it seriously. You're making sure you understand the parts you don't understand.
[cpg cn=true]

[VOICE f="sAki032"]
[OnName num="aki"]
It's the most basic part, but when it comes to those with bad grades, it's what they do the least.
[cpg cn=true]

The teacher - he was smiling. ...... smile!
[cpg]

[VOICE f="sAki033"]
[OnName num="aki"]
Why is that?　I feel like if I teach them functions properly, they are growing. To be honest, it's like I've been lying all this time.
[cpg cn=true]

[VOICE f="sAki034"]
[OnName num="aki"]
I'm surprised too.
[cpg cn=true]

[OnName num="takuma"]
"Oh, ......, oh, ......."
[cpg cn=true]

I was happy.
[cpg]

...... You don't think the doctor would laugh at you just for 'trying to do something normal and ordinary'?　Not to say that it's a laugh.
[cpg]

[OnName num="takuma"]
I'll do my best in class. I'll do my best in class.
[cpg cn=true]

[VOICE f="sAki035"]
[OnName num="aki"]
I have high hopes for you. Frankly, when he confessed, I thought, 'Maybe he's not going to do it,' but it looks like he's going to be okay."
[cpg cn=true]

[OnName num="takuma"]
"Gaaaah!
[cpg cn=true]

I began to work hard on my classes.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『踏み切り前』（夕方）******************************************************

After a little fun in the city, on the way home. I was idly waiting for the railroad crossing to open.
[cpg]

[OnName num="takuma"]
"....... ......, is math by any chance?"
[cpg cn=true]

[OnName num="takuma"]
Interesting?"
[cpg cn=true]

I felt my vision open up as I gradually understood more and more.
[cpg]

The harder I worked, the happier my teacher became. It felt like a good thing. ......
[cpg]

[OnName num="takuma"]
"....... Oh, there's a text from Koja.
[cpg cn=true]

;//========================================
;//●ＣＧ非エロ（スマートフォンの一般的なホーム画面）ev_51_0　再度流用
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[OnName num="kouya"]
<I got a big fish, you want to eat it at my house today?　My mom is having a hard time dealing with it.
[cpg cn=true]

[OnName num="takuma"]
Let's go there."
[cpg cn=true]

;//(Y)流用したものを編集。場所が違います

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の家＿リビング』（夜）******************************************************

It seemed that Ms. Sakuranae was cooking. In just a few moments, Kouya asked.
[cpg]

[OnName num="kouya"]
What's happened since then? Did you kiss or something?
[cpg cn=true]

[OnName num="takuma"]
What the hell, Koya would ask that kind of question too. ......
[cpg cn=true]

[OnName num="kouya"]
Well, it's someone else's business, you must be wondering.
[cpg cn=true]

That's a totally unreserved way of putting it. Well, okay.
[cpg]

[OnName num="takuma"]
I didn't, but I did get one compliment. She had a beautiful smile."
[cpg cn=true]

[OnName num="kouya"]
'...... Really?'
[cpg cn=true]

[OnName num="takuma"]
'Maybe I like students who work hard at their studies in general,...... I'm thinking of trying a little harder.'
[cpg cn=true]

[OnName num="kouya"]
I guess that's what you're supposed to do as a teacher.
[cpg cn=true]

[OnName num="kouya"]
I know a guy who works part-time as a tutor in secret, and he says things like, 'I know how it feels to be a teacher.
[cpg cn=true]

[OnName num="kouya"]
"His smile is rare, isn't it?　I'd like to see it.
[cpg cn=true]

[OnName num="takuma"]
"It's a rarity, isn't it? ...... I had a crush on her when I saw it.
[cpg cn=true]

[OnName num="kouya"]
"Is your guard really that low?"
[cpg cn=true]

;//(Y)別箇所から流用。2行ですが

I don't get the sense that they're letting their guard down. They probably wouldn't do this to any other student but me.
[cpg]

We had such a stupid exchange. ......Sakura Nae-san is serving the food. The smell of goodness wafts through the air.
[cpg]

;//(Y)新規追加

[OnName num="takuma"]
I've got his type. He's someone who makes me laugh."
[cpg cn=true]

[OnName num="kouya"]
Wow,......, that's a lot of details. No, but he just laughed at me in class.
[cpg cn=true]

[OnName num="kouya"]
I think we're a long way from being in love, don't you?　You're probably getting some kind of response.
[cpg cn=true]

It's also honest. ......Sakura Nae-san brought the food.
[cpg]

;//(Y)流用。

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sanae354"]
[OnName num="sanae"]
'...... you have a broken heart?'
[cpg cn=true]

[OnName num="takuma"]
I'm not. I'm not.
[cpg cn=true]

[OnName num="kouya"]
You know, the back and forth is not quite the same,.......
[cpg cn=true]

[free time=1000]
Indeed. If you didn't have a broken heart, you wouldn't be cared for or anything.
[cpg]

But when I look at Sanae again like this, I think she's ...... beautiful.
[cpg]

I was still not as thrilled as my teacher.
[cpg]

I realize I was fascinated to no end.
[cpg]

;//(Y)新規追加

[OnName num="takuma"]
"Koya. please think of something for the next comic story or whatever you're going to do. Not the stuff for the video."
[cpg cn=true]

[OnName num="takuma"]
No clipping material. I'll do something in-person, something ......."
[cpg cn=true]

[OnName num="kouya"]
"In-person?　No way. ......
[cpg cn=true]

[OnName num="takuma"]
It's just a story to make you laugh. I'm going to work hard in class until then.
[cpg cn=true]

[OnName num="takuma"]
If you succeed, I'll take any stuffed animal you want from UFO Catcher.
[cpg cn=true]

[OnName num="kouya"]
I'm in."
[cpg cn=true]

Sakura Nae-san was smiling when she heard that. There are few things that make me happier than having more stuffed animals in the house.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************

It was Sunday. It has been a long repair work, but it will be over tomorrow. I don't feel like I've been in pain .......
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sAki036"]
[OnName num="aki"]
I am very proud of you," he said. That's great. You've done a great job with the remedial work.
[cpg cn=true]

[OnName num="takuma"]
"〜〜〜〜〜!"
[cpg cn=true]

He said, "Great ...... work!　I was praised.
[cpg]

That simple compliment was more effective than anything else. I was glad I had worked so hard on my studies.
[cpg]

[OnName num="takuma"]
I'm so happy for you, Sensei. Thank you very much. ......
[cpg cn=true]

It stings so much when you get praised for your efforts. ......
[cpg]

The teacher is so dedicated to the class. ...... Don't they need a break or something?
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="sAki037"]
[OnName num="aki"]
'I got you an apple pie today.
[cpg cn=true]

What about ......?
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sAki038"]
[OnName num="aki"]
'It's a famous store in Yokohama. They had a temporary store at the north exit of the station and I just had to have it.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sAki039"]
[OnName num="aki"]
'My husband avoids sugar, and I couldn't eat it all by myself. Takuma-kun, here you go."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sAki040"]
[OnName num="aki"]
I also put some iced tea in a clear jar. It's cold.
[cpg cn=true]

--Wait, wait!　Wait, wait, wait!　Tokieda-sensei, isn't your liking for me actually going up quite a bit!
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sAki041"]
[OnName num="aki"]
Perhaps I should have added milk to make milk tea?
[cpg cn=true]

[OnName num="takuma"]
"Hey!　Wait a minute, doctor!　Thank you!
[cpg cn=true]

I put my fork in the apple pie offered to me and began to eat.
[cpg]

[OnName num="takuma"]
"...... mogg."
[cpg cn=true]

[OnName num="takuma"]
I put my fork in the apple pie offered to me and began to eat it.　Yum......!"
[cpg cn=true]

The custard melts in the mouth rich but not sticky. The apples are moist and sweet. And the cinnamon is savory.
[cpg]

--It's so good!　Cooking!　Food is also something that can make people smile. ......Ahhh, yummy!
[cpg]

I also had a cup of iced tea.
[cpg]

[OnName num="takuma"]
What?　The buttery oil sloshed down my throat and moistened my throat......"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="sAki042"]
[OnName num="aki"]
I was so happy to see him. I see you liked it."
[cpg cn=true]

[OnName num="takuma"]
'Oh, thank you!　Thank you very much!　Delicious!"
[cpg cn=true]

By the way, my breakfast consisted of multivitamin tablets, milk, and buttered bread.
[cpg]

I thought Tokie-sensei was smiling at me. Then she began to write on the blackboard.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sAki043"]
[OnName num="aki"]
Then, please eat while you still can.
[cpg cn=true]

Tokieda-sensei brings me an exquisite apple pie. I think I've fallen in love with her even more.
[cpg]

Tokieda-sensei who goes out of his way to make iced tea, pack up the apple pie, and drive that car here .......
[cpg]

[FACE method="change_1" pos="2/3"]

Is this very normal?　Can we just put it away as a "small" act of human kindness?
[cpg]

At least I was made to smile. Even though ...... I was thinking about making the doctor smile. I got one.
[cpg]

;//(Y)桜苗ルートが「年上好き」という依存（全年齢である以上性癖としての話はできず精神性としての話に成らざるを得ないので、卒業すべきものとなる）からの脱却っぽい話であれば、逆に、この時枝先生ルートの直上の話とかは「年上の人の無償の奉仕精神えらい」っていう年上の魅力の肯定な気がしてきました

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

And then home. I was - I was standing in front of Shiho's house.
[cpg]

The person I was going to meet was not Shiho-san.
[cpg]

[OnName num="takuma"]
"When you learn to make people laugh," she said.
[cpg cn=true]

[OnName num="takuma"]
The last person I wanted to meet. ......
[cpg cn=true]

I was about to meet a comedian, Dobasaki Gorogoro. I am trying to learn a skill.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（夕方）******************************************************

[OnName num="dobazaki"]
I'm glad you're here, ......, I got your email.
[cpg cn=true]

[OnName num="dobazaki"]
I don't have a job right now.
[cpg cn=true]

I'm sure that's true. He may have made bail, but he must have lost his job.
[cpg]

[OnName num="dobazaki"]
You're the guy who moved all the way next door to me because you love Shiho, right?
[cpg cn=true]

[OnName num="dobazaki"]
Let me start by saying I don't like you.
[cpg cn=true]

I'm sure that's true. I hate you too.
[cpg]

[OnName num="takuma"]
Where's Shiho-san going?
[cpg cn=true]

[OnName num="dobazaki"]
......
[cpg cn=true]

He seemed to be at a loss for an answer. But I know it.
[cpg]

[OnName num="dobazaki"]
I ain't here. ...... you know it too, don't you? I'm in this situation. I left temporarily."
[cpg cn=true]

[OnName num="takuma"]
Speaking of which, ...... this room.
[cpg cn=true]

There's a place where it looks like she's packed her bags.
[cpg]

She was suddenly not seen anymore. If anything, it's not something to be sad about, I think she's trying to step out anew.
[cpg]

[OnName num="takuma"]
Me and Koya are in a comedy club. We do video streaming."
[cpg cn=true]

[OnName num="takuma"]
If we get more viewers or buzz, I'll tell them that Dobasaki taught me how to do it.
[cpg cn=true]

[OnName num="dobazaki"]
Well, it's not a bad negotiation. I'm talking to you right now.
[cpg cn=true]

[OnName num="dobazaki"]
If I get noticed again as an 'interesting guy,' I might get a job.
[cpg cn=true]

This was the exchange for Dobasaki teaching me things. This is the price of tuition. --We gave him a chance to be noticed again.
[cpg]

[OnName num="dobazaki"]
Hmmm. Well, show me the video first. I'll tell you what's wrong with it.
[cpg cn=true]

;//ＢＫ

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（夕方）******************************************************

[OnName num="dobazaki"]
No, this is no good."
[cpg cn=true]

That's pretty harsh.
[cpg]

[OnName num="dobazaki"]
"You're talking about getting my name out there if you guys can get me more viewers. It's going to be a long time.
[cpg cn=true]

[OnName num="dobazaki"]
I was going to list all the bad points, but ...... I'm starting to feel pity for you, so I can't say anything.
[cpg cn=true]

[OnName num="dobazaki"]
First of all, the use of the word "abruptness" is not good.
[cpg cn=true]

[OnName num="takuma"]
Is it abruptness ......?
[cpg cn=true]

[OnName num="dobazaki"]
Yes, it is. Think about it.
[cpg cn=true]

;//(Y)ここ特に「シナリオライターの自我」をプレイヤーが感じやすい箇所だと思うので、なんというか……繊細な確認をお願いします。いちおう後に回想でも使いますので修正時にはそちらにも反映

[OnName num="dobazaki"]
Suppose you guys wrote a story. If everything goes as it should, it's 'predictable.
[cpg cn=true]

[OnName num="dobazaki"]
"You have to 'hash it out' to make it look like you've created a flow. Suddenly, absurdly."
[cpg cn=true]

[OnName num="dobazaki"]
Logic can predict what's logical. The audience. So for the audience, it crashes as expected."
[cpg cn=true]

[OnName num="dobazaki"]
As expected. It doesn't exceed expectations.
[cpg cn=true]

[OnName num="dobazaki"]
Nothing interesting."
[cpg cn=true]

[OnName num="takuma"]
Gosh, ......!
[cpg cn=true]

[OnName num="dobazaki"]
"Suppose there's a good guy and a bad guy in the story.
[cpg cn=true]

[OnName num="dobazaki"]
"How interesting is a story that can be explained away with, 'Good guys win over bad guys'?"
[cpg cn=true]

[OnName num="dobazaki"]
"Is it interesting to see a movie where the only thing that's interesting is the 'template with the character's face on it' instead of the characters?
[cpg cn=true]

[OnName num="dobazaki"]
"Is it interesting to have a woman who is a childhood friend who likes the protagonist and does nothing but affirm everything the protagonist does?
[cpg cn=true]

[OnName num="dobazaki"]
"How much do you think it would catch your attention if she suddenly says to the protagonist, 'No, I think like this' in the middle of the movie?"
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕）******************************************************

I was just standing in front of the front door of my house, ruminating over the many, many things Dobasaki had said to me.
[cpg]

My house is right in front of me. But my head is spinning .......
[cpg]

I think that any scumbag has a thing or two to learn .......
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep014.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
