
;//==============================
;//２、晶姫

*select05_2|Facing Repair

Tokieda-sensei's face came to mind.
[cpg]

I decided to stand up to the infernal repairs (with a parfait as a reward).
[cpg]


*start|Confronting Repair

;#################################################
*Ep012|Facing up to the remedial work
;#################################################

[SCENE id=12]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『部室』（昼）******************************************************

I took a video in the clubroom.
[cpg]

[OnName num="takuma"]
I'm going to step into the hell that is mathematics!
[cpg cn=true]

This video is also a statement of determination. The Manzai Club is about making people laugh, and we will use the pinch as a story for the video.
[cpg]

[OnName num="takuma"]
I'm going to train alone with a beautiful teacher who is older than me!
[cpg cn=true]

This oozed with genuine feeling. I did it, but I recorded it.
[cpg]

;//ＢＫ

[OnName num="male_student_A"]
I'm recording it. "Hey, Tomi, didn't Ms. Tokieda confess her feelings to you when you were ...... a freshman and was rejected?"
[cpg cn=true]

Damn. Is it getting through? I remember Koya telling off.
[cpg]

[OnName num="male_student_B"]
"A training class alone with you? ...... Maybe she still has feelings for you."
[cpg cn=true]

I thought they were going to make fun of me, but they were ...... good guys who followed me. Sorry.
[cpg]

....... Thinking about it, might there be a chance in the future to re-confess to Tokieda-sensei?
[cpg]

Is ...... this repair a chance to re-confess?
[cpg]

I'm on fire.
[cpg]

;//(Y)原文流用

Of course, he is married. He won't accept me if I ask him to do something for me.
[cpg]

Before the married woman barrier, there is also the teacher-student barrier.
[cpg]

But that barrier was what made me burn.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

[OnName num="kouya"]
I heard you taking video in the clubroom. Do you still like Tokieda-sensei?"
[cpg cn=true]

Wow!　I didn't know he could hear me.
[cpg]

;//(Y)原文流用

[OnName num="kouya"]
"Over there, ......, she's a married woman, you know?　You know that, right?
[cpg cn=true]

[OnName num="takuma"]
"I know."
[cpg cn=true]

[OnName num="kouya"]
"Well, I think she's beautiful, but ...... even our homeroom teacher is beautiful, right?　She's single.
[cpg cn=true]

[OnName num="takuma"]
She's not in my strike zone. I'm sorry to say this, but...
[cpg cn=true]

[OnName num="kouya"]
If you insist that much, I won't stop you. Oh, so Takuma is after all."
[cpg cn=true]

He said something like that as if he was convinced of something.
[cpg]

;//(Y)新規追加

[OnName num="takuma"]
I'm going to confess.
[cpg cn=true]

;//(Y)別箇所から原文流用

[OnName num="kouya"]
If you hear that, the girls who confessed to you will cry. ......
[cpg cn=true]

[OnName num="kouya"]
No, it's not only the girl, but also your fans who might stab you.
[cpg cn=true]

[OnName num="takuma"]
That may be so, but that's exactly the difference in values.
[cpg cn=true]

Koya is aghast. It's fine to be stunned.
[cpg]

;//(Y)ちょっと戻った箇所から原文流用

I don't think I can back out of this one. The only thing left to do is to consult with Ms. Tokieda at the end of her class.
[cpg]

;//(Y)原文流用＋追加から成ってます。

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

Once you've decided that, the sooner you act, the better.
[cpg]

So I was about to leave the house, thinking that I would tell her everything today.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shiho387"]
[OnName num="shiho"]
Takuma-kun. See you later."
[cpg cn=true]

Dobasaki is caught. I felt like I could see her genuine smile.
[cpg]

[OnName num="takuma"]
I'm off. I'm going to play the game of a lifetime.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Shiho388"]
[OnName num="shiho"]
"Eh, ......?　I'm going to go. Do your best.
[cpg cn=true]

Shiho is cheering me on, too. I don't think she knows what she's talking about.
[cpg]

[OnName num="takuma"]
"...... you look well, I'm glad."
[cpg cn=true]

;//(Y)新規

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

After showing up at the manzai club in the time before remedial work - the remedial work begins.
[cpg]

There was no one in the classroom except me and Tokieda-sensei. It was a one-on-one class.
[cpg]

;//========================================
;//●ＣＧ非エロ（男根を消してください）ev_34）
;//人物１：ヒロイン３
;//服装１：スーツ
;//場所　：学校
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sAki013"]
[OnName num="aki"]
First of all, thank you very much for coming. I'm glad you came. I'm glad you came.
[cpg cn=true]

[VOICE f="sAki014"]
[OnName num="aki"]
Let's begin the lesson.
[cpg cn=true]

[OnName num="takuma"]
"Yes, yes.
[cpg cn=true]

I was nervous. Not only is this a confession, but I don't even know what part of math I don't understand.
[cpg]

The one who makes the confession - in front of the teacher in this way, his resolve is shaken.
[cpg]

[VOICE f="sAki015"]
[OnName num="aki"]
'There was a test on quadratic functions, wasn't there? From what I saw, it looked like we should go back a bit in the class."
[cpg cn=true]

[OnName num="takuma"]
'Yes. ...... I'd like to know the rudiments.
[cpg cn=true]

It occurred to me. I was getting low marks in my classes because of the teacher.
[cpg]

I'm doing one-on-one remedial work, so close, I can even smell the teacher - is this remedial work going to improve my scores?
[cpg]

The teacher looked at my hand. He noticed that I hadn't even picked up a nock pen. I hurriedly picked up the nock pen.
[cpg]

[VOICE f="sAki016"]
[OnName num="aki"]
He said, "Let x here be a certain number ......, for example, 1, 2, or whatever."
[cpg cn=true]

[VOICE f="sAki017"]
[OnName num="aki"]
When that number is determined, then y is naturally determined when ......
[cpg cn=true]

I seem to have jumped into a situation that's even more difficult than class. I can't concentrate. ......
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

I could hear voices in the next classroom, which seemed to be conducting another remedial class. I felt a kinship with one of the students whose face I could not see.
[cpg]

The class is coming to an end. I decide to make a confession.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sAki018"]
[OnName num="aki"]
"Class is over. Thank you for your hard work.
[cpg cn=true]


;//(Y)原文流用

[OnName num="takuma"]
I have something important to tell you. Please listen to me.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aki025"]
[OnName num="aki"]
Can't we talk about it here?　I'm busy too.
[cpg cn=true]

[OnName num="takuma"]
I'm busy, but you don't have class today, do you?
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Aki026"]
[OnName num="aki"]
"That's true, but ...... what is it?"
[cpg cn=true]

I go for it. Tokieda-sensei seems to be a little withdrawn.
[cpg]

;//(Y)原文流用。

[OnName num="takuma"]
I like Ms. Tokie.
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Aki028"]
[OnName num="aki"]
I'm in love with Ms. Tokieda.
[cpg cn=true]

[OnName num="takuma"]
"Oh, no, wait a minute!"
[cpg cn=true]

;//(Y)原文流用ですが場所は変えています

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『部室』（夕方）******************************************************

That day didn't go well. But my resolve wasn't half-baked enough to give up after just one day.
[cpg]

;//(Y)新規。反省の場面あるだけでも主人公への親近感は湧くもの

Once again, we are in the club room of the Manzai Club. Surprisingly, there are a few members in the club. Today is a vacation, but it seems that club activities are still going on.
[cpg]

[OnName num="takuma"]
I think it was too sudden to say, "....... Confession.
[cpg cn=true]

[SE f="se029"]
;//【ＳＥ】『衣擦れ』

;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I plopped down on my desk. I think I was too ...... impatient. Without creating an atmosphere, a confession is not acceptable.
[cpg]

The only thing is - I had a feeling this was going to happen. I even felt rather relieved.
[cpg]

You 'shouldn't' accept my confession right away. ...... No, well, I did confess to you in freshman year.
[cpg]

[OnName num="kouya"]
Hey, what's up?"
[cpg cn=true]

[free time=1000]
[WAIT time=1000]

;//【ＢＧ】『部室』（夕方）******************************************************

I looked up.
[cpg]

[OnName num="takuma"]
'What, you're here?　You're a creepy guy. You weren't even a shadow of your former self.
[cpg cn=true]

[OnName num="kouya"]
He was here!　He just came in.
[cpg cn=true]

[OnName num="takuma"]
I'm off today, in case you're wondering. Why did you come all the way to the school?
[cpg cn=true]

[OnName num="kouya"]
To protest.
[cpg cn=true]

[OnName num="takuma"]
What?
[cpg cn=true]

It's not peaceful.
[cpg]

[OnName num="kouya"]
With your mother. My father is in Hungary. I used to spend some time there when I was a kid.
[cpg cn=true]

[OnName num="kouya"]
I was talking to the vice principal about going to a birthday celebration for a family I know, but it turned out to be a no-go."
[cpg cn=true]

[OnName num="takuma"]
Oh, .......
[cpg cn=true]

[OnName num="kouya"]
Whenever I tried to go abroad, the school would get in trouble. I'm sure there's a procedure.
[cpg cn=true]

The academy - to me, it sometimes seems like a prison.
[cpg]

Why do adults take away children's time so easily?　--I'm sure we've all wondered that question before.
[cpg]

They don't care if we students agree, they just tie us up in class.
[cpg]

[OnName num="kouya"]
I remember a science teacher who would kill 90 percent of her time with small talk. And when parents are present for class visits, they do the class right."
[cpg cn=true]

[OnName num="takuma"]
There she is: ......."
[cpg cn=true]

[OnName num="kouya"]
The small talk was usually resentment of current events and some dubious neologism from the limited media.
[cpg cn=true]

[OnName num="kouya"]
If it's such a class, let me go to Hungary. ......
[cpg cn=true]

Even what prevents me from falling in love with Tokieda-sensei is the taboo that "teachers and students are not allowed to fall in love.
[cpg]

The source of the taboo is the school.
[cpg]

[OnName num="kouya"]
The girl who played with me a lot is going to have a younger sister. I want to at least bring her a souvenir from Japan.
[cpg cn=true]

;//(Y)微妙に桜苗ルートの展開を意識しているところ。キャラに一貫性を持たせようとしている（＝家族なしでは生きられない）

[OnName num="kouya"]
Family is important, ...... and it makes you happy."
[cpg cn=true]

As I looked around the club room, I remembered the goal of the manzai club: ...... "To make people laugh.
[cpg]

Suddenly - I had the feeling that I had never seen Dr. Tokie smile before.
[cpg]

[OnName num="kouya"]
'Did you confess your feelings to Tokieda-sensei?
[cpg cn=true]

[OnName num="takuma"]
I did not."
[cpg cn=true]

I lied.
[cpg]

[OnName num="kouya"]
He lied.
[cpg cn=true]

This guy had a good eye for people. I forgot. Damn it.
[cpg]

[OnName num="kouya"]
"You guessed right.　I can read.
[cpg cn=true]

[OnName num="takuma"]
"....... If I - like a swordsman on high.
[cpg cn=true]

[OnName num="takuma"]
"Without a single evil thought, without a single conscious thought, if I farted here, I'd fart loudly."
[cpg cn=true]

[OnName num="takuma"]
Can you 'read'?"
[cpg cn=true]

[OnName num="kouya"]
Sorry. I'm sorry.
[cpg cn=true]

[OnName num="takuma"]
Don't make me draw my sword.
[cpg cn=true]

[OnName num="kouya"]
Sorry.
[cpg cn=true]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep013.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
