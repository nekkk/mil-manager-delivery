
*start|Relationship with Ms. Sakurana

;#################################################
*Ep009|Relationship with Ms. Sakurana
;#################################################

[SCENE id=9]

;//(Y)追加

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_00_1.ui" time=1000]
[WAIT time=3000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]

Several years have passed since then.
[cpg]

;//【ＢＧ】『街』（朝）******************************************************

Kouya went to a different university, but in my case, since I was attending an affiliated school, even the route to school did not change.
[cpg]

I went from uniform to plain clothes and started carrying my laptop computer with me. Also, I was in the Bodoge club, so I had to carry several kinds of cards.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

At the university, the classrooms were almost the same. And I was in the education department.
[cpg]

I would visit familiar classrooms as many times as I could for tours and practical training. I'm a boring guy who chooses to be unchanged.
[cpg]

But the important thing was that my route to see Ms. Sakurana would not change.
[cpg]

;//(Y)流用
[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[SE f="se011"]
;//【ＳＥ】『携帯電話の発信音

I quickly made a phone call to Ms. Sakuranae.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[VOICE f="Sanae068"]
[OnName num="sanae"]
I called her at ....... Yes, this is Miyauji.
[cpg cn=true]

[OnName num="takuma"]
Are you alone?　I have something important to tell you.
[cpg cn=true]

[VOICE f="Sanae069"]
[OnName num="sanae"]
"...... Okay, please wait a moment."
[cpg cn=true]

;//[lbox off]
[free time=1000]
[WAIT time=1000]

This way of speaking sounds like he is not alone.
[cpg]

;//(Y)追加。仮にも全年齢なので、性行為をにおわせるだけで展開がスリルあるものになるはず

Her husband is in Hungary now. Then it must be Koya.
[cpg]

I'm already a college student. I didn't even need the ...... name of handicrafts anymore. He still teaches me, but .......
[cpg]

What I wanted to do was something more direct.
[cpg]

;//(Y)流用

[SE f="se005"]
;//【ＳＥ】『携帯電話の振動音』
[WAIT time=1000]

Once the caller hangs up, this time it's coming from the other end.
[cpg]

[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[VOICE f="Sanae070"]
[OnName num="sanae"]
"Please don't call me on such short notice, ...... you'll be surprised."
[cpg cn=true]

[OnName num="takuma"]
Can we go out tomorrow afternoon?　I'd like to talk to you alone.
[cpg cn=true]

[VOICE f="Sanae071"]
[OnName num="sanae"]
I can go to ......, but..."
[cpg cn=true]

;//(Y)ここはそのまま残そうかな？　ここでバッと直接に「ヤった」事実を出すとびっくりするので面白いかなと。レーティングの危ない綱渡りをしている気もしますが……

It had been a little while since our last act. I was hoping that the memories of what I had done might be growing inside her.
[cpg]

;//(Y)カット

[VOICE f="Sanae072"]
[OnName num="sanae"]
She said, "All right. Lunch is okay?"
[cpg cn=true]

[OnName num="takuma"]
Yes. I won't let you regret it.
[cpg cn=true]

[free time=1000]

[SE f="se035"]
;//【ＳＥ】『携帯電話の通話終了音』

I did what I could ....... It's going to work.
[cpg]

I think Sakuranae-san wants to do more with me after all.
[cpg]

Otherwise, I don't think she would have come on board.
[cpg]

;//ＢＫ

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

Sunday. I told my family that I was going to visit a friend of mine.
[cpg]

Is she his girlfriend by any chance?　I was asked if it was a girlfriend, but I guess I was right.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shiho381"]
[OnName num="shiho"]
"Are you going out now?"
[cpg cn=true]

[OnName num="takuma"]
Oh, yes. ......
[cpg cn=true]

On the way out, Shiho-san happened to be outside and spoke to me.
[cpg]

She's going out somewhere too. She is dressed like that.
[cpg]

Before ......, I might have had a crush on this figure.
[cpg]

But now, I'm all about Sanae-san.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Shiho382"]
[OnName num="shiho"]
I'm going to see a friend. I'm going to see a friend of mine.
[cpg cn=true]

[OnName num="takuma"]
Then, Shiho, go see your friend.
[cpg cn=true]

;//ＢＫ

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

A little time passed and we arrived at the meeting place. The time passed a little bit and the meeting place was a little bit earlier than planned.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Sanae073"]
[OnName num="sanae"]
I've already cooked and eaten dinner. That's all right, right?
[cpg cn=true]

[OnName num="takuma"]
Yes, it's a date. It's a date. Let's go to a hotel.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sSanae024"]
[OnName num="sanae"]
"......."
[cpg cn=true]

I think she was remembering the word ...... nominal. She fumbled and hesitated a little.
[cpg]

In that moment, she must have once again imagined many things. What should I be thinking about for my family?
[cpg]

;//(Y)流用

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sanae075"]
[OnName num="sanae"]
'No. ...... I gave you my phone number, didn't I?'
[cpg cn=true]

That's right. That's right, it would be strange if she didn't have any feelings for me.
[cpg]

That's where I saw the odds, too. And then Ms. Sakuranae said ......
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sanae076"]
[OnName num="sanae"]
Takuma-kun, can you keep this a secret for sure?　Especially to Kouya."
[cpg cn=true]

Talking about my son again. Of course I'll keep it a secret.
[cpg]

[OnName num="takuma"]
I promise."
[cpg cn=true]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『ラブホテル室内』（昼）******************************************************

We are momentarily taken aback by the ...... interior. Sakurae-san is probably more nervous about the situation than about the room.
[cpg]

;//(Y)シャワーに関してフォロー

By the time we got here, both she and I were sweating.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="sSanae025"]
[OnName num="sanae"]
I'm going to go wash up."
[cpg cn=true]

She headed for the shower that had been prepared. The door was closed.
[cpg]

I want to see ....... I want to see .......
[cpg]

The room is well separated from the rest of the house, even though it is in a place like this. It's no different than a normal room.
[cpg]

I noticed that my hands were still and sweaty. Oh, I'm still getting worried about the sweat. ......
[cpg]

[OnName num="takuma"]
"......"
[cpg cn=true]

[OnName num="takuma"]
Sakura Nae-san!　I'm sorry!　I'll use the washroom next door!　Excuse me!"
[cpg cn=true]

;//========================================
;//●ＣＧ非エロ（シャワーを浴びている。扉の向こうかつシャワーで完全にシルエットにしてしまってください）ev_22_1

;//人物１：ヒロイン２
;//服装１：見えないものの裸
;//場所　：（ラブ）ホテルのシャワー。視点主である主人公と扉を隔てている
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_22_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

I was allowed to wash my hands. I washed my hands, and next to me, Sakuranaesan was washing her body.
[cpg]

[OnName num="takuma"]
She was washing her body next to me. "....... I can't see you, you can't see me.
[cpg cn=true]

[VOICE f="sSanae026"]
[OnName num="sanae"]
Takuma-kun, are you there?
[cpg cn=true]

[OnName num="takuma"]
I'm here!　I'm sorry, my hands are sticky with sweat!
[cpg cn=true]

[VOICE f="sSanae027"]
[OnName num="sanae"]
It's okay, there's no need to be nervous. I'm sorry, my hands are sweaty! You can at least see my shadow from there, can't you?
[cpg cn=true]

;//(Y)罪悪感を許してもらうという年上萌え要素に反応しないはずがあるまい……という

I felt my face light up. It's okay," he said. ...... I don't know why my heart is pounding in my chest.
[cpg]

[OnName num="takuma"]
I'm sorry, I'll be back in my room in a minute!　I'm going to go back to my room right now!　I'm sorry!
[cpg cn=true]

I went back to my room.
[cpg]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_00_2.ui" time=1000]
[WAIT time=3000]
[BG f="b_00_3.ui" time=1000]
[WAIT time=3000]

;//【ＢＧ】『ラブホテル室内』（昼）******************************************************

;//(Y)ここは何も語らないようカット。「ただホテルの風景を写して、ちょっと待って、夕方に切り替えただけですが？」という体裁さえあれば引っかからないと思います。そのために主人公も大学生にしたし……

;//ＢＫ
[free time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ラブホテル室内』（夕方）******************************************************

;//(Y)別シーンからの流用

I was going to keep going and give it one more push. But, unexpectedly, it didn't work out that way.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSanae028"]
[OnName num="sanae"]
Takuma, it's about time for Koja to come home.
[cpg cn=true]

[OnName num="takuma"]
"Eh,......, is that so?"
[cpg cn=true]

That's not good. There is no excuse for it in any way.
[cpg]

;//(Y)再びちょっと遡ったところから流用

Neither of us can be away from home for long periods of time.
[cpg]

Each of them will be suspected by their respective families. Especially, Mr. Sakuranae was afraid that his son would find out.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sanae096"]
[OnName num="sanae"]
'If I don't go home soon, Koya will get suspicious of me. ......
[cpg cn=true]

[OnName num="takuma"]
I have to go back too. I have to go back too.
[cpg cn=true]

If she thinks it's her, it might be okay to stay up until the night. Still, I was concerned about Sakuranae-san.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Sanae097"]
[OnName num="sanae"]
Let's get out of here then. ...... I'll do this kind of thing for you again."
[cpg cn=true]

I could hear such words from Mr. Sakuranae. That was today's harvest.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=2000]
[BG f="b_00_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]

;//(Y)追加

I still see her once in a while.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


The "Gieselbach part" is still going on. We often meet at a café to discuss a movie.
[cpg]

With our earnings, we can now at least drink tea and eat cake.
[cpg]

And every time we meet, the guilt inside me starts to creep up. It lives inside me.
[cpg]

It stares into my eyes. From the inside.
[cpg]

;//(Y)流用

[OnName num="kouya"]
Hey, Takuma. Are you hiding something from me?
[cpg cn=true]

[OnName num="takuma"]
What makes you think that? ......
[cpg cn=true]

I replied, with an inner twinge.
[cpg]

[OnName num="kouya"]
I don't know if it's something that's bothering you, or if you're just being distant towards me."
[cpg cn=true]

[OnName num="takuma"]
I don't think so. You're just too worried about it.
[cpg cn=true]

[OnName num="kouya"]
Okay, come stay at my place today.
[cpg cn=true]

[OnName num="takuma"]
Are you serious ......?　What's so funny about guys staying over?
[cpg cn=true]

[OnName num="kouya"]
What are you talking about, I'm serious. I'll do whatever it takes to solve Takuma's problems."
[cpg cn=true]

That's not possible with Koya by any means.
[cpg]

;//(Y)追加

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『部室』（昼）******************************************************

I am treated as an alumnus of the school I used to attend, and I am allowed to go to the club room where I used to attend. It's like a university system.
[cpg]

[OnName num="kouya"]
"Alright," he said. Let's take a video and get the hell out of here. It's a sleepover. I'm sorry. ...... Juniors.
[cpg cn=true]

[OnName num="male_student_A"]
I don't know what the teacher will say if he finds us.
[cpg cn=true]

[OnName num="male_student_B"]
Did you go on to study English Literature, seniors?
[cpg cn=true]

[OnName num="takuma"]
No, education. The other seniors are usually in English literature. ...... This place is famous, isn't it?
[cpg cn=true]

Unless you are a VERY LARGE SCHOOL, can't you focus on all of them? Is there a strategy to specialize in English literature?
[cpg]

Me and Koya took a video. I made a smile and got along well with Koya in appearance.
[cpg]

The tingling in my chest is still there.
[cpg]

;//(Y)流用

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の家＿リビング』（夕方））******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Sanae098"]
[OnName num="sanae"]
I asked him, "Are you going to stay over ......?　Really?"
[cpg cn=true]

Sanae-san looks at me and says such a thing, which is a bad reaction because it makes me look suspicious.
[cpg]

[OnName num="kouya"]
"No, Mom. "No, come on, just for one night."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sanae099"]
[OnName num="sanae"]
'It's fine with me, but what do ...... Takuma-kun's parents say?
[cpg cn=true]

[OnName num="takuma"]
I've already got their permission. It's up to you, Mr. Sakuranae.
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Sanae100"]
[OnName num="sanae"]
I understand. I'm not going to offer you any hospitality, but please forgive me.
[cpg cn=true]

Sanae-san manages to act the part of a normal mother.
[cpg]

It's dangerous, isn't it? I think it's not surprising that Koya would notice this, but I wonder if he's too slow. ......
[cpg]

;//(Y)追加

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
;//[BG f="b_08_3.ui" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洗面所』（夕方）******************************************************

Just as I was about to gratefully use the bath, it seemed I had a visitor.
[cpg]

[OnName num="kouya"]
What?　Dad, are you back?
[cpg cn=true]

[OnName num="sanae_husband"]
"Yes, I'm home. I'm home. Long time no see.
[cpg cn=true]

[OnName num="sanae_husband"]
I heard a relative passed away. I had to go to the funeral.
[cpg cn=true]

[OnName num="kouya"]
By coincidence,......, Takuma is staying with us today.
[cpg cn=true]

;//(Y)流用

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の家＿リビング』（夜）******************************************************

We had dinner with the Miyauji family.
[cpg]

[OnName num="sanae_husband"]
I haven't had a friend over for dinner since I was a kid. I haven't seen him since I was a kid.
[cpg cn=true]

[OnName num="sanae_husband"]
I thought he was bringing a girlfriend, but it turns out he's a guy.
[cpg cn=true]

[OnName num="kouya"]
I thought you were bringing a girlfriend, but it turns out you're a guy. Leave him alone.
[cpg cn=true]

;//(Y)追加。この夫じゃ桜苗のそばにいられないんだろうなあという厚みを出す。葬式で帰ってきた話も、とっとと向こうに戻りたいんだろうな感

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I saw - he exchanged words with Sanae-san and turned away apologetically. Then he resumed eating.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Finally I ended up sleeping in Koya's room. ......
[cpg]

You said you were going to take care of my problems, but Kouya quickly went to sleep.
[cpg]

I have no choice but to try to sleep too, but I can't.
[cpg]

Sanae-san is sleeping under the same roof right now. That makes it all the more special.
[cpg]

[SE f="se003"]
;//【ＳＥ】『ドアをノックする』
[WAIT time=1000]

I heard a knock on the door.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の家＿リビング』（夜）******************************************************

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sanae101"]
[OnName num="sanae"]
I was asleep, right? You were sleeping, weren't you?
[cpg cn=true]

[OnName num="takuma"]
I was thinking about you, Mr. Sakuranae. I couldn't sleep thinking about you.
[cpg cn=true]

;//(Y)追加。このところはキッチリ確かめてほしかったんです……

I kept my voice down for that part. ...... Koya was deeply asleep. No doubt.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Sanae102"]
[OnName num="sanae"]
'So...... I, too, am similar.
[cpg cn=true]

[OnName num="takuma"]
'...... can't you stand it?　I can't stand it."
[cpg cn=true]

He's probably sleeping too. But he might get up to go to the bathroom or something.
[cpg]

Koya may not have to do that, but there is that risk.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Sanae103"]
[OnName num="sanae"]
Me too. I can't just do nothing."
[cpg cn=true]

;//(Y)追加。直接的な描写の回避！　何しようとしてるのか分かればうっすらエロい！

I pulled on a pair of socks from my bag of luggage. I don't even want to make the floor creak.
[cpg]

Kouya is sleeping, but ...... my mouth is lying so that he can hear me.
[cpg]

[OnName num="takuma"]
'Kind of. I ...... just felt thirsty and couldn't sleep."
[cpg cn=true]

I left the room.
[cpg]

;//(Y)一週間後にした上で流用・一部編集


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]

About a week later. I noticed a change in me by the words around me.
[cpg]

[window target=false]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Shiho383"]
[OnName num="shiho"]
"Good morning, Takuma-kun. ...... I wonder if my mood has changed.
[cpg cn=true]

[OnName num="takuma"]
I don't know.
[cpg cn=true]

Does it mean they look more masculine or more confident?
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Shiho384"]
[OnName num="shiho"]
I see,......, you look sleepy.
[cpg cn=true]

[OnName num="takuma"]
Oh, yeah. Yes, I am indeed sleepy, but..."
[cpg cn=true]

...... I sometimes think about Mr. Sakuranae, and at other times I think about Kouya, and I can't sleep. There is certainly that.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[OnName num="takuma"]
Excuse me. Can I have a café mocha, please?
[cpg cn=true]

;//(Y)流用

[OnName num="kouya"]
I don't know, you've changed your mood. You.
[cpg cn=true]

[OnName num="takuma"]
"Do I look sleepy?"
[cpg cn=true]

[OnName num="kouya"]
"Oh, sure. Is that why you look different?
[cpg cn=true]

;//(Y)カット

[OnName num="kouya"]
But you look more dignified, or really different than you did yesterday.
[cpg cn=true]

[OnName num="takuma"]
"I wonder if that's so. ......
[cpg cn=true]

[FADEOUTBGM]

That feeling of guilt came back.
[cpg]

[BGM f="bg_pi"]
[WAIT time=100]

I realized. Every time I see Koya, this guilt comes to my face. It's natural when you think about it.
[cpg]

[OnName num="takuma"]
What's wrong?
[cpg cn=true]

[OnName num="kouya"]
What's wrong?　You look pale.
[cpg cn=true]

Meeting with Koya is the trigger. I became aware of this and hated the man in front of me. It's my childishness.
[cpg]

I feel nauseous at myself.
[cpg]

If I'm betraying Kouya for my selfish love - I'm no better than those guys who bullied me, aren't I?
[cpg]

I'm trampling on those around me and seeking only my own satisfaction.
[cpg]

[OnName num="takuma"]
"......!　......G......!"
[cpg cn=true]

I realize now. My sense of guilt is growing beyond my imagination.
[cpg]

I'm being crushed - no, I'm already being crushed.
[cpg]

[OnName num="takuma"]
"Ughhhh ...... ughhhhhh!"
[cpg cn=true]

I ran to the bathroom.
[cpg]

;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I wanted forgiveness.
[cpg]

My stomach was about to come out. I thought of the stupid video that I had taken with Kouya.
[cpg]

When was the last time we went bowling together?　It was fun. It was really fun. I'm betraying a friend like that.
[cpg]

I'm sorry. I'm sorry. Koya.
[cpg]

Help me. Help me. ......
[cpg]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[OnName num="takuma"]
I'm sorry. It's all settled. It's all empty now. ......
[cpg cn=true]

[OnName num="kouya"]
You'd better go home early today. Take it easy.
[cpg cn=true]

[OnName num="takuma"]
Oh, yeah. I'm sorry, .......
[cpg cn=true]

[OnName num="takuma"]
I'm so sorry.
[cpg cn=true]

[OnName num="takuma"]
I'm really sorry. I need to talk to you about something.
[cpg cn=true]

[OnName num="takuma"]
It's important. I'm ...... keeping a secret."
[cpg cn=true]

Koya looked at me strangely, but did not ask any more questions. He is a good guy. He cared about me.
[cpg]

I was at my limit.
[cpg]

;//(Y)ここで桜苗さんの魅力を印象づけるエピソードがないと拓馬VS耕哉の殺し合いの説得力がちょっと足りない

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

What the hell is wrong with me?　......I didn't have much of an appetite that day. So I had no energy.
[cpg]

If I could have stopped this kind of unforgivable love, I would have.
[cpg]

I was weak and even tried to force myself to think about what was wrong with Ms. Sakuranae and what was unforgivable.
[cpg]

[OnName num="takuma"]
".......
[cpg cn=true]

[OnName num="takuma"]
I tried to think of something wrong with her, something I couldn't forgive her for. I can't think of any.
[cpg cn=true]

If my will had been a little stronger, would I have given up on Ms. Sakuranae ......?
[cpg]

[SE f="se036"]
;//【ＳＥ】『携帯電話の通知音』
[WAIT time=1100]

...... hmm?　It's a message from Mr. Sakuranae.
[cpg]

;//========================================
;//●ＣＧ非エロ（スマートフォンの一般的なホーム画面）ev_51_0　再度流用
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//(Y)桜苗さんのボイス新規録音コストなしでキャラを表現する抜け道として、メッセージを使うつもりです。必要なら適宜こうしたシーンを膨らませる形でキャラ表現ができるはずです

[OnName num="sanae"]
<Did you feel ok today?　I think you should eat some porridge or something. I hear chicken and stuff is good for digestion>
[cpg cn=true]

Oh, I wonder if Kouya talked to him. He didn't even have to bother talking about this stuff. ......
[cpg]

I almost cried. The kindness soaked into me.
[cpg]

I wonder what they would talk about at home without their husbands. If it's just the two of us, I wonder if we talk a lot.
[cpg]

I hope the conversation between the two of us is fun and we laugh at silly things. ......
[cpg]

[OnName num="sanae"]
<Maybe I can let you listen to the performance sometime. Koya is going to be a committee member for the college festival>
[cpg cn=true]

[OnName num="sanae"]
<I told him that my schedule was free and I might be able to help out with the presentation, and that seemed to be the deal.
[cpg cn=true]

What a surprise! Finally, we get to hear Sakura Nae-san play? It's not a real ......, but it's an opportunity I've been missing out on.
[cpg]

[OnName num="sanae"]
<What about advertising flyers?　Koya keeps asking me, "What are you going to do with the advertising flyers? I'll practice hard. Looking forward to it.>
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=false]

One week to the festival. The day of rehearsal. Kouya went out early in the morning because he was a member of the committee.
[cpg]

Me and Ms. Sakuranae got in that car and headed to Koya's university.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

;//[SE f="se000"]
;//【ＳＥ】走行音

In the backseat, the black instrument case of the viola was heavy with weight. There were two black dial locks on it.
[cpg]

[SE f="se027"]
;//【ＳＥ】『喧噪』

[FADEOUTBGM]

[OnName num="takuma"]
'...... traffic jam?　And there's a crowd of people."
[cpg cn=true]

[BGM f="bg_pi"]
[WAIT time=100]

[OnName num="takuma"]
No way. ...... traffic accident?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

Our car couldn't move forward. I check the time. ...... is fine. We still have time.
[cpg]

We can make it to the rehearsal.
[cpg]

Mr. Sakuranae turned into a narrow alley. But there were many cars stuck in traffic there too. He had no choice but to pull over to the shoulder of the road.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="sSanae029"]
[OnName num="sanae"]
He said, "Go to ...... and watch the instrument case. Watch the instrument case.
[cpg cn=true]

She got out of the car and walked to the center of the traffic jam.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Mr. Sakuranae soon returned. He then asked for something strange.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[VOICE f="sSanae030"]
[OnName num="sanae"]
Takuma-kun. Takuma, give me the ...... instrument case.
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="sSanae031"]
[OnName num="sanae"]
Someone is dying.
[cpg cn=true]

[OnName num="takuma"]
!
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se053"]
;//【ＳＥ】救急車のサイレン

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧噪』

There was a car that had crashed into a building and was on fire. It was already completely charred and crushed. Several upside down and sideways cars around.
[cpg]

Traces of blood were smeared all over the road, and it smelled burnt.
[cpg]

An ambulance staggered to a stop. Many onlookers were yelling in the distance.
[cpg]

[OnName num="takuma"]
"Uh-oh... ........."
[cpg cn=true]

[OnName num="press_A"]
Hey!　Stop the camera!　You can't film this. ......!
[cpg cn=true]

[OnName num="press_B"]
Find a place a little further away!　Oh no!　This is ...... ogee-eee-eee-eee ......"
[cpg cn=true]

In the world of fiction, we are often in the midst of professional discrimination - people in the media profession.
[cpg]

The world's stereotype of them is this: cold-bloodedly seeking special stories, trampling on people's privacy and dignity.
[cpg]

[OnName num="press_C"]
No!　Oh no!　Such ...... ugh!"
[cpg cn=true]

Even they turn away, some clamping their mouths or stomachs and shuffling off.
[cpg]

[free time=800]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSanae032"]
[OnName num="sanae"]
Takuma-kun. You didn't have to come."
[cpg cn=true]

[OnName num="takuma"]
'...... a little, it's a bit harsh.'
[cpg cn=true]

At first glance, there is a cherry red car that is only lightly dented. The horn keeps honking and won't stop.
[cpg]

A man was dead in the driver's seat with his forehead pressed against the steering wheel.
[cpg]

I don't know anything about the car. But now I know - the horn has a button on the steering wheel that won't stop the sound.
[cpg]

[OnName num="paramedics_A"]
Until we find a hospital that can take him. ...... ah."
[cpg cn=true]

There was a man and a woman lying on their backs. The man had a black triage tag around his right wrist. The woman's was red.
[cpg]

The trooper saw the black tag and screamed. Here was reality.
[cpg]

The color black--"Already dead or not expected to recover even with CPR.
[cpg]

Medical resources are limited. Black is the color of abandoned lives. That was the man's tag.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="sSanae033"]
[OnName num="sanae"]
That man.
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="sSanae034"]
[OnName num="sanae"]
He saw my face clearly. He said, faintly, 'Play.
[cpg cn=true]

A new, young member of the team came and sat down in front of the woman. She seemed unfamiliar with the situation and her eyes swam as she took out a black ballpoint pen.
[cpg]

He seemed to be trying to rewrite something. But he failed to write it down. After some hesitation, he removes the entire red tag from the woman.
[cpg]

He wraps the new triage tag back around the woman's right arm - and rips the paper off halfway through. This time, the black remains, not the red.
[cpg]

She dies.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="sSanae035"]
[OnName num="sanae"]
Excuse me, paramedics. Paramedics. May I play my viola?"
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="sSanae036"]
[OnName num="sanae"]
He wants to hear me play for the last time. I know he's unconscious.
[cpg cn=true]

[OnName num="paramedics_A"]
"Oh, ......, you were talking about that earlier. Can you play, please?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
The corpsman had muscles. He was nodding his head like that.
[cpg]

Even the life that could still be saved would not be able to find a hospital that would accept him. From the ambulance, I hear an exasperated caller's voice.
[cpg]

[OnName num="paramedics_A"]
I've been doing this for 12 years, and I'll never get used to it. I told them to stay conscious, but it was just a habit.
[cpg cn=true]

[OnName num="paramedics_A"]
I can't put you in the ambulance, so you'll have to play here. We're going to the morgue, not the hospital.
[cpg cn=true]

[OnName num="paramedics_A"]
I'm sorry. I'm sorry. I'm sorry.
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="sSanae037"]
[OnName num="sanae"]
I'm sorry. I'm sorry, Takuma-kun. That's why.
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="sSanae038"]
[OnName num="sanae"]
I'll be late for the festival.
[cpg cn=true]

I thought Sakurae-san was cool.
[cpg]

[FACE method="change_2" pos="2/3"]

A couple of guys with yet another instrument come out from a nearby music store. I smiled at her, but sadly.
[cpg]

There was nothing I could do. I returned to the car.
[cpg]

;//(Y)ここで著作権期限切れのビオラのクラシックとか流せたらいいんですが……楽器屋の男たちはビオラ・ソロの楽曲があんまりなさそうな気がしたので、他の楽器が入る曲選びの余地をフォローするものです。いらなければ上のその部分の行を削ってください。のちのエンディングでもこの曲を使います

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_00_2.ui" time=1000]
[WAIT time=2000]
[window target=true]

From far away, I heard a beautiful, yet somewhat sad tone.
[cpg]

I called Koiya and told him I would be late for the rehearsal. He would be late for the rehearsal.
[cpg]

It was right that I fell in love with him. I felt it was inevitable fate. I was somewhat proud.
[cpg]

Isn't it natural to fall in love with someone who plays beautiful music for the sake of the dying?
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep010.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
