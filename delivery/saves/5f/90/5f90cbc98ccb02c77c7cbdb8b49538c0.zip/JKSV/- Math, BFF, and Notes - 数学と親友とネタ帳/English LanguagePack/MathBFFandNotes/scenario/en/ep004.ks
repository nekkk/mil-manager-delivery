
*start|I want to help Shiho-san

;#################################################
*Ep004|I want to save Shiho-san.
;#################################################

[SCENE id=4]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

Morning comes, leaving me sleepy and unsteady.
[cpg]

Today, too, my mother and Shiho-san are talking. I was so sleepy that I couldn't even stay conscious until a while ago. ......
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shiho030"]
[OnName num="shiho"]
Good morning, Takuma-kun. Takuma-kun.
[cpg cn=true]

[OnName num="takuma"]
"Oh, oh, good morning!"
[cpg cn=true]

;//(Y)変更

I get more nervous than usual. The more I get to know this person, the more excessive it is.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sShiho021"]
[OnName num="shiho"]
What's wrong?　You look pale.
[cpg cn=true]

[OnName num="takuma"]
It's nothing, I'm fine.
[cpg cn=true]

I'm more worried about Shiho than me.
[cpg]

I was worried more about Shiho than I was about me.
[cpg]

[OnName num="sakura_mother"]
"I heard your husband came back?"
[cpg cn=true]

Shiho did not say anything. She seemed to be at a loss for words.
[cpg]

Stop it, Mom. I'll tell you about it at ....... I left the place, unwilling to leave.
[cpg]

I had to help her.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

I honestly couldn't stand to listen to the classes at school.
[cpg]

No matter who the teacher was. I had lost interest in Tokieda-sensei as well.
[cpg]

After all, after seeing her like that, my impression of her changed strongly.
[cpg]

;//(Y)追加

[window target=false]
[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『部室』（夕方）******************************************************

[OnName num="kouya"]
Takuma. What's the story for your next video?"
[cpg cn=true]

I discuss the next video with Kouya. I haven't made any videos recently.
[cpg]

Me and Koya, the "Gieselbach part". It is a sensitive part of the back of the nose that causes nosebleeds when it is slightly damaged.
[cpg]

It has a right and left side, and it's facing the name of the pair, pure, delicate, but abominable.
[cpg]

[OnName num="takuma"]
Now, 'Dobasaki' is back next to me.
[cpg cn=true]

[OnName num="takuma"]
His real name is still unknown. I know his sex because he's Mr. Iizoku, but I'm going to ask him for his name."
[cpg cn=true]

[OnName num="kouya"]
"You mean the 'I asked a celebrity for his real name' kind of ......?　You're going to tell me?"
[cpg cn=true]

[OnName num="takuma"]
If anything, it would look better in the video if I broke his balls."
[cpg cn=true]

Of course, this is my first plan to meet that Dobasaki - to create an opportunity to get acquainted.
[cpg]

Little by little, we get closer. And then I'm going to meet Dobazaki and his wife, Shiho, more often.
[cpg]

[OnName num="takuma"]
I want to make them feel as close to me as possible.
[cpg cn=true]

--I'm going to try to find an opening for him and get evidence of what he's doing in the home.
[cpg]

I'm going to set him on fire.
[cpg]

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_00_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
;//ＢＫ

I'm going to ruin him. For the sake of love, to repay my debt to Shiho-san.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

;//(Y)追加。ねちっこい嫌な奴です！　という存在感を強めたい意図

On my way home. I felt eyes on me from behind.
[cpg]

I was being followed.
[cpg]

[OnName num="takuma"]
......
[cpg cn=true]

I knew who it was without looking. It was evening and the air was cool and fresh, but my whole body was itching.
[cpg]

I can't allow the man who is courting Shiho-san to exist--"Dobasaki".
[cpg]

That guy is behind me.
[cpg]

Aren't entertainers supposed to be busy .......
[cpg]

I went home with a blank expression on my face. It would be bad if I made him angry now.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I then uploaded a video of a live video game.
[cpg]

It's a set of me and Kouya, but I also upload videos by myself. Just having some kind of update is enough to make the viewers feel at ease.
[cpg]

[OnName num="takuma"]
He said, "Oh, my ally!　Nice!　I lost the group battle!　Now my special move is ...... ah ah."
[cpg cn=true]

[OnName num="takuma"]
I guess it was bad timing. But I can forgive him because he apologized in the chat room. Manners are important."
[cpg cn=true]

...... If 'that guy' next door can hear you, you're on target. I want them to think I'm just a crappy distributor.
[cpg]

Whatever the case, if I'm going to flame him, I want a number of viewers on my channel.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

Thanks to those efforts, there was no more sign of that guy on my way home.
[cpg]

And now, a few days later, he seems to be out filming the finals for that show. I've been looking into that, too.
[cpg]

I'll try to get his real name for the video another time. ...... He's busy, too, and he's turned me down for now. For now.
[cpg]

[OnName num="takuma"]
"Mr. Shiho,......, I haven't seen you in a while.
[cpg cn=true]

I think we need to talk once, don't you?　I want to tell Shiho-san that I'm on her side,.......
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho032"]
[OnName num="shiho"]
Oh my, Takuma-kun. What are you doing in front of my house?
[cpg cn=true]

[OnName num="takuma"]
"Oh,...... well, you know. I'm ...... having a little trouble.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Shiho033"]
[OnName num="shiho"]
"What can I do for you? Do you want to come up?"
[cpg cn=true]

I reconsidered. Now that he's gone, there's nothing to be afraid of. ......
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿リビング』（夕方）******************************************************

She led me over to the table.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sShiho022"]
[OnName num="shiho"]
I've just made coffee chicken," she said.
[cpg cn=true]

[OnName num="takuma"]
"Coffee chicken?
[cpg cn=true]

I was suddenly hit with a bomb. I had never had this dish before. At least, not a popular dish.
[cpg]

I was going to have an important conversation with him, but I was kind of off to a bad start. I'm glad, though.
[cpg]

She brought me some dishes and curry soup. Thank you very much.
[cpg]

;//========================================
;//●ＣＧ非エロ（テーブルで主人公と話している想定です。元の絵では陰部を握っている手を、テーブルにそっと置いているようにしてください。手前に飲み物などを置くと雰囲気が出るかもしれません）ev_11_1
;//人物１：ヒロイン１
;//服装１：私服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_11_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

Mooch. Coffee chicken tastes more interesting than I expected. ......
[cpg]

I'm even happier to see Shiho in front of me. This alone was an ideal meal.
[cpg]

[OnName num="takuma"]
This is interesting. The chicken is solid chicken and tasty, but there is a slight aroma and bitterness when you eat it. ......
[cpg cn=true]

[VOICE f="sShiho023"]
[OnName num="shiho"]
Hmmm. Thank you for the ideal meal report. Do you do any video streaming?
[cpg cn=true]

[OnName num="takuma"]
Yes. As a matter of fact, yes."
[cpg cn=true]

[VOICE f="sShiho024"]
[OnName num="shiho"]
Speaking of coffee, my husband doesn't like it. He won't even let me use the coffee bath salts.
[cpg cn=true]

[OnName num="takuma"]
"Oh, I'll do the dishes. I'll wash the dishes.
[cpg cn=true]

The living room is clean. It's as if it's been set up for guests ...... ostensibly.
[cpg]

If they are being violated on a daily basis, there must be blood or other marks somewhere.
[cpg]

I thought to myself. Could you show me the bathroom? I don't think I can show you the bedroom.
[cpg]

It would be unnatural to ask them to let me use the washroom when I had just entered the house. It would be rude. I want to talk to him.
[cpg]

[VOICE f="sShiho025"]
[OnName num="shiho"]
I'd like to talk to you. I feel like you've got muscles and stuff.
[cpg cn=true]

She sighed. I don't think Shiho is going to confide in me.
[cpg]

Even my mom, who I talk to on a daily basis, doesn't seem to talk to me. ......
[cpg]

But I am the neighbor, the one who can move without the fear of that man's shadow. So I want to move. Maybe I'm meddling.
[cpg]

;//(Y)以下は元文の展開を使用

;//[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho051"]
[OnName num="shiho"]
So what is it?　What's your problem?"
[cpg cn=true]

[OnName num="takuma"]
"Yes, actually. ......"
[cpg cn=true]

I start to talk about something or other.
[cpg]

I wait for Shiho to go to the bathroom. But is that a realistic strategy?
[cpg]

I would have to talk for at least two hours, and then the topic of conversation would be exhausted.
[cpg]

I wondered if it would go well ...... since I was confiding in him about a problem I never had in the first place.
[cpg]

[OnName num="takuma"]
"Even if I end up going on to higher education, I don't know what I'm going to ...... pursue.
[cpg cn=true]

;//[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho052"]
[OnName num="shiho"]
I'm sorry for a minute. I'm going to the bathroom, wait for me."
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿リビング』（夕方）******************************************************

The chance came easily.
[cpg]

[free time=1000]

I would take that moment to look for the bathroom while she sat down to use the restroom.
[cpg]

I have an idea which way the bathroom is located, it should be the same direction as the restroom.
[cpg]

;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

;//(Y)変更
[OnName num="takuma"]
I want to help Shiho-san, ......."
[cpg cn=true]

It was that one thought.
[cpg]


;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_08_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洗面所』（夕方）******************************************************

And then - in the washroom - I found a smartphone, sticking out of a man's pants.
[cpg]

[OnName num="takuma"]
"This is ......, no way."
[cpg cn=true]

No, wait. This is indeed a bad idea.
[cpg]

;//(Y)余裕があったらここは選択肢とする。プレイヤーに自発的に「調べる」選択をさせることで、より没入させる事ができるポイント

...... his smartphone.
[cpg]

The bathtub is slightly warm. The bathtub seems to be heating up. I thought about it.
[cpg]

It looks like Shiho-san is still in the bathroom. ...... How much time do I have?
[cpg]

[OnName num="takuma"]
No," he said. I'll go to ...... and help Shiho.
[cpg cn=true]

--I'm going to help her. I need as many clues as possible to help her.
[cpg]

After all, he is a celebrity. We want to probe him from every possible direction in order to give him the most lethal attack.
[cpg]

I opened the ...... smartphone.
[cpg]

;//========================================
;//●ＣＧ非エロ（完全新規。黒背景に、スマートフォンの拡大画像が出ている。一般的なホーム画面）ev_51_0
;//人物１：なし
;//場所　：場所にかかわらず使用できるようにしてください。流用予定です（この場面では洗面所）
;//時間　：時間にかかわらず使用できるようにしてください。流用予定です（この場面では夕方）
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[OnName num="takuma"]
...... unlocked.
[cpg cn=true]

I opened the email.
[cpg]

>I opened the text message.　I'm free at night?
[cpg]

......This was out of the blue. I had a bad feeling about this.
[cpg]

[OnName num="takuma"]
Seriously? ......
[cpg cn=true]

>I'm going to be in Tokyo at 16:16!　I'm definitely going to make him squeal today!
[cpg]

I was starting to feel sick. Seriously, oh no. .......
[cpg]

I was going to explore the flamewars. I can't believe how easy that was to get.
[cpg]

I want to reconfirm an important fact here - the stage name: Dobasaki Gorogoro has a wife. Yes, it is Shiho.
[cpg]

She was a comedian first, so the fact that she is married is acceptable, but she also started selling in the direction of idols.
[cpg]

But cheating is another matter entirely.
[cpg]

I looked at the list of contacts. The men had last names plus first names, but there were many female-like nicknames, such as "Miki," "Sally," and so on.
[cpg]

I counted the female-like names. ......30. ......40. ......I stopped counting.
[cpg]

I am indeed nervous about the dark fact that I am fishing for people's information on my phone like this.
[cpg]

But I wonder if he's more likely than ...... to have these relationships with people who are routinely immersed in that kind of thrill.
[cpg]

>to: deleted contact body: did you leak about me to a magazine?
[cpg]

I think this is an email to a man. The text is obviously not sexy and cold.
[cpg]

[OnName num="takuma"]
......"
[cpg cn=true]

I began to hear a rustling sound from Shiho's side as she was going to the bathroom. I should finish soon. ......
[cpg]

And then a thought occurred to me. A thought occurred to me.
[cpg]

If he left his smartphone here - doesn't that mean he's coming back here?
[cpg]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

[window target=false]
[free time=800]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=800]
[BG f="b_04_3.ui" time=800]
[WAIT time=2000]

;//【ＢＧ】『ヒロイン１の家＿リビング』（夕）******************************************************

;//(Y)一瞬だけ表示するほうがキレのある演出になる？

[window target=false]
[free time=1000]
[BG f="b_08_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洗面所』******************************************************

;//(Y)地味に台詞使い回しています。録音の必要はありません

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shiho053"]
[OnName num="shiho"]
Takuma-kun?"
[cpg cn=true]

Shiho-san came out of the bathroom.
[cpg]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』
[WAIT time=1000]
I hear another chime from the front door.
[cpg]

[FACE method="change_5" pos="2/3"]

[OnName num="dobazaki"]
"Oh-oh!　Open up!
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="sShiho026"]
[OnName num="shiho"]
"......Hide!　Go to the bath!
[cpg cn=true]

Shiho headed for the living room.
[cpg]

[OnName num="takuma"]
"Shit!"
[cpg cn=true]

I ran into the bath. In my socks.
[cpg]

[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_08_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洗面所』（浴槽へズーム。手前洗面所があまり見えないよう）******************************************************

I heard the front door open. Then I heard a voice.
[cpg]

[OnName num="dobazaki"]
"Sorry, man. I left my smartphone at home.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sShiho027"]
[OnName num="shiho"]
......."
[cpg cn=true]

Just being here, I can feel the tension in the air. No, the first one is probably me, ......!
[cpg]

[OnName num="dobazaki"]
The recording has been postponed. I'm not feeling well for the "170,000 people I've beaten". They say he overdid the food reportage."
[cpg cn=true]

;//(Y)特別な演出をしないで以下の文章をそっとプレイヤーに差し出してほしいです。シナリオ的にはこいつは邪悪で、行いも邪悪ですが、ゲームという形になれば、ドバ崎はこの名前がメッセージウィンドウに出る時点で面白カス野郎の成分を含むのです……かっこよかったり胸クソ悪い悪としては立てられないキャラなのです……

[OnName num="dobazaki"]
Guillain-Barre syndrome, reflux esophagitis, acute alcoholism, and a house collapse.
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="sShiho028"]
[OnName num="shiho"]
So, on the contrary, you were knocked down. ......
[cpg cn=true]

I've got to be careful too. ......
[cpg]

[OnName num="dobazaki"]
Damn it, .......
[cpg cn=true]

[OnName num="dobazaki"]
I've been forced to sit through a lube-wrestling shoot.
[cpg cn=true]

[OnName num="dobazaki"]
I hope your bathtub is boiling.
[cpg cn=true]

--I hope the bathtub is boiling!
[cpg]

[SE f="se022"]
;//【ＳＥ】『足音』

The sound of his footsteps is approaching the bathtub where I am. It's not good.
[cpg]

[OnName num="dobazaki"]
"Hey!　I found my phone here ......."
[cpg cn=true]

I remembered that I had left his phone behind when I ran away from him in a panic. Nice, me.
[cpg]

I'm too impatient and vague even for myself. ......
[cpg]

[SE f="se029"]
;//【ＳＥ】『衣擦れ』

I'm so desperate, even I'm a little fuzzy about it.
[cpg]

What are you going to do......!　Me!
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="sShiho029"]
[OnName num="shiho"]
Yes," he said, "I'm going to take a bath!　...... today's bath salts!"
[cpg cn=true]

[OnName num="dobazaki"]
Oh?
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="sShiho030"]
[OnName num="shiho"]
I didn't think you'd be back!
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="sShiho031"]
[OnName num="shiho"]
Coffee bath salts.
[cpg cn=true]


;//========================================
;//●ＣＧ非エロ　ev_11_1
;//テーブルの場面で使ったCGです。思い出す表現なのでセピア調にしてください
;//========================================
[window target=false]
[free time=1000]
[BG f="b_ev_11.ui" time=1000]
[WAIT time=1000]
[window target=true]

[VOICE f="sShiho024"]
[OnName num="shiho"]
Speaking of coffee, my husband doesn't seem to get along with it. He won't even let me use the coffee bath salts."
[cpg cn=true]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1000]
[BG f="b_08_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『洗面所』（浴槽へズーム。手前洗面所があまり見えないよう）******************************************************

I quickly and quietly opened the pile of coffee bath salts on the bath rack.
[cpg]

I gently dissolved it in the bathtub full of hot water.
[cpg]

[OnName num="dobazaki"]
"What the ......?
[cpg cn=true]

[OnName num="dobazaki"]
It's a lotion wrestling match!　I want to wash it off right now!
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="sShiho032"]
[OnName num="shiho"]
There's a hot spring in Mt!　You should go there!　It's only 800 yen on weekdays!
[cpg cn=true]

[OnName num="dobazaki"]
I'm going to go to the "Seina-yama no yu"!　Ugh...... coffee smell!　My nose itches. ......
[cpg cn=true]

[OnName num="dobazaki"]
"......!　Shhh, but ......!　Even I can stand a shower without getting in hot water!
[cpg cn=true]

I added more coffee bath salts.
[cpg]

Two, three, four.
[cpg]

[OnName num="dobazaki"]
Gaaaaaaaaaahhh!　The smell wafting in the air!　It's thick!　It's so strong!
[cpg cn=true]

That's a lot of work. I'm starting to feel sorry.
[cpg]

[OnName num="dobazaki"]
Gaaaahhhh!"
[cpg cn=true]

;//ＢＫ

Dobasaki grabbed the towel and walked out of the room.
[cpg]

I was out of danger.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『洗面所』******************************************************

And I, slightly damp, am now facing a new crisis, Shiho-san in front of me. ......
[cpg]

;//(Y)以下は、詩穂だけ元文の展開を使用

[FACE method="bow_7" pos="2/3"]
[VOICE f="Shiho054"]
[OnName num="shiho"]
I see. You mean the real trouble is this way. ......
[cpg cn=true]

[OnName num="takuma"]
?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Shiho055"]
[OnName num="shiho"]
"......, I'll pretend I didn't see it. I'll walk you to the door.
[cpg cn=true]

It seems that something has been misunderstood. Well, I'm the one who came to the washroom while Shiho-san went to the bathroom. ......
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Shiho057"]
[OnName num="shiho"]
"Huh. ...... how can I get back to the original Takuma-kun?"
[cpg cn=true]

[OnName num="takuma"]
Um. Do you think I'm an underwear thief or something?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

Shiho froze. 'No?' Silence like.
[cpg]

[OnName num="takuma"]
"I'm ......
[cpg cn=true]

[OnName num="takuma"]
"That man has been ...... assaulting you, Miss Shiho. He said you might have been violated.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

I cut him off.
[cpg]

Silence again. But it was a rather heavy silence.
[cpg]

On the wall, I saw a picture of Shiho and her husband smiling. They were both smiling and making peace signs at the amusement park.
[cpg]

I felt sad. They had certainly been a good couple in the beginning.
[cpg]

;//(Y)新規追加

[FACE method="shock_5" pos="2/3"]
[VOICE f="sShiho033"]
[OnName num="shiho"]
How did you know that ......?
[cpg cn=true]

[OnName num="takuma"]
I'm right next to you. I can hear them. I can see them.
[cpg cn=true]

[OnName num="takuma"]
I'm ...... trying to get proof of that.
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="sShiho034"]
[OnName num="shiho"]
No way, did you call the police at ......?
[cpg cn=true]

[OnName num="takuma"]
No, not yet. No, not yet. I'm just being cautious because I'm dealing with someone else.
[cpg cn=true]

Shiho was visibly dismayed. Oh, poor thing.
[cpg]

I would have loved this person a lot more than that guy. I would whisper love to him to make him happy.
[cpg]

I love her. Shiho. I don't think ...... love is about being married or not. ......
[cpg]

[OnName num="takuma"]
He's ...... Dobasaki is having an affair.
[cpg cn=true]

[FACE method="shock_4" pos="2/3"]
[VOICE f="sShiho035"]
[OnName num="shiho"]
Duh."
[cpg cn=true]

The atmosphere was that Shiho was ...... dimly aware of the situation. Though the smartphone wasn't locked,.......
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="sShiho036"]
[OnName num="shiho"]
Did you see it on ...... his private social networking account?
[cpg cn=true]

[OnName num="takuma"]
No, it was a text message.
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sShiho037"]
[OnName num="shiho"]
;//「浮気すら私にバレても問題もないって、思ってたんだね」
I guess he thought it wouldn't matter if I even found out about the affair.
[cpg cn=true]

[OnName num="takuma"]
You didn't see it, did you?
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="sShiho038"]
[OnName num="shiho"]
If he finds out I saw it, ...... it will get intense again. I was afraid that if I accidentally slipped up, it would be a bad idea.
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sShiho039"]
[OnName num="shiho"]
What are you going to do now that you know?　It won't change anything.
[cpg cn=true]

[OnName num="takuma"]
I hate him. ......She is the one who does terrible things to you. I hate him for what he did to you.
[cpg cn=true]

[OnName num="takuma"]
I want to burn him down. Fame is his stronghold. ......I want to take Shiho away from him.
[cpg cn=true]

[OnName num="takuma"]
Don't you want to return the favor by cheating on her?
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="sShiho040"]
[OnName num="shiho"]
"You know what that ...... means, don't you,......?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="sShiho041"]
[OnName num="shiho"]
He's not quite his breakthrough yet, but there's quite a bit of money going around," he said. And the industry he was in."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="sShiho042"]
[OnName num="shiho"]
He's been approached about doing some regular shows. I see his face in all the Internet ads.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="sShiho043"]
[OnName num="shiho"]
I hate it when I see that smile on .......
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sShiho044"]
[OnName num="shiho"]
Takuma-kun. What you see in front of you is a woman who is cursed by ...... such a man.
[cpg cn=true]

[OnName num="takuma"]
Shiho. I like you."
[cpg cn=true]

[OnName num="takuma"]
I'll make you happier--"
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="sShiho045"]
[OnName num="shiho"]
Stop it!
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="sShiho046"]
[OnName num="shiho"]
I'm not a woman who is cursed by a man like that!　I'm going to be ...... so!
[cpg cn=true]

[FACE method="shock_4" pos="2/3"]
[VOICE f="sShiho047"]
[OnName num="shiho"]
No!　I can't. Takuma-kun and I are ......!
[cpg cn=true]

I took those words as they came. He is still a kind man ...... too kind.
[cpg]

What are we talking about in a washroom like this ...... us.
[cpg]

;//(Y)問題ありそうなら、ぼかすべき箇所？

[FACE method="change_4" pos="2/3"]
[VOICE f="sShiho048"]
[OnName num="shiho"]
"I ...... and Takuma-kun are the same age."
[cpg cn=true]

[OnName num="takuma"]
"I like older people,...... no, you're wrong."
[cpg cn=true]

[OnName num="takuma"]
I like Shiho-san."
[cpg cn=true]

....... The two of us couldn't say anything after that.
[cpg]

I think I've told you what I can tell you. I don't know what to do from now on. ......
[cpg]

Oh, there are still things I need to say.
[cpg]

[OnName num="takuma"]
I'm on your side.
[cpg cn=true]

[OnName num="takuma"]
I want to repay you for what you did for me.
[cpg cn=true]

[OnName num="takuma"]
I don't care who I'm fighting.
[cpg cn=true]

[OnName num="takuma"]
I'm only looking at you.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="sShiho049"]
[OnName num="shiho"]
......
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sShiho050"]
[OnName num="shiho"]
Oh, I'm sorry. Takuma-kun.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="sShiho051"]
[OnName num="shiho"]
"Tears, I'm starting to ...... cry."
[cpg cn=true]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿リビング』（夜）******************************************************

Later that night...
[cpg]

The coffee bath smell wafted into the living room, and I couldn't stand it anymore.
[cpg]

What should I do about that bath ......?
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="sShiho052"]
[OnName num="shiho"]
I diluted it, in case you're wondering.
[cpg cn=true]

[OnName num="takuma"]
"Yes,......, I'm sorry. It's my fault.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="sShiho053"]
[OnName num="shiho"]
Do you want to take a bath?
[cpg cn=true]

[OnName num="takuma"]
What?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sShiho054"]
[OnName num="shiho"]
I confessed my feelings to you, and you didn't react that way.
[cpg cn=true]

Well, that's true, too.
[cpg]

Since I had been hiding in that bath earlier, I was also sweating delicately and clammy.
[cpg]

;//(Y)お色気要素。コーヒー風呂と湯煙で多くは消えちゃいますが……。ev_16が元から風呂のシーンなので使いたいのですが、男が胸を揉んでいるのは修正対象ということで、19,20を直して使うことを想定しています。問題なさそうなら16も使っちゃって大丈夫です

;//========================================
;//●ＣＧ非エロ（湯煙とコーヒー風呂とタオルで、大事な箇所を見えないよう修正してください）ev_20）
;//人物１：ヒロイン１
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：風呂
;//時間　：夜
;//========================================
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[SE f="se000"]
;//【ＳＥ】『お風呂につかる音　チャプチャプ』

In -- in. Why am I in there with Shiho?
[cpg]

[VOICE f="sShiho055"]
[OnName num="shiho"]
I'm going to ask you to take the responsibility for making it a thick coffee bath.
[cpg cn=true]

[OnName num="takuma"]
What do you mean? And wasn't it Shiho who told me to use bath salts?
[cpg cn=true]

[VOICE f="sShiho056"]
[OnName num="shiho"]
What do you mean?
[cpg cn=true]

The water is warm. But it's more than the temperature of the hot water. ...... My body feels like it's on fire. The cause is obvious.
[cpg]

I'm not used to this kind of situation. ......
[cpg]

;//(Y)2行流用してみます

[VOICE f="Shiho264"]
[OnName num="shiho"]
"Mmmm, Takuma-kun's fingers are so tough,......, they feel like a man's fingers."
[cpg cn=true]

Do you think they're tough?　I consider my fingers to be normal fingers.
[cpg]

I mean, I'm touching it. ......!
[cpg]

[VOICE f="sShiho057"]
[OnName num="shiho"]
I'm lying. Were you in a hurry?"
[cpg cn=true]

[OnName num="takuma"]
You have quite a nice personality,......, Shiho.
[cpg cn=true]

[VOICE f="sShiho058"]
[OnName num="shiho"]
I couldn't even say much naughty stuff.
[cpg cn=true]

[VOICE f="sShiho059"]
[OnName num="shiho"]
Thank you, Takuma. I appreciate it. Me."
[cpg cn=true]

She hugged me.
[cpg]

;//========================================
;//●ＣＧ非エロ（湯煙とコーヒー風呂とタオルで、大事な箇所を見えないよう修正してください）ev_19）
;//人物１：ヒロイン１
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：風呂
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sShiho060"]
[OnName num="shiho"]
"...... warm."
[cpg cn=true]

[OnName num="takuma"]
She hugged me and said, "Hey ......!　Wait!
[cpg cn=true]

I'm ...... going to get a little hot ...... if I don't!
[cpg]

[VOICE f="sShiho061"]
[OnName num="shiho"]
Do you want me to wash your body?
[cpg cn=true]

[OnName num="takuma"]
I'm fine!　I'm fine!
[cpg cn=true]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

After I cleaned myself up once more, we left the bath.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿リビング』（夜）******************************************************

;//(Y)流用

[FACE method="change_1" pos="2/3"]
[VOICE f="Shiho097"]
[OnName num="shiho"]
I'll tell you what, Takuma-kun, why don't we exchange phone numbers?
[cpg cn=true]

[OnName num="takuma"]
I don't think so.
[cpg cn=true]

I didn't understand the intention for a moment, but it is certainly necessary.
[cpg]

What time I'm okay and what time Shiho is okay. We need to know each other.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Shiho098"]
[OnName num="shiho"]
In the meantime, do you want to sign up for social networking chats?"
[cpg cn=true]

[OnName num="takuma"]
"I see you're on SNS too, Shiho-san. ......
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Shiho099"]
[OnName num="shiho"]
Oh, that's the way to say it. Even an old lady like me would do something like that.
[cpg cn=true]

I know. I said something rude.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]

And after exchanging numbers and stuff, I went back home.
[cpg]

I was impressed by the look of regret on Shiho-san's face.
[cpg]

;//(Y)追加

;//========================================
;//●ＣＧ非エロ（スマートフォンの一般的なホーム画面）ev_51_0　再度流用
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

Shiho immediately sent me a message.
[cpg]

;//(Y)SNSのメッセージは<>で囲ってみます。どういう囲みが適切なのかなど、あればお願いします

[OnName num="shiho"]
<Thanks for today. I'll let you know if there's anything I need to talk to you about.
[cpg cn=true]

I - after some exchange of messages - wrote
[cpg]

[OnName num="takuma"]
<If you ever get hit again, please shout louder so we can record and film it>.
[cpg cn=true]

[OnName num="takuma"]
<We may ask you to be patient until we gather evidence. But don't just force yourself>.
[cpg cn=true]

[OnName num="takuma"]
<I am a scary person to deal with, but I am on Shiho's side. Please consider a shelter when you reach your limit>
[cpg cn=true]

How much can I do?
[cpg]

I wonder if I should be taking such a long time for her who is being hurt.
[cpg]

There must be a better way. ...... That's what I think.
[cpg]

And. Message from Shiho.
[cpg]

[OnName num="shiho"]
<Thank you. I like you. I can't say it out loud with my husband around, but...
[cpg cn=true]

[OnName num="shiho"]
<Let's sneak out together sometime.
[cpg cn=true]

[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I took too many baths, so my appetite has increased a lot. I am very hungry.
[cpg]

I wonder if this is what happens when the autonomic nervous system is regulated.
[cpg]

[OnName num="takuma"]
But I have to take a video. ......
[cpg cn=true]

I want to expose his misdeeds to the world for Shiho-san's sake. That thought was renewed.
[cpg]

And. An idea came to me.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="takuma"]
"Yes, thank you!　I'm Takuma, left, of the Gieselbach site!
[cpg cn=true]

I couldn't wait to get going.
[cpg]

[OnName num="takuma"]
Today, you see, I have eggs I bought at the supermarket. I've got 8 boxes of 10 eggs here from the supermarket.
[cpg cn=true]

[OnName num="takuma"]
I'll eat them.
[cpg cn=true]

[OnName num="takuma"]
Raw. Eighty eggs.
[cpg cn=true]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep005.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
