
;//==============================
;//２、警察に連絡しよう。俺の出る幕じゃない

*select04_2|The decisive moment

I stared at the smartphone in front of me. It should serve as evidence.
[cpg]

It's okay. It's okay. ...... is okay. There are people more used to this kind of thing than I am.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
;//ＢＫ

When I called the police, the next-door neighbor, Dobasaki, was arrested on a completely unrelated charge.
[cpg]

Apparently he was evading quarantine on his way home from overseas.
[cpg]

I can't believe I'm getting caught for a crime I had nothing to do with. I can't believe I got caught for a crime I had nothing to do with. I'm feeling a bit bewildered.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[OnName num="takuma"]
"Hmm?　A call from the school.
[cpg cn=true]

We get a message from the school delivered to our tablets. Oh my God, they're sending us home early today.
[cpg]

[OnName num="male_student_A"]
"Hey, did you see that?　Did you see that?
[cpg cn=true]

[OnName num="male_student_B"]
We're going to play today!　It's all-you-can-eat shirataki for 800 yen at the cafe "Medjugichu HaMokko!"
[cpg cn=true]

[OnName num="male_student_A"]
"For real?　Let's go!
[cpg cn=true]

[OnName num="takuma"]
You've got strange taste.
[cpg cn=true]

[OnName num="kouya"]
"Hey, Takuma. What are you going to do today?　Do you want to take a video?"
[cpg cn=true]

......I didn't feel like it. I'm worried about Shiho. No, Dobasaki is under arrest.
[cpg]

[OnName num="takuma"]
I'm not going to do it today. By the way, why is he leaving early all of a sudden?
[cpg cn=true]

[OnName num="kouya"]
I didn't write anything about it. Well, teachers don't think it's necessary to share information with students.
[cpg cn=true]

I thought about it. I feel like I want to visit Sanae's house for the rest of the day.
[cpg]

I was wondering what to do. ......
[cpg]

[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sAki001"]
[OnName num="aki"]
Excuse me, is Takuma-kun there?"
[cpg cn=true]

Akirahime-sensei, who has nothing to do with the next class, came to the classroom. ...... Eh!　You want to see me?
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sAki002"]
[OnName num="aki"]
Well, it's not a big deal. I'm afraid we're going to have to close school for two days from now, Thursday and Friday.
[cpg cn=true]

[OnName num="takuma"]
What?　Closed?
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="sAki003"]
[OnName num="aki"]
"Then Saturday and Sunday, followed by Monday, which is a national holiday, will be a five-day break.
[cpg cn=true]

It's a long vacation!　You could call it a petit Golden Week.
[cpg]

;//「その五日間、拓馬くんだけ数学の補習で学校に来てもらいたいのですが」
[FACE method="change_1" pos="2/3"]
[VOICE f="sAki004"]
[OnName num="aki"]
Takuma-kun, I'd like you to come for a remedial math class during those five days.
[cpg cn=true]

Iaaaaaahhhh ！！！！
[cpg]

My emotions were pushed from heaven to hell.
[cpg]

[OnName num="kouya"]
I'm sorry, Takuma. I'm going to enjoy my five-day vacation.
[cpg cn=true]

[OnName num="takuma"]
That's not fair!　I'm sorry, Takuma, but I'm the only one who gets to enjoy the five-day vacation!　Why me?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="sAki005"]
[OnName num="aki"]
Because of your bad grades, isn't it?
[cpg cn=true]

[OnName num="takuma"]
"Ggboaaaah!
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sAki006"]
[OnName num="aki"]
I'm not forcing you to do this. I'm only offering it voluntarily.
[cpg cn=true]

Oh, what the heck. Good. ....... You are left with a choice.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="sAki007"]
[OnName num="aki"]
I also feel a little bad about it. So if you can follow me for five days,......, I guess so."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sAki008"]
[OnName num="aki"]
"I'm going to go to a local coffee shop and get an oversized pudding parfait ......."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sAki009"]
[OnName num="aki"]
I'm going to go to a local coffee shop and have an oversized pudding parfait. The staff meeting is still to come.
[cpg cn=true]

I was shaken. What am I going to do with this sudden five days off (still a possibility)?
[cpg]

Thinking about being allowed to visit Mr. Sakuranae's house or repairing hell with Dr. Akihime (with a rewarding parfait)?
[cpg]

As for me...
[cpg]

[switch]
[case "Sakurana"]
	[swap]
	[jump target="*select05_1"]
[case "Shohime"]
	[swap]
	[jump target="*select05_2"]
[endswitch]

;//■選択肢
1, Sakurana
2, Princess Akira


*select05_2|I want to see Ms. Sakurana.

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep012.ks" target="*select05_2"]



;//(Y)ハーレムルートはなしの方針です。必要なら追加します

;//==============================
;//１、桜苗
*select05_1|I want to meet Ms. Sakuranao.

...... Sanae-san. Her face popped into my head.
[cpg]

Mother of Kouya. The age difference is more than Shiho-san and Tokieda-sensei.
[cpg]

;//(Y)追加

As for math, I'll try to do a little more independent work at home.
[cpg]

I mean, can Kouya teach me?　If I dare, I'll ask Mr. Sakuranae to ...... No, no, that's impossible.
[cpg]



;//(Y)流用
;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_00_2.ui" time=1000]
[WAIT time=2000]
[window target=true]

I'm going to visit his house.
[cpg]

I want to meet Mr. Sakurana. Once it crosses your mind, you can't erase that desire.
[cpg]




*start|I want to see Mr. Sakurana.

;#################################################
*Ep008|I want to see Mr. Sakurana.
;#################################################

[SCENE id=8]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の家＿リビング』（夕方）******************************************************

[FACE method="change_2" pos="2/3"]
[VOICE f="Sanae014"]
[OnName num="sanae"]
"Come in, Mr. Sakuranae. Are you going to bother me again today?　Thank you.
[cpg cn=true]

[OnName num="takuma"]
No, well, don't worry about it. ......
[cpg cn=true]

However, even if you can go to see Mr. Sakuranao in the name of playing with Kouya, it is difficult to have a conversation with him.
[cpg]

You would have to go to Kouya's room. But, if you are going to see her, you are not going to see her very often.
[cpg]

[OnName num="takuma"]
"Oh, um, Mr. Sakurana.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sanae015"]
[OnName num="sanae"]
What is it?　What is it?
[cpg cn=true]

I've been told that my face is dark and serious every time I see someone today.
[cpg]

But I guess that's actually true. I can imagine it myself.
[cpg]

;//(Y)追加。桜苗に魅力が見えないと、不倫する主人公もまた愚かな性欲魔人に見えてきて、こんな主人公見たくない、という現象の起きやすいシナリオですから、彼女の魅力を盛れるところで盛るべきです

[FACE method="bow_7" pos="2/3"]
[VOICE f="sSanae001"]
[OnName num="sanae"]
I'm sorry. I have an old man in the neighborhood with a bad back and I want to cook for him. Something that will strengthen his bones."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sSanae002"]
[OnName num="sanae"]
I might not be able to leave Takuma-kun alone today. ......
[cpg cn=true]

I fell more in love with Sanae-san with those words. What a great guy.
[cpg]

I, on the other hand, am all about me. I play, I take videos, I ...... suddenly feel embarrassed.
[cpg]

[OnName num="kouya"]
What are you doing? Come on, come on."
[cpg cn=true]

[OnName num="takuma"]
"I'll be right there. I'll be right there.
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

In the end, I could not talk much with Sanae.
[cpg]

The actuality that you can't talk to them alone is difficult to find out.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

[FACE method="change_2" pos="2/3"]
[VOICE f="Sanae016"]
[OnName num="sanae"]
Well, come back then."
[cpg cn=true]

And then, suddenly, a chance came. I was so happy to see her.
[cpg]

I was not with him. I was the only one there.
[cpg]

[OnName num="takuma"]
"Well, Mr. Sanae, ...... I've been thinking about you ......"
[cpg cn=true]

I am at a loss for words. But I have to say it.
[cpg]

[OnName num="takuma"]
I like you, Sanae. I will come back again."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Sanae017"]
[OnName num="sanae"]
I'll be back again.
[cpg cn=true]

[OnName num="takuma"]
Well then, I'm sorry to bother you. That's all for today."
[cpg cn=true]

I said that and walked away as if to run away.
[cpg]

;//(Y)追加。いちおう禁断の恋なので人間らしい反応を

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の洗面所』（夜）******************************************************

As I was about to take a bath, I took off my jacket and suddenly felt calm.
[cpg]

[OnName num="takuma"]
I was so excited. I said it. ......"
[cpg cn=true]

I told Sanae how I feel, what if Kouya finds out?
[cpg]

......Now that's not good, I'm suddenly becoming calm. The feeling that I like you is true, but I feel guilty. ......
[cpg]

......No. I have no choice but to go through with it.
[cpg]

;//(Y)追加。後のキーになる車の登場と、耕哉と仲良しのシーンを厚み付けしておきます（殺し合いにまで落とすなら最初は仲良くしてないと落差が出ないため）
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

Thursday's holiday has arrived. I can't believe it. It's not even Golden Week, but a long vacation.
[cpg]

I was soaring. I took a fucking video.
[cpg]

[OnName num="takuma"]
"I can't believe it, I'm taking a weekday off. It would be a waste if I didn't make the best of these five days.
[cpg cn=true]

[OnName num="takuma"]
So I want you, the viewers, to give me your best vacation ideas!"
[cpg cn=true]

My brain can't even plan my own vacation. I'm asking for opinions. Where is my ego?
[cpg]

I can't help it!　My brain can't handle a sudden vacation.
[cpg]

And... --A message came in from Kouya.
[cpg]

<If you're free today, let's go to the car shop>.
[cpg]

...... I can't believe he's watching me. But why the car store?
[cpg]

<She says an acquaintance of hers is the owner. He wants me to promote it on video anyway. There are a lot of luxury cars and it will look good.
[cpg]

<By the way, my mom pulls out a very small bag and spends a lot of time grooming her hair. Do you know what it is? >
[cpg]

Because ...... he confessed yesterday?
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

We were shown a variety of cars while we took videos.
[cpg]

Having said that, me and Sanae-san have in common that we have little interest in cars, hubby and Kouya are the opposite.
[cpg]

The only ones with a driver's license were Sakurana-san and her husband. These two were checking out the ride.
[cpg]

;//========================================
;//●ＣＧ非エロ（桜苗さんが車のレバーを握る。言ってみればただそれだけなのですが、見るべき変態が見るとなにを想起させようとしてるのかわかってドキッとするようなやつ）ev_25_1
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：車
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_25_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[OnName num="kouya"]
How do you like it?　"How do you like it? Your father didn't seem to like this car.
[cpg cn=true]

[VOICE f="sSanae003"]
[OnName num="sanae"]
The new cars are ...... all so high-tech. The steering wheel and levers go so fast that it might be scary.
[cpg cn=true]

I'm uncomfortable because I confessed my feelings to Ms. Sakuranae the other day. I'm a little nervous.
[cpg]

[VOICE f="sSanae004"]
[OnName num="sanae"]
"Is ...... a little high?　He's going back to Hungary after his sabbatical, isn't he?"
[cpg cn=true]

[OnName num="kouya"]
I wonder if he'll buy one for my mom?"
[cpg cn=true]

[OnName num="kouya"]
Takuma. Takuma, you should get in the passenger seat too. The sofa is soft.
[cpg cn=true]

;//(Y)念のため。めっちゃ隠喩してます。耕哉と入れ替わる/桜苗さんの腰にすいつくクッション/放置したら悪くなる=放置された桜苗さんが浮気したがっている/固いレバーを握る/ベルトで縛る/ソファに体重を委ねる

I swapped places with Koya and sat in the passenger seat - in other words, next to Ms. Sanae.
[cpg]

What I'm doing now is a test drive. I'm not even supposed to be driving that, but I'm ...... kind of uncomfortable with it.
[cpg]

Beside me, Sakuranae-san checked the comfort of the sofa while looking at me. The cushion was sucking on my waist.
[cpg]

[VOICE f="sSanae005"]
[OnName num="sanae"]
The last car went bad when I didn't use it,....... If you don't use it, it gets worse.
[cpg cn=true]

She grips the steering wheel and intertwines her fingers. Her grip seems firm.
[cpg]

The only thing I can be sure of on my end is the comfort of the seatbelt. ...... How can you be sure of the performance of a car?
[cpg]

She, too, has tightened her body with the seatbelt. She surrenders her weight on the sofa,.......
[cpg]

[VOICE f="sSanae006"]
[OnName num="sanae"]
Takuma-kun. As a violist, I often go to music halls around here.
[cpg cn=true]

Wait a minute. I had never heard of him. He was a viola player?
[cpg]

[VOICE f="sSanae007"]
[OnName num="sanae"]
"I wish you would drive out with me and listen to my performance. ......
[cpg cn=true]

[VOICE f="sSanae008"]
[OnName num="sanae"]
I don't know what you mean.
[cpg cn=true]


;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Koya was an enthusiastic narrator and made a good video. He bought a black car called "Alex Bicephal.
[cpg]

Buying a car--. For me, it's a big event with dazzling money. I was rather excited about that.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

After that, Koiya and I went out for fun. I'm having iced tea at a cafe. Earl Grey is the best iced tea.
[cpg]

[OnName num="kouya"]
"Ooooh ...... can't wait to ride in my dad's car. The comfort of the couch is off the charts."
[cpg cn=true]

[OnName num="takuma"]
I see you like it. I'm sure you'll love it.　It should be in a few years.
[cpg cn=true]

[OnName num="kouya"]
Of course!
[cpg cn=true]

[OnName num="kouya"]
He sits down on the sofa. He buckles his seatbelt. Put your seatbelt on. That's how you become one with 160 years of history.
[cpg cn=true]

It's fun to watch Koya's excitement. He is drinking water. Interesting.
[cpg]

[OnName num="kouya"]
I'm going to have to deal with insurance and stuff for the car for a while after tomorrow," he said. My dad and I might not be home for a while.
[cpg cn=true]

[OnName num="takuma"]
What about you, Mr. Sakuranae?　Is that okay?
[cpg cn=true]

[OnName num="kouya"]
She's going to work remotely. She's working as a handicrafts teacher in her spare time.
[cpg cn=true]

...... Are you multi-talented by any chance?
[cpg]

I see. If we get to know each other, will you knit or crochet for me?　I might ask her to do it in the winter or something. ...... Maybe a scarf.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The next day - I couldn't stay put. I really wanted to see Mr. Sakuranae.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


That guy said, "I ain't home when you come to talk about the video. He said his husband is also away from home.
[cpg]

In the group messages of the manzai club, we had often begun to talk about the fall festival.
[cpg]

I went to Koya's--or rather, Sakuranae's--house. I think I have an excuse ready .......
[cpg]

How about learning handicrafts?
[cpg]

;//(Y)流用。一部カットや編集

[window target=false]
[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の家＿リビング』（昼）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Sanae018"]
[OnName num="sanae"]
Oh, Takuma,......, you're up very early today.
[cpg cn=true]

[OnName num="takuma"]
I'm here to see Mr. Sanae."
[cpg cn=true]

Ms. Sanae is puzzled. I don't care how confused she is, I'm prepared to take a hit and smash it.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Sanae020"]
[OnName num="sanae"]
The actuality is that you can't just take a look at the actual product or service. You can't say that to an old lady like that. ......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sanae021"]
[OnName num="sanae"]
And I have a son.　I can't do anything for you.
[cpg cn=true]

I knew it might say that. It is a predictable answer.
[cpg]

[OnName num="takuma"]
Mr. Sakuranae. I like you."
[cpg cn=true]

[OnName num="takuma"]
'....... I know it's unforgivable. But there is something I've been thinking about.
[cpg cn=true]

[OnName num="takuma"]
I feel ...... that the way Mr. Sakurana-san looks at your husband is somewhat cold.
[cpg cn=true]

I'm going to be more direct, to take away Sanae's escape route.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Sanae022"]
[OnName num="sanae"]
I can't ...... do that. You have to give up."
[cpg cn=true]

I could see that Sanae's mind was a bit shaken. She blushed and made a gesture as if she covered her mouth with her hand.
[cpg]

Sanae-san understands what I am saying. And also on the other hand, I understand Sanae-san's feelings too: .......
[cpg]

It's like telepathy. I felt like we were communicating,.......
[cpg]

[OnName num="takuma"]
I heard that you do handicrafts. Tell me about it."
[cpg cn=true]

[OnName num="takuma"]
I'm not really interested in that, to be honest. I really just want to be with you.
[cpg cn=true]

[OnName num="takuma"]
If you have an excuse like that, that's fine. ......
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sanae024"]
[OnName num="sanae"]
"......"
[cpg cn=true]

The name of the game is to do handicrafts. It could even be made into a video.
[cpg]

In fact, I believe that Mr. Sakuranae is a remote handicraft teacher ...... online and he is showing videos of his courses.
[cpg]

[OnName num="takuma"]
Why, no? ......?"
[cpg cn=true]

Silence. Then Ms. Sakuranao opened her mouth.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sSanae009"]
[OnName num="sanae"]
'It's just one ......, okay?　And I can't be direct with you.
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

We went to her room.
[cpg]

;//(Y)追加

As soon as she sat down on the sofa, she dropped a ball of yarn. It was a very expensive looking ball of yarn.
[cpg]

;//[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSanae010"]
[OnName num="sanae"]
Aah!
[cpg cn=true]

She quickly tried to pick it up and ......
[cpg]

;//========================================
;//●ＣＧ非エロ（ソファの間に落ちた高めの毛糸を拾い上げようとしている。お尻を見せる）ev_23_1

;//人物１：ヒロイン２
;//服装１：私服
;//場所　：桜苗の部屋
;//時間　：昼
;//========================================
[window target=false]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_23_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sSanae011"]
[OnName num="sanae"]
"That was a close call,......!
[cpg cn=true]

......No, wait. It's still "dangerous" from my point of view.
[cpg]

[VOICE f="sSanae012"]
[OnName num="sanae"]
It's not safe if you get floor debris or anything else on it!　When you knit, you have to weave all that in too.
[cpg cn=true]

[VOICE f="sSanae013"]
[OnName num="sanae"]
Be careful, Takuma-kun. Takuma said, "Be careful, Takuma-kun.
[cpg cn=true]

Sakurae-san didn't get up easily.
[cpg]

[OnName num="takuma"]
Are you okay?"
[cpg cn=true]

[VOICE f="sSanae014"]
[OnName num="sanae"]
"Hey, ......, my back is a bit painful!　I jumped in too fast."
[cpg cn=true]


;//(Y)以下2台詞はエロシーンから流用

[VOICE f="Sanae236"]
[OnName num="sanae"]
"Huuuuuuhhhhhh ...... haaaaaaahhhh ......"
[cpg cn=true]

[VOICE f="Sanae313"]
[OnName num="sanae"]
'Haaahhhh, ahhhhh!　Nnhhhhh, ahhhhh!"
[cpg cn=true]


[VOICE f="sSanae015"]
[OnName num="sanae"]
"Let me ...... stay like this for a while ......!　I think I've got a little cramp in my leg.
[cpg cn=true]

[OnName num="takuma"]
......!"
[cpg cn=true]

I was allowed to enjoy the spectacular view for a while. I'm sorry, Sakura Nae,.......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_00_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
;//ＢＫ

;//(Y)またしてもエロ！！　っていうふうに書きました

I was taught a lot of handicrafts after that. But it was more than handicrafts.
[cpg]

I was taught by the warm hands of Ms. Sakuranao--she guided me--this is how to insert this thread. Needle care.
[cpg]

The other side, too, looked embarrassed and turned away.
[cpg]

I thought she got the message. Even if I didn't say what it was.
[cpg]

;//(Y)流用・カット

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_00_3.ui" time=1000]
[WAIT time=3000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の家＿リビング』（夕方）******************************************************

I left the room and walked back to the living room. Then, on my way back, I called ......
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="takuma"]
I said, "Oh, Mr. Sakuranae, why don't we exchange ...... phone numbers?"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Sanae066"]
[OnName num="sanae"]
What, why ......?"
[cpg cn=true]

[OnName num="takuma"]
I said, "Mr. Sakuranae, you said there won't be a next time, but if you change your mind, you can always go to ......."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Sanae067"]
[OnName num="sanae"]
There is no ......."
[cpg cn=true]

With that said, she pulled out her cell phone. We exchange numbers.
[cpg]

It is a bizarre act. She is a married woman and a mother.
[cpg]

And the mother of my best friend. I had exchanged cell phone numbers with such a person.
[cpg]

;//(Y)ここ以下は追加。念のため：以下のエピソードは、桜苗さんに対する愛では主人公が勝っていて、夫・耕哉サイドが負けているという事を示す（のちの展開の説得力を強める）エピソードです

I felt that the distance between me and Ms. Sakuranae was getting closer.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

After I got home, I couldn't concentrate on my math self-study at my desk, and it occurred to me.
[cpg]

I had been bullied in the past. The childish classmates at that time. What's different about older people compared to them?
[cpg]

They must have gone through the same childhood as I did. They must have seen it - those bleak times.
[cpg]

Whether it was ten years ago or twenty years ago, it doesn't make any difference. I wonder how these girls have lived their lives.
[cpg]

;//ＢＫ

;//========================================
;//●ＣＧ非エロ（スマートフォンの一般的なホーム画面）ev_51_0　再度流用
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

On Saturday morning, Sakurana-san sent me a message.
[cpg]

It was unexpected. I had said there would be no next time, and now it was already ......?
[cpg]

[OnName num="sanae"]
<Husband and Koya both look at the tools in the car>.
[cpg cn=true]

I thought the message spoke eloquently of Ms. Sakurana's loneliness.
[cpg]

[OnName num="sanae"]
<Today they are going to look at winter tires. Even though winter is only a few months away>
[cpg cn=true]

Mr. Sakuranae has not survived the desolate times. She is still trapped. They, too, are suffering in unseen ways.
[cpg]

I felt my illusions about older women disappear.
[cpg]

One person.
[cpg]

We are all alone and don't know who to turn to. But we can't see others in important places.
[cpg]

Me and Ms. Sakuranae are also. I know that ...... this love in itself involves Sakuranaesan's husband, and Koya.
[cpg]

I've been in Hungary for a long time, and in this period of time that I've been back home for a bit, my husband is also looking at cars.
[cpg]

I've arranged to see Mr. Sakuranae again today.
[cpg]

[OnName num="takuma"]
<Meet you, Sanae-san>.
[cpg cn=true]

[OnName num="takuma"]
<I will be by your side>.
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の家＿リビング』（夕方）******************************************************

I want to be forgiven for my sinfulness - such a desire is sinful.
[cpg]

That is why it 'stays' as a desire. It doesn't become something more than that, and people keep it inside and leave it as it is.
[cpg]

I am just another sinful child.
[cpg]

[OnName num="takuma"]
"The true nature of my preference for older women is..."
[cpg cn=true]

[OnName num="takuma"]
"(Is it not the desire for protection, to create the illusion of being an older woman and to be forgiven by her?
[cpg cn=true]

[OnName num="takuma"]
"Are they not also ignoring the truth that they want to rely on someone else, and are trying to impose their burden on them?"
[cpg cn=true]

[VOICE f="sSanae016"]
[OnName num="sanae"]
Takuma-kun. Your hand, it's shaking. Concentrate on the needle. ......"
[cpg cn=true]

[OnName num="takuma"]
What?"
[cpg cn=true]

;//========================================
;//●ＣＧ非エロ（手を取ってもらっている。主人公が横にいる想定なので、主人公の腕や手などは描かない方が自然かも？　しれないです。以下のちょっと悲しめに語る様子なら表情を変える必要は少ないかな？）ev_26_1

;//人物１：ヒロイン２
;//服装１：私服
;//場所　：桜苗の部屋
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_26_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

I was being taken in hand by Ms. Sakuranae. Practicing handicrafts is just a name.
[cpg]

Sanae-san is touching my hand and teaching me to knit yarn, even though she doesn't have to.
[cpg]

[VOICE f="sSanae017"]
[OnName num="sanae"]
This is a craft exercise, isn't it?　...... I'll stay with you, it's okay, right? ......"
[cpg cn=true]

[OnName num="takuma"]
I say, "Yes, I want to do this. I want to do this all the time."
[cpg cn=true]

[VOICE f="sSanae018"]
[OnName num="sanae"]
"....... My husband is going back to Hungary soon.
[cpg cn=true]

[VOICE f="sSanae019"]
[OnName num="sanae"]
"Going back?　......'Going back' is funny. I'm going over there, aren't I? This is his home.
[cpg cn=true]

[OnName num="takuma"]
I'm going to stay by your side.
[cpg cn=true]

I thought. What about ...... Koya?　Can't Koya stay by my side?
[cpg]

[VOICE f="sSanae020"]
[OnName num="sanae"]
I told you that I also play the viola. It's hard for me to play at home, so I often go out to practice.
[cpg cn=true]

[VOICE f="sSanae021"]
[OnName num="sanae"]
I met my husband at a concert over there. We flew out and suffered from the time difference.
[cpg cn=true]

[VOICE f="sSanae022"]
[OnName num="sanae"]
It was a piece by Schumann. When I finished the piece, my eyes met his in the audience like a ...... magnet.
[cpg cn=true]

[VOICE f="sSanae023"]
[OnName num="sanae"]
He wouldn't even look for ...... the video that was now up on social media to find it."
[cpg cn=true]



;//(Y)流用・カット
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

A few mornings later, after the break. I head to the school. I'm going to the school.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shiho380"]
[OnName num="shiho"]
I'm going to be able to get a good look at the video. Takuma-kun,......, are you feeling a little down?"
[cpg cn=true]

[OnName num="takuma"]
Yes, I'm off. ......
[cpg cn=true]

I can't reply crisply. I've been in a forbidden love affair.
[cpg]

That is, whether it is Shiho-san or Tokieda-sensei, she is still a married woman.
[cpg]

But Sanae has a child. She's also my best friend.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[OnName num="kouya"]
What's wrong?　You look even gloomier again.
[cpg cn=true]

[OnName num="takuma"]
"I don't know if that's so.
[cpg cn=true]

[OnName num="kouya"]
Yes. You're in love, aren't you?　Who are you in love with?
[cpg cn=true]

[OnName num="takuma"]
Don't get your knickers in a twist. It's none of your business who I'm in love with.
[cpg cn=true]

[OnName num="kouya"]
Don't say it's none of your business. You're my best friend.
[cpg cn=true]

I can't tell you because we're best friends. I can't say "I'm your best friend.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep009.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
