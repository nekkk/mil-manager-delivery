
*start|Farewell to a Best Friend

;#################################################
*Ep010|Farewell to a Best Friend
;#################################################

[SCENE id=10]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=2000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

Later that day, I met with Koya. It was about a matter that I told him I needed to discuss with him.
[cpg]

As soon as we met, he blamed me for being late for the rehearsal. ...... I don't know what kind of conversation I had with Sakuranae.
[cpg]

[OnName num="kouya"]
And that's what he told me the other day. Takuma,...... Takuma."
[cpg cn=true]

;//(Y)流用。場所だけ変更

[OnName num="kouya"]
'What's that, again? What's the important talk?"
[cpg cn=true]

[OnName num="takuma"]
......It's a really important talk. Can I switch places for a minute?
[cpg cn=true]

[OnName num="kouya"]
You sound serious. You seem serious. Is there somewhere we can have some one-on-one time?
[cpg cn=true]

[OnName num="takuma"]
Yeah. Yeah, I'd like that.
[cpg cn=true]

[OnName num="kouya"]
Well, I consider you a good friend.
[cpg cn=true]

[OnName num="kouya"]
I don't care what you have to tell me. Don't worry.
[cpg cn=true]

Is this true? How would you feel if you found out that your friend was having an affair with your real mother?
[cpg]

Would it destroy the whole relationship? I felt that way.
[cpg]

;//ＢＫ

;//(Y)子供から卒業し切れていないので部室である必要がある

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『部室』（昼）******************************************************

We were allowed to use the school's club room, the same as before, even for alumni.
[cpg]

It was the most comfortable place for us to talk about our videos. Now, after graduation, I chose this place for some reason.
[cpg]

It was Saturday and there was no one around. ...... I want to tell them everything.
[cpg]

What should I do?　What should I say to Koya?
[cpg]

;//(Y)追加。

[OnName num="kouya"]
"So?　What do you mean, talk?
[cpg cn=true]

The words that came out of my mouth were frank.
[cpg]

;//(Y)流用。一部全年齢向けに編集

[OnName num="takuma"]
I'm in a relationship with Mr. Sakuranae. I'm going out with Mr. Sakuranae.
[cpg cn=true]

[OnName num="kouya"]
By "Ms. Sakuranae," do you mean my ...... mother?
[cpg cn=true]

I still think it's not good. I think it's not good.
[cpg]

I think Koya will be depressed. Then he will talk to Sanae herself about this.
[cpg]

And I imagine that my relationship with Ms. Sakuranae is over .......
[cpg]

[OnName num="kouya"]
I'm wondering, "How far along are you in a relationship?　Did you confess?"
[cpg cn=true]

I'm at a loss for an answer. I'm at a loss for an answer.
[cpg]

[OnName num="kouya"]
I'm at a loss for an answer. I see... I see... ......
[cpg cn=true]

Koya looked down for a moment, thought about it, and then said, "I'm sorry, but I don't think I can do this.
[cpg]

[OnName num="kouya"]
I don't know, I don't like it when people take these stories too seriously. ......
[cpg cn=true]

[OnName num="takuma"]
I'm sorry. But it's true that we're dating.
[cpg cn=true]

[OnName num="kouya"]
I'm going to tell you a little bit about the past. I'm going to tell you a story from the past.
[cpg cn=true]

An old story. I asked him what he was talking about.
[cpg]

[OnName num="kouya"]
When I was a kid, there were a lot of guys who wanted to get to know you.
[cpg cn=true]

[OnName num="kouya"]
She had a lot of friends. Even after she got married, she was approached by a lot of guys.
[cpg cn=true]

[OnName num="kouya"]
I don't mind. I don't mind that. I'm proud of her.
[cpg cn=true]

[OnName num="takuma"]
What do you mean ......?
[cpg cn=true]

[OnName num="kouya"]
My mother is beautiful, right?　I'm just saying, people are going to be after you.
[cpg cn=true]

[OnName num="kouya"]
I'm used to it, it's weird to say, but ...... I don't really care.
[cpg cn=true]

;//(Y)追加

I could not read the expression on Koya's face. Nor was it expressionless.
[cpg]

It shudders a little. He shrugs and laughs as if he's heard something funny.
[cpg]

--Are you proud of me?　Proud?　......I couldn't get a grip on Koya.
[cpg]

That guilt I was almost crushed by, did I even need to feel it?　I was suffering.
[cpg]

Koya nodded his head in satisfaction. I turned away. There were several tables in the clubroom.
[cpg]

Suddenly, I noticed that Nathaniel Hawthorne's "The Scarlet Letter" was on the table beside me.
[cpg]

Someone in the comic club must have left it there. Some of the alumni must have gone on to study English literature.
[cpg]

I don't think it's a bad idea to incorporate literature into a comic strip. ...... what kind of book was it?
[cpg]

I'm in the education department too. If I had wanted to be an English teacher, I might have read it.
[cpg]

[OnName num="kouya"]
Kuku, kuku. It's interesting.
[cpg cn=true]

[OnName num="kouya"]
"You went to the vomit party for that, by any chance?
[cpg cn=true]

[OnName num="takuma"]
"......"
[cpg cn=true]

...... was there anything at all that Sakura Nae-san was worried about?
[cpg]

It seems that Koya himself doesn't care who Mr. Sakuranae has to do with. ......Really?
[cpg]

;//(Y)流用・一部変更

[OnName num="kouya"]
'Just don't do anything that will destroy our family. Like taking it away from my dad."
[cpg cn=true]

[OnName num="takuma"]
"And, of course. I won't do that.
[cpg cn=true]

[OnName num="kouya"]
But, well, what the hell. Even if you were to go out with my mother, I wouldn't be mad at you, okay?
[cpg cn=true]

[OnName num="kouya"]
More importantly, when you have a baby, can I call you Stepfather?"
[cpg cn=true]

......That's a hell of a thing. I'm sorry.
[cpg]

[OnName num="takuma"]
"I'm sorry ....... I'm sorry, I made you talk weird.
[cpg cn=true]

[OnName num="kouya"]
"You feel a little better now?　Okay, you can stay the night.
[cpg cn=true]

[OnName num="takuma"]
Is that okay?　But, Mr. Sakuranae is ......
[cpg cn=true]

[OnName num="kouya"]
It's okay. I'm a man, too.　I'm a man too. I understand. You want to clear your head, too, don't you?
[cpg cn=true]

[OnName num="takuma"]
"......"
[cpg cn=true]

I can't believe he's so open about it.
[cpg]

There must have been many people courting Mr. Sakuranae for a very long time.
[cpg]

;//(Y)追加

[OnName num="takuma"]
I'm going to go back to ....... Sorry. I'll stay the night. ......"
[cpg cn=true]

[OnName num="kouya"]
Oh, yeah. You were blue in the face. It's closer to here, so it's better."
[cpg cn=true]

The Scarlet Letter caught my eye again. I remembered.
[cpg]

I remembered the story of the Reverend Dimmesdale, who had cheated on his wife and finally died because he couldn't bear the guilt.
[cpg]

A shadow appeared in my vision. I immediately crouched down.
[cpg]

[FADEOUTBGM]

[SE f="se051"]
;//【ＳＥ】破壊音

[WAIT time=1000]

Koya had slammed his chair down on the spot where I had been.
[cpg]

[OnName num="takuma"]
.......
[cpg cn=true]

[OnName num="kouya"]
Why did you dodge?"
[cpg cn=true]

The chair was shattered into pieces. I felt a drop of blood running down my cheek as the flying pieces of wood hurt me.
[cpg]

[OnName num="takuma"]
Oh, ...... ah!"
[cpg cn=true]

[BGM f="bg_pi"]
[WAIT time=100]

[OnName num="kouya"]
I wish I had died with all my heart.
[cpg cn=true]

[OnName num="kouya"]
The actuality is that you can't get rid of the actuality that you're not.　Takuma.
[cpg cn=true]

This is the result of my sin. So I had to accept it. I knew that in my head.
[cpg]

I couldn't expect any help at the school on Saturday.
[cpg]

[OnName num="kouya"]
I couldn't just keep it to myself, could I? Have you thought about how I feel when I confide in you?"
[cpg cn=true]

[OnName num="kouya"]
Did you want me to say, 'My glass heart can't take it - but we're friends, aren't we?
[cpg cn=true]

[OnName num="kouya"]
' "If you see a mosquito on a hot, humid night, it's so gross and creepy you can't sleep. I won't sleep until I kill it."
[cpg cn=true]

[OnName num="takuma"]
'Ugh. ......'
[cpg cn=true]

[OnName num="kouya"]
'I've got that mother's blood in my veins, don't I?
[cpg cn=true]

[OnName num="takuma"]
Aaaaahhhh!"
[cpg cn=true]

Koya hit me again. I tried to catch him, but he took a bite right in the cheek. He falls to the floor from the waist down.
[cpg]

On the table were a pair of scissors. He pulls them out and stabs me right in the eye!
[cpg]

[OnName num="takuma"]
"D!"
[cpg cn=true]

;//(Y)インパクトのある生々しい怨念の籠もった罵倒を、新たに造語したい。「耕哉ってこんな事言うんだ！？」というインパクトが作れれば、そのまま豹変した感になって、恐ろしさとなる

[OnName num="kouya"]
Dammit!!!!!!!　Don't you dare!　Give me back my memories!　I want my beautiful mother back!
[cpg cn=true]

[OnName num="kouya"]
You can't even handle this on your own, you fucking communicator!"
[cpg cn=true]

[SE f="se050"]
;//【ＳＥ】刺突音

[WAIT time=1000]

The scissors were thrust back. Koya lifted his chair again and swung it.
[cpg]

I pulled the scissors out and aimed them at his chest.
[cpg]

The chair slammed into my back. I stabbed the tip of the scissors into Koya's side. But it was shallow.
[cpg]

[OnName num="takuma"]
"Gaaaahhhh! ......"
[cpg cn=true]

[OnName num="kouya"]
I was having so much fun!　It was fun!　I've been having so much fun!
[cpg cn=true]

[OnName num="takuma"]
I was so stupid!
[cpg cn=true]

[OnName num="takuma"]
"Koiya, I'm sorry!　I'm so sorry!
[cpg cn=true]

My back ached. I ran, crawled and managed to escape from the club room.
[cpg]

[SE f="se012"]
;//【ＳＥ】『走る』

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

An empty classroom. I ran into the locker used for cleaning.
[cpg]

;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

The scaffolding was dirty with buckets and mops. But I had nowhere else to run.
[cpg]

[OnName num="kouya"]
Takumaaaaaaaaaaaaaaah!
[cpg cn=true]

[OnName num="kouya"]
"Wheeeeeeeeeeere iiiiiiiiiiiiiiiis iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiit?"
[cpg cn=true]

I twisted around. The bucket beneath my feet shook unsteadily. I held the dirty mop under my arm and restrained it. If I made a sound, it would be the end.
[cpg]

I heard a voice from far away. For a moment, I thought they had found me. But it sounded like a teacher.
[cpg]

[OnName num="teacher_mob"]
What's the matter with you?　It's Saturday!　Classes are already in session at ......."
[cpg cn=true]

;//(Y)以下の効果音は地味ながら効果音選定でクオリティが変わる、選定依存が強いところだと思います（美術室から持ち出した石膏像頭部、などの特徴的でディテイルのある音。汎用的だと生々しさが出ない気がします）

[SE f="se051"]
;//【ＳＥ】破壊音

I heard a clunk. Was it the sound of something heavier than glass being shattered?
[cpg]

Then the teacher's voice stopped. I began to shake and tremble. My legs felt numb.
[cpg]

[OnName num="takuma"]
I had to call the police at .......
[cpg cn=true]

;//========================================
;//●ＣＧ非エロ（スマートフォンの一般的なホーム画面）ev_51_0　再度流用
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

With trembling fingers, I opened the phone screen of my smartphone.
[cpg]

[OnName num="kouya"]
Takumaaaaaaaaaaaaaaaa......!!!!"
[cpg cn=true]

I heard a familiar voice from far away. It's so familiar that it's stuck in my ears because I was always next to him in the videos.
[cpg]

[OnName num="kouya"]
Where are you ...... where are you?"
[cpg cn=true]

The voice becomes quieter and quieter. Did he go far away?　Would it matter if I called the police?
[cpg]

I dialed 110. The call came through immediately.
[cpg]

[OnName num="takuma"]
A man is on a rampage at .......
[cpg cn=true]

The voice was quieter, not to mention I was aware of the whispering. A gasp, a breath, mingled with the sound of it.
[cpg]

I told him the situation.
[cpg]

They don't ask me 'who' he is or how this happened. They seemed to be treating it as a simple case of molestation.
[cpg]

I couldn't talk either.
[cpg]

[OnName num="police_voice"]
I was told, "Yes, I'm aware of the situation. ...... I understand the situation. Please make sure your cell phone is silent. You know how to operate it."
[cpg cn=true]

[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[OnName num="takuma"]
"Ugh, ugh ...... ugh."
[cpg cn=true]

I smelled a burning smell. ......!　Somewhere in the school building, a fire is lit!
[cpg]

It's downstairs--is it to cut off my retreat or ......?
[cpg]

My head hurts. I'm feeling dazed. Have I been gassed?　Is he hurt somewhere?
[cpg]

[SE f="se054"]
;//【ＳＥ】『非常ベル』

[OnName num="broadcast"]
Attention all students.
[cpg cn=true]

[OnName num="broadcast"]
There is a fire in the home economics room due to a gas leak, this is not a drill. ......
[cpg cn=true]

I heard the sound of a bucket under my feet. Is it filled with water? Did you not properly dispose of it after use ......?
[cpg]

--No, it's not. It's my blood. ...... lukewarm blood is pooling in the bucket.
[cpg]

......!　Could it be that the wound is deeper than expected!
[cpg]

[OnName num="kouya"]
Takumaaaaaaaaaaaaaaah!"
[cpg cn=true]

My legs are trembling and shaking. Wait, ......!　You can't support my body......!　If I collapse, it will be over......!
[cpg]

I heard a student's screeching voice. A voice that sounds like they are running away. The smell of fire grows stronger.
[cpg]

[OnName num="kouya"]
'Takumaa...... that was fun, wasn't it?　Taking boring videos and doing gags that weren't funny was fun, too!
[cpg cn=true]

[OnName num="kouya"]
I thought you two liked each other!
[cpg cn=true]

[OnName num="kouya"]
I know it's gross and graphic to imagine, but they loved each other and I was born, wasn't I!
[cpg cn=true]

[OnName num="takuma"]
......!"
[cpg cn=true]

I'm beginning to understand. Cheating is an existential crisis for the children involved.
[cpg]

I had sinned.
[cpg]

As if being pulled up by the sin I had to face - I collapsed forward. The locker opened.
[cpg]

[SE f="se024"]
;//【ＳＥ】がしゃあん、というロッカーが開く音

[free time=1000]
[WAIT time=1000]

;//【ＢＧ】『学園教室』（夕）******************************************************

;//画面シェイクで場面転換

There was a loud bang. The fire had not yet spread to the classroom, but the smell was in the air.
[cpg]

A piece of wood from a shattered chair had gone deep and blood was pouring from my leg and overflowing the bucket.
[cpg]

[OnName num="kouya"]
'There you go!
[cpg cn=true]

[OnName num="takuma"]
Ugh!"
[cpg cn=true]

I tried to crawl out.
[cpg]

I tried to crawl out of the bucket, but Koya appeared right in front of me.
[cpg]

[OnName num="kouya"]
"Haaaaahhhh... ...... haaaahhh!"
[cpg cn=true]

[OnName num="takuma"]
Gebo, gebo!"
[cpg cn=true]

[SE f="se031"]
;//【ＳＥ】『殴る』

;//画面シェイク

[free time=300]
[BG f="white.ui" time=300]
[WAIT time=300]
[BG f="b_01_3.ui" time=300]
[WAIT time=300]

Koya took a swing and swung his fist down as hard as he could. I was hit hard.
[cpg]

[OnName num="takuma"]
Geeeeeeeeeee!
[cpg cn=true]

[OnName num="kouya"]
You were late for the rehearsal the other night, weren't you?
[cpg cn=true]

;//(Y)こちら調整指示がありましたが、「豚」がスティーブン・キング作『キャリー』の豚の血をバケツ一杯に汲んだものを主人公キャリエッタ・ホワイト（キャリー）が浴びるネタの前振りなため、また変えてます。「許されようとしてダメだった罪人なら罪人らしく開き直れ！！」って話も含んでいるので、豚って言われたら豚の血で勝利するのは話として綺麗、かも……

[OnName num="kouya"]
You two pigs were really making a mess of each other, weren't you?　That's all you think about, isn't it?
[cpg cn=true]

[OnName num="takuma"]
"What the--!"
[cpg cn=true]

He kicked me in the stomach. I felt my stomach regurgitate. I felt as if my heart had stopped for a moment.
[cpg]

[OnName num="takuma"]
What the hell, you ...... are serious?
[cpg cn=true]

[OnName num="takuma"]
Didn't you explain?　She..."
[cpg cn=true]

;//(Y)ここも耕哉は自分の恥のことしか考えていない

[OnName num="kouya"]
"She said she was playing for someone who had passed away,......, and it put me to shame."
[cpg cn=true]

[OnName num="takuma"]
"Fuck ......."
[cpg cn=true]

[OnName num="takuma"]
"Fuck ...... fuck."
[cpg cn=true]

[OnName num="kouya"]
Aah!
[cpg cn=true]

Suddenly, Koya in front of me looked like a little baby. Hey, my best friend. How can you change so fast?
[cpg]

A moment ago, he was my best friend. That makes you look like a ferocious tiger, and now you're a baby, right?
[cpg]

[OnName num="takuma"]
I shouldn't have let you know anything, should I? I'm sorry. I'm sorry. Right at the Gieselbach site.
[cpg cn=true]

[OnName num="takuma"]
Whoa, I'm graduating.
[cpg cn=true]

[OnName num="takuma"]
"A perfect combination for a sensitive, vulnerable, and unsympathetic teenager, no?　"This pairing."
[cpg cn=true]

[OnName num="kouya"]
What is it, ......?
[cpg cn=true]

;//(Y)スティーブン・キング。出典はインタビュー集「悪夢の種子」の序盤にあるものです。版権とはまた違いますが。

[OnName num="takuma"]
Yeah, that's from a collection of interviews with the great American writer, the king of modern horror.
[cpg cn=true]

I grabbed the bucket behind my back. My leg was still there, pooling blood.
[cpg]

;//(Y)変えました。『キャリー』です

[OnName num="takuma"]
'You ever read it?　That story about the bullied kid who wakes up as a psychic killer?
[cpg cn=true]

[OnName num="takuma"]
Look, pig's blood!
[cpg cn=true]

[SE f="se000"]
;//【ＳＥ】『水を掛ける』

He splashes a bucket of blood on Koya. The blood lands on his eyes.
[cpg]

[OnName num="kouya"]
"Nahhhhhh?
[cpg cn=true]

[OnName num="takuma"]
Try to kill me, you psycho!
[cpg cn=true]

I jumped on him. He resisted and repeatedly hit me on the back. I almost lost consciousness.
[cpg]

I tore off his clothes and saw the wound where I had stabbed him earlier with scissors. I bit him there.
[cpg]

[OnName num="kouya"]
Gagieeeeeeeeeeeeeeeeeee!　Teeeeeee!　away ......!!!!"
[cpg cn=true]

A tremendous amount of germs lurk in the human mouth - oh, I'm sorry. It was a pig.
[cpg]

I was shaken loose and fell to the ground. I fell head first and hit the floor.
[cpg]

[OnName num="takuma"]
I fell head first and hit the floor!　...... heh heh heh."
[cpg cn=true]

[OnName num="kouya"]
Damn you!
[cpg cn=true]

[OnName num="takuma"]
Get to the hospital right away. I don't think you'll get away without suspicion with that bloody mess.
[cpg cn=true]

;//(Y)うーん、戦うことの正当性が少しは主人公にあるという扱いは説明した方がいいのかもと思って追加

[OnName num="takuma"]
It's one thing to lose your temper for the sake of killing me, but don't get everyone else involved.
[cpg cn=true]

[SE f="se053"]
;//【ＳＥ】サイレン

A cloud of smoke wafts overhead. The ambulance sirens began to sound before the police sirens.
[cpg]

;//(Y)ここ長めの台詞ですが形勢が急転してるので、プレイヤーはけっこう興味深く追ってくれると思います。「何言い出すんだこいつ！？」とか思いながら主人公の台詞を読むところ

[OnName num="takuma"]
I see. You can't stand the fact that Sanae-san and I love each other, can you? That's how much you loved her.
[cpg cn=true]

[OnName num="takuma"]
I should have met him more often out of sight. I should have held her until she forgot her husband. ......
[cpg cn=true]

[OnName num="kouya"]
"〜〜〜〜?　Shut up!
[cpg cn=true]

[OnName num="takuma"]
"It's not me, it's that guy, isn't it?"
[cpg cn=true]

[OnName num="takuma"]
I'll just leave the car here. You're going to Hungary to work right now!
[cpg cn=true]

[OnName num="takuma"]
I'll come home for the funeral and show my face, and he'll leave without a word of love!
[cpg cn=true]

[OnName num="takuma"]
I'm sure she missed you, too!　It's not my fault!
[cpg cn=true]

;//(Y)修正指示のあった箇所ですが、この台詞単体がひどいというより周囲のエグさかなあ……という気がします。「こんな危険な敵相手に、なんでこの主人公は挑発してるんだ！？　しかも邪悪でゲス過ぎだろ！　意味分かんねえ！」という感情をプレイヤーに引き起こして引きつけ、そののち「あっ、挑発のところは意図してたのね……」と認識を変化させることで面白さが成立すると考えています。なので「罠なんですよ」と最初に言ってしまうと唐突さを失い、面白さが失われると思います。ここではなく後の暴力部分とかを多少納得できるよう変えてみます（自分のような書く側は過激さがわからなくなるところがありがち）

[OnName num="takuma"]
It's not my fault.
[cpg cn=true]

[OnName num="kouya"]
"Shut up ...... up ！！！！"
[cpg cn=true]

[OnName num="kouya"]
"......!　Oh, ...... is ......?
[cpg cn=true]

[SE f="se030"]
;//【ＳＥ】『倒れる』

Koya suddenly collapsed.
[cpg]

[OnName num="takuma"]
"......, you finally took it?"
[cpg cn=true]

[OnName num="takuma"]
It's a provocation. It's obvious, you know.
[cpg cn=true]

[OnName num="kouya"]
"Is ...... ah......?
[cpg cn=true]

[OnName num="takuma"]
You're breathing hard - you've been running around all over the place. I'm just holed up in here.
[cpg cn=true]

[OnName num="takuma"]
You're out of control, you're breathing funny, you're breathing toxic fumes.
[cpg cn=true]

I staggered to my feet. My whole body ached.
[cpg]

[OnName num="takuma"]
You've done so much to me," he said. --I'm going to squeeze more air out of your lungs.
[cpg cn=true]

[OnName num="kouya"]
"Wait, ......, stop!　Stop, stop, stop, stop, stop, stop, stop, stop!
[cpg cn=true]

The tables were turned.
[cpg]

;//画面シェイク

[SE f="se031"]
;//【ＳＥ】打撃音

[OnName num="kouya"]
"Gubo!　Geez!
[cpg cn=true]

I kicked him in the chest. Over and over again.
[cpg]

[SE f="se031"]
;//【ＳＥ】打撃音

[OnName num="kouya"]
"Gugu!　Gugo!　Gugu!　Gggggh!　Gugg!　Yibby!
[cpg cn=true]

[OnName num="takuma"]
Hahahahahaha!　That was funny!
[cpg cn=true]

[SE f="se031"]
;//【ＳＥ】打撃音

[OnName num="kouya"]
Gyah!　Beeeeee..!　Stop!　Gah!　Ow!
[cpg cn=true]

[OnName num="takuma"]
I'm sorry!　But, but...!
[cpg cn=true]

[SE f="se031"]
;//【ＳＥ】打撃音

[OnName num="takuma"]
I hate it when people cry and hit each other because they're in pain!
[cpg cn=true]

[SE f="se031"]
;//【ＳＥ】打撃音

[OnName num="takuma"]
I hate you more than anyone else!　You're an 'older lover' who hasn't grown out of it!　You stinking baby!
[cpg cn=true]

[OnName num="kouya"]
"Guggaaaaah!　Gaby!
[cpg cn=true]

[OnName num="takuma"]
He's the kind of guy who only cares about sexuality, so violence is the only way he can get away with it!
[cpg cn=true]

[SE f="se031"]
;//【ＳＥ】打撃音

[OnName num="takuma"]
That's why he's going to answer back like this!　You understand?　If you understand, you'll die!
[cpg cn=true]

Was it partly due to the excitement of having my life threatened? No, I had no excuse. I kicked and kicked until I was exhausted.
[cpg]

He was no longer my friend.
[cpg]

;//(Y)時間経過の暗転を一回だけ

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

The fire was getting worse. My head hurt. I wasn't going to stay here any longer.
[cpg]

As the paramedics called out to me, I saw a rescue mat being deployed below the window, and I jumped down onto it.
[cpg]

I don't know what happened to Koya.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

I told him that I had been beaten up by an assailant, and he was taken away in an ambulance. I fell asleep without making any effort to stay conscious.
[cpg]

When I got to the hospital bed, the nurse handed me a smartphone that she said had fallen out.
[cpg]

My mother and Ms. Sakurana came to visit me. To my surprise, Dr. Tokieda and Ms. Shiho also came. ...... I was too dazed to remember.
[cpg]

The first thing I did when I woke up was delete all the videos. Then I frowned in pain and went back to sleep.
[cpg]

The next thing I did when I woke up was to unsubscribe from the video-sharing site.
[cpg]

;//セピア調にしてください
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

Goodbye, that youth.
[cpg]

Sleep in my grave.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

Three weeks passed. Classes at both my university and its affiliated school were postponed. The members of the Bodoge club went on a trip to Okinawa. I was hospitalized.
[cpg]

The university building did not catch fire, so classes resumed shortly after.
[cpg]

My professor seems to have been informed of my hospitalization, so I can take a break even after classes resume.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

My body still aches. Maybe it's just lack of exercise since I was in the hospital.
[cpg]

;//========================================
;//●ＣＧ非エロ（スマートフォンの一般的なホーム画面）ev_51_0　再度流用
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[OnName num="takuma"]
Damn, I'm getting a lot of e-mails. My subscriptions for video editing software have been deducted for this month.
[cpg cn=true]

I look at the social networking site I've been using to advertise, and there's a reply, "Thank you so much, it's so encouraging to see.
[cpg]

Won't you resume?" Did you delete it?" A pile of replies, "What's wrong ......."
[cpg]

I write, "I'm surprised that your nose bleeds out of both holes," and start the process of deleting my account. It will disappear in a few days.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

There are still things left to do. It is the most important thing.
[cpg]

--I need to contact Ms. Sakuranae.
[cpg]

She hasn't contacted me since she came to visit me. I think she is concerned about my health. But...
[cpg]

--She didn't even ask me, "Koiya hasn't come home yet, do you know anything?" Isn't it strange that she doesn't even ask me "What's wrong?
[cpg]

Where is that dangerous guy doing now?　Did I kill him?
[cpg]

[OnName num="takuma"]
......."
[cpg cn=true]

My fingers trembled. My body creaked, and the pain came back.
[cpg]

[OnName num="takuma"]
"Don't tell me--is he with Mr. Sakuranae?　That guy in that state?"
[cpg cn=true]

[OnName num="takuma"]
"....... I'm afraid to contact him. I'm afraid to contact ......!
[cpg cn=true]

[OnName num="takuma"]
But. I'm afraid to contact her. ......Then that means I have to protect her. ......!
[cpg cn=true]

I made up my mind. I swallowed my spit. With trembling hands, I send a message to Sanae.
[cpg]

<How is Koja doing?　He got caught in the fire with me>
[cpg]

;//(Y)いったんここで肩の力を抜くために、ちょっとアホな展開をねじ込む
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

I had fallen asleep.
[cpg]

When I came to, my consciousness had snapped. The message from Mr. Sakuranae had arrived... Damn, the battery is dead.
[cpg]

I quickly attached the charging cord. --A message had arrived.
[cpg]

;//========================================
;//●ＣＧ非エロ（スマートフォンの一般的なホーム画面）ev_51_0　再度流用
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[OnName num="sanae"]
<Koya just got back yesterday>.
[cpg cn=true]

--The message had arrived. It was alive.
[cpg]

[OnName num="sanae"]
<Why did he go to the hospital in the next town on his own? It was like he was badly injured, but he refused an ambulance.
[cpg cn=true]

[OnName num="sanae"]
<I believe it was as if she didn't want to go to the same hospital as Takuma-kun>.
[cpg cn=true]

It might be .......
[cpg]

I imagined it. I imagined him crawling along, in that state of wreckage.
[cpg]

[OnName num="sanae"]
<I also checked the video channel that Koya told me about before, and it disappeared. Takuma-kun? >
[cpg cn=true]

I couldn't reply. I couldn't reveal the truth.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

When my body was healing, I started going to a boxing gym during the gaps in my vacation.
[cpg]

As long as he was alive, I had to get in shape. --I had to settle the matter.
[cpg]

I also made running a part of my daily routine.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_12_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の洗面所』（昼）******************************************************

That's why I started taking showers three times a day.
[cpg]

It doesn't really matter, but every time I get naked, it makes me feel that much more vulnerable to my body.
[cpg]

It is even more so when I receive a phone call from Koya.
[cpg]

[OnName num="kouya"]
Yo. ......."
[cpg cn=true]

[OnName num="takuma"]
Hey!
[cpg cn=true]

[OnName num="takuma"]
You!　You!
[cpg cn=true]

I struggled to keep my voice down. My mother was at home.
[cpg]

[OnName num="takuma"]
Who the hell do you think you are to contact me?　I hope you didn't do anything to hurt Ms. Sakuranae.
[cpg cn=true]

[OnName num="kouya"]
You haven't seen her? I'm sure you haven't. I've been at home all this time. I've been home.
[cpg cn=true]

[OnName num="takuma"]
Did you run away from home?
[cpg cn=true]

[OnName num="kouya"]
I'm gathering my things right now. Don't be so nervous. I've got it under control for now.
[cpg cn=true]

[OnName num="kouya"]
Every time I see her I want to kill her, but she's my mother. I don't even want to admit it.
[cpg cn=true]

;//(Y)以下流用。一部編集

[OnName num="kouya"]
I'm gonna have a little brother or sister."
[cpg cn=true]

It was as if the world had frozen over.
[cpg]

Yes, I should have thought of that possibility. I should have thought of that possibility.
[cpg]

I would have met her husband around the funeral. It is possible that it is his child with him.
[cpg]

[OnName num="takuma"]
...... so."
[cpg cn=true]

While I had a feeling that I knew it, I didn't expect to hear it from Kouya first.
[cpg]

From Mr. Sakuranae's point of view, he would be the first to tell his own son and his family. I guess it's not me.
[cpg]

[OnName num="kouya"]
I wonder what it's like to be a sibling so far apart in age. Hey, Stepfather."
[cpg cn=true]

[OnName num="takuma"]
"......!"
[cpg cn=true]

[OnName num="kouya"]
You think it's Dad's kid?　I'd hate to even entertain the slightest possibility.
[cpg cn=true]

[OnName num="kouya"]
Whether it's your kid or my dad's, I'm gonna do something about it before it's born.
[cpg cn=true]

[OnName num="kouya"]
After I kill you, I'm sure I'll kill your mother next.
[cpg cn=true]

[OnName num="takuma"]
Don't you feel bad, Mr. Sakuranae?
[cpg cn=true]

[OnName num="kouya"]
"....... You're the one who said that?
[cpg cn=true]

[OnName num="kouya"]
I can't stand it if I don't kill you. I have no choice but to live my life that way.
[cpg cn=true]
;//ＢＫ

;//ＢＫ

;//(Y)以下も多く流用。一部編集

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[SE f="se029"]
;//【ＳＥ】『ベッドに倒れこむ』

He collapsed on the bed and stared at the ceiling.
[cpg]

[OnName num="takuma"]
'...... your father-in-law or ......
[cpg cn=true]

There can be no more relationships. Would I ever have a normal relationship with someone else?　Probably not.
[cpg]

The only person I can call my lover in my entire life is Mr. Sakuranae.
[cpg]

;//(Y)追加
;//ＢＫ
;//(Y)セピア色にしてください。回想です。以下は追加シーン→流用→追加シーン→流用……という感じ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I had a dream. It reminded me of the time when I attended the school.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[OnName num="kouya"]
My mom bought some nice meat today, and I don't think I'll be able to finish it.
[cpg cn=true]

[OnName num="kouya"]
I'd like you to eat it with me at my house. ...... tomorrow is Saturday.
[cpg cn=true]

[OnName num="takuma"]
I'll bring ...... some games with me. I forgot my controller the other day.
[cpg cn=true]

[OnName num="takuma"]
I'm going to beat that boss this time. Don't shoot at your own teammates this time.
[cpg cn=true]

;//(Y)ここは流用。

[FG f="CHA03_p1_04_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Aki018"]
[OnName num="aki"]
Then I'll give you this problem, ......, Tomi-kun.
[cpg cn=true]

[OnName num="takuma"]
Yes, sir.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aki019"]
[OnName num="aki"]
What's wrong with ......?　What's wrong?
[cpg cn=true]

[OnName num="takuma"]
No, no, nothing. ......
[cpg cn=true]

;//(Y)ここは追加

Dr. Tokie was very perceptive. Koya fidgeted and froze.
[cpg]

;//(Y)別シーンからの流用。

[FACE method="shake_3" pos="2/3"]
[VOICE f="sAki010"]
[OnName num="aki"]
Can you two ...... whisper, but not talk during class?"
[cpg cn=true]

That's right. Why does Koya talk to me during class?
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="sAki011"]
[OnName num="aki"]
Really, Tohmi-kun is especially dazed these days. Please be careful.
[cpg cn=true]

[OnName num="takuma"]
Yes. ......
[cpg cn=true]

But for some reason, it was me who was firmly pissed off.
[cpg]

;//(Y)別シーンからの流用＋編集。回想はまだ続く

[window target=false]
[free time=1000]
[BG f="b_03_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

I take the game console out of the house and walk around town. The shortest distance between me and Sakuranae's house.
[cpg]

It was a familiar walk. The scenery is as familiar as the path to school.
[cpg]

;//(Y)別シーンからの流用
[window target=false]
[free time=1000]
[BG f="b_05_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の家＿リビング』（夕方）******************************************************

[OnName num="kouya"]
I'm deeply moved by that. The three of us eating together."
[cpg cn=true]

[OnName num="takuma"]
What do you mean ......?
[cpg cn=true]

The three of us were talking over dinner prepared by Sakurana-san.
[cpg]

[OnName num="kouya"]
We're all like family, you know? Right?"
[cpg cn=true]

That's an implied way of putting it. Both Sakura Nae and I were at a loss for a response.
[cpg]

[OnName num="kouya"]
What's the matter, don't freeze. I'm not doing anything wrong.
[cpg cn=true]

I think it's a sinful thing, in the eyes of the public.
[cpg]

;//(Y)別シーンからの流用

[window target=false]
[free time=1000]
[BG f="b_05_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の家＿リビング』（夜）******************************************************

[FG f="CHA02_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSanae039"]
;//[VOICE f="Sanae330"]
[OnName num="sanae"]
I'm sure it's a public thing. ...... Then, let's go to bed. Good night.
[cpg cn=true]

[OnName num="takuma"]
"I'd like to sleep with you, Sakura Nae-san, but ...... that's not a good idea, is it?"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
;//[VOICE f="Sanae331"]
[VOICE f="sSanae040"]
[OnName num="sanae"]
I would like to,......, but that man is supposed to be home late at night.
[cpg cn=true]

Yes, I know. I'll never be the best of her no matter how far I go.
[cpg]

No, I might be, but I have to hide it.
[cpg]

That's what it means to fall in love with a married woman, isn't it?
[cpg]

;//ＢＫ
;//(Y)回想終わり。新規追加。そろそろ突然のシュールを挟んだ方がほっとするはず
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

A few mornings later. I went to see a guy.
[cpg]

[OnName num="dobazaki"]
"......"
[cpg cn=true]

[OnName num="dobazaki"]
"......" I'm not going to ask for details. Can I ask you something?
[cpg cn=true]

[OnName num="dobazaki"]
Why do you need all this stuff?
[cpg cn=true]

[OnName num="takuma"]
"Is that what you're asking me?"
[cpg cn=true]

I take the package. I hand him a few cash bills.
[cpg]

[OnName num="dobazaki"]
'...... No, I ain't gonna ask you.
[cpg cn=true]

[OnName num="takuma"]
I've collected evidence of what you did. You just got out and now you want to be sent back to jail?"
[cpg cn=true]

[OnName num="dobazaki"]
I said I ain't listening!
[cpg cn=true]

[OnName num="dobazaki"]
Quack!
[cpg cn=true]

[OnName num="dobazaki"]
Quack!　Quack!　Quack!
[cpg cn=true]

Dobasaki fell on his face and arched over like a reverse scale insect.
[cpg]

[OnName num="dobazaki"]
I'm going home. To the sea.
[cpg cn=true]

[OnName num="dobazaki"]
In prison, I woke up."
[cpg cn=true]

[OnName num="dobazaki"]
"Quack!　Quack!　Quack!"
[cpg cn=true]

[SE f="se044"]
;//【ＳＥ】『水を掛ける』

Dobasaki crawled, undulated, rolled, and entered a small river.
[cpg]

Dobazaki had awakened to his ego as a seal. He had found a place to return to. To his own, rightful place. ......
[cpg]

Now that several protection orders have been issued under the law, we will never see Shiho again.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『部室』（昼）******************************************************

[OnName num="policeman_A"]
I wanted to ask you something about the site," he said. Are you feeling okay?"
[cpg cn=true]

The old days of the comic club room are over. The fire had not spread. Still, some chairs were destroyed.
[cpg]

[OnName num="policeman_A"]
You are the one who fought with the thugs and called the police, right, Tomi?
[cpg cn=true]

[OnName num="takuma"]
Yes, that's right. I don't remember much because I was so shaken up. ...... I was also hit on the head.
[cpg cn=true]

[OnName num="policeman_B"]
I was hit on the head. Did the man come this far?"
[cpg cn=true]

I kept lying to the police.
[cpg]

I don't know why. If I turn that guy in to the police, it would be over, but I'm lying to protect him.
[cpg]

I just don't want to get Mr. Sakuranae involved. ...... That's all there should be to it.
[cpg]

Even though Koya has already left home. Mr. Sakuranae misses him running away from home.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

I saw that car in the eaves of the Miyauji house.
[cpg]

[OnName num="takuma"]
"I have to go see him at ....... I have to go see him.
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の家＿リビング』（昼）******************************************************

;//(Y)流用

[FACE method="bow_7" pos="2/3"]
[VOICE f="Sanae124"]
[OnName num="sanae"]
...... you came.
[cpg cn=true]

[OnName num="takuma"]
Yes, I'm here. We had an appointment today, right?
[cpg cn=true]

;//(Y)追加

[FACE method="shake_7" pos="2/3"]
[VOICE f="sSanae041"]
[OnName num="sanae"]
"I'm... I'm ...... pregnant."
[cpg cn=true]

I nodded quietly. As if I knew.
[cpg]

[OnName num="takuma"]
I'll be there for you. Please don't worry.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sSanae042"]
[OnName num="sanae"]
Thank you. You are a really nice guy, Takuma. You gave me the words I wanted you to give me. ......"
[cpg cn=true]

I found the package I received from Dobasaki in my bag of luggage. ...... and hide it.
[cpg]

[OnName num="takuma"]
I got a car license.
[cpg cn=true]

[OnName num="takuma"]
Please let me use your car later.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sSanae043"]
[OnName num="sanae"]
I think that's what you were talking about when you said ...... that it's all about names."
[cpg cn=true]

[OnName num="takuma"]
"I'm at ....... You're the one I'm looking for."
[cpg cn=true]

Sakuranae was embarrassed. It has been a few days since Koya disappeared.
[cpg]

She seemed to be lonely and anxious already. There were also marks of crying.
[cpg]

The school festival was canceled. The chance to play the viola was gone.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sSanae044"]
[OnName num="sanae"]
Please forgive me. I can only comfort myself like this. ......
[cpg cn=true]


;//========================================
;//●ＣＧ非エロ（服を着せただけ。誘っている）ev_29_1
;//人物１：ヒロイン２
;//服装１：少しセクシー程度にはだけた私服（全年齢範囲）
;//場所　：自宅
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

Sanae-san was asking me out. She said she needed my warmth.
[cpg]

...... she knows nothing about. I couldn't say it was a slight at a time like this without Koya. That would be terrible.
[cpg]

Sakura Nae was trying to bear it.
[cpg]

;//(Y)ちょっと戻って流用

[VOICE f="Sanae126"]
[OnName num="sanae"]
"...... I still feel guilty about Kouya. I wonder what she would think if she knew about this.
[cpg cn=true]

[VOICE f="Sanae127"]
[OnName num="sanae"]
I wonder what he will think when he finds out about this. He might want to stop being my child.
[cpg cn=true]

[OnName num="takuma"]
Don't worry. I'll be with you then.
[cpg cn=true]

;//(Y)原文に誤字があったので直してます。「と取り」→「取り」

I took her hand and said that with a serious face.
[cpg]

[VOICE f="Sanae128"]
[OnName num="sanae"]
I'm sure you're right. So ...... what do you want to do?
[cpg cn=true]

;//(Y)選択肢の中から流用

[OnName num="takuma"]
I want to make love to you, Mr. Sakurana. I want to be equal.
[cpg cn=true]

[VOICE f="Sanae130"]
[OnName num="sanae"]
I was like, "Hmmm. I like Takuma-kun who says so, too.　I like you too, Takuma-kun.
[cpg cn=true]

The two hands are held together. The form of the connection between lovers. We love each other.
[cpg]

;//(Y)別シーン流用＋とちゅう1行カット。CGの口元に拡大してもいいかもしれません。違和感出るようならカットでも

[VOICE f="Sanae290"]
[OnName num="sanae"]
Let's kiss, Takuma-kun.
[cpg cn=true]

I responded and brought my lips to his once again.
[cpg]

We asked for each other, over and over again. I repeated it ......
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

That night, he came out to ask me to let him use my car. In his hand was that package and the vehicle maintenance tools.
[cpg]

[OnName num="takuma"]
"Please. Dobasaki......"
[cpg cn=true]

I remained the same, with little knowledge of cars. I've done some research on the Internet, read some books, and played a few games on vehicle maintenance.
[cpg]

I even lied about getting my license.
[cpg]

[OnName num="takuma"]
If I hadn't been crushed, none of this would have happened.
[cpg cn=true]

[OnName num="takuma"]
I'll take the blame.
[cpg cn=true]

Mr. Sakuranae. I would do anything to protect the only woman I've ever loved.
[cpg]

I took the engine starter out of the package.
[cpg]

I took out the engine starter from the parcel. Metals, cables, caution stickers. Cables, caution stickers. An empty box. The manual.
[cpg]

;//[OnName num="instructions"]
The words "This unit cannot be installed by the customer.
[cpg]

Please have it installed by a dealer or car dealer" -- "Please have it installed by a dealer or car dealer" --.
[cpg]

Needless to say, this is an illegally modified product. I wonder where I can find a vendor who will install it.
[cpg]

;//(Y)桜苗さんの部屋に泊まった想定

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2000]

[BGM f="bg_hu"]
[WAIT time=100]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の家＿リビング』（昼）******************************************************

;//(Y)2行ですが流用

[OnName num="takuma"]
Let's do it again at ......."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sSanae045"]
[OnName num="sanae"]
Yeah, yeah. I'll do it again."
[cpg cn=true]

;//(Y)追加

I didn't say anything.
[cpg]

I had a plan. If I succeeded, Koya would die. If I failed, I would die, and so would she and her baby.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep011.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

