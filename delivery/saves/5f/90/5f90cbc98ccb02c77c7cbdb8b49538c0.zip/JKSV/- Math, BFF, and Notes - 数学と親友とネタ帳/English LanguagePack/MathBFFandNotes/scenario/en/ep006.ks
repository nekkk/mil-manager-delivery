
*start|Date with Shiho

;#################################################
*Ep006|Date with Shiho
;#################################################

[SCENE id=6]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************

So, the next day. I went out with my parents, still under the guise of going out with friends.
[cpg]

I felt it would be a bad idea to walk together right out of the house, so we decided on a meeting place.
[cpg]

;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

[SE f="se002"]
;//【ＳＥ】『喧噪』

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shiho100"]
[OnName num="shiho"]
"Oh, this way, this way!
[cpg cn=true]

[OnName num="takuma"]
I'm sorry, I didn't mean to keep you waiting!　Did I make you wait?
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Shiho101"]
[OnName num="shiho"]
"Well, I guess this isn't too much of a wait.
[cpg cn=true]

I had made a slight mistake. I thought I was right on time.
[cpg]

I thought that if I waited too long, I would make them feel awkward, so I went with this strategy. ......
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Shiho102"]
[OnName num="shiho"]
"So ...... we have a date today. I haven't had a date in years. Where shall we go?"
[cpg cn=true]

[OnName num="takuma"]
"Anywhere you like, Shiho-san."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Shiho103"]
[OnName num="shiho"]
"Favorite place ......?　You mean I decide?
[cpg cn=true]

[OnName num="takuma"]
Yes." No?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Shiho104"]
[OnName num="shiho"]
"I'm not saying no, but I'm not impressed that you leave it to ...... others.
[cpg cn=true]

;//(Y)流用ですが、以下3行は言っていることをまとめてあります

Oh no. I feel like it's kind of backfiring. Should I start taking the lead now?
[cpg]

But, I thought, Shiho is much older than me. I thought she would naturally take the lead.
[cpg]

But this assumption might be hurting her.
[cpg]

[OnName num="takuma"]
So, let's go to ...... then."
[cpg cn=true]

Saying that, I grabbed her hand.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Shiho105"]
[OnName num="shiho"]
He said, "Hmm. That's very manly of you, where are you taking me?"
[cpg cn=true]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_11_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ゲームセンター』（昼）

[SE f="se002"]
;//【ＳＥ】『ゲームセンターの騒音』

So we went to the game arcade where I usually go.
[cpg]

This is where I usually go to play with my friends. There was karaoke and stuff, and I couldn't think of anywhere else to play.
[cpg]

I also thought about a movie or something for a bit, but then I remembered what Koya had said, "There are no good ones showing right now." ......
[cpg]

So I thought this was a good idea and suggested some UFO catcher,
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Shiho106"]
[OnName num="shiho"]
I suggested UFO catchers or something, and he said, "Hey, let's go out for a bit. Takuma-kun."
[cpg cn=true]

[OnName num="takuma"]
He said, "What, ......?　Yes.
[cpg cn=true]

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[FACE method="change_7" pos="2/3"]
[VOICE f="Shiho107"]
[OnName num="shiho"]
I'm about a year older than you, right? I'm about a year older than you, right? You ask a guy like that out to the arcade?
[cpg cn=true]

[OnName num="takuma"]
Was it a bad idea, ......?
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Shiho108"]
[OnName num="shiho"]
I hope you don't think ...... it's a bad idea, but it looked like he wasn't sure.
[cpg cn=true]

He knows everything. I certainly had a feeling that I had taken Shiho with me, wondering if this was the right thing to do.
[cpg]

;//(Y)膨らませます。追加

[OnName num="takuma"]
But if you give it a try, it might be more fun than you think.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sShiho062"]
[OnName num="shiho"]
But I've never been able to catch a UFO catcher. I've never been able to get a UFO catcher.
[cpg cn=true]

I see. It's no fun if you can't get it. I understand that very well.
[cpg]

[OnName num="takuma"]
"...... I found a place where I can lead."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="sShiho063"]
[OnName num="shiho"]
What?
[cpg cn=true]

[OnName num="takuma"]
I'll let you take it. Maybe I've been sucking up a lot of 100-yen coins to UFO catchers for this moment.
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sShiho064"]
[OnName num="shiho"]
Don't feel strange fate. ...... can I get it?
[cpg cn=true]

[OnName num="takuma"]
I'll take care of it."
[cpg cn=true]


;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

And I went around getting various stuffed animals and cushions for Shiho-san.
[cpg]


Sometimes I would say, "Maybe more to the right," or "In the back!" I would give her a hand and she would smile.
[cpg]

;//========================================
;//●ＣＧ非エロ（ヒロイン１がでっかいぬいぐるみを抱きかかえる。かわいらしい笑顔）ev_13_1

;//人物１：ヒロイン１
;//服装１：私服
;//場所　：街
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_13_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sShiho065"]
[OnName num="shiho"]
"Wow~...... it's so mochi mochi!"
[cpg cn=true]

[OnName num="takuma"]
I was so happy to see her smiling. I'm sure you'll be able to get it. If you get the hang of it.
[cpg cn=true]

[VOICE f="sShiho066"]
[OnName num="shiho"]
Thank you!　This kind of thing is unexpectedly fun, isn't it?
[cpg cn=true]

Shiho-san gave me a sincere smile.
[cpg]

I'm so happy. I'm in the comic club, and maybe that's why I take videos, to see those beautiful smiles.
[cpg]

[OnName num="takuma"]
I'm sure that the UFO Catcher strategy is good for videos.
[cpg cn=true]

[VOICE f="sShiho067"]
[OnName num="shiho"]
Sorry, the stuffed animal is too fluffy and happy to get into my head. ......
[cpg cn=true]

Strangely, I feel I can forgive anything. I have Shiho's smile in front of me.
[cpg]

I see. The older Shiho-san was that much older, you could say that her history of not being able to get stuffed animals = age. ......
[cpg]

I wonder how much she felt every time she passed by a game center, thinking, "But I can't get it even if I wanted it.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[VOICE f="Shiho109"]
[OnName num="shiho"]
Well, I'm hungry, let's have dinner. Where are you taking me this time?"
[cpg cn=true]

Now I was in trouble. I don't know where I can have a fancy lunch and I don't have much money.
[cpg]

[OnName num="takuma"]
I'll take you to ......, your favorite place."
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Shiho110"]
[OnName num="shiho"]
"Hmmm. I told you I'm not impressed with that. Oh well.
[cpg cn=true]

After all, Shiho-san has a lot of leeway. The way she is accustomed to the situation is different.
[cpg]

I am not a young man. It's not even fair to compare them.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

;//(Y)膨らませます。追加

Lunch was Spanish paella, which I didn't expect. But it was delicious.
[cpg]

I was thinking that Shiho likes to eat strange food, like coffee chicken.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="sShiho068"]
[OnName num="shiho"]
I still like him.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sShiho069"]
[OnName num="shiho"]
'I wonder why. I still can't sort it out. ......
[cpg cn=true]

[OnName num="takuma"]
I think I have those feelings, too.
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sShiho070"]
[OnName num="shiho"]
I am. ......I probably won't come ...... when I can say with confidence that Takuma-kun is the best."
[cpg cn=true]

It's frustrating. But it's Shiho. I honestly don't want her to fall in love with me right away.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="sShiho071"]
[OnName num="shiho"]
But I wonder why.
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="sShiho072"]
[OnName num="shiho"]
I remember how much fun it was to be with a man.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sShiho073"]
[OnName num="shiho"]
"I guess it's thanks to Takuma-kun that I'm remembering that now.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sShiho074"]
[OnName num="shiho"]
"....... Thank you."
[cpg cn=true]

Then - on Shiho's recommendation - we decided to look around for clothes and such.
[cpg]

;//(Y)二行ですが流用

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

He also taught me about various coordination techniques.
[cpg]

No, no, no, I thought to myself, what about having a woman tell me what to wear?
[cpg]

;//(Y)追加。不倫ものの醍醐味みたいなセリフを入れたい

[FACE method="change_2" pos="2/3"]
[VOICE f="sShiho075"]
[OnName num="shiho"]
"Heh heh.
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="sShiho076"]
[OnName num="shiho"]
I'm much happier than when I'm with him.
[cpg cn=true]

She suddenly blurted out those words. I didn't miss it.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="sShiho077"]
[OnName num="shiho"]
Takuma-kun confessed to me.
[cpg cn=true]

;//(Y)流用

[FACE method="change_6" pos="2/3"]
[VOICE f="Shiho253"]
[OnName num="shiho"]
I've been remembering Takuma-kun instead of my ...... husband.
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Shiho254"]
[OnName num="shiho"]
"I know I'm not a good wife, but ...... I still can't forget Takuma-kun.
[cpg cn=true]

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//[BGM f="bg_d2"]
;//[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

By the time I left, it was late.
[cpg]

;//(Y)追加

[OnName num="takuma"]
Thank you for today."
[cpg cn=true]

[OnName num="takuma"]
I had a great time on our date. It was my first time, but I can see why the men of the world are into it. ......"
[cpg cn=true]

;//(Y)流用

[FACE method="shake_7" pos="2/3"]
[VOICE f="Shiho296"]
[OnName num="shiho"]
Don't talk like you know what you're talking about. There are still many things you don't know about me.
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

I had a bit of a skirmish with my mom about coming home late.
[cpg]

But in the end, I think I was able to keep up the deception.
[cpg]

She thought I had a girlfriend or something.
[cpg]

;//(Y)また別の所から流用

She told me that if it was a girlfriend, I should bring her home sometime. ......
[cpg]

I can't do that. She's much older, and a married woman.
[cpg]

And she's a neighbor who's also close to my mom: ......
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep007.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
