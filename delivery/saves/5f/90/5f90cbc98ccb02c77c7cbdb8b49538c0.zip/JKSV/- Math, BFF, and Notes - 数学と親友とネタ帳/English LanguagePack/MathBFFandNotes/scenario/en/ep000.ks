
;//童貞喰い　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//詩穂　　私服
;//桜苗　　私服
;//晶姫　　私服　スーツ

;//以下音声なし
;//拓馬
;//拓馬の母
;//女子学生
;//男子学生Ａ
;//男子学生Ｂ
;//耕哉
;//男子学生
;//女子学生Ａ
;//女子学生Ｂ
;//女子学生Ｃ
;//桜苗の夫
;//桜苗の娘
;//ドバ崎

;//詩穂 08 11 13 19 20
;//桜苗 07 22 23 25 26 29 52
;//晶姫 06 34 35 38 43 47
;//その他 51 53


*start|I've loved older people since I was a kid.

;#################################################
*Ep000|I've loved older people since I was a kid.
;#################################################

[SCENE id=0]

;//ＢＫ

[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]

;//暫く回想シーンですのでセピア調にしてください

;//(Y)以上は、元文。全年齢版のコメントは『;//(Y)』を付けようかと思います（苗字のイニシャル）

;//(Y)時間としては放課後の想定なので夕方が適切な気がしますが、夕方だと特別な意味ある時間のように思えそうなので、イントロとしては情報量が増えて優しくないかと思います。なのでここは昼にするのがいいかなあと思います

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『部室』（昼）******************************************************

[OnName num="kouya"]
"Takuma!　I've got a good story!"
[cpg cn=true]

I open the door to the club room and a noisy guy walks in. He is more excited than ever.
[cpg]

[OnName num="takuma"]
"Kouya! Shhhh ...... it's study time."
[cpg cn=true]

[OnName num="kouya"]
"Oh, sorry."
[cpg cn=true]

This is the club room of the Comedy Club. We call it studying and watch comedians live.
[cpg]

The guy in front of me is sleeping on three chairs together. I hope you can guess how serious I am.
[cpg]

While many of the club members were playing on their phones, some of them were trying to watch and learn the art properly, and they looked at Kouya with a sober eye.
[cpg]

[OnName num="takuma"]
"What's the story at ......?　What kind?"
[cpg cn=true]

[OnName num="kouya"]
'Look, a storybook. I think this will get more viewers."
[cpg cn=true]

[OnName num="takuma"]
"...... It's "Pop lemonade" ripoff!"
[cpg cn=true]

[OnName num="kouya"]
No?"
[cpg cn=true]

[OnName num="takuma"]
This is "Umeboshi defeated 170,000 people"! "Apex predator Toshizawa eats zombies"! "Ink ribbon"!
[cpg cn=true]

[OnName num="takuma"]
"Personification of existential crisis"! "Ryohuhousen"! "Don't Search Brothers"!
[cpg cn=true]

I pointed to a TV clip that was playing right now. There, a comedian is wowing the audience.
[cpg]

[OnName num="takuma"]
"Gorongoro Dobazaki"! ...... You know this guy lives next door to my house, right?"
[cpg cn=true]

[OnName num="kouya"]
"What!?　...... well, we talked about this before."
[cpg cn=true]

[OnName num="takuma"]
"If I upload it to a video site, the next day they might ask, "Ripped off?" Don't do it."
[cpg cn=true]

One of the club members looked at "Gorongoro Dobazaki" and blew up. If you look at it, you can see the snot coming out of his nose.
[cpg]

This triggers laughter among the club members. Even those who were sleeping start to wake up, and those who were playing with their phones look up.
[cpg]

He was rolling around the stage on his side, bouncing around. This is a move that is not normally possible.
[cpg]

The floor of the stage was banging, and next to me, my partner was shouting with his head in his hands, "What am I going to do! my partner was shouting with his head in his hands.
[cpg]

[OnName num="takuma"]
"Can Kouya do that?　That's the kind of stuff I brought you. I don't know how to train you to do it."
[cpg cn=true]

[OnName num="kouya"]
"I can't ....... Absolutely impossible. I'm sorry."
[cpg cn=true]

Dobazaki's performance is over. The senior judges raised their tags, saying "Pass," "Pass," "Ummm," and "Pass.
[cpg]

There is one person with a very subtle score, but a girl in the club interjected, "You were laughing just now. ......."
[cpg]

[OnName num="takuma"]
Dobazaki" is the name of a Japanese restaurant that has made it to the finals. Dobazaki.
[cpg cn=true]

[OnName num="kouya"]
I don't like it, Dobazaki....... I couldn't remember until I saw it."
[cpg cn=true]

[OnName num="takuma"]
"If he's going to be in a New Year's special in the next fight, I'll be approached to collaborate with him ....... No, he's going to be busy too."
[cpg cn=true]

Me and Kouya have a few videos up. I would like to collaborate with my neighbor if he breaks even more.
[cpg]

[FACE method="change_1" pos="2/3"]

The screen switched. The moderators began to proceed with a "Thank you very much.
[cpg]

One of the women, "Ariya Munakata," caught my attention.
[cpg]

[OnName num="takuma"]
"......"
[cpg cn=true]

She is 17 years older than me. She has fair skin. She has broad shoulders - I wish I could have hugged her.
[cpg]

No, I can't. I can't do it.
[cpg]

;//(Y)変更。 >記憶を遡るといつからかは定かじゃない。　などカットしてます

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Ever since I was a little girl, I somehow had my eye on women like teachers, friends' mothers, and so on.
[cpg]

Was it because I was too young?　No, no.
[cpg]

I can say that I have had a love affair with older people since I was a kid. I never had a crush on anyone, not even my classmates, but even those who were a little older than me.
[cpg]

The first time I became aware that I was in love was last year. When I was a freshman, I first confessed my feelings to a teacher at the school.
[cpg]

A little while later, I fell in love with my friend's mother.
[cpg]

And now, I couldn't take my eyes off my neighbor, a married woman.
[cpg]

;//(Y)場面転換のしかたを、日付転換だと分かる転換にしてください

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=3000]
[BG f="b_00_1.ui" time=1000]
[WAIT time=2000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

Takuma Toomi, a hardcore older lover, was greeting his neighbor today.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

My neighbor's name is Shiho Iizuka.
[cpg]

Her husband is that "Gorongoro Dobazaki". He has no children, so he is very good at taking care of me.
[cpg]

I forced my way in on what appeared to be a conversation with my mother.
[cpg]

[OnName num="takuma"]
Good morning, Shiho-san!
[cpg cn=true]

[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shiho001"]
[OnName num="shiho"]
Good morning. Are we at school now?"
[cpg cn=true]

[OnName num="takuma"]
Yes, its ...... beautiful today, Shiho-san."
[cpg cn=true]

[OnName num="sakura_mother"]
Go on, go on. Don't talk like that."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
Shiho-san laughs, and I usually tell her she is beautiful or pretty.
[cpg]

So I don't think it deserves to go through. And I'm going to say however much I'm through.
[cpg]

[OnName num="takuma"]
Well, I'm off then!"
[cpg cn=true]

Dare to be energetic, so that Shiho-san will remember you and see you as an energetic, good-looking young man.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Shiho002"]
[OnName num="shiho"]
Yes, have a good day."
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

[OnName num="female_student"]
Good morning, Tomi-kun.
[cpg cn=true]

[OnName num="takuma"]
Oh, yeah. ......."
[cpg cn=true]

A girl in my class talks to me on the way to school.
[cpg]

[OnName num="female_student"]
"Wanna go to the academy with me?　Let's do that."
[cpg cn=true]

I look normal. And since normal is not a bad thing, there are sometimes these oddballs.
[cpg]

But I had no interest in girls my own age.
[cpg]

I'm sorry to say this, but it seems childish.
[cpg]

It's like they ooze condescension towards men, or something like that.
[cpg]

;//(Y)エピソード足します
[FADEOUTBGM]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

-- No, I'm sure I'm still dragging it out.
[cpg]

;//(Y)回想。

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//(Y)【ＢＧ】『街』（夕方・セピア調）

Camera flashes surrounded me. Yes, that was in the evening.
[cpg]

He had several jump ropes tied to his arms. He was beaten, kicked, and kept being photographed. ......
[cpg]

[OnName num="female_student_A"]
"Gahahahaha!　That's disgusting!"
[cpg cn=true]

Her lips, which she says are the most beautiful in the class, are slime-covered like slugs.
[cpg]

[OnName num="male_student_A"]
"Don't get carried away!"
[cpg cn=true]

[SE f="se009"]
;//(Y)【ＳＥ】ビンタ
;//(Y)　画面シェイク

[OnName num="takuma"]
"Guh!　Fuck!"
[cpg cn=true]

[OnName num="male_student"]
"Hey!　One more shot!"
[cpg cn=true]

They hit me. Kicked. No one enters to help me; nine of my classmates are laughing around me.
[cpg]

I don't know why this happened.
[cpg]

;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I found out later - one of the girls had let it slip that she liked me.
[cpg]

This was overheard by this male student who is now beating me up. He liked this girl.
[cpg]

It is a childish story. From beginning to end.
[cpg]

[free time=1000]
[WAIT time=1000]

;//(Y)【ＢＧ】『街』（夕方・セピア調）

[OnName num="male_student_A"]
He's crying. Are you getting the video?"
[cpg cn=true]

[OnName num="male_student_B"]
You've been on a roll since before!"
[cpg cn=true]

[OnName num="female_student_B"]
I wonder why he fell in love with this guy."
[cpg cn=true]

;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sShiho001"]
[OnName num="shiho"]
Stop it!"
[cpg cn=true]

[SE f="se052"]
;//(Y)【ＳＥ】クラクション
;//(Y)フラッシュ

It was then that help arrived.
[cpg]

She pulls up to this alley in a red car that looks expensive. A horn honks.
[cpg]

A horn sounds, and the residents gather over there. I can't see them because of the shadow of the car, but they seem to be peeking over here.
[cpg]

[OnName num="female_student_A"]
"Wh, what ......!?"
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="sShiho002"]
[OnName num="shiho"]
Sorry, there boy.
[cpg cn=true]

She also took pictures with her smart phone. However, she seemed to be taking pictures of them around her.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="sShiho003"]
[OnName num="shiho"]
'I'll call the school. This is evidence."
[cpg cn=true]

With those words, the guys around me started to run away as if they were scattering. Some of them shat their pants. Others still kept their courage.
[cpg]

[OnName num="male_student_A"]
"What the ...... fuck!"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sShiho004"]
[OnName num="shiho"]
Oh, you have no idea what's going on."
[cpg cn=true]

The frat boy, who earlier had looked like an arrogant giant, could only make his voice tremble.
[cpg]

Was she on her way home from work? She put her coat on me.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sShiho005"]
[OnName num="shiho"]
My husband is a TV comedian."
[cpg cn=true]

[OnName num="male_student_A"]
"Yeah, so what!　My dad is a city councilman!"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="sShiho006"]
[OnName num="shiho"]
Do you want to be made into a beautiful story?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="sShiho007"]
[OnName num="shiho"]
Dobazaki solves bullying case". It's going to be in a weekly magazine. Just pretend it was my husband who came here, not me."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sShiho008"]
[OnName num="shiho"]
'When a comedian does that, a lot of people find it more amusing. He uses you as a springboard to shine."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sShiho009"]
[OnName num="shiho"]
I'm sure they'll talk to your father and your mother."
[cpg cn=true]

The person approached the male student. He took his arm and laced the tips of his long, slender fingers with his.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sShiho010"]
[OnName num="shiho"]
Have you ever been fingerprinted?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="sShiho011"]
[OnName num="shiho"]
I can get at least one of the escapees from the phone I was filming with," he said. We can use that as evidence that he was part of the filming."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="sShiho012"]
[OnName num="shiho"]
Do you know what it's like to be woken up in the middle of the night by the noise of the news crews at your house and at your school?"
[cpg cn=true]

Trace your fingers together. Tsutsuu ...... and down to the palms of the boys' hands.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="sShiho013"]
[OnName num="shiho"]
He said, "Your father and mother won't sleep well, and they'll scream in their nightmares at night. They look at you differently."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="sShiho014"]
[OnName num="shiho"]
"I might just blurt it out. Why did you do that?" Or, 'Why did you do that? 'Did you apologize? And then there's the rest. And then there's ......."
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="sShiho015"]
[OnName num="shiho"]
"――I wish I had never given birth."
[cpg cn=true]

[OnName num="male_student_A"]
"Ah......Aaahhhhhhhh!"
[cpg cn=true]

[SE f="se012"]
;//【ＳＥ】『走る』

He ran away.
[cpg]

They forgot many things. A student bag. A light green jumper.
[cpg]

I certainly fell in love with this guy then.
[cpg]

If you're not older, no.
[cpg]

[free time=300]
[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sShiho016"]
[OnName num="shiho"]
"It's all right now"
[cpg cn=true]

She hugged me. Her hair was fluffy in my face. She smiled gently at me.
[cpg]

My heart ―― I can't help it anymore.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep001.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
