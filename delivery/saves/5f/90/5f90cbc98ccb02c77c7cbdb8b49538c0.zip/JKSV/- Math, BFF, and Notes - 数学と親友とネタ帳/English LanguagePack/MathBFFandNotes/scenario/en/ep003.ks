
*start|The Decisive Moment

;#################################################
*Ep003|The Decisive Moment
;#################################################

[SCENE id=3]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]

I couldn't sleep much that day. It was more like being awake than having a nightmare.
[cpg]

The curtains in Shiho's room were still open. What the heck, I'm already ......
[cpg]

[window target=false]
[BG f="b_00_1.ui" time=1000]
[WAIT time=3000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

[SE f="se001"]
;//【ＳＥ】『歩く』

I headed to the school without waking up much.
[cpg]

I didn't hear Shiho-san and my mother talking today.
[cpg]

Well, I guess it's not something they do every day. It's just that they often do that.
[cpg]

[OnName num="female_student"]
Good morning, Takuma-kun. Takuma-kun.
[cpg cn=true]

[OnName num="takuma"]
Oh, good morning. ......
[cpg cn=true]

It's a girl from sometime ago. This girl doesn't ask, "Are you sick?" She didn't ask me "Are you sick?
[cpg]

Students of my generation have their hands full with themselves, not because they are girls, but because they have their hands full with themselves.
[cpg]

I have my hands full with myself. I'm too busy with myself to notice if someone else is sick. I guess she's the same way.
[cpg]

[OnName num="female_student"]
"Let's go to the school together. Hey, it's good, right?"
[cpg cn=true]

[OnName num="takuma"]
Yeah, well, ...... good."
[cpg cn=true]

She probably can't see that I'm thinking inside that it's a hassle.
[cpg]

The girl seemed happy. Maybe she has a thing for me.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************

[OnName num="kouya"]
What is it? Is that her?"
[cpg cn=true]

When I entered the classroom with that girl, she said to me.
[cpg]

[OnName num="takuma"]
I didn't even know we were in the same class.
[cpg cn=true]

[OnName num="female_student"]
I was like, "Hi, that's terrible. Hahaha,......."
[cpg cn=true]

The girl's face is drawn. Did I say something bad?
[cpg]

However, it is still difficult to be friendly to someone you are not good at.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

On the other hand, Sensei is beautiful today. Not the homeroom teacher, of course, but Ms. Tokie.
[cpg]

I was still gawking at that stylized body.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aki005"]
[OnName num="aki"]
"......Tomi kun. Tomi-kun?"
[cpg cn=true]

[OnName num="takuma"]
What was it? What was it?
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Aki006"]
[OnName num="aki"]
"You know,......, are you taking the class seriously?"
[cpg cn=true]

I can't answer that I don't take it very seriously.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Aki007"]
[OnName num="aki"]
I'm serious about my classes, so you're going to have to take me seriously.
[cpg cn=true]

Seeing his angry expression, I thought to myself.
[cpg]

;//■選択肢
[switch]
[case "I'm not content to be scolded."]
	[swap]
	[jump target="*select03_1"]
[case "Taking the class seriously without looking at Tokieda-sensei"]
	[swap]
	[jump target="*select03_2"]
[endswitch]

1, I am not content to be scolded.
2. Taking the class seriously without looking at Ms. Tokieda

;//==============================
;//１、叱られるのもまんざらじゃない
*select03_1|The decisive moment

;//後の分岐時に晶姫が候補になる
[stflag Cha3flg = 1]

[OnName num="takuma"]
"I'll be careful from now on."
[cpg cn=true]

When I replied so in a delirious manner, he sighed.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Aki008"]
[OnName num="aki"]
'...... that's fine then. I hope you mean what you say."
[cpg cn=true]

I didn't say that. ...... I'm sorry.
[cpg]

[jump target="*select03_3"]
;//==============================
;//２、時枝先生を見ず真面目に授業を受ける

*select03_2|The decisive moment.

[OnName num="takuma"]
'I'm sorry. I'll take the class seriously."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Aki009"]
[OnName num="aki"]
"Please do so. If you can answer right away, it's still better.
[cpg cn=true]

I guess there must be some boys who can't reply here if they are as beautiful as Ms. Tokieda.
[cpg]

But I didn't want my grades to drop any further, so I decided to take the class seriously.
[cpg]

;//==============================
*select03_3|The decisive moment

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************

After school. I was approached by a different girl than in the morning.
[cpg]

[OnName num="female_student_A"]
Hey, Tomi-kun. Can I talk to you for a minute?
[cpg cn=true]

[OnName num="takuma"]
She said, "......Yes."
[cpg cn=true]

He doesn't look serious. Or rather, they look like they are amused by something.
[cpg]

I felt like I might get involved in something, but I had no reason to refuse, so I went along.
[cpg]



[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

The morning girls were at the place where I was brought.
[cpg]

She was holding a bag that looked like it could hold a letter, and her face was bright red.
[cpg]

[OnName num="female_student_A"]
She said, "You can do it. You're a beautiful girl, you should have confidence.
[cpg cn=true]

[OnName num="female_student_B"]
That's right, you're the center of attention in class. ......
[cpg cn=true]

She was the center of attention in class, apparently. I never noticed it.
[cpg]

If you ask me, I think she has a well-defined face. And she looks pure and innocent.
[cpg]

[OnName num="female_student_3C"]
Oh, you know. Tomi-kun, that, I, I, wa, I am ......"
[cpg cn=true]

But why are there three of them? I guess this girl said she couldn't do it alone.
[cpg]

[OnName num="female_student_3C"]
I like you,......, I've always liked you,......, I like you."
[cpg cn=true]

How many times do I have to say it? I understand.
[cpg]

[OnName num="takuma"]
"I'm sorry. I can't read that letter.
[cpg cn=true]

[OnName num="female_student_3C"]
"Oh, ......?"
[cpg cn=true]

[OnName num="takuma"]
I don't know what's in it, but it's gonna be hard for me to read it. Because I can't go out with you.
[cpg cn=true]

[OnName num="female_student_A"]
"Oh, you don't have to say it like that!　You should take it.
[cpg cn=true]

Oh. I hate this feeling. It's becoming even clearer why I'm not interested in my generation.
[cpg]

I hate children. I guess it's a kind of homophobia.
[cpg]

[OnName num="takuma"]
I can't accept it. Is this all there is to it?
[cpg cn=true]

I must be doing something very resentful. Normally, I would just accept the letter and then decline.
[cpg]

But that too is a hassle. That's how much I don't like this kind of atmosphere.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

[OnName num="kouya"]
You know, you're going to get stabbed someday. You'll get stabbed someday if you do that.
[cpg cn=true]

[OnName num="takuma"]
"I don't know ......, I mean, how did you know?
[cpg cn=true]

[OnName num="kouya"]
I've been watching you secretly.
[cpg cn=true]

[OnName num="takuma"]
You have bad taste.
[cpg cn=true]

[OnName num="kouya"]
You don't say that. What kind of taste do you have?
[cpg cn=true]

Is it enough to make you question your taste? I wonder if she is that popular, the girl I just met.
[cpg]

[OnName num="kouya"]
She's the class' madonna, you know?　What a waste.
[cpg cn=true]

[OnName num="takuma"]
Madonna is so old-fashioned. ......
[cpg cn=true]

But what can I do if I'm not interested in something?
[cpg]

[OnName num="takuma"]
Rather than that, can I go over to Koja's house again today?'
[cpg cn=true]

[OnName num="kouya"]
'Huh?　I'm not going to ...... do that today. The time is also the time, you can't play too much.
[cpg cn=true]

[OnName num="takuma"]
I don't think so. I'm sorry I took up so much of your time with something I didn't need.
[cpg cn=true]

[OnName num="kouya"]
What do you mean, "extra time"?
[cpg cn=true]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_00_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[OnName num="takuma"]
I'm home.
[cpg cn=true]

I must be a terrible guy.
[cpg]

I don't just like older men. I've been a virgin for so long that I want my first partner to be an adult.
[cpg]

I'm too much of a virgin, and I want my first partner to be an adult.
[cpg]

If it was an older guy, I would be more nervous than most boys. ......
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

It's already night. I've eaten dinner and taken a bath.
[cpg]

I wondered if the curtains would be open again today. That's what I thought and just looked.
[cpg]

I had no other intention. Really, it was just curiosity. ......
[cpg]

So I had no idea that something like this would happen.
[cpg]

;//========================================
;//●ＣＧ非エロ（ヒロイン１と夫。カーテンはヒロイン1の脚が見える程度でほぼ閉じて影ばかり。シルエットで見える夫が左手前に立ち、ふりかぶるように手を上げている。元のev08の絵の窓枠の中だけ違う差分）ev_08_1
;//人物１：ヒロイン１
;//服装１：ほとんど影につきほぼ絵では不明だが、私服の想定
;//人物２：ドバ崎ごろんごろ（ヒロイン１の夫）
;//服装２：ホストのような装飾的スーツ
;//場所　：ヒロイン１の部屋（窓越し）
;//時間　：夜
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_08_a ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//(Y)追加 カーテンは——閉じていた。でも中の様子が光と影でうっすらとわかる。
The curtains were open. I could see what was going on inside.
[cpg]

[SE f="se009"]
;//【ＳＥ】『ビンタ』
[WAIT time=1000]

At first, Shiho fell down in the bed. She is holding her cheek and looks like she is in pain.
[cpg]

[OnName num="dobazaki"]
'Haaaa~...... I knew it would feel good.
[cpg cn=true]

[OnName num="dobazaki"]
How many times do I have to tell you, dude?"
[cpg cn=true]

It was a voice I had heard before. It was that voice that I often hear on TV in the comic club.
[cpg]

I turned on the voice memo function on my smartphone.
[cpg]

--It was a habit I had when something unusual was happening. My body moved before my head.
[cpg]

When the screen of a medal game at a video arcade broke down and a buggy video started playing, I immediately took a picture of it. ......
[cpg]

[VOICE f="sShiho018"]
[OnName num="shiho"]
"Hey!　I told you to ...... stop it already. ......."
[cpg cn=true]

[OnName num="dobazaki"]
You're the cutest when you look like you're in pain, Shiho."
[cpg cn=true]

It was a lowly voice. It was that voice I heard on TV, but not in any of those ways of speaking.
[cpg]

[OnName num="dobazaki"]
I told you not to meet any men, remember?　When I was out."
[cpg cn=true]

[OnName num="dobazaki"]
'Wives are supposed to do what they're told, right?
[cpg cn=true]

[VOICE f="sShiho019"]
[OnName num="shiho"]
I'm sorry.
[cpg cn=true]

[OnName num="dobazaki"]
Who's that kid?
[cpg cn=true]

[OnName num="dobazaki"]
Why did you say hello?　I told you to ignore him, didn't I?　I'm getting horny just talking to you.
[cpg cn=true]

[VOICE f="sShiho020"]
[OnName num="shiho"]
Stop it!　Why are you hitting me!"
[cpg cn=true]

[SE f="se045"]
;//【ＳＥ】皿が割れる
[WAIT time=1000]

The sound of throwing things. The sound of something breaking. I could hear it from next door.
[cpg]

His silhouette is in the window frame that I can see from here.
[cpg]

[OnName num="dobazaki"]
I told you to do what you have to do!　I've told you a million times!
[cpg cn=true]

This is a man who is not only a comedian, but has recently begun to market himself in an idol-like direction as well.
[cpg]

No way - what I'm looking at is -.
[cpg]

[SE f="se009"]
;//【ＳＥ】『ビンタ』
[WAIT time=1000]

;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Shiho's faint scream went up.
[cpg]

I couldn't watch. I cover my ears and eyes, leaving the recording on my smartphone untouched.
[cpg]

I knew why there was a shadow on Shiho-san's face.
[cpg]

Through the gap between my blocked ears, I could hear sounds coming from next door.
[cpg]

[SE f="se009"]
;//【ＳＥ】『ビンタ』
[WAIT time=1000]

And then - a voice saying, "Don't even think about consulting me or something. ......
[cpg]

[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）

I couldn't hear the sound anymore. I stared at my recorded smartphone.
[cpg]

If I turned it over to the police, would they act on it? Would it become evidence?
[cpg]

I'm shooting video too. I think the sound quality is clear. It's next door, so I'm not sure if it's heartbreaking, but you can check it out at .......
[cpg]

[OnName num="takuma"]
Poet: ......
[cpg cn=true]

There was something strange about her facial expression recently. All this time, she's been holding back.
[cpg]

There was no way she could laugh. Even that cool Shiho-san was not like that.
[cpg]

[OnName num="takuma"]
"Shiho-san......!!!!"
[cpg cn=true]

I found myself gritting my teeth and enduring. There was anger.
[cpg]

I'm not going to be able to do that. The stuff you've been taking down belonged to a man who wasn't worth taking down.
[cpg]

I felt the respect I had for that man somewhere in my heart disappear. All that was there now was anger.
[cpg]

[OnName num="takuma"]
I thought to myself, "If it's a comic club, ......, it's ......?　If it's study, it's ......?　Seeing the 'laughter' he causes?"
[cpg cn=true]

[OnName num="takuma"]
That I was childish, too?
[cpg cn=true]

[OnName num="takuma"]
If I had known more about people, would I have realized that he wasn't just a pretty face?"
[cpg cn=true]

[OnName num="takuma"]
Fuck you, ......, fuck you!"
[cpg cn=true]

I tried to punch the pillow on the bed. I stopped when the pillow overlapped with Shiho's.
[cpg]

[OnName num="takuma"]
'Ugh ...... ugh!'
[cpg cn=true]

He routinely ...... Mr. Shiho.
[cpg]

The curtains had been opened only recently. Shiho-san might have been looking for help.
[cpg]

It was closed this time. I have a feeling that he tried to ask for help and stopped.
[cpg]

What should I do?
[cpg]

The other party is a man who has even appeared on TV. Would the police act?
[cpg]

I should help her, shouldn't I?　But how?
[cpg]

;//(Y)　全年齢版ではここで完全に詩穂ルートへ分岐する予定。

;//■選択肢
[switch]
[case "I want to help Shiho-san."]
	[swap]
	[jump target="*select04_1"]
[case "I'll call the police. It's not my place."]
	[swap]
	[jump target="*select04_2"]
[endswitch]


*select04_2|I want to help Shiho-san.

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep008.ks" target="*select04_2"]


;//■選択肢
1, I want to help Shiho-san.
2. I'll call the police. It's not my place.

;//※今までの分岐で、候補になっているヒロインから選択
;//※候補が一人もいない場合「候補がいない場合」へと分岐する
;//※選択肢４は全てのルートを通りつつ、ヒロイン全員が候補になている場合発生

;//==============================
;//１、詩穂さんを助けてあげたい
*select04_1|I want to help Shiho-san.

;//(Y)　全年齢版ではここで完全に詩穂ルートへ分岐。

I'm a video distributor.
[cpg]

That's right. I have a plan.
[cpg]

In my blackened mood, I started to plan a plan.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[jump storage="ep004.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
