
*start

;//==============================
;//稲生の戦いで敗北していた場合

*root_5|Two people who are attracted to each other

;#################################################
*Ep004|Two people who are similarly attracted to each other.
;#################################################

[SCENE id=4]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru112"]
[OnName num="ranmaru"]
I'm sorry," said Keitaro. Keitaro.
[cpg cn=true]


[OnName num="keitarou"]
What is it, ......?
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru113"]
[OnName num="ranmaru"]
I've always been jealous of you. Nobunaga-sama likes you.
[cpg cn=true]


[OnName num="keitarou"]
Was that so?
[cpg cn=true]


I've been thinking about it for a long time.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru114"]
[OnName num="ranmaru"]
I've been thinking. How can I get you away from Nobunaga-sama?
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

[SE f=se014]
;//【ＳＥ】『地面歩く』

Saying this, Ranmaru-sama leads me out of the castle.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru115"]
[OnName num="ranmaru"]
I don't think I have any other choice. It's not like I want to do it.
[cpg cn=true]


[OnName num="keitarou"]
What are you talking about?　Ranmaru-sama.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="sRanmaru001"]
[OnName num="ranmaru"]
I'm not going to fall in love with you. I'd rather control you.
[cpg cn=true]

[STOPBGM]

[FG f="CHA05_p5_01_a.ui" method="change_2"  pos="2/3" time=1000]
Saying so, Ranmaru-sama came up to me and kissed me .......
[cpg]


;//移植前シーンカット
;//【ＢＧ】『城＿縁側の廊下』（夜）

[FACE method="change_6" pos="2/3"]


[VOICE f="sRanmaru002"]
[OnName num="ranmaru"]
What the hell? Don't make that face.
[cpg cn=true]


She looked a little embarrassed after we parted our lips.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

I was in my room, a little confused by Ranmaru-sama's approach to me.
[cpg]

Serving Nobunaga-sama is all I want to do. That's probably not wrong.
[cpg]

But if Ranmaru-sama is the same, maybe it is natural that we are attracted to each other.
[cpg]

In the end, I guess it comes down to what I do and what I want to do. ......
[cpg]

I was a bit torn as to whether or not I should just go along with Ranmaru-sama's advances.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

One day, I was called by Nobunaga-sama to his room.
[cpg]

Ranmaru-sama was there, and the atmosphere was delicate.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Nobunaga591"]
[OnName num="nobunaga"]
What's the matter, you two? Your faces are red.
[cpg cn=true]


[OnName num="keitarou"]
No, no. Nothing.
[cpg cn=true]


[FACE method="shock_3" pos="4/5"]
I was about to say, "Nothing," when Ranmaru-sama looked a little angry.
[cpg]

[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga592"]
[OnName num="nobunaga"]
He said, "...... Well, that's all right. It's not the end of the world. I expect you two to work even harder than before.
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

Then I was on my way to her room, accompanied by Ranmaru-sama.
[cpg]

She asks me what I am going to do. In other words, she wondered if ...... I would ever be with someone else.
[cpg]

[OnName num="keitarou"]
'That's out of the blue. I don't know if that's what you want me to say.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru140"]
[OnName num="ranmaru"]
She said, "It's okay. Just answer me."
[cpg cn=true]


She seemed unable to look me in the eye. I guess it's the flip side of the fact that she wants to hear it so badly.
[cpg]

[OnName num="keitarou"]
Right now, serving Nobunaga-sama is all that matters.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru141"]
[OnName num="ranmaru"]
...... really do look like each other. Maybe that's why we're attracted to each other.
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

Then Ranmaru-sama approaches.
[cpg]


[VOICE f="Ranmaru142"]
[OnName num="ranmaru"]
Nobunaga-sama and I are both women. But with you, we can have ...... children.
[cpg cn=true]


[OnName num="keitarou"]
Do you do this to ...... everyone?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="sRanmaru003"]
[OnName num="ranmaru"]
I don't think so. No one knows about this.
[cpg cn=true]



;//ブラックアウト

;//========================================
;//●ＣＧ（立っているヒロイン。目を閉じてキスを待つ）ev_14
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="sRanmaru004"]
[OnName num="ranmaru"]
I'm still a bit of a slut.
[cpg cn=true]


I wonder about ....... Certainly a bit more aggressive than normal?
[cpg]

[OnName num="keitarou"]
Even if that were true, I think Ranmaru-sama is a lovely person.
[cpg cn=true]



[VOICE f="Ranmaru168"]
[OnName num="ranmaru"]
You say that again,...... that kind of thing."
[cpg cn=true]


;**【ＣＧ】 ev_14_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1000]


She said that, closing her eyes and waiting for a kiss.
[cpg]

I couldn't leave it at that, so I brought my lips together.
[cpg]


[VOICE f="sRanmaru005"]
[OnName num="ranmaru"]
I'm going to ......"
[cpg cn=true]



;//移植前シーンカット

;//ブラックアウト

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


After that, Ranmaru-sama and I talked about the future.
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru169"]
[OnName num="ranmaru"]
I'm sure we're going to be busier than ever.
[cpg cn=true]


[OnName num="keitarou"]
I'm sure we will. I don't know anything about politics.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru170"]
[OnName num="ranmaru"]
Keitaro should learn a little bit more. Nobunaga-sama would like that.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
While we were talking, I saw Nobunaga-sama in the distance.
[cpg]

[FACE method="shake_6" pos="2/3"]
Ranmaru-sama's face turns red. He still likes her.
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="4/5" time=800]

[VOICE f="Nobunaga593"]
[OnName num="nobunaga"]
He was still in love with her. I hear you two are getting along well these days."
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]

[VOICE f="Ranmaru171"]
[OnName num="ranmaru"]
I'm the only one who has a relationship with Nobunaga-sama.　I am devoted to Nobunaga-sama.
[cpg cn=true]



[FACE method="bow_2" pos="2/5"]
Nobunaga-sama laughed. I guess he takes it for granted that she likes him.
[cpg]

I think about it. I served Nobunaga-sama, but in the end I did not stand on the battlefield.
[cpg]

If it is not myself who is favored by Nobunaga, then it is Ranmaru who is standing on the battlefield.
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga594"]
[OnName num="nobunaga"]
I'm going to need you guys to do a lot of work from now on. I ask for your cooperation.
[cpg cn=true]

[free time=1000]
Nobunaga-sama left after saying, "Nobunaga-sama, thank you again today.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Ranmaru172"]
[OnName num="ranmaru"]
Nobunaga-sama, you look beautiful today. ......
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


I thought for a moment and fell silent.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru173"]
[OnName num="ranmaru"]
What the hell? What do you mean by that face?"
[cpg cn=true]


[OnName num="keitarou"]
How does Ranmaru-sama view Nobunaga-sama?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru174"]
[OnName num="ranmaru"]
I like him more than I can ...... say. I'm not even going to say it out loud.
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

Then night. Mitsuhide-sama was visiting my room.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide043"]
[OnName num="mitsuhide"]
Keitaro-san. Are you about to go to bed?"
[cpg cn=true]


[OnName num="keitarou"]
No,......, a little bit is fine.
[cpg cn=true]


[STOPBGM]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

Mitsuhide-sama approached me and whispered in my ear.
[cpg]

[BGM f="bg_08"]


[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide044"]
[OnName num="mitsuhide"]
Lately, you've become more and more favored by Nobunaga-sama.
[cpg cn=true]


[OnName num="keitarou"]
Yes, well, ......
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide045"]
[OnName num="mitsuhide"]
Yes, well, ," he said, "I guess that means you have a promising future. You may become a big shot in the future.
[cpg cn=true]


He said that and came closer to me. Trying to get in close ......
[cpg]

I don't think her words and actions are connected, but I guess they are consistent in her mind.
[cpg]

Mitsuhide-sama is trying to get me, who is valued by Nobunaga-sama, on her side.
[cpg]

[OnName num="keitarou"]
No, please don't."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Mituhide046"]
[OnName num="mitsuhide"]
Why do you refuse?"
[cpg cn=true]


[OnName num="keitarou"]
You have to do this kind of thing only with someone you really like."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

Mitsuhide-sama looked a little disappointed after hearing my words.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


He backed down right away as it was, and this time when I tried to go to sleep, he said ......
[cpg]

[OnName num="nobunaga_vassal"]
Keitaro-sama. May I have a moment?"
[cpg cn=true]


[OnName num="keitarou"]
What is it, ......?　I'm already sleepy.
[cpg cn=true]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga595"]
[OnName num="nobunaga"]
What is it?　I'm already sleepy.
[cpg cn=true]


[OnName num="keitarou"]
Yes,...... I am too.
[cpg cn=true]


Nobunaga-sama's retainer had arranged for me to be taken to Nobunaga-sama's room.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga596"]
[OnName num="nobunaga"]
What do you mean? You came to me, didn't you?"
[cpg cn=true]


[OnName num="keitarou"]
'Yes, but ...... that ...... vassal said you are seeking the heir to the Oda family.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="sNobunaga020"]
[OnName num="nobunaga"]
"You are the one who came to me with this offer?　You're too heavy a burden.
[cpg cn=true]


I certainly think so, but I feel shameful when I hear it from Nobunaga-sama.
[cpg]

[OnName num="keitarou"]
But ...... I have someone else I love.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga598"]
[OnName num="nobunaga"]
I'm sure you mean Ranmaru. Then you can go back to your room like this.
[cpg cn=true]


[OnName num="keitarou"]
I say so, but if you go home now, what will the vassals say ......?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga599"]
[OnName num="nobunaga"]
I see. I'm not going to lend you the bedding, but I'm sure you'll be fine.　I can't lend you a futon.
[cpg cn=true]


[OnName num="keitarou"]
...... I will.
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


He did not sleep on the same futon as Nobunaga-sama and spent the night on the tatami mats.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（朝）******************************************************

I woke up in the morning and realized. It's kind of a harem-like situation.
[cpg]

It is a dreamy situation, being sought after by three people.
[cpg]

I was in a position where I was in control of the world behind the scenes. I was not in the least bit happy about it.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga600"]
[OnName num="nobunaga"]
Good morning, Keitaro. Keitaro, did you sleep well?
[cpg cn=true]


[OnName num="keitarou"]
Yes, well, my ...... body aches.
[cpg cn=true]



;//ブラックアウト

[window target=false]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の廊下』（朝）******************************************************

I went out into the corridor and walked with Nobunaga-sama.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga601"]
[OnName num="nobunaga"]
It's another beautiful day, isn't it?
[cpg cn=true]


[OnName num="keitarou"]
Yes, really.
[cpg cn=true]


Hopefully, we can talk about these other things all the time.
[cpg]

Nobunaga-sama will die in the Honnoji Incident if things continue as they are.
[cpg]

I have no choice but to do something about it, considering how Ranmaru-sama feels at that moment.
[cpg]

I have to avoid changing the future as much as possible, but I can't help it.
[cpg]

The only way to avert Nobunaga-sama's death is to tell Mitsuhide-sama of his betrayal.
[cpg]

[OnName num="keitarou"]
Nobunaga-sama. Tell Mitsuhide-sama: ......"
[cpg cn=true]

[STOPBGM]

Just as I was about to say, "Be careful," something happened to my body.
[cpg]


[transition target={true} rule="moya.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1000]

[BGM f="bg_08"]

[FACE method="shock_5" pos="2/3"]
My figure became translucent. My skin became translucent, and Nobunaga-sama was startled at the sight of me.
[cpg]

When I said nothing more, the figure returned to normal.
[cpg]

[OnName num="keitarou"]
Now that was ......."
[cpg cn=true]


After all, it seemed that if I changed the future here, it would be a future in which I would not be born.
[cpg]

So I, coming from the future, would disappear.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga602"]
[OnName num="nobunaga"]
What kind of magic trick is that?　Is that also a technology of the future?
[cpg cn=true]


Nobunaga-sama says so, but I think he is really aware of it.
[cpg]

I'm about to get what I deserve for trying to change history.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

[SE f=se014]
;//【ＳＥ】『地面歩く』

I step away from the castle for a moment and think about the future.
[cpg]

I don't think I can change the future where Nobunaga-sama commits suicide in the Honnoji Incident.
[cpg]

If I change it, I don't know what will happen to me, who is supposed to be from the future. In fact, a phenomenon occurred where my body became transparent.
[cpg]

But what about Ranmaru-sama?
[cpg]

I remembered that Ranmaru-sama was there at the time of the Honnoji Incident, and that he had died in battle.
[cpg]

Saving Nobunaga-sama was different from saving Ranmaru-sama.
[cpg]

The future would not be much different for rescuing Ranmaru-sama.
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

I went back inside and found Ranmaru-sama waiting for me in my room.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru175"]
[OnName num="ranmaru"]
Where have you been? I've been waiting for you.
[cpg cn=true]


[OnName num="keitarou"]
Excuse me, ......, can I help you?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
Ranmaru-sama is fidgeting. She looks at me and wants to say something.
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（主人公に迫るヒロイン。服を着ているように修正してください）ev_36
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


And then Ranmaru-sama comes at me.
[cpg]


[VOICE f="Ranmaru176"]
[OnName num="ranmaru"]
You know what? I'm crazy after all.
[cpg cn=true]



[VOICE f="sRanmaru006"]
[OnName num="ranmaru"]
When I think of Keitaro, I can't help myself.
[cpg cn=true]


[OnName num="keitarou"]
I see.
[cpg cn=true]


But she still probably still loves Nobunaga-sama.
[cpg]


[VOICE f="Ranmaru178"]
[OnName num="ranmaru"]
I wonder what I should do. At a time like this, I'm sick and tired of being so confused by love and romance.
[cpg cn=true]


[OnName num="keitarou"]
Everyone is like that. I'm always thinking about Ranmaru-sama, too.
[cpg cn=true]



[VOICE f="Ranmaru179"]
[OnName num="ranmaru"]
......I wonder if everyone is turned on by color. I guess it's not just me.
[cpg cn=true]


We exchanged kisses once more for I don't know how many times.
[cpg]


;//移植前シーンカット

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

Even if you spend a happy moment with her, your heart will never be at peace.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru202"]
[OnName num="ranmaru"]
What's wrong?　Keitaro. You look strange.
[cpg cn=true]


[OnName num="keitarou"]
No, nothing. ......
[cpg cn=true]


The correct future is the one in which Ranmaru-sama was defeated and killed. That means ......
[cpg]

The fact that Ranmaru-sama was going to live meant that he could not be involved in history to any greater extent.
[cpg]

As I thought about it, I wondered if I should tell Ranmaru-sama.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

While we were wringing our hands, the incident that would kill Nobunaga-sama and Ranmaru-sama, the Honnoji Incident, was surely approaching every minute.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

I felt as if I couldn't sleep at night.
[cpg]

Unable to sleep, I take a walk around the castle. Then ......
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Mituhide047"]
[OnName num="mitsuhide"]
What's the matter? You are taking a walk at this hour?
[cpg cn=true]


[OnName num="keitarou"]
No, I just couldn't sleep.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide048"]
[OnName num="mitsuhide"]
I see. I'm like you.
[cpg cn=true]


Mitsuhide. This man will kill Ranmaru-sama and Nobunaga-sama.
[cpg]

Then, is it better to dissuade Mitsuhide-sama?
[cpg]

No, it is not. That would be the same as me telling them of a future of betrayal.
[cpg]

These women may not have acted according to the historical facts so far, but on a different level, the future will be different.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide049"]
[OnName num="mitsuhide"]
'Look at it. The moon is that beautiful."
[cpg cn=true]


[OnName num="keitarou"]
'...... it's true.'
[cpg cn=true]


Mitsuhide-sama never revealed his true nature in front of me. The moon is beautiful, he says, literally mooning.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『街』（昼）******************************************************

And one day. One day, Ranmaru-sama and I were out in the castle town.
[cpg]


;//下記のセリフ、台本では「街」ですがシナリオでは「町」になっています

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru203"]
[OnName num="ranmaru"]
It's nice to see the townspeople being so peaceful. I've never seen anything like it before."
[cpg cn=true]


[OnName num="keitarou"]
'Yes. ...... the world of warfare is about to come to an end.
[cpg cn=true]


But I knew I wasn't done yet.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru204"]
[OnName num="ranmaru"]
You know, some people didn't love the people they loved because of the war. Some may have been torn apart.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru205"]
[OnName num="ranmaru"]
If those people can live honestly, I can't wish for anything more.
[cpg cn=true]


Ranmaru-sama says things that make me sad. Knowing what she was going to do, I couldn't help but feel sorry for her.
[cpg]

[OnName num="keitarou"]
......　Ranmaru-sama. You should cherish your time with Nobunaga-sama.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru206"]
[OnName num="ranmaru"]
'......?　What do you mean by that?
[cpg cn=true]


[OnName num="keitarou"]
I mean it as it is. I know what's going to happen.
[cpg cn=true]


Ranmaru-sama seemed not to be able to guess yet.
[cpg]

[OnName num="keitarou"]
If you like Nobunaga-sama, you'd better say it out loud.
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Ranmaru207"]
[OnName num="ranmaru"]
What do you mean by that?
[cpg cn=true]


I can't do this. I had no choice but to push Ranmaru-sama's back.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夕方）******************************************************

I had to take her back to the castle.
[cpg]


;//下記のセリフ、台本では「街」ですがシナリオでは「町」になっています

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru208"]
[OnName num="ranmaru"]
What's going on all of a sudden? I haven't even seen the town properly yet.
[cpg cn=true]


[OnName num="keitarou"]
I have more important things to do.
[cpg cn=true]


[OnName num="keitarou"]
I know you love Nobunaga-sama. Then there is no time for hesitation or shyness.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru209"]
[OnName num="ranmaru"]
What do you mean we don't have time? Nobunaga-sama has taken over the country, and it seems unlikely that there will be any more battles."
[cpg cn=true]


;//ブラックアウト
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

We both headed to Nobunaga-sama's room. She still didn't understand what I was saying.
[cpg]

[OnName num="keitarou"]
She still didn't understand what I was saying. Please tell Nobunaga-sama how you feel."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="sRanmaru007"]
[OnName num="ranmaru"]
Why, suddenly ......?"
[cpg cn=true]


I rushed her somewhat forcefully.
[cpg]


[window target=false]
[STOPBGM]
[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/5" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="4/5" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

[SE f=se025]
;//【ＳＥ】『ふすま開く』

[FACE method="change_7" pos="2/5"]

[VOICE f="Nobunaga603"]
[OnName num="nobunaga"]
What? You two together.
[cpg cn=true]


[OnName num="keitarou"]
Ranmaru-sama has something to tell you.
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]

[VOICE f="Ranmaru211"]
[OnName num="ranmaru"]
Wait, wait, ...... why does it have to be now?
[cpg cn=true]


I can't explain everything to Ranmaru-sama. He will not understand if I tell him that the time limit is already approaching.
[cpg]

If he did understand, it might be time to change the future.
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Nobunaga604"]
[OnName num="nobunaga"]
What is it?　What is it that you want to tell me?
[cpg cn=true]


Nobunaga-sama looked at Ranmaru-sama. Ranmaru-sama straightened his back.
[cpg]

[FACE method="change_6" pos="4/5"]

[VOICE f="Ranmaru212"]
[OnName num="ranmaru"]
Oh, let's see......... Nobunaga-sama. Thank you for having me by your side all this time.
[cpg cn=true]


[FACE method="shake_4" pos="2/5"]

[VOICE f="Nobunaga605"]
[OnName num="nobunaga"]
What do you want to say? What do you want?
[cpg cn=true]


[OnName num="keitarou"]
"...... Ranmaru-sama. I'm not a fan.
[cpg cn=true]


I'm going to give Ranmaru-sama a boost. Ranmaru-sama is trying to convey his pent up feelings ......
[cpg]

But the last words didn't come out.
[cpg]

[FACE method="shock_4" pos="4/5"]

[VOICE f="Ranmaru213"]
[OnName num="ranmaru"]
I'm ...... thinking of Nobunaga-sama.
[cpg cn=true]

[FACE method="change_4" pos="4/5"]

[OnName num="keitarou"]
......"
[cpg cn=true]


A long silence. It was Nobunaga-sama who broke it.
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga606"]
[OnName num="nobunaga"]
"Are you trying to say that you like me?"
[cpg cn=true]


[FACE method="shock_4" pos="4/5"]

[VOICE f="Ranmaru214"]
[OnName num="ranmaru"]
No!　No, I'm afraid not.
[cpg cn=true]


Ranmaru-sama was ahead of me and hurriedly corrected me. But
[cpg]

[FACE method="shake_6" pos="2/5"]

[VOICE f="sNobunaga021"]
[OnName num="nobunaga"]
I am aware of that much. Who do you think I am?"
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]

[VOICE f="Ranmaru215"]
[OnName num="ranmaru"]
"Nah. ......."
[cpg cn=true]


Ranmaru-sama turned red. It seemed that he had long been aware of this.
[cpg]

[FACE method="change_6" pos="2/5"]

[VOICE f="Nobunaga608"]
[OnName num="nobunaga"]
I can't pretend to be oblivious any more. I want to respond to your feelings, too.
[cpg cn=true]


The Nobunaga-sama seemed to be receptive to the idea.
[cpg]

[FACE method="change_2" pos="4/5"]
I was glad to see Ranmaru-sama's face light up.
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Nobunaga609"]
[OnName num="nobunaga"]
'But what's with the sudden willingness to confess?
[cpg cn=true]


[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru216"]
[OnName num="ranmaru"]
'Keitaro said something I didn't understand, like he didn't have much time. ......
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
Nobunaga-sama said, "Hm," and thought about it.
[cpg]

Naturally, I couldn't tell her everything.
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga610"]
[OnName num="nobunaga"]
So?　What do you want?　What do you want?
[cpg cn=true]


[FACE method="shock_4" pos="4/5"]
Nobunaga-sama said that and Ranmaru-sama reacted with a startle.
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru217"]
[OnName num="ranmaru"]
I wish I could stay by Nobunaga-sama's side. ......
[cpg cn=true]


[OnName num="keitarou"]
Then it would be the same as before.
[cpg cn=true]


Nobunaga-sama nodded in agreement.
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="sNobunaga022"]
[OnName num="nobunaga"]
You have served me well over the years. I'd like to give you what you want at least for now.
[cpg cn=true]


Ranmaru-sama's face turned red as if he wanted to say something.
[cpg]

[FACE method="change_6" pos="4/5"]

[VOICE f="Ranmaru218"]
[OnName num="ranmaru"]
Well, then ...... that .......
[cpg cn=true]


She walked up to Nobunaga-sama. I may have already interrupted you.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I decided to leave the room. I don't think I'm going to get in between the two of them.
[cpg]

I guess I can at least take a quick peek at .......
[cpg]

I could say that I fulfilled Ranmaru-sama's wish,......, but I still don't want to do it.
[cpg]


;//移植前シーンカット

;//ブラックアウト
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（朝）******************************************************

And later on. Nobunaga-sama asked me something like this.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga643"]
[OnName num="nobunaga"]
Why did you send Ranmaru to me?
[cpg cn=true]


[OnName num="keitarou"]
What do you mean by "why?" ......
[cpg cn=true]


I can't tell you the truth. I thought I was.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga644"]
[OnName num="nobunaga"]
I can't tell you the truth. If so, please tell me.
[cpg cn=true]


Nobunaga-sama was, as expected, extremely sharp. He could see through most of what I was thinking.
[cpg]

[OnName num="keitarou"]
No, nothing. Nothing.
[cpg cn=true]


I lied rather than cheat. But
[cpg]

[FACE method="shake_7" pos="2/3"]

[VOICE f="Nobunaga645"]
[OnName num="nobunaga"]
"You can't tell me. Surely, if I don't die when I'm supposed to die, it might be a future in which you're not born."
[cpg cn=true]


Really, you see it all. ...... I wonder how perceptive Nobunaga-sama is.
[cpg]


;//ブラックアウト

[window target=false]

[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

I go back to my work with an unquiet mind.
[cpg]

Today, I had a vassal teach me about politics.
[cpg]

I may be in charge one day, she says......
[cpg]


[window target=false]
[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

I knew that future would never come.
[cpg]

Nobunaga-sama would commit suicide in the Honnoji Incident. If so, a peaceful world is still a long way off.
[cpg]

If that is the case, what I should learn is not politics, but how to survive in the present.
[cpg]


;//ブラックアウト

Even if I thought so, there is no one who can teach me how to do so.
[cpg]

I had no choice but to figure out how to get around on my own.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

At any rate, it was Ranmaru-sama. I had to rescue Ranmaru-sama alone.
[cpg]

I wanted to do so out of pure love, and also out of consideration for the future.
[cpg]

I was thinking about the future.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Nobunaga646"]
[OnName num="nobunaga"]
What's the matter? Are you thinking about something?
[cpg cn=true]


[OnName num="keitarou"]
No, no.
[cpg cn=true]


Between these two, Nobunaga-sama and Ranmaru-sama were getting closer. And that's not all.
[cpg]

[FACE method="change_6" pos="4/5"]

[VOICE f="Ranmaru247"]
[OnName num="ranmaru"]
Thank you, Keitaro. I couldn't find the courage for a long time.
[cpg cn=true]


Ranmaru-sama seemed to be grateful to me, and the distance between me and Ranmaru-sama was also growing closer.
[cpg]

[OnName num="keitarou"]
The best way to do this is to get a good, clean, and healthy diet. While you're at it,......."
[cpg cn=true]


I inadvertently let my words slip a little.
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru248"]
[OnName num="ranmaru"]
'...... what do you mean by "while you're at it?"
[cpg cn=true]


[FACE method="change_1" pos="2/5"]

[VOICE f="sNobunaga023"]
[OnName num="nobunaga"]
I suppose you mean, 'while the night is still young.'
[cpg cn=true]


Nobunaga-sama cheated me, but it was a close call.
[cpg]


;//移植前シーンカット

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I knew how my or Ranmaru-sama's love ended.
[cpg]

I could not change the future. I already knew that I would disappear. ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

Ranmaru-sama is still unaware of the truth.
[cpg]

I can't tell her. It's too cruel a fact for her.
[cpg]

As I walked along thinking, I met Mitsuhide-sama.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide050"]
[OnName num="mitsuhide"]
He seems to be very interested in Ranmaru these days.
[cpg cn=true]


Mitsuhide-sama. I wonder if she is the one who is supposed to be in this castle.
[cpg]

She could have been in another castle. I don't know much about what the historical facts were, but ......
[cpg]

Somehow I got the feeling that her being here was a choice left to me.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Mituhide051"]
[OnName num="mitsuhide"]
'Hello?　Can you hear me?"
[cpg cn=true]


[OnName num="keitarou"]
'Oh, uh, ...... what was that?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide052"]
[OnName num="mitsuhide"]
You're so out of your mind. Do you like Ranmaru that much?
[cpg cn=true]


[OnName num="keitarou"]
"...... yeah."
[cpg cn=true]


I even hated Mitsuhide-sama.
[cpg]

 I can't help thinking without her.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_09"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

There are many things to consider. We have no choice but to rescue Ranmaru-sama, but......
[cpg]

But will that keep me from disappearing? I don't know yet.
[cpg]

And then there is the question of how I will spend the rest of my life with Ranmaru-sama.
[cpg]


[VOICE f="Ranmaru259"]
[OnName num="ranmaru"]
Keitaro. Are you there?
[cpg cn=true]


[OnName num="keitarou"]
Yes. Can I help you?
[cpg cn=true]


[SE f=se025]
;//【ＳＥ】『ふすま開く』
[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]


Ranmaru-sama came into the room. He blushed a little and said, "I'm here to see you.
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru260"]
[OnName num="ranmaru"]
Thank you for that .......
[cpg cn=true]


[OnName num="keitarou"]
What is it?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru261"]
[OnName num="ranmaru"]
I'm happier than I've ever been. Keitaro arranged everything for me.
[cpg cn=true]


...... Ranmaru-sama still doesn't seem to have realized the truth.
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="sRanmaru008"]
[OnName num="ranmaru"]
So,......, I want to thank him."
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
Saying that, he comes closer to me.
[cpg]

[OnName num="keitarou"]
　You're coming up to me.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru263"]
[OnName num="ranmaru"]
There's no reason why it shouldn't be. I can't thank you enough.
[cpg cn=true]


Originally, they were similar. He adored Nobunaga-sama and worked hard to help her take over the country.
[cpg]

;//ブラックアウト
;//移植前シーンカット
;//【ＢＧ】『城＿室内』（昼）

Ranmaru-sama probably believes ...... that the situation will continue as it is.
[cpg]

But the reality is that Nobunaga-sama will not live long.
[cpg]


;//ブラックアウト

And Ranmaru-sama must have sensed why I was looking so down.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru286"]
[OnName num="ranmaru"]
...... Hey. What's going to happen to Nobunaga-sama?
[cpg cn=true]


Ranmaru-sama, sensing my attitude, asked me that.
[cpg]

I was at a loss for a response, but I told what I could.
[cpg]

[OnName num="keitarou"]
I can't tell you everything. I can't tell you everything, because it will probably be in a future where I wasn't born.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru287"]
[OnName num="ranmaru"]
I had an inkling. You are from the future, aren't you?
[cpg cn=true]


Ranmaru-sama seems to be aware of the situation quite deeply.
[cpg]

I was frustrated that I couldn't tell them all the information for my own protection.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru288"]
[OnName num="ranmaru"]
I knew someone was going to betray me. Or was it an accident?"
[cpg cn=true]


[OnName num="keitarou"]
I can't ...... tell you."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru289"]
[OnName num="ranmaru"]
I guess that means I can't tell you what's in store for you.
[cpg cn=true]


And Nobunaga-sama is smarter than Ranmaru-sama. She might have noticed it earlier.
[cpg]

I was feeling sorry for myself for not being able to do anything about it.
[cpg]

[OnName num="keitarou"]
I'm sorry. I can't do anything about it.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru290"]
[OnName num="ranmaru"]
Don't apologize. It's not your fault.
[cpg cn=true]



[SE f=se024]
;//【ＳＥ】『通路歩く』

We both fell silent. Then footsteps approached us.
[cpg]


[free time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]


[VOICE f="Mituhide053"]
[OnName num="mitsuhide"]
What's the matter, you look so mysterious.
[cpg cn=true]


Mitsuhide-sama came over to talk to us. Ranmaru-sama replied, oblivious to what was about to happen.
[cpg]

[FACE method="bow_7" pos="4/5"]

[VOICE f="Ranmaru291"]
[OnName num="ranmaru"]
'Ah, Mitsuhide. Mitsuhide or ...... you too, what are you doing here at this hour?"
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Mituhide054"]
[OnName num="mitsuhide"]
'Don't worry about me. The two of you were looking amazing.
[cpg cn=true]


[OnName num="keitarou"]
"......."
[cpg cn=true]


I couldn't help but think nothing of her.
[cpg]

I hate Mitsuhide-sama, but I can't do anything about her.
[cpg]

Even if you were to convert her, it would be the same as telling her in advance.
[cpg]

;//＠いずれにせよ信長様が長らく国を治めることになり、未来が変わる。
In any case, Nobunaga-sama will rule the country for a long time and the future will change.
[cpg]

[FACE method="change_6" pos="2/5"]

[VOICE f="Mituhide055"]
[OnName num="mitsuhide"]
Don't look scared," he said. Your eyes look as if you are looking at the avenger of someone you care about.
[cpg cn=true]


That's not wrong. Or rather, that's exactly what it is.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Nobunaga-sama is now a man of the world. Even if we can't rescue her, maybe we can at least rescue Ranmaru-sama.
[cpg]

But rescuing Nobunaga-sama would be impossible by any means. That would be a major change in history.
[cpg]

It would also be difficult for Nobunaga-sama to survive as a normal person somewhere because of his character.
[cpg]

But what about Ranmaru-sama?
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

Today, I am spending all my time studying politics in order to become a future warlord.
[cpg]

Even if you think this is useless ......, you can't explain to anyone why it's useless.
[cpg]

I couldn't tell anyone that Nobunaga-sama's rule would be overturned.
[cpg]


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[OnName num="keitarou"]
'...... am tired today.
[cpg cn=true]


I don't have time for this. But what else should I do?
[cpg]

I just couldn't think of a way to keep Nobunaga-sama alive.
[cpg]

If that is the case, we must rescue Ranmaru-sama at least.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Ranmaru292"]
[OnName num="ranmaru"]
"Thanks for your hard work. It's not good to put down too many roots."
[cpg cn=true]


I wonder if that's how he looks at me. I don't give a damn about studying politics.
[cpg]

[OnName num="keitarou"]
"...... Ranmaru-sama."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru293"]
[OnName num="ranmaru"]
What's the matter, ......, with your mysterious face?
[cpg cn=true]


[OnName num="keitarou"]
I only want to make you happy. I can't seem to have it all.
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Ranmaru294"]
[OnName num="ranmaru"]
That's the story. Will there be a big event?
[cpg cn=true]


Even Ranmaru-sama looked a little sad face.
[cpg]

You must be feeling frustrated that you can't get the story out of me.
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="sRanmaru009"]
[OnName num="ranmaru"]
I'm going to forget about it for now. I don't want anything else as long as you're by my side.
[cpg cn=true]


[OnName num="keitarou"]
I don't think so. I think you like Nobunaga-sama too."
[cpg cn=true]


The Ranmaru-sama looks away. And then...
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru296"]
[OnName num="ranmaru"]
"Don't be mean to me," he said.
[cpg cn=true]


He just said. Yes, I guess this was an unnecessary thing to say. ......
[cpg]


;//ブラックアウト


I guess Ranmaru-sama thinks that both me and Nobunaga-sama are important.
[cpg]

I still think it wasn't a mistake to encourage Ranmaru-sama's confession.
[cpg]

It would have been too cruel for us to die and part before we could be united.
[cpg]

;//移植前シーンカット
;//【ＢＧ】『城＿室内』（夜）
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

I was once again confirming my inner feelings.
[cpg]

I just want to save her. That's all.
[cpg]


[FO pos="4/7" time=1000]
[WAIT time=1100]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru318"]
[OnName num="ranmaru"]
I want to be your wife. I want to spend the rest of my life with you. ......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru319"]
[OnName num="ranmaru"]
I wonder if I'm dead too, in your knowledge.
[cpg cn=true]


If I nodded my head, I would really be dead.
[cpg]

I had no choice but to deny it. I had made up my mind that she was the only one I would let live.
[cpg]

[OnName num="keitarou"]
No, I will rescue only Ranmaru-sama. 
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
Ranmaru-sama was smiling a little, but his eyes were sad.
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru320"]
[OnName num="ranmaru"]
I wish ...... days like this could go on forever."
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
The words seemed to come from the bottom of my heart. I hugged Ranmaru-sama again.
[cpg]



[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru321"]
[OnName num="ranmaru"]
'Stop it,...... if you hug me now, you'll make me want to cry.
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_09"]

;//【ＢＧ】『城＿室内』（朝）******************************************************

We both fell asleep, and when morning came,......, Ranmaru-sama said to me.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru344"]
[OnName num="ranmaru"]
'......Keitaro. This may not be the best time to say this, but ......
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru345"]
[OnName num="ranmaru"]
If you say we're running out of time, I have to tell you something. I want to say it now that I'm calm.
[cpg cn=true]


[OnName num="keitarou"]
"...... what is it?"
[cpg cn=true]


I had an inkling of what I was going to say.
[cpg]


;//下記のセリフ、台本では
;//「あんたと結婚したい。あたしの夫になってくれ……景太郎」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru346"]
[OnName num="ranmaru"]
'Be my husband,...... Keitaro.
[cpg cn=true]


I wondered if it was possible in ...... this time period for a woman to ask for a wife.
[cpg]

Or is it because she is still a warlord?
[cpg]

We will probably always be somewhat different.
[cpg]

If I were to become a warlord, I don't think I would be able to be as good as Ranmaru-sama right away.
[cpg]

That's why I'll be calling her by her title, and that's probably why she asked me to marry her. ......
[cpg]

[OnName num="keitarou"]
She said, "Thank you. Are you sure you want me?"
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="sRanmaru010"]
[OnName num="ranmaru"]
No, it's not. No, it has to be you.
[cpg cn=true]



;//ブラックアウト

And I became Ranmaru-sama's husband.
[cpg]

While retaining his love for Nobunaga-sama, Ranmaru-sama had decided to become my wife.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

;//下記のセリフ、台本では
;//「めでたいことだな。蘭丸がついに結婚することになるとは」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="3/3" time=800]


[VOICE f="Nobunaga660"]
[OnName num="nobunaga"]
That's a happy thing, isn't it?
[cpg cn=true]



[FACE method="bow_1" pos="3/3"]

[VOICE f="Mituhide056"]
[OnName num="mitsuhide"]
Yes, really. Ranmaru was devoted to Nobunaga-sama, so I thought he would remain single for a long time.
[cpg cn=true]


Nobunaga-sama congratulated Ranmaru-sama honestly.
[cpg]

But Mitsuhide-sama is being a bit sarcastic.
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru348"]
[OnName num="ranmaru"]
Oh, Mitsuhide, I'm so happy to see him happy before you. Mitsuhide, I made you happy before you did.
[cpg cn=true]


Ranmaru-sama replied, puffing out his chest. Mitsuhide-sama shrugged his shoulders.
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru349"]
[OnName num="ranmaru"]
I've got something to tell you, Keitaro. There's something I need to tell you.
[cpg cn=true]


[OnName num="keitarou"]
What is it?
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
I think I'm having a baby," Ranmaru said in a small voice. I think I'm having a baby," Ranmaru-sama said in a quiet voice.
[cpg]

[FACE method="change_5" pos="1/3"]

Nobunaga-sama was surprised for a moment and then smiled.
[cpg]

[FACE method="bow_2" pos="1/3"]

[VOICE f="Nobunaga661"]
[OnName num="nobunaga"]
I see. Good for you, you're going to be a mother."
[cpg cn=true]


She seemed as pleased as if it were her own.
[cpg]

Nobunaga-sama's blessing must have made Ranmaru-sama feel dreamy.
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Ranmaru351"]
[OnName num="ranmaru"]
She smiled, "Yes, I am. I will raise her as if she were Nobunaga-sama's child.
[cpg cn=true]


[OnName num="keitarou"]
Well, isn't that a bit ...... excessive?
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru352"]
[OnName num="ranmaru"]
That means you're going to be a father, too, Keitaro. Do you feel it?
[cpg cn=true]


[OnName num="keitarou"]
No,...... not yet, not really.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru353"]
[OnName num="ranmaru"]
I'm sure you're right. I don't feel it yet either.
[cpg cn=true]


[OnName num="keitarou"]
But then again, I never thought you would say you were Nobunaga-sama's child.
[cpg cn=true]


With a slight laugh, Ranmaru-sama replies.
[cpg]

[FACE method="shake_2" pos="2/3"]

[VOICE f="Ranmaru354"]
[OnName num="ranmaru"]
It's a feeling, that's how I feel.Of course I love you, too.
[cpg cn=true]


Of course I do. Even though I know it, I feel embarrassed when it is said in words.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

The time I spent with Ranmaru-sama was like sand spilling from my hand.
[cpg]

Four months passed since she was pregnant. Her belly swelled.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

The Honnoji Incident. I do not know how long it would take for that to happen after Nobunaga-sama took over the country.
[cpg]

But if Ranmaru-sama's life was in danger, I couldn't just sit around wondering.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru355"]
[OnName num="ranmaru"]
......You look like you're thinking about something.
[cpg cn=true]


[OnName num="keitarou"]
No, nothing.
[cpg cn=true]


;//移植前シーンカット

I have to rescue her from the rebellion.
[cpg]

That is something we will definitely have to talk about someday.
[cpg]

[OnName num="keitarou"]
Ranmaru-sama. May I have a moment?
[cpg cn=true]


I said in a serious tone of voice, and Ranmaru-sama became a little nervous.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru380"]
[OnName num="ranmaru"]
What is it? 
[cpg cn=true]


[OnName num="keitarou"]
I'm talking about what's going to happen at .......
[cpg cn=true]


[OnName num="keitarou"]
The incident in which Nobunaga-sama will die will happen from now on. You are going to be involved in it.
[cpg cn=true]


 Ranmaru-sama already knows this.
[cpg]

Still, I couldn't help but speak up.
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Ranmaru381"]
[OnName num="ranmaru"]
"So you're saying you're going to save me?
[cpg cn=true]


[OnName num="keitarou"]
Yes. History doesn't change much, we just survive ...... I'm going to do that, but do you want to, Ranmaru-sama?"
[cpg cn=true]


Ranmaru-sama was calm and collected, not even on the verge of tears.
[cpg]

It's not that she hasn't thought about it. In fact, she may have thought about it more than I did.
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru382"]
[OnName num="ranmaru"]
In the past I would have said differently.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru383"]
[OnName num="ranmaru"]
She probably would have said she would die with Nobunaga-sama. But now I want a happy future with you.
[cpg cn=true]


She seemed to have made up her mind.
[cpg]

I want to be happy. I don't know if such peace awaits me from now on, but I still ......
[cpg]

[OnName num="keitarou"]
I understand. I won't hesitate anymore.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Ranmaru384"]
[OnName num="ranmaru"]
"Ah. I'm sorry for all the trouble I've been going through.
[cpg cn=true]


[OnName num="keitarou"]
I'm not apologizing to you, Ranmaru-sama. That's my problem too.
[cpg cn=true]


At some point, I was on the verge of tears. Ranmaru-sama wiped my tears with his finger.
[cpg]

[FACE method="shake_2" pos="2/3"]

[VOICE f="Ranmaru385"]
[OnName num="ranmaru"]
I'm sure we'll be fine. We will be fine.
[cpg cn=true]


;//ブラックアウト

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[SE f=se024]
;//【ＳＥ】『通路歩く』

;//蘭丸と信長の立ち絵は表示しないでください

One day, I heard Ranmaru-sama and Nobunaga-sama talking.
[cpg]




[VOICE f="Ranmaru407"]
[OnName num="ranmaru"]
Nobunaga-sama,......, about the matter you mentioned."
[cpg cn=true]


I was in the room with the doctor, and I heard Ranmaru-sama's voice coming from the room. I listened.
[cpg]


[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="4/5" time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

[VOICE f="Ranmaru408"]
[OnName num="ranmaru"]
It seems that the time for parting is near. Has he told you?
[cpg cn=true]


[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga662"]
[OnName num="nobunaga"]
I haven't heard, but it's as if he's already told me. I have an idea.
[cpg cn=true]


Nobunaga-sama did not seem to be afraid of his own death.
[cpg]

I wondered how he could be in such a state of mind, but it seemed to be the truth.
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru409"]
[OnName num="ranmaru"]
I'm sorry, ....... I couldn't do anything for you.
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga663"]
[OnName num="nobunaga"]
Don't apologize. I didn't do anything wrong.
[cpg cn=true]


Ranmaru-sama is talking with Nobunaga-sama in tears.
[cpg]

[FACE method="change_2" pos="2/5"]

[VOICE f="Nobunaga664"]
[OnName num="nobunaga"]
It's been fun. Ranmaru, nothing can replace the days of ...... surviving this war with you so far.
[cpg cn=true]


[FACE method="shock_4" pos="4/5"]

[VOICE f="Ranmaru410"]
[OnName num="ranmaru"]
"......Me too,......Gusu,gusu."
[cpg cn=true]


Ranmaru was finally crying and seemed to be thinking that he didn't want to lose Nobunaga-sama after all.
[cpg]

I kept listening to them without getting in there.
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru411"]
[OnName num="ranmaru"]
Nobunaga-sama. What should I do?　I don't want to lose Keitaro or Nobunaga-sama.
[cpg cn=true]


There was a short pause. After that, he said.
[cpg]

[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga665"]
[OnName num="nobunaga"]
You are still weak. If you want to live with him alone, that is not good enough.
[cpg cn=true]


Nobunaga-sama said calmly.
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru412"]
[OnName num="ranmaru"]
I am weak. Without Nobunaga-sama, I still can't live.
[cpg cn=true]


I felt like I couldn't change the future, even though I couldn't stand it.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

The end is coming. A great change is coming.
[cpg]

The relationship between me and Ranmaru-sama will not stay the same.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru413"]
[OnName num="ranmaru"]
...... Nobunaga-sama is going to Honnoji Temple.
[cpg cn=true]


[OnName num="keitarou"]
I see. ......
[cpg cn=true]


I couldn't even say that Nobunaga-sama would be betrayed there. The actuality is, you can't just go to the store and buy a new one.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru414"]
[OnName num="ranmaru"]
Hey, Keitaro. Recently, Mitsuhide has been acting strangely. "Could it be..."
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


In historical fact, Ranmaru-sama was never aware of the rebellion.
[cpg]

So I think a lot of what I've been saying has had an effect.
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru415"]
[OnName num="ranmaru"]
If it weren't for you, I'd probably be dead too with nothing to show for it."
[cpg cn=true]


Still, Ranmaru-sama only said that.
[cpg]

It seems he is not going to help Nobunaga-sama. I guess he was thinking of me.
[cpg]

[OnName num="keitarou"]
I'll protect you, Ranmaru-sama. I will protect you.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Ranmaru416"]
[OnName num="ranmaru"]
Of course. If you don't say that, there's no point in my choosing you.
[cpg cn=true]


;//ブラックアウト
;//移植前シーンカット


The time of destiny was approaching.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

Not long after that.
[cpg]

Mitsuhide-sama's rebellion has been transmitted to the castle. And then ......
[cpg]

Nobunaga-sama committed suicide in the Honnoji Incident.
[cpg]

Ranmaru-sama was crying quietly. I'm sure he has already prepared himself for this, but he must still feel a strong sense of loss.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru441"]
[OnName num="ranmaru"]
How are we going to live from now on?
[cpg cn=true]


[OnName num="keitarou"]
If we are to live through the war, we should follow Hideyoshi or Ieyasu. ......
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]

[VOICE f="Ranmaru442"]
[OnName num="ranmaru"]
I wonder who killed Mitsuhide. Who killed Mitsuhide? Who did she fight, or will she take over?"
[cpg cn=true]


[OnName num="keitarou"]
No. He should have fought Hideyoshi and lost. No. He should have fought Hideyoshi and lost.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru443"]
[OnName num="ranmaru"]
Then ...... that's where we should turn to. Let's join them right away, we can't go against them on our own.
[cpg cn=true]


Ranmaru-sama was calmer than before. He was not distraught over the loss of Nobunaga-sama.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And we decided to join up with Hideyoshi.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

When we arrived at the castle, Ranmaru-sama told me something like this.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru444"]
[OnName num="ranmaru"]
I'm glad I chose you, even if it comes to this.
[cpg cn=true]


Ranmaru-sama's eyes were staring into the future. I can't be the only one left behind.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


The months passed by. I felt as if the days passed by slowly.
[cpg]

The day came after I avenged Nobunaga-sama.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[SE f=se000]
;//【ＳＥ】『赤ちゃんの泣き声』

Ranmaru-sama is nursing a baby with a smile on his face.
[cpg]

I became a father and Ranmaru-sama became a mother.
[cpg]

Everything cannot stay in one place.
[cpg]

Ranmaru-sama seemed to know that.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru445"]
[OnName num="ranmaru"]
When he grows up and falls in love.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru446"]
[OnName num="ranmaru"]
I don't want that kind of future where she might die and leave the person she's in love with."
[cpg cn=true]


[OnName num="keitarou"]
'......Yes. Yes, I do.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru447"]
[OnName num="ranmaru"]
I'll make it up as I go along. Mitsuhide was also avenged, but that's not the only reason why he had to be defeated.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru448"]
[OnName num="ranmaru"]
I want a future where all people can be honest in their love. What a ......"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru449"]
[OnName num="ranmaru"]
But if I say I just want peace, maybe that's all I want.
[cpg cn=true]


[OnName num="keitarou"]
No. I think it's an immutable truth. No. I think it is an immutable truth.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

She had a strong will. She was much stronger than I was.
[cpg]

The weak woman she was before she lost Nobunaga-sama is gone.
[cpg]


;//ブラックアウト


;//＠

;//ＥＮＤ　ヒロイン５ルート

[SCENE id=10]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="epend.ks" target="*start"]


