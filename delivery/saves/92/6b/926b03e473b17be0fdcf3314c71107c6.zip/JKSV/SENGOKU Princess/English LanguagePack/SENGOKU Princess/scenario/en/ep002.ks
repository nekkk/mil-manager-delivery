*start


;#################################################
*Ep002|Battle of Okehazama
;#################################################

[SCENE id=2]


[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]

[stflag Selectflg1=0]
[stflag Selectflg2=0]
[stflag Selectflg3=0]
[stflag Selectflg4=0]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

Time passed for a while and the days seemed peaceful and bleak.
[cpg]

I couldn't help but do nothing, but when I did things like chores, people around me stopped me.
[cpg]

I guess it was because I was the one whom Nobunaga-sama kept close by.
[cpg]

And it was common knowledge in those days that cooking and other chores were to be done by women. ......
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Nobunaga170"]
[OnName num="nobunaga"]
'Looks like you've got some free time. Keitaro."
[cpg cn=true]


[OnName num="keitarou"]
No,......, no,......
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]

[VOICE f="Ranmaru061"]
[OnName num="ranmaru"]
If you're not busy, I could give you some sword training.
[cpg cn=true]


Ranmaru-sama suggested. That was something I was rather grateful for.
[cpg]

[OnName num="keitarou"]
Yes, I am. I'm still confident in my swordsmanship.
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]

[VOICE f="Ranmaru062"]
[OnName num="ranmaru"]
I don't know how you can say such a thing in front of me.
[cpg cn=true]


Not knowing what it means, I look at Nobunaga-sama.
[cpg]

[FACE method="bow_2" pos="2/5"]

[VOICE f="Nobunaga171"]
[OnName num="nobunaga"]
Ranmaru is better with a spear, but he's also quite good with a sword.
[cpg cn=true]


[OnName num="keitarou"]
I see. I'm more than willing to do it then.
[cpg cn=true]


[FACE method="change_3" pos="4/5"]

[VOICE f="Ranmaru063"]
[OnName num="ranmaru"]
You say ......?"
[cpg cn=true]


Then we were asked to prepare for a hand-to-hand combat.
[cpg]

I was told that shinai (bamboo swords) existed even in this era. I had heard that shinai were very old.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru064"]
[OnName num="ranmaru"]
If you are so confident, you don't need protective gear.
[cpg cn=true]


[OnName num="keitarou"]
I can't take it easy on you. Is that okay with you?"
[cpg cn=true]



;//ブラックアウト

;//戦闘シーン　武器を振るうようなエフェクトなどつけられたらお願いします

;//========================================
;//●ＣＧ（紹介ページヒロイン５のＣＧ）ev_95
;//人物１：ヒロイン５　服装１：着衣
;//場所　：城＿外観
;//時間　：昼
;//備考　：可能であれば背景を足してください
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;**【ＣＧ】 ev_95_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]



[SE f=se028]
;//【ＳＥ】『竹刀打ち合う』

[BG f="white.ui" time=100]
[WAIT time=100]
;**【ＣＧ】 ev_95_0 ***********************
[CG id=2 index=0 time=100]
;***************************************
[WAIT time=100]

In this day and age, Nobunaga-sama would approve of my skill. I, on the other hand, am a kendo player like any other.
[cpg]

But there is a gap between eras. I thought it would be a good match, and when we struck each other ......
[cpg]


[VOICE f="Ranmaru065"]
[OnName num="ranmaru"]
"Ah!　Seya ah!"
[cpg cn=true]


Ranmaru-sama's tachiji was so straight. There are many preliminary movements.
[cpg]

I thought that the quality of kendo might have changed since it became more like a sport.
[cpg]

I suppose that kenjutsu that can be used in actual combat focuses on such things as the strength to swing a heavy sword.
[cpg]

Or is there simply a difference between men and women ...... as if there is no competition.
[cpg]


[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************


[VOICE f="Ranmaru066"]
[OnName num="ranmaru"]
Ha, ha, ha."
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


I didn't feel comfortable hitting a girl who wasn't wearing protective gear, so I was rustling the shinai for a while.
[cpg]

The first time I saw Ranmaru-sama about to run out of power, Nobunaga-sama was looking at me with interest.
[cpg]

[FACE method="bow_7" pos="2/5"]

[VOICE f="Nobunaga172"]
[OnName num="nobunaga"]
He looked at her with interest, "Lend me your ears for a moment. Keitaro."
[cpg cn=true]


[OnName num="keitarou"]
Yes, what is it, ......?"
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]

[VOICE f="Nobunaga173"]
[OnName num="nobunaga"]
'Do you not live in a more peaceful time than now? How can you handle a sword like this?
[cpg cn=true]


[OnName num="keitarou"]
"...... that's ......."
[cpg cn=true]


So there are things you can do because of the peaceful times?
[cpg]

[OnName num="keitarou"]
Even today, kendo is still a form of swordsmanship. I suppose you mean that it has evolved in its own way, assuming we don't use real swords.'
[cpg cn=true]

[FACE method="shake_4" pos="4/5"]
[FACE method="change_1" pos="2/5"]

Ranmaru-sama looks frustrated. Thinking about it, I shouldn't have done this to a girl opponent.
[cpg]

Nobunaga-sama looked impressed while thinking so. Overall, I guess it was a good thing that I had him hand-me-down.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

Time passed further like that.
[cpg]

I sometimes moved from one castle to another to accommodate Nobunaga-sama. I became somewhat accustomed to moving around.
[cpg]

We hear in the castle that he is finally about to unify Owari......
[cpg]

The names of places in this period don't really match the names of places in my time.
[cpg]

I heard that Iwakura Castle was the next target for Nobunaga-sama, but I don't even know who was there.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夕方）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Nobunaga174"]
[OnName num="nobunaga"]
He said, "From now on I intend to take over the country. I will finish the battle."
[cpg cn=true]


Ranmaru and I were summoned to Nobunaga-sama's room.
[cpg]

[FACE method="bow_2" pos="4/5"]

[VOICE f="Ranmaru067"]
[OnName num="ranmaru"]
Of course," said Ranmaru. I have no doubt that Nobunaga-sama will be the ruler of Japan.
[cpg cn=true]


Ranmaru-sama is, has been, and probably always will be single-minded about Nobunaga-sama.
[cpg]

[FACE method="shake_3" pos="2/5"]

[VOICE f="Nobunaga175"]
[OnName num="nobunaga"]
I don't know what lies beyond the unification of the world. I don't see peace coming anytime soon.
[cpg cn=true]


I have been wondering whether I should say this or not.
[cpg]

What kind of end will she face? ......
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

I'm sure that if left alone, Nobunaga-sama will commit suicide in the Honnoji Incident, as I know the history.
[cpg]

But am I allowed to change that?
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

I met Mitsuhide while I was still having mixed feelings about it.
[cpg]

[OnName num="keitarou"]
'Are you taking care of ...... the bonsai again?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide014"]
[OnName num="mitsuhide"]
Yes, I do. Do you want to try it too?
[cpg cn=true]


[OnName num="keitarou"]
No, I'm ......
[cpg cn=true]


In the midst of idle chitchat. Mitsuhide-sama suddenly changed the subject.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide015"]
[OnName num="mitsuhide"]
What do you think of Nobunaga-sama?
[cpg cn=true]


[OnName num="keitarou"]
Yes, ...... I would still say someone who is dependable."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Mituhide016"]
[OnName num="mitsuhide"]
I see. I am not good enough for you?
[cpg cn=true]


Her words, if taken in the normal sense, would mean, will you serve me?
[cpg]

But I know Mitsuhide-sama ambition. So I couldn't say anything.
[cpg]

[OnName num="keitarou"]
I only serve Nobunaga-sama for now at ...... least.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide017"]
[OnName num="mitsuhide"]
I like you. We smell the same.
[cpg cn=true]


[OnName num="keitarou"]
The same smell?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide018"]
[OnName num="mitsuhide"]
Yes, I do. In truth, aren't you tired of serving someone else?
[cpg cn=true]


Mitsuhide-sama is showing a glimpse of his ambition. Maybe he thinks I see through it all.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide019"]
[OnName num="mitsuhide"]
I would treat you as an equal. I would not think of you as my servant.
[cpg cn=true]


[OnName num="keitarou"]
What do you mean? Are you not loyal to Nobunaga-sama, Mitsuhide-sama?
[cpg cn=true]


When I asked Mitsuhide-sama, she laughed a little.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide020"]
[OnName num="mitsuhide"]
No way. No one has been more useful to Nobunaga-sama than I."
[cpg cn=true]


I cannot read her true intentions. I know she likes me, but ......
[cpg]

Maybe she wants me to follow her friends when she betrays me.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

I have to think about it. Even if it's the same as before: ......
[cpg]

It's not just about surviving this time.
[cpg]

It's about who and what we do. I can't help but be concerned about that.
[cpg]


[window target=false]
[BG f="b_07_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

It is not that I have so little time that I can't think about anything.
[cpg]

In fact, I have more than enough time. I have to think and think and think and come up with answers.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

Time passes, but it passes faster than time.
[cpg]

Much faster than the history I know. A general named Imagawa Yoshimoto and Nobunaga-sama came into conflict.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Mituhide021"]
[OnName num="mitsuhide"]
How many men will he lead?
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga176"]
[OnName num="nobunaga"]
He will not spare any of his men. It will be an all-out war.
[cpg cn=true]


The battle of Okehazama. I am not a history buff, but I knew about this battle.
[cpg]

I also remember that Nobunaga would win this battle. I clearly knew that there was no way we could lose this battle.
[cpg]

[FACE method="change_3" pos="2/5"]

[VOICE f="Nobunaga177"]
[OnName num="nobunaga"]
I'm going to surprise them. What do you think, Ranmaru?"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="4/5" time=800]

[VOICE f="Ranmaru068"]
[OnName num="ranmaru"]
"Surprise attack? ...... I think we should fight fair and square."
[cpg cn=true]


Nope. i wonder if that's the case...... As I recall, Okehazama is supposed to be one of the most famous raids in Japanese history.
[cpg]

It means that if you hit them head-on, you could lose.
[cpg]

[FACE method="change_3" pos="2/5"]

[VOICE f="Nobunaga178"]
[OnName num="nobunaga"]
What about Keitaro?　Do you have anything to say?
[cpg cn=true]


[OnName num="keitarou"]
"...... I think surprise attack is the way to go."
[cpg cn=true]


[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga179"]
[OnName num="nobunaga"]
I'm sure you would say that. You would say so.
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
Ranmaru-sama glared at me, but I had no choice.
[cpg]

Nobunaga-sama must know that I am from the future, and he must be listening to what I have to say.
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga180"]
[OnName num="nobunaga"]
What about you, Keitaro? You'll go into battle, won't you?
[cpg cn=true]


I thought about it. I think about it.
[cpg]

Nobunaga would have won the war without me in the first place. ......
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

He said he would not answer in front of Nobunaga-sama, but would stay alone with Mitsuhide-sama. ......
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide022"]
[OnName num="mitsuhide"]
He said, "You don't have to force yourself into battle, my dear. You are that important to me."
[cpg cn=true]


Mitsuhide-sama said. The choice is whether to follow Nobunaga-sama or Mitsuhide-sama.
[cpg]

What should I do? Who should I choose?
[cpg]


After all, I want to help ...... Nobunaga-sama. He was the first person to recognize me.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Mituhide023"]
[OnName num="mitsuhide"]
Keitaro-san?　Where are you going?"
[cpg cn=true]


I turn back the way I came and head back to Nobunaga-sama.
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga181"]
[OnName num="nobunaga"]
What's wrong?　Have you made up your mind?
[cpg cn=true]


[OnName num="keitarou"]
I turned back the way I came and headed back to Nobunaga-sama. Yes, I'm going with you. I want to help Nobunaga-sama.
[cpg cn=true]


Nobunaga-sama looked satisfied.
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga182"]
[OnName num="nobunaga"]
He looked satisfied and said, "That's very encouraging. I'm counting on you.
[cpg cn=true]


He said those words to me. I also felt happy.
[cpg]

Now that he had said this, there was no turning back.
[cpg]

As far as I know, this battle will settle everything.
[cpg]

Even if there are small battles in the future, the majority of battles will be settled at Okehazama.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

Nobunaga-sama was planning a surprise attack for the coming battle.
[cpg]

I would be the one to carry it out. It is an important role.
[cpg]

If I am not careful, I could die here.
[cpg]

But the fear must be felt more strongly by Nobunaga-sama.
[cpg]

Thinking about that, strangely enough, I was not afraid.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『戦場』（昼）******************************************************

The battle of Okehazama. I know that Nobunaga-sama won the battle by surprise.
[cpg]

As I recall, the difference in force was nearly ten times that of the other side. I'm sure the difference in force was close to ten times.
[cpg]

I wonder if we can win against such a large number of people. While I was worried about that, I still had a lot of ......
[cpg]

I only believed in Nobunaga-sama.
[cpg]



;//※ストーリーが分岐
;//　勝利した場合、ヒロイン１、ヒロイン５ルートへ
;//　敗北した場合、ヒロイン４ルートへ


;//伏兵は２、５、８に配置されています

;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※桶狭間の戦い　開始時（１のマスにいる場合のシナリオ）※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Mitsuhide-sama said she didn't want me to be forced to fight.
[cpg]

If I follow her advice, should I dare to consider withdrawing from the battle myself?
[cpg]

I guess it's a matter of which side you'd rather be on, Nobunaga-sama's or Mitsuhide-sama's.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（夜）******************************************************

;//ヒロイン１の立ち絵を表示してください

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]


Nobunaga-sama interjects. She said that in their march up to this point, Imagawa's army had often placed their ambush troops in a single line.
[cpg]

Of course, this may not be the case for all of them, but I had to keep that in mind.
[cpg]

I was prepared for this and continued on.
[cpg]


;//■選択肢
[switch]
[case "Proceeding to the south"]
	[swap]
	[jump target="*select03_4"]
[case "Go to the east"]
	[swap]
	[jump target="*select03_2"]
[endswitch]

1, going south
2, advance to the east


;//==============================
;//１、南へ進む

;//同じイベント中の「４のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「２のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※２のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_2|Battle of Okehazama


[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


Ahead of us, an ambush lurks. I boldly stand my ground.
[cpg]


[SE f=se019]
;//【ＳＥ】『つばぜり合い』

I defeat all the ambushers, but I cannot let my guard down. If we run into them again, we will be in danger.
[cpg]

We proceed with caution. ......
[cpg]

[stflag Selectflg3=1]


;//■選択肢
[switch]
[case "We go south."]
	[swap]
	[jump target="*select03_5"]
[case "Go east."]
	[swap]
	[jump target="*select03_3"]
[endswitch]

1, go south.

2, east.


;//==============================
;//１、南へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「３のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※３のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_3|Battle of Okehazama

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン４の立ち絵を表示してください

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/3" time=800]


As we proceeded, we met up with Lady Mitsuhide.
[cpg]

She had a disapproving look on her face. Because I did not follow Mitsuhide-sama's words.
[cpg]

[OnName num="keitarou"]
The surprise attack seems to be going well. Mitsuhide-sama.
[cpg cn=true]


Mitsuhide-sama still looked dissatisfied. But we could not retreat now.
[cpg]


;//■選択肢
[switch]
[case "Proceeding south"]
	[swap]
	[jump target="*select03_6"]
[endswitch]

1. Advance to the south


;//==============================
;//１、南へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※４のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_4|Battle of Okehazama

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン５の立ち絵を表示してください

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

On the way, we met up with Ranmaru-sama.
[cpg]

Ranmaru-sama is fighting valiantly. Even though she is a slender girl ......
[cpg]

I admire her, but I know I can't just admire her, so I look forward.
[cpg]


;//■選択肢
[switch]
[case "Going south."]
	[swap]
	[jump target="*select03_7"]
[case "Go to the east"]
	[swap]
	[jump target="*select03_5"]
[endswitch]

1, going south
2. to the east.


;//==============================
;//１、南へ進む

;//同じイベント中の「７のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※５のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※


*select03_5|Battle of Okehazama

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[if exp={getFlagValue("Selectflg3") == 1 }]
[jump target="*select03_5_t"]
[endif]

[jump target="*select03_5_f"]


;//==============================
;//２のマスを通っていた場合

*select03_5_t|Battle of Okehazama

As we proceeded, we found more ambush.
[cpg]

[OnName num="keitarou"]
"Damn ...... if we keep going like this ......"
[cpg cn=true]


I had exhausted my troops to the point where I had no choice but to retreat.
[cpg]

I couldn't go any further. I would have to leave it to Nobunaga-sama.
[cpg]


;//敗北判定となる
;//「桶狭間の戦い　二度伏兵のマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン４ルートへの可能性が残る

[jump target="*select03_lose"]


;//==============================
;//２のマスを通っていない場合

*select03_5_f|Battle of Okehazama

Ahead of me lurked an ambush. I boldly took the fight to them.
[cpg]


[SE f=se019]
;//【ＳＥ】『つばぜり合い』

I defeat the ambushers, but I can't let my guard down. If we run into them again, we will be in danger.
[cpg]

We proceed with caution. ......
[cpg]

[stflag Selectflg3=1]


;//■選択肢
[switch]
[case "We go south."]
	[swap]
	[jump target="*select03_8"]
[case "Go east."]
	[swap]
	[jump target="*select03_6"]
[endswitch]

1, go south.
[cpg]

2, east.
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※６のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_6|Battle of Okehazama

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


;//ヒロイン４の立ち絵を表示してください

I march forward with Mitsuhide-sama.
[cpg]

She seemed somewhat unhappy that I was here.
[cpg]

But I had decided to serve Nobunaga-sama. I will not turn my back from here.
[cpg]


;//■選択肢
[switch]
[case "Proceeding south"]
	[swap]
	[jump target="*select03_9"]
[endswitch]

1. Proceeding south
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※７のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_7|Battle of Okehazama

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

Finally, the long battle is coming to an end.
[cpg]

We have not encountered any ambush soldiers so far. This means that our surprise attack is going to work.
[cpg]


;//■選択肢
[switch]
[case "Advance to the east"]
	[swap]
	[jump target="*select03_8"]
[endswitch]

1. Advance to the east
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※８のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_8|Battle of Okehazama

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[if exp={getFlagValue("Selectflg3") == 1 }]
[jump target="*select03_8_t"]
[endif]

[jump target="*select03_8_f"]


;//==============================
;//２あるいは５のマスを通っていた場合

*select03_8_t|Battle of Okehazama

As we advanced, we found more ambush soldiers.
[cpg]

[OnName num="keitarou"]
"Damn ...... if we keep going like this ......"
[cpg cn=true]


I had exhausted my troops to the point where I had no choice but to retreat.
[cpg]

I couldn't go any further. I would have to leave it to Nobunaga-sama.
[cpg]


;//敗北判定となる
;//「桶狭間の戦い　二度伏兵のマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン４ルートへの可能性が残る

[jump target="*select03_lose"]


;//==============================
;//２、５いずれののマスを通っていない場合

*select03_8_f|Battle of Okehazama


Ahead of me lurked an ambush. I boldly took the fight to them.
[cpg]


[SE f=se019]
;//【ＳＥ】『つばぜり合い』

I defeat all the ambushers, but I can't let my guard down. If we run into them again, we will be in danger.
[cpg]

We proceed with caution. ......
[cpg]

[stflag Selectflg3=1]


;//■選択肢
[switch]
[case "Proceed to the east."]
	[swap]
	[jump target="*select03_9"]
[endswitch]

1. Advance to the east.
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※９のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_9|Battle of Okehazama


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（夕方）******************************************************

[SE f=se019]
;//【ＳＥ】『刀打ち合う』

Everything was a battle until the enemy general, Yoshimoto Imagawa, was defeated.
[cpg]

It is not necessary to defeat every soldier, or perhaps that would not be enough to win.
[cpg]

What a thing to do, Nobunaga-sama has already thought of that.
[cpg]

All we had to do was follow his instructions, and the battle progressed favorably.
[cpg]


[window target=false]
[BG f="b_09_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（夜）******************************************************

And after defeating Yoshimoto Imagawa, the enemy had lost the will to fight.
[cpg]

It was settled. If we won, it meant that Nobunaga-sama had taken over the country.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Mituhide024"]
[OnName num="mitsuhide"]
Nobunaga-sama's schemes make me fall in love with him every time. I am proud to be his vassal.
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
Nobunaga-sama nodded in agreement with Mitsuhide-sama's words.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga183"]
[OnName num="nobunaga"]
I must thank you for eliminating one source of insomnia.
[cpg cn=true]


[OnName num="keitarou"]
I must thank you. I did what I could do.
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga184"]
[OnName num="nobunaga"]
Don't be modest. You've grown into a man, Keitaro.
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


I was thinking about the future. Nobunaga-sama won the battle of Okehazama,.......
[cpg]

The day of reckoning is finally approaching.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

I can think of nothing else.
[cpg]

I can even dismiss this world as having nothing to do with the history that I know.
[cpg]

But no matter what I think, fate will not change, and the future will come.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

Still, when the tension had dissipated after the battle, Ranmaru-sama paid me a visit.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Ranmaru069"]
[OnName num="ranmaru"]
He said, "...... Keitaro. May I have a word?"
[cpg cn=true]


[OnName num="keitarou"]
Is there something wrong, Ranmaru-sama ......?
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru070"]
[OnName num="ranmaru"]
I wanted to thank you. I haven't been able to say it for a long time.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru071"]
[OnName num="ranmaru"]
Thank you. Thanks to you, Nobunaga-sama seems to be more comfortable to fight with.
[cpg cn=true]


[OnName num="keitarou"]
No way. It's Nobunaga-sama's own strength.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru072"]
[OnName num="ranmaru"]
I wonder if he's like me when he stands up for Nobunaga-sama like that.
[cpg cn=true]


Ranmaru-sama is no longer as jealous as he used to be.
[cpg]

Rather, she was grateful ...... I've never seen her make a face like this before.
[cpg]

[OnName num="keitarou"]
Ranmaru-sama is also single-minded about Nobunaga-sama, isn't he?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

Oh," Ranmaru-sama replied, and continued.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru073"]
[OnName num="ranmaru"]
There is no greater joy than to be praised and adored by Nobunaga-sama.
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

We are getting closer to unifying the country. No one can stop Nobunaga-sama.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga185"]
[OnName num="nobunaga"]
I'm thinking of forming an alliance with Takeda. I'm sure he won't refuse."
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga186"]
[OnName num="nobunaga"]
What's wrong? You don't look happy.
[cpg cn=true]


I had been thinking about it for a long time. Not much time has passed so far.
[cpg]

I think that the original history was moving more slowly.
[cpg]

[OnName num="keitarou"]
I have been thinking for a long time that this history is different from the one I know.
[cpg cn=true]


[OnName num="keitarou"]
It is partly because Nobunaga-sama is a woman, but the passage of time is too fast.
[cpg cn=true]


That may have something to do with the fact that there is not much difference in age between Ranmaru-sama and Nobunaga-sama.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga187"]
[OnName num="nobunaga"]
However, I won the Okehazama. Now, it is not even impossible for me to take over the country."
[cpg cn=true]


That is certainly true, and I don't think the future of taking the reigns will change from now on.
[cpg]

If it is ......, what about the Honnoji Incident?
[cpg]

If we take measures before the rebellion happens, the future might change.
[cpg]

If we did, would Nobunaga-sama live on, thinking: ......
[cpg]

[OnName num="keitarou"]
Yes. That's right."
[cpg cn=true]


For now, he just pledged his loyalty to Nobunaga-sama.
[cpg]

[if exp={getFlagValue("Selectflg2") == 1 }]
[jump target="*select03_ex"]
[endif]


[jump target="*select03_end"]


;//==============================
;//稲生の戦いで勝利していた場合のみ下記のシナリオを通る

*select03_ex|The Battle of Okehazama

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga188"]
[OnName num="nobunaga"]
'Hm. Keitaro, you are still somewhat nervous."
[cpg cn=true]


[OnName num="keitarou"]
No, that's not what ......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga189"]
[OnName num="nobunaga"]
'I must be the one to break the tension, I suppose.
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

Saying that, she approaches me.
[cpg]

[OnName num="keitarou"]
'Nobunaga-sama, ...... it's no good. This is such a waste of time for me."
[cpg cn=true]


[OnName num="keitarou"]
'Besides, you never know who's watching.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga190"]
[OnName num="nobunaga"]
'...... I see. If you refuse, I won't force you."
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

......I refused Nobunaga-sama's invitation.
[cpg]

It's a little heartbreaking. But it can't be helped.
[cpg]

I wasn't ready for it either.
[cpg]


[window target=false]
[BG f="b_06_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夕方）******************************************************

But soon enough, I couldn't remain unprepared.
[cpg]

I was summoned not by Nobunaga-sama, but by one of his vassals.
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

Both of the vassals were men. Both vassals were men, and both had mysterious looks on their faces.
[cpg]

[OnName num="vassal_A"]
Listen to me, Keitaro. Nobunaga-sama, as you know, keeps men away."
[cpg cn=true]


[OnName num="keitarou"]
Yes,......, he must be a very busy man.
[cpg cn=true]


[OnName num="vassal_B"]
He's probably a busy man. But I can no longer say so.
[cpg cn=true]


[OnName num="vassal_A"]
I hear that Nobunaga-sama likes Keitaro, which is unusual for a man.
[cpg cn=true]


I wonder about ....... I wonder if there are men out there who trust me more than I do.
[cpg]

Ranmaru-sama and Mitsuhide-sama are women.
[cpg]

[OnName num="vassal_A"]
I have a favor to ask of you.
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

So, I was set up with ......
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="sNobunaga007"]
[OnName num="nobunaga"]
"An heir, huh? Do I have to think about that too?
[cpg cn=true]


[OnName num="keitarou"]
...... yes, you do."
[cpg cn=true]


I could only reply dumbly.
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="sNobunaga008"]
[OnName num="nobunaga"]
But if the other party is Keitaro, I don't mind.
[cpg cn=true]


[OnName num="keitarou"]
But ...... Nobunaga-sama.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="sNobunaga009"]
[OnName num="nobunaga"]
You don't have to follow anything you say or do seriously. It's okay to say, I couldn't have children.
[cpg cn=true]


The ...... Nobunaga-sama still did not seem to intend to have a child.
[cpg]


;//ブラックアウト

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『街』（昼）******************************************************

The next day. The next day, I couldn't sit still in my room, so I went out to the castle town.
[cpg]

A town in the Warring States period. It was a town in the Warring States period, and it was very different from the modern town.
[cpg]

It was not glamorous, and the buildings were low as far as the eye could see.
[cpg]

Still, there was human life. I guess it was Nobunaga-sama's role to protect this.
[cpg]

Or is it also my role? As I was walking along, thinking about ......
[cpg]


;//========================================
;//●ＣＧ（紹介ページヒロイン４のＣＧ）ev_
;//人物１：ヒロイン４　服装１：着衣
;//場所　：城下町
;//時間　：昼
;//備考　：可能であれば背景を足してください
;//========================================


[free time=1000]
;**【ＣＧ】 ev_00_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]



I saw Mitsuhide-sama. Ranmaru-sama is also nearby.
[cpg]


[VOICE f="Mituhide025"]
[OnName num="mitsuhide"]
It seems that Nobunaga-sama has taken a liking to you lately.
[cpg cn=true]



[VOICE f="Ranmaru074"]
[OnName num="ranmaru"]
I'm not saying that recently, but all the time. I've been doing so for a long time now. Are you jealous?
[cpg cn=true]


I decided to listen to the conversation from behind.
[cpg]


[VOICE f="Mituhide026"]
[OnName num="mitsuhide"]
No, I just thought I'd be happy if I didn't think as much as you do.
[cpg cn=true]



[VOICE f="Ranmaru075"]
[OnName num="ranmaru"]
"What do you mean, ......?"
[cpg cn=true]


From the outside, it's a skirmish between two people who work for the same person.
[cpg]

But from my knowledge of the future, it sounded like a completely different nuance.
[cpg]

At that time, I couldn't speak up.
[cpg]

......But then again, Mitsuhide-sama also comes to a place like a teahouse, doesn't he?
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

[OnName num="keitarou"]
......"
[cpg cn=true]


Looking at the castle from the outside. The town has no lights, so the moon and the stars are very beautiful.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga215"]
[OnName num="nobunaga"]
Can't sleep? Keitaro.
[cpg cn=true]


[OnName num="keitarou"]
"...... Nobunaga-sama too?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga216"]
[OnName num="nobunaga"]
No. I was thinking about the future. I was thinking about the future. I've been working too hard, so I'm taking a break.
[cpg cn=true]


Nobunaga-sama is probably thinking about how he is going to rule Japan.
[cpg]

I can't even imagine what he's thinking about.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga217"]
[OnName num="nobunaga"]
What he should be thinking about from now on is different from how to win the war. I don't know who will hate me.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga218"]
[OnName num="nobunaga"]
Even I am afraid of death. What will happen next......
[cpg cn=true]


She doesn't show it in her expression. Still, I could tell she was worried.
[cpg]

[OnName num="keitarou"]
As long as I am here, Nobunaga-sama will protect you.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga219"]
[OnName num="nobunaga"]
I'll protect you, too. I will protect you, too.
[cpg cn=true]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]


[VOICE f="Nobunaga220"]
[OnName num="nobunaga"]
'...... don't be seen here.
[cpg cn=true]



[SE f=se027]
;//【ＳＥ】『茂みを歩く』

Nobunaga-sama led me into the thicket of the forest.
[cpg]


;//========================================
;//●ＣＧ（接近してキスをする）ev_07
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：森の茂み
;//時間　：夜
;//========================================



[BGM f="bg_09"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]



;//移植前シーンカット

After entering the forest bushes, she was about to kiss me on the mouth.
[cpg]


[VOICE f="sNobunaga010"]
[OnName num="nobunaga"]
'Chuu......, nn.'
[cpg cn=true]


When I was touching her, I couldn't be happier.
[cpg]

I don't need anything else. I don't care if I can't go back to the original time.
[cpg]

I could have wished that this time could go on forever.
[cpg]


;**【ＣＧ】 ev_07_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNobunaga011"]
[OnName num="nobunaga"]
I want ...... to have children with you.
[cpg cn=true]


Even so, there was hesitation when he said that.
[cpg]

If you have a child with her in this time period, you will finally not be able to return.
[cpg]

[OnName num="keitarou"]
"That's ......
[cpg cn=true]



[VOICE f="sNobunaga012"]
[OnName num="nobunaga"]
......You don't have to give me an answer right now."
[cpg cn=true]


I took Nobunaga-sama at his word.
[cpg]

I'm still going to continue our ambiguous relationship.
[cpg]


;//移植前シーンカット

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『森の中』（夜）******************************************************

It was a lovely time. I don't think I have much time left.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga262"]
[OnName num="nobunaga"]
I thought to myself, "I should get back to ......, what time is it?"
[cpg cn=true]


Still, we lost track of time as we sought each other out.
[cpg]

What could I do for her?
[cpg]

Could I prevent what was about to happen?
[cpg]


;//==============================

*select03_end|The Battle of Okehazama

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

Then, we received bad news. We received bad news.
[cpg]

Shingen-sama was very weak.
[cpg]

She was suffering from tuberculosis. A disease that cannot be cured in this day and age.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

Ranmaru-sama and I were on our way to the castle where Shingen-sama lived on orders from Nobunaga-sama.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru076"]
[OnName num="ranmaru"]
You're getting stronger, aren't you?
[cpg cn=true]


[OnName num="keitarou"]
I'm getting used to it,.......
[cpg cn=true]


Ranmaru-sama was becoming less prodding, perhaps recognizing my efforts to some extent.
[cpg]

 I even felt nostalgic for those days.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru077"]
[OnName num="ranmaru"]
And yet, that Shingen-sama. She was invincible and seemed to be immortal.
[cpg cn=true]


[OnName num="keitarou"]
I suppose it's true that no one can defeat illness.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru078"]
[OnName num="ranmaru"]
I don't know if that's true. I'm strangely lonely.
[cpg cn=true]


[OnName num="keitarou"]
I'll miss you strangely. You shouldn't say that yet.
[cpg cn=true]


Ranmaru-sama looked really lonely.
[cpg]

I could imagine that he and Shingen must have known each other for a long time.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

The mountain paths don't bother me as much as they used to.
[cpg]

I had been through more than my share of shuraku.
[cpg]

Then, through the continuing mountain road, ......
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_01_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（夜）******************************************************

We come out to the castle town. We are almost to Shingen-sama's place.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru079"]
[OnName num="ranmaru"]
...... Shingen-sama is probably asleep by now.
[cpg cn=true]


So it was decided that we would go to Shingen-sama's place tomorrow.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（朝）******************************************************

The next morning. Shingen-sama looked even paler than before.
[cpg]

He was lying on his side, breathing slowly. He was already too ill to get up.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Singen069"]
[OnName num="shingen"]
I'm sorry to worry you," he said. If only I were a little stronger.
[cpg cn=true]


Shingen-sama was even weaker than I had imagined. I was so worried about him," she said.
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru080"]
[OnName num="ranmaru"]
'Shingen-sama, ...... what did the doctor say?
[cpg cn=true]


[FACE method="shake_4" pos="2/5"]

[VOICE f="Singen070"]
[OnName num="shingen"]
He doesn't have long to live. He can't stop coughing. ......
[cpg cn=true]


Ranmaru-sama had tears in his eyes. Nobunaga-sama would be depressed if he knew about this.
[cpg]

Then Shingen-sama took my hand. It was a surprisingly cold hand.
[cpg]

[FACE method="bow_4" pos="2/5"]

[VOICE f="Singen071"]
[OnName num="shingen"]
"Nobunaga, ...... she is ......."
[cpg cn=true]


[OnName num="keitarou"]
What is it?　Is it to tell Nobunaga-sama?
[cpg cn=true]


[FACE method="bow_6" pos="2/5"]

[VOICE f="Singen072"]
[OnName num="shingen"]
Don't leave her alone. If she can't be happy, I can't die.
[cpg cn=true]


Shingen-sama looked pained as he spoke out his love for Nobunaga-sama.
[cpg]

It is not so much a physical suffering as a mental one.
[cpg]

He is probably afraid of what would happen to Nobunaga-sama if he were to die like this.
[cpg]

[FACE method="shake_6" pos="4/5"]

[VOICE f="Ranmaru081"]
[OnName num="ranmaru"]
I'll be fine. Shingen-sama will not die."
[cpg cn=true]


[FACE method="change_2" pos="2/5"]

[VOICE f="Singen073"]
[OnName num="shingen"]
"...... Ranmaru. You are so kind. Support Nobunaga.
[cpg cn=true]


Ranmaru-sama finally burst into tears.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

She died the next night. Both Ranmaru-sama and I were present.
[cpg]

At that time, Ranmaru-sama was sobbing like a child.
[cpg]

I was thinking about what I should tell Nobunaga-sama. ......
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

We headed back the way we came. I was thinking the same thing as Ranmaru-sama and I were probably thinking the same thing.
[cpg]

I don't want to see Nobunaga-sama depressed.
[cpg]

But I can't not tell him the truth. ......
[cpg]


[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

At night, while we were encamped, I was awakened by Ranmaru-sama's voice.
[cpg]

[OnName num="keitarou"]
...... Ranmaru-sama."
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru082"]
[OnName num="ranmaru"]
What? I'm not crying."
[cpg cn=true]


It was too dark to see clearly, but I thought Ranmaru-sama was crying.
[cpg]

Then maybe the voice that woke me up was also a sobbing voice.
[cpg]

...... Is this a time when human life is light? The difference is only rather heavy, isn't it?
[cpg]

I would not trade Nobunaga-sama's life for anything.
[cpg]

Shingen-sama's death reminded me of what is to come.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

Then, we exit the mountain road: ......
[cpg]

After a long time, I returned to Nobunaga-sama's place.
[cpg]

That alone made me feel a little relieved.
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

I was on my way to Nobunaga-sama to tell him everything.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Nobunaga263"]
[OnName num="nobunaga"]
I was going to tell him everything. Shingen is dead."
[cpg cn=true]


Nobunaga-sama's eyes were cloudy. I couldn't find any words to say.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga264"]
[OnName num="nobunaga"]
"For her sake, I must live.
[cpg cn=true]


[OnName num="keitarou"]
Yes. If Nobunaga-sama dies too, I'll be ......."
[cpg cn=true]


Nobunaga-sama looked a little surprised.
[cpg]

[FACE method="change_5" pos="2/3"]

[VOICE f="Nobunaga265"]
[OnName num="nobunaga"]
Why do you say that? I haven't had any serious illnesses so far.
[cpg cn=true]


[OnName num="keitarou"]
'...... that's true, but...'
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga266"]
[OnName num="nobunaga"]
'Don't worry. I will be in heaven, won't I?　Or are you hiding something?"
[cpg cn=true]


I didn't know if it was really a good idea to bend history, so I couldn't answer.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

Inside the castle. In the hallway, I met Ranmaru-sama.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru083"]
[OnName num="ranmaru"]
I told him everything, didn't I? I told Nobunaga-sama about ......."
[cpg cn=true]


[OnName num="keitarou"]
Yes.
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Ranmaru084"]
[OnName num="ranmaru"]
I see. I can't tell him. I'm going to cry again.
[cpg cn=true]


Ranmaru-sama said this to himself in self-mockery.
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru085"]
[OnName num="ranmaru"]
But thank you for ....... Nobunaga-sama has changed a lot since you came.
[cpg cn=true]


[OnName num="keitarou"]
Is that so,......?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru086"]
[OnName num="ranmaru"]
But now he's different,......, he's kinder.
[cpg cn=true]


I don't get it, but Ranmaru-sama is the one who sees Nobunaga-sama more than I do.
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru087"]
[OnName num="ranmaru"]
"I think he's probably just as greedy as anyone else, wanting people to like him,......, though I can't speak highly enough of him.
[cpg cn=true]


It seems that Ranmaru-sama is thinking about Nobunaga-sama in her own way.
[cpg]

He might even be thinking about how her change of heart might affect Japan in the future.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru088"]
[OnName num="ranmaru"]
I like the old Nobunaga-sama, but I like the new Nobunaga-sama even more. I have you to thank for that.
[cpg cn=true]


Ranmaru-sama seemed to be thanking me.
[cpg]

[OnName num="keitarou"]
Ranmaru-sama has changed, too. I think he was more jealous of me.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru089"]
[OnName num="ranmaru"]
That's true," he said. That's because I have no one but Nobunaga-sama.
[cpg cn=true]


We both think we have no choice but to serve Nobunaga-sama.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru090"]
[OnName num="ranmaru"]
You and I are kinda like each other, aren't we?
[cpg cn=true]


Her expression was different from the first time.
[cpg]

They looked quite confidant. It wasn't just a resemblance, either.
[cpg]

Can we call them friends-in-arms, or is the relationship more than that?
[cpg]

I thought ...... about it, but I couldn't say it out loud so easily.
[cpg]

[OnName num="keitarou"]
Maybe it's ...... true."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

We often look at each other.
[cpg]

Ranmaru-sama can't tell me now that he doesn't think anything of me.
[cpg]

But that doesn't mean I shouldn't touch him so easily.
[cpg]

And I knew that one word here carried a lot of weight.
[cpg]

I could not carelessly push her away, nor could I pull her closer.
[cpg]

If I said something here that would make her accept me, she might do ...... something.
[cpg]

I could not say anything because we both felt the presence of it.
[cpg]


;//※ストーリーが分岐
;//　稲生の戦いで勝利していた場合のみ、ヒロイン１ルートへ
;//　稲生の戦いで敗北していた場合のみ、ヒロイン５ルートへ


[if exp={getFlagValue("Selectflg2") == 1 }]
[jump target="*root_1"]
[endif]

[jump target="*root_5"]


*root_1
[jump storage="ep003.ks" target="*start"]


*root_5
[jump storage="ep004.ks" target="*start"]


*select03_lose
*root_4
[jump storage="ep005.ks" target="*start"]


