
*start

;//==============================
;//謙信の所へ潜入　二度音の鳴るマスを通った場合

*select04_lose|Loyalty to Shingen

*root_3|Loyalty put to the test

;#################################################
*Ep007|Loyalty put to the test.
;#################################################

[SCENE id=7]


[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin003"]
[OnName num="kenshin"]
Welcome to my castle. Perhaps you are one of Shingen's men.
[cpg cn=true]


Kenshin was not the only one there. Other than Kenshin, other soldiers were standing there to protect her.
[cpg]

They had swords at the ready. Our weapons are no match for them.
[cpg]

[OnName num="ninja"]
Damn ......!"
[cpg cn=true]


She tried to back away, but...
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin004"]
[OnName num="kenshin"]
"They must have thought we were outnumbered. My men informed us of the infiltration of the ninja.
[cpg cn=true]


The soldiers were circling around us like a pincer movement.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

Every last one of us was captured. Some of the ninja were killed for resisting.
[cpg]

I was no exception. Even now, I could not get out of the prison.
[cpg]

At this rate, I would be killed or tortured. Or both.
[cpg]

[OnName num="keitarou"]
"...... No, no, no. No, no, no, no, no, no, no, no, no, no, no, no, no.
[cpg cn=true]


I have to make it back alive no matter what. That's what I promised Shingen-sama.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin005"]
[OnName num="kenshin"]
You are reckless. We must not be underestimated.
[cpg cn=true]


Then, Kenshin came in. I stood up and grabbed the grate with my hand.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin006"]
[OnName num="kenshin"]
Do you have any last words?
[cpg cn=true]


I decide to play the only card I have left.
[cpg]

[OnName num="keitarou"]
I know what she's up to.
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Kensin007"]
[OnName num="kenshin"]
I see. Everyone says so. I don't think I can trust what you say.
[cpg cn=true]


Kenshin would not listen.
[cpg]

But I had a way to prove that I had really been by Shingen's side.
[cpg]

[OnName num="keitarou"]
My name is Keitaro. Does this name sound familiar? It is possible that Shingen-sama dares to spread the rumor.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin008"]
[OnName num="kenshin"]
"...... Keitaro. Are you that man?
[cpg cn=true]


I am also indebted to Shingen-sama. But right now, I have to give top priority to saving my own life.
[cpg]

Besides, if he lives, he may see Shingen-sama again.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin009"]
[OnName num="kenshin"]
I think it would be better to forgo your execution for once. I have heard rumors.
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I spent a sleepless night in prison.
[cpg]

Everyone who had snuck in with me would have been killed.
[cpg]

It was only natural, but I was still somewhat unprepared.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿外観＿謙信』（昼）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

I had a hard time sleeping, and I didn't know whether I was awake or asleep.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin010"]
[OnName num="kenshin"]
Hello, Keitaro-san. Keitaro-san.
[cpg cn=true]


[OnName num="keitarou"]
......!"
[cpg cn=true]


But in an instant, my sleepiness was gone. Kenshin had appeared.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin011"]
[OnName num="kenshin"]
I've decided to believe you. I have decided to believe what you say.
[cpg cn=true]


Kenshin told me in his prison cell.
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Kensin012"]
[OnName num="kenshin"]
There are rumors about your existence. I did not know the details.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin013"]
[OnName num="kenshin"]
I did not know the details, but it seems that you were with Nobunaga at first. I have heard about you since then.
[cpg cn=true]


[OnName num="keitarou"]
Are you going to help us?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin014"]
[OnName num="kenshin"]
I've heard about you since that time. But it would be a shame to kill him.
[cpg cn=true]


[OnName num="keitarou"]
Thank you for ......."
[cpg cn=true]


All kinds of thoughts were running through my mind.
[cpg]

I am grateful to Kenshin, but I would be betraying Shingen-sama. Would that be all right?
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin015"]
[OnName num="kenshin"]
'But I can't let you out of jail yet. You never know when he might betray you.
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I spend some time in the prison where there is no light.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

I don't know when he will kill me, but I know he won't kill me soon.
[cpg]

I was not in a good mood. I felt like I wasn't even alive.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin016"]
[OnName num="kenshin"]
It's a beautiful night. Not even moonlight reaches this prison.
[cpg cn=true]


[OnName num="keitarou"]
"...... Kenshin, sir."
[cpg cn=true]


I found myself calling her by her name. She was no longer just my enemy.
[cpg]

[OnName num="keitarou"]
Please let me out of here. I won't run away.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Kensin017"]
[OnName num="kenshin"]
Do you know what you have done?　Did you not go in there thinking you could get yourself killed?
[cpg cn=true]


I had nothing to say.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin018"]
[OnName num="kenshin"]
I told you again and again, you don't have to be frightened.
[cpg cn=true]


[OnName num="keitarou"]
'I can't ...... do that. I'm trapped in a place like this.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Kensin019"]
[OnName num="kenshin"]
If you want to get me out of here, it's a deal. If I get you out of here, it's a deal. You swear to me you'll be loyal to me?
[cpg cn=true]


[OnName num="keitarou"]
It's ......
[cpg cn=true]


I am lost. I am lost, but the only way to survive now may be to betray Shingen.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin020"]
[OnName num="kenshin"]
Can't you at least tell us what Shingen was planning to do next? Let's exchange that information.
[cpg cn=true]


The choice between telling a lie and telling the truth was a crucial one.
[cpg]

Can we tell a big lie and wait for Shingen-sama to come to our rescue? ......
[cpg]

Kenshin-sama says. If you obey me, I will even give you a reward.......
[cpg]

Of course, such words will not change my loyalty.
[cpg]

But I had a lot of emotions swirling around me.
[cpg]

If Kenshin-sama says that much, should I follow her?
[cpg]

I don't even know what the word "reward" means, but ......
[cpg]

Do I lie for Shingen-sama? I had two choices: tell the truth for Kenshin-sama's sake.
[cpg]


;//■選択肢
[switch]
[case "tell a lie"]
	[swap]
	[jump target="*root_3_bad"]
[case "Tell the truth"]
	[swap]
	[jump target="*root_3_true"]
[endswitch]

1, tell a lie
2, tell the truth


;//==============================
;//１、嘘をつく

*root_3_bad|Reckless Loyalty




[OnName num="keitarou"]
"...... Shingen-sama is planning a surprise attack. I know the date and time."
[cpg cn=true]


After thinking it over, I broke down and lied.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin021"]
[OnName num="kenshin"]
"Is that so? If he's planning such a surprise attack ......, then let's return the favor.
[cpg cn=true]


I decided to tell him something completely different from the actual plan to invade and make him thin out the castle.
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Kensin022"]
[OnName num="kenshin"]
'Thank you, sir, for telling me such an important lesson. Shall I reward you?"
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

And then they let me out of the prison.
[cpg]

Surrounded by a number of soldiers, Kenshin-sama took me and moved me.
[cpg]


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[OnName num="keitarou"]
"...... haha ......"
[cpg cn=true]


Finally, I was released. Of course, the room is guarded.
[cpg]

It's not like I could run away even if I tried. Still, I feel quite different.
[cpg]

My tautness loosened and I slept like mud for the first time in a long time. ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

It will be some time before they realize that everything I said is a lie.
[cpg]

Or rather, there is a possibility that the war will be turned upside down and Shingen-sama will invade.
[cpg]

If that happens, I will have fulfilled my role as a Shinobi.
[cpg]

I don't know if it will work out that well, but I'm betting on that possibility.
[cpg]


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

The next night, Kenshin-sama visited me.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin023"]
[OnName num="kenshin"]
He said, "We are preparing to attack you right now. If we win this battle, it will be thanks to you.
[cpg cn=true]


Kenshin-sama looked as if he did not know whether to believe me or not.
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（隣り合う二人。キスをする）ev_57
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_57_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Kensin024"]
[OnName num="kenshin"]
You said I would reward you.
[cpg cn=true]


He said and rubbed up against me.
[cpg]

[OnName num="keitarou"]
'Kenshin-sama, ...... what ......?
[cpg cn=true]



[VOICE f="Kensin025"]
[OnName num="kenshin"]
'I am truly grateful to you, my dear. Of course, if what you said is true.
[cpg cn=true]


She said. I'll give you a reward if you tell the truth.
[cpg]

That seemed to be about to become a reality. ......
[cpg]


[VOICE f="sKensin001"]
[OnName num="kenshin"]
"Chuu......!"
[cpg cn=true]


Her lips touch mine.
[cpg]


;//移植前シーンカット

;//ブラックアウト

;//移植前シーンカット

That kiss was sinful,.......
[cpg]

In fact, there was no way Shingen-sama would attack as he did.
[cpg]

Kenshin-sama is trying to intercept an enemy that is not supposed to come.
[cpg]

In the meantime, if only Shingen-sama would come ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

and waited for him, but it didn't work out that way.
[cpg]

In fact, they did not attack us for any length of time.
[cpg]

Shingen-sama was not intercepted, nor did he come to my rescue.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin078"]
[OnName num="kenshin"]
What do you mean?　Are you lying?
[cpg cn=true]


Kenshin-sama asked me. I hurriedly made an excuse.
[cpg]

[OnName num="keitarou"]
He must have thought that I knew the information, so he dared to betray me.
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Kensin079"]
[OnName num="kenshin"]
It is ...... possible, but that would make you useless.
[cpg cn=true]


You're absolutely right. How am I going to survive from here?
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

If I don't do anything, Kenshin-sama will give up on me.
[cpg]

If that happens, it will be my time to die. I have no choice but to get out of here before that happens.
[cpg]

I don't even need to think about it. Whether Shingen-sama wants to help me or not is the question before that.
[cpg]

From what I've seen so far, I've learned the cycle of when the guards will change.
[cpg]

I'll try to escape at that moment. ......
[cpg]

[OnName num="keitarou"]
......"
[cpg cn=true]



;//ブラックアウト

[SE f=se030]
;//【ＳＥ】『床走る』

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

I have infiltrated the castle many times. I had some idea of what kind of structure this castle was.
[cpg]

[OnName num="soldier"]
Wait!　Hey, who's there?"
[cpg cn=true]


Still, it was tough. After all, I had no weapons.
[cpg]

Without weapons, there was no way I could take them.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin080"]
[OnName num="kenshin"]
I knew you were going to betray me. He even lied to me to stay alive.
[cpg cn=true]


Kenshin-sama was the last one to stand in my way.
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Kensin081"]
[OnName num="kenshin"]
He was the last one to stand up to Kenshin-sama. I am disappointed in you.
[cpg cn=true]


I could not say anything. I was just frightened at the thought of what was to come.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I was eventually caught and put in jail.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

In prison, I knew that this time I would be killed.
[cpg]

There was no reason to keep me alive. I never thought this would happen. ......
[cpg]

Even though I deserved it, I thought back to how I should have worked near Shingen-sama from the beginning.
[cpg]

Or maybe I should have told the truth instead of lying.
[cpg]

It's all so improbable now that I think about it.
[cpg]


[window target=false]
[BG f="b_14_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（昼）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

At noon, Kenshin-sama paid me a visit.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin082"]
[OnName num="kenshin"]
How are you feeling?"
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Kensin083"]
[OnName num="kenshin"]
I'm asking you how you feel after all the deception. Why don't you answer me?
[cpg cn=true]


I remained silent.
[cpg]


;//ブラックアウト

;//移植前シーンカット

;//ブラックアウト

;//========================================
;//●ＣＧ（主人公を足蹴にするヒロイン）ev_58
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：裸
;//場所　：牢の中
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_58_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]



;//移植前シーンカット


[VOICE f="sKensin002"]
[OnName num="kenshin"]
I could care less about your life.
[cpg cn=true]



[VOICE f="sKensin003"]
[OnName num="kenshin"]
Are you willing to die for loyalty?　Is that what you really want?
[cpg cn=true]


I tried to keep my mind strong.
[cpg]

She was right. Loyalty to Shingen-sama was all I had to rely on.
[cpg]


[VOICE f="sKensin004"]
[OnName num="kenshin"]
Are you willing to work for me?
[cpg cn=true]


I kept silent. I made no reply.
[cpg]


[VOICE f="Kensin141"]
[OnName num="kenshin"]
I admired your spirit of never betraying me until the very end, but you will not live long if you do.
[cpg cn=true]



[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

Kenshin-sama left and never visited me again.
[cpg]

In the end, he did not turn in until the end.
[cpg]

In prison, I waited for Shingen-sama to come to my rescue.
[cpg]

But I knew that the battle of Kawanakajima would never be settled.
[cpg]

And so I disappeared into the shadows of history. ......
[cpg]


;//ブラックアウト

;//ＥＮＤ　バッドエンドルート

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="epend.ks" target="*back_title"]


;//==============================
;//２、本当のことを言う

*root_3_true|The Heart of Belief



[OnName num="keitarou"]
I understand. I pledge my allegiance to you.
[cpg cn=true]


I decided to turn to Kenshin-sama and tell him the truth.
[cpg]

[OnName num="keitarou"]
I know how Shingen-sama will blame me, but I know something even more important.
[cpg cn=true]


There is no reason to keep it hidden any longer. I couldn't even hide the fact that I was from the future.
[cpg]

[OnName num="keitarou"]
I am from the future. At first I was at Nobunaga-sama's place. ......
[cpg cn=true]


[FACE method="shake_5" pos="2/3"]

[VOICE f="Kensin142"]
[OnName num="kenshin"]
What is this all of a sudden?　No one would believe such a lie, even if it was for the sake of survival.
[cpg cn=true]


[OnName num="keitarou"]
It is true. I know that the battle of Kawanakajima was inconclusive.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin143"]
[OnName num="kenshin"]
...... If true, I can't think of anyone more useful than you. So far, I have no reason to believe it.
[cpg cn=true]


I also revealed all of Shingen-sama's plans.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

I was let out of my cell and proceeded to tell Kenshin-sama the details.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin144"]
[OnName num="kenshin"]
He said, "You mean they are coming from the front. Then we may launch a surprise attack.
[cpg cn=true]


[OnName num="keitarou"]
I told him the details of the operation. Yes, I think so.
[cpg cn=true]


My words were about to change the war situation drastically.
[cpg]

From that day on, the way I was treated also changed.
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Kensin145"]
[OnName num="kenshin"]
I would finally be able to outsmart Shingen. I have been waiting for this moment for a long time.
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（朝）******************************************************

I decided to serve Kenshin-sama.
[cpg]

I told him the truth, including my true identity. Kenshin-sama is trying to outsmart Shingen's strategy.
[cpg]

I was not taken to the battlefield as a matter of course. I guess he thought it would be too risky.
[cpg]

In any case, I had to defy Shingen-sama.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夕方）******************************************************

The battle of Kawanakajima did not end with a single clash.
[cpg]

It was an irregularity for me to join Kenshin-sama this time. The long battle may end here. ......
[cpg]

In the end, the battle was not settled. Kenshin-sama had returned without defeating Shingen-sama.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Kensin146"]
[OnName num="kenshin"]
"It's ...... difficult, isn't it? After all, are we sworn enemies?"
[cpg cn=true]


Kenshin-sama looked disappointed.
[cpg]

The only time I can know about Shingen's strategy is this time.
[cpg]

The first time I've ever had the chance to learn about Shingen's strategy, I may have missed it.
[cpg]

[FACE method="bow_6" pos="2/3"]

[VOICE f="Kensin147"]
[OnName num="kenshin"]
But how could you decide to take my side at the last minute?
[cpg cn=true]


[OnName num="keitarou"]
Because ...... I had no choice.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin148"]
[OnName num="kenshin"]
Did you have any doubts about taking my side?
[cpg cn=true]


If I nodded, I would be lying. I kept my mouth shut.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Kensin149"]
[OnName num="kenshin"]
I was happy that he chose me after all the deliberation.
[cpg cn=true]

[STOPBGM]

But then, Kenshin-sama packed up on me.
[cpg]

[BGM f="bg_09"]

[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin150"]
[OnName num="kenshin"]
If it is said that there is no God or Buddha, it is true.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Kensin151"]
[OnName num="kenshin"]
So, I value faith more than others,...... and I believe in what you say, too.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Kensin152"]
[OnName num="kenshin"]
You have a mysterious charm about you. I'm so charmed by you that even if you told me you were from the future, I'd believe you.
[cpg cn=true]


[OnName num="keitarou"]
......Kenshin-sama."
[cpg cn=true]


I couldn't just shove her out of my way.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Kensin153"]
[OnName num="kenshin"]
I'm not saying that I don't think anything of it, but I do.
[cpg cn=true]


[OnName num="keitarou"]
It's not that I don't think anything of it, but ......
[cpg cn=true]


I served Shingen-sama. And yet, it is so cowardly of me to love Kenshin-sama as well.
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Kensin154"]
[OnName num="kenshin"]
The best way to do this is to use the best of the best. But I think you are making the best choice right now.
[cpg cn=true]



;//ブラックアウト

;//========================================
;//●ＣＧ（主人公のすぐ前にいるヒロイン）ev_48
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_48_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]



;//移植前シーンカット

[OnName num="keitarou"]
"I can't ...... suddenly love you. It's crazy.
[cpg cn=true]



[VOICE f="Kensin178"]
[OnName num="kenshin"]
I know. But if that's the case, then I'm crazy for asking you out, aren't I?
[cpg cn=true]


[OnName num="keitarou"]
No,......, I didn't mean it that way.
[cpg cn=true]



[VOICE f="Kensin179"]
[OnName num="kenshin"]
I know that. I know I'm going crazy.
[cpg cn=true]


 Kenshin seemed to be really grateful.
[cpg]

And it seems that my feelings didn't stop there.
[cpg]


[VOICE f="Kensin180"]
[OnName num="kenshin"]
I think I am attracted to you. As well as the fact that you betrayed Shingen. ......
[cpg cn=true]



[VOICE f="Kensin181"]
[OnName num="kenshin"]
You have an air of being out of this world. He's not like other men."
[cpg cn=true]


......There is no doubt about that. I'm not from this time period.
[cpg]


;//ブラックアウト

;//移植前シーンカット

[window target=false]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

Still, I wonder if it was right for me to have done this.
[cpg]

There are probably other vassals who adore Kenshin-sama. If she is as beautiful as she is, they may be attracted to her even if they are not vassals.
[cpg]

When I mentioned my concern about ...... in front of all those people, he said.
[cpg]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin203"]
[OnName num="kenshin"]
'You don't need to worry about that.'
[cpg cn=true]


Kenshin-sama replied.
[cpg]

[OnName num="keitarou"]
"Even if you say so, I'm sure I'll still cause ...... jealousy.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="sKensin005"]
[OnName num="kenshin"]
'You don't like me because I'll make you jealous?
[cpg cn=true]


......Yes, that's right. Is that what I should be doing, taking care of that feeling?
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（昼）******************************************************

[SE f=se019]
;//【ＳＥ】『剣戟』

Then Kenshin-sama and Shingen-sama clashed again.
[cpg]

I was not there. This means that Kenshin-sama does not yet trust me completely.
[cpg]

Kenshin-sama was behind Shingen-sama's strategy. As I had expected, there was no resolution to the conflict.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿謙信』（夕方）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Kensin205"]
[OnName num="kenshin"]
The other side may be thinking the same thing. They may be thinking the same thing.
[cpg cn=true]


Kenshin-sama seemed to be feeling frustrated.
[cpg]

But when this battle is settled, I will lose one of my two masters.
[cpg]

All I could do, and all I wanted to do, was to keep the balance in this battle.
[cpg]

It will not be settled. Neither of the generals would be killed. I wanted to choose that path.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Kensin206"]
[OnName num="kenshin"]
If this happens,...... I have no choice but to send you back to Shingen once more.
[cpg cn=true]


[OnName num="keitarou"]
...... what do you mean?"
[cpg cn=true]


I was surprised to hear something so unexpected, and I couldn't help but make a bare voice.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin207"]
[OnName num="kenshin"]
I'm sure you will pledge your allegiance to me. Would you extract information from Shingen again?
[cpg cn=true]


[OnName num="keitarou"]
If I do that, don't you think I will join Shingen again?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin208"]
[OnName num="kenshin"]
I don't think so. You and I are no longer strangers.
[cpg cn=true]


 Kenshin confidently said so, and I thought so too.
[cpg]

I could no longer move to go back to Shingen-sama and avenge Kenshin-sama......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

But then again, I didn't think I wanted to defeat Shingen-sama either.
[cpg]

I think it is natural psychology. Perhaps Kenshin-sama had me in mind.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

I returned to Shingen-sama again.
[cpg]

Unlike before, my companions were no longer with me. But I couldn't be daunted.
[cpg]


[window target=false]
[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

Shingen-sama would be happy to see me return. But I could no longer take her side.
[cpg]

I was like a double agent from Kenshin-sama. My relationship with Shingen-sama will never be the same.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『山道』（夜）******************************************************

And a few days pass. I've been walking so much that I'm afraid I'm going to collapse. ......
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_13_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

I finally made it to Shingen-sama.
[cpg]

[OnName num="soldier_A"]
"You are ......!　Hey, who are you?
[cpg cn=true]


[OnName num="soldier_B"]
You're alive!　Oh my God, I have to tell Shingen-sama. ......
[cpg cn=true]



[SE f=se016]
;//【ＳＥ】『地面に倒れ込む』

I was so relieved that I just fell to the ground.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

The next time I woke up, I was in my room.
[cpg]

Shingen-sama was there. He had been by my side the whole time.
[cpg]

[OnName num="keitarou"]
Shingen-sama, it's been a long time.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen205"]
[OnName num="shingen"]
Yes, it's been a long time. It really has."
[cpg cn=true]


She said, almost in tears.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Singen206"]
[OnName num="shingen"]
I'm so glad you're all right. I thought you had already been killed.
[cpg cn=true]


[OnName num="keitarou"]
I'm not going to die so easily.
[cpg cn=true]


I was crying too, saying such baseless things.
[cpg]

I don't want to lose Shingen-sama, after all. I can't betray her here.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

There was only one thing for me to do.
[cpg]

Minimize the conflict between Shingen-sama and Kenshin-sama. That's all I can do.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Singen207"]
[OnName num="shingen"]
"...... Yes, that's right. Kenshin said that ......
[cpg cn=true]


[OnName num="keitarou"]
Yes, she said she would. She said he's on the defensive now.
[cpg cn=true]


I decided to inform them that we have well-developed defensive measures in place, while informing them that we have no intention of invading them.
[cpg]

If I went back to Kenshin-sama, I was going to say the same thing to her.
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Singen208"]
[OnName num="shingen"]
I will be relying on you," he said. I know I can count on you.
[cpg cn=true]


[OnName num="keitarou"]
I can go as many times as you want. I'm sure I'll be back sooner this time.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen209"]
[OnName num="shingen"]
I'm counting on you. I won't forgive you if you make me worry.
[cpg cn=true]


[OnName num="keitarou"]
Yes, I will. Yes, you can count on me.
[cpg cn=true]


I said, but my real intention is not just to go scouting.
[cpg]

I have to go back to Kenshin-sama and tell him the same thing over there.
[cpg]

It is my mission to avoid a clash between these two.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

There was not much time left before our next departure.
[cpg]

Shingen-sama also wants to resolve this situation.
[cpg]

But I couldn't let that happen.
[cpg]

I couldn't say I was on either Shingen's or Kenshin's side.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen210"]
[OnName num="shingen"]
I'm going to miss you. I will miss you.
[cpg cn=true]


[OnName num="keitarou"]
Don't worry. I won't leave without Shingen-sama.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Singen211"]
[OnName num="shingen"]
I believe you. Please come back safely.
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

After walking along the mountain path many times, my legs and back had become strong.
[cpg]

At the same time, I had the strength not to be discouraged by a little bit of walking.
[cpg]

I feel that my experience at Kenshin-sama's place helped me to grow up.
[cpg]


[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

I walked along the mountain path. It was a long walk, but I didn't think it was as hard as it used to be.
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_14_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

Then, I went back to Kenshin-sama's place again.
[cpg]

[OnName num="keitarou"]
"...... you're back again. ......"
[cpg cn=true]


I didn't think I'd be the one to do this, either.
[cpg]

It was just as Kenshin-sama wanted. It was as if she was controlling me.
[cpg]

But it's a ...... strange feeling, like it's all right.
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin209"]
[OnName num="kenshin"]
I'm glad you're back, Keitaro. I'm glad you're back, Keitaro.
[cpg cn=true]


[OnName num="keitarou"]
......I've sent word to Shingen-sama that he can't attack her.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin210"]
[OnName num="kenshin"]
I'm glad you're back, Mr. Keitaro. Well, you don't have to stop.
[cpg cn=true]


[OnName num="keitarou"]
I'm sorry. But for me, she's also ......
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin211"]
[OnName num="kenshin"]
I guess I am indebted to them in some way. "You served him, of course.
[cpg cn=true]


Then I said the same thing I had said at Shingen-sama's place, though I was mocking Kenshin-sama.
[cpg]

[OnName num="keitarou"]
Shingen-sama is on the defensive. If we attacked him now, we would probably be beaten back.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Kensin212"]
[OnName num="kenshin"]
I see. Is there any chance he will attack from the other side?
[cpg cn=true]


[OnName num="keitarou"]
"I think it is unlikely. I think it is unlikely. They are also wary that they may be on the defensive.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin213"]
[OnName num="kenshin"]
That's good. I will believe in them.
[cpg cn=true]


Kenshin-sama says so, but I wonder if he can ...... see through it all.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

Then I had to rest in the castle.
[cpg]

If I had stayed in one place, I wouldn't have had to go through all this trouble.
[cpg]

But now that it's come to this, I have no choice but to stick to my lie to the end.
[cpg]

[OnName num="kenshin_vassal"]
You are also in trouble. You must be scouting Shingen's place.
[cpg cn=true]


[OnName num="keitarou"]
Yes, well, ......
[cpg cn=true]


I'm sure Shingen-sama's vassals would say the same thing. It's a bat out of hell situation.
[cpg]

But ...... we have to do it now.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[BG f="b_14_3.ui" time=1500]
[WAIT time=3000]
[BG f="b_14_4.ui" time=1500]
[WAIT time=3000]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

I was worried that I wouldn't be able to make it through as is here.
[cpg]

Even if the truth is revealed, they won't kill me.
[cpg]

Even though I understood this, I had a hard time falling asleep. Then...
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin214"]
[OnName num="kenshin"]
I was in the middle of the night, and I was worried that I would not be killed. Can't you sleep?
[cpg cn=true]


[OnName num="keitarou"]
Kenshin-sama is the one. What's wrong?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Kensin215"]
[OnName num="kenshin"]
I'm still at loggerheads with Shingen. I can't stay calm when I think of what's to come.
[cpg cn=true]


[OnName num="keitarou"]
I'm sure you're right.
[cpg cn=true]


I kind of felt like I wasn't responding properly.
[cpg]

The lies I'm telling affect more than just her.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin216"]
[OnName num="kenshin"]
I am the one who is responsible for the lives of all of my subjects and the soldiers who fight under my command.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin217"]
[OnName num="kenshin"]
My life does not belong to me alone.
[cpg cn=true]


I cannot look her straight in the face. When I feel like that, I can't.
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Kensin218"]
[OnName num="kenshin"]
I want to protect you, too. I want to protect you.
[cpg cn=true]


[OnName num="keitarou"]
"......Kenshin-sama ......"
[cpg cn=true]


Kenshin-sama looked as if he was waiting for something.
[cpg]

In such a situation, doing nothing might have been the real betrayal.
[cpg]


;//ブラックアウト
[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

I kissed Kenshin-sama on the mouth.
[cpg]

I was feeling guilty, but I didn't hesitate.
[cpg]

;//移植前シーンカット

[OnName num="keitarou"]
I was so guilty, but I didn't hesitate to kiss him. I love you.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="sKensin006"]
[OnName num="kenshin"]
I am also the same way. I like you too.
[cpg cn=true]


Where did Kenshin-sama get his liking for me?
[cpg]

Maybe it was the fact that I came from the future, or the fact that I served Shingen and didn't hesitate to turn on him. ......
[cpg]

I think this is the first time he told me that he liked me.
[cpg]


;//移植前シーンカット

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

Me and Kenshin-sama were talking about what we were going to do.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Kensin275"]
[OnName num="kenshin"]
'What do you think, Keitaro-san?　Are you against attacking Shingen's place?
[cpg cn=true]


[OnName num="keitarou"]
I said, "As I said. Shingen-sama has made careful preparations.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin276"]
[OnName num="kenshin"]
"I see." "I see.
[cpg cn=true]


 Kenshin didn't feel like swallowing, but he seemed to believe.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿謙信』（朝）******************************************************

The balance of power between Kenshin-sama and Shingen-sama was such that I was manipulating them.
[cpg]

It was as if I was manipulating the generals behind their backs and controlling the war situation behind the scenes.
[cpg]

I had no choice but to do so. Once the war was over and we were in a cooperative relationship, the future would be altered.
[cpg]

If that happened, I didn't know what would happen to me.
[cpg]

If I am not born in the future, I might disappear.
[cpg]

On the other hand, if one of us wins, the future will still be changed.
[cpg]

I watched Shingen-sama and Kenshin-sama, who were in a precarious balance, so that they would not collapse.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[BG f="b_01_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『街』（昼）******************************************************

I have nothing special to do and come out to the castle town.
[cpg]

No one would be looking for him or her to fight. Not a single person thinks it can't be helped.
[cpg]

[OnName num="keitarou"]
"...... that's right. Is it natural?"
[cpg cn=true]


I can't help but think to myself. That's how much I know there is no point in fighting.
[cpg]

If that's the case, it would be better to cooperate with each other.
[cpg]

I didn't know if it was good to continue a situation where soldiers might die in the future for my own convenience.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin277"]
[OnName num="kenshin"]
You look distressed.
[cpg cn=true]


[OnName num="keitarou"]
Kenshin-sama,......, why are you here?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Kensin278"]
[OnName num="kenshin"]
I, too, am suffocating from being in the castle all the time.
[cpg cn=true]


Kenshin-sama approached me and I answered honestly.
[cpg]

[OnName num="keitarou"]
I am not looking for an end to the war, I am looking for stagnation.
[cpg cn=true]


[OnName num="keitarou"]
I can only say that there are circumstances that make it difficult for the war to end. ......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin279"]
[OnName num="kenshin"]
Why?　I know you are from the future, so why don't you tell me everything?
[cpg cn=true]


[OnName num="keitarou"]
......, yes.
[cpg cn=true]


[OnName num="keitarou"]
If Kenshin and Shingen cooperate, they will probably change the future.
[cpg cn=true]


[OnName num="keitarou"]
If that happens, we may be in a different era than the one I was in. If that happens, my existence may disappear too.
[cpg cn=true]


Kenshin-sama put his hand on his chin and thought.
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin280"]
[OnName num="kenshin"]
I see you've been thinking about that. But you needn't worry about it.
[cpg cn=true]


[OnName num="keitarou"]
'But,...... even with stagnation, there will be skirmishes.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Kensin281"]
[OnName num="kenshin"]
'Certainly, some may lose their lives there. But what is it that you cherish?
[cpg cn=true]


...... indeed it is. Nothing can replace one's own life.
[cpg]

Kenshin-sama might have felt the same way.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夕方）******************************************************

Kenshin-sama was aware of my distress. With her, I return to the castle again.
[cpg]

In person, he taught me about politics. He said he doesn't want to use me for mere intelligence, but ultimately wants to give me a heavier role.
[cpg]


;//ブラックアウト

Little by little, things are changing. The kind of change I was looking for, I could say.
[cpg]


;//移植前シーンカット

;//移植前シーンカット

;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

What if...? If Kenshin-sama and I were to have a child.
[cpg]

If that happened, it might be difficult for me to come and go from Shingen-sama's place.
[cpg]

But I thought that would be fine. I was ready to serve Kenshin-sama.
[cpg]

As a father, being away from the baby for so long might be a problem.
[cpg]

If so, I would have to stop serving Shingen-sama.
[cpg]


[window target=false]
[BG f="b_07_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

Still, I wanted to maintain a balance.
[cpg]

If I joined Kenshin-sama, the battle of Kawanakajima might be settled.
[cpg]

It was a matter of how I would handle the situation.
[cpg]

[OnName num="keitarou"]
Then, I'm off.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin337"]
[OnName num="kenshin"]
Yes. I hope you will come back with more information. Please be sure to come back.
[cpg cn=true]


[OnName num="keitarou"]
Of course. I'll take care of it.
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

I was used to this road by now. I no longer hesitated to walk along the road with no signs or anything.
[cpg]

If I didn't hesitate, I wouldn't waste my time.
[cpg]

I felt like I could do anything now.
[cpg]

Deceive Shingen-sama and avoid conflict with Kenshin-sama.
[cpg]

I thought I could do something that, if I thought about it calmly, would be quite difficult.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

Then, I would return to Shingen-sama once more.
[cpg]

He no longer collapsed on arrival as he had done before.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen212"]
[OnName num="shingen"]
'You have changed, my dear.
[cpg cn=true]


[OnName num="keitarou"]
It's ...... been a long time since I went into hiding with her.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Singen213"]
[OnName num="shingen"]
You seem strangely confident then.
[cpg cn=true]


[OnName num="keitarou"]
No, I don't.
[cpg cn=true]

[STOPBGM]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen214"]
[OnName num="shingen"]
I don't think so. And I've heard rumors about this.
[cpg cn=true]


After prefacing the rumor with a rumor, he mentioned that Kenshin-sama had given birth to a child.
[cpg]


;//下記のセリフ、台本では
;//「謙信が妊娠したらしいわね。彼女、独り身のはずなのだけど」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください

[FACE method="change_7" pos="2/3"]

[VOICE f="Singen215"]
[OnName num="shingen"]
I thought she was single.
[cpg cn=true]


I almost screamed out loud, but I held it in.
[cpg]

[OnName num="keitarou"]
"That's a ...... happy story," I said.
[cpg cn=true]


I almost shouted out loud, but I held myself and said, "That's  a happy story.
[cpg]

[FACE method="shake_7" pos="2/3"]

[VOICE f="Singen216"]
[OnName num="shingen"]
But I said, "What's so happy about it? You're supposed to be my enemy.
[cpg cn=true]


Shingen-sama had a point. Shingen-sama might actually be aware of all this.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『山道』（夜）******************************************************

I go back and forth between Shingen-sama's place and Kenshin-sama's place.
[cpg]

I was getting more and more unclear about who I was working for.
[cpg]

I'm the go-between for two people who are supposed to be enemies. This is the kind of thing that ......
[cpg]

This may be what women used to do in the past.
[cpg]

If the warlords were men, it might be women's role to restrain them.
[cpg]

And the two I'm interceding with now are women. Is it my role as a man to restrain them?
[cpg]

Thinking about this, I set out for Kenshin-sama's place.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（昼）******************************************************

Maybe Shingen-sama was right. I must have changed.
[cpg]

More specifically, I have changed a lot since my days in the modern world.
[cpg]

Meeting these women has strengthened me both physically and mentally.
[cpg]

I may have become more or less manly. I may be overconfident, but....
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se025]
;//【ＳＥ】『ふすま開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

When I returned to Kenshin-sama's place after a long absence, her belly was swollen.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Kensin338"]
[OnName num="kenshin"]
It's your child. You should name it.
[cpg cn=true]


[OnName num="keitarou"]
Why don't you name it ......?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin339"]
[OnName num="kenshin"]
It's all right. If it weren't for you, I would never have had a child.
[cpg cn=true]


[OnName num="keitarou"]
It's the same for me. It wouldn't have been possible without you.
[cpg cn=true]


What a repetition of the same argument, but Kenshin-sama decided to name the child.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

The lovely time passed slowly.
[cpg]

I never knew ...... whose child was in Kenshin-sama's belly.
[cpg]

All the vassals close to her knew, and I could have told them myself.
[cpg]

That is why Kenshin-sama and I officially became husband and wife.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And Kenshin-sama and Shingen-sama had stopped having major conflicts.
[cpg]

Of course, we never reconciled. Kenshin-sama understands that.
[cpg]

I think he is thinking of me.
[cpg]

I don't know how much he believes that I am from the future. ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin340"]
[OnName num="kenshin"]
I don't know how much you believe that I am from the future. How far into the future?"
[cpg cn=true]


[OnName num="keitarou"]
I said, "A tremendous amount, sir. You must be 500 years away.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Kensin341"]
[OnName num="kenshin"]
I see. It must be a good time.
[cpg cn=true]


[OnName num="keitarou"]
Yes. A peaceful time, easy to live in, no strife.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Kensin342"]
[OnName num="kenshin"]
Do you think you would like to return, Keitaro?
[cpg cn=true]


......I remembered what I heard when I first came here.
[cpg]

The first time I came here, I heard a lot of lore about this era.
[cpg]

I was told that a child born to a warlord and me might have magical powers.
[cpg]

Is the time of destiny approaching? If so, I must have an answer.
[cpg]


;//ブラックアウト

Her belly grows with time.
[cpg]

My original purpose was to return to the modern world or to make a place for myself in this time. ......
[cpg]

Now I could honestly rejoice in the fact that we had a child.
[cpg]


;//移植前シーンカット

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

That night we slept together.
[cpg]

I loved this time together more than anything.
[cpg]

I guess we will eventually become three people. Our child will be born. ......
[cpg]

It was truly unimaginable, but we were eager to see what the future held for us.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************

The battle between Shingen-sama and Kenshin-sama has yet to be settled.
[cpg]

I am sure it will never be settled.
[cpg]

[OnName num="keitarou"]
"......, the one who wears the robe of foreign lands."
[cpg cn=true]


[OnName num="keitarou"]
"I will give birth to a son who will eat the sky with the bond of a princess warlord. ......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin391"]
[OnName num="kenshin"]
What's wrong?　What is it?
[cpg cn=true]


[OnName num="keitarou"]
Haven't you ever heard of it, Kenshin-sama?　It's a legend from the first village I was in when I came to this time.
[cpg cn=true]


[OnName num="keitarou"]
My child and Kenshin-sama's child may have the power to transcend time.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Kensin392"]
[OnName num="kenshin"]
Now that you mention it, do you miss ...... your hometown?
[cpg cn=true]


[OnName num="keitarou"]
No, I don't. No, on the contrary. Even if I could go back to the future, I would never go back.
[cpg cn=true]


[OnName num="keitarou"]
I want to live with Kenshin-sama. I want to see it all through."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Kensin393"]
[OnName num="kenshin"]
"Thank you for ....... I am sure our children will be pleased."
[cpg cn=true]


Kenshin-sama had a peaceful expression on her face.
[cpg]

She is becoming a mother and I am becoming a father. It is not surprising that our way of thinking is changing.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

Days pass by. Her stomach grows bigger and bigger.
[cpg]

I was no longer returning to Shingen-sama.
[cpg]

I think she must have realized the truth.
[cpg]

I had always intended to stay by Kenshin-sama's side.
[cpg]

[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Kensin394"]
[OnName num="kenshin"]
"Keitaro-san. Look how much it has swelled.
[cpg cn=true]


[OnName num="keitarou"]
Yes. It's a strange thing about the female body, isn't it?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Kensin395"]
[OnName num="kenshin"]
I'm not a stranger to this. Soon you will be a father too.
[cpg cn=true]


;//移植前シーンカット

Looking back, the love started from a strange place.
[cpg]

Although we had always been enemies, Kenshin-sama and I were strangely attracted to each other.
[cpg]

I may have been called to this age for that reason, so that neither of us would be defeated in this battle.
[cpg]

[OnName num="keitarou"]
I hope this peace will last forever.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin421"]
[OnName num="kenshin"]
Not so much peace as ...... still, there is nothing better than no conflict, is there?"
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
Immediately after saying this, Kenshin-sama turned his head down.
[cpg]

[OnName num="keitarou"]
I said, "...... Kenshin-sama?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Kensin422"]
[OnName num="kenshin"]
I just had a fetal movement. The baby in my belly seems to be telling me that it is, too.
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

More months passed, and Kenshin-sama gave birth to a child with me.
[cpg]

I was relieved to hear that both mother and child were fine.
[cpg]

I ...... won't go back to the present day anymore. I decided to stay here forever.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿外観＿謙信』（昼）******************************************************

I don't know if our child has any magical powers.
[cpg]

But it didn't matter now.
[cpg]

I probably came to this time period to meet Kenshin-sama.
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ非エロ（座って、子供をあやすヒロイン。隣に主人公がいる）ev_63
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿縁側の通路
;//時間　：昼
;//備考　：子供は一歳に満たない赤ん坊です
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_63_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Kensin423"]
[OnName num="kenshin"]
'Okay, ...... phew, you look a bit like Keitaro-san.'
[cpg cn=true]


[OnName num="keitarou"]
'Is that so?　I feel like I look like Kenshin-sama."
[cpg cn=true]


;//＠
;//[VOICE f="Kensin424"]
;//[OnName num="kenshin"]
;//「その、謙信様というのはやめてくれませんか？　もう夫婦だというのに」
;//[cpg cn=true]

Perhaps it was because I had called them "Sama" even though they were now husband and wife, but Kenshin-sama seemed to be in a bit of a bad mood.
[cpg]

;//＠
;//[OnName num="keitarou"]
;//「確かにそうですが……慣れてしまって」
;//[cpg cn=true]

[OnName num="keitarou"]
'......I'm sorry,......I've gotten used to it.
[cpg cn=true]



[VOICE f="Kensin425"]
[OnName num="kenshin"]
Oh, my God. I'm going to call you out on it then. I'm sorry  for being so familiar with it.
[cpg cn=true]


[OnName num="keitarou"]
'Kenshin......-sama.'
[cpg cn=true]



[VOICE f="Kensin426"]
[OnName num="kenshin"]
...... this is going to take some time to fix."
[cpg cn=true]


Kenshin-sama laughed. He was not really angry.
[cpg]


[VOICE f="Kensin427"]
[OnName num="kenshin"]
He was not really angry. Not long ago, the castle was tense because of the battle with Shingen.
[cpg cn=true]



[VOICE f="Kensin428"]
[OnName num="kenshin"]
'No,...... even if there is another clash, with Keitaro,......
[cpg cn=true]


We may continue to run into hardships in the future.
[cpg]

But I am sure there is nothing to fear anymore.
[cpg]


;//ブラックアウト

;//ＥＮＤ　ヒロイン３ルート

[SCENE id=12]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="epend.ks" target="*start"]


;//==============================

