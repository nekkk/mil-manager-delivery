
*start

;//==============================
;//桶狭間の戦い　二度伏兵のマスを通った場合

*select03_lose|Battle of Okehazama

*root_4|Even though you know it's a betrayal.

;#################################################
*Ep005|Even though you know it's a betrayal.
;#################################################

[SCENE id=5]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I slipped away from the battlefield, partly because Mitsuhide-sama told me to.
[cpg]

In the end, I could not witness that moment when the decision was made, but ......
[cpg]

Nobunaga-sama had won the battle of Okehazama.
[cpg]

I was reminded once again of her talent. It would have been the same even if I had not been there.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

Nobunaga-sama won the battle, but he was not in a very good mood.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="3/3" time=800]

[VOICE f="Ranmaru450"]
[OnName num="ranmaru"]
It was a brilliant plan. I can only say that it was ...... quintessential for it to work so well.
[cpg cn=true]


[OnName num="keitarou"]
I couldn't fight to the ...... end. I'm sorry."
[cpg cn=true]


I had to be honest and apologize. Of course I should have been standing on the battlefield.
[cpg]



;//このセリフは削除
;//信長「私は不本意だ。景太郎が参戦しなかったからな」


I'm in a position where I'm just being kept alive.
[cpg]

[FACE method="change_1" pos="1/3"]

[VOICE f="Mituhide058"]
[OnName num="mitsuhide"]
Well, let Keitaro learn about politics.
[cpg cn=true]


[FACE method="change_6" pos="1/3"]

[VOICE f="Mituhide059"]
[OnName num="mitsuhide"]
That's one way to repay the favor, isn't it?
[cpg cn=true]


Mitsuhide-sama followed up. He's looking out for me ......
[cpg]

Or perhaps Mitsuhide-sama thinks that he has listened to me more than Nobunaga-sama.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

[OnName num="keitarou"]
"Thank you ....... For giving me a helping hand."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide060"]
[OnName num="mitsuhide"]
No, no, don't worry about this much."
[cpg cn=true]


Mitsuhide-sama was in a good mood in contrast to Nobunaga-sama.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide061"]
[OnName num="mitsuhide"]
I am glad that you are more attracted to me than to Nobunaga-sama.
[cpg cn=true]


After all, that's what it was all about. It seems that Mitsuhide-sama was watching to see if I would force myself to go into it.
[cpg]

Of course, there was a part of me that wanted to follow Mitsuhide-sama,.......
[cpg]

[OnName num="keitarou"]
'......I was also genuinely afraid to fight any longer.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide062"]
[OnName num="mitsuhide"]
He said, "Anything is fine. You are very important to me. I don't want to lose you."
[cpg cn=true]


Saying that, Mitsuhide-sama takes my hand. He turns to me. ......
[cpg]

Not knowing what that means, I look away.
[cpg]

No, I really know. Mitsuhide-sama also cares about me.
[cpg]

This time, I'm doing what Mitsuhide-sama says. It is ......
[cpg]


It could have meant that Mitsuhide-sama was more important than Nobunaga-sama.
[cpg]

[OnName num="keitarou"]
Don't stare at me so much.
[cpg cn=true]


Mitsuhide-sama heard my words and never let go of my hand.
[cpg]

[FACE method="shake_2" pos="2/3"]

 Rather, he even told me to stare at him.
[cpg]


;//ブラックアウト

[SE f=se000]
;//【ＳＥ】『通路歩く』

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And then Mitsuhide-sama pulled me by the hand and brought me to his room.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_09"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide063"]
[OnName num="mitsuhide"]
Mr. Keitaro," he said, "you have received a great deal from Nobunaga-sama. Nobunaga-sama likes you a lot, doesn't he?
[cpg cn=true]


[OnName num="keitarou"]
Yes, yes. ...... well.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide064"]
[OnName num="mitsuhide"]
"That's not why he likes you so much. ......
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

She says, puts her lips to mine while holding my hand.
[cpg]

I was so surprised that I pulled away.
[cpg]

[OnName num="keitarou"]
What are you trying to do?
[cpg cn=true]


Mitsuhide-sama was coming on to me. Is she trying to take it in her hands from me, who is favored by Nobunaga-sama?
[cpg]

If you want to shoot the general, shoot the horse first,.......
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide065"]
[OnName num="mitsuhide"]
I'm not going to run away from you.
[cpg cn=true]


[OnName num="keitarou"]
That's ...... what I'm trying to say.
[cpg cn=true]


I was not entirely satisfied with my decision. In part, I did not go into battle, thinking back on Mitsuhide-sama's words.
[cpg]


;//ブラックアウト

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide066"]
[OnName num="mitsuhide"]
Nobunaga-sama would never do something like this.
[cpg cn=true]


[OnName num="keitarou"]
That, of course, is ......
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide067"]
[OnName num="mitsuhide"]
I'm sure he would. I would have done anything for him.
[cpg cn=true]



;//移植前シーンカット

I held on to the feeling that wouldn't subside, and decided to ask her to leave.
[cpg]

As expected, the relationship is suddenly too short.
[cpg]

[OnName num="keitarou"]
I told her, "...... you need to take better care of yourself."
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide094"]
[OnName num="mitsuhide"]
I'm trying to. Well, if you don't like it, I'll change my mind.
[cpg cn=true]



[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

Another day. I saw Mitsuhide-sama taking care of his bonsai.
[cpg]

[OnName num="keitarou"]
He is very enthusiastic. Is bonsai really that interesting?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide095"]
[OnName num="mitsuhide"]
Yes. It looks to me as if it represents the rise and fall of the world.
[cpg cn=true]


The rise and fall of the world. She seemed to see such things.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Mituhide096"]
[OnName num="mitsuhide"]
......What do you think?　Do you think Nobunaga-sama will win the kingdom as it is?
[cpg cn=true]


Mitsuhide-sama asked while tending to the bonsai trees.
[cpg]

[OnName num="keitarou"]
Yes.
[cpg cn=true]


I answer that, but then I know Mitsuhide-sama will betray me.
[cpg]

Only I and Mitsuhide-sama, who is about to rebel, know everything.
[cpg]

As I was thinking this, Mitsuhide-sama looked around. After confirming that no one was there, he said
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide097"]
[OnName num="mitsuhide"]
I know somehow that you are aware of my rebellion. You know that I am trying to start a rebellion.
[cpg cn=true]


He told me everything.
[cpg]

[OnName num="keitarou"]
That is."
[cpg cn=true]


I flinched, but I couldn't deny it.
[cpg]

I can't say anything. I don't even know how to answer correctly.
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Mituhide098"]
[OnName num="mitsuhide"]
I do not know where you have come from. And you are being unusually wary of me.
[cpg cn=true]



;//下記のセリフ、台本では
;//「何か、魔法めいた力で、景太郎さんは未来を知っているようだ。違いますか」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください

[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide099"]
[OnName num="mitsuhide"]
Keitaro seems to know the future. Isn't that right?
[cpg cn=true]


You are almost right. Like Nobunaga-sama, he is quite sharp.
[cpg]

Ranmaru-sama didn't even notice it until here: ......
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide100"]
[OnName num="mitsuhide"]
I'm sure he's not the only one. There, he smells just like me."
[cpg cn=true]


He touches close to my true feelings.
[cpg]

I certainly couldn't tell Mitsuhide-sama that I would betray him.
[cpg]

If I did, Mitsuhide-sama would be executed. I was afraid that some evidence might come out.
[cpg]

[OnName num="keitarou"]
......How far do you see through him?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide101"]
[OnName num="mitsuhide"]
'Not as far as Nobunaga-sama, but mostly. But if it were true, I would like you even more.
[cpg cn=true]


I didn't argue with anything. It is true that I care about Mitsuhide-sama.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide102"]
[OnName num="mitsuhide"]
I was actually feeling a little uneasy about it. But with you on my side, I can do anything.
[cpg cn=true]


Mitsuhide-sama stopped tending the bonsai and took my hand.
[cpg]

What was impressive was that his hand was trembling.
[cpg]

He suddenly shows his weakness. He seemed to be afraid of defying Nobunaga-sama.
[cpg]

[OnName num="keitarou"]
"Mitsuhide-sama ......"
[cpg cn=true]


This is Mitsuhide-sama's act. It may all be an act.
[cpg]

;//＠それでもこのままでは折れてしまいそうな光秀様を見て、俺は心を動かされた。
I was moved to see Mitsuhide-sama who looked like he was going to break down if things continued as they were.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************


;//☆
;//[VOICE f="sMitsuhide001"]
;//[OnName num="mitsuhide"]
;//「……景太郎さん。私は貴方のことを、好きなのだと思います」
;//[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
I told Mitsuhide-sama that I really like him.
[cpg]

He even goes so far as to say that. Mitsuhide-sama looks serious.
[cpg]

[OnName num="keitarou"]
You shouldn't say such a thing lightly.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide104"]
[OnName num="mitsuhide"]
'Do I sound like I am saying it lightly?　I will say it as many times as I have to until it sounds serious.
[cpg cn=true]


[OnName num="keitarou"]
' "......"
[cpg cn=true]


Mitsuhide-sama came up to my ear and whispered. I had mixed feelings about this.
[cpg]


;//移植前シーンカット

It's not that I don't have any feelings for Mitsuhide-sama. Of course that is true.
[cpg]

It is nothing but love. But even so, I was still indebted to ...... Nobunaga-sama.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Mituhide129"]
[OnName num="mitsuhide"]
Is something wrong?　Keitaro, you look like you're in some kind of pain.
[cpg cn=true]


[OnName num="keitarou"]
No,.......
[cpg cn=true]


And Mitsuhide-sama knows he will fight Hideyoshi and lose.
[cpg]

No matter who you choose, Nobunaga-sama or Mitsuhide-sama, you will not be able to spend the rest of your life together.
[cpg]

Even though I feel impermanent, I ......
[cpg]

[OnName num="keitarou"]
Mitsuhide-sama. I love you, too.
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

I chose Mitsuhide-sama. She was a little surprised and then seemed happy.
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide130"]
[OnName num="mitsuhide"]
She was a little surprised and then happy. Thank you.
[cpg cn=true]



;//移植前シーンカット

I had a feeling that Mitsuhide-sama was trying to use this love to control me.
[cpg]

I don't think this would have happened if I was completely in control of my emotions.
[cpg]

That's how fascinated I had become with her.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide152"]
[OnName num="mitsuhide"]
I love you, ...... Keitaro. We will always be together."
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


She was attracted to me because Nobunaga-sama liked me.
[cpg]

It is possible that all of these are the result of calculation.
[cpg]

But knowing that, I couldn't stay away from her.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

In the end, will I be a traitor too?
[cpg]

I can say that as long as I can't stop Mitsuhide-sama, I'm just as guilty.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru451"]
[OnName num="ranmaru"]
...... Keitaro, huh? You're not looking so good.
[cpg cn=true]


[OnName num="keitarou"]
"Ranmaru-sama, ...... it's nothing."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru452"]
[OnName num="ranmaru"]
I hope so. You and Mitsuhide have been spending a lot of time together lately.
[cpg cn=true]


I'm sure you'll be fine. ...... The actuality that you can't get a good deal more than a few of these.
[cpg]

[OnName num="keitarou"]
I'm sure Ranmaru-sama hasn't noticed.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru453"]
[OnName num="ranmaru"]
No. No, that's nothing. I just thought, "How can you go out with a guy like that?"
[cpg cn=true]


[OnName num="keitarou"]
Does Mitsuhide-sama look like that?
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Ranmaru454"]
[OnName num="ranmaru"]
He smiles a lot, but it doesn't look like he's really smiling.
[cpg cn=true]


That's how it would appear to me. I know the truth of it all, and I know what Mitsuhide-sama thinks to a certain extent. ......
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『街』（夕方）******************************************************

The castle town in the evening. Nobunaga-sama had brought me here.
[cpg]


;//下記のセリフ、台本では「街」ですがシナリオでは「町」になっています

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga670"]
[OnName num="nobunaga"]
"Take a look. I have never seen such a peaceful town.
[cpg cn=true]


[OnName num="keitarou"]
I'm sure you have. By the time Nobunaga-sama was born, the war had probably already begun.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga671"]
[OnName num="nobunaga"]
Yes, but it is about to be over. But that is about to be over.
[cpg cn=true]


Nobunaga-sama did not seem to doubt that.
[cpg]

In fact, there is still one more upheaval to come. Nobunaga-sama would be involved in it.
[cpg]

I just couldn't bring myself to say it out loud.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

Even though I went back to my room and tried to rest, I was feeling somewhat restless.
[cpg]

What do Mitsuhide-sama and I want to do from now on?
[cpg]

Even she should not live long. Is it really okay to follow her?
[cpg]

On the other hand, even after the Honnoji Incident, she will probably continue to try to take over the country.
[cpg]

I can't stop her from doing so. I was thinking that way.
[cpg]


[VOICE f="Mituhide153"]
[OnName num="mitsuhide"]
"Keitaro-san, it's me. It's me.
[cpg cn=true]


[OnName num="keitarou"]
Oh, please come in to ......."
[cpg cn=true]



[SE f=se025]
;//【ＳＥ】『ふすま開く』


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]


Mitsuhide-sama had arrived.
[cpg]

[OnName num="keitarou"]
Can't you sleep?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide154"]
[OnName num="mitsuhide"]
I can't help thinking about the future. But I think I can do it with you.
[cpg cn=true]


Of course I am sure of that. I am going to be on Mitsuhide-sama's side.
[cpg]

But you can't change your fate. Mitsuhide-sama can't take down the heavens......
[cpg]

Then there is only one way for us to be happy.
[cpg]

Betray Nobunaga-sama. This is the only way since we cannot change the future by any means.
[cpg]

On top of that, we need to stay out of the way of trying to take over the country. Otherwise, Mitsuhide-sama will die.
[cpg]

[OnName num="keitarou"]
......"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide155"]
[OnName num="mitsuhide"]
You are thinking something. Right now, you don't need to think about anything else."
[cpg cn=true]


Mitsuhide-sama said so, but I had mixed feelings.
[cpg]

I need to tell him the only way for us to be happy sooner or later. But.
[cpg]

After betraying Nobunaga-sama, would I be able to convince her?
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide156"]
[OnName num="mitsuhide"]
"Keitaro, look at me. Look at me.
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

Mitsuhide-sama says so and comes closer to me. And then he kissed me.
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide157"]
[OnName num="mitsuhide"]
'...... the future, you know. Even I am not at peace with it.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide158"]
[OnName num="mitsuhide"]
But I'm still happy to be with you.
[cpg cn=true]


;//移植前シーンカット

I was captivated by her. There was no doubt about it.
[cpg]

Mitsuhide-sama says he likes me, but I think he's really pushing it a bit.
[cpg]

She's trying to hold me together by using even love.
[cpg]

Knowing that, I can't shake her off.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

As the days go by, I learn more and more about politics from Nobunaga-sama's retainer.
[cpg]

Nobunaga-sama probably thinks that there will be a peaceful world in the future.
[cpg]

In fact, if she took the reigns and kept it that way, it might even be possible. ......
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

Eventually, Nobunaga-sama unified the country.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="3/3" time=800]


[VOICE f="Nobunaga672"]
[OnName num="nobunaga"]
"......It's been a long time so far, hasn't it?"
[cpg cn=true]


[FACE method="bow_2" pos="3/3"]

[VOICE f="Ranmaru455"]
[OnName num="ranmaru"]
I've been waiting a long time for this. But you finally got your wish.
[cpg cn=true]


Nobunaga-sama looks at Mitsuhide-sama. Mitsuhide-sama was still smiling.
[cpg]

[FACE method="bow_2" pos="1/3"]

[VOICE f="Mituhide181"]
[OnName num="mitsuhide"]
I am happy to be your vassal.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga673"]
[OnName num="nobunaga"]
I see. I, too, am happy to have such an excellent vassal.
[cpg cn=true]


Nobunaga-sama was laughing, but I don't know if he was really laughing or not.
[cpg]

I was also thinking about how to stand my ground.
[cpg]

If I were to live with Mitsuhide-sama, what kind of path would I take?
[cpg]

I would be betraying Nobunaga-sama and Ranmaru-sama, at least.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga674"]
[OnName num="nobunaga"]
'Keitaro doesn't seem ...... too happy about it.
[cpg cn=true]


[OnName num="keitarou"]
No, sir. I am pleased."
[cpg cn=true]


It's no wonder they can see right through me here. I'll make up a smile, but I'm sure he'll see right through me.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

The most recent Mitsuhide-sama sometimes wanted to have a child with me.
[cpg]

If he's going to start a rebellion from now on, he won't want to have a child in his belly. ......
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Mituhide182"]
[OnName num="mitsuhide"]
'I won't be able to live quietly from now on. I want to have a child with you while I still can."
[cpg cn=true]


[OnName num="keitarou"]
"...... I see."
[cpg cn=true]


What is she going to do? Is there any doubt about her own life?
[cpg]

I can't just tell her everything. I had mixed feelings.
[cpg]


;//移植前シーンカット

Despite her cold-hearted nature, she has been showing me unsparing affection.
[cpg]

I don't know where her true feelings lie. I suppose it is because Nobunaga-sama trusts me to some extent.
[cpg]

I can understand why she wants to keep me on her side. It might also make it easier to start a rebellion. But ......
[cpg]

I wonder if she is really acting with that kind of calculation.
[cpg]

[OnName num="keitarou"]
I think she is really acting on such a calculation. Are you really going to betray Nobunaga-sama?
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Mituhide204"]
[OnName num="mitsuhide"]
Yes, I am. What's wrong?
[cpg cn=true]


Mitsuhide-sama said so without any hesitation.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Mituhide205"]
[OnName num="mitsuhide"]
I will have Ranmaru die as well. It is not safe to let her live.
[cpg cn=true]


He did not show any sign of this terrible nature in front of Nobunaga and the others.
[cpg]

The Honnoji Incident was about to occur.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Mituhide206"]
[OnName num="mitsuhide"]
......I really don't want to betray you."
[cpg cn=true]


Yes, she is. Why is she trying to betray us in the first place?
[cpg]

[OnName num="keitarou"]
"Mitsuhide-sama, are you ...... trying to take over the country yourself?"
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Mituhide207"]
[OnName num="mitsuhide"]
No. No. My real goal is to restore the Shogunate. I do not seek to rise to the top.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide208"]
[OnName num="mitsuhide"]
Do you know that I once served Yoshiaki Ashikaga?
[cpg cn=true]


[OnName num="keitarou"]
No, I never heard of .......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Mituhide209"]
[OnName num="mitsuhide"]
Yoshiaki-sama gave the order, this whole thing.
[cpg cn=true]


Does this mean that for Mitsuhide-sama, he is someone to follow more than Nobunaga-sama?
[cpg]

 However, I have nothing to say.
[cpg]

I don't care what the reason is. Does she adore this Ashikaga Yoshiaki more than Nobunaga-sama?
[cpg]

Or does she think that Nobunaga-sama's reign will not continue as it is?
[cpg]

That is irrelevant now. It's the same no matter what intention the rebellion has.
[cpg]

I could not say anything for fear of altering the future.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

Whether Mitsuhide-sama's will changes or I persuade him, the future will be altered in the end.
[cpg]

No matter what the plan is, it will be the same.
[cpg]

Nobunaga-sama is destined to die. So is Ranmaru-sama. ......
[cpg]

When you change that, it will probably be a future in which I am not born.
[cpg]

It would be the same for my family and others. I have to avoid that by all means.
[cpg]

So, I had no choice but to keep my mouth shut.
[cpg]

If there was anything I could change, it would be about Mitsuhide-sama's future.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide210"]
[OnName num="mitsuhide"]
It's a beautiful night, isn't it? It's quiet.
[cpg cn=true]


[OnName num="keitarou"]
......Yes."
[cpg cn=true]



;//ブラックアウト

She didn't say a word, but moved slowly toward me.
[cpg]


;//========================================
;//●ＣＧ（主人公の体に手を突いているヒロイン）ev_34
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿縁側の通路
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



And I didn't refuse her.
[cpg]


[VOICE f="Mituhide211"]
[OnName num="mitsuhide"]
I've never really been at peace.
[cpg cn=true]



[VOICE f="Mituhide212"]
[OnName num="mitsuhide"]
No matter how much Nobunaga-sama praised me, no matter how much I did for him, I felt empty.
[cpg cn=true]


[OnName num="keitarou"]
Of course it was.
[cpg cn=true]



[VOICE f="Mituhide213"]
[OnName num="mitsuhide"]
You, on the other hand, know my true nature, but somehow you have remained silent.
[cpg cn=true]



[VOICE f="Mituhide214"]
[OnName num="mitsuhide"]
Nothing could be a greater source of support to me than you."
[cpg cn=true]


She is fearless, or rather, she does not hesitate to talk about betraying Nobunaga-sama in front of me.
[cpg]

Maybe she really wants to be noticed.
[cpg]

Maybe she wants someone to stop her.
[cpg]

But I couldn't tell what she was really thinking, because it was hidden under layers of secrecy.
[cpg]

[OnName num="keitarou"]
She was saying, "Mitsuhide-sama, I wonder what you are thinking. I still don't know what you are thinking.
[cpg cn=true]


;**【ＣＧ】 ev_34_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Mituhide238"]
[OnName num="mitsuhide"]
'I'm sure you do. I don't think you can find what I myself am about to lose sight of.
[cpg cn=true]


I am sure that ...... she has too many complicated circumstances.
[cpg]

And Mitsuhide-sama was smart enough to overlap them all and make them add up.
[cpg]

I thought this was the result of acting with my head and not my heart.
[cpg]

If only she could get her heart back once more ......
[cpg]

I was thinking, "What a pity, but I don't know if it's a problem for me to be discouraged there.
[cpg]


;//移植前シーンカット

;//ブラックアウト

;//qwe

[window target=false]
[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

[OnName num="keitarou"]
"I'm starting to lose ...... track of what I want to ...... do, too.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide239"]
[OnName num="mitsuhide"]
I don't think it's going to work out. It's not going to work. Just living in the moment.
[cpg cn=true]



;//移植前シーンカット

;//ブラックアウト

;//移植前シーンカット

This was the last time I would be able to make love to her peacefully. The time of doom was already approaching.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

This would be the last time I would see Nobunaga-sama and Ranmaru-sama.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Nobunaga675"]
[OnName num="nobunaga"]
I'm going to have to go to ...... and see what's going on. You seem even gloomier than usual."
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


I couldn't even answer that it was nothing.
[cpg]

I couldn't reveal everything here.
[cpg]

[FACE method="shake_7" pos="4/5"]

[VOICE f="Ranmaru456"]
[OnName num="ranmaru"]
I can't reveal everything here. Nobunaga-sama, let's go.
[cpg cn=true]


Ranmaru-sama seems to be Ranmaru-sama today. Compared to Nobunaga-sama and Mitsuhide-sama, he is dull.
[cpg]

But this is the last time we will see her like that.
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="Nobunaga676"]
[OnName num="nobunaga"]
Keitaro. I don't know what's happening to you, but cheer up.
[cpg cn=true]


I couldn't even respond to her words.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


It was a bad night. I felt like I was going to be sucked into the darkness.
[cpg]

There was nothing to do but to do nothing, and it seemed as if I was being driven to do nothing.
[cpg]


[VOICE f="Mituhide285"]
[OnName num="mitsuhide"]
......This would bring about the re-establishment of the Shogunate."
[cpg cn=true]


Honnoji was burning red. I left Nobunaga and Ranmaru behind.
[cpg]

 Despite the feeling of guilt, I didn't understand my true intentions either.
[cpg]

There is no one else but Mitsuhide-sama. I think I have no choice but to be happy with her.
[cpg]

But ...... that road is not easy either.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

The next day and night, Mitsuhide-sama was surrounded by only her allies.
[cpg]

Of course he is. If anyone had even the slightest loyalty to Nobunaga-sama, she would be in danger.
[cpg]

[OnName num="keitarou"]
"......It's very careful, isn't it? Did you think of everything, including how you would behave?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide286"]
[OnName num="mitsuhide"]
I think that once I decide to do something like this, I am quick from there. I don't think I'm thorough.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Mituhide287"]
[OnName num="mitsuhide"]
I don't know if I'm the one who decides what I'm going to do.
[cpg cn=true]


Mitsuhide-sama must be going through a lot of conflicts.
[cpg]

They're working on ideas that I can't even imagine.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide288"]
[OnName num="mitsuhide"]
"I have good news for you, ...... more than that. I saw a doctor the other day,......."
[cpg cn=true]


Mitsuhide-sama rubbed his belly and told me that he was expecting a child.
[cpg]

I wasn't exactly happy about it. I know what is to come.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

From there, the other generals moved to surround Mitsuhide-sama.
[cpg]

At this rate, it was only a matter of time before Mitsuhide-sama would be killed.
[cpg]

At least that's the historical fact I know, though.
[cpg]

It's strange, I feel like there's some time left.
[cpg]

Normally, Mitsuhide-sama would not be treated as a person who once took over the country.
[cpg]

The time that she survived the rebellion must have been that short.
[cpg]

As I thought, it was a little different from the history I knew.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

Mitsuhide-sama's stomach was growing. Four months have passed since she gave birth to the child.
[cpg]

I'm still alive, she's still alive. I don't know how much time I have left.
[cpg]

I wonder what Mitsuhide-sama is thinking right now.
[cpg]

I am sure he is aware of my feelings, but the person I fear the most is Mitsuhide-sama himself.
[cpg]


;//ブラックアウト

[window target=false]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

I still had mixed feelings.
[cpg]

I wondered if I should love her for killing Nobunaga-sama and Ranmaru-sama.
[cpg]

And she herself will not be safe from now on.
[cpg]

[OnName num="keitarou"]
I think it might be better to tell Mitsuhide-sama everything.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Mituhide293"]
[OnName num="mitsuhide"]
I think so. I'd be glad if you would reveal it to me since it seems that you still have some secrets from me.
[cpg cn=true]


I knew I didn't want to lose her. There was only one thing I could do for that.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Mituhide317"]
[OnName num="mitsuhide"]
I think I'm going to run into Hideyoshi," she said. And in the not-too-distant future, too.
[cpg cn=true]


[OnName num="keitarou"]
I see.
[cpg cn=true]


Perhaps she will die there.
[cpg]

I know that's not supposed to be acceptable ...... but that's the historical fact.
[cpg]

I wonder how much I'm allowed to reveal.
[cpg]

Nobunaga-sama said he didn't want to know about the future, but what about Mitsuhide-sama?
[cpg]

What about Mitsuhide? If he knew about his own death, he would probably try to avoid it.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夕方）******************************************************

I was troubled. I was troubled, but the answer had to come soon.
[cpg]

There is no one to consult. Nobunaga-sama and Ranmaru-sama are no longer in this world.
[cpg]

It was Mitsuhide-sama who killed them. It was unbelievable.
[cpg]

If you don't betray, you will be betrayed; if you don't kill, you will be killed. I know it's that kind of time.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[window target=true]


...... and I made a decision.
[cpg]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide318"]
[OnName num="mitsuhide"]
What is it? You want to talk to me?"
[cpg cn=true]


[OnName num="keitarou"]
"Yes,...... I wanted to tell you everything I know."
[cpg cn=true]


Mitsuhide-sama was indeed serious. He probably thinks he can finally hear the truth from me.
[cpg]

[OnName num="keitarou"]
I'm from the future. You won't believe it, but it's true.
[cpg cn=true]


[OnName num="keitarou"]
And I can't change the future in any significant way.
[cpg cn=true]


In fact, I've worked so hard to keep the future the same.
[cpg]

[FACE method="bow_7" pos="2/3"]

[VOICE f="Mituhide319"]
[OnName num="mitsuhide"]
It's ...... hard to believe, but then it makes sense that he knew I was going to betray him and kept quiet about it.
[cpg cn=true]


Mitsuhide-sama seemed to be satisfied. I continue.
[cpg]

[OnName num="keitarou"]
If things continue as they are, Mitsuhide-sama will lose to Hideyoshi. Do you intend to escape even now?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide320"]
[OnName num="mitsuhide"]
No, I don't. But if I win in the future, you'll be in trouble. 
[cpg cn=true]


You are right. If the future changes, it could mean that I would not be born.
[cpg]

[OnName num="keitarou"]
If I don't do this, the future will change. Maybe it will be a world in which I will never be born.
[cpg cn=true]


I continued speaking. I couldn't just stand by and watch.
[cpg]

[OnName num="keitarou"]
If it comes to war, I will stop you at all costs.
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Mituhide321"]
[OnName num="mitsuhide"]
I see. But there is only one thing for me to do.
[cpg cn=true]


Still, it seemed that Mitsuhide-sama's intention had not changed.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Mituhide322"]
[OnName num="mitsuhide"]
'It is too much of a sacrifice to turn back now. I have no intention of surrendering the kingdom to Hideyoshi now."
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Am I, after all, unable to stop Mitsuhide-sama?
[cpg]

I wondered if there was nothing I could do. ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

I tried to persuade Mitsuhide-sama many times and talked about what I was going to do.
[cpg]

But Mitsuhide-sama's resolve seemed firm.
[cpg]

[OnName num="keitarou"]
He said, "...... Are you going to fight, no matter what?
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Mituhide323"]
[OnName num="mitsuhide"]
Yes. I just have to.
[cpg cn=true]


;//ブラックアウト

;//移植前シーンカット
[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

I went straight to sleep with her.
[cpg]

There was not much time left. I suppressed my impatience and thought that I must not let him know my true feelings.
[cpg]

My true intention was to let Mitsuhide-sama escape even if I had to kidnap him.
[cpg]


[window target=false]
[BG f="b_07_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

And in the morning,......, I was the one who woke up first.
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ微エロ（事後。二人で同じ布団に入っている。眠そうにしながら目を覚ますヒロイン）ev_53
;//人物１：ヒロイン４　服装１：裸
;//人物ex：主人公　　　服装ex：裸
;//場所　：城＿室内
;//時間　：朝
;//備考　：ヒロインは妊娠六ヶ月くらいです
;//========================================


[BGM f="bg_09"]
;**【ＣＧ】 ev_53_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Mituhide348"]
[OnName num="mitsuhide"]
"Nn...... morning?"
[cpg cn=true]


[OnName num="keitarou"]
Yes. Please get up.
[cpg cn=true]


;//＠二人とも、裸のまま眠ってしまっていた。
We had both fallen asleep naked.
[cpg]

This peaceful time is about to be taken away from us.
[cpg]

It's an irresistible feeling. I want to protect her at all costs.
[cpg]


[VOICE f="Mituhide349"]
[OnName num="mitsuhide"]
You look scared. Do you have something on your mind?
[cpg cn=true]


[OnName num="keitarou"]
"I've told you everything I have to say.
[cpg cn=true]



[VOICE f="Mituhide350"]
[OnName num="mitsuhide"]
"Don't worry. I won't lose.
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


I had nothing to say back.
[cpg]

I'm sure there's nothing more I can say. Then ......
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

I planned to do so.
[cpg]

Some of the soldiers were more likely to follow me than Mitsuhide-sama.
[cpg]

Even if they didn't, they would understand if I explained the whole situation to them. ...... No.
[cpg]

No one would believe something so outlandish as coming from the future?
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Mituhide351"]
[OnName num="mitsuhide"]
"...... what are you trying to do?"
[cpg cn=true]


[OnName num="soldier_A"]
I'm sorry. For now, please follow Keitaro-sama.
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]

[VOICE f="Mituhide352"]
[OnName num="mitsuhide"]
What do you mean? Mr. Keitaro.
[cpg cn=true]


[OnName num="soldier_B"]
......
[cpg cn=true]


There were three of us, including me. That's the minimum number of people we need to keep her from escaping.
[cpg]

[OnName num="keitarou"]
I'm leaving the castle. I have no choice but to do this."
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

I took Mitsuhide-sama and fled from the castle.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Mituhide353"]
[OnName num="mitsuhide"]
I'm sure it's pointless. Once I'm gone, everyone will notice, and they will come after me.
[cpg cn=true]


[OnName num="keitarou"]
I can't give up on you, even so. I don't want to give up on you."
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夕方）******************************************************

We couldn't move fast. After all, Mitsuhide-sama is pregnant.
[cpg]

Even if you say you are going to run away, it is only a matter of time before they catch up with you.
[cpg]

But still, I couldn't do nothing.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Mituhide354"]
[OnName num="mitsuhide"]
If ...... you are so adamant about it, I may really be losing it!
[cpg cn=true]


[OnName num="keitarou"]
Yes, I know. According to the history I know, the next person to take the reigns is Hideyoshi.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Mituhide355"]
[OnName num="mitsuhide"]
But we cannot run away now. As I said before, I have sacrificed too much."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

[OnName num="mitsuhide_vassal"]
There he is!　Over here!
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


The escape attempt did not last a day. They caught up with us that night.
[cpg]

I think we had bought enough time, but people of this era are very fast on their feet.
[cpg]

While thinking this, I also realized that it was still impossible to keep running away forever.
[cpg]

Maybe there is nothing I can do after all.
[cpg]

I was filled with such a feeling of helplessness.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

They took me to the castle, and when I returned, it was morning.
[cpg]

Mitsuhide-sama must have known about everything. Still, he thinks there is no way I can escape now.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Mituhide356"]
[OnName num="mitsuhide"]
There won't be a next time. If you do the same thing again, I will even have to execute you."
[cpg cn=true]


Mitsuhide-sama would not be able to leave those who tried to flee with his lord.
[cpg]

Saying so in front of the soldiers was also a deterrent to me.
[cpg]

The next time he tries to kidnap Mitsuhide-sama, he will probably really intend to execute him.
[cpg]

It seemed that I now had to weigh my life against Mitsuhide-sama's life.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

What a surprise. There was no need to weigh the scales.
[cpg]

My will had already been decided. Mitsuhide-sama's life was much heavier than mine.
[cpg]

It was true from her vassal's point of view, and it was even more so from mine.
[cpg]

How about from her own point of view?　I can't imagine that much, but ......
[cpg]

But I thought everything was fine with this.
[cpg]


;//ブラックアウト

When I thought I was going to die, I still couldn't stop shaking.
[cpg]

But I was happy that I had met something more important than myself.
[cpg]

Love with Mitsuhide-sama is not something that can be replaced by such ...... someone else.
[cpg]

It was the same when compared to my own life.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************

[OnName num="keitarou"]
"...... this way. Mitsuhide-sama."
[cpg cn=true]


I was about to take Mitsuhide-sama out again.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Mituhide357"]
[OnName num="mitsuhide"]
He said, "...... you are a man who never changes. I knew you wouldn't break so easily.
[cpg cn=true]


[OnName num="keitarou"]
I'm not going to kill you," he said. You can kill me if you want.
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]

[VOICE f="Mituhide358"]
[OnName num="mitsuhide"]
I am not saying this as a threat either. I'm not saying this as a threat either.
[cpg cn=true]


Mitsuhide-sama says to me with a pained expression, almost in tears.
[cpg]

[OnName num="keitarou"]
It doesn't matter. Your vassals will catch up with me anyway, but I cannot bear to lose you without doing something about it."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Mituhide359"]
[OnName num="mitsuhide"]
He says, "I see. I don't want to say goodbye to you.
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I try to take Mitsuhide-sama away for the second time.
[cpg]

This was a statement that I was willing to be killed.
[cpg]

The second time, too, the second time to take out Mitsuhide will not come true in the end. I know that.
[cpg]

I will be executed. I know that, too.
[cpg]

[OnName num="mitsuhide_vassal"]
Do you, ......, realize what you have done?
[cpg cn=true]


[OnName num="keitarou"]
I understand. If you don't know, you can't do it.
[cpg cn=true]


[OnName num="mitsuhide_vassal"]
It is a shame to lose you. But it is inevitable now.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide360"]
[OnName num="mitsuhide"]
That's enough. I'm sure Keitaro doesn't want to pretend it never happened.
[cpg cn=true]


[OnName num="keitarou"]
"......Yes."
[cpg cn=true]


I didn't run and hide. In exchange for my life, if I could get even a small message to her.
[cpg]

Or, if it didn't reach her, if it didn't mean I let her die for nothing.
[cpg]

Really, that's all I needed. ......
[cpg]


;//背景と別の場所なので、上下に黒帯を入れるなどしてください

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

They took me back and locked me in a cell.
[cpg]

The day of my execution was approaching. Strangely, I felt calm.
[cpg]

I never saw Mitsuhide-sama's face again.
[cpg]

It must have been hard for her to see me. That was all right.
[cpg]


;//ホワイトアウト
[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1100]

I am not afraid of anything. The scariest thing is not being able to make up my mind.
[cpg]

I'm ...... all right with this.
[cpg]

[window target=false]
[WAIT time=1000]

;//ここから一人称ではなく三人称に変わります
;//文章を画面中央に表示するなどして、雰囲気を変えてください


;//ゆっくりとブラックアウト
[BG f="black.ui" time=1000]
[WAIT time=1000]

[STOPBGM]
[WAIT time=1000]
[window target=true]


After .......
[cpg]

After Keitaro was executed, Mitsuhide had a child.
[cpg]

While seeing in the child the image of Keitaro, Mitsuhide fought bravely.
[cpg]


[VOICE f="Mituhide361"]
[OnName num="mitsuhide"]
"...... Keitaro. Me too ......."
[cpg cn=true]


Now that Keitaro was gone, he had no hesitation in winning this battle.
[cpg]

He clashed with Hideyoshi with all his might, but Mitsuhide was defeated.
[cpg]


[VOICE f="Mituhide362"]
[OnName num="mitsuhide"]
I, myself, am not afraid of anything."
[cpg cn=true]


Because Keitaro was not there, Mitsuhide was able to fight with all his might.
[cpg]

Mitsuhide had no regrets if he could not win after giving it his all.
[cpg]


;//ＥＮＤ　ヒロイン４ルート

[SCENE id=11]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="epend.ks" target="*start"]

