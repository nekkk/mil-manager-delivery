
*start

;//==============================
;//２、信玄に仕える

*select_root23|Loyalty to Shingen-sama.

;#################################################
*Ep006|Loyalty to Shingen-sama.
;#################################################
;//ブラックアウト

[SCENE id=6]


[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]


[OnName num="keitarou"]
I am ......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen074"]
[OnName num="shingen"]
What am I? Let me hear your answer."
[cpg cn=true]


I thought it was better to be with Shingen than to be with Nobunaga.
[cpg]

She would not have been killed in battle if the historical facts were true.
[cpg]

As I recall, she died of illness. The battle with Kenshin was also inconclusive, wasn't it? ......
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="4/5" time=800]

[VOICE f="Ranmaru457"]
[OnName num="ranmaru"]
What ...... are you seriously talking about?"
[cpg cn=true]


Ranmaru-sama was surprised, but I was determined.
[cpg]

[OnName num="keitarou"]
I'm going to serve Shingen-sama. I will serve Shingen-sama.
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]

[VOICE f="Singen075"]
[OnName num="shingen"]
I'm glad you've made up your mind. You've made up your mind.
[cpg cn=true]


[FACE method="change_3" pos="4/5"]

[VOICE f="Ranmaru458"]
[OnName num="ranmaru"]
I've been following you to stop you. You know what that means?
[cpg cn=true]


[FACE method="change_3" pos="4/5"]

[VOICE f="Ranmaru459"]
[OnName num="ranmaru"]
Even if you and I don't become enemies, I can't leave you alone.
[cpg cn=true]


[OnName num="keitarou"]
But you're not going to kill me, are you?
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
For me, it's a decisive decision. I'm sure Ranmaru-sama knows that.
[cpg]

[OnName num="keitarou"]
Don't worry, I won't attack Nobunaga-sama. I will not attack Shingen-sama.
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru460"]
[OnName num="ranmaru"]
"You'll regret it. Keitaro.
[cpg cn=true]


But Ranmaru-sama said nothing more.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

From that day on, I was to serve Shingen-sama.
[cpg]

Ranmaru-sama left. I would not see her again for a while.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen076"]
[OnName num="shingen"]
She said, "Truly, you are a mind-reader, aren't you? I wonder if she felt sorry for me.
[cpg cn=true]


[OnName num="keitarou"]
I don't understand why you came so close to me. Why?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen077"]
[OnName num="shingen"]
I don't know. I don't think love at first sight will convince you.
[cpg cn=true]


Shingen-sama looked into the distance.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen078"]
[OnName num="shingen"]
I am determined to live. I'm a man who is determined to live, as anyone would be in this day and age.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen079"]
[OnName num="shingen"]
I'll say it. I'm not attracted to you or anything.
[cpg cn=true]


[OnName num="keitarou"]
I'm not attracted to you or anything. ......
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Singen080"]
[OnName num="shingen"]
I'm just saying that I need more friends. But that's all.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Singen081"]
[OnName num="shingen"]
I hear ...... that you have some strange rumors and I can't leave you alone.
[cpg cn=true]


Perhaps it is important to Shingen-sama that she knows the future.
[cpg]

She is more aware of death than most people are.
[cpg]

I had nothing to say to her when she said she didn't like me that way.
[cpg]

It was natural. I could even say, "That's fine.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen082"]
[OnName num="shingen"]
I'm sickly, so I've given up on children, but I'll do these things to keep ...... you together."
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

Shingen-sama then put his lips to mine.
[cpg]

[OnName num="keitarou"]
'...... this is not a good place to be.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Singen083"]
[OnName num="shingen"]
'Would it be better if it wasn't in a place like this?'
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I kiss her. I made sure she was there.
[cpg]

;//移植前シーンカット
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

The bond between me and Shingen-sama is becoming stronger ...... than ever, and I'm slowly getting to know her personality.
[cpg]

She is still pessimistic and has given up on children. I wanted to encourage her somehow.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen136"]
[OnName num="shingen"]
I wondered if she was ever going to be on the battlefield.
[cpg cn=true]


[OnName num="keitarou"]
What do you mean?　Do you want me to be a soldier?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Singen137"]
[OnName num="shingen"]
I don't want to be a soldier. I want you to become a military commander worthy of me.
[cpg cn=true]


Shingen had fought Kenshin for a long time.
[cpg]

The so-called battle of Kawanakajima. Shingen must have fought to the death many times.
[cpg]

[OnName num="keitarou"]
Shingen-sama will remain in the future. ......
[cpg cn=true]


I thought I had slipped up.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Singen138"]
[OnName num="shingen"]
I thought I had slipped up, but then I said, "So you're from the future, after all. I've heard rumors."
[cpg cn=true]


I was doubly surprised. One, that you know about it, and two, that you believe it.
[cpg]

[OnName num="keitarou"]
He said, "...... believe me? You believe this?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen139"]
[OnName num="shingen"]
Yeah, I thought so. I thought you weren't thinking outside the box.
[cpg cn=true]


When I came to this time, I couldn't tell anyone but Nobunaga-sama that I was from the future.
[cpg]

But Shingen-sama believed me right away. That made me somewhat happy.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Then, a few months passed. Another war was about to break out.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『戦場』（昼）******************************************************

It is known even today that Shingen-sama's talent as a military commander is considerable.
[cpg]

And it was the same for Kenshin.
[cpg]

[OnName num="keitarou"]
'...... I can't believe I'm going to do this.'
[cpg cn=true]


I was to be in the battlefield too. As a commander.
[cpg]

Shingen-sama has taught us the basics of how to get around on the battlefield.
[cpg]

They are excellent soldiers. He even told me that in the worst case scenario, I wouldn't have to do anything.
[cpg]

But that doesn't mean I should just take their word for it.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f=se019]
;//【ＳＥ】『つばぜり合い』
[WAIT time=1100]

I was able to achieve a certain amount of military success, but the battle was never settled.
[cpg]

Is it strange that the battle was so easily settled?
[cpg]

It was a battle that would go down in Japanese history. It is also famous as a battle that could not be settled.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen140"]
[OnName num="shingen"]
You're doing a great job, aren't you?
[cpg cn=true]


[OnName num="keitarou"]
"...... No. My hands still shake at the thought of me killing people.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Singen141"]
[OnName num="shingen"]
I know. I can't do it when I feel like a murderer.
[cpg cn=true]


Shingen-sama seemed to be guessing what I was thinking.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen142"]
[OnName num="shingen"]
I wonder if there is war in your world?
[cpg cn=true]


[OnName num="keitarou"]
No, it was peaceful. No, it's peaceful. I'd like to take Shingen-sama back to that time.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
Shingen smiled.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

Shingen's words had not changed much since then.
[cpg]

You can't have children with me. Even if I could, would I be safe after giving birth?
[cpg]

And even if not, he said that he could die at any time.
[cpg]

It was not that it was depressing to listen to him. Rather, it made me think.
[cpg]

I began to think about how to use my life after coming to this age.
[cpg]


[window target=false]
[BG f="b_13_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

Then, one day in the afternoon. A little out of the castle, I heard this story from Shingen-sama.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen143"]
[OnName num="shingen"]
He said, "I am going to hire a ninja. What do you think?
[cpg cn=true]


[OnName num="keitarou"]
"...... Ninja, huh?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Singen144"]
[OnName num="shingen"]
You know a lot about ninja. You know a lot about ninjas.
[cpg cn=true]


I ponder. I have the knowledge that Shingen Takeda was the feudal lord who employed the most ninjas in the Warring States period.
[cpg]

[OnName num="keitarou"]
I think ...... is good.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen145"]
[OnName num="shingen"]
"Yes," he said. If you say so, I wonder if the ninjas were effective to some extent.
[cpg cn=true]


I don't have the detailed knowledge of that area.
[cpg]

I couldn't give you an immediate answer, but as long as it's in history, it must have worked to some degree.
[cpg]

[OnName num="keitarou"]
Wasn't there something very similar to a ninja, the Garden Keeper ......, in the Warring States period?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Singen146"]
[OnName num="shingen"]
I don't know, and I have never heard of it. I don't know, and I have never heard of it.
[cpg cn=true]


I tell Shingen-sama, wondering if that was only in the Edo period.
[cpg]

[OnName num="keitarou"]
I tell Shingen, wondering if that was in the Edo period. They are the people who do espionage.
[cpg cn=true]


Ninjas, courtiers, and various other forms of spy-like people have been passed down to the future.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen147"]
[OnName num="shingen"]
'...... Right,' he says, 'I've decided. I've made up my mind."
[cpg cn=true]


Hearing this, Shingen-sama seemed to have made up his mind.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Singen148"]
[OnName num="shingen"]
If I'm going to do espionage, I think you're the right person for the job. You know the future.
[cpg cn=true]


[OnName num="keitarou"]
"Me?" he said.
[cpg cn=true]


I was torn.
[cpg]

If I become an intelligence agent here, I could be captured and taken in by Kenshin's side.
[cpg]

If you want to stay close to Shingen-sama, it is better not to accept it.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen149"]
[OnName num="shingen"]
What do you think? Will you head for Kenshin's place?
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


I thought about whether or not to accept the offer, and I gave my answer.
[cpg]



;//１、受け入れる２、受け入れない　があった場所　必要無し　このままシナリオは進行


[OnName num="keitarou"]
I understand. If you want me to be a secret agent, I will be.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen150"]
[OnName num="shingen"]
You answer right away," he said. That's reassuring.
[cpg cn=true]


I decided to accept the job. I wanted to follow Shingen-sama's words, even though I wondered if I would be able to do the job.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

From that day on, I began to prepare.
[cpg]

I would have to leave Shingen-sama's place once. Even though that was inevitable, ......
[cpg]

I could not fail to prepare for my eventual return.
[cpg]

I've led troops and fought as a commander before.
[cpg]

Considering that, there's no reason ...... for this, but I'm still nervous.
[cpg]

[OnName num="keitarou"]
I've got no choice but to do it,.......
[cpg cn=true]


I'm not going to be able to do anything else. I have no choice but to respond to it.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

Shingen-sama had already hired ninjas. I'm the first to join up with them.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen151"]
[OnName num="shingen"]
He is the leader of the ninja. He's a good one to a certain extent.
[cpg cn=true]


[OnName num="ninja"]
How do you do? The man who is joining us, Keitaro-sama, is you, isn't it?
[cpg cn=true]


They seemed to have some respect for me, as I had originally stood on the battlefield.
[cpg]

[OnName num="keitarou"]
...... who are these people?"
[cpg cn=true]


[OnName num="ninja"]
They are Kunoichi.
[cpg cn=true]


They are not dressed like that. They were dressed somewhere between a traveler and a priestess.
[cpg]

Upon closer inspection, it seemed that the kunoichi were lurking around as walking miko, priestesses who did not belong to a shrine.
[cpg]

[OnName num="keitarou"]
That's not what I know, is it?
[cpg cn=true]


[OnName num="ninja"]
That may be so," he said. But I intend to pass on to you everything I know.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen152"]
[OnName num="shingen"]
That's very encouraging. I think it will be a good experience for Keitaro.
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


He will learn things that are different from what he knows, and he will learn how to be a clandestine ninja.
[cpg]

I guess it is not about using ninjutsu like in the manga.
[cpg]

He will just have to keep in mind not to be found or noticed.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

Although he did not go directly to Kenshin's place for a while, the time would eventually come for him to infiltrate.
[cpg]

[OnName num="keitarou"]
I guess we will have to say goodbye to you for a while.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen153"]
[OnName num="shingen"]
"Yes. Yes. Make sure you come back alive.
[cpg cn=true]


I regret to say goodbye. Shingen-sama must have felt the same way.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen154"]
[OnName num="shingen"]
Hey. I have a favor to ask you.
[cpg cn=true]


[OnName num="keitarou"]
What is it?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="sSingen001"]
[OnName num="shingen"]
"It's something only you can do."
[cpg cn=true]


Shingen-sama brought a kimono. A kimono, or rather, this.
[cpg]

[OnName num="keitarou"]
Is it a ninja costume?
[cpg cn=true]


Shingen-sama nodded. I wondered what she was going to do with it. ......
[cpg]

She started to ask to see me change into this.
[cpg]

[OnName num="keitarou"]
Shingen-sama, you are not planning to go there as a ninja yourself, are you?"
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
When I asked, she shook her head.
[cpg]

She was simply interested in such costumes.
[cpg]

I guess she is a woman, too. I guess she wants people to see her dressed differently than usual. ......
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（忍び装束のヒロイン。座っている）ev_56
;//人物１：ヒロイン２　服装１：忍装束
;//場所　：城＿室内
;//時間　：夜
;//========================================

[SE f=se001]
;//【ＳＥ】『衣擦れ』

[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_56_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]



I leave the room once and go back in after she finishes changing.
[cpg]

Shingen-sama looked a little embarrassed.
[cpg]

[OnName num="keitarou"]
'It suits you.
[cpg cn=true]


I don't know if I can say that. But she seemed happy.
[cpg]

Shingen-sama says she' s willing to do whatever it takes to get my attention.
[cpg]

I was looking at her, wondering if that was what she meant after all.
[cpg]


;**【ＣＧ】 ev_56_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSingen002"]
[OnName num="shingen"]
I looked at her and said, "I'm covering my ...... face, so I can't kiss you in this outfit."
[cpg cn=true]


When I saw her smiling at me like that, I wanted to protect her.
[cpg]


;//移植前シーンカット
;//【ＢＧ】『城＿室内』（夜）
;//ブラックアウト
;//移植前シーンカット

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

I couldn't talk enough with Shingen-sama no matter how much I talked to him.
[cpg]

But the day was already approaching when I would be on my way to Kenshin's place.
[cpg]

I decided once again that I would return home alive.
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

And so, I headed for the castle where Kenshin lived.
[cpg]

I would find out how he marched, or I would assassinate Kenshin himself.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen203"]
[OnName num="shingen"]
Be a good soldier.
[cpg cn=true]


[OnName num="keitarou"]
Yes. I will return the favor.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Singen204"]
[OnName num="shingen"]
As with espionage, don't forget that you owe me a debt of gratitude if you return alive.
[cpg cn=true]


[OnName num="keitarou"]
I understand. Well then.
[cpg cn=true]


I left with the ninjas.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

The ninjas who were walking along the mountain path were very fast.
[cpg]

I had thought this before, but the people of this time were fast walkers.
[cpg]

[OnName num="ninja"]
I thought to myself, "Are you tired already? If you want to take a rest, you'd better say so quickly.
[cpg cn=true]


[OnName num="keitarou"]
I said, "No, I'm fine. I'm fine.
[cpg cn=true]


To a certain extent, they had to push themselves, thinking it was to build up their physical strength.
[cpg]


[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

Sleeping in the middle of the mountain path is also something I am still not used to.
[cpg]

The ninjas take turns keeping watch. I was not part of it.
[cpg]

Everyone was looking out for me. I guess it was partly because I had served Shingen-sama directly.
[cpg]

I felt ashamed of myself, but at the same time I knew that I would make a difference.
[cpg]


[window target=false]
[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

A few days passed. I finally made it to the castle.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

[OnName num="ninja"]
We're going to break in. Are you ready, Mr. Keitaro?
[cpg cn=true]


[OnName num="keitarou"]
Yes, I am. I'll try not to drag my feet.
[cpg cn=true]


[OnName num="ninja"]
Very well. If push comes to shove, there's a chance I'll leave you behind.
[cpg cn=true]


[OnName num="ninja"]
The reverse is also true. If we make a mistake, you can just run away.
[cpg cn=true]


[OnName num="keitarou"]
"...... Yes."
[cpg cn=true]


We have no choice. There is no turning back now.
[cpg]


;//ブラックアウト


;//※ストーリーが分岐
;//　勝利した場合、ヒロイン２ルートへ
;//　敗北した場合、ヒロイン３ルートへ


;//伏兵の代わりに「音の鳴るマス」という部分があります
;//伏兵と同様、二度通ることで敗北判定となります
;//音の鳴るマスは、２、３、７、８に配置されています

;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※謙信の所へ潜入　開始時（１のマスにいる場合のシナリオ）※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※

;//ブラックアウト

;//[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_07"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

;//ヒロイン３の立ち絵を表示してください

Heading to Kenshin's place, I hide in the attic of the castle where she lives.
[cpg]

There is a part where the material seems to be different,......, the direction of the east.
[cpg]

I wonder if there was such a thing as "ugui-bari" in this time period.
[cpg]

Is there a possibility that she might have planted it in the attic? We proceeded with caution.
[cpg]


;//■選択肢
[switch]
[case "Proceed to the south."]
	[swap]
	[jump target="*select04_4"]
[case "Go to the east."]
	[swap]
	[jump target="*select04_2"]
[endswitch]

1. Proceed to the south.
2, advance east.


;//==============================
;//１、南へ進む

;//同じイベント中の「４のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「２のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※２のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_2|Loyal to Shingen-sama.

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン３の立ち絵を表示してください

[SE f=se029]
;//【ＳＥ】『木材きしむ』

;//qwe
[stflag Selectflg4=1]


I hear the wood creak. I stop in a panic.
[cpg]

Kenshin, who is just below me, is looking up at me. I can see him through the gap: ......
[cpg]

There is no light from this side, so I should not be able to see him.
[cpg]

But I can hear the sound. It's best to be on the alert.
[cpg]


;//■選択肢
[switch]
[case "Proceed to the south."]
	[swap]
	[jump target="*select04_5"]
[case "Proceed to the east."]
	[swap]
	[jump target="*select04_3"]
[endswitch]

1, going south.
[cpg]

Two, proceed east.
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「３のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※３のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_3|Loyal to Shingen-sama.

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン３の立ち絵を表示してください

[if exp={getFlagValue("Selectflg4") == 1 }]
[jump target="*select04_3_t"]
[endif]

[jump target="*select04_3_f"]


;//==============================
;//２のマスか７のマスを通っている場合

*select04_3_t|Loyalty to Shingen-sama.

[SE f=se029]
;//【ＳＥ】『木材きしむ』

[WAIT time=1000]

[FACE method="change_3" pos="2/3"]

Kenshin looks at me again.
[cpg]

I see him calling for people. At this rate, we may not even make it back.
[cpg]

[OnName num="keitarou"]
'This isn't good. ......
[cpg cn=true]


Hiding in the attic, I might even lose my escape route.
[cpg]

I decided to get out while I still can.
[cpg]


;//敗北判定となる
;//「謙信の所へ潜入　二度音の鳴るマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン３ルートへ続く

[jump target="*select04_lose"]


;//==============================
;//２のマス、７のマスいずれも通っていない場合

*select04_3_f|Loyalty to Shingen-sama.


[SE f=se029]
;//【ＳＥ】『木材きしむ』

[stflag Selectflg4=1]

[WAIT time=1000]

[FACE method="change_7" pos="2/3"]

I heard the wood creak. I panicked and stopped.
[cpg]

Kenshin, who is just below me, is looking up at me. I can see him through the gap: ......
[cpg]

There is no light from this side, so I should not be able to see him.
[cpg]

But I can hear the sound. It's best to be on the alert.
[cpg]


;//■選択肢
[switch]
[case "Proceeding to the south"]
	[swap]
	[jump target="*select04_6"]
[endswitch]

1. Proceed south.
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※４のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_4|Be loyal to Shingen-sama.

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

Proceed cautiously so as not to make a sound.
[cpg]

Listen and listen for Kenshin. ......
[cpg]

Now the floor is changing color in the direction to the south. We must be careful.
[cpg]


;//■選択肢
[switch]
[case "Proceeding to the south"]
	[swap]
	[jump target="*select04_7"]
[case "Proceed to the east"]
	[swap]
	[jump target="*select04_5"]
[endswitch]

1, going south
[cpg]

2, proceeding to the east.
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「７のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※５のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_5|Loyalty to Shingen-sama.

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

I hear Kenshin talking to himself. Maybe he is trying to call someone.
[cpg]

Is that because he senses my presence, or is he talking to someone about the upcoming battle?
[cpg]

If it is the latter, I can't help but listen.
[cpg]


;//■選択肢
[switch]
[case "Proceed south."]
	[swap]
	[jump target="*select04_8"]
[case "Proceed to the east."]
	[swap]
	[jump target="*select04_6"]
[endswitch]

1, go south.
[cpg]

Two, proceed east.
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※６のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_6|Loyalty to Shingen-sama.

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

Finally, we have reached a point where we can catch a glimpse of Kenshin up close.
[cpg]

I can't let up until the end. I'm going slowly. ......
[cpg]


;//■選択肢
[switch]
[case "Proceeding south"]
	[swap]
	[jump target="*select04_9"]
[endswitch]

1, advance to the south
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※７のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_7|Loyalty to Shingen-sama.

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン３の立ち絵を表示してください

[SE f=se029]
;//【ＳＥ】『木材きしむ』

[stflag Selectflg4=1]

[WAIT time=1000]

[FACE method="change_7" pos="2/3"]


I hear the wood creak. I stop in a hurry.
[cpg]

Kenshin, who is just below me, is looking up at me. I can see him through the gap: ......
[cpg]

There is no light from this side, so I should not be able to see him.
[cpg]

But I can hear the sound. It is best to be on the lookout.
[cpg]


;//■選択肢
[switch]
[case "Proceed to the east."]
	[swap]
	[jump target="*select04_8"]
[endswitch]

One, advance east.
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※８のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_8|Loyalty to Shingen-sama.

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン３の立ち絵を表示してください

[if exp={getFlagValue("Selectflg4") == 1 }]
[jump target="*select04_8_t"]
[endif]

[jump target="*select04_8_f"]


;//==============================
;//２のマスか７のマスを通っている場合

*select04_8_t|Loyalty to Shingen-sama!

[SE f=se029]
;//【ＳＥ】『木材きしむ』

[WAIT time=1000]

[FACE method="change_3" pos="2/3"]

Kenshin looks at me again.
[cpg]

I see him calling for people. At this rate, we may not even make it back.
[cpg]

[OnName num="keitarou"]
'This isn't good. ......
[cpg cn=true]


Hiding in the attic, I might even lose my escape route.
[cpg]

I decided to get out while I still can.
[cpg]


;//敗北判定となる
;//「謙信の所へ潜入　二度音の鳴るマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン３ルートへ続く

[jump target="*select04_lose"]


;//==============================
;//２のマス、７のマスいずれも通っていない場合

*select04_8_f|Loyalty to Shingen-sama.


[SE f=se029]
;//【ＳＥ】『木材きしむ』

[stflag Selectflg4=1]

[WAIT time=1000]

[FACE method="change_7" pos="2/3"]


I heard the wood creak. I panicked and stopped.
[cpg]

Kenshin, who is just below me, is looking up at me. I can see him through the gap: ......
[cpg]

There is no light from this side, so I should not be able to see him.
[cpg]

But I can hear the sound. It is best to be on the lookout.
[cpg]


;//■選択肢
[switch]
[case "Proceed to the east."]
	[swap]
	[jump target="*select04_9"]
[endswitch]

One, advance east.
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※９のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_9|Loyalty to Shingen-sama.



;//勝利判定

;//謙信の所へ潜入　勝利した場合
;//と書いてあるところまで飛ぶ（ヒロイン２ルートに入る


[jump target="*select04_win"]



*select04_lose
[jump storage="ep007.ks" target="*start"]



*select04_win
[jump storage="ep008.ks" target="*start"]

