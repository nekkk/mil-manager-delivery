
*start

;//==============================
;//謙信の所へ潜入　勝利した場合

*select04_win|

*root_2|To see each other again

;#################################################
*Ep008|To see each other again.
;#################################################

[SCENE id=8]


[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_07"]


;//【ＢＧ】『城＿室内』（夜）


Kenshin called his retainers, not knowing I was there, and told them various things.
[cpg]

I can say that my goal has been achieved. With this, the battle with Kenshin could be settled.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

I have learned what I needed to know. There was no need to linger.
[cpg]

It was not my role to assassinate him, nor did I have to.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『山道』（朝）******************************************************

I had achieved my goal. She didn't seem to notice me, so there was no way she was lying.
[cpg]

I walked back to Shingen-sama in high spirits.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

When I returned to her place, she praised me.
[cpg]

I was happy just to hear her say, "You did a good job.
[cpg]

It was worth risking my life. ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

Shingen-sama kept me by his side.
[cpg]

Of course, it doesn't mean that he is there for nothing. I would think about what I could do.
[cpg]

Shingen-sama's subjects taught me how to stand on the battlefield, politics, and so on.
[cpg]


[window target=false]
[BG f="b_13_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

I have much to learn. In this era, there is common sense of this era.
[cpg]

Learning something was more fulfilling than just spending my days in idleness.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

In the midst of such days, a few irregularities sometimes occur.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Ranmaru461"]
[OnName num="ranmaru"]
You ...... are not going back to Nobunaga-sama's place?
[cpg cn=true]


Ranmaru-sama was visiting me and Shingen-sama.
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Singen218"]
[OnName num="shingen"]
What are you going to do?　I'm going to stay.
[cpg cn=true]


[OnName num="keitarou"]
No,...... I will not return to Nobunaga-sama.
[cpg cn=true]


I shook my head. Ranmaru-sama looked frustrated.
[cpg]

[FACE method="change_3" pos="4/5"]

[VOICE f="Ranmaru462"]
[OnName num="ranmaru"]
Nobunaga-sama is still waiting for you.
[cpg cn=true]


[OnName num="keitarou"]
Shingen-sama is the same way. He needs me.
[cpg cn=true]


Ranmaru-sama was not ready to give up.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

I've never been needed so much before.
[cpg]

I'm from the future, but I've never been treated so well.
[cpg]

So, when I told Shingen-sama about this…
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen219"]
[OnName num="shingen"]
He said, "That's not all. You have a mysterious charm.
[cpg cn=true]


She came very close to me as she answered, "I'm sure you're right.
[cpg]


;//========================================
;//●ＣＧ（主人公の体に両手を突いているヒロイン）ev_69
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_69_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="keitarou"]
I said to her, "...... is that right?"
[cpg cn=true]


I feel like everyone is saying that, but what is it about me that is so fascinating?
[cpg]

It seems to me that it's just because I come from a different era.
[cpg]

[OnName num="keitarou"]
I don't feel like I'm living up to anyone's expectations. And yet, Ranmaru-sama is trying to bring me back.
[cpg cn=true]



[VOICE f="Singen220"]
[OnName num="shingen"]
I agree. Maybe you should have more confidence.
[cpg cn=true]


[OnName num="keitarou"]
What do you mean by ......?
[cpg cn=true]



[VOICE f="Singen221"]
[OnName num="shingen"]
"You fight well on the battlefield. You should be aware that you are only as good as your reputation.
[cpg cn=true]


Her eyes seemed to be telling us that she was in an unusual state of mind.
[cpg]


;//移植前シーンカット

All the vassals are aware of our relationship. I guess you could say it's not a problem. ......
[cpg]

But I'm sure they're jealous. I have to work to make up for it.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

Another war with Kenshin was about to begin.
[cpg]

I was to stand on the battlefield as a general and lead the soldiers.
[cpg]

[OnName num="keitarou"]
Shall we go?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Singen248"]
[OnName num="shingen"]
Yes. Let's see each other again, safe and sound.
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（昼）******************************************************

Together, we had nothing to be afraid of.
[cpg]

Shingen-sama and I may be far away from each other, but our hearts are one.
[cpg]


[STOPBGM]
[window target=false]
[BG f="b_09_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（夕方）******************************************************

[SE f=se019]
;//【ＳＥ】『剣戟』

I realized that I had become stronger as a military commander.
[cpg]

As I fought for Shingen-sama, he gradually gained the upper hand in the battle with Kenshin.
[cpg]

If things continue as they are, history will be a little different from what I know.
[cpg]

As I recall, this battle was supposed to be inconclusive.
[cpg]

However, the battle may be tilted because of me.
[cpg]

If the future is altered, I don't know what will happen. I might not exist at all.
[cpg]

In order to prevent this, I was manipulating the war situation ...... just in time to prevent Kenshin from being defeated.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen249"]
[OnName num="shingen"]
He said, "...... you are really doing a great job. You have a talent for warfare."
[cpg cn=true]


[OnName num="keitarou"]
I am not a match for Shingen-sama. I'm no match for Shingen-sama.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen250"]
[OnName num="shingen"]
I am not surprised. I would be in trouble if there were a general better than me so easily.
[cpg cn=true]


I see. It's so much a warlord that he has left his name in the future, right?
[cpg]


;//ブラックアウト

;//移植前シーンカット
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

Time is running out. The battle that could not be settled continued.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen280"]
[OnName num="shingen"]
The ninja I sent out to fight have returned, and it looks like the next battle will be an all-out war.
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


An all-out battle. Does this mean that either Shingen-sama or Kenshin-sama will be defeated?
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Singen281"]
[OnName num="shingen"]
Next time, it will decide whether I or Kenshin will perish.
[cpg cn=true]


I was ready to give up everything for Shingen-sama.
[cpg]

[OnName num="keitarou"]
Shingen-sama, I am with you. I am with you.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen282"]
[OnName num="shingen"]
Thank you. I said before that I wasn't attracted to you, but I take that back.
[cpg cn=true]


They have done me a certain amount of favor. That was something I already knew.
[cpg]

It's one thing to keep fighting for Shingen-sama.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen283"]
[OnName num="shingen"]
I was thinking, "...... Nice sunset. Whenever the sun sets, I always wonder if today's sunset will be the last.
[cpg cn=true]


Even someone as good as Shingen-sama could get scared.
[cpg]

Still, I didn't want to see her looking anxious.
[cpg]

[OnName num="keitarou"]
'That won't happen, my dear. As long as I'm here.'
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Singen284"]
[OnName num="shingen"]
'I want eternal life. If I survive this battle, will I be able to get that too?
[cpg cn=true]


[FACE method="bows_4" pos="2/3"]

[VOICE f="Singen285"]
[OnName num="shingen"]
But even if I win this battle, ...... kehoh, kohoh.
[cpg cn=true]


[OnName num="keitarou"]
"Are you all right, Shingen-sama? Shingen-sama.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Singen286"]
[OnName num="shingen"]
"...... even if I win this battle with Kenshin, I won't win against the disease after all.
[cpg cn=true]


;//ブラックアウト

;//移植前シーンカット

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The more you want to cherish it, the sooner time will pass. The day of the decisive battle is fast approaching.
[cpg]

A contradictory situation where the only way for us to be at peace is to fight.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

I wish I had met her in, say, the present day, not in this time.
[cpg]

Tuberculosis would have been cured. There is no end to what I can imagine.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『戦場』（朝）******************************************************

And then, the day of the battle.
[cpg]

[FG f="CHA02_p3_02_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Singen314"]
[OnName num="shingen"]
I said, "I can do it, I'm going. I'll finish it today."
[cpg cn=true]


[OnName num="keitarou"]
"Yes. I'll leave it to you.
[cpg cn=true]


But I could not let the battle end.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（昼）******************************************************

[SE f=se019]
;//【ＳＥ】『剣戟』

If the battle was settled, history would change, so I used my judgment to control the situation.
[cpg]

And the battle with Kenshin ended without being settled in the end. ......
[cpg]

Still, I must have inflicted a lot of pain on him.
[cpg]

If anything, Shingen-sama continues to have the advantage.
[cpg]

He was on the verge of losing the battle if he tilted any further, and Kenshin would lose.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Singen315"]
[OnName num="shingen"]
Shingen was just on the verge of losing the battle. You did a wonderful job.
[cpg cn=true]


[OnName num="keitarou"]
Thank you.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Singen316"]
[OnName num="shingen"]
But there is something unnatural about it. How could the battle have gone so far and not been settled?
[cpg cn=true]


[OnName num="keitarou"]
That's .......
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen317"]
[OnName num="shingen"]
I know most of it. You'll be in trouble when it's all settled.
[cpg cn=true]


I listened to her, unable to say anything back.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen318"]
[OnName num="shingen"]
If you're from the future, you've got some kind of situation I can't imagine, I'm sure.
[cpg cn=true]


[OnName num="keitarou"]
I'm sorry, ......."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Singen319"]
[OnName num="shingen"]
Don't be sorry. Don't be sorry. I'm grateful.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen320"]
[OnName num="shingen"]
Thank you. Really, it's thanks to you. ......Kenshin won't be able to attack us so easily. One more thing to worry about is gone, though.
[cpg cn=true]


[OnName num="keitarou"]
Are you thinking about your illness?
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Singen321"]
[OnName num="shingen"]
I'm sure I've died in battle. I'm sure I didn't die in battle?
[cpg cn=true]


That part is a hazy memory. But if the battle between Shingen and Kenshin was inconclusive in historical fact, he must have died of illness somewhere .......
[cpg]

[OnName num="keitarou"]
I am afraid of losing you."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Singen322"]
[OnName num="shingen"]
You say so ....... No one can control your life.
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット

;//移植前シーンカット

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（昼）******************************************************

The next day, I left the castle and looked out over the town.
[cpg]

This is the town that Shingen-sama protected. Even if it is not as lively as it was in the times of the quintessential era, it is still a town with a lot to offer. ......
[cpg]

There is no doubt that people are still living in the town. I sense it.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen377"]
[OnName num="shingen"]
I wish they could just focus on their own happiness without worrying.
[cpg cn=true]


The battle between Shingen-sama and Kenshin remains unresolved.
[cpg]

Shingen-sama may think that he will have to kill him because he has been hostile to him for many years.
[cpg]

Perhaps Kenshin wishes the same thing, and they are at odds.
[cpg]

[OnName num="keitarou"]
I kind of hate it," he said. Is this something that can't be helped?"
[cpg cn=true]


This kind of thing may have been the same in the modern world where I was.
[cpg]

Everyone is working for the sake of others and wishing for world peace, but it cannot be achieved.
[cpg]

This may be true on a national scale or on an individual scale.
[cpg]

People want to love each other, but it often doesn't happen.
[cpg]

[OnName num="keitarou"]
I wonder why human love is so distorted.
[cpg cn=true]


[OnName num="keitarou"]
Things that we want, things that we all wish for, don't come true easily.
[cpg cn=true]


When I talk to Shingen-sama about those ideas…
[cpg]

[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen378"]
[OnName num="shingen"]
I told Shingen that I thought that way and he said, "Yes, it is true. It must be a miracle that you and I are able to love each other.
[cpg cn=true]

[STOPBGM]
Shingen-sama replied, but shortly after that, he said.
[cpg]

[FACE method="bows_4" pos="2/3"]

[VOICE f="Singen379"]
[OnName num="shingen"]
"Gekho!　Gee, goho!
[cpg cn=true]


[OnName num="keitarou"]
Are you all right, Shingen-sama?
[cpg cn=true]


She suddenly coughed and covered her mouth with her hand. Her palm was covered with blood.
[cpg]

Is this miraculous love also about to be taken away?
[cpg]

The disease of tuberculosis was tearing us apart.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

[OnName num="keitarou"]
'...... It's all right. Shingen-sama's disease will be cured.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen381"]
[OnName num="shingen"]
I can't. It's me, I know what I'm talking about.
[cpg cn=true]


[OnName num="keitarou"]
Even if Shingen-sama gives up, I won't.
[cpg cn=true]


Shingen-sama, who is sickly and weak, is about to give up on the child.
[cpg]

But I kept encouraging him.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


I could not have children, and even if I did, I did not know if Shingen-sama would be safe.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen382"]
[OnName num="shingen"]
You may be right. Love alone may not be enough.
[cpg cn=true]


[OnName num="keitarou"]
I wasn't talking about that. I was talking about love itself becoming distorted.
[cpg cn=true]


[OnName num="keitarou"]
I don't think Shingen-sama's love is like that at all.
[cpg cn=true]


I say such words to Shingen-sama who is feeling weak.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen383"]
[OnName num="shingen"]
'...... don't need any consolation.'
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And her wish came true.
[cpg]


;//========================================
;//●ＣＧ（妊娠しているヒロインが前のめりで主人公に近づく）ev_29
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//備考　：ヒロインは妊娠四ヶ月くらいです
;//========================================


[BGM f="bg_05"]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]



Her stomach was distended. Nothing is impossible for us.
[cpg]


[VOICE f="Singen384"]
[OnName num="shingen"]
Maybe when I have a baby, that's when I'll die.
[cpg cn=true]


[OnName num="keitarou"]
"Then again, you don't have to worry ...... about that," she said.
[cpg cn=true]



[VOICE f="Singen385"]
[OnName num="shingen"]
"Really?　You have no evidence to support that.
[cpg cn=true]


[OnName num="keitarou"]
As far as I know, there is no history of people dying because they had children.
[cpg cn=true]


Having said that, I can't say that I ...... feel safe because she was essentially a man to begin with.
[cpg]


;**【ＣＧ】 ev_29_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSingen003"]
[OnName num="shingen"]
......"
[cpg cn=true]


She was supposed to be happy to have a child, but she was still somewhat melancholy.
[cpg]

Shingen-sama's belly swelled and happy days passed.
[cpg]

As she said, I also had the feeling that everything was going to pass away.
[cpg]

Shingen-sama has tuberculosis. Even if he could have children, ......
[cpg]

he might die before me. That was something I had to think about, even if I didn't want to.
[cpg]


;//移植前シーンカット

;//ブラックアウト

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

Kenshin and I had a standoff.
[cpg]

Me and Shingen-sama were on the lookout for it for a long time. I couldn't not be bothered.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen436"]
[OnName num="shingen"]
In your time, Japan was a country, wasn't it?
[cpg cn=true]


[OnName num="keitarou"]
Yes, it was. You didn't have an army, either.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen437"]
[OnName num="shingen"]
I envy you. It is unthinkable in this day and age that a country can exist without soldiers.
[cpg cn=true]


Shingen-sama's words left me feeling frustrated.
[cpg]

[OnName num="keitarou"]
The world I was in won't change either. It changes in form, and things like wars keep happening."
[cpg cn=true]


The peace she wanted has not been realized after all.
[cpg]

If I could go back to the past, I wouldn't want to live in idleness.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen438"]
[OnName num="shingen"]
Don't you wish you could go back to the way things were?"
[cpg cn=true]


I stammered a little, thinking.
[cpg]

[OnName num="keitarou"]
"Yes, I do. I want to bring back the medicine to cure tuberculosis and save you.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

Thinking of Shingen-sama, I answered.
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen439"]
[OnName num="shingen"]
I was so happy to hear you say that," I replied. But it is too late for my disease.
[cpg cn=true]


[OnName num="keitarou"]
I am sure there are medicines for tuberculosis in the time I was there.
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

Does Shingen-sama believe my words or not?
[cpg]

Either way, it was the same thing, since there was no way for me to return to the present day.
[cpg]

The least I could do was to love her seriously. ......
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sSingen004"]
[OnName num="shingen"]
'As long as I'm with Keitaro, I can forget everything.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen465"]
[OnName num="shingen"]
Even my own death. I can forget everything while I'm with Keitaro, even my own death, and whether or not this baby will be born safe and sound.
[cpg cn=true]


[OnName num="keitarou"]
I'll tell you what, you don't have to worry about it. I'll say it again and again.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Singen466"]
[OnName num="shingen"]
Yes. If you say so, I think I may not have to worry.
[cpg cn=true]


After all, she would inevitably feel vulnerable. I wanted to support her.
[cpg]

It might be me, not Shingen-sama, who is looking for a sure connection. ......
[cpg]


;//ブラックアウト

;//移植前シーンカット

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）

I wonder how much time we have left to share.
[cpg]

Shingen-sama's stomach continues to growl. And her tuberculosis was getting worse.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

She was about to give birth.
[cpg]

I stayed by her side the whole time. Combined with her TB, she didn't get up much anymore.
[cpg]

;//[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen491"]
[OnName num="shingen"]
I said to her, "......, I'm sorry for worrying you.
[cpg cn=true]


[OnName num="keitarou"]
Don't apologize. I do worry, but I do it because I want to.
[cpg cn=true]


;//[FACE method="shock_4" pos="2/3"]

[VOICE f="Singen492"]
[OnName num="shingen"]
"So ...... kehoh, gee whiz."
[cpg cn=true]


;//[FACE method="change_6" pos="2/3"]

[VOICE f="Singen493"]
[OnName num="shingen"]
"You're about to have a baby. I just wish I could meet my child face to face.
[cpg cn=true]


[OnName num="keitarou"]
Don't worry. That's exactly what you need to worry about.
[cpg cn=true]


Shingen-sama did not return the words.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I prayed. I prayed again and again. I prayed for her to be safe.
[cpg]

I prayed over and over again that she would give birth to a child. I would trade my life for hers if I had to.
[cpg]

Perhaps my prayers were answered, and she gave birth to ......
[cpg]

She gave birth to a child. The child that Shingen-sama and I wanted was born into this world.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

;//[SE f=se000]
;//【ＳＥ】『赤子の泣き声』

[OnName num="keitarou"]
I'm so happy...... I'm so happy.
[cpg cn=true]


Our child was a boy. He cried cheerfully.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen494"]
[OnName num="shingen"]
I've never seen you cry before.
[cpg cn=true]


[OnName num="keitarou"]
I'm that happy. We're really going to be a family.
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]

[VOICE f="Singen495"]
[OnName num="shingen"]
I guess so. ...... gee whiz, gee whiz!　Hah .......
[cpg cn=true]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

Both mother and child are safe. However, it doesn't mean that Shingen-sama's tuberculosis is cured.
[cpg]

I don't know if Shingen-sama will be able to watch this child grow up.
[cpg]


[window target=false]
[BG f="b_13_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

Months passed by. Our child has grown up, and the battle with Kenshin remains unresolved.
[cpg]

Today, Ranmaru-sama came from Nobunaga-sama's place.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="2/3" time=800]

[VOICE f="Ranmaru463"]
[OnName num="ranmaru"]
He said, "...... You're the father? I can't imagine what it must be like.
[cpg cn=true]


[OnName num="keitarou"]
I didn't imagine it either, but I'm finally starting to feel it.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru464"]
[OnName num="ranmaru"]
 How is Shingen-sama?
[cpg cn=true]


[OnName num="keitarou"]
That's .......
[cpg cn=true]



[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

Shingen-sama's condition was not good. If his condition continued, he would have less than five years to live.
[cpg]

It is painful to imagine parting with her in death.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Singen496"]
[OnName num="shingen"]
"Ranmaru......, you're here."
[cpg cn=true]


[FACE method="bow_4" pos="4/5"]

[VOICE f="Ranmaru465"]
[OnName num="ranmaru"]
Yes. How is your health?
[cpg cn=true]


[FACE method="shake_4" pos="2/5"]

[VOICE f="Singen497"]
[OnName num="shingen"]
...... not so good, not so good. I had to get my shit together.
[cpg cn=true]


Shingen-sama face is very weak. I don't want to see her face like this.
[cpg]

 I wanted to save her anyway.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


And there was a path that might make that possible.
[cpg]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

As our child grew up, she developed a strange ability.
[cpg]

It was in the lore. The power to transcend time.
[cpg]

He had the power to erase objects that he touched with his mind.
[cpg]

It probably sent them into the future. Using that power, I might be able to return to the present.
[cpg]

Maybe. Maybe. ......
[cpg]

[OnName num="keitarou"]
"Shingen-sama. I may be able to bring you a medicine to cure your tuberculosis."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Singen498"]
[OnName num="shingen"]
You're talking about ...... time travel, right?"
[cpg cn=true]


I have explained this to Shingen-sama many times. Going back and forth in time hasn't been done even in my time, but ......
[cpg]

I had an idea that's what our kids were doing.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Singen499"]
[OnName num="shingen"]
I'm still confused. There is no guarantee that you will go back to the future and come back here.
[cpg cn=true]


[OnName num="keitarou"]
I will come back. I'll even invent a time machine for you.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen500"]
[OnName num="shingen"]
What is a time machine?
[cpg cn=true]


Shingen-sama giggles. However, his complexion was not good.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

I didn't have time to take any more time to make a decision. I might not make it if I didn't leave now.
[cpg]

[OnName num="keitarou"]
I'm going to ...... then.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen501"]
[OnName num="shingen"]
You're really going, aren't you? Make sure you come back.
[cpg cn=true]


[OnName num="keitarou"]
"Yes, I will. I promise."
[cpg cn=true]


I took my kid's hand and I begged him.
[cpg]

[OnName num="keitarou"]
"Just like you always do," I said, "I want you to make me disappear. I want you to make me disappear.
[cpg cn=true]


Somehow, I had a feeling he understood what I was trying to do.
[cpg]

Finally, I looked at Shingen-sama and closed my eyes.
[cpg]


;//画面ゆがむ

[SE f=se018]
;//【ＳＥ】『タイムリープ　シンセ系の効果音』

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0xffffffff} time=2000]
[FACE method="change_4" pos="2/3"]
[WAIT time=500]
[WAIT time=2000]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1500]

[BG f="black.ui" time=1000]

[WAIT time=2000]
[BG f="b_11_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『博物館＿現代』（夕方）******************************************************

;//画面元に戻る

[OnName num="keitarou"]
'...... this is...'
[cpg cn=true]


Before I had returned to the past, I was back in the present day.
[cpg]

I look around. I looked around and saw that the folding screen itself, which was supposed to be displayed, had disappeared.
[cpg]

[OnName num="classmate_A"]
What's wrong, Keitaro? Where have you been?
[cpg cn=true]


[OnName num="classmate_B"]
I went to ...... and looked around.　Is it my imagination?
[cpg cn=true]


Not even an hour had passed. Everything has remained the same since I arrived, except for the folding screen.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Was it all an illusion? Was it real?
[cpg]

I was reunited with my family without knowing for sure.
[cpg]

But Shingen-sama and our children are still in the past.
[cpg]

There was no way to go back to cure Shingen-sama's tuberculosis. ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『博物館＿現代』（昼）******************************************************

Then I started visiting castles and museums as if I was possessed by something.
[cpg]

In historical fact, did Shingen leave behind any children? The Shingen-sama I know had children.
[cpg]

I found out that he had some offspring. That much I have found out.
[cpg]

I left the museum, imagining what might have happened if I had not had a child with Shingen-sama.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then I left the museum and walked around for a while.
[cpg]

I just can't help but see her again.
[cpg]

But still, I wondered if I could ...... see her again.
[cpg]

[WAIT time=1100]

;//以降セリフ名前欄を「少女」と置き換えてください
[STOPBGM]


[VOICE f="Singen502"]
[OnName num="girl"]
I wondered if ...... I had seen you somewhere before.
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（街を歩くヒロイン。主人公の方を向いてびっくりしている）ev_67
;//人物１：ヒロイン２　服装１：制服
;//場所　：現代＿街
;//時間　：昼
;//備考　：信玄本人ではなく、末裔です
;//========================================


;**【ＣＧ】 ev_67_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

[BGM f="bg_05"]


The girl looks at me and looks surprised.
[cpg]

Her appearance was very similar to that of Shingen-sama.
[cpg]

[OnName num="keitarou"]
You are ......
[cpg cn=true]



[VOICE f="Singen503"]
[OnName num="girl"]
I feel like I've been looking for you for a long time. I wonder why.
[cpg cn=true]


Even the way they talked was exactly the same. I found myself shedding tears.
[cpg]


[VOICE f="Singen504"]
[OnName num="girl"]
I think I've seen you shed a ...... tear somewhere.
[cpg cn=true]



;//ブラックアウト

;//ＥＮＤ　ヒロイン２ルート

[SCENE id=13]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="epend.ks" target="*start"]

;//==============================





