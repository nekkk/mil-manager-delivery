
*start
;//姫武将　全年齢移植用シナリオ

;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり

;//信長　　　　　　着衣
;//信玄　　　　　　着衣
;//謙信　　　　　　着衣
;//光秀　　　　　　着衣
;//蘭丸　　　　　　着衣

;//上記以外のキャラクターには音声がありません

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//信長　　　　　　一人称「私（わたし）」　信玄呼び「信玄」　謙信呼び「謙信」
;//　　　　　　　　光秀呼び「光秀」　蘭丸呼び「蘭丸」　景太郎呼び「景太郎」
;//信玄　　　　　　一人称「私（わたし）」　信長呼び「信長」　謙信呼び「謙信」
;//　　　　　　　　光秀呼び「光秀」　蘭丸呼び「蘭丸」　景太郎呼び「景太郎」
;//謙信　　　　　　一人称「わたくし」　信長呼び「信長」　信玄呼び「信玄」
;//　　　　　　　　光秀呼び「光秀」　蘭丸呼び「蘭丸」　景太郎呼び「景太郎さん」
;//光秀　　　　　　一人称「私（わたし）」　信長呼び「信長様」　信玄呼び「信玄様」
;//　　　　　　　　謙信呼び「謙信」　蘭丸呼び「蘭丸」　景太郎呼び「景太郎さん」
;//蘭丸　　　　　　一人称「あたし」　信長呼び「信長様」　信玄呼び「信玄様」
;//　　　　　　　　謙信呼び「謙信」　光秀呼び「光秀」　景太郎呼び「景太郎」

;//景太郎　　　　　一人称「俺」　信長呼び「信長様」　信玄呼び「信玄様」
;//　　　　　　　　謙信呼び「謙信」　光秀呼び「光秀様」　蘭丸呼び「蘭丸様」
;//　　　　　　　　ただし、謙信ルートでは謙信を「謙信様」と呼ぶ

;//以下、残したＣＧを列挙いたします
;//信長 ev_01 ev_07 ev_24 ev_47 ev_68 紹介ページのCG
;//信玄 ev_29 ev_56 ev_67 ev_69
;//謙信 ev_48 ev_57 ev_58 ev_63
;//光秀 ev_34 ev_53 紹介ページのCG
;//蘭丸 ev_14 ev_36 紹介ページのCG


;//////////////////////////////////////
;///////////////以下本編///////////////
;//////////////////////////////////////


;#################################################
*Ep000|One who wears a foreign robe.
;#################################################

[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]

[stflag Selectflg1=0]
[stflag Selectflg2=0]
[stflag Selectflg3=0]
[stflag Selectflg4=0]



[SCENE id=0]

;//ブラックアウト
[window target=true]
[BG f="black.ui" time=1000]
[WAIT time=1000]

It is not mere sleep. Still, I dare to compare it to sleep: ......
[cpg]

It was like after an all-nighter, after about twelve hours of sleep.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『森の中』（夕方）******************************************************

[OnName num="keitarou"]
Is this ...... where I am?"
[cpg cn=true]


I was completely unconscious. I was in a completely unknown place.
[cpg]

I was in the woods. I tried to trace my vague memories, but my consciousness was too muddled.
[cpg]

Keitaro Sudo. I can remember my name.
[cpg]

I remember before I fell asleep. I was on a school trip, I think, and what happened there......
[cpg]

[OnName num="keitarou"]
...... my head hurts."
[cpg cn=true]


I walked through the forest, not knowing why, not wanting to stay there forever.
[cpg]


[SE f=se027]
;//【ＳＥ】『山道歩く』

;//ブラックアウト
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

I don't even know how long I had been asleep.
[cpg]

I don't even know how long I've been asleep, but the feeling is that I've been asleep for quite some time, just like I thought earlier.
[cpg]

But strangely enough, I wasn't hungry. I wonder if I was put to sleep rather than slept.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_10_3.ui" time=1000]
[WAIT time=2000]
[window target=true]

;//【ＢＧ】『村』（夕方）******************************************************

[OnName num="keitarou"]
It's a village, .......
[cpg cn=true]


But it was so rural. I wondered if I had been transported to some other place.
[cpg]

As I was thinking that, someone who looked like a villager came toward me.
[cpg]

[OnName num="villager"]
"Are you ......?　You are strangely dressed.
[cpg cn=true]


[OnName num="keitarou"]
"......, isn't there a museum around here?"
[cpg cn=true]


[OnName num="villager"]
A museum?　What's that?
[cpg cn=true]


My vague consciousness was gradually being recovered.
[cpg]

It was as if meeting someone and talking to them made me realize that this was not a dream.
[cpg]

[OnName num="keitarou"]
Let's see... I was at the museum.
[cpg cn=true]



What happened? I really need to remember what happened.
[cpg]

Where am I? We can't be far.
[cpg]

[OnName num="keitarou"]
"Yes," he said. I heard voices coming from the folding screen.
[cpg cn=true]


There were exhibits of things from the Warring States period, and one of them was a folding screen, and I heard a voice.
[cpg]

I think it was a girl's voice, but it was strange to hear a voice coming from a folding screen.
[cpg]

[OnName num="keitarou"]
It was a girl's voice, I think, but it was strange to hear a voice coming from a folding screen.
[cpg cn=true]

[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

Memories are connected. It all makes sense, in its own strange way.
[cpg]

I touched the folding screen as if I was being pulled in. From that point on, I was unconscious.
[cpg]

And this village is not just rural.
[cpg]

The architectural style is too old, in other words.
[cpg]

[OnName num="villager"]
What's wrong?　You look pale.
[cpg cn=true]


I have a hypothesis. Maybe this place is...
[cpg]

[OnName num="keitarou"]
"Warring States period......?"
[cpg cn=true]


He nodded his head as if he didn't recognize my muttered words.
[cpg]

[OnName num="villager"]
Anyway, if you don't have anywhere to go, stay the night.
[cpg cn=true]


[free time=1000]
[BG f="b_10_4.ui" time=1000]
[WAIT time=2000]
[window target=true]

;//【ＢＧ】『村』（夜）******************************************************

Distraught. As much as I was, I instinctively knew not to act in a hurry.
[cpg]

There were so many questions I wanted to ask, but I should not be in a hurry right now.
[cpg]

I decided to stay at a private house for the night.
[cpg]

I was served some food for dinner. I was grateful, but the food was too simple.
[cpg]

I wondered if this place was really modern.　I wondered, "Is this really modern times?
[cpg]

[OnName num="villager_A"]
But still, it's a strange kimono.
[cpg cn=true]


[OnName num="villager_B"]
Maybe this is the man in the lore.
[cpg cn=true]


[OnName num="keitarou"]
Lore ......?"
[cpg cn=true]


[OnName num="villager_C"]
There is such a thing. The one who wears the garment of foreign lands. 'He who wears the robe of a foreign country, shall give birth to a son who eats the sky under the bond of a princess warlord.
[cpg cn=true]


What is a "princess warlord"? I had never heard of this term before.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

We were in a place where there was no electricity, let alone cell phone reception.
[cpg]

In addition, it would take a long time to walk to the nearest town.
[cpg]

It was hard to believe, but it didn't seem like everyone was lying.
[cpg]

[SE f=se027]
;//【ＳＥ】『山道歩く』

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『森の中』（夜）******************************************************

Then, late at night. I heard strange noises and headed toward the forest. ......
[cpg]

;//しばらく、信長の名前欄を「謎の少女」と隠してください

There they were, some men dressed like warriors and ......
[cpg]

There was one girl who was so beautiful that I couldn't help but admire her. For some reason, she was holding a sword.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Nobunaga001"]
[OnName num="mysterious_girl"]
She said, "Who are you? Tell me your name.
[cpg cn=true]


[OnName num="keitarou"]
I am Sudo,...... Keitaro Sudo, but who are you?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga002"]
[OnName num="mysterious_girl"]
Don't you know who I am? Why are you here?
[cpg cn=true]


She looks like an old princess, but also like a warlord.
[cpg]

Is the princess warlord this person ......?
[cpg]


;//ここから、信長の名前を隠さないでください

[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga003"]
[OnName num="nobunaga"]
I am Nobunaga Oda. You, you are called Keitaro."
[cpg cn=true]


It was too sudden for me to get it right in my head.
[cpg]

First of all, Nobunaga Oda was not only deceased, but also lived hundreds of years ago.
[cpg]

Secondly, he couldn't have been a girl.
[cpg]

[OnName num="keitarou"]
That's absurd. ......
[cpg cn=true]

[STOPBGM]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga004"]
[OnName num="nobunaga"]
What is there that you don't agree with?　Well, whether there is or isn't, there's only one thing for you to do."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
The girl who called herself Nobunaga offered me her sword.
[cpg]

[BGM f="bg_06"]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga005"]
[OnName num="nobunaga"]
Can you handle a sword? Even if you can't, if you don't have a sword now, you could die.
[cpg cn=true]


[OnName num="keitarou"]
What do you mean?
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga006"]
[OnName num="nobunaga"]
I'm surrounded by bandits. I can't handle them by myself. If you just stand there, there is a good chance you will be killed.
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


I can't believe it. Am I dreaming?
[cpg]

The girl asked you if you could handle a sword. I'm sure there's nothing I can't handle.
[cpg]

I belong to the kendo club. I'm a member of the kendo club, and I think I'm pretty good at it. ......
[cpg]

But when it comes to swinging at people, it's a different story.
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Nobunaga007"]
[OnName num="nobunaga"]
The "It's coming. There's already a sign right there."
[cpg cn=true]



[SE f=se022]
;//【ＳＥ】『草木揺れる』

While I'm thinking about what to do, I feel someone is definitely approaching.
[cpg]

I think. What's the best way to get out of this situation?
[cpg]


;////////////////////////////////////////////////////

;//オレは姫武将を孕ませたい！　マップシステムに関して

;//体験版及び本編中に、ゲーム性を持たせるためマップを用いたパートを用意します。
;//マップパートでは選択肢によって、勝利、敗北の二種類に分かれます

;//マップパートでは、

;//１→２→３
;//↓　↓　↓
;//４→５→６
;//↓　↓　↓
;//７→８→９

;//という形で９マスあり「１」のマスからスタートし「９」までたどり着けばクリアとなります
;//下に進むか右に進むかという形で二択あり、合計四回選択します
;//ルートは全六種類になります
;//（選択肢は「南へ進む」「東へ進む」の二種類となります）

;//賊が「２」「６」「７」に待ち構えているという設定で
;//二度通ると敗北となります
;//今回のイベントでは、敗北でゲームオーバーとなりますが、ストーリーが分岐する場合もあります

;////////////////////////////////////////////////////


;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※最初の戦闘　開始時（１のマスにいる場合のシナリオ）※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※

;//ブラックアウト
;//【ＢＧ】『森の中』（夜）
;//ヒロイン１の立ち絵を表示してください

[OnName num="keitarou"]
Let's just get out of here.
[cpg cn=true]

She nodded. We don't know where the bandits are.
[cpg]

I think I see some movement in the bushes to the east. ......
[cpg]




;//■選択肢
[switch]
[case "Proceeding south"]
	[swap]
	[jump target="*select01_4"]
[case "Proceeding east"]
	[swap]
	[jump target="*select01_2"]
[endswitch]

1, going south
2. to the east.


;//==============================
;//１、南へ進む

;//同じイベント中の「４のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「２のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※２のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_2|The one who wears the garb of foreign lands

[stflag Selectflg1=1]


[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


[OnName num="keitarou"]
No!　Please stand back!"
[cpg cn=true]


The bandit appeared. They jumped on me.
[cpg]


[SE f=se019]
;//【ＳＥ】『剣戟』

We exchanged swords, and I wounded the bandit.
[cpg]

They ran back, and I didn't pursue them.
[cpg]

I was drained of energy. If I run into them again, it might be dangerous. ......
[cpg]


;//■選択肢
[switch]
[case "Proceeding south"]
	[swap]
	[jump target="*select01_5"]
[case "Go to the east"]
	[swap]
	[jump target="*select01_3"]
[endswitch]

1. Going south.
2, go east.


;//==============================
;//１、南へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「３のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※３のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_3|The one who wears the garb of foreign lands

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン１の立ち絵を表示してください

The path to the east is more of a steep mountain than a forest.
[cpg]

If this happens, we have no choice but to continue south.
[cpg]

I looked at her and saw her looking at me with concern.
[cpg]

[OnName num="keitarou"]
She said, "...... don't worry. Don't worry.
[cpg cn=true]



;//■選択肢
[switch]
[case "Proceeding to the south"]
	[swap]
	[jump target="*select01_6"]
[endswitch]

1. Going south
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※４のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_4|The One in Foreign Clothing

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

It is awfully quiet. No bandits in sight.
[cpg]

We proceed cautiously. There is no certainty of safety in this situation.
[cpg]

I feel a presence from the south, but I am not sure if I should continue in that direction.
[cpg]


;//■選択肢
[switch]
[case "Proceed to the south."]
	[swap]
	[jump target="*select01_7"]
[case "Proceed to the east."]
	[swap]
	[jump target="*select01_5"]
[endswitch]

1, proceed to the south.
2, go to the east.


;//==============================
;//１、南へ進む

;//同じイベント中の「７のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※５のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_5|The one who wears the garb of foreign lands

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン１の立ち絵を表示してください

We have come to a slightly open area in the forest.
[cpg]

She is tense, but does not look tired.
[cpg]

I wonder if I'm the only one who's nervous. ......
[cpg]


;//■選択肢
[switch]
[case "Proceeding south"]
	[swap]
	[jump target="*select01_8"]
[case "Proceed to the east"]
	[swap]
	[jump target="*select01_6"]
[endswitch]

1, going south
2. to the east


;//==============================
;//１、南へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※６のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_6|The one who wears the robe of foreign lands

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[if exp={getFlagValue("Selectflg1") == 1 }]
[jump target="*select01_6_2t"]
[endif]

[jump target="*select01_6_2f"]


;//==============================
;//２のマスを通っていた場合

*select01_6_2t|The one who wears a foreign robe

Again, bandits appear from the bushes.
[cpg]

I was caught off guard, and I ran forward as quickly as I could to protect her.
[cpg]

[OnName num="keitarou"]
I realized that I had been mortally wounded.
[cpg cn=true]

[SE f=se020]
;//【ＳＥ】『刀振るう』

[window target=false]
[free time=500]
[BG f="red.ui" time=500]
[WAIT time=500]
[BG f="b_08_4.ui" time=500]
[WAIT time=500]
[window target=true]


By the time I realized I had been mortally wounded, it was too late.
[cpg]


;//ブラックアウト
[SE f=se016]
;//【ＳＥ】『倒れる』
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

Why am I here? Who was she?
[cpg]

The truth of everything remained unrevealed, and I ran out of strength. ......
[cpg]


;//ゲームオーバー

[jump storage="epend.ks" target="*back_title"]


;//==============================
;//２のマスを通っていない場合

*select01_6_2f|The one who wears the garb of foreign lands

[OnName num="keitarou"]
Please back off!　Please stay back!
[cpg cn=true]


A bandit appeared. They jumped on me.
[cpg]


[SE f=se019]
;//【ＳＥ】『剣戟』

We exchanged swords, and I wounded the bandit.
[cpg]

They ran back, and I didn't pursue them.
[cpg]

I was drained of energy. If I run into them again, it might be dangerous. ......
[cpg]


;//■選択肢
[switch]
[case "Proceeding south"]
	[swap]
	[jump target="*select01_9"]
[endswitch]

1. Proceeding south


;//==============================
;//１、南へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※７のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_7|The one who wears the garb of foreign lands

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[SE f=se022]
;//【ＳＥ】『草木揺れる』

[OnName num="keitarou"]
Oops!　Please stay back!"
[cpg cn=true]


The bandit appeared. They jumped on me.
[cpg]


[SE f=se019]
;//【ＳＥ】『剣戟』

We exchanged swords, and I wounded the bandit.
[cpg]

They ran back, and I didn't pursue them.
[cpg]

I was drained of energy. If I run into them again, it might be dangerous. ......
[cpg]


;//■選択肢
[switch]
[case "Proceed to the east"]
	[swap]
	[jump target="*select01_8"]
[endswitch]

1. Going east
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※８のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_8|The one who wears the robe of foreign lands

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン１の立ち絵を表示してください

We are almost through the forest. It looks like we're going to make it.
[cpg]

Still, we cannot let our guard down. She is still alert.
[cpg]


;//■選択肢
[switch]
[case "We continue east."]
	[swap]
	[jump target="*select01_9"]
[endswitch]

1. Proceed to the east.
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※９のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_9|The one who wears the garb of foreign lands

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//マップシステム終了。下記のシナリオへ進む

If I don't kill her, she might kill me. I am prepared.
[cpg]

I swing my sword at the man who appears from the bushes with the intention of inflicting a fatal wound.
[cpg]


[SE f=se020]
;//【ＳＥ】『刀振るう』

Blood splatters. It doesn't feel like a very deep wound, but it's enough to make him unable to fight.
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Nobunaga009"]
[OnName num="nobunaga"]
That's good. Don't hesitate.
[cpg cn=true]


I could feel the adrenaline pumping through me. He continued to swing his sword.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『森の中』（夜）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga010"]
[OnName num="nobunaga"]
You're good with a sword," he said. I've never seen a sword like that before.
[cpg cn=true]


As it turned out, we were saved. The bandits were almost all defeated by the warriors and Nobunaga.
[cpg]

[OnName num="keitarou"]
'...... Hon'ble really, Oda Nobunaga, is it?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Nobunaga011"]
[OnName num="nobunaga"]
You call me rude. But now you owe me your life.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga012"]
[OnName num="nobunaga"]
How very true, I am Oda Nobunaga. Suppose I were lying, there would be no advantage."
[cpg cn=true]


She called herself so again. I don't look like I'm lying.
[cpg]

She even lets me hold the sword and cut down the bandit. I don't think this is all a setup.
[cpg]

But if she really is Oda Nobunaga, I'm in a lot of trouble.
[cpg]

[OnName num="keitarou"]
Is this a time slip ......?　No, it's a parallel universe.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga013"]
[OnName num="nobunaga"]
"...... what?　That's a word I'm not familiar with.
[cpg cn=true]


I also think it's a parallel world, given that Nobunaga is not a man.
[cpg]

Or perhaps the history that was considered male is in error. ...... While I am thinking about this, a girl who calls herself Nobunaga cuts in with this.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga014"]
[OnName num="nobunaga"]
Let's go back to the castle. Sorry to take up so much of your time, guys.
[cpg cn=true]


She calls out to the warriors. I wonder if there really is a castle ...... called a castle.
[cpg]

[OnName num="keitarou"]
Where is a castle?
[cpg cn=true]


I may have asked something stupid.
[cpg]

I might be asking a stupid question, but I couldn't help but ask. I just need to know where it is and how old it is.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga015"]
[OnName num="nobunaga"]
Kiyosu Castle. Don't you know that too?
[cpg cn=true]


Kiyosu Castle. Just by hearing the name, some people might be able to tell what year it is.
[cpg]

But I don't know. If I had to say, I vaguely know where it is: ......
[cpg]

It's not that far from the museum where I was before I moved.
[cpg]

That was more than enough to confirm that this event was not a dream.
[cpg]

[OnName num="keitarou"]
What year is it now?"
[cpg cn=true]


Nobunaga replied, with a quizzical look on his face.
[cpg]

[FACE method="shake_5" pos="2/3"]

[VOICE f="Nobunaga016"]
[OnName num="nobunaga"]
Who are you that you don't know when the present is?"
[cpg cn=true]

;//様は年号を言うが、俺はそれ聞いてもやっぱりピンとこない。いつ頃だろう。
He gave me the year, but I still had no idea what it was. When was it?
[cpg]

I could guess that it was during the Warring States period, but I don't know what Nobunaga will be like in the future. ......
[cpg]


;//ブラックアウト
[SE f=se014]
;//【ＳＥ】『歩く』

[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=1]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

We walked for a while. I was surprised at how fast the warriors were walking, even though they were quite heavily armed.
[cpg]

Nobunaga is leading them in that form. That's also surprising, ...... even though she's a girl.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga017"]
[OnName num="nobunaga"]
'Keitaro. What do you mean you don't know what year it is now?　And what's with the outfit?"
[cpg cn=true]


I was promptly called out. I was called out on my way out and asked the same question as if I were the one who had gone back in time.
[cpg]

[OnName num="keitarou"]
I don't have it all figured out yet either. But I'll tell you all about it when I get ...... settled."
[cpg cn=true]


It was probably a bad idea to tell them what I knew.
[cpg]

What would happen to my very existence if the future was changed?
[cpg]

I could not imagine what would happen if a time paradox actually occurred.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

I walked for quite a long time. It was hard to walk at night, but I arrived at ......
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga018"]
[OnName num="nobunaga"]
"Here we are. Kiyosu Castle.
[cpg cn=true]


[OnName num="keitarou"]
...... is amazing. It looks like it was just built.
[cpg cn=true]


It was hard to see at night, but I could still make it out.
[cpg]

When I think of a castle, I imagine an old structure, but that was not the case at this time.
[cpg]

[OnName num="keitarou"]
I didn't know such technology existed in this time period.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga019"]
[OnName num="nobunaga"]
So what do you mean by that? What do you mean by "this time period?"
[cpg cn=true]


[OnName num="keitarou"]
'...... No, I mean...'
[cpg cn=true]

[free time=1000]

While I was at a loss for words, I heard a voice from the castle.
[cpg]


;//しばらく、蘭丸の名前を「少女」と置き換えてください
;//girl

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="4/5" time=800]

[VOICE f="Ranmaru001"]
[OnName num="girl"]
Are you safe, sir?　Nobunaga-sama!
[cpg cn=true]


Another girl appeared on the way to the castle.
[cpg]

[FACE method="shock_4" pos="4/5"]

[VOICE f="Ranmaru002"]
[OnName num="girl"]
I've been looking for you. ...... please tell me when you leave the castle.
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga020"]
[OnName num="nobunaga"]
I'm sorry, I couldn't sleep because my heart was racing. I was just walking where my heart took me and there she was."
[cpg cn=true]


Another girl with a sword. Is this normal in this world?
[cpg]

If a general as great as Nobunaga was a girl, there might be other examples.
[cpg]

[OnName num="keitarou"]
Who are you ......?
[cpg cn=true]


I asked her. Maybe she knew him.
[cpg]


;//ここから蘭丸の名前を置き換えないでください

[FACE method="change_7" pos="4/5"]

[VOICE f="Ranmaru003"]
[OnName num="ranmaru"]
I'm Ranmaru Mori, ....... Who are you?
[cpg cn=true]


[OnName num="keitarou"]
I am Keitaro Sudo.
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru004"]
[OnName num="ranmaru"]
"Keitaro ......?　Nobunaga-sama, who is he?
[cpg cn=true]


Nobunaga looked amused at Ranmaru's inquiry.
[cpg]

[FACE method="shake_7" pos="2/5"]

[VOICE f="Nobunaga021"]
[OnName num="nobunaga"]
I don't know either. I couldn't even get Keitaro himself to talk to me.
[cpg cn=true]


I had no answer, and that was a fact.
[cpg]

[FACE method="change_5" pos="4/5"]

[VOICE f="Ranmaru005"]
[OnName num="ranmaru"]
Is it safe to have such a person in the castle?
[cpg cn=true]


Ranmaru's question was quite reasonable. I think that's what people usually think.
[cpg]

This was a time when people killed far more than they do today.
[cpg]

It was a time when it was hard for people to trust others. And yet.
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="Nobunaga022"]
[OnName num="nobunaga"]
Keitaro protected me. I didn't swear allegiance to him, but he saved my life.
[cpg cn=true]


Ranmaru sneered. Looking at me, he said.
[cpg]

[FACE method="change_7" pos="4/5"]

[VOICE f="Ranmaru006"]
[OnName num="ranmaru"]
'...... is that so? Such a weak-looking ......"
[cpg cn=true]


I thought it was indeed rude, but they certainly seemed stronger than the girls.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************


In the meantime, I think about it.
[cpg]

Both the man who called himself "Nobunaga" and the man who called himself "Ranmaru" looked old enough to be called a girl.
[cpg]

More to the point, they didn't seem to be far apart in age.
[cpg]

Maybe Ranmaru is a little younger than her, or maybe they are about the same age.
[cpg]

If it were historical fact, it should not be so. I could somehow tell from the image that Nobunaga and Ranmaru are quite a bit older than each other.
[cpg]

I knew I had wandered into a world that was different from the historical reality.
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Nobunaga023"]
[OnName num="nobunaga"]
What's wrong?　You seem to be lost in thought.
[cpg cn=true]


[OnName num="keitarou"]
No, I'm just a little ...... curious about something.
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]

[VOICE f="Nobunaga024"]
[OnName num="nobunaga"]
I see. You can tell me what you're thinking and who you are later.
[cpg cn=true]


They are very tolerant. Maybe it was good that I fought bravely.
[cpg]

Nobunaga has the image of being a man with a rough temperament, but ......
[cpg]

I saw her as a more noble person than just a rough-tempered person.
[cpg]


[SE f=se024]
;//【ＳＥ】『床歩く』

[free time=1000]

In the middle of the passage, we parted from Nobunaga and continued on.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru007"]
[OnName num="ranmaru"]
This way. Follow me.
[cpg cn=true]


[SE f=se024]
;//【ＳＥ】『床歩く』

;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru008"]
[OnName num="ranmaru"]
Sleep here for now. You're a guest now.
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


It's quite spacious. I can't believe they're giving me a room like this.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru009"]
[OnName num="ranmaru"]
How could they assign a room like this to someone they don't even know?
[cpg cn=true]


And it seemed that Ranmaru felt the same way.
[cpg]

[OnName num="keitarou"]
I'm sorry."
[cpg cn=true]


I apologized as quickly as I could. I feel like Ranmaru doesn't like me somehow.
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Ranmaru010"]
[OnName num="ranmaru"]
I don't have anything to apologize for. It was Nobunaga-sama's idea, so there must be something in it for him.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru011"]
[OnName num="ranmaru"]
I'll ask him about his background or something tomorrow. For now, rest.
[cpg cn=true]


[OnName num="keitarou"]
Thank you.
[cpg cn=true]


I thanked her, and watched Ranmaru leave.
[cpg]


[SE f=se025]
;//【ＳＥ】『ふすま閉まる』
[free time=1000]

You are alone, and you get the sense that you are in a lot of trouble.
[cpg]

I really have no idea what's going on. ......
[cpg]

It's not so much that I've gone back in time itself.
[cpg]

The fact that Nobunaga Oda is a woman.
[cpg]

I wonder if there is any connection to the present time in which I live?
[cpg]

I hear that there are still many things about Japanese history that we don't know.
[cpg]

Even so, I wondered if it was possible for the rulers of Japan to be of different genders.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I couldn't think about anything properly. I was tired and slept soundly ......
[cpg]

And the next morning......
[cpg]


[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿城内』（朝）******************************************************

The second day after being invited to the castle.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru012"]
[OnName num="ranmaru"]
Nobunaga-sama wants to see you. Follow me."
[cpg cn=true]


Ranmaru came to his room.
[cpg]

[OnName num="keitarou"]
He said, "...... yes."
[cpg cn=true]


I was still sleepy, but I couldn't stay in bed.
[cpg]


[window target=false]
[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************

[SE f=se024]
;//【ＳＥ】『床歩く』

Ranmaru took me on a walk through the unfamiliar architecture.
[cpg]

I realized again that I had really time-traveled to the past.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru013"]
[OnName num="ranmaru"]
"...... were you able to sleep last night?"
[cpg cn=true]


[OnName num="keitarou"]
Yes, well ......
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru014"]
[OnName num="ranmaru"]
You've got a lot of guts. I wouldn't be able to sleep if I didn't know what I was going to do.
[cpg cn=true]


I guess you're right. It's not like I know I'm safe yet.
[cpg]

But it is true that I was so tired that I fell asleep.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（朝）******************************************************

I walked to Nobunaga's room, which was probably a few steps more luxurious than the room I was in.
[cpg]

The room was a few steps more luxurious than the one I was in.
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="Nobunaga025"]
[OnName num="nobunaga"]
Ranmaru. You wait outside."
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru015"]
[OnName num="ranmaru"]
But ...... as long as we don't know who he is, we don't know what he might do."
[cpg cn=true]


Ranmaru seemed worried about Nobunaga. I have no weapons of any kind.
[cpg]

[FACE method="shake_3" pos="2/5"]

[VOICE f="Nobunaga026"]
[OnName num="nobunaga"]
I don't need to worry."
[cpg cn=true]

[free time=1000]

Ranmaru hesitated for a few moments, then excused himself.
[cpg]

Then Nobunaga approached me and looked at me intently.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga027"]
[OnName num="nobunaga"]
He looked at me seriously and said, "You look even more peculiar in the light.
[cpg cn=true]


[OnName num="keitarou"]
'...... I'm sure it is.'
[cpg cn=true]


A school uniform is a very unusual attire for this time period.
[cpg]


;//下記のセリフ、台本では
;//「お前はどこから来たんだ？　言葉は通じるようだが、服装はこの国のものではないように見えるが……」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga028"]
[OnName num="nobunaga"]
Where are you from?　You seem to speak the language.
[cpg cn=true]


[OnName num="keitarou"]
It's ......
[cpg cn=true]


When I was puzzling over the answer, Nobunaga said, "I can't let someone who doesn't know who I am stay at the castle.
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga029"]
[OnName num="nobunaga"]
I can't have a man in the castle if I don't know who he is. Answer me.
[cpg cn=true]


I knew I had no choice but to answer. It would be bad to be thrown out without a single ally in this day and age.
[cpg]

I had no choice but to answer honestly. Whether he believed me or not, he said, "I'm from another time.
[cpg]

[OnName num="keitarou"]
'......I'm from another time. From much further in the future than now."
[cpg cn=true]


Saying "time travel" shouldn't have conveyed the side letter in the first place.
[cpg]

[OnName num="keitarou"]
"Can we call it time travel,...... or is there such a concept in this time period?"
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Nobunaga030"]
[OnName num="nobunaga"]
From another time period,...... hmm."
[cpg cn=true]


Nobunaga was pondering. I was not laughing at me, nor was I angry at him for telling me the truth.
[cpg]

[OnName num="keitarou"]
He said, "You can't imagine what I'm talking about when I say this. In this day and age, there shouldn't even be that kind of creativity."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga031"]
[OnName num="nobunaga"]
No, it's not something I don't understand. If I were to go back to the Heian period, I would be laughed at for my funny attire.
[cpg cn=true]


It is said that Nobunaga was a very sharp man.
[cpg]

He ...... she may be able to understand things that people in the Warring States period could not understand.
[cpg]

In a time when there would have been no concept of time slips, Nobunaga had a good grasp of things.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga032"]
[OnName num="nobunaga"]
"You mean, in your time, they could do that kind of thing at will?　That's funny.
[cpg cn=true]


[OnName num="keitarou"]
Yes, it is. It was an accident that I traveled through time, or rather, there was no such technology. ......
[cpg cn=true]


[OnName num="keitarou"]
I touched a folding screen in a museum and was transported to this world.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga033"]
[OnName num="nobunaga"]
'That sounds more and more plausible. If he was caught up in the supernatural, it would explain why he came alone in this time period.
[cpg cn=true]


Nobunaga did not doubt. Rather, he was quick-witted enough to understand too quickly.
[cpg]

[OnName num="keitarou"]
Do you believe me?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga034"]
[OnName num="nobunaga"]
I believe you. If he came from the future, I would like to keep him by my side.
[cpg cn=true]


...... I see. Is it natural to think so?
[cpg]

I know about Nobunaga. I know about Nobunaga: that he would become the ruler of Japan, and that he would commit suicide in the Honnoji Incident.
[cpg]

I know that, and if I follow Nobunaga, the future may change.
[cpg]

In other words, maybe the future will come when Nobunaga takes the reigns of the country and rules Japan as it is. ......
[cpg]

But just as I was thinking that, he said, "Just don't tell me about the future.
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga035"]
[OnName num="nobunaga"]
But just as I was thinking that, he said, "Just don't tell me about the future. And don't tell anyone else.
[cpg cn=true]


[OnName num="keitarou"]
Why not?　Because I might be able to help you.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga036"]
[OnName num="nobunaga"]
If you know the future, you can do whatever you want. I don't want to be a coward.
[cpg cn=true]


Do you think so ......? Nobunaga seemed to want a fair fight, even in a situation where his life was at stake.
[cpg]

But I have a desire to be useful. The person who saved his life is mutually beneficial.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga037"]
[OnName num="nobunaga"]
'Not to change the subject, but do you have any idea what kind of times we are living in now?
[cpg cn=true]


[OnName num="keitarou"]
'To some extent. History was never my strong point.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga038"]
[OnName num="nobunaga"]
I'm sure Ranmaru will be able to explain that to you. In any case, you are interesting.
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Then I was fed.
[cpg]

At least Nobunaga is trying to keep me alive.
[cpg]

I don't know what Ranmaru thinks of me, but I know I'm being treated with a certain amount of generosity.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru016"]
[OnName num="ranmaru"]
What the hell are you, you ......!　You just showed up out of the blue and Nobunaga-sama likes you."
[cpg cn=true]


Ranmaru says to me as we move.
[cpg]

[OnName num="keitarou"]
I'm sorry.
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]

[VOICE f="Ranmaru017"]
[OnName num="ranmaru"]
Don't apologize right away!　You don't even know what's wrong.
[cpg cn=true]


I do know what's wrong.
[cpg]

Ranmaru, I believe, lost his life at Honnoji with Nobunaga.
[cpg]

 It's called Ichirentakushou, or the person who was closest to me.
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

Irritated, Ranmaru explained to me about this period.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru018"]
[OnName num="ranmaru"]
You know at least the Muromachi Shogunate," Ranmaru said. You know at least the Muromachi Shogunate.
[cpg cn=true]


[OnName num="keitarou"]
No, no, ...... that.
[cpg cn=true]


Nobunaga has stopped me from telling you that I am from another era.
[cpg]

[OnName num="keitarou"]
I have told Nobunaga, but I don't know if I can tell you everything.
[cpg cn=true]


Ranmaru turned bloody and said, "Nobunaga-sama, right!
[cpg]

[FACE method="shock_3" pos="2/3"]

[VOICE f="Ranmaru019"]
[OnName num="ranmaru"]
Nobunaga-sama, right!　If you're going to call me that, call me with a "Sama!"
[cpg cn=true]


He said something that certainly seemed to be true.
[cpg]

Nobunaga-sama is right, isn't it? I'm alive, too.
[cpg]

[OnName num="keitarou"]
I've already told Nobunaga-sama, but I don't know if I can tell Ranmaru-sama everything.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]

[VOICE f="Ranmaru020"]
[OnName num="ranmaru"]
What the hell, that's ...... all right."
[cpg cn=true]


Ranmaru-sama told me about this period with dismay.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru021"]
[OnName num="ranmaru"]
The Shogunate lost its power. To put it very simply, the patron lords were gone.
[cpg cn=true]


[OnName num="keitarou"]
"The patron lords ......?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru022"]
[OnName num="ranmaru"]
You really don't know, do you? Well, let me tell you.
[cpg cn=true]


I don't even understand Japanese history at a general education level. I'm really bad at history.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru023"]
[OnName num="ranmaru"]
I'm really not good at history. Just as their names are different, their characteristics are completely different.
[cpg cn=true]


[OnName num="keitarou"]
Since it's called Sengoku, they fought, didn't they?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru024"]
[OnName num="ranmaru"]
"They were fighting ......?　Why is it in the past tense?
[cpg cn=true]


Oh, no. That's funny too.
[cpg]

[OnName num="keitarou"]
They are fighting, aren't they?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru025"]
[OnName num="ranmaru"]
Well, ...... I don't know if I'll be alive tomorrow.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru026"]
[OnName num="ranmaru"]
It could die at any moment. Not even Nobunaga-sama can say that it won't."
[cpg cn=true]


The world is in the midst of warfare. The time when friend and foe are clearly divided and you can be killed even by your own side.
[cpg]

We have come to a terrible place. I thought I was prepared for it to some extent, but thinking about it again, it's a big deal.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

I changed into a kimono of this era because I thought it would be conspicuous if I stayed in my school uniform forever.
[cpg]

I think it is something a samurai would wear. If it was Nobunaga-sama's order, was he trying to turn me into a samurai?
[cpg]

Still, it helps that I don't have to worry about food and clothing.
[cpg]

It was unexpected that Nobunaga-sama liked me.
[cpg]

I think it was a good thing that I had told him everything honestly at that time.
[cpg]

[OnName num="keitarou"]
I wonder what I would have been like in the time of ...... Yuan."
[cpg cn=true]


I couldn't help but talk to myself. It was something I couldn't help but think about.
[cpg]

It would be a big deal if time was passing the same way on the other side of the world. I would probably be treated as missing.
[cpg]

That would mean I'd better get back as soon as possible. ......
[cpg]

But how is it possible for time to pass the same way in the present when I'm actually moving through time like this?
[cpg]

Of course, we don't know at what point we will return. In any case, do we have to hurry?
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

I was never let out of the castle, either.
[cpg]


[STOPBGM]
[window target=false]
[BG f="b_06_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

I don't have a phone or anything. I would be suffocating if I stayed in the castle all day.
[cpg]

[OnName num="keitarou"]
But is it okay? I might run away."
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru027"]
[OnName num="ranmaru"]
Nobunaga-sama's will about that. He wants to take care of something more important than the risk of you escaping. ......
[cpg cn=true]


What is it that he wants to take care of? I wonder, am I being expected to do something?
[cpg]

But I also told him not to tell me that he is from the future, and not to tell me what happened in the future.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru028"]
[OnName num="ranmaru"]
Damn, why is this guy ...... Nobunaga-sama thinking?"
[cpg cn=true]


Ranmaru-sama seems to like Nobunaga-sama very much. He seemed to be directing his jealousy toward me.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I had Ranmaru-sama follow me and I came a little further to the castle town.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『街』（朝）******************************************************

However, there was nothing in the castle town.
[cpg]

Apparently, there is no such thing as an affluent town in this era as there was in the Edo period.
[cpg]

I thought that must be true. It means that the peaceful time has not lasted that long.
[cpg]

[OnName num="keitarou"]
'......There's nothing here.'
[cpg cn=true]



;//下記のセリフ、台本の「街」がシナリオでは「町」に変わっています

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru029"]
[OnName num="ranmaru"]
'Nothing seems to be there?　It's such a rich town, it's so rare."
[cpg cn=true]


I'm not talking about the buildings being shorter ...... than they were in my time.
[cpg]

It's like looking at a period drama set, but more lived-in and realistic.
[cpg]

[OnName num="keitarou"]
I guess so." In this era, this is normal or ...... normal."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru030"]
[OnName num="ranmaru"]
What do you mean by this era,......, the way you say it?"
[cpg cn=true]


Even though the words came out unintentionally, Ranmaru-sama did not miss them.
[cpg]

The general of this era is supposed to be a very smart person.
[cpg]

They must be making sure they don't miss anything I say.
[cpg]

If it is to protect their beloved lord, it is even more so.
[cpg]

[OnName num="keitarou"]
No, it's nothing. It's nothing.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru031"]
[OnName num="ranmaru"]
"...... You're a funny guy."
[cpg cn=true]


Ranmaru-sama was suspicious, but said nothing more to me.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（昼）******************************************************

[SE f=se014]
;//【ＳＥ】『歩く』

Then I looked around the castle town for a while.
[cpg]

It was too big to be some kind of surprise. This time I understood that this was real.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

After that, Nobunaga-sama called me to her room.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga039"]
[OnName num="nobunaga"]
How are you doing? Have you gotten used to it?
[cpg cn=true]


[OnName num="keitarou"]
Yes, well... a little.
[cpg cn=true]


I guess I can assume that Nobunaga-sama likes me.
[cpg]

Just being allowed to stay in this castle is quite a feat.
[cpg]

But still,......, there is something that bothers me a little.
[cpg]

[OnName num="keitarou"]
Nobunaga-sama, do you know the lore about the princess warlord?
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga040"]
[OnName num="nobunaga"]
'Of course I do. The one who wears the robe of foreign lands. The Princess Warlord's bond will give you a son who eats the sky. ......, right?
[cpg cn=true]


[OnName num="keitarou"]
You know it?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga041"]
[OnName num="nobunaga"]
Everyone around here knows it. But I don't know what it means.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Nobunaga042"]
[OnName num="nobunaga"]
The one who wears the robe of the foreign lands may be ...... you.
[cpg cn=true]


[OnName num="keitarou"]
"Then, the princess warlord..."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Nobunaga043"]
[OnName num="nobunaga"]
"...... Indeed, if they knew who you were, various generals, and women for that matter, might seek you out."
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


I'm going to have a son,.......
[cpg]

I'm willing to do whatever it takes to survive in this world.
[cpg]

And if the child with the warlord has magical powers, he might be able to return to the present day.
[cpg]

I feel like that's where my role lies.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga044"]
[OnName num="nobunaga"]
But then again, what do you think? I'm sure there will be some inconvenience if you come from the future.
[cpg cn=true]


[OnName num="keitarou"]
I can't even tell you how much ......
[cpg cn=true]


It's so hard to get through to you.
[cpg]

I don't think I could go back from a cell phone to a cell phone or even a regular phone and explain it to her.
[cpg]

I wonder how people in this time period communicated with others.
[cpg]

[FACE method="shake_7" pos="2/3"]

[VOICE f="Nobunaga045"]
[OnName num="nobunaga"]
I hope Ranmaru doesn't realize that I'm from the future.
[cpg cn=true]


[OnName num="keitarou"]
I think he's probably fine.
[cpg cn=true]


I almost ragged on him a little, but I'm sure he'll be fine.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga046"]
[OnName num="nobunaga"]
That being said,...... I have something to tell you."
[cpg cn=true]


Nobunaga-sama looked a little more serious, then said
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga047"]
[OnName num="nobunaga"]
I'm sure you'll be fine. It may turn into a standoff. ......
[cpg cn=true]


I had no idea what he was talking about. I had no idea what he was talking about.
[cpg]

[OnName num="keitarou"]
He said, "...... Kai and Echigo, huh?"
[cpg cn=true]


I asked him again, although I vaguely knew where Kai and Echigo were.
[cpg]

I'm sure Nobunaga-sama is here, so it must be ...... from here to the east, right?
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga048"]
[OnName num="nobunaga"]
I don't think you understand. Have the names of places changed?
[cpg cn=true]


Nobunaga-sama was too perceptive.
[cpg]

[OnName num="keitarou"]
"You understand well, don't you ......?
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Nobunaga049"]
[OnName num="nobunaga"]
The future will be the same. The future will be the same.
[cpg cn=true]


After she said that, she thought about it for a moment.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga050"]
[OnName num="nobunaga"]
She then thought for a moment, "Takeda and Uesugi, can you tell?"
[cpg cn=true]


[OnName num="keitarou"]
She said, "Yes. Takeda Kenshin...... or Shingen?"
[cpg cn=true]


I spoke from my vague memory. Nobunaga-sama laughed a little.
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga051"]
[OnName num="nobunaga"]
I was a little confused. But you mean those two men will be handed down to the future?
[cpg cn=true]


Shingen Takeda and Kenshin Uesugi. I had at least heard of them.
[cpg]

But I don't know which one was closer to the Oda family, or even if they were on bad terms with each other.
[cpg]

[OnName num="keitarou"]
I have a name that is still clearly visible on ....... Though not as clearly as Nobunaga-sama's."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga052"]
[OnName num="nobunaga"]
'I suppose you are right. He must have been no match for me.
[cpg cn=true]


Nobunaga-sama was a man of considerable confidence. He seemed to have no doubt that he was the one whose name would remain in the future.
[cpg]

And he must have had the ability or the talent as a ...... warlord to match it.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga053"]
[OnName num="nobunaga"]
But if there are so many names left, I suppose you know who will win from now on.
[cpg cn=true]


If you ask me, I don't know. How would it have been ......?
[cpg]

I don't even know if the battle between the two has been settled. I don't even know.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga054"]
[OnName num="nobunaga"]
But don't tell me. It's against my principles to know the status of a battle in advance.
[cpg cn=true]


[OnName num="keitarou"]
No, no, ...... don't worry about it. I don't know either.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]

[VOICE f="Nobunaga055"]
[OnName num="nobunaga"]
What? Don't you care about history?　Or are you so far in the future that the past is a blur?
[cpg cn=true]


Both are correct. Either way, I can't tell you anything.
[cpg]

I don't know which house survives: ......
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga056"]
[OnName num="nobunaga"]
I think they'll be generals that everyone will know, no matter how far into the future they are, but I hear that's not the case."
[cpg cn=true]


Nobunaga-sama says, also a bit curious.
[cpg]

[OnName num="keitarou"]
'By "they," you mean ...... those two are women too?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga057"]
[OnName num="nobunaga"]
Yes," he said. Yes," he said, "are they women too?
[cpg cn=true]


I'm not curious, because according to the history I know, both of them are men.
[cpg]

I mean, all military commanders are men. I probably shouldn't say that either.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga058"]
[OnName num="nobunaga"]
I'll take the opportunity to write about them at ....... I would like you to go to Kai ...... Takeda.
[cpg cn=true]


[OnName num="keitarou"]
Me?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
Nobunaga-sama nodded. I didn't know what he meant.
[cpg]

[OnName num="keitarou"]
What do you mean you're on your way to Takeda?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga059"]
[OnName num="nobunaga"]
No, that's not why I'm going. I'm just trying to make you a better servant.
[cpg cn=true]


[OnName num="keitarou"]
What kind of ...... is that?
[cpg cn=true]


I did not understand what Nobunaga-sama was trying to tell me.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga060"]
[OnName num="nobunaga"]
I'm sure there's a lot you don't know about this period of time.
[cpg cn=true]


Apparently, he wanted to teach me what the Warring States period was all about. He continued, "Eventually, you will become a warlord and a tailor.
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga061"]
[OnName num="nobunaga"]
Eventually, I will make you a warlord. You'd better prepare yourself.
[cpg cn=true]


[OnName num="keitarou"]
I can't even imagine.
[cpg cn=true]


I can't even imagine. I'm a warlord?
[cpg]

I can't even imagine if I would ever lead an army.
[cpg]

And there was a problem before that.
[cpg]

[OnName num="keitarou"]
When you say you're on your way to Takeda, are you sure you want me to go there myself?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Nobunaga062"]
[OnName num="nobunaga"]
I was thinking, "Oh, I don't know. Do you think there is a problem?
[cpg cn=true]


I don't think there is a problem or anything, I think it's a big problem. Because ......
[cpg]

[OnName num="keitarou"]
"Don't you think that I might ...... be on Takeda's side?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga063"]
[OnName num="nobunaga"]
If that happens, I will do everything in my power to crush you. I'm going to crush you with all my might if that happens.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga064"]
[OnName num="nobunaga"]
If you don't want to die, serve me. If you don't want to die, serve me. All my enemies will perish.
[cpg cn=true]


I shuddered, but Nobunaga-sama laughed at me.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga065"]
[OnName num="nobunaga"]
If you think you have something to gain by betraying me, so be it. I don't even think I look that weak."
[cpg cn=true]


I see. I see. He was thinking that much before he said and did what he did.
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[OnName num="keitarou"]
"......, you're in a lot of trouble. ......"
[cpg cn=true]


I'm going to be a warlord? Maybe that's the way to survive in this world.
[cpg]

If you are under Nobunaga-sama and you are not a warlord, you may have to fight as a soldier.
[cpg]

It would not be acceptable to just stay by his side and do nothing.
[cpg]

Since Nobunaga-sama, a woman, is a military commander, it would be even more so for me, a man.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

From that day on, preparations for departure began.
[cpg]

Would I have to walk for a while? Or would I have to ride a horse?
[cpg]

Either way, it was going to be tough. Would I be able to do it?
[cpg]


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

While I was thinking about it, night fell.
[cpg]

The time seemed to pass by in an unusually long time.
[cpg]

There was nothing to occupy my time, and the only people in the castle were strangers.
[cpg]

In addition, I felt that Nobunaga-sama was jealous of me because he liked me.
[cpg]

So I didn't talk to anyone and think about what I was going to do.
[cpg]

It must be quite a big move. These are the days of no cars and nothing else.
[cpg]

[OnName num="keitarou"]
We'll just have to do it. ......
[cpg cn=true]


I talk to myself with anxiety. I'm good at sports, and I think I have the physical strength, but I wonder how well I'll do.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

Then came the day of departure.
[cpg]

Naturally, there was no way we could head out with a small group, so there were quite a few warriors there.
[cpg]

Everything was ready. All we had to do was walk.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru032"]
[OnName num="ranmaru"]
"All right," he said. Let's head out then.
[cpg cn=true]


But still, Ranmaru-sama is a girl,......, with a slender body that doesn't seem to be able to walk long distances.
[cpg]

[OnName num="keitarou"]
......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru033"]
[OnName num="ranmaru"]
What is it?　Stare at me.
[cpg cn=true]


[OnName num="keitarou"]
No, nothing ......."
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se014]
;//【ＳＥ】『歩く』

But when it came time to start walking, Ranmaru-sama was tougher.
[cpg]

Of course he was, since he was living as a warlord in this era.
[cpg]

And the move went beyond the word tough; it was life-threatening.
[cpg]

I had never really imagined it, but in this era, horses were only used when the occasion called for it.
[cpg]


[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

Night was hard at night. I couldn't sleep.
[cpg]

I could not carry my exhausted body into the next day.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru034"]
[OnName num="ranmaru"]
"I guess I'm not as strong as I thought I'd be.
[cpg cn=true]


[OnName num="keitarou"]
I'm sorry. ......
[cpg cn=true]


I wonder where Ranmaru-sama's thin body has such energy.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

Day, night, day, night, and more and more time passes.
[cpg]

My sense of time is getting strange and I speak less and less.
[cpg]

I want to reach my destination as soon as possible, but it is difficult to walk fast.
[cpg]

And everyone was walking so fast. If I got left behind, it would be the end.
[cpg]


[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]

;//【ＢＧ】『山道』（夜）******************************************************

If I hadn't joined the sports club, I would be dead by now.
[cpg]

I realize that I am lucky to have built up some muscle mass.
[cpg]

In this day and age, there's not much you can rely on other than your body: ......
[cpg]



[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]


;//【ＢＧ】『山道』（昼）******************************************************

And just when you think you're at the end of your rope, you go to ......
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『街』（夕方）******************************************************

[OnName num="keitarou"]
"......"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru035"]
[OnName num="ranmaru"]
We're here. Keitaro, are you okay?
[cpg cn=true]


[OnName num="keitarou"]
I think I'm going to collapse.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru036"]
[OnName num="ranmaru"]
"You can't afford to be overwhelmed by something like this. ......The battlefield is a much tougher place."
[cpg cn=true]


Yes, that's right. I'm pretty sure that's what it is, too.
[cpg]

But just for today, I want to get a good night's sleep. ......
[cpg]


[SE f=se014]
;//【ＳＥ】『歩く』


;//ブラックアウト
[free time=1000]
[BG f="b_13_4.ui" time=1000]
[WAIT time=1100]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

I reached the castle and slept like a mud.
[cpg]

Takeda Shingen, that man I never got to meet.
[cpg]

I decided to leave the hard part to Ranmaru-sama, who had more than enough energy ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（朝）******************************************************



And the next morning.
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen001"]
[OnName num="shingen"]
Shingen said, "Nice to meet you. Are you the Keitaro Nobunaga was talking about?
[cpg cn=true]


[OnName num="keitarou"]
Yes, I am. Thank you for letting me stay here yesterday.
[cpg cn=true]


I was one-on-one with Shingen, without Ranmaru-sama present.
[cpg]

No, Shingen-sama, I should call you. If Nobunaga-sama sent me, then we must be on friendly terms.
[cpg]

There may not be at this time a superior position of either Nobunaga-sama or Shingen-sama.
[cpg]

But at least from my point of view, they are above the clouds.
[cpg]

[OnName num="keitarou"]
You said that a ...... war might be about to begin.
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Singen002"]
[OnName num="shingen"]
That's right. It won't be decided soon.
[cpg cn=true]


The battle of Kawanakajima. I know that much.
[cpg]

The actuality that the actual battle is not going to be settled anytime soon. And they have been fighting for quite a long time.
[cpg]

And they're in the middle of it right now.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen003"]
[OnName num="shingen"]
Between you and me, ...... I don't think I want to fight this battle.
[cpg cn=true]


[OnName num="keitarou"]
Huh?"
[cpg cn=true]


Is that so?　If so, it's kind of a bad idea.
[cpg]

It means that one of the most important battles that ever happened in history will be lost.
[cpg]

It would change the future, so even if we go back to the original time, it might not be the Japan I know.
[cpg]

[OnName num="keitarou"]
I don't know. If we try to fight, we might easily win.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen004"]
[OnName num="shingen"]
"You have no basis for that. ...... But I'll take it if you're rooting for me."
[cpg cn=true]


I was a little relieved when Shingen-sama said that.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen005"]
[OnName num="shingen"]
I've heard rumors about you. I've heard rumors that you've blended in from another world?
[cpg cn=true]


[OnName num="keitarou"]
"You know a lot about ......, don't you?"
[cpg cn=true]


I wonder if it is possible in this day and age to hear rumors.
[cpg]

I was wondering if Nobunaga-sama was making rumors about me with the best of intentions.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen006"]
[OnName num="shingen"]
'Certainly, you have an air of buoyancy about you,...... ghosh, ghosh.
[cpg cn=true]


[OnName num="keitarou"]
Are you all right!"
[cpg cn=true]


Shingen-sama suddenly coughed. It stopped right away.
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen007"]
[OnName num="shingen"]
I'm sorry. I have tuberculosis. Don't worry about it.
[cpg cn=true]


[OnName num="keitarou"]
"......, I didn't know you had tuberculosis.
[cpg cn=true]


Tuberculosis. Tuberculosis, an incurable disease in this day and age.
[cpg]

Come to think of it, while I knew that Shingen-sama and Kensin were at odds with each other, I had no recollection of either of them defeating the other.
[cpg]

Maybe Shingen-sama died of the disease. ......
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Singen008"]
[OnName num="shingen"]
I wonder. You seem to be saying something.
[cpg cn=true]


[OnName num="keitarou"]
...... no.
[cpg cn=true]


I thought about it, but kept it to myself.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[OnName num="keitarou"]
Oh, Ranmaru-sama.
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru037"]
[OnName num="ranmaru"]
Did you see Shingen-sama?　How did he seem?
[cpg cn=true]


[OnName num="keitarou"]
How was it?" "I don't know what you mean, ......."
[cpg cn=true]


There was nothing complicated to talk about.
[cpg]

I don't even know how much Shingen-sama knows about me.
[cpg]

[OnName num="keitarou"]
He was a hard man to read.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru038"]
[OnName num="ranmaru"]
I guess he was. I have the same impression.
[cpg cn=true]


Nobunaga-sama is rather easy to understand. She has no back and forth.
[cpg]

 I felt that there was a contrast with Shingen-sama.
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

Later that evening, I was still at the castle.
[cpg]

I was very tired and it was difficult to go back to Nobunaga-sama's place right away.
[cpg]

I was to stay at the castle for a while.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru039"]
[OnName num="ranmaru"]
I asked him, "Keitaro, how are you feeling? How are you feeling?
[cpg cn=true]


[OnName num="keitarou"]
"My leg still hurts.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru040"]
[OnName num="ranmaru"]
I see. I'm sorry, but we're going to have to leave again soon.
[cpg cn=true]


I was listening to the conversation with dismay. Then I heard a message from ......
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]


[VOICE f="Singen009"]
[OnName num="shingen"]
Good evening, Keitaro. Keitaro, may I have a word?
[cpg cn=true]


[FACE method="change_7" pos="4/5"]

[VOICE f="Ranmaru041"]
[OnName num="ranmaru"]
Shingen-sama,...... what can I do for you?"
[cpg cn=true]


Ranmaru-sama looks alarmed.
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Singen010"]
[OnName num="shingen"]
I see that ...... Ranmaru is there too. Well, fine.
[cpg cn=true]


Shingen-sama then looks not at Ranmaru-sama, but at me.
[cpg]

I have something important to tell you. Saying that, Shingen-sama approached me.
[cpg]

I think Shingen-sama has a kind of sexy expression on his face.
[cpg]

I didn't know why he had that look on his face.
[cpg]

She is ...... horrifyingly beautiful. You said I'm a floater, but isn't she the one?
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Singen011"]
[OnName num="shingen"]
I'm not as brutal as Nobunaga.　I am not as brutal or harsh as Nobunaga.
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="4/5" time=1]
She whispers to me. And then she comes closer to me.
[cpg]

[FACE method="change_2" pos="2/5"]
She put her hand on my ear. Then he smiles wryly.
[cpg]

I was in trouble, and I didn't know what to say.
[cpg]

The fact that he touched me with the words, "I don't think you can use me. ......
[cpg]

If I serve you, does that mean you'll do that too?
[cpg]

A lot of thoughts went through my mind. He might try to ask me out before serving me.
[cpg]

But seeing such a gesture, Ranmaru-sama became angry.
[cpg]

[FACE method="shock_3" pos="4/5"]

[VOICE f="Ranmaru042"]
[OnName num="ranmaru"]
He said, "Hey!　Even Shingen-sama would not listen to you.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]

[VOICE f="Singen012"]
[OnName num="shingen"]
I was joking. He would never seriously say such a thing.
[cpg cn=true]


I think, at a loss for a response.
[cpg]


;//■選択肢
[switch]
[case "I don't answer anything."]
	[swap]
	[jump target="*select_shingen01"]
[case "I thank him."]
	[swap]
	[jump target="*select_shingen02"]
[endswitch]

1. I don't answer.
Two, I thank him.


;//==============================
;//１、何も答えない

*select_shingen01|The one who wears the garb of foreign lands

[OnName num="keitarou"]
......"
[cpg cn=true]


[FACE method="shake_6" pos="2/5"]

[VOICE f="Singen013"]
[OnName num="shingen"]
I'm not going to give you that look. It just means I care about you."
[cpg cn=true]


I made no reply. I owe a debt of gratitude to Nobunaga-sama,......
[cpg]



[stflag Cha2flg=0]

[jump target="*select_shingen03"]


;//ヒロイン２ルートへの可能性が無くなる

;//==============================
;//２、お礼を言う

*select_shingen02|The one who wears the robe of foreign lands.

[OnName num="keitarou"]
Thank you."
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]

[VOICE f="Ranmaru043"]
[OnName num="ranmaru"]
'Even Keitaro ......!　Are you really going to betray me?"
[cpg cn=true]


Ranmaru-sama stared at me. But Shingen-sama was smiling at him.
[cpg]

I wonder if I'll ever serve Shingen-sama......
[cpg]


[stflag Cha2flg=1]


[jump target="*select_shingen03"]

;//ヒロイン２ルートへの可能性が残る

;//==============================

*select_shingen03|The one who wears the robe of foreign lands

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

More time passed, and at night. I had a dream.
[cpg]


;//ブラックアウト

;//夢の中であるため、色調をグレースケールにしてください
;//＠
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

There was a woman who was neither Shingen-sama nor Nobunaga-sama.
[cpg]

She was dressed like a nun. I wondered who she was, and then I saw ......
[cpg]

[OnName num="samurai"]
She said, "Kenshin-sama. We can still fight.
[cpg cn=true]


I heard the words, "Kenshin-sama. I was dreaming, but it sounded so clear.
[cpg]

[FACE method="bow_4" pos="2/3"]

[VOICE f="Kensin001"]
[OnName num="kenshin"]
Yes. We can't back down now, can we?
[cpg cn=true]


Her face looked very tired.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Kensin002"]
[OnName num="kenshin"]
I wonder how long this kind of battle will continue.
[cpg cn=true]


That man, Kenshin,......, somehow has the image of being a brave man in history, but.
[cpg]

Both Shingen-sama and Kenshin seemed not to be that belligerent.
[cpg]


;//ブラックアウト

;//色調を戻してください

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（朝）******************************************************

[OnName num="keitarou"]
......"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru044"]
[OnName num="ranmaru"]
You're awake. You were dreaming, weren't you?
[cpg cn=true]


I was having a nightmare. I don't get the impression that it was that bad of a dream.
[cpg]

But it was a ...... kind of unpleasant dream.
[cpg]

[OnName num="keitarou"]
No, it was nothing.
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

The muscle pain has finally subsided and I've regained some of my strength.
[cpg]

Ranmaru-sama doesn't even look tired.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru045"]
[OnName num="ranmaru"]
I think we'll be leaving again tomorrow or so," he said. You'd better be ready by then.
[cpg cn=true]


[OnName num="keitarou"]
"......Yes."
[cpg cn=true]


Yes," was all I could say. The thought of going down that road again was not something I was keen on. ......
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

That night, too, I was invited by Shingen-sama.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen014"]
[OnName num="shingen"]
'Yes. You had a dream like that,......."
[cpg cn=true]


[OnName num="keitarou"]
'Yes,...... she seemed to be in some kind of distress.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen015"]
[OnName num="shingen"]
Yes, she is a nun. You may have seen the real her.
[cpg cn=true]


I certainly didn't know that Kenshin was a religious enthusiast, and yet she was a nun.
[cpg]

It is strange that I saw her as a nun.
[cpg]

I have already gone back in time.
[cpg]

I wouldn't be surprised if any more strange things happened: ......
[cpg]

[FACE method="bow_7" pos="2/3"]

[VOICE f="Singen016"]
[OnName num="shingen"]
'She may be in agony because of her. She may really not want to fight me.
[cpg cn=true]


Maybe that's what warfare is all about. I have to fight for my life.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen017"]
[OnName num="shingen"]
So you really don't plan to serve me?"
[cpg cn=true]


[OnName num="keitarou"]
Because I serve ...... Nobunaga-sama."
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

Shingen-sama approaches me as I answer that.
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen018"]
[OnName num="shingen"]
'Nobunaga ...... she will not allow you to be physical with her. She is an ascetic. But I am not."
[cpg cn=true]


It's getting kind of crazy. I couldn't push her away as she approached me.
[cpg]

[OnName num="keitarou"]
What do you mean?"
[cpg cn=true]


I asked her, knowingly.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen019"]
[OnName num="shingen"]
Don't you get it?
[cpg cn=true]


I know. Shingen-sama might know that I am from the future.
[cpg]

She is frail. She is frail, and considering that, there is no way she would just let me leave without telling me.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Singen020"]
[OnName num="shingen"]
I will do whatever it takes to keep me alive.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Singen021"]
[OnName num="shingen"]
Only ...... as you can see, she is frail and will not be able to bear children."
[cpg cn=true]


Shingen-sama brings her face so close to mine that our lips almost touch.
[cpg]

She must be aware of her good looks, I thought.
[cpg]

[OnName num="keitarou"]
'...... you should take better care of yourself. Do this ...... to me."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Singen022"]
[OnName num="shingen"]
'It's because I do take care of you. I don't think I'm making the wrong choice."
[cpg cn=true]


......What am I going to do? I need to be with someone, anyone, someday.
[cpg]

They say that a child born to me and the princess warlord will have magical powers.
[cpg]

If so, I really need to get back to the future.
[cpg]

But ...... is Shingen-sama the right partner for that?
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


In the end, unable to give an answer, I did not accept Shingen-sama's invitation.
[cpg]


;//移植前シーンカット

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

She looked a little sad. But it can't be helped, I'm not ready.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen065"]
[OnName num="shingen"]
'I'm doing this because it's you. You may have guessed that.
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


I fall silent. She is trying to win me over.
[cpg]

Of course, I am indebted to Nobunaga-sama. I should not flirt with her so easily.
[cpg]

I thought about it and came up with an answer.
[cpg]


;//※ストーリーが分岐
;//　１を選んだ場合、ヒロイン１、ヒロイン４、ヒロイン５ルートへ
;//　２を選んだ場合、ヒロイン２、ヒロイン３ルートへ

;//※ただし、以前の選択肢で「１、何も答えない」を選んでいた場合、この選択肢は発生せず１を選んだことになる



[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*select_root145"]
[endif]

;//■選択肢
[switch]
[case "I will not serve her."]
	[swap]
	[jump target="*select_root145"]
[case "I will serve Shingen."]
	[swap]
	[jump target="*select_root23"]
[endswitch]

1, I do not intend to serve him.
2, I will serve Shingen.


*select_root145
[jump storage="ep001.ks" target="*start"]

*select_root23
[jump storage="ep006.ks" target="*start"]
