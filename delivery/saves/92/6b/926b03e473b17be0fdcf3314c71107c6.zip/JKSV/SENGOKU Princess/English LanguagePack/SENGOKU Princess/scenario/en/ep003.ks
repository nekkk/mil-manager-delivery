
*start

;//==============================
;//稲生の戦いで勝利していた場合

*root_1|Oda Nobunaga under Heaven

;#################################################
*Ep003|Oda Nobunaga under the heaven
;#################################################

[SCENE id=3]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru091"]
[OnName num="ranmaru"]
What is this silence? This silence."
[cpg cn=true]


Ranmaru-sama broke the silence first. A subtle air of embarrassment flowed between us.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru092"]
[OnName num="ranmaru"]
Anyway!　I will support Nobunaga-sama at all costs.
[cpg cn=true]


Ranmaru-sama looked away and said.
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru093"]
[OnName num="ranmaru"]
But I'm trying to say that you can do more than just support them.
[cpg cn=true]


[OnName num="keitarou"]
What do you mean?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru094"]
[OnName num="ranmaru"]
I mean that you can be Nobunaga-sama's husband. That's how much he likes you.
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru095"]
[OnName num="ranmaru"]
Really, please. There is no one but you. I just can't do it myself."
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

That night, Nobunaga-sama called out to me.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga267"]
[OnName num="nobunaga"]
I see you've gotten used to living in a castle.
[cpg cn=true]


[OnName num="keitarou"]
Yes, well, ......, what can I do for you?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga268"]
[OnName num="nobunaga"]
What can I do for you? I just wanted to make sure.
[cpg cn=true]


What is it?　What is it?
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru096"]
[OnName num="ranmaru"]
I also want to make sure of something. Keitaro and Nobunaga-sama are ...... that ......
[cpg cn=true]


Not only Nobunaga-sama, but also Ranmaru-sama and Mitsuhide-sama were there.
[cpg]

[FACE method="shake_7" pos="2/5"]

[VOICE f="Mituhide027"]
[OnName num="mitsuhide"]
Ranmaru.
[cpg cn=true]


[FACE method="shock_3" pos="4/5"]

[VOICE f="Ranmaru097"]
[OnName num="ranmaru"]
"But ...... I was curious.
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Mituhide028"]
[OnName num="mitsuhide"]
I'm not anyone's property, Keitaro-san. Isn't that right?"
[cpg cn=true]


While saying that, Mitsuhide-sama was Mitsuhide-sama, and I felt he was trying to monopolize me.
[cpg]

 Ranmaru-sama can't think of anything to me.
[cpg]

It's like a harem situation. From behind the scenes, it could be like he's controlling the whole country. ......
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Nobunaga269"]
[OnName num="nobunaga"]
Hmph."
[cpg cn=true]


Nobunaga-sama then made some really unimportant small talk.
[cpg]

She wanted to make sure, I guess, that I was liked by everyone.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_04"]


;//【ＢＧ】『城＿室内』（夜）******************************************************

Then I went back to my room. I thought about my future with Nobunaga-sama.
[cpg]

Ranmaru-sama approves of me. So I guess I didn't need to hesitate.
[cpg]

After Ranmaru-sama told me, I became aware of the dreamy idea of becoming Nobunaga-sama's husband.
[cpg]

However, Nobunaga-sama will eventually die in the Honnoji Incident.
[cpg]

I must avoid that at all costs. I want to live with Nobunaga-sama.
[cpg]

A sleepless night. My room was visited by ......
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga270"]
[OnName num="nobunaga"]
"Keitaro. Are you already asleep?
[cpg cn=true]


[OnName num="keitarou"]
...... No.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga271"]
[OnName num="nobunaga"]
I see. I've been thinking about what you said since then. ......
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Nobunaga272"]
[OnName num="nobunaga"]
Something is happening to me, isn't it?
[cpg cn=true]


Nobunaga-sama gets to the heart of the matter.
[cpg]


;//ブラックアウト

;//移植前シーンカット

;//========================================
;//●ＣＧ（主人公に迫るヒロイン。主人公の体に触れている）ev_01
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//備考　：ヒロイン１の部屋は城内の一室です
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]



She approaches me.
[cpg]


[VOICE f="sNobunaga013"]
[OnName num="nobunaga"]
Keitaro's body is still very muscular. I am reminded once again that he is a man.
[cpg cn=true]


[OnName num="keitarou"]
Nobunaga-sama ......
[cpg cn=true]



[VOICE f="sNobunaga014"]
[OnName num="nobunaga"]
Keep listening.
[cpg cn=true]



[VOICE f="Nobunaga273"]
[OnName num="nobunaga"]
You don't have to answer right away. You're probably wondering the same thing.
[cpg cn=true]


Nobunaga-sama seemed to understand my fear of changing the future.
[cpg]

The present day I was in might be gone. I may never be able to return.
[cpg]


;**【ＣＧ】 ev_01_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNobunaga015"]
[OnName num="nobunaga"]
But I want you to do me this one favor. Keitaro, ......
[cpg cn=true]



[VOICE f="sNobunaga016"]
[OnName num="nobunaga"]
I want to have a child with you.
[cpg cn=true]


[OnName num="keitarou"]
"...... Nobunaga-sama."
[cpg cn=true]


Nobunaga-sama seemed to love me dearly.
[cpg]


;//移植前シーンカット

;//ブラックアウト

[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************


[VOICE f="Nobunaga323"]
[OnName num="nobunaga"]
I don't want anyone to see me like this,.......
[cpg cn=true]


[OnName num="keitarou"]
Yes,......."
[cpg cn=true]


I've never been so happy. But this happiness is going to be lost someday.
[cpg]

I think I have no choice but to act. She was finally going to tell me everything.
[cpg]

She was going to die in the Honnoji Incident. I'm going to tell her to stop it.
[cpg]

Perhaps the future will be distorted. Knowing the repercussions of doing so.
[cpg]

[STOPBGM]


[OnName num="keitarou"]
Nobunaga-sama. I have something important to tell you.
[cpg cn=true]

[BGM f="bg_04"]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga324"]
[OnName num="nobunaga"]
What is it?　Is it something you've been hiding from me all this time?
[cpg cn=true]


[OnName num="keitarou"]
You know everything, don't you? That's right.
[cpg cn=true]


I took a deep breath to calm myself. After that, I said the words.
[cpg]

[OnName num="keitarou"]
Nobunaga-sama. Mitsuhide-sama has ......."
[cpg cn=true]


At the moment I was about to say, "Watch out for Mitsuhide-sama," my body gradually became translucent and semi-transparent.
[cpg]


[transition target={true} rule="moya.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1000]

My body was gradually becoming translucent and translucent.
[cpg]

[FACE method="shock_5" pos="2/3"]

[VOICE f="Nobunaga325"]
[OnName num="nobunaga"]
What was that?　What was that about ......?
[cpg cn=true]


When I didn't say anything after the words "to Mitsuhide-sama," my body returned to normal.
[cpg]

[OnName num="keitarou"]
'Oh, so that's what you mean .......'
[cpg cn=true]


I had an idea. By changing the future, what happens in the future changes.
[cpg]

That means there will be a future in which I will not be born.
[cpg]

I was supposed to have come from that future, but I was destined to disappear.
[cpg]

[OnName num="keitarou"]
"...... haha."
[cpg cn=true]


I can't save Nobunaga-sama, apparently. Realizing this, I started to laugh dryly.
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga326"]
[OnName num="nobunaga"]
Keitaro, what is the meaning of this? Explain it to me.
[cpg cn=true]


[OnName num="keitarou"]
"......."
[cpg cn=true]


I did not explain to Nobunaga-sama, and at that time I just kept silent.
[cpg]

Nobunaga-sama did not pursue me any further.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

Nobunaga-sama then returned to his room.
[cpg]

The morning was coming. No matter how many worries he had, he was tired and fell asleep.
[cpg]

[OnName num="keitarou"]
He was tired and had fallen asleep. "...... morning or ......"
[cpg cn=true]


When I woke up and Nobunaga-sama was not there, I was driven by anxiety.
[cpg]

We do not know when the Honnoji Incident will occur.
[cpg]

To begin with, time is moving faster in this world where I am than in historical fact.
[cpg]

The next time you wake up, it is possible that you will not be able to see him again.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru098"]
[OnName num="ranmaru"]
"Keitaro, are you awake? You're awake, you've been having a nightmare.
[cpg cn=true]


[OnName num="keitarou"]
'...... Ranmaru-sama.'
[cpg cn=true]


Seeing her makes me feel a little safer.
[cpg]

Ranmaru-sama must have followed Nobunaga-sama in the Honnoji Incident.
[cpg]

That means that at least while she's here, we'll be okay. ......
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru099"]
[OnName num="ranmaru"]
You look pale. Are you not sleeping well?"
[cpg cn=true]


[OnName num="keitarou"]
No, I don't mind. 
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Ranmaru100"]
[OnName num="ranmaru"]
I'm fine, but don't make that kind of face in front of Nobunaga-sama. He must be worried.
[cpg cn=true]


Do I have that look on my face? If so, I must be firm.
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

Unable to stay still in the castle, I went outside.
[cpg]

I think it's safe to say that it's peaceful. The country is being unified.
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_01_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（昼）******************************************************

Seeing the castle town bustling with people, I felt as if this peace would last forever.
[cpg]

But I am wrong. She will never rule Japan like this.
[cpg]

I feel unwilling to do anything about it. What should I do?
[cpg]


[window target=false]
[BG f="b_01_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************

I think what she, Nobunaga-sama, wanted was this peace.
[cpg]

And yet, it must have been what the people of the town had been waiting for, too.
[cpg]

Why should Nobunaga-sama, who should have contributed the most, suffer such misfortune?
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


At first I thought I had to talk to Mitsuhide-sama, but in the end it would be the same thing if I let her dissuade me.
[cpg]

I would disappear, and it would be a future in which I would not be born.
[cpg]

That's what it means to change history in a big way. ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『村』（夜）******************************************************

I had come to the first village I was in when I was transported to this time period.
[cpg]

Is that lore really lore? If it was spontaneous, even Nobunaga-sama knew about it.
[cpg]

I feel as if someone has added their hand to it. It seemed to be something that had been deliberately incorporated.
[cpg]

[OnName num="villager"]
I was surprised to hear that he had been working on it for a long time. It's been a while.
[cpg cn=true]


[OnName num="keitarou"]
Can you tell me more about the lore?
[cpg cn=true]


[OnName num="villager"]
I don't know more than you know. I don't know any more than you know.
[cpg cn=true]


[OnName num="keitarou"]
I don't feel comfortable with it. It doesn't feel right. It doesn't feel like lore.
[cpg cn=true]


[OnName num="villager"]
"I agree with ....... It can be suspicious.
[cpg cn=true]


The villager was silent for a moment, then said, "I can only imagine what I'm about to tell you.
[cpg]

[OnName num="villager"]
The villagers were silent for a moment, then said, "What I'm about to tell you is only my imagination, but please listen with that in mind. But please listen to me with that in mind.
[cpg cn=true]


[OnName num="villager"]
In the distant future. If we were able to manipulate time, we might be able to ......
[cpg cn=true]


[OnName num="villager"]
"I might be able to suppress the anomalies that have occurred in the past.
[cpg cn=true]


[OnName num="keitarou"]
...... "You think that's why I was called here?"
[cpg cn=true]


[OnName num="villager"]
'Well, listen to me. How do you restore a great man who is no longer operating according to history?
[cpg cn=true]


[OnName num="villager"]
"Rather than having someone from the future who knows it all alter it, it might be more natural for someone who knows a little bit of future ...... history to act naturally.
[cpg cn=true]


I listened in silence. This person is probably a person from the future disguised as a person from this time period.
[cpg]

[OnName num="villager"]
It's like implanting cells into damaged internal organs. Do you understand?"
[cpg cn=true]


[OnName num="keitarou"]
I can't alter history, is what you're saying.
[cpg cn=true]


[OnName num="villager"]
I'll leave that to you to decide. That's the whole reason I called you here.
[cpg cn=true]



;//ブラックアウト
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

......That's a crazy story. But it wasn't impossible to understand.
[cpg]

Implanting cells. Well, there are certainly things that can go wrong with something that is entirely artificial.
[cpg]

Maybe history can be connected because of the will of people who know nothing about it.
[cpg]

If that's the case,...... what should I do?
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夕方）******************************************************

I was on my way to her room when Nobunaga-sama called me.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Nobunaga327"]
[OnName num="nobunaga"]
Ranmaru told me you've been acting strangely. Something is wrong.
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga328"]
[OnName num="nobunaga"]
The other day, your body seemed to be transparent. If I'm not mistaken.
[cpg cn=true]


[OnName num="keitarou"]
That's ......
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga329"]
[OnName num="nobunaga"]
If you can't tell me everything, you don't have to. But at least be your normal Keitaro now.
[cpg cn=true]


Nobunaga-sama seemed to know that she was in danger.
[cpg]

I cursed myself for not being able to save her, but I wanted to at least fulfill her wish to be the normal me. ......
[cpg]


;//========================================
;//●ＣＧ（主人公を抱きしめるヒロイン）ev_68
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿ヒロイン１の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_68_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="keitarou"]
'Nobunaga-sama,...... I love you.
[cpg cn=true]



[VOICE f="Nobunaga330"]
[OnName num="nobunaga"]
I know, but it's embarrassing to be dared to say it."
[cpg cn=true]


This time will not last indefinitely. Rather, soon, we will be separated.
[cpg]

I just wanted to forget about my anxiety, just for now.
[cpg]


[VOICE f="sNobunaga017"]
[OnName num="nobunaga"]
......Keitaro. Don't give me that look.
[cpg cn=true]


Did I look sad? Did I look regretful?
[cpg]

It was true that I wanted to reassure Nobunaga-sama just now.
[cpg]


;//移植前シーンカット
;//ブラックアウト
;//移植前シーンカット
;//ブラックアウト

[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夕方）******************************************************


[VOICE f="Nobunaga377"]
[OnName num="nobunaga"]
...... Hey. Keitaro.
[cpg cn=true]


[OnName num="keitarou"]
What is it?　Nobunaga-sama.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga378"]
[OnName num="nobunaga"]
I want to have a child with you someday. When the time of peace comes.
[cpg cn=true]


[OnName num="keitarou"]
'...... I see. If that were to come true, it would be like a dream.
[cpg cn=true]


We talk about such things while cuddling together with Nobunaga-sama.
[cpg]

But only I know that it is an unfulfilled wish.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga379"]
[OnName num="nobunaga"]
'I have never wanted someone so badly before. Keitaro is the first.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga380"]
[OnName num="nobunaga"]
Will you grant me my wish?　Keitaro."
[cpg cn=true]


I had no answer. It would be possible to have a child with her, but.
[cpg]

I probably wouldn't be able to raise a child with her in any way.
[cpg]

And I couldn't say it out loud.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I couldn't say anything important.
[cpg]

But I had no choice. I had no other choice.
[cpg]

I almost disappeared trying to change the future.
[cpg]

In short, I have to choose between two ...... options.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

Night. Walking down the hallway, I saw Mitsuhide-sama.
[cpg]

[OnName num="keitarou"]
"...... Mitsuhide-sama."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide029"]
[OnName num="mitsuhide"]
Good evening. Is something wrong?"
[cpg cn=true]


She's going to kill Nobunaga-sama. I had mixed feelings.
[cpg]

Would Mitsuhide-sama do such a thing?　No, there had been hints of it before.
[cpg]

[OnName num="keitarou"]
No, nothing.
[cpg cn=true]


She once made a proposal to me as if she was flirting with me.
[cpg]

She must be serious. If she wasn't, there was no explanation for my disappearance.
[cpg]

[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide030"]
[OnName num="mitsuhide"]
I'm sure she's serious about what she's saying. If it's okay with me, I'll listen.
[cpg cn=true]


Mitsuhide-sama said so, but there was no use talking to her.
[cpg]

It's the same thing if I discourage her from betraying Nobunaga-sama.
[cpg]

It would be inevitable that I would disappear, and I knew I probably wouldn't be able to dissuade her.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

I returned to my room. I was alone with my thoughts.
[cpg]

All I could think of was bad things. The days I spent with Nobunaga-sama were so enjoyable that it was even more so.
[cpg]

But I wonder if I have no choice but to accept it.
[cpg]

This is the biggest event in history that I know of. If so, this must be fate.
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

Soon the morning will come. I have no choice but to cherish this day, today.
[cpg]

That is also difficult. Because I know the fate that will eventually come.
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

It was as if everything was spilling out of my hands.
[cpg]

I was somewhat absent-minded when I was called by Nobunaga-sama to talk to him.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga381"]
[OnName num="nobunaga"]
I was in a kind of a daze. Is it related to the case?
[cpg cn=true]


Nobunaga-sama must be talking about the fact that I almost disappeared.
[cpg]

[OnName num="keitarou"]
I'm fine. I'm fine.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="sNobunaga018"]
[OnName num="nobunaga"]
"I see."
[cpg cn=true]


Hearing my reply, Nobunaga-sama looks out from his room and says, "Thinking back, this war-torn world has changed.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="sNobunaga019"]
[OnName num="nobunaga"]
'Come to think of it, this war-torn world has changed.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga404"]
[OnName num="nobunaga"]
'A certain amount of peace has come to us. It's thanks to you.
[cpg cn=true]


That is a complete exaggeration. I didn't do anything.
[cpg]

[OnName num="keitarou"]
I have done nothing to help you, Nobunaga-sama.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga405"]
[OnName num="nobunaga"]
No, no. No, I mean that you are supporting him emotionally. It is different from making a military merit.
[cpg cn=true]


I really don't deserve such words. I couldn't help but shut up.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

Today is the same as yesterday. Tomorrow is the same as today.
[cpg]

Happy time passes quickly. It's as if it's rushing by in a frightening manner.
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

I can't go on like this. But I can't tell them everything.
[cpg]

She went out of the castle to get some fresh air. There, she came to.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga406"]
[OnName num="nobunaga"]
I felt ...... somehow that Keitaro was here."
[cpg cn=true]


I turned around and couldn't smile at her.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga407"]
[OnName num="nobunaga"]
She looked as unflappable as ever.
[cpg cn=true]


If I don't say anything, Nobunaga-sama will die in the Honnoji Incident.
[cpg]

On the other hand, if I tell you what's going to happen, I'm going to disappear.
[cpg]

Not only that, my family and friends who are supposed to be in the future will also disappear.
[cpg]

No, ...... that's not important. What matters is.
[cpg]

Either way, we are not destined to be together.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga408"]
[OnName num="nobunaga"]
I still think they are hiding something. I'm sure it's all something you can't tell me. ......
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga409"]
[OnName num="nobunaga"]
But it seems that not everything can be hidden.
[cpg cn=true]


Nobunaga-sama knew me better than anyone else.
[cpg]

I opened my mouth in contemplation.
[cpg]

[OnName num="keitarou"]
I opened my mouth and said, "...... Nobunaga-sama. You are ......."
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I can't tell you everything. But I can't hide everything. Nobunaga-sama is right.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************


[VOICE f="Nobunaga410"]
[OnName num="nobunaga"]
You mean that for some reason I will die, even though I will be under your control?
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Nobunaga411"]
[OnName num="nobunaga"]
If that fact is rewritten, you who were to be born will be gone."
[cpg cn=true]


[OnName num="keitarou"]
'...... That's what I mean. We just can't get together."
[cpg cn=true]


Nobunaga-sama's expression was sad.
[cpg]

But that doesn't mean he was surprised. I think he knew what he was doing.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga412"]
[OnName num="nobunaga"]
I understood. You can watch me die in silence. Without you, I have no reason to live.
[cpg cn=true]


[OnName num="keitarou"]
"Oh, no. ......!"
[cpg cn=true]


I didn't expect him to say that much. I was flabbergasted.
[cpg]

[OnName num="keitarou"]
It's quite the opposite. If it weren't for you, I wouldn't be here.
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]

I told her in a strong tone, but Nobunaga-sama shook her head.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga413"]
[OnName num="nobunaga"]
I've been lonely all my life. You were a light in the midst of all that.
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=1000]

Saying this, Nobunaga-sama approached and hugged me.
[cpg]

Tears streamed down my cheeks. I found myself crying.
[cpg]


;//ブラックアウト

;//移植前シーンカット

;//========================================
;//●ＣＧ（屋外でヒロインが主人公を抱きしめる）ev_24
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：屋外＿城近く
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_24_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Nobunaga414"]
[OnName num="nobunaga"]
I'm glad I met you, Keitaro. I am glad I met you.
[cpg cn=true]


[OnName num="keitarou"]
I'm glad I met you, too. I don't want to think ...... that you're gone.
[cpg cn=true]



[VOICE f="Nobunaga415"]
[OnName num="nobunaga"]
I don't want to think about it. For now, let's make sure we have a moment of peace.
[cpg cn=true]


We will make sure of each other's existence. We are still alive.
[cpg]

Nobunaga-sama was right, I decided not to think about the future when she would be gone, just for a moment.
[cpg]

The moon and stars were beautiful that day, but everything seemed to enhance Nobunaga-sama.
[cpg]

I hugged her. Not to go anywhere.
[cpg]

And me, too, not to go anywhere.
[cpg]

We both hugged each other tightly.
[cpg]


;//移植前シーンカット

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

Even back at the castle, we wanted to stay together.
[cpg]

We are not officially a married couple, but people around us still know about our relationship.
[cpg]

I have a feeling that Ranmaru, in particular, has told me a lot about us.
[cpg]


;//ブラックアウト


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

We still can't sleep together.
[cpg]

It would be terrible if someone comes in the morning and sees me and Nobunaga-sama sleeping together.
[cpg]

So I sleep alone again.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

I wake up in the morning. Ranmaru-sama had come to wake me up.
[cpg]

[OnName num="keitarou"]
He said, "Good morning, ......."
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru101"]
[OnName num="ranmaru"]
What a face! I must have had a very scary dream.
[cpg cn=true]


Lately, I've been having a lot of these things. I couldn't help thinking about the future.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]


Months go by. Decisions are being made.
[cpg]

When will the Honnoji Incident occur? It is different from the history I know.
[cpg]

What was supposed to happen decades later could happen tomorrow.
[cpg]


[window target=false]
[BG f="b_03_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（朝）******************************************************

I was on my way to Nobunaga-sama.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga464"]
[OnName num="nobunaga"]
"I hear you have something to tell me ....... What is it?"
[cpg cn=true]


What to talk about. That's obvious. I'm going to help her. I want to, but ......
[cpg]

It would change the future. Of course, for me, she's the one I want to protect, even if I have to give up everything.
[cpg]

...... but I was lost.
[cpg]

[OnName num="keitarou"]
I want to save Nobunaga-sama. But ......
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Nobunaga465"]
[OnName num="nobunaga"]
'Don't say such a thing. Shingen also told you not to leave me alone, didn't he?"
[cpg cn=true]


I still wanted to protect Nobunaga-sama.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga466"]
[OnName num="nobunaga"]
The thing I fear most now is to live alone.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga467"]
[OnName num="nobunaga"]
'Hey, Keitaro. Tell me you'll always be by my side.
[cpg cn=true]


I wish I could say that, but I can't. But I can't.
[cpg]

[OnName num="keitarou"]
I can't say that for sure.
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Nobunaga468"]
[OnName num="nobunaga"]
"I see."
[cpg cn=true]


Nobunaga-sama seemed to have understood my intention.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の廊下』（昼）******************************************************

I can't make a decision yet. But if there is any difference, it is when we will part ways.
[cpg]

Nobunaga-sama does not know that I will be betrayed at Honnoji.
[cpg]

So he will probably say something to me when we head for Honnoji. It is not too late to stop him then.
[cpg]

Of course, it could be sooner. The only difference is when I disappear.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru102"]
[OnName num="ranmaru"]
What were you talking to Nobunaga-sama about, Keitaro? What were you talking to Nobunaga-sama about?
[cpg cn=true]


[OnName num="keitarou"]
There will come a time when I will tell Ranmaru-sama everything.
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]

[VOICE f="Ranmaru103"]
[OnName num="ranmaru"]
I'm the only one who's left. I'm afraid you're going away.
[cpg cn=true]


Even Ranmaru-sama is worried about me.
[cpg]

I'm a lucky guy. Is it any wonder I'm not afraid to die now?
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_01_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************

I somehow found myself in the castle town, where people were hurriedly going about their daily lives.
[cpg]

In my time, people did not live their lives so fiercely.
[cpg]

I guess the fear of death is no longer present today.
[cpg]

Of course, I don't think that's a bad thing. I think it is a sign of peace.
[cpg]

But it was in this era that I felt a sense of purpose in life.
[cpg]

It's not that I enjoy the thrill of possibly dying or anything like that.
[cpg]

I don't know when I will die, so I have no choice but to cherish this moment.
[cpg]

When I think of that, the idea of living shines through.
[cpg]

Nobunaga-sama is alive. He is still alive.
[cpg]

What if I don't protect him? That was the state of mind I was in.
[cpg]


[window target=false]
[BG f="b_01_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（夜）******************************************************

Hopefully, ...... I wanted to live purely as a person of this time period.
[cpg]

But then, Nobunaga couldn't be saved, could he?
[cpg]

I wouldn't have been able to realize the Honnoji Incident, either. I don't know which would have made me happier.
[cpg]


;//ブラックアウト

[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

Once again, I was on my way to Nobunaga-sama's place. I was going to tell him everything.
[cpg]


[OnName num="keitarou"]
Nobunaga-sama. You are going to commit rebellion.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[OnName num="keitarou"]
It is the rebellion that will kill you. ......
[cpg cn=true]


My body became a little transparent. I'm still scared.
[cpg]

I think I was trembling with fear.
[cpg]

[FACE method="change_3" pos="2/3"]
And just as I was about to say Mitsuhide-sama's name.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=1000]
She kissed me. She covered my lips.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga469"]
[OnName num="nobunaga"]
I said, "...... I won't let you say it yet.
[cpg cn=true]


[OnName num="keitarou"]
"Nobunaga-sama, ......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga470"]
[OnName num="nobunaga"]
I always want to do it one more time. Even though I know this isn't the way to do it.
[cpg cn=true]


She seemed to still want me.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga471"]
[OnName num="nobunaga"]
'I know you think this could be the last time, but somewhere ......
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga472"]
[OnName num="nobunaga"]
'I still want to be connected to you. I wonder why."
[cpg cn=true]


Nobunaga-sama's voice gradually became tearful. And then, I realized.
[cpg]

I was crying and so was Nobunaga-sama. I didn't want to think of this love as a tragedy.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga473"]
[OnName num="nobunaga"]
Even if you've made your decision, I haven't.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga474"]
[OnName num="nobunaga"]
"Please. Stay with me.
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I always think that this is the last time.
[cpg]

I feel the same way. This is the last time.
[cpg]

I hope that someday, when the time really comes for the last time, I will have no regrets.
[cpg]


;//移植前シーンカット

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

Originally, Nobunaga-sama seemed to spend all his time in politics and warfare.
[cpg]

But now he was quite different.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Nobunaga497"]
[OnName num="nobunaga"]
'I never thought I would become so infatuated with colorful love.
[cpg cn=true]


[OnName num="keitarou"]
'...... would you like to have a child with me?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga498"]
[OnName num="nobunaga"]
I'm sure of it. Even if I eventually die.
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

And then morning comes again. I met Ranmaru-sama in the corridor.
[cpg]


[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************



[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru104"]
[OnName num="ranmaru"]
"...... Keitaro."
[cpg cn=true]


[OnName num="keitarou"]
What is it?　Ranmaru-sama.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru105"]
[OnName num="ranmaru"]
What are you thinking about?　You never reveal anything to me, do you?
[cpg cn=true]


[OnName num="keitarou"]
No. Yes, because it's not that easy to tell you.
[cpg cn=true]


Ranmaru-sama didn't pursue it any further either.
[cpg]

That was a big help to me. ......
[cpg]


[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]


[VOICE f="Nobunaga499"]
[OnName num="nobunaga"]
What's the matter? What are you two talking about?"
[cpg cn=true]


I heard Nobunaga-sama's voice and we turned around.
[cpg]

[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru106"]
[OnName num="ranmaru"]
What's wrong?　Nobunaga-sama, you seem a little down.
[cpg cn=true]


Ranmaru-sama really is a man who notices the smallest of things.
[cpg]

[STOPBGM]

[FACE method="change_4" pos="2/5"]

[VOICE f="Nobunaga500"]
[OnName num="nobunaga"]
He is a man who notices the smallest of things. Maybe it's ...... ugh."
[cpg cn=true]


Nobunaga-sama holds his mouth. 
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

Not long after that, we learned that Nobunaga-sama was pregnant with a child.
[cpg]

I don't know how long it will be until the Honnoji Incident.
[cpg]

Would she be able to give birth? We don't even know that. ......
[cpg]

I don't even know how much time there is between Nobunaga-sama taking power and the rebellion.
[cpg]

If that's the case, I should tell her all about it right away. ......
[cpg]

But then I don't know if a child with me could even exist?
[cpg]

At the very least, I'd like ...... her and her child to be alive.
[cpg]

I wouldn't be able to live without it.
[cpg]

Otherwise, I would have to tell her about the rebellion and rearrange history.
[cpg]


;//ブラックアウト





[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then we became husband and wife.
[cpg]

It doesn't change anything in our relationship. I still refer to Nobunaga-sama as "Sama-sama.
[cpg]

I guess it's like the wives of warlords in the past.
[cpg]

By far, Nobunaga-sama has more power. ......
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夕方）******************************************************

Her stomach was getting bigger and bigger.
[cpg]

Time is running out. I was in a situation where I didn't know when she was going to die ......
[cpg]

Still, I wanted her to have a baby.
[cpg]

[OnName num="keitarou"]
"...... Nobunaga-sama,......
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Nobunaga501"]
[OnName num="nobunaga"]
Don't look at me like that. It won't be too late to make all the decisions after this baby is born."
[cpg cn=true]


That might be too late. I was a jumble of mixed emotions inside me.
[cpg]

As I was about to start crying, Nobunaga-sama approached me.
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga502"]
[OnName num="nobunaga"]
You are weak. But am I not strong, too?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

He puts his hand on my cheek. Then he kisses me.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[VOICE f="Nobunaga503"]
[OnName num="nobunaga"]
I wish I could forget everything that hurts me.
[cpg cn=true]


Nobunaga-sama said that and asked for me.
[cpg]

I have no reason to refuse. I would rather feel her close to me.
[cpg]


;//移植前シーンカット
[BG f="b_06_2.ui" time=1000]
[WAIT time=1100]


I have a feeling that she, too, realizes that she is about to die. I can't help it, but there is little I can do.
[cpg]

Either I disappear or Nobunaga-sama dies.
[cpg]

If I disappear, the future will be altered.
[cpg]

It can't be just me. I can't make that kind of decision. ......
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

Two more months pass. I was on my way to Mitsuhide-sama.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Mituhide031"]
[OnName num="mitsuhide"]
What is it that you want from me?
[cpg cn=true]


[OnName num="keitarou"]
I'm not trying to stop you anymore,.......
[cpg cn=true]


[OnName num="keitarou"]
I'm not going to try to stop you anymore,. But at least ......
[cpg cn=true]


I wonder how Mitsuhide-sama sees me.
[cpg]

Do you think that somehow you have a hunch?
[cpg]

Or does he know that I am from the future?
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide032"]
[OnName num="mitsuhide"]
Is this about the kids?　Don't worry about it.
[cpg cn=true]


[OnName num="keitarou"]
"Eh, ......."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Mituhide033"]
[OnName num="mitsuhide"]
I'm not a demon either. Even if the child survived, I don't think it would be as much of a threat as she is.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide034"]
[OnName num="mitsuhide"]
I will not do such a terrible thing, and I will consider your feelings as well.
[cpg cn=true]


I was feeling relieved by what Mitsuhide-sama said, but I still couldn't help but ......
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Mituhide035"]
[OnName num="mitsuhide"]
Don't get in my way. Apparently, for some reason or another, I can't do that.
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


I said nothing more.
[cpg]

She had told me to stay out of her way. Still, she said she would wait until the baby was born.
[cpg]

I don't know what the real Honnoji Incident was like.
[cpg]

But it is not likely that Nobunaga-sama had no children.
[cpg]

So the future is the same, including the future of Nobunaga.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[SE f=se024]
;//【ＳＥ】『通路歩く』

I was walking around the castle with an unsettled feeling.
[cpg]

I knew who was going to kill her. And that's not all.
[cpg]

I could save Nobunaga-sama. Still, I can't choose.
[cpg]

I was afraid that I would disappear. I have to admit that now.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru107"]
[OnName num="ranmaru"]
"......, you look like that again."
[cpg cn=true]


[OnName num="keitarou"]
"Ranmaru-sama, ...... it's nothing."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru108"]
[OnName num="ranmaru"]
I know you won't say anything to me anymore. I know."
[cpg cn=true]


Ranmaru-sama looked a little taken aback.
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Ranmaru109"]
[OnName num="ranmaru"]
Just don't get me wrong, you are not alone.
[cpg cn=true]


If the Honnoji Incident occurs as it did in historical fact, she too will die.
[cpg]

It will not be as Ranmaru-sama said. I would be alone.
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

I was back in my room alone.
[cpg]

The decision is already made. As soon as she gives birth to a child, I will be able to ......
[cpg]


[VOICE f="Nobunaga526"]
[OnName num="nobunaga"]
Keitaro. Are you there?"
[cpg cn=true]


Nobunaga-sama visited me there. I reply.
[cpg]

[OnName num="keitarou"]
Yes. What is it?
[cpg cn=true]


[SE f=se025]
;//【ＳＥ】『ふすま開く』

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[WAIT time=1100]


[VOICE f="Nobunaga527"]
[OnName num="nobunaga"]
Nothing at all. I just wanted to see your face.
[cpg cn=true]


[OnName num="keitarou"]
"I see.
[cpg cn=true]


Nobunaga-sama still thinks of me that way.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga528"]
[OnName num="nobunaga"]
When I'm alone, I tend to get sentimental, which is no good.
[cpg cn=true]


[OnName num="keitarou"]
Me too. I want to be near you, Nobunaga-sama.
[cpg cn=true]


[OnName num="keitarou"]
'Do you know ......? I heard that feeling of sadness is not an unpleasant emotion.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Nobunaga529"]
[OnName num="nobunaga"]
I think that might be true. Rather, it's the opposite.
[cpg cn=true]


[OnName num="keitarou"]
I'd rather be close to the believer. It's more like something you immerse yourself in.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga530"]
[OnName num="nobunaga"]
Well, then, ...... I can't stay in sadness forever.
[cpg cn=true]


Rubbing his own stomach, Nobunaga-sama turned to me.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga531"]
[OnName num="nobunaga"]
The future is here for you and for this child. You and this child have a future.
[cpg cn=true]


I could not answer. I wasn't determined enough to answer immediately.
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga532"]
[OnName num="nobunaga"]
I was not determined enough to give an immediate answer. That's all I ask.
[cpg cn=true]



;//移植前シーンカット

Unspeakable feelings welled up in me. But I could not speak.
[cpg]

[OnName num="keitarou"]
"I am ...... Nobunaga-sama. I am .......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga556"]
[OnName num="nobunaga"]
What's wrong?　I'm still confused."
[cpg cn=true]

;//裸になった彼女を見つめながら、また振り切ったはずの感情が湧いてくる。
As I stare at her, the feelings I thought I had shaken off come up again.
[cpg]

I was still brooding over it. But I couldn't let her make the decision.
[cpg]

She couldn't possibly let me live in the first place.
[cpg]

One word from me would settle everything.
[cpg]

Mitsuhide-sama betrays me. With that one word, ......
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga557"]
[OnName num="nobunaga"]
I know you are afraid. I know how you feel."
[cpg cn=true]


I found myself trembling. I was still afraid that I would disappear.
[cpg]

[FACE method="shake_2" pos="2/3"]

[VOICE f="Nobunaga558"]
[OnName num="nobunaga"]
I didn't need to think about it. You've already done enough for me.
[cpg cn=true]



;//ブラックアウト

It was easy to believe her. But it's not enough.
[cpg]

Not enough at all. If I couldn't help her, there was no point.
[cpg]

I couldn't say the last word, even though I was thinking it.
[cpg]


;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

And as a few more months passed, her belly swelled even more.
[cpg]

The whole castle was in an uproar because a nobleman was going to give birth to a child.
[cpg]


[window target=false]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

Nobunaga himself, however, was unconcerned.
[cpg]

He looked cool, as if to say that everyone around him was making too much noise. ......
[cpg]


[window target=false]
[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************


[VOICE f="Nobunaga581"]
[OnName num="nobunaga"]
He said, "Don't let me worry you. I don't think I'm that frightened though."
[cpg cn=true]


[OnName num="keitarou"]
'...... I think it's okay to be a little scared.'
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga582"]
[OnName num="nobunaga"]
I guess you're right. But labor pains are something I just can't get used to. I've never had pain like this, not even on the battlefield.
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


I had mixed feelings when I saw the soft expression on Nobunaga-sama's face.
[cpg]

If she gives birth to a child, Mitsuhide-sama will move mercilessly.
[cpg]

By then, if we do nothing, Nobunaga-sama will ......
[cpg]

[STOPBGM]

[FACE method="shock_4" pos="2/3"]

[VOICE f="Nobunaga583"]
[OnName num="nobunaga"]
Ugh. ...... Kuuuh!"
[cpg cn=true]


[OnName num="keitarou"]
What's wrong?　Nobunaga-sama, are you all right?
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I could not be present at her birth.
[cpg]

I thought it might be like that in these times, but I was not in the mood for it.
[cpg]

I don't think it was the way to say that both mother and child were healthy.
[cpg]

But it means that Nobunaga-sama herself and the newborn baby are healthy.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１』（夜）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Ranmaru110"]
[OnName num="ranmaru"]
Congratulations, Nobunaga-sama,......, on your adorable baby.
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]

[VOICE f="Nobunaga584"]
[OnName num="nobunaga"]
'It's mine and Keitaro's child. It's only natural.
[cpg cn=true]


Nobunaga-sama says this with a laugh. I felt that her face was becoming more like a mother's.
[cpg]

I must protect her. I try to speak with determination, but my voice trembles.
[cpg]

[OnName num="keitarou"]
'...... Nobunaga-sama. I'm ......."
[cpg cn=true]


[FACE method="shake_6" pos="2/5"]

[VOICE f="Nobunaga585"]
[OnName num="nobunaga"]
'That's enough. Keitaro, if you are lost, it must mean you are that afraid."
[cpg cn=true]

[FACE method="bow_6" pos="2/5"]
Nobunaga-sama looks at Ranmaru-sama. And ......
[cpg]


[STOPBGM]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga586"]
[OnName num="nobunaga"]
I'm not afraid to die as long as I have you. So I won't hear anything more about the future from you."
[cpg cn=true]


He said. Ranmaru-sama approaches me.
[cpg]

[OnName num="keitarou"]
'Ranmaru-sama, what ......
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru111"]
[OnName num="ranmaru"]
I don't know much either. I don't know much about it, but it was Nobunaga-sama's order, so don't take it personally.
[cpg cn=true]


Some men came into the room. I was surprised and turned around. ......
[cpg]


;//ブラックアウト
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=1]
[WAIT time=1500]

[FACE method="in" pos="4/7"]


By the time I realized what Nobunaga-sama was up to, it was too late.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

He is trying to save me even if Nobunaga himself is dead.
[cpg]

I was locked in a room in the castle. I could not take a single step outside.
[cpg]

I can no longer tell her the future. ...... No.
[cpg]

[OnName num="keitarou"]
You're on guard!　Listen to me!"
[cpg cn=true]


[OnName num="keitarou"]
Nobunaga-sama will be betrayed at Honnoji!　Please, someone tell her that.
[cpg cn=true]


There are guards. But I knew that someone was not going to tell Nobunaga-sama.
[cpg]


[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

Thinking back, I had no time to hesitate.
[cpg]

I still wanted to disappear after seeing the child with her.
[cpg]

I'm sure Nobunaga-sama saw through that as well.
[cpg]

[OnName num="keitarou"]
"...... Mitsuhide-sama.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Mituhide036"]
[OnName num="mitsuhide"]
I am in a terrible situation. Who are you really?
[cpg cn=true]


[OnName num="keitarou"]
Please,......, if I lose Nobunaga-sama, I will,......
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide037"]
[OnName num="mitsuhide"]
Apparently, you are also aware of my motives. But Nobunaga-sama doesn't listen to me, but rather......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Mituhide038"]
[OnName num="mitsuhide"]
I'm not going to contact you, who is smelling it. As if he is not afraid of dying.
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


I hated Mitsuhide-sama. But it wasn't as if killing her would solve everything.
[cpg]

The future is going to be altered after all. It is inevitable.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide039"]
[OnName num="mitsuhide"]
I just want to say, Mr. Keitaro. I don't think her determination will be in vain.
[cpg cn=true]


[OnName num="keitarou"]
What does that ...... mean?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide040"]
[OnName num="mitsuhide"]
If there is something she wants to protect more than herself, and that is you, shouldn't she live?
[cpg cn=true]


Mitsuhide-sama is orchestrating everything. I think she must be an evil person.
[cpg]

But ...... she said this to me.
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide041"]
[OnName num="mitsuhide"]
I think she must be evil. It's the same for me.
[cpg cn=true]


;//[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide042"]
[OnName num="mitsuhide"]
But you mustn't be desperate. No one should be.
[cpg cn=true]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

Then the castle suddenly became noisy.
[cpg]

Everyone was saying that Honnoji had been set on fire.
[cpg]

The guards are gone. I'm going outside.
[cpg]

I realized that Nobunaga-sama was no longer with us.
[cpg]

Ranmaru-sama must have accompanied him. Mitsuhide-sama would be my adversary from now on.
[cpg]

There is no one I can rely on anymore.
[cpg]

[OnName num="keitarou"]
...... Still, do I have to live? Nobunaga-sama.
[cpg cn=true]


I wanted to throw it all away.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Nobunaga-sama was very careful in his preparations. He tried to avoid working with children as much as possible.
[cpg]

Nobunaga himself did not know that he would be killed at Honnoji.
[cpg]

But after her death, he seems to have told his retainers to run away with the child.
[cpg]

And no matter what I do from here, history will not change much. It seemed that he had read that far and had made arrangements to release me.
[cpg]

[OnName num="vassal"]
Let's run away, Mr. Keitaro. If you are killed here, everything Nobunaga-sama has done will have been for nothing.
[cpg cn=true]


If you stay here, you will probably kill me and my child. The only thing to do now is to run away.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の廊下』（昼）******************************************************

In the castle where we escaped, I was holding the child with Nobunaga-sama.
[cpg]

I couldn't stop crying. It was as if he was crying on my behalf, as my tears had dried up.
[cpg]

At that time, Nobunaga-sama's retainer had arrived.
[cpg]

[OnName num="vassal"]
He said, "I have a letter from Nobunaga-sama addressed to Keitaro-sama, ......."
[cpg cn=true]


I must have looked terrible. The vassal hesitated to hand it over.
[cpg]

[OnName num="keitarou"]
Let me see ......."
[cpg cn=true]


I picked up the letter. A small piece of paper was folded.
[cpg]


;//ブラックアウト

;//可能であればここから一連の音声にリバーブをかけてください

[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[WAIT time=1500]

[FACE method="in" pos="4/7"]


[VOICE f="Nobunaga587"]
[OnName num="nobunaga"]
'Keitaro, thank you for all you've done. I have no desire to die.
[cpg cn=true]



[VOICE f="Nobunaga588"]
[OnName num="nobunaga"]
Still, I can see everything in your attitude.
[cpg cn=true]



[VOICE f="Nobunaga589"]
[OnName num="nobunaga"]
I guess I am no longer in this world. What I am about to write is baseless.
[cpg cn=true]



[VOICE f="Nobunaga590"]
[OnName num="nobunaga"]
"Still, live. If you live, you will find happiness again.
[cpg cn=true]



[free time=1000]
[WAIT time=1100]

;//【ＢＧ】『城＿縁側の廊下』（昼）******************************************************

Nobunaga-sama did not choose the future in which he survived and I disappeared.
[cpg]

[OnName num="keitarou"]
Nobunaga-sama ......"
[cpg cn=true]


I call his name once more, a name I don't know how many times I've called it.
[cpg]

I'm not going to let this happen again, I have no choice but to survive and be happy for Nobunaga-sama.
[cpg]

That's right. I know all the future. If I change to a history that deviates from it, I will disappear in the first place.
[cpg]

I should now turn to Hideyoshi or Ieyasu. ......
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

I decided to live in a world of warfare while thinking about it.
[cpg]

I will not die. I will not disappear.
[cpg]

For the sake of Nobunaga-sama and for the sake of my children, ...... I will live to the fullest.
[cpg]

I will live.
[cpg]



;//ＥＮＤ　ヒロイン１ルート
;//＠
[SCENE id=9]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="epend.ks" target="*start"]

