
*start

;//==============================
;//１、仕えるつもりはない

*select_root145|Loyalty to Nobunaga-sama


;#################################################
*Ep001|Loyalty to Nobunaga-sama
;#################################################

[SCENE id=1]

[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]

[stflag Selectflg1=0]
[stflag Selectflg2=0]
[stflag Selectflg3=0]
[stflag Selectflg4=0]


[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]


[OnName num="keitarou"]
......I am sorry, but I have no desire to serve you."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

Shingen-sama looked surprised for a moment, and then turned his head to the side.
[cpg]

[FACE method="bow_4" pos="2/3"]

[VOICE f="Singen067"]
[OnName num="shingen"]
Shingen looked surprised for a moment, then sagged and said, "...... yes, that's right. I am so sorry.
[cpg cn=true]


He looked exaggeratedly sad.
[cpg]

But it didn't look like an act. He must have really liked me.
[cpg]

[OnName num="keitarou"]
He said, "I'm sorry, but I'm waiting for Nobunaga-sama to come back. But Nobunaga-sama is waiting for my return.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen068"]
[OnName num="shingen"]
I don't need to apologize. It means I was not good enough.
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

What did she find so attractive about me?
[cpg]

Did you know that I am from the future?
[cpg]

Is it possible that Nobunaga-sama is spreading such rumors on a dare? ......
[cpg]

Many thoughts are going through my mind. There is even a possibility that I will never see Shingen-sama again.
[cpg]

But I thought again that I would serve Nobunaga-sama.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（朝）******************************************************

And then morning came. It was the day of departure.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru046"]
[OnName num="ranmaru"]
"...... Keitaro, were you not misled by Shingen-sama?"
[cpg cn=true]


[OnName num="keitarou"]
What makes you think so?"
[cpg cn=true]


I replied, trying to appear as nonchalant as possible.
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru047"]
[OnName num="ranmaru"]
No. Shingen-sama may be trying to get you on his side. 
[cpg cn=true]


That's a funny thing to say. I thought Ranmaru-sama didn't think highly of me.
[cpg]

[OnName num="keitarou"]
What makes you think so?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru048"]
[OnName num="ranmaru"]
Don't say the same thing over and over again. I'm just saying that Nobunaga-sama said so.
[cpg cn=true]


Nobunaga-sama also seemed to have read the situation ahead of time.
[cpg]

There was even a possibility that they would ask me where I came from.
[cpg]

Nobunaga-sama may have thought that if I answered him there.
[cpg]

;//ブラックアウト

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

And then it was back to the mountain path. If I had not been so busy with my club activities, I would not have been able to walk there.
[cpg]



[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

Besides, there was a possibility that bandits might appear.
[cpg]

This era is really full of inconveniences. ......
[cpg]


[window target=false]
[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

Several days and nights pass. It's the return trip, not the way there, and I'm worn out from the round trip.
[cpg]

And then, when my consciousness was fading...
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

Finally, the castle came into view. I was relieved to know that I had made it home again.
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru049"]
[OnName num="ranmaru"]
You really don't have any stamina, do you?
[cpg cn=true]


[OnName num="keitarou"]
...... It's a wonder you have more stamina than I do in your thin body, Ranmaru-sama.
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Ranmaru050"]
[OnName num="ranmaru"]
I'm not a woman. I think Nobunaga-sama trusts me to some extent even with this."
[cpg cn=true]


I guess that's what it's all about. Physical fitness is a prerequisite for everything.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

As I was getting tired after the move, I was called by Nobunaga-sama.
[cpg]

I was worried that I might say something rude to her by talking to her in this out-of-strength situation, but I headed for her.
[cpg]



;//========================================
;//●ＣＧ（紹介ページヒロイン１のＣＧ）ev_91
;//人物１：ヒロイン１　服装１：着衣
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//備考　：可能であれば背景を足してください
;//========================================


[free time=1000]
;**【ＣＧ】 ev_91_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Nobunaga066"]
[OnName num="nobunaga"]
She said, "You came back all right. You're thinking of me to some extent."
[cpg cn=true]


Nobunaga-sama seemed to appreciate the fact that I had not flirted with Shingen-sama.
[cpg]

[OnName num="keitarou"]
"...... that's ......."
[cpg cn=true]


I couldn't say it was because I was afraid of you.
[cpg]

[OnName num="keitarou"]
'In any case, it was hard to walk. In my time, we didn't have to walk so much.
[cpg cn=true]



[VOICE f="Nobunaga067"]
[OnName num="nobunaga"]
I thought I should also experience the means of transportation in this time period.
[cpg cn=true]



[VOICE f="Nobunaga068"]
[OnName num="nobunaga"]
In the future, horses will probably be more developed. I think horses will probably be more developed in the future, and there will probably be more of them.
[cpg cn=true]


Horses are very precious in this era. They are not so easy to use.
[cpg]

In addition, Nobunaga-sama also saw that in the future there would be more means of transportation.
[cpg]

Of course, it's not a horse, but I don't think he'd get the message if I said ...... car.
[cpg]


[VOICE f="sNobunaga001"]
[OnName num="nobunaga"]
By the way, don't you drink?
[cpg cn=true]


[OnName num="keitarou"]
I'm not very good at it,......."
[cpg cn=true]


I see," said Nobunaga-sama, looking a little sad.
[cpg]

She might be quite a drinker, and that somehow suited her well.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

I slept again for a while, exhausted.
[cpg]

I didn't have time to think or dream anymore.
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

The next morning, I woke up later than usual.
[cpg]

My muscles ache again. I'm sure I'm going to get injured someday if I keep going on like this. ......
[cpg]


[window target=false]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

But that doesn't mean I have any particular work to do.
[cpg]

I have plenty of time to think and ponder.
[cpg]

How can I go back to my original world?
[cpg]

If the folding screen is the trigger, is there a counterpart in this world?
[cpg]

As I was thinking this, I met another girl.
[cpg]

She was tending to her bonsai. When she saw me, she turned around and bowed deeply.
[cpg]


;//光秀の名前を「少女」と隠してください

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mituhide001"]
[OnName num="girl"]
She said, "Nice to meet you. I have heard a lot about you. You certainly have a mysterious atmosphere, don't you?
[cpg cn=true]


[OnName num="keitarou"]
I'm Keitaro Sudo. My name is Keitaro Sudo.
[cpg cn=true]



;//ここから光秀の名前を隠さないでください

[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide002"]
[OnName num="mitsuhide"]
My name is Mitsuhide Akechi. I also serve Nobunaga-sama.
[cpg cn=true]


Mitsuhide Akechi...... she is also a military commander.
[cpg]

The person who is supposed to betray Nobunaga-sama.
[cpg]

But still, a general as good as Mitsuhide should have his own castle, shouldn't she?
[cpg]

[OnName num="keitarou"]
I wondered if the phrase, "......, why in the world?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
I wondered if I could get the point across. Mitsuhide-sama was stunned.
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide003"]
[OnName num="mitsuhide"]
Nobunaga-sama is fond of bonsai. I am summoned here to talk about bonsai.
[cpg cn=true]


[OnName num="keitarou"]
Heh. ......
[cpg cn=true]


It is somewhat surprising. I wonder if Nobunaga-sama would be interested in such a thing.
[cpg]

[OnName num="keitarou"]
I see. That doesn't sound like Nobunaga-sama."
[cpg cn=true]


I wondered if it would be a little impolite of me to say something like that.
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide004"]
[OnName num="mitsuhide"]
"Is that so?　It is precisely because we live in such an era that I think it is important to be in touch with living things.
[cpg cn=true]


Mitsuhide-sama said that a bonsai is a living thing.
[cpg]

That's the kind of thinking we have in this day and age. Of course so. ......
[cpg]

Rather, because it was the Warring States period, we might feel the creatureliness in plants.
[cpg]

In the modern age, even ornamental plants are artificial.
[cpg]

[OnName num="keitarou"]
...... I think that might be true."
[cpg cn=true]


I think about it even as I speak. If this person were to kill Nobunaga someday, I wonder if he would ever tell Nobunaga about it.
[cpg]

But if I do that, I would be changing the future. I don't know what will happen.
[cpg]


[free time=1]
[WAIT time=1]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Ranmaru051"]
[OnName num="ranmaru"]
Ah, Mitsuhide...... was here."
[cpg cn=true]


While I was thinking about that, Ranmaru-sama came to me.
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="Mituhide005"]
[OnName num="mitsuhide"]
'What is it?　Ranmaru, what do you want from me?"
[cpg cn=true]


Ranmaru-sama and Mitsuhide-sama call each other.
[cpg]

How is it in terms of hierarchy in this era?
[cpg]

Is there no such thing as either of them being superior? In the first place, their positions are totally different.
[cpg]

[FACE method="shake_7" pos="4/5"]

[VOICE f="Ranmaru052"]
[OnName num="ranmaru"]
There is no "What can I do for you? Nobunaga-sama wants to see you. What do you think you are coming to the castle for?"
[cpg cn=true]


Ranmaru-sama's words had a thorn in them. Somehow, I guessed the relationship between the three of them.
[cpg]

Both Mitsuhide-sama and Ranmaru-sama serve Nobunaga-sama.
[cpg]

On top of that, Ranmaru-sama loves Nobunaga-sama, so maybe he sees Mitsuhide-sama as his rival.
[cpg]

If that is the case, it makes sense that they call each other by their first names.
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide006"]
[OnName num="mitsuhide"]
I understand. Then, let's meet again. Keitaro-san.
[cpg cn=true]


[OnName num="keitarou"]
"Yes, yes.
[cpg cn=true]


You call me "san" while Ranmaru-sama calls me "san". I was kind of nervous.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

While I was idle, the world of the Warring States was changing in a hurry.
[cpg]

I heard that a man named Dosan Saito had passed away.
[cpg]

I know he was a military commander, but I don't know what kind of relationship he had with Nobunaga-sama.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Nobunaga069"]
[OnName num="nobunaga"]
I don't know what kind of relationship he had with Nobunaga-sama. Such a will. ......"
[cpg cn=true]


But things were moving so fast that I thought it might be too fast.
[cpg]

I still think it's different from the history I know.
[cpg]

[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru053"]
[OnName num="ranmaru"]
What should we do with ......? Nobunaga-sama.
[cpg cn=true]


 It seems that he left behind to hand over Mino Province to Nobunaga.
[cpg]

The reason for his death was not specifically mentioned, but it was probably not death from illness.
[cpg]

If he died in battle ......, I wonder if Nobunaga-sama is even aware of his own death.
[cpg]

[FACE method="shake_7" pos="2/5"]

[VOICE f="Nobunaga070"]
[OnName num="nobunaga"]
He said, "As for me, I've lost my backer. Now, what should we do?
[cpg cn=true]


Both Mitsuhide-sama and Ranmaru-sama looked nervous.
[cpg]

In this life, I have never experienced such tense situations.
[cpg]

 Of course ... there are no life-threatening problems in modern times.
[cpg]

[FACE method="bow_3" pos="2/5"]

[VOICE f="Nobunaga071"]
[OnName num="nobunaga"]
The "Katsuie Shibata" also seems to be showing some disturbing movements. Let's strike from here."
[cpg cn=true]


I don't know who this Katsuie Shibata is.
[cpg]

I glanced at Ranmaru-sama, but she remained silent.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru054"]
[OnName num="ranmaru"]
It's getting a little dicey, he said. But it looks like there's no turning back now.
[cpg cn=true]


She was talking to me as we walked down the hallway with Ranmaru-sama.
[cpg]

[OnName num="keitarou"]
A battle, you say?
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Ranmaru055"]
[OnName num="ranmaru"]
I'm sure I'm going to be there. I'll be there.
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


I can't imagine what it's like. Nobunaga-sama and Ranmaru-sama are leading the troops.
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

I go back to my assigned room and ponder.
[cpg]

Katsuie Shibata. I traced the name from my dim memory.
[cpg]

The name "Inou" was also mentioned in Nobunaga-sama's story. Was there a battle called "Battle of Inau"?
[cpg]

No. The truth is, I don't need to ...... recall it properly. Nobunaga-sama must not have experienced defeat in battle.
[cpg]

Or, he might have at least fled from the battlefield.
[cpg]

In any case, he didn't die until he took over the country. I know that much.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夕方）******************************************************

Unable to stand still, I went out of the castle for a little while.
[cpg]

Perhaps seeing me, Mitsuhide-sama came to the castle.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Mituhide007"]
[OnName num="mitsuhide"]
What's wrong, Mr. Keitaro? You look pale.
[cpg cn=true]


[OnName num="keitarou"]
Oh, that's ......
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide008"]
[OnName num="mitsuhide"]
...... No, it can't be helped. ....... It means you might be on the battlefield too."
[cpg cn=true]


I guess so. Nobunaga-sama also said that he would make me a warlord.
[cpg]

[OnName num="keitarou"]
He said, "Don't worry. I don't expect you to just let me live without doing anything.
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Mituhide009"]
[OnName num="mitsuhide"]
I think it's important that you keep that in mind, but please don't overdo it.
[cpg cn=true]


Mitsuhide-sama looked worried as he said that.
[cpg]

What should I ...... do?
[cpg]

If Nobunaga-sama asked you to go out to the battlefield, would i go out to ......?
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

That night. I was on my way to her room when Nobunaga-sama called me.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga072"]
[OnName num="nobunaga"]
I was on my way to her room.　You can wield a sword, can't you?
[cpg cn=true]


She said what I had feared.
[cpg]

How I responded was important. Mitsuhide-sama had said that there was no need to push yourself too hard.
[cpg]

But I also want to meet Nobunaga-sama's expectations. ......
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga073"]
[OnName num="nobunaga"]
I'm not going to answer right away. If you don't want to kill people, that's fine too.
[cpg cn=true]


I hesitated for a moment and then gave my answer.
[cpg]

[OnName num="keitarou"]
"...... I'll get it too. I'm getting a free meal now.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga074"]
[OnName num="nobunaga"]
That's brave and good. I'm counting on you.
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

I couldn't sleep that night.
[cpg]

But I was determined. I was not going to run anymore.
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru056"]
[OnName num="ranmaru"]
"Hey, Keitaro. I heard you're going to join the battle of Inou?
[cpg cn=true]


[OnName num="keitarou"]
Yes, ......, well...
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru057"]
[OnName num="ranmaru"]
What a poor answer.
[cpg cn=true]


I was not so sure about that, but I asked Ranmaru-sama what she had to say.
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru058"]
[OnName num="ranmaru"]
Nobunaga-sama is going to make you a military commander. That means he is going to entrust you with a certain amount of troops.
[cpg cn=true]


[OnName num="keitarou"]
...... I'm going to be entrusted with a man's life?
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Ranmaru059"]
[OnName num="ranmaru"]
Of course. I do, and so does Mitsuhide."
[cpg cn=true]


I'm sure that's true,.......
[cpg]

What if I couldn't do it?
[cpg]


[free time=1]
[WAIT time=1]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="4/5" time=800]

[VOICE f="Mituhide010"]
[OnName num="mitsuhide"]
What is it?　Are you two having a private conversation?
[cpg cn=true]


Then Mitsuhide-sama came in. Ranmaru-sama looked a little uncomfortable.
[cpg]

[FACE method="shake_7" pos="4/5"]

[VOICE f="Ranmaru060"]
[OnName num="ranmaru"]
He said, "It's you. ...... Well, that's all right. Teach Keitaro about the art of war.
[cpg cn=true]


[FACE method="change_7" pos="2/5"]

[VOICE f="Mituhide011"]
[OnName num="mitsuhide"]
If that's the case, I think Ranmaru would be better suited for the role than I. ...... but that would be fine.
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

Then I learned basic battlefield tactics from Mitsuhide-sama and Ranmaru-sama.
[cpg]

Nobunaga-sama has already laid out the basic strategy. Nobunaga-sama has the basic strategy and all I have to do is follow it. ......
[cpg]

I wondered if such a thing would be okay.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

Then, the night before the war started. I was anxious and couldn't sleep.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga075"]
[OnName num="nobunaga"]
...... Keitaro.
[cpg cn=true]


[OnName num="keitarou"]
What?　Nobunaga-sama ......?"
[cpg cn=true]


Nobunaga-sama was visiting me in my room.
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga076"]
[OnName num="nobunaga"]
"You can't sleep, can you?"
[cpg cn=true]


[OnName num="keitarou"]
'Yes, well,...... I've never seen anything like this before.'
[cpg cn=true]


I said, half-awake.
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga077"]
[OnName num="nobunaga"]
'I can't sleep before a battle either. No matter how many times I do it, I never get used to it.
[cpg cn=true]


[OnName num="keitarou"]
Is that so for a man of Nobunaga-sama's stature?"
[cpg cn=true]


Nobunaga-sama frowned a little when I said that.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga078"]
[OnName num="nobunaga"]
What do you think I am? Do you think of me as a mindless monster?
[cpg cn=true]


It was rather a little reassuring to hear that ...... Nobunaga-sama said so.
[cpg]

That's how much attention they pay to us.
[cpg]

[OnName num="keitarou"]
......"
[cpg cn=true]


Still, there is a strange air of silence between the two of us.
[cpg]


[FACE method="change_2" pos="2/3"]
The Nobunaga-sama is looking at me and smiling.
[cpg]

[OnName num="keitarou"]
He says, "Well, what do you mean by that face ......?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
Nothing, said Nobunaga-sama. Her smile was a bit sexy.
[cpg]

I wonder if they have any feelings for me.
[cpg]

It was the kind of face that makes you think that. ......
[cpg]

[OnName num="keitarou"]
I'm sure it's fine if it's nothing."
[cpg cn=true]


But I can't help but wonder too. What do I want to be with Nobunaga-sama?
[cpg]

Why did I say I was going off to battle? I feel that there is something deep inside me that is working in a place that I am not aware of.
[cpg]

Nobunaga-sama is such a charming person that I can't help but think that way.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

Then we left the castle. Everyone was uniformly dressed in heavy armor.
[cpg]

Their faces were different. I thought to myself, "A battle is really about to begin.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga079"]
[OnName num="nobunaga"]
Let's go."
[cpg cn=true]


Nobunaga-sama looks calm and collected. According to her, this must be something I'm not used to.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Nobunaga-sama led us to the battlefield.
[cpg]

The opponent is Katsuie Shibata. I don't even know his name.
[cpg]

But we are going to destroy him. Even if I don't do it with my own hands, I will be a part of it.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（昼）******************************************************

And ...... the war is about to begin.
[cpg]

It is said that this battle is also a battle for the family head.
[cpg]

I thought that the surname was different ...... for that, but it seems that he is not the one who is fighting for the viceroy.
[cpg]

It is likely that Katsuie Shibata was the one who encouraged the battle for the governorship.
[cpg]

If he didn't, he would have rebelled more publicly. ...... In any case, he is an enemy to Nobunaga-sama.
[cpg]

In any case, he is an enemy to Nobunaga-sama. He has become an opponent who must be eliminated.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Nobunaga080"]
[OnName num="nobunaga"]
Get back home alive. Keitaro."
[cpg cn=true]


That one word carried the implication that he might die.
[cpg]

[OnName num="keitarou"]
"Of course I will."
[cpg cn=true]


[free time=1000]

I replied and parted from Nobunaga-sama for the moment.
[cpg]

They are told in advance what kind of lineup they will have.
[cpg]

What I have to do is simple. As she said, to return alive.
[cpg]

Of course, I can't not participate in the battle. Even so, my role is second to none.
[cpg]

Both Mitsuhide-sama and Ranmaru-sama have told me that my first priority is to protect my own life.
[cpg]



;//※後のルート分岐に影響
;//　勝利した場合、ヒロイン１ルートへの可能性が残る
;//　敗北した場合、ヒロイン５ルートへの可能性が残る


;//稲生の戦い　マップシステム開始
;//伏兵マスは２、３、７です

;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※稲生の戦い　開始時（１のマスにいる場合のシナリオ）※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Ranmaru-sama seemed awfully uptight. She even went so far as to say that it was not my place to be.
[cpg]

She said that if I wanted to save my life, I should stay in the castle, but I guess that was because she cared about me.
[cpg]

If I followed Ranmaru-sama's advice, I might not have to fight to the end in this battle.
[cpg]

Of course, I can't die, so it would mean retreat. ......
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（昼）******************************************************

And so the battle began. It's not that I have to lead the way, but I don't know where the ambushers are.
[cpg]

The road to the south is open, but the road to the east is overgrown with vegetation.
[cpg]

Which way should I go?　However far I have come from the future, I don't know that much.
[cpg]

Nobunaga-sama is also on this battlefield. If I make the wrong decision, I will be putting Nobunaga-sama's life in danger as well.
[cpg]

However, I have learned some military techniques from Mitsuhide-sama and Ranmaru-sama.
[cpg]

I should not leave everything to her. She is testing me, and I have to make some judgments.
[cpg]


;//■選択肢
[switch]
[case "Proceeding south"]
	[swap]
	[jump target="*select02_4"]
[case "Proceed to the east."]
	[swap]
	[jump target="*select02_2"]
[endswitch]

1. Proceed south.
[cpg]

Two, go east.
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「４のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「２のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※２のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_2|Loyalty to Nobunaga-sama


[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

I led the army, but I had a bad feeling.
[cpg]

That is why I asked Nobunaga-sama to stay. And as we marched on,......
[cpg]

[OnName num="keitarou"]
Damn ......, I knew he was still there.
[cpg cn=true]


An ambush was lurking. I'm not the first one to stand in front of them, but but ......
[cpg]

soldiers were getting wounded. Even though I wasn't at the front of the line, it was a sight I couldn't bear to watch.
[cpg]

I was prepared for the blood to flow because of me.
[cpg]

Then, after a brief sparring match, the ambush soldiers moved back to the east.
[cpg]


;//■選択肢
[switch]
[case "Proceeding south"]
	[swap]
	[jump target="*select02_5"]
[case "Proceeding east"]
	[swap]
	[jump target="*select02_3"]
[endswitch]

1, going south
[cpg]

2, advance to the east
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「３のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※３のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_3|Loyalty to Nobunaga-sama

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

I led my troops toward the ambush soldiers in pursuit.
[cpg]

However, there were more ambush soldiers lurking there.
[cpg]


;//敗北判定となる
;//「稲生の戦い　二度伏兵のマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン５ルートへの可能性が残る


[jump target="*select02_lose"]


;//※※※※※※※※※※※※※※※※※※※※
;//※※※４のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_4

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

As we marched forward, we found that the mountains were to the south.
[cpg]

If we went in order, we should advance east, but we did not know what would happen.
[cpg]

We wanted to get to the enemy's main camp as untired as possible, but what should we do?
[cpg]


;//■選択肢
[switch]
[case "Proceed to the south"]
	[swap]
	[jump target="*select02_7"]
[case "Go to the east"]
	[swap]
	[jump target="*select02_5"]
[endswitch]

1, go south
[cpg]

2, advance to the east
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「７のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※５のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_5|Loyalty to Nobunaga-sama

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン１の立ち絵を表示してください

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]


As we marched forward, Nobunaga-sama followed us.
[cpg]

She cannot go in front of him. Rather, we must protect her.
[cpg]

[OnName num="keitarou"]
I will take the lead. That's fine.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga009"]
[OnName num="nobunaga"]
That's fine. Don't hesitate.
[cpg cn=true]

Seeing my judgment, Nobunaga-sama nodded. I wonder if I am standing well so far.
[cpg]

And little by little, the enemy line is getting closer. The view is quite clear.
[cpg]

Unless I take out the general here, it won't be history as I know it.
[cpg]

Whether I do it or not, we have to win this battle.
[cpg]


;//■選択肢
[switch]
[case "Proceed south."]
	[swap]
	[jump target="*select02_8"]
[case "Proceed east."]
	[swap]
	[jump target="*select02_6"]
[endswitch]

One, proceed south.
[cpg]

Two, advance east.
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※６のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_6|Loyalty to Nobunaga-sama

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

As we marched forward, we were joined by Mitsuhide-sama.
[cpg]

[OnName num="keitarou"]
I can't believe you are here in this battle. Aside from Ranmaru-sama, ......"
[cpg cn=true]


As far as I know, Mitsuhide-sama is not in this battle.
[cpg]

When I mentioned this, Mitsuhide-sama said, "I see.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mituhide016"]
[OnName num="mitsuhide"]
I see. Am I insufficient?"
[cpg cn=true]

I was misunderstood. He seemed to think I was being compared to Ranmaru-sama.
[cpg]

[OnName num="keitarou"]
'No, that's not what I meant. ......
[cpg cn=true]


The enemy camp was almost there. I could not calm myself down.
[cpg]

It's hard to stay calm in a place where life and death are at stake.
[cpg]

But I had already decided which direction to go. I decided to go.
[cpg]


;//■選択肢
[switch]
[case "I proceeded to the south."]
	[swap]
	[jump target="*select02_9"]
[endswitch]

1. Proceeding to the south
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※７のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_7|Loyalty to Nobunaga-sama

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

I led the army, but I had a bad feeling.
[cpg]

That is why I asked Nobunaga-sama to stay. And as we marched on,......
[cpg]

[OnName num="keitarou"]
Damn ......, I knew he was still there.
[cpg cn=true]


An ambush was lurking. I'm not the first one to stand in front of them, but but ......
[cpg]

soldiers were getting wounded. Even though I wasn't at the front of the line, it was a sight I couldn't bear to watch.
[cpg]

I was prepared for the blood to be spilled because of me.
[cpg]

[OnName num="keitarou"]
"......Somehow, you managed to hold on,......."
[cpg cn=true]


Then, after a sparring match, I defeated the ambush soldiers one by one.
[cpg]


;//■選択肢
[switch]
[case "Proceed to the east."]
	[swap]
	[jump target="*select02_8"]
[endswitch]

1. Advance to the east
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※８のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_8|Loyalty to Nobunaga-sama

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン５の立ち絵を表示してください

As we continued on, we met up with Ranmaru-sama.
[cpg]

She looked safe, but her face was different from usual.
[cpg]

;//蘭丸「こっちだ。ついてきな」
The enemy camp was almost there. I could not calm myself down.
[cpg]

It is impossible to stay calm in a place where life and death are at stake.
[cpg]

But I had already decided which direction to go. I was determined.
[cpg]


;//■選択肢
[switch]
[case "I go to the east."]
	[swap]
	[jump target="*select02_9"]
[endswitch]

1. Eastward
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※９のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_9|Loyalty to Nobunaga-sama

[jump target="*select02_win"]


;//マップシステム終了。下記のシナリオへ進む

;//==============================
;//稲生の戦い　９のマスに到達した場合


*select02_win|Loyalty to Nobunaga-sama

[stflag Selectflg2=1]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（夕方）******************************************************

[SE f=se019]
;//【ＳＥ】『刀　打ち合う』

There was a clear difference in force. The other side had nearly twice as many men.
[cpg]

Still, it was a matter of strategy.
[cpg]

It is not a battlefield where one man clashes with one man and they are sure to wear each other out.
[cpg]

I just advanced my troops as I was told, but Nobunaga's army still won.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

I guess that means I have military merit too.
[cpg]

It was something that didn't feel real. I don't even know if it really happened.
[cpg]

I was selfless. Even if I had not wielded a sword myself, a soldier would have been wounded under my command.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Nobunaga081"]
[OnName num="nobunaga"]
I was so selfless that I didn't even have to swing a sword myself. Keep up the good work and become a stronger man.
[cpg cn=true]


[OnName num="keitarou"]
"I didn't do anything.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga082"]
[OnName num="nobunaga"]
Don't be modest. I am telling the truth.
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

No matter how many compliments he received, he was not in the mood for them.
[cpg]

In fact, my mind was more disturbed than it had been before the battle.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

I had killed a man, and it was possible that I had even hurt an ally.
[cpg]

Do I have to stay calm in this situation?
[cpg]

Nobunaga-sama, Mitsuhide-sama, and Ranmaru-sama must have had similar experiences.
[cpg]

I mean, ...... they must be much more responsible than I am.
[cpg]

I can't sleep. I haven't slept for a long time and today I can't sleep again.
[cpg]

While I was in such a state of mind, someone came to visit me.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga083"]
[OnName num="nobunaga"]
"Keitaro, are you sleeping? Are you sleeping?
[cpg cn=true]


[OnName num="keitarou"]
"No, .......
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga084"]
[OnName num="nobunaga"]
He fought really hard. I thought you might run away.
[cpg cn=true]


[OnName num="keitarou"]
I didn't do anything worthy of praise. I can't ...... stop trembling now that I'm involved in someone else's life and death.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga085"]
[OnName num="nobunaga"]
The future will be more peaceful than the present. It is a talent to come from such a time and be able to fight right away.
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
 Nobunaga-sama approaches the burn and strokes my hair.
[cpg]

[OnName num="keitarou"]
Nobunaga-sama ...... what ......?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga086"]
[OnName num="nobunaga"]
I don't know myself very well either. But now I finally understand what was not settled in my heart.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga087"]
[OnName num="nobunaga"]
Now that I know you are a man who can fight bravely, I understand how I feel.
[cpg cn=true]


Nobunaga-sama is very far-fetched. But ......
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（寝ている主人公に近づくヒロイン。キスをする）ev_47
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_47_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]



I can tell by her actions. I know what she is thinking. She brings her face close to mine.
[cpg]

[OnName num="keitarou"]
No!　You must be Nobunaga-sama."
[cpg cn=true]



[VOICE f="Nobunaga088"]
[OnName num="nobunaga"]
She said, "Just think of it as a courtesy. Don't think too much about it.
[cpg cn=true]


Nobunaga-sama brought her lips to mine while saying that.
[cpg]


;**【ＣＧ】 ev_47_a ***********************
[CG id=1 index=1 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sNobunaga002"]
[OnName num="nobunaga"]
"Suck."
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


For the first time in my life, I couldn't say anything. Or is it bad if I say something?
[cpg]

[OnName num="keitarou"]
I said, "...... is it okay? Nobunaga-sama, do this to me.
[cpg cn=true]


;**【ＣＧ】 ev_47_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNobunaga003"]
[OnName num="nobunaga"]
I don't do this to anyone. I'm not interested in love, but I'm not ...... interested in love.
[cpg cn=true]


[OnName num="keitarou"]
I see.
[cpg cn=true]



[VOICE f="sNobunaga004"]
[OnName num="nobunaga"]
I'm attracted to you, I guess. I wonder myself.
[cpg cn=true]


It was Nobunaga-sama who was already saying something almost like a confession.
[cpg]


[VOICE f="Nobunaga110"]
[OnName num="nobunaga"]
Few men living in this time can command in battle.
[cpg cn=true]



[VOICE f="Nobunaga111"]
[OnName num="nobunaga"]
Besides, he must have come from the future. He must have lived in a time of peace.
[cpg cn=true]


[OnName num="keitarou"]
"......, that's true."
[cpg cn=true]



[VOICE f="Nobunaga112"]
[OnName num="nobunaga"]
'I am counting on you,' he said. You've accomplished what no amount of bravery can."
[cpg cn=true]


It's really a waste of words. I even felt embarrassed.
[cpg]


;//ブラックアウト

;//移植前シーンカット

[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************


[VOICE f="sNobunaga005"]
[OnName num="nobunaga"]
I wonder what this feeling is. I'm the most confused of all.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="sNobunaga006"]
[OnName num="nobunaga"]
I want ...... to have a child with you.
[cpg cn=true]


Nobunaga-sama was very aggressive. I was a little puzzled.
[cpg]

[OnName num="keitarou"]
Why did you go to such lengths with ...... me?
[cpg cn=true]


No, it's not that. I'm not talking about that. There is something you should be more careful about.
[cpg]

[OnName num="keitarou"]
If you were to carry a child, it would be a big deal.
[cpg cn=true]


Nobunaga-sama's expression turned dark when he heard that.
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga140"]
[OnName num="nobunaga"]
He said, "I agree with ....... If you were a man, you could have as many children as you like, but I am a woman.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga141"]
[OnName num="nobunaga"]
If you are carrying a child, you will not be able to stand on the battlefield. But we cannot let the blood run out.
[cpg cn=true]


Nobunaga-sama seemed to be feeling impatient.
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga142"]
[OnName num="nobunaga"]
I am not approaching you merely because I do not wish to cut off your blood.
[cpg cn=true]


I guess he meant it. I continued to listen with that thought in my mind.
[cpg]

I can imagine that Nobunaga-sama is probably an ascetic by nature.
[cpg]

I think he just likes me.
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

;//移植前シーンカット

After all, nothing more happened between us at that time.
[cpg]

[OnName num="keitarou"]
He said, "You should think about it again. I mean, are you sure it's me?"
[cpg cn=true]



[VOICE f="Nobunaga167"]
[OnName num="nobunaga"]
'...... I have the same feeling no matter how many times I think about it, but if you say so, I won't force you.'
[cpg cn=true]


Nobunaga-sama seemed to feel that he had been rejected in a roundabout way, and he looked sad.
[cpg]

[jump target="*jump_select02_end"]


;//==============================
;//稲生の戦い　二度伏兵のマスを通った場合

*select02_lose|Loyalty to Nobunaga-sama

[stflag Selectflg2=0]


The soldiers I was leading were exhausted.
[cpg]

Of course, it was not that we were outnumbered. It was not a battle we could not win.
[cpg]

But I don't know if I'll be able to reach the general myself if I don't.
[cpg]

[OnName num="keitarou"]
Damn ......, I'll have to retreat.
[cpg cn=true]


I put my life first and decided to retreat while watching the prevailing situation.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Mituhide012"]
[OnName num="mitsuhide"]
I heard. Keitaro, you are surprisingly timid.
[cpg cn=true]


[OnName num="keitarou"]
'...... call me whatever you want.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide013"]
[OnName num="mitsuhide"]
'I don't think anything of it, but Nobunaga-sama will not like you for that.
[cpg cn=true]


As we were talking about this, Nobunaga-sama was coming.
[cpg]


[free time=800]
[WAIT time=800]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="4/5" time=800]


[VOICE f="Nobunaga169"]
[OnName num="nobunaga"]
He said, "Keitaro is not a coward. There are some circumstances.
[cpg cn=true]


[OnName num="keitarou"]
Nobunaga-sama: ......
[cpg cn=true]


Nobunaga-sama even followed up with me.
[cpg]

 The fact that there is a circumstance means that it came from another era.
[cpg]

I really feel like I can't stand it. I wonder if there will come a time when I, too, will be able to defeat the general of the enemy.
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]


After all, it was Nobunaga-sama who won the battle of Inou.
[cpg]

I was not there to witness it. But I knew, without having to ask her.
[cpg]

There was no way she would lose. With that conviction, I was able to retreat. ......
[cpg]

The one who had the most success in this battle was Ranmaru-sama.
[cpg]

She seemed to be in a good mood, being adored by Nobunaga-sama.
[cpg]


[jump target="*jump_select02_end"]




*jump_select02_end|Battle of Okehazama
[jump storage="ep002.ks" target="*start"]

