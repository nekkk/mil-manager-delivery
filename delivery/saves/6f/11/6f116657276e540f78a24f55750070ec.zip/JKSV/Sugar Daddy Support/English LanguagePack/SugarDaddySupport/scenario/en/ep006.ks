;//２、花

*start|A Motherless Hana

;#################################################
*Ep006|A Motherless Hana
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************


*root_hana|A Motherless Hana

[SCENE id=6]


[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[VOICE f="Hana014"]
[OnName num="hana"]
"...... Uh, who is this?"
[cpg cn=true]

She sounded surprised to get a call from an unknown number.
[cpg]

[OnName num="keiichi"]
"Hey, we met a little while ago. Do you remember me?"
[cpg cn=true]


[VOICE f="Hana015"]
[OnName num="hana"]
"What?"
[cpg cn=true]

[OnName num="keiichi"]
"You know Kanako right? She gave me your number."
[cpg cn=true]

Hana continues to be confused on the other end of the phone. She keeps repeating "but......" and "what?" Well, maybe that's how it is.
[cpg]

To her, I must have remained simply as a memory of fear. I can understand this reaction to some extent.
[cpg]

[OnName num="keiichi"]
"How are you doing these days? Are you still poor?"
[cpg cn=true]


[VOICE f="Hana016"]
[OnName num="hana"]
"Hey, that's none of your business."
[cpg cn=true]

Didn't she want to see me that much? But I can't back down here......
[cpg]

[OnName num="keiichi"]
"It kind of is my business."
[cpg cn=true]


[VOICE f="Hana017"]
[OnName num="hana"]
"I don't want anything to do with you anymore."
[cpg cn=true]

[OnName num="keiichi"]
"Are you sure? I thought you needed the money."
[cpg cn=true]

Over the phone, Hana fell silent.
[cpg]

[OnName num="keiichi"]
"I'll wait for you. If you change your mind, call me."
[cpg cn=true]


[SE f="se034"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー

[free time=1000]
[WAIT time=1000]

I hang up, thinking that I'd made good progress.
[cpg]

I think this kind of action will come into play later......If her guard is tight, I have no choice but to break it down. And it is not something that can be done with a single thrust.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（朝）******************************************************

In the morning after waking up. I had an idea for the next action, but it was time to go to work.
[cpg]

She and Kanako were both students. They would be busy in the morning.
[cpg]

I thought to myself, "I'll call her again at night......", and left the house.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

When you live your life with a purpose, the streets begin to look different.
[cpg]

It is also a reminder of how I have been living my life in vain......but more than that.
[cpg]

The fact that I'm now able to concentrated on making Hana mine is taking away the feeling of emptiness inside of me.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Then night came, and I decided to take action.
[cpg]


[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[OnName num="keiichi"]
"Kanako? It's me."
[cpg cn=true]


[VOICE f="Kanako122"]
[OnName num="kanako"]
"What is it? You want to see me?"
[cpg cn=true]

We've had this exchange before......Was this the third time? Or the fourth?
[cpg]

[OnName num="keiichi"]
"Hana's your friend, right?"
[cpg cn=true]

[OnName num="keiichi"]
"I want to know more about her. Tell me anything you know."
[cpg cn=true]

[VOICE f="Kanako123"]
[OnName num="kanako"]
"Weeeell..."
[cpg cn=true]

It was as if I could hear Kanako's nose breathing. It was as if she wanted to be there if possible.
[cpg]


[VOICE f="Kanako124"]
[OnName num="kanako"]
"She's a friend from my old school, and we still see each other often."
[cpg cn=true]

The more I listen to the story, the more I can't believe it, yet I have no choice but to believe it.
[cpg]

Kanako was extremely flexible but Hana was hard-headed. They are opposite to the extent that they are on the same wavelength.
[cpg]

I felt that surely there would be no other reason for them to be friends.
[cpg]

[OnName num="keiichi"]
"I see......well I guess if there's one thing you're good at, it's taking things in stride."
[cpg cn=true]


[VOICE f="Kanako125"]
[OnName num="kanako"]
"Heh heh. Well, thank you."
[cpg cn=true]

[OnName num="keiichi"]
"That wasn't really a compliment."
[cpg cn=true]

This was proof that she had a loose personality.
[cpg]

[OnName num="keiichi"]
"So why did you bring Hana?"
[cpg cn=true]


[VOICE f="Kanako126"]
[OnName num="kanako"]
"Well, she's in trouble. Do you wanna hear about it?"
[cpg cn=true]

Why was she asking me that? I said I wanted to hear all about her, didn't I? She was trying to tease me.
[cpg]

However, I don't complain to her. If I complain, she would say something loose and not pretend to hear me.
[cpg]

[OnName num="keiichi"]
"Oh, then let me hear it."
[cpg cn=true]


[VOICE f="Kanako127"]
[OnName num="kanako"]
"First of all, her mother is dead."
[cpg cn=true]

Sad, but nothing exceptional...until Kanako continued, explaining that Hana's father was also deeply in debt.
[cpg]

Apparently, she even has a sister, and no matter how many part-time jobs she took, it was not enough.
[cpg]

[OnName num="keiichi"]
"That's an amazing story......Is such a thing possible nowadays?"
[cpg cn=true]

[VOICE f="Kanako128"]
[OnName num="kanako"]
"Yes. But you're going to help her, right?"
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

From there, it was just a silly conversation. Kanako may think she is explaining in detail, but she didn't seem to understand what I wanted to hear.
[cpg]

I couldn't get anything more out of her other than that Hana's mother was dead and that her father owed money.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************


[VOICE f="Kanako129"]
[OnName num="kanako"]
"I guess that's about it......"
[cpg cn=true]

[OnName num="keiichi"]
"I see. I understand. Thanks for telling me. Bye then."
[cpg cn=true]

I said so randomly and tried to hang up the phone. Then she said,
[cpg]


[VOICE f="Kanako130"]
[OnName num="kanako"]
"Oh, you're hanging up already? Do you have any plans to meet with me again?"
[cpg cn=true]


[SE f="se034"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー

[free time=1000]
[WAIT time=1000]

Before she could get to that topic, I forcefully hung up the phone.
[cpg]

[OnName num="keiichi"]
"......Phew."
[cpg cn=true]

I casually look at my watch. It wasn't that late yet.
[cpg]

[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル



I might as well call Hana. I don't know how long it will take to convince her, but I'll have to keep trying to find out.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[OnName num="keiichi"]
"....Hey, sorry. It's me again."
[cpg cn=true]


[VOICE f="Hana018"]
[OnName num="hana"]
"You again ......"
[cpg cn=true]

This time, she noticed my phone number. She wasn't as taken aback as she had been before.
[cpg]

[OnName num="keiichi"]
"I said I'd wait, but I changed my mind. Can I talk to you for a minute."
[cpg cn=true]


[VOICE f="Hana019"]
[OnName num="hana"]
"Don't call me again. I'm hanging up......"
[cpg cn=true]

She's pretty guarded. I tried to hold her back, choosing my words carefully.
[cpg]

[OnName num="keiichi"]
"Wait. It's not like I just want to see you."
[cpg cn=true]

She didn't hang up the phone. I kept talking.
[cpg]

[OnName num="keiichi"]
"I'll buy you what you want. I promise."
[cpg cn=true]


[VOICE f="Hana020"]
[OnName num="hana"]
"......What's the catch? It all sounds too good to be true."
[cpg cn=true]

[OnName num="keiichi"]
"There's no catch. Besides, if it sounds good, then why are you hesitating?"
[cpg cn=true]

She was silent. I guess she was in the middle of deciding.
[cpg]

What can I say to convince her......? Kanako and the other girls are the type to ask me rather than be asked.
[cpg]


;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]


In this way, we managed to arrange a meeting.
[cpg]

It will make all the difference with how gentle I am the next time we meet.
[cpg]

Maybe that was not the best attitude to approach the situation, but that was how I felt.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hp"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

[FACE method="change_4" pos="2/3"]
[VOICE f="Hana021"]
[OnName num="hana"]
"......"
[cpg cn=true]

Hana was the first to arrive at the place of our meet-up. I was surprised to see her since she had often been late before.
[cpg]

[OnName num="keiichi"]
"You're early today. Are you ready for this?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Hana022"]
[OnName num="hana"]
"You really aren't going to do anything......?"
[cpg cn=true]

[OnName num="keiichi"]
"Within reason, sure."
[cpg cn=true]

She was stiff and nervous. Was it because Kanako was not next to her? If so, it must be true that they are friends.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

I took her into my room.
[cpg]


;//●ＣＧ（花・キスをする二人：主人公の部屋）ev_29

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="Hana023"]
[OnName num="hana"]
"Wait......you promised......"
[cpg cn=true]


When I approached her, she was still reluctant.
[cpg]

[OnName num="keiichi"]
"I'm not thinking about doing anything more than this."
[cpg cn=true]


I don't want to push it. No......
[cpg]

I was not going to just give her something and get nothing in return.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************

After that, I decided to go to the city again and buy what Hana wanted.
[cpg]

A designer bag. I don't think she really wants this kind of thing.
[cpg]

I gave it to her, thinking that she would probably sell it to someone else......
[cpg]

[OnName num="keiichi"]
"Here, take it."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

Hana's eyes light up a little. Then she looks at the money and me alternately.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Hana024"]
[OnName num="hana"]
"Are you sure......?"
[cpg cn=true]

[OnName num="keiichi"]
"What, do you want me to change my mind?"
[cpg cn=true]

Still, Hana didn't seem convinced.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Hana025"]
[OnName num="hana"]
"Please, tell me......why are you being so nice to me?"
[cpg cn=true]

I don't know. What would be the best way to explain it?
[cpg]

[OnName num="keiichi"]
"I don't know. I wonder why."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Hana026"]
[OnName num="hana"]
"......"
[cpg cn=true]

Hana seems to be worried that things are going too well.
[cpg]

I can't just tell her how I really feel. I am in a dilemma.
[cpg]

[OnName num="keiichi"]
"I really don't know, believe me. I'm almost as surprised as you are."
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Hana027"]
[OnName num="hana"]
"You can tell me the truth..."
[cpg cn=true]

[OnName num="keiichi"]
"What's there to tell......?"
[cpg cn=true]

She was persistent, but I know how she felt. I know what it feels like to suspect that you are being cheated somehow.
[cpg]

[OnName num="keiichi"]
"Somehow. Somehow, I felt like splurging. Does that make sense?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Hana028"]
[OnName num="hana"]
"......"
[cpg cn=true]

She didn't look too convinced. Well, of course she wasn't. She was being lied to.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

On the way back to my place.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************

[OnName num="keiichi"]
"......What the hell is that?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Hana029"]
[OnName num="hana"]
"Oh...... this, well......"
[cpg cn=true]

If you look closely, you can see bruises on her body.
[cpg]

[OnName num="keiichi"]
"What's wrong? Why are you injured?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Hana030"]
[OnName num="hana"]
"Well, this is......nothing serious."
[cpg cn=true]

Hana doesn't say that she bumped into something or that she fell and hurt herself.
[cpg]

That alone seems like a big enough deal. However.
[cpg]

[OnName num="keiichi"]
"......I see."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]

I don't ask any further. She had a complicated family situation, so there must be something going on.
[cpg]

And if I wanted to ask, I could probably get the information from Kanako or so.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hp"]
[WAIT time=100]


From there, I parted from Hana and walked toward home.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『住宅街』（夜）******************************************************


During the walk, I thought about a lot of things. What are some of the situations where you can't talk to people about bruises?
[cpg]

......Well, abuse. That was the only explanation. Was her dad the abuser?
[cpg]

[OnName num="keiichi"]
"That must be hard......"
[cpg cn=true]

But it's nothing for me to worry about. If Hana starts earning money, maybe those bruises won't get added.
[cpg]

If that is the case, then what I am doing is right to some extent. With that thought, I headed home.
[cpg]

[SE f="se001"]
;//【ＳＥ】『ドア閉まる』

[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

[OnName num="keiichi"]
"Whew......"
[cpg cn=true]

I thought about what had happened today. Hana's injuries were fresh in my mind.
[cpg]

[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル

[WAIT time=1000]

I thought that Kanako would know something about it, so I called her.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[OnName num="keiichi"]
"Hello? Kanako?"
[cpg cn=true]


[VOICE f="Kanako131"]
[OnName num="kanako"]
"Yes, yes, this is Kanako. You wanted to see me?"
[cpg cn=true]

[OnName num="keiichi"]
"Just stop that......"
[cpg cn=true]

I needed to know what had happened to Hana.
[cpg]

[OnName num="keiichi"]
"Do you know that Hana has bruises on her body?"
[cpg cn=true]

Kanako did not reply. I don't know whether she was amused or just silent, wondering what it was all about.
[cpg]

[OnName num="keiichi"]
"What is it? Is it abuse from her father?"
[cpg cn=true]


[VOICE f="Kanako132"]
[OnName num="kanako"]
"Bruises......"
[cpg cn=true]

Kanako groaned. Maybe she doesn't really understand what was going on.
[cpg]


[VOICE f="Kanako133"]
[OnName num="kanako"]
"I don't know either. Maybe something happened."
[cpg cn=true]

[OnName num="keiichi"]
"I see......"
[cpg cn=true]

The fact that even her friend Kanako doesn't know means that it's something she wants to keep hidden.
[cpg]

Then I don't know if it's a good idea to ask any more questions......Yet, I'm still curious.
[cpg]

If I find out what kind of a family she comes from, then the method I will use to pursue her might change a little.
[cpg]

[OnName num="keiichi"]
"Could you ask her about it in a roundabout way the next time you see her?"
[cpg cn=true]


[VOICE f="Kanako134"]
[OnName num="kanako"]
"I can't do that for free."
[cpg cn=true]

[OnName num="keiichi"]
"......I see. You're right."
[cpg cn=true]

Kanako, who is not a greedy person, says she can't do it for free. That means that she doesn't want to ask.
[cpg]

She's no use, I'll just back down now. I guess I should ask Hana directly.
[cpg]

[OnName num="keiichi"]
"I'm sorry for calling you so late at night. I'm hanging up now."
[cpg cn=true]


[VOICE f="Kanako135"]
[OnName num="kanako"]
"Well, aren't you going to meet me?"
[cpg cn=true]

[OnName num="keiichi"]
"When I feel like it......Hana said she'd feel more at ease if you were there."
[cpg cn=true]

I know, I know.", she says.
[cpg]

But when she's there, the atmosphere becomes lighter. Unfortunately, that wasn't what I was looking for right now.
[cpg]

[OnName num="keiichi"]
"I'll call you when I feel like it."
[cpg cn=true]


[VOICE f="Kanako136"]
[OnName num="kanako"]
"That means the same thing, Keiichi."
[cpg cn=true]

I'm sure she was right. I keep thinking the same thing. I hung up the phone without responding.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[BGM f="bg_t2"]
[WAIT time=100]

A few days passed from there.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社内』（昼）******************************************************

Now, I should wait for her to contact me. Now that she knows that she can make money, she won't ignore me.
[cpg]

I think I can do a lot more if she comes to me rather than me going to her......
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（夜）******************************************************


[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[WAIT time=1500]

And it turns out that my plan worked.
[cpg]

[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[OnName num="keiichi"]
"Yeah, it's me."
[cpg cn=true]


[VOICE f="Hana031"]
[OnName num="hana"]
"Uh, is this...Keiichi?"
[cpg cn=true]

[OnName num="keiichi"]
"That's right. What do you want?"
[cpg cn=true]

I already guessed what she wanted without having to ask her. But I dared to let Hana tell me.
[cpg]

[VOICE f="Hana032"]
[OnName num="hana"]
"I was wondering if I could see you again......"
[cpg cn=true]


[OnName num="keiichi"]
"Yeah, sure."
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then we decided on a place and time to meet. Since it was impossible to meet right now because of her part-time job, we decided to meet the following day.
[cpg]

She was working the night shift which was normal for students I guess. What a hassle. 
[cpg]



[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（昼）******************************************************

Then, the next day.
[cpg]

My work was the same as usual, but the thought of meeting Hana after this made me feel that time was passing slowly.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=3000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************

[SE f="se027"]
;//【ＳＥ】『喧騒』

And then I meet up with Hana again.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hana033"]
[OnName num="hana"]
"Umm....It's good to see you......"
[cpg cn=true]

[OnName num="keiichi"]
"Huh."
[cpg cn=true]

Her opening sentence was awkward. But it was progress since she was finally able to say something.
[cpg]

;//移植のためシーンをカットしています


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************

She was not as nervous as the last time I brought her to my room.
[cpg]

I wonder if I could kiss her again.
[cpg]


;//●ＣＧ（花・背後からヒロインに近づく主人公：ラブホテル）ev_32
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_32_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

I approached her again and she looked like she wasn't ready.
[cpg]

[VOICE f="Hana034"]
[OnName num="hana"]
"Wait a minute......"
[cpg cn=true]


[OnName num="keiichi"]
"Why?"
[cpg cn=true]


[VOICE f="Hana035"]
[OnName num="hana"]
"I don't want to rush it......"
[cpg cn=true]


This wasn't going anywhere, I decided to give up for the day.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_rl"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』


I didn't even kiss her today. But I bought her something.
[cpg]

She seemed surprised, but I'm sure she'll come to understand my psychology in time.
[cpg]

[OnName num="keiichi"]
"Well, I'll see you later. Let me know if you need anything."
[cpg cn=true]



[FACE method="bow_7" pos="2/3"]
[VOICE f="Hana036"]
[OnName num="hana"]
"Yeah, good-bye then......"
[cpg cn=true]


[SE f="se001"]
;//【ＳＥ】『歩く』

[free time=1000]
[WAIT time=1000]


I was on my way home again. I was getting used to this road.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（夜）******************************************************

The family situation will be resolved, I assured her, but I didn't ask how much debt her dad had.
[cpg]

I wonder if he was just trying to pay the interest. If so, it might be pointless.
[cpg]

Or maybe the debt isn't as big as it seems.
[cpg]

I could ask, but I also don't have to.
[cpg]

Neither I nor Hana is in an untenable situation. From my point of view, Hana doesn't seem to be in a catastrophic situation.
[cpg]

For example, her clothes are not in tatters, nor is her body covered with scars.
[cpg]

But she did have bruises......but those might be bruises that would lessen if she could give money to her dad.
[cpg]

Whatever the case, I had a feeling that things were slowly getting better.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（朝）******************************************************

[OnName num="keiichi"]
"......"
[cpg cn=true]

However, when I went to sleep and woke up, my thoughts changed a bit again.
[cpg]

The emptiness that hit me in the morning makes me question myself.
[cpg]

For example, "Why does the gradual improvement of the situation seem somehow desirable?"
[cpg]

Or for example, "Do I like Hana?" Questions that don't need to be answered drift in my mind in the morning.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************


I manage to shake them off and go to work, but the good feeling that I had last night turned into a bad one.
[cpg]

My premonitions usually end up being right. I wonder why?
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hp"]
[WAIT time=100]
;//【ＢＧ】『住宅街』（夜）******************************************************

The sun goes down and it gets completely dark. And my thoughts are still as dark as ever.
[cpg]

Then, I received a phone call from her.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

I was so certain that I would hear from Hana that I thought it would be either work or her when I got the call.
[cpg]

But the person on the other end of the phone was not her.
[cpg]

[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]



[VOICE f="Kanako137"]
[OnName num="kanako"]
"Hey, Keiichi."
[cpg cn=true]

[OnName num="keiichi"]
"Oh, it's you Kanako......"
[cpg cn=true]


[VOICE f="Kanako138"]
[OnName num="kanako"]
" What do you mean by that? How rude."
[cpg cn=true]

I'd been expecting Hana to call, so I couldn't hide my disappointment.
[cpg]

[OnName num="keiichi"]
"What do you want?"
[cpg cn=true]

[VOICE f="Kanako139"]
[OnName num="kanako"]
"Keiichi, did you do something terrible to Hana?"
[cpg cn=true]

[OnName num="keiichi"]
"......umm......well."
[cpg cn=true]

I had no idea what she was talking about, but I was caught off guard by the way she asked me. Kanako's tone of voice sounded like she was really worried about Hana.
[cpg]

[OnName num="keiichi"]
"Did something happen? Was she injured or something?"
[cpg cn=true]

Once again, Kanako was silent through the receiver. It sounded like she was trying to find out what was really going on.
[cpg]

[OnName num="keiichi"]
"Please answer me. What's going on?"
[cpg cn=true]


[VOICE f="Kanako140"]
[OnName num="kanako"]
"Well, Hana appeared wearing a face mask one day."
[cpg cn=true]

[OnName num="keiichi"]
"......What?"
[cpg cn=true]

I reacted not because I was surprised, but because I didn't know what it meant.
[cpg]

I couldn't understand her logic of being negative just because she was wearing a face mask.
[cpg]


[VOICE f="Kanako141"]
[OnName num="kanako"]
"Hana wouldn't take her face mask off. So I forced her to take it off."
[cpg cn=true]

There were bruises all over her face......Kanako continues.
[cpg]

[OnName num="keiichi"]
"Oh......"
[cpg cn=true]

That was an extraordinary event. I knew my feeling was right......
[cpg]

[OnName num="keiichi"]
"If you're suspecting me, don't. I'm not screwed up enough to do something like that."
[cpg cn=true]

I don't know about that, Kanako muttered. I let that pass and ask more questions.
[cpg]

[OnName num="keiichi"]
"Don't you have any idea who's doing this to her? Can't you imagine who's doing that?"
[cpg cn=true]


[VOICE f="Kanako142"]
[OnName num="kanako"]
"I guess from what you said about the......bruises, it could be her father."
[cpg cn=true]

[OnName num="keiichi"]
"Yeah, I can't think of anyone else."
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

We talked for a while from there, but I couldn't get to the bottom of it. I thought things must be getting better since she was getting the money after all.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************


[VOICE f="Kanako143"]
[OnName num="kanako"]
"I don't think that we can come to any conclusions."
[cpg cn=true]

[OnName num="keiichi"]
"I guess so......"
[cpg cn=true]

I guess the only way to conclude is to ask Hana directly after all. Of course, it is not something I can just ask her about, so I have to wait for her to tell me.
[cpg]

[OnName num="keiichi"]
"It's getting quite late, isn't it?"
[cpg cn=true]


[VOICE f="Kanako144"]
[OnName num="kanako"]
"Yes, it is. I don't want to waste any more money on the phone bill. I'll talk to you later then."
[cpg cn=true]

[OnName num="keiichi"]
"Yeah."
[cpg cn=true]


[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』
[free time=1000]
[WAIT time=1000]


Just like that, I hang up the phone. I was concerned about Hana, but there was nothing I could do about it right now.
[cpg]

Still, I felt like I needed to call Hana. Maybe it was just to suppress the anxiety inside me, or maybe it was just because I wanted to hear her voice.
[cpg]

After all, it was late in the day, so I decided to do it another time......
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_h3"]
[WAIT time=100]
;//【ＢＧ】『空』（昼）******************************************************

I'm not making much progress at work. At least, not compared to normal.
[cpg]

Up until now, it was unthinkable that I'd struggle with my work, but even that was gradually changing.
[cpg]

All of this has happened since I came into contact with a girl named Hana. The stagnant atmosphere is gradually changing.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=3000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（夜）******************************************************

[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

And just like that, things changed drastically.
[cpg]

[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[OnName num="keiichi"]
"It's me. What's wrong, Hana?"
[cpg cn=true]

Hana called me. Her voice was trembling. It was a cry of grief.
[cpg]


[VOICE f="Hana037"]
[OnName num="hana"]
"Please. Can I see you right now?"
[cpg cn=true]

[OnName num="keiichi"]
"Calm down. Take a deep breath and tell me what happened."
[cpg cn=true]

I tried to calm her down, but she became even more panicked, and her voice was muffled.
[cpg]

Something bad was happening and I didn't particularly enjoy not being able to do anything about it.
[cpg]

[OnName num="keiichi"]
"Can you explain to me everything? First, why do you want to see me?"
[cpg cn=true]

Still distraught, Hana replies,
[cpg]


[VOICE f="Hana038"]
[OnName num="hana"]
"I don't have time to explain, I need the money......!"
[cpg cn=true]

;//[lbox off]

That was not a good enough answer, still I had no choice but to comply.
[cpg]

I didn't know what was going on, so I designated a place and we met up.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************

[OnName num="keiichi"]
"......Long time no see, Hana."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Hana039"]
[OnName num="hana"]
"...... Yeah. Umm......"
[cpg cn=true]

When I saw her, she looked frightened.
[cpg]

The wounds on her face had mostly healed, but the discoloration remained. I was reminded of the phone call I had with Kanako.
[cpg]

[OnName num="keiichi"]
"I saw a bruise on you before..."
[cpg cn=true]

She looked down and said nothing. I continued to speak.
[cpg]

[OnName num="keiichi"]
"Your father, huh? Does that have anything to do with the debt?"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Hana040"]
[OnName num="hana"]
"How do you know about that?"
[cpg cn=true]

[OnName num="keiichi"]
"I heard about it from Kanako. She told me about it."
[cpg cn=true]


[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『住宅街』（夜）******************************************************

[OnName num="keiichi"]
"Tell me. Why do you need the money? I want to know more about it."
[cpg cn=true]

[OnName num="keiichi"]
"If it's just your father's debt, it should have nothing to do with you."
[cpg cn=true]

Hana was reluctant to say anything, but little by little she clarified the situation.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Hana041"]
[OnName num="hana"]
"If I don't give my father the money every month, he......"
[cpg cn=true]

[OnName num="keiichi"]
"If you don't give it to him, he'll beat you?"
[cpg cn=true]

Hana nods, revealing the true nature of her father.
[cpg]

He is the kind of father who would even hit Hana's sister if she didn't bring enough money.
[cpg]

Hana is very protective of her sister, and so she has to complete the task.
[cpg]

[OnName num="keiichi"]
"......I see. It must be tough."
[cpg cn=true]


Unintentionally, such a childish reply comes out of my mouth. It was a dramatic story.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Hana042"]
[OnName num="hana"]
"Please, I need the money. After I told him about you, he said I could make more money......"
[cpg cn=true]


I was really angry with Hana's father. But at the same time, I think that he is not someone you cannot get angry at directly.
[cpg]

We are not much different, and I may be more despicable than he is.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************

Then I was alone with Hana.
[cpg]

;//●ＣＧ（花・ヒロインに近づく主人公：恵一の部屋）ev_34
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

Kissing her was a kind of an excuse.
[cpg]

In reality, I would have given her anything, even money, without anything in return.
[cpg]

But without an excuse, I won't be able to justify what I was doing.
[cpg]

[VOICE f="Hana043"]
[OnName num="hana"]
"What's wrong......?"
[cpg cn=true]


[OnName num="keiichi"]
"Nothing."
[cpg cn=true]

;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

We stayed together for a long time that day.
[cpg]

I was afraid to let her go home. Maybe that's why I stayed by her side until she fell asleep.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I couldn't decide if my feelings for Hana were real affection or not. Then I woke up in the morning.
[cpg]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_rl"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************


[FACE method="bow_4" pos="2/3"]
[VOICE f="Hana044"]
[OnName num="hana"]
"Good morning...... Keiichi."
[cpg cn=true]

[OnName num="keiichi"]
"Oh, good morning......"
[cpg cn=true]

Hana didn't seem to know how to approach me.
[cpg]

There may be a part of her that can't decide whether to hate me or not.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Hana045"]
[OnName num="hana"]
"Um......well, I have to go to school......"
[cpg cn=true]

[OnName num="keiichi"]
"Oh, right. Sorry, I didn't mean to keep you."
[cpg cn=true]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社内』（昼）******************************************************

Then I bought her what she wanted and went right to work.
[cpg]

I went to work as usual, but my mind was full of Hana.
[cpg]

Never before had my mind been so occupied with one person.
[cpg]

I used to think I was an empty shell of a person, but apparently that was changing.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hp"]
[WAIT time=100]
;//【ＢＧ】『会社内』（夜）******************************************************

And then a few days passed.
[cpg]


;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン


[OnName num="keiichi"]
"Hmm......"
[cpg cn=true]

The display on my cell phone said "Kanako". She would call me every once in a while.
[cpg]

I couldn't believe she would go to such lengths to meddle in the affairs of her friend sleeping with someone else. Kanako seemed to be that type of person.
[cpg]


[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[VOICE f="Kanako145"]
[OnName num="kanako"]
"Hello, hello. It's Kanako."
[cpg cn=true]

[OnName num="keiichi"]
"Don't greet me like that......What do you want?"
[cpg cn=true]

"That's the thing," Kanako began, prefacing her story.
[cpg]


[VOICE f="Kanako146"]
[OnName num="kanako"]
"Hana's mood seems to be a little better. That's why I got anxious."
[cpg cn=true]

[OnName num="keiichi"]
"What?"
[cpg cn=true]

The sentences don't connect well in my head. She was worried because she seems to be in a good mood?
[cpg]

[OnName num="keiichi"]
"What do you mean? Tell me so I can understand."
[cpg cn=true]

Kanako just repeated the same thing one more time.
[cpg]

Hana's mood improved and Kanako became anxious. She said the same thing just a little more in detail.
[cpg]

[OnName num="keiichi"]
"If she's in a good mood, then that should be fine. Explain to me what's making you uneasy."
[cpg cn=true]


[VOICE f="Kanako147"]
[OnName num="kanako"]
"Well......if things continue as they are, Hana's father will take advantage of her."
[cpg cn=true]

[OnName num="keiichi"]
"...... yeah, well, I guess so."
[cpg cn=true]

So that was what she wanted to talk about. It was something I hadn't thought about just yet.
[cpg]

[OnName num="keiichi"]
"Let it go. What do you want me to do?"
[cpg cn=true]

Kanako coughed on the other end of the phone. "I'd like to talk to you about something," she said, with her high pitched voice.
[cpg]


[VOICE f="Kanako148"]
[OnName num="kanako"]
"I can tell you where Hana lives. I know because I'm her friend."
[cpg cn=true]

[OnName num="keiichi"]
"So what? What do you mean by that?"
[cpg cn=true]

[OnName num="keiichi"]
"What does Hana's father taking advantage have to do with me knowing Hana's house?"
[cpg cn=true]

Kanako is not a bad communicator. But today she seems to be nervous.
[cpg]

[OnName num="keiichi"]
"Don't tell me you're suggesting that I should go to Hana's house."
[cpg cn=true]

It's close, Kanako said. Oh, come on, give me a break.
[cpg]


[VOICE f="Kanako149"]
[OnName num="kanako"]
"If you don't want to, then I can look for evidence of abuse."
[cpg cn=true]

Apparently, Kanako is proposing to solve the cause of Hana's suffering.
[cpg]

I guess she really is a friend. So I thought at the time......
[cpg]

[OnName num="keiichi"]
"Wait. Why are you telling me that? If that's what you think, then go ahead and do it."
[cpg cn=true]

Kanako is silent on the other end of the phone. Why is she being quiet now?
[cpg]

[OnName num="keiichi"]
"Don't tell me you're talking about taking my money or something?"
[cpg cn=true]


[VOICE f="Kanako150"]
[OnName num="kanako"]
"Yes, well......I don't think I'm a greedy person either."
[cpg cn=true]


[VOICE f="Kanako151"]
[OnName num="kanako"]
"But it's a risky business, isn't it? Then, it wouldn't be worth it if there was no reward."
[cpg cn=true]

Kanako may also be in some kind of financial trouble.
[cpg]

It seemed unnatural for her to act for money.
[cpg]

However, I should make Hana's situation a priority now. And I understood roughly what Kanako was trying to say.
[cpg]

Kanako will get evidence of abuse and get her father away from Kanako. And she supports me and Hana's relationship.
[cpg]

She'll help me if I pay her.
[cpg]

[VOICE f="Kanako152"]
[OnName num="kanako"]
"You don't have to give me an answer right now. If you need help again, just let me know."
[cpg cn=true]

[SE f="se035"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー

[free time=1000]
[WAIT time=1000]

With these words, Kanako hung up the phone.
[cpg]


;//ＢＫ

Surely, if Kanako could get proof of her father's abuse and turn him in, to the police, both Hana and her sister would be free.
[cpg]

Would that mean that Hana and her sister would go to some institution......?
[cpg]

I don't have to think about whether or not that is what they both want.
[cpg]

It can't be good for Hana to have a father who is violent.
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（朝）******************************************************

I fell asleep thinking about this, and in the morning, my cell phone rang.
[cpg]


[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[VOICE f="Hana046"]
[OnName num="hana"]
"I'm sorry, Keiichi......I need some money again."
[cpg cn=true]

It was really early in the morning. I rubbed my sleepy eyes and listened to Hana's story.
[cpg]

[OnName num="keiichi"]
"......Is it your father? Wasn't the money enough the other day?"
[cpg cn=true]

[OnName num="keiichi"]
"Why don't you tell the police that you're being abused?"
[cpg cn=true]


[VOICE f="Hana047"]
[OnName num="hana"]
"Well, yes......it's, uh..."
[cpg cn=true]

Hana is apparently confused by the sudden need for money. The answer is not very clear.
[cpg]

[OnName num="keiichi"]
"If it's too hard, I can call them for you."
[cpg cn=true]


[VOICE f="Hana048"]
[OnName num="hana"]
"No, no! You can't do that!"
[cpg cn=true]

But this time, she clearly refused. I was puzzled, so I asked her why.
[cpg]

[OnName num="keiichi"]
"Why not? Are you saying you want things to be the way they are now?"
[cpg cn=true]

Hana fell silent. The silence felt like a virtual affirmation.
[cpg]

[OnName num="keiichi"]
"What's wrong with you......? Is your environment that important to you? Or you don't want to leave your home?"
[cpg cn=true]


[VOICE f="Hana049"]
[OnName num="hana"]
"No, but......there was a time when my father was decent."
[cpg cn=true]

According to Hana, her father was decent. He was a good father who cared for his family until her mother passed away.
[cpg]

Hana believes that maybe those days will come back.
[cpg]

I was about to say, "That's a complicated story."
[cpg]


[VOICE f="Hana050"]
[OnName num="hana"]
"I can't do anything that would betray my father......"
[cpg cn=true]

[OnName num="keiichi"]
"......I see. Well, then, what are you going to do......?"
[cpg cn=true]

;//十分、もう裏切られてるよ。そう言いたかったが、やめておいた。
He already betrayed you. I wanted to say that, but I didn't.
[cpg]

I don't want to lose my relationship with Hana by forcing her to report him.
[cpg]

From there, I discuss with Hana and decide where and when to meet up.
[cpg]

I couldn't miss work, so we decided on meeting at night. We decided on a park as our meeting spot.
[cpg]


[SE f="se035"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー

[free time=1000]
[WAIT time=1000]

I wonder how things got so complicated. I wish Hana could just live her life the way she wants to.
[cpg]

Although, I don't have an ideal image of how I want to live either.
[cpg]

[OnName num="keiichi"]
"I guess I'd better get to work......"
[cpg cn=true]

My mind is occupied with Hana. I don't even deny that anymore.
[cpg]

But I still couldn't decide whether to solve this troublesome situation or leave it alone.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

And then time passed, and night came.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『公園』（夜）******************************************************

[OnName num="keiichi"]
"Did I keep you waiting, Hana?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Hana051"]
[OnName num="hana"]
"No......it's okay. I'm fine......"
[cpg cn=true]

[OnName num="keiichi"]
"Really, you're okay with your father? You don't want me to do anything?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]

Hana said, "Yes". She didn't hesitate.
[cpg]

She refused when I first asked her if I should call the cops. That means I'm the only one who's still thinking about it.
[cpg]

[OnName num="keiichi"]
"It's too public out here."
[cpg cn=true]


I said, pulling her hand.
[cpg]


;//ＢＫ
;//●ＣＧ（花・主人公を見つめるヒロイン：路地裏）ev_36
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[OnName num="keiichi"]
You sure you want to leave things the way they are?"
[cpg cn=true]


Seeing how honest Hana was, I asked her frankly.
[cpg]

[VOICE f="Hana052"]
[OnName num="hana"]
"......Yes."
[cpg cn=true]


What does that answer mean? Was she happy?
[cpg]

I don't understand. I don't understand, but......
[cpg]


;//移植のためシーンをカットしています

;//●ＣＧ（花・ヒロインにキスを迫る主人公：路地裏）ev_37
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_37_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


Being nice wasn't enough.
[cpg]

[VOICE f="Hana053"]
[OnName num="hana"]
"......"
[cpg cn=true]


She just waits for me, silently.
[cpg]

I can't think the same thing as Hana.
[cpg]

This repetition needs to end someday.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ
;//[free time=1000]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
;//[WAIT time=1000]


How long will I keep doing this? Hana will continue to suffer, and the only one who will benefit is her father.
[cpg]


In the end, I can't tear Hana away from her dad and make her live on her own.
[cpg]

Maybe there are institutions for children who have lost their parents......
[cpg]


;//[window target=false]
;//[free time=1000]
;//[BG f="b_02_4.ui" time=1000]
;//[WAIT time=2000]
;//[window target=true]
;//[WAIT time=100]

;//【ＢＧ】『空』（夜）******************************************************


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）


If not, maybe I can provide for them......
[cpg]

I've noticed a feeling inside me. I have affection for Hana.
[cpg]

[OnName num="keiichi"]
"It's about your father......or maybe even  about you......"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Hana054"]
[OnName num="hana"]
"What is it ?...... If it's about my dad, then leave me alone."
[cpg cn=true]

That's right. She had already told me so once.
[cpg]

She knew her father when he was still a decent man. The memories make it too hard to cut him off, so she chose to suffer in silence.
[cpg]

[OnName num="keiichi"]
"Don't misunderstand the situation. I can get evidence of the abuse and report him without you."
[cpg cn=true]

I threaten to put an end to it all myself, but I think Hana understand that I just want to help.
[cpg]

All she has to do is ask and I'd take care of everything. I think she understands that, right?
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Hana055"]
[OnName num="hana"]
"If you do that, I'll never see you again."
[cpg cn=true]

[OnName num="keiichi"]
"Why?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Hana056"]
[OnName num="hana"]
"Because I would hate you."
[cpg cn=true]

How much of this was Hana's true feeling? I don't know anymore.
[cpg]

I am also frustrated with Hana for not giving me the answer I wanted. But I still have affection for her.
[cpg]

If I didn't head toward a certain way, there was no way for me or Hana to survive. Knowing that, I had no choice but to come up with an answer.
[cpg]

Perhaps I should come to a conclusion now, at this very moment.
[cpg]

I realized my own feelings, there's not a single reason to delay the process.
[cpg]


;//ＢＫ

[OnName num="keiichi"]
"......I'll take your dad's place, and I'll take care of you. That's not a problem right?"
[cpg cn=true]


I swung over to love. There was no longer any doubt in my mind.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Hana057"]
[OnName num="hana"]
"There is a problem. I haven't forgotten the man he used to be."
[cpg cn=true]

[OnName num="keiichi"]
"Then forget about it. Overwrite it with memories of me."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Hana058"]
[OnName num="hana"]
"......I can't do that."
[cpg cn=true]



;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_rl"]
[WAIT time=100]
;//【ＢＧ】『公園』（夜）******************************************************

[OnName num="keiichi"]
"......Look, Hana."
[cpg cn=true]

I'm standing there drinking a canned coffee I bought from the vending machine while Hana is sitting on the bench.
[cpg]

Hana looks up at me. I tell her.
[cpg]

[OnName num="keiichi"]
"I like you."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Hana059"]
[OnName num="hana"]
"Oh...... I'm......that......"
[cpg cn=true]

Hana seemed to know. But she also seemed confused.
[cpg]

And she doesn't look like she's at a loss for words. She seemed like she wanted to say something.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Hana060"]
[OnName num="hana"]
"I also think you are a good person."
[cpg cn=true]

A word that, depending on how you look at it, doesn't mean anything. It's a word used to dump someone, but I know that's not the case, given Hana's personality.
[cpg]

I am sure that Hana likes me. She can't say it directly, so she was choosing her words.
[cpg]

[OnName num="keiichi"]
"Please tell me. Do you like me? What would you do if I asked you to go out with me?"
[cpg cn=true]

She seemed torn. I'm sure it's not about whether she likes me or not but about her father.
[cpg]

She probably thinks that if she says she likes me here, she will be separated from her father.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Hana061"]
[OnName num="hana"]
"I like you......you're always so kind...and good."
[cpg cn=true]

Still, she responded. It felt like a gust of wind blowing through the void inside me.
[cpg]

It felt like the missing pieces were being filled. And I couldn't stop myself.
[cpg]

[OnName num="keiichi"]
"Good. Then don't complain about what I'm about to do."
[cpg cn=true]

[OnName num="keiichi"]
"Well, you can complain if you want to. I'm going to do what I want. It's my choice."
[cpg cn=true]

;//♪どうなの？目を見てくれない。立ち絵は目を見てる。
Hana didn't look me in the eye. That left an impression on me.
[cpg]


;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

I like Hana. Apparently, I had always liked her, and that was fine.
[cpg]

She also liked me for some reason. I had a hunch, but I didn't know why.
[cpg]

I have been kind to her just for fun, but I wonder if that means she received my love.
[cpg]

If so, we have no choice but to make each other happy. There was no hesitation in my actions from this point forward.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="burainndo1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="burainndo1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『住宅街』（夜）******************************************************

[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル
[WAIT time=1000]

And so, after parting with Hana, I called Kanako on the way home.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[VOICE f="Kanako153"]
[OnName num="kanako"]
"Yes, hi, it's Kanako."
[cpg cn=true]

I was in such a hurry that I felt a little annoyed when I heard her carefree voice.
[cpg]

I want to save Hana as soon as possible.
[cpg]

[OnName num="keiichi"]
"Kanako. I have a favor to ask you. It's about what we talked the other day."
[cpg cn=true]

Kanako's voice became a little more serious as she said, "okay, okay."
[cpg]


[VOICE f="Kanako154"]
[OnName num="kanako"]
"If you have a favor to ask, then that means you have made a decision, haven't you?"
[cpg cn=true]

[OnName num="keiichi"]
"Can I ask you to report her father to the police?"
[cpg cn=true]

I added that I would pay as much money as I could. Kanako was in need of money when we talked and that situation probably hasn't changed.
[cpg]

Either way, I had no choice but to ask Kanako for help. I felt that it would be a bad idea for me to report her, since we were too close.
[cpg]


[VOICE f="Kanako155"]
[OnName num="kanako"]
"I'm not going to do that for free, after all. There is a risk on my part."
[cpg cn=true]

Kanako explains that she would be in trouble if the father came after her.
[cpg]

I understand that feeling, and I thought the amount of money she suggested was reasonable. It was a lot of money for Kanako, but not something that I couldn't afford.
[cpg]

[OnName num="keiichi"]
"Okay, I'll give you whatever you want."
[cpg cn=true]

Kanako seemed a little surprised on the phone and seemed at a loss for words.
[cpg]

Maybe she didn't think I was that into Hana. It's nothing new, I thought
[cpg]


[VOICE f="Kanako156"]
[OnName num="kanako"]
"Weeell, I might have already set up the camera and gotten the footage you wanted..."
[cpg cn=true]

[OnName num="keiichi"]
"......So you already took it?"
[cpg cn=true]

"Yes", Kanako said. She was really quick.
[cpg]

I couldn't believe that she already had everything ready to sell it to me.
[cpg]

I don't know if she needs the money that badly...... or maybe not. Kanako must have another reason.
[cpg]

[OnName num="keiichi"]
"She must be an important friend to you, too."
[cpg cn=true]


[VOICE f="Kanako157"]
[OnName num="kanako"]
"Yes, of course. I think this is a good opportunity."
[cpg cn=true]

It sounded like she was about to get a little emotional, but maybe that was just my imagination.
[cpg]

I don't know everything about Kanako either. I'd rather help Hana right now.
[cpg]

[OnName num="keiichi"]
"Then, I'll leave it to you......"
[cpg cn=true]


"Of course," Kanako answered and I hung up the phone.
[cpg]


[SE f="se001"]
;//【ＳＥ】『ドア閉まる』

[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************


By the time I reached home, my hands were sweating so much that they were damp.
[cpg]

This changes everything. It may not be what Hana is looking for, but at least she will be released.
[cpg]

Things would not move so rapidly. It should be a few days before she can get out of there.
[cpg]

In the meantime, I was praying that Hana would persevere......
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

I had a bad dream that day. I dreamed that Hana was scared of me and asked her father for help.
[cpg]

[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hp"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************

[OnName num="keiichi"]
"......"
[cpg cn=true]


I wondered what it would be like for her to never be able to return.
[cpg]

She said she might hate me. But, I'm ready for that now.
[cpg]

I was determined. So this is the last time I'm going to have this dream.
[cpg]

I will make it the last time. I'll end this once and for all.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『空』（昼）******************************************************

I didn't know exactly what Hana's father's crime was.
[cpg]

I didn't hear about it from Hana, but from Kanako, so I decided not to ask too much about it.
[cpg]

Either way, Hana and her sister no longer had a father.
[cpg]

But that doesn't mean that their money issues would work themselves out. There was talk of both of them going to an orphanage......
[cpg]



[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（昼）******************************************************

[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

[OnName num="keiichi"]
"......It's not much, but you can think of it as your home from now on."
[cpg cn=true]

My room is too big for one person, but a little too small for three people to live together.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Hana062"]
[OnName num="hana"]
"Hi, thank you for the invitation."
[cpg cn=true]

[OnName num="hana_sister"]
"Hi......"
[cpg cn=true]

Hana came to my place. It's almost like an engagement now, but her heart is still broken.
[cpg]

The expression on her face is not a cheerful one.
[cpg]

This was the first time I saw Hana's younger sister. She was really just a young child.
[cpg]

She had to watch violence being inflicted on such a young child for a long time. It would be strange if she could recover fast.
[cpg]

[OnName num="hana_sister"]
"Hey, sis......"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Hana063"]
[OnName num="hana"]
"......What? You agreed to live here from today."
[cpg cn=true]

[OnName num="hana_sister"]
"Where did father go?"
[cpg cn=true]

She asked Hana with innocent eyes. Hana looked as if she had just collected all her sorrows and......
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Hana064"]
[OnName num="hana"]
"......"
[cpg cn=true]

She started to cry. Her sister was about to cry with her.
[cpg]

I don't know what to do. I hadn't lived a life that prepared me for situations like this.
[cpg]

[OnName num="keiichi"]
"It's okay now. You've all suffered enough."
[cpg cn=true]

[free time=300]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[WAIT time=1000]

I guess I was getting a little sentimental. I wasn't really sure what to do, but I took them both in my arms and held them.
[cpg]

I have no idea if this was the right thing to do.
[cpg]

If I had left them alone, maybe Hana's father would have changed.
[cpg]

It's hard to say that I didn't have any regrets about my choice, but......
[cpg]

I decided to take care of Hana. It was my decision, and I wasn't about to change my mind.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


The years did not pass in a flash.
[cpg]

There were many hardships. The hardest thing was explaining everything to Hana's sister.
[cpg]

Hana was heartbroken, and I didn't have any way of helping either of them get over it.
[cpg]

But little by little, both Hana and I were changing.
[cpg]

I could no longer remain an empty person. There was no way that I could care for someone that way.
[cpg]

And if I had to care for people, I had to change, even if I had to force myself to do so.
[cpg]

I think I became quite human. And Hana became more calm.
[cpg]

I could see just by looking at her that she was trying to become a strong person in a changing environment.
[cpg]

And in fact, I think she did become a strong person......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="burainndo1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="burainndo1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『空』（昼）******************************************************

By the time Hana's sister grew up and Hana and I officially became husband and wife, we moved.
[cpg]

It wasn't a house, but a larger apartment. There, the three of us lived together.
[cpg]

[OnName num="hana_sister"]
"I don't really want to see my sister and her husband living together......"
[cpg cn=true]

She would say, but she didn't want to leave her sister. She did not want to go to an orphanage.
[cpg]

Hana's sister grew up and began to understand the situation.
[cpg]

[OnName num="hana_sister"]
"Well, I don't want to go back to the way things used to be anymore, so yeah."
[cpg cn=true]


[VOICE f="Hana065"]
[OnName num="hana"]
"I'm sure......that's true. I'm sure you don't want that......"
[cpg cn=true]

Hana is all grown up. I, too, am getting older......
[cpg]

[OnName num="hana_sister"]
"I'm staying at a friend's house today. You two can flirt in peace."
[cpg cn=true]


[VOICE f="Hana066"]
[OnName num="hana"]
"What are you talking about?"
[cpg cn=true]

She was dismayed, but her dismay was not childish. On the contrary, she was becoming more like a housewife.
[cpg]

[OnName num="keiichi"]
"Well, it has been a little hard to flirt in front of your sister..."
[cpg cn=true]


[VOICE f="Hana067"]
[OnName num="hana"]
"Not you too!"
[cpg cn=true]

;//移植のためシーンをカットしています



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『空』（夜）******************************************************


[OnName num="keiichi"]
"......Do you still regret what happened with your father?"
[cpg cn=true]

We were in bed, snuggled up together. I asked her, staring at the ceiling.
[cpg]

There was quiet for a moment. Hana seemed to be thinking about how to reply.
[cpg]

[OnName num="keiichi"]
"Sorry, I shouldn't have asked that."
[cpg cn=true]

[OnName num="keiichi"]
"You don't have to answer......"
[cpg cn=true]

But still, I want to hear. I want to know the truth.
[cpg]

[OnName num="keiichi"]
"But let me ask you one more time. Are you okay with not having contact anymore?"
[cpg cn=true]


[VOICE f="Hana068"]
[OnName num="hana"]
"What kind of a question is that......?"
[cpg cn=true]


[VOICE f="Hana069"]
[OnName num="hana"]
"You are the own who brought us here. I don't think that's the right way to ask."
[cpg cn=true]

[OnName num="keiichi"]
"......You might be right. I'm sorry."
[cpg cn=true]

[VOICE f="Hana070"]
[OnName num="hana"]
"But I think it's for the best."
[cpg cn=true]

[OnName num="keiichi"]
"Really? Are you sure?"
[cpg cn=true]

Hana's eyes were a little misty. She still thinks about her father sometimes.
[cpg]

She thinks about the time he was nicer......Apparently, he was just like me.
[cpg]

It's a complicated story, and I have complicated feelings about it. That is why I get worried sometimes.
[cpg]

[OnName num="keiichi"]
"Why do you think that this is for the best?"
[cpg cn=true]


[VOICE f="Hana071"]
[OnName num="hana"]
"Because......your eyes have become more lively."
[cpg cn=true]

[OnName num="keiichi"]
"What do you mean?"
[cpg cn=true]


[VOICE f="Hana072"]
[OnName num="hana"]
"When I first met you, your eyes were dead. Were you not aware of it?"
[cpg cn=true]

......So that's what she was talking about. I was losing my will to live at the time, so it's no surprise.
[cpg]

But it's the same for her as well. Her eyes are more alive......
[cpg]

[OnName num="keiichi"]
"I see. That may be so."
[cpg cn=true]

;//目が生き生きしてるよ、とは言わずにいたら、花が再び俺に重なってきた。
As I kept quiet after that, Hana held my hand tightly.
[cpg]

[OnName num="keiichi"]
;//「……どんだけ体力あるんだ」
"......You are warm. Are you nervous?"
[cpg cn=true]

;//[VOICE f="-Hana073"]
;//[OnName num="hana"]
;//「貴方だって、体力あるほうでしょ？　朝まで、しましょうよ」
;//[cpg cn=true]

[VOICE f="Hana073"]
[OnName num="hana"]
"I think you are the one that's nervous."
[cpg cn=true]

;//ほら、生き生きしてるだろ、言葉遣いも、言葉そのものも、声も。
She's so energetic. From the tenderness of her hand to the embarrassed look on her face and that loving gaze.
[cpg]

[OnName num="keiichi"]
;//「分かったよ。じゃあ、付き合ってやる」
"You've really opened up. I guess I'll have to stick around."
[cpg cn=true]

I'll stay with you until the very end. Until we have children, until they grow up, and until we grow old.
[cpg]

I'm going to keep you company. I made up my mind.
[cpg]

[SCENE id=10]

[jump storage="epend.ks" target="*start"]


;//【花ルート】ハッピーエンド

;//==============================
;////////////////////////////////////////////////////////////////////////
