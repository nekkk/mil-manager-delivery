
*start|The Mysterious Mari

;#################################################
*Ep003|The Mysterious Mari
;#################################################

[SCENE id=3]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;//[SE f="se014"]
;//【ＳＥ】『スイッチ音』カチッ

[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_rl"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************


I get home and turn on the lights.
[cpg]

I live alone, so I often cook for myself, but I never bothered making anything that takes effort or time.
[cpg]

It's not like I care about the taste, so it's not unusual for me to only have a bowl of rice and some miso soup.
[cpg]

Sometimes I add pickled vegetables or fermented soybeans......It was difficult to call it a meal, and my colleagues would probably laugh if they found out.
[cpg]

I think that actually happened once. They laughed at me, saying it was an old man's meal.
[cpg]

I never really thought about it much before then. I guess I was missing something that other people took for granted.
[cpg]

[OnName num="keiichi"]
"......"
[cpg cn=true]


;//[SE f="se001"]
;//【ＳＥ】『食器音』カチャカチャ

But even still, I eat three meals a day.
[cpg]

Maybe some part of me wanted to live. It's not like I had a death wish, but I also didn't have any good reasons to stay alive.
[cpg]

;//ＢＫ

I'm in an introspective mood as I wash the dishes and put them away.
[cpg]


[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン
[WAIT time=3000]

;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_03_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=1000]
;//
;//【ＢＧ】『恵一の部屋』（夜）******************************************************

;//[lbox on]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]


[VOICE f="Mari012"]
[OnName num="mari"]
"Hello? Keiichi?"
[cpg cn=true]

[OnName num="keiichi"]
"......"
[cpg cn=true]

The voice sounded slightly familiar. Maybe it was the sound quality of the phone call, but I couldn't remember who it was.
[cpg]

[OnName num="keiichi"]
"Who is this?"
[cpg cn=true]


[VOICE f="Mari013"]
[OnName num="mari"]
"It's me, Mari."
[cpg cn=true]

[OnName num="keiichi"]
"......Oh."
[cpg cn=true]

It took a moment for me to realize something was wrong.
[cpg]

I didn't recognize the number, or rather I never registered Mari's number on my cell phone.
[cpg]

That meant I'd never given her my number, either. We didn't really know each other that well.
[cpg]

[OnName num="keiichi"]
"Did someone tell you my number or did I give it to you?"
[cpg cn=true]


[VOICE f="Mari014"]
[OnName num="mari"]
"I'm in front of your house right now. Let me in, I need a place to stay tonight."
[cpg cn=true]

[OnName num="keiichi"]
"What?"
[cpg cn=true]

A chill ran down my spine. She knows where I live? I don't remember telling her my phone number either...
[cpg]

[OnName num="keiichi"]
"How could you possibly know where I live?"
[cpg cn=true]

[OnName num="keiichi"]
"You're in front of my house, right? Then knock on my door."
[cpg cn=true]


[VOICE f="Mari015"]
[OnName num="mari"]
"Okay."
[cpg cn=true]

And after a few moments......
[cpg]


[SE f="se037"]
;//【ＳＥ】『ドアをノックする音』コンコン

[WAIT time=2000]


[OnName num="keiichi"]
"No way."
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

[SE f="se023"]
;//【ＳＥ】『ドア開ける』


[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=800]

It was like a scene from a horror film. I hesitantly went to the front door and opened it to find Mari standing there in her school uniform.
[cpg]

[OnName num="keiichi"]
"Are you stalking me......?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Mari016"]
[OnName num="mari"]
"Something like that. Just remember that there's no getting away from me."
[cpg cn=true]

[OnName num="keiichi"]
"Wait, hold on!"
[cpg cn=true]


[window target=false]
[free time=1000]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

;//[SE f="se001"]
;//【ＳＥ】『歩く』

Mari barges into my room and looks around.
[cpg]

[OnName num="keiichi"]
"This is trespassing."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mari017"]
[OnName num="mari"]
"Unlawful lodging too, probably. I'm staying the night."
[cpg cn=true]

[OnName num="keiichi"]
"I'm going to call the police."
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Mari018"]
[OnName num="mari"]
"Then I'm going to scream."
[cpg cn=true]

There was no reasoning with her. I could probably call the police if I wanted, there was no evidence that I'd done anything wrong.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]

[FG f="CHA04_p4_01_a.ui" method="change_3"  pos="2/3" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

......But it was difficult for me to put my foot down around her.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Mari019"]
[OnName num="mari"]
"......It's cramped."
[cpg cn=true]

Mari and I were snuggled up against each other on my bed.
[cpg]

[OnName num="keiichi"]
"If you want more space, there's plenty on the floor."
[cpg cn=true]

I wasn't interested in sleeping on the floor either. If she wanted to sleep next to me, I wasn't about to refuse her.
[cpg]

There's something comforting about sleeping next to someone.
[cpg]

I've never really felt lonely before, but I could tell that some part of me craved this sensation.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Mari020"]
[OnName num="mari"]
"You smell good."
[cpg cn=true]

[OnName num="keiichi"]
"Sounds like a line out of a romantic movie."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mari021"]
[OnName num="mari"]
"Maybe that's not far from the truth."
[cpg cn=true]

[OnName num="keiichi"]
"......"
[cpg cn=true]

[OnName num="keiichi"]
"......Why is this happening to me?"
[cpg cn=true]

[OnName num="keiichi"]
"All of a sudden I've got 4 weird girls in my life."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Mari022"]
[OnName num="mari"]
"......So I have three rivals?"
[cpg cn=true]

We were both lying there, looking up at the ceiling.
[cpg]

I turned my head to catch a glimpse of her expression from the side. Maybe I was imagining it, but she almost looked like a normal girl in love.
[cpg]

Did she mean rivals in love? No, I'm overthinking things.
[cpg]

[OnName num="keiichi"]
"Why'd you decide to stay over tonight? Did you get kicked out or something?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Mari023"]
[OnName num="mari"]
"No."
[cpg cn=true]

[OnName num="keiichi"]
"......Okay."
[cpg cn=true]

I could ask her questions all night long, but I doubted I'd get a clear answer out of her.
[cpg]

The night seemed to drag on until we fell asleep and, suddenly, it was morning.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************


[FACE method="shake_1" pos="2/3"]
[VOICE f="Mari024"]
[OnName num="mari"]
"Wake up."
[cpg cn=true]

[OnName num="keiichi"]
"Mmh......what?"
[cpg cn=true]

Mari shook me awake about two hours earlier than I'd usually get up.
[cpg]

[OnName num="keiichi"]
"What are you up to and why does it involve waking me up this early?"
[cpg cn=true]

[free time=300]
[FG f="CHA04_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mari025"]
[OnName num="mari"]
"I'm going home. I want you to see me off."
[cpg cn=true]

[OnName num="keiichi"]
"Did you wake me up just for that?"
[cpg cn=true]

She nodded without any hesitation. I couldn't tell from her blank expression whether she was serious or not.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mari026"]
[OnName num="mari"]
"Call me later."
[cpg cn=true]

[OnName num="keiichi"]
"I don't have your phone number."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Mari027"]
[OnName num="mari"]
"......Then I'll write it in here."
[cpg cn=true]

[OnName num="keiichi"]
"Hey-"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]

She grabs a notepad and a pen and scribbles her contact information on a page.
[cpg]

[SE f="se023"]
;//【ＳＥ】『ドア開ける』


[free time=1000]
[WAIT time=1000]

Without changing her expression, she waves goodbye and leaves my apartment, still wearing yesterday's school uniform.
[cpg]

[OnName num="keiichi"]
"I don't know what it is, but I think I've been dragged into something."
[cpg cn=true]

It was still early, so I locked the door and went back to sleep.
[cpg]

......What should I do with her number? I could throw it away, but it was still in my phone....
[cpg]

I could just register that number as hers......after all, it would be better to know who was calling me.
[cpg]

I add her as a contact and went back to sleep.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（朝）******************************************************

When I woke up again, something else started bothering me again.
[cpg]

I can understand how she found out where I lived. She must have seen me somewhere and followed me home.
[cpg]

I've seen her around before, so it stands to reason that the opposite was true.
[cpg]

The real question was how she found my number. She'd have to ask me directly or get it from somebody I know.
[cpg]

I can't imagine that she could have stolen my phone. I'm not that careless.
[cpg]

And I didn't give her my number. That means it had to have been a mutual acquaintance......
[cpg]

[OnName num="keiichi"]
"Oh."
[cpg cn=true]

Only one person came to mind.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

[SE f="se027"]
;//【ＳＥ】『喧騒』

I'd have to ask her about it later. I'd overslept and was about to be late for work.
[cpg]

[OnName num="keiichi"]
"Ugh, I'm still sleepy......"
[cpg cn=true]

It's been a while since I've felt sleepy like this. My routine generally had me getting enough sleep.
[cpg]

Mari and her ilk were like natural disasters. There was no predicting how they'd disrupt my life.
[cpg]



[stopse g=2]
;//通常se
[stopse g=3]
;//通常se



[jump storage="ep004.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
