;//４、茉莉
*start|Mari Doesn't Smile

;#################################################
*Ep008|Mari Doesn't Smile
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************


*root_mari|Mari Doesn't Smile

[SCENE id=8]

[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル

I think I was a little crazy.
[cpg]

Because out of the four girls, I had called the person I thought was the most unexceptable.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[VOICE f="Mari039"]
[OnName num="mari"]
"Keiichi......?"
[cpg cn=true]

As usual, Mari answered the phone in a voice that seemed either blunt or somewhat mysterious.
[cpg]

I almost regretted calling her.
[cpg]

She was the most suspicious. In a way, she is more dangerous than Kanako and more resilient than Hana.
[cpg]

[OnName num="keiichi"]
"Oh, you know, I just needed a little......distraction."
[cpg cn=true]

Mari doesn't laugh much. When I say these things, she doesn't laugh it off, but takes it seriously.
[cpg]


[VOICE f="Mari040"]
[OnName num="mari"]
"Are you ready to buy me?"
[cpg cn=true]

[OnName num="keiichi"]
"Really, it's just a whim, you know. I just thought I'd hear your voice."
[cpg cn=true]

I feel ashamed of myself for being indirect but I had to.
[cpg]

Because it's embarrassing. It's like saying I fell in love with someone who suddenly barged into my house.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

[SE f="se027"]
;//【ＳＥ】『喧騒』

The following day was a work day.
[cpg]

Somehow, somehow, I was worried that Mari might be following me.
[cpg]

She is kind of scary. She's a little beyond mysterious.
[cpg]

Even the other day, she came over to my house......and I wouldn't be surprised if she's following me for some reason at this very moment.
[cpg]

In that sense, she might be stimulating but I'm not looking for any stimulation.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_rl"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="Mari041"]
[OnName num="mari"]
"Good evening, Keiichi. Long time no see."
[cpg cn=true]

[OnName num="keiichi"]
"Oh, uh......long time no see?"
[cpg cn=true]

It hadn't been that long. Didn't I see her yesterday? Or was it the day before yesterday?
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Mari042"]
[OnName num="mari"]
"A day has passed, and it felt like forever."
[cpg cn=true]

"That's how much I want to see you, Keiichi.", Mari continued......
[cpg]

She's got a troublesome personality. I wonder why I'm liked by these kinds of people......
[cpg]

[OnName num="keiichi"]
;//「無駄話はやめだ。ホテル行くぞ、今日の目的はそれだろ」
"This isn't the place to talk, someone might see us. Follow me."
[cpg cn=true]

Mari nodded. And then, she follows me. The distance between us was awkward......
[cpg]

It was scary how she kept keeping the same distance from me as if she was used to stalking me on a regular basis.
[cpg]



;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]



She has no hesitation in getting close to me.
[cpg]


;//●ＣＧ（茉莉・キスをするヒロイン：街）ev_56
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_56_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

She could kiss me without even lifting an eyebrow.
[cpg]

Did she think a guy would be happy with that......?
[cpg]

I thought so, but there was also a part of me that was happy.
[cpg]

[VOICE f="Mari043"]
[OnName num="mari"]
"......"
[cpg cn=true]


It was as I had expected.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_rl"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************

And here's the story of what happened right after I bought her something in return.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mari044"]
[OnName num="mari"]
"I'm leaving now."
[cpg cn=true]

[OnName num="keiichi"]
"......What do you mean? What kind of an attitude is that especially toward a man?"
[cpg cn=true]

I thought so and grabbed her hand, but Mari was staring at my hand, wanting me to let go.
[cpg]

[OnName num="keiichi"]
"You're not in a hurry are you?"
[cpg cn=true]

But when I asked her about that, she had a good reason.
[cpg]

It wasn't an urgent matter, but she had to go home.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Mari045"]
[OnName num="mari"]
"I have school tomorrow, and I'm busy with my studies."
[cpg cn=true]

[OnName num="keiichi"]
"......huh."
[cpg cn=true]

I wouldn't be surprised if Mari told me that she is an honor student.
[cpg]

On the other hand, I probably wouldn't be surprised if she told me that she was a bad student or an average student either...
[cpg]

I was not that surprised, but I was curious about the reason.
[cpg]

The reason why she was an honor student.
[cpg]

[OnName num="keiichi"]
"You're an honor student?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Mari046"]
[OnName num="mari"]
"Of course I am."
[cpg cn=true]

[OnName num="keiichi"]
"Why? I want to know why you study so hard."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

Mari's expression was one of confusion. Does she not understand what I'm saying?
[cpg]

[OnName num="keiichi"]
"If you had time to study, you'd be seducing men, wouldn't you?"
[cpg cn=true]

[OnName num="keiichi"]
"If you like money, it's more efficient."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Mari047"]
[OnName num="mari"]
"That's not good. If I like money, I need to go to a good school and get good grades."
[cpg cn=true]

...... That may indeed be a good argument. But still, she was really into money.
[cpg]

[OnName num="keiichi"]
"Then why don't you concentrate on your studies?"
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
She shakes her head again.
[cpg]

In Mari's mind, she wants to earn money now while also setting herself up to earn more in the future.
[cpg]

She seems to be frustrated by the time she has to spend as a student because she can't make money, even though she has perfectly laid the groundwork for her future.
[cpg]

[OnName num="keiichi"]
"All right, you're studying, right? Then you should go home. I'll see you out."
[cpg cn=true]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hp"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************

[OnName num="keiichi"]
"......"
[cpg cn=true]

That night, I was strangely unable to sleep.
[cpg]

For no reason at all, I fiddled with my cell phone. My fingers moved on their own, searching for information about the uniform Mari was wearing.
[cpg]

I looked up a few characteristics and places she frequently went, and found a school that seemed to be the one.
[cpg]

[OnName num="keiichi"]
"Are you kidding me......?"
[cpg cn=true]

It was a very prestigious school.
[cpg]

I wouldn't call it a household name, but it was quite famous if you had connections in certain circles.
[cpg]

She was either a genius or she studied harder than anybody I ever knew.
[cpg]

[OnName num="keiichi"]
"Phew!"
[cpg cn=true]

I put away my cell phone and stopped looking further into the matter.
[cpg]

I feel like I'm becoming more obsessed with Mari's charm.
[cpg]

Nothing about her was ordinary. She was the complete opposite of me.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（朝）******************************************************

I felt that morning came earlier than usual. The reason was that I went to bed late.
[cpg]

So much for getting an early start in the morning.
[cpg]

[OnName num="keiichi"]
"Huh......"
[cpg cn=true]

I yawn. I can't be seen at work like this.
[cpg]

I was an empty shell of a person until yesterday. I'm supposed to be leading a healthy, balanced lifestyle.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『住宅街』（夜）******************************************************

[OnName num="keiichi"]
"Ah."
[cpg cn=true]

[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mari048"]
[OnName num="mari"]
"Good evening."
[cpg cn=true]

I was on my way home. Maybe she was waiting for me or something, but I bumped into Mari.
[cpg]

[OnName num="keiichi"]
"Have you been stalking me again?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
She nodded. No, don't nod. I'm pretty sure that's a crime.
[cpg]

[OnName num="keiichi"]
"How did you find out where I work?"
[cpg cn=true]

I ask, but then I realize that I had also been doing research on her.
[cpg]

We were both invading each other's privacy. But I think she was the one who invaded my privacy first.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Mari049"]
[OnName num="mari"]
"You work for a big company?"
[cpg cn=true]

[OnName num="keiichi"]
"I guess I do."
[cpg cn=true]

Saying this kind of thing usually brings out some sort of animosity, but Mari did not show any such behavior.
[cpg]

For Mari, it was like attending a prestigious school before she knew about it.
[cpg]

Mari and I are different in that we both have a purpose......
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Mari050"]
[OnName num="mari"]
"So, you have a bunch of extra money?"
[cpg cn=true]

[OnName num="keiichi"]
"Don't be so indirect. I'll go out with you if you say you want to see me."
[cpg cn=true]

Mari pretends as if she just noticed.
[cpg]

I'm pretty sure she's been talking to me and stalking me with that intention.
[cpg]

......hmm, wait?
[cpg]

[OnName num="keiichi"]
"Don't you have school?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mari051"]
[OnName num="mari"]
"I pretended I was sick and left."
[cpg cn=true]

Was she really an honor student?
[cpg]



;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

Then I noticed her acting weird.
[cpg]

I thought it was weird because she had her phone with her the whole time. Apparently, she was filming our date and conversation.
[cpg]

And she doesn't think I'll notice it......
[cpg]

I don't know how much I can trust her. Maybe I shouldn't trust her at all.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=2000]

[SE f="se001"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************


No matter what I think while I walk, I get back home as usual.
[cpg]

Then it's useless to think about it. Suppose, after some thought, I decide that it's better not to approach Mari any further.
[cpg]

Would I be able to do it? I don't think I can.
[cpg]

It would be a lie to say that I have no attachment to Mari.
[cpg]

After all, I can't stay away from Mari. Then, I don't need to think about anything else.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************

The days repeat themselves. I understood my situation a little better now, so it was easier to get to sleep.
[cpg]

I've only had a few good mornings in my life, and I think today was one of them.
[cpg]

Since I met Mari, I have been stimulated in many ways. I feel like I have to think about this, or it's useless to think about that, and so on.
[cpg]

At least, I think that's a good thing for me.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社内』（昼）******************************************************

As proof, work is going even better than before. I can tell that the days I used to spend aimlessly are changing.
[cpg]

Time doesn't just pass me by anymore. There's at least a clear distinction between the time when I am not with Mari and the time when I am with her.
[cpg]

I can even allow myself to imagine if she'll be waiting for me on my way home today.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_rl"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夜）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="keiichi"]
"...... Oops."
[cpg cn=true]

My thoughts are interrupted by an unexpected guest. Mari wasn't there, but someone else was.
[cpg]

[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ayaka130"]
[OnName num="ayaka"]
"Oh......Keiichi? Long time no see."
[cpg cn=true]

It's been a really long time since I've seen her. I hadn't particularly contacted her, but we ran into each other by chance.
[cpg]

Since it was a coincidence when we originally met, there was a chance that we would meet, but I guess it was a pretty low chance.
[cpg]

[OnName num="keiichi"]
"It's been a long time. How are you?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayaka131"]
[OnName num="ayaka"]
"Yeah......well, I'm good."
[cpg cn=true]

[OnName num="keiichi"]
"I don't want to stand around talking, so let's go sit somewhere."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
I invited her and Ayaka accepted. She nodded and followed me.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p4_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************

[OnName num="keiichi"]
"How's it going on your end? Is it the same as ever?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayaka132"]
[OnName num="ayaka"]
"Yeah, I guess so."
[cpg cn=true]

The conversation was nothing more than a trivial one. I'm not here for this kind of talk, and neither is Ayaka.
[cpg]

I want to ask Ayaka something. I'm sure Ayaka has something she wants to ask me, too.
[cpg]

[OnName num="keiichi"]
"Hey Ayaka. Do you know anything about Mari?"
[cpg cn=true]

I asked her, thinking that it couldn't be helped if she didn't know.
[cpg]

The reason is that Ayaka and Mari do not have any direct contact. But Ayaka knew.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Ayaka133"]
[OnName num="ayaka"]
"......I guess. I heard about you two."
[cpg cn=true]

[OnName num="keiichi"]
"What do you mean?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayaka134"]
[OnName num="ayaka"]
"You've been seeing her a lot lately."
[cpg cn=true]

What was that? I don't know how she heard about it, but it seems that Ayaka knows about it too.
[cpg]

[OnName num="keiichi"]
"I don't deny it."
[cpg cn=true]

I was impressed that Ayaka looked a little worried.
[cpg]

[OnName num="keiichi"]
"Don't tell me you're worried about me."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayaka135"]
[OnName num="ayaka"]
"I'm a bit of an acquaintance of......Mari's."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Ayaka136"]
[OnName num="ayaka"]
"I haven't heard anything good about her. I don't think you should do it."
[cpg cn=true]

[OnName num="keiichi"]
"Do it as in not see her?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
She nodded. What can I say, she seemed quite determined......
[cpg]

I don't think even Ayaka would want to monopolize me.
[cpg]

I guess she was genuinely concerned rather than she was jealous, but I wasn't sure how to respond.
[cpg]

[OnName num="keiichi"]
"You say that but...... it's not like I don't care about her."
[cpg cn=true]

I found the words surprising even to myself, but this was no mistake.
[cpg]

I can't take the time to build a relationship of trust with another person from scratch.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayaka137"]
[OnName num="ayaka"]
"Then at least be careful......"
[cpg cn=true]

Although she didn't say what to be careful about, I understood what she was trying to say.
[cpg]

[OnName num="keiichi"]
"But why do you care so much about me?"
[cpg cn=true]

[free time=300]
[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
"Well," she said, getting up from the bench.
[cpg]

[OnName num="keiichi"]
"I'm a little worried about you, too.", I say.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Ayaka138"]
[OnName num="ayaka"]
"Don't worry about me. I'll see you around."
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『住宅街』（夜）******************************************************


......That was interesting. So there was a connection between Mari and Ayaka.
[cpg]

It's a bit of an unexpected combination. It was easier to imagine Mari and Kanako together.
[cpg]

I can't imagine what kind of conversation those two would have.
[cpg]

And what I couldn't imagine, I had to make up for with reality.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1000]

[BGM f="bg_sl"]
[WAIT time=2000]

[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夕方）******************************************************


It was evening on a weekend. A phone call came in, and it was Mari on the other end.
[cpg]


[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[VOICE f="Mari052"]
[OnName num="mari"]
"Good evening, Keiichi."
[cpg cn=true]

[OnName num="keiichi"]
"Mari? What do you want at this hour?"
[cpg cn=true]

Mari's suggestion was straightforward;
[cpg]

[VOICE f="Mari053"]
[OnName num="mari"]
"Aren't you interested in a date with two girls?"
[cpg cn=true]

[OnName num="keiichi"]
"That's sudden. Well, I'm cant say that I'm not interested."
[cpg cn=true]

That's all I could answer.
[cpg]

Yet Mari rushes to conclusions and tries to set a date.
[cpg]

[OnName num="keiichi"]
"Wait a minute. I don't know the other girl."
[cpg cn=true]

I said I didn't know, but at the same time I was thinking that maybe I did know......but I refused just in case.
[cpg]

[VOICE f="Mari054"]
[OnName num="mari"]
"It's a girl named Ayaka. Do you know her?"
[cpg cn=true]

Of course, I know her. I didn't tell her that I met her just the other day......
[cpg]

[OnName num="keiichi"]
"I know her. You two operate in the same circles, right?"
[cpg cn=true]

On the other end of the phone, Mari seemed a little surprised.
[cpg]

I guess she thought I didn't know. Well, it doesn't matter.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se027"]
;//【ＳＥ】『喧騒』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************


The meeting with the three people I knew went smoothly.
[cpg]

[FACE method="bow_1" pos="4/5"]
[VOICE f="Ayaka139"]
[OnName num="ayaka"]
"Long time no see-ish, Keiichi."
[cpg cn=true]

[OnName num="keiichi"]
"You're right. It hasn't been a long time at all."
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
Mari was looking at us curiously. So I decided to explain to her just in case.
[cpg]

[OnName num="keiichi"]
"Ayaka and I know each other."
[cpg cn=true]

;//こいつを抱いてやったこともある、とちょっと誇張気味に言った。
"I used to see her a lot.", I said with a bit of exaggeration.
[cpg]

[FACE method="bow_1" pos="2/5"]
Mari seemed to understand and clapped her hands.
[cpg]

[FACE method="change_3" pos="2/5"]
[VOICE f="Mari055"]
[OnName num="mari"]
"I thought your call yesterday was strange."
[cpg cn=true]

[OnName num="keiichi"]
"I see. I guess."
[cpg cn=true]

;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

During our date that day, she seemed to be recording the conversation again.
[cpg]

I choose my words carefully as I talk. Who knows what she recorded me saying before I noticed.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（夜）******************************************************

From there, another few days and nights passed.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=3000]

[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（昼）******************************************************

And then, during the daytime on my day off. I was sitting at home, doing nothing in particular, when I heard a voice say,
[cpg]


[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[VOICE f="Mari056"]
[OnName num="mari"]
"Hello, Keiichi?"
[cpg cn=true]

[OnName num="keiichi"]
"Yes, it's me."
[cpg cn=true]

[VOICE f="Mari057"]
[OnName num="mari"]
"If you like, can we meet this evening?"
[cpg cn=true]

[OnName num="keiichi"]
"You must be the kind of person who never gets bored. Or are you just looking for something in return?"
[cpg cn=true]

"Yes," she replied. Well, in that case then......
[cpg]

[OnName num="keiichi"]
"Do you want to come over to my place?"
[cpg cn=true]


I asked, and she didn't refuse.
[cpg]

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

[FACE method="bow_6" pos="2/3"]
[VOICE f="Mari058"]
[OnName num="mari"]
"It smells like you."
[cpg cn=true]

That was the first thing she said when she came up to my room.
[cpg]

[OnName num="keiichi"]
"Don't say something so basic......"
[cpg cn=true]

I say so but I don't feel bad about it. She seemed to know what made me happy.
[cpg]


;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then Mari said she was going to stay the night.
[cpg]

I didn't intend to do anything, but there was no reason for me to refuse......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hp"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************

[OnName num="keiichi"]
"......"
[cpg cn=true]

It seems that Mari had woken up first. When I woke up, she was nowhere to be found.
[cpg]

I felt a little uneasy. I didn't know what Mari would do.
[cpg]

[OnName num="keiichi"]
"Did I do something wrong?"
[cpg cn=true]

;//[SE f="se001"]
;//【ＳＥ】『鞄漁る』ガサゴソ

I checked my wallet and my checkbook, but they were safe.
[cpg]

That makes sense. If I they were gone, the culprit would obvious.
[cpg]

......No, wait. If I were to explain the situation to the police, wouldn't I be the one in trouble?......
[cpg]

It would probably be the perfect opportunity from Mari's point of view.
[cpg]

[OnName num="keiichi"]
"That was a close call......I'm glad Mari is not bright."
[cpg cn=true]

Mari is not dumb. I know that. She is a student at a prestigious school.
[cpg]

So today felt unnatural. I had a bad feeling.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

No matter what kind of bad feeling I had, I had to go to work in the morning, and I couldn't neglect that, but......
[cpg]

What is this feeling of unease? A girl who is so greedy for money has missed a great opportunity to get it.
[cpg]

That can only mean she has a different plan to squeeze even more money out of me.
[cpg]

It was weird, and my steps were heavy as I headed to the office. And yet, I felt like I was floating and couldn't feel a thing.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]

The days passed but I was unable to shake that feeling of unease.
[cpg]

Surprisingly, it didn't take long for me to get used to it.
[cpg]



[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************


Then, Mari called me.
[cpg]


[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[OnName num="keiichi"]
"Mari, what do you want?"
[cpg cn=true]


[VOICE f="Mari059"]
[OnName num="mari"]
"I just want to talk to you."
[cpg cn=true]

Her tone was the same as usual. But what she was saying was a little different than usual.
[cpg]

[OnName num="keiichi"]
"You want to talk to me? Not see me?"
[cpg cn=true]

Mari replied, "Yes". It was a little hard to imagine what was to come.
[cpg]

The bad feeling comes back to me. Feeling somewhat uncomfortable, I stayed on the line.
[cpg]

[OnName num="keiichi"]
"What then? You say we're going to make small talk?"
[cpg cn=true]


[VOICE f="Mari060"]
[OnName num="mari"]
"It's not small talk."
[cpg cn=true]

The voice of Mari was lower in tone than usual and had a sense of strength to it.
[cpg]

It sounded like a prelude to a serious confession, and combined with her usual emotionless nature, her voice had a strangely cold tone.
[cpg]


[VOICE f="Mari061"]
[OnName num="mari"]
"I'm in front of your house right now."
[cpg cn=true]

She said something outrageous. Wasn't there an urban legend or something about this sort of a situation......
[cpg]


[SE f="se038"]
;//【ＳＥ】『ドアをノック』コンコン

[WAIT time=1000]

The was a knock on the door, twice. I guess she was here.
[cpg]

I don't have any doubts, so why did she have to knock.
[cpg]

I headed for the front door, thinking, "Well, she has done something like this before......"
[cpg]

[OnName num="keiichi"]
"Yea, sure. Hold on, I'll let you right inside."
[cpg cn=true]

[free time=1000]
[WAIT time=2000]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

In front of the front door, Mari was there looking the same as usual.
[cpg]

But I still remember that the words out of her mouth and the tone of her voice were colder than usual.
[cpg]

And Mari was carrying some luggage. It was a large bag.
[cpg]

[OnName num="keiichi"]
"......What's with the bag?"
[cpg cn=true]


Before she answered the question, Mari came inside. I followed her.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Mari062"]
[OnName num="mari"]
"It's because you don't have anything in your house."
[cpg cn=true]

She took out a laptop and a case with DVDs from the bag.
[cpg]

I didn't really understand what she was trying to say, but it didn't take long for me to realize what she meant.
[cpg]

In other words, "There is no DVD player in this room."
[cpg]

[OnName num="keiichi"]
"What's this about...?"
[cpg cn=true]

As I listened, I had a vague idea. It was the thing from before right?
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Mari063"]
[OnName num="mari"]
"I want you to take a look at it."
[cpg cn=true]



[FADEOUTBGM]

;//ＢＫ
;//[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


My eyes were drawn to the screen. It was a video file.
[cpg]

The content was Mari and I on one of our dates.
[cpg]

She shows me the part where I bought her something in exchange for the date......
[cpg]

[FO pos="4/7" time=1000]
[WAIT time=1000]

;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_03_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]

[BGM f="bg_hp"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************

[OnName num="keiichi"]
"......What's this all about?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Mari064"]
[OnName num="mari"]
"This is just a copy. I have the data at my house as well."
[cpg cn=true]

Well yeah, it was her camera...
[cpg]

[OnName num="keiichi"]
"Yeah, but I mean what's the point of showing me all this?"
[cpg cn=true]

[OnName num="keiichi"]
"You took the video, of course you've got the data. So what?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mari065"]
[OnName num="mari"]
"I'm taking this to your office."
[cpg cn=true]

[OnName num="keiichi"]
"......What?"
[cpg cn=true]

For a moment, I lost my voice. The words were barely audible, but just barely.
[cpg]

The muffled voice sounded weak, even for me. But all the pieces of my discomfort fell into place.
[cpg]

[OnName num="keiichi"]
"You're painting me as the bad guy......?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
Mari nods. Wait, that's absurd. It was Mari who invited me in the first place!
[cpg]

[OnName num="keiichi"]
"Don't be crazy. Anyone who knows the whole story would say I'm the victim here."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Mari066"]
[OnName num="mari"]
"I edited it to make you look bad."
[cpg cn=true]

[OnName num="keiichi"]
"......"
[cpg cn=true]

I am beaten, I thought. I was a fool for not noticing it, but it was too late to regret it.
[cpg]

[OnName num="keiichi"]
"Is that why you brought Ayaka, too?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Mari067"]
[OnName num="mari"]
"Yes. I think two people would make it more convincing than one."
[cpg cn=true]

She was a gold digger. That's the only way I can describe it.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Mari068"]
[OnName num="mari"]
"If you act quickly, you can buy this copy before I bring it to your boss. What do you think?"
[cpg cn=true]


I had no more way out of this......
[cpg]

[OnName num="keiichi"]
"......Okay, I'll pay for it."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Mari069"]
[OnName num="mari"]
"I'm glad you're so understanding."
[cpg cn=true]


;//移植のためシーンをカットしています

;//●ＣＧ（茉莉・主人公に近づいて、見下すヒロイン：恵一の部屋）ev_66
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_66_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

She said so as she came close to me.
[cpg]

I flinched at this unexpected turn of events.
[cpg]

[VOICE f="Mari070"]
[OnName num="mari"]
"This is a reward. I want you to be mine."
[cpg cn=true]


After saying this, she put her lips to mine.
[cpg]

It was a ridiculous situation.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hp"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（昼）******************************************************

From that point on, I began to receive phone calls from Mari.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[VOICE f="Mari071"]
[OnName num="mari"]
"How are you these days? How's work going?"
[cpg cn=true]

[OnName num="keiichi"]
"...... I don't think you'd understand if I told you."
[cpg cn=true]

For some reason, more and more of these small talk calls came in.
[cpg]

Why are we talking about this, and why does she approach me with these topics?
[cpg]

If there was a master-slave relationship between me and Mari, she wouldn't have to do this.
[cpg]

And if she had wanted to have this kind of small talk, or rather, a casual conversation, it would have been fine if she had done so in the past.
[cpg]

Here's what I think. I think that even if she had wanted to call me before, she would not have been able to do so out of boundaries.
[cpg]

Now, she knows my weak spot, and she can call without hesitation. It seemed to make sense.
[cpg]


[VOICE f="Mari072"]
[OnName num="mari"]
"Things are really hard here. With studying."
[cpg cn=true]

[OnName num="keiichi"]
"Do you have that much studying to do?"
[cpg cn=true]


[VOICE f="Mari073"]
[OnName num="mari"]
"No, it's just that the people around me are not serious and I don't like it."
[cpg cn=true]

[OnName num="keiichi"]
"......You're at a prestigious school. Who is not serious?"
[cpg cn=true]

From Mari's point of view, her fellow students might seem less motivated. I don't know anyone who is as serious about money as Mari.
[cpg]

The process of setting me up, up until now, has been perfect. It must have been a strategy that she had gone over many times.
[cpg]

The timing of bringing Ayaka back to the house was also exquisite.
[cpg]

[OnName num="keiichi"]
"Are we done? I'm tired, so let me sleep."
[cpg cn=true]

It was my day off. I'm not the kind of person who sleeps through the day, but I lied and tried to hang up the phone. Then,
[cpg]


[VOICE f="Mari074"]
[OnName num="mari"]
"Then I'll do the talking. You can just listen."
[cpg cn=true]

She stops me. Mari seems to be quite obsessed with me.
[cpg]

It seems that Mari is definitely feeling the affection that I have been feeling for her.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夕方）******************************************************


[VOICE f="Mari075"]
[OnName num="mari"]
"I'll call you again."
[cpg cn=true]

[OnName num="keiichi"]
"Yeah......"
[cpg cn=true]

[free time=1000]
[WAIT time=1000]

The call finally ends when my hand gets tired of holding the receiver. It's already evening, what am I doing......
[cpg]

I can't continue to be Mari's playmate and purse. Somehow, somewhere, I have to turn the tables.
[cpg]

But I can't think of a way to do it. Mari is probably still living with her parents, so I can't think of a way to sneak in and get the DVDs.
[cpg]

[OnName num="keiichi"]
"Oh, what should I do?......"
[cpg cn=true]

I'm just going to accept it already. I'll just accept this life as Mari's slave.
[cpg]

She's cute in her own way. And this life is not so bad.
[cpg]

I'm afraid I'm starting to change my mind. I'm being brainwashed......This is bad......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（夕方）******************************************************

And so I go on with my days. Even when Mari doesn't call me, even when she's not in front of me, all I can think about is her.
[cpg]

I think about Mari while I eat, while I take a bath, before I go to bed, and when I wake up.
[cpg]

Why was that? I'm not a girl in love.
[cpg]

I convince myself that I'm being threatened, and if I'm being threatened, it's not surprising that my mind is occupied with the person threatening me.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

I am still thinking of a plan to reverse the situation with Mari, but nothing comes to mind.
[cpg]

Today, she texted me again asking to see me. I ignored it, but......
[cpg]


;//●ＣＧ（茉莉・朝、主人公を起こしに来るヒロイン：恵一の部屋）ev_67
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_67_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//移植のためシーンをカットしています

[VOICE f="Mari076"]
[OnName num="mari"]
"Good morning."
[cpg cn=true]


[OnName num="keiichi"]
"Whoa."
[cpg cn=true]


She barged into my room.
[cpg]

I swear I locked the door, but I wouldn't put it past her to make a copy of my key...
[cpg]

[VOICE f="Mari077"]
[OnName num="mari"]
"Don't forget. You can't run away from me."
[cpg cn=true]


;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


The days went by like this.
[cpg]

One day, Mari started to half-live in my house.
[cpg]

By that, I mean that sometimes she would leave at night, and other times she would stay only at night.
[cpg]

It is hard to understand why her parents leave her alone, but perhaps it is their educational policy.
[cpg]

Considering the parents I could imagine from Mari's personality, it was not impossible.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（朝）******************************************************

[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="keiichi"]
"...See you later?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mari078"]
[OnName num="mari"]
"Of course."
[cpg cn=true]

I went to work. Mari went to school. We each said our morning greetings as we headed off.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社内』（昼）******************************************************

I knew I had to put a label to my feelings.
[cpg]

I don't resist Mari strongly, because I'm afraid of being threatened.
[cpg]

But that would not explain the amount of money I was paying her.
[cpg]

Then why am I obeying? Maybe it was because I liked Mari.
[cpg]

It had been that way since the first time I made the call. Out of the four girls I knew, I'd chosen Mari.
[cpg]

Whether it was unconsciously or not, it means that I found her more attractive than the other three.
[cpg]

It's a fact that I can no longer deny. I'm in love with Mari.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夜）******************************************************

[OnName num="keiichi"]
"Phew......"
[cpg cn=true]

I can't help but sigh. I think I'm starting to act more and more like a normal human being.
[cpg]

Now I can hardly say I'm an empty shell.
[cpg]

It's Mari, whether I'm asleep or awake. My interest in her has made me more human.
[cpg]

At work, there are people who find my stories interesting. That had never happened before.
[cpg]

Of course, I don't have any topics of my own to talk about, so I just respond to the topics that other people bring up......
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『住宅街』（夜）******************************************************



I notice that the sound of my shoes is lighter than usual when I leave the office.
[cpg]

It seems that I am looking forward to returning to my home where Mari is waiting for me.
[cpg]


[SE f="se001"]
;//【ＳＥ】『ドア開く』

[window target=false]
[free time=1000]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

It is more embarrassing than comfortable to go home, knowing that there was somebody waiting for me there.
[cpg]

[OnName num="keiichi"]
"I'm home."
[cpg cn=true]

Mari's usual expressionless face replies,
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mari079"]
[OnName num="mari"]
"Welcome home."
[cpg cn=true]


;//別に裸エプロンで待っているということはない。いや、こいつの茶目っ気ならありえることかもしれないな。
It's not that she welcomes me like a lover. Although she has a mischievous side to her it might be possible.
[cpg]

[OnName num="keiichi"]
"You're at my house again? I thought you were busy."
[cpg cn=true]

I said the opposite of what I was thinking. I was even feeling a little happy that Mari was there.
[cpg]

[OnName num="keiichi"]
"What's the plan? Are you going to keep leeching off of me forever?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Mari080"]
[OnName num="mari"]
"Something like that."
[cpg cn=true]

Mari is no longer hiding anything. And I somehow understood that her blank expression was, until now, to hide what she was up to.
[cpg]

I don't know if I'd simply gotten better at reading her expression or she'd allowed herself to relax a little more around me, but I felt like she was showing more emotion these days...
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Mari081"]
[OnName num="mari"]
"I really want to be rich."
[cpg cn=true]

Mari once again speaks of her obsession with money, something she has been saying for a while now.
[cpg]

[OnName num="keiichi"]
"I already know that."
[cpg cn=true]

I'm sounding like Mari these days. I'm beginning to sound quite heartless.
[cpg]

I'll have to lecture Mari if I start talking like this at work.
[cpg]

[OnName num="keiichi"]
"So to achieve this goal of being filthy rich, you're going to just keep leeching off of me, right?"
[cpg cn=true]

[OnName num="keiichi"]
"You'd have better luck if you married into a family with real money."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
Mari nods.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Mari082"]
[OnName num="mari"]
"The first step is to land myself a rich fiancee."
[cpg cn=true]

And then she turned her gaze on me and looked at me......Oh, the way she looked at me......
[cpg]

[OnName num="keiichi"]
"Stop it. Don't look at me like you have a crush on me. It's embarrassing for me to watch this."
[cpg cn=true]

I guess we were in love with each other. Damn, how did this happen? When did this happen?
[cpg]

[OnName num="keiichi"]
"You started out by blackmailing me, what changed?"
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Mari083"]
[OnName num="mari"]
"Nothing changed, the blackmail was just a roundabout confession."
[cpg cn=true]

She was gathering materials to threaten me, and she was pushing them toward me, all to make sure I couldn't escape.
[cpg]

What kind of a person was this? It's all too complicated for me to follow. But I found it fascinating.
[cpg]

That's how much she cared about me.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

And here's what happened just before I went to bed.
[cpg]

;//●ＣＧ（茉莉・ベッドに横たわるヒロイン：恵一の部屋）ev_70
[window target=false]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_70_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[OnName num="keiichi"]
"You want to get married?"
[cpg cn=true]

Mari nodded. I'm not hesitating any longer.
[cpg]

[OnName num="keiichi"]
"......Then what's the point of squeezing all that money out of me?"
[cpg cn=true]

[OnName num="keiichi"]
"If we got married, it'd all be part of our shared assets and everything you've done so far would be for nothing."
[cpg cn=true]


[VOICE f="Mari084"]
[OnName num="mari"]
"Not really."
[cpg cn=true]


[VOICE f="Mari085"]
[OnName num="mari"]
"It all depends on how much money I can use freely after we get married."
[cpg cn=true]

Ah, now it makes sense......I guess she wanted control over my earnings.
[cpg]

[OnName num="keiichi"]
"You're planning on getting a job after you leave school, aren't you?"
[cpg cn=true]


[VOICE f="Mari086"]
[OnName num="mari"]
"Of course."
[cpg cn=true]


I'm going to be tremendously rich, she said, squeezing my hand.
[cpg]

It's not romantic at all. But that was Mari's way of showing affection.
[cpg]

If she's right and she sticks with me until marriage, I'm going to end up being controlled by her......
[cpg]

But maybe that's not so bad. Being with Mari has filled the void in my heart.
[cpg]

[SCENE id=12]

[jump storage="epend.ks" target="*start"]

;//【茉莉ルート】ハッピーエンド
