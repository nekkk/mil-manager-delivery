
*start|Casually-clothed Kanako

;#################################################
*Ep004|Casually-clothed Kanako
;#################################################

[SCENE id=4]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]

I was on my way home after work.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（夜）******************************************************

I thought I'd run into the little sellout this morning, but I didn't see her.
[cpg]

I guess that was to be expected. She had her own schedule, there was no guarantee I'd see her.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************


So I went back home and called her.
[cpg]


[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]



[stopse g=2]
;//通常se
[stopse g=3]
;//通常se



[VOICE f="Kanako057"]
[OnName num="kanako"]
"Hello, feeling lonely?"
[cpg cn=true]

[OnName num="keiichi"]
"Don't make this awkward."
[cpg cn=true]

Kanako knew about Mari. We had talked about her the other day.
[cpg]

I couldn't think of any other mutual acquaintances, so I was pretty confident that Kanako had sold me out.
[cpg]

[OnName num="keiichi"]
"Is there something you want to apologize to me about?"
[cpg cn=true]


[VOICE f="Kanako058"]
[OnName num="kanako"]
"What? You mean about Hana?"
[cpg cn=true]

[OnName num="keiichi"]
"No, I mean something a little more serious."
[cpg cn=true]


[VOICE f="Kanako059"]
[OnName num="kanako"]
"......I can't think of anything."
[cpg cn=true]

I could sense that she was getting nervous. She knows what this is about, but she's playing dumb.
[cpg]

[OnName num="keiichi"]
"You gave Mari my phone number, didn't you?"
[cpg cn=true]


[VOICE f="Kanako060"]
[OnName num="kanako"]
"Urk......"
[cpg cn=true]

That pretty much cemented her guilt in my mind. What's done was done, but I was going to make her at least apologize.
[cpg]

[VOICE f="Kanako061"]
[OnName num="kanako"]
"Wh-what are you talking about?"
[cpg cn=true]

[OnName num="keiichi"]
"It's no use playing dumb at this point."
[cpg cn=true]


[VOICE f="Kanako062"]
[OnName num="kanako"]
"......Well, I didn't have a choice, she really pressured me."
[cpg cn=true]

[OnName num="keiichi"]
"So you told her."
[cpg cn=true]

That's not good. If she squealed on me once, she'd do it again. Who knows what else she might let slip...
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************


[VOICE f="Kanako063"]
[OnName num="kanako"]
"I'm really sorry about this, I'll make it up to you."
[cpg cn=true]

[VOICE f="Kanako064"]
[OnName num="kanako"]
"I'll even bring that girl again next time."
[cpg cn=true]

[OnName num="keiichi"]
"You mean Hana?"
[cpg cn=true]

I had a feeling she'd just run away again.
[cpg]

[OnName num="keiichi"]
"......I'll give it some thought."
[cpg cn=true]


[SE f="se035"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー

[free time=1000]
[WAIT time=1000]

After discussing where and when we would meet, I hung up the phone.
[cpg]

We're meeting on a weekend, so at least I'll get to see Kanako in her casual clothes. It had been a while, I think?
[cpg]

Or maybe she'll be wearing her school uniform.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（昼）******************************************************

;//ここまで裸以外全員制服
;//その埋め合わせの日にやってきた可南子は、制服だった。ちょっと残念だ。
When Kanako arrived, she was in her casual clothes.
[cpg]

[OnName num="keiichi"]
"Why are we meeting here in the middle of the day?"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kanako065"]
[OnName num="kanako"]
"You don't like it? The idea of dating a schoolgirl until the night?"
[cpg cn=true]

[OnName num="keiichi"]
"When you put it that way......"
[cpg cn=true]


[OnName num="keiichi"]
"But that still doesn't make up for selling me out to Mari."
[cpg cn=true]

[OnName num="keiichi"]
"You're bringing Hana, right? Where is she?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kanako066"]
[OnName num="kanako"]
"I'm not sure......"
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

From there, we waited for another hour.
[cpg]

I couldn't get the experience that Kanako promised me because the other person didn't show up.
[cpg]


;//【ＢＧ】『繁華街』（昼）******************************************************

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kanako067"]
[OnName num="kanako"]
"Hold on, I'll call her."
[cpg cn=true]

[OnName num="keiichi"]
"Alright."
[cpg cn=true]


[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル

[WAIT time=1000]

Kanako, probably feeling guilty, took out her cell phone and called Hana.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kanako068"]
[OnName num="kanako"]
"Hello? Hana?"
[cpg cn=true]

All I could hear was Kanako's voice. Still, I could tell it was getting pretty awkward.
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Kanako069"]
[OnName num="kanako"]
"What? You're nearby. Have you been there the whole time?"
[cpg cn=true]

Kanako is irritated. I haven't seen this kind of attitude from her, since she usually smiles a lot.
[cpg]

From the little I could hear, I imagined that Hana was close by, but wracked by indecision about whether or not she should come over.
[cpg]

And when Kanako suggested that we go over to her instead, she refused.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kanako070"]
[OnName num="kanako"]
"I understand, then I'll be the only one heading that way, okay?"
[cpg cn=true]

[OnName num="keiichi"]
"Hey, are you planning on leaving me here alone?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kanako071"]
[OnName num="kanako"]
"Don't worry. I'll bring her back here later."
[cpg cn=true]

She distanced her mouth from the phone and whispered to me.
[cpg]


[SE f="se034"]
;//【ＳＥ】『携帯電話　通話終了音』

[WAIT time=1000]

[FACE method="change_3" pos="2/3"]

She then hung up the phone and grumbled, then looked at me apologetically.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kanako072"]
[OnName num="kanako"]
"I'm sorry about all this."
[cpg cn=true]

[OnName num="keiichi"]
"It's okay......"
[cpg cn=true]

[SE f="se012"]
;//【ＳＥ】『走る』

[free time=1000]
[WAIT time=1000]

Before I could say anything further, Kanako ran off.
[cpg]


;//ＢＫ

It would be foolish to just stand here. However, I can't move since I've been told to wait here.
[cpg]

Unfortunately, I didn't have any good way to kill time while waiting. Time feels longer when I'm not doing anything.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（昼）******************************************************



[OnName num="keiichi"]
"......How long are they going to keep me waiting?"
[cpg cn=true]

After waiting and waiting, Hana finally appeared. She seemed like she had done a lot of crying.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Kanako073"]
[OnName num="kanako"]
"I'm sorry to keep you waiting. This is Hana."
[cpg cn=true]

[OnName num="keiichi"]
;//「いや、それは知ってるが」
"I know."
[cpg cn=true]

[FACE method="bow_4" pos="2/5"]
[VOICE f="Hana011"]
[OnName num="hana"]
"I'm sorry......"
[cpg cn=true]

She is still freaking out, even though she doesn't seem to be an anxious type of person.
[cpg]

What is she usually like? From the way she dresses, she seems like a rather mature and calm girl.
[cpg]

[FACE method="bow_1" pos="4/5"]
[VOICE f="Kanako074"]
[OnName num="kanako"]
"She won't run away this time. Right, Hana?"
[cpg cn=true]

[FACE method="bow_7" pos="2/5"]
[VOICE f="Hana012"]
[OnName num="hana"]
"Umm, yeah."
[cpg cn=true]

That wasn't very convincing. The death grip she had on Hana's arm didn't give me much hope, either.
[cpg]

I can't help but suspect that she was brought here by force.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I think Hana's purpose is the same as Kanako's.
[cpg]

She wants to get presents or something from me in exchange for a date. But......
[cpg]

She seemed nervous about it and kept observing me.
[cpg]


;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

;//[SE f="se001"]
;//【ＳＥ】『歩く』


[FACE method="shake_4" pos="2/5"]
[VOICE f="Hana013"]
[OnName num="hana"]
"Umm, I......think I should go home now."
[cpg cn=true]



[FACE method="change_5" pos="4/5"]
[VOICE f="Kanako075"]
[OnName num="kanako"]
"What?"
[cpg cn=true]


I was surprised too, but it was Kanako who answered first.
[cpg]

[FACE method="shake_3" pos="4/5"]
[VOICE f="Kanako076"]
[OnName num="kanako"]
"If you go back home now you won't get anything."
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』
[FO pos="2/5" time=1000]

She shook Kanako off and took off practically running.
[cpg]

She probably had a fear or men, which made it all the more curious as to why she was doing this in the first place.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（夜）******************************************************

[OnName num="keiichi"]
"How far are you going to follow me?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kanako077"]
[OnName num="kanako"]
"I wonder."
[cpg cn=true]

I remembered the first time we had met. If so, how did I get rid of her?
[cpg]

[OnName num="keiichi"]
"Don't follow me, I'm going home."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kanako078"]
[OnName num="kanako"]
"That's convenient."
[cpg cn=true]

Kanako says so without hesitation. She's not exactly a stalker.
[cpg]

So she's not as creepy as Mari.
[cpg]

[OnName num="keiichi"]
"You can be a real pain in the ass."
[cpg cn=true]

She just laughs in response.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

We walk for a while longer. At this rate, we would end up at my place.
[cpg]

Well, that's okay though, she knows where I live anyway.
[cpg]

Then I saw someone unexpected.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『住宅街』（夜）******************************************************



[FACE method="bow_2" pos="2/3"]
[VOICE f="Mari028"]
[OnName num="mari"]
"Welcome home, Keiichi."
[cpg cn=true]

Mari was waiting for me in front of my house. I looked at Kanako, who was looking at me.
[cpg]

Kanako and Mari should have no particular connection. Why was Mari here?
[cpg]

[free time=300]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="4/5" time=800]
[WAIT time=1000]

[VOICE f="Kanako079"]
[OnName num="kanako"]
"Mari, right......?"
[cpg cn=true]

Kanako approaches her cautiously. It's kind of refreshing to see her being suspicious towards people.
[cpg]

Mari is standing there with her usual expressionless face. Maybe I looked like that too.
[cpg]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Mari029"]
[OnName num="mari"]
"Keiichi, you must really like girls."
[cpg cn=true]

[OnName num="keiichi"]
"I don't dislike them."
[cpg cn=true]

I wonder how Kanako would perceive the conversation between me and Mari.
[cpg]

Come to think of it, I'm not the type to change my facial expression much either.
[cpg]

[OnName num="keiichi"]
"What are you doing in front of my house? Do I need to call the police?"
[cpg cn=true]

Kanako is looking for the right moment to interrupt the conversation. She kept changing her expression, so much so that I could tell she was wary of the situation.
[cpg]

[FACE method="change_7" pos="4/5"]
[VOICE f="Mari030"]
[OnName num="mari"]
"Do you not know......? You have a talent for attracting girls like this."
[cpg cn=true]

[OnName num="keiichi"]
"......"
[cpg cn=true]

I was aware of it. I don't know why we're talking about it now, but I'm aware of it.
[cpg]

Strange men attract strange women. I can say that with some degree of certainty.
[cpg]

[OnName num="keiichi"]
"Talent? That's a strange word to use."
[cpg cn=true]

[FACE method="shake_3" pos="4/5"]
[VOICE f="Mari031"]
[OnName num="mari"]
"It's not weird. It would be weirder not to call it a talent."
[cpg cn=true]

[FACE method="shake_3" pos="2/5"]
[VOICE f="Kanako080"]
[OnName num="kanako"]
"Hey, I'm still here, right? Hello? Guys?"
[cpg cn=true]

Kanako tries to cut in, but Mari continues as if she wasn't even there.
[cpg]

[FACE method="change_1" pos="4/5"]
[VOICE f="Mari032"]
[OnName num="mari"]
"Your number one talent is that you are empty......"
[cpg cn=true]

[OnName num="keiichi"]
"You ambushed me just to lecture me?"
[cpg cn=true]

Mari continues, unfazed.
[cpg]

[FACE method="bow_2" pos="4/5"]
[VOICE f="Mari033"]
[OnName num="mari"]
"The second is that you have money, and a lot of it."
[cpg cn=true]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Kanako081"]
[OnName num="kanako"]
"Hey, what are you talking about? Hey Keiichi, please get rid of this girl."
[cpg cn=true]

Mari glances over at Kanako as if she'd only just recognized her as a fellow human being. Then, she lets out a derisive huff.
[cpg]

It was clear that they weren't going to get along.
[cpg]

[FACE method="bow_4" pos="2/5"]
[VOICE f="Kanako082"]
[OnName num="kanako"]
"Can I stay over tonight? You don't mind, do you, Keiichi?"
[cpg cn=true]

I'm beginning to understand why Mari was saying all of this.
[cpg]

[FACE method="shake_1" pos="4/5"]
[VOICE f="Mari034"]
[OnName num="mari"]
"You really should hurry up and pick somebody."
[cpg cn=true]

She was right. I'd been passive about my relationships with these girls.
[cpg]

Maybe it's time for me to make a decision. As it was, the situation was about as far from normal as it could get.
[cpg]

I wasn't normal, and neither were they. But there still had to be some rules or there would be trouble.
[cpg]

[FACE method="change_4" pos="4/5"]
[VOICE f="Mari035"]
[OnName num="mari"]
"If you don't make an effort to change things, we'll never be able to move on."
[cpg cn=true]

[OnName num="keiichi"]
"......Just go."
[cpg cn=true]

The words just came out of my mouth. I guess she'd hit a sore spot.
[cpg]

Now I'm just playing with women under the pretense that I didn't do anything or choose anyone.
[cpg]

[FACE method="bow_3" pos="2/5"]
[VOICE f="Kanako083"]
[OnName num="kanako"]
"That's right, go home. We've got things to do......"
[cpg cn=true]

[OnName num="keiichi"]
"I mean the both of you. Just leave me alone tonight."
[cpg cn=true]

[FACE method="shake_4" pos="2/5"]
[VOICE f="Kanako084"]
[OnName num="kanako"]
"But......"
[cpg cn=true]

She's persistent. Why can't they back down? Mari is also looking at me as if she wants to say something......
[cpg]


;//■選択肢
[switch]
[case "I'm going to invite Kanako inside."]
	[swap]
	[jump target="*select02_1"]
[case "I'm going to invite Mari inside."]
	[swap]
	[jump target="*select02_2"]
[case "I tell both of them to go home."]
	[swap]
	[jump target="*select02_3"]
[endswitch]
;//１、可南子を家に上げる
;//２、茉莉を家に上げる
;//３、どちらも家に帰るように言う

;//==============================
;//１、可南子を家に上げる
*select02_1|Casually-clothed Kanako
;//この選択の場合、茉莉ハッピーエンドへの選択肢が無くなる

[stflag CHA04flag = 1]


[OnName num="keiichi"]
"All right, Kanako. Stay the night."
[cpg cn=true]

[FACE method="change_4" pos="4/5"]

[FACE method="bow_2" pos="2/5"]
[VOICE f="Kanako085"]
[OnName num="kanako"]
"Really? Yay!"
[cpg cn=true]

Hearing my words, Mari stepped back without saying anything. Then she turned around and left.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[FO pos="4/5" time=1000]
[WAIT time=1000]

She was the one who told me to choose. She must have thought that she was not chosen.
[cpg]

;//@
[OnName num="keiichi"]
"I'm tired today so you get to do the cooking and cleaning."
[cpg cn=true]

[FACE method="shake_5" pos="2/5"]
;//と釘を刺すと、可南子は「えーっ」と文句を言った。
Kanako grumbles.
[cpg]

[FACE method="bow_7" pos="2/5"]
Kanako left, saying something about me owing her for this.
[cpg]

[jump target="*select02_4"]

;//==============================
;//２、茉莉を家に上げる
*select02_2|Casually-clothed Kanako
;//この選択の場合、可南子ハッピーエンドへの選択肢が無くなる

[stflag CHA03flag = 1]



[OnName num="keiichi"]
"So, what? Was all that some roundabout way of asking me to pick you? Fine, you can come in."
[cpg cn=true]


[FACE method="change_4" pos="2/5"]
[FACE method="shake_7" pos="4/5"]
[VOICE f="Mari036"]
[OnName num="mari"]
"I only came here today to give you a warning. There is no reason for me to stay over tonight."
[cpg cn=true]

What was that supposed to mean? This was coming from the same girl who barged in the other night?
[cpg]

This wasn't the first time I've felt like she had me wrapped around her finger.
[cpg]

[free time=1000]
[WAIT time=1000]

I watched as Mari walked away while Kanako stomped off in a huff, grumbling about not being chosen.
[cpg]

[jump target="*select02_4"]

;//==============================
;//３、どちらも家に帰るように言う
*select02_3|Casually-clothed Kanako
;//この選択の場合、茉莉ハッピーエンドへの選択肢が無くなる

;//この選択の場合、可南子ハッピーエンドへの選択肢が無くなる

[stflag CHA03flag = 1]
[stflag CHA04flag = 1]

[FACE method="shake_3" pos="2/5"]

Kanako grumbled when I told her she couldn't come in either.
[cpg]

Mari also persisted, but I wasn't interested in hearing any of it.
[cpg]

Maybe Mari was just trying to say that I should pick her in some roundabout way.
[cpg]

[FACE method="bow_7" pos="4/5"]
[VOICE f="Mari037"]
[OnName num="mari"]
"Okay, I'll go home. Kanako, you should head home too."
[cpg cn=true]

[FACE method="shock_5" pos="2/5"]
[VOICE f="Kanako086"]
[OnName num="kanako"]
"Don't decide for me."
[cpg cn=true]

[OnName num="keiichi"]
"Just let me be alone tonight."
[cpg cn=true]

It's unusual for me to feel like this. For the first time in a long time, I felt like I wanted to take time for myself to think.
[cpg]

[FACE method="change_4" pos="2/5"]
[VOICE f="Kanako087"]
[OnName num="kanako"]
"Fine......see you around then, Keiichi."
[cpg cn=true]

That was for me to decide......but if I say it out loud, she'd probably never leave.
[cpg]

[OnName num="keiichi"]
"Yeah."
[cpg cn=true]

That was the perfect reply. I can decide if I want to meet again after I think about who I want to choose.
[cpg]

[FACE method="bow_1" pos="4/5"]
[VOICE f="Mari038"]
[OnName num="mari"]
"Goodbye. I hope we meet again."
[cpg cn=true]

Mari replied something similar. Was she really implying that I should choose her?
[cpg]


;//==============================
;//どれを選択してもここに合流

*select02_4|Casually-clothed Kanako


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************


The sun had long set. I headed to my room and flopped on the bed. I should get changed, but I'm too tired.
[cpg]


[SE f="se029"]
;//【ＳＥ】『ベッドきしむ』


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[OnName num="keiichi"]
"......"
[cpg cn=true]

Ayaka. A girl with a light-hearted personality.
[cpg]

Kanako, who went to the same school as her. She always follows me around when she sees me.
[cpg]

Then there's Hana, who seems to be Kanako's friend. I don't know much about her......
[cpg]

I can only imagine what kind of person she is.
[cpg]

Then there's Mari, who's got nothing in common with the others. She seems to know more about me than I do of her......
[cpg]

According to Kanako, she's a gold digger, but when she stayed over the other night, she didn't ask me for anything.
[cpg]

Everything about her seemed a mystery. I still don't know what her true intentions are.
[cpg]

As far as I can tell, they're all on the same level, but it can't stay that way forever.
[cpg]

I remember what Mari told me about being empty. It seemed an accurate assessment.
[cpg]

Empty. A fitting word for me. Too fitting. My entire existence, summed up in a single word.
[cpg]

My life wasn't the problem. The problem was me.
[cpg]

If that was true, then if I made one of them mine, I might be able to fill this void. That must be what Mari wanted to say.
[cpg]

Besides, it would be a waste to not do anything with all of this money.
[cpg]


;//[SE f="se001"]
;//【ＳＥ】『ベッドきしむ』

[free time=1000]
[WAIT time=1000]

I sit up and pull out my phone. I scroll through my contacts.
[cpg]

Just like before, only four numbers seem to stand out from the rest.
[cpg]

[OnName num="keiichi"]
"Right......"
[cpg cn=true]

After some hesitation and thought, I pressed the call button. I hadn't decided what I was going to do yet, but I had chosen who I was going to do it with.
[cpg]

Maybe it didn't matter who I chose in the end.
[cpg]

As long as they could bring some sort of meaning into my life. I look down at the name on the screen...
[cpg]


;//■選択肢

[if exp={getFlagValue("CHA02flag") == 1 }]
[jump target="*flg_134"]
[endif]

[if exp={getFlagValue("CHA03flag") == 1 }]
[jump target="*flg_124"]
[endif]


*flg_123|Casually-clothed Kanako
[switch]
[case "Ayaka"]
	[swap]
	[jump target="*root_ayaka"]
[case "Hana"]
	[swap]
	[jump target="*root_hana"]
[case "Kanako"]
	[swap]
	[jump target="*root_kanako"]
[endswitch]


*flg_134|Casually-clothed Kanako
[if exp={getFlagValue("CHA03flag") == 1 }]
[jump target="*flg_14"]
[endif]

*flg_13|Casually-clothed Kanako
[switch]
[case "Ayaka"]
	[swap]
	[jump target="*root_ayaka"]
[case "Kanako"]
	[swap]
	[jump target="*root_kanako"]
[endswitch]


*flg_14|Casually-clothed Kanako
;//ヒロイン１以外フラグが立っていない
[if exp={getFlagValue("CHA04flag") == 1 }]
[jump target="*root_ayaka"]
[endif]

[switch]
[case "Ayaka"]
	[swap]
	[jump target="*root_ayaka"]
[case "Mari"]
	[swap]
	[jump target="*root_mari"]
[endswitch]



*flg_124|Casually-clothed Kanako
[if exp={getFlagValue("CHA04flag") == 1 }]
[jump target="*flg_12"]
[endif]
[switch]
[case "Ayaka"]
	[swap]
	[jump target="*root_ayaka"]
[case "Hana"]
	[swap]
	[jump target="*root_hana"]
[case "Mari"]
	[swap]
	[jump target="*root_mari"]
[endswitch]

*flg_12|Casually-clothed Kanako
[switch]
[case "Ayaka"]
	[swap]
	[jump target="*root_ayaka"]
[case "Hana"]
	[swap]
	[jump target="*root_hana"]
[endswitch]


;//発生しない選択肢
*flg_1234|Casually-clothed Kanako
[switch]
[case "Ayaka"]
	[swap]
	[jump target="*root_ayaka"]
[case "Hana"]
	[swap]
	[jump target="*root_hana"]
[case "Kanako"]
	[swap]
	[jump target="*root_kanako"]
[case "Mari"]
	[swap]
	[jump target="*root_mari"]
[endswitch]


;//[stflag CHA01flag = 0]
;//[stflag CHA02flag = 0]
;//[stflag CHA03flag = 0]
;//[stflag CHA04flag = 0]


;//１、彩華
;//２、花
;//３、可南子
;//４、茉莉

;//それぞれ、番号ごとのヒロインへと分岐します。


*root_ayaka|Casually-clothed Kanako
[jump storage="ep005.ks" target="*root_ayaka"]

*root_hana|Casually-clothed Kanako
[jump storage="ep006.ks" target="*root_hana"]

*root_kanako|Casually-clothed Kanako
[jump storage="ep007.ks" target="*root_kanako"]

*root_mari|Casually-clothed Kanako
[jump storage="ep008.ks" target="*root_mari"]
;////////////////////////////////////////////////////////////////////////
