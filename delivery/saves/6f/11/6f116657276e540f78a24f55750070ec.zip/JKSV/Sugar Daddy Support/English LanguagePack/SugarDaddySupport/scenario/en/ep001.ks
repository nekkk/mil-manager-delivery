
*start|Meeting Hana

;#################################################
*Ep001|Meeting Hana
;#################################################

[SCENE id=1]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************

I wake up and nibble on some toast. Nothing really has much taste, so I don't bother putting jam or butter on it.
[cpg]

I don't care what it is, as long as it's edible. I understand that some people are just trying to save money, but that wasn't the problem I was having.
[cpg]

I just didn't feel much of anything. That's probably why I'm like this.
[cpg]

The only thing that really sticks out in my memory are my conversations with the girls I'd met.
[cpg]

Like yesterday.....I could clearly remember when I met Kanako.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

[SE f="se001"]
;//【ＳＥ】『歩く』

My commute to the office was walkable. It's not a short walk, but I didn't mind the exercise.
[cpg]

It gave me something to do with my time.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社内』（昼）******************************************************

It's little wonder I led such a boring life.
[cpg]

Yet, I found myself almost eager to meet Hana that evening.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************

[SE f="se027"]
;//【ＳＥ】『喧騒』

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kanako032"]
[OnName num="kanako"]
"......I wonder what she's doing?"
[cpg cn=true]

[OnName num="keiichi"]
"......I thought you were going to bring her along."
[cpg cn=true]

Hana didn't show up until an hour past the appointed meeting time.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kanako033"]
[OnName num="kanako"]
"But we don't even go to the same school."
[cpg cn=true]


[OnName num="keiichi"]
"I trust you're going to make this up to me?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kanako034"]
[OnName num="kanako"]
"Sure, if that's what you really want."
[cpg cn=true]

Kanako says so, pridefully, but I doubted she could satisfy me.
[cpg]

;//そのくらい、花に会ってみたかった。抱こうとしたら、どれだけ抵抗するのか、見てみたかった。
That's how much I'd been looking forward to meeting Hana.
[cpg]


[free time=1000]
[WAIT time=1000]

[VOICE f="Hana001"]
[OnName num="hana"]
"......"
[cpg cn=true]

It seems she'd been watching us from afar for a while before gathering up the courage to approach us.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[WAIT time=1000]

[VOICE f="Hana002"]
[OnName num="hana"]
"I'm sorry......for being late."
[cpg cn=true]

;//花。なるほど、確かにどう見ても処女だなと思わせるような感じがあった。
Hana. Something about her made me think that she never have had a boyfriend.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Hana003"]
[OnName num="hana"]
"Um, well......"
[cpg cn=true]

She seemed more frightened and nervous than she should be. Her voice was quiet and just barely audible.
[cpg]

It seemed like she was more scared of what she was here to do than anything else.
[cpg]

[free time=300]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="4/5" time=800]
[VOICE f="Kanako035"]
[OnName num="kanako"]
"You're late, Hana!"
[cpg cn=true]

[FACE method="bow_4" pos="2/5"]
[VOICE f="Hana004"]
[OnName num="hana"]
"I'm really sorry. I got nervous."
[cpg cn=true]

[FACE method="bow_3" pos="4/5"]
[VOICE f="Kanako036"]
[OnName num="kanako"]
"We've talked about this many times, you said you were ready!"
[cpg cn=true]

Hana was a friend from a different school. So this was how they interacted with each other.
[cpg]

They didn't seem to have the usual upper and underclassmen relationship.
[cpg]

[FACE method="bow_2" pos="4/5"]
[VOICE f="Kanako037"]
[OnName num="kanako"]
"Let's start with introductions."
[cpg cn=true]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Hana005"]
[OnName num="hana"]
"But I just introduced myself a moment ago......?"
[cpg cn=true]

[FACE method="shake_1" pos="4/5"]
[VOICE f="Kanako038"]
[OnName num="kanako"]
"You can't call that half-mumbled whisper an introduction. This is Keiichi."
[cpg cn=true]

[OnName num="keiichi"]
"......Hi."
[cpg cn=true]

[FACE method="bow_7" pos="2/5"]
[VOICE f="Hana006"]
[OnName num="hana"]
"Hello, my name is Hana..."
[cpg cn=true]

Her voice trails off into a mumble again.
[cpg]


;//ＢＫ

It seemed very clear that she hadn't had much experience around men. I guess Kanako was telling the truth.
[cpg]


;//移植のためシーンをカットしています


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************


We spent some time together, but she kept fidgeting and looking around the whole time.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Hana007"]
[OnName num="hana"]
"Umm......I......"
[cpg cn=true]


[FACE method="shake_5" pos="4/5"]
[VOICE f="Kanako039"]
[OnName num="kanako"]
"What? Are you leaving already?"
[cpg cn=true]

Hana goes quiet.
[cpg]

[FACE method="change_7" pos="2/5"]
[FACE method="change_5" pos="4/5"]
;//■選択肢
[switch]
[case "I force her to stay."]
	[swap]
	[jump target="*select01_1"]
[case "I leave her alone."]
	[swap]
	[jump target="*select01_2"]
[endswitch]
;//１、無理やり引き止める
;//２、放っておく

;//==============================
;//１、無理やり引き止める
*select01_1|Meeting Hana

;//この選択の場合、花ハッピーエンドへの選択肢が無くなる
[stflag CHA02flag = 1]

[free time=300]

[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Hana008"]
[OnName num="hana"]
"Eek!"
[cpg cn=true]

I forcefully grabbed Hana's shoulders. I don't think I had the looks for a power play like this, but maybe I could get through with a false sense of bravado.
[cpg]

[OnName num="keiichi"]
"We haven't done anything yet. You can't just back out like this."
[cpg cn=true]

Hana struggles to get away. She lets out a cry for help, causing even Kanako to start panicking.
[cpg]

I didn't have a lot of experience with women, so I didn't exactly expect this to backfire so spectacularly.
[cpg]

[free time=300]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Hana009"]
[OnName num="hana"]
"I can't do this after all, I'm leaving!"
[cpg cn=true]

She grabs her stuff and leaves in a hurry.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[FO pos="2/3" time=1000]
[WAIT time=1000]

[jump target="*select01_3"]

;//==============================
;//２、放っておく
*select01_2|Meeting Hana
There's no sense in pushing her. If she doesn't want to do this, then it wasn't my place to stop her.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Hana010"]
[OnName num="hana"]
"......I don't think I can do this......"
[cpg cn=true]


[FACE method="change_4" pos="4/5"]
Kanako looked a little disappointed, but didn't stop her.
[cpg]

;//残念そうに頷いて、花の荷物を拾い、花へ手渡す可南子。
She nods and sees Hana off.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[FO pos="2/5" time=1000]
[WAIT time=1000]

;//==============================
;//どちらを選択してもここに合流
*select01_3|Meeting Hana

;//ＢＫ

[free time=300]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kanako040"]
[OnName num="kanako"]
"......I'm sorry about that."
[cpg cn=true]

[OnName num="keiichi"]
"Me too..."
[cpg cn=true]

Now I was alone with Kanako. It was awkward.
[cpg]

[OnName num="keiichi"]
"......So, what's her story?"
[cpg cn=true]

[OnName num="keiichi"]
"She clearly wasn't ready, why'd you bring her along?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Kanako041"]
[OnName num="kanako"]
"Weeeell, Hana's family is kinda poor......"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Kanako042"]
[OnName num="kanako"]
"I know she still needs money, so I'll give you her number."
[cpg cn=true]

[OnName num="keiichi"]
"Seriously?"
[cpg cn=true]

What was Kanako thinking? That poor girl clearly didn't want to have anything to do with me, why would she give me Hana's number?
[cpg]

[OnName num="keiichi"]
"Are you sure about this? I don't think she's going to be happy with you when she finds out."
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kanako043"]
[OnName num="kanako"]
"It's okay, we're friends."
[cpg cn=true]

Somehow, I wasn't convinced.
[cpg]

Either way, I ended up with Hana's phone number.
[cpg]

;//移植のためシーンをカットしています

Hana made the fourth girl I'd met like this.
[cpg]

The third being Ayaka, the second being Kanako...but the first one was different.
[cpg]

I started thinking of her for some reason...
[cpg]


;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_07_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=1000]
;//
;//[BGM f="bg_ni"]
;//[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************


[FACE method="change_2" pos="2/3"]
[VOICE f="Kanako044"]
[OnName num="kanako"]
"Well then, call me anytime, Keiichi."
[cpg cn=true]

[OnName num="keiichi"]
"If I feel like it."
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

[free time=1000]
[WAIT time=1000]

I wave and leave. It was late in the evening, but there was still too early to go to bed.
[cpg]

I found myself with a bit of time on my hands.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

I'm the type who doesn't know how to kill time at times like this.
[cpg]

Since I don't have any hobbies, I have no convenient way of spending my time.
[cpg]

Maybe it's because I'm always walking around town with nothing to do that I keep running into girls like them.
[cpg]

When was the first time I'd been propositioned like that? I can't say it was recently, it had to have been a while ago.
[cpg]

I met Kanako two months ago, so it would have been a bit before that......
[cpg]

I think her name was...Mari.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夜）******************************************************

;/[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="keiichi"]
"Oh."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Mari001"]
[OnName num="mari"]
"......Oh."
[cpg cn=true]

There was a slight delay in recognizing each other. It seems Mari doesn't think of me very often.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Mari002"]
[OnName num="mari"]
"Keiichi. Long time no see."
[cpg cn=true]

[OnName num="keiichi"]
"I guess so......"
[cpg cn=true]

Still, she remembered my name.
[cpg]

Mari approaches me.
[cpg]

[OnName num="keiichi"]
"What are you doing out here this late. Shouldn't you be at home?"
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Mari003"]
[OnName num="mari"]
"It's none of your business."
[cpg cn=true]

You might think she was a little angry, but this is how she acted all the time.
[cpg]

Mari was the kind of girl who never ever seemed to change her expression. She always looked like this.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Mari004"]
[OnName num="mari"]
"......I saw you with another girl the other day."
[cpg cn=true]

[OnName num="keiichi"]
"Huh?"
[cpg cn=true]

When was it? It's just like her keep quiet then and only just tell me now.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************

She leads me to a bench in the park.
[cpg]

[OnName num="keiichi"]
"......Are you planning on asking me out again?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Mari005"]
[OnName num="mari"]
"Good guess."
[cpg cn=true]

[OnName num="keiichi"]
"Sorry, but I'm not interested."
[cpg cn=true]

[OnName num="keiichi"]
"You're not like the other girls. I can see you're up to something and I'm not sure I like it."
[cpg cn=true]

Mari's usual cool expression becomes clouded for a moment before returning to normal.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mari006"]
[OnName num="mari"]
"Why? I'm just like the other girls."
[cpg cn=true]

[OnName num="keiichi"]
"Your actions, sure. But it's your motivations that get me wondering about you. I feel like you're going to get me into trouble one of these days."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Mari007"]
[OnName num="mari"]
"......"
[cpg cn=true]

She groaned and looked up at the sky. The sky was pitch-black and there wasn't a single star to be seen.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Mari008"]
[OnName num="mari"]
"How can I get you to trust me?"
[cpg cn=true]

[OnName num="keiichi"]
"Figure it out. I'll just say that if you keep that blank expression on your face, no one will come near you."
[cpg cn=true]

[OnName num="keiichi"]
"Did you forget how to smile or something?"
[cpg cn=true]

It was a lot easier to trust easy going girls who smiled a lot. Even reserved girls who approached with trepidation were more relatable than Mari was.
[cpg]

Her lack of facial expressions made it so hard to figure out what she was thinking. It wasn't too hard to imagine she was up to no good.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Mari009"]
[OnName num="mari"]
"I don't smile a lot."
[cpg cn=true]


[OnName num="keiichi"]
"......Did something happen in your past?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Mari010"]
[OnName num="mari"]
"My upbringing was normal."
[cpg cn=true]

There's a shocking bit of information. So why was she going around approaching men like this?
[cpg]

[OnName num="keiichi"]
"Either way, you'd better practice smiling a little if you want repeat customers."
[cpg cn=true]

[OnName num="keiichi"]
"Not that it's my problem. I don't know what you're thinking, so I'm not going to get involved with you."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Mari011"]
[OnName num="mari"]
"That's precisely why I don't like to make facial expressions."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

What was that supposed to mean? I parted with Mari there and went back home.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Ayaka. I'd only met her recently, but she seemed to be the lighthearted, playful type.
[cpg]

Hana. Kanako's friend, who seemed to be very inexperienced with romance and very cautious around men.
[cpg]

Then there was Kanako. She was a real player.
[cpg]

Lastly, Mari......The girl I'd talked to earlier. Those were the four girls I'd gotten to know.
[cpg]

Even I could tell this wasn't a normal situation. Working men my age aren't supposed to have anything to do with girls like that.
[cpg]

I had a feeling that whatever was wrong with me was also attracting troublesome women.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

I was tired when I finally made it home. As I understand it, most people feel a sense of joy when they finally get to bed after a long day.
[cpg]

But I don't. I understand what's waiting for me when I wake up in the morning.
[cpg]

Or maybe I don't even care that I'm tired from work. I don't have an on or off switch.
[cpg]

I fall asleep, unsure of myself.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

I don't dream. If I did, would those girls show up in my dreams?
[cpg]

I guess that's the only place where I can find any joy in my life.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_rl"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************


I hear that when people wake up on weekdays, they sometimes feel the strain of starting another day.
[cpg]

But I don't. For the same reason I don't feel joy when I go to bed.
[cpg]

The days are like plain toast. No taste, no texture, just repetition.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

[SE f="se001"]
;//【ＳＥ】『歩く』

When I was a student, I had a similar feeling when I went to school. I think.
[cpg]

I think the fact that I can't remember it properly is proof of that.
[cpg]

The parts I can't remember are all the same. Not much has changed since I was born.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************

After work, I went to my room and looked at the contact list in my cell phone.
[cpg]

My office. My family members. Various acquaintances from over the years. Only the names of the girls I'd met seem to stand out.
[cpg]

I don't know Mari's number, but I have the impression that the names of the other three girls stand out in my mind.
[cpg]

Could it be that I was feeling a little joy at the prospect of being able to contact them whenever I wanted?
[cpg]

[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=3000]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[OnName num="keiichi"]
"......Hello, is this Kanako?"
[cpg cn=true]


[VOICE f="Kanako045"]
[OnName num="kanako"]
"You want to meet up?"
[cpg cn=true]

[OnName num="keiichi"]
"No, that's not why I'm calling you."
[cpg cn=true]

Kanako raised her voice in dissatisfaction. I had somehow imagined this kind of exchange at the beginning.
[cpg]


[VOICE f="Kanako046"]
[OnName num="kanako"]
"I'm still going to charge you if you're just calling because you're lonely."
[cpg cn=true]

[OnName num="keiichi"]
"You're not the type to be so greedy, are you?"
[cpg cn=true]


[VOICE f="Kanako047"]
[OnName num="kanako"]
"You know me too well."
[cpg cn=true]

"So, what can I do for you?", she asked.
[cpg]

[OnName num="keiichi"]
"Do you know Mari?"
[cpg cn=true]

There was a bit of silence on the other end of the phone. She was trying to remember.
[cpg]


[VOICE f="Kanako048"]
[OnName num="kanako"]
"......I heard that was part of her territory."
[cpg cn=true]

[OnName num="keiichi"]
"Who is she? Is she involved with scary people or something?"
[cpg cn=true]


[VOICE f="Kanako049"]
[OnName num="kanako"]
"What? Getting cold feet?"
[cpg cn=true]

[OnName num="keiichi"]
"No, that's not it. I just got the feeling she might have a reason for doing what she does."
[cpg cn=true]


[VOICE f="Kanako050"]
[OnName num="kanako"]
"Is she stalking you or something?"
[cpg cn=true]

[OnName num="keiichi"]
"I wouldn't go that far......but she approached me again the other day."
[cpg cn=true]

Over the receiver, I hear her groan. What did she know?
[cpg]


[VOICE f="Kanako051"]
[OnName num="kanako"]
"I don't know that much about her."
[cpg cn=true]

[OnName num="keiichi"]
"You don't? But you said something about territory..."
[cpg cn=true]

Apparently they didn't know each other directly. I see. Maybe they had some overlap in their clientele.
[cpg]

Or perhaps she was just sensitive to rumours about girls in the same line of business.
[cpg]


[VOICE f="Kanako052"]
[OnName num="kanako"]
"Anyways, I haven't heard any good rumors about her."
[cpg cn=true]

[OnName num="keiichi"]
"Is that so? Are you sure you're not just trying to keep me all to yourself?"
[cpg cn=true]

Kanako leaves the answer up in the air. Very well then.
[cpg]

[OnName num="keiichi"]
"So why keep her away? Does she have a scary boyfriend or something?"
[cpg cn=true]


[VOICE f="Kanako053"]
[OnName num="kanako"]
"I'd heard that she's a gold-digger......"
[cpg cn=true]

That makes sense.
[cpg]

[OnName num="keiichi"]
"Who'd you hear that from?"
[cpg cn=true]


[VOICE f="Kanako054"]
[OnName num="kanako"]
"You hear a lot of things whether you want to or not when you work in the same circles."
[cpg cn=true]

[OnName num="keiichi"]
"I take it Ayaka's a different breed......"
[cpg cn=true]


[VOICE f="Kanako055"]
[OnName num="kanako"]
"Oh right, you said you'd met her, didn't you?"
[cpg cn=true]


[OnName num="keiichi"]
"I don't know if it's her age or her determination, but she has a totally different attitude."
[cpg cn=true]


[VOICE f="Kanako056"]
[OnName num="kanako"]
"You know I'm younger than Ayaka."
[cpg cn=true]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]


[SE f="se035"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************


[OnName num="keiichi"]
"Right......"
[cpg cn=true]

I end the call with Kanako to find myself interested in Ayaka's situation.
[cpg]

She was charging me more than Kanako. But unlike Kanako, Ayaka seemed to be in real need of money.
[cpg]

Of course, it wasn't my place to find out why, but I was getting curious all the same.
[cpg]

[OnName num="keiichi"]
"......"
[cpg cn=true]

I stared at Ayaka's number on my phone screen.
[cpg]

After thinking about it for a few seconds, I put the phone down. I often go to the park where we met, I'm sure I'll see her again.
[cpg]


[jump storage="ep002.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
