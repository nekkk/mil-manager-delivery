;//３、可南子

*start|Kanako Attracts People

;#################################################
*Ep007|Kanako Attracts People
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************

*root_kanako|Kanako Attracts People


[SCENE id=7]

[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[OnName num="keiichi"]
Hello, Kanako?
[cpg cn=true]

[VOICE f="Kanako158"]
[OnName num="kanako"]
Oh, Keiichi-san. Are you missing someone?"
[cpg cn=true]

I thought to myself that I had called an unexpected person.
[cpg]

It was a whim that I did not understand.
[cpg]

[OnName num="keiichi"]
"You're not mistaken.
[cpg cn=true]

Kanako on the other end of the line was in a good mood. And then she said, "Where do you want to meet?
[cpg]


[VOICE f="Kanako159"]
[OnName num="kanako"]
Where would you like to meet?　I can meet him right now.
[cpg cn=true]


[OnName num="keiichi"]
I can't do it right now. Don't be in such a hurry.
[cpg cn=true]

Kanako said, "What? I don't care what you say, I can't meet you right now.
[cpg]

[OnName num="keiichi"]
How about tomorrow? How about tomorrow night?
[cpg cn=true]


[VOICE f="Kanako160"]
[OnName num="kanako"]
I understand. I'm looking forward to it.
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（朝）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

[SE f="se001"]
;//【ＳＥ】『歩く』

[OnName num="keiichi"]
"...... Kanako, huh? Why did I choose her?
[cpg cn=true]

No matter how many times I think about it, I can't convince myself. I can tell you that there is no progress on this guy, no matter what you do.
[cpg]

I don't know how much of this is an act. I don't know how much of it is an act, but it's better than Mari's.
[cpg]

Thinking about this, I went to work as usual. Perhaps my mood was a bit buoyant, but my work went well.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************

Then, it was night in the blink of an eye. Kanako was already at the meeting place.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kanako161"]
[OnName num="kanako"]
She said, "Hello, how do you do? Thank you for your help.
[cpg cn=true]

[OnName num="keiichi"]
Don't talk like that. ......
[cpg cn=true]

I'm not wrong, though, because I'm getting something in return.
[cpg]


;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています


[SE f="se001"]
;//【ＳＥ】『歩く』

[free time=300]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

We walk around the city at night for a while. Kanako rubs up against me without hesitation.
[cpg]

I didn't feel bad, even if there was something I was looking for.
[cpg]

However, I have to work tomorrow, so I can't take her home.
[cpg]

And if I did, Kanako would squeeze me for a long time.
[cpg]

[OnName num="keiichi"]
I'd have to go to ......, Kanako. You're too close.
[cpg cn=true]


I said, and after a short distance, he came closer and stuck close to me as we walked again.
[cpg]

[OnName num="keiichi"]
You know,......?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Kanako162"]
[OnName num="kanako"]
Is it okay if I stick to you?
[cpg cn=true]

[OnName num="keiichi"]
I don't think so, but..."
[cpg cn=true]

Kanako gets puffed up. I don't know what she likes about me, but she keeps trying to stay by my side.
[cpg]

I wonder how far she will follow me.
[cpg]

I wonder if she will end up at my house. I don't mind, since he already knows where I live. ......
[cpg]

But if he gets into my house, that would be troublesome. With that in mind, I went around the town at random.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_rl"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************

[SE f="se001"]
;//【ＳＥ】『歩く』

Then I came back to the original place. Kanako walks next to me, still not complaining.
[cpg]

[OnName num="keiichi"]
...... you haven't noticed?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
I put my index finger on my chin. I put my index finger on my chin.
[cpg]

[OnName num="keiichi"]
I'm here, near the meeting place. You didn't notice?
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kanako163"]
[OnName num="kanako"]
"Oh, that's what you're talking about. I noticed.
[cpg cn=true]

I've noticed it, but you're still going out with her. ...... How far does she just want to be by my side?
[cpg]

I wonder how far this guy is going to follow me. I'm not going to keep quiet all the time.
[cpg]

I don't know what to say to him to get him to leave. ......
[cpg]


;//■選択肢
[switch]
[case "Tell him I'm worried about him."]
	[swap]
	[jump target="*select04_1"]
[case "I say it's too much trouble."]
	[swap]
	[jump target="*select04_2"]
[endswitch]
;//１、心配だと言う
;//２、面倒くさいと言う

;//==============================
;//１、心配だと言う
*select04_1|Kanako attracts people

[OnName num="keiichi"]
Are you like this with everyone?　Do you do this to other guys, too?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

Kanako laughs. I've been thinking about it for a while, but he laughs a lot.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kanako164"]
[OnName num="kanako"]
You think I have feelings for you, don't you?
[cpg cn=true]

[OnName num="keiichi"]
If you're going to make fun of me, leave here. I'm seriously worried about you.
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kanako165"]
[OnName num="kanako"]
'No, you're not mistaken. But I'm rubbing off on other men.
[cpg cn=true]

I'm even more worried about ...... it's getting late and this guy needs to go home.
[cpg]

[OnName num="keiichi"]
Where's your home, boy?　I'll give you a ride."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
Kanako is surprised and rolls her eyes.
[cpg]

[FACE method="change_5" pos="2/3"]
[OnName num="keiichi"]
Of course I'm not going to your house. Of course, I won't go to your house, because I don't want your parents to suspect anything.
[cpg cn=true]

I'm still continuing to be surprised. I thought that's what I was surprised about.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kanako166"]
[OnName num="kanako"]
I'm so impressed that you're that concerned about me. I'm impressed."
[cpg cn=true]

[OnName num="keiichi"]
It's not something to be thrilled about. Anyone would be worried if they saw you.
[cpg cn=true]

[OnName num="keiichi"]
I have work tomorrow, too, and I want you to go home as soon as possible.
[cpg cn=true]

Kanako was thinking about it as she said, "Hmmm. I understand," she said, looking up.
[cpg]

[OnName num="keiichi"]
I understand," she said, looking up at Kanako.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kanako167"]
[OnName num="kanako"]
I understand.
[cpg cn=true]

The fact that this guy says he understands doesn't make him convincing.
[cpg]

I'm not usually a big liar, but for some reason ...... I'm worried about it.
[cpg]

[jump target="*select04_3"]

;//==============================
;//２、面倒くさいと言う
*select04_2|Kanako, who attracts people.


[stflag CHA03flag = 1]


[OnName num="keiichi"]
'You're such a pain in the ass. Don't follow me forever."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Kanako168"]
[OnName num="kanako"]
I'm used to being told that. Heh."
[cpg cn=true]

What do you mean you're used to being told that? Do you understand my words properly ......?
[cpg]

[OnName num="keiichi"]
I have work tomorrow. I can't hang out with you forever."
[cpg cn=true]

I said, forcing him to untie my hand that was squeezing it.
[cpg]

And again, he immediately ...... entangles his hands. This guy is selfish to no end, I'd say. ......
[cpg]

[OnName num="keiichi"]
You're going to be in a lot of trouble someday if you keep doing that.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kanako169"]
[OnName num="kanako"]
Thanks for your concern."
[cpg cn=true]

After that, after several times of forcibly pushing him away and sticking with him.
[cpg]

Finally, Kanako seemed to give up, but with a smile on her face, we parted ways.
[cpg]


;//==============================
;//どちらを選択してもここに合流
*select04_3|Kanako attracts people


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************


[OnName num="keiichi"]
'Oh, I'm kind of tired ......'
[cpg cn=true]

I go home and can't help but talk to myself. That's how much I was turned on by Kanako today.
[cpg]

I thought to myself, "I shouldn't have called her on a whim," but my regrets were not that deep.
[cpg]

I wonder if I'm somehow attracted to Kanako, just as she likes me.
[cpg]

It's a little bit horrifying ...... even though I don't know that much about Kanako.
[cpg]

Yes, I know very little about Kanako.
[cpg]

I don't want to know that much about her, but I still have my concerns.
[cpg]

If she died suddenly one day, I would feel bad about it.
[cpg]

As for that guy, it's easy to imagine him dying suddenly, so I worry about him even more.
[cpg]


;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I also saw her in my dream that day.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************

[OnName num="keiichi"]
"...... huh, he even appears in my dreams, this guy ......."
[cpg cn=true]

I vividly recall Kanako's innocent smile of ah-ha-ha. I'm not her lover, but I'm not crazy about her.
[cpg]

But infatuation is written as being in a dream, isn't it? I thought to myself, "No, no, no, what am I thinking?
[cpg]

No, no, no, what am I thinking? If I were to admit that I was crazy about her, there would be no end to it.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************


I tried to shake Kanako out of my head, but it didn't ...... go so well.
[cpg]

Yes, it would be nice if we could just contact each other once in a while. I just worry about whether she's alive or dead, that's all.
[cpg]

It's not like I'm on a long phone call with my girlfriend. There is nothing to be ashamed of.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（夜）******************************************************


So, on my way home from work, I made a phone call.
[cpg]

[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1500]
[WAIT time=2500]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[OnName num="keiichi"]
"Hello, is this Kanako?"
[cpg cn=true]


[VOICE f="Kanako170"]
[OnName num="kanako"]
Yes, this is Kanako. Can I help you?
[cpg cn=true]

[OnName num="keiichi"]
No, nothing. Nothing, I was just wondering if you went home after that.
[cpg cn=true]

Oh no. I didn't have a topic in mind, so I said something strange.
[cpg]

I was not prepared for the topic and I said something weird. She was so annoying.
[cpg]


[VOICE f="Kanako171"]
[OnName num="kanako"]
No, I mean, ha ha. You sound like your father."
[cpg cn=true]

[OnName num="keiichi"]
I'm sorry, ....... I'm worried about you.
[cpg cn=true]

He says, "Thanks," but still smiles at me. I was getting pissed off, and I said, "I'm glad you're alive,
[cpg]

[OnName num="keiichi"]
"I'm glad you're alive. See you later."
[cpg cn=true]

[SE f="se035"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー

[free time=1000]
[WAIT time=1000]

I hung up the phone. I don't know why I called him.
[cpg]

I really don't know why I called. It hadn't been that long since we last saw each other, even if it was just to check if he was still alive or not.
[cpg]

What was wrong with me. ......
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]


From that point on, I continued to call Kanako's place whenever a few days passed.
[cpg]

I was glad that she was someone who would take my calls for no particular reason, but I didn't know myself anymore.
[cpg]




[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************


[VOICE f="Kanako172"]
[OnName num="kanako"]
She's been calling me a lot lately, hasn't she?
[cpg cn=true]

[OnName num="keiichi"]
Yeah, well.
[cpg cn=true]

I know, I know, that I'm not exactly calm either.
[cpg]


[VOICE f="Kanako173"]
[OnName num="kanako"]
Have you grown fond of me, by any chance?
[cpg cn=true]

[OnName num="keiichi"]
No, I'm not. I'm just worried about your reckless nature.
[cpg cn=true]

But I can tell you this. I'm just worried about Kanako.
[cpg]

[OnName num="keiichi"]
If one day you suddenly become a corpse, it would not be good for me either.
[cpg cn=true]

Kanako laughs while saying, "What's that? I'm just worried about Kanako.
[cpg]

I say this as if it were possible enough, but Kanako is optimistic to no end.
[cpg]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


The next day after we made an appointment to meet again.
[cpg]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=3000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************

The next day, the weather was surprisingly fine and the sun was shining brightly.
[cpg]

I had never felt the dazzling sunrise before.
[cpg]

It was only after I started seeing Kanako that I began to notice the changes in her daily life.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『空』（夕方）******************************************************

And the normal daylight hours passed in a flash, and the sun was already setting.
[cpg]

I went about my business, wondering if Kanako would be finished with school by now .......
[cpg]


[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=3000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=200]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『公園』（夜）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

Kanako had arrived at the park earlier. She was sitting on a bench, so I went to sit next to her.
[cpg]

[OnName num="keiichi"]
Can I sit next to you?"
[cpg cn=true]

She gave me a miffed look before I could respond with the words, "You're late, Keiichi-san.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kanako174"]
[OnName num="kanako"]
You're late, Keiichi.
[cpg cn=true]

[OnName num="keiichi"]
You're here too early, you're earlier than we agreed.
[cpg cn=true]

I can imagine that this guy's personality is loose with time by nature.
[cpg]

I can imagine that he wants to see me as soon as possible to overcome that.
[cpg]

[OnName num="keiichi"]
I'm sorry, but I didn't come here today for a date.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

Kanako said, "What? She looked utterly just astonished. And after that, she starts to complain.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kanako175"]
[OnName num="kanako"]
She said, "Oh, no, we're spending our precious time here.
[cpg cn=true]

[OnName num="keiichi"]
I said, "It's not that valuable. ...... You're a student, aren't you?"
[cpg cn=true]

I don't mean that. I'm not here to talk about that.
[cpg]

[OnName num="keiichi"]
No, let's get down to business. That's why I brought you here today. Listen to me seriously.
[cpg cn=true]

Kanako looks at me, saying, "Yes, yes. I'm not taller than you, so I have to look up at you a little.
[cpg]

[OnName num="keiichi"]
Are you going to stay that way forever?　That's what I've called you here today to find out.
[cpg cn=true]

[OnName num="keiichi"]
If you keep on like that, you're going to get seriously hurt someday. It's too late to get hurt.
[cpg cn=true]

The eyes that looked up at her gradually became more and more sober,...... and finally Kanako sighed.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kanako176"]
[OnName num="kanako"]
I'm sorry," he said. Then I'll charge you extra."
[cpg cn=true]

This guy is not greedy. So, it's not that he wants money, he's just using it as a reason to say no. But, unfortunately, we have to pay for it.
[cpg]

Unfortunately, we have too much money. That's too bad. That's no reason to say no.
[cpg]

[OnName num="keiichi"]
I don't care. Listen to me seriously. Also, turn around and look at me.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]

Kanako says, "Yes, yes," and turns her eyes this way. She said, "Yes, yes," and turned her eyes toward me, one tone lower than the "Yes, yes," she had said earlier.
[cpg]

;//ＢＫ

;//●ＣＧ（可南子・しゃがむヒロイン。誘ってる感じ：公園）ev_45
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_45_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

And then she crouched down right next to me.
[cpg]

[OnName num="keiichi"]
She said, "......, what are you trying to do?
[cpg cn=true]


[VOICE f="Kanako177"]
[OnName num="kanako"]
I don't care. I'm cute, aren't I?
[cpg cn=true]


I wanted to say the same thing again, but decided not to.
[cpg]

[VOICE f="Kanako178"]
[OnName num="kanako"]
I wanted to say the same thing again, but I didn't. "Will you forgive me for being so cute?"
[cpg cn=true]


I told you that's what I'm worried about. ......
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************

[OnName num="keiichi"]
I'm not going to say it again. You better understand what kind of person you are."
[cpg cn=true]

Kanako says, "Yes," and sits on the bench while flapping her legs. I'm not listening to you at all.
[cpg]

[OnName num="keiichi"]
"Listen to me, ......."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kanako179"]
[OnName num="kanako"]
I'm listening to you. I'm listening to you. You really don't need to worry about me.
[cpg cn=true]

[OnName num="keiichi"]
If you had listened properly, you wouldn't have come to that conclusion.
[cpg cn=true]

Ummm...and laugh. How can you laugh there? That's the part that makes me want to torment you.
[cpg]

[OnName num="keiichi"]
I think the worst that can happen is that you die. Is that what you want?
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kanako180"]
[OnName num="kanako"]
Even if that happens, Keiichi-san doesn't need your help.
[cpg cn=true]

He added, "At that time, it's all my own fault. Sure, that's true, but ......
[cpg]

[OnName num="keiichi"]
I couldn't just say, "Well, you can't just say that I don't have to worry about it because I deserved it."
[cpg cn=true]

I said to myself and thought, Huh? Why?
[cpg]

When he says don't worry about it, he deserves it, and you're worried about it, it's not just worry.
[cpg]

[OnName num="keiichi"]
...... I see."
[cpg cn=true]

Kanako looked at me curiously as I muttered to myself. Of course it's strange, I wonder about myself too.
[cpg]

I've noticed a kind of attachment that is less than affection. No, I might say it's affection.
[cpg]

I can't help but feel for this guy. This is something close to love, if not love: ......
[cpg]

I think it's something close to love. I found myself tempted to scream out.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kanako181"]
[OnName num="kanako"]
"What's the matter, your eyes are all black and white."
[cpg cn=true]

[OnName num="keiichi"]
No, it's nothing. ......
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

[FACE method="change_1" pos="2/3"]
[VOICE f="Kanako182"]
[OnName num="kanako"]
I'll see you later. I'll come by anytime.
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』


[free time=1000]
[WAIT time=1000]

She waved and left. So that's what I'm worried about,......, I said goodbye without saying a word.
[cpg]


But still, I never thought I'd get attached to someone. I've never been attached to anything, not even things.
[cpg]

[OnName num="keiichi"]
What is wrong with me, ......?
[cpg cn=true]

It's embarrassing to talk to myself like this. I was so full of Kanako that I could not stop thinking about her.
[cpg]

I think it's because I was an empty person to begin with that my head fills up so quickly. I like to think so.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

[SE f="se001"]
;//【ＳＥ】『ベッドに倒れる』

I went home and collapsed on my bed without changing my clothes. I lay on my back.
[cpg]

I had to organize my thoughts. I wondered if I liked Kanako or not.
[cpg]

I think Kanako is an attractive girl, but when asked if I like her, I can't say I like her to her face.
[cpg]

I can't say I like her to her face, which proves that I like her even more.
[cpg]

I feel like I'm losing if I admit it. Because, you know, he's such-and-such a guy.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************

It was a little past the time when those days of feeling grounded had passed.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夕方）******************************************************

[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[WAIT time=1500]


One day on a holiday. Kanako called me.
[cpg]

[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[OnName num="keiichi"]
Kanako called me. What's wrong?
[cpg cn=true]


[VOICE f="Kanako183"]
[OnName num="kanako"]
I'm sorry. I'm sorry to call you so suddenly.
[cpg cn=true]

She sounded unusually timid. I felt that what she was saying was also a bit weak.
[cpg]

My first thought was whether this guy was the type to feel guilty about calling suddenly.
[cpg]

It's not just something. I could tell by just one word.
[cpg]

[OnName num="keiichi"]
I said to him, "...... what's going on?　Why do you sound like that?"
[cpg cn=true]


[VOICE f="Kanako184"]
[OnName num="kanako"]
Uh, uh, ......, um, can I see you today?"
[cpg cn=true]


[OnName num="keiichi"]
"What's wrong?　You need money?"
[cpg cn=true]

I fell silent for a moment. That's probably what he meant.
[cpg]

The fact that Kanako, who had never been a money-hungry person, was suddenly asking for money, it was something out of the ordinary.
[cpg]

I remained silent, but my worry grew and grew in my heart. And Kanako, on the other end of the line, was also silent.
[cpg]


[VOICE f="Kanako185"]
[OnName num="kanako"]
Yes, well. But don't worry about Keiichi-san.
[cpg cn=true]

Something must have happened. But Kanako did not say anything more.
[cpg]

I felt that I had to meet her and talk to her before I could start. I felt that way.
[cpg]

[OnName num="keiichi"]
If you want to meet me right now, I'll be available. What do you think?
[cpg cn=true]

Kanako answered, "Yes. We then decided on a time and place to meet.
[cpg]

Kanako's voice was somber all the while.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夕方）******************************************************


[VOICE f="Kanako186"]
[OnName num="kanako"]
She said, "......, hello. Keiichi-san."
[cpg cn=true]

Kanako, whom I hadn't seen in a long time, looked pale.
[cpg]

It's not so much that he's worn out physically, but something is draining him mentally. It looks like that.
[cpg]

[OnName num="keiichi"]
Ah, ah ......."
[cpg cn=true]

What's more, her expression lacked its usual brightness.
[cpg]

I was a bit at a loss for words at the expression on Kanako's face, which I had never seen before.
[cpg]

[OnName num="keiichi"]
Really, what's wrong?　Are you okay?"
[cpg cn=true]

She didn't answer properly. And then I went to ......
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kanako187"]
[OnName num="kanako"]
...... take me to your room?"
[cpg cn=true]


I said.
[cpg]


;//ＢＫ

;//●ＣＧ（可南子・ベッドに横たわるヒロイン：主人公の部屋）ev_47
[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_47_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

She sat down on the bed, looking tired.
[cpg]

And then she just laid down.
[cpg]

[OnName num="keiichi"]
Hey, I'm here. That's not very nice."
[cpg cn=true]


But she didn't change her expression.
[cpg]

It was more than just the usual "she's not my girlfriend.
[cpg]


;//●ＣＧ（可南子・ベッドに横たわるヒロイン：主人公の部屋）ev_49
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_49_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


;//移植のためシーンをカットしています

[OnName num="keiichi"]
She said, "......, what are you doing?　You need the money that bad?
[cpg cn=true]

[VOICE f="Kanako188"]
[OnName num="kanako"]
Yes. ......
[cpg cn=true]

It doesn't look like Kanako now. It shows in her appearance.
[cpg]

She is pale and looks more emaciated than before.
[cpg]

[OnName num="keiichi"]
I don't have a choice. You want something, I'll buy it for you, just get up."
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_rl"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

A little while later, as she was leaving.
[cpg]

[OnName num="keiichi"]
'Well, call me if you need anything. Bye."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kanako189"]
[OnName num="kanako"]
'...... yes.'
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

[free time=1000]
[WAIT time=1000]

There was a pause in her reply. I knew she was still concerned about me.
[cpg]

Or rather, they are trying to hide something. Are you trying not to bother me?
[cpg]

You were saying sometime ago that you deserved everything that happened to you, or is that what you're talking about?
[cpg]

I thought as I looked over at Kanako, who had turned her back on me and was gradually becoming smaller and smaller.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

For now, I had no choice but to find out what had happened to Kanako. But there is no way to find out.
[cpg]

Kanako knows where I live, but I don't know where she lives.
[cpg]

Even if I knew where she lived, I couldn't follow her. I think it is a little more sinful for a man to follow a woman than the other way around.
[cpg]

[OnName num="keiichi"]
I wonder what I should do about ......."
[cpg cn=true]

At any rate, I decided to go to bed that day without worrying too much.
[cpg]

I knew I was worrying a little too much, so I decided to leave it for a day to cool off.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

In the meantime, things might be resolved on Kanako's side or something. ......
[cpg]

Of course, it could be the other way around, but I pushed all that worry away and went to sleep.
[cpg]

[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************

And after a day passed, as I imagined, I regained some composure and began to have an idea of Kanako's situation.
[cpg]

I'm worried that she's going to get seriously hurt ...... like that, and that "serious injury" is happening right now.
[cpg]

It seems plausible enough. And then, after a day of waiting, I came up with a way to confirm the truth.
[cpg]

[OnName num="keiichi"]
I guess I slept too long."
[cpg cn=true]

But since that was impossible right now, I decided to go to work as usual.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社内』（昼）******************************************************

It doesn't have to be so grandiose as to confirm the truth.
[cpg]

If he didn't want to tell me, he could ask someone else. That was all there was to it.
[cpg]

Ayaka and Kanako were at the same school, but there was no point in asking Ayaka.
[cpg]

As I recall, they did not have that much contact with each other. So, Mari?
[cpg]

It was even more improbable. Mari and Kanako had pretended to be strangers when they met in front of the house, as I recall.
[cpg]

If that was the case, the best thing to do would be to ask her. Even if I couldn't ask him directly, I could ask him over the phone.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『会社内』（夜）******************************************************

The sun was setting and the end of the workday was approaching.
[cpg]


[SE f="se001"]
;//【ＳＥ】『ドア閉まる』

[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************


It might be a long phone call. So I decided to call him after I returned home.
[cpg]

I couldn't call him in the morning because he was a student. I was sure they would be free at night, like now.
[cpg]


[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル

[OnName num="keiichi"]
......"
[cpg cn=true]

It took a little while for the person to answer. From the other party's point of view, I didn't know their phone number.
[cpg]

I had it one way or the other. So, there was a possibility that they would not answer. But then, I got a message from the person I was talking to,
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[VOICE f="Hana074"]
[OnName num="hana"]
"Who is ......?"
[cpg cn=true]

The person answered the phone. Kanako said it was her friend, Hana.
[cpg]

[OnName num="keiichi"]
It's Keiichi. It's been a long time, but you remember my name.
[cpg cn=true]

[VOICE f="Hana075"]
[OnName num="hana"]
Oh, that person ......!
[cpg cn=true]

He seemed to have remembered me, although he called me "that person.
[cpg]

The other side is blatantly dismayed, but that's not important right now. I'm not asking you to do anything wrong.
[cpg]

[OnName num="keiichi"]
I'm sure you're a friend of Kanako's, right? I want to ask you something about Kanako.
[cpg cn=true]

On the other end of the phone, a confused Hana kept repeating, "Well," "Well," "Well," and so on.
[cpg]

[OnName num="keiichi"]
You know Kanako is depressed right now, right?
[cpg cn=true]

[OnName num="keiichi"]
No, it's not that she's depressed, it's more like she's in a hurry,...... whatever that is, it's just not normal."
[cpg cn=true]


[VOICE f="Hana076"]
[OnName num="hana"]
Yes, yes,...... I know that, but...
[cpg cn=true]

[OnName num="keiichi"]
I know that, but do you know anything about why he's the way he is?　If you know something, I'd like to hear it.
[cpg cn=true]

I don't expect you to answer these questions out of the blue.
[cpg]

But I can't afford to take the time to let my guard down to the point where I can talk with flowers about anything.
[cpg]

Then I thought it would be better to state my purpose first. Maybe I'm a little too hasty, though.
[cpg]

[OnName num="keiichi"]
If you're a friend of mine, you might have asked me for advice. If you need anything, you can contact me at ......."
[cpg cn=true]


[VOICE f="Hana077"]
[OnName num="hana"]
I said, "Yes, Kanako has talked to ...... me about it."
[cpg cn=true]

Then she said, "But," and fell silent.
[cpg]

I know Hana is not an aggressive person to begin with, but it was a little frustrating.
[cpg]

[OnName num="keiichi"]
I'll tell you what I'd like to know. Just tell me."
[cpg cn=true]


[VOICE f="Hana078"]
[OnName num="hana"]
But why do you want to know?
[cpg cn=true]

[OnName num="keiichi"]
It's ......."
[cpg cn=true]

That's right. Naturally, those questions come up. And that's something I haven't settled yet.
[cpg]

Why am I even doing this, worrying about Kanako? I've been asked things that I don't even know.
[cpg]

If I knew, I would want her to tell me.
[cpg]

[OnName num="keiichi"]
I said, "I can't talk about it at ...... right now. Still, please tell me."
[cpg cn=true]

Would he be convinced by such a way of talking? Normally, I would not.
[cpg]


[VOICE f="Hana079"]
[OnName num="hana"]
"If you can't talk, then neither can I."
[cpg cn=true]

And Hana was the closest to normal among the four girls I knew.
[cpg]

I have no doubt that Hana seems to know the truth to some extent. But, however ......
[cpg]

Hana continues. I don't know if I can talk to you without Kanako's permission.
[cpg]

In short, she seemed to be trying to figure out whether I was Kanako's friend or foe.
[cpg]

If I did not answer, I would not be able to move on. However, the answer was already decided.
[cpg]

There is nothing I can tell you if I answer that I am an enemy of Hana.
[cpg]

So, I have no choice but to say that I am an ally,.......
[cpg]


[OnName num="keiichi"]
I'm on Kanako's side, believe me.
[cpg cn=true]

It was not a convincing performance. It was a word that came from the bottom of my heart.
[cpg]

I had given myself the answer to the question that had been bothering me all this time, why I was worried about Kanako.
[cpg]

Because I am Kanako's ally. Because I am on her side, I am worried about her.
[cpg]

[OnName num="keiichi"]
Please. I want to know what's going on with Kanako.
[cpg cn=true]


[VOICE f="Hana080"]
[OnName num="hana"]
"......, yes, I understand.
[cpg cn=true]

[OnName num="keiichi"]
Take your time. I've got time on my hands.
[cpg cn=true]

It's not that I don't have time. But if it's time for Kanako, I don't mind using it.
[cpg]

In fact, I'd like to use it actively. I was in such a mood, maybe a little too heroic.
[cpg]


[VOICE f="Hana081"]
[OnName num="hana"]
I'd say he's an acquaintance of Kanako's, or ...... a guy who's a ...... uh..."
[cpg cn=true]

I was at a loss for words, slowly. Suppressing my desire to know the truth as soon as possible, I wait for Hana to speak.
[cpg]

[OnName num="keiichi"]
You mean someone other than me?"
[cpg cn=true]

Yes," I answer. She didn't seem to know his name, so she called him "Mr. A" as a tentative name.
[cpg]


[VOICE f="Hana082"]
[OnName num="hana"]
I told that Mr. A the name of the school. ......
[cpg cn=true]

It was a defenseless story that was typical of Kanako.
[cpg]

She said that the man was nice to her, and the conversation got heated, so she told him her name, Kanako, and the name of the school she attended.
[cpg]

If you think about it calmly, it was a risky thing to do, but Kanako also said that she enjoyed the risk. It was not impossible.
[cpg]

[OnName num="keiichi"]
So what happened?　Kanako was threatened?
[cpg cn=true]


[VOICE f="Hana083"]
[OnName num="hana"]
Yes,......, I feel sorry for her, but I think she, too, was too vulnerable."
[cpg cn=true]

According to Hana, Kanako was threatened. She was told by this A that he would inform the school of the fact that she approached the man for a quid pro quo.
[cpg]

If that was found out, of course it would be bad. ......
[cpg]

At first glance, the threat seemed reasonable, but I also thought it was impossible, especially for Kanako.
[cpg]

[OnName num="keiichi"]
Kanako is afraid of such a thing?"
[cpg cn=true]

Yes," replies Hana. It's hard to imagine.
[cpg]

[OnName num="keiichi"]
Because she's not even a ...... serious student. If he is, I can't imagine it.
[cpg cn=true]


[VOICE f="Hana084"]
[OnName num="hana"]
Yes, it's surprising,......, but it's true.
[cpg cn=true]

The truth about Kanako was revealed from there, which was too unexpected.
[cpg]

Kanako said that she had approached the man in order to earn money for her school fees.
[cpg]

Kanako told her parents that it was a part-time job.
[cpg]

So, if she gets expelled from school, there is no way she can get back in. And Hana says: ......
[cpg]

[OnName num="keiichi"]
I'm still not convinced. First of all, is Kanako that kind of a serious person?"
[cpg cn=true]

Hana was silent for a moment, hesitated, and then said something like this.
[cpg]


[VOICE f="Hana085"]
[OnName num="hana"]
She has a serious nature, but she also has the opposite.
[cpg cn=true]

From there, Hana goes on to say some outrageous things. Kanako wants to reassure her parents that she is going to leave the school properly, or something.
[cpg]

[OnName num="keiichi"]
I don't ...... believe it."
[cpg cn=true]

It took me a long time to get this much out of her, because Hana chooses her words in various ways, as if she is trying not to spoil Kanako's impression.
[cpg]

But good. I got more out of it than the time I spent on it.
[cpg]

[OnName num="keiichi"]
I was able to get more out of him than the time I spent on him.
[cpg cn=true]

After I said it, I felt I had said something irresponsible. That changes the purpose of the call.
[cpg]

If I could do that, I would have done it already. He was Kanako's friend.
[cpg]

[OnName num="keiichi"]
I'm sorry. That was irresponsible of me.
[cpg cn=true]


[VOICE f="Hana086"]
[OnName num="hana"]
I'll try to do something about it.
[cpg cn=true]

I'm sorry, I'm irresponsible. What am I doing?
[cpg]

[OnName num="keiichi"]
I've got the gist of it. Leave the rest to me, and I will save Kanako.
[cpg cn=true]

I told Kanako's friend that I was on Kanako's side.
[cpg]


[SE f="se035"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー

[free time=1000]
[WAIT time=1000]

Now that I had said it, I had no choice but to take her side. With that in mind, I hung up the phone.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************

I couldn't sleep that night. It was as if I had become some kind of emotional person, but I had to admit it.
[cpg]

Compared to before, I had regained some of my emotions and conscience. Maybe it was because I wanted to save the girl, Kanako.
[cpg]

Then, I have no choice but to do it. I spent all night thinking about what I would do if I had no choice but to help her out.
[cpg]

Let's say, for example, that I called the police and told them that I had been threatened by this "A" guy.
[cpg]

This would result in some kind of punishment for A. It would be okay in terms of revenge, but it would not be enough.
[cpg]

He will take Kanako along with him. That's a no-brainer now, so he can't be expelled from school.
[cpg]

What else is there to do but go to ......A and beat him up?
[cpg]

The guy himself, when threatened in the opposite direction,...... no.
[cpg]

[OnName num="keiichi"]
"...... surprisingly, it might be a simple enough strategy."
[cpg cn=true]

I have one idea. But I can't do this on my own.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『住宅街』（夜）******************************************************


[OnName num="keiichi"]
I'm sorry about ....... Sorry for calling so late at night.
[cpg cn=true]


[VOICE f="Kanako190"]
[OnName num="kanako"]
No, ......, so what was it?
[cpg cn=true]

[OnName num="keiichi"]
You know that guy, Hana. No, I don't need to ask.
[cpg cn=true]

I could somehow feel Kanako on the other end of the phone getting a little nervous.
[cpg]

You are probably thinking that you have heard it all. And indeed, they have.
[cpg]

[OnName num="keiichi"]
You're a pretty serious guy, aren't you?
[cpg cn=true]

[OnName num="keiichi"]
I'm the complete opposite of your image. But I don't think of you as a saver, either.
[cpg cn=true]

[VOICE f="Kanako191"]
[OnName num="kanako"]
"...... I guess so."
[cpg cn=true]

I have to pretend to be a lightweight woman to get by,......," she said in a muffled voice.
[cpg]

[OnName num="keiichi"]
I've heard everything you have to say. I've heard everything you have to say. I'll help you.
[cpg cn=true]

[OnName num="keiichi"]
I didn't know anything about you, did I? I'm sorry I didn't try to get to know you before.
[cpg cn=true]


[VOICE f="Kanako192"]
[OnName num="kanako"]
What are you saying ......?"
[cpg cn=true]

I understand Kanako's question. I'm saying something that doesn't sound like me.
[cpg]

I've been pretending that I'm not interested in everything. There was a time when I actually wasn't interested, but from then on it was just "pretending.
[cpg]

I pretended I didn't like Kanako that much. I've come a long way, I think about it.
[cpg]

[OnName num="keiichi"]
If you just follow my lead, you'll probably be fine. It's not that risky an operation for you.
[cpg cn=true]



;//ＢＫ
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1000]


From there, he tells Kanako about his plan to save her.
[cpg]

It wasn't that grandiose, but Kanako listened with bated breath.
[cpg]



[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『住宅街』（夜）******************************************************

[OnName num="keiichi"]
He said, "How's ...... going?　Do you think it will work?"
[cpg cn=true]


[VOICE f="Kanako193"]
[OnName num="kanako"]
'...... really?　Are you saying you're going to help me?
[cpg cn=true]

[OnName num="keiichi"]
I don't want to see Kanako in such a weak state. I don't want to see ...... this weak Kanako, I don't want to hear it."
[cpg cn=true]

It's a toothless line. I could feel myself getting worked up.
[cpg]

[OnName num="keiichi"]
I'm going to help you, but I'm going to need your help, too. I'm going to need you to help me out, too.
[cpg cn=true]

I was relieved to hear a determined reply.
[cpg]

[OnName num="keiichi"]
Well, let me know if there are any further developments.
[cpg cn=true]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

The plan was simple. In layman's terms, I would just take a hidden picture.
[cpg]

The idea was to get the evidence of the threat first.
[cpg]


;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


That in itself went well. It was more Kanako's doing than mine.
[cpg]

But from there, it was my job.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hp"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************

My hands were sweating. Even for Kanako's sake, I was nervous.
[cpg]

I even felt as if someone was watching me. Even if I shook it off as my imagination, it still followed me around.
[cpg]

I learned for the first time on this day that people usually get upset when they are in the position of being threatened, but the person who threatens them also gets upset.
[cpg]

If that is the case, what I am going to do now should also work on the man A.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

Then, when I was about to burn the DVD and send it to A's address ......, I was in a bit of trouble.
[cpg]

[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=3000]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[OnName num="man"]
He said, "Hey, who are you? If this is a prank call, I'm hanging up. ......."
[cpg cn=true]

[OnName num="keiichi"]
Well, listen," he said. I'm filming everything you and Kanako are doing. I'm not lying.
[cpg cn=true]

I wasn't following her, so there was no way I could send it to her. I had not followed A, so there was no way I could send it to him.
[cpg]

[OnName num="keiichi"]
If you think I'm lying, open the locker I'm going to give you. The key is at ......."
[cpg cn=true]

It was a bit complicated, but it worked.
[cpg]

In fact, if I give it to them face to face, they might be upset. Besides, they need to be scared of my presence. I thought this was the best way.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


After all was said and done, I took a breath. I was exhausted from the whole process.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************

I went to ...... and a few days later.
[cpg]

The two of us met and looked at each other with a mysterious look on our faces. And gradually,
[cpg]


[BGM f="bg_rl"]


[OnName num="keiichi"]
"...... pfft, ha ha."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
They started to smile. I was so happy to see her smile, and she smiled.
[cpg]

[OnName num="keiichi"]
Surprisingly, it worked. Even with the wit of an amateur.
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kanako194"]
[OnName num="kanako"]
What do you mean by an amateur?　What do you mean by an amateur?
[cpg cn=true]

[OnName num="keiichi"]
No, I felt like a hero in a spy movie.
[cpg cn=true]

[OnName num="keiichi"]
I didn't know a simple businessman like me could do something like this.
[cpg cn=true]

I'm feeling so excited. What do you mean, "the hero of a spy movie"?
[cpg]

I know it's not something I'm supposed to say, but it's still coming out of my mouth.
[cpg]

That's how well everything went. The "A" man left her presence and Kanako was released.
[cpg]

[OnName num="keiichi"]
She said, "You should have praised me a little. "Hey, Kanako.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kanako195"]
[OnName num="kanako"]
As much as you want.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
Kanako smiled and bowed her head.
[cpg]

That's all there was to it, I thought, and she went on to say thank you in the most honest way imaginable.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Kanako196"]
[OnName num="kanako"]
Thank you, Keiichi-san. I will never forget this favor.
[cpg cn=true]

I like her honesty. But I think I did something that I have no choice but to thank her straight up like this.
[cpg]

I was able to save Kanako. I don't mind being told this much.
[cpg]

[OnName num="keiichi"]
I have a feeling you'll forget about it tomorrow.
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
Kanako shook her head.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kanako197"]
[OnName num="kanako"]
I won't forget. I'll never forget.
[cpg cn=true]

;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

;//ＢＫ
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1000]


She wanted to come to my room, and I didn't refuse.
[cpg]

I had no ulterior motive, I just wanted to be close to the person I love.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************


;//●ＣＧ（可南子・主人公の目覚めを待つヒロイン。嬉しそうな感じに表情を変えてください：主人公の部屋）ev_55
[window target=false]
;**【ＣＧ】 ev_55_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[OnName num="keiichi"]
......"
[cpg cn=true]

;//気づけば朝。隣で可南子はすやすや眠っている……かと思いきや、服まで着ていた。
It was morning before I realized it. I was so excited to see her.
[cpg]

[VOICE f="Kanako198"]
[OnName num="kanako"]
She had a cute sleeping face."
[cpg cn=true]


She said something embarrassing. But I was happy to spend time like this.
[cpg]


[VOICE f="Kanako199"]
[OnName num="kanako"]
Then, good luck with your work.
[cpg cn=true]

[OnName num="keiichi"]
"...... Today is a holiday, you know. You're losing your sense of the days of the week, aren't you?"
[cpg cn=true]

;//[window target=false]
;//[free time=1000]
;//[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=1000]
;//[BG f="b_03_1.ui" time=1000]
;//[WAIT time=2000]
;//[window target=true]
;//[WAIT time=100]
;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************


Was I right?　Kanako said.
[cpg]

[OnName num="keiichi"]
I'm not going to say anything about it. You should go home today and take a good rest.
[cpg cn=true]

;//[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kanako200"]
[OnName num="kanako"]
"Heh heh. Yes.
[cpg cn=true]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]



From there, no drastic change occurred.
[cpg]


[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（朝）******************************************************

[OnName num="keiichi"]
He said, "Well, ......, it's been quite a long call. Shall I go now?
[cpg cn=true]


[VOICE f="Kanako201"]
[OnName num="kanako"]
"No, I hope you don't mind my phone bill.
[cpg cn=true]

I don't mean that we suddenly became lovers and went on dates every holiday.
[cpg]

However, Kanako started calling me more and more often like this.
[cpg]

[OnName num="keiichi"]
'Well, then, I guess I'll leave it out of it.'
[cpg cn=true]

And here is the biggest change.
[cpg]


[VOICE f="Kanako202"]
[OnName num="kanako"]
'Yes, I do. To your future wife, don't worry about it."
[cpg cn=true]

Every holiday, we would meet up and go on a series of dates.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（（夜）******************************************************

Before going to sleep, we sit on the bed and talk. We talk about nothing, until we get tired of talking about nothing.
[cpg]

[OnName num="keiichi"]
You're a serious student, aren't you? Can I stay over?
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kanako203"]
[OnName num="kanako"]
Yes, well. Yes, well, I am serious, but I am also serious in love.
[cpg cn=true]

[OnName num="keiichi"]
I don't believe either of them. ......
[cpg cn=true]

And you're serious in love, so you're staying over?　I don't know what's going on.
[cpg]

[OnName num="keiichi"]
Where did you fall in love with me?
[cpg cn=true]

I had a pretty good idea about this, too, but Kanako explains that the deciding factor was when she pulled him away from that guy.
[cpg]

[OnName num="keiichi"]
'I was in a heroic mood then, too, so that wasn't the real you.
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kanako204"]
[OnName num="kanako"]
Really?　I, I think that was my true nature.'
[cpg cn=true]

[OnName num="keiichi"]
'Don't embarrass me, .......'
[cpg cn=true]

The conversation continued throughout the night.
[cpg]

I talked to Kanako and listened to her words as if I was regaining something I had lost.
[cpg]

[OnName num="keiichi"]
I listened to Kanako's words. "You're serious about getting married, aren't you?"
[cpg cn=true]

Kanako frowned at me. I didn't mean it that way.
[cpg]

[OnName num="keiichi"]
No, I mean I'm serious. I just want to know if you are serious.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kanako205"]
[OnName num="kanako"]
I've saved up some money for our wedding, you know.
[cpg cn=true]

[OnName num="keiichi"]
That's my money, right? ......?　That's crazy, you .......
[cpg cn=true]

I'm me, and I've just said something that's too late. If I'm going to say this, I can say it earlier.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Kanako206"]
[OnName num="kanako"]
"Didn't you know?"
[cpg cn=true]

Right? That's what I'm talking about.
[cpg]

I liked this guy because he was crazy. I can't say I didn't know that.
[cpg]

[OnName num="keiichi"]
No, I knew it. I like him for that, too.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Kanako207"]
[OnName num="kanako"]
Right?
[cpg cn=true]

I don't know how to put it, but I guess that's just like Kanako.
[cpg]

;//ＢＫ

To the world, it might seem that the woman he fell in love with was a terrible cheater.
[cpg]

But it's not like that. It's not like that.
[cpg]

;//俺は、こいつがビッチであるところも含めて好きになったんだ。
I fell in love with this guy, including his personality.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kanako208"]
[OnName num="kanako"]
I see. I also fell in love with Keiichi because he is Keiichi.
[cpg cn=true]

You know how to make a man happy, don't you?
[cpg]

[OnName num="keiichi"]
I'm sure we'll get along well. I don't know much about women, and you know everything about men.
[cpg cn=true]

I've heard it said the other way around, but I think it should be the other way around, too.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kanako209"]
[OnName num="kanako"]
No, Keiichi-san will get to know me, the woman.
[cpg cn=true]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

Oh, that's right. ...... I see what you mean.
[cpg]

I'll go along with you to the end, as you wish. I'm going to stay with you until the end.
[cpg]

[SCENE id=11]

[jump storage="epend.ks" target="*start"]
;//【可南子ルート】ハッピーエンド
;////////////////////////////////////////////////////////////////////////
