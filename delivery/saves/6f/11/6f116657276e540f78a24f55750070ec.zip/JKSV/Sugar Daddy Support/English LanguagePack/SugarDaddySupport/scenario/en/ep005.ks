;//１、彩華

*start|Ayaka Putting On a Show

;#################################################
*Ep005|Ayaka Putting On a Show
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************


*root_ayaka|Ayaka Putting On a Show

[SCENE id=5]

[SE f="se011"]
;//【ＳＥ】『携帯電話の呼び出し音』プルルル

I make my decision and make the call. The ringing echoes in the silence.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[VOICE f="Ayaka056"]
[OnName num="ayaka"]
"......Keiichi. Is this the first time you've called me?"
[cpg cn=true]

I didn't have to wait long for her to answer.
[cpg]

[OnName num="keiichi"]
"Yeah. I wanted to see you."
[cpg cn=true]


[VOICE f="Ayaka057"]
[OnName num="ayaka"]
"I'm not available right now, so I'll talk to you later."
[cpg cn=true]

I couldn't see her facial expression because I was on the phone. But she still sounded somewhat light-hearted.
[cpg]

[OnName num="keiichi"]
"Are you with someone else?"
[cpg cn=true]


[VOICE f="Ayaka058"]
[OnName num="ayaka"]
"No. I'm in the bathtub."
[cpg cn=true]

Right. I couldn't imagine it, but I guess she has her own routine.
[cpg]

[OnName num="keiichi"]
"So, let's set a time and place for our next meeting. When would be good for you?"
[cpg cn=true]

We set a time and place for our next date.
[cpg]

Then, after that......
[cpg]

[VOICE f="Ayaka059"]
[OnName num="ayaka"]
"Are you busy right now?"
[cpg cn=true]

[OnName num="keiichi"]
"No, not really."
[cpg cn=true]


[VOICE f="Ayaka060"]
[OnName num="ayaka"]
"Hold on, I didn't mean it like that. Can we talk?"
[cpg cn=true]

I guess she wanted to talk to me a little longer.
[cpg]

I think this might have happened before, that she wanted to talk more with me.
[cpg]


;//ＢＫ

Ayaka's starts complaining about school, often coming back to her teachers and classes.
[cpg]

Then it was about TV or whatever, a topic I couldn't keep up with at all. I refused to listen since I couldn't follow her.
[cpg]

But I noticed during the conversation, not a single mention of friendship came up.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************


[VOICE f="Ayaka061"]
[OnName num="ayaka"]
"I'm sorry, I didn't mean to make you stay on the phone so long."
[cpg cn=true]

[OnName num="keiichi"]
"That was a surprise. I made the call, so I'm deducting the cost of the call from your next payment."
[cpg cn=true]


[VOICE f="Ayaka062"]
[OnName num="ayaka"]
"Ha ha, give me a break."
[cpg cn=true]

She said with a laugh. Really, all I had to do was listen to her.
[cpg]




[SE f="se035"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I turn off the lights and close my eyes. I have a hard time falling asleep.
[cpg]

The night passes without me being able to fall asleep.
[cpg]

The day of the meeting with Ayaka.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************

I was a bit sleepy that morning. If I couldn't sleep because of excitement, it would be childlike and embarrassing.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

Then I walked down the street as usual.
[cpg]

My mind was empty, and I felt a little bit of buoyancy in the midst of the emptiness.
[cpg]

Instead of heading to the meeting place immediately after work, I went home once. But then......
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************

[FACE method="shake_3" pos="2/3"]
[VOICE f="Ayaka063"]
[OnName num="ayaka"]
"You're late."
[cpg cn=true]

[OnName num="keiichi"]
"I'm sorry."
[cpg cn=true]

;//移植のためシーンをカットしています


[FACE method="bow_1" pos="2/3"]
[VOICE f="Ayaka064"]
[OnName num="ayaka"]
"I don't mind. Your gift better be exciting."
[cpg cn=true]


......Of course. This was the extent of our relationship.
[cpg]

But there is a sense that it's not enough.
[cpg]

If I told her how I felt, she probably won't accept my feelings.
[cpg]

So what should I do?
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

And from there, similar things continued for a while.
[cpg]

I was in a different state of mind, but I don't think she realized it.
[cpg]

Then one day, after repeating such days.
[cpg]



[FADEOUTBGM]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=3000]

[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************



[OnName num="keiichi"]
"......Who's that, so early in the morning?"
[cpg cn=true]

Before I left for work, I received a call from someone early in the morning. I looked at the display and saw that it was Kanako.
[cpg]

[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se



[VOICE f="Kanako088"]
[OnName num="kanako"]
"Good morning."
[cpg cn=true]

[OnName num="keiichi"]
"What do you want? This better be good."
[cpg cn=true]


[VOICE f="Kanako089"]
[OnName num="kanako"]
"Well, well, well, I won't take up too much of your time."
[cpg cn=true]

But really, what was she calling about? I don't care what time of the day it is, I haven't seen her for a while, so what was there to talk about?
[cpg]

Maybe it was about that? About the fact that we hadn't seen each other recently. 
[cpg]


[VOICE f="Kanako090"]
[OnName num="kanako"]
"I heard that you and Ayaka are getting along well."
[cpg cn=true]

That's not what I was imagining. What's that supposed to mean?
[cpg]

[OnName num="keiichi"]
"Yeah...... what about it?'
[cpg cn=true]


[VOICE f="Kanako091"]
[OnName num="kanako"]
"It's fine. But, why won't you hang out with me?"
[cpg cn=true]

I was right. It was just a different approach.
[cpg]

[OnName num="keiichi"]
"I don't know what to tell you."
[cpg cn=true]

Kanako and Ayaka may look alike, but they are completely different.
[cpg]

[OnName num="keiichi"]
"So, what? You called me because you want me to pay attention to you?"
[cpg cn=true]

[VOICE f="Kanako092"]
[OnName num="kanako"]
"You're acting very cold. It sounds like you're not interested in me anymore."
[cpg cn=true]

[OnName num="keiichi"]
"Well..."
[cpg cn=true]

Kanako seemed angry over the phone. She says she'll do anything......
[cpg]

She doesn't seem to understand that it was rather counterproductive.
[cpg]

[OnName num="keiichi"]
"You have no modesty, do you?"
[cpg cn=true]

I thought I had said something obvious while saying my thoughts out loud. 
[cpg]


[VOICE f="Kanako093"]
[OnName num="kanako"]
"Then what should I do?"
[cpg cn=true]

I thought for a......moment about what to do, and then it hit me.
[cpg]

[OnName num="keiichi"]
"Fine, then tell me what you know about Ayaka."
[cpg cn=true]

Kanako lets out a loud sigh. I wonder if I said something that would make her sigh.
[cpg]


[VOICE f="Kanako094"]
[OnName num="kanako"]
"You're that into her......"
[cpg cn=true]

She was whispering, but I could hear her perfectly, so I answered her.
[cpg]

[OnName num="keiichi"]
"You're into me, too, aren't you?"
[cpg cn=true]


[VOICE f="Kanako095"]
[OnName num="kanako"]
"I just miss you."
[cpg cn=true]

How was that different......No, let's not get into that.
[cpg]

[OnName num="keiichi"]
"So? Tell me about Ayaka."
[cpg cn=true]

Kanako groans. Come to think of it, Kanako and Ayaka don't know each other that well.  
[cpg]


[VOICE f="Kanako096"]
[OnName num="kanako"]
"I don't know much, so don't expect anything earth shattering."
[cpg cn=true]

[OnName num="keiichi"]
"That's fine."
[cpg cn=true]

Kanako lists off what she knew about Ayaka.
[cpg]

[VOICE f="Kanako097"]
[OnName num="kanako"]
"She is a vain person."
[cpg cn=true]

[OnName num="keiichi"]
"What?"
[cpg cn=true]


[VOICE f="Kanako098"]
[OnName num="kanako"]
"She's vain when it comes to her friends."
[cpg cn=true]

It's not that I can't imagine it, it's more that I think it's a lie.
[cpg]

[OnName num="keiichi"]
"You're kidding, right? That light-hearted girl?"
[cpg cn=true]


[VOICE f="Kanako099"]
[OnName num="kanako"]
"Yeah. She's the kind of girl who keeps his friendships alive by having money."
[cpg cn=true]

I didn't know. But it kind of makes sense when you think about it.
[cpg]

I remember her saying something about needing money to keep up with her friendships.
[cpg]

[OnName num="keiichi"]
"Why is she so vain? Does she have a reason or something?"
[cpg cn=true]

Kanako grunted once again. Then she gave me her own interpretation.
[cpg]


[VOICE f="Kanako100"]
[OnName num="kanako"]
"Her family is super rich."
[cpg cn=true]

It's not that I can't imagine it, but I thought it was a lie......
[cpg]

[OnName num="keiichi"]
"That can't be true, she doesn't act like it."
[cpg cn=true]


[VOICE f="Kanako101"]
[OnName num="kanako"]
"Well her parents are rich."
[cpg cn=true]

Her character and mannerisms didn't imply that she was from a rich family. It was a little hard to believe.
[cpg]

[OnName num="keiichi"]
"Really......? Then why won't she just leave me alone?"
[cpg cn=true]


[VOICE f="Kanako102"]
[OnName num="kanako"]
"She professes to be rich, but she has no money."
[cpg cn=true]

This was getting confusing. And on top of that, she's vain?
[cpg]

[OnName num="keiichi"]
"So you mean......she's rich but only has a small allowance."
[cpg cn=true]

As I put it into words, everything connects, although in a rather mysterious way.
[cpg]


[VOICE f="Kanako103"]
[OnName num="kanako"]
"Pretty much."
[cpg cn=true]

[OnName num="keiichi"]
"......Rich huh? Then, she must have a very strict curfew."
[cpg cn=true]


[VOICE f="Kanako104"]
[OnName num="kanako"]
"I don't know. I'm sure there's a lot going on."
[cpg cn=true]

I think she also mentioned that her parents wouldn't allow her to work a part-time job or give her an allowance.
[cpg]

I'm starting to feel like she's being raised in a very particular way. I can't even imagine what kind of parents they are.
[cpg]


[VOICE f="Kanako105"]
[OnName num="kanako"]
"But more importantly, you're going to meet me, right?"
[cpg cn=true]

[OnName num="keiichi"]
"Why?"
[cpg cn=true]


[VOICE f="Kanako106"]
[OnName num="kanako"]
"That's what you promised!"
[cpg cn=true]



I didn't have much time before I had to leave for work. I had no choice but to make an appointment to meet with Kanako.
[cpg]

[OnName num="keiichi"]
"In return, will you bring Ayaka with you?"
[cpg cn=true]


[VOICE f="Kanako107"]
[OnName num="kanako"]
"Easy peasy."
[cpg cn=true]

[OnName num="keiichi"]
"Then, it's decided. I'm hanging up now."
[cpg cn=true]


[SE f="se035"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

And then, around the time night fell. I was waiting for them at the meeting place.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

[free time=1000]
[FG f="CHA01_p2_01_a.ui" method="change_4"  pos="4/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[WAIT time=1000]

[OnName num="keiichi"]
"Sorry to make you wait. But I'm sure you weren't bored, now that there are two of you."
[cpg cn=true]

[FACE method="bow_2" pos="2/5"]
[VOICE f="Kanako108"]
[OnName num="kanako"]
"Yes, of course. We are friends, aren't we?"
[cpg cn=true]

[FACE method="shock_5" pos="4/5"]
[VOICE f="Ayaka065"]
[OnName num="ayaka"]
"Yes ......yes."
[cpg cn=true]

Ayaka seems confused when Kanako calls her a friend.
[cpg]

I am sure Kanako has this kind of attitude toward everyone. Regardless of gender.
[cpg]

[OnName num="keiichi"]
"Don't react like that. I feel bad for Kanako."
[cpg cn=true]

Ayaka is silent. She seemed confused as usual.
[cpg]

I think they had some time to talk since I came a little late.
[cpg]

But it's hard to imagine them becoming friends during that short time.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************


;//移植のためシーンをカットしています

Then, at Ayaka's request, we decided to go to karaoke.
[cpg]

I don't sing. At my age, karaoke is a difficult thing to do.
[cpg]


;//●ＣＧ（彩華と可南子・寄り添う二人：カラオケ店室内）ev_16

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_15_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


However, just watching the two girls being friendly with each other was a treat for my eyes.
[cpg]

[VOICE f="Kanako109"]
[OnName num="kanako"]
"Your waist is so thin, isn't it?"
[cpg cn=true]


[VOICE f="Ayaka066"]
[OnName num="ayaka"]
"Stop it, stop it. That tickles."
[cpg cn=true]


[VOICE f="Kanako110"]
[OnName num="kanako"]
"So? Does it only tickle?"
[cpg cn=true]


Kanako was this type of person......
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

;//ブラックアウト


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

;**【ＣＧ】 ev_15_0 ***********************
[CG id=3 index=0 time=1]
;***************************************
[WAIT time=1]

[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



It was almost time to leave the room, and I felt that Ayaka and I had become closer......
[cpg]



;//[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/5" time=800]

Somehow Ayaka and Kanako had too. They had exchanged phone numbers earlier as well.
[cpg]

[OnName num="keiichi"]
"Wow you two seem close. Are you give up on me and go out with each other instead?"
[cpg cn=true]

;//[FG f="CHA01_p2_01_a.ui" method="change_6"  pos="4/5" time=800]
[VOICE f="Ayaka067"]
[OnName num="ayaka"]
"Oh, it's not love or anything like that......"
[cpg cn=true]

She trails off into mumbling, her expression a little softer than before.
[cpg]

I guess friends are the most important thing to her. That's why she is happy now that she has a new friend.
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/5" time=800]
[VOICE f="Kanako111"]
[OnName num="kanako"]
;//「私は愛が芽生えてますけど」
"I wouldn't mind."
[cpg cn=true]

[OnName num="keiichi"]
"......I'd be more surprised if you did."
[cpg cn=true]

But still, Ayaka is a difficult person to deal with. She was using money to stay close to her friends.
[cpg]

;//[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Kanako112"]
[OnName num="kanako"]
"Then, shall we go?"
[cpg cn=true]

[OnName num="keiichi"]
"Yeah."
[cpg cn=true]

Losing money meant losing friends, that's why she's afraid. Somehow, I'm beginning to understand her.
[cpg]


[SE f="se001"]
;//【ＳＥ】『ドア閉まる』


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="4/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************

[FACE method="bow_2" pos="4/5"]
[VOICE f="Ayaka068"]
[OnName num="ayaka"]
"So I'll see you then......"
[cpg cn=true]

[FACE method="bow_2" pos="2/5"]
[VOICE f="Kanako113"]
[OnName num="kanako"]
"Yeah. See you again somewhere."
[cpg cn=true]


[SE f="se001"]
;//【ＳＥ】『歩く』

[free time=1000]
[WAIT time=1000]



With that, the three of us parted. I took the familiar route home as usual.
[cpg]

......friends, huh? If I had a friend, I might have been different.
[cpg]

But if it sucked up all my money and I couldn't maintain it the moment it ran out, I wouldn't want friends.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************


From there, it was just the usual routine again for a while. Nothing much happened. Just the usual, empty days.
[cpg]

But that emptiness made me think of Ayaka.
[cpg]

Something is filling my heart. I don't know if it is good or bad for me.
[cpg]

I don't even know if it is good or bad for Ayaka or in the eyes of the world.
[cpg]

Either way, my life was starting to change.
[cpg]


;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[WAIT time=1000]

[OnName num="keiichi"]
"...... Ayaka?"
[cpg cn=true]


[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[VOICE f="Ayaka069"]
[OnName num="ayaka"]
"Sorry, I know it's late."
[cpg cn=true]

[OnName num="keiichi"]
"Since when do you apologize?"
[cpg cn=true]

I say that to her, meaning "Don't worry about it." Then Ayaka laughed a little.
[cpg]


[VOICE f="Ayaka070"]
[OnName num="ayaka"]
"I wanted to talk to you."
[cpg cn=true]

Right. So she didn't call me to ask me out or anything......"
[cpg]

[OnName num="keiichi"]
"You are asking me for advice. Why not someone else?"
[cpg cn=true]


[VOICE f="Ayaka071"]
[OnName num="ayaka"]
"Well, it could be but......please."
[cpg cn=true]

I couldn't say no. I don't want to distance myself from her.
[cpg]

[OnName num="keiichi"]
"All right. So, what do you want to talk about?"
[cpg cn=true]


[VOICE f="Ayaka072"]
[OnName num="ayaka"]
"It's about a friend of mine...... I'm not normal, am I?"
[cpg cn=true]

I don't understand what she means. I can understand that she is not normal, although not as weird as Kanako.
[cpg]

[OnName num="keiichi"]
"Explain it to me. I don't really understand."
[cpg cn=true]

Ayaka searched for the words. I have at least enough time to wait for her to say something.
[cpg]


[VOICE f="Ayaka073"]
[OnName num="ayaka"]
"It's getting...really expensive treating my friends to...things."
[cpg cn=true]

So that's what it was about. I guess she didn't really need advice then.
[cpg]

[OnName num="keiichi"]
"I think you've already answered your own question. You just said it's not normal."
[cpg cn=true]


[VOICE f="Ayaka074"]
[OnName num="ayaka"]
"......Yeah."
[cpg cn=true]

Her voice was dark. I think I may have never heard her sound so depressed.
[cpg]

I thought he was a light-hearted girl, but I didn't know he had this side to her.
[cpg]

[OnName num="keiichi"]
"If you already know, then I don't have anything to say."
[cpg cn=true]


[VOICE f="Ayaka075"]
[OnName num="ayaka"]
"Yeah. I have to stop being like this someday."
[cpg cn=true]

The situation was getting a bit tiresome. Was this exchange really necessary?
[cpg]

I was going to give her advice earlier, but this was less than that.
[cpg]

I wonder what I should do......
[cpg]


;//■選択肢
[switch]
[case "I'm going to hang up the phone."]
	[swap]
	[jump target="*select03_1"]
[case "I'm going to give her advice."]
	[swap]
	[jump target="*select03_2"]
[endswitch]
;//１、電話を切ろうとする
;//２、相談に乗る

;//==============================
;//１、電話を切ろうとする
*select03_1|Ayaka Putting On a Show
;//この選択の場合、彩華ハッピーエンドへの選択肢が無くなる
[stflag CHA01flag = 1]


[OnName num="keiichi"]
"I don't know. If you want to stop it, you can stop it right now."
[cpg cn=true]


[VOICE f="Ayaka076"]
[OnName num="ayaka"]
"Yes, but......"
[cpg cn=true]

She then stops. There was no point in taking the conversation any further.
[cpg]

[OnName num="keiichi"]
"I'm hanging up now. You can figure out the rest on your own."
[cpg cn=true]


[VOICE f="Ayaka077"]
[OnName num="ayaka"]
"Oh, wait."
[cpg cn=true]

[SE f="se034"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー

[free time=1000]
[WAIT time=1000]

I heard her say, but I hung up without paying attention to it.
[cpg]


[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

My phone began to ring again.
[cpg]


[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

I hung up once, but then there was another call ......She's a hard girl to deal with......
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[VOICE f="Ayaka078"]
[OnName num="ayaka"]
"You're terrible. I won't see you anymore if you keep doing that."
[cpg cn=true]

[OnName num="keiichi"]
"If that's what you've decided, then so be it."
[cpg cn=true]

Ayaka is at a loss for words again. After all, she herself doesn't seem to understand that this was what got me into this situation.
[cpg]

[jump target="*select03_3"]
;//==============================
;//２、相談に乗る
*select03_2|Ayaka Putting On a Show
[OnName num="keiichi"]
"I guess that's true."
[cpg cn=true]


[VOICE f="Ayaka079"]
[OnName num="ayaka"]
"So, what should I do......?"
[cpg cn=true]

It's a common story. Even if it's less than a consultation, it's something that gets sorted out as we talk.
[cpg]

If that's the case, I'm willing to listen for a while. But if she is just going to talk in circles, then that's a different story.
[cpg]


;//==============================
;//どちらを選択してもここに合流
*select03_3|Ayaka Putting On a Show


[VOICE f="Ayaka080"]
[OnName num="ayaka"]
"I don't have any strengths other than having money......"
[cpg cn=true]

[VOICE f="Ayaka081"]
[OnName num="ayaka"]
"I feel like if I lose my money, I'll lose my friends......"
[cpg cn=true]

That's also a difficult thing to deal with. I'm sure she must have a lot of anxiety every day.
[cpg]

[OnName num="keiichi"]
"It's useless to make friends like that. In fact, I wouldn't even call them friends."
[cpg cn=true]


[VOICE f="Ayaka082"]
[OnName num="ayaka"]
"......But it's lonely when I'm by myself."
[cpg cn=true]

...... I don't have the feeling of being lonely alone, so I can't sympathize with her. I can understand that this is not normal.
[cpg]

[OnName num="keiichi"]
"What's so wrong about being alone?"
[cpg cn=true]

Ayaka is silent for a while. I know it's not something she would want to admit, but that's what it sounds like to me.
[cpg]


[VOICE f="Ayaka083"]
[OnName num="ayaka"]
"You're right. I guess I have to take care of me."
[cpg cn=true]

[OnName num="keiichi"]
"Don't be so vague. I can't tell you what to do."
[cpg cn=true]

You're right, Ayaka said again. I feel like I was just being a witness as she was struggling on her own.
[cpg]

That's how much she's been thinking about it. Ayaka is Ayaka in how she pushes the topic, but I am also the one who is accepting the situation.
[cpg]

It seems that a strange relationship of trust, or rather a rather one-sided one......is forming.
[cpg]


[VOICE f="Ayaka084"]
[OnName num="ayaka"]
"It's not something you can just decide to change."
[cpg cn=true]

[OnName num="keiichi"]
"I don't understand that either. It sounds like an excuse for not changing."
[cpg cn=true]


[VOICE f="Ayaka085"]
[OnName num="ayaka"]
"Thank you ......"
[cpg cn=true]

Thank you? I thought I said something harsh, but she replied thank you.
[cpg]


[VOICE f="Ayaka086"]
[OnName num="ayaka"]
"You're so sweet, Keiichi."
[cpg cn=true]

[OnName num="keiichi"]
"I'm not sure we're seeing eye to eye......"
[cpg cn=true]

[OnName num="keiichi"]
"I meant to be stern. Am I being nice?"
[cpg cn=true]

Another little silence. Then Ayaka mumbles that I am kind. I was not sure if she could hear me or not.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

From there, it went on like that for a while. When I would say something stern and pressure her to make a decision, she would say something like "I know," or "Thank you."
[cpg]

I wonder if she pretends to be lighthearted and is indecisive in that way. Is that why she wants someone to push her?
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************


[VOICE f="Ayaka087"]
[OnName num="ayaka"]
"I've been talking too long, haven't I?"
[cpg cn=true]

[OnName num="keiichi"]
"I don't mind, but I guess you have to worry about your phone bill, huh?"
[cpg cn=true]


[VOICE f="Ayaka088"]
[OnName num="ayaka"]
"I usually get the money to pay for it from you."
[cpg cn=true]

Finally, her usual light-heartedness came out. I feel a little bit relieved.
[cpg]

[OnName num="keiichi"]
"Keep it up. It's not like you being so distressed."
[cpg cn=true]


[VOICE f="Ayaka089"]
[OnName num="ayaka"]
"Okay, I'll see you later then......"
[cpg cn=true]


[SE f="se035"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー
[free time=1000]
[WAIT time=1000]

And with that, I ended the call. I was starting to feel a little weird about it.
[cpg]

[OnName num="keiichi"]
"......What is this relationship?", I wondered.
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（朝）******************************************************

[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="keiichi"]
"......"
[cpg cn=true]

I rubbed my sleepy eyes. I didn't get much sleep last night.
[cpg]

Ayaka is not necessarily an empty person, but how can she fill up her void......
[cpg]

I've found myself thinking about Ayaka.
[cpg]

It's as if I'm not an empty person anymore. I have feelings, as if I'm more sensitive than other people.
[cpg]

Even the road to the office looks like a different scenery. The emptiness was being filled.
[cpg]

It is not given to me by Ayaka, but with Ayaka, the empty space is filling up.
[cpg]

It's not like me......If someone who knows me heard this thought, they would laugh.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then I continued to see Ayaka several times.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayaka090"]
[OnName num="ayaka"]
"Sorry to keep you waiting.
[cpg cn=true]

[OnName num="keiichi"]
"I wasn't waiting long."
[cpg cn=true]

Even if I hadn't been waiting for her, I don't think I would have said "I wasn't waiting for you."
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayaka091"]
[OnName num="ayaka"]
"Let's go, then."
[cpg cn=true]

[OnName num="keiichi"]
"Yeah......"
[cpg cn=true]


;//ＢＫ

[SE f="se001"]
;//【ＳＥ】『歩く』

;//移植のためシーンをカットしています
;//移植のためシーンをカットしています


I've been treating her nicely which was unimaginable.
[cpg]

If we are doing this, it's only a matter of time before we become lovers...... I think
[cpg]

But if we are just lovers, then that should be okay.
[cpg]

I don't know anymore. For a long time, I thought it was something I didn't need.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』


[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayaka092"]
[OnName num="ayaka"]
"I'll see you later then."
[cpg cn=true]

Then she waved at me as she turned away.
[cpg]

I turned around and waved again.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』
[free time=1000]
[WAIT time=1000]

...... This was serious. I didn't know what I would be told if Kanako or Mari see me.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

[SE f="se029"]
;//【ＳＥ】『ベッドに倒れる』ドサッ

[OnName num="keiichi"]
"......"
[cpg cn=true]

I went back home and fell into bed without changing into my pajamas. The ceiling, with its lights on, seemed awfully bright.
[cpg]

I could see clearly. I thought I could hear the hustle and bustle of the street on my way home more clearly than usual.
[cpg]

I can feel the haze that has been haunting me is clearing.
[cpg]

And I'm sure it's because my heart is being filled.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_hp"]
[WAIT time=100]

The days passed with mixed feelings.
[cpg]

After several days and nights that passed, Ayaka would call me once in a while and we would talk about trivial things.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=3000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『住宅街』（夜）******************************************************

And then, she called me again. It was about something more serious.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[WAIT time=2000]

[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

I pressed the call button and immediately knew Ayaka was not in a normal state of mind.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[VOICE f="Ayaka093"]
[OnName num="ayaka"]
"I need your help! My money!"
[cpg cn=true]

[OnName num="keiichi"]
"What's wrong, Ayaka?"
[cpg cn=true]

It sounded like she'd been robbed, but apparently that wasn't far from the truth.
[cpg]


[VOICE f="Ayaka094"]
[OnName num="ayaka"]
"The money. They found out where I was hiding it and took it all away!"
[cpg cn=true]

[OnName num="keiichi"]
"Wait, wait. Relax for a moment."
[cpg cn=true]

Her voice was shaking, and I was feeling disturbed. And I can't understand what she's saying in some moments.
[cpg]

[OnName num="keiichi"]
"I don't know what you're talking about. First, take a deep breath."
[cpg cn=true]

I manage to calm Ayaka down. As she resumed the conversation, the whole picture began to emerge.
[cpg]

[VOICE f="Ayaka095"]
[OnName num="ayaka"]
"My parents forbade me from working part-time, so......I hid the money from them, too."
[cpg cn=true]

[VOICE f="Ayaka096"]
[OnName num="ayaka"]
"So they took all my money and......I don't know what to do......"
[cpg cn=true]

[OnName num="keiichi"]
"You have to negotiate with your parents."
[cpg cn=true]

And more importantly, why is Ayaka so upset?
[cpg]

For example, she was angry, I would understand. But Ayaka sounds like she's in a state of panic.
[cpg]

[OnName num="keiichi"]
"Why are you so upset? Calm down."
[cpg cn=true]


[VOICE f="Ayaka097"]
[OnName num="ayaka"]
"How am I going to deal with my friends?"
[cpg cn=true]

[OnName num="keiichi"]
"I see what you mean......"
[cpg cn=true]

That seems to be the source of her anxiety. I could understand that, but still I thought that she was being too dramatic.
[cpg]

It seems to me that the only way to calm her down right now was to get her money back.
[cpg]



;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

The appointment was tomorrow night. Until then, Ayaka also said that she would manage to lie to her friends.
[cpg]

I can't believe she is a student and worried just because she doesn't have money for only one day......
[cpg]

Ayaka seemed to have been possessed by the magic of money for some time.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p2_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『繁華街』（夜）******************************************************

[OnName num="keiichi"]
"Sorry to keep you waiting, Ayaka."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayaka098"]
[OnName num="ayaka"]
"That's okay."
[cpg cn=true]

Ayaka, who was waiting, looked pale and terribly nervous.
[cpg]

[OnName num="keiichi"]
"What do we do now? What should I do to make you feel at ease?"
[cpg cn=true]


[VOICE f="Ayaka099"]
[OnName num="ayaka"]
"......"
[cpg cn=true]

She didn't say directly. She could have asked for money directly, not as a gift or something.
[cpg]


;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

;//ＢＫ

[OnName num="keiichi"]
"Look Ayaka. This isn't a charity, I can't just give you money for nothing."
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Ayaka100"]
[OnName num="ayaka"]
"...... I know.
[cpg cn=true]


[OnName num="keiichi"]
"If you know, then what are you going to do?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayaka101"]
[OnName num="ayaka"]
"...... I don't know."
[cpg cn=true]


She must have some conflict inside of her. And then she said something like this.
[cpg]

[free time=300]
[FG f="CHA01_p4_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Ayaka102"]
[OnName num="ayaka"]
"What should I......do? What kind of things do I have to say to make a man happy?"
[cpg cn=true]


She moved closer to me as she said this.
[cpg]

She stands on her toes to kiss me.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_rl"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************

[OnName num="keiichi"]
"......"
[cpg cn=true]

In the morning, it was still kind of weird.
[cpg]

I even thought Ayaka might be next to me, but that was not the case.
[cpg]

[OnName num="keiichi"]
"It's obvious, isn't it......?"
[cpg cn=true]

Ayaka may never see me again.
[cpg]

Mere sympathy won't save her.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

I got up from the bed and went to the bathroom to wash my face but I'm still sleepy.
[cpg]

I decide to sleep for a while longer. I have not experienced sleeping all day long in my life.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社内』（昼）******************************************************

I was more sad than relieved to have my normal, meaningless life back.
[cpg]

But this was all for the best. I can't keep playing lover for so long.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社内』（夜）******************************************************

I'll be me again, and Ayaka will continue to make herself look good to her friends.
[cpg]

Everything was back to normal, as it should be......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************

[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

One day, I received a phone call. It was not from Ayaka, but from Kanako.
[cpg]


[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


[VOICE f="Kanako114"]
[OnName num="kanako"]
"Hello?"
[cpg cn=true]

[OnName num="keiichi"]
"Yeah, it's me......What do you want?"
[cpg cn=true]

I had a hunch about what it was going to be. It was about Ayaka.
[cpg]

Because I don't think it's possible for Ayaka to go through her days without any damage after something like that was done to her.
[cpg]

Even I, the one who caused the damage, feel a little different from before......
[cpg]


[VOICE f="Kanako115"]
[OnName num="kanako"]
"Keiichi, what happened with Ayaka?"
[cpg cn=true]

See, I knew it. Now, how do I explain this? I don't know if I should just say what happened.
[cpg]

[OnName num="keiichi"]
"Well. Her parents confiscated her money and she's in a panic."
[cpg cn=true]

"Oh.", she just said.
[cpg]


[VOICE f="Kanako116"]
[OnName num="kanako"]
"If you saw Ayaka now, you would be surprised."
[cpg cn=true]

Kanako then continued, "You didn't hear much about what Ayaka's normally like?"
[cpg]

[OnName num="keiichi"]
"No, most of what I know is what you told me. Did you forget?"
[cpg cn=true]

Kanako was silent for a while, seeming unsure of where to begin.
[cpg]


[VOICE f="Kanako117"]
[OnName num="kanako"]
"She stopped doing things like making friends with money."
[cpg cn=true]

I couldn't believe my ears. I no longer understood Ayaka's motive for approaching me.
[cpg]

[OnName num="keiichi"]
"What...."
[cpg cn=true]

She had come to me because her friends were going to leave her because she had no money.
[cpg]

According to Kanako, she is no longer using money to maintain friendships like she used to.
[cpg]


[VOICE f="Kanako118"]
[OnName num="kanako"]
"She's acting very suspicious right now."
[cpg cn=true]

[OnName num="keiichi"]
"What do you mean? That's also a problem."
[cpg cn=true]

Behaving suspiciously. She was acting suspiciously, by either fawning over someone or blushing, or something along those lines.
[cpg]

It's as if she has found someone she likes......
[cpg]

[OnName num="keiichi"]
"What, are you saying it's because of me?" 
[cpg cn=true]


[VOICE f="Kanako119"]
[OnName num="kanako"]
"Think for yourself before you ask someone else that question..."
[cpg cn=true]

[OnName num="keiichi"]
"......you can't be serious."
[cpg cn=true]

I can't see any reason for us to fall in love with each other.
[cpg]

But Kanako sees it that way, so denying it won't get me anywhere.
[cpg]

[OnName num="keiichi"]
"Tell me why. How did we become so entangled with each other?"
[cpg cn=true]


[VOICE f="Kanako120"]
[OnName num="kanako"]
"I guess you've been too much of a counselor to her."
[cpg cn=true]


;//ＢＫ

I'm ashamed to say it, but I've come to realize that.
[cpg]

We've had some sort of romantic interest for each other.
[cpg]



;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_03_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//
;//[BGM f="bg_ni"]
;//[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************

[VOICE f="Kanako121"]
[OnName num="kanako"]
"Well, that's about it from me......"
[cpg cn=true]


[SE f="se035"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー

[free time=1000]
[WAIT time=1000]

She told me to make a decision with no regrets, and hung up the phone. Kanako sounded annoyed from start to finish.
[cpg]

[OnName num="keiichi"]
"What am I supposed to do."
[cpg cn=true]

I don't know what I'm supposed to do when she says something like that.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[BGM f="bg_op"]
[WAIT time=100]

A few more days passed in confusion.
[cpg]

I was behaving so out of the ordinary that even my co-workers were worried about my health.
[cpg]

I can't believe I'm having these worries at my age. It's ridiculous, but it's not a problem that can be suppressed.
[cpg]

[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『恵一の部屋』（夜）******************************************************

Not too long after that, I received a call from Ayaka.
[cpg]

[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[OnName num="keiichi"]
"What is it?"
[cpg cn=true]

[VOICE f="Ayaka103"]
[OnName num="ayaka"]
"Well...... um, well..."
[cpg cn=true]

Ayaka was indeed a different person. I could understand why people thought that she was acting suspiciously.
[cpg]

But still, I didn't realize how much she'd changed. I'm on the other end of the phone, wondering how to cut to the chase.
[cpg]

One would have at least decided on the first word before making a phone call, but she hasn't even been able to do that. She was really lost in love.
[cpg]

I didn't want to do this to her, but I can't change things now.
[cpg]

[OnName num="keiichi"]
"Say something...I can't have a conversation by myself."
[cpg cn=true]


[VOICE f="Ayaka104"]
[OnName num="ayaka"]
"Umm, can we meet again?"
[cpg cn=true]


It was the kind of language that made me realize everything.
[cpg]

She'd changed her reasons for doing this, which in turn, changed everything. You could say she was acting more like Kanako now.
[cpg]


[VOICE f="Ayaka105"]
[OnName num="ayaka"]
"So, what do you think? Are you no longer interested in me now that I've changed...?"
[cpg cn=true]


She wouldn't have called me if she didn't care who it was.
[cpg]

But she didn't do that because she has feelings for me.
[cpg]

What should I do about that?
[cpg]

...... It's obvious, isn't it?
[cpg]

[OnName num="keiichi"]
"I don't hate you. When and where will we meet?"
[cpg cn=true]

[VOICE f="Ayaka106"]
[OnName num="ayaka"]
"Thank you......"
[cpg cn=true]

Ayaka said, "Thank you," in a voice that sounded both relieved and impressed.
[cpg]

Is this like responding to a confession? Well, it doesn't matter now. I was ready.
[cpg]

[OnName num="keiichi"]
"Is now a good time? Can we meet?"
[cpg cn=true]

When I suggested that Ayaka flinched. I could not see her expression because I was talking on the phone, but I could hear it in her voice.
[cpg]


[VOICE f="Ayaka107"]
[OnName num="ayaka"]
"I don't know about now......"
[cpg cn=true]

[OnName num="keiichi"]
"I'll meet you at the park. I'll be on my way."
[cpg cn=true]

[SE f="se034"]
;//【ＳＥ】『携帯電話　通話終了音』ツー、ツー

[free time=1000]
[WAIT time=1000]

I forcefully decide so and hang up the phone without waiting for Ayaka's reply. The reason I hung up so forcefully was because I felt a little embarrassed.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************

[OnName num="keiichi"]
"......"
[cpg cn=true]

I sat on the bench and waited for Ayaka. All the while, the feeling of embarrassment was swirling inside me.
[cpg]

What am I doing? I'm too old to be acting like this.
[cpg]

[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Ayaka108"]
[OnName num="ayaka"]
"...... Hey."
[cpg cn=true]

A few moments later, Ayaka appeared. She came with the same tone I had heard in her voice before.
[cpg]

[OnName num="keiichi"]
"You sit down too. It's hard to relax when I'm the only one sitting down."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayaka109"]
[OnName num="ayaka"]
"Okay."
[cpg cn=true]

[free time=300]
[FG f="CHA01_p4_01_a.ui" method="change_6"  pos="2/3" time=800]

Ayaka is next to me. She is nervous. And I am also a little nervous, which is also embarrassing.
[cpg]

We talked for a while about things that had nothing to do with us.
[cpg]

How are you doing lately, are you done with your friendships, and so on.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Ayaka110"]
[OnName num="ayaka"]
"I'm doing well with my friends."
[cpg cn=true]

Ayaka started to get nervous. I was waiting.
[cpg]

I couldn't make the first move. At the very least, I wanted Ayaka to reveal her true feelings to me.
[cpg]

[OnName num="keiichi"]
"Why are you fidgeting? Do you have to go to the bathroom?"
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]

Ayaka shook her head. I knew what was bound to happen.
[cpg]


;//●ＣＧ（彩華・もどかしそうにして立って居るヒロイン：公園）ev_24
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_24_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


Then she stood up and said
[cpg]

[VOICE f="Ayaka111"]
[OnName num="ayaka"]
"Keiichi......about the other day."
[cpg cn=true]


[VOICE f="Ayaka112"]
[OnName num="ayaka"]
"You don't want anything from me, do you?"
[cpg cn=true]


[OnName num="keiichi"]
"Yeah...... well."
[cpg cn=true]

She stares at me as if to ask me why. In the past, she would have complained right away, but she just stared at me.
[cpg]

Really, it was as if we were lovers. So I make one last confirmation.
[cpg]

[OnName num="keiichi"]
"Until I hear your true feelings, I can't say the words you want to hear."
[cpg cn=true]

Ayaka is at a loss for words. Doesn't she understand what I'm saying?
[cpg]


[VOICE f="Ayaka113"]
[OnName num="ayaka"]
"That's......"
[cpg cn=true]

[OnName num="keiichi"]
"What would you do if someone offered you a gift or something in return? What would you do?"
[cpg cn=true]

[VOICE f="Ayaka114"]
[OnName num="ayaka"]
"I don't care about money anymore."
[cpg cn=true]

That's where it stops again. I knew she had a naïve streak, but I didn't realize that it was to this extent.
[cpg]

[OnName num="keiichi"]
"You don't care about money...then I guess we're done for now."
[cpg cn=true]

Ayaka mumbles. Good luck, I think. All she needed was a little more courage.
[cpg]

Or do I have to say it? I was wondering......
[cpg]

[VOICE f="Ayaka115"]
[OnName num="ayaka"]
"I like you......"
[cpg cn=true]

Ayaka squeezed out the last word. She confided her true feelings to me.
[cpg]

[OnName num="keiichi"]
"I see."
[cpg cn=true]

It had been a long and winding road to this point. In the end, Ayaka sought money and friends because she was empty.
[cpg]

We filled in the blanks for each other.
[cpg]

[OnName num="keiichi"]
"......I don't think of you as a stranger anymore either."
[cpg cn=true]


[OnName num="keiichi"]
"I love you."
[cpg cn=true]


;//移植のためシーンをカットしています
;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

From there, Ayaka began to change little by little. Or perhaps it would be more correct to say that she continued to change.
[cpg]

Because Ayaka on that day was also Ayaka after she had already changed.
[cpg]

;//●ＣＧ（彩華・主人公にすがりつくヒロイン。主人公の位置をヒロイン側に変えてください：通勤路）ev_25

[window target=false]
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_25_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_06_1.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=1000]

;//[BGM f="bg_sl"]
;//[WAIT time=1000]
;//【ＢＧ】『通勤路』（朝）******************************************************

;//[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ayaka116"]
[OnName num="ayaka"]
"Good morning, Keiichi."
[cpg cn=true]

[OnName num="keiichi"]
"Good morning."
[cpg cn=true]

She started coming to meet me at the time of my commute to work before she went to school.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

She came to see me, just to say good morning. Our walk together is a little longer than it takes to finish saying "good morning".
[cpg]

;//ＢＫ

[OnName num="keiichi"]
"......How are you, these days?"
[cpg cn=true]

I never thought I'd hear myself say something like this.
[cpg]

;//[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayaka117"]
[OnName num="ayaka"]
"I'm good. I just want to jump up and down."
[cpg cn=true]

[OnName num="keiichi"]
"Are you okay? That sounds too cheerful."
[cpg cn=true]


Then, we became lovers. Although there is a considerable age difference between us, we are now in a relationship that cannot be described in any other way than as lovers.
[cpg]

I mean, it had been that way for a little while now. I just hadn't noticed.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（昼）******************************************************

[SE f="se027"]
;//【ＳＥ】『喧騒』
;//私服


We tried to go on a date on a weekend, but Ayaka got angry with me because I didn't show any interest in anything.
[cpg]

Still, when I was walking around with Ayaka next to me, I could tell.
[cpg]

Ayaka had a pure side to her as well as her light-hearted, playful side. Right now, she was showing me the pure side of her. She acts like a maiden in love.
[cpg]

[OnName num="keiichi"]
"Where are we going to go next? The game arcade?"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayaka118"]
[OnName num="ayaka"]
"A thirty-year-old man in an arcade? Ha ha ha!"
[cpg cn=true]

[OnName num="keiichi"]
"No, I didn't mean that I want to go there."
[cpg cn=true]

However, a joking side of Ayaka sometimes comes out in a flash. Both of them are Ayaka's true nature.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p4_02_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************

[FACE method="change_6" pos="2/3"]
[VOICE f="Ayaka119"]
[OnName num="ayaka"]
"The sun has completely set, hasn't it?"
[cpg cn=true]

[OnName num="keiichi"]
"You should head home soon."
[cpg cn=true]

I suggested, but Ayaka kept holding onto my arm. I knew that this was going to happen.
[cpg]

;//しかし、今日はラブホテルなんかに行くつもりはない。デートなら、進展がないとな。
But I had no intention of going to the park today. If it's a date, there has to be progress.
[cpg]

[OnName num="keiichi"]
"Why don't you come to my place, then? I'll let you inside."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Ayaka120"]
[OnName num="ayaka"]
"Oh, really?"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

Ayaka was surprised and pleased more than I had imagined. I guess she was happy to visit a man's house.
[cpg]

[OnName num="keiichi"]
"There isn't much to see, I wouldn't get too excited.."
[cpg cn=true]

I say so but Ayaka continued to rejoice. She was so high-spirited,
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayaka121"]
[OnName num="ayaka"]
"That's okay. I'm just happy that you are inviting me."
[cpg cn=true]

Now the bar has been raised......
[cpg]

;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2500]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（朝）******************************************************
;//【ＢＧ】『恵一の部屋』（夜）

;//●ＣＧエロ（彩華・布団に寝転がって、主人公と会話しているいる。：主人公の部屋・朝）ev_19

[window target=false]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[OnName num="keiichi"]
"......Hey, Ayaka."
[cpg cn=true]

;//[FACE method="change_7" pos="2/3"]
[VOICE f="Ayaka122"]
[OnName num="ayaka"]
"What? Oh, are you worried about my parents?"
[cpg cn=true]

[OnName num="keiichi"]
"Yeah. As I recall, you are......"
[cpg cn=true]

No, wait. I realize now that this is quite strange.
[cpg]

She comes from a rich background and it would not be surprising that she is being raised with the utmost care.
[cpg]

And yet, she's staying at a man's house that her parents don't know. Won't they say anything about it?
[cpg]

;//[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayaka123"]
[OnName num="ayaka"]
"Don't worry. My parents support me."
[cpg cn=true]

[OnName num="keiichi"]
"Huh......? The parents who forbid you to get a part-time job and don't give you an allowance?"
[cpg cn=true]


;//[FACE method="bow_1" pos="2/3"]
[VOICE f="Ayaka124"]
[OnName num="ayaka"]
"Yeah, that's weird, right?"
[cpg cn=true]

Ayaka laughs as if it weren't her problem.
[cpg]

They don't allow her to work part-time. They don't even give her an allowance. However, they are okay with her staying out overnight.
[cpg]

I'm starting to get the picture. Everything is connecting.
[cpg]

[OnName num="keiichi"]
"Maybe your parents are very greedy......?"
[cpg cn=true]

;//[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayaka125"]
[OnName num="ayaka"]
"Yes. They even told me to stop working part-time because it's inefficient."
[cpg cn=true]

I see. I think that makes sense.
[cpg]

They were raising their daughter to make money. And now they were even trying to cut costs...?
[cpg]

It would be rude of me if I was wrong, but it doesn't add up unless that were the case.
[cpg]

If it is something other than this, their educational policy may be too specific for me to understand.
[cpg]

Either way, it seems to be a complicated case......
[cpg]

[OnName num="keiichi"]
"How on earth am I supposed to introduce myself......"
[cpg cn=true]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Ayaka126"]
[OnName num="ayaka"]
"Heh, are you getting cold feet?"
[cpg cn=true]

[OnName num="keiichi"]
"Who wouldn't after hearing all that?"
[cpg cn=true]

I am scared, but I feel that I can overcome anything with Ayaka.
[cpg]

[OnName num="keiichi"]
"Look Ayaka, I'm sure a lot's going to happen from her on out. Way more than before."
[cpg cn=true]

It wasn't just about her parents. Our age gap wasn't ever going to close, and that would bring its own set of problems with it.
[cpg]

;//[FACE method="shake_1" pos="2/3"]
[VOICE f="Ayaka127"]
[OnName num="ayaka"]
"It's okay. As long as I'm with you, we'll be fine."
[cpg cn=true]

I knew that Ayaka and I were thinking the same thing.
[cpg]

I'm sure that since Ayaka and I think it's going to be okay, it will be okay.
[cpg]

[OnName num="keiichi"]
"I have to go to work soon......"
[cpg cn=true]

;//[FACE method="change_2" pos="2/3"]
[VOICE f="Ayaka128"]
[OnName num="ayaka"]
"Oh, wait. I'll make you breakfast."
[cpg cn=true]

[OnName num="keiichi"]
"I don't have the ingredients for that though."
[cpg cn=true]

But maybe things will change. The empty refrigerator, the tasteless meals, the colorless days.
[cpg]

It was not enough for me anymore. It was Ayaka, of all people, who made me feel inadequate.
[cpg]

;//[FACE method="change_7" pos="2/3"]
[VOICE f="Ayaka129"]
[OnName num="ayaka"]
"Doesn't it feel wrong having such an empty fridge?"
[cpg cn=true]

;//[FACE method="bow_6" pos="2/3"]
[OnName num="keiichi"]
"Lately, I've been feeling like it's not enough."
[cpg cn=true]

...... This is how I decided to be happy.
[cpg]


[SCENE id=9]

[jump storage="epend.ks" target="*start"]
;//【彩華ルート】ハッピーエンド
;////////////////////////////////////////////////////////////////////////
