
*start|A Made Man
;//援交もの　シナリオ

;//以下、残したCGを列挙します

;//彩華   01 02 07 19 24 25
;//花     29 32 34 36 37
;//可南子 45 47 49 55
;//茉莉   56 66 67 70
;//複数   16




;#################################################
*Ep000|A Made Man
;#################################################

[SCENE id=0]


[stflag CHA01flag = 0]
[stflag CHA02flag = 0]
[stflag CHA03flag = 0]
[stflag CHA04flag = 0]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I had money, but not much else.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_rl"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夜）******************************************************

[SE f="se027"]
;//【ＳＥ】『喧騒』

When I finish work and head home, I can't remember what I did today.
[cpg]

It's not that I don't remember, it's more that it's not worth remembering.
[cpg]

There's no meaning to any of it. I don't have purpose. I don't have goals.
[cpg]

I can't remember. There is no point in remembering. I can't remember the work I was doing, my school days, or even what I was like when I was a child.
[cpg]

I've lived 30 years like this and I'm sure the next 30 years will be more or less the same.
[cpg]

[OnName num="keiichi"]
"Whew......"
[cpg cn=true]

I can sigh all I want, but I can't think of much I could do that would change my life.
[cpg]

I work for a big company, most people know the name......I had money, but not much else.
[cpg]

There's only so much that you can buy with money.
[cpg]

I don't have hobbies or anything to spend all of this money on, so my savings just accumulate.
[cpg]

I tried getting into investing and apparently it paid off because I'm even richer than before. It's almost ironic.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************

There was nothing for me to do at home. There was nobody waiting for me, either.
[cpg]

I sat on a bench in a park at night for no particular reason, just staring at the ground, doing nothing, alone.
[cpg]

......I've started to realize that it's because I'm alone that I have an excess of time and money.
[cpg]

But I'm single. I'll probably always be single, because I know the reasons why I'm single.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]


;//[SE f="se001"]
;//【ＳＥ】『手を洗う音』ザーッ

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


After using the restroom in the park, I wash my hands and look in the mirror. I let out another sigh.
[cpg]

I call myself the living dead, because when I look in the mirror, I can't find any trace of life behind my eyes.
[cpg]

What do women look for in a man? Is it income? Looks? Maybe personality?
[cpg]

No, I think the most important factor is decency. And I'm a far cry from decent.
[cpg]

No decent woman would want to approach a man like me.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

[free time=1000]
[WAIT time=1000]

;//【ＢＧ】『公園』（夜）******************************************************

I can't even remember which bench I was sitting on.
[cpg]

More proof that I was just drifting through life......I decided to head home for the day.
[cpg]

;//ここから、彩華の名前を「少女」と隠してください
[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Ayaka001"]
[OnName num="girl"]
"Hey mister, looking for something to do?"
[cpg cn=true]

[OnName num="keiichi"]
"......"
[cpg cn=true]

I was just walking around with my head down, there was no reason for a girl of her age to talk to me.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayaka002"]
[OnName num="girl"]
"Hey, where are you going? Why are you making that face?"
[cpg cn=true]

[OnName num="keiichi"]
"What do you mean?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Ayaka003"]
[OnName num="girl"]
"You look glum, mister. You thinking about offing yourself or something?"
[cpg cn=true]

She makes a big show of approaching me and peering at my face. It seemed almost calculated.
[cpg]

I hadn't really considered suicide, but some days I wasn't even sure if I was really still alive.
[cpg]

[OnName num="keiichi"]
"Good eye, kid. You could be a fortune teller."
[cpg cn=true]

I walk past her, but she trots alongside me. She sure was persistent.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayaka004"]
[OnName num="girl"]
"There's no money in fortune-telling. Beside, I have a much better job."
[cpg cn=true]

[OnName num="keiichi"]
"......Good for you, but you should choose your clientele better. I doubt you'll get many repeaters if you keep choosing dead men walking."
[cpg cn=true]

;//●ＣＧ（彩華・主人公を見上げるヒロイン：公園）ev_01
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Ayaka005"]
[OnName num="girl"]
"You're right. Hey, do you want to do something fun?"
[cpg cn=true]

[OnName num="keiichi"]
"Fun, huh?"
[cpg cn=true]

We both know what she's insinuating.
[cpg]

Not this again.
[cpg]

I'd never been in a real relationship, decent women were smart enough to avoid me like the plague. That said, this situation was not unfamiliar to me.
[cpg]

In truth, this was the third time I'd been propositioned like this.
[cpg]

Of course, I didn't mean to imply that she wasn't a decent person or anything.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


It's just that it was clear that she had ulterior motives. She wanted something in return.
[cpg]

That's the only reason why a girl like her would dare to approach an older guy like me.
[cpg]


;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]


;//●ＣＧ（彩華・座り込んで、主人公と話すヒロイン：公園）ev_02

;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


After walking around the city at night, we come back to the same park.
[cpg]

She'd tagged along the entire time.
[cpg]

[OnName num="keiichi"]
"......Should you be heading home?"
[cpg cn=true]

[VOICE f="Ayaka006"]
[OnName num="ayaka"]
"Why? Don't you want to talk anymore?"
[cpg cn=true]


[OnName num="keiichi"]
"I think I've had enough for today."
[cpg cn=true]


Of course, I hadn't given her anything in return.
[cpg]

Maybe that was why she was stubbornly hanging around.
[cpg]

[window target=false]
[free time=1000]
[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************


[OnName num="keiichi"]
"What's your name?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayaka007"]
[OnName num="girl"]
"You tell me your name first."
[cpg cn=true]

[OnName num="keiichi"]
"......Keiichi. My name is Keiichi."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayaka008"]
[OnName num="girl"]
"I'm Ayaka. Isn't it a pretty name?"
[cpg cn=true]

[OnName num="keiichi"]
"I've seen your school uniform somewhere before."
[cpg cn=true]

;//ここから、彩華の名前を隠さないで下さい
[FACE method="change_1" pos="2/3"]
[VOICE f="Ayaka009"]
[OnName num="ayaka"]
"Oh, you're trying to find out which school I go to, aren't you?"
[cpg cn=true]

She laughs. Her innocent expression does not look like he has been with many men.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Ayaka010"]
[OnName num="ayaka"]
"So what do you do, Keiichi? You are a businessman, right?"
[cpg cn=true]

[OnName num="keiichi"]
"You could say that."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
Her eyes widened when I told her where I worked.
[cpg]

[FACE method="bow_5" pos="2/3"]
[VOICE f="Ayaka011"]
[OnName num="ayaka"]
"Then you must be rich."
[cpg cn=true]

[OnName num="keiichi"]
"Maybe based on your standards."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Ayaka012"]
[OnName num="ayaka"]
"Aww, I should have asked for more......"
[cpg cn=true]

Normally you wouldn't say that part out loud. She's still a child, I thought to myself.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayaka013"]
[OnName num="ayaka"]
"I can't imagine what it's like being a businessman. It sounds like a lot of work."
[cpg cn=true]

[OnName num="keiichi"]
"Maybe. So, why did you approach me?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayaka014"]
[OnName num="ayaka"]
"......"
[cpg cn=true]

;//俺から目を逸らす。目を逸らしたまま、彼女はこう言った。
She goes silent for a moment.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayaka015"]
[OnName num="ayaka"]
"I need money to hang out with my friends."
[cpg cn=true]

Something about the way she said it implied there was more to the story.
[cpg]

[OnName num="keiichi"]
"What, a normal part-time job isn't enough?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

She mumbles a bit. I guess it wasn't an easy topic to broach. I could probably get a clear answer out of her if I tried, but it wasn't my problem.
[cpg]

[OnName num="keiichi"]
"I guess it's time to call it a night."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayaka016"]
[OnName num="ayaka"]
"Aww, but the night's just getting started."
[cpg cn=true]

[OnName num="keiichi"]
"Are you planning on following me home? If so, I'm calling the police."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayaka017"]
[OnName num="ayaka"]
"Something tells me you'd be the one getting in trouble."
[cpg cn=true]

Good point. I guess she'd done this before.
[cpg]

[OnName num="keiichi"]
"Yeah, well I'm going home. I'm not in the mood today."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayaka018"]
[OnName num="ayaka"]
"Hmm......fine, fine."
[cpg cn=true]

She wrote something on a girly notepad, pulled off a page, and handed it to me.
[cpg]

[OnName num="keiichi"]
"I take it this is your phone number?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayaka019"]
[OnName num="ayaka"]
"Give me a call when you change your mind."
[cpg cn=true]

[OnName num="keiichi"]
"You do this to everyone?"
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Ayaka020"]
[OnName num="ayaka"]
"No, just you."
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』
[free time=1000]
[WAIT time=1000]

Ayaka stands up and leaves first. After a few steps, she looks back and waves.
[cpg]

[OnName num="keiichi"]
"......What am I supposed to do with this?"
[cpg cn=true]

I muttered to myself, but this wasn't the first time this had happened, either.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************

I returned to my apartment. It's spacious and tidy, but felt far too large for one person.
[cpg]

I don't have a lot of things since I don't have any hobbies. While the room itself seems bright, there's no warmth or sense of humanity in the room.
[cpg]

......And, naturally, there was nobody waiting for my return.
[cpg]

It was all somehow fitting. An empty room for an empty human being.
[cpg]

[OnName num="keiichi"]
"Ayaka......"
[cpg cn=true]

I hadn't intended to remember her name, but something about her stuck in my head.
[cpg]

I couldn't remember what I'd done that day, but for some reason, I could remember her name.
[cpg]

She was wearing a uniform, so she must have been a student......hold on.
[cpg]

The uniform itself seemed familiar to me, somehow.
[cpg]

I think I've seen that design on my commute to work, but I'm not positive.
[cpg]

Much like what I'd done that day at work, my memory of my commute was hazy, at best.
[cpg]

I'm sure I've seen that uniform somewhere before, but I just can't remember.
[cpg]


[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン
[WAIT time=1000]

[OnName num="keiichi"]
"......Who's calling at this hour?"
[cpg cn=true]

Suddenly, I realized where I'd seen that uniform before.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[SE f="se034"]
;//【ＳＥ】『携帯電話の通話開始』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]

;//[FADEOUTBGM]
;//[BGM f="bg_d1"]


;//可南子の名前を「？？？」と隠してください

[VOICE f="Kanako001"]
[OnName num="unknown"]
"Hello?"
[cpg cn=true]

;//ここから、可南子の名前を隠さないで下さい
[OnName num="keiichi"]
"......Kanako? What is it?"
[cpg cn=true]


[VOICE f="Kanako002"]
[OnName num="kanako"]
"Aww, why so grumpy?"
[cpg cn=true]

[OnName num="keiichi"]
"Just tell me what you want."
[cpg cn=true]


[VOICE f="Kanako003"]
[OnName num="kanako"]
"How are you doing these days?"
[cpg cn=true]

[OnName num="keiichi"]
"......Get to the point."
[cpg cn=true]


[VOICE f="Kanako004"]
[OnName num="kanako"]
"I thought I just did?"
[cpg cn=true]

Just like Ayaka, she drags the conversation on longer than necessary.
[cpg]

I don't know why she does this. Was there something about me that cause girls to act like this?
[cpg]

[OnName num="keiichi"]
"Who cares? Things are normal, nothing's changed."
[cpg cn=true]


[VOICE f="Kanako005"]
[OnName num="kanako"]
"Normal? Well, nothing's changed here, either."
[cpg cn=true]

Then it hit me. The sight of Kanako in her uniform came to mind. The same uniform that Ayaka was wearing......
[cpg]

I was sure of it. In fact, I think that was the same place we'd met.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kanako006"]
[OnName num="kanako"]
"......Somehow, your voice is brighter than usual."
[cpg cn=true]

[OnName num="keiichi"]
"Don't get any ideas. It's none of your business."
[cpg cn=true]

[VOICE f="Kanako007"]
[OnName num="kanako"]
"Isn't it? We've known each other for two whole months now."
[cpg cn=true]

Right, I'd first met Kanako two months ago.
[cpg]

I'd always considered myself incapable of having strong emotions, but that wasn't the case when she was around.
[cpg]

[OnName num="keiichi"]
"Has it been that long?"
[cpg cn=true]


[VOICE f="Kanako008"]
[OnName num="kanako"]
"You were so fresh and cute."
[cpg cn=true]

[OnName num="keiichi"]
"I recall you describing me a gloomy and depressing."
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Kanako and I met about two months ago.
[cpg]

Just like Ayaka, she approached me at night, but the nature of her invitation was quite different.
[cpg]


;//ここから回想です。イベントＣＧ以外はセピア調にしてください


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_04_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『通勤路』（夜セピア調）******************************************************

[SE f="se027"]
;//【ＳＥ】『喧騒』

[FACE method="change_1" pos="2/3"]
[VOICE f="Kanako009"]
[OnName num="girl"]
"That's a nice suit."
[cpg cn=true]

[OnName num="keiichi"]
"......What?"
[cpg cn=true]

I was on my usual, aimless walk through the city.
[cpg]

......Before I knew it, a girl was standing in front of me. She was quite small, and since I was always looking down, she fit into my field of vision rather comfortably.
[cpg]

[OnName num="keiichi"]
"Can you tell a good suit from a bad one?"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kanako010"]
[OnName num="girl"]
"Let me rephrase that. You look like you have a lot of disposable income."
[cpg cn=true]

[OnName num="keiichi"]
"Maybe I do..."
[cpg cn=true]

At this point, this was the second time I'd been propositioned by a schoolgirl. I wouldn't say that I was used to it, but I did understand the process.
[cpg]

I don't want to get into trouble, so I try to avoid the girl and proceed with my walk......
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kanako011"]
[OnName num="girl"]
"Why don't you use some of that cash do a little shopping with me?"
[cpg cn=true]

[OnName num="keiichi"]
"What do you want me to buy?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kanako012"]
[OnName num="girl"]
"......Me."
[cpg cn=true]

Hah. It was a good line, she'd probably done this before.
[cpg]
;//ＢＫ

;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_04_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_06_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


In exchange for going out on dates with me, she'd ask me for gifts and things......
[cpg]

Our relationship continued on like this for a little while.
[cpg]

[OnName num="keiichi"]
"You like me? Are you serious?"
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kanako013"]
[OnName num="girl"]
"Yes, I am."
[cpg cn=true]

She tries to put on a serious face, but it seemed calculated. What was she really thinking?
[cpg]

[OnName num="keiichi"]
"Is that what you tell everybody?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kanako014"]
[OnName num="kanako"]
"No, it's just that your eyes seemed so dark. I'd never seen anybody like that before."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Kanako015"]
[OnName num="girl"]
"Maybe you're just my type."
[cpg cn=true]

[OnName num="keiichi"]
"......"
[cpg cn=true]

It's not everyday you hear a phrase like that. I'd heard similar lines from other people, but they were never quite so direct.
[cpg]

I wonder if there is something about me that attracts girls like this.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[FG f="CHA03_p1_04_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_05_5.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『住宅街』（夜セピア調）******************************************************



I didn't reply, but she followed me around anyways.
[cpg]

I'd learned that her name was Kanako and, for some reason, I'd told her my name as well.
[cpg]


;//////////////ここから少女から可南子にする

[FACE method="change_6" pos="2/3"]
[VOICE f="Kanako016"]
[OnName num="kanako"]
"That's a cool name."
[cpg cn=true]

[OnName num="keiichi"]
"......You think?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kanako017"]
[OnName num="kanako"]
"I do. I guess your name is cool as well."
[cpg cn=true]

She kept complimenting me, but I couldn't understand what she was trying to accomplish.
[cpg]

;//ここまで回想です。色調を戻してください
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


She was curious and energetic. Her smile really stuck in my memory.
[cpg]

......I was surprised to learn that girls like this existed.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『恵一の部屋』（夜）******************************************************


[VOICE f="Kanako018"]
[OnName num="kanako"]
"So, how about tomorrow?"
[cpg cn=true]

[OnName num="keiichi"]
"Why? I keep telling you I'm fine."
[cpg cn=true]

But I had gotten used to it after a few dates.
[cpg]


[VOICE f="Kanako019"]
[OnName num="kanako"]
"Why not? Don't you like spending time with me?"
[cpg cn=true]

[OnName num="keiichi"]
"It's not that I don't enjoy it, but it's tiring having to go out all of the time."
[cpg cn=true]


[VOICE f="Kanako020"]
[OnName num="kanako"]
"Boo. Well this time it will be a little different."
[cpg cn=true]

[OnName num="keiichi"]
"What do you mean?"
[cpg cn=true]


[VOICE f="Kanako021"]
[OnName num="kanako"]
"I think I can bring another person along."
[cpg cn=true]

That certainly would change things.
[cpg]

[OnName num="keiichi"]
"......Fine. I'll see you tomorrow."
[cpg cn=true]


[VOICE f="Kanako022"]
[OnName num="kanako"]
"I knew you'd be interested."
[cpg cn=true]

[OnName num="keiichi"]
"Don't say anything stupid."
[cpg cn=true]


[VOICE f="Kanako023"]
[OnName num="kanako"]
"Fine, fine. I'll tell Hana that you're looking forward to it."
[cpg cn=true]

Hana? Who was that?
[cpg]

[OnName num="keiichi"]
"......What about Ayaka?"
[cpg cn=true]


[VOICE f="Kanako024"]
[OnName num="kanako"]
"Huh?"
[cpg cn=true]

Kanako goes silent for a moment.
[cpg]


[VOICE f="Kanako025"]
[OnName num="kanako"]
"You know Ayaka?"
[cpg cn=true]

[OnName num="keiichi"]
"Well, I met her the other day......or rather, she approached me the other day."
[cpg cn=true]


[VOICE f="Kanako026"]
[OnName num="kanako"]
"Wow Keiichi, you sure are popular."
[cpg cn=true]

She sounded like she was upset, but it was obvious that she was acting.
[cpg]

[VOICE f="Kanako027"]
[OnName num="kanako"]
"But Ayaka...? That's unexpected."
[cpg cn=true]

[OnName num="keiichi"]
"You guys go to the same school, right?"
[cpg cn=true]

[VOICE f="Kanako028"]
[OnName num="kanako"]
"We do, but I don't know her that well."
[cpg cn=true]

Kanako suddenly changes the topic back to tomorrow's plans.
[cpg]

[VOICE f="Kanako029"]
[OnName num="kanako"]
"......I'm going to bring a girl named Hana along. I'm sure you'll get along."
[cpg cn=true]

[OnName num="keiichi"]
"What kind of a girl is this Hana?"
[cpg cn=true]


[VOICE f="Kanako030"]
[OnName num="kanako"]
"She's two years older than me."
[cpg cn=true]

[OnName num="keiichi"]
"Is she like you? Or is she a bit more proper like Ayaka?"
[cpg cn=true]


[VOICE f="Kanako031"]
[OnName num="kanako"]
"Don't worry, she's a pretty girl with a pure heart."
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I've never had much trouble getting to sleep.
[cpg]

Of course, I can't remember much about what I do all day, but I think I work hard enough each day to warrant being tired at night.
[cpg]

But that night, I had a hard time falling asleep. I wondered what Hana was like.
[cpg]

Was she just forcibly dragged into all this by Kanako?
[cpg]

Or did she come to Kanako because she desperately needed money? What if it was both?
[cpg]




[jump storage="ep001.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
