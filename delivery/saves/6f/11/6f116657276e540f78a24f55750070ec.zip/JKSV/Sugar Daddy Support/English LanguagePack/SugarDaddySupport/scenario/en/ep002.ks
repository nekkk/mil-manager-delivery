
*start|A Call from Ayaka

;#################################################
*Ep002|A Call from Ayaka
;#################################################

[SCENE id=2]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t2"]
[WAIT time=100]
;//【ＢＧ】『会社内』（昼）******************************************************

;//[SE f="se027"]
;//【ＳＥ】『喧騒』

Morning comes, I go to work, and come back home at night. My usual routine.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『会社内』（夜）******************************************************

What was the difference between me and a robot, simply following its programming?
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（朝）******************************************************

One day I bumped into Ayaka on my way to work. I saw her waving at me from the opposite train platform.
[cpg]

She had an innocent smile and was wearing the same uniform as Kanako.
[cpg]

It was the kind of gesture you'd make to a casual acquaintance.
[cpg]

[OnName num="keiichi"]
"......"
[cpg cn=true]

But I couldn't return the gesture.
[cpg]

If Kanako was the curious and innocent type, then Ayaka wasn't taking me seriously.
[cpg]

Kanako knows the risk and probably even enjoys it. But Ayaka seemed like she saw this as a normal part-time job.
[cpg]

Or maybe this was all in my head. All she did was wave to me, but it was enough to send a chill down my spine.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[WAIT time=1000]

[VOICE f="Ayaka021"]
[OnName num="ayaka"]
"Hey, you could at least say hi."
[cpg cn=true]


She approached me as I was thinking to myself. What would other people think if they saw us together?
[cpg]

But she didn't seem to be afraid of that.
[cpg]

[OnName num="keiichi"]
"Don't wave to me. People might wonder what kind of relationship we have."
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Ayaka022"]
[OnName num="ayaka"]
"You're worried about me? How sweet. But I can't play with you right now, I've got school today."
[cpg cn=true]

[OnName num="keiichi"]
"......"
[cpg cn=true]

So that's how she sees it. She paints me as the degenerate lusting over her while she remains immaculate.
[cpg]

I guess there was no point in trying to explain myself to her. In a way, she's more childish than Kanako.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Ayaka023"]
[OnName num="ayaka"]
"I'll see you tonight."
[cpg cn=true]

[OnName num="keiichi"]
"Wait, I didn't agree to that."
[cpg cn=true]

She really thinks she's got me around her little finger, doesn't she? She doesn't seem to understand me at all.
[cpg]

Ayaka smiles confidently, oblivious to my exasperation.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Ayaka024"]
[OnName num="ayaka"]
"Good luck with work."
[cpg cn=true]

She waved again and walked away briskly.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』ブーン

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

During my lunch break, I received a call. It was from Ayaka.
[cpg]

I let it ring. I knew she'd just say something about helping me relieve all that pent up stress and ask where we were going tonight or something like that.
[cpg]

Thankfully, she only tried calling once......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『繁華街』（夜）******************************************************

[SE f="se027"]
;//【ＳＥ】『喧騒』

[FACE method="shake_3" pos="2/3"]
[VOICE f="Ayaka025"]
[OnName num="ayaka"]
"You're late, Keiichi."
[cpg cn=true]

[OnName num="keiichi"]
"Late? I don't recall agreeing to see you tonight."
[cpg cn=true]

;//[t_move pos=C 動揺]
[FACE method="change_3" pos="2/3"]
[VOICE f="Ayaka026"]
[OnName num="ayaka"]
"I called you to set the time, but you didn't answer."
[cpg cn=true]

It seems that Ayaka had been waiting for me, even though there was no guarantee I'd take this route home.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Ayaka027"]
[OnName num="ayaka"]
"If you had come an hour later, I would have gone home."
[cpg cn=true]

[OnName num="keiichi"]
"You must have really wanted to see me."
[cpg cn=true]

I tease her as if she were my lover or a friend.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Ayaka028"]
[OnName num="ayaka"]
"Oh you!"
[cpg cn=true]

She links her arm to mine. It was an exaggerated and childish gesture.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Ayaka029"]
[OnName num="ayaka"]
"......Well, that's okay. How was work?"
[cpg cn=true]

She grabs my hand and grins.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Ayaka030"]
[OnName num="ayaka"]
"Let's go somewhere a little quieter, okay?"
[cpg cn=true]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************

She takes me to the park we'd met at the other night.
[cpg]

;//●ＣＧ（彩華・主人公にすり寄るヒロイン：公園）ev_07
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="Ayaka031"]
[OnName num="ayaka"]
"Look, we're this close together, doesn't it make you want to do something?"
[cpg cn=true]


[OnName num="keiichi"]
"It does not. I don't want any trouble."
[cpg cn=true]


She didn't falter despite my rejection.
[cpg]

[VOICE f="Ayaka032"]
[OnName num="ayaka"]
"Oh well, I guess a normal date will have to do. It's easier than the alternative."
[cpg cn=true]


She's very clear about what she wants.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************

;//[SE f="se000"]
;//【ＳＥ】『自販機　缶落ちる音』ガタン

I buy her a drink with a 1,000 yen bill and give her the change.
[cpg]

"Thanks.", she said and laughed. It was easy to please her......
[cpg]

[OnName num="keiichi"]
"You said something about hanging out with friends. Do you really need a lot of money for that?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayaka033"]
[OnName num="ayaka"]
"Come on, let's not talk about that."
[cpg cn=true]

[OnName num="keiichi"]
"......If you don't want to talk about it, fine, but I'm curious. What do you need the money for?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayaka034"]
[OnName num="ayaka"]
"......like buying people drinks and stuff?"
[cpg cn=true]

I don't get it. The amount of money a student would need for basic socializing shouldn't amount to much.
[cpg]

[OnName num="keiichi"]
"Don't your parents give you an allowance? I have no idea what's normal these days, but I imagine it's enough to get by on."
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Ayaka035"]
[OnName num="ayaka"]
"......I guess."
[cpg cn=true]

Her reaction is a little different than before. Her facial expression darkened somewhat. It seems like there's something she wants to say.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayaka036"]
[OnName num="ayaka"]
"My parents don't give me an allowance."
[cpg cn=true]

[OnName num="keiichi"]
"Then why don't you get a part-time job?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Ayaka037"]
[OnName num="ayaka"]
"They won't even let me get a part-time job."
[cpg cn=true]

[OnName num="keiichi"]
"If you can approach a guy like me, you could probably get a part-time job without telling them."
[cpg cn=true]

She stares at the ground, but her expression brightens a little.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayaka038"]
[OnName num="ayaka"]
"You're very kind, Keiichi."
[cpg cn=true]

[OnName num="keiichi"]
"And you're changing the subject."
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Ayaka039"]
[OnName num="ayaka"]
"This is a lot easier than a part-time job."
[cpg cn=true]

[OnName num="keiichi"]
"......I wouldn't know."
[cpg cn=true]

Maybe that was true for her, but I still didn't feel like I'd gotten the whole story out of her.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayaka040"]
[OnName num="ayaka"]
"I need money to hang out with my friends. I want to buy clothes and stuff too."
[cpg cn=true]

[OnName num="keiichi"]
"I guess kids these days can't get by with just their school uniforms, huh?"
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Ayaka041"]
[OnName num="ayaka"]
"You really don't understand what it's like to be a girl, mister."
[cpg cn=true]

I sure didn't. Normally, a man in his thirties would have virtually no contact with girls her age. We were practically different species.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayaka042"]
[OnName num="ayaka"]
"Of course, there are other expenses to take care of. I'm sure you can understand. You're the type who spends a lot of money on his hobbies, right?"
[cpg cn=true]

[OnName num="keiichi"]
"......I see."
[cpg cn=true]

She couldn't be more wrong, but I didn't see a need to correct her.
[cpg]

More than that, I was getting a strange feeling. Is that what money was for?
[cpg]

I had a vague sense that I alone had been somehow shunned from the various amusements and pleasures of this world.
[cpg]

But what's with this difference in perception? I'm making my own money, and I'm having trouble spending it, and here she is......
[cpg]

[OnName num="keiichi"]
"You don't know what money is until you actually earn it."
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Ayaka043"]
[OnName num="ayaka"]
"I'm making plenty of money, too."
[cpg cn=true]

[OnName num="keiichi"]
"......I guess I still don't understand the value of money, myself."
[cpg cn=true]

;//[SE f="se001"]
;//【ＳＥ】『空の缶投げ捨てる音』

Ayaka finishes her drink and throws the can away.
[cpg]

[OnName num="keiichi"]
"Hey, put it in the bin. You're better than that."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Ayaka044"]
[OnName num="ayaka"]
"What makes you say that?"
[cpg cn=true]

[OnName num="keiichi"]
"There's no need to put on an act around me."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Ayaka045"]
[OnName num="ayaka"]
"......"
[cpg cn=true]

[OnName num="keiichi"]
"Why do you need so much money?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Ayaka046"]
[OnName num="ayaka"]
"......If I told you, you'd laugh at me."
[cpg cn=true]

It seems she really didn't want to tell me. I decided against pursuing the topic any further.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

From there, the conversation turned casual.
[cpg]

As if talking with a close friend, she told me about her school life and other trivial things.
[cpg]

I got the feeling that she couldn't really open up around her friends.
[cpg]

Either that or her idea of friendship was completely different from what I was imagining.
[cpg]

Otherwise, there was no way she would have kept talking to a complete stranger like me.
[cpg]


[FO pos="4/7" time=1000]
[WAIT time=1000]

;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_04_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=1000]

;//【ＢＧ】『公園』（夜）******************************************************

;//[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[FACE method="shake_1" pos="2/3"]
[VOICE f="Ayaka047"]
[OnName num="ayaka"]
"Sorry for talking this whole time."
[cpg cn=true]

[OnName num="keiichi"]
"......I don't really mind."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayaka048"]
[OnName num="ayaka"]
"Is there anything you want to talk about?"
[cpg cn=true]

I thought about it for a while and then one thing occurred to me.
[cpg]

[OnName num="keiichi"]
"Oh right, do you know Kanako?"
[cpg cn=true]

Kanako said she had no connection with Ayaka, but I decided to see if there was any truth to that.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Ayaka049"]
[OnName num="ayaka"]
"She's an underclassman. Do you know her?"
[cpg cn=true]

[OnName num="keiichi"]
"A little."
[cpg cn=true]

So, Ayaka had at least heard of her. Either Kanako was a friend or she was well-known at school.
[cpg]

[OnName num="keiichi"]
"So, how do you know Kanako?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayaka050"]
[OnName num="ayaka"]
"She's a bit of a celebrity at school."
[cpg cn=true]

I see. I can imagine Kanako being like that with her personality.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Ayaka051"]
[OnName num="ayaka"]
"I think she is notorious among the teachers, even more than me."
[cpg cn=true]

[OnName num="keiichi"]
"I see. So I take it you're following in her footsteps or something?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Ayaka052"]
[OnName num="ayaka"]
"Maybe so."
[cpg cn=true]

Ayaka leans in towards me. She is going to say something troublesome, isn't she?
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Ayaka053"]
[OnName num="ayaka"]
"Are you dating Kanako, too?"
[cpg cn=true]

[OnName num="keiichi"]
"Yep."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Ayaka054"]
[OnName num="ayaka"]
"Ahaha, I guess that makes her my rival. At least at school."
[cpg cn=true]

......I guess so.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『通勤路』（夜）******************************************************


[VOICE f="Ayaka055"]
[OnName num="ayaka"]
"See you again."
[cpg cn=true]

[OnName num="keiichi"]
"......Sure."
[cpg cn=true]


[SE f="se001"]
;//【ＳＥ】『歩く』

[free time=1000]
[WAIT time=1000]

I wasn't sure I was going to meet with her again.
[cpg]

[OnName num="keiichi"]
"......"
[cpg cn=true]

I walk for a while and when I turned around, Ayaka was already gone.
[cpg]

I felt strange thinking that she might be on her way to see another man.
[cpg]



[jump storage="ep003.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
