

;=========================================================================================

*start

*ep001|世界を巡る旅

[SCENE id=1]

[stflag Cha1flg=1]
[stflag Cha2flg=0]
[stflag Cha3flg=1]
[stflag Cha4flg=0]

[stflag Cha2flg_s=0]
[stflag Cha3flg_s=0]
[stflag Cha4flg_s=0]



[window target=false]

[STOPBGM]

[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[free time=1]
[BG f="b_10_1.ui" time=11]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



And the next morning. I was allowed to stay at Meir's house for a while.
[cpg]


It was natural considering what I had done, but I didn't really feel it.
[cpg]


I was in a daze, thinking about it.
[cpg]


[OnName num="kousuke"]
It's kind of a peaceful place. ......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile004"]
[OnName num="meile"]
It's a holiday today. Everyone is not supposed to be working in the fields today,...... maybe.
[cpg cn=true]


Maybe it's because I've been asleep for so long.
[cpg]


But it's a farming village to see. It's strange to see a beastman farming. ......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile005"]
[OnName num="meile"]
But your brother is a strange man. It's like he has a whiff of our world, or something.
[cpg cn=true]


[OnName num="kousuke"]
What's that? ......
[cpg cn=true]

[window target=false]
[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]


[BG f="b_10_3.ui" time=1000]
[WAIT time=1500]

[WAIT time=100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



The first thing to do is to go around the village and try to find a way to get back to Japan.
[cpg]


It is said that this is a rural area in the land of the beastmen.
[cpg]


The airport is in the city. But ......
[cpg]


I can't help it if I go there. I've been smuggled into Japan twice.
[cpg]


I don't think I can go to the airport and go back to Japan properly.
[cpg]



;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く

[BG f="b_10_3_up_l.ui" time=1000]
[WAIT time=1500]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]

[WAIT time=1000]

[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile006"]
[OnName num="meile"]
You are thinking too much. If you're in trouble, why don't you just ask someone for help?"
[cpg cn=true]


I came back to my house and was greeted by Mail.
[cpg]


[OnName num="kousuke"]
I came back to my house and was greeted by Maille, who asked me, "Where are your parents?　Aren't they on holiday today?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile007"]
[OnName num="meile"]
'They're at church. It's a holiday."
[cpg cn=true]


You go to church in the evening? I wonder if it's a cross-cultural thing.
[cpg]


[OnName num="kousuke"]
"You're not going to the mail?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile008"]
[OnName num="meile"]
I have more important things to do, you know, like ......."
[cpg cn=true]


He invites me over to his house. I was wondering what was going on.
[cpg]



[window target=false]

[free time=1000]

[WAIT time=1000]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1500]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=100]
;//ブラックアウト

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


[window target=true]


[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1000]


;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

Meir sat in his bedroom, on his bed.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile009"]
[OnName num="meile"]
I've been acting strange ever since I met you.
[cpg cn=true]


[OnName num="kousuke"]
What do you mean, strange?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Meile010"]
[OnName num="meile"]
I've never felt this way before. I'm not sure if this is love.
[cpg cn=true]


...... again. The first thing to do is to make sure that you have a good idea of what you're getting into. I've never felt this way before.
[cpg]


The most important thing to remember is that you can't just go out and buy a new car.
[cpg]


I'm not a romantic person, but she's in love with me. ......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile011"]
[OnName num="meile"]
"What's wrong, don't you weird-looking ...... people ever get happy when people say these things to you?"
[cpg cn=true]


[OnName num="kousuke"]
No, no,......
[cpg cn=true]


I don't think it's a good idea to be too speculative in various places when I eventually return to Japan.
[cpg]


But the original purpose is to get a subhuman wife, right?
[cpg]


If you ask me if Meir is my type, I think she's cute.
[cpg]

;//
;//さて、どうしよう……
;//[cpg]
;//
;//
;//
;//
;//
;//;//■選択肢
;//[switch]
;//[case "メイルを口説く"]
;//	[swap]
;//	[jump target="*IseSel01_1"]
;//[case "何もしない"]
;//	[swap]
;//	[jump target="*IseSel01_2"]
;//[endswitch]
;//
;//
;//
;//
;//１、メイルを口説く
;//２、何もしない
;//
;//
;//
;//;//==============================
;//;//１、メイルを口説く
;//*IseSel01_1|世界を巡る旅
;//
;//
;//;//ヒロイン２が攻略対象になる
;//[stflag Cha2flg_s=1]
;//
;//
;//
;//[OnName num="kousuke"]
;//「……誰にでも言ってるわけじゃ無いんだな？」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_2" pos="2/3"]
;//[VOICE f="Meile012"]
;//[OnName num="meile"]
;//「もちろん。こんな気持ちになったことない、って言ったでしょ」
;//[cpg cn=true]
;//
;//
;//[OnName num="kousuke"]
;//「俺も、本当は亜人の奥さんがほしくて旅を始めたんだよ」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_1" pos="2/3"]
;//[VOICE f="Meile013"]
;//[OnName num="meile"]
;//「なら、あたしたちってお似合いじゃないかな？」
;//[cpg cn=true]
;//
;//;//＠
;//[SE f="se001"]
;//;//【ＳＥ】衣擦れ
;//[FG f="CHA02_p7_01_a.ui" method="change_6"  pos="2/3" time=800]
;//
;//
;//隣り合ってベッドに座ると、膝の上に頭をのせてきた。
;//[cpg]
;//
;//
;//[VOICE f="Meile014"]
;//[OnName num="meile"]
;//「良い匂い……落ち着くなぁ」
;//[cpg cn=true]
;//
;//;//＠
;//[FACE method="change_6" pos="2/3"]
;//[VOICE f="sMeile001"]
;//[OnName num="meile"]
;//「……ねえ、このまま寝て良いかな？」
;//[cpg cn=true]
;//
;//
;//こんなことをしていいんだろうか。フィアの時も思ったことだ。
;//[cpg]
;//
;//
;//しかし、罪深いのは今更変わらないか、と思う所もあった……
;//[cpg]
;//
;//;//Ｈシーンカット
;//
;//
;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=100]
;//;//ブラックアウト
;//
;//[jump target="*IseSel01_3"]
;//

;//==============================
;//２、何もしない
*IseSel01_2|世界を巡る旅




[OnName num="kousuke"]
“......I don’t think I can do this……you're not my girlfriend."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile073"]
[OnName num="meile"]
“What...... How can you embarrass a girl like this.”
[cpg cn=true]


[OnName num="kousuke"]
“I don't care what you say, I'm not doing it. I don’t want to be unprincipled.”
[cpg cn=true]


I waited for her parents to come home while I exchanged these words with Meir.
[cpg]



;//==============================

*IseSel01_3|世界を巡る旅


[window target=false]

[free time=1000]

[WAIT time=1000]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4_up_l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************


[window target=true]



Later, Meir’s parents came home.
[cpg]


They served me dinner again……although I felt bad I knew I had to find a way to get back to Japan as soon as possible.
[cpg]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************


[window target=true]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1500]


Information gathering. I’ve been asking the beastmen's around village for information…..
[cpg]


[OnName num="therianthropy_girl_A"]
“Hey there......, you smell nice.”
[cpg cn=true]


[OnName num="therianthropy_girl_B"]
“It's true, ...... and you don't seem like a normal guy.”
[cpg cn=true]


I seem to be very popular around here. I had never experienced anything like this before.
[cpg]


[OnName num="therianthropy_girl_A"]
“If you want, you can come over to my place. I can prepare some delicious herbal tea.”
[cpg cn=true]


[OnName num="therianthropy_girl_B"]
“That’s not fair! I was here first!”
[cpg cn=true]


[OnName num="kousuke"]
“Please tell me how to get back to Japan.”
[cpg cn=true]


Unlike in the land of the elves, they seem to be liberal when it comes to their love affairs.
[cpg]


If this goes on, I will never be able to go back to Japan. But I was also enjoying the harem-like situation.
[cpg]


[window target=false]
[BG f="b_10_3.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]

[BG f="b_10_3_up_l.ui" time=1000]
[WAIT time=1000]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]
[WAIT time=1000]


It was evening again. I know I'm safe as long as I stay here, but if I don't, I won't make any progress.
[cpg]


[OnName num="meile_mother"]
“Well, ...... if you head north from here, there is a settlement where the harpies live.”
[cpg cn=true]


[OnName num="kousuke"]
“I see. ……"
[cpg cn=true]


Harpies. Harpies are a species of bird people, I recall.
[cpg]


If the location is in the north, would I be able to return to Japan from there?
[cpg]


[OnName num="kousuke"]
“Thank you for telling me. I think I'll head to the harpy settlement.”
[cpg cn=true]


[OnName num="meile_mother"]
"I see. It's quite a distance, so you better take some food with you.”
[cpg cn=true]


Meir’s mother has prepared a lot of things. I feel sorry to be a burden.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile074"]
[OnName num="meile"]
“Are you sure you want to go? I want you to stay here forever.”
[cpg cn=true]


[OnName num="kousuke"]
“I can't do that. ...... The elves might be getting closer to find me.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile075"]
[OnName num="meile"]
“The others will stop you too. They say you’re handsome.”
[cpg cn=true]


I'm not sure what to say.......
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile076"]
[OnName num="meile"]
"Please stay here, just one more night. Please."
[cpg cn=true]


[OnName num="kousuke"]
"...... I guess.”
[cpg cn=true]

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1000]

;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]


So I decide to stay at Meir 's for another night.
[cpg]


[OnName num="kousuke"]
「……」
[cpg cn=true]


However I had decided to runaway. Not only had I overstayed my welcome but,
[cpg]


I was also not a fan of the idea of the elves coming after me and bothering them.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[STOPBGM]

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


[WAIT time=1000]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[BG f="b_09_1.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『草原』（朝）******************************************************


[window target=true]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1000]

So I left before Meir woke up.
[cpg]


I could see that she would lecture me before we would part.
[cpg]


[OnName num="kousuke"]
“It's a big country ……."
[cpg cn=true]


I don't even know how far I have to walk to get to the harpy village.
[cpg]


There see a sign. I can barely read the numbers.
[cpg]


I can somehow tell how much further I have to walk to reach the next village or town.
[cpg]


It looks like I’ll have to sleep outside for a day. ......
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[window target=false]

[BG f="b_09_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『草原』（昼）******************************************************


[window target=true]


;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

It's not easy to walk all day long.
[cpg]


It's hard on my back. If I keep going, I'm going to have a lot of chronic diseases by the time I get to Japan.
[cpg]


But now I'm being treated as a criminal. Besides, I have to get back to Japan before my work starts.
[cpg]


With that in mind, I can’t help but walk.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_09_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


[window target=true]



I also have to sleep outside along the way.
[cpg]


I am afraid of running out of food, but I am even more afraid of being caught by the elves.
[cpg]


[OnName num="kousuke"]
"...... hmm?"
[cpg cn=true]


As I am trying to sleep, I have a sense that someone is nearby.
[cpg]


In this empty plain? No way…… Then, a demon-like silhouette appeared.
[cpg]



;//クロロウルードの名前を「悪魔」と隠してください





[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1500]
[WAIT time=2000]
[VOICE f="Clolowlude001"]
[OnName num="devil"]
"...... what? Don't look so curious.”
[cpg cn=true]


Ironically, I was thinking the same thing. The demon-like figure is looking down at me.
[cpg]


[OnName num="kousuke"]
“You're ……?"
[cpg cn=true]



;//クロロウルードの名前を表示してください





[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude002"]
[OnName num="clolowlude"]
"I'm Kullulu Urud. I'm a demon from the underworld.”
[cpg cn=true]


[OnName num="kousuke"]
“…… I see."
[cpg cn=true]


I should have been more surprised, but after everything that had happened. I had never met a demon before though ......
[cpg]


This is not something I was hoping to experience, but I've already been through a lot.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude003"]
[OnName num="clolowlude"]
“You should be more surprised.”
[cpg cn=true]


[OnName num="kousuke"]
“I'm tired. Please leave me alone.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude004"]
[OnName num="clolowlude"]
“So, you're the guy ...... that Chartier was talking about. You’re weaker looking than I had imagined.”
[cpg cn=true]


I wondered what else the demon thought of me.
[cpg]


[OnName num="kousuke"]
“What do you want from me?”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude005"]
[OnName num="clolowlude"]
“Nothing much really”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude006"]
[OnName num="clolowlude"]
“I don't know where you're headed, but this is a too big of a country to be moving on foot.”
[cpg cn=true]


[OnName num="kousuke"]
“Yeah, well, ……"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude007"]
[OnName num="clolowlude"]
“I'm a demon and I can do magic. I thought you might be interested in that?”
[cpg cn=true]


[OnName num="kousuke"]
“…… can you take me back to Japan?”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude008"]
[OnName num="clolowlude"]
“You can use transportation magic to get back to Japan in an instant. But it will consume a lot of magic power, so you can't use it without caution.
[cpg cn=true]


“What? You're not going to get me home after all?” I rolled over and turned my back to her.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude009"]
[OnName num="clolowlude"]
“Hey!I think your attitude is too blatant.”
[cpg cn=true]


[OnName num="kousuke"]
“You just told me you can’t help me, Kullulu.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude010"]
[OnName num="clolowlude"]
“Hey, don’t call me by my name. We’re not that close.”
[cpg cn=true]


[OnName num="kousuke"]
“Whatever. I don't need you. Please let me sleep."
[cpg cn=true]


She clears her throat and begins to talk
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude011"]
[OnName num="clolowlude"]
“My ancestors served the Demon Lord for generations.”
[cpg cn=true]


[OnName num="kousuke"]
"Demon Lord? I've never heard of such a thing.”
[cpg cn=true]


Besides the merger with the other world, I had never heard of a Demon Lord.
[cpg]


I wondered if they were here to take over the world, were they to exist.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude012"]
[OnName num="clolowlude"]
“What kind of a reaction is that ? Not that I care.”
[cpg cn=true]


What was bad about my reaction? I cannot understand the culture of this world.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude013"]
[OnName num="clolowlude"]
“If you go back four generations in my family, you'll find a demon who was the wife of a demon lord.”
[cpg cn=true]


[OnName num="kousuke"]
"So what's the point? I don't what you’re bragging about.”
[cpg cn=true]


I tell her frankly, but Kullulu goes on.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude014"]
[OnName num="clolowlude"]
“The great astrologers of the demon tribe also foresaw this.”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude015"]
[OnName num="clolowlude"]
“I am chosen to be the new queen of the Demon Lord. ...... I have always admired the one who is meant to be the new Demon Lord.”
[cpg cn=true]


[OnName num="kousuke"]
“I can't understand what you're saying. Just get to the point."
[cpg cn=true]


Kullulu’s cheeks turn red. I didn’t know why she is stammering or blushing.
[cpg]



[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_09_2.ui" time=1000]

[WAIT time=1100]
;//【ＢＧ】『草原』（昼）******************************************************

[window target=true]




Even the next day, Kullulu still followed me around.
[cpg]


[OnName num="kousuke"]
“What do you want from me?”
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Clolowlude016"]
[OnName num="clolowlude"]
“I'm trying to figure out. If you're the right guy for me.”
[cpg cn=true]


[OnName num="kousuke"]
“...... Don't tell me you're in love with me.”
[cpg cn=true]


Kullulu doesn't answer. The whole situation seems strange.
[cpg]

[free time=800]

She is acting as if she has a thing for me. I’d never had any luck with humans.
[cpg]


Last night, she was talking about her being the new demon queen. ......
[cpg]


I wonder what it means to be a demon queen. I don't know what the new Demon Lord means either.
[cpg]


[OnName num="kousuke"]
"The new Demon Lord, right? If you're going to be his queen, you might as well go to him.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude017"]
[OnName num="clolowlude"]
"Yes. That's why I'm following you.”
[cpg cn=true]


[OnName num="kousuke"]
"You mean ...... The Demon Lord is in the harpy settlement?"
[cpg cn=true]


Kullulu still doesn’t answer. What was that all about.
[cpg]

[window target=false]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]

[BG f="b_09_4.ui" time=1000]

[WAIT time=1000]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


[window target=true]



Night is coming again. Our food supply is slowly dwindling, and we're feeling impatient. ......
[cpg]

[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
Kullulu being next to me made me less lonely.
[cpg]


If I were to starve to death, Kullulu would take care of me, I think to myself.
[cpg]


[OnName num="kousuke"]
“…….But why can’t you use the magic of transportation”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude018"]
[OnName num="clolowlude"]
“There are many reasons why you cannot return to Japan immediately. You, after all, are ……"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude019"]
[OnName num="clolowlude"]
“I feel a strange attraction towards you. Pheromones, if you will.”
[cpg cn=true]


I didn’t know what she was talking about. I have a lot of questions for Kullulu , but I don't know where to start.
[cpg]



;//
;//
;//;//■選択肢
;//[switch]
;//[case "フェロモンって何だ？"]
;//	[swap]
;//	[jump target="*IseSel02_1"]
;//[case "早く日本に帰りたい"]
;//	[swap]
;//	[jump target="*IseSel02_2"]
;//[endswitch]
;//
;//
;//
;//１、フェロモンって何だ？
;//２、早く日本に帰りたい
;//
;//
;//
;//;//==============================
;//;//１、フェロモンって何だ？
;//
;//
;//*IseSel02_1|世界を巡る旅
;//
;//
;//;//ヒロイン４が攻略対象になる
;//[stflag Cha4flg_s=1]
;//
;//
;//
;//[FACE method="change_7" pos="2/3"]
;//[VOICE f="Clolowlude020"]
;//[OnName num="clolowlude"]
;//「分からない？　まあ、分からないなら、それも良いわ。私から、全部説明する気も無いしね」
;//[cpg cn=true]
;//
;//
;//
;//[window target=false]
;//[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[WAIT time=1]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="heart.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//
;//[window target=true]
;//
;//;//========================================
;//;//●ＣＧエロ（ヒロインに迫られる。至近距離）ev_07
;//;//人物１：ヒロイン４　服装１：着衣
;//;//人物ex：主人公　　　服装ex：私服
;//;//場所　：草原
;//;//時間　：夜
;//;//========================================
;//
;//*Scene000|世界を巡る旅
;//
;//[BG f="black.ui" time=1000]
;//[free time=1000]
;//[WAIT time=1000]
;//
;//[STOPBGM]
;//[BGM f="bg_h1"]
;//;**【ＣＧ】 ev_07_0 ***********************
;//[CG id=2 index=0 time=1000]
;//;***************************************
;//[WAIT time=100]
;//
;//そう言って、彼女は俺に顔を近づけてきた。鼻をすんすんと鳴らしている。
;//[cpg]
;//
;//
;//[OnName num="kousuke"]
;//「ちょっ……お前もかよ」
;//[cpg cn=true]
;//
;//
;//[VOICE f="Clolowlude021"]
;//[OnName num="clolowlude"]
;//「今まで色々あったでしょう。私も……貴方に惹かれてるって事」
;//[cpg cn=true]
;//
;//
;//今まで色々あったのをどうして知ってるんだ。そう思っている間にも彼女は至近距離に居る。
;//[cpg]
;//
;//[OnName num="kousuke"]
;//「待ってくれ。とりあえず離れてくれ」
;//[cpg cn=true]
;//
;//;**【ＣＧ】 ev_07_a ***********************
;//[CG id=2 index=1 time=1000]
;//;***************************************
;//[WAIT time=100]
;//
;//[VOICE f="sClolowlude002"]
;//[OnName num="clolowlude"]
;//「良い匂いだから、もう少し嗅がせて欲しいんだけど」
;//[cpg cn=true]
;//
;//そう言われても俺がどうにかなりそうだ。こんなことばっかり続いて……
;//[cpg]
;//
;//
;//
;//俺の体は普通じゃない。それはなんとなく、フィアやメイルの一件で分かっていた。
;//[cpg]
;//
;//
;//しかし、彼女ほどいきなり……急接近してくるというのは、いくらなんでもおかしい。
;//[cpg]
;//
;//
;//[OnName num="kousuke"]
;//「お前は、何を求めて俺なんかに近づくんだ」
;//[cpg cn=true]
;//
;//;**【ＣＧ】 ev_07_b ***********************
;//[CG id=2 index=2 time=1000]
;//;***************************************
;//[WAIT time=100]
;//
;//[VOICE f="Clolowlude053"]
;//[OnName num="clolowlude"]
;//「貴方自身は気づいてないのね。よくそれで、何もなく暮らせたわね」
;//[cpg cn=true]
;//
;//
;//[OnName num="kousuke"]
;//「もったいぶらずに教えてくれよ」
;//[cpg cn=true]
;//
;//
;//[VOICE f="Clolowlude054"]
;//[OnName num="clolowlude"]
;//「シャルティエから聞いてちょうだい」
;//[cpg cn=true]
;//
;//
;//なんだよ……教えてくれないのか。
;//[cpg]
;//
;//
;//[VOICE f="sClolowlude003"]
;//[OnName num="clolowlude"]
;//「でも……まだ起きられるなら、もう少し話に付き合って欲しいわ」
;//[cpg cn=true]
;//
;//
;//[OnName num="kousuke"]
;//「ああ。俺も俺のことを知りたい」
;//[cpg cn=true]
;//
;//;//＠
;//;[SceneEnd f="sc_005"]
;//
;//;//ブラックアウト
;//
;//[window target=false]
;//[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[WAIT time=1]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[STOPBGM]
;//[WAIT time=200]
;//[transition target={false} rule="heart.webp" color={0x000000ff} time=1]
;//
;//[WAIT time=1100]
;//
;//[BG f="b_09_4.ui" time=1000]
;//
;//[BGM f="bg_d3"]
;//[WAIT time=1000]
;//;//【ＢＧ】『草原』（夜）******************************************************
;//
;//
;//[window target=true]
;//
;//
;//
;//その後、クロロは寝かしてくれなかった。別におかしな意味ではない。
;//[cpg]
;//
;//
;//俺に話したいことがあるようだった。シャルティエについてクロロが話し出す。
;//[cpg]
;//
;//[jump target="*IseSel02_3"]
;//

;//==============================
;//２、早く日本に帰りたい

*IseSel02_2|世界を巡る旅



[OnName num="kousuke"]
“I want to go back to Japan as soon as possible. Please let me go home.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude086"]
[OnName num="clolowlude"]
"It's easy to use the magic of transportation . But I won't let you.”
[cpg cn=true]


[OnName num="kousuke"]
“What……..? Do you have feelings for me?”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude087"]
[OnName num="clolowlude"]
“Don't get cocky. Although…..it’s not a mistake.”
[cpg cn=true]


What was that all about ...... It did not seem like people were hitting on me because I was a demi-human to them.
[cpg]


Was there something going on with my body?
[cpg]



;//==============================


*IseSel02_3|世界を巡る旅


[OnName num="kousuke"]
“…… Oh, by the way, you were talking about Chartier. Can you tell me more about her?”
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Clolowlude088"]
[OnName num="clolowlude"]
“You've already met her right? She's the one who flew the amphibian.”
[cpg cn=true]


That was right. Kullulu is apparently acquainted with Chartier . ......
[cpg]


Which means that this was the fastest way to get back to Japan.
[cpg]


[OnName num="kousuke"]
“If possible, could you tell Chartier ...... that I want to go back to Japan?”
[cpg cn=true]


[OnName num="kousuke"]
“With that amphibian, I should be able to get back.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude089"]
[OnName num="clolowlude"]
“I'd be happy to help you get on an amphibian, but I'm afraid they'll take you to another country.”
[cpg cn=true]


[OnName num="kousuke"]
“Why ……?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude090"]
[OnName num="clolowlude"]
“Because there’s no way that Chartier would let you get back to Japan.”
[cpg cn=true]


I don't know what she is talking about. But ......
[cpg]


It looks like I'll have to return to Japan in something other than her flying boat.
[cpg]

[window target=false]

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_09_1.ui" time=1000]
[WAIT time=1100]
;//【ＢＧ】『草原』（朝）******************************************************


[window target=true]



I have a lot of questions. But I can't overcome my drowsiness, and by the time I wake up, Kullulu was gone.
[cpg]


I walk along the road, still unsure of what is happening.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************



;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1000]


My food supply is running out. Then, I come across three beastman women who seemed to be traveling.
[cpg]


[OnName num="kousuke"]
"Please, could you share some food with me?"
[cpg cn=true]


[OnName num="therianthropy_girl_A"]
“...... What's this guy ...... doing here?”
[cpg cn=true]


[OnName num="therianthropy_girl_B"]
“Can you feel it? It's kind of strange, no?”
[cpg cn=true]


Again. I didn’t care about that, I just want some food. ......
[cpg]



[window target=false]

[BG f="b_09_3.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『草原』（夕方）******************************************************

[window target=true]




I continue to search for someone who could help me get back to Japan, as I get more worn out and get almost attacked by beastmen.
[cpg]


Finally......
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[STOPBGM]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（夕方）******************************************************

[window target=true]




[OnName num="kousuke"]
"So this is it, ......."
[cpg cn=true]


I arrived. This must be the village where the harpy tribe lives.
[cpg]


Harpies have wings. If I'm lucky, they might help me get back to Japan.
[cpg]



[SE f="se001"]
;//【ＳＥ】『倒れる』





But by the time I thought that, I had run out of energy and collapsed.
[cpg]


People really do collapse when they are tired, I thought dimly.
[cpg]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="e_01_3.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





In the meantime, I had a dream. I wasn't asleep, I was supposed to be in a coma, but I dreamt anyway.
[cpg]


Someone is there next to me. I don't know who it is.
[cpg]


I mean, I don't even know who I am. The clothes I see are not to my taste.
[cpg]


I feel as if I were someone else. It is still hazy, yet what I see seems strangely familiar.
[cpg]


I'm in a place that looks like a castle. ...... it doesn’t seem to be Japan.
[cpg]


I wonder where it is. ...... Many demi-humans are kneeling down infront of me.
[cpg]


They treat me as if I were a king or something.
[cpg]



;//画面白く

[BG f="white.ui" time=1000]
[WAIT time=100]

[STOPBGM]

Then I wake up. Everything is still a bit hazy.
[cpg]


The second time I wake up, I am inside a room.
[cpg]


At someone's house. I’m lying on a bed.
[cpg]




[window target=false]

[transition target={true} rule="tobira2.png" color={0xffffffff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira2.png" color={0xffffffff} time=1000]

;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く

[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（朝）******************************************************

[window target=true]



[WAIT time=1100]


I get up and walk outside, where I meet a harpy woman.
[cpg]


[OnName num="harpy_A"]
"Oh, you're ...... awake......?"
[cpg cn=true]


[OnName num="kousuke"]
"......, you saved me?"
[cpg cn=true]



[OnName num="harpy_A"]
“Well, it was someone else who found you......but my room was empty……”
[cpg cn=true]


That seemed like help.
[cpg]


Either way, it seems like the harpies are warm people.
[cpg]


I'm glad they’re not one of those people who would strip a fallen man of his body. But then, there would be nothing to take from me.
[cpg]


[OnName num="kousuke"]
“Thank you for your kindness.”
[cpg cn=true]



[OnName num="harpy_A"]
"Oh, no, you don’t have to thank me, I'm just doing what's ...... natural."
[cpg cn=true]


[OnName num="harpy_B"]
“Oh! The man is awake……"
[cpg cn=true]


[OnName num="harpy_C"]
“How are you feeling? Are you hungry?”"
[cpg cn=true]


Watching us talk, other harpies join us. They're all women.
[cpg]


I wonder if there are male harpies. There aren’t any in this room to say the least.
[cpg]


I've never been this popular with humans.
[cpg]


There was something odd about them, but I couldn't figure out what it was.
[cpg]


[OnName num="harpy_B"]
“Don’t keep him all to yourself.”
[cpg cn=true]


[OnName num="harpy_C"]
“Come to my house, I'll buy you breakfast.”
[cpg cn=true]


[OnName num="harpy_A"]
“What’s going on, hey!”
[cpg cn=true]


The first girl I met also pulls my hand. It's like they were fighting over me.
[cpg]


[OnName num="kousuke"]
“Don't pull……"
[cpg cn=true]


This feeling of discomfort has been with me ever since I arrived here in the land of the demi-humans.
[cpg]


I wondered why this was happening. The answer to that question was hard to find.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（昼）******************************************************


;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1100]

I walk around the village of the harpy tribe for a while.
[cpg]


I try to make arrangements to return to Japan.
[cpg]


The men in the village are sympathetic, but not kind.
[cpg]


It was only the women who I could rely on, as a result. Only women would be kind to me. ......
[cpg]


That means, I should rely on women.
[cpg]


I had a lot to think about, but it looked like I wouldn't have to worry about food for a while.
[cpg]




[window target=false]

[BG f="b_01_3.ui" time=1500]
[WAIT time=1500]
;//【ＢＧ】『ハーピー族の集落』（夕方）******************************************************

[window target=true]


But still, I couldn't find anyone who looked like her family. I wondered about that, so I asked her.
[cpg]

[OnName num="kousuke"]
“Do you live alone?"
[cpg cn=true]


[OnName num="harpy_A"]
“Yes……but my parents live just around the corner.”
[cpg cn=true]


[OnName num="kousuke"]
“…….? Why?”
[cpg cn=true]


[OnName num="harpy_A"]
“I have to get married soon. ……"
[cpg cn=true]



[OnName num="harpy_A"]
“That's why my parents built their house first.”
[cpg cn=true]


I didn’t know that such a situation existed. I guess our human culture is different.
[cpg]


[OnName num="kousuke"]
“More importantly, ...... can I stay at your house again today?”
[cpg cn=true]



[OnName num="harpy_A"]
"Yes. If it's okay with you.”
[cpg cn=true]


She looked embarrassed, and her cheeks turned strangely red.
[cpg]


To be honest, she looked like she was in love. It was definitely not normal.
[cpg]


[OnName num="kousuke"]
"....... What kind of a state are you in right now?”
[cpg cn=true]



[OnName num="harpy_A"]
“What do you mean by that?”
[cpg cn=true]


[OnName num="kousuke"]
“I've seen this happen to demi-humans too many times.”
[cpg cn=true]


[OnName num="kousuke"]
“Is there something wrong with me? What do they see in me?”
[cpg cn=true]



[OnName num="harpy_A"]
“There is something ...... magical about you, you don't seem ...... like a normal person.”
[cpg cn=true]


I had been told that, but no matter how many times I thought about it, I could not sense it.
[cpg]




[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=10]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（夜）******************************************************

[window target=true]
[WAIT time=100]

A few days later. As I spent time in the Harpy clan's village, the following happened.
[cpg]


[OnName num="harpy_A"]
...... The stars are beautiful, aren't they?
[cpg cn=true]


[OnName num="kousuke"]
"Yes, they are. They are not this beautiful in Japan.”
[cpg cn=true]



[OnName num="harpy_A"]
“You know, ......, I thought love at first sight did not exist.”
[cpg cn=true]


See? This is what happens.
[cpg]


[OnName num="harpy_A"]
“But then I saw you, and I realized it really does exist.”
[cpg cn=true]


[OnName num="kousuke"]
"Love at first sight."
[cpg cn=true]


Love at first sight, love at first sight. Why is that happening to everyone?
[cpg]



[OnName num="harpy_A"]
“I have a brother who passed away. You look just like him.”
[cpg cn=true]



[OnName num="harpy_A"]
“It's not that I was in love with my brother, but I feel so much more relaxed when I'm with ...... you.”
[cpg cn=true]


Everyone seems like they want to get to know me more.
[cpg]


Should I just accept it?
[cpg]


Of course, it would be a bad idea to cause trouble, but I didn't care anymore.
[cpg]



The fact that I want a demi-human wife hasn't changed.
[cpg]


It's not a bad feeling to be liked by a girl.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_11_4.ui" time=1000]
[WAIT time=1000]

I can't do nothing, but I also can't think of what to do.
[cpg]

I was afraid that if I tried to kiss her, something would happen to me.
[cpg]

[OnName num="harpy_A"]
"What do you mean by something, ......?"
[cpg cn=true]

[OnName num="kousuke"]
“If there's magic in my body, it would be transferred……”
[cpg cn=true]

I'm talking from my imagination, but I don't think I'm way off.
[cpg]

What should I do? Would a hug be enough? Would I make her feel uncomfortable?
[cpg]

;//Ｈシーンカット

[STOPBGM]

[WAIT time=1000]


[window target=false]

[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[BGM f="bg_tc"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（朝）******************************************************

[window target=true]



Then, early in the morning, I got some news.
[cpg]


[OnName num="harpy_B"]
"Oh my God! The elves are looking for you, Kosuke !”
[cpg cn=true]


[OnName num="harpy_A"]
"Oh, really, ......? What are you doing here, Kosuke ?”
[cpg cn=true]


[OnName num="kousuke"]
"Well, it's actually……a false charge.”
[cpg cn=true]


Saying that wouldn’t convince them. I decided to explain everything.
[cpg]


I was seen with an elven woman, and was accused of seduction.
[cpg]


As I listened to the story, the first girl I met had a bit of a clouded expression on her face, but well, that was expected. ...... I know the feeling.
[cpg]


[OnName num="harpy_C"]
“What should we do, Kosuke ...... Why not run away?”
[cpg cn=true]


[OnName num="kousuke"]
“When you say run away, how are you planning on doing that?”
[cpg cn=true]


The question is “where?" rather than “how?”.
[cpg]



[OnName num="harpy_A"]
“You should run away to ...... Japan. It’s hard to enter the country from the land of the elves.”
[cpg cn=true]


If I could do that, I wouldn't be struggling. I think to myself.
[cpg]



[OnName num="harpy_A"]
“Can’t us harpies deliver Kosuke to Japan.....?"
[cpg cn=true]


[OnName num="harpy_B"]
“...... Yes, we could. We don't know what will happen if the elves catch him.”
[cpg cn=true]


[OnName num="kousuke"]
“Are you sure? I don’t have any money.”
[cpg cn=true]


[OnName num="harpy_C"]
“You can pay for it later. For now, just rely on us.”
[cpg cn=true]


They are so kind to me that I don't know why they are doing this.
[cpg]


But I guess ...... Chartier knows why.
[cpg]


[OnName num="kousuke"]
“But ...... It’s hard to carry me, it's too far away.”
[cpg cn=true]


[OnName num="harpy_A"]
“Us harpies can use wind magic, so we can fly as fast as an airplane."
[cpg cn=true]


“I didn't know that. That's new to me. I've never heard of that, but isn't “as fast as an airplane” too fast ……?"
[cpg]


[OnName num="harpy_B"]
"Whatever it is, the sooner we leave, the better. What do you say?"
[cpg cn=true]


[OnName num="kousuke"]
“Well, can you ask ……?"
[cpg cn=true]


[OnName num="harpy_A"]
“Yes, sir. No problem.”
[cpg cn=true]



[BG f="black.ui" time=1000]
[STOPBGM]
;//ブラックアウト



[SE f="se001"]
;//【ＳＥ】『羽ばたく』

[WAIT time=2000]


[BG f="b_11_1.ui" time=1000]


[WAIT time=1000]

[BGM f="bg_d1"]


So, with the help of the three harpies, I was going to make my way back to Japan.
[cpg]


I was held in a hug. The opposite of a piggyback.
[cpg]


I was wrapped in a unique cloth that looked like a larger version of the one used to swaddle babies.
[cpg]


Because of their wings, they could not carry me in a piggyback.
[cpg]


And the fact that he had such a tool meant that he probably made a living out of it.
[cpg]


I mean, if I fell, I would die, right? More to the point, don't harpies get tired?
[cpg]


[OnName num="harpy_A"]
“We don't get tired. We're a specie that specializes in...... flying."
[cpg cn=true]


I wonder if that's possible. How can one carry a single person and not let it bother the flying?
[cpg]


[free time=800]


As I was thinking that, I found out that the harpies were taking shifts to carry me.
[cpg]


After doing this several times, Japan came into my view.
[cpg]


I was so relieved that I almost cried.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="101.jpg" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="101.jpg" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（昼）******************************************************


;//＠
[SE f="se011"]
;//【ＳＥ】『人混み』


Probably Kyushu. As we got closer, I saw a modern town.
[cpg]



[OnName num="harpy_A"]
.”..... So this is Japan. It's so close, but I've never been here before.”
[cpg cn=true]


[OnName num="harpy_B"]
"That's true. Shall we do some sightseeing?”
[cpg cn=true]


[OnName num="harpy_C"]
“I'd like to take a break.”
[cpg cn=true]


[OnName num="kousuke"]
“Hold on a second.”
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



[SE f="se009"]
;//【ＳＥ】『走る』





I run to the nearest bank, withdraw some money and come back ......
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[WAIT time=1]
[STOPBGM]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（昼）******************************************************


[window target=true]

[WAIT time=100]


[OnName num="kousuke"]
“Thanks for the ride. If you can exchange the money there, please use this.”
[cpg cn=true]


I gave him money to cover more than a plane ride, but also to thank him for saving my life.
[cpg]


[OnName num="harpy_A"]
“Thank you very much. But we couldn’t take that amount”
[cpg cn=true]


[OnName num="kousuke"]
“Please. ...... I can’t thank you enough for saving my life.”
[cpg cn=true]



[OnName num="harpy_A"]
“I guess it’s time for us to leave now. I'm sure the elven nation will not interfere with Japan.”
[cpg cn=true]


[OnName num="kousuke"]
“I hope so ...... I really appreciate your help.”
[cpg cn=true]



;//ブラックアウト

[window target=false]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『街＿現代』（夜）******************************************************

[window target=true]



By the time I get back to my house, it is midnight.
[cpg]


I had to go back to work tomorrow. ......
[cpg]


[OnName num="kousuke"]
“Man, that was close. ……"
[cpg cn=true]


It really was a close call. I was about to loose everything.
[cpg]



[free time=1000]
;//[BG f="black.ui" time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************



I feel like I've been through a lot, and I feel like I've had some good things happen to me.
[cpg]


Eventually, I was able to smuggle myself out and sneak back in.
[cpg]


I even managed to make it back home during my vacation.
[cpg]


I was relieved, but I thought about it again. What would it be like to marry a demi-human girl?
[cpg]


After all, there is an enormous difference in our culture and race. Plus, I’ve even been chased by the elves.
[cpg]


And then there are the legal procedures and the customs of the otherworlders. In conclusion, it's a hassle.
[cpg]


I decided to end my dreaming and stay a normal salaryman.
[cpg]

[STOPBGM]
[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_03_1.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
;//【ＢＧ】『街＿現代』（朝）******************************************************


[window target=true]


The next morning, I head to work, feeling quite exhausted.
[cpg]


Work would not wait for me. It wrung me out.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





My co-workers ask me if I had lost weight. I guess I have.
[cpg]


I had a lot going on at once.
[cpg]


When I think back about it……
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

Fia . Meir . Chartier . Kullulu . ......
[cpg]

[free time=800]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

They were all cute and beautiful, but I'll never see them again.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[free time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『街＿現代』（夕方）******************************************************

[window target=true]
[WAIT time=100]



Should I have exchanged contact information with at least one of them? I don't even know if they have any contact information to begin with.
[cpg]


If I had given them my phone number, would they have called me? Would they even have a phone?
[cpg]


I returned home with an indescribable feeling.
[cpg]


Work was surprisingly manageable.
[cpg]


But my heart felt inexplicably empty.
[cpg]


I head home, and there stood: .......
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1500]
[STOPBGM]
;//ブラックアウト





[OnName num="kousuke"]
「……」
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Fia056"]
[OnName num="fia"]
「……」
[cpg cn=true]


I froze at front of the door. A familiar face was standing there.
[cpg]


[window target=false]

[free time=1000]
[WAIT time=1500]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************

[window target=true]




[OnName num="kousuke"]
"...... Well, come on in.”
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Fia057"]
[OnName num="fia"]
“Sorry to bother you.”
[cpg cn=true]


Fia . Why is she here?
[cpg]


[OnName num="kousuke"]
“How did you get here? I mean, what for?”
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Fia058"]
[OnName num="fia"]
I've been wanting to see you….. Kosuke.”
[cpg cn=true]


I am popular in an unusual way.
[cpg]


I can't believe that someone I've only met once likes me so much.
[cpg]


I'm surprised, but Fia says she had been wanting to see me.
[cpg]


[OnName num="kousuke"]
“What are you going to do? Are you going to stay here?”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia059"]
[OnName num="fia"]
“If you don’t want me here, I’m determined to stay outside.”
[cpg cn=true]


[OnName num="kousuke"]
“I can't let you do that. ……"
[cpg cn=true]


I have an indescribable feeling.
[cpg]


It’s not a demi-human wife, but I could say I have a demi-human girlfriend.
[cpg]


I'm also worried that the elves will come after me again.
[cpg]


[OnName num="kousuke"]
“My room is pretty big, right? I think two or three people could stay here.”
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Fia060"]
[OnName num="fia"]
“In that case……."
[cpg cn=true]


[OnName num="kousuke"]
"You can stay here. I won't be able to pay for food and amenities for too long though.”
[cpg cn=true]


Fia has a big smile on her face.
[cpg]


[FACE method="change_2" pos="2/3"]
;;[t_move pos=C 下礼]
[VOICE f="Fia061"]
[OnName num="fia"]
"Thank you so much!"
[cpg cn=true]


She bowed her head. I really felt…… speechless.
[cpg]


What will happen to me now?
[cpg]

[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_03_1.ui" time=1000]
[WAIT time=1500]

[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（朝）******************************************************

[window target=true]



I left some money for food at home. There’s even a place to sleep.
[cpg]


So, there is no way that Fia can't survive here.
[cpg]


I grin a little. I've never lived with a girl before.
[cpg]



;//※ヒロイン１とヒロイン３は最初から攻略対象となっている

;//■分岐

;//==============================
;//ヒロイン２が攻略対象となっている場合のみイベント発生

[if exp={getFlagValue("Cha2flg_s") == 1 }]
[jump target="*eve_01_1"]
[else]
[jump target="*eve_01_2"]
[endif]


*eve_01_1|世界を巡る旅


[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夕方）******************************************************



;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1000]


While I think about the current situation, I meet another subhuman.
[cpg]


Not just any subhuman, but the one I met during my trip, she was ......
[cpg]


[BG f="b_03_3_up_l.ui" time=1000]
[WAIT time=1500]

[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile077"]
[OnName num="meile"]
“Oh.”
[cpg cn=true]


[OnName num="kousuke"]
"...... Meir ?"
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile078"]
[OnName num="meile"]
“I looked everywhere for you, Kosuke . I found you with your scent.”
[cpg cn=true]


[OnName num="kousuke"]
“Hold on. Aren’t you supposed to be able to use magic?”
[cpg cn=true]


I can still understand how Fia found my house. It must have been with magic or something.
[cpg]


But isn't it weird that Meir can do the same thing?
[cpg]


[OnName num="kousuke"]
"How did you find me?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile079"]
[OnName num="meile"]
“I told you, I found you by scent.”
[cpg cn=true]


That's ridiculous. But then again, she did find me.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile080"]
[OnName num="meile"]
"Hey, can I go to your house? I came all the way to Japan just for you.”
[cpg cn=true]


I couldn't say no, so I headed to the house. ......
[cpg]


Even if I did refuse, I still have to go home. Even if I leave her alone, Meir wiould come to my house.
[cpg]



;//ブラックアウト
[window target=false]
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************

[window target=true]

;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く
[WAIT time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Fia062"]
[OnName num="fia"]
“Welcome home ......, the beastly one ……?"
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile081"]
[OnName num="meile"]
"Huh? Elf ......? Kosuke, what’s going on?
[cpg cn=true]


The two of them had never met before. Their reaction was expected.
[cpg]


[OnName num="kousuke"]
"Well, ......, she's Fia . The reason of why I'm being chased."
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Meile082"]
[OnName num="meile"]
“So you followed Kosuke here, too?”
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="Meile083"]
[OnName num="meile"]
“I'm Meir . Nice to meet you.”
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Fia063"]
[OnName num="fia"]
“Nice to meet you……."
[cpg cn=true]


As a result the three of us spend time together in this small room.
[cpg]


Although I was a bit taken aback, Meir was going to stay with us.
[cpg]

[window target=false]

[STOPBGM]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（朝）******************************************************

[window target=true]




The three of us were cramped together. The situation is like a man's dream, but it is still hard to sleep.
[cpg]


I wake up early in the morning and decide to leave the house before the two of them.
[cpg]


I leave a note for Fia and Meir, telling them to go sightseeing in Japan during the day.
[cpg]


Especially Meir, who can't stand to be stuck in a small space.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





The week continues. I'd like to spend some time with my demi-human girlfriend, but that's not allowed.
[cpg]


I have a normal day of work ahead of me. It's been a long holiday, and I am extremely busy.
[cpg]

[window target=false]

[STOPBGM]
[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]

[transition target={true} rule="39.png" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="39.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************


[window target=true]



In the evening, I can finally be with the two of them. ......
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sMeile002"]
[OnName num="meile"]
"Hey, Kosuke. Are you not going try to do anything to me?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Fia064"]
[OnName num="fia"]
"Hey, you're a little ...... too close."
[cpg cn=true]


While Meir is attached to me, Fia is trying to pull me away.
[cpg]

[free time=800]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/2" time=800]

[VOICE f="sMeile003"]
[OnName num="meile"]
"Didn't Fia try to do something with you as well? Why are you stopping me?”
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia065"]
[OnName num="fia"]
“...... That's true, but…"
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile086"]
[OnName num="meile"]
“You don't like demi-humans or beastmen ……?"
[cpg cn=true]


Even as Meir was closing in on me, she seemed to have a complex about herself as a beast.
[cpg]


I was not sure what to say.
[cpg]



;//
;//
;//;//■選択肢
;//[switch]
;//[case "答えない"]
;//	[swap]
;//	[jump target="*IseSel04_1"]
;//[case "嫌いじゃない"]
;//	[swap]
;//	[jump target="*IseSel04_2"]
;//[endswitch]
;//
;//
;//
;//１、答えない
;//２、嫌いじゃない
;//
;//

;//==============================
;//１、答えない
*IseSel04_1|世界を巡る旅



[OnName num="kousuke"]
「……」
[cpg cn=true]


[FACE method="change_5" pos="1/2"]
[VOICE f="Meile087"]
[OnName num="meile"]
“……"
[cpg cn=true]


[FACE method="change_4" pos="2/2"]
[VOICE f="Fia066"]
[OnName num="fia"]
“Oh, um, I don't think ...... Kosuke is the kind of person who would discriminate like that.”
[cpg cn=true]


[FACE method="change_4" pos="1/2"]
[VOICE f="Meile088"]
[OnName num="meile"]
“Yeah, I know. I know. Right Kosuke?”
[cpg cn=true]


I couldn't reply. I was a little annoyed that she had barged into our conversation.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[if exp={getFlagValue("Cha2flg") == 1 }]
[stflag Cha2flg=-1]
[endif]


;//ヒロイン２は攻略対象でなくなる


;//
;//[jump target="*IseSel04_3"]
;//
;//;//==============================
;//;//２、嫌いじゃない
;//
;//*IseSel04_2|世界を巡る旅
;//
;//
;//
;//[OnName num="kousuke"]
;//「嫌いじゃない。そんなはずないだろ」
;//[cpg cn=true]
;//
;//
;//[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="1/2" time=800]
;//[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
;//[VOICE f="Meile089"]
;//[OnName num="meile"]
;//「ありがとうっ」
;//[cpg cn=true]
;//
;//;//＠
;//[SE f="se001"]
;//;//【ＳＥ】衣擦れ
;//
;//メイルが抱きついて、俺を押し倒してくる。
;//[cpg]
;//
;//
;//[FACE method="change_7" pos="1/2"]
;//[FACE method="change_7" pos="2/2"]
;//[VOICE f="sMeile004"]
;//[OnName num="meile"]
;//「……康介。ねぇ、あたし……もっとそばに居たいよ」
;//[cpg cn=true]
;//
;//
;//隣にはフィアも居るんだぞ、と言おうとしたけど、
;//[cpg]
;//
;//
;//[FACE method="change_2" pos="2/2"]
;//[VOICE f="Fia067"]
;//[OnName num="fia"]
;//「あ、あの……わたくし、買い物に行ってきます」
;//[cpg cn=true]
;//
;//
;//
;//[move from="2/2" to="5/3" ease="easeInOutSine" time=1000]
;//
;//[SE f="se004"]
;//;//【ＳＥ】『ドア閉まる』
;//
;//
;//
;//
;//
;//フィアはお金も持ってないというのに、部屋を出て行ってしまった。
;//[cpg]
;//
;//
;//[FACE method="change_6" pos="1/2"]
;//[WAIT time=1]
;//[move from="1/2" to="2/3" ease="easeInOutSine" time=1000]
;//
;//[VOICE f="sMeile005"]
;//[OnName num="meile"]
;//「フィア、気を遣ってくれたね」
;//[cpg cn=true]
;//
;//
;//[OnName num="kousuke"]
;//「……ああ」
;//[cpg cn=true]
;//
;//
;//
;//
;//;//ブラックアウト
;//
;//[window target=false]
;//[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[WAIT time=1]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//
;//[window target=true]
;//
;//
;//
;//いいのかなと思いつつ、住まわせている費用の元を取ろうというような気持ちだった。
;//[cpg]
;//
;//[VOICE f="sMeile006"]
;//[OnName num="meile"]
;//「やっぱり、康介って良い匂いがするよね」
;//[cpg cn=true]
;//
;//[OnName num="kousuke"]
;//「だから、それは自覚がないんだよな……」
;//[cpg cn=true]
;//
;//[VOICE f="sMeile007"]
;//「すぅー……すぅー……んんっ、たまんない！」
;//[cpg cn=true]
;//
;//
;//;//========================================
;//;//●ＣＧエロ（主人公に迫るヒロイン。体の上に乗っている）ev_01
;//;//人物１：ヒロイン２　服装１：着衣
;//;//人物ex：主人公　　　服装ex：着衣
;//;//場所　：主人公の部屋＿現代
;//;//時間　：夜
;//;//========================================
;//
;//*Scene007|世界を巡る旅
;//
;//[STOPBGM]
;//
;//
;//[BG f="black.ui" time=1000]
;//[free time=1000]
;//[WAIT time=1000]
;//
;//;//＠
;//[SE f="se001"]
;//;//【ＳＥ】衣擦れ
;//
;//[BGM f="bg_h1"]
;//;**【ＣＧ】 ev_01_0 ***********************
;//[CG id=0 index=0 time=1000]
;//;***************************************
;//[WAIT time=100]
;//
;//
;//と言ったかと思うと、メイルは俺の上にのしかかってきた！
;//[cpg]
;//
;//[OnName num="kousuke"]
;//「ちょ、ちょっと待て。お前野生にかえってないか」
;//[cpg cn=true]
;//
;//
;//;**【ＣＧ】 ev_01_a ***********************
;//[CG id=0 index=1 time=1000]
;//;***************************************
;//[WAIT time=100]
;//
;//俺がそう言うと、メイルは頬を膨らませて怒った表情になった。
;//[cpg]
;//
;//[VOICE f="sMeile008"]
;//[OnName num="meile"]
;//「そんなことないよ。獣人だからって馬鹿にしてるでしょ」
;//[cpg cn=true]
;//
;//確かに獣人に対して野生という言い方はまずいか。
;//[cpg]
;//
;//[OnName num="kousuke"]
;//「い、いや……」
;//[cpg cn=true]
;//
;//いずれにせよ、このまま何もされないとは思えない。
;//[cpg]
;//
;//俺にもその覚悟はない、と思っていると体を倒して俺の胸元に顔を近づけてきた。
;//[cpg]
;//
;//
;//;**【ＣＧ】 ev_01_0 ***********************
;//[CG id=0 index=0 time=1000]
;//;***************************************
;//[WAIT time=100]
;//
;//[VOICE f="sMeile009"]
;//[OnName num="meile"]
;//「すぅー、ふぅーっ……ずっとそばに居たくなっちゃう」
;//[cpg cn=true]
;//
;//彼女はそんなことをいいながら、また元の姿勢に戻る。
;//[cpg]
;//
;//[VOICE f="sMeile010"]
;//[OnName num="meile"]
;//「んんーっ、フィアが居なかったら何でもしてあげるのになぁ」
;//[cpg cn=true]
;//
;//思わせぶりなことを言うメイル。困惑して俺はたずねる。
;//[cpg]
;//
;//[OnName num="kousuke"]
;//「何でもって、何だよ」
;//[cpg cn=true]
;//
;//にやりと笑ってメイルはもう一度顔を近づけてくる。
;//[cpg]
;//
;//;**【ＣＧ】 ev_01_b ***********************
;//[CG id=0 index=2 time=1000]
;//;***************************************
;//[WAIT time=100]
;//
;//[VOICE f="sMeile011"]
;//[OnName num="meile"]
;//「いやらしいこと考えてるでしょ」
;//[cpg cn=true]
;//
;//[OnName num="kousuke"]
;//「お前のせいだろ！」
;//[cpg cn=true]
;//
;//[VOICE f="sMeile012"]
;//[OnName num="meile"]
;//「ふふんっ。やっぱりそうなんだ」
;//[cpg cn=true]
;//
;//メイルはいたずら好きな性格らしい。いや、なんとなく分かってはいたけど……
;//[cpg]
;//
;//;//Ｈシーンカット
;//
;//
;//[window target=false]
;//[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[WAIT time=1]
;//[STOPBGM]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="heart.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//
;//[BG f="b_04_4.ui" time=1000]
;//
;//[WAIT time=1500]
;//[BGM f="bg_d3"]
;//
;//[WAIT time=100]
;//;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************
;//
;//
;//[window target=true]
;//
;//[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="4/2" time=1]
;//[WAIT time=1]
;//
;//
;//
;//[move from="4/2" to="2/2" ease="easeInOutSine" time=1000]
;//
;//[VOICE f="Fia068"]
;//[OnName num="fia"]
;//「お、お邪魔します……」
;//[cpg cn=true]
;//
;//
;//しばらくいちゃついた後、フィアが恐る恐る部屋に戻ってきた。
;//[cpg]
;//
;//
;//気まずい。フィアもそうだし、メイルもそうだ。
;//[cpg]
;//
;//
;//[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
;//[VOICE f="sMeile013"]
;//[OnName num="meile"]
;//「もうすこし二人きりで居たいなあ」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_3" pos="2/2"]
;//[VOICE f="sFia005"]
;//[OnName num="fia"]
;//「そんなの、メイルさんばっかりずるいですよ」
;//[cpg cn=true]
;//
;//;//＠
;//;//フィアが謝ることは何も無いと思うが、それでも謝ってきた。
;//;//[cpg]
;//
;//
;//
;//[free time=800]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//[STOPBGM]
;//[WAIT time=1000]
;//;//ブラックアウト
;//
;//
;//
;//[stflag Cha2flg=1]
;//;//ヒロイン２は攻略対象のまま
;//
;//
;//
;//;//==============================
;//
;//
;//*IseSel04_3|
;//

*eve_01_2|世界を巡る旅

;//
;//;//==============================
;//
;//
;//;//■分岐
;//
;//
;//;//==============================
;//
;//;//ヒロイン４が攻略対象となっている場合のみイベント発生
;//
;//[if exp={getFlagValue("Cha4flg_s") == 1 }]
;//[jump target="*eve_04_1"]
;//[else]
;//[jump target="*eve_04_2"]
;//[endif]
;//
;//
;//*eve_04_1|世界を巡る旅
;//
;//;//■分岐
;//
;//;//■分岐
;//
;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=100]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[BG f="black.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_03_4.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//[STOPBGM]
;//[BGM f="bg_si"]
;//[WAIT time=100]
;//;//【ＢＧ】『街＿現代』（夜）******************************************************
;//
;//
;//
;//
;//
;//ある平日の夜。彼女は現れた。
;//[cpg]
;//
;//
;//[BG f="b_03_4_up_l.ui" time=1000]
;//[WAIT time=1500]
;//
;//[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
;//
;//
;//[OnName num="kousuke"]
;//「……お前は」
;//[cpg cn=true]
;//
;//
;//[VOICE f="Clolowlude091"]
;//[OnName num="clolowlude"]
;//「来てあげたわよ。感謝しなさい」
;//[cpg cn=true]
;//
;//
;//クロロが来ていた。俺は、クロロにも思わせぶりなことしてしまったかと思い出す。
;//[cpg]
;//
;//
;//まだ家に戻る途中。家の所まで連れて行ったらフィアはどう思うだろう……
;//[cpg]
;//
;//
;//なんて考えながらも、クロロを家に上げないのはまずいよな。
;//[cpg]
;//
;//
;//[FACE method="change_7" pos="2/3"]
;//[VOICE f="Clolowlude092"]
;//[OnName num="clolowlude"]
;//「貴方の家はどこなの？　良かったら、上げて欲しいんだけど」
;//[cpg cn=true]
;//
;//
;//良かったら、とは言っているがほとんど強制だ。
;//[cpg]
;//
;//
;//彼女は魔法を操る。ここで断ればどうなるか分からない。
;//[cpg]
;//
;//
;//
;//;//ブラックアウト
;//[window target=false]
;//
;//[STOPBGM]
;//
;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1500]
;//
;//[BG f="b_04_4.ui" time=1000]
;//[WAIT time=1500]
;//[BGM f="bg_d3"]
;//[WAIT time=100]
;//;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************
;//
;//
;//[window target=true]
;//
;//
;//
;//[OnName num="kousuke"]
;//「というわけで、クロロ……っていう、悪魔か？」
;//[cpg cn=true]
;//
;//
;//[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
;//[VOICE f="Clolowlude093"]
;//[OnName num="clolowlude"]
;//「ええ、悪魔よ。あと、名前はクロロじゃなくてクロロウルードね」
;//[cpg cn=true]
;//
;//;//[free time=800]
;//
;//[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
;//
;//[VOICE f="Fia075"]
;//[OnName num="fia"]
;//「……」
;//[cpg cn=true]
;//
;//
;//フィアは呆れているだろうな。どれだけの女性に声をかけたのかと思ってるだろう。
;//[cpg]
;//
;//
;//
;//*eve_05_2|世界を巡る旅
;//
;//;//■分岐
;//
;//;//[free time=800]
;//
;//
;//[FACE method="change_1" pos="1/2"]
;//[FACE method="change_1" pos="2/2"]
;//
;//[VOICE f="Fia077"]
;//[OnName num="fia"]
;//「はじめまして……クロロウルードさん」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_2" pos="2/2"]
;//[VOICE f="Clolowlude096"]
;//[OnName num="clolowlude"]
;//「ええ、はじめまして。略さずに呼んでくれるのは嬉しいわ」
;//[cpg cn=true]
;//
;//
;//クロロ、やっぱりそこにこだわりがあるんだな。
;//[cpg]
;//
;//
;//
;//;//ブラックアウト
;//
;//[STOPBGM]
;//
;//[window target=false]
;//
;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[free time=1]
;//[BG f="b_04_1.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[BGM f="bg_d3"]
;//[WAIT time=100]
;//;//【ＢＧ】『主人公の部屋＿現代』（朝）******************************************************
;//
;//
;//[window target=true]
;//
;//
;//
;//そして、フィアが目を覚ます前。クロロが、俺を起こしてきた。
;//[cpg]
;//
;//
;//*eve_05_3|世界を巡る旅
;//
;//
;//
;//[OnName num="kousuke"]
;//「……何だよ」
;//[cpg cn=true]
;//
;//
;//[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
;//[VOICE f="Clolowlude097"]
;//[OnName num="clolowlude"]
;//「やっぱり、貴方のフェロモンは健在ね」
;//[cpg cn=true]
;//
;//
;//[OnName num="kousuke"]
;//「だから、それを言われても俺は分からないんだって」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_6" pos="2/3"]
;//[VOICE f="Clolowlude098"]
;//[OnName num="clolowlude"]
;//「分からない、じゃ済まされないわ。現に私は……虜になってるし」
;//[cpg cn=true]
;//
;//
;//これは。この流れは、あまりよくない。
;//[cpg]
;//
;//
;//[FACE method="change_7" pos="2/3"]
;//[VOICE f="Clolowlude099"]
;//[OnName num="clolowlude"]
;//「……フィアだって、貴方の事を放っておかなかったでしょう」
;//[cpg cn=true]
;//
;//
;//[OnName num="kousuke"]
;//「それとこれとは、話が違うだろ」
;//[cpg cn=true]
;//
;//
;//と拒んでも、クロロは俺にすり寄ってくる。
;//[cpg]
;//
;//[OnName num="kousuke"]
;//「まずいって……フィアが起きたらどうするんだ」
;//[cpg cn=true]
;//
;//*eve_06_3|世界を巡る旅
;//
;//
;//[FACE method="change_2" pos="2/3"]
;//[VOICE f="Clolowlude122"]
;//[OnName num="clolowlude"]
;//「見せつけてあげるだけよ」
;//[cpg cn=true]
;//
;//
;//クロロは結構な無茶を言っていた。だけど、逆の立場だったらそうかもな……
;//[cpg]
;//
;//
;//[OnName num="kousuke"]
;//「……いちゃつくならせめて、他に誰も居ないときにしよう」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_1" pos="2/3"]
;//[VOICE f="sClolowlude004"]
;//[OnName num="clolowlude"]
;//「いちゃつくこと自体はいいのね？」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_6" pos="2/3"]
;//[VOICE f="Clolowlude124"]
;//[OnName num="clolowlude"]
;//「感謝しなさいよ。私みたいな美人が、こんなに迫ってるんだから」
;//[cpg cn=true]
;//
;//
;//自分で言うか、と思いながらも……確かに綺麗な人だ。
;//[cpg]
;//
;//;//Ｈシーンカット
;//
;//

;//==============================

*eve_04_2|世界を巡る旅

;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[STOPBGM]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_04_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夕方）******************************************************

[window target=true]




I was going to be living with a demi-human girl for a while.
[cpg]


Fia was cooking for me, using Japanese ingredients that she was not familiar with.
[cpg]


I didn't understand the situation, but I thought it was okay because I was happy.
[cpg]


The cost of living is a bit high, but I can manage that for a while with my savings.
[cpg]


[OnName num="kousuke"]
" Fia, what's for dinner today?"
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia078"]
[OnName num="fia"]
“I tried to make miso soup, but I'm not too sure if it’s good.”
[cpg cn=true]


[OnName num="kousuke"]
“It's amazing. They don't have miso soup in the elf country.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia079"]
[OnName num="fia"]
“Yes, ......, but there was something on TV the other day about miso soup being good for you.”
[cpg cn=true]


An elf watching TV. It felt kind of strange.
[cpg]

[free time=1000]

;//＠
[SE f="se012"]
;//【ＳＥ】テレビをつける（スイッチを押す）

I went to the dining table and turned on the TV.
[cpg]


[OnName num="kousuke"]
"...... what?"
[cpg cn=true]


I was carefree and enjoyed living together. However, the situation was more serious than I thought.
[cpg]


What I saw on the TV news was my face.
[cpg]


I was so surprised that I could not react. If you ask me what I had done to make the news, I might have done it.
[cpg]


[OnName num="news_caster"]
"Wanted criminal last seen in elf country ......"
[cpg cn=true]


Wanted criminal. I was surprised by the word "wanted", but even more so by ......
[cpg]


The reason why I was being hunted in the land of the elves seemed to be for a reason other than to catch me for the crime of tricking Fia .
[cpg]


The person on the TV, who seemed to be the chief of the elves, said this.
[cpg]


[OnName num="elven_chief"]
“He is a reincarnation of the Demon Lord. ...... There have been signs of this for some time.”
[cpg cn=true]


[OnName num="elven_chief"]
“He seems to be a man in his twenties, but he must have just realized. The prophecy is true.”
[cpg cn=true]


Apparently now I’m a reincarnated Demon Lord due to the prophecy and sensitive magic of the elves.
[cpg]


I'm not aware of that at all. It's so sudden that I don't understand a thing.
[cpg]


In the first place, I had broken the law to come to the land of the elves, and even then I was being hunted. ......
[cpg]


But it would be a different story if I were to be a reincarnation of a Demon Lord.
[cpg]



;//==============================
;//ヒロイン２が攻略対象となっている場合のテキスト

;//■分岐
[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*eve_07_1"]
[else]
[jump target="*eve_07_2"]
[endif]


*eve_07_1|Journey around the world

[free time=800]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Meile119"]
[OnName num="meile"]
"Wow, Kosuke ! You’re the reincarnation of a Demon Lord.”
[cpg cn=true]


[OnName num="kousuke"]
"Wait a minute. I don't know anything about that.”
[cpg cn=true]

[jump target="*eve_07_3"]

;//==============================
;//ヒロイン２が攻略対象となっていない場合のテキスト

;//■分岐

*eve_07_2|世界を巡る旅


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia080"]
[OnName num="fia"]
“Mr. Kosuke……, is that true?”
[cpg cn=true]


[OnName num="kousuke"]
“No, no ...... I don't know either."
[cpg cn=true]



;//==============================

*eve_07_3|世界を巡る旅

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]

[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************





The television continued to show the news. There seemed to be an announcement from the land of the elves this afternoon, and it was all over the news.
[cpg]


The Demon Lord has so much power that even weapons are useless.
[cpg]


It was even said that the world would become his ...... when he appears.
[cpg]


I’d be thrown into jail if I were to get caught.
[cpg]

[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[OnName num="kousuke"]
"What should I do, Fia ......, I don't want to die."
[cpg cn=true]


Fia makes a difficult face. And then she said,
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia081"]
[OnName num="fia"]
“Why don't you go to ...... the land of the beasts?”
[cpg cn=true]


She is right.
[cpg]


[free time=800]

It wouldn’t be a good idea to stay in Japan or head to the land of the elves.
[cpg]


If I stayed in the country of the beastmen I could buy some time. But I would still get caught.
[cpg]


I wouldn’t be able to fully protect myself.
[cpg]




;//==============================
;//ヒロイン４が攻略対象となっている場合のテキスト

;//■分岐
[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_08_1"]
[else]
[jump target="*eve_08_2"]
[endif]



*eve_08_1|世界を巡る旅



[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude148"]
[OnName num="clolowlude"]
“There’s no use to be frightened right now.”
[cpg cn=true]


[OnName num="kousuke"]
“Kullulu, have you known this for a long time?”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude149"]
[OnName num="clolowlude"]
“Yes, of course.”
[cpg cn=true]


Was that so? ...... Did the demi-humans want me because I was a Demon Lord?
[cpg]

[jump target="*eve_08_3"]

;//==============================
;//ヒロイン４が攻略対象となっていない場合のテキスト

;//■分岐

*eve_08_2|世界を巡る旅


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia082"]
[OnName num="fia"]
"You don't look so good, Mr. Kosuke……."
[cpg cn=true]


[OnName num="kousuke"]
"...... Oh, yeah, ...... I guess."
[cpg cn=true]



;//==============================

*eve_08_3|世界を巡る旅

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_04_4.ui" time=1000]

[WAIT time=1500]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************

[window target=true]



It's night. If I don't sleep, I won't be able to go to the office tomorrow, but going to the office is also a bad idea.
[cpg]


What should I do? Will I even be able to eat tomorrow?
[cpg]



[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

[WAIT time=1100]



Just as I am thinking this, I see someone coming to my house.
[cpg]


The police. I am scared, but I have to answer.
[cpg]


With determination, I unlocked the door before .......
[cpg]


The door unlocked from the outside. Then I saw the face of the person who opened the door.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye018"]
[OnName num="schartye"]
"What a look on his face. The Demon Lord..."
[cpg cn=true]


[OnName num="kousuke"]
“You, ......, now what?”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye019"]
[OnName num="schartye"]
"Is that how you want to talk to me? Doesn't the Demon Lord need any help?"
[cpg cn=true]


[OnName num="kousuke"]
“...... No, no. I'd appreciate it if you could help me.”
[cpg cn=true]

[free time=800]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Fia083"]
[OnName num="fia"]
“Well, who is this?”
[cpg cn=true]


[OnName num="kousuke"]
“This is Chartier . It's a long story…..”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Schartye020"]
[OnName num="schartye"]
"To put it simply, I am the one who took the Demon Lord around the world.”
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Schartye021"]
[OnName num="schartye"]
“It was all a setup for this day, Demon Lord.”
[cpg cn=true]


[OnName num="kousuke"]
“...... Please don't call me the Demon Lord.”
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Schartye022"]
[OnName num="schartye"]
“The beastman kingdom is still developing. You know that, don't you, Demon Lord?”
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Schartye023"]
[OnName num="schartye"]
“That means you can be a king there.”
[cpg cn=true]


[OnName num="kousuke"]
“What do you mean, ……?"
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Schartye024"]
[OnName num="schartye"]
“If you're a king, you need to build your kingdom.”
[cpg cn=true]




[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[free time=1]
[STOPBGM]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="163.jpg" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_03_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夜）******************************************************


[window target=true]



So it was decided that I would head to the land of the beastman.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia084"]
[OnName num="fia"]
“I've heard rumors about the amphibian ......, but I've never seen one before.”
[cpg cn=true]

[VOICE f="sFia006"]
[OnName num="fia"]
“I don't know how something so big can float.”
[cpg cn=true]


[OnName num="kousuke"]
“I don't know either. ...... It must be magic or something.”
[cpg cn=true]



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye025"]
[OnName num="schartye"]
“Don't be lazy. Let's go."
[cpg cn=true]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト
;//【ＢＧ】『空』（夜）******************************************************



[SE f="se005"]
;//【ＳＥ】『魔法発動する音　シンセパッド系』


[WAIT time=1500]



Then we flew out of Japan with the demi-human girl.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
During the journey, Chartier explained to me about my being.
[cpg]


Apparently, I have a pheromone that intensely attracts demi-humans,and my saliva, for example, contains magical elements.
[cpg]

[VOICE f="sSchartye001"]
[OnName num="schartye"]
“A demi-human who is kissed by you might have an increase in magic power. That's how much magic element it contains."
[cpg cn=true]

[OnName num="kousuke"]
“You're lying. ……"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSchartye002"]
[OnName num="schartye"]
“It's not a lie. It has the power to attract mainly women, but even men will be happy to see the Demon Lord return.”
[cpg cn=true]


[OnName num="kousuke"]
「そんなものか……？」
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye027"]
[OnName num="schartye"]
“Yes. Demi-humans don't take kindly to being vulnerable at the moment.”
[cpg cn=true]


While we are talking about this, the airship takes off.
[cpg]


The suspicious passengers are not here today.
[cpg]

[free time=800]


;//==============================
;//ヒロイン４が攻略対象となっていない場合のみイベント発生

;//■分岐
[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_10_2"]
[endif]




[OnName num="kousuke"]
"So, ...... where is she?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude150"]
[OnName num="clolowlude"]
"...... what?"
[cpg cn=true]


Before I knew it, Chartier was with Kullulu Urud.
[cpg]


She's apparently acquainted with Chartier .
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude151"]
[OnName num="clolowlude"]
“I'm here to help. I hope you don't mind.”
[cpg cn=true]


For some reason, she wants to help me build my country.
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Clolowlude152"]
[OnName num="clolowlude"]
"The return of the Demon Lord is a long-cherished dream for us demi-humans,” she said.
[cpg cn=true]


She said the same thing as Chartier .
[cpg]



;//==============================


*eve_10_2|世界を巡る旅


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[STOPBGM]
[BG f="b_10_1.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



Then we arrived at the land of the beastmen. It is not possible to suddenly declare oneself king and become king.
[cpg]


At any rate, we headed for the village where Meir was.
[cpg]



;//==============================
;//ヒロイン２が攻略対象となっていない場合のみイベント発生

;//■分岐
[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*eve_11_2"]
[endif]



On my way there, I naturally met Meir again.
[cpg]


She was surprised, but seemed happy.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile120"]
[OnName num="meile"]
" Kosuke ......! Why are you here?"
[cpg cn=true]


[OnName num="kousuke"]
"Oh, oh, ......, it's a long story."
[cpg cn=true]


I recounted the story. I told her that I was being hunted more than ever before.
[cpg]


I explained that I was going to start my own country and she said she would help me with that.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile121"]
[OnName num="meile"]
"So you're a Demon Lord, Kosuke……! No wonder I thought you were out of the ordinary."
[cpg cn=true]


I couldn't keep up with her excitement. I was rather worried.
[cpg]


Isn't it too early to accept? I still hadn’t caught up with the fact.
[cpg]


Maybe it's because it was about myself.......
[cpg]


;//続くのでリセットで転調



;//==============================

*eve_11_2|世界を巡る旅




;//続くのでリセットで転調
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_1.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


;//==============================

*eve_12_2|世界を巡る旅



Then Chartier begins to explain;
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye028"]
[OnName num="schartye"]
“I will gather the people of this village. The Demon Lord himself will not go to the village.”
[cpg cn=true]


[OnName num="kousuke"]
"But, but ……"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye029"]
[OnName num="schartye"]
"All you have to do is stay put."
[cpg cn=true]

[free time=800]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Clolowlude153"]
[OnName num="clolowlude"]
“That's right. You don't need to be afraid.”
[cpg cn=true]


I feel like I should be afraid……
[cpg]

[STOPBGM]


[free time=1000]
[window target=false]

[BG f="b_10_3.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



The beastmen from all over the village have gathered. Wait they've gathered from outside the village?
[cpg]


There are so many of them. There are about a thousand of them.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Schartye030"]
[OnName num="schartye"]
"Listen up! The Demon Lord has been resurrected here and now!”
[cpg cn=true]


[VOICE f="Clolowlude154"]
[OnName num="clolowlude"]
“We are his dependents! In order to protect the Demon Lord, and to create a world for him, ……"
[cpg cn=true]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye031"]
[OnName num="schartye"]
“ We have to sacrifice ourselves. What is our longing?”
[cpg cn=true]


It's a strange atmosphere. Fia seems a little frightened, but Meir is swallowed into the atmosphere.
[cpg]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye032"]
[OnName num="schartye"]
“What is our longing? It is to reign the world”
[cpg cn=true]


Cheers erupt. This is not good. I'm not that kind of person.
[cpg]


[OnName num="therianthropy_A"]
"Oh, Demon Lord ......, I would give my life for you."
[cpg cn=true]


[OnName num="therianthropy_B"]
“I'll take part of any kind of battle. I won't let the humans and elves have their way with you!”
[cpg cn=true]


[free time=800]

In any case, they seem to be pleased with the Demon Lord's resurrection, and everyone is worshipping me.
[cpg]


[OnName num="kousuke"]
"...... Oh, yeah. I'm the Demon Lord, maybe ......."
[cpg cn=true]


I decide to call myself the Demon Lord, although it’s an unsettling feeling
[cpg]

[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]




That night was like a banquet. It seems that the Demon Lord is a very important person to the demi-humans.
[cpg]


A short distance away from the party, Chartier and I talk.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye033"]
[OnName num="schartye"]
"Maybe it's time to tell everything."
[cpg cn=true]


[OnName num="kousuke"]
“What do you mean, "everything" ......? What's going on?”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye034"]
[OnName num="schartye"]
“It's not much, but it's important.”
[cpg cn=true]


She tells me that she knew from the beginning that I was the reincarnation of the Demon Lord.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye035"]
[OnName num="schartye"]
"I took you on a trip as a prelude to this. I didn't send you back to Japan right away so that you could make friends in each place."
[cpg cn=true]


Chartier explained. Then Kullulu came.
[cpg]


[free time=800]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Clolowlude155"]
[OnName num="clolowlude"]
“What are the two of you are talking about?”
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Schartye036"]
[OnName num="schartye"]
“We were talking about why we took the Demon Lord on the trip.”
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude156"]
[OnName num="clolowlude"]
“Oh. Well, it's hard to understand without an explanation, isn't it?”
[cpg cn=true]


I was becoming more and more aware of it as she was talking.
[cpg]


It is true that Fia would not have become one of us if we had not gone to the land of the elves.
[cpg]


It's also possible that if I hadn't met Meir in person, we wouldn't have been able to ask for her help right away.
[cpg]


[OnName num="kousuke"]
“What would have happened if I had stayed in Japan without knowing?”
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye037"]
[OnName num="schartye"]
“You would have out of the blue realized and probably been killed.”
[cpg cn=true]


I shudder. Was it just by the skin of my teeth, or did this journey lead to my awakening as a Demon Lord?
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="sSchartye003"]
[OnName num="schartye"]
“Let me tell you one more thing. Your qualities as a demon lord are awakened when you connect with a demi-human.”
[cpg cn=true]


[OnName num="kousuke"]
"Awakening ...... what?"
[cpg cn=true]


When I asked her about the details, he said that falling in love with a demi-human, kissing her, or something like that would remind his soul that he was a Demon Lord.
[cpg]


The theory seemed to be that it was because they had created a harem of demi-humans in the past.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="sSchartye004"]
[OnName num="schartye"]
"The former Demon Lord had countless children with demi-human daughters. What about the current Demon Lord?"
[cpg cn=true]


[OnName num="kousuke"]
「……」
[cpg cn=true]


I think back. It's not so much a replacement as it is a ......
[cpg]


[FACE method="change_7" pos="2/2"]
[VOICE f="sClolowlude005"]
[OnName num="clolowlude"]
“In any case, the number of people you connect with in the future will probably change your personality as well.”
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Schartye040"]
[OnName num="schartye"]
“That's right. Whether you want world domination or peace depends on how much of your nature as a demon lord returns.”
[cpg cn=true]


[OnName num="kousuke"]
“...... Is it true, Kullulu . Everything you've said so far is true?”
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude158"]
[OnName num="clolowlude"]
“There's nothing to deny.”
[cpg cn=true]


I knew it. ...... My nature changes when I fall in love with a demi-human girl.
[cpg]


If I get too tempted, I guess I will revive as a Demon Lord.
[cpg]


I couldn't tell if that was a good thing or a bad thing.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude159"]
[OnName num="clolowlude"]
"Whatever it is, you should be grateful to Chartier . You're still in danger of being killed."
[cpg cn=true]


I felt like I had gotten myself into a terrible situation, but I was determined to protect myself as the Demon Lord.
[cpg]



;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[free time=1]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="163.jpg" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_10_1.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



It is morning, and everyone's excitement has calmed down a bit.
[cpg]


Still, it seemed that everyone respected me.
[cpg]


Men and women bowed deeply when they came near me.
[cpg]


[OnName num="kousuke"]
"The Demon Lord, the Demon Lord......."
[cpg cn=true]


But even though I'm the Demon Lord, there's no sign that I can use magic.
[cpg]


I can't use magic because I've never used it before. I decided to talk to Fia and Meir about it.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile122"]
[OnName num="meile"]
“I don't know much about magic myself.”
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="Fia085"]
[OnName num="fia"]
"I do have some knowledge."
[cpg cn=true]


[OnName num="kousuke"]
“Well, could you teach me? I’m a Demon Lord, I should be able to use some of it.”
[cpg cn=true]


It's a matter of image. Since I’m a Demon Lord, I should be able to use magic.
[cpg]


So the three of us, Fia and Meir and I, talk about magic.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia086"]
[OnName num="fia"]
“Magic, like anything else, can only be achieved through a combination of ...... effort and talent.”
[cpg cn=true]


[OnName num="kousuke"]
“What about me? I can work hard, but talent?”
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Meile123"]
[OnName num="meile"]
“I can sense some kind of magical power from Kosuke , but ……"
[cpg cn=true]


Meir doesn't refer to me as the Demon Lord. But I guess that’s that.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia087"]
[OnName num="fia"]
“You're not wrong. Kosuke seems to have ...... tremendous magical qualities."
[cpg cn=true]


Fia says, holding out her hand towards me.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia088"]
[OnName num="fia"]
“...... Perhaps Chartier or Kullulu Urud would be a better choice than me to teach you.”
[cpg cn=true]


[OnName num="kousuke"]
"Well, I guess those two can do magic."
[cpg cn=true]


Fia tells me that I have strong magical qualities, but don't know how to use them.
[cpg]


So, I was taught magic by Fia, Chartier and Kullulu .
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=100]
;//ブラックアウト





Fia and Kullulu were not so keen, but Chartier was willing to teach me magic.
[cpg]


She wasn't talking too fast, but she was giving me so much information that I was confused.
[cpg]


[WAIT time=500]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye041"]
[OnName num="schartye"]
“You get the gist? Now let's talk about how the summoning magic works.”
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Fia089"]
[OnName num="fia"]
“We should take a break here. Kosuke, you look tired.”
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye042"]
[OnName num="schartye"]
“Are you tired? I wouldn’t know.”
[cpg cn=true]


I was so tired that I deliberately showed it in my attitude. I don’t understand everything I was explained.
[cpg]


But it was a matter of life and death for me, so I took it seriously.
[cpg]


[window target=false]
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]


Several days and nights passed.
[cpg]


I was to stay in the country of the beastmen, in a house that was intended for ...... guests in that village.
[cpg]


But sooner or later, I'll have to build a castle or something, or I'll be attacked.
[cpg]

[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





With that in mind, I successfully performed my first magic.
[cpg]



[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』



;//フラッシュ
[BG f="white.ui" time=1000]
[WAIT time=1000]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1000]

;//【ＢＧ】『村＿獣人の国』（昼）******************************************************






The three of us, Fia , Chartier , and I, were in a magic class. However, it seems that Fia doesn't know as much as Chartier .
[cpg]


[OnName num="kousuke"]
"Did it work?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Fia090"]
[OnName num="fia"]
“Yes, it did. The magic of summoning ...... should have helped you summon the ideal demon you envisioned, but this is……."
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="sSchartye005"]
[OnName num="schartye"]
“A tentacled creature. Wonderful."
[cpg cn=true]


Tentacles. They are buzzing and wriggling.
[cpg]


It's red and black and creepy, but I see, this is the demon I've been looking for.
[cpg]


[OnName num="kousuke"]
「……」
[cpg cn=true]

It's an indescribable feeling to be told that this demon lived inside my head.
[cpg]

But it's true that I don't like dragons, gryphons, and other cool demons.
[cpg]


I do like horror movies. I guess that's the image I have.
[cpg]



[FACE method="change_7" pos="1/2"]
[VOICE f="sSchartye006"]
[OnName num="schartye"]
"After all, he is the reincarnation of the former Demon Lord. I can feel the remnants of that man."
[cpg cn=true]


[OnName num="kousuke"]
“...... Is that so?”
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="sSchartye007"]
[OnName num="schartye"]
“Yeah. You should be able to control it. You can use it as you wish.”
[cpg cn=true]


[OnName num="kousuke"]
「……」
[cpg cn=true]


I even got a seal of approval from Chartier .
[cpg]

The tentacled creature is still buzzing. Fia is frightened to see it.
[cpg]

[FACE method="change_7" pos="2/2"]
[VOICE f="sFia007"]
[OnName num="fia"]
"Yes, in case of emergency, ...... it might be a fighting force."
[cpg cn=true]

says Fia. But my head was somewhere else.
[cpg]

I was wondering if I could use this to play a trick on the girls.
[cpg]

It's not that I've regained my old memories, but I think I was thinking something similar before I was reincarnated. ......
[cpg]


I had such a vague memory in my mind.
[cpg]


[OnName num="kousuke"]
“How do I get rid of this ……?"
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Fia091"]
[OnName num="fia"]
“Hold on a second.”
[cpg cn=true]


[FACE method="change_5" pos="1/2"]
[VOICE f="Schartye046"]
[OnName num="schartye"]
“...... Hey, you're getting tangled up.”
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia092"]
[OnName num="fia"]
“…… Wait a minute, please.”
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『触手絡みつく』


[BG f="b_10_2_l.ui" time=1000]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



Then there was an agony. My magic power was too strong and the tentacle creature went out of control.
[cpg]


It got entangled in Chartier 's body and wouldn't leave.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Schartye047"]
[OnName num="schartye"]
"Demon Lord! ...... What am I supposed to do with this?"
[cpg cn=true]


[OnName num="kousuke"]
"Oh, don't ask me! Fia , what should I do ......?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Fia093"]
[OnName num="fia"]
"Wait a minute, you can do the opposite of summoning. ...... Uh, wait a minute."
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Fia094"]
[OnName num="fia"]
“Where did I put the grimoire to erase a spell ……?"
[cpg cn=true]


[OnName num="kousuke"]
“I don't know! You don't have it?”
[cpg cn=true]

[FACE method="change_5" pos="2/2"]
[VOICE f="sFia008"]
[OnName num="fia"]
“I'll go look for it!”
[cpg cn=true]

[move from="2/2" to="4/2" ease="easeInOutSine" time=1000]




With that, Fia left the scene to get out of danger.
[cpg]


I turned to Chartier thinking, "Oh, come on.”
[cpg]



;//========================================
;//●ＣＧ（触手に絡まれるヒロイン。逃げだそうとしている）ev_14
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：触手　　　　服装ex：無し
;//場所　：村＿獣人の国
;//時間　：昼
;//========================================

*Scene012|世界を巡る旅

[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=100]


[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[WAIT time=1000]


[VOICE f="sSchartye008"]
[OnName num="schartye"]
"I can't ...... unwind it.”
[cpg cn=true]
[OnName num="kousuke"]
“You all right, Chartier ?”
[cpg cn=true]

[VOICE f="sSchartye009"]
[OnName num="schartye"]
"It's slimy and not very pleasant.……"
[cpg cn=true]

[VOICE f="sSchartye010"]
[OnName num="schartye"]
"But when I think of the demons that the Demon Lord created, I..."
[cpg cn=true]

[OnName num="kousuke"]
“Don't raise your voice. ……"
[cpg cn=true]

I feel like I'm being naughty.
[cpg]

[OnName num="kousuke"]
“What should I do, I didn’t want this to happen.”
[cpg cn=true]

;**【ＣＧ】 ev_14_a ***********************
[CG id=1 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sSchartye011"]
[OnName num="schartye"]
“I don't know, either. I think the Demon Lord can control it to some extent. ……"
[cpg cn=true]


I see. If I can manipulate it to my will, then I can just remind it to let go.
[cpg]

[OnName num="kousuke"]
“Hold on a second, Chartier.”
[cpg cn=true]

[VOICE f="sSchartye012"]
[OnName num="schartye"]
“All I can do is wait, because I'm stuck.”
[cpg cn=true]
[OnName num="kousuke"]
"I'm sorry, ......."
[cpg cn=true]

I apologize and try my best to imagine releasing her.
[cpg]

But that was not enough to control the demons.
[cpg]

Just thinking about it would not help Chartier.
[cpg]



;[SceneEnd f="sc_012"]

;[Live2d target=0]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



The scene looks familiar as I try. I tell that to Chartier .
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sSchartye013"]
[OnName num="schartye"]
"I see. The more you do this, the more your qualities as a demon lord will come back.”
[cpg cn=true]

[FACE method="change_6" pos="1/2"]
[VOICE f="sSchartye014"]
[OnName num="schartye"]
“I'm not going to be displeased. It's not that I can't say anything I don't like.”
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="4/2" time=1]

This was the same as her previous claim.
[cpg]

[move from="4/2" to="2/2" ease="easeInOutSine" time=1000]

[VOICE f="Fia095"]
[OnName num="fia"]
" Chartier , I figured out how to remove it! I'm going to remove it now!"
[cpg cn=true]


But then Fia came back.
[cpg]


After that, I figured out how to remove the tentacles and Chartier was released. ......
[cpg]


[STOPBGM]

[free time=1000]
[WAIT time=1000]
[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************

[window target=true]




A few days passed. I was gradually gaining more and more magic that I could use.
[cpg]


One day, a messenger from Japan and the land of the elves came to visit.
[cpg]


Fia took care of it for me. Or rather, I ordered her to do it.
[cpg]


I'm afraid to meet them in person. Chartier or Kullulu might take the messenger alive.
[cpg]


I thought that Fia would be the best choice.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Fia096"]
[OnName num="fia"]
“They said they would not kill you if you surrendered”
[cpg cn=true]


[OnName num="kousuke"]
“...... What do you think?”
[cpg cn=true]



[VOICE f="Meile124"]
[OnName num="meile"]
“Hmmm ...... I think it's best not to trust them.”
[cpg cn=true]


Meir looks at Kullulu .
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude160"]
[OnName num="clolowlude"]
“Maybe the elven magic will seal you in for life and you won't be able to die.”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Schartye070"]
[OnName num="schartye"]
"Probably."
[cpg cn=true]


They say. Fia did not deny it. It's a much worse situation than one might imagine.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





From that day on I decided to stay in the castle.
[cpg]


Just temporarily. The village where Meir lived, the place where the chief lived.
[cpg]


The chief didn’t seem to mind at all. As a fact his house was the strongest one.
[cpg]


Of course, it does not have as much protection as a castle.
[cpg]


But of course, it doesn't have the defensive capabilities of a castle. Still, if the other side uses force, Chartier and Kullulu say they'll take care of it.
[cpg]


Without knowing how much I can rely on them, our days of studying magic passed by.
[cpg]



;//==============================
;//ヒロイン２が攻略対象となっている場合のみイベント発生

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*eve_13_1"]
[else]
[jump target="*eve_13_2"]
[endif]



*eve_13_1|世界を巡る旅


;//■分岐
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************





I can't sleep, so I decide to walk around the village at night.
[cpg]


Everyone is so carefree. This village could have been invaded.
[cpg]


But ...... I wonder if they would do anything for me?
[cpg]


Or do they think that if they were to attack, it would only be me who were to get killed?
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile125"]
[OnName num="meile"]
"Ah. Kosuke."
[cpg cn=true]


[OnName num="kousuke"]
"Oh. ...... Meir ?"
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile126"]
[OnName num="meile"]
“What's wrong with you? You don't look well.”
[cpg cn=true]


[OnName num="kousuke"]
“No, nothing's wrong.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile127"]
[OnName num="meile"]
“Everyone in my village welcomes you. You should be more proud of yourself.”
[cpg cn=true]


[OnName num="kousuke"]
“You say that, but ...... I'm in fear of my life.”
[cpg cn=true]


“You may be right, but" Meir begins.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile128"]
[OnName num="meile"]
"We demi-humans have been discriminated just because we are demi-humans.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile129"]
[OnName num="meile"]
“I'm sure everyone is thinking about the chance to change that.”
[cpg cn=true]


That's too much be burdened with. But I couldn't do nothing.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile130"]
[OnName num="meile"]
“Are you keeping an eye on ...... Fia ?”
[cpg cn=true]


[OnName num="kousuke"]
" Fia? What about Fia ?”
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sMeile014"]
[OnName num="meile"]
"It's not just Fia . It's also me....... We're all crazy about you.”
[cpg cn=true]


[OnName num="kousuke"]
“....... Yeah, that's true.”
[cpg cn=true]


They are all under the influence of my pheromones.
[cpg]


It was time for me to understand that.
[cpg]


Maybe I should at least love the people who are near me.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile132"]
[OnName num="meile"]
"Hey, Kosuke. Come here for a minute."
[cpg cn=true]


Meir is looking for something. I knew it, and I took her up on her offer.
[cpg]


[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

[BG f="b_10_4_l.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************



I stayed by her side for a while. I felt her warmth against my shoulder.
[cpg]

[FG f="CHA02_p7_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMeile015"]
[OnName num="meile"]
"Hey ...... Kosuke ."
[cpg cn=true]

She seemed to be begging for a kiss, but my kisses contain magic elements.
[cpg]

So I didn't want to get Meir into any trouble. ......
[cpg]



I decided to stop.
[cpg]



[VOICE f="sMeile016"]
[OnName num="meile"]
“Do you not care abut me Kosuke? Do you not want to do anything?”
[cpg cn=true]


[OnName num="kousuke"]
"It's not that I don't want to, but there are ...... circumstances."
[cpg cn=true]


I wondered if Meir would be convinced if I explained everything.
[cpg]


Meir looked sad, but nodded.
[cpg]


;//==============================

*eve_13_2|世界を巡る旅

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





A few more days pass. My efforts were about to bear fruit.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye071"]
[OnName num="schartye"]
"......, that's about right. That's about as good as it gets."
[cpg cn=true]


[OnName num="kousuke"]
"Huh, how's this……?"
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Fia097"]
[OnName num="fia"]
“It's amazing, Mr. Kosuke . It's really a level that no ordinary wizard can reach.”
[cpg cn=true]


As a result of the training, I was able to use magic almost decently.
[cpg]


Although I do not know a lot of spells, the ones that I know have a lot of power.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="sFia009"]
[OnName num="fia"]
“This is the reincarnation of the Demon Lord,......, he’s more powerful than one can imagine.”
[cpg cn=true]

;//;[FO layer="1/2"]



[FACE method="change_2" pos="1/2"]
[VOICE f="Schartye072"]
[OnName num="schartye"]
“I'm not surprised. We were not wrong with the assessment."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude161"]
[OnName num="clolowlude"]
“You're right, it's more than I imagined. I'm a little more impressed.”
[cpg cn=true]


[OnName num="kousuke"]
"Oh, yeah ......?"
[cpg cn=true]


I didn't feel so bad. And I wondered if I could protect myself a little ......
[cpg]

[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_3.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



Well, now that I can protect myself. What to do next: ......
[cpg]


[OnName num="kousuke"]
“I do want a castle. We are being too careless right now."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Fia098"]
[OnName num="fia"]
“I agree, but there's no way ...... we're going to get the manpower.”
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[FACE method="change_7" pos="1/2"]

[VOICE f="Meile183"]
[OnName num="meile"]
“Don't you think there are more people in this village?”
[cpg cn=true]


[OnName num="kousuke"]
“Sure. There's been a lot of people here lately.”
[cpg cn=true]


Beastmen and demi-humans gathered around us.
[cpg]

[FACE method="change_2" pos="2/2"]
[FACE method="change_7" pos="1/2"]
[VOICE f="Fia099"]
[OnName num="fia"]
“Why are they gathering. ……"
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[FACE method="change_7" pos="1/2"]

[VOICE f="Meile184"]
[OnName num="meile"]
“It's all over the news. They want to help you Kosuke ."
[cpg cn=true]


[OnName num="kousuke"]
“I see. ……"
[cpg cn=true]


It seems that they are coming from all over the beastman country.
[cpg]


If that's the case, let's get them to help us build the castle.
[cpg]


[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************


[window target=true]



The castle is built little by little.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
I am not in charge of the construction, but Chartier is.
[cpg]


[OnName num="kousuke"]
"Does Chartier know anything about construction?"
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye073"]
[OnName num="schartye"]
“No. It's just a good idea to have someone to give instructions in order to make people aware that they are working for the Demon Lord.”
[cpg cn=true]


[OnName num="kousuke"]
“That makes sense.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye074"]
[OnName num="schartye"]
“This the way we should do it. The Demon Lord will only gives orders when it's really important.”
[cpg cn=true]


[OnName num="kousuke"]
“All right. I will do that.”
[cpg cn=true]


Having said that, I still can't really believe that this is all real.
[cpg]



;//ブラックアウト
[window target=false]
[STOPBGM]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_03_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（昼）******************************************************

[window target=true]




The time is ticking away. I could easily imagine that the way the world will look at me is gradually going change.
[cpg]


The fact that I was gaining power as the Demon Lord, and that I was starting to build a castle, felt like someone was watching me.
[cpg]


[window target=false]

;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_02_2.ui" time=1000]

[WAIT time=1500]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************

[window target=true]




Although the whole country is not trying to destroy me, ......
[cpg]


The same thing was already about to happen.
[cpg]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************





[OnName num="kousuke"]
"Assassins ......?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Fia100"]
[OnName num="fia"]
“Yes. Chartier and Kullulu Urud said they found ...... them.”
[cpg cn=true]


It seemed that many assassins had come from the land of the elves, who particularly despised the Demon Lord.
[cpg]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye075"]
[OnName num="schartye"]
“There's nothing to worry about. So far, Kullulu Urud and me have managed to do everything.”
[cpg cn=true]


Chartier said that, but I was not in the mood.
[cpg]


I just hope that the castle will be completed soon. ......
[cpg]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_10_4.ui" time=1000]

[WAIT time=1500]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]


;//==============================
;//ヒロイン４が攻略対象となっている場合のみイベント発生
[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_14_1"]
[else]
[jump target="*eve_14_2"]
[endif]


*eve_14_1|世界を巡る旅


[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1500]


;//■分岐

;//室内ですので上下に黒帯を入れてください

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1000]
That night, I shared my concerns with Kullulu .
[cpg]


She was sleeping in a guest bedroom, so I went to visit her.
[cpg]


Kullulu was about to fall asleep, and got up from the bed, rubbing her eyes.
[cpg]


[OnName num="kousuke"]
“..... Sorry to bother you this late at night.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude162"]
[OnName num="clolowlude"]
“Don't apologize, and don't worry about it. You seem to have a lot of luck.”
[cpg cn=true]


I wondered if she was complimenting me, but then I remembered that Kullulu had been coming on to me, too.
[cpg]


[OnName num="kousuke"]
"Are you also now attracted to ...... my magical element?"
[cpg cn=true]


Kullulu doesn't say anything. Then, she looks away for a moment.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clolowlude163"]
[OnName num="clolowlude"]
“Don't make me say it. ...... I can't say it.”
[cpg cn=true]


She looks a little uncomfortable. I wonder what she meant by that.
[cpg]


;//
;//
;//
;//;//■選択肢
;//[switch]
;//[case "何か期待しているのだろうか"]
;//	[swap]
;//	[jump target="*IseSel05_1"]
;//[case "自分に惹かれてないのかもしれない"]
;//	[swap]
;//	[jump target="*IseSel05_2"]
;//[endswitch]
;//
;//
;//１、何か期待しているのだろうか
;//２、自分に惹かれてないのかもしれない
;//
;//
;//
;//;//==============================
;//;//１、何か期待しているのだろうか
;//*IseSel05_1|世界を巡る旅
;//
;//
;//
;//
;//[OnName num="kousuke"]
;//「……クロロ。そういえば、長いことかまってやれなかったな」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_6" pos="2/3"]
;//[VOICE f="sClolowlude006"]
;//[OnName num="clolowlude"]
;//「ええ。ずっと……待ってたわ」
;//[cpg cn=true]
;//
;//
;//
;//[free time=800]
;//[BG f="black.ui" time=1000]
;//[WAIT time=100]
;//;//ブラックアウト
;//
;//
;//;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]
;//
;//
;//[BG f="b_10_4_l.ui" time=1000]
;//[WAIT time=1500]
;//;//【ＢＧ】『村＿獣人の国』（夜）******************************************************
;//
;//
;//;//Ｈシーンカット
;//
;//というときに、俺は一つ思い浮かぶことがあった。
;//[cpg]
;//
;//[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
;//[OnName num="kousuke"]
;//「クロロ。いいマッサージの方法があるんだ」
;//[cpg cn=true]
;//
;//[OnName num="kousuke"]
;//「あともう一つ聞きたいんだけど、触手生物に抵抗はないか」
;//[cpg cn=true]
;//
;//[FACE method="change_7" pos="2/3"]
;//
;//[VOICE f="Clolowlude187"]
;//[OnName num="clolowlude"]
;//「な、何を言ってるの……？　触手って」
;//[cpg cn=true]
;//
;//
;//[OnName num="kousuke"]
;//「触手を召喚できるようになったのはお前も知ってるだろ。それを使ってな」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_5" pos="2/3"]
;//[VOICE f="Clolowlude188"]
;//[OnName num="clolowlude"]
;//「馬鹿なこと言わないでっ、そういうのはシャルティエとかにしなさいよ」
;//[cpg cn=true]
;//
;//
;//シャルティエは確かに何をしても受け入れてくれるよな。
;//[cpg]
;//
;//
;//それなりの楽しさというのはある。だけど、クロロみたいに嫌がる相手だからこその楽しみもあるんだ。
;//[cpg]
;//
;//
;//[OnName num="kousuke"]
;//「よし、召喚してやろう。逃げるなよ」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_4" pos="2/3"]
;//[VOICE f="Clolowlude189"]
;//[OnName num="clolowlude"]
;//「ちょっと待ってっ、待って、呪文唱えないで！」
;//[cpg cn=true]
;//
;//
;//そうこうしているうちに、俺は召喚に成功していた。
;//[cpg]
;//
;//
;//[OnName num="kousuke"]
;//「心配するな、ただのマッサージだ」
;//[cpg cn=true]
;//
;//
;//彼女は恐れおののいていた。だけど、逃げようとしても逃げられない状況にある。
;//[cpg]
;//
;//
;//俺は、そのまま触手でクロロの体を絡めてやることにした。
;//[cpg]
;//
;//[free time=800]
;//
;//;//========================================
;//;//●ＣＧ（触手プレイ。マッサージと称している）ev_18
;//;//人物１：ヒロイン４　服装１：着衣
;//;//人物ex：触手　　　　服装ex：無し
;//;//場所　：獣人の国＿室内寝室
;//;//時間　：夜
;//;//========================================
;//
;//*Scene012|世界を巡る旅
;//
;//[BG f="black.ui" time=1000]
;//[free time=1000]
;//
;//[SE f="se013"]
;//;//【ＳＥ】『触手絡みつく』
;//
;//[WAIT time=1000]
;//[STOPBGM]
;//[BGM f="bg_h2"]
;//;**【ＣＧ】 ev_18_0 ***********************
;//[CG id=4 index=0 time=1000]
;//;***************************************
;//[WAIT time=100]
;//
;//
;//[VOICE f="sClolowlude007"]
;//[OnName num="clolowlude"]
;//「ちょっと、ほんとに……っ、気持ち悪いんだけど」
;//[cpg cn=true]
;//
;//[OnName num="kousuke"]
;//「あんまり動くと、変なツボを刺激するかもしれないぞ」
;//[cpg cn=true]
;//
;//と言いつつ、俺はマッサージの知識なんて無い。
;//[cpg]
;//
;//それに加えて、動かし慣れてない触手でとなると……ツボを刺激するなんてできそうにない。
;//[cpg]
;//
;//しかし、普通のマッサージとは言えないのは元からそうだ。
;//[cpg]
;//
;//
;//;**【ＣＧ】 ev_18_a ***********************
;//[CG id=4 index=1 time=1000]
;//;***************************************
;//[WAIT time=100]
;//
;//[VOICE f="sClolowlude008"]
;//[OnName num="clolowlude"]
;//「ううっ、触られてる……変な感じ」
;//[cpg cn=true]
;//
;//[OnName num="kousuke"]
;//「足の裏って、ツボが多いらしいよな」
;//[cpg cn=true]
;//
;//とかなんとか分かったようなことを言いつつ、彼女の体をほぐしていった。
;//[cpg]
;//
;//[VOICE f="sClolowlude009"]
;//[OnName num="clolowlude"]
;//「や、やめて、くすぐったいっ」
;//[cpg cn=true]
;//
;//[VOICE f="sClolowlude010"]
;//[OnName num="clolowlude"]
;//「ぬるぬるするっ……本当に、もうやめて」
;//[cpg cn=true]
;//
;//彼女は振りほどこうとするが、逃げ出せない状態が続いている。
;//[cpg]
;//
;//[VOICE f="sClolowlude011"]
;//[OnName num="clolowlude"]
;//「マッサージっていうなら、普通にしてほしいんだけどっ」
;//[cpg cn=true]
;//
;//[OnName num="kousuke"]
;//「多分、人間の俺より力も強いからな。向いてるかと思って」
;//[cpg cn=true]
;//
;//何もかも詭弁だらけだけど、彼女は嫌がりつつ受け入れてくれた。
;//[cpg]
;//
;//;**【ＣＧ】 ev_18_b ***********************
;//[CG id=4 index=2 time=1000]
;//;***************************************
;//[WAIT time=100]
;//
;//[VOICE f="sClolowlude012"]
;//[OnName num="clolowlude"]
;//「っ……本当に、マッサージできるのね。変なの……」
;//[cpg cn=true]
;//
;//[OnName num="kousuke"]
;//「一回召喚したことがあるからな。ちょっとは操れるようになったんだよ」
;//[cpg cn=true]
;//
;//そんな話をしながら、暫く彼女のリアクションを楽しんでいた。
;//[cpg]
;//
;//
;//
;//[free time=800]
;//[BG f="black.ui" time=1000]
;//[WAIT time=100]
;//;//ブラックアウト
;//
;//
;//[stflag Cha4flg=1]
;//;//ヒロイン４は攻略対象のまま
;//;//■分岐
;//
;//[jump target="*IseSel05_3"]
;//
;//;//==============================
;//;//２、自分に惹かれてないのかもしれない
;//

*IseSel05_2|世界を巡る旅



I don't know, maybe Kullulu might not be attracted to me.
[cpg]


She may have fallen in love with me because of the pheromones, but I don't think she likes me.
[cpg]


[OnName num="kousuke"]
"Sorry. Sorry to interrupt."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
With that, I left Kullulu .
[cpg]

[FACE method="change_4" pos="2/3"]
Even though Kullulu looked at me questioningly……
[cpg]


[if exp={getFlagValue("Cha4flg") == 1 }]
[stflag Cha4flg=-1]
[endif]

;//ヒロイン４は攻略対象でなくなる


;//■分岐

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


;//==============================

*IseSel05_3

*eve_14_2|世界を巡る旅

;//==============================





Since. The construction of the Demon Lord's Castle proceeded smoothly.
[cpg]


Thankfully to the enormous manpower.
[cpg]


I wonder where the supplies are, but there were so many people that I have no trouble getting them.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************





[OnName num="kousuke"]
“It's coming along nicely. ……"
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile185"]
[OnName num="meile"]
"Yeah. It's almost finished. Is that what you call a finished castle?”
[cpg cn=true]


But other than the castle, the rest of the village hasn't changed much from the original.
[cpg]


It would be cool if there were a town below the castle or something like that.
[cpg]

[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





After several days and nights, we finally arrived at .......
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[OnName num="kousuke"]
“...... Nice chair.”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye076"]
[OnName num="schartye"]
"It looks good on you, Demon Lord."
[cpg cn=true]


I don't feel bad. I guess I really am a Demon Lord now.
[cpg]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude210"]
[OnName num="clolowlude"]
“You'll want to dress accordingly too. Maybe a cloak."
[cpg cn=true]


[OnName num="kousuke"]
“I'll leave that up to you guys.”
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sFia010"]
[OnName num="fia"]
“Actually, I already have one here”
[cpg cn=true]

;//;[FO layer="2/2"]


Fia leaves the room to get something.
[cpg]

[OnName num="kousuke"]
“Is ...... Fia particular about what she wants me to wear?”
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sMeile017"]
[OnName num="meile"]
“Maybe so. Elves are fashionable even in their simple clothes."
[cpg cn=true]

And when she returned, Fia brought clothes that had bad taste and were over-decorated.
[cpg]

[OnName num="kousuke"]
"Simple and fashionable ......."
[cpg cn=true]

Meir and I exchanged looks. Aside from that.
[cpg]


I wonder how long she’d been making them. It's not something one can prepare right away.
[cpg]


But it seems to suit me now.
[cpg]


[OnName num="kousuke"]
“I can’t be wearing what I have on now. I’ll start wearing them today.”
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="sFia011"]
[OnName num="fia"]
"Yes. It was worth the effort.”
[cpg cn=true]


She laughs. But that's enough about the clothes. ......
[cpg]


It's a pretty big castle. It can hold a lot of people.
[cpg]


But with the number of demi-humans increasing day by day, it is not enough space.
[cpg]


It seems that demi-humans were gathering from other continents and islands across the sea.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="sFia012"]
[OnName num="fia"]
“Some of them have volunteered to be soldiers to protect you Kosuke. What should we do, ......?"
[cpg cn=true]


[OnName num="kousuke"]
“There's nothing to be done. If we don't use what we have, we will get killed.”
[cpg cn=true]


;//;[FO layer="4/4"]

[FACE method="change_2" pos="2/2"]
[VOICE f="Meile186"]
[OnName num="meile"]
“You're right. You can't be too carefree about it, can you?”
[cpg cn=true]


After that, we started talking about creating a Demon Lord army.
[cpg]


I'm not be able to command everyone by myself anymore.
[cpg]


[OnName num="kousuke"]
“Let's divide everyone into groups”
[cpg cn=true]


[OnName num="kousuke"]
"I think Chartier and Kullulu are the right people for the military. Can I leave it up to you guys?”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye077"]
[OnName num="schartye"]
"You don't have to tell me, we’re already doing it. We’re here to organize the people who volunteered to be soldiers.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude211"]
[OnName num="clolowlude"]
“...... I'll help you as much as I can. I want to protect the Demon Lord.”
[cpg cn=true]


[OnName num="kousuke"]
“Internal affairs..…… Meir should handle that.”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile187"]
[OnName num="meile"]
“I don't even know what internal affairs are. I don't know anything about politics.”
[cpg cn=true]

;//;[FO layer="2/2"]

[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile018"]
[OnName num="meile"]
“I've never even been in charge of a group of people…….”
[cpg cn=true]


Meir was not going to listen to me. I don't think there’s any other choice though ......
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Clolowlude212"]
[OnName num="clolowlude"]
“How dare you defy the demon lord's orders”
[cpg cn=true]

[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile019"]
[OnName num="meile"]
“I'm telling you I’m really not good at leading people”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Schartye078"]
[OnName num="schartye"]
“But for you guys, the Demon Lord is your hope to elevate the status of demi-humans correct?”
[cpg cn=true]


[OnName num="kousuke"]
“Please. You've been my friends since the beginning.”
[cpg cn=true]


[OnName num="kousuke"]
“I want you to stay by my side as much as possible. Can't you ……?"
[cpg cn=true]


[FACE method="change_4" pos="1/2"]
[VOICE f="sMeile020"]
[OnName num="meile"]
“It's hard for me to say no when you're acting like that.”
[cpg cn=true]


[OnName num="kousuke"]
“Don't worry, I'm going to get you an aide who knows politics. Can you at least accept the title?”
[cpg cn=true]


I'm sure Chartier will choose the right person who can do that.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile021"]
[OnName num="meile"]
“I guess…….”
[cpg cn=true]


[OnName num="kousuke"]
"Okay. It's settled.”
[cpg cn=true]



[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Fia103"]
[OnName num="fia"]
“Um, what about me……?”
[cpg cn=true]


Only Fia has not been assigned to a role. I thought about that too.
[cpg]


[OnName num="kousuke"]
“I'd like Fia to work on diplomacy, or ......negotiations, especially with the elven nations.”
[cpg cn=true]


It's not just the elf country. The human nation of Japan, which is right next to us, also sees me as a problem.
[cpg]


But more than that, the elf country is against the demon lord the most.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Schartye079"]
[OnName num="schartye"]
“I can't blame them. When the other world and this world were still separate, the Elves and the Demon Lord were at odds with each other.”
[cpg cn=true]


[OnName num="kousuke"]
“That's right. If not, it would be strange for them to be in conflict with a demi-human.”
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Fia104"]
[OnName num="fia"]
“Yes, ......, this feud goes way back. It's not something that can be managed through discussion.”
[cpg cn=true]


[OnName num="kousuke"]
"Still, I want to reduce the number of useless fights. Fia "
[cpg cn=true]


[OnName num="kousuke"]
“You're an elf by nature, you know. I think you're the right person for the job. What do you think?”
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Fia105"]
[OnName num="fia"]
“...... I understand.”
[cpg cn=true]


Fia is probably influenced by the magic or pheromones that I was releasing. It was convenient…..
[cpg]

This is how the four girls became a top leader of this country.
[cpg]

Before assigning them to their first job, I was made to wear the new clothing.
[cpg]

[FACE method="change_2" pos="1/2"]
[VOICE f="Schartye080"]
[OnName num="schartye"]
“You look mighty, Demon Lord. It suits you well.”
[cpg cn=true]


I'll have to wear such ostentatious clothes on a regular basis from now on. ...... Oh well.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Meile190"]
[OnName num="meile"]
“By the way, this country has no name. Are you going to take over the name of the beastman country?"
[cpg cn=true]


[OnName num="kousuke"]
“...... Since we're here, I'd like to give it a different name.”
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia106"]
[OnName num="fia"]
“What kind of name would you like? We don't want to offend the other countries too much. ……"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye081"]
[OnName num="schartye"]
“No. No, we should suggest that we dare to fight.”
[cpg cn=true]


The girls are divided in their opinions, but ......
[cpg]


[OnName num="kousuke"]
“I think we should simply call it the Land of the Demon Lord.”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile191"]
[OnName num="meile"]
“Yes, I agree. I'm with you.”
[cpg cn=true]


[FACE method="change_7" pos="2/2"]

[VOICE f="Fia107"]
[OnName num="fia"]
“Is that so? ......? Doesn't it give a scary impression?”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye082"]
[OnName num="schartye"]
“I disagree. We can't maintain our dignity with a name like that.”
[cpg cn=true]


After balancing the various opinions, the name "Land of the Demon Lord" was chosen.
[cpg]


The "Land of the Demon Lord" was newly established within the Land of the Beasts.
[cpg]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト
;//【ＢＧ】『空』（夜）******************************************************





Some of the beastmen were against the rule of the Demon Lord.
[cpg]


There was also the fact that the borders of the country hadn't been decided in the first place, so there were now two forces within the beast country.
[cpg]


And the anxiety in my heart did not disappear just because a castle was built.
[cpg]


My days pass by as I hold the demi-humans in my arms one by one, faking the anxiety of not knowing when I would be killed.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************





[OnName num="kousuke"]
"......?"
[cpg cn=true]


In the quiet corridor, I hear a singing voice coming from somewhere. It is a familiar voice.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia108"]
[OnName num="fia"]
"Ah, ...... Kosuke ."
[cpg cn=true]


The voice belongs to Fia .
[cpg]


[OnName num="kousuke"]
" Fia . I didn’t know you liked to sing?”
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Fia109"]
[OnName num="fia"]
“I do. I like singing. ...... In times like these, I don't want to forget what I like.”
[cpg cn=true]


[OnName num="kousuke"]
“What's the song called?”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia110"]
[OnName num="fia"]
“There are many names for it. I don't know which one is the right one. ...... But it's a song that's been passed down in Elf country since I was a child.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia111"]
[OnName num="fia"]
“It's a song that soothes my soul. It's also a reminder of a happy past.”
[cpg cn=true]


[OnName num="kousuke"]
「……」
[cpg cn=true]


A happy past. I was a little confused by that phrase.
[cpg]


Fia seems to have worries of her own.
[cpg]


[OnName num="kousuke"]
" Fia . Where was your room?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia112"]
[OnName num="fia"]
"Right around the corner.”
[cpg cn=true]


[OnName num="kousuke"]
“Do you mind if I visited? If you can't sleep, I'll stay with you.”
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="sFia013"]
[OnName num="fia"]
“How did you know that I can't sleep…..…”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


We both walked to Fia 's room.
[cpg]


I snuggled up next to her and stayed with her until she fell asleep. ......
[cpg]

;//Ｈシーンカット



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************





After that, I continued to work on my magic.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Fia135"]
[OnName num="fia"]
“Your magic has become quite stable.”
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye083"]
[OnName num="schartye"]
“That’s true. It usually takes five years to get to this point.”
[cpg cn=true]


[OnName num="kousuke"]
“Oh......?”
[cpg cn=true]


I'm able to summon not only tentacles, but simple creatures like slime as well.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Meile192"]
[OnName num="meile"]
It's a good thing that Kosuke can now defend himself, right?
[cpg cn=true]


[OnName num="kousuke"]
“Yes, it is. Otherwise it would be up to Chartier and Kullulu”
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude213"]
[OnName num="clolowlude"]
“That is true. How many assassins have you killed…..….?”
[cpg cn=true]


I shudder when I hear that, but I am somewhat relieved.
[cpg]


I'll take care of myself. Not only that, but I have friends now.
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_1.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城内＿廊下』（朝）******************************************************





[OnName num="soldier_A"]
“I can't believe the Demon Lord is back. ……"
[cpg cn=true]


[OnName num="soldier_B"]
“Yeah. It won't be long until we beastmen get our proper rights.”
[cpg cn=true]


[OnName num="soldier_A"]
“That's right. You have no idea how oppressed we've been. ……"
[cpg cn=true]


Then they realize that I am nearby.
[cpg]


[OnName num="kousuke"]
「……」
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

As I walked through the corridors of the castle, soldiers would salute me.
[cpg]


They were probably instructed by Chartier or Kullulu . Probably Chartier .
[cpg]


I don't know, it's not annoying, but it's a bit disturbing. ......
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

I went outside again, thinking what to do. Fia is standing next to me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia136"]
[OnName num="fia"]
"Well, ......, what can I do for you?"
[cpg cn=true]


[OnName num="kousuke"]
"I heard there's a wild tentacled creature around here.”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia137"]
[OnName num="fia"]
“What ......? What are you talking about, Kosuke ?”
[cpg cn=true]

[OnName num="kousuke"]
“We have to study the wildlife before we can use the summoning magic.”
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sFia014"]
[OnName num="fia"]
“You know, I'm not very good with ...... creatures like that.”
[cpg cn=true]


[OnName num="kousuke"]
“You should not go on your own.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト




As soon as I entered the forest, I see the creature.
[cpg]

[VOICE f="sFia015"]
[OnName num="fia"]
"What?"
[cpg cn=true]

;//========================================
;//●ＣＧ（触手がフィアに絡まる）ev_20
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：触手　　　　服装ex：無し
;//場所　：森
;//時間　：昼
;//備考　：公式サイト一枚目のＣＧです
;//========================================

*Scene016|世界を巡る旅

[BG f="black.ui" time=1000]
[free time=1000]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sFia016"]
[OnName num="fia"]
"I can't untie it. ......! What an enormous power!”
[cpg cn=true]

[OnName num="kousuke"]
“Wait for me. I'll help you now. ...... No, ......."
[cpg cn=true]

I suddenly thought. It's boring to rescue Fia right away.
[cpg]

Though she wouldn’t understand that thought.
[cpg]

[OnName num="kousuke"]
“I'm sure you'll be able to keep her interested for a while until you untie her.”
[cpg cn=true]

Fia looked at me with a surprised look.
[cpg]

;**【ＣＧ】 ev_20_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia017"]
[OnName num="fia"]
"Hey!I'm really in trouble.”
[cpg cn=true]

I know that she is in trouble. But I had to come up with an excuse.
[cpg]

[OnName num="kousuke"]
“If we don’t look at it closely I won’t be able to summon it anytime.”
[cpg cn=true]

[VOICE f="sFia018"]
[OnName num="fia"]
"That's terrible, Kosuke and ......!"
[cpg cn=true]

[OnName num="kousuke"]
“I know it's terrible, but bear with me.”
[cpg cn=true]

[VOICE f="sFia019"]
[OnName num="fia"]
“It's almost as if I'm the bait.”
[cpg cn=true]

It wasn’t “almost”, she was already the bait.
[cpg]

[OnName num="kousuke"]
“Well, the mouth is in this position. It's like an octopus.”
[cpg cn=true]

;**【ＣＧ】 ev_20_b ***********************
[CG id=2 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia020"]
[OnName num="fia"]
“Stop observing and help me!”
[cpg cn=true]

Pretending to examine the tentacled creature, I also observed ...... Fia .
[cpg]

Once I was done examining, I rescue her.
[cpg]




;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_10_3.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************

[window target=true]




In the meantime, it was evening.
[cpg]


We have to go back to the castle soon. The actual command center is Chartier , but it's not a good thing that I'm not in the castle.
[cpg]


[OnName num="kousuke"]
“We should go back to the castle. Fia "
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sFia021"]
[OnName num="fia"]
"...... Yes. Please don't ask me to do this again.”
[cpg cn=true]


[OnName num="kousuke"]
“I don't know. I can’t promise that.”
[cpg cn=true]


Fia gave me a subtle look. Well, okay.
[cpg]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





And then, it's night in my room.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドアノック』





I hear a knock on my door and I answer it.
[cpg]


[OnName num="kousuke"]
"Who is it?"
[cpg cn=true]



[VOICE f="Schartye084"]
[OnName num="schartye"]
“It's Chartier . Can I come in?”
[cpg cn=true]


[OnName num="kousuke"]
"......, yeah. Sure.”
[cpg cn=true]



[SE f="se002"]
;//【ＳＥ】『ドア開く』





[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSchartye015"]
[OnName num="schartye"]
“How's it going? How's it going with the demi-human girl?”
[cpg cn=true]


[OnName num="kousuke"]
“I've been pretty good. ……"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sSchartye016"]
[OnName num="schartye"]
“That's not good enough. You have to be awakened as a Demon Lord.”
[cpg cn=true]


Now Chartier is coming on to me.
[cpg]


I'm sure she has feelings for me as well. It's not just the pheromones that are seducing her though.
[cpg]


[OnName num="kousuke"]
“...... I've never been this popular.”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye087"]
[OnName num="schartye"]
“You should just accept it. A Demon Lord is a Demon Lord.”
[cpg cn=true]


Maybe so, but I'm not sure. ......
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye088"]
[OnName num="schartye"]
“It is a great honor to be touched by a Demon Lord. I'm happy.”
[cpg cn=true]


[OnName num="kousuke"]
「……そうか」
[cpg cn=true]


Chartier says that. But I don’t know what to reply.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



I can't read her mind. I don't know how serious she is……
[cpg]


;//Ｈシーンカット

;//ブラックアウト

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Then I have a casual chat with Chartier .
[cpg]


I couldn't refuse, even though I wondered if she was jealous of Fia or something.
[cpg]


In addition, I had a great calling to wake up as a Demon Lord.
[cpg]


I'm sure that Fia will understand ...... how naive am I to think that.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





And the night dawns. In the country of the Demon Lord, so far, everything was going well.
[cpg]


More people, more things. The beastmen were self-sufficient to begin with.
[cpg]


There was never a shortage of food and therefore no complaints.
[cpg]


As the number of people increased, businesses increased. And as the number of people increased, so did the need for places to live.
[cpg]


The city was being developed. Houses and stores were built and developed.
[cpg]


In the end, I realized that a nation is run by its people.
[cpg]



;//ブラックアウト

[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=100]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



;//背景が変化　村の背景が徐々に薄くなって城下町になる感じ




[BG f="b_05_2.ui" time=2500]
[WAIT time=2500]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[BGM f="bg_d3"]


[window target=true]



As a result, the area around the Demon Lord's Castle had become quite like a castle town.
[cpg]


The demi-humans who had been scattered in different areas and races were now gathering here.
[cpg]


Of course, the Elf Nation and Japan wouldn't take it well.
[cpg]


If you're not careful, they might attack you. ......
[cpg]


[OnName num="kousuke"]
“There's no point in thinking that.”
[cpg cn=true]


Somehow, I was walking with Meir next to me. She was optimistic, but...
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile193"]
[OnName num="meile"]
"Well, you know. I'm sure that day will come someday.”
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="4/2" time=800]


She wasn't the type of person who fooled around with reality. I'm not saying that we'll always be at peace.
[cpg]



[SE f="se009"]
;//【ＳＥ】『走る』

[move from="2/3" to="1/2" ease="easeInOutSine" time=1000]

[move from="4/2" to="2/2" ease="easeInOutSine" time=1000]


[STOPBGM]




Then Fia came running in. She was out of breath and didn't look like she was here to give us good news.
[cpg]



[OnName num="kousuke"]
"What's wrong? Fia "
[cpg cn=true]



[VOICE f="Fia160"]
[OnName num="fia"]
"...... The elven soldiers are trying to invade."
[cpg cn=true]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************






I hurriedly gathered all four of us together and discussed it.
[cpg]


The land of the elves was going to lead an army to invade the land of the Demon Lord. What I feared is going to happen.
[cpg]

[free time=800]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye110"]
[OnName num="schartye"]
“There is nothing to worry about. The difference in military power is clear.”
[cpg cn=true]


Chartier said there was no need to worry, but I had a lot to think about.
[cpg]


Will the land of the elves lose? Will the land of the Demon Lord lose?
[cpg]


Either way, it could mean that soldiers would die for me.
[cpg]


Whether it's the soldiers of the Demon Lord's country or the soldiers of the Elf country, neither of them will be safe.
[cpg]


Is that really the right thing to do? ......
[cpg]


[OnName num="kousuke"]
“Fia ...... What do you think?”
[cpg cn=true]

[free time=800]
[WAIT time=1]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Fia161"]
[OnName num="fia"]
“I'm also looking for a dialogue with the Elf Nation,......, but it's difficult.”
[cpg cn=true]


After all, we have been bickering for years. However, I couldn't just surrender.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Clolowlude214"]
[OnName num="clolowlude"]
“Don't worry, my army is quite large, and I have weapons.”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Schartye111"]
[OnName num="schartye"]
“In the first place, Kullulu Urud and me alone are quite a force to be reckoned with. You can't lose.”
[cpg cn=true]


She was right. But I still didn’t want people to get killed.
[cpg]

[free time=800]
[WAIT time=1]
[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile194"]
[OnName num="meile"]
"You look pale. I think you need to calm down.”
[cpg cn=true]


[OnName num="kousuke"]
"...... Oh."
[cpg cn=true]


*IseSel06_3
*eve_15_2|A Journey Around the World


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





It is morning. My anxiety will not reside.
[cpg]


Not just anxiety, but outright fear.
[cpg]


People are going to die because of me. Even if they are demi-human, it's the same thing.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude215"]
[OnName num="clolowlude"]
"Are you scared?"
[cpg cn=true]


At that time, Kullulu was visiting my room, and I talked to her about it.
[cpg]


[OnName num="kousuke"]
“I'm not saying I'm scared, I'm just saying that I'm not ...... willing to let people die for my life anymore.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude216"]
[OnName num="clolowlude"]
“It's not your life alone anymore. If we lose you, the Demon Lord's kingdom will collapse."
[cpg cn=true]


That's a good argument. You're right……..
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude217"]
[OnName num="clolowlude"]
“Then all of us demi-humans will be persecuted even more than before.”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude218"]
[OnName num="clolowlude"]
“It's not just that. Those of us who are complicit with the Demon Lord may be killed.”
[cpg cn=true]


It's not that I haven't thought about that possibility.
[cpg]


It's not only Kullulu , but also Fia , who is originally an elf.
[cpg]


We cannot go back from here. Even though I know it, I was scared, as Kullulu said. ......
[cpg]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************





So I tried to learn a new magic.
[cpg]


There was no other way. I would create a magic that would save us from fighting.
[cpg]


I don't know if there is such a thing, but I have to find out.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia162"]
[OnName num="fia"]
“If there were such a thing that convenient, I feel like I wouldn't have any trouble. ……"
[cpg cn=true]


[OnName num="kousuke"]
“Don't say that. ...... It's depressing.”
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Fia163"]
[OnName num="fia"]
“I'm sorry.”
[cpg cn=true]

[free time=800]

[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Clolowlude219"]
[OnName num="clolowlude"]
“I know how you feel, Fia . We should just fight.”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye112"]
[OnName num="schartye"]
“Totally.”
[cpg cn=true]


Fia did not seem to agree. After all she used to be a resident of the land of the elves.
[cpg]


Anyway, these three are skilled in magic. I’ll just have to find out from them.
[cpg]


The castle had just been built and there was not a library yet.
[cpg]


So, I had to ask them steadily. I went to every wizard in the castle.
[cpg]



[free time=1000]

;//ブラックアウト

[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************



[OnName num="therianthropy_A"]
“Beastmen who can use magic ......? I'm sure there are.”
[cpg cn=true]


[OnName num="therianthropy_B"]
“But there's no such thing as magic that doesn't involve fighting. ……"
[cpg cn=true]


[OnName num="therianthropy_C"]
"Oh. I've heard of this kind of magic.”
[cpg cn=true]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夕方）******************************************************





So I finally found it. It was called “magic of attraction”.
[cpg]


It is a magic that a normal demi-human could not handle, but as a Demon Lord, I might be able to use it.
[cpg]


It seems to be a way to further enhance my original power of attracting demi-humans .......
[cpg]


[OnName num="kousuke"]
"What do you think? Fia"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Fia164"]
[OnName num="fia"]
“I think it might have been a blind spot. I think it's a good idea.”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye113"]
[OnName num="schartye"]
"I don't agree with it. It's a coward's idea.”
[cpg cn=true]


I ignored what Chartier said and decided to move on.
[cpg]


She might despise the elves but they are still the same demi-human.
[cpg]


If one is a woman, they will be fascinated by the magical element of the Demon Lord. As Fia does......
[cpg]


[OnName num="kousuke"]
"Are there any women in the elven army?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Clolowlude220"]
[OnName num="clolowlude"]
“I'm sure there are. Probably about half of them are women.”
[cpg cn=true]


In the elven race, it seems that women are the most skilled magicians .......
[cpg]


This is why there are women on the front lines, and in fact the generals are women.
[cpg]

[STOPBGM]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Once I had decided that, my actions were swift.
[cpg]


I couldn't help but hurry. The war was about to start.
[cpg]


Preventing it from happening depended entirely on my magic.
[cpg]


Even if you call yourself a Demon Lord, it does not mean that you have become a Demon Lord in your heart.
[cpg]


I might have not been a good man but I've been living my life as an ordinary businessman…..
[cpg]


I can't stand the thought of people dying to protect my orders or my life.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





I stayed up for a night or two to design and complete the ...... magic circle.
[cpg]


[OnName num="kousuke"]
“I think ...... it's done.”
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia165"]
[OnName num="fia"]
"What do you think, ......? Is it going to work?”
[cpg cn=true]


[OnName num="kousuke"]
“We can't use it here. I don't know what the side effects will be.”
[cpg cn=true]


Besides, we can't afford to attract more demi-humans to this country than we already have.
[cpg]


[OnName num="kousuke"]
“We've only got one shot at this. They've already declared war on us, so we'd better hurry."
[cpg cn=true]


As we were discussing this, Meir came strolling in.
[cpg]

[free time=800]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile195"]
[OnName num="meile"]
“What's wrong? Kosuke, you look like you haven't slept well.”
[cpg cn=true]


Meir doesn't seem know anything, she seems at ease ......
[cpg]


I guess she doesn't think that her life is at stake.
[cpg]


[OnName num="kousuke"]
“I can't do this. We have to sneak into elf country."
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Meile196"]
[OnName num="meile"]
"Uh-huh. What's the plan?
[cpg cn=true]


[OnName num="kousuke"]
“...... Fia , explain it to her.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





The mission was immediately put into action.
[cpg]


I enlisted the help of the harpies. Most of them including a couple of girls had resided to this country.
[cpg]


They said it would be no problem at all to carry me alone.
[cpg]


In the first place, when I returned to Japan, I was carried by the harpies.
[cpg]


[OnName num="kousuke"]
"Then, will you carry me……?”
[cpg cn=true]

[OnName num="harpy_A"]
"Yes. You look tired, Mr. Kosuke ."
[cpg cn=true]


[OnName num="kousuke"]
“Yeah, well, I'm tired sort of ……."
[cpg cn=true]


I was so exhausted that I fell asleep while the harpies carried me.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************





From there on I let the harpies take control.
[cpg]


It took quite a while, but after a long time, I landed in the land of the elves.
[cpg]


[OnName num="suspicious_man"]
"We've been waiting for you, sir.”
[cpg cn=true]


In the land of the elves, there was a suspicious man I had met in an airship.
[cpg]


[OnName num="kousuke"]
"......, who are you?”
[cpg cn=true]


[OnName num="suspicious_man"]
“I'm sort of the servant for Chartier.”
[cpg cn=true]


[OnName num="kousuke"]
“You've been in elf country all this time? Scouting?”
[cpg cn=true]


[OnName num="suspicious_man"]
“That's about right. Come on, let's go.”
[cpg cn=true]


I'm sure he had his own difficulties.
[cpg]


But he didn’t seem to be jealous about the fact that Chartier was after me.
[cpg]


Maybe he was also hoping for the resurrection of the Demon Lord.
[cpg]


If that's the case, I knew I can't fail in this mission.
[cpg]

;//qwe

;//上下に黒帯を入れてください
[STOPBGM]
[BGM f="bg_si"]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]



I disguised myself as a member of the military in the land of the elves and sneak in.
[cpg]


I had asked the man to get me some armor that looked like that.
[cpg]


I hadn't planned it out at all. To be honest, it was a great help to have it had all prepared.
[cpg]


If this plan goes well, at least the female elves won't be able to attack me.
[cpg]


If half of the army is gone, it will be difficult to invade.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
He was accompanied by Fia and several harpies.
[cpg]


Ostensibly, Fia had come to negotiate a deal that would prevent a fight.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia166"]
[OnName num="fia"]
"Good luck with everything……Kosuke ."
[cpg cn=true]


[OnName num="kousuke"]
“Thanks. Good luck Fia with your escape."
[cpg cn=true]


In the meantime, I decided to head to the elf army's headquarters and use my charm magic.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]

[WAIT time=100]
[BG f="b_02_2_l.ui" time=1000]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************




I really needed to get to a place where there were a lot of soldiers.
[cpg]


For that, maybe the quarters would be better than the training grounds or something. Plus it was night.
[cpg]


I develop my magic. It’s not perfect, but I can get an idea of where they are.
[cpg]


I'm doing my best to avoid a fight.
[cpg]


[OnName num="elf_soldier"]
"What ……? You're new?"
[cpg cn=true]


[OnName num="kousuke"]
“Yes, yes! I'm looking forward to your guidance!”
[cpg cn=true]


[OnName num="elf_soldier"]
"......?"
[cpg cn=true]


I could see that he was looking at me suspiciously. But he did not ask me any further questions.
[cpg]


I was nervous, but I tried not to say anything unnecessary.
[cpg]


[OnName num="harpy_A"]
“...... With this armor, it's hard to tell if it's a hand or a feather.”
[cpg cn=true]


The harpy girl was also wearing the armor of the elves. This way, even if she can't fly, she could still accompany me.
[cpg]


This means that if the time comes, we can escape together.
[cpg]


[OnName num="kousuke"]
“When the spell is activated, there will probably be people chasing me.”
[cpg cn=true]


[OnName num="kousuke"]
“If I have to run, I’m counting on you.”
[cpg cn=true]


[OnName num="harpy_A"]
“You can count on me. I'll protect you, Kosuke ."
[cpg cn=true]


I feel relieved. In the meantime, I had arrived at the center of the dormitory.
[cpg]




I had to draw a magic circle. It wasn't going to take more than a second.
[cpg]


If Chartier or Kullulu were here, they would be able to knock someone out if they spotted me. ......
[cpg]


But there's no point in thinking about that now. I hurriedly draw the magic circle in blood.
[cpg]


The size of the magic circle is not that big. However, it seems that my blood is flowing with magical power.
[cpg]


Even though it was a small magic circle, its effect should be far-reaching.
[cpg]



[SE f="se014"]
;//【ＳＥ】『地鳴りのような音』



A powerful magic is activated. The earth starts to rumble. ......
[cpg]


This is definitely going to get noticed. But I don't care if they notice me now.
[cpg]


[STOPBGM]
[BGM f="bg_tc"]



[OnName num="elf_soldier"]
“Who are you? What are you doing?”
[cpg cn=true]


[OnName num="harpy_A"]
“Mr. Kosuke! What the hell are you doing?!
[cpg cn=true]


The magic is already activated. All that's left is to escape.
[cpg]


[OnName num="kousuke"]
“Let's go!”
[cpg cn=true]


[window target=false]

[transition target={true} rule="108.jpg" color={0x000000ff} time=1]
[WAIT time=1]
[free time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="108.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『街＿エルフの国』（夜）******************************************************

[window target=true]


[SE f="se009"]
;//【ＳＥ】『走る』


[OnName num="elf_soldier_A"]
“He's gone! That way!”
[cpg cn=true]


[OnName num="elf_soldier_B"]
“Damn it, how did the Demon Lord get here?”
[cpg cn=true]


[OnName num="elf_soldier_A"]
“I don't know! We've got to get him now!”
[cpg cn=true]


We run for our lives. If we get caught, it's really over.
[cpg]


But with a few harpies on our side, it was almost a given that we could escape.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1500]
;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】『羽ばたく』
[BG f="b_11_4.ui" time=1000]

[WAIT time=1500]

[BGM f="bg_si"]
;//【ＢＧ】『空』（夜）******************************************************



I was carried by a harpy who took off her armor and left the land of the elves, and now I'm on the sea.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kousuke"]
“Fia ! Are you all right?”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia167"]
[OnName num="fia"]
“Yes, barely. You're safe too, Kosuke…..”
[cpg cn=true]


[OnName num="kousuke"]
“Yeah. I think the magic worked, but I can’t be sure…….”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sFia022"]
[OnName num="fia"]
“It’s probably working. Even though the magic had just been activated, my heart was already pounding.”
[cpg cn=true]


It seems to work, even during this short amount of time.
[cpg]


It is still too early to be relieved. I knew that but......
[cpg]


I had a sense of accomplishment for the time being. I felt like I had fulfilled my role as a Demon Lord and that I was on my way to a peaceful resolution.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





Exhausted, I slept soundly that night. It wasn't until noon that I woke up.
[cpg]


The good news was immediate. The good news was that half of the elven army were no longer able to attack the Demon Lord.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile197"]
[OnName num="meile"]
"Some of them would rather join the Demon Lord's kingdom. It seems that the elven army can no longer move forward with their original plan.
[cpg cn=true]


[OnName num="kousuke"]
"Oh, I see. ...... Huh."
[cpg cn=true]


I took a deep breath. For a while we are at peace.
[cpg]


Meir looked like this was normal, when it actually was a close call.
[cpg]


I was even more relieved now, because I thought it was a 50-50 chance whether it would work or not.
[cpg]



[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1500]
[STOPBGM]
;//ブラックアウト


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_05_3_l.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城下町＿魔王の国』（夕方）******************************************************



That evening, I showed up at the castle, still tired.
[cpg]



[BGM f="bg_mi"]



[OnName num="therianthropy_A"]
“Welcome back, Demon Lord!”
[cpg cn=true]


[OnName num="therianthropy_B"]
“Your mission was a great success! That's great!”
[cpg cn=true]


[OnName num="kousuke"]
“No, no, no. ...... There's no need to make such a fuss. ……"
[cpg cn=true]


[OnName num="therianthropy_A"]
"Let's have a feast today, everyone is happy that it didn't turn into a war.
[cpg cn=true]


[OnName num="kousuke"]
"There's nothing to be too happy about……”
[cpg cn=true]


But I was relieved inside.
[cpg]


Everyone wanted to avoid a fight. That's a good thing.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************





The whole country was celebrating. There are even people who want to make it an annual holiday.
[cpg]


Everyone is understandably emotional. If I die, this country will be turned upside down. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Fia168"]
[OnName num="fia"]
“…… Good for you, Kosuke ."
[cpg cn=true]


[OnName num="kousuke"]
"Well, yeah. My life depends on it."
[cpg cn=true]


The party was going to last all night. ......
[cpg]


[STOPBGM]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I was still tired and went back to my room.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye114"]
[OnName num="schartye"]
“I don’t like what you did. You’re gutless."
[cpg cn=true]


[OnName num="kousuke"]
"...... Chartier . Don't come into my room without permission.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye115"]
[OnName num="schartye"]
“Why not. If it weren't for me, you'd have been assassinated by now.”
[cpg cn=true]


[OnName num="kousuke"]
“But the fact is, I drove the Elves away all by myself.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye116"]
[OnName num="schartye"]
“That's why you're in a celebratory mood. I don't understand, it's not like you won the battle.”
[cpg cn=true]


...... Chartier is hateful.
[cpg]


But Chartier is supposed to be fascinated by me all the time.
[cpg]


But she wasn't as aggressive as the rest of them. Maybe there's something that’s holding her back.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye117"]
[OnName num="schartye"]
"Look. There’s so much alcohol left over from the celebration. Maybe demi-humans are weak to alcohol.”
[cpg cn=true]


[OnName num="kousuke"]
“What about you?”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye118"]
[OnName num="schartye"]
“I'm strong. Shall we find out who’s stronger?”
[cpg cn=true]


I'm not that strong, and I'm tired.
[cpg]


[OnName num="kousuke"]
“Let's just drink to this victory.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye119"]
[OnName num="schartye"]
“Look I told you, it’s not a victory. ……"
[cpg cn=true]



[SE f="se00"]
;//【ＳＥ】『乾杯』





From there, the two of us drank together for a while.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye120"]
[OnName num="schartye"]
"......, Demon Lord. What do you think of me?
[cpg cn=true]


[OnName num="kousuke"]
"What do you mean, ...... I'm grateful."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye121"]
[OnName num="schartye"]
"I see. Is that all?”
[cpg cn=true]


I wonder if Chartier is really a strong drinker. Or is she pretending to be drunk?
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Schartye122"]
[OnName num="schartye"]
“It's not just that I'm ungrateful to you, Demon Lord. I'm feeling something else."
[cpg cn=true]


She sounded as if she was expecting something.
[cpg]


She’s probably also confused by the pheromones. ......
[cpg]


I was unsure of what to do, but I decided.
[cpg]





;//■選択肢
[switch]
[case "I'm too tired to do anything."]
	[swap]
	[jump target="*IseSel07_1"]
[case "I respond to Chartier 's feelings."]
	[swap]
	[jump target="*IseSel07_2"]
[endswitch]



1. I'm too tired to do anything.
2. I respond to Chartier 's feelings.



;//==============================
;//１、疲れているので何も言わない
*IseSel07_1|世界を巡る旅


[OnName num="kousuke"]
「……」
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sSchartye018"]
[OnName num="schartye"]
"Hmm. I’ve told you all this but you haven’t replied."
[cpg cn=true]


Chartier smiles a little ruefully. Then she says,
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="sSchartye019"]
[OnName num="schartye"]
You are free to choose not to accept my invitation. After all, you are the Demon Lord.
[cpg cn=true]


And then she said nothing more.
[cpg]


I felt bad, but I didn’t want to lead her on any further.
[cpg]



;//ヒロイン３は攻略対象でなくなる
[if exp={getFlagValue("Cha3flg") == 1 }]
[stflag Cha3flg=-1]
[endif]

;//■分岐

[jump target="*IseSel07_3"]

;//==============================
;//２、シャルティエの気持ちに応える

*IseSel07_2|世界を巡る旅



[OnName num="kousuke"]
"I'm grateful to you Chartier . If it weren't for you, I'd be long dead."
[cpg cn=true]


Chartier looks happy. I guess she was thinking about me all the time, even though she always seemed so cold.
[cpg]


I caressed her head.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="sSchartye020"]
[OnName num="schartye"]
"I can't believe ...... the Demon Lord is doing this to me."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. You've probably been waiting for this.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye150"]
[OnName num="schartye"]
"Of course. I'm sure the other girls did too.”
[cpg cn=true]


...... She was right. I have a lot of people I need to love.
[cpg]


It's all because of the pheromones that attract demi-humans.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

;//Ｈシーンカット


;//ブラックアウト


;//ヒロイン３は攻略対象のまま
;//■分岐

;//==============================

*IseSel07_3|世界を巡る旅

;//ブラックアウト
[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]




Then, the fact that the Demon Lord had defeated the soldiers of the Elf Nation became known all over the world.
[cpg]


It's not just Japan, but the whole world is coming after me, the Demon Lord.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile198"]
[OnName num="meile"]
“What should we do, Kosuke ……?"
[cpg cn=true]


[OnName num="kousuke"]
"What do you want me to do? The whole world is my enemy.”
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia169"]
[OnName num="fia"]
“There's a movement in the world to create a coalition army. They want to stop you at all costs. ……"
[cpg cn=true]


I was faced with a further decision. They're all connected, country by country, and they're all against me.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia170"]
[OnName num="fia"]
“I need to do something to let them know that the Demon Lord is not dangerous. ……"
[cpg cn=true]


Fia tries to make things go smoothly. But...
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude221"]
[OnName num="clolowlude"]
“I think you can conquer the world with the power of the Demon Lord.”
[cpg cn=true]


Kullulu says. I'm confused again.
[cpg]


[free time=800]

Do I want peace or do I want world domination?
[cpg]


I think it probably depends on what I've done so far.
[cpg]


To what extent am I awakening as a Demon Lord?
[cpg]


I think it also connects with how many demi-human girls I've accepted ......
[cpg]


How many girls have I led on?
[cpg]


As I think about this, I have only one thing on my mind.
[cpg]

;//
;//;//※攻略ヒロインがどれだけ居るか　によって分岐
;//;//※全てのヒロインを攻略対象にしている場合、魔王として覚醒　世界を征服するルートへ分岐
;//;//※そうで無い場合、魔王として覚醒していない　平和を望むルートへ分岐
;//
;//
;//
;//[if exp={getFlagValue("Cha2flg") == 0 }]
;//[jump target="*root_heiwa"]
;//[endif]
;//
;//
;//[if exp={getFlagValue("Cha3flg") == 0 }]
;//[jump target="*root_heiwa"]
;//[endif]
;//
;//
;//[if exp={getFlagValue("Cha4flg") == 0 }]
;//[jump target="*root_heiwa"]
;//[endif]
;//
;//[jump target="*root_mao"]
;//
;//;//qwe
;//
;//;//[jump target="*root_heiwa"]
;//
;//==============================
;//攻略対象になっていないヒロインが居る場合


;//キャラ売り用
[switch]
[case "I want peace."]
	[swap]
	[jump target="*root_heiwa"]
[case "Desire for world domination"]
	[swap]
	[jump target="*root_mao"]
[endswitch]



*root_heiwa|世界を巡る旅


[OnName num="kousuke"]
“...... I'd like to get things done in peace.”
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude222"]
[OnName num="clolowlude"]
“I knew you would say that. You're an idiot, Demon Lord.”
[cpg cn=true]


[OnName num="kousuke"]
“Say what you want.”
[cpg cn=true]


All I wanted was to find peace.
[cpg]


Although if I came into contact with too many demi-humans, I would awaken as a Demon Lord. ......
[cpg]


Now, I wasn't that tempted.
[cpg]


I knew that I did not want to kill people.
[cpg]


It's not that I can't handle the fact that I've become a Demon Lord, but I didn't think about expanding my power from this country to other countries.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I didn't want to kill anyone, but only gather wisdom to make it all work out.
[cpg]


Fia and Meir seemed to be taking it seriously, but ......
[cpg]


Chartier and Kullulu Urud seem to be trying to tell me that I wasn't fighting hard enough.
[cpg]


Sleepless nights. I wake up to visit a woman.
[cpg]


I go to ......
[cpg]
;//
;//
;//;//＠
;//;//※ここまでの選択肢で攻略対象になっているヒロインのみ選択肢に出てくる
;//;//※ヒロイン１は必ず選択肢に残る
;//;//※ヒロイン１しか残っていない場合、選択肢は発生せずヒロイン１ルートへ
;//
;//[if exp={getFlagValue("Cha2flg") == 1 }]
;//[jump target="*GoRoot_1"]
;//[endif]
;//
;//;//10?0?
;//[if exp={getFlagValue("Cha3flg") == 1 }]
;//[jump target="*GoRoot_01"]
;//[endif]
;//
;//;//1000?
;//
;//
;//;//10000	フィアのみなのでフィアルート
;//[jump storage="ep002.ks" target="*start"]
;//
;//
;//;//1010?
;//*GoRoot_01
;//
;//
;//;//1010
;//;//■選択肢
;//[switch]
;//[case "フィア"]
;//	[swap]
;//	[jump storage="ep002.ks" target="*start"]
;//[case "シャルティエ"]
;//	[swap]
;//	[jump storage="ep004.ks" target="*start"]
;//[endswitch]
;//
;//
;//
;//;//11?0?
;//*GoRoot_1
;//[if exp={getFlagValue("Cha3flg") == 1 }]
;//[jump target="*GoRoot_11"]
;//[endif]
;//
;//
;//;//1100
;//;//■選択肢
;//[switch]
;//[case "フィア"]
;//	[swap]
;//	[jump storage="ep002.ks" target="*start"]
;//[case "メイル"]
;//	[swap]
;//	[jump storage="ep003.ks" target="*start"]
;//[endswitch]
;//
;//
;//
;//;//1110?
;//*GoRoot_11
;//
;//
;//;//11100
;//;//■選択肢
;//[switch]
;//[case "フィア"]
;//	[swap]
;//	[jump storage="ep002.ks" target="*start"]
;//[case "メイル"]
;//	[swap]
;//	[jump storage="ep003.ks" target="*start"]
;//[case "シャルティエ"]
;//	[swap]
;//	[jump storage="ep004.ks" target="*start"]
;//[endswitch]
;//
;//
;//
;//１、フィア
;//２、メイル
;//３、シャルティエ
;//
;//

;// キャラ売り用 シャルティエ
[jump storage="ep004.ks" target="*start"]

;//==============================

;//全てのヒロインが攻略対象になっている場合
;//asd
*root_mao|The Demon Lord



All I ever wanted was to conquer the world.
[cpg]


I guess I'm awakening as a Demon Lord now that I've been in contact with so many demi-humans.
[cpg]


I wonder what steps I could take to conquer the world.
[cpg]


It may be something I can do on my own.
[cpg]


Still, I wanted to ask for someone's help. I didn't feel comfortable doing it alone.
[cpg]


To tell the truth, it was also a journey to find my demi-human wife.
[cpg]


It would be good to choose one person as a partner.
[cpg]


[STOPBGM]


[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




It is night. I have no more doubts about plotting world domination or choosing one person to be my partner.
[cpg]


There is only one person I love. It's ......
[cpg]

;//
;//
;//;//※全てのヒロインが攻略対象になっているため、必ず全ての選択肢がある
;//
;//
;//;//■選択肢
;//[switch]
;//[case "フィア"]
;//	[swap]
;//	[jump storage="ep005.ks" target="*start"]
;//[case "メイル"]
;//	[swap]
;//	[jump storage="ep006.ks" target="*start"]
;//[case "シャルティエ"]
;//	[swap]
;//	[jump storage="ep007.ks" target="*start"]
;//[case "クロロウルード"]
;//	[swap]
;//	[jump storage="ep008.ks" target="*start"]
;//[endswitch]
;//
;//
;//１、フィア
;//２、メイル
;//３、シャルティエ
;//４、クロロウルード
;//
;//

;// キャラ売り用 シャルティエ
[jump storage="ep007.ks" target="*start"]

