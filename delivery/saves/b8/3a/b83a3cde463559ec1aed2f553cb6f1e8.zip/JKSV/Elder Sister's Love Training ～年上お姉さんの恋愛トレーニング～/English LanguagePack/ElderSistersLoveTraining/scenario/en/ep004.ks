
*start|A Personal Maid

;#################################################
*Ep004|A Personal Maid
;#################################################

[SCENE id=4]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



On another day. 
[cpg]

Kanade invited me to her house.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sKanade023"]
[OnName num="kanade"]
"I can't believe you really came over."
[cpg cn=true]


[OnName num="masato"]
"Oh.....were you joking?"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sKanade024"]
[OnName num="kanade"]
"No. I just thought you'd chicken out."
[cpg cn=true]


In truth, I almost did. I was terrified that Miki would find out.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sKanade025"]
[OnName num="kanade"]
"Well, come on in. There's not much to see or do, but it's home."
[cpg cn=true]



;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_08_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[OnName num="masato"]
"Thank you....."
[cpg cn=true]


So I went inside."
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sKanade026"]
[OnName num="kanade"]
"Welcome to my castle."
[cpg cn=true]


It was cleaner and tidier than I'd expected.
[cpg]

Although she was being casual, I still wondered if it was okay for her to let me inside.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sKanade027"]
[OnName num="kanade"]
"It's a big bed, isn't it? I bet at least two people could lie down on it."
[cpg cn=true]



;//========================================
;//●ＣＧ（ベッドに寝転がるヒロイン。主人公は消してください）ev_13
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_13_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

And then she really lay down.
[cpg]

[OnName num="masato"]
".....What are you doing?
[cpg cn=true]


[VOICE f="sKanade028"]
[OnName num="kanade"]
"What? It's my room, so I'm free to do whatever I want."
[cpg cn=true]


Somehow, I can't read her.
[cpg]

I can't tell if she's trying to seduce me or not......
[cpg]

[VOICE f="sKanade029"]
[OnName num="kanade"]
"You look like you want to jump me at any moment now.."
[cpg cn=true]


[OnName num="masato"]
"You're imagining it."
[cpg cn=true]


[VOICE f="sKanade030"]
[OnName num="kanade"]
"Haha, I'm just kidding."
[cpg cn=true]


I'm glad she said it was a joke because the thought had crossed my mind for an instant......
[cpg]

At least, I hoped she was just joking.
[cpg]

;//移植のためシーンをカットしています


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

......I cooled down a bit and thought, I wouldn't do something like this as a joke.
[cpg]

I was rather serious. I'm trying to practice to succeed in a serious relationship.
[cpg]

I guess she was thinking of her friend. She sincerely wants me to develop my romance with Miki.
[cpg]

Yet, I did nothing...…
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

From there we talked for a while, and then I was on my way home again.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kanade135"]
[OnName num="kanade"]
"Please take care of Miki. Make sure you love her properly."
[cpg cn=true]


[OnName num="masato"]
"Sure......see you around."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]


I said goodbye to Kanade. I feel like I could have treated her differently than from when we were at the maid cafe.
[cpg]

I wonder if I'm getting used to being around girls a little......I started to think about my future.
[cpg]

;//■選択肢
[switch]
[case "Kanade is a really good person."]
	[swap]
	[jump target="*select04_1"]
[case "Now I can love Miki."]
	[swap]
	[jump target="*select04_2"]
[endswitch]


1. Kanade is a really good person.
2. Now I can love Miki.



;//１を選んだ場合　変数Ｂが１増加
;//どちらを選んでも物語は進行



;//==============================
;//１、奏は本当に良い人だ
*select04_1|A Personal Maid


[stflag flgB = 1]



Kanade is almost too kind. She always puts Miki first.
[cpg]

I guess she doesn't think about being with me.
[cpg]

Still, I felt that she was being almost too kind......
[cpg]

[jump target="*select04_3"]

;//==============================
;//２、これで美樹を愛することができる
*select04_2|A Personal Maid




Now I can finally love Miki properly.
[cpg]

I felt sorry for Kanade, but......Miki is the only one in my heart.
[cpg]

;//==============================

*select04_3|A Personal Maid


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


The weekend wasn't over yet, tomorrow is a Sunday.
[cpg]

I was determined to kiss Miki tomorrow.
[cpg]

I made up my mind, I'd kept her waiting long enough. I went to sleep, excited for the next day.
[cpg]

[jump storage="ep005.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

