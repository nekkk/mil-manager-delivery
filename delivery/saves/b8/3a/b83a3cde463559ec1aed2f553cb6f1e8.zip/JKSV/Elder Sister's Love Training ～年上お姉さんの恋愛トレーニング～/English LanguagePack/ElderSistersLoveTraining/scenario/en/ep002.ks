
*start|Training with Kanade

;#################################################
*Ep002|Training with Kanade
;#################################################

[SCENE id=2]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


Although I'd made up my mind, it was hard to take that first step.
[cpg]

In the first place, I wasn't even sure what exactly a concept cafe was.
[cpg]

I should probably look into it, but I felt like it would lead me down a path I'd never return from.......
[cpg]

Maybe that was a good thing, I didn't want to stay as I was now. It was hard to decide.
[cpg]

[OnName num="masato"]
"Whew...…"
[cpg cn=true]


The lecture was over and I was about to head to the cafeteria.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miki066"]
[OnName num="miki"]
"Oh, Masato. Are you going for lunch?"
[cpg cn=true]


[OnName num="masato"]
"Um, yeah. Do you want to join me, Miki?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Miki067"]
[OnName num="miki"]
"Sure, I'm starving."
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Miki used to turn a lot of heads whenever she entered the cafeteria......
[cpg]

But ever since she started dating me, their gazes have been directed at me instead.
[cpg]

People stare in wonder, as if to say, "Why is that guy with Ms. Rikura?"
[cpg]

Of course, the reason Miki drew so much attention was simply because she was beautiful.
[cpg]

Although I'm sure most college students had outgrown the tradition, if there was a ranking of girls that people wanted to date, I think she would be pretty high up on the list.
[cpg]

Conversely, if there was one for boys, I think I'd rank near the bottom.
[cpg]

I honestly didn't feel like I deserved her.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[FACE method="bow_7" pos="2/3"]
[VOICE f="Miki068"]
[OnName num="miki"]
"Okay, I'll see you later."
[cpg cn=true]


[OnName num="masato"]
"See you later......."
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』

[free time=1000]
[WAIT time=2000]

I say goodbye to Miki, thinking this was going to be the day.
[cpg]

Should I keep trying to date Miki without having any experience? Or should I get some practice first?
[cpg]

Normally, I'd probably choose the former, but the stress and panic I was feeling made it difficult to think rationally.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


That night I decided to go to the concept cafe where Kanade was working.
[cpg]

It was a pretty standard maid cafe. That said, I'd never been to one before.
[cpg]

[SE f="se006"]
;//【ＳＥ】『カフェ入店鈴』

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『メイドカフェ』（夜）******************************************************

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kanade014"]
[OnName num="kanade"]
"You finally came. What, were you trying to make up your mind all this time?"
[cpg cn=true]


[OnName num="masato"]
"Well, something like that...…"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sKanade006"]
[OnName num="kanade"]
"Well, I don't really care as long as you make Miki happy."
[cpg cn=true]


;//========================================
;//●ＣＧ（主人公のことを品定めするような感じの表情のヒロイン。背景と服装が変わっています）ev_06
;//人物１：ヒロイン２
;//服装１：メイド服
;//場所　：メイドカフェ室内
;//時間　：夜
;//========================================


[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[VOICE f="sKanade007"]
[OnName num="kanade"]
"Normally I'd tell you not to stare, but fortunately for you, this is the kind of place where it's okay."
[cpg cn=true]


[OnName num="masato"]
"I didn't think there'd be so many girls."
[cpg cn=true]


[VOICE f="sKanade008"]
[OnName num="kanade"]
"Haha, what did you think it would be like?"
[cpg cn=true]


We chatted for a bit and I decided to try to get used to being around girls for now.
[cpg]

Easier said than done...….
[cpg]

[VOICE f="sKanade009"]
[OnName num="kanade"]
"When you get used to being around me, you'd better show Miki how much you love her.
[cpg cn=true]



[OnName num="masato"]
"I know...…"
[cpg cn=true]


[VOICE f="Kanade020"]
[OnName num="kanade"]
"Do you? You seem really unreliable."
[cpg cn=true]


Yeah, I know. I'm pretty sure Miki feels that way too.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『メイドカフェ』（夜）******************************************************

;//移植のためシーンをカットしています

I'd been in the store for a while, but I didn't want to stay long.
[cpg]

It's not that it was uncomfortable or anything like that, but I couldn't shake this feeling of shame.
[cpg]

Of course, I couldn't voice my concerns because I was afraid of what Kanade would say.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="sKanade010"]
[OnName num="kanade"]
"You look nervous."
[cpg cn=true]


[OnName num="masato"]
"Well...yeah."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

She lets out an exasperated sigh and steps even closer.
[cpg]

;//ブラックアウト

;//========================================
;//●ＣＧ（可能であれば、立って居る絵にしてください）ev_08
;//人物１：ヒロイン２
;//服装１：メイド服
;//人物２：主人公
;//服装２：私服
;//場所　：メイドカフェ室内
;//時間　：夜
;//========================================

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[OnName num="masato"]
"Wha- whoa, hey!"
[cpg cn=true]


She came right up to me.
[cpg]

[VOICE f="sKanade011"]
[OnName num="kanade"]
"You're too timid. I'm sure you get that a lot."
[cpg cn=true]


She was right.
[cpg]

[VOICE f="sKanade012"]
[OnName num="kanade"]
"......What a waste. You're so good-looking, you should try to act like it."
[cpg cn=true]



;//移植のためシーンをカットしています
;//ブラックアウト

[OnName num="masato"]
"......Good-looking?"
[cpg cn=true]


[VOICE f="sKanade013"]
[OnName num="kanade"]
"That's what I said."
[cpg cn=true]


I guess I hadn't misheard her.
[cpg]

[OnName num="masato"]
"That makes me happy even if it's a lie. But I have to admit, it also makes me a little embarrassed."
[cpg cn=true]


[VOICE f="sKanade014"]
[OnName num="kanade"]
"It's not a lie and you're not supposed to admit that you're embarrassed."
[cpg cn=true]


I feel like I can learn a lot from her.
[cpg]

I can tell that she's thinking about what's best for Miki and I.
[cpg]

She's a real straight shooter.
[cpg]

;//■選択肢
[switch]
[case "This was just practice."]
	[swap]
	[jump target="*select02_1"]
[case "I might fall for Kanade."]
	[swap]
	[jump target="*select02_2"]
[endswitch]


1. This was just practice.
2. I might fall for Kanade.



;//２を選んだ場合　変数Ｂが２増加
;//どちらを選んでも物語は進行



;//==============================
;//１、あくまでこれは練習だ
*select02_1|Training with Kanade




This was just practice. I'm doing this for Miki's sake.
[cpg]

I had to clear my head. I was losing sight of my real goal.
[cpg]

I'd started all of this for one reason...…
[cpg]

[jump target="*select02_3"]

;//==============================
;//２、奏の事を好きになってしまいそうだ
*select02_2|Training with Kanade

[stflag flgB = 2]




I can't help but have feelings for Kanade......
[cpg]

I knew it was wrong, but Kanade started to fill my thoughts.
[cpg]

[VOICE f="Kanade065"]
[OnName num="kanade"]
"What's up with you?"
[cpg cn=true]


[OnName num="masato"]
"......Nothing."
[cpg cn=true]



;//==============================

*select02_3|Training with Kanade


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


On my way back home, I kept wondering if I was doing the right thing.
[cpg]

She's Miki's best friend......wasn't this just complicating things?
[cpg]

I need to show how much I love Miki as soon as possible, but I just didn't feel ready.
[cpg]

I was starting to hate myself for being unable to love Miki the way she deserved to be loved. I only hope it wasn't too late.
[cpg]

[OnName num="masato"]
"......If only I could be more honest with her about how I feel."
[cpg cn=true]


But I feel like she might dislike me if I told her the truth.
[cpg]

I'm so endlessly self-centered.....here comes that feeling of self-loathing again.
[cpg]

If I can't get over this, I'll never make any progress...…
[cpg]

[jump storage="ep003.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

