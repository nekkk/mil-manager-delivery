
*start|Invincible together

;//==============================
;//変数Ａが３
*goflgA3|Invincible together




I knew it was wrong that I hadn't even kissed Miki yet.
[cpg]

She's been waiting for six months. I have to answer her feelings.
[cpg]

After all, Miki had given me her answer a long time ago.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


It's not like Miki was shy about these sorts of things. I don't want her to make the first move.
[cpg]

If anyone is out of the ordinary, it's definitely me.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I can't keep freaking out forever. I decided to ask her out the next day.
[cpg]

I try to simulate how it will go, but in the end I'd just have to go with the flow.
[cpg]

No, no. I'd practiced for this, hadn't I? Now is the time to show off the results.
[cpg]

;#################################################
*Ep010|Invincible together
;#################################################

[SCENE id=10]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


I headed to the university without getting much sleep.
[cpg]

What should I say to Miki? Should I just act normal?
[cpg]

[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miki424"]
[OnName num="miki"]
".....Are you finally ready?"
[cpg cn=true]


Miki broached the subject first in a casual, joking manner.
[cpg]

But this time, I was serious.
[cpg]

[OnName num="masato"]
"I'm really sorry for making you wait so long."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Miki425"]
[OnName num="miki"]
"Haha...…I'd almost think you were serious, but I know.....you need more time, right?"
[cpg cn=true]


She's still teasing me. My words didn't mean much, I'd have to prove it to her through my actions.
[cpg]



[SE f="se001"]
;//【ＳＥ】『歩く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

I brought her into my room, it was finally time to take the first step.
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[FACE method="change_1" pos="2/3"]
[VOICE f="sMiki048"]
[OnName num="miki"]
"......So our first kiss, huh? It's taken so long to get this far......"
[cpg cn=true]


She looked a little hesitant.
[cpg]

[OnName num="masato"]
"You look nervous."
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="sMiki049"]
[OnName num="miki"]
"No way, you must be talking about yourself..."
[cpg cn=true]


She still doesn't believe me. I moved closer to her.
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I gently press my lips to hers. It was a soft brush of a kiss.
[cpg]

[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[OnName num="masato"]
"I guess I kept you waiting, didn't I?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sMiki050"]
[OnName num="miki"]
"You sure did......what made up your mind?"
[cpg cn=true]


I can't say.
[cpg]

Maybe someday, the truth will come out...…would she still be by my side then?
[cpg]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


......That day we finally made some progress.
[cpg]

I thought everything was going to be smooth sailing from there. What was there to be scared of anymore?
[cpg]

I felt like we could go anywhere and do anything.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


[FACE method="change_1" pos="2/3"]
[VOICE f="Miki472"]
[OnName num="miki"]
"Masato, your lecture today ends in the morning, right? Do you want to hang out?"
[cpg cn=true]


[OnName num="masato"]
"Yeah, sure......But what about you?"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Miki473"]
[OnName num="miki"]
"I'm not going to let you go today. Let's show off to everyone."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Miki474"]
[OnName num="miki"]
"Yeah, our classes got cancelled today too."
[cpg cn=true]


[OnName num="male_student_A"]
"......Those two are closer than ever, huh?"
[cpg cn=true]


[OnName num="male_student_B"]
"Yeah, did something happen...…? Did they have a fight and make up?"
[cpg cn=true]


[OnName num="male_student_A"]
"That doesn't explain it...…"
[cpg cn=true]


I don't think people will understand. We hadn't made any progress for six whole months.
[cpg]

In the meantime, Miki talks to somebody on the phone.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Miki475"]
[OnName num="miki"]
"Kanade is coming, too. Is that okay Masato?"
[cpg cn=true]


[OnName num="masato"]
"Sure. You're going to show off to Kanade, aren't you?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Miki476"]
[OnName num="miki"]
"Precisely."
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************



The three of us walk together.
[cpg]

I was a little nervous, but I was sure Kanade wouldn't interfere.
[cpg]

[FACE method="bow_2" pos="2/5"]
[VOICE f="Miki477"]
[OnName num="miki"]
"I'm hungry, let's grab something to eat."
[cpg cn=true]


[free time=500]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="4/5" time=800]
[WAIT time=1000]

[VOICE f="Kanade333"]
[OnName num="kanade"]
"Masato...…you didn't tell Miki, did you?"
[cpg cn=true]


[OnName num="masato"]
"What are you talking about?"
[cpg cn=true]


I play dumb, but Kanade looks at me seriously.
[cpg]

[FACE method="bow_3" pos="4/5"]
[VOICE f="Kanade334"]
[OnName num="kanade"]
"I'm fine with it. I'll leave it up to you whether you want to hide it or not."
[cpg cn=true]


[free time=500]
[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Miki478"]
[OnName num="miki"]
"What are you talking about? Come on, let's go."
[cpg cn=true]


[OnName num="masato"]
"Yeah, sure......."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


I started to worry.
[cpg]

It was true that hiding things from Miki was a problem.
[cpg]

Should I try to her even a little bit? No, I didn't see a way to keep everything a secret.
[cpg]

I'd have to tell her everything.
[cpg]

But how would she react......?
[cpg]

No. I can't tell her. But the harder I try to keep it a secret, the more it feels like she'll find out.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Miki479"]
[OnName num="miki"]
"That was a lot of fun..…See you later, Kanade."
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Kanade335"]
[OnName num="kanade"]
"What? Are you two ditching me?"
[cpg cn=true]


[FACE method="shake_6" pos="2/5"]
[VOICE f="Miki480"]
[OnName num="miki"]
"Read the room...….."
[cpg cn=true]


Miki was extremely affectionate. She'd stopped holding back for my sake.
[cpg]

[FACE method="bow_2" pos="4/5"]
[VOICE f="Kanade336"]
[OnName num="kanade"]
"Fine, fine......be happy, you two."
[cpg cn=true]


Kanade parted with us with a slightly conflicted look on her face..
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[FACE method="change_2" pos="2/3"]
[VOICE f="Miki481"]
[OnName num="miki"]
"Well then, let's do it here today. Masato......Masato?"
[cpg cn=true]


[OnName num="masato"]
"......There's something I think I should tell you."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Miki482"]
[OnName num="miki"]
"What? Is it serious?"
[cpg cn=true]


[OnName num="masato"]
"Well...…hear me out."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Miki483"]
[OnName num="miki"]
"Okay, I promise I won't hate you, no matter what you tell me."
[cpg cn=true]


As if encouraged by her words, I begin to explain all that I'd done.
[cpg]

[OnName num="masato"]
"In the beginning, I was......really scared about dating you and what that implied."
[cpg cn=true]


[OnName num="masato"]
"So I......met with Kanade a few times. Just the two of us."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

Miki goes pale and her expression freezes. She might be regretting her promise already...
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Miki484"]
[OnName num="miki"]
"……I see."
[cpg cn=true]


Her voice was quiet. She looked more depressed than angry or confused.
[cpg]

Miki looks up as if she'd made up her mind about something.
[cpg]

[SE f="se009"]
;//【ＳＥ】『力ないビンタ』

[FACE method="shock_4" pos="2/3"]


She slapped my cheek, but there wasn't much weight behind it.
[cpg]

Tears roll down her face. I knew I shouldn't have told her...
[cpg]

I knew it. I knew it, but I couldn't hide it from her......
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Miki488"]
[OnName num="miki"]
"......I'm going home......"
[cpg cn=true]


[OnName num="masato"]
"Wait, please......I really love you Miki."
[cpg cn=true]


[OnName num="masato"]
"I was so scared that you'd come to hate me...…"
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Miki489"]
[OnName num="miki"]
"Then you could have kept what you did with Kanade a secret. What were you really scared of!? I know it's not me!"
[cpg cn=true]


[OnName num="masato"]
"That's...…"
[cpg cn=true]


Was I just making excuses? Was I more comfortable around other girls?
[cpg]

In the end, it wasn't much of an excuse and it certainly didn't validate what I'd done.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト


I tried to keep Miki from leaving in tears, but words were not enough.
[cpg]

Words weren't enough......we haven't talked since that day.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


Miki started to keep her distance from me.
[cpg]

I wasn't really sure how to talk to her anymore.
[cpg]

Maybe I could invite her over, but I don't think that would resolve anything.
[cpg]

It's not like I had the courage to do so anyways.
[cpg]

I don't want her to hate me. I don't want to lie to her, or pretend that I hadn't cheated on her.......
[cpg]

Of course, I couldn't accomplish both of those things.
[cpg]

Time just goes by.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


One night, I thought about Kanade.
[cpg]

Would Kanade be willing to give me some advice.
[cpg]

I headed to her place.
[cpg]

I was terrified. If Miki finds out, that would truly be the end of us.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miki490"]
[OnName num="miki"]
"......What are you doing here......"
[cpg cn=true]


[OnName num="masato"]
"Whoa!?"
[cpg cn=true]


I ran into Miki while I was thinking about what to do.
[cpg]

[OnName num="masato"]
"Why are you here......?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="sMiki051"]
[OnName num="miki"]
"I wanted to talk to Kanade about something. I guess we know who you really like after all."
[cpg cn=true]


Miki rings the doorbell. It was too late for me to leave.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="4/5" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



[FACE method="shake_4" pos="4/5"]
[VOICE f="sKanade063"]
[OnName num="kanade"]
".....What are you two doing here?"
[cpg cn=true]


[FACE method="shock_5" pos="2/5"]
[VOICE f="Miki493"]
[OnName num="miki"]
"Well......Kanade......"
[cpg cn=true]


[FACE method="shake_3" pos="4/5"]
[VOICE f="sKanade064"]
[OnName num="kanade"]
"Miki, I'm sorry about all this."
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="sKanade065"]
[OnName num="kanade"]
"No matter how much you talk to me, you'll never make any progress."
[cpg cn=true]

[free time=1000]
[SE f="se012"]
;//【ＳＥ】『走る』

Miki walked away, almost in tears.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Kanade340"]
[OnName num="kanade"]
"What are you doing? Go after her."
[cpg cn=true]


[OnName num="masato"]
"Yeah......yeah, I know."
[cpg cn=true]



[SE f="se012"]
;//【ＳＥ】『走る』

[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


[OnName num="masato"]
"Wait! Miki, don't go...…"
[cpg cn=true]


I chased after Miki and grabbed her.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miki496"]
[OnName num="miki"]
"......If only I could just go crazy, then maybe I wouldn't have to feel like this."
[cpg cn=true]


Miki wouldn't even make eye contact with me.
[cpg]

[OnName num="masato"]
"Can't I play that role?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Miki498"]
[OnName num="miki"]
"You can't, you don't have the guts."
[cpg cn=true]


What should I do? No, this wasn't the time to think.
[cpg]

[SE f="se029"]
;//【ＳＥ】『衣擦れ』

[FACE method="shock_5" pos="2/3"]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



This might not have been the right choice, but I was out of options.
[cpg]

I grabbed her arm and took her into a secluded alley.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="sMiki052"]
[OnName num="miki"]
"What are you doing? Stop it!"
[cpg cn=true]


The old me probably would have stopped.
[cpg]

I was going to do what she had once wanted me to do.
[cpg]

;//移植のためシーンをカットしています

;//[FACE method="shock_5" pos="2/3"]
[free time=300]
[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]

And I kissed her forcefully.
[cpg]

Something I wouldn't have done in the past. Was I able to do this because I practiced with Kanade?
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="sMiki053"]
[OnName num="miki"]
"……"
[cpg cn=true]


I don't know. But there was nothing else I could do.
[cpg]

;//移植のためシーンをカットしています

;//【ＢＧ】『街』（夜）******************************************************


[OnName num="masato"]
"......I don't want you to go crazy."
[cpg cn=true]


I'd calmed down a bit.
[cpg]

Miki looked up at me and nodded.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Miki537"]
[OnName num="miki"]
"I guess I was acting a little desperate..."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Miki538"]
[OnName num="miki"]
You must have been scared, I'm sorry."
[cpg cn=true]


Who else could be as devoted as she is?
[cpg]

[OnName num="masato"]
"No, I'm not scared. I'm not afraid of anything anymore."
[cpg cn=true]


[OnName num="masato"]
"As long as I have you, nothing else matters."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Miki539"]
[OnName num="miki"]
"Thank you.......I feel a little better already."
[cpg cn=true]


I wonder if that's how she really felt......
[cpg]

I'd have to take my time and make sure.
[cpg]

I hug her again.
[cpg]

Feeling her warmth hardened my resolve to never let her go again.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

That weekend.
[cpg]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


Looking back, I'd made a huge mistake, yet Miki had found it in her heart to forgive me.
[cpg]

Every time she forgave me, I felt a weight on my shoulders.
[cpg]

It was my sin to bear. I know I had her forgiveness, but I couldn't forgive myself.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Miki540"]
[OnName num="miki"]
"Are you thinking of something unnecessary again?"
[cpg cn=true]


[OnName num="masato"]
"......How do you know?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Miki541"]
[OnName num="miki"]
"If you cheat on me again, I don't think it would take long to find out. You're really easy to read."
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Miki542"]
[OnName num="miki"]
"But I don't think you'll lie to me again..."
[cpg cn=true]


[OnName num="masato"]
"I won't lie to you ever again. You know I'm a coward."
[cpg cn=true]


Miki smiled a little. I felt some relief.
[cpg]

;//========================================
;//●ＣＧ（主人公を誘うヒロイン）ev_45
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================

;//[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_45_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[VOICE f="sMiki054"]
[OnName num="miki"]
"I know. But......"
[cpg cn=true]


[VOICE f="sMiki055"]
[OnName num="miki"]
"You already know what I want you to do, don't you?"
[cpg cn=true]


I know. I've known for a long time.
[cpg]

I won't hesitate anymore. I won't keep her waiting...…
[cpg]

[OnName num="masato"]
"Yeah, I know."
[cpg cn=true]


[VOICE f="sMiki056"]
[OnName num="miki"]
"I'm glad. Masato."
[cpg cn=true]


Calling my name is not just for confirmation.
[cpg]

She call my name because of her affection for me.
[cpg]

If only I had the words to describe how much I felt for her.......
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


We kiss again. This was part of what we were missing all this time.
[cpg]

It's what Miki wanted. There was so much more to say, but words couldn't convey even half of it.
[cpg]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************

We spend some time together.
[cpg]

[OnName num="masato"]
"I'm hungry."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sMiki057"]
[OnName num="miki"]
"I still like you, Masato after all."
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="sMiki058"]
[OnName num="miki"]
"Even if you did some pretty awful things to me."
[cpg cn=true]


I couldn't answer. I guess that part of me hadn't changed.
[cpg]

[OnName num="masato"]
"I'll do whatever it takes to make up for it."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sMiki059"]
[OnName num="miki"]
"Ahaha, I guess you're a little cooler than before."
[cpg cn=true]

I felt a strange sensation welling up inside of me.
[cpg]

[OnName num="masato"]
"I'm embarrassed...…."
[cpg cn=true]


I'd call it embarrassment, but I think it was something different.
[cpg]

It's somewhere between relief and regret.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

Miki approached me again.
[cpg]

;//========================================
;//●ＣＧ（主人公にのしかかるヒロイン）ev_46
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_46_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[VOICE f="sMiki060"]
[OnName num="miki"]
"......You smell good."
[cpg cn=true]


She looked like she meant it.
[cpg]

She still loves me.
[cpg]

That made me happier than anything else.......
[cpg]

[VOICE f="sMiki061"]
[OnName num="miki"]
"I love you. Masato, really, truly."
[cpg cn=true]


Those frank words move me the most.
[cpg]

[OnName num="masato"]
"I love you too, Miki. I love you."
[cpg cn=true]


What I said was similar.
[cpg]

After all, there is only so much meaning that words can convey.
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]

After that, we spent a long time together.
[cpg]

We cherish every moment.
[cpg]

No matter what we were doing, we were happy just being together.
[cpg]

We'd met up in the afternoon, but it was already night.
[cpg]

;//========================================
;//●ＣＧ（二人寄り添って、ベッドで疲れ切って寝ている。ヒロインは途中で目を閉じる）ev_47
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;**【ＣＧ】 ev_47_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]



[VOICE f="Miki584"]
[OnName num="miki"]
"......I feel like I'm going to fall asleep...…"
[cpg cn=true]


[OnName num="masato"]
"Are you sure? How are you going to explain that to your family?"
[cpg cn=true]



[VOICE f="Miki585"]
[OnName num="miki"]
"I'll just say I stayed at Kanade's place.....I wonder if that'll work?"
[cpg cn=true]


[OnName num="masato"]
"Don't ask me."
[cpg cn=true]

;**【ＣＧ】 ev_47_a ***********************
[CG id=19 index=1 time=1]
;***************************************
[WAIT time=1]

Miki drifts off to sleep.
[cpg]

[OnName num="masato"]
"Miki......are you sleeping?"
[cpg cn=true]



[VOICE f="Miki586"]
[OnName num="miki"]
"Mmh......not yet."
[cpg cn=true]


Then she turned over to me and smiles.
[cpg]

We had overcome a wall. It was a wall I'd built, but now......
[cpg]

I think our bond has become stronger. We are invincible.
[cpg]

;//ブラックアウト


[SCENE id=16]
;//ＥＮＤ：ヒロイン１ルート２

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

