
*start|I want to cherish my relationships with Miki and Kanade

;//==============================
;//変数Ａが２以上　変数Ｂが２以上
*goflgA2B2|I want to cherish my relationships with Miki and Kanade




I care about both Kanade and Miki.
[cpg]

I know this is cheating......but it didn't change how I felt about them.
[cpg]

Of course, my feelings for Miki were stronger, but despite that......
[cpg]

I wanted to visit Kanade more frequently.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


Of course, I have to make sure I don't get found out. It's a lot of work when you have to be so careful.
[cpg]

With that thought, I headed off to college.
[cpg]


;#################################################
*Ep007|I want to cherish my relationships with Miki and Kanade
;#################################################

[SCENE id=7]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


I attended my lectures and met up with Miki.
[cpg]

We ate together and talked about trivial things.
[cpg]

All the while, I was thinking about Kanade.
[cpg]

Later, I found myself walking to Kanade's place. It felt natural.
[cpg]

Rather than going to the maid cafe where she worked, I went to her house.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

Then one day.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sKanade042"]
[OnName num="kanade"]
"......Masato, have you been paying attention to Miki lately?"
[cpg cn=true]


[OnName num="masato"]
"Um, yeah."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Kanade230"]
[OnName num="kanade"]
"Bull. You know she tells me everything."
[cpg cn=true]


I probably shouldn't have lied. I scratch my head.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="sKanade043"]
[OnName num="kanade"]
"I don't need to confirm that you don't have the courage to do it."
[cpg cn=true]


[OnName num="masato"]
".....Sorry."
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="sKanade044"]
[OnName num="kanade"]
"You can apologize to me all you want, but don't you feel sorry for Miki?"
[cpg cn=true]


[OnName num="masato"]
"I do. I feel sorry for making her wait."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sKanade045"]
[OnName num="kanade"]
"Do you? If you really feel that way, you should be able to take action."
[cpg cn=true]


[OnName num="masato"]
"I'm sorry...…"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="sKanade046"]
[OnName num="kanade"]
"What good is apologizing going to do?"
[cpg cn=true]



;//移植のためシーンをカットしています

This was supposed to be practice.
[cpg]

But it seems I'd gotten too comfortable with the process and my goals had changed.
[cpg]


;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


When we parted, I called out to Kanade.
[cpg]

[OnName num="masato"]
"......Hey, Kanade."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sKanade047"]
[OnName num="kanade"]
"What? You look so gloomy."
[cpg cn=true]


[OnName num="masato"]
"I'm cheating on Miki, aren't I?"
[cpg cn=true]


[OnName num="masato"]
"Am I really doing this for Miki's sake...…?"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sKanade048"]
[OnName num="kanade"]
"......Don't worry about it."
[cpg cn=true]


At that time, I didn't understand what she was trying to say.
[cpg]

;//ブラックアウト

[FACE method="bow_1" pos="2/3"]
[VOICE f="sKanade049"]
[OnName num="kanade"]
"I'll see you later."
[cpg cn=true]

[OnName num="masato"]
"Yeah......."
[cpg cn=true]


The days go on and on without me ever understanding.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


The weekdays pass, and then the weekend arrives. I went on a date with Miki, but......
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Miki211"]
[OnName num="miki"]
"......Sigh."
[cpg cn=true]


Miki just sighs frequently and looks unhappy.
[cpg]

[OnName num="masato"]
"Hey, did I say something wrong...…? Tell me if you have any complaints."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Miki212"]
[OnName num="miki"]
"I don't. Masato, are you hiding something from me?"
[cpg cn=true]


[OnName num="masato"]
"No, nothing in particular...…"
[cpg cn=true]


My body jerks in panic.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Miki213"]
[OnName num="miki"]
"Okay."
[cpg cn=true]


I don't know what Miki is thinking.
[cpg]

Maybe she figured out what was going on with Kanade and I.
[cpg]

But if that was true, I thought she'd get angrier with me.......
[cpg]

We continued our date with me wondering the entire time about what she knew.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



Later that evening, Miki and I head to her room.
[cpg]

[free time=500]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="sKanade050"]
[OnName num="kanade"]
"Oh, you're here."
[cpg cn=true]


[OnName num="masato"]
"Kanade!?"
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="sMiki024"]
[OnName num="miki"]
"Why are you so surprised? We've already spent so much time together."
[cpg cn=true]


[OnName num="masato"]
"Well, it's, uh, it's......uh..."
[cpg cn=true]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************




I was herded into her room before I'd gotten a grasp on what was happening.
[cpg]

[OnName num="masato"]
"......What's going on? Miki, did you know all along?"
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="sMiki025"]
[OnName num="miki"]
"What's going on? I think that's what I should be asking you."
[cpg cn=true]


She looks more annoyed than angry.
[cpg]

;//移植のためシーンをカットしています

[FACE method="shake_7" pos="4/5"]
[VOICE f="sKanade051"]
[OnName num="kanade"]
"How many times did I tell you not to keep Miki waiting?"
[cpg cn=true]


[OnName num="masato"]
"Wait just a minute."
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="sMiki026"]
[OnName num="miki"]
"Wait wait wait. Do you ever say anything else?"
[cpg cn=true]

[OnName num="masato"]
"But I'm not ready for this."
[cpg cn=true]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Miki227"]
[OnName num="miki"]
"Then what am I supposed to do? I've been ready for so long now, I can't wait any longer."
[cpg cn=true]



;//ブラックアウト
;//========================================
;//●ＣＧ（ヒロイン二人が主人公を誘う。背景が変わっています）ev_25
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_25_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

;//移植のためシーンをカットしています

[VOICE f="sMiki027"]
[OnName num="miki"]
"Don't you care?"
[cpg cn=true]


[OnName num="masato"]
"……It's not that I don't care."
[cpg cn=true]


[VOICE f="sKanade052"]
[OnName num="kanade"]
"Yeah, yeah. You're scared."
[cpg cn=true]


[VOICE f="sKanade053"]
[OnName num="kanade"]
"Get over it. Quit wasting your youth and do something with it."
[cpg cn=true]


......I guess this was it.
[cpg]

[VOICE f="sMiki028"]
[OnName num="miki"]
"......Come on."
[cpg cn=true]


Her words were the final push I needed.
[cpg]

[OnName num="masato"]
"Okay....."
[cpg cn=true]


I felt strange to answer like that. Normally, I never would have said that.
[cpg]

;//ブラックアウト

It was now or never. I moved closer to Miki...ever closer until our lips touched.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


......It happened. It finally happened.
[cpg]

[FACE method="bow_6" pos="2/5"]
[VOICE f="Miki239"]
[OnName num="miki"]
"Oh, I'm......sorry, Masato."
[cpg cn=true]


[OnName num="masato"]
"Why are you apologizing?"
[cpg cn=true]


I ask, but I also know that Miki is that kind of girl.
[cpg]

[OnName num="masato"]
"……So, Kanade told you everything?"
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Kanade296"]
[OnName num="kanade"]
"Yeah, well, I just thought I couldn't let things go on like this."
[cpg cn=true]


I kind of thought she'd say that.
[cpg]

[FACE method="shake_2" pos="2/5"]
[VOICE f="Miki240"]
[OnName num="miki"]
"I knew you were cheating on me, but I still love you, Masato."
[cpg cn=true]


I felt like a weight had been lifted off my shoulders, but all that remained was exhaustion...…
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I stopped going to Kanade's place.
[cpg]

There was no need to, I saw Miki and Kanade together often.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="sMiki029"]
[OnName num="miki"]
"......Why this outfit?"
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="sKanade054"]
[OnName num="kanade"]
"What? It looks good on you."
[cpg cn=true]



It seems like Kanade's even more energetic than usual.
[cpg]

Today Kanade had gotten Miki to wear a uniform.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="sMiki030"]
[OnName num="miki"]
"Are you sure......?"
[cpg cn=true]


[FACE method="bow_6" pos="4/5"]
[VOICE f="sKanade055"]
[OnName num="kanade"]
"Yes, yes. I'd jump you right now if we didn't have an audience."
[cpg cn=true]

I had a feeling that she was serious when she said that.
[cpg]

[OnName num="masato"]
"Hold on, did you get involved in our relationship because you wanted to be with Miki?"
[cpg cn=true]


Kanade giggles and turns to Miki.
[cpg]

;//ブラックアウト
;//========================================
;//●ＣＧ（キスするヒロイン二人）ev_26
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：ヒロイン２
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_26_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

[VOICE f="sKanade056"]
[OnName num="kanade"]
"Pretty much, yeah......"
[cpg cn=true]


Kanade hugs Miki.
[cpg]

[OnName num="masato"]
"Whoa, hey!"
[cpg cn=true]


[VOICE f="sMiki031"]
[OnName num="miki"]
"Mmmhhh!!"
[cpg cn=true]


And she moves in for a kiss. Was she serious?
[cpg]

;//移植のためシーンをカットしています

;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[window target=true]
;//ブラックアウト

;//移植のためシーンをカットしています

;//[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMiki032"]
[OnName num="miki"]
"What are you doing?"
[cpg cn=true]


;//[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sKanade057"]
[OnName num="kanade"]
"Sorry, sorry. I thought you were in that kind of mood."
[cpg cn=true]


She plays it off casually, but I think there was more to it than that.
[cpg]

She must really like Miki.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


From there on our relationship still continued, but Miki was the only one for me.
[cpg]

Miki really loves me, but Kanade seems to have other plans.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（夕方）******************************************************


The three of us spend most of our free time together.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

Kanade had taken to waiting on campus for us to finish our classes.
[cpg]

[OnName num="male_student"]
"Wow, she's soooo beautiful......."
[cpg cn=true]


[OnName num="female_student"]
"I know......Is she someone's girlfriend?"
[cpg cn=true]


While eavesdropping on such conversations, we headed toward Kanade.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



[FACE method="bow_1" pos="2/5"]
[VOICE f="sMiki033"]
[OnName num="miki"]
"It's the three of us together again. I feel like this has become our new normal."
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Kanade319"]
[OnName num="kanade"]
"What? Should I have brought another girl?"
[cpg cn=true]


[OnName num="masato"]
"No, no, don't do that...…"
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Miki268"]
[OnName num="miki"]
"I wouldn't like that either...…"
[cpg cn=true]



[FACE method="shake_1" pos="4/5"]
[VOICE f="Kanade320"]
[OnName num="kanade"]
"It was just a joke guys, come on."
[cpg cn=true]


Time passes, but our strange relationship continues.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FACE method="change_1" pos="2/5"]
[FACE method="change_1" pos="4/5"]

Some day, Miki will probably want it to just be the two of us.
[cpg]

Kanade's probably just happy to be with Miki.
[cpg]

[FACE method="bow_2" pos="2/5"]
[FACE method="bow_2" pos="4/5"]


As for me? What was there to complain about?
[cpg]

[SCENE id=13]
;//ＥＮＤ：ヒロイン２ルート２


[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

