
*start|A detour to face Miki

;//==============================
;//変数Ｂが３
*goflgB3|A detour to face Miki


I should practice with Kanade for a little while longer. I know this is like cheating, but still......
[cpg]

I just didn't have the courage. I didn't care what would happen with Kanade.
[cpg]

No, the truth was that I don't want her to be disappointed by me either.
[cpg]

But there was something about how casually I could interact with Kanade that drew me to her.
[cpg]

;//ブラックアウト

Somehow I lacked the courage to even kiss Miki, but I somehow have the courage to cheat on her.
[cpg]

I feel that Kanade could see right through me.
[cpg]

More to the point, even Miki would understand all this if she knew the facts.
[cpg]

……I can't go on like this.
[cpg]

;#################################################
*Ep006|A detour to face Miki.
;#################################################

[SCENE id=6]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2100]


;//【ＢＧ】『主人公の部屋』（夜）******************************************************




[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


[OnName num="masato"]
"……Yaaaawn"
[cpg cn=true]


I wake up in the morning, yawning. I had another day of lectures at the university.
[cpg]

I might meet Miki on campus, but I found my mind to be occupied with thoughts of Kanade.
[cpg]

I brush my teeth, wash my face, and have breakfast.
[cpg]

I don't feel like cooking breakfast in the morning. All I do is nibble on a pastry.
[cpg]

I wouldn't say I'd fallen so far as to become a slob.
[cpg]

I wondered if sleeping with Kanade would become a part of my daily life.......
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（昼）******************************************************


I head to the university and attend the lectures.
[cpg]

I also have lunch with Miki during lunch break.
[cpg]

But I was still thinking about Kanade.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miki146"]
[OnName num="miki"]
"......What's wrong, Masato? Lately, it seems like you're thinking of something else whenever you're with me."
[cpg cn=true]


[OnName num="masato"]
"It's nothing, really."
[cpg cn=true]


I tried to assure her that nothing had changed.
[cpg]

If she knew the truth, we might break up.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


Recently, Kanade and I have been meeting more frequently, but not at the maid cafe.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kanade136"]
[OnName num="kanade"]
"So, shall we go?"
[cpg cn=true]


[OnName num="masato"]
"Yeah. Sorry about all of this."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="sKanade031"]
[OnName num="kanade"]
"I don't really mind, but...shouldn't you be ready by now? You should be giving your love to Miki."
[cpg cn=true]


I can't do that. I haven't made up my mind yet...…
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I can't go on a date with her because I don't want Miki to find out about us.
[cpg]

We were headed to Kanade's house, but even then, I found myself hesitating.
[cpg]

While we were talking about Miki, Kanade grew impatient.
[cpg]

;//========================================
;//●ＣＧ（主人公に詰め寄るヒロイン）ev_18
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]




[VOICE f="sKanade032"]
[OnName num="kanade"]
"Will you just stop? How can you possibly be this much of a coward?"
[cpg cn=true]


[OnName num="masato"]
"What's with you all of a sudden?"
[cpg cn=true]


[VOICE f="sKanade033"]
[OnName num="kanade"]
"And to top it off, you play dumb the same way every time."
[cpg cn=true]


There wasn't anything I could say in response.
[cpg]

[VOICE f="sKanade034"]
[OnName num="kanade"]
"All of this is because of you. Take responsibility for once in your life."
[cpg cn=true]


[OnName num="masato"]
"……"
[cpg cn=true]


She was right, but I still can't get rid of this feeling of indecisiveness.
[cpg]

[VOICE f="sKanade035"]
[OnName num="kanade"]
"When I'm with you, I start feeling like I'm ruining everything."
[cpg cn=true]


[OnName num="masato"]
"It's not your fault, Kanade."
[cpg cn=true]


Kanade shakes her head and continues.
[cpg]

[VOICE f="sKanade036"]
[OnName num="kanade"]
"If I'm feeling like this after talking to you, I know that Miki feels that way even more."
[cpg cn=true]


She wasn't holding back, but I felt like I needed to hear it.
[cpg]

[OnName num="masato"]
"You're right...…"
[cpg cn=true]


Kanade saw me pondering and said nothing.
[cpg]

I could tell that all of this came from a place of kindness.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


;//そんなことがあってから、家に戻るまでの途中。
After that, Kanade saw me out the door.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kanade184"]
[OnName num="kanade"]
"Don't keep Miki waiting too long. Remember that she tells me everything."
[cpg cn=true]


[OnName num="masato"]
"Yeah, I know."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="sKanade037"]
[OnName num="kanade"]
"You'd better."
[cpg cn=true]



;//ブラックアウト



[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

[free time=1000]
[WAIT time=1500]


After parting with Kanade, I went back to my house.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


……I'm going to keep practicing with Kanade.
[cpg]

She and I are not lovers. Miki was the only girl for me.
[cpg]

I convinced myself that all of this was necessary.......it was inevitable.
[cpg]

Deep down, I know that I'm in the wrong.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


It's morning. I have to go to the university again.
[cpg]

What will I talk about when I see Miki? How many times have I told her that I didn't want to rush.
[cpg]

Despite what she says, I don't think she agrees with me.
[cpg]

She's just enduring it for my sake. I know it's a problem I'll have to deal with someday......
[cpg]

But I can't do anything about it, this was how I felt.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（朝）******************************************************


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miki147"]
[OnName num="miki"]
"Good morning, Masato."
[cpg cn=true]


[OnName num="masato"]
"Good morning."
[cpg cn=true]


Miki and I were in the same lecture today. We chat a bit until the professor arrives.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Miki148"]
[OnName num="miki"]
"By the way, there is a new restaurant that opened the other day......"
[cpg cn=true]


[OnName num="masato"]
"Let's go there together, but let me check the price first."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Miki149"]
[OnName num="miki"]
"Ahaha, sure."
[cpg cn=true]


She laughs when I talk about money, or casual things.
[cpg]

But when it comes to more personal matters, she doesn't laugh.
[cpg]

I guess that's how seriously she took our relationship.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（夕方）******************************************************


Time passes. I end up not doing anything with Miki again.
[cpg]

I wanted to meet Kanade again.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miki150"]
[OnName num="miki"]
"Hey Masato......do you have some time after this?"
[cpg cn=true]


[OnName num="masato"]
"I'm sorry, I have some business to attend to."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Miki151"]
[OnName num="miki"]
"I see...…"
[cpg cn=true]


It wouldn't be surprising if she had asked about what I was doing, but she was kind enough not to.
[cpg]

I often feel something like a maternal nature from her.
[cpg]

I felt myself falling in love with her all over again, but it was quickly replaced with a feeling of self-loathing.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


I would say that men are foolish creatures......but that wouldn't be fair to all of the other men in the world.
[cpg]

I'm probably the worst of them all. I can't even bring myself to kiss my girlfriend and we've been dating for six months.
[cpg]


;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『メイドカフェ』（夜）******************************************************



[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kanade186"]
[OnName num="kanade"]
"You're here again.....? Why can't you just put all this energy into wooing Miki?"
[cpg cn=true]



After I headed to Kanade's place, she was quite angry.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kanade187"]
[OnName num="kanade"]
"If you keep this up, I'm going to have to rethink our arrangement."
[cpg cn=true]


[OnName num="masato"]
".....But it was your idea, wasn't it?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Kanade188"]
[OnName num="kanade"]
".....Yes, but.....Well, I'm still going to have to think about it."
[cpg cn=true]


I'm kind of scared. I wonder what Kanade is up to.
[cpg]

Even if she were up to something, I don't think it's something I'd have the courage to do.
[cpg]

While talking to me, Kanade was playing with her phone. I had a feeling that it wasn't just because she was in a bad mood.
[cpg]

;//移植のためシーンをカットしています



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Kanade210"]
[OnName num="kanade"]
"Listen, Masato. Are you seriously not going to do anything with Miki?"
[cpg cn=true]


[OnName num="masato"]
"Well......one of these days."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Kanade211"]
[OnName num="kanade"]
"When is that supposed to be?"
[cpg cn=true]


[OnName num="masato"]
"One of these days?"
[cpg cn=true]

The conversation doesn't go anyways. She'll ask a question about Miki and I'll deflect it. I've had a lot of practice now.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kanade212"]
[OnName num="kanade"]
"......Okay, I guess there's no other choice."
[cpg cn=true]

[free time=1000]

We parted without me finding out what she meant by that.
[cpg]

I went back home......
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

Some part of me thought that we'd continue on like this for a while.
[cpg]

I could practice with Kanade, but that was it.
[cpg]

It will be a while before I can take the next step......
[cpg]

Or so, I had thought.....change comes suddenly.
[cpg]

Apparently, I was not the only one who thought that nothing would change.
[cpg]

Kanade was determined to break me out of the comfortable routine I'd fallen into.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


The next morning I headed to the university as usual.
[cpg]

A familiar routine. Familiar was good. Familiar was comfortable. I felt like I could drag it out forever.
[cpg]

But the reality was different. I should have paid more attention to Kanade when she was playing with her phone.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』


;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（昼）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]

[OnName num="masato"]
"Yo, Miki...… What's up? Is something wrong?"
[cpg cn=true]


I ran into Miki on campus. She looked shaken, like she'd seen something shocking.
[cpg]

She grabs my arm and pulls me to a less populated location.
[cpg]



[SE f="se001"]
;//【ＳＥ】『歩く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（昼）******************************************************



[VOICE f="Miki152"]
[OnName num="miki"]
"Masato. Is there something you're not telling me?"
[cpg cn=true]


[OnName num="masato"]
"What are you talking about......?"
[cpg cn=true]


I felt a chill run down my spine. Did she find out about Kanade?
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="sMiki012"]
[OnName num="miki"]
"Tell me the truth.....are you meeting with Kanade behind my back?"
[cpg cn=true]


[OnName num="masato"]
"Of course not, where did this come from?"
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Miki154"]
[OnName num="miki"]
"......I didn't think you'd lie to my face."
[cpg cn=true]


Miki had to have proof.
[cpg]

When did it happen? Did she see us together? No, that's unlikely...
[cpg]

How did she know? Did she follow me? No, why would she be suspicious of me in the first place......
[cpg]

Maybe there wasn't any solid proof, maybe I could say that she was mistaken.
[cpg]

[OnName num="masato"]
"I'm not lying. What reason would I have to lie to you?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Miki155"]
[OnName num="miki"]
"Because if you don't lie, you'd be cheating on me."
[cpg cn=true]


[OnName num="masato"]
"It's a misunderstanding. Why do you think so?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="sMiki013"]
[OnName num="miki"]
"Kanade sent me a message......she told me you two were meeting up a lot lately."
[cpg cn=true]


Why would she tell her? Wait, was it then...?
[cpg]

Kanade was on her phone when we were together......
[cpg]

[OnName num="masato"]
"It's a misunderstanding.....please wait."
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Miki157"]
[OnName num="miki"]
"Fine. I've been waiting for so long already, what's a little longer? I'll wait until you come up with good reason for what you did."
[cpg cn=true]


It wasn't over yet, I still had a chance......
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


I headed straight to Kanade's place.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『メイドカフェ』（夜）******************************************************

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]

[OnName num="masato"]
"What are you trying to do, Kanade?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Kanade213"]
[OnName num="kanade"]
"What? You mean Miki?"
[cpg cn=true]


[OnName num="masato"]
"Yes! Why did you tell her?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Kanade214"]
[OnName num="kanade"]
"Well, that's obvious......If I didn't tell her, you'd just drag this out forever."
[cpg cn=true]


[OnName num="masato"]
"We have to get together tomorrow so you can tell Kanade it was all a joke."
[cpg cn=true]


Kanade seemed truly exasperated with me. I don't blame her.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kanade215"]
[OnName num="kanade"]
"Ugh......Fine, sure, whatever."
[cpg cn=true]


Kanade gives me a noncommittal response, but it was a huge deal to me.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）
;//【ＢＧ】『街』（夕方）******************************************************



The next day, the three of us were to scheduled to get together.
[cpg]

It was at my place. I had to clear up the misunderstanding here and now.
[cpg]

Technically it wasn't a misunderstanding, but I still had to convince Miki that it wasn't as bad as it seemed......
[cpg]

No matter how understanding Miki was, this could easily lead to the end of our relationship.
[cpg]


;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Miki158"]
[OnName num="miki"]
"......So, what kind of story did you come up with, Masato?"
[cpg cn=true]


[OnName num="masato"]
"It's not like that......Kanade will clear up the misunderstanding, not me. Right, Kanade?"
[cpg cn=true]



[FACE method="shake_2" pos="4/5"]
[VOICE f="Kanade216"]
[OnName num="kanade"]
"Uh, yeah. I'm sorry, Miki. That was all a lie."
[cpg cn=true]


Kanade follows the script.
[cpg]

[FACE method="bow_1" pos="4/5"]
[VOICE f="sKanade038"]
[OnName num="kanade"]
"I really just wanted to see you two take the next step instead of.....whatever it is you two have going right now."
[cpg cn=true]



[FACE method="shake_7" pos="4/5"]
[VOICE f="Kanade218"]
[OnName num="kanade"]
"It was irresponsible of me to scare you like that, I'm sorry...…"
[cpg cn=true]


That was the explanation I'd come up with. It was flimsy at best, but it was all I could come up with.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Miki159"]
[OnName num="miki"]
"Oh okay.....got it."
[cpg cn=true]


Miki looked unconvinced. I guess that was a given.
[cpg]

Maybe she knew I'd made Kanade lie for me.
[cpg]

But I also know that she wasn't going to pry any further.
[cpg]

I feel awful. I'm taking advantage of Miki's personality......
[cpg]

After a few moments of silence, Kanade continues.
[cpg]

[FACE method="shake_1" pos="4/5"]
[VOICE f="Kanade219"]
[OnName num="kanade"]
"Well, that's what Masato told me to say, but the truth is different."
[cpg cn=true]

[FACE method="shock_5" pos="2/5"]

[OnName num="masato"]
"Hey, hey!"
[cpg cn=true]


I shout in my surprise, but Kanade continues without changing her expression.
[cpg]

[FACE method="bow_2" pos="4/5"]
[VOICE f="sKanade039"]
[OnName num="kanade"]
"Masato came to meet me. I lost count of how many times he visited me at work and at home."
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Miki160"]
[OnName num="miki"]
"......"
[cpg cn=true]


Miki stays silent the entire time. She seemed to accept Kanade's version of the events.
[cpg]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Kanade221"]
[OnName num="kanade"]
"You know, the two of you are both equally scared of something, and I don't really know what it is."
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="sKanade040"]
[OnName num="kanade"]
"Look, I know what I did was wrong, but think of how much worse it would be if it were somebody else."
[cpg cn=true]


[OnName num="masato"]
"Stop! It was all a lie, can't we leave it at that?"
[cpg cn=true]


[FACE method="shake_3" pos="4/5"]
[VOICE f="sKanade041"]
[OnName num="kanade"]
"Is that okay with you, Miki? Is it really okay with you if Masato gets taken by someone else?"
[cpg cn=true]


Miki went silent for a moment, then takes a breath to compose herself.
[cpg]

[FACE method="bow_1" pos="2/5"]
[VOICE f="Miki161"]
[OnName num="miki"]
"I'm glad it was you, Kanade......Thank you."
[cpg cn=true]


She turns to me again.
[cpg]

[FACE method="bow_2" pos="4/5"]
[VOICE f="Kanade224"]
[OnName num="kanade"]
"I'm sure the two of you can work it out from here. I think I've done enough."
[cpg cn=true]



[SE f="se019"]
;//【ＳＥ】『ドア閉まる』
[FADEOUTBGM]
[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=1000]

She left Miki and I alone, together.
[cpg]

What happened next was up to us......
[cpg]

But what am I supposed to do...…? I don't want her to hate me, I'm scared, I can't help it...…
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="sMiki014"]
[OnName num="miki"]
"Hug me. Masato."
[cpg cn=true]


If I end up not being able to do anything here, I'd be lower than scum.
[cpg]

;//ブラックアウト

[OnName num="masato"]
"Okay."
[cpg cn=true]



;//========================================
;//●ＣＧ（ヒロインを抱きしめる主人公）ev_20
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]



[OnName num="masato"]
"......"
[cpg cn=true]


I've never been this close to her before.
[cpg]

[VOICE f="sMiki015"]
[OnName num="miki"]
"You can kiss me now, right?"
[cpg cn=true]


I nodded. I had to nod.
[cpg]

Human beings are capable of taking any action when they are being cornered.
[cpg]

[VOICE f="sMiki016"]
[OnName num="miki"]
"Don't look so torn......"
[cpg cn=true]


I mean, I wasn't exactly cornered......
[cpg]

I just have to follow my feelings.
[cpg]

I've always loved her, but I've never been able to show it......
[cpg]

;//移植のためシーンをカットしています

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

I kissed her for the first time.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************




[VOICE f="sMiki017"]
[OnName num="miki"]
"I'm happy. Masato."
[cpg cn=true]


She smiles as our lips part. I felt like it had been a while since I'd seen her smile like that.
[cpg]

I wondered if she still loved me, as messed up as I am.
[cpg]

I couldn't help but think that after I saw her face.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="sMiki018"]
[OnName num="miki"]
"I am grateful towards Kanade, but also you Masato."
[cpg cn=true]


[OnName num="masato"]
"Me...…?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sMiki019"]
[OnName num="miki"]
"I'm so glad you've finally worked up the courage. I've been waiting for so long."
[cpg cn=true]


[OnName num="masato"]
"Miki......I'm...…"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="sMiki020"]
[OnName num="miki"]
"For the longest time, all I could do was wait, so in a way I was the same as you."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMiki021"]
[OnName num="miki"]
"I'm glad you took the first step, Masato."
[cpg cn=true]


[OnName num="masato"]
"No. All of this was my fault. I'm sorry."
[cpg cn=true]


[OnName num="masato"]
"From now on, we have make up for lost time."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]

Is it possible to do that? No, this wasn't the time to have doubts.
[cpg]

I'm going to love Miki. I thought I could do that now.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

……Some time passes.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


Our relationship was strangely stable.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMiki022"]
[OnName num="miki"]
"I'm going to become even more attractive. I'm going to make you want to do even more amazing things."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sMiki023"]
[OnName num="miki"]
"I don't want you to look at anybody but me...…"
[cpg cn=true]


Kanade has since stopped trying to intervene.
[cpg]

We've taken quite a detour to get here.
[cpg]

But now I think I can say that it was all for the best.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト


I am sure our love has taken a step forward.
[cpg]


[SCENE id=12]
;//ＥＮＤ：ヒロイン２ルート１

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

