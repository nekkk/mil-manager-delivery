
*start|What was the goal?

;//==============================
;//変数Ａが３　変数Ｂが１以上
*goflgA3B1|What was the goal?




I have no choice but to love Miki now.
[cpg]

To come this far and not satisfy her feelings would be betraying her.
[cpg]

With this thought, I went back to my house.
[cpg]

;//ブラックアウト

When I went to bed, my thoughts did not change.
[cpg]

It seems that I loved her even more than I'd thought.
[cpg]

;#################################################
*Ep008|What was the goal?
;#################################################

[SCENE id=8]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


In the morning, I think about Miki.
[cpg]

I made her wait for half a year. I don't think most girls would have forgiven me for that.
[cpg]


;//ブラックアウト


With that thought in mind, I headed off to the university.
[cpg]

[SE f=se001]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（朝）******************************************************


Then, at noon I made my move.


[OnName num="masato"]
"Do you have some time after today's lecture...…?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Miki270"]
[OnName num="miki"]
"Yeah, but what are we going to do?"
[cpg cn=true]


I guess she can't imagine me being the one to pursue her.
[cpg]

That's okay. We can talk about it when we actually meet up.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se010"]
;//【ＳＥ】『家のチャイム』

[WAIT time=2000]

[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ka"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


I invited Miki to my room and told her everything.
[cpg]

No, not everything......I confided in her without telling her about Kanade.
[cpg]

[OnName num="masato"]
"Miki. I'm ready."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Miki271"]
[OnName num="miki"]
".....You say that, but I bet you're just going to stop halfway again, aren't you?"
[cpg cn=true]


[OnName num="masato"]
"Not this time."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Miki272"]
[OnName num="miki"]
"Are you serious? It's so sudden, I don't know if I'm ready."
[cpg cn=true]


I couldn't stop myself even though I heard her say that she wasn't ready.
[cpg]

I probably could have if I wanted to......
[cpg]

But I was so overcome with regret for keeping Miki waiting so long.
[cpg]

;//ブラックアウト


[FACE method="bow_4" pos="2/3"]
[VOICE f="Miki273"]
[OnName num="miki"]
"Wait.....just give me a moment."
[cpg cn=true]

Miki takes a deep breath to calm herself.
[cpg]

I take the opportunity to collect myself in the meantime, but......
[cpg]

After I'd calmed down a bit, I started to come to my senses.
[cpg]

I needed momentum to get past my anxieties, I couldn't give myself time to think.
[cpg]

;//========================================
;//●ＣＧ（ベッドで主人公のキスを待つヒロイン）ev_28
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

I put my lips onto hers as she lay there.
[cpg]

[VOICE f="sMiki034"]
[OnName num="miki"]
"……"
[cpg cn=true]


She looked awfully nervous even though this was supposed to be what she'd been waiting for all this time.
[cpg]

I thought she was cute.
[cpg]

Then our lips touch.
[cpg]

It's the first time. No matter how thrilled I am, it's never enough.
[cpg]

You only get to experience the feeling of a first kiss once.
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト

When we parted our lips, she looked like overwhelmed.
[cpg]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="sMiki035"]
[OnName num="miki"]
"Masato...…was this really your first time?"
[cpg cn=true]


[OnName num="masato"]
"Uh, yeah. It was my first time, did I do something wrong?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Miki294"]
[OnName num="miki"]
"I don't know, you seem strangely good at it......Are all boys like this?"
[cpg cn=true]


I couldn't explain myself.
[cpg]

[OnName num="masato"]
"Well, don't worry about that. More importantly......."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Miki296"]
[OnName num="miki"]
"How about a little bit more?"
[cpg cn=true]


Miki said so and leaned in close to me.
[cpg]

We've never been able to do these things before.
[cpg]

Normal lovers do it but we couldn't......
[cpg]

I felt relaxed for the first time in a while. I was happy.
[cpg]

;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


We flirted for a while longer. Miki was very, very proactive.
[cpg]

I didn't know that she was that type of girl, but I thought she was cute.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Miki316"]
[OnName num="miki"]
"I'm sorry.......I couldn't hold back anymore."
[cpg cn=true]


[OnName num="masato"]
"What do you mean......?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="sMiki036"]
[OnName num="miki"]
"I felt so lonely, but I couldn't......do it until you came to me first."
[cpg cn=true]


[OnName num="masato"]
"......Sorry I kept you waiting."
[cpg cn=true]


I was just relieved that things were going well.
[cpg]

We'd taken another step in our relationship. I guess this happiness will continue for a while.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



[FACE method="bow_2" pos="2/3"]
[VOICE f="Miki318"]
[OnName num="miki"]
"See you later, Masato."
[cpg cn=true]


[OnName num="masato"]
"Yeah. See you...…."
[cpg cn=true]


[window target=false]
[free time=800]
[WAIT time=2000]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I was in a daze for a while. This was all thanks to Kanade."
[cpg]

I wanted to thank her, but that would mean meeting her again in secret.
[cpg]

But I thought that was okay, too.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


On another night. I don't know what came over me.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sKanade058"]
[OnName num="kanade"]
"You must really like coming here. I thought you and Miki were getting along."
[cpg cn=true]


Kanade seemed annoyed. I felt the same way about myself.
[cpg]

[OnName num="masato"]
"Yeah...…I just wanted to thank you."
[cpg cn=true]

That was just an excuse. I am sure Kanade can see that it is a lie.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="sKanade059"]
[OnName num="kanade"]
"You could do that over the phone. Why come all the way here?"
[cpg cn=true]

I didn't have a good answer.
[cpg]

[OnName num="masato"]
"That's......well, yes."
[cpg cn=true]


But Kanade is also an important person to me.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kanade323"]
[OnName num="kanade"]
"Do you feel that? Is someone watching us?"
[cpg cn=true]


[OnName num="masato"]
"No, I don't think so?"
[cpg cn=true]


Kanade waves me off and heads home.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
;//[VOICE f="Miki319"]
;//[OnName num="miki"]
;//「……」
;//[cpg cn=true]


Miki and I were finally together.
[cpg]

That meant there was no longer a need to see Kanade any more.
[cpg]

But I felt a little sad to part with Kanade like this.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Kanade325"]
[OnName num="kanade"]
"......I swear someone's watching me. Is it just my imagination?"
[cpg cn=true]


[OnName num="masato"]
"What, do you think someone was following us the whole time or something?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Kanade326"]
[OnName num="kanade"]
"I guess it's unlikely, never mind."
[cpg cn=true]


After that conversation, we parted.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


It happened when I got home.
[cpg]

[SE f="se005"]
;//【ＳＥ】『携帯電話の着信音』
[WAIT time=1500]


[OnName num="masato"]
"What...…? Miki?"
[cpg cn=true]


Miki was calling me.
[cpg]

I was nervous. Could it be Miki who was spying on us?
[cpg]

If so, it would be unnatural for me not to answer the call right now...….
[cpg]

[SE f="se034"]
;//【ＳＥ】『携帯電話のボタン音』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]



[VOICE f="Miki320"]
[OnName num="miki"]
"......Hello?"
[cpg cn=true]


[OnName num="masato"]
"It's me. What's up......?"
[cpg cn=true]



[VOICE f="sMiki037"]
[OnName num="miki"]
"I didn't know. I thought you were pretty confident despite it being your first time."
[cpg cn=true]

[OnName num="masato"]
"What are you talking about?"
[cpg cn=true]



[VOICE f="sMiki038"]
[OnName num="miki"]
"But I finally figured it out. You were practicing with Kanade, weren't you?"
[cpg cn=true]


A cold sweat runs down my back. She knew everything.
[cpg]

I'd only practiced with Kanade to make sure things went smoothly with Miki.
[cpg]

If she found out, everything I'd done would be for nothing.
[cpg]

[VOICE f="Miki323"]
[OnName num="miki"]
"Say something...…Tell me it's not true, Masato."
[cpg cn=true]


[OnName num="masato"]
"......Well, that's...…"
[cpg cn=true]


What good would lying to her do?
[cpg]

She says she wants me to lie, but does she mean it?
[cpg]

If I lie to her now, I'd just hurt her even more......
[cpg]

[VOICE f="Miki324"]
[OnName num="miki"]
"......I guess we're over. I can't be with you like this."
[cpg cn=true]



[VOICE f="Miki325"]
[OnName num="miki"]
"I'm so jealous that I can hardly think straight."
[cpg cn=true]


[OnName num="masato"]
"Oh, no....…"
[cpg cn=true]



[VOICE f="Miki326"]
[OnName num="miki"]
"I'm hanging up.......Bye."
[cpg cn=true]




[SE f="se035"]
;//【ＳＥ】『携帯電話の通話終了音』

[free time=1000]
[WAIT time=1000]


My cell phone beeps to let me know she's hung up.
[cpg]

So it was all over. I felt the energy drain from my body.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（昼）******************************************************


From then on, Miki started avoiding me. Our relationship was in shambles.
[cpg]

[OnName num="masato"]
"Hey, Miki...…"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Miki327"]
[OnName num="miki"]
"……."
[cpg cn=true]


I'd try to greet her, but she would walk right past me.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩き』

[free time=1000]
[WAIT time=1000]

[OnName num="male_student_A"]
"She finally dumped him……"
[cpg cn=true]


[OnName num="male_student_B"]
"I heard he screwed up a date or something."
[cpg cn=true]


I hear people whispering about us. Unfortunately, we'd had a great time on that date.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（夕方）******************************************************


I guess Kanade was all I had left.
[cpg]

Was it the right choice? I didn't know.
[cpg]

I'd be betraying Miki, but......did it matter anymore?
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


While thinking to myself, I bumped into Mrs. Yayoi on the street.
[cpg]

[OnName num="masato"]
"Are you shopping Mrs. Yayoi?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yayoi061"]
[OnName num="yayoi"]
"Oh, Masato. Yes……what's wrong? You look very pale."
[cpg cn=true]


[OnName num="masato"]
"Well, a lot has been going on...…."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Yayoi062"]
[OnName num="yayoi"]
"Miki hasn't been well lately either, it's as if you two had a fight."
[cpg cn=true]


That's exactly right, but then she continued...
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Yayoi063"]
[OnName num="yayoi"]
"Miki should just come clean and say that she still loves you."
[cpg cn=true]


[OnName num="masato"]
".....Miki said that?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yayoi064"]
[OnName num="yayoi"]
"She sure did. Masato, why don't you try to be a little more honest too?"
[cpg cn=true]


Maybe she was right. Maybe we could still start over...…I had to apologize.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


On the weekend. During the daytime, I went to Miki's house.
[cpg]

[window target=false]
[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Miki328"]
[OnName num="miki"]
"......"
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


Miki let me into her room, I guess that was a good start.
[cpg]

Now it's just a matter of how I'm going to start the conversation......
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="sMiki039"]
[OnName num="miki"]
"How many times did you meet with Kanade?"
[cpg cn=true]


[OnName num="masato"]
"Well......it's...…"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sMiki040"]
[OnName num="miki"]
"So many times that you lost count? Do you love her? Was I not enough for you?"
[cpg cn=true]


[OnName num="masato"]
"......I'm sorry. I'm really sorry. It's not like that, I could only ever love you, Miki."
[cpg cn=true]


[OnName num="masato"]
"I didn't want to screw up our relationship so I asked Kanade to help me...…."
[cpg cn=true]


[OnName num="masato"]
"That's all...…."
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Miki331"]
[OnName num="miki"]
"......I understand what you're trying to say. But there are lines you don't cross."
[cpg cn=true]


I'd crossed the line. She was breaking up with me, wasn't she?
[cpg]

I struggle to hold back the tears as I sit there and listen to her.
[cpg]

;//ブラックアウト


She stands up and approaches me. I braced myself to be hit, at the very least......
[cpg]

;//========================================
;//●ＣＧ（座り込んでいるヒロイン。背景が変わっています）ev_30
;//人物１：ヒロイン１
;//服装１：私服
;//場所　：ヒロイン１の部屋
;//時間　：昼
;//========================================

;//[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


She sits down on the floor as if she'd lost all of her strength.
[cpg]

[VOICE f="sMiki041"]
[OnName num="miki"]
"......What am I supposed to do?"
[cpg cn=true]


[VOICE f="sMiki042"]
[OnName num="miki"]
"I shouldn't apologize to you...…but that's how I feel."
[cpg cn=true]


I thought she was going to dump me, but the truth of the matter was far graver.
[cpg]

......I'd robbed her of her confidence.
[cpg]

Some part of me had known that I was putting her under extreme stress, but I'd never seen the effect of my actions play out like this in front of me.
[cpg]

[OnName num="masato"]
"......"
[cpg cn=true]


I'd lost my words. Whenever I feel like I have to say something, the same words would always come out.
[cpg]

;//移植のためシーンをカットしています
;//
;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[window target=true]
;//ブラックアウト

[OnName num="masato"]
"......Sorry."
[cpg cn=true]


It seems that I've gotten a little too used to apologizing.
[cpg]

This wasn't nearly enough. I move closer to her and hold her.
[cpg]

I didn't do it to fix the situation, but I wanted to prove that I wasn't a coward anymore.
[cpg]

;//移植のためシーンをカットしています

;//[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMiki043"]
[OnName num="miki"]
"Do you really love me?"
[cpg cn=true]


[OnName num="masato"]
"Of course I do. I think you know that too."
[cpg cn=true]


;//[FACE method="change_1" pos="2/3"]
[VOICE f="sMiki044"]
[OnName num="miki"]
"......I love you too."
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I don't think she forgave me just yet, but we were able to confirm our feelings for each other.
[cpg]

In some way, we'd made progress in our relationship.
[cpg]

Of course, everything's clearer in hindsight.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


[FACE method="change_1" pos="2/3"]
[VOICE f="sMiki045"]
[OnName num="miki"]
"Hey Masato, what shall we do for lunch?"
[cpg cn=true]


We were still together. Or rather, we were still lovers.
[cpg]

[OnName num="masato"]
"Anything is okay. I don't care where as long as it's with you, Miki."
[cpg cn=true]


[OnName num="male_student_A"]
"......Masato is so annoying."
[cpg cn=true]


[OnName num="male_student_B"]
"Yeah, screw that guy. I'm so jealous......."
[cpg cn=true]


Fools, their jealousy only feeds my ego.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（夕方）******************************************************


I think Miki and I are closer than ever before.
[cpg]

There an expression that goes something like "when it rains, the ground hardens." It felt like a good way to describe our relationship.
[cpg]

We'd almost broken up, but now our bond was even tighter.
[cpg]

We meet up again after our lectures.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miki383"]
[OnName num="miki"]
"I'm sorry. Did you wait for me?"
[cpg cn=true]


[OnName num="masato"]
"Of course not, we got out at the same time."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Miki384"]
[OnName num="miki"]
"Ahaha, you're right. Let's go?."
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

The two of us walk through the city in the evening. It feels natural to hold hands now.
[cpg]

Not too long ago, I would have hesitated to even touch her.
[cpg]

Miki had put up with a lot.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト


I should be more honest with her. Looking back, Miki had always been honest about her feelings from the very beginning.
[cpg]

I had to make up for the past six months.
[cpg]

;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


We'd taken a bit of a detour, but now we were closer than ever.
[cpg]

I think our relationship has deepened and our bond has become stronger than before.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Miki404"]
[OnName num="miki"]
"It's getting pretty late......I guess dad's going to scold me again."
[cpg cn=true]


[OnName num="masato"]
"Yeah......Mrs. Yayoi doesn't seem like the type to scold you at all, so I guess your dad had to pick up the slack."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Miki405"]
[OnName num="miki"]
"Will you come with me? Let's get scolded together."
[cpg cn=true]


[OnName num="masato"]
"Uhh...…I'll have to think about that...…."
[cpg cn=true]


If I went with her, I get the feeling that I'd be the only one getting scolded that night.
[cpg]

We took it one day at a time.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]

Rather, each day was strangely fulfilling and memorable.
[cpg]

I never thought I'd feel so comfortable outside of my routine.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（昼）******************************************************


[OnName num="masato"]
"Oh, Miki...…were you waiting for me?"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miki406"]
[OnName num="miki"]
"Yes. Let's go to the cafeteria, Masato."
[cpg cn=true]


[OnName num="masato"]
"Sure, but don't you have a lecture to attend?"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Miki407"]
[OnName num="miki"]
"It's fine, I'm in the mood to show off today."
[cpg cn=true]


We were so in love that I felt like we might be breaking some rules or something.
[cpg]

We'll probably always be like this.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Miki408"]
[OnName num="miki"]
"I'm going to hang out with Kanade after class, do you want to come too?"
[cpg cn=true]


[OnName num="masato"]
"Are you sure that you're okay with that?"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Miki409"]
[OnName num="miki"]
"It's okay now. You seem to have reflected on what you did."
[cpg cn=true]


Although I thought it was going to be awkward......I decided to tag along.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]

We meet up again after our lectures.
[cpg]

I thought it would be an awkward reunion, but it seems I was wrong.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Kanade327"]
[OnName num="kanade"]
"I'm happy for you. You guys seem to get along better than before."
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Miki410"]
[OnName num="miki"]
"What do you mean ‘seem'? We are getting along better. Right, Masato?"
[cpg cn=true]


[OnName num="masato"]
"Oh, yeah...…"
[cpg cn=true]


I'd always thought that women had complex relationship with each other, but these two seemed okay with each other.
[cpg]

Then again, they'd been friends for a long time.
[cpg]

;//========================================
;//●ＣＧ（歩きながら主人公にくっついているヒロイン１。嬉しそうな表情。ヒロイン２は少し後ろを歩いている）ev_33
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//人物３：主人公
;//服装３：私服
;//場所　：街
;//時間　：夕方
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]



[VOICE f="sKanade060"]
[OnName num="kanade"]
"It took you six months to even kiss, right? That's rare nowadays."
[cpg cn=true]


Miki clings to my arm as if to show off.
[cpg]

[VOICE f="Miki411"]
[OnName num="miki"]
"Yeah, but we're past all that."
[cpg cn=true]


She seems to be saying that Kanade has no chance with me.
[cpg]

I guess she likes me that much.
[cpg]

What more could I ask of her......
[cpg]

We were finding our way through life, but we were doing it together now.
[cpg]

Looking back, I'd been so obsessed about the most trivial things.
[cpg]

Marriage is the goal, living together is the goal, and so on.
[cpg]

It's up to us to decide where the goal is. And until we decide, we can continue to deepen our relationship.
[cpg]

;//ブラックアウト


[SCENE id=14]
;//ＥＮＤ：ヒロイン１ルート１


[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

