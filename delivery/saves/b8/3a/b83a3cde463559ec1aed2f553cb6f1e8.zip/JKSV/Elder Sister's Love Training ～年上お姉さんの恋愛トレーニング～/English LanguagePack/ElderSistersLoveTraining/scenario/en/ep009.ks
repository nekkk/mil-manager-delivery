
*start|I am attracted to Mrs. Yayoi

;//==============================
;//変数Ｃが２
*goflgC2|I am attracted to Mrs. Yayoi




……I'm attracted to Mrs. Yayoi. I wanted to be more intimate with her.
[cpg]

Of course, it is a sin just to think about such a thing. No normal man would even think about it.
[cpg]

But I was attracted to her.
[cpg]

It was taboo, but I couldn't stop thinking about her.
[cpg]

I had to ask myself who I really loved.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


A lot happened today. I fall asleep, exhausted.
[cpg]

......Miki is my girlfriend. I know when she has lectures scheduled.
[cpg]

It wouldn't be that difficult to go see Mrs. Yayoi while Miki was out.
[cpg]

;#################################################
*Ep009|I am attracted to Mrs. Yayoi
;#################################################

[SCENE id=9]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


I wake up, and try to formulate a plan as I head to the university.
[cpg]

If, for some reason, something were to happen with Mrs. Yayoi, it would just be practice. It's the same as what I did with Kanade.
[cpg]

It's just training to improve my relationship with Miki...…
[cpg]

With this in mind, I made plans to leave in the middle of the lecture.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（昼）******************************************************


[FACE method="change_1" pos="2/3"]
[VOICE f="Yayoi065"]
[OnName num="yayoi"]
"Oh Masato......I'm glad you came."
[cpg cn=true]


Mrs. Yayoi is no longer surprised. It's as if she knew I was coming.
[cpg]

I wouldn't be surprised...….she'd made it clear that she was seducing me.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Yayoi066"]
[OnName num="yayoi"]
"What are you doing here at this hour? Don't you have classes to attend?"
[cpg cn=true]


[OnName num="masato"]
"......You already know why."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Yayoi067"]
[OnName num="yayoi"]
"Yes, but I still want to hear you say it."
[cpg cn=true]


She got something out of teasing me. I guess she was showing her true personality now......
[cpg]

It couldn't be helped, this was necessary......I was doing this for Miki's sake.
[cpg]

[OnName num="masato"]
"I've been thinking about you a lot lately."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yayoi068"]
[OnName num="yayoi"]
"I like it when you're honest...…but this is for Miki's sake, right?"
[cpg cn=true]


She makes it clear what this was all about. I nodded.
[cpg]

All of this was just so Miki and I could take our relationship to the next level.
[cpg]

This was how it had to be, or I'd be betraying Miki.
[cpg]

[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト






[FACE method="bow_1" pos="2/3"]
[VOICE f="sYayoi006"]
[OnName num="yayoi"]
"Come in."
[cpg cn=true]


She invites me into her room.
[cpg]

;//移植のためシーンをカットしています

[FACE method="change_2" pos="2/3"]
[VOICE f="sYayoi007"]
[OnName num="yayoi"]
"Then let's start by practicing kissing....."
[cpg cn=true]


If we were starting with kissing, how far did she intend to go?
[cpg]

What did Mrs. Yayoi get out of all this, anyways?
[cpg]

The situation was almost like she was competing with her own daughter.
[cpg]

;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（昼）******************************************************


I noticed that quite a bit of time had passed.
[cpg]

Miki will come back soon, I couldn't risk running into her at home.
[cpg]

I decided to go home before Miki arrived.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yayoi108"]
[OnName num="yayoi"]
"I'll be here if you ever feel like you need more.....practice."
[cpg cn=true]


Mrs. Yayoi must feel something for me.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（夕方）******************************************************


I think I could still make it back in time to catch one of my lectures, so I headed back to the university.
[cpg]

I met up with Miki later and we talked for a bit.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Miki412"]
[OnName num="miki"]
"I'm going to hang out with Kanade today......do you want to tag along?"
[cpg cn=true]


[OnName num="masato"]
"Yeah, sure."
[cpg cn=true]


I reply, but I was really thinking about Mrs. Yayoi.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[VOICE f="Kanade329"]
[OnName num="kanade"]
"Did something about you change, Masato?"
[cpg cn=true]


[OnName num="masato"]
"I don't......think so."
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="sKanade061"]
[OnName num="kanade"]
"Oh, something happened, huh? Let me guess..."
[cpg cn=true]


[FACE method="shake_6" pos="2/5"]
[VOICE f="sMiki046"]
[OnName num="miki"]
"Don't be like that, we didn't do anything yet."
[cpg cn=true]


Kanade is very perceptive. How did she know?
[cpg]

But Miki, on the other hand, seemed unaware. I guess it would be a big problem if she found out somehow......
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


We had dinner, talked about some unimportant things, and parted ways.
[cpg]

As we said goodbye......
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sKanade062"]
[OnName num="kanade"]
"Hey, are you practicing with someone else?"
[cpg cn=true]


She suspected me.
[cpg]

[OnName num="masato"]
"Er......."
[cpg cn=true]


[free time=500]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Miki414"]
[OnName num="miki"]
"What are you talking about, Kanade?"
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Kanade332"]
[OnName num="kanade"]
"It's nothing, don't worry about it. See ya."
[cpg cn=true]


This was bad. Really bad. Miki might find out.
[cpg]

That would be the end of us, Miki would be beyond angry.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I understand that, but...…I can't control my impulses.
[cpg]

I was surprised at myself for having such an honest side to myself.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿リビング』（昼）******************************************************


Unlike when I'm with Miki, for some reason, I'm not afraid to be around Mrs. Yayoi.
[cpg]

I think I'm losing my mind. But I can't stop......
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Yayoi109"]
[OnName num="yayoi"]
"Masato? This is just practice. You know that, right...?"
[cpg cn=true]


Mrs. Yayoi makes sure I have my priorities straight.
[cpg]

[OnName num="masato"]
".......Yeah."
[cpg cn=true]


I was beginning to lose sight of my original goal of progressing my relationship with Miki.
[cpg]

I'm sure Mrs. Yayoi knows what's happening, even though she says otherwise...…
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Yayoi110"]
[OnName num="yayoi"]
"......If you're thinking about leaving Miki because you want to be with me, then that's a different story."
[cpg cn=true]


[OnName num="masato"]
"No! I wasn't thinking that, I swear...…"
[cpg cn=true]


Wasn't I? At this very moment I was longing for Mrs. Yayoi.....
[cpg]

What am I going to do?
[cpg]

[window target=false]
[free time=1000]
[BG f="b_09_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//ブラックアウト


Mrs. Yayoi, perhaps seeing through all my struggles, took me up to her room.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Yayoi111"]
[OnName num="yayoi"]
"I guess you can't help it......You'd better take good care of Miki, alright?"
[cpg cn=true]


[OnName num="masato"]
"Yes, I promise...…"
[cpg cn=true]


I felt like I was trying to cover something up.
[cpg]

;//移植のためシーンをカットしています

[FADEOUTBGM]
[free time=500]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[WAIT time=1000]

We drew closer, ever closer, until our lips touched.
[cpg]

;//移植のためシーンをカットしています

[SE f="se019"]
;//【ＳＥ】『ドア閉まる』
[WAIT time=1000]

;//ブラックアウト

That's when I felt the gaze of somebody else.....
[cpg]

[free time=500]
[FG f="CHA01_p1_02_a.ui" method="change_5"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="4/5" time=800]
[WAIT time=1500]

[VOICE f="Miki415"]
[OnName num="miki"]
"......Mom...…Is this some kind of sick joke?"
[cpg cn=true]


I quickly pull away from Mrs. Yayoi and turn to see Miki standing in the doorway.
[cpg]

[OnName num="masato"]
"No, wait, it's not what you think...…!"
[cpg cn=true]

[FO pos="2/5" time=1000]

Miki took a few steps back and left.
[cpg]

Mrs. Yayoi seemed speechless as well.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



[OnName num="masato"]
"Wait, Miki......please."
[cpg cn=true]


I called out to her, quickly realized that I had no excuse.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sMiki047"]
[OnName num="miki"]
"I get it now......Masato.....you were after my mother this whole time. That's why you didn't care about me."
[cpg cn=true]


[OnName num="masato"]
"No.....I mean.....what about your lecture?"
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Miki417"]
[OnName num="miki"]
"I wasn't feeling well, so I left early. That doesn't matter now, does it?"
[cpg cn=true]


It doesn't. There's something I need to talk to her about right now.
[cpg]

[OnName num="masato"]
"I was afraid to......do it with you, Miki, so I asked Mrs. Yayoi to help me practice!"
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Miki418"]
[OnName num="miki"]
"Don't call her Mrs. Yayoi! It's disgusting, how can you look at my mother like that?"
[cpg cn=true]


She had every right to be furious.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Miki419"]
[OnName num="miki"]
"I can't be with you anymore.."
[cpg cn=true]


[OnName num="masato"]
"Miki...…"
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Miki420"]
[OnName num="miki"]
"Goodbye. Don't ever show your face to me again."
[cpg cn=true]


Miki walks away from me.
[cpg]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


Could the situation be any worse?
[cpg]

So much for practicing, I'd just been dumped.
[cpg]

I should head to Kanade's place or something......Maybe she could distract me from this overpowering sense of loneliness...…
[cpg]

But no. That won't change anything.
[cpg]

I was at a loss.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I went back home and spent my time in a daze.
[cpg]

I feel like I lost everything important at once. It's not that I feel like I've lost it, but I actually have.
[cpg]

I felt hopeless. There was nothing I could do...…
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************


I skipped my lectures and stayed in my room.
[cpg]

I felt like I was being crushed. What was the point?
[cpg]

I wanted a reason to keep living, but I couldn't find one.
[cpg]

As I was on the verge of losing hope, I hear a voice at the door.
[cpg]

[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

[WAIT time=2000]


;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yayoi155"]
[OnName num="yayoi"]
"Masato...…? It's me, Yayoi."
[cpg cn=true]


[OnName num="masato"]
"......Mrs. Yayoi."
[cpg cn=true]




[SE f="se019"]
;//【ＳＥ】『ドア開く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yayoi156"]
[OnName num="yayoi"]
"I'm really sorry that this happened......"
[cpg cn=true]


[OnName num="masato"]
"……It's not something you have to apologize for."
[cpg cn=true]


It was my fault. I didn't want her to worry about me.
[cpg]

[OnName num="masato"]
"If only I'd been able to love Miki like she deserved...…"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yayoi157"]
[OnName num="yayoi"]
"No, I was the one who seduced you."
[cpg cn=true]


;//========================================
;//●ＣＧエロ（ヒロインはベットで横になり主人公を誘っている。毛布などは無い状態）ev_39
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_39_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]

She lies down on the bed and reaches for me.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Yayoi158"]
[OnName num="yayoi"]
"It's all my fault, so at least let me make amends."
[cpg cn=true]


......I felt a sense of overpowering solitude.
[cpg]

Taking her hand seemed like it would solve everything...but no.
[cpg]

She has a family. She has a daughter and a husband.
[cpg]

No matter how desperate I was, I couldn't let myself fall for her......
[cpg]

Even though I knew that, I had no choice but to cling to her and the salvation she offered me.
[cpg]

;//ブラックアウト
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]


;//========================================
;//●ＣＧ（二人寄り添って寝ている。毛布などは無い状態で、ラブラブな感じ）ev_40
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================


[BGM f="bg_op"]
;**【ＣＧ】 ev_40_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


This love could never come to fruition.
[cpg]

I was crazy about Mrs. Yayoi, that was for sure.
[cpg]

[OnName num="masato"]
"What shall we do......now?"
[cpg cn=true]



[VOICE f="Yayoi200"]
[OnName num="yayoi"]
"The truth is.....I don't really know either."
[cpg cn=true]


I'm sure she didn't. Mrs. Yayoi must have also acted on impulse.
[cpg]

But I was beginning to love her...…
[cpg]

If this kept up, I'd be travelling down the thorny path of forbidden love.
[cpg]

I wonder what will happen to Miki, I used to love her.
[cpg]

Or do I still love her......? I don't know anymore.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[SE f="se005"]
;//【ＳＥ】『携帯電話の着信音』

[WAIT time=2000]


My cell phone rings as I'm trying to figure out what it was that I'm feeling.
[cpg]

[SE f="se034"]
;//【ＳＥ】『携帯電話のボタン音』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[OnName num="masato"]
"......Hello?"
[cpg cn=true]



[VOICE f="Miki421"]
[OnName num="miki"]
"......I'm sorry about the other day. I was a little surprised."
[cpg cn=true]


A chill ran down my spine. I didn't think it was possible, but......
[cpg]

[VOICE f="Miki422"]
[OnName num="miki"]
"I still like you Masato.......What should I do?"
[cpg cn=true]


[OnName num="masato"]
"But...…"
[cpg cn=true]


Don't say it. Please, don't say it...…!
[cpg]

[VOICE f="Miki423"]
[OnName num="miki"]
"I still think we can start over."
[cpg cn=true]


[OnName num="masato"]
"……"
[cpg cn=true]


I'd been given another chance. The decision was mine.
[cpg]

Mrs. Yayoi-san is very considerate and stays silent the whole time.
[cpg]

What should I do? Could I pursue Mrs. Yayoi? Or will I try to get back together with Miki?
[cpg]

[free time=1000]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]
[WAIT time=2000]
;//ブラックアウト


......I have no other choice but to get back together with Miki. But I'd fallen in love with her mother.
[cpg]

It was a sin I'd have to bear for the rest of my life.
[cpg]

I will probably continue to be Miki's lover...…and fall in love all over again with her mother every time we meet.
[cpg]

[SCENE id=15]
;//ＥＮＤ：ヒロイン３ルート

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

