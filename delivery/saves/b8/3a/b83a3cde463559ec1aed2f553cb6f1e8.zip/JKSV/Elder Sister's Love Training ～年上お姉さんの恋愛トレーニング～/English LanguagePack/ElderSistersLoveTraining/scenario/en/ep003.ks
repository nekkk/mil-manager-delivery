
*start|Mrs. Yayoi's Joke

;#################################################
*Ep003|Mrs. Yayoi's Joke
;#################################################

[SCENE id=3]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

That weekend.
[cpg]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

[free time=800]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=1500]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Miki069"]
[OnName num="miki"]
"I think we're running out of date spots..."
[cpg cn=true]


[OnName num="masato"]
"Yeah......I think we'll have to start looking at day trips from here on out."
[cpg cn=true]

[FADEOUTBGM]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sMiki006"]
[OnName num="miki"]
"Well that sounds like fun, but...wouldn't you rather come to my place?'
[cpg cn=true]


I turned back and looked at Miki.
[cpg]

[BGM f="bg_ka"]
[WAIT time=100]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Miki071"]
[OnName num="miki"]
"My parents are both out today. There are a lot of things you want to do.....aren't there?"
[cpg cn=true]


Yeah, there are. I wanted to do lots of things with her. But I can't.
[cpg]

I'm afraid. I've often wondered what I would do if Miki gave up on me.
[cpg]

But maybe this was a good chance to test what Kanade had taught me.......
[cpg]


;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

That said, she hadn't really taught me much.
[cpg]

Kanade was only there to help me get used to being close to Miki.
[cpg]

But I felt like it was wrong of me to see her when I had a girlfriend.
[cpg]

[SE f="se019"]
;//【ＳＥ】『ドア開く』



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（昼）******************************************************


[OnName num="masato"]
"Thank you for inviting me."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Miki072"]
[OnName num="miki"]
"Haha. There's nobody here but us."
[cpg cn=true]


Right, it was just the two of us.
[cpg]

Of course I knew where Miki's room was, but I let her lead me in.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************


Miki's room is always well-kept and clean.
[cpg]

[OnName num="masato"]
"Are these pictures new?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Miki073"]
[OnName num="miki"]
"Yeah. Photography is my hobby."
[cpg cn=true]


She's the type to try and capture the whole scene in her frame, rather than focus on a single subject.
[cpg]

It's a very girly and cute hobby.
[cpg]

;//移植のためシーンをカットしています



[FACE method="change_1" pos="2/3"]
[VOICE f="sMiki007"]
[OnName num="miki"]
"I'd like to take more pictures of us."
[cpg cn=true]


[OnName num="masato"]
"Come to think of it, you don't have any pictures of the two of us on display."
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="sMiki008"]
[OnName num="miki"]
"It's a little embarrassing."
[cpg cn=true]


That made sense, she was living with her parents, so they'd naturally see the photos of us together.
[cpg]

[OnName num="masato"]
"Why don't we take one now?"
[cpg cn=true]


I had the courage to say so.
[cpg]

[FACE method="bow_6" pos="2/3"]

She nodded and looked a little embarrassed...…
[cpg]

;//ブラックアウト

[OnName num="masato"]
"Phone cameras have come a long way."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sMiki009"]
[OnName num="miki"]
"What do you mean......?"
[cpg cn=true]


I'd heard that cell phones these days could take pictures that rivaled mediocre cameras.
[cpg]

[free time=300]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

I leaned closer to Miki, who was holding the camera.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト

;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[VOICE f="Yayoi007"]
[OnName num="yayoi"]
"I'm home. Is Masato here too?"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

I heard Mrs. Yayoi's voice. We panicked as quietly as possible.
[cpg]

;//慌てて服を整えて、先に美樹がこう言った。
I quickly moved away from her and then Miki calls out to her mother.
[cpg]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=500]
[WAIT time=500]

[VOICE f="Miki115"]
[OnName num="miki"]
"He's here! Hold on!"
[cpg cn=true]


;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yayoi008"]
[OnName num="yayoi"]
"Ahaha, okay okay."
[cpg cn=true]



Mrs. Yayoi might have guessed what was going on......
[cpg]

[SE f="se019"]
;//【ＳＥ】『ドア開く』
[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[WAIT time=1000]

But then the door opened suddenly and she walked in!
[cpg]

[FACE method="shock_5" pos="2/5"]
[VOICE f="Miki116"]
[OnName num="miki"]
"Wha-why did you open the door?"
[cpg cn=true]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Yayoi009"]
[OnName num="yayoi"]
"To bring you some refreshments, of course."
[cpg cn=true]


True to her word, she'd brought us tea.
[cpg]

[FACE method="bow_2" pos="4/5"]
[VOICE f="Yayoi010"]
[OnName num="yayoi"]
"So, what were you two doing?"
[cpg cn=true]


[FACE method="shock_3" pos="2/5"]
[VOICE f="Miki117"]
[OnName num="miki"]
"Wait, we can't have tea without sweets! I'll go buy some!"
[cpg cn=true]



[FO pos="2/5" time=500]

Miki felt too awkward and left in a hurry.
[cpg]

Mrs. Yayoi was clearly teasing us.
[cpg]

[free time=500]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Yayoi011"]
[OnName num="yayoi"]
"Ahaha, I've never seen Miki panic like that before."
[cpg cn=true]


[OnName num="masato"]
"...…I see."
[cpg cn=true]


I wasn't really sure how to act around Mrs. Yayoi after all that.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sYayoi001"]
[OnName num="yayoi"]
"......So, I heard a little from Miki. Is it true you're a bit of a late bloomer?"
[cpg cn=true]


Mrs. Yayoi doesn't pull her punches.
[cpg]

I think I'd let my jaw drop in surprise.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sYayoi002"]
[OnName num="yayoi"]
"It looks like you need to get used to being around girls...or women."
[cpg cn=true]


[OnName num="masato"]
"M-Mrs. Yayoi?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Yayoi014"]
[OnName num="yayoi"]
"Oh, it's nothing, dear. Don't worry."
[cpg cn=true]


What was I supposed to say if Miki saw us like this?
[cpg]

I wonder if Mrs. Yayoi was serious......
[cpg]

;//■選択肢
[switch]
[case "She's probably joking."]
	[swap]
	[jump target="*select03_1"]
[case "She might be serious."]
	[swap]
	[jump target="*select03_2"]
[endswitch]


1. She's probably joking.
2. She might be serious.



;//２を選んだ場合　変数Ｃが１増加
;//どちらを選んでも物語は進行



;//==============================
;//１、流石に冗談だろう
*select03_1|Mrs. Yayoi's Joke




She had to be teasing me, right?
[cpg]

She was teasing Miki earlier, too, and this must be an extension of that.
[cpg]

Thinking so, I felt a little calmer.
[cpg]

[jump target="*select03_3"]

;//==============================
;//２、本気かもしれない
*select03_2|Mrs. Yayoi's Joke

[stflag flgC = 1]




She might be serious, her eyes didn't give the impression that she was joking.
[cpg]

I wonder if Mrs. Yayoi likes younger men.
[cpg]

If so, things could get pretty dicey......
[cpg]

;//==============================
*select03_3|Mrs. Yayoi's Joke



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿リビング』（夕方）******************************************************


Miki came back and we ended up talking in the living room.
[cpg]

I was Miki's way of showing that we had done nothing wrong.
[cpg]

I figured there wouldn't be any further progress today.
[cpg]

[OnName num="masato"]
"Well, I think I'm gonna go now...…."
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Yayoi015"]
[OnName num="yayoi"]
"Are you sure? Won't you stay for dinner"
[cpg cn=true]


[OnName num="masato"]
"I don't want to be a bother......I'll see you later, Miki.
[cpg cn=true]


[FACE method="bow_6" pos="2/5"]
[VOICE f="Miki118"]
[OnName num="miki"]
"Uh-huh...…"
[cpg cn=true]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

It was all awkward from start to finish.
[cpg]

It was all because Mrs. Yayoi said something weird...…Although I can't place all the blame on her.
[cpg]

I didn't expect her to say something like that.
[cpg]

[if exp={getFlagValue("flgC") == 1 }]
[jump target="*select03_5"]
[endif]

;//[jump target="*select03_4"]



;//==============================
;//１、流石に冗談だろう　を選んでいた場合
*select03_4|Mrs. Yayoi's Joke

I was surprised that people like her actually existed.
[cpg]

I hoped I'd be able to resist her charms, but it seemed like that would be difficult.
[cpg]

[jump target="*select03_6"]
;//==============================
;//２、本気かもしれない　を選んでいた場合
;//２を選んだ場合　変数Ｃが増えていた場合
;//[stflag flgC = 1]

*select03_5|Mrs. Yayoi's Joke

I found myself unexpectedly flattered by her actions.
[cpg]

Maybe it was because Mrs. Yayoi seemed to be serious about propositioning me.
[cpg]

;//==============================
*select03_6|Mrs. Yayoi's Joke


[SE f="se019"]
;//【ＳＥ】『ドア閉まる』



[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


I decided to head back to my apartment.
[cpg]

After finishing dinner, I headed out again......
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


I reach the maid cafe where Kanade works. There was something about the place that attracted me.
[cpg]

Rather, I may be attracted to Kanade.
[cpg]

Whenever I find myself thinking that, I remind myself that I have a girlfriend.
[cpg]

[SE f="se006"]
;//【ＳＥ】『カフェ入店鈴』

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『メイドカフェ』（夜）******************************************************



[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sKanade015"]
[OnName num="kanade"]
"You came again. Should I be happy about that?"
[cpg cn=true]


I scratch my head in embarrassment.
[cpg]

Was this how other boys gained the confidence they needed to do things with girls?
[cpg]

Or are they just confident from the start and there was something wrong with me?
[cpg]

[OnName num="masato"]
"......I came again."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sKanade016"]
[OnName num="kanade"]
"Aren't you the cutest?"
[cpg cn=true]


Even though I knew it was a lie, I don't feel bad about it.
[cpg]

It must be because someone as pretty as Kanade was saying it.
[cpg]

;//ブラックアウト

;//========================================
;//●ＣＧ（主人公に近づくヒロイン。背景と服装が変わっています）ev_12
;//人物１：ヒロイン２
;//服装１：メイド服
;//人物２：主人公
;//服装２：私服
;//場所　：メイドカフェ室内
;//時間　：夜
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


[VOICE f="sKanade017"]
[OnName num="kanade"]
"What's the matter? You seem to be lost in thought."
[cpg cn=true]


[OnName num="masato"]
"No it's just...…I feel like I'm acting suspicious or something."
[cpg cn=true]


[VOICE f="sKanade018"]
[OnName num="kanade"]
"You're fine, you just worry too much."
[cpg cn=true]


[VOICE f="sKanade019"]
[OnName num="kanade"]
"More importantly, I keep telling you not to say that sort of thing out loud."
[cpg cn=true]


I guess she was right. There are things that are better left unsaid.
[cpg]

I'd felt this way for a while, but like she said, I decided to keep it to myself.
[cpg]

;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『メイドカフェ』（夜）******************************************************

We continued to chat for a while before she broached a different topic.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sKanade020"]
[OnName num="kanade"]
"You know what? If you want, why don't we meet somewhere else next time?"
[cpg cn=true]


[OnName num="masato"]
"Somewhere else......?
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sKanade021"]
[OnName num="kanade"]
"It's not like we're strangers, right? We can hang out on our days off."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="sKanade022"]
[OnName num="kanade"]
"That's why I'm offering to be your personal maid."
[cpg cn=true]


A personal maid. As one can imagine, even if that was a joke, I was thrilled.
[cpg]

[jump storage="ep004.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

