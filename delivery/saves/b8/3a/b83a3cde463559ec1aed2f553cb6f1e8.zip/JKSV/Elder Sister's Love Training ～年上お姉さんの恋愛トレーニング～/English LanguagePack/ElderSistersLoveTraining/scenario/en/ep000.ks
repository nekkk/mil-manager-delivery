
*start|Timid in Love

;//童貞へるぷ　シナリオ

;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり

;//美樹　　制服　私服
;//奏　　　私服
;//やよい　私服

;//上記以外のキャラクターには音声がありません

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//美樹　　一人称「私」　奏呼び「奏」　やよい呼び「お母さん」　雅人呼び「雅人」
;//奏　　　一人称「あたし」　美樹呼び「美樹」　やよい呼び「美樹のお母さん」　雅人呼び「雅人」
;//やよい　一人称「私」　美樹呼び「美樹」　奏呼び「奏ちゃん」　雅人呼び「雅人くん」
;//雅人　　一人称「俺」　美樹呼び「美樹」　奏呼び「奏」　やよい呼び「やよいさん」

;//分岐に変数を三つ使います
;//変数Ａ　変数Ｂは０から始まって３まで上昇します
;//変数Ｃは０から始まって２まで上昇します


;#################################################
*Ep000|Timid in Love
;#################################################

[SCENE id=0]


[stflag flgA = 0]
[stflag flgB = 0]
[stflag flgC = 0]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************


What is the goal of love?
[cpg]

People often say that marriage is the graveyard of life, and I agree.
[cpg]

But isn't there a goal before marriage? For example, if you start to live together, you usually get married later.
[cpg]

I think that once you've been dating for a while, you naturally move in together.
[cpg]

If you count backwards, the goal gets closer and closer.
[cpg]

We seemed to have reached that goal early on and failed to develop our relationship from there.
[cpg]

;//========================================
;//●ＣＧ（ベッドに腰掛けて苦笑いしているヒロイン。背景を変えてください）ev_01
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


Miki Rikura. My girlfriend.
[cpg]

[VOICE f="Miki001"]
[OnName num="miki"]
"......"
[cpg cn=true]


Masato Mugara. Miki's lover, me.
[cpg]

[OnName num="masato"]
"......"
[cpg cn=true]



[VOICE f="sMiki001"]
[OnName num="miki"]
"Hey? Aren't we going to do anything today?"
[cpg cn=true]


[OnName num="masato"]
"Well...…"
[cpg cn=true]



[VOICE f="Miki003"]
[OnName num="miki"]
"......"
[cpg cn=true]


It's not awkward or anything. I just want to get out of here as soon as possible.
[cpg]

I know. I know that Miki is the first and last person who will like me.
[cpg]

She was the one who confessed her feelings to me. We started going out six months ago.
[cpg]

The reason she gave was that I was "incredibly kind to girls."
[cpg]

It was true, I am kind to girls. I'm so nice to girls that I can't even kiss one!
[cpg]


;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]


I didn't know what to do. No, that's wrong. I know what I'm supposed to do.
[cpg]

Why doesn't Miki do anything? Maybe she felt the same hesitation that I did.
[cpg]

Time passed this way, and I left the room.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Miki004"]
[OnName num="miki"]
"......Hey, Masato? Am I not that attractive?"
[cpg cn=true]


[OnName num="masato"]
"No...… Why would you think that way?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Miki005"]
[OnName num="miki"]
"Never mind, I know that's not the reason."
[cpg cn=true]


After six months of dating, you get to know each other's personalities pretty well.
[cpg]

I am a coward and Miki knows it.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I go home alone and fall into self-loathing.
[cpg]

It's not so much that I'm a coward, it's that I'm not proactive enough in pursuing her, so Miki was feeling insecure.
[cpg]

At this point, it's not about me being afraid to make the first move.
[cpg]

I'm afraid to even touch her.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


Miki and I are both college students. Both of us want to be with someone.
[cpg]

But we haven't kissed once during these six months.
[cpg]

She's my first girlfriend and I felt too timid to do anything.
[cpg]

[OnName num="male_student_A"]
"I can't believe you're going out with Ms. Rikura. How are you two getting along?"
[cpg cn=true]


[OnName num="masato"]
"Well, we've been together for a bit. I guess we're doing okay."
[cpg cn=true]


[OnName num="male_student_B"]
"That means you're doing things that lovers do, right?"
[cpg cn=true]


[OnName num="masato"]
"......Hmm."
[cpg cn=true]


I struggled to answer. Perhaps Miki had found herself in a similar situation.
[cpg]

I couldn't stand the thought.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


One day, while I was walking alone in the city, I saw Miki and her friend walking together.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1000]
[WAIT time=2000]

[FACE method="bow_2" pos="2/5"]
[VOICE f="Miki006"]
[OnName num="miki"]
"Oh......Masato."
[cpg cn=true]


[OnName num="masato"]
"Yo. Who's your friend......?"
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[VOICE f="Miki007"]
[OnName num="miki"]
"This is Kanade. I don't think you've met, but she's my best friend."
[cpg cn=true]


Kanade. I've never heard of her, and I've never seen her before.
[cpg]

[FACE method="bow_7" pos="4/5"]
[VOICE f="Kanade001"]
[OnName num="kanade"]
"Yeah......the name's Kanade Sazashiki......So, are you the boyfriend I keep hearing about?"
[cpg cn=true]


I wonder what she'd heard.
[cpg]

;//抱いてくれない甲斐性無しの彼氏だとでも言われてるんだろうな……
Miki might have told her that I was a worthless boyfriend who won't even touch her......
[cpg]

[OnName num="masato"]
"That's me. So, what were you two chatting about?"
[cpg cn=true]


[FACE method="shake_2" pos="2/5"]
[VOICE f="Miki008"]
[OnName num="miki"]
"Um, it's a secret."
[cpg cn=true]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Kanade002"]
[OnName num="kanade"]
"What are you think, Miki? Do you want to bring him along?"
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Miki009"]
[OnName num="miki"]
"I guess so. Masato, do you want to hang out today?"
[cpg cn=true]


[OnName num="masato"]
"I don't mind, but I don't want to intrude."
[cpg cn=true]


[FACE method="shake_2" pos="2/5"]
[VOICE f="Miki010"]
[OnName num="miki"]
"Not at all. Let's go then."
[cpg cn=true]


The three of us decided to hang out together.
[cpg]

It was the usual situation. We just went around window shopping.
[cpg]

Eventually we got hungry and headed into a diner.we went into a diner because we were hungry.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

When Miki got up to use the restroom, Kanade, who hadn't really talked to me much, finally said something.
[cpg]

;//========================================
;//●ＣＧ非エロ（ヒロイン１が席を立っている状態、対面する二人。真剣な表情）ev_02
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ファミレス店内
;//時間　：昼
;//========================================

[BGM f="bg_ni"]
[window target=false]
[free time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]



[VOICE f="sKanade001"]
[OnName num="kanade"]
"......So, how long are you going to keep Miki waiting?"
[cpg cn=true]


[OnName num="masato"]
"......I see you heard about us."
[cpg cn=true]



[VOICE f="Kanade004"]
[OnName num="kanade"]
"Yeah, of course. She's my best friend."
[cpg cn=true]


I guess women tended to discuss these things.
[cpg]

Still, I didn't have the confidence to take the next step...…
[cpg]

[VOICE f="sKanade002"]
[OnName num="kanade"]
"Are you afraid of disappointing her? Are you lacking confidence?"
[cpg cn=true]


[OnName num="masato"]
"Yeah......that pretty much sums me up."
[cpg cn=true]


[VOICE f="sKanade003"]
[OnName num="kanade"]
"You know, I'm working at a concept cafe."
[cpg cn=true]


[OnName num="masato"]
"A what? You mean like a maid cafe...…?"
[cpg cn=true]


[VOICE f="sKanade004"]
[OnName num="kanade"]
"Yeah, if you're not feeling confident, I can teach you a few things."
[cpg cn=true]


[VOICE f="Kanade010"]
[OnName num="kanade"]
"I do that kind of work too, so Miki asks me for advice sometimes."
[cpg cn=true]


That may be the case......Miki must at least know about Kanade's occupation.
[cpg]

;//ブラックアウト

[SE f="se001"]
;//【ＳＥ】『歩く』
[WAIT time=1000]


[VOICE f="Miki011"]
[OnName num="miki"]
"What were you two talking about?"
[cpg cn=true]



[VOICE f="sKanade005"]
[OnName num="kanade"]
"Nothing, we were just chatting."
[cpg cn=true]


I just went along with what Kanade said.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[VOICE f="Kanade012"]
[OnName num="kanade"]
"Well, I've got my shift coming up, so I'm going to head out. See you soon, Miki."
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Miki012"]
[OnName num="miki"]
"I'll see you soon...…What about you, Masato?"
[cpg cn=true]


[OnName num="masato"]
"Well...…do you want to hang out a little longer?"
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Kanade013"]
[OnName num="kanade"]
"Well. I'm glad to see you guys are so close. I'm rooting for you."
[cpg cn=true]


She left me without a way out.
[cpg]

[FADEOUTBGM]
[SE f="se001"]
;//【ＳＥ】『歩く』

[FO pos="4/5" time=800]
[WAIT time=1500]


After Kanade left, we knew where we were headed.
[cpg]

[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=500]
[VOICE f="Miki013"]
[OnName num="miki"]
"......Let's do it today. Masato."
[cpg cn=true]


[OnName num="masato"]
"Yeah. I'm ready too."
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="hiraki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="hiraki.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="hiraki.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************

At Miki's room.
[cpg]

We were tense. The mood was long gone.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sMiki002"]
[OnName num="miki"]
"......So, you're not going to do anything today either?"
[cpg cn=true]


[OnName num="masato"]
"Uh......well...…."
[cpg cn=true]



;//移植のためシーンをカットしています

[FACE method="shake_3" pos="2/3"]
[VOICE f="sMiki003"]
[OnName num="miki"]
"I don't want to wait any longer."
[cpg cn=true]

[free time=300]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=500]

She draws herself even closer.
[cpg]

[OnName num="masato"]
"No, look...…I just think maybe we should be a little more prepared."
[cpg cn=true]


My mind races to come up with some sort of excuse.
[cpg]

[OnName num="masato"]
"Look, I haven't even brushed my teeth."
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="sMiki004"]
[OnName num="miki"]
"......I don't care about that."
[cpg cn=true]


[OnName num="masato"]
"But you know.....we just need a little more time......."
[cpg cn=true]


Miki must have understood what I wanted to say.
[cpg]

In the end, I couldn't work up the courage. She knows it, I know it.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=1000]

[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=500]
[VOICE f="Miki036"]
[OnName num="miki"]
"Okay.….I get it."
[cpg cn=true]


She says with a sigh.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//移植のためシーンをカットしています


I couldn't even kiss Miki that night.
[cpg]

I had every opportunity, but I just couldn't find the courage to do anything.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="sMiki005"]
[OnName num="miki"]
"I don't get it......I'm ready, why aren't you?"
[cpg cn=true]


We talked about it for a while, but I couldn't give her a reason.
[cpg]

;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_ni"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I went back to my house and didn't feel self-loathing anymore.
[cpg]

It couldn't be helped. This is the way we are.
[cpg]

I remembered Kanade's offer from earlier.
[cpg]

I could practice with Kanade first, and then have a proper relationship with Miki......
[cpg]

Was it really an option? I started thinking about it.
[cpg]

Normally this would just mean I was cheating on Miki......right?
[cpg]

It was a crazy idea. I decided against it.
[cpg]

[jump storage="ep001.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
