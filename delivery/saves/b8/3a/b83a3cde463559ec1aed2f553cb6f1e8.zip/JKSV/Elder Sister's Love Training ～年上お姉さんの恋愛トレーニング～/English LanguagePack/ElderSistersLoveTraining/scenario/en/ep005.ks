
*start|A Dangerous Joke

;#################################################
*Ep005|A Dangerous Joke
;#################################################

[SCENE id=5]


[stflag flgA = 0]
[stflag flgB = 0]
[stflag flgC = 0]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


Around noon I decided to drop in and visit Miki.
[cpg]

We were close enough that it wasn't unusual.
[cpg]

If she was home, great. If she wasn't, or she was busy, I could come back another time.
[cpg]

Finally....I was going to kiss her. I felt very excited when I imagined it.
[cpg]

Miki would probably be there. I started to get nervous and even wished for a moment that Miki wouldn't be the one to answer the door.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

And sadly, that wish came true.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（昼）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yayoi016"]
[OnName num="yayoi"]
"I'm so sorry. Miki is out right now."
[cpg cn=true]


[OnName num="masato"]
"I see..…"
[cpg cn=true]


There went my plans for the day.
[cpg]

I couldn't waste the motivation that I'd finally scraped together.
[cpg]

[OnName num="masato"]
"What time will she be back?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yayoi017"]
[OnName num="yayoi"]
"She'll be back in the evening. Would you like to wait until then?"
[cpg cn=true]


[OnName num="masato"]
"If it's okay with you...…"
[cpg cn=true]


I decided to wait for her at her home.
[cpg]

Since it would be some time before she came back, I talked with Mrs. Yayoi for a while.
[cpg]

It would have been a normal situation......if nothing happened.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sYayoi003"]
[OnName num="yayoi"]
"Miki came to me for advice again. She really wants to spend more quality time with you."
[cpg cn=true]


If anything happened, it would be something like this.
[cpg]

[OnName num="masato"]
"I'm sorry.......I know she deserves better…"
[cpg cn=true]

[FADEOUTBGM]
[FACE method="bow_7" pos="2/3"]
[VOICE f="Yayoi019"]
[OnName num="yayoi"]
"It's okay, but do you remember what we talked about......About practicing with me?"
[cpg cn=true]


[OnName num="masato"]
"Um...…yes, I remember."
[cpg cn=true]

[BGM f="bg_h1"]
[FACE method="change_2" pos="2/3"]
[VOICE f="sYayoi004"]
[OnName num="yayoi"]
"It wasn't a joke."
[cpg cn=true]


I was listening to her, wondering why she would bring this up all of a sudden.
[cpg]

[OnName num="masato"]
"But when you say practice, what-......."
[cpg cn=true]


Flustered, I tried to make sense of the situation when she pulled me by the arm and took me to her room in a blink of an eye.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

I suddenly found myself......in Mrs. Yayoi's room. What just happened?
[cpg]

;//========================================
;//●ＣＧ（主人公に接近するヒロイン）ev_14
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：昼
;//========================================

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]


;//移植のためシーンをカットしています

[VOICE f="sYayoi005"]
[OnName num="yayoi"]
"I think I still have some charm as a woman."
[cpg cn=true]


She does. There was no denying it.
[cpg]

But she's Miki's mother, I couldn't let anything happen between us.
[cpg]

Thinking so, I managed to shake her off...…
[cpg]

For a moment, she seemed a little disappointed.
[cpg]

If she was serious, then she was a real threat to my relationship with Miki.
[cpg]

[OnName num="masato"]
"......Please stop kidding around."
[cpg cn=true]


I try to pass it off as a joke gone wrong, but her expression didn't change.
[cpg]

It didn't look like she had given up.
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の家＿リビング』（夕方）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Miki119"]
[OnName num="miki"]
"I'm home. Oh Masato, I didn't know you were here."
[cpg cn=true]


[OnName num="masato"]
"Oh, yeah......sorry, I was going to call."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Miki120"]
[OnName num="miki"]
"It's okay, don't worry about it. You're always welcome."
[cpg cn=true]


I hid what had happened with Mrs. Yayoi.
[cpg]

If Miki found out, it could mean the end of our relationship.
[cpg]

But more than that, Miki would be terribly hurt.
[cpg]

Because even if we parted ways, she still had to live with Mrs. Yayoi.
[cpg]

I thought about Mrs. Yayoi and what she had done......
[cpg]

;//■選択肢
[switch]
[case "I found Mrs. Yayoi to be reckless."]
	[swap]
	[jump target="*select05_1"]
[case "I think she did it out of the goodness of her heart."]
	[swap]
	[jump target="*select05_2"]
[endswitch]


1. I found Mrs. Yayoi to be reckless.
2. I think she did it out of the goodness of her heart.



;//２を選んだ場合　変数Ｃが１増加
;//どちらを選んでも物語は進行



;//==============================
;//１、やよいさんは無茶苦茶な人だ
*select05_1|A Dangerous Joke




Why would Mrs. Yayoi do that? Did I give her the wrong impression?
[cpg]

I couldn't understand. Mrs. Yayoi seemed reckless person.
[cpg]

I'll have to be careful around her......
[cpg]

[jump target="*select05_3"]

;//==============================
;//２、厚意でしてくれたのだろう
*select05_2|A Dangerous Joke

[stflag flgC = 1]


I'm sure she did it out of the kindness of her heart. She must have been teasing us because we couldn't seem to take the next step.
[cpg]

Or rather, if I don't interpret it that way, it would mean that Ms.Yayoi was trying to make a move on me.
[cpg]

I felt it would be rude to think that way about her mother.
[cpg]

;//==============================
*select05_3|A Dangerous Joke



;//ブラックアウト

[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************


Miki and I went to her room for some privacy. We stood there, facing each other.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMiki010"]
[OnName num="miki"]
"So......what should we do today?"
[cpg cn=true]


[OnName num="masato"]
"……Um, I'm down with whatever."
[cpg cn=true]


My answer was vague. But that was expected.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="sMiki011"]
[OnName num="miki"]
"Okay......I can wait. Let's do it at your pace."
[cpg cn=true]


I've been taking advantage of her kindness.
[cpg]

Miki acknowledges and accepts my weaknesses, why can't I?
[cpg]

;//ブラックアウト

Of course, it's not like I could change my personality on the spot.
[cpg]

If Miki felt like she had no choice...… From there, the two of us spent time together.
[cpg]

;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************


Did Miki find it frustrating that this was the extent of what we could do together?
[cpg]

Even if she thought so, would she tell me?
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Miki144"]
[OnName num="miki"]
"I'll wait for as long as I have to. Until you come to me."
[cpg cn=true]


[OnName num="masato"]
"Yeah......When I'm ready...…"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Miki145"]
[OnName num="miki"]
"It's fine. You don't have to say anything else. I can wait."
[cpg cn=true]


[OnName num="masato"]
"......Oh."
[cpg cn=true]


Miki's words made my heart ache. It was time to make a decision.
[cpg]

;//■選択肢
[switch]
[case "Miki had waited long enough."]
	[swap]
	[jump target="*select06_1"]
[case "I just need a little more time."]
	[swap]
	[jump target="*select06_2"]
[endswitch]


1. Miki had waited long enough.
2. I just need a little more time.



;//１を選んだ場合　変数Ａが１増加
;//どちらを選んでも物語は進行



;//==============================
;//１、美樹をこれ以上待たせられない
*select06_1|A Dangerous Joke

[stflag flgA = 1]


Miki had waited long enough.
[cpg]

I know she was feeling lonely and I don't want to make her suffer any longer.
[cpg]

[jump target="*select06_3"]

;//==============================
;//２、もう少し美樹に待ってもらおう
*select06_2|A Dangerous Joke



I have no choice but to ask Miki to wait a little longer. I'm just not ready.
[cpg]

I don't have the confidence......I want to be more experienced with women.
[cpg]

;//==============================
*select06_3|A Dangerous Joke



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Miki and I parted after that.
[cpg]

All I could do was think about what I was going to do next.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


I went out into the city in the evening and thought about Miki. No matter what happened, I didn't want her to hate me.
[cpg]

I want to practice with Kanade, but I felt like I was being unfaithful to Miki.
[cpg]

It was a nuanced situation, but I think most people would consider it cheating.
[cpg]

At the very least, it would certainly look like cheating from Miki's point of view.
[cpg]

Mrs.Yayoi was even more out of the question...…but even I wasn't immune to her charms.
[cpg]

I made a decision.
[cpg]

;//※分岐
;//上から順に条件を満たしているルートが発生します
;//二つ以上条件を満たしている場合上にあるものが優先されます

;//変数Ｂが３
[if exp={getFlagValue("flgB") == 3 }]
[jump target="*goflgB3"]
[endif]

;//変数Ａが２以上　変数Ｂが２以上
[if exp={getFlagValue("flgA") >= 2 }]
[if exp={getFlagValue("flgB") >= 2 }]
[jump target="*goflgA2B2"]
[endif]
[endif]

;//変数Ａが３　変数Ｂが１以上
[if exp={getFlagValue("flgA") == 3 }]
[if exp={getFlagValue("flgB") == 1 }]
[jump target="*goflgA3B1"]
[endif]
[endif]

;//変数Ｃが２
[if exp={getFlagValue("flgC") == 2 }]
[jump target="*goflgC2"]
[endif]

;//変数Ａが３
[if exp={getFlagValue("flgA") == 3 }]
[jump target="*goflgA3"]
[endif]

;//いずれのルートにも該当しない場合
[jump target="*root_ather"]


*goflgB3|I was going to take a detour to face Miki
[jump storage="ep006.ks" target="*goflgB3"]

*goflgA2B2|I want to cherish my relationships with Miki and Kanade
[jump storage="ep007.ks" target="*goflgA2B2"]

*goflgA3B1|Where was the goal?
[jump storage="ep008.ks" target="*goflgA3B1"]

*goflgC2|I was attracted to Mrs. Yayoi
[jump storage="ep009.ks" target="*goflgC2"]

*goflgA3|Invincible together
[jump storage="ep010.ks" target="*goflgA3"]

*root_ather|A sin to bear alone
[jump storage="ep011.ks" target="*root_ather"]


