
*start|The Next Step

;#################################################
*Ep001|The Next Step
;#################################################

[SCENE id=1]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（朝）******************************************************


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miki058"]
[OnName num="miki"]
"Oh, Masato. You're up early."
[cpg cn=true]


[OnName num="masato"]
"You too, Miki. Do you have a lecture at this time?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Miki059"]
[OnName num="miki"]
"Yeah, they had to reschedule this class for some reason...…"
[cpg cn=true]


I was in a similar situation so I decided to talk to Miki for a bit.
[cpg]

I wondered if she was angry about yesterday. I tried to probe her about it.
[cpg]

[OnName num="masato"]
"......Miki, are you mad at me?"
[cpg cn=true]


I guess I wasn't clever enough to word it in a tactful manner.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Miki060"]
[OnName num="miki"]
"Would getting mad at you change anything?"
[cpg cn=true]


Miki looked depressed.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Miki061"]
[OnName num="miki"]
"I'm having a really hard time, it feels like you're ruining everything."
[cpg cn=true]


[OnName num="masato"]
"......I didn't know...…Miki?'
[cpg cn=true]


Miki had started to cry. That's...not good. We were in public.
[cpg]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Miki062"]
[OnName num="miki"]
"You're horrible, Masato......"
[cpg cn=true]


[OnName num="masato"]
"I'm sorry, you're right. It's all my fault, please don't cry......."
[cpg cn=true]


What good was apologizing now?
[cpg]

In the end I still won't be able to take the first step.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（夕方）******************************************************


I am a coward, but Miki had fallen for me anyways.
[cpg]

If I could do something about my timidity, we'd have a healthier relationship.
[cpg]

How did we end up in this situation anyways?
[cpg]

I know the reason. Either Miki or I had to change.
[cpg]

But I can't ask Miki to change. I have to change.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************


On another day, I went to apologize to Miki again.
[cpg]

[OnName num="masato"]
"If you'll let me, I want to try to explain my reasoning."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Miki063"]
[OnName num="miki"]
"......Okay. I think I have a pretty good idea of what you're going to say though."
[cpg cn=true]


Miki's words had a slight edge to them. I can't blame her.
[cpg]

[OnName num="masato"]
"I'm......really scared. If our first time doesn't go well, I'm afraid that you'll start to hate me."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Miki064"]
[OnName num="miki"]
"......I won't hate you. But it's not like saying that will help you get past this."
[cpg cn=true]


Miki really knows me well. I was happy to hear her say it, but she was right. It didn't change anything for me.
[cpg]

[OnName num="masato"]
"Can you give me just a little more time.....?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Miki065"]
[OnName num="miki"]
"Sure, I think I can wait just a little longer."
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『ドア開閉』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の家＿リビング』（夕方）******************************************************


I left Miki's room.
[cpg]

She lives at her parents' house. I live in an apartment fairly close to her.
[cpg]

;//下記セリフのみ名前欄を？？？と隠してください


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yayoi001"]
[OnName num="unknown"]
"Oh Masato, are you going home already?"
[cpg cn=true]


[OnName num="masato"]
"Oh...…Mrs. Yayoi."
[cpg cn=true]


Although Mrs. Yayoi looked like she could pass as Miki's older sister, she was actually her mother.
[cpg]

She looks quite young, I guess Miki got her looks from her mother.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Yayoi002"]
[OnName num="yayoi"]
"Why don't you stay for a while longer?"
[cpg cn=true]


[OnName num="masato"]
"Oh, yeah......thanks.."
[cpg cn=true]


After six months of dating, her parents approved of our relationship.
[cpg]

Miki, Mrs. Yayoi, and I chatted for a while.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]
[WAIT time=100]


Later, when I was about to leave......
[cpg]

;//========================================
;//●ＣＧ非エロ（主人公に鞄を渡すヒロイン。笑顔から、少し真面目な表情になる）ev_05
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン１の家＿玄関先
;//時間　：夕方
;//========================================



[window target=false]
;**【ＣＧ】 ev_05_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]



[VOICE f="Yayoi003"]
[OnName num="yayoi"]
"Here, Masato. You forgot something."
[cpg cn=true]


[OnName num="masato"]
"Huh? Oh, thank you."
[cpg cn=true]


Apparently, I had left my bag behind.
[cpg]

It was a small bag, but I must have been pretty nervous if I'd forgotten it...…
[cpg]

[VOICE f="Yayoi004"]
[OnName num="yayoi"]
"......Can I have a word?"
[cpg cn=true]


[OnName num="masato"]
"Oh, uh sure."
[cpg cn=true]



[VOICE f="Yayoi005"]
[OnName num="yayoi"]
"Lately, Miki seems to be worried that you might not like her."
[cpg cn=true]



[VOICE f="Yayoi006"]
[OnName num="yayoi"]
"Do you really love Miki?"
[cpg cn=true]


[OnName num="masato"]
"That's...…"
[cpg cn=true]


It was an awkward conversation to have with my girlfriend's mother. But it wasn't entirely unexpected.
[cpg]

After all, Miki could only confide in the people closest to her. I felt regret for dragging them both into this situation....…
[cpg]

[OnName num="masato"]
"I think it will be all right. It might take a little time, but...it will be all right."
[cpg cn=true]


All I could manage was a vague response.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


As I was walking home, I gave it some more thought. How could I take my relationship with Miki to the next step?
[cpg]

It didn't feel like I had much time left.
[cpg]

;//■選択肢
[switch]
[case "I want to find the courage."]
	[swap]
	[jump target="*select01_1"]
[case "I still can't find the courage."]
	[swap]
	[jump target="*select01_2"]
[endswitch]


1. I want to find the courage.
2. I still can't find the courage.

;//１を選んだ場合　変数Ａが２増加
;//どちらを選んでも物語は進行

;//==============================
;//１、いつか臆病者を卒業したい
*select01_1|The Next Step

[stflag flgA = 2]



I still want to express my love to her someday.
[cpg]

I want to be able to show her how strongly I feel for her.
[cpg]

In order to do that, I really have to work up the courage.
[cpg]

[jump target="*select01_3"]

;//==============================
;//２、それでもやっぱり勇気が出ない
*select01_2|The Next Step


But I still can't find the courage.
[cpg]

If she told me I was a bad kisser, I might not be able to recover.
[cpg]

Actually, that wasn't even the worst case scenario. I really didn't want to lose her....….
[cpg]

;//==============================
*select01_3|The Next Step

[SE f="se001"]
;//【ＳＥ】『歩く』




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I'm able to cook for myself, more or less. At the very least, I can cook rice and make a side dish or two.
[cpg]

But lately I've been relying on the prepared food section at the supermarket.
[cpg]

I feel like I'm losing weight......
[cpg]

I was doing some research on my phone. I was looking up the concept cafe that Kanade had told me about.
[cpg]

It was surprisingly close. I guess it made sense, the two of them were friends so they probably lived near each other too.
[cpg]

But then, it wasn't a guarantee that she worked near where she lived......
[cpg]

I made up my mind. I was going to ask Kanade to teach me a few things.
[cpg]




[jump storage="ep002.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

