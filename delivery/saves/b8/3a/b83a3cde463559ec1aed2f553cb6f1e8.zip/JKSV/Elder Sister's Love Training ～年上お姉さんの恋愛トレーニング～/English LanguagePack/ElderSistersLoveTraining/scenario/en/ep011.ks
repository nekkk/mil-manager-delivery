
*start|A sin to bear alone

;//==============================
;//いずれのルートにも該当しない場合
*root_ather|A sin to bear alone




I had to love Miki. A kiss wouldn't resolve the situation.
[cpg]

I just knew I couldn't keep her waiting any longer.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I spend the night trying to think of a plan.
[cpg]

I'll ask her out tomorrow. I don't care if it's sudden, it's not sudden for us.
[cpg]

She'd waited for six months. I'd made her wait.
[cpg]

I can't let her wait any longer.
[cpg]

When I think about it, I feel like I can't sleep...…
[cpg]

Am I going to sleep with Miki? It would be different from sleeping with Kanade.
[cpg]

;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


I didn't get much sleep. In the morning I headed off to college.
[cpg]

I would meet Miki during lunch break. I should ask her about it then.
[cpg]

;#################################################
*Ep011|A sin to bear alone
;#################################################

[SCENE id=11]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


[FG f="CHA01_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Miki589"]
[OnName num="miki"]
"Good morning...…did something happen? You look really tired."
[cpg cn=true]


[OnName num="masato"]
"Oh, well......it's not a big deal, don't worry about it."
[cpg cn=true]


She'd probably figure it out after I invite her over.
[cpg]

[OnName num="masato"]
"......Do you have any plans later? Are you free?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Miki590"]
[OnName num="miki"]
"I don't have any plans......Why?"
[cpg cn=true]


[OnName num="masato"]
"Would you like to come over to my place?"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

After saying that much, Miki seemed to understand. Her face turns red.
[cpg]

[FACE method="change_6" pos="2/3"]

I felt kind of sorry, but I wasn't going to stop.
[cpg]

What happened with Kanade and with Mrs. Yayoi was necessary. At least, that's what I told myself.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Miki591"]
[OnName num="miki"]
"Okay......sure. I'll go."
[cpg cn=true]



;//ブラックアウト


Miki was tense. I hoped she understood what I was trying to say.
[cpg]

I think she knew I was serious this time. I started to get nervous.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


Then, I kissed her for the first time.
[cpg]

She was nervous. I was nervous too, but not as much as I should have been.
[cpg]

I guess it was the result of practice. Miki is still not used to men, I guess.
[cpg]

The moment our lips touched, I felt a surge of excitement, but...…
[cpg]

Perhaps what I felt was a sense of regret that I had kept her waiting for six months.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="sMiki062"]
[OnName num="miki"]
"I'm......happy. It's almost like you're someone completely different."
[cpg cn=true]


She was so cute when she smiled like that.
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

;//ブラックアウト


That day, I took Miki home before it got late.
[cpg]

It was hard to persuade Miki to not stay the night, even though she thought that it was a good opportunity.
[cpg]

I didn't want to give her father an excuse to come after me......
[cpg]

This didn't have anything to do with me being a coward or anything.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Miki634"]
[OnName num="miki"]
"Masato, let's go home together today."
[cpg cn=true]


[OnName num="masato"]
"......I still have a lecture."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Miki635"]
[OnName num="miki"]
"Aww......You can't skip it ?"
[cpg cn=true]


I know she wanted me to skip it, but I chose to attend the lecture.
[cpg]

Miki no longer held back showing her affection for me.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（夕方）******************************************************


Miki and I meet up again after classes. She'd been waiting for me the entire time. We head to my place again.
[cpg]

[OnName num="masato"]
"....Are you sure about this? How many days in a row is this now?"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sMiki063"]
[OnName num="miki"]
"Does it matter? You're the only one who matters to me right now, Masato."
[cpg cn=true]


She's engrossed in our relationship. I'm starting to get a little worried.
[cpg]

I dread to think of what would happen if she ever found out about Kanade or Mrs. Yayoi......
[cpg]

It was probably fine, I didn't have any need to practice with them anymore. Or at least that's what I thought.
[cpg]



[SE f="se001"]
;//【ＳＥ】『歩く』

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


How many times have we kissed now? I'd stopped counting.
[cpg]

I was having difficulty adjusting to how sudden she'd closed the distance between us...…
[cpg]

But I felt happy to be with her.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="sMiki064"]
[OnName num="miki"]
"You're getting better at kissing."
[cpg cn=true]


[OnName num="masato"]
"Compared to who?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="sMiki065"]
[OnName num="miki"]
"Oh, don't be mean."
[cpg cn=true]


I showed her that I was confident enough to tease her. And she was confident enough accept it.
[cpg]

It was times like this that made me realize how far we'd come.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sMiki066"]
[OnName num="miki"]
"I'm glad you've changed, Masato."
[cpg cn=true]



;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


I wish that this could go on forever, but Miki has to go home.
[cpg]

[OnName num="masato"]
"I'll walk you home. You will at least let me do that right?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Miki657"]
[OnName num="miki"]
"Yeah, thanks. We can keep talking along the way."
[cpg cn=true]


Miki and I head out.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Miki658"]
[OnName num="miki"]
"It took a long time for us to come this far......what changed your mind?"
[cpg cn=true]

It was a hard question to answer.
[cpg]

[OnName num="masato"]
"Oh......well, thought about how you were waiting for me all that time."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Miki659"]
[OnName num="miki"]
"I guess I was.....but is that really all it took?"
[cpg cn=true]

It was out of character for me, sure...
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Miki660"]
[OnName num="miki"]
"So there wasn't any other reason behind your sudden, passionate approach?"
[cpg cn=true]


......Was Miki getting suspicious? I wonder how much she knew.
[cpg]

[OnName num="masato"]
"No, not really......I thought about you and I felt like I could do it."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Miki661"]
[OnName num="miki"]
"Hmm. If you say so."
[cpg cn=true]


From there, we walked for a while further.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************




[FACE method="bow_2" pos="4/5"]
[VOICE f="Yayoi201"]
[OnName num="yayoi"]
"Oh, welcome back. I see that Masato is with you too."
[cpg cn=true]


[OnName num="masato"]
"Good evening...…"
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Miki662"]
[OnName num="miki"]
"Okay, see you tomorrow, Masato."
[cpg cn=true]


[OnName num="masato"]
"Yeah, see you."
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Some time passes.
[cpg]

I found myself in Miki's room along with Kanade.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Kanade341"]
[OnName num="kanade"]
"I'm happy to hear you two finally got together for real. Congratulations."
[cpg cn=true]


[FACE method="bow_6" pos="2/5"]
[VOICE f="Miki663"]
[OnName num="miki"]
"Ehehe, I'm so embarrassed."
[cpg cn=true]


Miki told Kanade that we just had our first kiss.
[cpg]

I watched them chat, sweating the whole time.
[cpg]

[FO pos="2/5" time=1000]

Miki gets up to use the restroom...…
[cpg]

[free time=500]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kanade342"]
[OnName num="kanade"]
"I'm not going to say anything, you don't have to tell her either."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Kanade343"]
[OnName num="kanade"]
"Miki is probably the jealous type. It's better for the both of us to keep our mouths shut."
[cpg cn=true]


[OnName num="masato"]
"Yeah, okay......sounds good."
[cpg cn=true]


[free time=500]


[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[WAIT time=1500]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Miki664"]
[OnName num="miki"]
"So? What were you two talking about?"
[cpg cn=true]


[OnName num="masato"]
"Nothing much...…"
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[FACE method="bow_1" pos="4/5"]

I can't ever let her find out.
[cpg]

;//でも、それは美樹以外の二人としてしまった罪だ。
I'd approached two other women under the guise of practice.
[cpg]

It was a secret I'd have to keep for the rest of my life.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト


Telling Miki everything might make me feel better.
[cpg]

But Miki would suffer. In that case, wouldn't it be better to keep everything a secret?
[cpg]

[FACE method="change_2" pos="2/5"]
[FACE method="change_2" pos="4/5"]


I don't think honesty is the answer to everything.
[cpg]


[SCENE id=17]
;//ＥＮＤ：ヒロイン１ルート３

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================


