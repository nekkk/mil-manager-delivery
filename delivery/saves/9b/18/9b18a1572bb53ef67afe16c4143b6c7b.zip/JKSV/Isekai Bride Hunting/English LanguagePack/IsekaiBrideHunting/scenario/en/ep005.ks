
;//==============================
;//１、フィア

*start

*ep005
*IseSel09_1|Demon King x Fia

[SCENE id=5]


I want to make Fia my queen, as the Demon King.
[cpg]


With that in mind, I decided to go to the room where Fia lived.
[cpg]



[window target=false]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]

[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************


[window target=true]



[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia318"]
[OnName num="fia"]
"What is it...? At this time of night?"
[cpg cn=true]


[OnName num="kousuke"]
"I have a few things to discuss."
[cpg cn=true]


I explained to her that I was determined to conquer this world.
[cpg]


The expression on Fia's face grew cloudy. I'm sure the pacifist in her won't agree with me.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia319"]
[OnName num="fia"]
"I think there are ways to live in peace without world domination..."
[cpg cn=true]


[OnName num="kousuke"]
"You defy me? You mean to defy the Demon King?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia320"]
[OnName num="fia"]
"Still, I can't do it. I want peace."
[cpg cn=true]


Fia I don't know if I'll ever be able to keep you by my side.
[cpg]


Even though I knew that, I still wanted to make Fia my queen.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト


[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]



[OnName num="kousuke"]
"Not an ally...., but a queen."
[cpg cn=true]

I thought about it in my head, and it felt right.
[cpg]

We are attracted to each other because of our conflicting thoughts.
[cpg]

;//Ｈシーンカット


;//ブラックアウト


[WAIT time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************






The next day, I gathered the four of us together and decided to talk about what we were going to do.
[cpg]


[OnName num="kousuke"]
"I've already told Fia that I'm going to take over the world so that I can live in peace."
[cpg cn=true]


The four of us were silent for a moment, but then Chartier spoke up.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Schartye333"]
[OnName num="schartye"]
"I told you. That's what the Demon King is all about."
[cpg cn=true]


And then they all applauded. Kullulu joined it.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Clolowlude260"]
[OnName num="clolowlude"]
My arms are sore. I'm sure you can handle more magic, so I'll teach you."
[cpg cn=true]





[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="sMeile046"]
[OnName num="meile"]
"Yeah, why not? I'll go along with whatever Kosuke wants to do."
[cpg cn=true]


Meir seems to respect my decision.
[cpg]




Fia still seems conflicted. Only one person seemed to have a different opinion.
[cpg]

[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=1000]
[VOICE f="Fia343"]
[OnName num="fia"]
"I'm against it. As I said yesterday, Kosuke..."
[cpg cn=true]


[OnName num="kousuke"]
"I'm going to do it even if you disagree. I just wanted to let you know, I'm not asking for your opinion."
[cpg cn=true]


Fia couldn't say anything and slumped down.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





I then worked with Chartier and Kullulu to develop magic for the military.
[cpg]


Even though Fia had knowledge of magic and could have helped, she did not.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye334"]
[OnName num="schartye"]
"This is where the power would be increased."
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude261"]
[OnName num="clolowlude"]
"Chartier, there's no need to go overboard with the power here, a half-kill would be fine."
[cpg cn=true]


Chartier and Kullulu responded to my suggestion with some crazy replies, but...
[cpg]


It was the noise of things that I had asked for in the first place. Finally, I was about to become a real Demon King.
[cpg]



;//ブラックアウト

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_3.ui" time=1000]

[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夕方）******************************************************





[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia344"]
[OnName num="fia"]
"I'm not sure..."
[cpg cn=true]


I'm not surprised. She might have thought that being loved by me was somehow good.
[cpg]

[OnName num="kousuke"]
"I'll keep saying I love you until Fia feels the same way."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sFia030"]
[OnName num="fia"]
"You can keep saying I love you, but I it doesn't mean you do. How can you say you love me..."
[cpg cn=true]

[OnName num="kousuke"]
"I don't know... But, I still love you."
[cpg cn=true]

She didn't answer anything. But I felt that this was one answer.
[cpg cn=true]

Fia is conflicted. But she's not pushing me away.
[cpg cn=true]


;//ブラックアウト


;//Ｈシーンカット

;//Ｈシーンカット


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************



[OnName num="kousuke"]
"I'm thinking of invading the Elven Nation soon..."
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia394"]
[OnName num="fia"]
"Yes..., finally."
[cpg cn=true]


Fia had an unhappy expression on her face. Of course she would.
[cpg]


After all, we are talking about invading her former homeland.
[cpg]


It's not like I'm trying to destroy everything and kill everyone.
[cpg]


Bbut I'm also trying to create magic that diminishes their ability to fight.
[cpg]


I still thought it would be better to have as few deaths as possible.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia395"]
[OnName num="fia"]
"Kosuke, I have a favor to ask of you."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia396"]
[OnName num="fia"]
"The Elven Nation is my home. So..."
[cpg cn=true]


[OnName num="kousuke"]
"Fia, it doesn't matter if you try and stop me."
[cpg cn=true]


[OnName num="kousuke"]
"I just thought I'd tell you before anyone else does."
[cpg cn=true]


Fia said nothing and slumped.
[cpg]



;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="162.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="162.jpg" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]


[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************


[window target=true]



The next day, I had gathered the four of us together.
[cpg]


They all seemed to have some idea of what I had decided.
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[OnName num="kousuke"]
"I've perfected a new spell, tentatively named Sleep Magic."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye335"]
[OnName num="schartye"]
"Oh, come on. I'm sure the Demon King couldn't have perfected it without our help."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Clolowlude262"]
[OnName num="clolowlude"]
"Well, true. I just wanted to say it."
[cpg cn=true]


Chartier interjects. But that's not the main point.
[cpg]


[OnName num="kousuke"]
"It will have a tremendous effect on the battlefield. It's the kind of magic that makes it impossible to stand up, even if you don't go to sleep."
[cpg cn=true]


[OnName num="kousuke"]
"It's also very far-reaching. If I go in alone, and then call in the soldiers, I can..."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile353"]
[OnName num="meile"]
"It might be able to neutralize any country. Though, I'm not really sure..."
[cpg cn=true]


[OnName num="kousuke"]
"I think the first place I'm going to use this magic is in the Elven Nation."
[cpg cn=true]


Fia bit her lip. I wasn't surprised to get that look.
[cpg]


[OnName num="kousuke"]
"I'm sorry Fia... But is the country that is most hostile to me. I want to take it down first."
[cpg cn=true]

;//;[FO layer="2/2"]



[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sFia031"]
[OnName num="fia"]
"You mean with warfare, right?"
[cpg cn=true]


[OnName num="kousuke"]
"As much as possible, I don't want to kill them. It's more efficient to capture them and turn them into our soldiers."
[cpg cn=true]


Fia didn't agree with this. Even if she didn't say anything we all knew it.
[cpg]


[OnName num="kousuke"]
"Fia, you really don't like this, huh?
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia397"]
[OnName num="fia"]
"Of course not..."
[cpg cn=true]


I knew it. Even if we don't go around killing people, it's still a conquest.
[cpg]


My relationship with Fia may one day prevent me from conquering the world.
[cpg]


I wonder what I'll do then. I just want to live in peace with Fia.
[cpg]


But if that possibility disappears, then my goal itself will be lost.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile354"]
[OnName num="meile"]
"Well, there's no use thinking about it. If we don't do something, we might be invaded, right?"
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. You're right. We're not going to sit around and do nothing."
[cpg cn=true]



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye336"]
[OnName num="schartye"]
"That's reassuring. You're starting to look like the Demon King."
[cpg cn=true]


Chartier smiled at that. Kullulu was smiling too.
[cpg]


But... Fia was clearly frustrated.
[cpg]

[free time=800]

[OnName num="kousuke"]
"Fia, let's go outside for a while."
[cpg cn=true]


[FACE method="change_5" pos="2/2"]
[VOICE f="Fia398"]
[OnName num="fia"]
"Huh? Y-yes..."
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

;//＠
[SE f="se011"]
;//【ＳＥ】『人混み』

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

I took Fia and just the two of us went out to the city.
[cpg]


This city is lively. It may be a result of the lower class fighting to change their status.
[cpg]


Or maybe they're simply expecting me to do the same.
[cpg]


Either way, these are the people who can give me a boost.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia399"]
[OnName num="fia"]
"I'm still not sure... Do we really need to invade the Elven Nation?"
[cpg cn=true]


[OnName num="kousuke"]
"If we don't, they will come here. Wouldn't you be sad if I died, Fia?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia400"]
[OnName num="fia"]
"I don't think they'd kill you."
[cpg cn=true]


[OnName num="kousuke"]
"Okay, they'll seal me up. Either way, it's like dying."
[cpg cn=true]


Fia fell silent. I was supposed to be trying to convince her, but it turned into an argument.
[cpg]


I don't want to do this either.
[cpg]


[OnName num="kousuke"]
"We can't go on like this... It's not like it's an issue of race, right?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia401"]
[OnName num="fia"]
"Yes. It's because Kosuke is the Demon King."
[cpg cn=true]


It may my cursed fate, but...
[cpg]


[OnName num="kousuke"]
"But if I wasn't the Demon King, I wouldn't have been able to meet you, Fia."
[cpg cn=true]


Fia looked a little sad. She seemed to be pessimistic about things.
[cpg]


[OnName num="kousuke"]
"Let's walk the streets. I think Fia will know what the citizens think."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_3.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城下町＿魔王の国』（夕方）******************************************************



[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]


As we walked through the city, the citizens spoke amongst each other.
[cpg]


They were saying things like, "Aren't they going to invade the Elven Nation yet?" or "Maybe they're not invading Japan since the Demon King is from there".
[cpg]


They seemed to be ready at any time. If anything, even the non-soldiers were bloodthirsty.
[cpg]


I guess that's how dissatisfied they were until now.
[cpg]


It was true that the fromer Beast Country, unlike the Elven Nation, could not have been called a developed country.
[cpg]


It was impossible not to complain about being left behind by the rest of the world.
[cpg]


[OnName num="therianthropy_A"]
"You're developing new magic, aren't you, Demon King?"
[cpg cn=true]


[OnName num="therianthropy_B"]
"Let's invade the Elven Nation! If we can get the elves to follow us, we can really take over the world."
[cpg cn=true]


[OnName num="kousuke"]
"You hear that, Fia? This is what the people are saying."
[cpg cn=true]


[VOICE f="Fia402"]
[OnName num="fia"]
"I know. I know, but..."
[cpg cn=true]


[OnName num="kousuke"]
"I'm not talking about destroying the Elven Nation. Just have them join the Land of the Demon King."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia403"]
[OnName num="fia"]
"But you can't promise that something terrible won't happen to the elves..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia404"]
[OnName num="fia"]
"No. Even if I don't, I still don't think something like that will happen."
[cpg cn=true]


[OnName num="kousuke"]
"You are stubborn."
[cpg cn=true]


I may be stubborn, but I understand what she's getting at. If I were in the same position, I might have argued that way.
[cpg]



;//ブラックアウト

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





I was alone with Fia in my room.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia405"]
[OnName num="fia"]
"Kosuke... I don't know anymore."
[cpg cn=true]


[OnName num="kousuke"]
"You don't know what? Why don't you just do what I say?"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia406"]
[OnName num="fia"]
"My mind is a mess... What can I do to help you, Kosuke?"
[cpg cn=true]


[OnName num="kousuke"]
"Isn't it obvious? I need your help."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia407"]
[OnName num="fia"]
"I can't...do that."
[cpg cn=true]


[OnName num="kousuke"]
"You really are stubborn."
[cpg cn=true]


You need to be reminded, even if things get a little rough, that you're mine.
[cpg]

[OnName num="kousuke"]
"I love you, Fia. I think you know what I need from you."
[cpg cn=true]

[OnName num="kousuke"]
"Don't hesitate to ask. I'll give you whatever you want."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia408"]
[OnName num="fia"]
"I may be stubborn..., but you are pushy, Kosuke."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah, I know that."
[cpg cn=true]

;//Ｈシーンカット

I had slowly come to understand that Fia was stubborn.
[cpg]

No matter how many times I tried to seduce her, tell her I loved her, or convince her that this was the only way, she wouldn't change.
[cpg]


There was a part of me that thought, "Of course she's stubborn. Nothing is going to change because of this."
[cpg]


[OnName num="kousuke"]
"Fia..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia432"]
[OnName num="fia"]
"What is it? I don't care how many times you say it, my opinion is the same."
[cpg cn=true]


[OnName num="kousuke"]
"I know. I'm not asking you to accept it. But please forgive me."
[cpg cn=true]


[OnName num="kousuke"]
"It's so I can live without being hunted. That's why I have to..."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia433"]
[OnName num="fia"]
"I don't know what to say to something like that..."
[cpg cn=true]


Fia has a troubled look on her face.
[cpg]


I, too, was feeling delicate. But what right did I have to say that?
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





At night, I was alone in my room.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドアノック』





[OnName num="kousuke"]
"Who is it?"
[cpg cn=true]



[VOICE f="Schartye337"]
[OnName num="schartye"]
"It's me. Can I come in?"
[cpg cn=true]


[OnName num="kousuke"]
"Yes. Come in."
[cpg cn=true]



[SE f="se002"]
;//【ＳＥ】『ドア開く』





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye338"]
[OnName num="schartye"]
"You don't look so good, Your Majesty."
[cpg cn=true]


Chartier didn't seem to be worried about me.
[cpg]


Rather, she looked as if she wanted to tell me not to hesitate now.
[cpg]


[OnName num="kousuke"]
"What is it that you want? Tell me quickly."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye339"]
[OnName num="schartye"]
"My men are ready, and so Kullulu-Urd informed me that hers are too."
[cpg cn=true]


[OnName num="kousuke"]
"I see... It's time."
[cpg cn=true]


I have to make up my mind. I'm going to invade the land where Fia used to live.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_02_2.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_tc"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************

[window target=true]




I had visited the Elven Nation before.
[cpg]


The magic of sleep. In the end, the provisional name became the name.
[cpg]


This magic worked indiscriminately. The only way to make the mission work was for me to go in practically alone.
[cpg]


If they find out that I'm the Demon King and surround me, that's the end of it.
[cpg]


I had to leave Chartier and Kullulu in the Land of the Demon King.
[cpg]


I don't want these women who lead my army to end up falling asleep.
[cpg]


[OnName num="kousuke"]
"Let's go..."
[cpg cn=true]


It was a  one-way mission from there.
[cpg]


[SE f="se016"]
;//【ＳＥ】状態異常魔法

;//画面薄く赤色に
[BG f="red.ui" time=1000]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_de"]




Very few of them were resistant to magic. Some of the wizards noticed something was wrong and put up barriers, but...
[cpg]


We outnumbered them. The soldiers from the Land of the Demon King were also brave.
[cpg]


And on top of that, I have my magic. It was no contest.
[cpg]


No more screams, just one-sided domination. the Elven Nation was neutralized in a matter of hours.
[cpg]

[window target=false]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


;//色調元に戻る


[BG f="b_02_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（夜）******************************************************



[window target=true]


By the time night fell, the news had swept the world.
[cpg]


The land of the Demon King had invaded the Elven Nation. We are steadily trying to take over the world...
[cpg]


I don't know if it's my reputation, or if it's my danger in the eyes of the world...
[cpg]


In any case, I've become someone who can't be left alone, but I've also become someone who's difficult to deal with.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia434"]
[OnName num="fia"]
"Are you sure you want to do this...?"
[cpg cn=true]


[OnName num="kousuke"]
"It's okay. We've captured all the soldiers and the people in the center of the country."
[cpg cn=true]


[OnName num="kousuke"]
"We'll be able to control this country as we see fit. Maybe more demi-humans will come."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia435"]
[OnName num="fia"]
"I have mixed feelings about this. It's my home..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia436"]
[OnName num="fia"]
"To overrun it unilaterally, without dialogue, is..."
[cpg cn=true]


[OnName num="kousuke"]
"You have to understand. There is no other way."
[cpg cn=true]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************





The next day, I returned to the Land of the Demon King.
[cpg]


After all, I feel more at home here. I left the control of the Elven Nation to my advisors.
[cpg]


The advisors were not Chartier or Kullulu, but those who were their subordinates.
[cpg]


There were plenty of people who were better than me at politics.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[OnName num="kousuke"]
"Fia, Don't look at me like that."
[cpg cn=true]


Fia and I walked together, but she stayed silent.
[cpg]


In the midst of this, one of the citizens stood in front of me.
[cpg]


It looked like a beast, but on closer inspection it was an elf.
[cpg]



[OnName num="elf_man"]
"How dare you do this to me...!"
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

He had a blade in his hand. I immediately shielded Fia.
[cpg]


[SE f="se006"]
;//【ＳＥ】『魔法発動する』
[WAIT time=1000]

[OnName num="elf_man"]
"...! Ugh!"
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『倒れる』
[WAIT time=1000]


[BG f="b_05_2.ui" time=1000]


The elf man collapsed on the spot. He was attacked from behind by someone.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude263"]
[OnName num="clolowlude"]
"This is not a good time to go out. You should not be walking around right now."
[cpg cn=true]


[OnName num="kousuke"]
"My bad..."
[cpg cn=true]


[free time=800]

[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
I looked back at Fia and saw her wide-eyed.
[cpg]


[OnName num="kousuke"]
"Are you okay? You're not hurt, are you?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Fia437"]
[OnName num="fia"]
"I just remembered..."
[cpg cn=true]

[free time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="1/2" time=800]

[VOICE f="Clolowlude264"]
[OnName num="clolowlude"]
"Remembered? Remembered what?"
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia438"]
[OnName num="fia"]
"We elves have a long life. I met Kosuke once before I was reborn."
[cpg cn=true]


[OnName num="kousuke"]
"What?"
[cpg cn=true]


Fia said that the memory of her former encounter with the Demon King before her reincarnation had come back to her.
[cpg]


She said that the Demon King back then, though abhorrent, had a gentle nature.
[cpg]



[FACE method="change_6" pos="1/2"]
[VOICE f="sFia032"]
[OnName num="fia"]
"When I was almost attacked by a demon, you saved me in my past life..."
[cpg cn=true]


Fia told me that I saved her as one of my previous reincarnations.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia440"]
[OnName num="fia"]
"I had wanted to thank you...for saving me."
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude265"]
[OnName num="clolowlude"]
"Hmm. What did the Demon King say then?
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia441"]
[OnName num="fia"]
"Back then he said 'No thanks'. Instead, he said that if we met again somewhere, I should help him next time..."
[cpg cn=true]


[OnName num="kousuke"]
"Oh, I see..."
[cpg cn=true]


Fia had met me before I was reincarnated. I have no memory of it.
[cpg]


[OnName num="kousuke"]
"Forget about it. I'm not asking for your help."
[cpg cn=true]


[FACE method="change_3" pos="1/2"]
[VOICE f="Fia442"]
[OnName num="fia"]
"No. I'm going to help Kosuke."
[cpg cn=true]


Fia looked as if she had made a decision.
[cpg]


[OnName num="kousuke"]
"I said I don't need it."
[cpg cn=true]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************



[FG f="CHA01_p5_01_a.ui" method="change_3"  pos="2/3" time=800]

Fia followed me to my room. She said she was going to help me.
[cpg]


[OnName num="kousuke"]
"If you're not going to do anything, don't force yourself to stay here."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia443"]
[OnName num="fia"]
"I'm thinking about it right now... What would really help you, Kosuke..."
[cpg cn=true]


It's not like Fia to follow my lead without thinking. That's part of what I fell in love with.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



Either way, it's still my burden to bear.
[cpg]

If I'm the Demon King, I should act like the Demon King. That's all.
[cpg]


;//Ｈシーンカット



[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[OnName num="kousuke"]
"Next, I'm going to declare war on humans."
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia465"]
[OnName num="fia"]
"I see..."
[cpg cn=true]


[OnName num="kousuke"]
"My family is human, too. I want the whole world to be mine."
[cpg cn=true]


Fia's expression only grew cloudier.
[cpg]


[OnName num="kousuke"]
"You're not convinced yet? I'd like to conquer as much of the world as possible in its original form."
[cpg cn=true]


[OnName num="kousuke"]
"We'll try to minimize the number of deaths. That's why we're using magic to neutralize them..."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia466"]
[OnName num="fia"]
"Let's stop all this already..."
[cpg cn=true]


[OnName num="kousuke"]
"Stop what? There's no turning back now."
[cpg cn=true]


I was a little annoyed by the incomprehensible Fia and tried to a different approach.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_06_2_l.ui" time=1000]
[WAIT time=1000]


[OnName num="kousuke"]
"Fia, sit here, please."
[cpg cn=true]

[VOICE f="sFia033"]
[OnName num="fia"]
"Uh, what is it...?"
[cpg cn=true]

I sat her down right in front of me and pinned her down from behind. Then...
[cpg]

I cast a summoning spell.
[cpg]


;//========================================
;//●ＣＧ（ヒロインが主人公のすぐ前に居る。さらにその前から触手が伸びている）ev_51
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//人ex２：触手　　　　服ex２：無し
;//場所　：城内＿主人公の部屋
;//時間　：昼
;//========================================

*Scene041

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』

[WAIT time=1000]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[BGM f="bg_h2"]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sFia034"]
[OnName num="fia"]
"W-what are you doing?"
[cpg cn=true]

[OnName num="kousuke"]
"Well, you're not listening to me very well."
[cpg cn=true]

[VOICE f="sFia035"]
[OnName num="fia"]
"Are you going to threaten me with this?"
[cpg cn=true]

She is still resolute, or at least she is trying to be.
[cpg]

But her body seems to be trembling.
[cpg]

[OnName num="kousuke"]
"It's not that I'm trying to do anything. It's just that..."
[cpg cn=true]

[OnName num="kousuke"]
"Tentacles are disgusting, aren't they? You don't want to just be touched."
[cpg cn=true]

I tried to say a lot of things, but still Fia did not break
[cpg]

;**【ＣＧ】 ev_51_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia036"]
[OnName num="fia"]
"Whatever... I don't care what you do to me."
[cpg cn=true]

[VOICE f="sFia037"]
[OnName num="fia"]
"I'll accept anything, as long as I can change your mind."
[cpg cn=true]

[OnName num="kousuke"]
"......"
[cpg cn=true]

How stubborn can she be? It's not easy for me to do this.
[cpg]

Not this way, it's not how I want it to be.
[cpg]

;//Ｈシーンカット


;//ブラックアウト


[STOPBGM]

[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]




I had no choice, so I unsummoned the tentacle creature and asked it to leave.
[cpg]

Then Fia fell silent and said nothing.
[cpg]


[OnName num="kousuke"]
"You love me, don't you, FIa?"
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia485"]
[OnName num="fia"]
"Yes..."
[cpg cn=true]


[OnName num="kousuke"]
"Why don't you obey me? Isn't what I want what you want?"
[cpg cn=true]


She fell silent again for a while. Then Fia opened her mouth.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia486"]
[OnName num="fia"]
"I've figured out why I fell in love with you at first sight..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia487"]
[OnName num="fia"]
"No, it wasn't really love at first sight, was it? But because I have a long life as an elf..."
[cpg cn=true]


She's talking about me before I was reincarnated. She wants to say that the love began there.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia488"]
[OnName num="fia"]
"I know that you are really a kind person. I want you to be the real you again."
[cpg cn=true]


[OnName num="kousuke"]
"What's the real me? I'm doing what I want to do."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia489"]
[OnName num="fia"]
"No, you're not. Maybe out of fear for your life."
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


I couldn't say anything back. I couldn't even deny it out...
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BG f="b_06_3.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





I then gathered Meir and the others.
[cpg]


[OnName num="kousuke"]
"I'm declaring war on humans. If we could conquer the Elven Nation, it should be no problem."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Schartye340"]
[OnName num="schartye"]
"That's a bold and good idea. I agree."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude266"]
[OnName num="clolowlude"]
"Me too. Though it may be a bit premature."
[cpg cn=true]


I knew these two would agree with me. The problem was, Fia, right?
[cpg]

;//;[FO layer="2/2"]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sMeile047"]
[OnName num="meile"]
"Um..., Fia."
[cpg cn=true]

Meir glanced around awkwardly. Fia did not say anything.
[cpg]

[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile048"]
[OnName num="meile"]
"I think I agree... Don't be reckless. Everyone here loves you."
[cpg cn=true]

It's not just the four of us. All the people in the Land of the Demon King have placed their hopes in me.
[cpg]


I believe I understand that.
[cpg]


;//ブラックアウト
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************



[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]


The final battle is near. With this in mind, Fia and I went outside.
[cpg]

[OnName num="kousuke"]
"Hey Fia, do you still love me after all this?"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

When I asked Fia that, her cheeks flushed without saying a word.
[cpg]

[OnName num="kousuke"]
"In the next battle, I might die. I don't plan on it, though."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="sFia038"]
[OnName num="fia"]
'I will not let that happen, and I will make sure that the fight itself does not happen."
[cpg cn=true]

Fia is as stubborn as ever. Then we went straight into the forest bushes.
[cpg]


[SE f="se008"]
;//【ＳＥ】『歩く』

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





;//========================================
;//●ＣＧ（樹のそばに立っているヒロイン）ev_52
;//人物１：ヒロイン１　服装１：着衣
;//場所　：森の茂み
;//時間　：夜
;//========================================

*Scene042

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_52_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sFia039"]
[OnName num="fia"]
"Uh, Kosuke...?
[cpg cn=true]

[OnName num="kousuke"]
"Stay with me."
[cpg cn=true]

I closed in on her. There's a tree behind her and she can't escape.
[cpg]

Not "escape", more like she stayed with me.
[cpg]

;**【ＣＧ】 ev_52_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia040"]
[OnName num="fia"]
"......"
[cpg cn=true]

And Fia closed her eyes. She understood.
[cpg]

I'm sure she already knew what it meant to be taken to a secluded place like this.
[cpg]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]

Then I kissed her on the mouth.
[cpg]

Of course, it was a calculated move, thinking that she might listen to me with this.
[cpg]


;**【ＣＧ】 ev_52_b ***********************
[CG id=13 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia041"]
[OnName num="fia"]
"I'm happy being with you, Kosuke..."
[cpg cn=true]

[OnName num="kousuke"]
"That's good. Fia, please stay by my side forever and ever."
[cpg cn=true]

[VOICE f="sFia042"]
[OnName num="fia"]
"Yes, of course."
[cpg cn=true]


She said this, but lowered his eyes a little. I didn't know what that look meant at the time.
[cpg]

;//Ｈシーンカット

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_11_4.ui" time=1000]
[WAIT time=1000]



Thinking about it, Fia must have been thinking about a lot of things. Like the fact that I've invaded her country.
[cpg]


I guess they thought that if they left me alone, I might actually take over the world.
[cpg]


That's what I thought, and that's why I did this.
[cpg]



[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]



[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************

[window target=true]




[OnName num="kousuke"]
"......"
[cpg cn=true]


I woke up alone. I thought I slept with Fia, but she was gone.
[cpg]


[STOPBGM]
[BGM f="bg_tc"]

[SE f="se009"]
;//【ＳＥ】『走る』

[WAIT time=1000]

[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile356"]
[OnName num="meile"]
"Oh my god, Kosuke! Fia is gone, we cna't find her anywhere!"
[cpg cn=true]


[OnName num="kousuke"]
"What...?"
[cpg cn=true]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城内＿廊下』（昼）******************************************************





I wandered around looking for Fia. Of course, I wasn't the only one looking for Fia.
[cpg]


The whole castle was looking for Fia, but she was nowhere to be found.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMeile049"]
[OnName num="meile"]
"I wonder if she has left the country..."
[cpg cn=true]


[OnName num="kousuke"]
"What do you mean? She can't have run off on her own."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMeile050"]
[OnName num="meile"]
"It's possible, because some of the Harpy people want peace, not invasion."
[cpg cn=true]


So those are the ones who helped her. Did Chartier and the others know about it and just let it happen?
[cpg]


No, now is not the time to blame them. Where did Fia go?
[cpg]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





Later that day, the harpy that had apparently carried Fia had returned.
[cpg]


[OnName num="kousuke"]
"You helped Fia run off?"
[cpg cn=true]


[OnName num="harpy_woman"]
"Yes, it was all Fia's idea, and it was for the good of the country."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye341"]
[OnName num="schartye"]
"I'm missing the point. Just say it."
[cpg cn=true]


[OnName num="harpy_woman"]
"Fia is in Japan right now to tell them the Demon King is about to invade the country."
[cpg cn=true]


[OnName num="kousuke"]
"I see..."
[cpg cn=true]


I knew it would be something like that. She's been trying to keep me from invading Japan.
[cpg]


But even if I did, I could still invade other countries.
[cpg]


It was futile stopgap measure. That's what I thought to myself, but...
[cpg]


[free time=800]


[OnName num="harpy_woman"]
"Now, she is being held hostage in Japan."
[cpg cn=true]


[OnName num="kousuke"]
"What?"
[cpg cn=true]


[OnName num="harpy_woman"]
"I've been dealing with the Japanese demands."
[cpg cn=true]


The main demand was the liberation of the Elven Nation.
[cpg]


And the other demand was that there be no further invasions.
[cpg]


If we don't meet those, Fia will be dead.
[cpg]


Of course, it is a promise that can be broken at any time if Fia is returned...
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude267"]
[OnName num="clolowlude"]
"It's funny..., they are acting on the assumption that the Demon King loves Fia."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile357"]
[OnName num="meile"]
"I think Fia told them about your relationship herself. The fact that Kosuke loves her..."
[cpg cn=true]


[OnName num="kousuke"]
"What does mean...?"
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile358"]
[OnName num="meile"]
"It means she went to Japan to be a hostage."
[cpg cn=true]


The harpy woman nodded. I couldn't say anything.
[cpg]



[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye342"]
[OnName num="schartye"]
"What do we do now? What should we do, Demon King? If we give in here, we'll have to give up the Elven Nation."
[cpg cn=true]


[OnName num="kousuke"]
"I've already decided my answer. There is no substitute for Fia."
[cpg cn=true]


[FACE method="change_5" pos="2/2"]
[VOICE f="Clolowlude268"]
[OnName num="clolowlude"]
"Hey! We've gone to a lot of trouble to rule the Elven Nation."
[cpg cn=true]


[OnName num="kousuke"]
"I don't care about that anymore... I knew this would happen one day."
[cpg cn=true]



;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="cube.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_02_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************


[window target=true]



"I decided to let go of the Elven Nation."
[cpg]


It didn't take me long to make my decision.
[cpg]


I can say that it all started when I fell in love with Fia...
[cpg]


I felt that if the people I loved wanted peace, this was the way it had to be.
[cpg]

[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





No more invasions. I also liberated the Elven Nation.
[cpg]


I think the situation was worse than when the Land of the Demon King was established, let alone world domination.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia515"]
[OnName num="fia"]
"I'm sorry for the trouble I've caused, Kosuke."
[cpg cn=true]


But I was still relieved when I saw Fia had returned.
[cpg]


[OnName num="kousuke"]
"You know what's coming, Fia "
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia516"]
[OnName num="fia"]
"Yes, I do. I'll take any punishment I can get."
[cpg cn=true]


My wish for world domination did not come true, but I was able to protect the people I cared about.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[SE f="se008"]
;//【ＳＥ】『歩く』

[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]



[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
I took Fia to the basement.
[cpg]


[OnName num="kousuke"]
"What I'm going to do now, as you said, is punish you."
[cpg cn=true]


[OnName num="kousuke"]
"I'm not going to just threaten you like I have in the past. You know that, right?"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia517"]
[OnName num="fia"]
"Yes..."
[cpg cn=true]


Then I thought about what Fia hates the most. It was time to try a new summoning spell.
[cpg]

;//Ｈシーンカット


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//＠地下室
[BG f="b_12_4.ui" time=1000]
[WAIT time=1000]

[OnName num="kousuke"]
"You don't seem to like bugs much, do you?"
[cpg cn=true]



[VOICE f="sFia043"]
[OnName num="fia"]
"Not many people would dare to say they like them..."
[cpg cn=true]


[OnName num="kousuke"]
"You're honest. You know you're pushing yourself."
[cpg cn=true]



[VOICE f="Fia540"]
[OnName num="fia"]
"W-well..."
[cpg cn=true]


[OnName num="kousuke"]
"But I'm glad you don't like it."
[cpg cn=true]


I said, and cast a summoning spell.
[cpg]


It's a magic I've never used before and I don't know what it will do.
[cpg]


[OnName num="kousuke"]
"Here we go, Fia. If you stay sane, I will praise you."
[cpg cn=true]



;//========================================
;//●ＣＧ（大量のワーム状の虫が体中を這っている。膣に何匹も入り込まれるヒロイン）ev_54
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：ワーム　　　服装ex：なし
;//場所　：城内＿地下室
;//時間　：夜
;//========================================

*Scene012

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』

[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_54_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia044"]
[OnName num="fia"]
"Oh, my God..."
[cpg cn=true]

[OnName num="kousuke"]
"It's not just a bug. It's more like a slime."
[cpg cn=true]

[OnName num="kousuke"]
"It's an individual that can grow on its own. If we wait long enough, it will multiply."
[cpg cn=true]

[VOICE f="sFia045"]
[OnName num="fia"]
"N-no... Get rid off it, please."
[cpg cn=true]

[OnName num="kousuke"]
"You said I'd be punished. Now you're whining."
[cpg cn=true]

I reminded her, and turned away.
[cpg]

[OnName num="kousuke"]
"Well, I'll let see you later. I'll release you when I come back, so please take good care of him until then."
[cpg cn=true]

;**【ＣＧ】 ev_54_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia046"]
[OnName num="fia"]
"Wait, Kosuke...!"
[cpg cn=true]

This is not as scray as I made it out to be.
[cpg]

When I said it would increase, I only meant it as a scare tactic. In fact, there is no way such a phenomenon will happen.
[cpg]

Maybe Fia knows my bluff.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[STOPBGM]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]



[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]


Then, a few hours later, I let Fia out of the room.
[cpg]


She looked tired, but she hadn't lost the light in her eyes...
[cpg]


[OnName num="kousuke"]
"Are you sorry, Fia?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Fia562"]
[OnName num="fia"]
"Yes..."
[cpg cn=true]


But no matter how much Fia regrets it, it doesn't change the fact that I'm now limited in what I can do.
[cpg]


The Elven Nation is back to normal. It is no longer the territory of the Demon King.
[cpg]


From Fia's point of view, it means that she could protect her homeland.
[cpg]


Maybe Fia is actually very cunning.
[cpg]


And maybe it is we who is being conquered, maybe I'm the one fascinated by her...
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia563"]
[OnName num="fia"]
"Can I help you, Kosuke...?"
[cpg cn=true]


[OnName num="kousuke"]
"No, it's nothing."
[cpg cn=true]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





And then the Land of the Demon King and myself were in a tight spot.
[cpg]


I lost the Elven Nation as my territory and could no longer move freely.
[cpg]


The fact that my life is being targeted hasn't changed. In fact, the situation has worsened.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Clolowlude269"]
[OnName num="clolowlude"]
"It seems that no one is going to invade, but the number of assassins is increasing again."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Meile359"]
[OnName num="meile"]
"I wonder if people are thinking that now is the time to contain Kosuke..."
[cpg cn=true]


[OnName num="kousuke"]
"I see..."
[cpg cn=true]


It could be Fia's fault, but it also could be that I can't be left alone with my world domination ambitions...
[cpg]


That's exactly why I might have died somewhere along the line.
[cpg]


I'm not sure we're in a position to say which was better.
[cpg]


[FACE method="change_2" pos="2/2"]
[VOICE f="Meile360"]
[OnName num="meile"]
"But I think it's good. Kosuke was so dangerous a while ago that I couldn't bear to watch it."
[cpg cn=true]


[OnName num="kousuke"]
"Was that so?"
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Clolowlude270"]
[OnName num="clolowlude"]
"It's true. You really wanted to take over the world, didn't you?"
[cpg cn=true]


When I think about it, I wonder if Fia did a good job of stopping me...
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





Later, I was alone with Fia.
[cpg]


[OnName num="kousuke"]
"Fia, I can't understand what you're thinking inside."
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia564"]
[OnName num="fia"]
"I'm a simple minded person... I just keep thinking that Kosuke is a kind person."
[cpg cn=true]


Maybe she's right. But in the end...
[cpg]


[OnName num="kousuke"]
"I'm in a life-threatening situation. Are you happy with this?"
[cpg cn=true]


Fia didn't nod. I noticed that.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia565"]
[OnName num="fia"]
"I like the Kosuke you are now, just like the you were when you first saved me..."
[cpg cn=true]


She must be talking about my previous reincarnation. I have no memory of that time.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia566"]
[OnName num="fia"]
"Do you hate me now, Kosuke...?"
[cpg cn=true]


[OnName num="kousuke"]
"No. I don't. No, not at all."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Fia567"]
[OnName num="fia"]
"Then..."
[cpg cn=true]


Fia is about to say something. I think she's still attracted to the pheromones.
[cpg]


[OnName num="kousuke"]
"Ah, I'll kiss you. I'm glad you still love me."
[cpg cn=true]

It was like I was the real Demon King.
[cpg]



;//ブラックアウト

[STOPBGM]


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************


[window target=true]



Time passed, and it was night.
[cpg]


Fia and I were cuddling and sleeping. I was with Fia, who was supposed to have betrayed me.
[cpg]


[OnName num="kousuke"]
"You're probably smarter than me..."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia589"]
[OnName num="fia"]
"No, I'm not. You're exaggerating."
[cpg cn=true]


[OnName num="kousuke"]
"I'm not exaggerating. It's like you know exactly what I'm thinking and you act accordingly."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia590"]
[OnName num="fia"]
"It's a coincidence...."
[cpg cn=true]


Fia is humble. But maybe that's exactly how the lover of the Demon King should be.
[cpg]


I didn't achieve world domination, but I felt I had something more important.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia591"]
[OnName num="fia"]
"When I'm with you, Kosuke... I kind of feel nostalgic."
[cpg cn=true]


[OnName num="kousuke"]
"You said that. You met me before I was reincarnated, didn't you?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia592"]
[OnName num="fia"]
"Yes. Looking back, I've been in love with you since then."
[cpg cn=true]


"So you're saying that even though I died once, your love was fulfilled. Maybe it's romantic, I don't know."
[cpg]


But for me, I'm just happy to be with Fia.
[cpg]


It's not how we got here that matters to me, it's what I'm doing now that matters.
[cpg]


Of course, there was an attempt on my life. And I'm far from safe.
[cpg]


Even so, I was happy to be spending time with Fia.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia593"]
[OnName num="fia"]
"My species lives quite a long time... Maybe Kosuke will pass before I do..."
[cpg cn=true]


[OnName num="kousuke"]
"Then, next time I'm reborn, let's be together again."
[cpg cn=true]


I said without hesitation. Fia smiled and replied...
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia594"]
[OnName num="fia"]
"You're right. I was about to say the same thing."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//ＥＮＤ　ヒロイン１征服ルート



[WAIT time=100]
[jump storage="epend.ks" target="*start"]
[WAIT time=100]
;[s]
[WAIT time=100]
[WAIT time=100]


;//==============================

