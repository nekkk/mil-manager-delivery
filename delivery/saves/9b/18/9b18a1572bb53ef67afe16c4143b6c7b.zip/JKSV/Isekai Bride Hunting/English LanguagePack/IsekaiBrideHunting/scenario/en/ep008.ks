

;//==============================
;//４、クロロウルード

*start

*ep008
*IseSel09_4|Demon King x Kullulu-Urd

[SCENE id=8]


I thought of Kullulu.
[cpg]


I thought I needed her help, so I summoned her.
[cpg]



;//ブラックアウト
[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Clolowlude276"]
[OnName num="clolowlude"]
"What can I do for you? I can't believe the Demon King himself summoned me."
[cpg cn=true]


I didn't know how to start. But there was no point in beating around the bush.
[cpg]


I was at a loss for words, so I just said what I was thinking.
[cpg]


[OnName num="kousuke"]
"I'm thinking of...conquering the world. And I want you to help me, Kullulu."
[cpg cn=true]


Kullulu and I plotted about how to conquer the world.
[cpg]


Kullulu is also skilled in magic. If we worked together, we could destroy the Elven Nation.
[cpg]


If we did that, then my main concern, or rather the concern that wants to kill me, will be gone for good.
[cpg]


Of course, if we expanded our territory, there's the risk that other countries may come after us...
[cpg]


What a pipe dream..., and I didn't know if Kullulu was truly on board or not.
[cpg]


Of the four, I think I'm the one who prefers to fight. That said..., will they all agree with me?
[cpg]


As I kept quiet, thinking about this, Kullulu laughed.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude277"]
[OnName num="clolowlude"]
"Okay, let's do it. Let's take over the world. You're the Demon King, you should be able to do that."
[cpg cn=true]


Her words were without hesitation. I was relieved.
[cpg]


[OnName num="kousuke"]
"I see..."
[cpg cn=true]


In the end, Kullulu also seemed to be on board. We were both in agreement.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude278"]
[OnName num="clolowlude"]
"But..., you could have confided in Chartier about that."
[cpg cn=true]


Chartier... It's not that I didn't think of her.
[cpg]


But I still wanted to rely on Kullulu... I don't know why.
[cpg]


Kullulu and I have an unusual relationship. Maybe there was some kind of love for her inside of me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude279"]
[OnName num="clolowlude"]
"Are you really okay with me? I'm afraid I can't bring you happiness."
[cpg cn=true]


Kullulu was saying something strange and I wanted to know why.
[cpg]


[OnName num="kousuke"]
"What's this about...?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude280"]
[OnName num="clolowlude"]
"Come with me. I'll tell you everything about my dark secret."
[cpg cn=true]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************



;//上下に黒帯を入れてください

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]

[BG f="b_07_4_l.ui" time=1000]


I followed Kullulu to her room.
[cpg]

[SE f="se002"]
;//【ＳＥ】ドア開く
[WAIT time=1000]

[OnName num="kousuke"]
"What is this...?"
[cpg cn=true]


She had a lot of good luck items in her room, some of which looked like good luck charms and some of which looked like they had been bought in Japan.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Clolowlude281"]
[OnName num="clolowlude"]
"I know a lot about Feng Shui, though it's a mixture of customs from my world and this world."
[cpg cn=true]


Feng shui... How does a demon like her know so much about feng shui?
[cpg]


[OnName num="kousuke"]
"Why are you going to these lengths?"
[cpg cn=true]


Kullulu's expression darkened. There must be some deeper reason.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude282"]
[OnName num="clolowlude"]
"I've been involved in a few fights in my life. But I've never won."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude283"]
[OnName num="clolowlude"]
"I bring misfortune. Some demons are known for that sometimes."
[cpg cn=true]


That's absurd. Bringing misfortune is such a superstitious concept.
[cpg]


[OnName num="kousuke"]
"Why are you so worried? You think we can't win with you around?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude284"]
[OnName num="clolowlude"]
"A little... I know misfortune doesn't care who you are."
[cpg cn=true]


Kullulu seemed anxious. I wondered if I could distract her.
[cpg]


[OnName num="kousuke"]
"There's nothing to be anxious about... It's what everyone thinks when they're lonely or things go wrong."
[cpg cn=true]


Kullulu looked dejected. I felt like my words didn't reach her properly.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude285"]
[OnName num="clolowlude"]
"I doubt it. I'm thinking the misfortune I bring is all too real."
[cpg cn=true]


[OnName num="kousuke"]
"You're feeling lonely, aren't you? I'll make you feel better."
[cpg cn=true]

[FG f="CHA04_p7_01_a.ui" method="change_5"  pos="2/3" time=800]
;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

With that, I hugged her. Kullulu didn't seem to mind.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clolowlude286"]
[OnName num="clolowlude"]
"It's a good thing you're here to comfort me, Demon King..., you are still kind after everything that's happened."
[cpg cn=true]


Even with that being said, I'm willing to do things that aren't kind.
[cpg]





[FACE method="change_1" pos="2/3"]
[VOICE f="sClolowlude015"]
[OnName num="clolowlude"]
"If you're going to make me feel better, then I need a favor."
[cpg cn=true]


[OnName num="kousuke"]
"What is it?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sClolowlude016"]
[OnName num="clolowlude"]
"Do you know how to use healing magic? I've got a bit of a stiff shoulder."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sClolowlude017"]
[OnName num="clolowlude"]
"I've been so uptight after all that's happened..."
[cpg cn=true]


[OnName num="kousuke"]
"Oh. Well, that's no problem."
[cpg cn=true]


And then I cast a spell that was not recovery magic.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


;//========================================
;//●ＣＧエロ（巨大な蛸に襲われるヒロイン。仰向けで体を絡められ、膣を犯される）ev_66
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：巨大な蛸　　服装ex：無し
;//場所　：城内＿ヒロイン４の部屋
;//時間　：夜
;//========================================

*Scene056
[WAIT time=500]

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』

[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_66_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=100]


I cast a summoning spell. The legs of an octopus crawled over her body.
[cpg]

[VOICE f="sClolowlude018"]
[OnName num="clolowlude"]
"Hey! Why are you doing this?"
[cpg cn=true]

She looked at me in surprise, but I tried to play it off.
[cpg]

[OnName num="kousuke"]
"Why? I thought I'd give you a shoulder rub if your shoulders were stiff."
[cpg cn=true]

[VOICE f="sClolowlude019"]
[OnName num="clolowlude"]
"I didn't mean it like that. Hey, stop it...!"
[cpg cn=true]

She was reluctant. But I wasn't about to back down.
[cpg]

I wondered if she remembered that this had happened once before.
[cpg]

[OnName num="kousuke"]
"You never learn, do you? Have you forgotten about the massage?"
[cpg cn=true]

[VOICE f="sClolowlude020"]
[OnName num="clolowlude"]
"No, I haven't forgotten, so that makes it even worse!"
[cpg cn=true]

That's true. In that case she must have expected something like this could happen.
[cpg]

;**【ＣＧ】 ev_66_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sClolowlude021"]
[OnName num="clolowlude"]
"I didn't think you'd do it again."
[cpg cn=true]

[OnName num="kousuke"]
"It's different this time. This time it's an octopus."
[cpg cn=true]

Hearing my excuse, Kullulu became even angrier.
[cpg]

[VOICE f="sClolowlude022"]
[OnName num="clolowlude"]
"It's the same thing...!"
[cpg cn=true]

I scratched my head. But since I've summoned it...
[cpg]

I didn't break the summoning spell for a while.
[cpg]




;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************



;//上下に黒帯を入れてください

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]



[cpg cn=true]
[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sClolowlude023"]
[OnName num="clolowlude"]
"Why does the Demon King do such things?"
[cpg cn=true]


[OnName num="kousuke"]
"You could say it's just a hobby. It seems like I was like this in my previous life."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude317"]
[OnName num="clolowlude"]
"Is that so? Did you hear that from Chartier?"
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. She knows who I was before I was reincarnated."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude318"]
[OnName num="clolowlude"]
"......"
[cpg cn=true]


Kullulu looked a bit sad. Maybe she's a little jealous of Chartier.
[cpg]


No matter how much time we spend together, Kullulu doesn't know who I was before I was reincarnated.
[cpg]


We also probably had a difference in life span. Just as I was thinking that...
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude319"]
[OnName num="clolowlude"]
"I don't know anything about the previous Demon King. But ......"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude320"]
[OnName num="clolowlude"]
"I've admired you since before I met you."
[cpg cn=true]


That's right. For Kullulu, I'm a destined lover.
[cpg]


[OnName num="kousuke"]
"You should be more honest with me. Tell me you love me."
[cpg cn=true]


Kullulu fell silent. I guess she's not going to be honest there.
[cpg]


I decided to do more to get those words out of her.
[cpg]


I think the body comes before the mind.
[cpg]


[OnName num="kousuke"]
"Your shoulders must still feel stiff. How about another demon massage?"
[cpg cn=true]

;//＠使えそうなため残しておく
[FG f="CHA04_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sClolowlude024"]
[OnName num="clolowlude"]
"I don't want one...! Did you not see my reaction earlier?"
[cpg cn=true]


[OnName num="kousuke"]
"I'm doing it because I saw your reaction earlier."
[cpg cn=true]

;//＠使えそうなため残しておく
[FACE method="change_4" pos="2/3"]

[VOICE f="sClolowlude025"]
[OnName num="clolowlude"]
"Oh my God! That's enough!"
[cpg cn=true]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_11_4.ui" time=1000]
[WAIT time=1100]
;//【ＢＧ】『空』（夜）******************************************************



And so the night went on.
[cpg]


I was so happy at this time that I didn't want it to end...
[cpg]


But no matter how much I wished, time would not stop.
[cpg]


My life was always in danger, and there was always the possibility that this country would be destroyed.
[cpg]



;//上下の黒帯を外してください

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]

[STOPBGM]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





The time for battle was drawing nearer by the minute. We were getting ready to face the Elven Nation.
[cpg]


The battle would soon begin. That's where it will all come to an end.
[cpg]


We will also find out if Kullulu's curse was real or not....
[cpg]


When Kullulu and I were alone, Kullulu opened her mouth hesitantly.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude351"]
[OnName num="clolowlude"]
"You know, Demon King... I've been in love with you since...a long time ago."
[cpg cn=true]


[OnName num="kousuke"]
"You've said it before, about your admiration and divination."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clolowlude352"]
[OnName num="clolowlude"]
"Yes. There was the demon tribe's divination..., and it seems like I was in love with you before I even met the Demon King..."
[cpg cn=true]


Kullulu wasn't blushing blushing. Rather, she looked pale.
[cpg]


It wasn't a smile. Her face was pale and didn't match her words.
[cpg]


[OnName num="kousuke"]
"So, how did you like meeting me after all?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude353"]
[OnName num="clolowlude"]
"I had high expectations, but you turned out to be the Demon King I had imagined. You look the part now too."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
And then, she lowered his face a little. There's something off about it.
[cpg]


[OnName num="kousuke"]
"What's wrong...? You don't look so good."
[cpg cn=true]


It's as if there's a big secret hidden in there. So I asked her about it.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude354"]
[OnName num="clolowlude"]
"Yes... There was a bit more to the divination."
[cpg cn=true]


A continuation. Is there something she hadn't told me?
[cpg]


[OnName num="kousuke"]
"Tell me."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude355"]
[OnName num="clolowlude"]
"I'm going to spend my life with the Demon King, but there will be great trials ahead..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude356"]
[OnName num="clolowlude"]
"They say that a small difference in judgment could tear us apart."
[cpg cn=true]


So that's what they told her. It may just be fortune-telling...
[cpg]


I couldn't say anything about it. No, I wanted to try to reassure her even if there was nothing I could say.
[cpg]


[OnName num="kousuke"]
"There's need to worry. It's just a divination."
[cpg cn=true]


I patted Kullulu on the head. Even so, I could see that she was frightened.
[cpg]


Maybe it's true that she brings misfortune to people.
[cpg]


I can only imagine what kind of life she has led so far.
[cpg]


Still, she must be so anxious about possibly losing this battle.
[cpg]


I guess I need to take her anxiety into account.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_11_1.ui" time=1000]
[WAIT time=1100]
;//【ＢＧ】『空』（朝）******************************************************




But the more I listened to her words, the more anxious I became. The day of the battle was approaching.
[cpg]


If everything goes according to plan, I don't think we will be defeated by the Elven Nation.
[cpg]


Even as I thought this, my anxiety grew.
[cpg]



[STOPBGM]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_de"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************





And then, it was the decisive battle against the Elven Nation. Originally, the elves had lost the power of their magic soldiers, and the fight seemed to be one-sided...
[cpg]


That's what I had thought, but other countries had come to the Elven Nation's aid.
[cpg]


And these other countries... They weren't other demi-human countries.
[cpg]


Not the demi-human countries that had merged with this world, but the human countries.
[cpg]


Modern weapons stood in our way.
[cpg]


[OnName num="kousuke"]
"What the hell is going on?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Fia602"]
[OnName num="fia"]
"I don't understand...how the world can be so hostile towards Kosuke."
[cpg cn=true]


No way. I didn't think this was possible.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Schartye514"]
[OnName num="schartye"]
"It's as if some unseen force is at work...! What happens to the Elven Nation shouldn't matter to humans."
[cpg cn=true]


Is this what Kullulu was talking about...?
[cpg]


;//画面赤く

[SE f="se020"]
;//【ＳＥ】『連続爆発』

[transition target={true} rule="amamori2.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="red.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.png" color={0x000000ff} time=1]
[WAIT time=1500]
[STOPBGM]





The Demon King's army was defeated by weapons. The word "defeated" was not enough.
[cpg]


We, who had turned against the world, rushed back to escape.
[cpg]


At that stage, there were quite a few deaths. It would take a long time to rebuild.
[cpg]


The morale of the entire army was also down. It was at that time...
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1500]

[stopse g=2]
;//通常se

[BGM f="bg_si"]
;//ブラックアウト

[BG f="b_11_3.ui" time=1000]
[WAIT time=1100]
;//【ＢＧ】『空』（夕方）******************************************************




The country of the Demon King was attacked directly. It was a horrible sight.
[cpg]


A large number of weapons were pouring down, and the attack was unrestrained.
[cpg]


It was so bad that no one could live in the Land of the Demon King. The Land of the Demon King was so desolate that it was unlikely that people would ever come back.
[cpg]


They were scattered, and the Land of the Demon King became extinct.
[cpg]


Fia also. Meir too... They were also scattered.
[cpg]






[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『草原』（夕方）******************************************************





I ran for my life. It was no longer a town or village, but the plains of the Land of the Demon King.
[cpg]


The three of us, me, Chartier, and Kullulu, were walking.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye515"]
[OnName num="schartye"]
"I guess I was wrong about  everything... Demon King. I'm not sure if you can even call yourself the Demon King now."
[cpg cn=true]


Chartier smiled softly as she said that.
[cpg]


[OnName num="kousuke"]
"Chartier..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye516"]
[OnName num="schartye"]
"My ambitions were crushed. If everything went as it was supposed to, I would have reigned second in this world."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye517"]
[OnName num="schartye"]
"Maybe that was never going to happen in the first place since you fell in love with Kullulu-Urd."
[cpg cn=true]


Chartier looks at Kullulu. Kullulu looked sad.
[cpg]

[free time=800]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Clolowlude357"]
[OnName num="clolowlude"]
"Chartier... Don't say that."
[cpg cn=true]


Kullulu must be riddled with guilt. Even though she didn't do anything.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="Schartye518"]
[OnName num="schartye"]
Just so you know, I don't hold a grudge against Kullulu-Urd. I accept it as fate."
[cpg cn=true]


Kullulu bit her lip in frustration. Then...
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye519"]
[OnName num="schartye"]
"In any case, farewell. We will never meet again."
[cpg cn=true]


[move from="1/2" to="4/2" ease="easeInOutSine" time=2000]

Chartier was leaving me. She was no longer at my side.
[cpg]


Kullulu was still with me.
[cpg]



[free time=1000]
;//[BG f="black.ui" time=1000]
[BG f="b_10_4_up.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト


;//【ＢＧ】『森の中っぽいの』（夜）******************************************************




If they find us, they will kill us. We hid ourselves in the woods and just waited for the heat to die down.
[cpg]


We waited, not knowing if that day would ever come...
[cpg]


I couldn't help but love Kullulu. And there may not be much time left.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude358"]
[OnName num="clolowlude"]
"I'm scared.., Demon King. I dreamt that you are going to die."
[cpg cn=true]


[OnName num="kousuke"]
"Don't worry. You said it yourself, I have bad luck."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clolowlude359"]
[OnName num="clolowlude"]
"Even so..."
[cpg cn=true]


Kullulu was looking worried. I thought I'd try to distract her a little.
[cpg]

[FG f="CHA04_p7_01_a.ui" method="change_4"  pos="2/3" time=800]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[OnName num="kousuke"]
"Forget about it for now. Come on, Kullulu."
[cpg cn=true]


I said and put my lips on Kullulu's.
[cpg]






;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************



Kullulu and I..., the two of us kept hiding.
[cpg]


We've been hiding, but never apart from each other.
[cpg]


If we thought about running away, it might be better to run away separately, but still...
[cpg]


I wanted to be with Kullulu.
[cpg]


Without her, I felt like I had nothing.
[cpg]


That's how much I loved Kullulu.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_09_2.ui" time=1000]
[WAIT time=1500]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************





Several days and nights came and went.
[cpg]


Even Kullulu was drained of magical power from the battle with the Elven Nation and could not use any magic to move around.
[cpg]


[OnName num="kousuke"]
"If they find us, they're not going to show us any lenience."
[cpg cn=true]


I can't help but say that. Kullulu made a bitter face.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Clolowlude385"]
[OnName num="clolowlude"]
"Don't say that... I don't want to imagine that."
[cpg cn=true]


While talking about this, we continue to run away.
[cpg]


I guess the most terrifying thing for Kullulu is not that she will die.
[cpg]


What's more terrifying is that I'm going to die....
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_09_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************





As we ran from our pursuers, Kullulu and I confirmed our love.
[cpg]


[OnName num="kousuke"]
"We're going to go together. I will not let Kullulu die alone."
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Clolowlude386"]
[OnName num="clolowlude"]
"That's how I feel, too. If I lose you, I probably won't be able to live."
[cpg cn=true]


Even as we talked, we had nowhere to go.
[cpg]


We survived by scavenging for food in what used to be villages and towns, but we were barely making ends meet.
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト



[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『空』（夜）******************************************************



We were losing hope. We were helplessly impatient, but there was nothing we could do.
[cpg]


We couldn't just run away forever. We were ready for it.
[cpg]


Finally, the day I had been dreading arrived.
[cpg]


[STOPBGM]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=100]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************

[window target=true]




In the end, we were caught in the Land of the Demon King. It seemed that elven pursuers were all over the Land of the Demon King.
[cpg]


They went to such lengths to capture us. Maybe that's the fate of the Demon King.
[cpg]


In any case, it was impossible to escape from our elven pursuers. Both me and Kullulu were seized.
[cpg]


It was time for me and Kullulu to be separated. There was something about it that made Kullulu and me give up.
[cpg]


Kullulu didn't put up any more of a fight than she had to, and neither did I.
[cpg]


No matter what we did here, our fate would not change.
[cpg]


The elves were proud of their victory and said to me...
[cpg]


[OnName num="elf_soldier"]
"Don't think you can die. We'll make it worse."
[cpg cn=true]


Please don't do anything terrible to Kullulu at least. That's how I felt.
[cpg]


[OnName num="kousuke"]
"Kullulu..."
[cpg cn=true]



[VOICE f="Clolowlude410"]
[OnName num="clolowlude"]
"Demon King... I love you."
[cpg cn=true]



;//ブラックアウト
[STOPBGM]

[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（夜）******************************************************


[window target=true]



After we were captured, we were brought to the Elven Nation.
[cpg]


I was held captive and had no chance to escape.
[cpg]


I was wondering what was going to happen to me and if I was going to be killed soon...
[cpg]


The elves seemed to be unable to kill me due to the power of the Demon King.
[cpg]


I heard that they ended up deciding to seal me up.
[cpg]


The seal may be broken after many years, but apparently the immediate crisis could be averted...
[cpg]


The seal was said to last for ten thousand years.
[cpg]



[BG f="white.ui" time=1000]
[WAIT time=1000]



Ten thousand years. It's a tremendous amount of time..., so much time that Kullulu will probably not be around when I wake up.
[cpg]



[free time=1000]
;//[BG f="black.ui" time=1000]
[BG f="e_01_3.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト




I'm under a spell that will seal me in for ten thousand years. Fia, Meir, Chartier...
[cpg]


...and even Kullulu will die without ever seeing me again.
[cpg]


[OnName num="kousuke"]
"Sigh..."
[cpg cn=true]


Just before the sealing. I was in a place that looked like a church.
[cpg]


I guess technically it's not a church, but a building to seal me in.
[cpg]


I took a deep breath. There are a lot of elven wizards surrounding me.
[cpg]


Strangely enough, I didn't feel sad.
[cpg]


I can hear the voices of several elves chanting spells.
[cpg]


It's not like I'm going to die, some part of me might think.
[cpg]


Still, I'll never see Kullulu again. No matter what kind of demon you are, you will not be able to live for 10,000 years.
[cpg]


I don't think this world will be the same in 10,000 years.
[cpg]


My consciousness was fading. Finally, I thought I saw a figure that looked like Kullulu.
[cpg]



[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Clolowlude411"]
[OnName num="clolowlude"]
"Demon King...! Wait, don't leave me!"
[cpg cn=true]


[free time=1000]
;//画面白く

;//＠
[SE f="se016"]
;//【ＳＥ】状態異常魔法

[window target=false]
[transition target={true} rule="dark.webp" color={0xffffffff} time=2000]
[WAIT time=2100]
[BG f="white.ui" time=10]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0xffffffff} time=1]
[WAIT time=1]

[WAIT time=1000]
[STOPBGM]

[window target=true]


[BG f="black.ui" time=1000]
[WAIT time=150000]
;//ブラックアウト


I lost consciousness... At least, I think I lost it.
[cpg]


From that point on, I didn't wake up for 10,000 years.
[cpg]


But the next awakening felt like it came quickly.
[cpg]


;//画面白く
[window target=false]





[transition target={true} rule="dark.webp" color={0xffffffff} time=2000]
[WAIT time=2500]
[BG f="white.ui" time=1]

[WAIT time=200]
[transition target={false} rule="dark.webp" color={0xffffffff} time=1]
[WAIT time=100]
[BGM f="bg_d3"]

[window target=true]

It was just like going to bed and waking up from sleep.
[cpg]



How much time had passed? No, 10,000 years had passed, I thought..., and I got up.
[cpg]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ
[WAIT time=1100]


My restraints were tattered and ready to be removed.
[cpg]

[BG f="b_09_6.ui" time=1000]
[WAIT time=2000]



The building that was probably made for me is also weathered and tattered.
[cpg]


I woke up in a desolate place, and next to me was...
[cpg]

[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

Kullulu was there. SHe looked the same as she did before I was sealed away.
[cpg]


[OnName num="kousuke"]
"Why are you here...?"
[cpg cn=true]


Kullulu laughed with tears in her eyes.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude412"]
[OnName num="clolowlude"]
"At the moment of the seal..., I jumped to your side."
[cpg cn=true]


Oh. I see. That's what happened.
[cpg]


[OnName num="kousuke"]
"Don't be absurd... You weren't supposed to wake up with me."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clolowlude413"]
[OnName num="clolowlude"]
"Yeah, I know."
[cpg cn=true]


As she said this, Kullulu was in tears.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude414"]
[OnName num="clolowlude"]
"I don't think any of my friends from that time are still alive..."
[cpg cn=true]


[OnName num="kousuke"]
"You're right. No matter how long they live, there's no way Fia or Chartier would still be around..."
[cpg cn=true]


Meir is even more unlikely. Even so...
[cpg]


[FG f="CHA04_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Clolowlude415"]
[OnName num="clolowlude"]
"But we're still together, Demon King."
[cpg cn=true]


Only Kullulu was here.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





That's what I wanted. And there was only one thing that Kullulu wanted.
[cpg]

In a desolate land, we kissed for the first time in ten thousand years.
[cpg]


;//========================================
;//●ＣＧエロ（対面座位。主人公を抱きしめるヒロイン）ev_70
;//人物１：ヒロイン４　服装１：裸
;//人物ex：主人公　　　服装ex：裸
;//場所　：荒野
;//時間　：昼
;//========================================

*Scene060

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_70_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sClolowlude026"]
[OnName num="clolowlude"]
"I've always...wished this would happen."
[cpg cn=true]

Kullulu's eyes welled up as she spoke.
[cpg]

[VOICE f="sClolowlude027"]
[OnName num="clolowlude"]
"I wanted to leave all my troubles behind and be with you."
[cpg cn=true]

[OnName num="kousuke"]
"Yeah. It's just the two of us from now on."
[cpg cn=true]

Kullulu nodded and leaned closer to me.
[cpg]

[VOICE f="sClolowlude028"]
[OnName num="clolowlude"]
"A world without an unhappy fate, strife, peace, or anything..."
[cpg cn=true]


[VOICE f="sClolowlude029"]
[OnName num="clolowlude"]
"Wouldn't that suit us?"
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]

;**【ＣＧ】 ev_70_a ***********************
[CG id=19 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sClolowlude030"]
[OnName num="clolowlude"]
"I don't need anything else besides you."
[cpg cn=true]

She had tears in her eyes, but I was about to cry too.
[cpg]

We were still in love, even after all this.
[cpg]

We were happy, I was sure of it.
[cpg]


[VOICE f="sClolowlude031"]
[OnName num="clolowlude"]
"We'll be together forever, and no one can stand in our way."
[cpg cn=true]


[OnName num="kousuke"]
"Who's going to stand in the way...?"
[cpg cn=true]

;**【ＣＧ】 ev_70_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sClolowlude032"]
[OnName num="clolowlude"]
"Hmm. Well, I guess you don't have to worry about that anymore..."
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1500]
[BGM f="bg_si"]
;//ブラックアウト

[BG f="b_11_2.ui" time=1000]



Wilderness as far as the eye can see. Both Kullulu and I were worried.
[cpg]


Who is out there in this world? There are also questions of whether there is food and whether the environment is viable.
[cpg]


However, I felt that I could make it as long as Kullulu was there.
[cpg]


Even if we were really the only ones in the world, it would be impossible to be lonely.
[cpg]



[VOICE f="Clolowlude440"]
[OnName num="clolowlude"]
"Shall we go find some food...?"
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. We can't die, can we?"
[cpg cn=true]


We're going into the wilderness. Our journey alone has begun.
[cpg]



[VOICE f="Clolowlude441"]
[OnName num="clolowlude"]
"Yes. We're going to live, and we're going to keep this love alive."
[cpg cn=true]



;//ＥＮＤ　ヒロイン４征服ルート

[WAIT time=100]
[jump storage="epend.ks" target="*start"]
[WAIT time=100]



;//==============================


