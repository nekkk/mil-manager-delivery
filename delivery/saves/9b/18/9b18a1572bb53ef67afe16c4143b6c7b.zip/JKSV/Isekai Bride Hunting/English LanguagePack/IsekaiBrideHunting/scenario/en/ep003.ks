
;//==============================
;//２、ヒロイン２

*start

*ep003
*IseSel08_2|Peace x Meir

[SCENE id=3]

Meir. The first thing that came to my mind was her.
[cpg]


She's always been close to me, and I've always been comfortable with that, but...
[cpg]


It's not just that. She is originally from Beast Country.
[cpg]


It might be that Meir wanted peace more than anyone else.
[cpg]



;//ブラックアウト
[window target=false]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************


[window target=true]


The next day, I went to Meir.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile204"]
[OnName num="meile"]
"Oh, Kosuke. What's wrong?"
[cpg cn=true]


[OnName num="kousuke"]
"Meir... Can I talk to you for a minute?"
[cpg cn=true]


I told her everything I was feeling.
[cpg]


I want to stop fighting right now. It may not have started yet, but I want to make sure it doesn't happen.
[cpg]


I don't care if I'm not the Demon King anymore. That's how I felt.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile205"]
[OnName num="meile"]
"I see. That's what you were thinking?"
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. I want to hear what Meir has to say. Can you think of a way to do that?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile206"]
[OnName num="meile"]
"Even if you ask me suddenly, I'm not sure..."
[cpg cn=true]


[OnName num="kousuke"]
"Please. I don't care what it is, I think some ideas even come from people who don't know as much about magic as you do."
[cpg cn=true]


I'll just say whatever I can to convince her.
[cpg]


But the fact is, it doesn't matter what I say to Chartier or Kullulu.
[cpg]


I'm sure they're against my desire for peace.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile207"]
[OnName num="meile"]
"I wonder if there is a way to separate the Demon King's power from Kosuke...?"
[cpg cn=true]


[OnName num="kousuke"]
"Well..."
[cpg cn=true]


I, for one, would like it best if such a thing were possible.
[cpg]


I wondered if it was possible. It seems impossible.
[cpg]


If there's such a way, it would be a battle for the Demon King's power.
[cpg]


[OnName num="kousuke"]
"If I could, that would be ideal. You mean I'll be a normal person again?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile208"]
[OnName num="meile"]
"Yes. I guess we'll have to ask Chartier or Kullulu if that's possible."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Meile209"]
[OnName num="meile"]
"Actually, Kosuke... Do you have a moment first?"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


Meir had a dazed look on her face. She seems to have been affected by my magical aura.
[cpg]

[OnName num="kousuke"]
"Sure... But let's go somewhere private, okay?"
[cpg cn=true]


I was also in the mood for it. I wanted to be near her.
[cpg]


[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[window target=true]




We walked out of the castle and headed further out into the city.
[cpg]


We went into the woods where no one would find us.
[cpg]

[VOICE f="sMeile023"]
[OnName num="meile"]
"I feel at home in the woods."
[cpg cn=true]

[VOICE f="sMeile024"]
[OnName num="meile"]
"When I'm with Kosuke, I feel like it's just the two of us."
[cpg cn=true]

[OnName num="kousuke"]
"Yeah."
[cpg cn=true]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




Hopefully, that's true. I've been in too many strange positions I didn't intend to be in.
[cpg]

All I really want is Meir.
[cpg]

As I was walking along, Meir tripped over a tree root and nearly fell.
[cpg]

[VOICE f="sMeile025"]
[OnName num="meile"]
"Ouch!"
[cpg cn=true]

[OnName num="kousuke"]
"Woah."
[cpg cn=true]

;//========================================
;//●ＣＧ（後ろからヒロインの手を掴む主人公）ev_33
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：魔王の国＿森の中
;//時間　：昼
;//備考　：公式サイト三枚目のCGです
;//========================================

*Scene012

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile026"]
[OnName num="meile"]
"Thank you... That was a close one."
[cpg cn=true]

[OnName num="kousuke"]
"Y-yeah..."
[cpg cn=true]

This probably looks kind of awkward now.
[cpg]

I can feel Meir's body heat. Is she a little taller than a human being because she is a beast?
[cpg]

I wonder what she thinks about this situation.
[cpg]

I really do think..., Meir has a great figure.
[cpg]

;**【ＣＧ】 ev_33_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile027"]
[OnName num="meile"]
"Hehe... Kosuke's hands are warm, aren't they?"
[cpg cn=true]

[OnName num="kousuke"]
"Is that so? I feel like your hands are warm."
[cpg cn=true]

[VOICE f="sMeile028"]
[OnName num="meile"]
"Maybe so. Beasts tend to have a higher body temperature."
[cpg cn=true]

I wondered if that was true, but a silence ensued that I couldn't quite understand.
[cpg]

We both felt like we wanted to say something, but couldn't.
[cpg]

[OnName num="kousuke"]
"How long are you going to stay like that?"
[cpg cn=true]

;**【ＣＧ】 ev_33_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile029"]
[OnName num="meile"]
"Sorry, sorry, I just wanted to hold your hand."
[cpg cn=true]

[OnName num="kousuke"]
"Well then, let's just hold hands."
[cpg cn=true]

[VOICE f="sMeile030"]
[OnName num="meile"]
"Yeah. Sure."
[cpg cn=true]

Then we can hold hands normally.
[cpg]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//Ｈシーンカット


[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Meile233"]
[OnName num="meile"]
"Hey, Kosuke... Do you like me?"
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. I like you, Meir."
[cpg cn=true]

[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Meile234"]
[OnName num="meile"]
"I see... I'm glad. I love you too, Kosuke"
[cpg cn=true]


I know that Meir likes me. That's because I'm the Demon King.
[cpg]


But what would happen if...I was no longer the Demon King?
[cpg]


[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************


[window target=true]



[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude232"]
[OnName num="clolowlude"]
"Ripping the power out of the Demon King...? That's an interesting idea."
[cpg cn=true]


Later, after consulting with Kullulu, it seemed possible.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude233"]
[OnName num="clolowlude"]
"If anything, it's easier to rip out from the Demon King's power than to just seal it off."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude234"]
[OnName num="clolowlude"]
"If you only seal the magic power, you will be sealing away what makes you the Demon King."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude235"]
[OnName num="clolowlude"]
"There is a risk of damage to the Demon King's body. It's dangerous."
[cpg cn=true]


[OnName num="kousuke"]
"So there's no disadvantage to ripping out the magic power versus sealing it?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude236"]
[OnName num="clolowlude"]
"But then only the stripped magic will exist on its own."
[cpg cn=true]


It's a difficult subject. I'm not really following, and Meir wasn't trying to understand in the first place.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude237"]
[OnName num="clolowlude"]
"I don't know if the magic has a will of its own or not, but it could go out of control."
[cpg cn=true]


[OnName num="kousuke"]
"Y-yeah...?"
[cpg cn=true]


I can't quite picture it. I'm sure it's a big deal.
[cpg]


Only power can run amok. Only the magic that this world can hold will exist on its own, it seems.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************

[window target=true]




We decided to get Chartier's opinion as well.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Schartye180"]
[OnName num="schartye"]
"Once the power is stripped from the Demon King's body, we will have to do something about the embodied Demon King's power itself."
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye181"]
[OnName num="schartye"]
"It might even turn against us. It'll be dangerous to try and hold it back."
[cpg cn=true]


However, it seems that if Chartier and Kullulu were here, it would not be impossible to fight it.
[cpg]


[FACE method="change_7" pos="2/2"]
[VOICE f="Meile235"]
[OnName num="meile"]
"Could we win...?"
[cpg cn=true]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye182"]
[OnName num="schartye"]
"I don't know if we'll win or lose. But if we lose, then we're probably going to die."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



Chartier has also raised other concerns...
[cpg]


This means that if we are successful in fighting and sealing the power of the Demon King...
[cpg]


The issue was that this country would lose material to negotiate with other countries.
[cpg]


;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[window target=true]




I came out to the city. The people of this country have come together for me.
[cpg]


[OnName num="kousuke"]
"What am I supposed to do...?"
[cpg cn=true]

[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
I murmured. Next to me was Meir.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile236"]
[OnName num="meile"]
"Whatever you want to do. I'll be happy if you're happy, Kosuke."
[cpg cn=true]


[OnName num="kousuke"]
"Well..."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]


I felt as if I couldn't feel anything at all.
[cpg]

[free time=1000]

I don't know if I can do as I please. And what will happen to this country as a result of me behaving as I please?
[cpg]


I couldn't imagine anything well.
[cpg]


I guess I'm not in a calm mood...
[cpg]


[VOICE f="Meile237"]
[OnName num="meile"]
"Kosuke..."
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]


Meir hugged me from behind.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile238"]
[OnName num="meile"]
"I'm here for you. Don't worry."
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





Meir doesn't have any special powers.
[cpg]


But it felt more reassuring than what Chartier or Kullulu were saying.
[cpg]

[STOPBGM]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]



[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
We were coming back to my room.
[cpg]


[OnName num="kousuke"]
"What if...I'm not the Demon King anymore?"
[cpg cn=true]


[OnName num="kousuke"]
"You might not be attracted to me anymore. I won't have any pheromones or anything."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile239"]
[OnName num="meile"]
"I told you not to worry. I'll always like Kosuke no matter what."
[cpg cn=true]


[OnName num="kousuke"]
"Why are you so crazy about me...?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile240"]
[OnName num="meile"]
"I don't know, but I think it started with...when I first came on to him."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sMeile031"]
[OnName num="meile"]
"Kosuke, you didn't mind, and you actually looked happy. It made me happy too."
[cpg cn=true]


[OnName num="kousuke"]
"There was a time when that happened..."
[cpg cn=true]




;//ブラックアウト



;//========================================
;//●ＣＧ（主人公にのしかかるヒロイン）ev_34
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城内＿主人公の部屋
;//時間　：昼
;//========================================

*Scene027

[BG f="black.ui" time=1000]
[free time=1000]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile032"]
[OnName num="meile"]
"I'm pretty sure it was something like that..."
[cpg cn=true]

[OnName num="kousuke"]
"I don't think so. It was after we met."
[cpg cn=true]

[VOICE f="sMeile033"]
[OnName num="meile"]
"No? I think I remember what happened with Kosuke pretty well."
[cpg cn=true]

[OnName num="kousuke"]
"I'm pretty sure I remember Meir, too."
[cpg cn=true]

As we talked, I felt her presence very close to me.
[cpg]

Then Meir leaned forward.
[cpg]

;**【ＣＧ】 ev_34_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile034"]
[OnName num="meile"]
"Do you want me to kiss you like this?"
[cpg cn=true]

[OnName num="kousuke"]
"You'd better not. I've heard that my saliva contains magical elements."
[cpg cn=true]

;**【ＣＧ】 ev_34_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=100]

Meir was puzzled and asked if that was really true.
[cpg cn=true]

[VOICE f="sMeile035"]
[OnName num="meile"]
"Who told you that?"
[cpg cn=true]

[OnName num="kousuke"]
"I'm pretty sure it was Chartier."
[cpg cn=true]

[VOICE f="sMeile036"]
[OnName num="meile"]
"If I kiss you, I might fall in love with you even more."
[cpg cn=true]

[OnName num="kousuke"]
"Want to try it? I don't know what will happen."
[cpg cn=true]

We talked and talked, but in the end we didn't kiss.
[cpg]

I didn't want to rush things... I wanted to treasure my time with Meir.
[cpg]

Of course, taking the right steps is not the same thing as treasuring someone.
[cpg]

But...if time is going to pass too quickly, it would be a waste.
[cpg]

I had such a feeling in me.
[cpg]

;//Ｈシーンカット

;//ブラックアウト
[STOPBGM]


*effect|Peace x Meir

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




At night. It was going to take place in my room.
[cpg]

[BG f="e_01_1.ui" time=1000]
[WAIT time=1000]

There was a magic circle on the floor. It was drawn by Fia and Chartier.
[cpg]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1000]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Schartye183"]
[OnName num="schartye"]
"I have to say, I'm not in favor of this."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude238"]
[OnName num="clolowlude"]
"Me too. I don't know what this country will be like without you as the Demon King."
[cpg cn=true]


[OnName num="kousuke"]
" I know, but..."
[cpg cn=true]

[free time=800]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Meile263"]
[OnName num="meile"]
"But there's also the danger of being the Demon King..."
[cpg cn=true]

Meir was not pressured by Chartier and the others.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sFia025"]
[OnName num="fia"]
"I think so too. It's the only way to solve everything peacefully."
[cpg cn=true]

[FACE method="change_1" pos="1/2"]
[VOICE f="sMeile037"]
[OnName num="meile"]
"Fia..."
[cpg cn=true]


And then my powers as the Demon King were stripped away.
[cpg]


[free time=800]

I'm in the center of the magic circle. It seems to be easier than sealing the magic power as the Demon King.
[cpg]


However, this also means that there is another danger.
[cpg]


She also said that the magic power might go out of control.
[cpg]


[STOPBGM]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Schartye184"]
[OnName num="schartye"]
"Here we go. Prepare yourself, Demon King."
[cpg cn=true]


Chartier chants a spell. And...
[cpg]



[SE f="se005"]
;//【ＳＥ】『魔法の音　低め』
[free time=1000]



[BGM f="bg_ma"]

;//画面白く
[BG f="e_01_1.ui" time=1000]
[WAIT time=2000]

[FG f="e_02_2.ui" method="change_1"  pos="3/5" time=1]
[WAIT time=3000]

[BG f="black.ui" time=1000]


;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]


I fell down on the spot. My legs lost their strength.
[cpg]


[SE f="se014"]
;//【ＳＥ】『地鳴りのような音』


[window target=false]
[transition target={true} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=2100]

[BG f="e_01_3.ui" time=1]
[free time=1]
[WAIT time=10]

[WAIT time=200]
[transition target={false} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=1500]

[window target=true]


The only thing that was stripped from my body was my magic power. As expected, the Demon King's power is out of control without anything to contain it...
[cpg]


A black sphere was bubbling away and floating above my fallen body.
[cpg]

;//＠
[SE f="se005"]
;//【ＳＥ】魔法攻撃

Then it shot a beam of light. It's going to attack Meir...!
[cpg]




[SE f="se005"]
;//【ＳＥ】『バリア　金属音のような感じ』





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye185"]
[OnName num="schartye"]
"Oh..., I knew this would happen."
[cpg cn=true]

[stopse g=2]
;//通常se

[SE f="se005"]
;//【ＳＥ】魔法攻撃

[transition target={true} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=1100]

[free time=1]
[BG f="e_01_3.ui" time=1]
[WAIT time=10]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/2" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=1]
;//[FG f="e_02_2.ui" method="change_2"  pos="3/5" time=1]


[WAIT time=200]
[transition target={false} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=1500]


[SE f="se005"]
;//【ＳＥ】『バリア　金属音のような感じ』

[FACE method="change_5" pos="2/2"]
[VOICE f="Clolowlude239"]
[OnName num="clolowlude"]
"What to do, even if you attack back, the Demon King will...!"
[cpg cn=true]



[FACE method="change_3" pos="1/2"]
[VOICE f="Fia297"]
[OnName num="fia"]
"We have to defend ourselves and hold it back."
[cpg cn=true]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=2100]
[free time=1]
[BG f="black.ui" time=1]


I couldn't do anything about it. I didn't even know what to do.
[cpg]


[WAIT time=1000]

[SE f="se008"]
;//【ＳＥ】『歩く』
[BG f="e_01_3.ui" time=1]

[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=1]


[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1000]


But then, Meir approached the black ball..., the Demon King's power that is being held back.
[cpg]


[VOICE f="Fia298"]
[OnName num="fia"]
"Meir! It's dangerous, stay back!"
[cpg cn=true]


I was wondering what Meir was trying to do.
[cpg]

[FACE method="change_2" pos="2/3"]


That's when Meir said something to it. Then...
[cpg]



The Demon King's power subsided as I watched. It stopped attacking.
[cpg]


I don't know what's going on, and I don't know what Meir did.
[cpg]


But Chartier didn't miss the opportunity.
[cpg]



[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]

[free time=1]
[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="1/2" time=1]

[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=1]
[BG f="e_01_3.ui" time=1]



[WAIT time=200]
[transition target={false} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1500]

[window target=true]


[VOICE f="Schartye186"]
[OnName num="schartye"]
"Now!"
[cpg cn=true]


[VOICE f="Fia299"]
[OnName num="fia"]
"Y-yes..."
[cpg cn=true]

[SE f="se005"]
;//【ＳＥ】『バリア　金属音のような感じ』

[FG f="e_02_2.ui" method="change_2"  pos="3/5" time=2000]
[WAIT time=3000]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
;//ブラックアウト



As it is, the power of the Demon King was sealed by the power Fia and the other women.
[cpg]


In the end, I had no idea what Meir had done...
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye187"]
[OnName num="schartye"]
"Hah, hah, We got it...?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Fia300"]
[OnName num="fia"]
"Yes... I think so."
[cpg cn=true]


There was nothing left behind. I guess it is more correct to say that it was erased rather than sealed.
[cpg]


[OnName num="kousuke"]
"Is it gone...?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude240"]
[OnName num="clolowlude"]
"No. It's only a seal, it's invisible in this world."
[cpg cn=true]


[OnName num="kousuke"]
"Really...?"
[cpg cn=true]


I still don't know much about magic.
[cpg]


But I do know one thing for sure. I am no longer the Demon King.
[cpg]



;//ブラックアウト
[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_05_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************

[window target=true]




The people still don't know that the Demon King is gone.
[cpg]


Will they be disappointed? This country may have lost its reason for existence.
[cpg]


But... somehow, it seemed to be inevitable. This is what the Demon King himself wanted.
[cpg]


But what did Meir say to it at that time?
[cpg]


[OnName num="kousuke"]
"Meir... What did you say to it back there?
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile265"]
[OnName num="meile"]
"Nothing. I didn't say anything important."
[cpg cn=true]


[OnName num="kousuke"]
"You must have said something. Obviously, it stopped attacking us."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile266"]
[OnName num="meile"]
"But... you're right. If the Demon King's power has been stripped from you..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile267"]
[OnName num="meile"]
"I was wondering if there was any of your true nature left. So I..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile268"]
[OnName num="meile"]
"I said, 'I love you for who you are as a human being, and I want you to sleep peacefully for now'..."
[cpg cn=true]


[OnName num="kousuke"]
"You said that...?"
[cpg cn=true]


It seems that the power of the Demon King, which seemed to have no substance, had some personality left. She had been appealing to it.
[cpg]


[OnName num="kousuke"]
"Thank you, Meir. Really, I can't thank you enough."
[cpg cn=true]


I thanked Meir and thought about what to do.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile269"]
[OnName num="meile"]
"No need to thank me. More importantly..."
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMeile038"]
[OnName num="meile"]
"Let's just embrace. It's been a long time since you've felt that safe, since no one is trying to kill you."
[cpg cn=true]


[OnName num="kousuke"]
"Well..."
[cpg cn=true]



;//ブラックアウト
[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_07_4.ui" time=1000]

[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************

[window target=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

Meir and I walked back to the castle.
[cpg]


We decided to head to her room. So the two of us could be together.
[cpg]


We have nothing to fear anymore.
[cpg]


[OnName num="kousuke"]
"I suppose we should announce that the Demon King is no longer in power...."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile271"]
[OnName num="meile"]
"Maybe not... Someone in the Elven Nation who is skilled in magic has probably already figured it out."
[cpg cn=true]


That's true. I'm sure that's how they figured out that I was the Demon King.
[cpg]


Thinking that the opposite may also be true... I walked into Meir's room.
[cpg]



[SE f="se002"]
;//【ＳＥ】『ドア開く』




;//ブラックアウト


;//Ｈシーンカット

;//========================================
;//●ＣＧ（キスをするヒロインと主人公）ev_03
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城内＿ヒロイン２の部屋
;//時間　：夜
;//========================================

*Scene031

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
;[Event g="ev_03_0" a=false f=false]
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=100]

The moment came abruptly. Something we couldn't do the other day.
[cpg]

[OnName num="kousuke"]
"This is all moving pretty fast..."
[cpg cn=true]

;**【ＣＧ】 ev_03_a ***********************
[CG id=1 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile039"]
[OnName num="meile"]
"Hmm. We did it. And it's not fast, because we couldn't do it the other day."
[cpg cn=true]

[VOICE f="sMeile040"]
[OnName num="meile"]
"Maybe now I've got your magic."
[cpg cn=true]

[VOICE f="sMeile041"]
[OnName num="meile"]
"Maybe there will be more miracles."
[cpg cn=true]

[OnName num="kousuke"]
"I don't know. It's already a miracle we're both here."
[cpg cn=true]

[VOICE f="sMeile042"]
[OnName num="meile"]
"You're starting to sound like a king. It's sexy."
[cpg cn=true]

[OnName num="kousuke"]
"Well..., It's been a long time since I've become the Demon King."
[cpg cn=true]


;**【ＣＧ】 ev_03_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile043"]
[OnName num="meile"]
"It's weird to say you've become the Demon King. You've been the Demon King since the beginning."
[cpg cn=true]

[VOICE f="sMeile044"]
[OnName num="meile"]
"And now you're not the Demon King, you're just the King."
[cpg cn=true]

[OnName num="kousuke"]
"Yeah. That's right."
[cpg cn=true]

We kissed again while talking about such trivial things.
[cpg]

It's a shame to let such a happy time pass by.
[cpg]

Meir seemed to be thinking the same thing, and wouldn't let me go.
[cpg]


;//Ｈシーンカット



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





The night dawned. I'm no longer the Demon King, but I'm still the King.
[cpg]

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[window target=true]





All over the world, it was reported that the power of the Demon King was gone.
[cpg]


In other words, the world knew that I was no longer a marvel. And this country was no exception.
[cpg]


I thought I would no longer be able to be king, but...
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





The reality was not that simple. It seems that I have the credit of having united the demi-humans.
[cpg]


It seems that this alone is significant in that it has united the scattered demi-humans of various regions.
[cpg]


As the former Demon King, I became a mere King.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile314"]
[OnName num="meile"]
 "I wonder what the name of this country will be."
[cpg cn=true]


[OnName num="kousuke"]
"I'm going to change it back to Beast Country. That's what it used to be."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sFia026"]
[OnName num="fia"]
"I think that's a good idea. The beasts will be familiar with it."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude241"]
[OnName num="clolowlude"]
"I can't believe I'm not the Demon King anymore."
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Clolowlude242"]
[OnName num="clolowlude"]
"If it were me, I would have put my faith in the power of the Demon King, no matter the risk."
[cpg cn=true]


[OnName num="kousuke"]
"It's not that simple, you know. As long as the Demon King's power exists, there will always be fighting."
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="sFia027"]
[OnName num="fia"]
"I guess that's the way it is..."
[cpg cn=true]


Conquering power with power doesn't seem like a good idea in this day and age.
[cpg]


I think I've got it the way I want it.
[cpg]


And Meir was essential to that.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Meile315"]
[OnName num="meile"]
"Hey, Kosuke. By the way, are you free today?"
[cpg cn=true]


[OnName num="kousuke"]
"No, I'm not free... I've got a lot of work to do..."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sFia028"]
[OnName num="fia"]
"Looks like I'm a distraction."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude243"]
[OnName num="clolowlude"]
"Yes it does..."
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]

;//ブラックアウト



[SE f="se004"]
;//【ＳＥ】『ドア閉まる』

[STOPBGM]
[WAIT time=1000]



[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile316"]
[OnName num="meile"]
"Heh. It's just you and me now."
[cpg cn=true]


[OnName num="kousuke"]
"Don't you ever get embarrassed?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sMeile045"]
[OnName num="meile"]
"Why? It's normal for two people who like each other to be together."
[cpg cn=true]


[OnName num="kousuke"]
"Maybe so, but... We're being too obvious."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile318"]
[OnName num="meile"]
"That's fine. I'm ready to be Kosuke's wife."
[cpg cn=true]


What? Don't tell me...
[cpg]


[OnName num="kousuke"]
"I don't think I need to tell you that you're the only one for me."
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile319"]
[OnName num="meile"]
"Hehe... I'm glad."
[cpg cn=true]

;//Ｈシーンカット

;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]




Time passed peacefully.
[cpg]


There was no longer any reason for anyone to try to kill me.
[cpg]


But I'm still the king. I still had a lot of things to do, even if it's peaceful.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile340"]
[OnName num="meile"]
"Hey, Kosuke. Don't spend all your time working, spend some time with me."
[cpg cn=true]


[OnName num="kousuke"]
"I'll see you later... A messenger is coming from the Elven Nation today as well."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile341"]
[OnName num="meile"]
"Hmph, you said later. You better keep your promise."
[cpg cn=true]


Meir is still the same, but maybe I'm still the same.
[cpg]


Just because I'm not the Demon King anymore, doesn't mean that anything is going to change drastically...
[cpg]


Me and Meir lived happily ever after.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_mi"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************

[window target=true]




One day, we were walking together at night in the castle town.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile342"]
[OnName num="meile"]
"It's become a great town, isn't it? Just a while ago, there was nothing here."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile343"]
[OnName num="meile"]
"I don't think the demi-humans have ever been so united, Kosuke."
[cpg cn=true]


[OnName num="kousuke"]
"I think you're right..."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile344"]
[OnName num="meile"]
"It's all thanks to you, Kosuke. You may not be the Demon King anymore, but you'll always be special to me."
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile345"]
[OnName num="meile"]
"I won't let you go. Be prepared."
[cpg cn=true]


[OnName num="kousuke"]
"Aah..."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//ＥＮＤ　ヒロイン２平和ルート

[WAIT time=100]
[jump storage="epend.ks" target="*start"]
[WAIT time=100]
;[s]
[WAIT time=100]
[WAIT time=100]

