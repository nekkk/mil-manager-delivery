

;=========================================================================================

*start

*ep001|A Journey Around the World

[SCENE id=1]

[stflag Cha1flg=1]
[stflag Cha2flg=0]
[stflag Cha3flg=1]
[stflag Cha4flg=0]

[stflag Cha2flg_s=0]
[stflag Cha3flg_s=0]
[stflag Cha4flg_s=0]



[window target=false]

[STOPBGM]

[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[free time=1]
[BG f="b_10_1.ui" time=11]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



And the next morning. I was invited to stay at Meir's house for a while.
[cpg]


Considering what I had done, it seemed natural, but I didn't feel like I did anything.
[cpg]


As I was thinking about this, I was in a daze.
[cpg]


[OnName num="kousuke"]
"It's kind of peaceful..."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile004"]
[OnName num="meile"]
"It's a national holiday today, you know. So people aren't working in the fields today... I think."
[cpg cn=true]


Maybe because I've been asleep for a long time.
[cpg]


But it is a farming village. It's strange to see beasts farming...
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile005"]
[OnName num="meile"]
"But you're an odd one, aren't you? You smell like our world, it's so strange..."
[cpg cn=true]


[OnName num="kousuke"]
"What do you mean...?"
[cpg cn=true]

[window target=false]
[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]


[BG f="b_10_3.ui" time=1000]
[WAIT time=1500]

[WAIT time=100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



I went around the village and tried to find a way to get back to Japan.
[cpg]


It seems that this is the most rural part of Beast Country.
[cpg]


The airport is in the city. But...
[cpg]


There's no point in going there, right? I've been smuggled into a foreign country twice now.
[cpg]


I don't think I can go to the airport and return to Japan properly.
[cpg]



;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く

[BG f="b_10_3_up_l.ui" time=1000]
[WAIT time=1500]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]

[WAIT time=1000]

[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile006"]
[OnName num="meile"]
"I'm overthinking it. If I'm in trouble, why don't I just try and ask for help?"
[cpg cn=true]


As I walked back to my house, Meir greeted me.
[cpg]


[OnName num="kousuke"]
"Where are your parents..? Aren't they off today?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile007"]
[OnName num="meile"]
"They're at church. Since they have a day off."
[cpg cn=true]


You go to church in the evening? I wonder if it's a cross-cultural thing.
[cpg]


[OnName num="kousuke"]
"Aren't you going too, Meir?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile008"]
[OnName num="meile"]
"Well, I've got something I'd rather be doing, you know..."
[cpg cn=true]


Then she invited me in. I wondered what she was thinking when...
[cpg]



[window target=false]

[free time=1000]

[WAIT time=1000]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1500]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=100]
;//ブラックアウト

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


[window target=true]


[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1000]


;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

Meir sat down on the bed in the bedroom.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile009"]
[OnName num="meile"]
"I've been...feeling strange ever since I met you."
[cpg cn=true]


[OnName num="kousuke"]
"What do you mean strange?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Meile010"]
[OnName num="meile"]
"I've never felt this way before. I don't know if this is love."
[cpg cn=true]


Again...? It's the same as when I was at Fia. I can't help but think there's something wrong with my body.
[cpg]


She's never felt this way before, and if that's true, it's even stranger.
[cpg]


She's never been in love with anyone, but she's in love with me...
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile011"]
[OnName num="meile"]
"What's with that expression? Wouldn't a human be happy to hear this?"
[cpg cn=true]


[OnName num="kousuke"]
"N-no...."
[cpg cn=true]


In the end, I'm going to go back to Japan, but I don't think it's a good idea to do anything too suggestive in all these different places.
[cpg]


Although my original purpose was to get a demi-human wife, right?
[cpg]


If someone asked me if Meir is my type, I have to say I do think she's pretty cute.
[cpg]


What should I do...?
[cpg]





;//■選択肢
[switch]
[case "Hit on Meir"]
	[swap]
	[jump target="*IseSel01_1"]
[case "Nothing"]
	[swap]
	[jump target="*IseSel01_2"]
[endswitch]




1. Hit on Meir
2. Do nothing



;//==============================
;//１、メイルを口説く
*IseSel01_1|A Journey Around the World


;//ヒロイン２が攻略対象になる
[stflag Cha2flg_s=1]



[OnName num="kousuke"]
"You don't just say these kind of things to just anyone, right?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile012"]
[OnName num="meile"]
"Of course not. I told you I've never felt this way before."
[cpg cn=true]


[OnName num="kousuke"]
"I started traveling because I wanted a demi-human wife."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile013"]
[OnName num="meile"]
"Then we'd be a good match, wouldn't we?"
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ
[FG f="CHA02_p7_01_a.ui" method="change_6"  pos="2/3" time=800]


We sat down on the bed next to each other and she put her head on my lap.
[cpg]


[VOICE f="Meile014"]
[OnName num="meile"]
"You smell nice... It's soothing."
[cpg cn=true]

;//＠
[FACE method="change_6" pos="2/3"]
[VOICE f="sMeile001"]
[OnName num="meile"]
"Hey..., can I just sleep like this?"
[cpg cn=true]


I wonder if it's okay for me to do this. I wondered the same thing about Fia.
[cpg]


However, there is a part of me that thinks that sinfulness is no longer a problem...
[cpg]

;//Ｈシーンカット


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト

[jump target="*IseSel01_3"]

;//==============================
;//２、何もしない
*IseSel01_2|A Journey Around the World




[OnName num="kousuke"]
"I can't do it after all..., you're not my girlfriend."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile073"]
[OnName num="meile"]
"What? Don't embarrass a girl."
[cpg cn=true]


[OnName num="kousuke"]
"No matter what you say, I can't. I have principles."
[cpg cn=true]


I waited for her parents to come home while I talked it over with Meir.
[cpg]



;//==============================

*IseSel01_3|A Journey Around the World


[window target=false]

[free time=1000]

[WAIT time=1000]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4_up_l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************


[window target=true]



Later, Meir's parents came home.
[cpg]


While I felt sorry to have them serve me dinner again... I knew I had to find a way to get back to Japan as soon as possible.
[cpg]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************


[window target=true]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1500]


Information gathering. That's why I went to the village to ask around...
[cpg]


[OnName num="therianthropy_girl_A"]
"H-hey..., you smell good."
[cpg cn=true]


[OnName num="therianthropy_girl_B"]
"It's true...,and you don't seem like a normal human."
[cpg cn=true]


I've been very popular. I had never experienced anything like this before.
[cpg]


[OnName num="therianthropy_girl_A"]
"If you want, you can come over to my place. I have some delicious herbal tea."
[cpg cn=true]


[OnName num="therianthropy_girl_B"]
"Oh, no fair! I was first."
[cpg cn=true]


[OnName num="kousuke"]
"No, that's not the point. Just tell me how to get back to Japan."
[cpg cn=true]


Unlike in the Elven Nation, they seem to be uninhibited when it comes to love.
[cpg]


I knew I had to find a way back to Japan, but I was also a bit happy about the harem-like situation.
[cpg]


[window target=false]
[BG f="b_10_3.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]

[BG f="b_10_3_up_l.ui" time=1000]
[WAIT time=1000]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]
[WAIT time=1000]


The evening would come again. I know I'm safe as long as I stay here, but if I don't, I won't make any progress.
[cpg]


[OnName num="meile_mother"]
"Well..., if you head north from here, there is a settlement where the Harpies live."
[cpg cn=true]


[OnName num="kousuke"]
"I see..."
[cpg cn=true]


Harpies. Harpies are a species of bird people, right?
[cpg]


If the location is in the north, can I return to Japan from there?
[cpg]


[OnName num="kousuke"]
"Thank you for telling me. I think I'll head to the Harpy Village."
[cpg cn=true]


[OnName num="meile_mother"]
"I see. It's quite a distance, so you'd better take some food with you."
[cpg cn=true]


Meir's mother prepared a lot of things for me. I felt bad.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile074"]
[OnName num="meile"]
"You're really going? No, Kosuke, stay here forever!"
[cpg cn=true]


[OnName num="kousuke"]
"I can't... The elves might be closing in on me."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile075"]
[OnName num="meile"]
"The other girls will be after you. Everyone says Kosuke is cool."
[cpg cn=true]


I'm not sure what to say. I was speechless...
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile076"]
[OnName num="meile"]
"Please stay here just for today. Please."
[cpg cn=true]


[OnName num="kousuke"]
"I guess it can't be helped..."
[cpg cn=true]

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1000]

;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]


That's why I stayed at Meir's house another day.
[cpg]


[OnName num="kousuke"]
"......"
[cpg cn=true]


But I still decided to leave the next day. It's not just that it's bad to stay longer...
[cpg]


I'm not a fan of the idea of the elves coming after me and bothering Meir's family.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[STOPBGM]

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


[WAIT time=1000]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[BG f="b_09_1.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『草原』（朝）******************************************************


[window target=true]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1000]

So before Meir woke up, I left.
[cpg]


I could see that they would say this and that when we parted.
[cpg]


[OnName num="kousuke"]
"This country is so huge..."
[cpg cn=true]


I don't even know how far I have to walk to get to the Harpy village.
[cpg]


There was some kind of sign. But I could barely read the numbers.
[cpg]


I could kind of figure out how much further I had to walk to get to the next village or town.
[cpg]


It looks like I'll have to stay in the field for a day...
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[window target=false]

[BG f="b_09_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『草原』（昼）******************************************************


[window target=true]


;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

It's not easy to walk all day long.
[cpg]


It's hard on my back. If I keep doing this, I'm going to have a lot of new health problems by the time I get to Japan.
[cpg]


And now I'm being treated as a criminal. On top of which, I have to get back to Japan before my work starts.
[cpg]


With that in mind, I kept walking.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_09_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


[window target=true]



And I had to stay in the field along the way.
[cpg]


I was afraid of running out of food, but I was even more afraid of being caught by the elves.
[cpg]


[OnName num="kousuke"]
"Hmmm...?"
[cpg cn=true]


As I was trying to sleep, I felt someone appear in front of me.
[cpg]


As I noticed it... in this empty plain, a demon-like silhouette appeared.
[cpg]



;//クロロウルードの名前を「悪魔」と隠してください





[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1500]
[WAIT time=2000]
[VOICE f="Clolowlude001"]
[OnName num="devil"]
"What...? You don't seem all that strange..."
[cpg cn=true]


No, that should be my line. A demon-like figure was looking down at me.
[cpg]


[OnName num="kousuke"]
"And you are...?"
[cpg cn=true]



;//クロロウルードの名前を表示してください





[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude002"]
[OnName num="clolowlude"]
"I'm Kullulu-Urd. I'm a demon from the underworld."
[cpg cn=true]


[OnName num="kousuke"]
"Really...?"
[cpg cn=true]


I would have been more surprised, but all I could think was, "Really?" I've never met a demon before...
[cpg]


It's not an experience that I was trying to avoid or anything, but I've already been through a lot.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude003"]
[OnName num="clolowlude"]
"Most people would be more surprised."
[cpg cn=true]


[OnName num="kousuke"]
"I'm sleepy. Can we do this later, please?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude004"]
[OnName num="clolowlude"]
"So, you're the guy...Chartier was going on about? This weak-looking guy is really who she was talking about?"
[cpg cn=true]


What was that she was saying before "really"?
[cpg]


[OnName num="kousuke"]
"What do you want from me?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude005"]
[OnName num="clolowlude"]
"It's not about what I want."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude006"]
[OnName num="clolowlude"]
"I don't know where you're headed, but this country is too big to walk across."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah, well..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude007"]
[OnName num="clolowlude"]
" I'm a demon, and I can do magic. I thought you might be interested in that."
[cpg cn=true]


[OnName num="kousuke"]
"Are you going to send me back to Japan...?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude008"]
[OnName num="clolowlude"]
"You can use transference magic to get back to Japan in an instant. But it also consumes a lot of magic power, so it's best not to use it unnecessarily."
[cpg cn=true]


What? She's not going to send me home after all? I rolled over and turned my back on her.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude009"]
[OnName num="clolowlude"]
"Hey! You've got some attitude."
[cpg cn=true]


[OnName num="kousuke"]
"Kullulu, you're not going to help me leave, are you?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude010"]
[OnName num="clolowlude"]
"Don't call me 'Kullulu'. That's too familiar."
[cpg cn=true]


[OnName num="kousuke"]
"Whatever, we have nothing else to talk about if you're not going to help me. Let me sleep."
[cpg cn=true]


Kullulu cleared her throat and then...
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude011"]
[OnName num="clolowlude"]
"My ancestors served the Demon King for generations."
[cpg cn=true]


[OnName num="kousuke"]
"Demon King? I've never heard of him."
[cpg cn=true]


Even though we've merged with another world, I've never heard of any Demon King.
[cpg]


If there was one, wouldn't they try to take over the world?
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude012"]
[OnName num="clolowlude"]
"You haven't heard of the Demon King... Well, that's okay."
[cpg cn=true]


What's okay? I have no idea what's happening.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude013"]
[OnName num="clolowlude"]
"If you go back four generations in my family, you'll find a demon who was queen to the Demon King."
[cpg cn=true]


[OnName num="kousuke"]
"So what's the point? I don't know why you're bragging."
[cpg cn=true]


I was frank, but Kullulu did not stop speaking.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude014"]
[OnName num="clolowlude"]
"The great astrologers of the demon tribe had a divination."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude015"]
[OnName num="clolowlude"]
"I am the one who will be the new queen to the Demon King. So I have always admired the man who would become the new Demon King."
[cpg cn=true]


[OnName num="kousuke"]
"I can't follow. Just get to the point."
[cpg cn=true]


Kullulu blushed a little. I don't know why she blushed there or what she was talking about.
[cpg]



[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_09_2.ui" time=1000]

[WAIT time=1100]
;//【ＢＧ】『草原』（昼）******************************************************

[window target=true]




The next day, Kullulu was still following me around.
[cpg]


[OnName num="kousuke"]
"What do you really want from me?"
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Clolowlude016"]
[OnName num="clolowlude"]
"I'm trying to figure out if you're the right guy for me."
[cpg cn=true]


[OnName num="kousuke"]
"Don't tell me you're in love with me, too..."
[cpg cn=true]


Kullulu didn't answer. This is a bit strange after all.
[cpg]

[free time=800]

She's acting like she has a thing for me. I've never had any luck with humans.
[cpg]


Last night, she was talking about a new Demon Queen...
[cpg]


I don't know why she mentioned the Queen to the Demon King. I don't know what she meant by the new Demon King either.
[cpg]


[OnName num="kousuke"]
"The new Demon King, right? If you're going to be his queen, you might as well go to him."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude017"]
[OnName num="clolowlude"]
"Yes. That's why I'm following you."
[cpg cn=true]


[OnName num="kousuke"]
"You mean, all the way to the Harpy Village...?"
[cpg cn=true]


Kullulu still didn't answer. What is it?
[cpg]

[window target=false]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]

[BG f="b_09_4.ui" time=1000]

[WAIT time=1000]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


[window target=true]



Night came again. Our food supply was slowly dwindling, and I was feeling impatient...
[cpg]

[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
The fact that Kullulu was next to me helped a bit.
[cpg]


If I were to starve to death, I thought, Kullulu could take care of me.
[cpg]


[OnName num="kousuke"]
"Why don't you use transference magic?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude018"]
[OnName num="clolowlude"]
"There are many reasons why you cannot return to Japan immediately. After all, you're..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude019"]
[OnName num="clolowlude"]
"You have a strange aura that attracts others. Call them pheromones, if you will."
[cpg cn=true]


I don't know what she's talking about. I had a lot of questions for Kullulu, but I didn't know where to start.
[cpg]





;//■選択肢
[switch]
[case "What are pheromones?"]
	[swap]
	[jump target="*IseSel02_1"]
[case "I want to go back to Japan."]
	[swap]
	[jump target="*IseSel02_2"]
[endswitch]



1. What are pheromones?
2. I just want to go back to Japan



;//==============================
;//１、フェロモンって何だ？


*IseSel02_1|A Journey Around the World


;//ヒロイン４が攻略対象になる
[stflag Cha4flg_s=1]



[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude020"]
[OnName num="clolowlude"]
"You don't get it? Well, if you don't, that's okay, too. I'm not going to explain everything to you."
[cpg cn=true]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

;//========================================
;//●ＣＧエロ（ヒロインに迫られる。至近距離）ev_07
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：私服
;//場所　：草原
;//時間　：夜
;//========================================

*Scene000|A Journey Around the World

[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]

[STOPBGM]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=100]

With that, she brought her face close to mine. She sniffed me.
[cpg]


[OnName num="kousuke"]
"Hey..., you too?"
[cpg cn=true]


[VOICE f="Clolowlude021"]
[OnName num="clolowlude"]
"You've been through a lot, haven't you? I'm also attracted to...you."
[cpg cn=true]


How does she know that I've been through a lot? While I was wondering about it, she was still pretty close to me.
[cpg]

[OnName num="kousuke"]
"Wait a minute. Just move away from me for now."
[cpg cn=true]

;**【ＣＧ】 ev_07_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sClolowlude002"]
[OnName num="clolowlude"]
"You smell so good, I'd like to smell you some more."
[cpg cn=true]

"I don't know if I can handle that. All this is going on and..."
[cpg]



My body is not normal. I kind of knew that from the incidents with Fia and Meir.
[cpg]


However, the way she is suddenly approaching me so quickly...is just not right.
[cpg]


[OnName num="kousuke"]
"What are you looking for by getting close to me?"
[cpg cn=true]

;**【ＣＧ】 ev_07_b ***********************
[CG id=2 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Clolowlude053"]
[OnName num="clolowlude"]
"You don't even know it yourself, do you? How could you live this long without knowing it?"
[cpg cn=true]


[OnName num="kousuke"]
"Don't leave me hanging. Just tell me."
[cpg cn=true]


[VOICE f="Clolowlude054"]
[OnName num="clolowlude"]
"Please ask Chartier."
[cpg cn=true]


What, she's not going to tell me...?
[cpg]


[VOICE f="sClolowlude003"]
[OnName num="clolowlude"]
"But..., if you're staying up, I'd like to talk and get to know you some more."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah, I want to know about me too."
[cpg cn=true]

;//＠
;[SceneEnd f="sc_005"]

;//ブラックアウト

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="heart.webp" color={0x000000ff} time=1]

[WAIT time=1100]

[BG f="b_09_4.ui" time=1000]

[BGM f="bg_d3"]
[WAIT time=1000]
;//【ＢＧ】『草原』（夜）******************************************************


[window target=true]



After that, Kullulu wouldn't let me sleep. I don't mean that in a funny way.
[cpg]


She seemed to want to tell me something. Kullulu started talking about Chartier.
[cpg]

[jump target="*IseSel02_3"]

;//==============================
;//２、早く日本に帰りたい

*IseSel02_2|A Journey Around the World



[OnName num="kousuke"]
I want to go back to Japan as soon as possible. Please let me go home.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude086"]
[OnName num="clolowlude"]
"It's easy to use transference magic. But I can't let you."
[cpg cn=true]


[OnName num="kousuke"]
"What the...? Do you have feelings for me or something?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude087"]
[OnName num="clolowlude"]
"Don't get cocky. But...you're not wrong."
[cpg cn=true]


So what is it...that makes it seem like no one is attracted to me except demi-humans?
[cpg]


Is there something wrong with my body?
[cpg]



;//==============================


*IseSel02_3|A Journey Around the World


[OnName num="kousuke"]
"Oh, by the way, you mentioned someone named Chartier... Who's that?"
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Clolowlude088"]
[OnName num="clolowlude"]
"You've met her, haven't you? She's the one who put you on the airship."
[cpg cn=true]


It must be the same person. And Kullulu apparently knows Chartier...
[cpg]


Then I've found the fastest way to get back to Japan.
[cpg]


[OnName num="kousuke"]
"If you could, could you tell Chartier...that I want to go back to Japan?"
[cpg cn=true]


[OnName num="kousuke"]
"With her airship, I should be able to get back to Japan."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude089"]
[OnName num="clolowlude"]
"I'd be happy to put you on an airship, but I'm afraid she'll just take you to another country."
[cpg cn=true]


[OnName num="kousuke"]
"Why...?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude090"]
[OnName num="clolowlude"]
"Because Chartier is not going to let you go back to Japan."
[cpg cn=true]


I don't know what she's talking about. But...
[cpg]


It looks like I'll have to return to Japan in something other than her airship.
[cpg]

[window target=false]

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_09_1.ui" time=1000]
[WAIT time=1100]
;//【ＢＧ】『草原』（朝）******************************************************


[window target=true]



I had a lot of questions. But I couldn't overcome my drowsiness, and by the time I woke up, Kullulu was gone.
[cpg]


I walked along the road, still unsure of what was happening.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************



;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1000]


My food supply was running out. At that time, I came across three beast women who seemed to be traveling.
[cpg]


[OnName num="kousuke"]
"Please, can you share some food with me?"
[cpg cn=true]


[OnName num="therianthropy_girl_A"]
"What's this guy...doing here?"
[cpg cn=true]


[OnName num="therianthropy_girl_B"]
"Can you feel it? It's kind of a weird feeling, isn't it?"
[cpg cn=true]


Not again. I don't want to do this anymore, I just want some food...
[cpg]



[window target=false]

[BG f="b_09_3.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『草原』（夕方）******************************************************

[window target=true]




I continued to look for someone who could help me get back to Japan, while I was worn out and almost attacked by the occasional beast.
[cpg]


Then finally...
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[STOPBGM]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（夕方）******************************************************

[window target=true]




[OnName num="kousuke"]
"S-so this is it..."
[cpg cn=true]


I arrived at the site. This must be the village where the Harpy Tribe lives.
[cpg]


Harpies have wings. If I'm lucky, they'll help me return to Japan.
[cpg]



[SE f="se001"]
;//【ＳＥ】『倒れる』





But as I was mulling over the idea, I had run out of energy and collapsed.
[cpg]


I stupidly thought to myself that people really do collapse when they are tired.
[cpg]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="e_01_3.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





In the meantime, I had a dream. I wasn't asleep, it was more like I was in a coma, but I had a dream.
[cpg]


There was someone next to me. I don't know who it is.
[cpg]


I mean, I don't even know who I am. The clothes I see from my perspective are not my taste.
[cpg]


I dream that I am someone else. It was a hazy, yet a strangely familiar scene.
[cpg]


I'm in a place that looks like a castle... Maybe it's not Japan.
[cpg]


I wonder where it is... Many demi-humans are kneeling down to me.
[cpg]


They treated me as if I were a king or something.
[cpg]



;//画面白く

[BG f="white.ui" time=1000]
[WAIT time=100]

[STOPBGM]

When I woke up for a moment, everything was still a bit hazy.
[cpg]


The next time I woke up, I was in a room.
[cpg]


I was in someone's house, lying on a bed.
[cpg]




[window target=false]

[transition target={true} rule="tobira2.png" color={0xffffffff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira2.png" color={0xffffffff} time=1000]

;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く

[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（朝）******************************************************

[window target=true]



[WAIT time=1100]


I got up and walked outside, where I met a harpy woman.
[cpg]


[OnName num="harpy_A"]
"O-oh, you're awake..."
[cpg cn=true]


[OnName num="kousuke"]
"You save me...?"
[cpg cn=true]



[OnName num="harpy_A"]
"Well, it was someone else who found you..., but I had a spare room."
[cpg cn=true]


I guess you could say that she helped me too.
[cpg]


In any case, it seems that the Harpy people are mild-mannered.
[cpg]


I'm glad she wasn't one of those people who would steal everything off a passed out man. I guess they don't have anything to take from me, though.
[cpg]


[OnName num="kousuke"]
"Thank you for your kindness."
[cpg cn=true]



[OnName num="harpy_A"]
"Oh, no. Don't thank me. I'm just doing what anyone would do..."
[cpg cn=true]


[OnName num="harpy_B"]
"Oh! You're awake..."
[cpg cn=true]


[OnName num="harpy_C"]
"How are you feeling? Are you hungry?"
[cpg cn=true]


Seeing me and her talking, other harpies came by. They were all women.
[cpg]


There may be male harpies, but they never came to see me.
[cpg]


I've never been this popular with humans.
[cpg]


There was something odd about them, but I couldn't figure out what it was.
[cpg]


[OnName num="harpy_B"]
"It's not good to keep him all to yourself."
[cpg cn=true]


[OnName num="harpy_C"]
"Come to my house, I'll make you breakfast."
[cpg cn=true]


[OnName num="harpy_A"]
"H-hey!"
[cpg cn=true]


The first girl I met grabbed my hand. It's like we're fighting over it.
[cpg]


[OnName num="kousuke"]
"Don't pull..."
[cpg cn=true]


This uncomfortable feeling has been with me ever since I arrived here in the land of the demi-humans.
[cpg]


I wondered why this was happening. I couldn't find the answer to that question.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（昼）******************************************************


;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1100]

I walked around the Harpy village for a while.
[cpg]


I tried to make arrangements to return to Japan.
[cpg]


The men in the village were sympathetic, but not as kind.
[cpg]


Only the women acted that kind towards me...
[cpg]


I guess, I should have just asked the women for help.
[cpg]


I had a lot to think about, but it looked like I wouldn't have to worry about food for a while.
[cpg]




[window target=false]

[BG f="b_01_3.ui" time=1500]
[WAIT time=1500]
;//【ＢＧ】『ハーピー族の集落』（夕方）******************************************************

[window target=true]


In the end, I didn't meet any of the harpy girl's family members. I wondered about them, so I asked her about it.
[cpg]

[OnName num="kousuke"]
"Do you live alone?"
[cpg cn=true]


[OnName num="harpy_A"]
"Yes, but my parents live just around the corner..."
[cpg cn=true]


[OnName num="kousuke"]
"Why?"
[cpg cn=true]


[OnName num="harpy_A"]
"I have to get married soon..."
[cpg cn=true]



[OnName num="harpy_A"]
"That's why my parents built their house first."
[cpg cn=true]


I wonder if that is possible. I don't know, I guess their culture is different from humans.
[cpg]


[OnName num="kousuke"]
"More importantly..., can I stay at your house again today?"
[cpg cn=true]



[OnName num="harpy_A"]
"Yes. If you're okay with me."
[cpg cn=true]


She looked embarrassed, and her cheeks were strangely red.
[cpg]


She's acting like she is in love with me or something. This is not normal.
[cpg]


[OnName num="kousuke"]
"Hey, how're you feeling right now?"
[cpg cn=true]



[OnName num="harpy_A"]
"What do you mean by that?"
[cpg cn=true]


[OnName num="kousuke"]
"I've seen this happen to demi-humans too many times to count."
[cpg cn=true]


[OnName num="kousuke"]
"Is there something wrong with me? What do you see in me now?"
[cpg cn=true]



[OnName num="harpy_A"]
"There is something magical about you..., you don't seem like a normal person."
[cpg cn=true]


I've been told that, but no matter how many times I thought about it, I couldn't understand.
[cpg]




[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=10]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（夜）******************************************************

[window target=true]
[WAIT time=100]

A few days after that. As I spent time in the Harpy clan's village, this happened...
[cpg]


[OnName num="harpy_A"]
"The stars are beautiful, aren't they...?"
[cpg cn=true]


[OnName num="kousuke"]
"Yes, they are. They don't look this beautiful in Japan."
[cpg cn=true]



[OnName num="harpy_A"]
"You know, Kosuke..., I thought love at first sight didn't exist in this world."
[cpg cn=true]


See? This is what happened, again.
[cpg]


[OnName num="harpy_A"]
"But then I saw Kosuke , and I realized it really does exist."
[cpg cn=true]


[OnName num="kousuke"]
"Love at first sight, huh?"
[cpg cn=true]


Love at first sight, love at first sight. Isn't that what's happening to everyone?
[cpg]



[OnName num="harpy_A"]
"I have a brother who passed away. Kosuke is just like him."
[cpg cn=true]



[OnName num="harpy_A"]
"It's not that I was in love with my brother, but I feel so much more relaxed when I'm with you..."
[cpg cn=true]


Everyone is trying to get close to me before they know anything about my personality or anything deep.
[cpg]


Should I just accept what's happening?
[cpg]


Of course, it would be a bad idea to cause trouble, but I was beginning to think that I didn't care anymore.
[cpg]



The fact that I want a demi-human wife hasn't changed.
[cpg]


It's not a bad feeling to be courted by a girl.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_11_4.ui" time=1000]
[WAIT time=1000]

I couldn't just do nothing, but I couldn't think of what to do.
[cpg]

I was afraid that if I tried to kiss her, something would happen.
[cpg]

[OnName num="harpy_A"]
"What do you mean by something...?"
[cpg cn=true]

[OnName num="kousuke"]
"It's just that if there's magic in my body, it could be transferred to..."
[cpg cn=true]

This is all just my imagination, but I don't think I'm way off.
[cpg]

But what should I do? Would a hug be enough? Would that make her feel uncomfortable?
[cpg]

;//Ｈシーンカット

[STOPBGM]

[WAIT time=1000]


[window target=false]

[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[BGM f="bg_tc"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（朝）******************************************************

[window target=true]



Then, early in the morning, I got some news.
[cpg]


[OnName num="harpy_B"]
"Oh my God! The elves are looking for you, Kosuke!"
[cpg cn=true]


[OnName num="harpy_A"]
"O-oh, really...? What happened, Kosuke?"
[cpg cn=true]


[OnName num="kousuke"]
"Well, it's a little...like I commited a crime of passion."
[cpg cn=true]


I didn't think admitting that would be enough. So I decided to explain everything.
[cpg]


The fact that it looked like I seduced an elven woman, and that's why I was on the run.
[cpg]


As I told my story, the first girl I met had a bit of a clouded expression on her face. But well..., I thought that might happen.
[cpg]


[OnName num="harpy_C"]
"What should we do? Kosuke, do you want to run away?"
[cpg cn=true]


[OnName num="kousuke"]
"When you say run away... How should I?"
[cpg cn=true]


It was more like "where should I run to" than "how".
[cpg]



[OnName num="harpy_A"]
"You should run away to...Japan. It's far away from the Elven Nation."
[cpg cn=true]


If I could do that, I wouldn't be struggling right now. I thought to myself.
[cpg]



[OnName num="harpy_A"]
"Couldn't we Harpies return Kosuke to Japan...?"
[cpg cn=true]


[OnName num="harpy_B"]
"Yes...it's possible. We don't know what will happen if the elves catch him."
[cpg cn=true]


[OnName num="kousuke"]
"Are you sure? I don't even have any money."
[cpg cn=true]


[OnName num="harpy_C"]
"You can pay for it later. For now, just leave it to us."
[cpg cn=true]


I don't know why everyone is so kind to me.
[cpg]


But I guess...Chartier knows why.
[cpg]


[OnName num="kousuke"]
"But...I can't ask you to carry me, it's too far away."
[cpg cn=true]


[OnName num="harpy_A"]
"We Harpies can use wind magic, so we can fly as fast as an airplane."
[cpg cn=true]


I didn't know that. But, isn't as fast as an airplane a little too fast....?
[cpg]


[OnName num="harpy_B"]
"Whatever you decide, the sooner we leave, the better. So what do you want to do?"
[cpg cn=true]


[OnName num="kousuke"]
"Then, can I count on you...?"
[cpg cn=true]


[OnName num="harpy_A"]
"Yes. No problem."
[cpg cn=true]



[BG f="black.ui" time=1000]
[STOPBGM]
;//ブラックアウト



[SE f="se001"]
;//【ＳＥ】『羽ばたく』

[WAIT time=2000]


[BG f="b_11_1.ui" time=1000]


[WAIT time=1000]

[BGM f="bg_d1"]


So, with the help of the three harpies, we made our way back to Japan.
[cpg]


It was like being held in a hug. It's the opposite of a piggyback.
[cpg]


I was wrapped in a unique cloth that looked like a large baby blanket.
[cpg]


Because of the wings, piggyback was not an option.
[cpg]


And the fact that she had such a tool meant that she probably did this all the time.
[cpg]


Anyway if I fell, I would die, right? More to the point, don't harpies get tired?
[cpg]


[OnName num="harpy_A"]
"No, we don't get tired. We're a species that specializes in, you know..., flying."
[cpg cn=true]


I wonder if that's possible. To carry a single person and get tired while flying them around?
[cpg]


[free time=800]


As I was thinking this, the harpies switched places mid flight.
[cpg]


After doing this several times, Japan came into view.
[cpg]


I was so relieved that I almost cried.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="101.jpg" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="101.jpg" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（昼）******************************************************


;//＠
[SE f="se011"]
;//【ＳＥ】『人混み』


Probably Kyushu. When I got there, I saw a modern town.
[cpg]



[OnName num="harpy_A"]
"This is Japan... It's so close, but I've never been here before."
[cpg cn=true]


[OnName num="harpy_B"]
"That's true. Shall we do some sightseeing?"
[cpg cn=true]


[OnName num="harpy_C"]
"I'd also like to take a break."
[cpg cn=true]


[OnName num="kousuke"]
"H-hold on a second."
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



[SE f="se009"]
;//【ＳＥ】『走る』





I ran to the nearest bank, withdrew some money and came straight back....
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[WAIT time=1]
[STOPBGM]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（昼）******************************************************


[window target=true]

[WAIT time=100]


[OnName num="kousuke"]
"Thanks for the ride. Please accept this money ."
[cpg cn=true]


I gave them more money than it might take to fly, but it was also my way of saying thanks for saving my life.
[cpg]


[OnName num="harpy_A"]
"Thank you very much. But just the thought is enough."
[cpg cn=true]


[OnName num="kousuke"]
"I could never thank you enough... Thank you so much for saving my life."
[cpg cn=true]



[OnName num="harpy_A"]
"Anyway, we'll leave it at that. I'm sure the Elven Nation will come after you in Japan."
[cpg cn=true]


[OnName num="kousuke"]
"Then...I really appreciate your help."
[cpg cn=true]



;//ブラックアウト

[window target=false]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『街＿現代』（夜）******************************************************

[window target=true]



By the time I got back to my house, it was midnight.
[cpg]


I had to go back to work tomorrow...
[cpg]


[OnName num="kousuke"]
"That was cutting it close..."
[cpg cn=true]


It really was a close call. I could have lost everything.
[cpg]



[free time=1000]
;//[BG f="black.ui" time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************



I feel like I've been through a lot, but I feel like I've had some good things happen to me too.
[cpg]


Eventually, I was able to smuggle myself out and sneak back in.
[cpg]


I even managed to make it back just before my vacation ended.
[cpg]


I was relieved, but I thought about it again. What would it be like to marry a demi-human girl?
[cpg]


After all, the differences in culture and race are huge obstacles. I've even been chased by the elves.
[cpg]


And then there are the legal procedures and the customs of the countries from another world. In a word, it's a hassle.
[cpg]


I decided to stay as an ordinary office worker for a while, thinking that I should stop looking for a demi-human wife.
[cpg]

[STOPBGM]
[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_03_1.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
;//【ＢＧ】『街＿現代』（朝）******************************************************


[window target=true]


The next morning, I headed to work, feeling quite exhausted.
[cpg]


Work wouldn't wait for me. I whipped my tired body into shape.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





My co-workers asked me if I had lost weight. I guess I have lost weight.
[cpg]


I'm sure I've lost weight, because really, there's more to it than one word can say.
[cpg]


But when I look back, I remember...
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

Fia. Meir. Chartier. Kullulu...
[cpg]

[free time=800]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

They were all cute and beautiful, but I'll never see them again.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[free time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『街＿現代』（夕方）******************************************************

[window target=true]
[WAIT time=100]



Should I have exchanged contact information with at least one of them? I don't even know if they any contact information to begin with.
[cpg]


If I had given them my phone number, would they have called me?
[cpg]


I returned home with an indescribable feeling.
[cpg]


Work was surprisingly manageable.
[cpg]


But my heart felt inexplicably empty.
[cpg]


I headed home, and there was...
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1500]
[STOPBGM]
;//ブラックアウト





[OnName num="kousuke"]
"......"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Fia056"]
[OnName num="fia"]
"......"
[cpg cn=true]


I froze in front of the door. There was a familiar face there.
[cpg]


[window target=false]

[free time=1000]
[WAIT time=1500]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************

[window target=true]




[OnName num="kousuke"]
"Well..., come on up."
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Fia057"]
[OnName num="fia"]
"Sorry to intrude."
[cpg cn=true]


Fia. Why is she here?
[cpg]


[OnName num="kousuke"]
"How did you get here? I mean, why are you here?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Fia058"]
[OnName num="fia"]
"I've been wanting to meet...you, Kosuke."
[cpg cn=true]


I was really unusually popular.
[cpg]


I can't believe that someone I've only met once likes me so much.
[cpg]


I'm surprised, but Fia says she's been wanting to see me.
[cpg]


[OnName num="kousuke"]
"What are you going to do? Are you going to stay here?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia059"]
[OnName num="fia"]
"If you don't mind, I'm prepared to stay here."
[cpg cn=true]


[OnName num="kousuke"]
"I can't let you do that..."
[cpg cn=true]


I had an indescribable feeling.
[cpg]


I could say that I have found my demi-human lover, if not my future demi-human wife...
[cpg]


I'm also worried that the elves will come after me again.
[cpg]


[OnName num="kousuke"]
"My room is actually pretty big. I think two or three people could stay in it."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Fia060"]
[OnName num="fia"]
"Then..."
[cpg cn=true]


[OnName num="kousuke"]
"You can stay here. I won't be able to pay for food or anything for a very long time, though."
[cpg cn=true]


Fia had a big smile on her face.
[cpg]


[FACE method="change_2" pos="2/3"]
;;[t_move pos=C 下礼]
[VOICE f="Fia061"]
[OnName num="fia"]
"Thank you very much!"
[cpg cn=true]


She bowed her head. I had a really...indescribable feeling.
[cpg]


What will happen now?
[cpg]

[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_03_1.ui" time=1000]
[WAIT time=1500]

[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（朝）******************************************************

[window target=true]



I had left some money for food at home. I even have a place to sleep.
[cpg]


So, Fia should be okay here.
[cpg]


My face smiled. I've never lived with a girl before.
[cpg]



;//※ヒロイン１とヒロイン３は最初から攻略対象となっている

;//■分岐

;//==============================
;//ヒロイン２が攻略対象となっている場合のみイベント発生

[if exp={getFlagValue("Cha2flg_s") == 1 }]
[jump target="*eve_01_1"]
[else]
[jump target="*eve_01_2"]
[endif]


*eve_01_1|A Journey Around the World


[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夕方）******************************************************



;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1000]


While I was thinking about it, I met another demi-human.
[cpg]


Not just any demi-human, but the one I met during my trip, it was...
[cpg]


[BG f="b_03_3_up_l.ui" time=1000]
[WAIT time=1500]

[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile077"]
[OnName num="meile"]
"Oh."
[cpg cn=true]


[OnName num="kousuke"]
"Meir...?"
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile078"]
[OnName num="meile"]
"I looked everywhere for you, Kosuke. Luckily I could follow your scent."
[cpg cn=true]


[OnName num="kousuke"]
"N-no, wait. You're not supposed to be able to do magic."
[cpg cn=true]


I can still see how Fia found my house. It must have been magic or something.
[cpg]


But isn't it weird that Meir can do the same thing?
[cpg]


[OnName num="kousuke"]
"How did you find me?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile079"]
[OnName num="meile"]
"I told you, I followed your scent."
[cpg cn=true]


That's ridiculous. But then again, she did find me.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile080"]
[OnName num="meile"]
"Hey, can I go to Kosuke's place? I came all the way to Japan just for you."
[cpg cn=true]


I couldn't say no, so we headed to my place...
[cpg]


Even if you refuse, you still have to go home. Even if I refuse, I still have to go home. Even if I leave it alone, Meir will come to my house.
[cpg]



;//ブラックアウト
[window target=false]
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************

[window target=true]

;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く
[WAIT time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Fia062"]
[OnName num="fia"]
"Welcome home..., a beast...?"
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile081"]
[OnName num="meile"]
"Huh? An elf? What's the meaning of this, Kosuke?"
[cpg cn=true]


The two of them had never met before. So it was bound to turn out like this.
[cpg]


[OnName num="kousuke"]
"Well..., This is Fia. Remember, I told you I was being chased."
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Meile082"]
[OnName num="meile"]
"Yeah. I followed Kosuke here, too."
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="Meile083"]
[OnName num="meile"]
"I'm Meir. Nice to meet you."
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Fia063"]
[OnName num="fia"]
"Y-yeah.."
[cpg cn=true]


I suddenly had to spend time with three people in my small room.
[cpg]


Suddenly, I was going to live with Meir too...
[cpg]

[window target=false]

[STOPBGM]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（朝）******************************************************

[window target=true]




The three of us were cramped together. The situation was like a man's dream, but it was still hard to sleep.
[cpg]


I woke up early in the morning and decided to leave the house before the two of them woke up.
[cpg]


I left a note for Fia and Meir, telling them to go sightseeing around Japan during the day.
[cpg]


Especially Meir, who can't stand to be stuck in a small space.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





The weekdays continued. I'd like to spend some time with a demi-human girlfriend, but that's not allowed.
[cpg]


I have a normal day of work ahead of me. It's been a long holiday weekend, so I've been dizzyingly busy.
[cpg]

[window target=false]

[STOPBGM]
[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]

[transition target={true} rule="39.png" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="39.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************


[window target=true]



In the evening, I could finally be with the two of them...
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sMeile002"]
[OnName num="meile"]
"Hey, Kosuke. What about me?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Fia064"]
[OnName num="fia"]
"H-hey, you're a little...too close."
[cpg cn=true]


While Meir is attached to me, Fia is trying to pull me away.
[cpg]

[free time=800]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/2" time=800]

[VOICE f="sMeile003"]
[OnName num="meile"]
"Didn't something already happen between Fia and Kosuke? Don't stop me."
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia065"]
[OnName num="fia"]
"That's true, but..."
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile086"]
[OnName num="meile"]
"Is it that you don't like demi-humans or beasts...?
[cpg cn=true]


Even as Meir was closing in on me, she seemed to have a complex about herself being a beast.
[cpg]


I was not sure what to say.
[cpg]





;//■選択肢
[switch]
[case "Don't say anything."]
	[swap]
	[jump target="*IseSel04_1"]
[case "I don't hate them."]
	[swap]
	[jump target="*IseSel04_2"]
[endswitch]



1. Don't say anything.
2. I don't hate them.



;//==============================
;//１、答えない
*IseSel04_1|A Journey Around the World



[OnName num="kousuke"]
......
[cpg cn=true]


[FACE method="change_5" pos="1/2"]
[VOICE f="Meile087"]
[OnName num="meile"]
"......"
[cpg cn=true]


[FACE method="change_4" pos="2/2"]
[VOICE f="Fia066"]
[OnName num="fia"]
"Oh, um..., I don't think Kosuke is the kind of person who would discriminate like that."
[cpg cn=true]


[FACE method="change_4" pos="1/2"]
[VOICE f="Meile088"]
[OnName num="meile"]
"Yeah, I know. Righ, Kosuke?"
[cpg cn=true]


I couldn't reply. I was a little annoyed that she had said that out of the blue.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[if exp={getFlagValue("Cha2flg") == 1 }]
[stflag Cha2flg=-1]
[endif]


;//ヒロイン２は攻略対象でなくなる

[jump target="*IseSel04_3"]

;//==============================
;//２、嫌いじゃない

*IseSel04_2|A Journey Around the World



[OnName num="kousuke"]
"There's no way anyone could hate demi-humans."
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Meile089"]
[OnName num="meile"]
"Thank you."
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

Meir hugs me and pushes me down.
[cpg]


[FACE method="change_7" pos="1/2"]
[FACE method="change_7" pos="2/2"]
[VOICE f="sMeile004"]
[OnName num="meile"]
"Kosuke... Hey, I want to be around you more..."
[cpg cn=true]


I was going to remind her that Fia is right next to me when she said...
[cpg]


[FACE method="change_2" pos="2/2"]
[VOICE f="Fia067"]
[OnName num="fia"]
"Um..., I'm going to go shopping."
[cpg cn=true]



[move from="2/2" to="5/3" ease="easeInOutSine" time=1000]

[SE f="se004"]
;//【ＳＥ】『ドア閉まる』





Fia left the room without any money.
[cpg]


[FACE method="change_6" pos="1/2"]
[WAIT time=1]
[move from="1/2" to="2/3" ease="easeInOutSine" time=1000]

[VOICE f="sMeile005"]
[OnName num="meile"]
"Fia is so considerate."
[cpg cn=true]


[OnName num="kousuke"]
"Ah..."
[cpg cn=true]




;//ブラックアウト

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]



I wondered if it was okay, but I felt as if they were trying to give back the cost of housing them.
[cpg]

[VOICE f="sMeile006"]
[OnName num="meile"]
"Kosuke really does smell good."
[cpg cn=true]

[OnName num="kousuke"]
"So unaware of it..."
[cpg cn=true]

[VOICE f="sMeile007"]
"Soooo... Mmmm, so irresistible!"
[cpg cn=true]


;//========================================
;//●ＣＧエロ（主人公に迫るヒロイン。体の上に乗っている）ev_01
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：主人公の部屋＿現代
;//時間　：夜
;//========================================

*Scene007|A Journey Around the World

[STOPBGM]


[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[BGM f="bg_h1"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=100]


And just as I was about to say that, Meir came crashing down on me!
[cpg]

[OnName num="kousuke"]
"W-wait a minute, aren't you acting too wild?"
[cpg cn=true]


;**【ＣＧ】 ev_01_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=100]

When I said that, Meir puffed out her cheeks and had an angry look on her face.
[cpg]

[VOICE f="sMeile008"]
[OnName num="meile"]
"No, I'm not. You're making fun of me because I'm a beast."
[cpg cn=true]

It is true that the term "wild" is not appropriate for a beast.
[cpg]

[OnName num="kousuke"]
"N-no..."
[cpg cn=true]

In any case, she's definitely going to try to do something to me.
[cpg]

I'm not ready for that, I thought to myself, as she leaned down and put her face close to my chest.
[cpg]


;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile009"]
[OnName num="meile"]
"Mmmm, I want to stay with you forever."
[cpg cn=true]

She said this and went back to her original position.
[cpg]

[VOICE f="sMeile010"]
[OnName num="meile"]
"I'd do anything for you if only Fia wasn't here."
[cpg cn=true]

Meir says thoughtfully. Confused, I asked her about it...
[cpg]

[OnName num="kousuke"]
"What do you mean by 'anything'?"
[cpg cn=true]

Meir smirked and brought her face close to mine again.
[cpg]

;**【ＣＧ】 ev_01_b ***********************
[CG id=0 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile011"]
[OnName num="meile"]
"You're thinking dirty thoughts."
[cpg cn=true]

[OnName num="kousuke"]
"It's your fault!"
[cpg cn=true]

[VOICE f="sMeile012"]
[OnName num="meile"]
"Hmmm, you definitely are."
[cpg cn=true]

Meir seems to be a little mischievous. Well, I kind of knew that already, though...
[cpg]

;//Ｈシーンカット


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_04_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d3"]

[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************


[window target=true]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="4/2" time=1]
[WAIT time=1]



[move from="4/2" to="2/2" ease="easeInOutSine" time=1000]

[VOICE f="Fia068"]
[OnName num="fia"]
"Oh, sorry to interrupt..."
[cpg cn=true]


After a bit of flirting, Fia came back into the room with trepidation.
[cpg]


I felt awkward. So did Fia, and so did Meir.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="sMeile013"]
[OnName num="meile"]
"I'd like to be alone with you for a while longer."
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="sFia005"]
[OnName num="fia"]
"That's not fair to only spend time with Meir."
[cpg cn=true]

;//＠
;//フィアが謝ることは何も無いと思うが、それでも謝ってきた。
;//[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]
;//ブラックアウト



[stflag Cha2flg=1]
;//ヒロイン２は攻略対象のまま



;//==============================


*IseSel04_3|

*eve_01_2|A Journey Around the World

;//==============================


;//■分岐


;//==============================

;//ヒロイン４が攻略対象となっている場合のみイベント発生

[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_04_1"]
[else]
[jump target="*eve_04_2"]
[endif]


*eve_04_1|A Journey Around the World

;//■分岐

;//■分岐

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夜）******************************************************





One weekday evening. She showed up.
[cpg]


[BG f="b_03_4_up_l.ui" time=1000]
[WAIT time=1500]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]


[OnName num="kousuke"]
"You..."
[cpg cn=true]


[VOICE f="Clolowlude091"]
[OnName num="clolowlude"]
"I came for you. You should be grateful."
[cpg cn=true]


Kullulu showed up. I reminded myself that I'd been rude to Kullulu.
[cpg]


I was still on my way back home. I wondered what Fia would think if I brought her back with me...
[cpg]


Bringing Kullulu home is probably a bad idea.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude092"]
[OnName num="clolowlude"]
"Where do you live? I'd like you to take me there if that's alright with you."
[cpg cn=true]


Even though she said it like I had a choice, I clearly didn't.
[cpg]


She can use magic. I don't know what will happen if I refuse her.
[cpg]



;//ブラックアウト
[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************


[window target=true]



[OnName num="kousuke"]
"So, you're a demon, Kullulu...?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Clolowlude093"]
[OnName num="clolowlude"]
"Yes, I'm a demon. And my name is Kullulu-Urd, not Kullulu."
[cpg cn=true]

;//[free time=800]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Fia075"]
[OnName num="fia"]
"......"
[cpg cn=true]


Fia would be flabbergasted. She's probably wondering how many women I've interacted with.
[cpg]



*eve_05_2|A Journey Around the World

;//■分岐

;//[free time=800]


[FACE method="change_1" pos="1/2"]
[FACE method="change_1" pos="2/2"]

[VOICE f="Fia077"]
[OnName num="fia"]
"Nice to meet you, Kullulu-Urd."
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude096"]
[OnName num="clolowlude"]
"Yes, it's nice to meet you. I'm glad you called me by name without abbreviating."
[cpg cn=true]


Kullulu, definitely hates when people do that.
[cpg]



;//ブラックアウト

[STOPBGM]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[free time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（朝）******************************************************


[window target=true]



And before Fia woke up. Kullulu woke me up.
[cpg]


*eve_05_3|A Journey Around the World



[OnName num="kousuke"]
"What the...?"
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Clolowlude097"]
[OnName num="clolowlude"]
"Your pheromones are alive and well."
[cpg cn=true]


[OnName num="kousuke"]
"I really don't know what you're talking about."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clolowlude098"]
[OnName num="clolowlude"]
"You can't just say you don't know. I'm a slave to your pheromones."
[cpg cn=true]


This... This is not a good trend.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude099"]
[OnName num="clolowlude"]
"Fia shouldn't be left alone..."
[cpg cn=true]


[OnName num="kousuke"]
"That is that and this is this. We're not talking about that right now."
[cpg cn=true]


Even though I refused, Kullulu kept coming on to me.
[cpg]

[OnName num="kousuke"]
"What if Fia wakes up...?"
[cpg cn=true]

*eve_06_3|A Journey Around the World


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude122"]
[OnName num="clolowlude"]
"I'm just showing you."
[cpg cn=true]


Kullulu was being quite reckless. But maybe if it were the other way around...
[cpg]


[OnName num="kousuke"]
"If we're going to mess around..., let's at least do it when no one else is around."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sClolowlude004"]
[OnName num="clolowlude"]
"I see, so you don't mind messing around?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clolowlude124"]
[OnName num="clolowlude"]
"You should be grateful. A beautiful woman like me is coming on to you so much."
[cpg cn=true]


I'm not sure that's something one can say about themselves...., but she's certainly beautiful.
[cpg]

;//Ｈシーンカット



;//==============================

*eve_04_2|A Journey Around the World

;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[STOPBGM]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_04_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夕方）******************************************************

[window target=true]




I was going to be living with a demi-human girl for a while.
[cpg]


Fia was cooking for me, using unfamiliar Japanese ingredients.
[cpg]


I didn't understand the situation, but I thought it was okay because I was happy.
[cpg]


The cost of living is a bit high, but I can manage that for a while with my savings.
[cpg]


[OnName num="kousuke"]
"Fia , what's for dinner today?"
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia078"]
[OnName num="fia"]
"I tried to make miso soup, but I'm not too sure how to..."
[cpg cn=true]


[OnName num="kousuke"]
"That's amazing. They don't have miso soup in the Elven Nation, huh?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia079"]
[OnName num="fia"]
"Yeah, we don't..., but there was something on TV the other day about miso soup being good for you."
[cpg cn=true]


An elf watching TV. It's kind of strange.
[cpg]

[free time=1000]

;//＠
[SE f="se012"]
;//【ＳＥ】テレビをつける（スイッチを押す）

I went to the dining table and turned on the TV.
[cpg]


[OnName num="kousuke"]
"Huh...?"
[cpg cn=true]


I had been carefree and enjoyed us living together. However, the situation was more serious than I thought.
[cpg]


Because what I saw on the news was my face.
[cpg]


I was so surprised that I could not react. If you ask me what I had done to make the news, it could have been a number of things recently.
[cpg]


[OnName num="news_caster"]
"Wanted criminal last seen in the Elven Nation..."
[cpg cn=true]


Wanted criminal. I was surprised by the word "wanted", but even more so by...
[cpg]


The reason why I was being hunted in the Elven Nation seemed to be for a reason other than me being caught with Fia.
[cpg]


The person on the TV, who seemed to be the Leader of the Elves, said this...
[cpg]


[OnName num="elven_chief"]
"He is the reincarnation of the Demon King... There have been signs about the Demon King's resurrection for some time."
[cpg cn=true]


[OnName num="elven_chief"]
"It seems to be a man in his twenties, but his true self must have just woken up. The prophecy is true."
[cpg cn=true]


It seems that a prophecy passed down among the elves and magical detection have determined that I am the reincarnation of the Demon King.
[cpg]


I was not aware of this at all. Or rather, it's so sudden that I don't understand.
[cpg]


In the first place, I had broken the law entering the Elven Nation, and even then I was being hunted...
[cpg]


But when it comes to the reincarnation of the Demon King, it seems to be a different story.
[cpg]



;//==============================
;//ヒロイン２が攻略対象となっている場合のテキスト

;//■分岐
[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*eve_07_1"]
[else]
[jump target="*eve_07_2"]
[endif]


*eve_07_1|A Journey Around the World

[free time=800]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Meile119"]
[OnName num="meile"]
"Wow, Kosuke! You're the reincarnation of the Demon King."
[cpg cn=true]


[OnName num="kousuke"]
"Wait a minute. I don't know anything about that."
[cpg cn=true]

[jump target="*eve_07_3"]

;//==============================
;//ヒロイン２が攻略対象となっていない場合のテキスト

;//■分岐

*eve_07_2|A Journey Around the World


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia080"]
[OnName num="fia"]
"Kosuke..., is it true?"
[cpg cn=true]


[OnName num="kousuke"]
"N-no... I don't know."
[cpg cn=true]



;//==============================

*eve_07_3|A Journey Around the World

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]

[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************





The TV continued to show the news. There seemed to be an announcement from the Elven Nation this afternoon, and it was all over the news.
[cpg]


The Demon King has so much power that weapons are useless.
[cpg]


It was even said that the world would become his when he appears...
[cpg]


They wouldn't just throw me in jail if I got caught.
[cpg]

[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[OnName num="kousuke"]
"What should I do, Fia..., I don't want to die."
[cpg cn=true]


Fia frowned and then said...
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia081"]
[OnName num="fia"]
"Then...., why don't you go to Beast Country?"
[cpg cn=true]


After she suggested it, I knew she was right.
[cpg]


[free time=800]

I don't think it would be a good idea to stay in Japan or head to the Elven Nation.
[cpg]


Beast Country will probably be the last to know about me. But only because news travels slow there.
[cpg]


It doesn't solve all my problems...
[cpg]




;//==============================
;//ヒロイン４が攻略対象となっている場合のテキスト

;//■分岐
[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_08_1"]
[else]
[jump target="*eve_08_2"]
[endif]



*eve_08_1|A Journey Around the World



[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude148"]
[OnName num="clolowlude"]
"It's no use being afraid now."
[cpg cn=true]


[OnName num="kousuke"]
"Kullulu, you knew the whole time, right?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude149"]
[OnName num="clolowlude"]
"Yes, of course."
[cpg cn=true]


Was that it...? Did the demi-humans want me because I was the Demon King?
[cpg]

[jump target="*eve_08_3"]

;//==============================
;//ヒロイン４が攻略対象となっていない場合のテキスト

;//■分岐

*eve_08_2|A Journey Around the World


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia082"]
[OnName num="fia"]
"You don't look so good, Kosuke..."
[cpg cn=true]


[OnName num="kousuke"]
"Well..., you know."
[cpg cn=true]



;//==============================

*eve_08_3|A Journey Around the World

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_04_4.ui" time=1000]

[WAIT time=1500]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************

[window target=true]



Nightfall... If I don't sleep, I won't be able to go to the office tomorrow, but going to the office is also a bad idea.
[cpg]


What should I do? Will I even be able to eat tomorrow?
[cpg]



[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

[WAIT time=1100]



Just as I was thinking this, I saw someone coming towards my place.
[cpg]


The police? I was scared, but I couldn't not answer.
[cpg]


With determination, I unlocked the door...
[cpg]


It opened from the outside. As I was wondering who it was, I saw the face of the person on the other side of the door.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye018"]
[OnName num="schartye"]
"Why the face? Demon King..."
[cpg cn=true]


[OnName num="kousuke"]
"You..., what now?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye019"]
[OnName num="schartye"]
"Is that how you want to be? Doesn't the Demon King need my help?"
[cpg cn=true]


[OnName num="kousuke"]
"Sorry, I'd appreciate it if you could help me."
[cpg cn=true]

[free time=800]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Fia083"]
[OnName num="fia"]
"Um, who's this?"
[cpg cn=true]


[OnName num="kousuke"]
"This is Chartier. It's a long story..."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Schartye020"]
[OnName num="schartye"]
"To put it simply, I took my Demon King around the world."
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Schartye021"]
[OnName num="schartye"]
"It was all to prepare for this day. You majesty, the Demon King."
[cpg cn=true]


[OnName num="kousuke"]
"Please don't call me that..."
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Schartye022"]
[OnName num="schartye"]
"Beast Country is still quite new. You know that, don't you, Demon King?"
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Schartye023"]
[OnName num="schartye"]
"That means you can literally become king there."
[cpg cn=true]


[OnName num="kousuke"]
"What do you mean...?"
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Schartye024"]
[OnName num="schartye"]
"If you're the Demon King, you need to be a king and build your kingdom."
[cpg cn=true]




[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[free time=1]
[STOPBGM]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="163.jpg" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_03_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夜）******************************************************


[window target=true]



Therefore, we headed for Beast Country with the demi-humans who came barging into my life.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia084"]
[OnName num="fia"]
"I've heard about airships, but I've never seen one before."
[cpg cn=true]

[VOICE f="sFia006"]
[OnName num="fia"]
"I don't know how something so big can float."
[cpg cn=true]


[OnName num="kousuke"]
"Me either... It must be magic or something."
[cpg cn=true]



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye025"]
[OnName num="schartye"]
"Don't look so scared. Let's go."
[cpg cn=true]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト
;//【ＢＧ】『空』（夜）******************************************************



[SE f="se005"]
;//【ＳＥ】『魔法発動する音　シンセパッド系』


[WAIT time=1500]



Then the demi-human women and I flew out of Japan.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
During our journey, Chartier explained what's been happening to me.
[cpg]


Apparently, I have a pheromone that makes demi-humans go into heat, and my saliva, for example, contains magical elements.
[cpg]

[VOICE f="sSchartye001"]
[OnName num="schartye"]
"If you kiss a demi-human, they might have an increase in magic power. That's how much magic your saliva contains."
[cpg cn=true]

[OnName num="kousuke"]
"You're joking..."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSchartye002"]
[OnName num="schartye"]
"I'm not. It has the power to attract mainly women, but even men will be happy to see the Demon King return if they are demi-human."
[cpg cn=true]


[OnName num="kousuke"]
"Is that what it was...?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye027"]
[OnName num="schartye"]
"It's a good thing. Demi-humans are still in a vulnerable position, which hasn't been great."
[cpg cn=true]


While we are talking about this, the airship kept flying along.
[cpg]


Today there were no suspicious passengers.
[cpg]

[free time=800]


;//==============================
;//ヒロイン４が攻略対象となっていない場合のみイベント発生

;//■分岐
[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_10_2"]
[endif]




[OnName num="kousuke"]
"So..., she is...?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude150"]
[OnName num="clolowlude"]
"What?"
[cpg cn=true]


Before I knew it, I was with Chartier and Kullulu-Urd.
[cpg]


She's apparently acquainted with Chartier.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude151"]
[OnName num="clolowlude"]
"I'm here to help. I hope you don't mind."
[cpg cn=true]


For some reason, she wants to help me build my country.
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Clolowlude152"]
[OnName num="clolowlude"]
"It is the long-cherished wish of us demi-humans that the Demon King be resurrected."
[cpg cn=true]


She said the same thing as Chartier.
[cpg]



;//==============================


*eve_10_2|A Journey Around the World


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[STOPBGM]
[BG f="b_10_1.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



Then we arrived in Beast Country. There is no way I can suddenly declare myself a king and start acting like one.
[cpg]


At any rate, I headed to the village where Meir was.
[cpg]



;//==============================
;//ヒロイン２が攻略対象となっていない場合のみイベント発生

;//■分岐
[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*eve_11_2"]
[endif]



On my way there, I ran into Meir again.
[cpg]


She was surprised, but still looked happy.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile120"]
[OnName num="meile"]
"Kosuke...! What are you doing here?"
[cpg cn=true]


[OnName num="kousuke"]
"O-oh..., it's a long story."
[cpg cn=true]


I recounted the story. I told her that I was being hunted more than ever now.
[cpg]


I explained that I was going to start my own country and she said she would help me with that.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile121"]
[OnName num="meile"]
"So Kosuke turned out to be the Demon King...! No wonder I thought you were out of the ordinary."
[cpg cn=true]


I couldn't keep up with the tension. I was rather worried.
[cpg]


And isn't it too early to accept all of this? I still haven't caught up with it.
[cpg]


Maybe it's because it's my own thing...
[cpg]


;//続くのでリセットで転調



;//==============================

*eve_11_2|A Journey Around the World




;//続くのでリセットで転調
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_1.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


;//==============================

*eve_12_2|A Journey Around the World



After that, Chartier started explaining the plan.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye028"]
[OnName num="schartye"]
I will gather the people of this village. The Demon King himself will not go to the village.
[cpg cn=true]


[OnName num="kousuke"]
"B-but..."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye029"]
[OnName num="schartye"]
"All you have to do is stay put."
[cpg cn=true]

[free time=800]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Clolowlude153"]
[OnName num="clolowlude"]
"That's right. You don't need to be afraid."
[cpg cn=true]


I don't have to be afraid, she said...
[cpg]

[STOPBGM]


[free time=1000]
[window target=false]

[BG f="b_10_3.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



The beasts from all over the village have gathered. No, they're gathering from outside the village?
[cpg]


There are so many of them. There are about a thousand of them.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Schartye030"]
[OnName num="schartye"]
"Listen up! The Demon King has been resurrected here and now!"
[cpg cn=true]


[VOICE f="Clolowlude154"]
[OnName num="clolowlude"]
"We are his subjects! In order to protect the Demon King, and to create a kingdom for him..."
[cpg cn=true]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye031"]
[OnName num="schartye"]
"What is our purpose? What is our wish?"
[cpg cn=true]


It was a strange atmosphere. Fia was a little frightened, but Meir was swallowed by the air.
[cpg]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye032"]
[OnName num="schartye"]
"Our wish is to take over the world!"
[cpg cn=true]


Cheers erupted. This was not good. I'm not that kind of person.
[cpg]


[OnName num="therianthropy_A"]
"Oh, Demon King..., I would give my life for you."
[cpg cn=true]


[OnName num="therianthropy_B"]
"I'm ready for any kind of battle. I won't let the humans and elves have their way with you!"
[cpg cn=true]


[free time=800]

In any case, they seem to be pleased with the Demon King's resurrection, and everyone is worshipping me.
[cpg]


[OnName num="kousuke"]
"Oh, yeah... I guess I'm the Demon King..."
[cpg cn=true]


I tried calling myself the Demon King, still feeling unsettled.
[cpg]

[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]




That night, it was like a banquet. It seems that the Demon King is a very important person to the demi-humans.
[cpg]


A short distance away from the party, Chartier and I talked.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye033"]
[OnName num="schartye"]
"Maybe it's time to tell him everything."
[cpg cn=true]


[OnName num="kousuke"]
"What do you mean, 'everything'...? What's going on?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye034"]
[OnName num="schartye"]
"It's not difficult, but it's important."
[cpg cn=true]


Chartier spoke up. She said that she had already discovered that I was the reincarnation of the Demon King.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye035"]
[OnName num="schartye"]
"I took you on a trip as a prelude to this. I didn't send you back to Japan right away so that you could make friends in each place."
[cpg cn=true]


Chartier explained. Then Kullulu came in.
[cpg]


[free time=800]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Clolowlude155"]
[OnName num="clolowlude"]
"What are the two of you talking about...?"
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Schartye036"]
[OnName num="schartye"]
"We were talking about why we took the Demon King on the trip."
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude156"]
[OnName num="clolowlude"]
"Oh. Well, it's hard to understand without an explanation, isn't it?"
[cpg cn=true]


I was becoming more and more aware of it as they spoke.
[cpg]


It is true that Fia would not have joined us if we had not gone to the Elven Nation.
[cpg]


It's also true that if I hadn't met Meir in person, I wouldn't have been able to ask for her help right away.
[cpg]


[OnName num="kousuke"]
"What would have happened if you had lived in Japan all those years without doing that...?"
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye037"]
[OnName num="schartye"]
"It's not too hard to imagine that Kosuke would have been suddenly discovered to be the reincarnation of the Demon King and killed."
[cpg cn=true]


I shuddered. Was it just a hair's breath away, or did this journey lead to my awakening as a Demon King?
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="sSchartye003"]
[OnName num="schartye"]
"Let me tell you one more thing. Your qualities as a Demon King awaken when you connect with a demi-human."
[cpg cn=true]


[OnName num="kousuke"]
"Awaken... What do you mean?"
[cpg cn=true]


When I asked about the details, she said that falling in love with a demi-human, kissing her, or something like that would remind my soul that I was the Demon King.
[cpg]


The theory seemed to be that it was because they had created a harem of demi-humans in the past.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="sSchartye004"]
[OnName num="schartye"]
"The former Demon King had countless children with demi-human women. What about the current Demon King?"
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


I think back. Not so much...
[cpg]


[FACE method="change_7" pos="2/2"]
[VOICE f="sClolowlude005"]
[OnName num="clolowlude"]
"In any case, the number of people you connect with in the future will probably change your personality as well."
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Schartye040"]
[OnName num="schartye"]
"That's right. Whether you want world domination or peace depends on how much of your past self as the Demon King returns."
[cpg cn=true]


[OnName num="kousuke"]
"Is it true, Kullulu...? Everything you've said so far is true?"
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude158"]
[OnName num="clolowlude"]
"There's no denying it."
[cpg cn=true]


Then, it's true... I'll change when I fall in love with a demi-human girl.
[cpg]


I guess if I tempt anyone too much, I'll be resurrected as the Demon King.
[cpg]


I couldn't decide if that was a good thing or a bad thing.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude159"]
[OnName num="clolowlude"]
"Whatever it is, you should be grateful to Chartier. Or you'd still be in danger of being killed."
[cpg cn=true]


I felt like I had gotten myself into a terrible situation, but I was determined to protect myself as the Demon King.
[cpg]



;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[free time=1]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="163.jpg" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_10_1.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



It was morning, and everyone had calmed down a bit.
[cpg]


Still, it seemed that everyone respected me.
[cpg]


Men and women alike bowed deeply when they crossed my path.
[cpg]


[OnName num="kousuke"]
"The Demon King. The Demon King, huh?"
[cpg cn=true]


But even though I'm the Demon King, there's no sign that I can use magic.
[cpg]


I can't use magic because I've never tried to use it before. I decided to talk to Fia and Meir about it.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile122"]
[OnName num="meile"]
"I don't know much about magic myself."
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="Fia085"]
[OnName num="fia"]
"I do have some knowledge."
[cpg cn=true]


[OnName num="kousuke"]
"Well, why don't I teach you? You're the Demon King, so you should be able to use some of it."
[cpg cn=true]


It's a matter of image. Since I'm the Demon King, I should be able to use magic.
[cpg]


So the three of us discussed magic.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia086"]
[OnName num="fia"]
"Magic, like anything else...., can only be achieved through a combination of effort and talent."
[cpg cn=true]


[OnName num="kousuke"]
"What about me? Hard work maybe, but talent?"
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Meile123"]
[OnName num="meile"]
"I think I can sense some kind of magical power from Kosuke, but..."
[cpg cn=true]


Meir doesn't refer to me as the Demon King, huh? I guess not.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia087"]
[OnName num="fia"]
"You're not wrong. Kosuke seems to have...tremendous magical qualities."
[cpg cn=true]


So says Fia, as she holds out her hand towards me.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia088"]
[OnName num="fia"]
"Perhaps... Chartier or Kullulu-Urd would be a better choice than me to teach you."
[cpg cn=true]


[OnName num="kousuke"]
"Well, I guess those two can do magic."
[cpg cn=true]


Fia tells me that they have strong magical qualities, but they don't know how to use them.
[cpg]


So, I was taught magic by Fia, Chartier, and Kullulu.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=100]
;//ブラックアウト





Fia and Kullulu were not so keen, but Chartier was willing to teach me magic.
[cpg]


She wasn't talking that fast, but he was giving me so much information that I got confused.
[cpg]


[WAIT time=500]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye041"]
[OnName num="schartye"]
"You get the gist? Now let's talk about how summoning magic works."
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Fia089"]
[OnName num="fia"]
"No, let's take a break here. Kosuke, you look tired."
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye042"]
[OnName num="schartye"]
"Are you? I hadn't noticed."
[cpg cn=true]


I was so tired that I deliberately showed it in my attitude. I won't understand if everything is suddenly explained to me.
[cpg]


But it was a matter of life and death for me, so I took it seriously.
[cpg]


[window target=false]
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]


Several days and nights passed.
[cpg]


I was to stay in Beast Country, in a house...that was intended for the guests in that village.
[cpg]


But sooner or later, I'll have to build a castle or something, or I'll suddenly find myself on the wrong side of the bed.
[cpg]

[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





With that in mind, I was successfully performing my first magic spell.
[cpg]



[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』



;//フラッシュ
[BG f="white.ui" time=1000]
[WAIT time=1000]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1000]

;//【ＢＧ】『村＿獣人の国』（昼）******************************************************






The three of us, Fia , Chartier, and I, were in a magic class. However, it seems that Fia didn't know as much as Chartier.
[cpg]


[OnName num="kousuke"]
"Did it work?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Fia090"]
[OnName num="fia"]
"Yes, it did. The magic summoning spell...should have summoned the ideal demon you envisioned, but..."
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="sSchartye005"]
[OnName num="schartye"]
"A tentacled creature. Wonderful."
[cpg cn=true]


Tentacles. They were writhing and wriggling.
[cpg]


It was red and black and creepy, but I see, this was the demon I'd been looking for.
[cpg]


[OnName num="kousuke"]
"......"
[cpg cn=true]

It's an indescribable feeling to be told that these demons lived inside my head.
[cpg]

But come to think of it, I don't like dragons, griffins, or other cool demons.
[cpg]


I like horror movies. So I guess that's the image I have.
[cpg]



[FACE method="change_7" pos="1/2"]
[VOICE f="sSchartye006"]
[OnName num="schartye"]
"After all, he is the reincarnation of the former Demon King. I can feel the remnants of that man."
[cpg cn=true]


[OnName num="kousuke"]
"Is that so...?"
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="sSchartye007"]
[OnName num="schartye"]
"Yeah. You should be able to control it now. Use it as you wish."
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


I even got a seal of approval from Chartier.
[cpg]

The tentacled creature was still writhing about, and Fia was frightened to see it.
[cpg]

[FACE method="change_7" pos="2/2"]
[VOICE f="sFia007"]
[OnName num="fia"]
"W-when the time comes..., you might have to use force."
[cpg cn=true]

Fia says this with a frightened look on her face, but I had something completely different in mind.
[cpg]

I was wondering if I could use this to play a trick on the girls.
[cpg]

It's not that I've regained my old memories, but I think I was thinking something similar before I was reincarnated...
[cpg]


I had such a vague memory in my mind.
[cpg]


[OnName num="kousuke"]
"How do I get rid of this...?"
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Fia091"]
[OnName num="fia"]
"Hold on."
[cpg cn=true]


[FACE method="change_5" pos="1/2"]
[VOICE f="Schartye046"]
[OnName num="schartye"]
"H-hey, it's getting tangled up."
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia092"]
[OnName num="fia"]
"Wait, h-hold on."
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『触手絡みつく』


[BG f="b_10_2_l.ui" time=1000]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



From there, things spiraled out of control. My magic was too strong and the tentacle creature ran amok.
[cpg]


It got entangled in Chartier's body and wouldn't let go.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Schartye047"]
[OnName num="schartye"]
"Demon King! How do we handle this?"
[cpg cn=true]


[OnName num="kousuke"]
"Oh, don't ask me! Fia, what should we do?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Fia093"]
[OnName num="fia"]
"Wait, you can do the opposite of summoning... Uh, hold on."
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Fia094"]
[OnName num="fia"]
"Where did I put the grimoire to seal...?"
[cpg cn=true]


[OnName num="kousuke"]
"I don't know! You don't have it?"
[cpg cn=true]

[FACE method="change_5" pos="2/2"]
[VOICE f="sFia008"]
[OnName num="fia"]
"I'll go look for it!"
[cpg cn=true]

[move from="2/2" to="4/2" ease="easeInOutSine" time=1000]




With that, Fia left the scene and got out of harm's way.
[cpg]


I turned to Chartier thinking about what to do now.
[cpg]



;//========================================
;//●ＣＧ（触手に絡まれるヒロイン。逃げだそうとしている）ev_14
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：触手　　　　服装ex：無し
;//場所　：村＿獣人の国
;//時間　：昼
;//========================================

*Scene012|A Journey Around the World

[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=100]


[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[WAIT time=1000]


[VOICE f="sSchartye008"]
[OnName num="schartye"]
"I can't...get untangled."
[cpg cn=true]
[OnName num="kousuke"]
"You all right, Chartier?"
[cpg cn=true]

[VOICE f="sSchartye009"]
[OnName num="schartye"]
"It's slimy and not very pleasant..."
[cpg cn=true]

[VOICE f="sSchartye010"]
[OnName num="schartye"]
"But when I think about the demons that the Demon King created..."
[cpg cn=true]

[OnName num="kousuke"]
"Don't raise your voice..."
[cpg cn=true]

I feel like I'm being naughty.
[cpg]

[OnName num="kousuke"]
"I don't know what to do. I didn't want this to happen either."
[cpg cn=true]

;**【ＣＧ】 ev_14_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sSchartye011"]
[OnName num="schartye"]
"I don't know, either. I think the Demon King can control it to some extent..."
[cpg cn=true]


I see. If I can manipulate it to my will, then I can just remind it to let go.
[cpg]

[OnName num="kousuke"]
"Hold on a second, Chartier."
[cpg cn=true]

[VOICE f="sSchartye012"]
[OnName num="schartye"]
"I don't have much of a choice since I'm stuck."
[cpg cn=true]
[OnName num="kousuke"]
"Sorry..."
[cpg cn=true]

I apologized and tried my best to imagine releasing her.
[cpg]

But that was not enough to control the demon.
[cpg]

It took a long time before she was released because I still didn't know how to do it with just my mind.
[cpg]



;[SceneEnd f="sc_012"]

;[Live2d target=0]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



The scene looked familiar when it happened. I told Chartier about it.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sSchartye013"]
[OnName num="schartye"]
"I see. The more you do this, the more your qualities as the Demon King will come back."
[cpg cn=true]

[FACE method="change_6" pos="1/2"]
[VOICE f="sSchartye014"]
[OnName num="schartye"]
"I'm not going to say I'm displeased. On the other hand, it's not like I can't say what I don't like."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="4/2" time=1]

This is like what she said before.
[cpg]

[move from="4/2" to="2/2" ease="easeInOutSine" time=1000]

[VOICE f="Fia095"]
[OnName num="fia"]
"Chartier, I figured out how to get rid of it! We're going to get rid of it now!"
[cpg cn=true]


But then Fia came back.
[cpg]


After that, I figured out how to remove the tentacles and Chartier was released...
[cpg]


[STOPBGM]

[free time=1000]
[WAIT time=1000]
[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************

[window target=true]




A few days passed, and I was gradually gaining more and more magic knowledge that I could use.
[cpg]


One day, a messenger from Japan and the Elven Nation came to visit.
[cpg]


Fia took care of it for me. Or rather, I ordered her to.
[cpg]


I'm afraid to meet them in person. On the other hand, Chartier or Kullulu might take the messenger on.
[cpg]


I thought that Fia would be the best choice.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Fia096"]
[OnName num="fia"]
"They meekly said they would not kill you if you surrendered..."
[cpg cn=true]


[OnName num="kousuke"]
"What do you think...?"
[cpg cn=true]



[VOICE f="Meile124"]
[OnName num="meile"]
"Hmmm... I think it's best not to trust them."
[cpg cn=true]


Meir looked at Kullulu.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude160"]
[OnName num="clolowlude"]
"Maybe the elven magic will seal you in for life and you won't be able to die."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Schartye070"]
[OnName num="schartye"]
"Probably."
[cpg cn=true]


Fia did not deny it. It was much worse than I could have imagined.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





From that day on, I decided to set up the Demon King's Castle.
[cpg]


It's a temporary one. The village where Meir lived, the place where the leader lived.
[cpg]


The leader said he'd be happy to move for me, and it's the sturdiest house in the village...
[cpg]


Of course, it's not as defensible as a castle.
[cpg]


Still, if the other side uses force, Chartier and Kullulu said they'll take care of it.
[cpg]


Without knowing how much we could rely on them, our days of studying magic passed by.
[cpg]



;//==============================
;//ヒロイン２が攻略対象となっている場合のみイベント発生

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*eve_13_1"]
[else]
[jump target="*eve_13_2"]
[endif]



*eve_13_1|A Journey Around the World


;//■分岐
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************





I couldn't sleep, so I decided to walk around the village at night.
[cpg]


Everyone is so carefree. Even though this village could be invaded.
[cpg]


But...would they do anything for me?
[cpg]


Or do they think that if someone was to be killed, it would only be me?
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile125"]
[OnName num="meile"]
"Ah. Kosuke."
[cpg cn=true]


[OnName num="kousuke"]
"Oh... Meir ?"
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile126"]
[OnName num="meile"]
"What's wrong? You don't look well."
[cpg cn=true]


[OnName num="kousuke"]
"No, nothing's wrong."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile127"]
[OnName num="meile"]
"Everyone in my village welcomes you. You should be proud of yourself."
[cpg cn=true]


[OnName num="kousuke"]
"You say that..., but I fear of my life."
[cpg cn=true]


Meir said I might be right, but...
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile128"]
[OnName num="meile"]
"We demi-humans have been discriminated against just because we are demi-humans."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile129"]
[OnName num="meile"]
"I'm sure everyone is thinking about getting the chance to change that."
[cpg cn=true]


That's too much to ask. But I can't really say anything.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile130"]
[OnName num="meile"]
"Anyway, have you noticed Fia?"
[cpg cn=true]


[OnName num="kousuke"]
"Fia? What about Fia?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sMeile014"]
[OnName num="meile"]
"It's not just Fia. It's me and... We're all crazy about you."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah..., I guess."
[cpg cn=true]


They are all under the influence of my pheromones.
[cpg]


Perhaps it is better to try to understand that effect I have on them.
[cpg]


Maybe I should at least love those around me.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile132"]
[OnName num="meile"]
"Hey, Kosuke. Come here for a minute."
[cpg cn=true]


Meir wanted something from me. And I took her up on her offer.
[cpg]


[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

[BG f="b_10_4_l.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************



I stayed by her side for a while. We huddled our shoulders together and felt each other's warmth.
[cpg]

[FG f="CHA02_p7_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMeile015"]
[OnName num="meile"]
"Hey... Kosuke."
[cpg cn=true]

She seemed to be begging for a kiss, but my kisses contain magic elements.
[cpg]

So I didn't want to get Meir into any trouble...
[cpg]



I decided to stop there for the day.
[cpg]



[VOICE f="sMeile016"]
[OnName num="meile"]
"I don't care about that Kosuke. We don't have to do anything."
[cpg cn=true]


[OnName num="kousuke"]
"It's not that I don't want to, but there are...circumstances."
[cpg cn=true]


I wondered if Meir would be convinced if I explained everything.
[cpg]


She looked sad, but nodded.
[cpg]


;//==============================

*eve_13_2|A Journey Around the World

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





A few more days pass. My efforts were about to bear fruit.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye071"]
[OnName num="schartye"]
"That's about it... That's about as good as it gets."
[cpg cn=true]


[OnName num="kousuke"]
"Huh, huh, how's that...?"
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Fia097"]
[OnName num="fia"]
"It's amazing, Kosuke . It's really a level that no ordinary wizard can reach."
[cpg cn=true]


As a result of training, I was able to use magic, albeit falteringly.
[cpg]


Although the number of magic spells I remember is small, it is said that my power is immense...
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="sFia009"]
[OnName num="fia"]
"This is the reincarnation of the Demon King... More than anyone can imagine."
[cpg cn=true]

;//;[FO layer="1/2"]



[FACE method="change_2" pos="1/2"]
[VOICE f="Schartye072"]
[OnName num="schartye"]
"I'm not surprised. I'm sure you'll agree with my assessment."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude161"]
[OnName num="clolowlude"]
"You're right, it's more than I imagined. I'm a little more impressed."
[cpg cn=true]


[OnName num="kousuke"]
"Oh, yeah...?"
[cpg cn=true]


I didn't feel so bad anymore. And I wondered if I could protect myself a little...
[cpg]

[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_3.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



Well, now that I can protect myself. What to do next...
[cpg]


[OnName num="kousuke"]
"The next thing to do is to get a castle. We are too careless as it is now."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Fia098"]
[OnName num="fia"]
"I agree, but there's no way...we're going to get the manpower."
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[FACE method="change_7" pos="1/2"]

[VOICE f="Meile183"]
[OnName num="meile"]
"You think so? Don't you think there are more people in this village than before?"
[cpg cn=true]


[OnName num="kousuke"]
"Sure. There's been a lot of people here lately."
[cpg cn=true]


Demi-humans have been gathering all around us.
[cpg]

[FACE method="change_2" pos="2/2"]
[FACE method="change_7" pos="1/2"]
[VOICE f="Fia099"]
[OnName num="fia"]
"I wonder why they're gathering..."
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[FACE method="change_7" pos="1/2"]

[VOICE f="Meile184"]
[OnName num="meile"]
"It's all over the news. They want to help Kosuke."
[cpg cn=true]


[OnName num="kousuke"]
"I see..."
[cpg cn=true]


It seems that they are coming from all over Beast Country.
[cpg]


Since that's the case, we should get them to help us build the castle.
[cpg]


[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************


[window target=true]



So, the castle was being built little by little.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
I was not in charge of the construction, but Chartier was.
[cpg]


[OnName num="kousuke"]
"Does Chartier know anything about construction?"
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye073"]
[OnName num="schartye"]
"No. But someone has to give them a sense that they are working for the Demon King."
[cpg cn=true]


[OnName num="kousuke"]
"Is that so...?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye074"]
[OnName num="schartye"]
"Yes. The Demon King only gives orders when it's really important."
[cpg cn=true]


[OnName num="kousuke"]
"All right. I will do that."
[cpg cn=true]


Having said that, I still can't really feel it.
[cpg]



;//ブラックアウト
[window target=false]
[STOPBGM]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_03_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（昼）******************************************************

[window target=true]




Time is ticking away. The way the world looks at me will gradually change. It's not too hard to imagine.
[cpg]


The fact that I was gaining power as the Demon King, and that I was starting to build a castle, someone must be watching me.
[cpg]


[window target=false]

;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_02_2.ui" time=1000]

[WAIT time=1500]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************

[window target=true]




Although the whole country is not trying to destroy me...
[cpg]


It almost happened.
[cpg]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************





[OnName num="kousuke"]
"Assassins...?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Fia100"]
[OnName num="fia"]
"Yes. Chartier and Kullulu-Urd said they found some..."
[cpg cn=true]


It seemed that many assassins had come from the Elven Nation, who particularly abhorred the Demon King.
[cpg]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye075"]
[OnName num="schartye"]
"There's nothing to worry about. So far, Kullulu-Urd and I have managed to take care of everything."
[cpg cn=true]


That's what Chartier said, but I still felt uneasy.
[cpg]


I just hope that the castle will be completed soon...
[cpg]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_10_4.ui" time=1000]

[WAIT time=1500]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]


;//==============================
;//ヒロイン４が攻略対象となっている場合のみイベント発生
[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_14_1"]
[else]
[jump target="*eve_14_2"]
[endif]


*eve_14_1|A Journey Around the World


[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1500]


;//■分岐

;//室内ですので上下に黒帯を入れてください

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1000]
That night, I shared my concerns with Kullulu.
[cpg]


She had been assigned a guest bedroom, and I spoke with her there.
[cpg]


As Kullulu had just gone to sleep, she got up from the bed, and rubbed her eyes.
[cpg]


[OnName num="kousuke"]
"Sorry to bother you, especially this late at night."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude162"]
[OnName num="clolowlude"]
"Don't apologize, and don't worry about it. You seem to be the one having a spot of bad luck."
[cpg cn=true]


I wondered if she was trying to make me feel better, but then I remembered that Kullulu had been coming on to me, too.
[cpg]


[OnName num="kousuke"]
"Are you also now attracted to...my magical aura?"
[cpg cn=true]


Kullulu doesn't say anything. Then, she looks away for a moment.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clolowlude163"]
[OnName num="clolowlude"]
"Don't make me say it... I can't say it."
[cpg cn=true]


Kullulu looked a little tongue-tied. I wondered what she meant by that.
[cpg]





;//■選択肢
[switch]
[case "I wondered if she was expecting something."]
	[swap]
	[jump target="*IseSel05_1"]
[case "Maybe she's not attracted to me."]
	[swap]
	[jump target="*IseSel05_2"]
[endswitch]


1. Wonder if she's expecting something.
2. Maybe she's not attracted to me.



;//==============================
;//１、何か期待しているのだろうか
*IseSel05_1|A Journey Around the World




[OnName num="kousuke"]
"Kullulu... I haven't been able to spend time with you for a while, you know."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sClolowlude006"]
[OnName num="clolowlude"]
"Yeah. I've been waiting for you..."
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


[BG f="b_10_4_l.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************


;//Ｈシーンカット

And then one thing came to mind.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[OnName num="kousuke"]
"Kullulu. I have a good massage technique."
[cpg cn=true]

[OnName num="kousuke"]
"And one more thing, are you comfortable with tentacled creatures?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[VOICE f="Clolowlude187"]
[OnName num="clolowlude"]
"W-what are you talking about...? Tentacles?"
[cpg cn=true]


[OnName num="kousuke"]
"You know I can summon tentacles now, don't you? And use them."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Clolowlude188"]
[OnName num="clolowlude"]
"Don't be ridiculous. You should use that kind of thing on someone like Chartier."
[cpg cn=true]


Chartier is definitely someone who lets me do whatever I want.
[cpg]


There is a certain amount of fun in that. But there's also a certain amount of fun to be had with someone like Kullulu who doesn't like it.
[cpg]


[OnName num="kousuke"]
"Alright, let's summon it. Don't run away."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clolowlude189"]
[OnName num="clolowlude"]
"Wait, wait, wait, don't cast a spell!"
[cpg cn=true]


In the meantime, I had succeeded in summoning it.
[cpg]


[OnName num="kousuke"]
"Don't worry, it's just a massage."
[cpg cn=true]


She was terrified. But even if she tried to escape, she couldn't.
[cpg]


I decided to use my tentacles to entangle Kullulu's body.
[cpg]

[free time=800]

;//========================================
;//●ＣＧ（触手プレイ。マッサージと称している）ev_18
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：触手　　　　服装ex：無し
;//場所　：獣人の国＿室内寝室
;//時間　：夜
;//========================================

*Scene012|A Journey Around the World

[BG f="black.ui" time=1000]
[free time=1000]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sClolowlude007"]
[OnName num="clolowlude"]
"Hey, this is....really gross."
[cpg cn=true]

[OnName num="kousuke"]
"Don't move too much or you might stimulate some weird pressure points."
[cpg cn=true]

I say that, but I don't know anything about massaging.
[cpg]

On top of that, I don't think I could stimulate a....pressure point by using a tentacle I wasn't used to moving.
[cpg]

It's not a normal massage, but it's not a massage at all, is it?
[cpg]


;**【ＣＧ】 ev_18_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sClolowlude008"]
[OnName num="clolowlude"]
"Ugh, I'm being touched... It feels weird."
[cpg cn=true]

[OnName num="kousuke"]
"I've heard that the soles of the feet have many acupuncture points."
[cpg cn=true]

I said as I began to massage her body.
[cpg]

[VOICE f="sClolowlude009"]
[OnName num="clolowlude"]
"No, stop, you're tickling me."
[cpg cn=true]

[VOICE f="sClolowlude010"]
[OnName num="clolowlude"]
"It's so slimy... Really, stop it."
[cpg cn=true]

She tried to shake it off, but was unable to escape.
[cpg]

[VOICE f="sClolowlude011"]
[OnName num="clolowlude"]
"If you're going to give me a massage, I want it to be normal."
[cpg cn=true]

[OnName num="kousuke"]
"You're probably stronger than I am as a human, so I thought this might be appropriate."
[cpg cn=true]

It was all nonsense, but she accepted it, even though she didn't like it.
[cpg]

;**【ＣＧ】 ev_18_b ***********************
[CG id=4 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sClolowlude012"]
[OnName num="clolowlude"]
"You can actually give a massage. It's weird..."
[cpg cn=true]

[OnName num="kousuke"]
"I've summoned one before. I've learned to control it a little bit."
[cpg cn=true]

I was enjoying her reaction for a while as we talked about this.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


[stflag Cha4flg=1]
;//ヒロイン４は攻略対象のまま
;//■分岐

[jump target="*IseSel05_3"]

;//==============================
;//２、自分に惹かれてないのかもしれない

*IseSel05_2|A Journey Around the World



I don't know, maybe Kullulu isn't attracted to me.
[cpg]


She may have fallen in love with me because of pheromones or something, but I don't think she actually likes me.
[cpg]


[OnName num="kousuke"]
"Sorry to have bothered you."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
With that, I left Kullulu.
[cpg]

[FACE method="change_4" pos="2/3"]
I think Kullulu looked at me as if to ask why I was leaving.
[cpg]


[if exp={getFlagValue("Cha4flg") == 1 }]
[stflag Cha4flg=-1]
[endif]

;//ヒロイン４は攻略対象でなくなる


;//■分岐

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


;//==============================

*IseSel05_3|

*eve_14_2|A Journey Around the World

;//==============================





Since then, the construction of the Demon King's Castle proceeded smoothly.
[cpg]


It went smoothly because there was an abundance of manpower.
[cpg]


I wondered where the supplies were, but there were so many people that I had no trouble getting them.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************





[OnName num="kousuke"]
It's coming along nicely...
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile185"]
[OnName num="meile"]
"Yeah. It's almost finished. Is that what you call a finished castle?"
[cpg cn=true]


But other than the castle, the rest of the village hasn't changed much.
[cpg]


It would be cool if there was a castle town or something like that.
[cpg]

[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





After several days and nights, finally...
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[OnName num="kousuke"]
"Nice chair..."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye076"]
[OnName num="schartye"]
"It suits you, Your Majesty the Demon King."
[cpg cn=true]


I don't feel bad. I guess I really am a Demon King now.
[cpg]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude210"]
[OnName num="clolowlude"]
"You'll want to dress more accordingly. Like wear a royal cape."
[cpg cn=true]


[OnName num="kousuke"]
"I'll leave that to you all."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sFia010"]
[OnName num="fia"]
"If that's the case... I've already made preparations."
[cpg cn=true]

;//;[FO layer="2/2"]


Then Fia went to get something.
[cpg]

[OnName num="kousuke"]
" Is Fia particular about clothing...?"
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sMeile017"]
[OnName num="meile"]
"Maybe. I mean, elves are fashionable even in simple clothing."
[cpg cn=true]

And when she returned, Fia brought with her tastless and gaudy clothes of a Demon King.
[cpg]

[OnName num="kousuke"]
"Simple and fashionable..."
[cpg cn=true]

Meir and I looked at each other. Anyway...
[cpg]


I wonder how long it took her to make them. It's not something one could prepare right away.
[cpg]


But it seemed to suit who I've become.
[cpg]


[OnName num="kousuke"]
"Can't dress like a normal person forever. These clothes are more suitable from now on."
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="sFia011"]
[OnName num="fia"]
"Yes, it's been a labor of love."
[cpg cn=true]


She laughed. That's enough about the clothes...
[cpg]


It's a pretty big castle. It must be able to house a lot of people.
[cpg]


But even this is not enough, the number of demi-humans coming here has been increasing day by day.
[cpg]


It seemed that demi-humans were gathering from other continents and islands across the sea.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="sFia012"]
[OnName num="fia"]
"Yes, some of them have volunteered to be soldiers to protect you, Kosuke. What would you like to do...?"
[cpg cn=true]


[OnName num="kousuke"]
"There's nothing to be done. If we don't use who we can, I'm going to get killed."
[cpg cn=true]


;//;[FO layer="4/4"]

[FACE method="change_2" pos="2/2"]
[VOICE f="Meile186"]
[OnName num="meile"]
"You're right. You can't be too carefree about it, can you?"
[cpg cn=true]


After that, we started talking about creating a Demon King army.
[cpg]


I'm not going to be able to command it by myself anymore.
[cpg]


[OnName num="kousuke"]
"Okay..., it's time to start sharing roles properly."
[cpg cn=true]


[OnName num="kousuke"]
"I think Chartier and Kullulu are the right people to leave in charge of the army. Can I leave it to you two?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye077"]
[OnName num="schartye"]
"You don't have to tell me, I'm already doing it. I'm the one who's been organizing the people who are volunteering to be soldiers."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude211"]
[OnName num="clolowlude"]
"I'll help you as much as I can.... Anything to protect the Demon King."
[cpg cn=true]


[OnName num="kousuke"]
"Internal affairs will be left to... Meir."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile187"]
[OnName num="meile"]
"I don't even know what internal affairs mean. I don't know anything about politics."
[cpg cn=true]

;//;[FO layer="2/2"]

[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile018"]
[OnName num="meile"]
"I mean, I've never been in charge of...a group of people."
[cpg cn=true]


Meir was not going to listen to me. Just when I thought it couldn't be helped...
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Clolowlude212"]
[OnName num="clolowlude"]
"You are going to defy the Demon King's orders?"
[cpg cn=true]

[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile019"]
[OnName num="meile"]
"But it's not really my nature to lead others."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Schartye078"]
[OnName num="schartye"]
"But for you, the Demon King is your hope to elevate the status of demi-humans."
[cpg cn=true]


[OnName num="kousuke"]
"Please. You've been with me since the beginning."
[cpg cn=true]


[OnName num="kousuke"]
"I want you to stay by my side as much as possible. Can't you...?"
[cpg cn=true]


[FACE method="change_4" pos="1/2"]
[VOICE f="sMeile020"]
[OnName num="meile"]
"It's hard for me to say no when you're asking like that."
[cpg cn=true]


[OnName num="kousuke"]
"Don't worry, I'm going to get you an aide who knows politics. Can you just accept the title?"
[cpg cn=true]


Though I'm sure Chartier will end up choosing the person who will do that.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile021"]
[OnName num="meile"]
"Can't be helped..."
[cpg cn=true]


[OnName num="kousuke"]
"Okay. It's settled."
[cpg cn=true]



[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Fia103"]
[OnName num="fia"]
"Um, what about me...?"
[cpg cn=true]


Only Fia has not been assigned a role. I was thinking about that too.
[cpg]


[OnName num="kousuke"]
"I'd like Fia to do some diplomacy, or some negotiations...., especially with the Elven Nation."
[cpg cn=true]


It's not just the Elven Nation. The human nation of Japan, which is right next to us, also sees me as a problem.
[cpg]


But what's worse is that the Elven Nation seems to view the Demon King as an enemy.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Schartye079"]
[OnName num="schartye"]
"I can't blame them. When the other world and this world were still separate, the Elves and the Demon King were at odds with each other."
[cpg cn=true]


[OnName num="kousuke"]
"That's right. If not, it would be strange for them to be in conflict even though they are demi-humans."
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Fia104"]
[OnName num="fia"]
"Yes..., this feud goes back quite a ways. It's not something that can be managed through discussion."
[cpg cn=true]


[OnName num="kousuke"]
"Even so, I want to reduce the number of useless fights. Fia. "
[cpg cn=true]


[OnName num="kousuke"]
"You're an elf by nature, you know. I think you're the right person for the job. What do you think?"
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Fia105"]
[OnName num="fia"]
"I understand..."
[cpg cn=true]


I guess Fia is also attracted to my magical aura or pheromones. That's convenient...
[cpg]

Soon after, the four of them became the country's top ministers.
[cpg]

Before assigning them to their first job, I was made to model my new clothes.
[cpg]

[FACE method="change_2" pos="1/2"]
[VOICE f="Schartye080"]
[OnName num="schartye"]
"You look dignified, Demon King. It suits you well."
[cpg cn=true]


I'll have to wear such ostentatious clothes on a regular basis from now on... I don't hate it.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Meile190"]
[OnName num="meile"]
"By the way, are you going to rename Beast Country?"
[cpg cn=true]


[OnName num="kousuke"]
"Since we're come this far, I'd like to give it a different name."
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia106"]
[OnName num="fia"]
"What kind of name would you like? We don't want to offend the other countries too much..."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye081"]
[OnName num="schartye"]
"No, we should suggest that we dare to fight."
[cpg cn=true]


The girls are divided in their opinions, but...
[cpg]


[OnName num="kousuke"]
"I think we should simply call it the Land of the Demon King."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile191"]
[OnName num="meile"]
"Yes, I agree."
[cpg cn=true]


[FACE method="change_7" pos="2/2"]

[VOICE f="Fia107"]
[OnName num="fia"]
"Really...? Doesn't it sound a bit scary?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye082"]
[OnName num="schartye"]
"The opposite. We can't maintain our dignity with a name like that."
[cpg cn=true]


After balancing the various opinions, the name "Land of the Demon King" was chosen.
[cpg]


The "Land of the Demon King" was newly established within Beast Country.
[cpg]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト
;//【ＢＧ】『空』（夜）******************************************************





Some of the beasts were against the rule of the Demon King.
[cpg]


There was also the fact that the borders of the country hadn't been decided in the first place, so there were now two forces within the Beast Country.
[cpg]


And the anxiety in my heart did not disappear just because a castle was built.
[cpg]


Days passed by as I held the demi-humans in my arms, holding in the anxiety of not knowing when I would be killed.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************





[OnName num="kousuke"]
"Huh...?"
[cpg cn=true]


In a quiet corridor, I heard a singing voice coming from somewhere. It was a familiar voice.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia108"]
[OnName num="fia"]
"Ah..., Kosuke."
[cpg cn=true]


The voice belonged to Fia.
[cpg]


[OnName num="kousuke"]
" Fia. Do you like to sing?"
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Fia109"]
[OnName num="fia"]
"Yes, I do. I like to sing... In times like these, I don't want to forget what I like."
[cpg cn=true]


[OnName num="kousuke"]
"What's that song called?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia110"]
[OnName num="fia"]
"There are many names for it. I don't know which one is the right one... But it's a song that's been passed from generation to generation within the Elven Nation since I was a child."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia111"]
[OnName num="fia"]
"It's a song that soothes my soul. It's also a reminder of a happy past."
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


A happy past. I was a little confused by that phrase.
[cpg]


I guessed that Fia must be anxious in her own way, and I...
[cpg]


[OnName num="kousuke"]
"Fia. Where's your room again?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia112"]
[OnName num="fia"]
"Uh, it's...right around the corner."
[cpg cn=true]


[OnName num="kousuke"]
"Can I come to your room? If you can't sleep, I'd like to stay with you."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="sFia013"]
[OnName num="fia"]
"You noticed..."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


We both walked to Fia's room.
[cpg]


I snuggled up next to her and stayed with her until she fell asleep...
[cpg]

;//Ｈシーンカット



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************





After that, I continued to work on my magic.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Fia135"]
[OnName num="fia"]
"Your magic has become quite stable."
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye083"]
[OnName num="schartye"]
"No, not at all. No matter how good you are, it usually takes five years to get to this point."
[cpg cn=true]


[OnName num="kousuke"]
"Is that so...?"
[cpg cn=true]


I'm starting to be able to summon not only tentacles, but simple creatures like slime.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Meile192"]
[OnName num="meile"]
"It's a good thing you can now defend yourself, right Kosuke?"
[cpg cn=true]


[OnName num="kousuke"]
Yes, it is. Since Chartier or Kullulu always took care of it."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude213"]
[OnName num="clolowlude"]
"Really. How many assassins have been killed...?"
[cpg cn=true]


I shuddered when I heard that, but I was somewhat relieved.
[cpg]


I'll take care of myself now. Not only that, but I have friends now.
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_1.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城内＿廊下』（朝）******************************************************





[OnName num="soldier_A"]
"I can't believe the Demon King is back..."
[cpg cn=true]


[OnName num="soldier_B"]
"Yeah. It won't be long before we beasts get our just desserts."
[cpg cn=true]


[OnName num="soldier_A"]
"That's right. You have no idea how oppressed we've been..."
[cpg cn=true]


She said, noticing my appearance.
[cpg]


[OnName num="kousuke"]
"......"
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

As I walked through the corridors of the castle, soldiers would salute me.
[cpg]


It was probably orchestrated by Chartier or Kullulu. Probably Chartier.
[cpg]


I don't know, it's not annoying, but it's a bit disturbing...
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

I went outside again, thinking about what to do. Fia was next to me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia136"]
[OnName num="fia"]
"Well..., what can I do for you?"
[cpg cn=true]


[OnName num="kousuke"]
"No. I heard there's a wild tentacled creature around here."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia137"]
[OnName num="fia"]
"What...? What are you talking about, Kosuke?"
[cpg cn=true]

[OnName num="kousuke"]
"We have to study the creatures before we can use summoning magic."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sFia014"]
[OnName num="fia"]
"You know, I'm not very good with...creatures like that."
[cpg cn=true]


[OnName num="kousuke"]
"Oh well. It's not safe to be alone in an emergency."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト




As soon as I entered the forest, I saw the creature.
[cpg]

[VOICE f="sFia015"]
[OnName num="fia"]
"What?!"
[cpg cn=true]

;//========================================
;//●ＣＧ（触手がフィアに絡まる）ev_20
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：触手　　　　服装ex：無し
;//場所　：森
;//時間　：昼
;//備考　：公式サイト一枚目のＣＧです
;//========================================

*Scene016|A Journey Around the World

[BG f="black.ui" time=1000]
[free time=1000]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sFia016"]
[OnName num="fia"]
"I can't untangle it...! What power!"
[cpg cn=true]

[OnName num="kousuke"]
"Hold on. I'll help you... No..."
[cpg cn=true]

I suddenly thought. It's boring to rescue Fia right away.
[cpg]

That said, she would not be convinced if I told her as it is that it is boring.
[cpg]

[OnName num="kousuke"]
"Can you keep it distracted for a bit while I try to get it off?"
[cpg cn=true]

Fia looked at me with a surprised look.
[cpg]

;**【ＣＧ】 ev_20_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia017"]
[OnName num="fia"]
"Hey?! I'm really in trouble."
[cpg cn=true]

I know you're in trouble. But I had to come up with an excuse.
[cpg]

[OnName num="kousuke"]
"No, we need more information about this thing before using a spell..."
[cpg cn=true]

[VOICE f="sFia018"]
[OnName num="fia"]
"Hurry and do something, Kosuke...!"
[cpg cn=true]

[OnName num="kousuke"]
"I know it's terrible, but bear with me."
[cpg cn=true]

[VOICE f="sFia019"]
[OnName num="fia"]
"It's almost as if I'm the bait."
[cpg cn=true]

It's more like Fia has been the bait.
[cpg]

[OnName num="kousuke"]
"Well, the mouth is in this position. It's like an octopus."
[cpg cn=true]

;**【ＣＧ】 ev_20_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia020"]
[OnName num="fia"]
"Stop observing it and help me!"
[cpg cn=true]

Pretending to examine the tentacled creature..., I observed Fia .
[cpg]

After that, I rescued her after I understood the biology.
[cpg]




;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_10_3.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************

[window target=true]




Then evening came.
[cpg]


I have to go back to the castle soon. The Chartier is actually the one in command, but it' doesn't look good if I'm not in the castle.
[cpg]


[OnName num="kousuke"]
"We should go back to the castle, Fia."
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sFia021"]
[OnName num="fia"]
"Yes... Please don't ask me to do something like this again."
[cpg cn=true]


[OnName num="kousuke"]
"I don't know. No promises."
[cpg cn=true]


Fia gave me a look. Well, maybe she's okay with it.
[cpg]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





And then, it's night in my room.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドアノック』





I hear a knock on my door and I answer it.
[cpg]


[OnName num="kousuke"]
"Who is it?"
[cpg cn=true]



[VOICE f="Schartye084"]
[OnName num="schartye"]
"It's Chartier. Can I come in?"
[cpg cn=true]


[OnName num="kousuke"]
"Yeah... Sure."
[cpg cn=true]



[SE f="se002"]
;//【ＳＥ】『ドア開く』





[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSchartye015"]
[OnName num="schartye"]
"How are things going? Have you been with a demi-human girl yet?"
[cpg cn=true]


[OnName num="kousuke"]
"It's been pretty good..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sSchartye016"]
[OnName num="schartye"]
"That's not good enough. You're going to be awakened as a Demon King."
[cpg cn=true]


As she was saying this, Chartier was also coming on to me.
[cpg]


I'm sure she has feelings for me as well. It's not just the pheromones that are seducing her.
[cpg]


[OnName num="kousuke"]
"I've never been this popular..."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye087"]
[OnName num="schartye"]
"Just take it in stride. The Demon King is the Demon King."
[cpg cn=true]


Maybe so, but I'm not sure...
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye088"]
[OnName num="schartye"]
"It is a great honor to be touched by the Demon King. I'm so happy."
[cpg cn=true]


[OnName num="kousuke"]
"I see..."
[cpg cn=true]


When Chartier says something like that, it's hard to say anything.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



I can't read her mind. I don't know how genuine it all is...
[cpg]


;//Ｈシーンカット

;//ブラックアウト

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Then I had talked with Chartier.
[cpg]


I couldn't refuse, even though I wondered if Fia would get jealous or something.
[cpg]


In addition, I had a great reason to wake up as the Demon King.
[cpg]


I'm sure that Fia will understand.... how naive I am to think that.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





And the night dawned. In the Land of the Demon King, so far, everything was going well.
[cpg]


More people, more things. The beasts were self-sufficient to begin with.
[cpg]


There was never a shortage of food and they never complained.
[cpg]


As the number of people increased, the types of businesses increased. And as the number of people increased, so did the need for places to live.
[cpg]


The city was being developed. Houses and stores were built and developed.
[cpg]


In the end, I realized that a nation is run by its people.
[cpg]



;//ブラックアウト

[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=100]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



;//背景が変化　村の背景が徐々に薄くなって城下町になる感じ




[BG f="b_05_2.ui" time=2500]
[WAIT time=2500]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[BGM f="bg_d3"]


[window target=true]



As a result, the area around the Demon King's Castle had become quite like a castle town.
[cpg]


The demi-humans who had been scattered in different areas and races were now gathering here.
[cpg]


Of course, the Elven Nation and Japan won't take it well. Probably.
[cpg]


If I'm not careful, they could come marching in...
[cpg]


[OnName num="kousuke"]
"I can't help thinking about it..."
[cpg cn=true]


Somehow, I was walking with Meir next to me. She was optimistic, but...
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile193"]
[OnName num="meile"]
"Well, you know. I'm sure that day will come."
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="4/2" time=800]


She wasn't the type of person who fooled around with reality. Though it's not like I'm not saying that we'll always be at peace.
[cpg]



[SE f="se009"]
;//【ＳＥ】『走る』

[move from="2/3" to="1/2" ease="easeInOutSine" time=1000]

[move from="4/2" to="2/2" ease="easeInOutSine" time=1000]


[STOPBGM]




Then Fia came running in. She was out of breath and didn't look like she was here to give us good news.
[cpg]



[OnName num="kousuke"]
"What's wrong? Fia."
[cpg cn=true]



[VOICE f="Fia160"]
[OnName num="fia"]
"Elven soldiers are trying to invade..."
[cpg cn=true]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************






I hurriedly gathered the four of them and discussed it.
[cpg]


It's happening, the Elven Nation is going to lead an army to invade the Land of the Demon King. What I feared most is going to happen.
[cpg]

[free time=800]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye110"]
[OnName num="schartye"]
"There is no need to worry, the difference in strength is clear."
[cpg cn=true]


Chartier said there was no need to worry, but I had a lot to think about.
[cpg]


Will the Elven Nation be defeated? Will the Land of the Demon King be invaded?
[cpg]


Either way, it could mean that soldiers would die for me.
[cpg]


Whether it's the soldiers of the Land of the Demon King or elven soldiers, neither of them will be safe.
[cpg]


Is that really the right thing to do...?
[cpg]


[OnName num="kousuke"]
"Fia... What do you think?"
[cpg cn=true]

[free time=800]
[WAIT time=1]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Fia161"]
[OnName num="fia"]
"I've also been trying to open up a dialogue with the Elven Nation..., but it's been difficult."
[cpg cn=true]


After all, we have been bickering for years. However, I couldn't just surrender.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Clolowlude214"]
[OnName num="clolowlude"]
"Don't worry. My army is quite large, and we have weapons."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Schartye111"]
[OnName num="schartye"]
"In the first place, Kullulu-Urd and I alone are quite a force to be reckoned with. We can't lose."
[cpg cn=true]


I certainly felt that way, but I still don't think I would want to kill someone indirectly.
[cpg]

[free time=800]
[WAIT time=1]
[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile194"]
[OnName num="meile"]
"You look pale. I think you need to rest."
[cpg cn=true]


[OnName num="kousuke"]
"Oh..."
[cpg cn=true]


*IseSel06_3|
*eve_15_2|A Journey Around the World


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





Morning is coming. My anxiety continued to flow underneath.
[cpg]


Not just anxiety, but outright fear.
[cpg]


People are going to die because of me. Even if they are demi-human, it's the same thing.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude215"]
[OnName num="clolowlude"]
"Are you scared?"
[cpg cn=true]


At that time, Kullulu was visiting my room, and I was talking to her about it.
[cpg]


[OnName num="kousuke"]
"I'm not saying I'm scared. I'm just saying that I'm not...willing to kill in exchange for my life anymore."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude216"]
[OnName num="clolowlude"]
"It's not your life alone anymore. If we lose you, the Demon King's kingdom will collapse."
[cpg cn=true]


She had a point. That's true...
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude217"]
[OnName num="clolowlude"]
"Then all of us demi-humans will be persecuted even more than before."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude218"]
[OnName num="clolowlude"]
"Not only that, but those of us who have aided the Demon King may be killed."
[cpg cn=true]


It's not that I haven't thought about that possibility.
[cpg]


That's not only a possibility for Kullulu, but also Fia, who is an elf.
[cpg]


There's no going back. Even though I knew it, I was scared, as Kullulu said...
[cpg]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************





So I tried to learn a new magic.
[cpg]


There was no other way. I would create a magic that would save me from fighting.
[cpg]


I don't know if there is such a thing, but I have to find out.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia162"]
[OnName num="fia"]
"If there were such a thing as convenient as that...., I feel like we wouldn't have any trouble..."
[cpg cn=true]


[OnName num="kousuke"]
"Don't say that... It's depressing."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Fia163"]
[OnName num="fia"]
"S-sorry."
[cpg cn=true]

[free time=800]

[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Clolowlude219"]
[OnName num="clolowlude"]
"I know how you feel, Fia. We may have to fight."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye112"]
[OnName num="schartye"]
"Definitely."
[cpg cn=true]


Fia did not seem to agree with me. Since she used to be a citizen of the Elven Nation.
[cpg]


Anyway, these three are skilled in magic. We'll just have to find out from them.
[cpg]


The castle had just been built and there was no room for books.
[cpg]


So, I had to ask them steadily. I went to every wizard in the castle.
[cpg]



[free time=1000]

;//ブラックアウト

[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************



[OnName num="therianthropy_A"]
"Are there any beasts who can use magic...? I'm sure there are."
[cpg cn=true]


[OnName num="therianthropy_B"]
"But there's no such thing as magic that doesn't involve fighting..."
[cpg cn=true]


[OnName num="therianthropy_C"]
"Oh. I've heard of this kind of magic before."
[cpg cn=true]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夕方）******************************************************





So I finally found someone who has heard of this kind of magic.
[cpg]


It was a magic that a normal demi-human could not handle, but as the Demon King, I might be able to use it.
[cpg]


It seems to be a way to further enhance my original power of attracting demi-humans...
[cpg]


[OnName num="kousuke"]
"What do you think, Fia?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Fia164"]
[OnName num="fia"]
"I think it might have been a blind spot. I think it's a good idea."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye113"]
[OnName num="schartye"]
"I don't agree with it. It's a coward's idea."
[cpg cn=true]


We ignored what Chartier said for the moment and move on.
[cpg]


Even though the Elves abhor the Demon King, they are still demi-humans.
[cpg]


If they are women, they will be attracted to the magical aura of the Demon King. Just as Fia is.
[cpg]


[OnName num="kousuke"]
"Are there any women in the elven army?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Clolowlude220"]
[OnName num="clolowlude"]
"I'm sure there are. I think about half of the soldiers are women."
[cpg cn=true]


In the elven race, it seems that women are the most skilled magic users...
[cpg]


This is why there are women on the front lines, and in fact the generals are women.
[cpg]

[STOPBGM]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Once I had decided that, my actions were swift.
[cpg]


Rather, I couldn't help but hurry. The war was about to start.
[cpg]


Preventing it from happening depended entirely on my magic.
[cpg]


In the first place, even if you call myself the Demon King, it does not mean that I have become the Demon King deep down.
[cpg]


I had been living my life as a good man..., I had been an ordinary businessman.
[cpg]


I can't stand the thought of people dying to protect my orders or my life.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





I stayed up all night for two nights straight...to design and complete the magic circle.
[cpg]


[OnName num="kousuke"]
"I think it's done..."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia165"]
[OnName num="fia"]
"What do you think...? Is it going to work?"
[cpg cn=true]


[OnName num="kousuke"]
"We can't use it here. I don't know what the side effects will be."
[cpg cn=true]


Besides, we can't afford to attract more demi-humans to this country than we already have.
[cpg]


[OnName num="kousuke"]
"We've got one shot at this. They've already declared war on us, so we'd better hurry."
[cpg cn=true]


As we were discussing this, Meir came strolling in.
[cpg]

[free time=800]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile195"]
[OnName num="meile"]
"What's wrong? Kosuke, you look like you haven't slept well."
[cpg cn=true]


Meir doesn't know anything, so she can be carefree...
[cpg]


I guess she doesn't think that her life is at stake.
[cpg]


[OnName num="kousuke"]
"We're running out of time. We have to sneak into the Elven Nation."
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Meile196"]
[OnName num="meile"]
"Y-yeah. What's the plan?"
[cpg cn=true]


[OnName num="kousuke"]
"Fia , please lay it out..."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





The mission was immediately put into action.
[cpg]


I enlisted the help of the Harpies. The Harpies, including the girl from sometime ago, had mostly gathered in the Land of the Demon King.
[cpg]


They said it would be no problem at all to carry one person alone.
[cpg]


In the first place, when I returned to Japan, I was carried by the Harpies.
[cpg]


[OnName num="kousuke"]
"Then, will you carry me...?"
[cpg cn=true]

[OnName num="harpy_A"]
"Yes. You look tired, Kosuke."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah, well, I am tired..."
[cpg cn=true]


I was so exhausted that I fell asleep while the harpies carried me.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************





I was tired and fell asleep while the harpies carried me.
[cpg]


It took quite a while, but after a long time, I arrived in the Elven Nation.
[cpg]


[OnName num="suspicious_man"]
"We've been waiting for you, sir."
[cpg cn=true]


In the Elven Nation, there was the suspicious man I had met on the airship.
[cpg]


[OnName num="kousuke"]
"Who are you...?"
[cpg cn=true]


[OnName num="suspicious_man"]
"I'm sort of Chartier's minion, sir."
[cpg cn=true]


[OnName num="kousuke"]
"You've been in the Elven Nation all this time? Scouting?"
[cpg cn=true]


[OnName num="suspicious_man"]
"That's about right. Come on, let's go."
[cpg cn=true]


I'm sure he has his own difficulties.
[cpg]


But he doesn't seem to be jealous of me and Chartier.
[cpg]


This man may have been hoping for the Demon King's resurrection for some time.
[cpg]


If that's the case, I knew I couldn't fail in this mission.
[cpg]

;//qwe

;//上下に黒帯を入れてください
[STOPBGM]
[BGM f="bg_si"]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]



I disguised myself as an Elven soldier and snuck in.
[cpg]


The suspicious man had already prepared some armor that looked the part.
[cpg]


I hadn't thought about that at all. To be honest, it was a great help to have it prepared.
[cpg]


If this plan goes well, at least the female elves won't be able to attack me.
[cpg]


If half of the army won't attack, it will be difficult to invade.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
I was accompanied by Fia and several harpies.
[cpg]


Ostensibly, Fia had come to negotiate a deal that would prevent a fight.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia166"]
[OnName num="fia"]
"Good luck..., Kosuke."
[cpg cn=true]


[OnName num="kousuke"]
"Ah. Let's get out of here safely together, Fia."
[cpg cn=true]


In the meantime, I decided to head to the elven army's headquarters and use my charm magic.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]

[WAIT time=100]
[BG f="b_02_2_l.ui" time=1000]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************




I really needed to get to a place where there were a lot of soldiers.
[cpg]


For that, maybe the quarters would be better than the training grounds or something. Especially since it was night.
[cpg]


I deployed my magic. I'm just trying to get a sense of where they are located, but it's not perfect.
[cpg]


It's not perfect, but I'm doing my best to avoid a fight.
[cpg]


[OnName num="elf_soldier"]
"What...? You're new?"
[cpg cn=true]


[OnName num="kousuke"]
"Y-yes! I'm looking forward to your guidance!"
[cpg cn=true]


[OnName num="elf_soldier"]
"...?"
[cpg cn=true]


I could see I had raised suspicions. But I was let off the hook.
[cpg]


I was nervous, but I tried not to say anything unnecessary.
[cpg]


[OnName num="harpy_A"]
"With this armor..., it's hard to tell if it's a hand or a feather."
[cpg cn=true]


The harpy girl was also wearing the elven armor. This way, even if she didn't fly, she could still accompany me.
[cpg]


This means that if the need arises, we could escape together.
[cpg]


[OnName num="kousuke"]
"When the spell is activated, there will probably be people chasing us."
[cpg cn=true]


[OnName num="kousuke"]
"If we have to run, I'll be counting on you."
[cpg cn=true]


[OnName num="harpy_A"]
"You can count on me. I'll protect you, Kosuke ."
[cpg cn=true]


That's reassuring. In the meantime, I had arrived at the center of the quarters.
[cpg]




I had to draw a magic circle. It wasn't going to take more than a second.
[cpg]


If Chartier or Kullulu were here, they would be able to protect me if one or two people spotted me...
[cpg]


But there's no point in thinking about that now. I hurriedly drew the magic circle in blood.
[cpg]


The size of the magic circle was not that big. However, it seemed that my blood was flowing with magical power.
[cpg]


Even though it was a small magic circle, its effect should be far-reaching.
[cpg]



[SE f="se014"]
;//【ＳＥ】『地鳴りのような音』



A powerful magic had been activated. The earth started to rumble...
[cpg]


This is definitely going to get noticed. But I don't care if they notice me now.
[cpg]


[STOPBGM]
[BGM f="bg_tc"]



[OnName num="elf_soldier"]
"Why are you here? What are you doing?"
[cpg cn=true]


[OnName num="harpy_A"]
"Kosuke...?"
[cpg cn=true]


The magic had been activated. All that's left is to escape.
[cpg]


[OnName num="kousuke"]
"Let's go!"
[cpg cn=true]


[window target=false]

[transition target={true} rule="108.jpg" color={0x000000ff} time=1]
[WAIT time=1]
[free time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="108.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『街＿エルフの国』（夜）******************************************************

[window target=true]


[SE f="se009"]
;//【ＳＥ】『走る』


[OnName num="elf_soldier_A"]
"He's gone! That way!"
[cpg cn=true]


[OnName num="elf_soldier_B"]
"Damn, how the Demon King do this?"
[cpg cn=true]


[OnName num="elf_soldier_A"]
"I don't know! We've got to get him now!"
[cpg cn=true]


We're going to have to run for our lives. If we get caught, it's really over.
[cpg]


But with a few harpies on our side, it was almost a given that we could escape.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1500]
;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】『羽ばたく』
[BG f="b_11_4.ui" time=1000]

[WAIT time=1500]

[BGM f="bg_si"]
;//【ＢＧ】『空』（夜）******************************************************



I was carried by a harpy who took off her armor and left the Elven Nation, and now I'm on the sea.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kousuke"]
"Fia! Are you alright?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia167"]
[OnName num="fia"]
"Yes, somehow. Are you okay, Kosuke?"
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. I think the magic worked, but I can't be sure..."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sFia022"]
[OnName num="fia"]
"Maybe it's working. Even though the magic had just been activated, my heart is pounding."
[cpg cn=true]


I see. It seems to work, since it does so in a short time.
[cpg]


It is still too early to be relieved. Even though I knew that...
[cpg]


I had a sense of accomplishment for the time being. I felt like I had fulfilled my role as a Demon King and that I was on my way to a peaceful resolution.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





Exhausted, I slept soundly that night. It wasn't until noon that I woke up.
[cpg]


The good news was immediate. Half of the elven army was no longer able to attack the Demon King.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile197"]
[OnName num="meile"]
"Some of them would rather join the Demon King's kingdom. It seems that the elven army can no longer advance."
[cpg cn=true]


[OnName num="kousuke"]
"O-oh, I see..."
[cpg cn=true]


I took a breath. Crisis averted.
[cpg]


Meir looked like we had this in the bag, but it was a pretty close call.
[cpg]


I was even more relieved now because I thought it was 50-50 whether it would work or not.
[cpg]



[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1500]
[STOPBGM]
;//ブラックアウト


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_05_3_l.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城下町＿魔王の国』（夕方）******************************************************



That evening, I returned to the castle, still tired.
[cpg]



[BGM f="bg_mi"]



[OnName num="therianthropy_A"]
"Welcome back, Demon King!"
[cpg cn=true]


[OnName num="therianthropy_B"]
"The mission was a great success! That's great!"
[cpg cn=true]


[OnName num="kousuke"]
"N-no, no... There's no need to make such a fuss..."
[cpg cn=true]


[OnName num="therianthropy_A"]
"Let's have a feast today, everyone is happy that it didn't turn into a war."
[cpg cn=true]


[OnName num="kousuke"]
"Like I said..., there's nothing to be too happy about."
[cpg cn=true]


But I was relieved inside.
[cpg]


Everyone wanted to avoid a fight. That's a good thing.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************





The whole country was celebrating. There are even people who want to make it an annual holiday.
[cpg]


Everyone is happy and sad about what I do. Well, if I die, this country will be turned upside down...
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Fia168"]
[OnName num="fia"]
"Good for you, Kosuke..."
[cpg cn=true]


[OnName num="kousuke"]
"Well, yeah. My life depended on it."
[cpg cn=true]


Everyone was partying late into the night...
[cpg]


[STOPBGM]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I was still tired and went back to my room.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye114"]
[OnName num="schartye"]
"I don't like this way of doing things. It's cowardly."
[cpg cn=true]


[OnName num="kousuke"]
"Chartier... Don't come into my room without permission."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye115"]
[OnName num="schartye"]
"Can't I? If it weren't for me, you'd have been assassinated by now."
[cpg cn=true]


[OnName num="kousuke"]
"But the fact is, I drove the elves away all by myself."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye116"]
[OnName num="schartye"]
"That's why you're in a celebratory mood. I don't understand, it's not like you won the battle."
[cpg cn=true]


Chartier is being negative...
[cpg]


But she is supposed to be enchanted by me all the time.
[cpg]


But she wasn't as aggressive as the rest of them. Maybe there's something she's holding back.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye117"]
[OnName num="schartye"]
"Look. There was so much alcohol left over from the celebration. Maybe demi-humans have a weakness for alcohol."
[cpg cn=true]


[OnName num="kousuke"]
"What about you?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye118"]
[OnName num="schartye"]
"I'm strong. Shall we have a drink off?"
[cpg cn=true]


I'm not that strong, and I'm tired.
[cpg]


[OnName num="kousuke"]
"Let's just drink to this victory."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye119"]
[OnName num="schartye"]
"But it's not a victory..."
[cpg cn=true]



[SE f="se00"]
;//【ＳＥ】『乾杯』





From there, the two of us drank together for a while.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye120"]
[OnName num="schartye"]
"Your Majesty the Demon King... How do you feel about me?"
[cpg cn=true]


[OnName num="kousuke"]
"What do you mean... I'm grateful."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye121"]
[OnName num="schartye"]
"I see. Is that all?"
[cpg cn=true]


I wonder if Chartier is really a strong drinker. Or is this her pretending to be drunk?
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Schartye122"]
[OnName num="schartye"]
"It's not just appreciation I feel for you, Demon King. I'm feeling something else."
[cpg cn=true]


She sounded as if she was expecting something.
[cpg]


She's also confused by my pheromones...
[cpg]


I was unsure what to do, but I decided...
[cpg]





;//■選択肢
[switch]
[case "I'm too tired to do anything."]
	[swap]
	[jump target="*IseSel07_1"]
[case "Respond to the Chartier's feelings"]
	[swap]
	[jump target="*IseSel07_2"]
[endswitch]



1. I'm too tired to say anything.
2. Respond to Chartier's feelings



;//==============================
;//１、疲れているので何も言わない
*IseSel07_1|A Journey Around the World


[OnName num="kousuke"]
"......"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sSchartye018"]
[OnName num="schartye"]
"Hmm. I've said all this and nothing."
[cpg cn=true]


Chartier smiled a little ruefully and said...
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="sSchartye019"]
[OnName num="schartye"]
"You are free to choose not to accept my invitation here, too. After all, you are the Demon King."
[cpg cn=true]


And then she said nothing more.
[cpg]


I wondered if I had done something wrong ......, but I thought it would be a bad idea to be to think too much about it.
[cpg]



;//ヒロイン３は攻略対象でなくなる
[if exp={getFlagValue("Cha3flg") == 1 }]
[stflag Cha3flg=-1]
[endif]

;//■分岐

[jump target="*IseSel07_3"]

;//==============================
;//２、シャルティエの気持ちに応える

*IseSel07_2|A Journey Around the World



[OnName num="kousuke"]
"I'm grateful to Chartier. If it weren't for you, Chartier, I'd be long dead."
[cpg cn=true]


Chartier looked happy. I guess she was thinking about me this whole time, even though she always seemed so cruel.
[cpg]


I started to realize that and nodded my head.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="sSchartye020"]
[OnName num="schartye"]
"I can't believe... the Demon King is doing this to me."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. You've been waiting for this."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye150"]
[OnName num="schartye"]
"Of course. I'm sure the other girls are too."
[cpg cn=true]


She's right. I have a lot of people I need to love.
[cpg]


It's all because of my pheromones that attract demi-humans.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

;//Ｈシーンカット


;//ブラックアウト


;//ヒロイン３は攻略対象のまま
;//■分岐

;//==============================

*IseSel07_3|A Journey Around the World

;//ブラックアウト
[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]




Then, the fact that the Demon King had defeated the elven soldiers became known all over the world.
[cpg]


It's not just Japan, but the whole world is after me, the Demon King.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile198"]
[OnName num="meile"]
"What do you want to do, Kosuke...?"
[cpg cn=true]


[OnName num="kousuke"]
"What do you want me to do? The whole world is my enemy."
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia169"]
[OnName num="fia"]
"There's a movement in the world to create a coalition army. They want Kosuke to be sealed away at all costs..."
[cpg cn=true]


I was faced with another decision. They're all connected, country by country, and they're all against me.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia170"]
[OnName num="fia"]
"I need to do something to let them know that the Demon King is not dangerous..."
[cpg cn=true]


Fia tried to make things go smoothly. But...
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude221"]
[OnName num="clolowlude"]
"Really? I think you can conquer the world with the power of the Demon King."
[cpg cn=true]


Kullulu says I can. But I'm still confused.
[cpg]


[free time=800]

Do I want peace or do I want world domination?
[cpg]


I think it probably depends on what I've done so far.
[cpg]


To what extent am I awakening as a Demon King?
[cpg]


I think that depends on how many demi-human advances I have accepted....
[cpg]


How many thought-provoking replies have I given?
[cpg]


As I thought about this, I had one thing on my mind.
[cpg]


;//※攻略ヒロインがどれだけ居るか　によって分岐
;//※全てのヒロインを攻略対象にしている場合、魔王として覚醒　世界を征服するルートへ分岐
;//※そうで無い場合、魔王として覚醒していない　平和を望むルートへ分岐



[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*root_heiwa"]
[endif]


[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*root_heiwa"]
[endif]


[if exp={getFlagValue("Cha4flg") == 0 }]
[jump target="*root_heiwa"]
[endif]

[jump target="*root_mao"]

;//qwe

;//[jump target="*root_heiwa"]

;//==============================
;//攻略対象になっていないヒロインが居る場合


*root_heiwa|A Journey Around the World


[OnName num="kousuke"]
"I'd like to settle things peacefully..."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude222"]
[OnName num="clolowlude"]
"I knew you would say that. You're an idiot, Demon King."
[cpg cn=true]


[OnName num="kousuke"]
"Say whatever you want."
[cpg cn=true]


All I wanted was to find peace.
[cpg]


I was told that if I came into contact with too many demi-humans, I would awaken as a Demon King...
[cpg]


Now, I wasn't so much tempted as I couldn't control it.
[cpg]


I knew that I did not want to kill people.
[cpg]


It's not that I can't handle the fact that I've become a Demon King, but I didn't think about expanding my power.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I didn't want to kill anyone and gather wisdom to make it all work out.
[cpg]


Fia and Meir seemed to be taking it seriously, but...
[cpg]


Chartier and Kullulu-Urd seemed to be trying to tell me that I wasn't fighting hard enough.
[cpg]


I had sleepless nights. I went to visit one of the women.
[cpg]


I went to...
[cpg]


;//＠
;//※ここまでの選択肢で攻略対象になっているヒロインのみ選択肢に出てくる
;//※ヒロイン１は必ず選択肢に残る
;//※ヒロイン１しか残っていない場合、選択肢は発生せずヒロイン１ルートへ

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*GoRoot_1"]
[endif]

;//10?0?
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*GoRoot_01"]
[endif]

;//1000?


;//10000	フィアのみなのでフィアルート
[jump storage="ep002.ks" target="*start"]


;//1010?
*GoRoot_01


;//1010
;//■選択肢
[switch]
[case "Fia"]
	[swap]
	[jump storage="ep002.ks" target="*start"]
[case "Chartier"]
	[swap]
	[jump storage="ep004.ks" target="*start"]
[endswitch]



;//11?0?
*GoRoot_1
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*GoRoot_11"]
[endif]


;//1100
;//■選択肢
[switch]
[case "Fia"]
	[swap]
	[jump storage="ep002.ks" target="*start"]
[case "Meir"]
	[swap]
	[jump storage="ep003.ks" target="*start"]
[endswitch]



;//1110?
*GoRoot_11


;//11100
;//■選択肢
[switch]
[case "Fia"]
	[swap]
	[jump storage="ep002.ks" target="*start"]
[case "Meir"]
	[swap]
	[jump storage="ep003.ks" target="*start"]
[case "Chartier"]
	[swap]
	[jump storage="ep004.ks" target="*start"]
[endswitch]



1. Fia
2. Meir
3. Chartier



;//==============================

;//全てのヒロインが攻略対象になっている場合
;//asd
*root_mao|The Demon King



All I ever wanted was to conquer the world.
[cpg]


I guess I'm awakening as a Demon King now that I've been in contact with so many demi-humans.
[cpg]


I wondered what steps I could take to conquer the world.
[cpg]


It may be something I can do on my own.
[cpg]


Still, I wanted to ask for someone's help. I didn't feel comfortable going it alone.
[cpg]


To tell the truth, it was also a journey to find my demi-human wife.
[cpg]


It would be good to choose one person as a partner.
[cpg]


[STOPBGM]


[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




It was night. I had no more doubts about plotting world domination or choosing one person to be my partner.
[cpg]


There is only one person I love. It's...
[cpg]



;//※全てのヒロインが攻略対象になっているため、必ず全ての選択肢がある


;//■選択肢
[switch]
[case "Fia"]
	[swap]
	[jump storage="ep005.ks" target="*start"]
[case "Meir"]
	[swap]
	[jump storage="ep006.ks" target="*start"]
[case "Chartier"]
	[swap]
	[jump storage="ep007.ks" target="*start"]
[case "Kullulu-Urd"]
	[swap]
	[jump storage="ep008.ks" target="*start"]
[endswitch]


1. Fia
2. Meir
3. Chartier
4. Kullulu-Urd



