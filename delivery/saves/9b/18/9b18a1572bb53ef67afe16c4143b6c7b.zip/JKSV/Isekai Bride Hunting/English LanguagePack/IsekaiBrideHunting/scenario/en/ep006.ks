
;//==============================
;//２、メイル

*start

*ep006
*IseSel09_2|Demon King x Meir

[SCENE id=6]


It was Meir. I want her and I to rule this world together.
[cpg]


I don't know if Meir is good at magic, and I don't know what she'll think...
[cpg]


Still, I went to Meir's room.
[cpg]




;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]

[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************





[OnName num="kousuke"]
"That's why I need your wisdom, Meir "
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile361"]
[OnName num="meile"]
"You're asking for my opinion...? Why me?"
[cpg cn=true]


[OnName num="kousuke"]
"I can't ask anyone but you. Don't you get it?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile362"]
[OnName num="meile"]
"I don't get it. There are a lot of people smarter than me."
[cpg cn=true]


[OnName num="kousuke"]
"That's not the point. I want Meir."
[cpg cn=true]


I wonder if Meir understands what I'm thinking.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile363"]
[OnName num="meile"]
"I'm not very smart, so I might not be able to come up with anything..."
[cpg cn=true]


[OnName num="kousuke"]
"That's okay. Meir is my..."
[cpg cn=true]


I didn't say anything else. Meir blushed.
[cpg]


She seemed to have guessed. We don't say it in words, but we know we love each other.
[cpg]


From Meir's perspective, she thinks she owes me her life. I'm not surprised it ended up this way.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile364"]
[OnName num="meile"]
"Hmm. I don't know much about magic...., but maybe that's why I can come up with something."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. Can you think of anything?
[cpg cn=true]


Meir and I talked for a while.
[cpg]


Some of the things Meir said were ridiculous, but some of them were good ideas.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile365"]
[OnName num="meile"]
"The other day, the way we weakened the elven army. I wonder if we can apply that to humans too, not just demi-humans?"
[cpg cn=true]


[OnName num="kousuke"]
"Yeah, why not..."
[cpg cn=true]


Why do my pheromones only work on demi-humans?
[cpg]


If this were to expand its range to humans, it could be applied to other countries.
[cpg]


Maybe we can create this magic on a larger scale.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile366"]
[OnName num="meile"]
"Oh, did I say something good?"
[cpg cn=true]


[OnName num="kousuke"]
"Yes, you did. You said something very good."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Meile367"]
[OnName num="meile"]
"Then, I'd like a reward..."
[cpg cn=true]



Meir squirmed as she spoke. She was asking in a roundabout way...
[cpg]

[VOICE f="sMeile051"]
[OnName num="meile"]
"Maybe I miss having skinship, or maybe I just want warmth."
[cpg cn=true]

IWe haven't actually said we love each other. But there was definitely love there.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[BG f="b_06_4_l.ui" time=1000]
[WAIT time=1100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************




I went into Meir's room. Then I chanted a spell.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile368"]
[OnName num="meile"]
"Huh? What are you doing?"
[cpg cn=true]


[OnName num="kousuke"]
"Well, you said you want some warmth."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Meile369"]
[OnName num="meile"]
W-wait. I don't want it to be too uncomfortable... Hey, are you listening?"
[cpg cn=true]






;//========================================
;//●ＣＧ（スライムに包み込まれるヒロイン）ev_56
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：スライム　　服装ex：無し
;//場所　：城内＿ヒロイン２の部屋
;//時間　：夜
;//========================================

*Scene045

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]
[WAIT time=1000]


[BGM f="bg_h1"]
;**【ＣＧ】 ev_56_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=100]


Even though Meir sensed I might be up to something, I chanted a spell while playing dumb.
[cpg]

[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』
[WAIT time=1000]


And then a slime demon was summoned.
[cpg]

[VOICE f="sMeile052"]
[OnName num="meile"]
"Hey, I told you...!"
[cpg cn=true]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

The slime was clinging to Meir.
[cpg]

[OnName num="kousuke"]
"It's a feverish slime, so if you're talking warmth, you've got plenty."
[cpg cn=true]

[VOICE f="sMeile053"]
[OnName num="meile"]
"That's not what I meant."
[cpg cn=true]

[OnName num="kousuke"]
"Don't be so selfish."
[cpg cn=true]

;**【ＣＧ】 ev_56_a ***********************
[CG id=15 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile054"]
[OnName num="meile"]
"Ugh, it's slimy...and gross."
[cpg cn=true]

[OnName num="kousuke"]
"Don't say that after I've summoned this just for you."
[cpg cn=true]

[VOICE f="sMeile055"]
[OnName num="meile"]
"Don't be so mean...!"
[cpg cn=true]

She did not like it, but she did not run away either.
[cpg]

Or rather, even if she had wanted to escape, she couldn't.
[cpg]

Once a slime has been swallowed, I heard that it becomes difficult to move one's body freely...
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


After playing with her for a while, I sent the demon back from where it came with my magic.
[cpg]


[OnName num="kousuke"]
"I'm sorry. I just want to play around with Meir."
[cpg cn=true]


[VOICE f="sMeile056"]
[OnName num="meile"]
"That's awful..."
[cpg cn=true]



[STOPBGM]

[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_06_4.ui" time=1000]
[WAIT time=200]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile390"]
[OnName num="meile"]
"Hey, Kosuke... Do you like me?"
[cpg cn=true]


Meir asked me out of the blue.
[cpg]


Was it just a casual question, or was it something she had been wanting to ask from the bottom of her heart?
[cpg]


[OnName num="kousuke"]
"Of course. I love you, Meir."
[cpg cn=true]

[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]

Meir smiled, looking satisfied. I stroked her head, and she purred like a cat.
[cpg]


She and I have developed an unusual relationship.
[cpg]


It's different from Fia, Chartier, and Kullulu.
[cpg]


Maybe this is what you call love.
[cpg]





;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





But I've been trying to manipulate that love.
[cpg]


The magic of fascination. I'm going to make every woman in the world, human or otherwise, mine.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Fia595"]
[OnName num="fia"]
"Perhaps that idea was too far-fetched..."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye343"]
[OnName num="schartye"]
"That's true. It's not easy to charm a human woman."
[cpg cn=true]


[FACE method="change_2" pos="3/3"]
[VOICE f="Clolowlude271"]
[OnName num="clolowlude"]
"But I'm sure Kosuke could do it."
[cpg cn=true]


[OnName num="kousuke"]
"That's for sure. I'll do it."
[cpg cn=true]


If this were to happen, it would lead to world domination.
[cpg]


Even considering that most military personnel are men, in the long run, a nation cannot exist without women.
[cpg]


Depending on how I used this bargaining chip, I might be able to treat them like hostages, right?
[cpg]


I was going to gather all the women in the world and lure them to the Land of the Demon King.
[cpg]

[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





I'm going to research this magic. The magic of fascination is a strange thing, and the degree of attraction seems to be fixed.
[cpg]


Even if the magic can lead to the point where no one would want to disobey me because they were attracted to me...
[cpg]


Even after all that, it seems that magic can't manage to get to the point of developing love.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile391"]
[OnName num="meile"]
So that means that me and Kosuke are connected regardless of magic, right?"
[cpg cn=true]


[OnName num="kousuke"]
"Who knows. There's also the pheromone thing."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile392"]
[OnName num="meile"]
"Don't be so cold. You can't brush it off like that."
[cpg cn=true]


[OnName num="kousuke"]
"But if I can mesmerize them to the point that they can't resist me, that's all that matters. This magic is truly unbeatable, depending on how I use it."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile393"]
[OnName num="meile"]
"Not that it matters to me, because I'm already mesmerized."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile394"]
[OnName num="meile"]
"Hey, Kosuke. I don't think magic or pheromones have anything to do with it."
[cpg cn=true]


She's trying to make me say it. I could only nod.
[cpg]


[OnName num="kousuke"]
"Yeah..."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile395"]
[OnName num="meile"]
"Hehe. We'll always be together, Kosuke."
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************




Fia, Chartier, and Kullulu-Urd are all skilled in magic.
[cpg]


Their cooperation was indispensable in my pursuit of magical knowledge.
[cpg]



But I couldn't leave Meir out. So the five of us were in my room most of the time.
[cpg]

Meir's ideas, even though she had no knowledge of magic, seemed new to Fia and the others.
[cpg]

But with five people, my room was a bit cramped, even though it was large.
[cpg]


[STOPBGM]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]

[BG f="b_06_4.ui" time=1000]

[BGM f="bg_d3"]
[WAIT time=1000]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





And at night, I was finally alone...
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile396"]
[OnName num="meile"]
"Hey, hey, Kosuke. Is there really such a thing as beast magic?
[cpg cn=true]


I was not alone. Meir didn't go back to her room yet.
[cpg]


[OnName num="kousuke"]
"What's with this all of a sudden..., I heard there is such magic."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile397"]
[OnName num="meile"]
"I want you to try it. I've been a beast since I was born, you know."
[cpg cn=true]


[OnName num="kousuke"]
"Well, yeah."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMeile057"]
[OnName num="meile"]
"I'd like to see what happens when Kosuke turns into a beast."
[cpg cn=true]


[OnName num="kousuke"]
"That'd be an interesting roleplay. But..."
[cpg cn=true]

Is being attracted to a human different from being attracted to a beast?
[cpg]

Actually, from Meir's point of view, beasts are normal.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I don't know if there are any side effects to beast magic or not.
[cpg]


But I thought I'd just try. Because Meir was asking for it.
[cpg]


[OnName num="kousuke"]
"Uh...ugh..."
[cpg cn=true]


It's beast magic. It's really a form of combat magic.
[cpg]


The blood in my body feels like it's boiling. It's a strange kind of excitement.
[cpg]


Then, hair grew out of my skin and my figure looked like that of a beast.
[cpg]


And from that point on, I blacked out.
[cpg]










;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]



[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************

[window target=true]


[SE f="se017"]
;//【ＳＥ】『鳥の鳴き声』



[WAIT time=1000]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye344"]
[OnName num="schartye"]
"You two are getting along great."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Meile446"]
[OnName num="meile"]
"Huh...? Oh, this is..."
[cpg cn=true]


My magic was broken, and we were both on the futon together and I was in human form.
[cpg]


[OnName num="kousuke"]
"Please knock Chartier."
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye345"]
[OnName num="schartye"]
"I did. We were worried when you didn't answer."
[cpg cn=true]


[OnName num="kousuke"]
"I see... So, what do you want?"
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Schartye346"]
[OnName num="schartye"]
"My business is with Meir rather than with you, Your Majesty the Demon King."
[cpg cn=true]


Meir was flabbergasted at the sudden turn of events.
[cpg]


[FACE method="change_5" pos="2/2"]
[VOICE f="Meile447"]
[OnName num="meile"]
"Huh? Me?"
[cpg cn=true]


[OnName num="kousuke"]
"What is it? What's going on?"
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye347"]
[OnName num="schartye"]
"It's not that something has happened, it's that something's going to happen."
[cpg cn=true]


[free time=800]
[STOPBGM]


I couldn't understand what she was saying. So I waited for Chartier to continue.
[cpg]

[BGM f="bg_si"]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Schartye348"]
[OnName num="schartye"]
"Well, Meir, do you understand what it means for the Demon King to acquire further enchantment magic?"
[cpg cn=true]

[FACE method="change_7" pos="2/2"]
[OnName num="kousuke"]
"......"
[cpg cn=true]


Somehow, I've come to understand. I wondered if Meir could remain in love with me.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye349"]
[OnName num="schartye"]
"I don't really care, but I also feel sorry for you, Meir."
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Meile448"]
[OnName num="meile"]
"What do you mean...?"
[cpg cn=true]


Since Meir doesn't seem to understand yet, I'd thought I would try to explain.
[cpg]


[OnName num="kousuke"]
"Maybe humans and demi-humans will come to me without distinction."
[cpg cn=true]


[OnName num="kousuke"]
"How can you not be jealous?"
[cpg cn=true]


Meir was silent for a moment.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Meile449"]
[OnName num="meile"]
"I am jealous. Of course I'm jealous, like how I am jealous of Fia and Chartier."
[cpg cn=true]


Is that so? Then why are you letting me develop this magic?
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Meile450"]
[OnName num="meile"]
"But more than that, I want to fulfill Kosuke's wishes. If he's afraid for his life, I want to help."
[cpg cn=true]


Chartier sighed a little...
[cpg]


[FACE method="change_2" pos="1/2"]
[VOICE f="Schartye350"]
[OnName num="schartye"]
"Don't worry about it. Nevermind, just forget it."
[cpg cn=true]



[free time=800]


[SE f="se008"]
;//【ＳＥ】『歩く』





And then he left. I was a bit taken aback.
[cpg]


[OnName num="kousuke"]
"Don't you ever get possessive...?"
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile451"]
[OnName num="meile"]
"I do. But I want you to be happy more than anything, Kosuke."
[cpg cn=true]


I'm kind of scared that I'm too selfish... It makes me wonder if I'm being the person she wants me to be.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_d2"]
[WAIT time=1000]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************





However, if you think about it, the fact that I chose Meir may also be something that will make others jealous...
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]

[VOICE f="Fia596"]
[OnName num="fia"]
"Oh, good morning Kosuke..., and Meir."
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Meile452"]
[OnName num="meile"]
"Yes. Good morning, Fia."
[cpg cn=true]


I'm sure Fia is jealous of Meir. It's not like I don't know that she still has feelings for me.
[cpg]


When I think about it, I'm probably doing something pretty sinful.
[cpg]


But it's impossible to love everyone equally.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia597"]
[OnName num="fia"]
"What's wrong, Kosuke?"
[cpg cn=true]


[OnName num="kousuke"]
"Oh, no, it's nothing... Just..."
[cpg cn=true]


[OnName num="kousuke"]
"I'm just wondering if maybe I'm guilty of something."
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Meile453"]
[OnName num="meile"]
"Why...?"
[cpg cn=true]


[OnName num="kousuke"]
"Everyone is attracted to my pheromones, but I can only reciprocate one person's feelings."
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="Fia598"]
[OnName num="fia"]
"You don't have to worry about that. You're the Demon King, you should be able to do as you please."
[cpg cn=true]


[OnName num="kousuke"]
"You're right..."
[cpg cn=true]


I know. I should just love Meir as much as I can.
[cpg]



;//ブラックアウト

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





I will continue to research magic. In the meantime, I'll cherish Meir.
[cpg]

[FG f="CHA02_p7_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sMeile058"]
[OnName num="meile"]
"Hey, Kosuke... Could you summon the slime from that one time?"
[cpg cn=true]

[OnName num="kousuke"]
"You're asking for it? Have you become addicted to it?"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="sMeile059"]
[OnName num="meile"]
"Hehe."
[cpg cn=true]

As we talked, the magic was nearing completion.
[cpg]








;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





While occasionally fooling around with Meir, I did what I had to do.
[cpg]


While spending time with my beloved, my life was in imminent danger.
[cpg]


[OnName num="kousuke"]
"Okay, it's done..."
[cpg cn=true]


The magic of enchantment has been completed. It was possible to create a magic that could encompass this world with my magic power.
[cpg]


[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************





It'll take a very large magic circle. It needed to encompass the entire world.
[cpg]


Even with my magical power, I can't just invoke the magic and be done with it.
[cpg]


[OnName num="kousuke"]
"It seems like the people in this country will really listen to anything I have to say..."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Meile477"]
[OnName num="meile"]
"Looks like it. They love Kosuke."
[cpg cn=true]


I had the whole city, the whole country, drawing the magic circle.
[cpg]


A magic circle can be drawn in blood, but it is difficult to draw something of this scale in blood.
[cpg]


It's more important to have an undisturbed pattern.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye351"]
[OnName num="schartye"]
"The current Demon King could probably summon a dragon. You could paint it with your blood."
[cpg cn=true]


[OnName num="kousuke"]
"I don't want to play with life like that."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Fia599"]
[OnName num="fia"]
"It seems like something Kosuke would say, but... You also summon demons for women, right?"
[cpg cn=true]


[OnName num="kousuke"]
"That's not the same thing. Taking life is different."
[cpg cn=true]


No use in splitting hairs.
[cpg]



;//ブラックアウト
[STOPBGM]


[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[free time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_02_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（夜）******************************************************

[window target=true]




The magic was activated. The ultimate magic of enchantment.
[cpg]


From that day on, women all over the world will be enchanted by me and will be heading for the Land of the Demon King...
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_03_4.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『街＿現代』（夜）******************************************************





Race didn't matter.
[cpg]


For example, it had an effect on the women of Japan, our neighboring country.
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[transition target={true} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************





The effect appeared in a few days.
[cpg]


The Land of the Demon King is not that big, but still all the women were gathering here.
[cpg]


Buildings were being built and more and more areas were being developed.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile478"]
[OnName num="meile"]
"The other countries seem to be on alert. They can't leave Kosuke alone."
[cpg cn=true]


[OnName num="kousuke"]
"Seems like it..."
[cpg cn=true]


But I think I've won the battle.
[cpg]


Without women, the population will only decrease, so other countries will start to take advantage.
[cpg]


I think we're going to have to start competing with other countries on things that aren't military power.
[cpg]


The cLand of the Demon King is unique, and it would not be possible without magic.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile479"]
[OnName num="meile"]
"You see, the magic of enchantment...shouldn't work on people who are already enchanted, right?"
[cpg cn=true]


[OnName num="kousuke"]
"But...Meir's face is red, isn't it?"
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile480"]
[OnName num="meile"]
"Hehe, is it that obvious?"
[cpg cn=true]


Meir was rubbing herself against me. She really is like an animal.
[cpg]


[OnName num="kousuke"]
"You're so cute."
[cpg cn=true]


[VOICE f="sMeile060"]
[OnName num="meile"]
"I got a compliment. Hehe."
[cpg cn=true]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】衣擦れ


Afterwards, I gave Meir a gentle hug.
[cpg]



Meir looked satisfied...and seemed to have forgiven me.
[cpg]


And then night came again.
[cpg]

[STOPBGM]

[WAIT time=1100]


[BG f="b_05_4.ui" time=1000]

[WAIT time=1100]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************



There are still many women in the Land of the Demon King, and the woman closest to me, Meir, has grown jealous.
[cpg]


[OnName num="kousuke"]
"This must be hard for you. right...? You must be uneasy."
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile501"]
[OnName num="meile"]
"Why? I don't care about that."
[cpg cn=true]


[OnName num="kousuke"]
"But that doesn't mean you don't think about it."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile502"]
[OnName num="meile"]
"Yeah, but....it's also kind of nice to be jealous."
[cpg cn=true]


For Meir it's such an uncharacteristic thing to say. Is it a feeling of superiority?
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile503"]
[OnName num="meile"]
"It's nice when the person I love is loved by everyone."
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


I guess I've been thinking in a twisted way. Maybe Meir is just as single-minded as they come.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile504"]
[OnName num="meile"]
"Come to think of it, can't enchantment magic be cast on a man?"
[cpg cn=true]


[OnName num="kousuke"]
"Well..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile505"]
[OnName num="meile"]
"If we could do that, no one would have anything to fight over. It would be a world where we could all live in peace."
[cpg cn=true]


Of course that's not possible... It's not the kind of magic that the Demon King is known for, so it'd be hard to develop it.
[cpg]


But I didn't want to give up too soon.
[cpg]


I wanted to conquer the world so that there would be no conflict for Meir's sake.
[cpg]



;//ブラックアウト
[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





At night, I always slept with Meir.
[cpg]


I didn't officially make Meir my queen. But still...
[cpg]


I wanted to stay by her side for as long as possible.
[cpg]


That's probably what Meir is thinking as well.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************



[SE f="se017"]
;//【ＳＥ】『鳥の鳴き声』

And we get to wake up together. Sometimes I wake Meir up, sometimes the other way around.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile506"]
[OnName num="meile"]
"Wow..., is it morning already...?"
[cpg cn=true]


Today I was the first to wake up.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile507"]
[OnName num="meile"]
"Good morning, Kosuke..."
[cpg cn=true]


[OnName num="kousuke"]
"Oh, good morning."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile508"]
[OnName num="meile"]
"So, what are we going to do today?"
[cpg cn=true]


[OnName num="kousuke"]
For the time being, I had to deal with politics, and not magic research.
[cpg cn=true]


Politics are not my thing. But it was not something that I could leave to Meir.
[cpg]



;//ブラックアウト
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************





Even so, my position will never change.
[cpg]


After all, most of the people in this country are under the spell of my enchantment.
[cpg]


[OnName num="therianthropy_woman"]
"Oh, Your Majesty the Demon King!"
[cpg cn=true]


[OnName num="human_woman"]
"Good morning! Today is another wonderful day..."
[cpg cn=true]


What kind of reaction is that? I wonder if Meir really thinks nothing of it.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="1/2" time=800]

When I looked at Meir next to me, she was smiling.
[cpg]


If she's okay with this, then I'm okay with it.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]

When I got back to the castle, Meir was rubbing up against me more than usual.
[cpg]



When I patted her on the head, she seemed really happy.
[cpg]

[OnName num="kousuke"]
"You really are like an animal."
[cpg cn=true]

[VOICE f="sMeile061"]
[OnName num="meile"]
"I'm a beast."
[cpg cn=true]

She only said that when it suited her. But that side of her was cute too.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト



Since then, we have been flirting in peace.
[cpg]


It's good to have a reward like this for overcoming a life threatening crisis...
[cpg]

[STOPBGM]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




With the magic of enchantment, an immediate crisis was averted.
[cpg]


To a certain extent, the political situation in the country has been stabilized. I have to keep up this momentum.
[cpg]

[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="kousuke"]
"Would you like to be my queen, Meir...?"
[cpg cn=true]


I'm embarrassed to admit that my proposal was a bit over the top. But this is the kind of relationship we had.
[cpg]


It's a bit over dramatic to ask her to be my queen. But I thought it was appropriate.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile532"]
[OnName num="meile"]
"Hehe, of course. Please make me your wife, Kosuke."
[cpg cn=true]


Meir laughed, and I laughed along with her.
[cpg]


[OnName num="kousuke"]
"I knew there was no way you would say no..., but I was a little nervous."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile533"]
[OnName num="meile"]
"I see. Even though there was nothing to be nervous about."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile534"]
[OnName num="meile"]
"Hey, Kosuke..., I remember something from when I was really little."
[cpg cn=true]


[OnName num="kousuke"]
"What? What do you mean you remember..."
[cpg cn=true]


No, wait. Meir has been asleep for a long time. She never got old...
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile535"]
[OnName num="meile"]
"Maybe I met Kosuke before you were reincarnated. I think."
[cpg cn=true]


Meir's disease caused her body to be frozen in time. It was like a magical curse.
[cpg]


In other words, Meir was born a long time ago.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile536"]
[OnName num="meile"]
"Before I got sick, a pre-incarnated Kosuke came to our village, I think."
[cpg cn=true]


When she was young, Meir remembered the previous Demon King playing with her there.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile537"]
[OnName num="meile"]
"He was so cool. I told him I wanted to be his wife."
[cpg cn=true]


[OnName num="kousuke"]
"What did he say to that...?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile538"]
[OnName num="meile"]
"He said, 'I have Chartier.' and that his life span was different than mine."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile539"]
[OnName num="meile"]
"But he said we might be reincarnated and get together. And then Kosuke appeared..."
[cpg cn=true]


Actually, Meir was never reborn, time stopped and only I was reborn, and now we are together.
[cpg]


[OnName num="kousuke"]
"What a romantic story. You're not making this up, are you?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Meile540"]
[OnName num="meile"]
"Oh, you don't believe me? That's terrible."
[cpg cn=true]


[OnName num="kousuke"]
"I'm kidding. I think it was fate that brought me to you, Meir ."
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile541"]
[OnName num="meile"]
"Yeah..., that's right. It's fate, isn't it?"
[cpg cn=true]


Me and Meir kissed each other. For a while, this country will remain peaceful.
[cpg]


A love that was once unfulfilled is now fulfilled.
[cpg]


So, I guess it's okay to just bask in it for now.
[cpg]



;//ＥＮＤ　ヒロイン２征服ルート

[WAIT time=100]
[jump storage="epend.ks" target="*start"]
[WAIT time=100]
;[s]
[WAIT time=100]
[WAIT time=100]



