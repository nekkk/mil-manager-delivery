
;//==============================
;//３、ヒロイン３

*start

*ep007
*IseSel09_3|Demon King x Chartier

[SCENE id=7]


I thought of Chartier.
[cpg]


I could say that she was the only one for me. I could also say that I had met her before Fia or Meir.
[cpg]



;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye352"]
[OnName num="schartye"]
"What's wrong, Your Majesty?"
[cpg cn=true]


That's why I invited Chartier to my room.
[cpg]


[OnName num="kousuke"]
"I've decided to conquer the world... So I need your wisdom to do it."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye353"]
[OnName num="schartye"]
"Hmm. That's what the previous Demon King said..."
[cpg cn=true]


[OnName num="kousuke"]
"I've always wondered if you knew me before my reincarnation."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye354"]
[OnName num="schartye"]
"That's right. I saw how the previous Demon King connected the other world with this one."
[cpg cn=true]


[OnName num="kousuke"]
"You mean the previous me. Why did I do it?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye355"]
[OnName num="schartye"]
"It was not enough to just conquer the other worlds of the past... In a nutshell, there are many more reasons."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye356"]
[OnName num="schartye"]
"But in order to connect this world with the other world, you had to expend too much magic power. Your body just couldn't take it anymore."
[cpg cn=true]


It seems that at that moment, I was reincarnated as the human being, Kosuke, and carried over my ambition to the next reincarnation.
[cpg]


[OnName num="kousuke"]
"So that's what happened..."
[cpg cn=true]


I was a pretty gutsy guy before my reincarnation. I can't believe I had ambitions that I wanted to fulfill even after dying.
[cpg]


The fact that I want it now after all seems to be some kind of fate.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye357"]
[OnName num="schartye"]
"Now, if we want to take over the world, we're going to need more troops than this."
[cpg cn=true]


[OnName num="kousuke"]
"That's the only way. Do you have any ideas?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Schartye358"]
[OnName num="schartye"]
"You do understand, Your Majesty the Demon King. I can't tell you without anything in return."
[cpg cn=true]


Chartier blushed. It looks like I needed to satisfy her.
[cpg]


[OnName num="kousuke"]
"I'll do whatever you want. What do you want? Tell me what you want and I'll make it happen."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]


[VOICE f="sSchartye030"]
[OnName num="schartye"]
"Then I need a favor."
[cpg cn=true]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="CHA03_p7_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_06_4_l.ui" time=1000]
[WAIT time=1500]


She said and closed her eyes. I knew what she meant, but I was confused.
[cpg]

[VOICE f="sSchartye031"]
[OnName num="schartye"]
"What is it? You're not going to do it?"
[cpg cn=true]

[OnName num="kousuke"]
"N-no. I will."
[cpg cn=true]

I kissed her on the mouth. She must have been waiting for this moment for a long time.
[cpg]



[STOPBGM]

[WAIT time=1500]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[window target=true]


Then, the next afternoon came.
[cpg]


[OnName num="kousuke"]
"Hey. I thought you were going to help me."
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye379"]
[OnName num="schartye"]
"Hold on. I still have something to tell Your Majesty the Demon King."
[cpg cn=true]


[OnName num="kousuke"]
"What do you need to tell me...?"
[cpg cn=true]


We had come to the outskirts of the castle town.
[cpg]


The further we went, the more the road disappeared.
[cpg]


[OnName num="kousuke"]
"Where are you taking me, Chartier?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye380"]
[OnName num="schartye"]
"Just follow me. I'll show you."
[cpg cn=true]


We walked some more. We walk further and further until we reach the edge of the city.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_13_4.ui" time=1000]
[WAIT time=1500]



And then Chartier took me into a cave-like place.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Schartye381"]
[OnName num="schartye"]
"It's a place that I used to visit with the former Demon King, before your reincarnation."
[cpg cn=true]


[OnName num="kousuke"]
"This place? It looks like an ordinary cave.!
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye382"]
[OnName num="schartye"]
"In the past, I was a difficult child. I used to run away from home all the time."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye383"]
[OnName num="schartye"]
"One time I ran away from home, and I was crying here, and the Demon King found me."
[cpg cn=true]


Did Chartier live near the former Beast Country...? I guess that's not the main point of this discussion.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sSchartye032"]
[OnName num="schartye"]
"I and the former Demon King were lovers. It was platonic, though."
[cpg cn=true]


That's an odd story, it's different from what I've heard so far.
[cpg]



[OnName num="kousuke"]
"The previous Demon King was not a womanizer? Platonic? That's weird."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye385"]
[OnName num="schartye"]
"It's not for me to say, but...I guess I was special. And I was very young."
[cpg cn=true]


[OnName num="kousuke"]
"You're talking about finally fulfilling this wish?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Schartye386"]
[OnName num="schartye"]
"Yeah. Since you're the Demon King..."
[cpg cn=true]


I have a pretty good idea what Chartier wanted.
[cpg]


I wanted to respond to her. But I just couldn't muster up the courage.
[cpg]



[SE f="se005"]
;//【ＳＥ】『魔法の音』


[WAIT time=1500]


I cast a spell. I thought about what she needed right now.
[cpg]



;//========================================
;//●ＣＧエロ（スライム姦。ヒロイン嫌がっていない感じ）ev_63
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：スライム　　服装ex：無し
;//場所　：洞窟
;//時間　：昼
;//備考　：公式サイト二枚目のＣＧです
;//========================================

*Scene052

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_63_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=100]




[VOICE f="sSchartye033"]
[OnName num="schartye"]
"What's the meaning of this...? This isn't what I wanted."
[cpg cn=true]

[OnName num="kousuke"]
"Well, listen to me. This slime is specially developed."
[cpg cn=true]

[OnName num="kousuke"]
"This is the slime of sleep, and it will give you the best dreams. It's so good, you won't even remember it was a dream."
[cpg cn=true]

[VOICE f="sSchartye034"]
[OnName num="schartye"]
"Why don't you just...embrace me?"
[cpg cn=true]

I don't have the courage. I don't think she'd be convinced if I told her that.
[cpg]

[VOICE f="sSchartye035"]
[OnName num="schartye"]
"Ah...h..."
[cpg cn=true]

Little by little, Chartier's expression became more and more vacant. I'm sure she's hugging me in her dreams right now.
[cpg]

I'm disgusted with myself for not being good enough, but I can't help it...
[cpg]

;**【ＣＧ】 ev_63_a ***********************
[CG id=16 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sSchartye036"]
[OnName num="schartye"]
"......"
[cpg cn=true]

And she seems to have completely let go of her consciousness.
[cpg]

She has a look of peace. And she'll have no memory of me having done this to her.
[cpg]

[OnName num="kousuke"]
"I'm sorry."
[cpg cn=true]

I say that, but I can't keep fooling around like this.
[cpg]

I knew I had to accept Chartier's love head on.
[cpg]



;//ブラックアウト




[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1]


The night passed. The next day, me and Chartier had gathered the other three.
[cpg]

[STOPBGM]
[WAIT time=1000]

[window target=false]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Schartye412"]
[OnName num="schartye"]
"We're going to invade the Elven Nation. That's what the Demon King has decided."
[cpg cn=true]



[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Fia600"]
[OnName num="fia"]
"I-I'm against it. As a former citizen, I cannot allow that to happen."
[cpg cn=true]


[OnName num="kousuke"]
"Even if Fia doesn't allow it, it's my will. That's not why I'm telling you this."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Meile542"]
[OnName num="meile"]
"But I'm curious about the difference in strength... Do we have a chance of winning?"
[cpg cn=true]


Meir turns to Chartier. Chartier nodded.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye413"]
[OnName num="schartye"]
"Well, the other world has completely merged with this world, but..."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye414"]
[OnName num="schartye"]
"But there is one more world, the underworld."
[cpg cn=true]


Hearing what she said I realized it too. There is a third world, different from the two merged worlds.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude272"]
[OnName num="clolowlude"]
"I'm from there, too. There are demi-humans living in the underworld..."
[cpg cn=true]


[OnName num="kousuke"]
"Maybe they'll follow me."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Fia601"]
[OnName num="fia"]
"You're going in without being sure...?"
[cpg cn=true]


[OnName num="kousuke"]
"I'm not sure, but I have to try. After that we can go on the offensive."
[cpg cn=true]


That's what I decided, and I let everyone know of my plans.
[cpg]


I will conquer the world. That feeling I have will never waver again.
[cpg]


I'm going to do it so that Chartier and I can live happily ever after without anyone trying to kill us.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************



[SE f="se08"]
;//【ＳＥ】『歩く』

[WAIT time=1000]




At night, I walked around the castle, unable to sleep.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye415"]
[OnName num="schartye"]
"Demon King. You couldn't sleep either?"
[cpg cn=true]


[OnName num="kousuke"]
"Chartier...you too?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye416"]
[OnName num="schartye"]
"Well, yeah. Probably for different reasons."
[cpg cn=true]


Chartier's face was flush. I could sense how she felt.
[cpg]


[OnName num="kousuke"]
"Chartier, if you can't sleep, I can distract you..."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]


With a flushed face, Chartier nodded.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_06_4_l.ui" time=1000]
[WAIT time=1500]



I walked into Chartier's room. I could have summoned the slime again, but...
[cpg]


I can't fake that forever. Or hide my own feelings anymore.
[cpg]






;//ブラックアウト




[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]


[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




My love for Chartier has only deepened. In the meantime, there are those who would tear us apart.
[cpg]


Before we decided to invade, there was talk of the Elven Nation coming for us.
[cpg]


Even though there is a long history between the Demon King and the Elves... it is difficult to talk about.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





We had to perfect the magic that would connect us to the underworld soon.
[cpg]


Fia was not in favor of fighting. The three of us, Chartier, Kullulu and I, researched the magic.
[cpg]


Finally, after several days and nights, we finally came up with something.
[cpg]



[SE f="se006"]
;//【ＳＥ】『魔法の音　衝撃波』



;//フラッシュ
[window target=false]
[transition target={true} rule="cube.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


[transition target={true} rule="cube.webp" color={0xffffffff} time=1]
[WAIT time=100]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0xffffffff} time=1000]
[WAIT time=1500]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]





In the center of the magic circle, there was a humanoid shadow.
[cpg]


It's not a simple life form, like tentacles or slime.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Clolowlude273"]
[OnName num="clolowlude"]
"Looks like it worked..."
[cpg cn=true]


[FACE method="change_7" pos="1/2"]

[VOICE f="Schartye439"]
[OnName num="schartye"]
"Um, hey... Do you know who this person is?"
[cpg cn=true]


[OnName num="devil_woman"]
"Could it be possible that you..."
[cpg cn=true]


Chartier and Kullulu look at me.
[cpg]


[OnName num="kousuke"]
"Ahem... I'm the Demon King."
[cpg cn=true]


I guess I'll just have to call myself this. As I was thinking this, the summoned demon knelt down to me.
[cpg]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[BGM f="bg_d3"]




With that I began summoning demi-humans from the underworld.
[cpg]


Staying under the radar, I gradually increased my troops.
[cpg]


All the while, my pheromones were mesmerizing the people around me.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye440"]
[OnName num="schartye"]
"Your Majesty the Demon King... It seems that your summoning from the underworld is going well."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah, but if they're a woman it's a bit of a problem that they're attracted to me..."
[cpg cn=true]


But it helps to know that they will follow me without fail.
[cpg]


Even men wouldn't have disobeyed me if they knew I was the Demon King.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye441"]
[OnName num="schartye"]
"I think about it sometimes. I sometimes wonder if the Demon King will always love me."
[cpg cn=true]


[OnName num="kousuke"]
"Don't worry about that. It's nothing to be concerned about."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye442"]
[OnName num="schartye"]
"Really? Then prove it to me."
[cpg cn=true]




When she put it like that, I couldn't help but do something.
[cpg]

[OnName num="kousuke"]
"I think about it too. I sometimes wonder how much Chartier likes me."
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_06_4_l.ui" time=1000]
[WAIT time=1500]


[OnName num="kousuke"]
"Will you love anything I summon?"
[cpg cn=true]

[VOICE f="sSchartye037"]
[OnName num="schartye"]
"Yeah. I'll accept anything you do, Demon King."
[cpg cn=true]

[OnName num="kousuke"]
"You said it."
[cpg cn=true]

As I watched her nod, I cast a spell.
[cpg]





;//========================================
;//●ＣＧ（ヒロインの体を蜘蛛が這う）ev_64
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：蜘蛛　　　　服装ex：無し
;//人ex２：主人公　　　服ex２：着衣
;//場所　：城内＿主人公の部屋
;//時間　：夜
;//========================================

*Scene054

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

[WAIT time=1000]
[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』

[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_64_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=100]



I wondered if she really wouldn't mind whatever I did to her.
[cpg]

It's not really an experiment, but I wanted to see.
[cpg]

[VOICE f="sSchartye038"]
[OnName num="schartye"]
"What did you have in mind, Demon King?"
[cpg cn=true]

[OnName num="kousuke"]
"What do you mean? You said you'll accept anything I do, right?"
[cpg cn=true]

[VOICE f="sSchartye039"]
[OnName num="schartye"]
"Yes, I will..."
[cpg cn=true]

A spider crawled over her body.
[cpg]

[OnName num="kousuke"]
"You know this spider, right? It's a demon."
[cpg cn=true]

[OnName num="kousuke"]
"The threads that it spits out are supposed to help with the stagnation of magic. Chartier, you must be happy since you're a magic user, too."
[cpg cn=true]

[VOICE f="sSchartye040"]
[OnName num="schartye"]
"Of course... I'm fine with this."
[cpg cn=true]

The way she said she was fine, I could tell she was not fine.
[cpg]

But still, she was trying hard to endure. She's so adorable.
[cpg]

;**【ＣＧ】 ev_64_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sSchartye041"]
[OnName num="schartye"]
"If you're so worried about the stagnation of magic, shall we do the same for the Demon King later?"
[cpg cn=true]

[OnName num="kousuke"]
"N-no. I'm good."
[cpg cn=true]

Chartier is a bit of a bully herself.
[cpg]

I love the fact that our relationship dynamic has not easily changed.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]


Since then, I've made the Demon King's army stronger. I recruited supporters from the underworld.
[cpg]


As a result, the Demon King's army was growing in number.
[cpg]


No one noticed it. If I may say so, this development would be unexpected of any country.
[cpg]


I think that the Elven Nation is being a bit careless.
[cpg]


[STOPBGM]


[window target=false]


[transition target={true} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1500]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1500]
[BGM f="bg_si"]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************

[window target=true]




[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye469"]
[OnName num="schartye"]
"The battle will begin tomorrow..., won't it?"
[cpg cn=true]


[OnName num="kousuke"]
"Yes. But I have no doubts."
[cpg cn=true]


[OnName num="kousuke"]
"Kill them before they kill us. It's the only way."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye470"]
[OnName num="schartye"]
"Take it easy. We're the ones who have to get our hands dirty."
[cpg cn=true]


[OnName num="kousuke"]
"Sorry..., Chartier"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Schartye471"]
[OnName num="schartye"]
"Don't worry about it. It's all because I love you, the Demon King."
[cpg cn=true]

[free time=800]

[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Clolowlude274"]
[OnName num="clolowlude"]
"It seems like things are going well between you two. It's almost like it's not the night before the battle."
[cpg cn=true]


[OnName num="kousuke"]
"Oh, you're here, Kullulu."
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Clolowlude275"]
[OnName num="clolowlude"]
"Yeah. The soldiers are feeling confident. Still, maybe you should inspire them in person, Demon King."
[cpg cn=true]


[OnName num="kousuke"]
"Yes..."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]



I decided to inspire the soldiers directly.
[cpg]


They all seemed to have a lot of blood in their veins. They were pumped, but they were listening to my words carefully and quietly.
[cpg]


[OnName num="kousuke"]
"We will reclaim the world! We're going to make the world of demi-humans again!"
[cpg cn=true]


Then I shouted, and the soldiers shouted. Those voices sounded like the earth shaking back.
[cpg]


I think I've finally reached a point of no return. But this is good.
[cpg]


It's what Chartier wants, too. So...
[cpg]


[STOPBGM]

[window target=false]


[transition target={true} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_tc"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************

[window target=true]




We invaded the Elven Nation.
[cpg]


Of course, I'm not talking about me taking the lead or anything.
[cpg]


Even Chartier would not be on the front lines.
[cpg]


There still was a difference in military strength. We were careful in the unlikely event that Chartier or I should fall.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





From the perspective of the Elven Nation, it would not seem like a surprise attack.
[cpg]


They must have thought about war and that there was a possibility they could be attacked at any time.
[cpg]


[STOPBGM]

[BG f="b_09_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_de"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************





But I had built up enough of an army to conquer the Elven Nation.
[cpg]


If I did this, it would finally be an official declaration of war, but I didn't mind.
[cpg]


I knew why dictators around the world liked to invade.
[cpg]


In other words, I knew what it was like to have your life threatened.
[cpg]


What it means to have the whole world as your enemy. I thought I knew...
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Schartye472"]
[OnName num="schartye"]
"Let's go! Prepare to sacrifice your life for the Demon King!"
[cpg cn=true]


Countless soldiers responded to Chartier's words.
[cpg]


There's no way we couldn't win. The question is, how long would it take...
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//＠
[SE f="se018"]
;//【ＳＥ】『剣戟』

[WAIT time=3000]

[stopse g=2]
;//通常se

[STOPBGM]


[BG f="b_09_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『草原』（夕方）******************************************************

[window target=true]






That's what I thought, but the battle with the Elven Nation was over in an instant.
[cpg]


It was too one-sided. There was no need for Chartier, me, or anyone else to get involved.
[cpg]


[OnName num="kousuke"]
"This was too easy. It must be a trap."
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye473"]
[OnName num="schartye"]
"A trap? What kind of trap is that? To abandon your entire country?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye474"]
[OnName num="schartye"]
"It's hard to imagine. So it makes you wonder who's behind it."
[cpg cn=true]


She was absolutely right. The Elven Nation had no choice but to fight with all their might.
[cpg]


In the first place, the magical soldiers of the elven army were already weakened.
[cpg]


If there was a difference in the strength of the troops, it may be only natural to have this outcome...
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_11_3.ui" time=1000]
[WAIT time=1500]



Then, the Land of the Demon King gained territory across the sea.
[cpg]


Because of me, a considerable number of lives were lost. Not only the lives of demi-humans belonging to the Land of the Demon King, but the elven lives too.
[cpg]


My heart hurt and I was riddled with guilt. Still...
[cpg]


I found myself feeling relieved.
[cpg]


I was thinking that the chances of me surviving had increased.
[cpg]




[window target=false]
[STOPBGM]

[WAIT time=1000]


[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




The citizens of the Land of the Demon King were happy about this victory.
[cpg]


Fia seemed to have mixed feelings, but Kullulu celebrated.
[cpg]


Meir seemed to be pleased with...whatever stance I took.
[cpg]

[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
After all the festivities had passed, Chartier and I were left alone.
[cpg]


[OnName num="kousuke"]
"I think this was the right thing to do..."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye475"]
[OnName num="schartye"]
"What do you mean? Of course it's good, it's what we've always wanted."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. It was for the best."
[cpg cn=true]


The most important battle was over. I couldn't have been more nervous.
[cpg]


We were both feeling a bit out of sorts.
[cpg]




[OnName num="kousuke"]
"Chartier, how am I supposed to feel?"
[cpg cn=true]


[VOICE f="sSchartye042"]
[OnName num="schartye"]
"What do you mean 'how'? You should be feeling like you can rest a little easier."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah..., it is nice to feel a little relieved."
[cpg cn=true]


[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1500]
[WAIT time=2500]
;//ブラックアウト




;//[BG f="b_02_2.ui" time=10]

[BGM f="bg_ma"]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************


[CG id=20 index=0 time=1000]

[WAIT time=1000]


[window target=true]




And then we began to rule the Elven Nation.
[cpg]


It's better to say the former Elven Nation, because now it is part of the Land of the Demon King.
[cpg]


Reinforcements from the underworld were no longer needed.
[cpg]


The newly conquered Elven Nation had had its talented wizards study new military magic.
[cpg]


They have become powerful enough to compete with great powers...
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_11_2.ui" time=1000]
[WAIT time=1500]


In this day and age, it is said that if we were to start a serious war, the earth would be destroyed.
[cpg]


But we had enough power to prevent that from happening.
[cpg]


Even if all the weapons in the world were to be launched at the Land of the Demon King, we and our people would be safe.
[cpg]


That's how much magic technology we've acquired.
[cpg]

[STOPBGM]
[WAIT time=1500]


[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





While making love to Chartier, I continued to go further and further down the path of evil.
[cpg]


Eventually, the day will come when this world will surrender to me, the Demon King.
[cpg]


I may have been just an ordinary person, but I had the makings of an evil mastermind.
[cpg]


And more than that, I could say that Chartier was possibly even more infamous.
[cpg]


To tell you the truth, this country could run without me.
[cpg]


It could do with just Chartier.
[cpg]


Still, Chartier loves me.
[cpg]


On top of that, I had a magical power that no one else could match. We were invincible.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Schartye505"]
[OnName num="schartye"]
"You know, Demon King. I broke up with my former lover in death."
[cpg cn=true]


[OnName num="kousuke"]
"I see..."
[cpg cn=true]


Next to me, sitting on the bed, Chartier talked about the past.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye506"]
[OnName num="schartye"]
"After all, no matter what, the Demon King before his reincarnation and the Demon King now are two different people."
[cpg cn=true]


Chartier had a thoughtful look on her face. However...
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye507"]
[OnName num="schartye"]
"It's because of you..., that I was able to fulfill the wishes of the previous Demon King."
[cpg cn=true]


Chartier continued. A tragic love that never came true was revealed.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye508"]
[OnName num="schartye"]
"Before we were connected to this world, our world was a terrible place."
[cpg cn=true]


In the past, even after the Demon King conquered the world, the other world was still impoverished.
[cpg]


Due to abnormal weather, crops could not be grown. It seemed that without food, no matter what kind of magic technology was available, a nation could not survive.
[cpg]


For the sake of the people, I sacrificed my own life, hoping to connect with the other world, the world where I originally lived.
[cpg]


As a result, the countries ruled by a single Demon King were torn apart.
[cpg]


[OnName num="kousuke"]
"I didn't know about all that..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye509"]
[OnName num="schartye"]
"Yeah. In the end, he sacrificed his life for his people."
[cpg cn=true]


He was the Demon King who had developed a human side, and then had been reborn as me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye510"]
[OnName num="schartye"]
"But now we're going back to the way things were. A world ruled by the Demon King...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye511"]
[OnName num="schartye"]
"It was never a world where people complained. People had faith in the Demon king."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye512"]
[OnName num="schartye"]
"You must have inherited that character. I believe in you."
[cpg cn=true]


[OnName num="kousuke"]
"Chartier..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye513"]
[OnName num="schartye"]
"I want you to rule this world. That's what I want, and that's what the former Demon King wanted."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_11_2.ui" time=1000]
[WAIT time=1500]



I decided to conquer this world in order to make the world that Chartier and the former Demon King dreamed of come true.
[cpg]


This was not just a path of evil, but a necessary one, mixed with justice.
[cpg]


Above all, if this is what Chartier wished for, I want it to come true. That's all.
[cpg]


It was a love that transcended good and evil.
[cpg]



;//ＥＮＤ　ヒロイン３征服ルート

[WAIT time=100]
[jump storage="epend.ks" target="*start"]
[WAIT time=100]




