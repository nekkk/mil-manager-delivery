*start

;###################################################################
*Ep005|即使被改造，勇敢的人也会害怕。
;###################################################################


[SCENE id=5]


[BG f="black.ui"  time=1000]
[WAIT time=100]


[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]


[window target=true]


而在第二天。
[cpg]

[window target=false]





[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





我总是在这个地牢的某个时间醒来，地牢里的灯光总是很暗。
[cpg]


我得到了一个这样的台钟。即使没有闹钟功能，我也能有点起床气。
[cpg]


但是，我还是希望至少能看到一次光明。......
[cpg]


这个身体是一个恶魔，所以它可能在应对一个没有光的世界。
[cpg]


但我觉得我的心，或我的灵魂，作为一个人，正在寻找光明。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=800]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="4/5" time=800]

[VOICE f="Janice047"]
[OnName num="janice"]
'你想看看太阳吗？
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Arsha091"]
[OnName num="asha"]
'但在地面附近并不安全。人类将被淘汰'。
[cpg cn=true]


我仍然想看。我向他解释了这一点，并请他给我指点一下通往地面的路。
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Janice048"]
[OnName num="janice"]
'我没有选择......，如果你这么坚持，我就给你看。
[cpg cn=true]


[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]
[FO pos="4/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





珍妮丝带我走了一半，我被带到了地牢的出口，或者说是入口......？　我们已经来到了附近的。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Janice049"]
[OnName num="janice"]
'要小心。如果你看到一个人类，你应该跑。"
[cpg cn=true]


在珍妮丝的建议下，我朝地面走去。
[cpg]

[SE f=se007]
;//【ＳＥ】『ゴーレム足音』

我采取了格木的形式，这样万一我被人类发现了，对方就会跑掉。
[cpg]


然后，当我到了地上，我去了......
[cpg]



;//画面白く

[STOPBGM]


[window target=false]
[transition target={true} rule="tobira.webp" color={0xffffffff} time=2000]
[WAIT time=3100]
[FO pos="2/3" time=1]
[BG f="white.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0xffffffff} time=1]
[WAIT time=1]



[transition target={true} rule="tobira.webp" color={0xffffffff} time=1]
[WAIT time=1000]
[BG f="b_09_2.ui" time=1000]
[WAIT time=200]
[transition target={false} rule="tobira.webp" color={0xffffffff} time=2000]
[WAIT time=3100]

[window target=true]
[BGM f="06"]
;//【ＢＧ】『平原』（昼）******************************************************



;//徐々に色調戻る





这让人眼花缭乱。只是让人眼花缭乱。
[cpg]


我听说当你在很长一段时间内第一次看到太阳时就会发生这种情况。......。
[cpg]


那是一种含泪的光。
[cpg]


但我心想，我不认为格木有任何器官会让我哭。
[cpg]


[SE f=se022]
;//【ＳＥ】『草むらが揺れる』
[WAIT time=1100]

有一个人的存在。我觉得自己是个混蛋。
[cpg]


[OnName num="swordfighter"]
'......，为什么这里会有恶魔？他们怎么可能在地面上，侦查或什么的？
[cpg cn=true]


[OnName num="monk"]
'克拉拉，我们现在该怎么办？
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Clara001"]
[OnName num="clara"]
'......'
[cpg cn=true]

[SE f=se014]
;//【ＳＥ】『弓を引き絞る』

克拉拉，正如女精灵对她的称呼，准备好她的弓。
[cpg]


我冲回地下。但是，这些妇女是否想攻克地牢？
[cpg]


如果是这样，逃亡只是暂时的。他们会追上你。
[cpg]


[SE f=se007]
;//【ＳＥ】『ゴーレム足音』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_06_0 ***********************
;//カットイン
[CUTIN f="ci_06_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

我赶紧把自己伪装成粘液，藏在墙的缝隙里。
[cpg]

[CUTIN f="ci_06_0.ui" show={false} method="slideout"]
[WAIT time=1000]

[SE f=se010]
;//【ＳＥ】『走る』
[WAIT time=1000]

[OnName num="monk"]
'他不在这里。......，他消失到哪里去了？
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Clara002"]
[OnName num="clara"]
'也许它不仅仅是一个格木。它可能已经变形，并潜伏在这里的某个地方。
[cpg cn=true]



好一句话。如果他们发现我，我就完了。
[cpg]


但那些石头，他们没有想到格莱姆会变成粘液，他们就直接穿过去了。......
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="4/5" time=800]
[VOICE f="Janice050"]
[OnName num="janice"]
'你说有一个克拉拉！'
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Dorothy018"]
[OnName num="dorothy"]
'你没有看错，是吗？　Renji不知道Kulara长什么样子。"
[cpg cn=true]


[OnName num="renzi"]
'是的。但我想我的伙伴说是库拉拉。
[cpg cn=true]


我是一个人形粘液，正在和珍妮丝和多萝西交谈。
[cpg]


[OnName num="rudolf"]
'......，我没有看到他们进入深处的任何迹象。
[cpg cn=true]


恶魔领主在说这话时似乎感觉到了一种存在。
[cpg]


可能他是控制地牢的人，所以他可能对东西的位置有一些了解。
[cpg]


[FACE method="change_4" pos="2/5"]
[VOICE f="Dorothy019"]
[OnName num="dorothy"]
'我们该怎么做，父亲？
[cpg cn=true]


[OnName num="rudolf"]
'这次可能是侦察，但有可能他们最终会深入进去。
[cpg cn=true]


这是一个艰难的场景。我想我是在关键时刻得救了。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]
[FO pos="4/5" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





仔细想想，我在任何时候都可能会死。
[cpg]


在这种世界观中，当你是恶魔而不是人类时，就很难只是活着。
[cpg]


我很奇怪地悲观，独自摇摇头。
[cpg]


[OnName num="renzi"]
'...... 不，我应该只是享受这一刻。
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[STOPBGM]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』


一天中的时间：晚上。桃乐丝和阿莎现在应该已经睡着了。
[cpg]


珍妮丝只是一个战士，她的生活模式很难读懂，但......
[cpg]


多萝西现在肯定会想睡觉。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



考虑到这一点，我去了多萝西的住处。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy020"]
[OnName num="dorothy"]
'Nn......?　史莱姆，你想要什么？"
[cpg cn=true]


桃乐丝认为我是个黏液。
[cpg]


这不是没有道理的。我经常变成粘液，但有很多粘液不是我。
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Dorothy021"]
[OnName num="dorothy"]
'也许她很孤独，希望我不要打扰她？　你妹妹可以和你一起玩。"
[cpg cn=true]


她自称是姐妹，但她太天真了，不敢说。
[cpg]


她多大了？　是否可以说他们普遍比人类年轻，因为他们的寿命会与人类不同？
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Dorothy022"]
[OnName num="dorothy"]
Kyah！"
[cpg cn=true]

[SE f=se015]
;//【ＳＥ】『触手・スライム』

考虑到这一点，我抱住了她的身体。
[cpg]


她一屁股坐在地上，想把我甩开。
[cpg]



;//========================================
;//●ＣＧ（床に座っているヒロインに近づく主人公）ev_09
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公は人型のスライムに変身しています
;//========================================

;//*Scene004

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1500]



[VOICE f="Dorothy023"]
[OnName num="dorothy"]
'不，不要这样做，......，不要靠近！'
[cpg cn=true]

[SE f=se015]
;//【ＳＥ】『触手・スライム』

桃乐丝试图推开我，但我不能那样做，因为我是粘液。
[cpg]


她好像想推，但她的手臂好像在我的身体里。
[cpg]


粘液体在这样的时候就会派上用场。
[cpg]

;**【ＣＧ】 ev_09_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Dorothy024"]
[OnName num="dorothy"]
'你要做什么，这是一个粘液会做的事......？
[cpg cn=true]


粘液当然可以与另一物种相爱？
[cpg]


我认为史莱姆会和其他史莱姆生孩子。
[cpg]


还是以分化的方式繁殖？　无论是哪种方式。
[cpg]


我不认为他们会爱上其他物种。这就是为什么多萝西会感到惊讶。
[cpg]


但是，这就无法解释阿莎的事了，不是吗？
[cpg]

[SE f=se015]
;//【ＳＥ】『触手・スライム』


无论如何，我是想碰她，因为我被她的反应逗乐了。
[cpg]


;**【ＣＧ】 ev_09_b ***********************
[CG id=3 index=2 time=1000]
;***************************************
[WAIT time=1500]


[VOICE f="Dorothy025"]
[OnName num="dorothy"]
'嗯，这很冷。不，不要！'
[cpg cn=true]


她继续不情愿。她的反应与阿霞和珍妮丝的不同。
[cpg]


她的脸不是变成蓝色，而是变成红色。
[cpg]


[VOICE f="Dorothy026"]
[OnName num="dorothy"]
'我说不，......，哈，不要做任何事。
[cpg cn=true]



;//移植前シーンカット

;//ブラックアウト

[SE f=se015]
;//【ＳＥ】『触手・スライム』


[VOICE f="Dorothy043"]
[OnName num="dorothy"]
'好吧，等等......，我不会放过你的！'
[cpg cn=true]


多萝西试图站起来，但似乎无法做到这一点。
[cpg]


她似乎变得驼背，无法跟随我。
[cpg]


我头也不回地走出房间，幸好有我在。
[cpg]

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[STOPBGM]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


我把一动不动的桃乐丝留在那里，一离开房间就变身为另一种形态。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[SE f=se010]
;//【ＳＥ】『走る』

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Dorothy044"]
[OnName num="dorothy"]
'嘿，那个......，不在这里。
[cpg cn=true]


现在我打扮成了一个格木。多萝西似乎很困惑，尽管如果她想一想就会明白。
[cpg]


我不得不停止自己的笑声。我的意思是，它是一个格木，所以它首先就不好笑。......
[cpg]


然后我回到我的房间。我要怎么处理这种我不能拥有的感觉呢？
[cpg]



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="ep006.ks" target="*start"]

