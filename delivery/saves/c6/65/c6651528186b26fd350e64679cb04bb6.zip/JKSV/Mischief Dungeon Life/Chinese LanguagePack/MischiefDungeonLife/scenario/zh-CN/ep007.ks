*start

;###################################################################
*Ep007|一个不寻常的宪法。
;###################################################################


[SCENE id=7]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
[BG f="black.ui"  time=1000]
[WAIT time=100]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



下面是与多萝西的那场比赛后几个小时发生的事情。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="3/3" time=800]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]

[VOICE f="Dorothy076"]
[OnName num="dorothy"]
'不知为何，最近有很多奇怪的恶魔。
[cpg cn=true]


桃乐丝在食堂点餐时与阿莎说话。
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha097"]
[OnName num="asha"]
'是吗？　以什么方式？"
[cpg cn=true]


我带着不怀好意的表情听着多萝西和阿莎的对话。
[cpg]


[FACE method="change_1" pos="3/3"]
[VOICE f="Dorothy077"]
[OnName num="dorothy"]
'不，不。什么都没有。"
[cpg cn=true]


我听着，但没有参与谈话。
[cpg]


[FACE method="change_1" pos="1/3"]
[VOICE f="Janice080"]
[OnName num="janice"]
'......，那是仁济吗？
[cpg cn=true]


[OnName num="renzi"]
'诶...... 啊，是的。你怎么知道是我？"
[cpg cn=true]


[FACE method="change_7" pos="1/3"]
[VOICE f="Janice081"]
[OnName num="janice"]
'你会看到，我总是一个人。'不过，你又有礼貌了。
[cpg cn=true]


[OnName num="renzi"]
'对不起。我只是......'
[cpg cn=true]



;//ブラックアウト



[SE f=se011]
;//【ＳＥ】『食器の音』



珍妮丝、多萝西和我一起吃饭。我已经打扮成一个妖精，而不是一只蜜蜂。
[cpg]


不过，珍妮丝能认出我也是个奇迹。
[cpg]


不，等等，......，意思是我到目前为止所做的事情也是出奇的明显？
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="3/3" time=1]
[FO pos="2/3" time=1]
[FO pos="1/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



我们吃完了饭，我们喘了口气。
[cpg]


阿莎已经完成了她的职责，正向我们的桌子走来。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="3/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]

[VOICE f="Arsha098"]
[OnName num="asha"]
'......'
[cpg cn=true]


他沉默不语，脸色有些发红，看着远方。
[cpg]


我不是指远处，我是指......，就像她正热切地看着某处的人。
[cpg]


[FACE method="change_7" pos="3/3"]
[VOICE f="Dorothy078"]
[OnName num="dorothy"]
'那个样子是什么意思？
[cpg cn=true]


[FACE method="change_7" pos="1/3"]
[VOICE f="Janice082"]
[OnName num="janice"]
'你必须猜测。公主'。
[cpg cn=true]


[FACE method="change_5" pos="3/3"]
[VOICE f="Dorothy079"]
[OnName num="dorothy"]
'哦，我明白了。
[cpg cn=true]


阿莎的脸变的更红了，她说。我不确定，我点了点头。
[cpg]


[FACE method="change_3" pos="3/3"]
[VOICE f="Dorothy080"]
[OnName num="dorothy"]
'你必须猜测。仁济。'
[cpg cn=true]


[OnName num="renzi"]
'不，你不必这样说。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="sArsha009"]
[OnName num="asha"]
'哦，上帝，也是。不要取笑我们所有人'。
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="3/3" time=1]
[FO pos="2/3" time=1]
[FO pos="1/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[BGM f="05"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





最后我不知道自己在说什么，当珍妮丝和我单独在一起时我又问了一遍。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice083"]
[OnName num="janice"]
'你不明白吗？她是兔子部落的野兽，不是吗？
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sJanice004"]
[OnName num="janice"]
'无论你是否愿意，都很容易坠入爱河。我想他是在欣赏这个新的恶魔'。
[cpg cn=true]


[OnName num="renzi"]
哦，......，这就是你所说的？"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="sJanice005"]
[OnName num="janice"]
'他们说孤独感也比其他人更容易感受到。他似乎为此感到烦恼，所以给他一些宽限。"
[cpg cn=true]


很抱歉，我没有意识到这一点。
[cpg]


我只是结束了让你感到尴尬。我以后必须道歉。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





例如，如果一个恶魔接近于昆虫或动物，它就没有智慧。
[cpg]


以妖精的形式接近他们不是一个好主意。例如，半兽人会说话，是两足动物，似乎像人类一样思考。
[cpg]


但我也见过几乎像动物一样的恶魔......，我想你可以称它们为魔兽。
[cpg]


如果是以这样的形式，难道我不能填补阿莎的孤独吗？
[cpg]


;//ブラックアウト


[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

我对青蛙有一种新的嗅觉，一种恶魔般的野兽。闻到妖兽的味道不是我想做的事，但......
[cpg]


不过，如果我必须为阿莎这么做，我也毫不犹豫。
[cpg]

[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





于是我以青蛙魔兽的形式跟随阿莎。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Arsha100"]
[OnName num="asha"]
'这个女孩......，从不久前开始就一直在跟踪我。我想知道她是否喜欢我'。
[cpg cn=true]


阿莎蹲下身子，我假装在她身上咬了一口。
[cpg]


我感到很不舒服，好像我在欺骗她。不，我不是在愚弄她。
[cpg]


她伸出手来，我舔着她的手指。
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sArsha010"]
[OnName num="asha"]
'我想知道我是否应该养一只...... 的宠物。但这对一个野兽来说就很奇怪了。"
[cpg cn=true]


他说这样的话。阿莎似乎处于一种相当孤独的状态。

通常情况下，她不会想到这一点。

;//移植前シーンカット

[FACE method="change_1" pos="2/3"]
[VOICE f="sArsha011"]
[OnName num="asha"]
'对不起。'当我真的变得很困难时，我会养一只宠物。
[cpg cn=true]


他拍拍我的头。这是一种无法描述的感觉。
[cpg]


我觉得我在欺骗他，我对此感到很难过。......
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





这就是我不断陷入恶作剧的原因。
[cpg]


起初，无论我吓唬谁，他们都不知道那是我。
[cpg]


[OnName num="renzi"]
'早上好。也许现在已经是早上了'。
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Janice085"]
[OnName num="janice"]
'嗯？　是的。......"
[cpg cn=true]


我想跟珍妮丝打招呼，但她似乎心情不好。
[cpg]


我不知道我为什么会有这样的反应，但是......。
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Janice086"]
[OnName num="janice"]
'Renji，无论你做什么，都不要做得太过分。
[cpg cn=true]


我有点明白，当他们说。
[cpg]


[OnName num="renzi"]
'...... 你在说什么？
[cpg cn=true]


你知道我的意思，但我要把它说出来。
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Janice087"]
[OnName num="janice"]
'你是我唯一的变身者。你不认为我不会发现吗？
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



我隐隐有些生气。我对石头做得太过分了吗？
[cpg]


但我没有在那里崩溃，而是想知道我怎样才能在不被发现的情况下进行转变。
[cpg]


纵观历史，我们不难发现，在过去的几年里，中国的经济发展一直处于高速增长的阶段，而中国的经济发展却一直处于低迷的状态。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha126"]
[OnName num="asha"]
啊，他在那里，他在那里。是Renji，对吗？
[cpg cn=true]


我现在打扮成一个妖精。我需要穿成这样才能让人们听到我的声音。
[cpg]


但是，你还是能看出是我吗？他们是否看穿了很多行为模式和姿态？
[cpg]


[OnName num="renzi"]
'阿沙。我能为你做什么？"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha127"]
[OnName num="asha"]
'魔王叫你来的。你不应该去吗？"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[OnName num="rudolf"]
仁济。你不是要去执行侦察任务吗？"
[cpg cn=true]


[OnName num="renzi"]
'呃，是的。嗯，......"
[cpg cn=true]


恶魔之主告诉我甩掉它。
[cpg]


[OnName num="rudolf"]
'如你所知，我们恶魔和人类之间的战斗处于僵持状态。
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Dorothy081"]
[OnName num="dorothy"]
'但这可能一下子都会改变，取决于仁慈的工作方式。
[cpg cn=true]


[OnName num="renzi"]
'......，我当然愿意这样做。但我有一套变换的剧目......"
[cpg cn=true]


[OnName num="rudolf"]
'你现在可以成为任何东西。我已经听说了所有的细节'。
[cpg cn=true]


他们知道，不是吗？桃乐丝肯定已经告诉你了。
[cpg]


[OnName num="renzi"]
'真的，我最终会到达那里。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="4/5" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


我只是不停地躲避，躲避。
[cpg]


事实是，我不想去。我不想让自己处于危险之中。
[cpg]


但我在地牢里的恶作剧已经达到了极限。
[cpg]


我在想该怎么做。......
[cpg]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[WAIT time=1000]
[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="2/3" time=1]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]




她变身为珍妮丝，再一次认真地看着自己的身体。
[cpg]



;//ここからしばらく、ジャニスのセリフ名前欄を「ジャニス（蓮司）」と置き換えてください



[VOICE f="Janice088"]
[OnName num="renzi_to_janice"]
「……」
[cpg cn=true]


例如，你可以假装成别人，住在一个房子里，而对其他人没有任何用处。
[cpg]


毕竟很难完全摆脱我，即使你在食堂吃免费的食物。
[cpg]


当我想到这一点时，我甚至不能让自己做任何事情。
[cpg]

;//移植前シーンカット


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



;//ここからジャニスのセリフの名前欄を元に戻してください


如果我说我没有做什么，我就没有做什么。对恶魔部落来说没有什么有用的东西。
[cpg]



;//ブラックアウト


如果我一直这样，我周围的人就开始催促我去流沙。
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]



[jump storage="ep008.ks" target="*start"]

