*start

;###################################################################
*Ep004|如何在不被发现的情况下实现转型。
;###################################################################


[SCENE id=4]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out" pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
[BG f="black.ui"  time=1000]
[WAIT time=100]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





[OnName num="renzi"]
'你好。珍妮丝，你看起来不舒服。"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice041"]
[OnName num="janice"]
'...... 哦。这就是你。"
[cpg cn=true]


在食堂里，我看到了珍妮丝，并叫住了她。
[cpg]


她现在是粘液形态。方便的是，我仍然可以以这种身份说话。
[cpg]


当然，我也有视觉、听觉和嗅觉。我仍然记得我走近珍妮丝时的那种味道，就像水果和薄荷的结合。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Janice042"]
[OnName num="janice"]
'我过得很不好。让我一个人呆着。"
[cpg cn=true]


那个鬼魂说她不记得穿了它，......，珍妮丝喃喃自语道。
[cpg]


你质疑幽灵，就是我抄袭的那个。这是我的错，尽管我被卷入其中是件好事。
[cpg]


[move from="2/3" to="2/5" ease="easeInOutSine" time=2000]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=2000]

[VOICE f="Dorothy011"]
[OnName num="dorothy"]
'哦，珍妮丝。那边的是Renji吗？"
[cpg cn=true]


[OnName num="renzi"]
'是的，是我。我为自己的困惑而道歉'。
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Dorothy012"]
[OnName num="dorothy"]
'不，这很好。珍妮丝，你的脸怎么了？
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[VOICE f="Janice043"]
[OnName num="janice"]
'不，这不是公主要谈的事。
[cpg cn=true]


桃乐丝和我对同一个问题的反应非常不同。
[cpg]


从珍妮丝的角度看，多萝西的立场和感受是什么？
[cpg]


紧张还是佩服？　还是有类似亲情的东西？
[cpg]


[FACE method="change_4" pos="2/5"]
[VOICE f="Janice044"]
[OnName num="janice"]
'与其担心我，不如担心这个地牢。
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Dorothy013"]
[OnName num="dorothy"]
'是的，我想是的。我想知道Kulara是如何工作的。
[cpg cn=true]


[OnName num="renzi"]
'库拉拉'？
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Dorothy014"]
[OnName num="dorothy"]
'你不知道吗？　不，Renji不知道？"
[cpg cn=true]


当我感到疑惑时，珍妮丝告诉我。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="4/5" time=1]
[FO pos="2/5" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FACE method="in" pos="4/7"]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="03"]
;//【ＢＧ】『街』（昼）******************************************************



;//ヒロイン１の立ち絵を黒いシルエットで表示してください



[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]



[VOICE f="Janice045"]
[OnName num="janice"]
'克拉拉-伊斯顿。我们的天敌，英雄'。
[cpg cn=true]


我以前从未听说过这个名字。但如果是天敌，也许所有的恶魔都知道。
[cpg]


[VOICE f="Janice046"]
[OnName num="janice"]
她在过去给我造成了多少苦难。......。
[cpg cn=true]


[OnName num="renzi"]
'你是在说那些已经被杀死的...... 恶魔吗？
[cpg cn=true]


[VOICE f="Dorothy015"]
[OnName num="dorothy"]
'是的......，所以他们是不共戴天的敌人。如果我们能打败她，我想我们的形状会有很大的改变。"
[cpg cn=true]


我能够做到吗？即使我不能打败他，我至少可以抓住他。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FACE method="out" pos="4/7"]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="3/3" time=800]


[VOICE f="Arsha058"]
[OnName num="asha"]
你们三个在说什么？"
[cpg cn=true]


然后阿莎出现了。
[cpg]


[OnName num="renzi"]
'你是个厨师，对吗？　我可以离开我的工作吗？"
[cpg cn=true]


[FACE method="change_7" pos="3/3"]
[VOICE f="Arsha059"]
[OnName num="asha"]
'是的，我已经完成了今天的工作。我是说，你对我有点囤积居奇的感觉。
[cpg cn=true]


[OnName num="renzi"]
'...... 不，这是以友好的方式进行的。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy016"]
[OnName num="dorothy"]
'你也不必对我使用敬语。我们是朋友，不是吗？"
[cpg cn=true]


朋友。我不知道突然间是什么原因，但我知道多萝西对我感兴趣。
[cpg]


她看着我，眼睛里闪烁着光芒。我不认为这是兴趣，我认为她在期待我工作。
[cpg]


[OnName num="renzi"]
'嗯，......，也许我会这么做。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Dorothy017"]
[OnName num="dorothy"]
'诶嘿嘿'。
[cpg cn=true]


[FACE method="change_7" pos="1/3"]

桃乐丝看起来很高兴。珍妮丝看起来难以形容。
[cpg]


她和她在一起也很开心，还是...... 嫉妒还是什么？
[cpg]


[OnName num="renzi"]
'话又说回来，你怎么能告诉她今天的工作已经完成了？
[cpg cn=true]


[FACE method="change_1" pos="3/3"]
[VOICE f="Arsha060"]
[OnName num="asha"]
'嗯，那是因为没有白天或黑夜，但有一个时钟。
[cpg cn=true]


[OnName num="renzi"]
'它是靠魔法还是什么来工作的？
[cpg cn=true]


[FACE method="change_5" pos="3/3"]
[VOICE f="Arsha061"]
[OnName num="asha"]
'什么？　钟表不是靠魔法工作的，不是吗？"
[cpg cn=true]


[OnName num="renzi"]
不，......，这是正确的。"
[cpg cn=true]


我们已经足够文明，有了在机器上运行的时钟。
[cpg]


也可能是我们从人类那里掠夺来的那些东西之一。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="1/3" time=1]
[FO pos="2/3" time=1]
[FO pos="3/3" time=1]


[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





回到我的房间后，我自己也在尝试各种改造方法。
[cpg]


然后我发现了一件事。那就是我现在可以转化为珍妮丝。
[cpg]


我的剧目越来越多，而且我对规则也越来越熟悉了。
[cpg]


无机物或知道她的一些情况的伙伴，如......？
[cpg]


但你不知道为什么阿莎是第一个被改造的人？
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[BGM f="05"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





想来想去，我决定去找阿霞。当然，为了做一些调皮的事情。
[cpg]


例如，在这个世界上，哥布林和兽人都有智力。
[cpg]


即便如此，也有各种类型的恶魔，似乎也有没有智慧的恶魔。
[cpg]


例如，据说粘液和昆虫形状的是相当原始的恶魔。
[cpg]


换句话说，通过化身为这样的恶魔，可以在攻击他们的同时隐藏他们的真实身份。......
[cpg]

;**【ＣＧ】ci_06_0 ***********************
;//カットイン
[CUTIN f="ci_06_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

考虑到这一点，我把自己伪装成粘液，向阿莎的房间走去。
[cpg]

[CUTIN f="ci_06_0.ui" show={false} method="feadout"]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Arsha062"]
[OnName num="asha"]
'嗯，你今天工作很努力，......？
[cpg cn=true]


[OnName num="renzi"]
......"
[cpg cn=true]


通过打开的门缝，我进入了阿莎的房间。
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha063"]
[OnName num="asha"]
'在这个地方，粘液？　迷路了？"
[cpg cn=true]


阿莎似乎没有意识到这些粘液是我。
[cpg]


我默默地接近她的身体。
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha064"]
[OnName num="asha"]
'奇怪的是，你是一个友好的粘液。这让我很痒。
[cpg cn=true]


他直接爬到阿霞的身上。当我试图贴近她的身体时，我......
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Arsha065"]
[OnName num="asha"]
'......，我明白了。我想，也是如此。"
[cpg cn=true]


她说了一些奇怪的话。我想知道她说的恰好是什么意思，她关上了门。
[cpg]

;//========================================
;//●ＣＧ（スライムとなった主人公を、寝ているヒロインが撫でる）ev_04
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：ダンジョン内部
;//時間　：夜
;//備考　：主人公はスライムに変身しています
;//========================================

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="10"]

;**【ＣＧ】 ev_04_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************

[wait time=1500]

[VOICE f="sArsha003"]
[OnName num="asha"]
我也一直在想念人类的皮肤，'她说。嗯，我是一个粘液，不是一个人'。
[cpg cn=true]


[VOICE f="sArsha004"]
[OnName num="asha"]
'但是......，一个人睡觉很孤独，不是吗？
[cpg cn=true]


...... 如果你仔细想想，她是兔子部落的兽人。
[cpg]


所以我突然想到，爱上她是多么容易的事情，或者类似这样的事情。
[cpg]


;**【ＣＧ】 ev_04_a ***********************
[CG id=2 index=1 time=1000]
;***************************************

[wait time=1500]

[VOICE f="sArsha005"]
[OnName num="asha"]
'你来找我的事实是否意味着你也很孤独？
[cpg cn=true]


我既不能回答，也不能回敬他的姿态。
[cpg]


或者说，粘液没有所谓的手势。如果有什么我可以做的，我可以 ......
[cpg]

;**【ＣＧ】 ev_04_b ***********************
[CG id=2 index=2 time=1000]
;***************************************

[wait time=1500]

[VOICE f="sArsha006"]
[OnName num="asha"]
'呀。这很痒。"
[cpg cn=true]


这刚好够她抚摸我，也够我从这里触摸她。
[cpg]


最后，我所要做的就是和她在一起。
[cpg]


我不知道我以粘液的形式是否能抚慰阿莎的孤独。
[cpg]

;**【ＣＧ】 ev_04_a ***********************
[CG id=2 index=1 time=1000]
;***************************************

[wait time=1500]

[VOICE f="sArsha007"]
[OnName num="asha"]
'......，我可以就这样上床睡觉，但我要怎么做呢？
[cpg cn=true]


她仍然看起来好像带着某种孤独。
[cpg]



;//移植前シーンカット



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Arsha090"]
[OnName num="asha"]
'再见，然后。再见了。"
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


我不能在离开的时候解除转变。我离开了，不知道该如何处理这种感觉。
[cpg]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]



[jump storage="ep005.ks" target="*start"]


