*start

;###################################################################
*Ep013|变化的身体改变了世界。
;###################################################################
;//１、クラーラ

[SCENE id=13]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out" pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out" pos="3/5"]


[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]


[window target=true]


我在想我自己抓住的库拉拉。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Dorothy178"]
[OnName num="dorothy"]
'你为什么把目光移开......'
[cpg cn=true]


[OnName num="renzi"]
'不，这没什么。
[cpg cn=true]


虽然她在库拉拉眼里是个敌人，但我被她的美貌和她明亮、活泼的个性所吸引。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



然后有一天。我是被魔王召唤来的。
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_4" pos="2/2" time=800]

桃乐丝在那里。因为前几天的事情，她似乎有点脾气不好。
[cpg]



[OnName num="renzi"]
'你要见我？巫妖王"。
[cpg cn=true]


[OnName num="rudolf"]
'哦。是关于克拉拉的。
[cpg cn=true]


[OnName num="rudolf"]
'现在是时候了，我们不只是抓住他们。人类可能会做出下一步行动。"
[cpg cn=true]


[OnName num="rudolf"]
'在这之前，我想彻底打破他的心。你能为我做这个吗？"
[cpg cn=true]


[OnName num="renzi"]
'......Yes。
[cpg cn=true]


我不能说不。如果我拒绝，桃乐丝或珍妮丝将不得不承担这个角色。
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Dorothy179"]
[OnName num="dorothy"]
'仁兄不必如此。我来做。"
[cpg cn=true]


如果多萝西这么做了，她会毫不留情。她当然会对他不好，因为他是同性。
[cpg]


[OnName num="renzi"]
'不。让我来做。"
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Dorothy180"]
[OnName num="dorothy"]
'为什么不呢!　Renji，我喜欢那个女孩。"
[cpg cn=true]


我无法回答。这是正确的，我没有。
[cpg]


多萝西的脾气更加暴躁，但我现在别无选择。
[cpg]


[FO pos="2/2" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





克拉拉今天被囚禁了。
[cpg]


她被软禁，因为她可以作为与人类谈判的筹码。
[cpg]


当然，他们并没有太严厉地对待她。
[cpg]


[BG f="b_04_5_up.ui" time=1000]

[FACE method="feadin_up" pos="4/7"]


[WAIT time=1500]

[OnName num="renzi"]
'Kulara。上午好。"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Clara097"]
[OnName num="clara"]
'...... 现在是早上了吗？
[cpg cn=true]


[OnName num="renzi"]
'你已经麻木了吗？
[cpg cn=true]


我曾以人类的形式来到克拉拉。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara098"]
[OnName num="clara"]
我对你没有什么可说的。
[cpg cn=true]


库拉拉，对我或对恶魔持看涨态度的人。
[cpg]


尽管如此，我还是不能不审问她。
[cpg]


;//========================================
;//●ＣＧ（ヒロインの体にぴったりと張り付く形で、触手が覆っている）ev_28
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：ダンジョン＿室内
;//時間　：暗い
;//備考　：主人公は体にぴったり張り付くような触手に変身しています。触手スーツのような感じ。体全体を覆っています
;//========================================

[STOPBGM]
[FACE method="feadout_up" pos="4/7"]

[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1500]
[BGM f="09"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1500]


[SE f=se015]
;//【ＳＥ】『触手・スライム』

我化身为触手，这是她的祸根。这也是一个紧紧依附在她身上的触手。
[cpg]


我试图在她的衣服里蠕动。这将是一种生理上令人厌恶的感觉。
[cpg]

;**【ＣＧ】 ev_28_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sClara004"]
[OnName num="clara"]
'唉，......，太恶心了......'。
[cpg cn=true]


克拉拉仍在挣扎着坚持。
[cpg]


我不想再看到她受苦，我觉得我想看着她。
[cpg]


矛盾的情绪在我体内翻腾。
[cpg]


我怎样才能把这些感觉整理出来？
[cpg]

[SE f=se015]
;//【ＳＥ】『触手・スライム』

;**【ＣＧ】 ev_28_b ***********************
[CG id=6 index=2 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sClara005"]
[OnName num="clara"]
'哈，哈，这让我很痒。...... 啊，啊'。
[cpg cn=true]


我可以感觉到她的体温。这至少是一种解脱。......
[cpg]


我可以感觉到，克拉拉肯定在那里。
[cpg]


;//移植前シーンカット


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





毕竟，我不觉得自己做了什么太可怕的事情。
[cpg]


但这样一来，情况就永远是这样了。
[cpg]



[window target=false]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



晚上。当我在床上闭上眼睛时，我回忆起第一次审讯时......，克拉拉痛苦的样子。
[cpg]


这真是我想做的事吗？......
[cpg]


我不禁想到。但我没有别的办法。
[cpg]


我明天一定会再去库拉拉。毕竟，这是魔王的命令。
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;//ブラックアウト


;//移植前シーンカット
[window target=true]


即使我想与库拉拉结合，但情况是这样的，没有办法做到这一点。
[cpg]


考虑到目前他们彼此为敌，而且是战俘的情况，......
[cpg]


毕竟，结束人类和恶魔之间战争的唯一方法是结束战争。
[cpg]


[window target=false]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


;//＠ベッドの上で状況を整理する。
我回到自己的房间，整理了一下情况。
[cpg]


首先，人类和恶魔在战斗。
[cpg]


第二，根据我从库拉拉那里得到的信息，人类并不是在寻找一场战斗。
[cpg]


更重要的是，我对恶魔方面的感觉是，并非所有的恶魔都是如此热血。
[cpg]


第三，只要库拉拉是战俘，只要她打算在人类这边作战，她就不能和我在恶魔那边。
[cpg]


我有两种方式与库拉拉结合。要么我们结束这场冲突，要么我背叛她。
[cpg]


...... 两者似乎都非常困难。
[cpg]


即使我简单地说，我将结束它，这可能是现在在各种意图的基础上发生的事情。
[cpg]


无论我有多大的转化能力，我都不知道我自己是否能处理好它。
[cpg]


至于背叛，在感情上是很困难的。
[cpg]


特别是，它将背叛桃乐丝。我不太确定这是个好主意。
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



想来想去，我也拿不定主意，于是就去找魔王。
[cpg]


[OnName num="renzi"]
'库拉拉说，人类方面也不是在寻找冲突。也许现在我们可以让他们进入休战状态'。
[cpg cn=true]


[OnName num="rudolf"]
'......，并不是说我也不考虑这个问题，但......'
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/2" time=800]
[VOICE f="Dorothy181"]
[OnName num="dorothy"]
'我不能，我不能。我的一些朋友，我的一些家人，一些恶魔都被杀了'。
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1" pos="1/2" time=800]
[VOICE f="Janice161"]
[OnName num="janice"]
'哦。'这在人类方面也会是一样的。
[cpg cn=true]


...... 除此之外，他们说还有其他各种议程和联系。
[cpg]


人类方面对恶魔有怨恨，而恶魔方面也有一些激进分子。
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


没有出路，我就会厌倦思考这个问题。这是一种感觉，我再也忍不住了。
[cpg]


简而言之，我当时处于一种低迷状态。
[cpg]


在审讯克拉拉的时候，我当然能感觉到她，所以这成了我活着的理由。
[cpg]


当然，我也觉得它不可能有那么好。
[cpg]





[BG f="b_04_5_up.ui" time=1000]
[FACE method="feadin_up" pos="4/7"]
[WAIT time=1500]
;//ブラックアウト



[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara148"]
[OnName num="clara"]
「……」
[cpg cn=true]


克拉拉正变得越来越虚弱。即使给她一顿像样的饭，也自然如此。
[cpg]


她不仅会被软禁，没有任何形式的娱乐活动，而且还将面临随时被杀的压力。
[cpg]


[OnName num="renzi"]
'别担心，我不会杀克拉拉。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara149"]
[OnName num="clara"]
'...... 你在说什么？
[cpg cn=true]


[OnName num="renzi"]
'我是站在库拉拉这边的。相信我。"
[cpg cn=true]


你在说什么。我怎么能站在你这边呢，在你让我经历了那么多糟糕的事情之后？
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara150"]
[OnName num="clara"]
你也失去了你的头脑，......？
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara151"]
[OnName num="clara"]
但可以肯定的是，被关押的不仅仅是...... 被拘留者，还有那些可能头脑不正常的行为者。"
[cpg cn=true]


SO。我早就疯了。
[cpg]


我爱上了克拉拉，这已经很疯狂了。
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



如果可以，我愿意永远留在Kulara。
[cpg]


但我不能保持这种状态。
[cpg]


如果我无缘无故地呆在她身边，她会知道我喜欢她。如果发生这种情况，我将不得不去......。
[cpg]


如果我不得不隐藏我的真实身份并带她出去，我必然会有麻烦。
[cpg]


当然，我还没有完全决定我是否要这样做。
[cpg]


我确信我将会背叛地牢里的每一个人。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



我无缘无故地来到了食堂。
[cpg]


我需要和某人谈谈。在我的脑海中好像没有什么是确定的。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1" pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/2" time=800]


在食堂，多萝西和珍妮丝也在那里。阿莎此刻似乎正在值班，并不在那里。
[cpg]


多萝西看着我说，啊，并向我挥手。
[cpg]


[FACE method="change_7" pos="2/2"]
[VOICE f="Dorothy182"]
[OnName num="dorothy"]
'看来库拉拉也是个狠角色。你能把它交给我一次吗？
[cpg cn=true]


[OnName num="renzi"]
'不，不，是......。
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Janice162"]
[OnName num="janice"]
'你为什么不愿意？　你在为克拉拉辩护吗？"
[cpg cn=true]


你问我是否在保护你，而这正是我在做的事。
[cpg]


我想拯救克拉拉。这是我们能够以任何方式在一起的唯一途径。
[cpg]


[OnName num="renzi"]
无论如何，我会处理好的。我不会让桃乐丝妨碍我的工作。
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Dorothy183"]
[OnName num="dorothy"]
'是吗？　我对她有很多怨恨，所以我不会对她轻易下手。"
[cpg cn=true]


这就是为什么我不能把它留给他们，但我不能让自己说出来。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[SE f=se009]
;//【ＳＥ】『歩く』



我沿着过道走回我的房间。
[cpg]


去阿莎家肯定会治愈我的孤独。但我想要的是克拉拉。
[cpg]


我看不到其他东西，这是......
[cpg]


也许这就是爱。我现在不得不承认这一点。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************




[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FG f="CHA01_p4_01_a.ui" method="change_1" pos="2/3" time=800]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

回到我的房间，我突然想到了这个问题。
[cpg]



仔细想想，我可以把自己伪装成克拉拉，但我从未这么做过。
[cpg]



;//ここからしばらく、クラーラのセリフ名前欄を「クラーラ（蓮司）」と置き換えてください



[FACE method="change_5" pos="2/3"]


[VOICE f="Clara177"]
[OnName num="renzi_to_clara"]
真的，它看起来和她一模一样。......
[cpg cn=true]


我看着镜子里的自己，叹了口气。所以我必须知道我所变身的人的气味，但我已经很了解克拉拉的气味。
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="sClara006"]
[OnName num="renzi_to_clara"]
;//「ごくっ……我慢、できない」
'......，她是多么美丽。
[cpg cn=true]


这是我很久没有做过的事情了。与克拉拉的直接接触，就是这样。
[cpg]


好吧，严格来说不是她本身，而是我在摸我的手。
[cpg]


;//移植前シーンカット


;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



我想被她的气味所包围。这正是我所想的。......
[cpg]


我直接以克拉拉的形式入睡。......
[cpg]





[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





第二天早上，我仍然处于昏昏沉沉的意识状态，沿着马路走到食堂。
[cpg]

[FG f="CHA01_p4_01_a.ui" method="change_1" pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/2" time=800]

[VOICE f="Dorothy184"]
[OnName num="dorothy"]
'啊！'
[cpg cn=true]


她一看到多萝西，就开始了战争。
[cpg]


她在念着某种咒语，我急忙解释。
[cpg]


[FACE method="change_5" pos="1/2"]
[VOICE f="Clara204"]
[OnName num="renzi_to_clara"]
'志，不，是我。看到了吗？
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



;//ここからクラーラの名前欄を元に戻してください




我变回来了。在人类，男性的形式。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Dorothy185"]
[OnName num="dorothy"]
'什么...... clara，我还以为你会跑掉。
[cpg cn=true]


[OnName num="renzi"]
对不起。"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Dorothy186"]
[OnName num="dorothy"]
'但你为什么要伪装成库拉拉？　会不会是......"
[cpg cn=true]


桃乐丝有一种预感。我也否认了这一点。
[cpg]


[OnName num="renzi"]
'没什么，她说，我没做什么。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
;//[VOICE f="Dorothy187"]
;//[OnName num="dorothy"]
;//「それって、何かしました、って言ってるようなものだと思うよ」
;//[cpg cn=true]

是吗？　多萝西边说边点头。我不认为你可以伪造这一点。
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



当多萝西发现我的真实感受时，没有什么变化。
[cpg]


日子继续平淡。可以说，和平的日子。
[cpg]


我的爱既没有结果，也没有枯萎，它只是继续维持现状。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



如何与克拉拉结婚。我以前曾想过，有两种方法。
[cpg]


但我不能如此轻易地结束这场战斗。
[cpg]


所以我必须以另一种方式来做。
[cpg]


换句话说，就是把自己伪装成人类，打破库拉拉的束缚，以人类的身份回到人类村庄的方法。
[cpg]


如果我隐藏我的真实身份，库拉拉会觉得对我有亏欠，我就可以作为一个人混进去。
[cpg]



[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



即使我想到了，我也不能这么轻易地执行它。
[cpg]

;//移植前シーンカット

我不想再利用我的地位来接近库拉拉了。
[cpg]


与其说是我对库拉拉没有爱心，不如说是我对自己没有爱心。我知道这一点。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





回到我的卧室后，我有一件事要考虑。
[cpg]


让库拉拉离开这里。我对地下城的结构有一些了解。
[cpg]


我知道如何在最短的时间内出去，以及在一天中的哪个时间段，卫兵是稀少的。
[cpg]


我甚至不需要考虑这个问题，如果我给库拉拉解开镣铐，她可能会自己解决。
[cpg]


[OnName num="renzi"]
我想我们只能......。"
[cpg cn=true]


我试图睡觉，但我不能。克拉拉会有一个这样的夜晚吗？
[cpg]





[BG f="black.ui"  time=1000]
[WAIT time=100]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


他在早上醒来后就去了食堂。
[cpg]


我的行动需要保密。但我不能不和任何人讨论这个问题。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Arsha197"]
[OnName num="asha"]
'早上好，Renji。昨晚没睡好吗？
[cpg cn=true]


[OnName num="renzi"]
'早上好......，我看起来像吗？
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha198"]
[OnName num="asha"]
'你看起来有点苍白。有什么事困扰着你吗？
[cpg cn=true]


[OnName num="renzi"]
'......'
[cpg cn=true]


如果。如果我们执行行动，救出克拉拉，我们就会背叛桃乐丝、珍妮丝和阿莎，她们对我们的帮助很大。
[cpg]


我永远无法与多萝西特别交谈。她对库拉拉怀恨在心。
[cpg]


珍妮丝也会反对，因为她与魔王的关系很密切。
[cpg]


按照排除法，我应该和阿莎谈一谈吗？
[cpg]


[OnName num="renzi"]
'嘿，阿沙......，嘿，当你有空的时候，我希望你能听我说。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha199"]
[OnName num="asha"]
'是的，什么？　我想午餐后我将有一些时间。"
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA04_p3_01_a.ui" method="change_1" pos="2/3" time=800]

秘密故事。一个不允许任何人听到的故事。但为了不给他们留下错误的印象，我只是告诉他们这不是关于爱情。
[cpg]


在空荡荡的走廊里，我在切入正题之前检查了周围的环境。
[cpg]


[OnName num="renzi"]
'我正试图帮助...... 克拉拉出来。我想把自己伪装成一个人，重新开始这种关系。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha200"]
[OnName num="asha"]
'什么...... 的爱情故事，就是这样。
[cpg cn=true]


的确如此。我想我因此而撒了点谎。
[cpg]


[OnName num="renzi"]
'我喜欢克拉拉。我真的想和她在一起。"
[cpg cn=true]


[OnName num="renzi"]
'如果你继续这样下去，库拉拉即使怨恨你，也不会喜欢你。
[cpg cn=true]


[OnName num="renzi"]
'所以......，我想重新开始。我可以重生为别人，因为我可以做到。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha201"]
[OnName num="asha"]
'你是说，从地牢里出来，对吗？
[cpg cn=true]


阿莎看起来有点若有所思，但很快就
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha202"]
[OnName num="asha"]
'......，我不会阻止你。我不认为让那个勇敢的人离开会大大改变事情。"
[cpg cn=true]


他回答说。只是......。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Arsha203"]
[OnName num="asha"]
'只是那个Renji，他要走了，只是...... 呐，这没什么。
[cpg cn=true]


阿莎似乎很想念我的离开。
[cpg]


我心碎了，但我必须告诉她我的真实感受。
[cpg]


[OnName num="renzi"]
'对不起。我可能有一段时间不会回到地牢了'。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha204"]
[OnName num="asha"]
'我会想你的。但我非常爱你。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





阿莎并不强烈反对。不过，她似乎确实认为她会想念他。
[cpg]


因此，这是一种促进。我在我的房间里，制定了一个计划，并进行了数学计算，以使库拉拉离开那里。
[cpg]


我不想让任何人发现。即使他们发现了，我也不希望手术在中间失败。
[cpg]


我不仅模拟了各种可能性，而且还为可能与同志们对立做了准备。
[cpg]



[SE f=se009]
;//【ＳＥ】『歩く』

[BG f="black.ui"  time=1000]
[WAIT time=1000]

[FACE method="feadin_up" pos="4/7"]

;//ブラックアウト
[WAIT time=1000]

[BG f="b_04_5_up.ui" time=1000]
[WAIT time=1500]


就时间而言，当时是半夜。
[cpg]


我走到囚禁克拉拉的房间，我打破了束缚。
[cpg]


[OnName num="renzi"]
'请醒醒。我是来救你的。"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Clara232"]
[OnName num="clara"]
'......?　你是......"
[cpg cn=true]


我看起来像个剑客。不要为能够来到这里而感到奇怪。
[cpg]


[OnName num="renzi"]
'我的名字是哈利。来吧，让我们离开这里'。
[cpg cn=true]


我准备了一个假名字。这是对我的姓氏的恶搞，这并不是什么转折，但这是个名字，......。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara233"]
[OnName num="clara"]
他说："我是来帮助你的。" ...... 你怎么会有这么深的体会？
[cpg cn=true]


可疑的。但不管有没有，我都退缩了。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se010]
;//【ＳＥ】『走る』




我们已经快没钱了。我曾说服自己，一旦我们离开这里，我们可以像人一样生活。
[cpg]


[OnName num="goblins"]
等等，等等!　嘿，谁在那里？"
[cpg cn=true]


追兵来了。但库拉拉用魔法进行了反击。
[cpg]


[OnName num="renzi"]
'...... 你有很大的权力，不是吗？你本可以自己逃走的。"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara234"]
[OnName num="clara"]
束缚有封杀邪恶的力量......，我不可能靠自己的力量出去。"
[cpg cn=true]


但是当我独自面对恶魔时，我什么都做不了。
[cpg]


事情进行得很顺利，部分原因是库拉拉本人拥有权力。
[cpg]


[FO pos="2/3" time=1000]


;//ブラックアウト

[FACE method="feadin_up" pos="4/7"]



没过一会儿我就到了外面。
[cpg]


即便如此，库拉拉的魔法也是压倒性的。她原来一定是个弓箭手。
[cpg]


当她在自己的领域里时，她的力量是不可估量的。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（夜）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara235"]
[OnName num="clara"]
外面 ...... 外面 ......
[cpg cn=true]


[OnName num="renzi"]
你出局了。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara236"]
[OnName num="clara"]
是的。......"。
[cpg cn=true]


克拉拉站在那里，哭了起来。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara237"]
[OnName num="clara"]
'我很害怕。我真的以为他们会杀了我'。
[cpg cn=true]


然后他看了看我。我握着她的手，紧紧抓住她的手，努力不让自己想去拥抱她。
[cpg]


不可否认，欺骗克拉拉的变形金刚是我，但现在我却充当了她的恩人。
[cpg]


[SE f=se020]
;//【ＳＥ】『草原歩く』



从那里开始，我和库拉拉单独行走。
[cpg]


这里离克拉拉居住的小镇有一段距离。
[cpg]


由于她身体相当虚弱，我们决定在沿途住宿。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夜）******************************************************





[OnName num="demon_A"]
'...... 你们人类想要什么？
[cpg cn=true]


[OnName num="renzi"]
'这只是今晚的事。你能在这里过夜吗？"
[cpg cn=true]


[OnName num="demon_B"]
'不。我们不希望有任何麻烦，即使我们是中立的。"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Clara238"]
[OnName num="clara"]
'哈利先生，我不会有事的。我还能走路。"
[cpg cn=true]


克拉拉这么说，但如果她继续走下去，她甚至有可能被恶魔追上。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1" pos="5/3" time=1]

当她在想该怎么办的时候，恰好路过。
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』

[move from="2/3" to="1/2" ease="easeInOutSine" time=2000]
[move from="5/3" to="2/2" ease="easeInOutSine" time=2000]

[wait time=2000]
[FACE method="change_5" pos="2/2"]


[VOICE f="Satuki090"]
[OnName num="satsuki"]
'...... 等待。那个人。"
[cpg cn=true]


[OnName num="renzi"]
'Satsuki!　拜托，是我。"
[cpg cn=true]


我不能给你一个具体的名字。但我以为樱木会理解。
[cpg]


[FACE method="change_7" pos="2/2"]
[VOICE f="Satuki091"]
[OnName num="satsuki"]
我知道这一点。我想你可能会以某种方式。"
[cpg cn=true]


[FACE method="change_4" pos="1/2"]
[VOICE f="Clara239"]
[OnName num="clara"]
'什么......？　嗯，你是什么意思？"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************



我们被带到了佐藤的家里，我们的理解力没有跟上，或者说，怎么也猜不透。
[cpg]


[OnName num="renzi"]
'谢谢你。有一段时间我想知道会发生什么。
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4" pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_7" pos="2/2" time=800]
[VOICE f="Satuki092"]
[OnName num="satsuki"]
'好的。我猜我们终究不兼容。
[cpg cn=true]


鉴于他在克拉拉面前，他似乎对发生的事情有所了解。
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Satuki093"]
[OnName num="satsuki"]
'我想这毕竟只是人类是人类......。
[cpg cn=true]


他选择自己的话语，以免被发现。我没有回答。
[cpg]


;//[free]

[OnName num="renzi"]
'......，克拉拉。也许你应该去睡觉。"
[cpg cn=true]


[VOICE f="Clara240"]
[OnName num="clara"]
「……」
[cpg cn=true]


我试图关心克拉拉，但她坐在我后面，几乎要睡着了。
[cpg]


[OnName num="renzi"]
'你需要好好睡觉。
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Clara241"]
[OnName num="clara"]
是的，是的。...... 抱歉。"
[cpg cn=true]


;//[free]


克拉拉睡着后，我和Satsuki继续聊了一会儿。
[cpg]


[FACE method="change_7" pos="2/2"]
[VOICE f="Satuki094"]
[OnName num="satsuki"]
'我有点明白你的意思，因为我的爱是类似的。'我的爱情是类似的，所以我有点明白。
[cpg cn=true]


[OnName num="renzi"]
'...... 哦。
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Satuki095"]
[OnName num="satsuki"]
'但我认为与一个叛徒相爱是很难的。
[cpg cn=true]


樱木的眼睛就是这样，暗示着将要发生的事情。
[cpg]

;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ヒロイン５の家＿室内』（朝）
;//【ＢＧ】『鬼の集落』（朝）******************************************************


在我们休息够了之后，我们离开了樱木的家。
[cpg]


当时几乎是中午而不是早上。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2" pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/2" time=800]
[VOICE f="Clara242"]
[OnName num="clara"]
'我很久以来第一次睡得很好。谢谢你，嗯，.......'
[cpg cn=true]


[VOICE f="Satuki096"]
[OnName num="satsuki"]
'我是Satsuki。你不需要感谢我。
[cpg cn=true]


[OnName num="renzi"]
'谢谢你。樱木，我不会忘记这个忙的。
[cpg cn=true]


樱木的脸上似乎有一种痛苦的表情。
[cpg]


她一定很担心我们的未来。我自己也忍不住想到了未来。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（朝）******************************************************

[SE f=se020]
;//【ＳＥ】『草原歩く』


我们离开食人魔村，开始再次向人类的城市走去。
[cpg]


库拉拉似乎恢复得相当好，现在即使追兵追来，她似乎也能应付自如。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Clara243"]
[OnName num="clara"]
'哈利先生，......，你到底是谁？
[cpg cn=true]


[OnName num="renzi"]
'这并不多，真的。我只是一个旅行者，只是一个剑客'。
[cpg cn=true]


在某种程度上，我想的是一个虚假的身份。
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara244"]
[OnName num="clara"]
'哦，不。你说你只是个剑客，但这样的人不可能到达地牢的深处'。
[cpg cn=true]


但是，抹布的出现可能只是一个时间问题。
[cpg]


不过，我还是得继续装下去。她没有用怀疑的眼光看我，似乎觉得对我有亏欠。
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（昼）******************************************************



[OnName num="renzi"]
'我已经到了：......'
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara245"]
[OnName num="clara"]
'哦......，你终于回家了。
[cpg cn=true]


克拉拉又到了哭的边缘。
[cpg]


[OnName num="renzi"]
'我们现在该怎么做？首先，我们必须向我们的家人报告，不是吗？
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara246"]
[OnName num="clara"]
'是的。有很多人我需要告诉他们我回到了这里。
[cpg cn=true]


[OnName num="renzi"]
'那就去告诉他们。我是......"
[cpg cn=true]


有从地牢里秘密偷来的钱。这将使我们能够获得住宿。
[cpg]


假装是人类并不意味着你能得到一栋房子。我们必须以旅行者的假身份去。
[cpg]


[OnName num="renzi"]
'我去找一家旅馆。到时见。"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara247"]
[OnName num="clara"]
'是的。我将在适当的时候还你钱。哈里先生救了我的命。"
[cpg cn=true]


[window target=false]
[FO pos="2/3" time=1000]
[STOPBGM]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="04"]

;//【ＢＧ】『街』（夜）******************************************************





这一天是个大事件。一个英雄的囚犯奇迹般地复出了。
[cpg]


她的家人、朋友或整个国家都很高兴听到这个消息。
[cpg]


我的心情很复杂。这都是我的错。
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『街』（昼）******************************************************





整个城市就像一个节日，特别是在酒吧和其他地方，但现在是时候让它平静下来了。
[cpg]


第二天，我终于再次与克拉拉见面了。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6" pos="2/3" time=800]
[VOICE f="Clara248"]
[OnName num="clara"]
'谢谢你。那......，你愿意和我谈一谈吗？'
[cpg cn=true]


克拉拉看着我，脸红了。
[cpg]


这个表情不是针对我的，我是恶魔的形态。
[cpg]




[window target=false]
[transition target={true} rule="tobira2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tobira2.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se023]
;//【ＳＥ】『ドア閉まる』

[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（夕方）******************************************************





我被邀请到库拉拉的家里。
[cpg]


这不是一个特别豪华的住所，尽管它是一个勇敢的人的家。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara249"]
[OnName num="clara"]
'我不知道该如何感谢你。真的，当你来救我时，那......"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara250"]
[VOICE f="sClara007"]
[OnName num="clara"]
;//「白馬の王子様、というと少し変ですが……でも、ずっと真っ暗な部屋に閉じ込められて、毎日のように犯されてたんです」
'白马王子，这有点奇怪......，但我一直被关在黑屋子里，每天都要接受审讯。

[cpg cn=true]


她说了一些她几乎已经承认的事情，但她的良心却很痛。是我把她关起来并审问她。
[cpg]


这真的是我在做的事吗？
[cpg]


[OnName num="renzi"]
'...... 你的父母现在在哪里？
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara251"]
[OnName num="clara"]
'我的父亲和母亲此刻都不在。我要求他们这样做'。
[cpg cn=true]


他脸红了。我的存在对克拉拉来说已经成为一件大事。
[cpg]


我知道她的感受，或者说我是这么想的。我救了她的命并不是夸大其词。
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clara252"]
[OnName num="clara"]
'我想感谢你。你会来我的房间吗？"
[cpg cn=true]


[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1500]
;//ブラックアウト


[FACE method="feadin_up" pos="4/7"]
[WAIT time=1000]
[BG f="b_05_3_up.ui" time=1000]
[WAIT time=1500]

[BGM f="04"]


她自己的房间很可爱。它并不觉得自己是一个勇敢的战士。
[cpg]


例如，书架上摆满了魔法书，墙上有几张弓。不过在这方面，它不是一个正常的女孩的房间。
[cpg]


不过，这还是让人感受到了她的日常生活。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara253"]
[OnName num="clara"]
'......，请不要对我要做的事情感到惊讶。
[cpg cn=true]


[OnName num="renzi"]
我指的是......？"
[cpg cn=true]


;//[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
;//[VOICE f="Clara254"]
;//[OnName num="clara"]
;//「私、あの部屋で何度も虐められて……どこか、おかしくなっちゃったんだと思います」
;//[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sClara008"]
[OnName num="clara"]
'不要认为这很奇怪。我不知道还能做什么'。
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_2" pos="2/3" time=800]


克拉拉然后把她的嘴唇放在我的嘴唇上。
[cpg]


[OnName num="renzi"]
'你确定......，你想对我这样做吗？
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clara256"]
[OnName num="clara"]
'别这么说，请不要这么说。我已经下定决心，但我在犹豫不决。
[cpg cn=true]


;//移植前シーンカット

;//移植前シーンカット


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（夜）******************************************************


即使什么都不说，克拉拉的喜爱之情也是显而易见的。
[cpg]


但我们不可能永远在一起。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Clara309"]
[OnName num="clara"]
'你已经要走了，不是吗？
[cpg cn=true]


[OnName num="renzi"]
是的。"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara310"]
[OnName num="clara"]
'......，我还想感谢你。但现在已经快到晚上了，不是吗？"
[cpg cn=true]


[OnName num="renzi"]
'别担心，我相信我们会再见到对方的。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara311"]
[OnName num="clara"]
嗯，如果你不介意的话，你能告诉我...... 哈利住在哪里吗？
[cpg cn=true]


[OnName num="renzi"]
'...... 那是--'
[cpg cn=true]


在这里。如果你需要考虑，这就是你需要考虑的时候。
[cpg]


[OnName num="renzi"]
'正如我所说，我是一个旅行者。我在这个城市没有家'。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara312"]
[OnName num="clara"]
'那么你要在某个地方呆上一段时间。我想知道你在哪里，至少'。
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（夜）******************************************************





于是我把克拉拉带到了我要住一段时间的旅馆。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara313"]
[OnName num="clara"]
'......，这是一个非常好的地方。
[cpg cn=true]


[OnName num="renzi"]
是的，好吧。"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara314"]
[OnName num="clara"]
'你，嗯，有钱吗，哈利？
[cpg cn=true]


[OnName num="renzi"]
不，...... 嗯。
[cpg cn=true]


如果你甚至问我是怎么挣来的，我也无法回答。
[cpg]


但克拉拉没有进一步追究。
[cpg]


[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=2000]
[WAIT time=2100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=2000]
;//ブラックアウト

[window target=true]


[SE f=se024]
;//【ＳＥ】『鳥の鳴き声』





回到客栈后，我进入了梦乡，夜幕降临。
[cpg]



[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BGM f="04"]

;//【ＢＧ】『街』（朝）******************************************************





如果你问我是否快乐，我是快乐的，但另一方面，有一种逐渐的不安从我的脚下蔓延开来。
[cpg]


我还能这样下去多久？如果我不在这里安顿下来，我就没有钱了。
[cpg]


当然，我有足够的钱来生活一段时间，但即使我在某个地方找到工作，我也不能暴露我的身份。
[cpg]


或者我可以再去一次地牢，偷......？　不，这太冒险了。
[cpg]


现在应该很明显，我已经跑了，或者说，我把克拉拉带出去了。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（昼）******************************************************





即使我暂时没有麻烦，这也是我在某个时候必须处理的问题。
[cpg]


果不其然，还有一个问题。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2" pos="2/3" time=800]
[VOICE f="Clara315"]
[OnName num="clara"]
'哈里先生!
[cpg cn=true]


在客栈门口，我被拦住后转身。在那里，克拉拉正带着灿烂的笑容向我挥手。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara316"]
[OnName num="clara"]
'我已经来了。我不能留下来。......，这是个讨厌的人吗？
[cpg cn=true]


[OnName num="renzi"]
'不，不是真的，但......
[cpg cn=true]


起初我只是很高兴能和克拉拉在一起，但我越来越害怕被宰。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara317"]
[OnName num="clara"]
'你在城里呆了多久了，哈利？
[cpg cn=true]


[OnName num="renzi"]
'没有那么多。我想大约半个月的时间......'
[cpg cn=true]


我以为我选择了一个温和的地方。
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Clara318"]
[OnName num="clara"]
'半个月了!　仅仅这么长时间，你就征服了一个地牢？"
[cpg cn=true]


情况就是这样。没错，这是唯一一个靠近地牢的城镇。
[cpg]


[OnName num="renzi"]
不，好吧，从技术上讲，它有点长，因为我们做了一些营地和东西。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara319"]
[OnName num="clara"]
'但它仍然是伟大的!　我们四个人才能通过，而我们却不能。......，哦，是的。"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara320"]
[OnName num="clara"]
'我还会把你介绍给以前和我一起聚会的一些人。他们都非常渴望见到你。"
[cpg cn=true]


[OnName num="renzi"]
'......，我明白了。
[cpg cn=true]


我只能说是的。我有种感觉，我马上就要得到一块抹布了。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（夕方）******************************************************





然后。我们都在那里，在她的房子里，全力以赴。
[cpg]


[OnName num="monk"]
'你救了克拉拉，不是吗？
[cpg cn=true]


[OnName num="warrior"]
'你救了我以前的战友。让我谢谢你。"
[cpg cn=true]


[OnName num="renzi"]
不，我......，没做什么。"
[cpg cn=true]


那天，不仅曾经陪伴库拉拉的女祭司和战士在那里，而且她的父母也在那里。
[cpg]


[OnName num="clara_mother"]
真的，光是让库拉拉再次像这样回家，似乎就是一个...... 的奇迹。"
[cpg cn=true]


克拉拉的父母似乎都是精灵族人。
[cpg]


[OnName num="clara_father"]
'这都要归功于他。谢谢你，哈利。"
[cpg cn=true]


克拉拉本人相当聪明和活泼，但她的父母也是如此。
[cpg]


而且他们真正地庆祝他们女儿的回归。
[cpg]


[OnName num="renzi"]
'...... 不，没有这样的......'
[cpg cn=true]


[OnName num="monk"]
'你很谦虚。'你一个人潜入地牢，拯救了你的国家的英雄。
[cpg cn=true]


[OnName num="warrior"]
'对。你的口气好像是想说你没有做任何困难的事情。
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara321"]
[OnName num="clara"]
'不可能。我们四个人不可能查出真相，他也冒着生命危险。
[cpg cn=true]


[OnName num="warrior"]
'我希望是......'。
[cpg cn=true]


[OnName num="monk"]
'你是个旅行剑客，是吗？　你来自哪里？"
[cpg cn=true]


[OnName num="renzi"]
'这是这样一个农村地区，即使我告诉你，你也不会知道。
[cpg cn=true]


这是一个痛苦的发展。如果他们一直挖我的根，我就无法正确回答。
[cpg]


[OnName num="monk"]
我明白了。
[cpg cn=true]


除了她的父母之外，女祭司和战士显然也怀疑我。
[cpg]


但他们并没有当场进一步打听。
[cpg]



[window target=false]
[FO pos="2/3" time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]
[window target=true]
[STOPBGM]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（夜）******************************************************





然后天色渐渐暗了下来，晚饭后我们决定分手一天。
[cpg]



[SE f=se023]
;//【ＳＥ】『ドア閉まる・開く』



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（夜）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara322"]
[OnName num="clara"]
'好吧，到时候见。你打算在这个城市呆多久，哈利-桑？
[cpg cn=true]


[OnName num="renzi"]
'是的，这是一个非常宜居的城市，我正在考虑定居下来。
[cpg cn=true]


我所说的只是一个口号，但...
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara323"]
[OnName num="clara"]
'真的吗？　我太高兴了，我一直在想我什么时候能离开。"
[cpg cn=true]


克拉拉比我想象的还要高兴。
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（朝）******************************************************





渐渐地，我的幸福生活就要崩溃了。
[cpg]


很快，人们就会发现，我已经不在地牢里了。
[cpg]


他们会发现，是我把克拉拉带走了。
[cpg]


那是有一天，我在想这个问题。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1" pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1" pos="2/2" time=800]

[VOICE f="Dorothy188"]
[OnName num="dorothy"]
'嘿，你在那里。
[cpg cn=true]


[OnName num="renzi"]
是吗？"
[cpg cn=true]


我转过身，看到一张熟悉的脸在那里。
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Dorothy189"]
[OnName num="dorothy"]
'珍妮丝，你确定吗？
[cpg cn=true]


[FACE method="change_3" pos="1/2"]
[VOICE f="Janice163"]
[OnName num="janice"]
'是的。'该描述与瞭望员的描述相符。
[cpg cn=true]


我很快就想到了我要做的事情。以变形金刚的力量逃跑？
[cpg]


...... 号。即使我可以暂时改变我的形状，一旦我逃出来，我就必须无休止地继续跑下去。劝说他是否更有建设性？
[cpg]


[OnName num="renzi"]
'对不起。我冒昧地这么做了。"
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Janice164"]
[OnName num="janice"]
'你承认吧。'我希望这只是自私的，但我们已经失去了我们的王牌。
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Dorothy190"]
[OnName num="dorothy"]
'你为什么要背叛我们？　你要永远保持这种状态吗？"
[cpg cn=true]


[OnName num="renzi"]
'我将永远隐藏我的真实身份。我不会再回到地牢了。"
[cpg cn=true]

[FACE method="change_7" pos="2/2"]
你一定很喜欢它，多萝西嘀咕道。她看起来有点懊恼。
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Dorothy191"]
[OnName num="dorothy"]
'好吧。我有一个想法......，或者说，这是珍妮丝的想法。
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Dorothy192"]
[OnName num="dorothy"]
对我们来说，Renji是我们需要的人。我们会请他回来。"
[cpg cn=true]

[FO pos="1/2" time=1000]
[FO pos="2/2" time=1000]

说完这些，多萝西和珍妮丝欣然退下。
[cpg]


[window target=false]
[STOPBGM]
[BG f="b_07_2.ui" time=1500]
[WAIT time=2000]
[window target=true]

[BGM f="04"]

;//【ＢＧ】『街』（昼）******************************************************





我想知道他们说他们有一个想法时是在说什么。
[cpg]


我甚至无法猜测。时间过去了，已经是下午了。
[cpg]


我正在去克拉拉家的路上。她经常问我住在哪里，反之亦然。
[cpg]


所以我知道这不会是一个问题，但......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3" pos="2/3" time=800]
[VOICE f="Clara324"]
[OnName num="clara"]
"...... 是你吗？"
[cpg cn=true]


[OnName num="renzi"]
'怎么了？　你的表情很阴沉。"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara325"]
[OnName num="clara"]
'就在刚才，一个自称是魔王之女的人来到我家。
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


对。所以这是桃乐丝的主意。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara326"]
[OnName num="clara"]
'你，哈利，是个假名。我听说你的名字是Renji。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara327"]
[OnName num="clara"]
'你就是那个让我在后面陷入困境的变形金刚，对吗？
[cpg cn=true]


[OnName num="renzi"]
这是......."
[cpg cn=true]


我没有什么可回话的。克拉拉已经知道了真相，没有任何借口可以让这种事情发生。
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara328"]
[OnName num="clara"]
'一直以来，你都在欺骗我。我才是那个被欺骗的人。
[cpg cn=true]


对克拉拉来说，这一定很复杂。这意味着自以为在帮助她的人也是把她推到边缘的人。
[cpg]


[OnName num="renzi"]
'...... 抱歉。
[cpg cn=true]


沉默占了上风。我在这里应该说些什么呢？
[cpg]


[OnName num="renzi"]
'起初，我所做的是为了魔族的利益。这一点毋庸置疑'。
[cpg cn=true]


[OnName num="renzi"]
'我在与克拉拉打交道的过程中爱上了她。那是真的。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara329"]
[OnName num="clara"]
'我不再相信任何东西了。我甚至不知道你说的有多少是真的'。
[cpg cn=true]


[OnName num="renzi"]
'......，是的，没错。
[cpg cn=true]


这是真的，我一直在为自己的原因向克拉拉挥手。
[cpg]


我以为我让她成为恶魔部落的俘虏是因为我爱上了她的美貌，但我要把她从地牢里带出来，卖给她一个人情。......
[cpg]


而首先，有一个问题是，一个恶魔部落，即使他们是精灵，是否能与人类方面的人联合起来。
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara330"]
[OnName num="clara"]
'请离开。我也想理清我的思路'。
[cpg cn=true]


我被告知后就回到了客栈，无法回话。
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





在我的生活中，我知道许多恶魔的味道。对我来说，成为一个人是必要的。
[cpg]


如果我需要立即变身，我就会到恶魔那边去闻。
[cpg]


即使我不这样做，我也可以和我认识很久的人一起转变，因为我莫名其妙地知道他们的气味。
[cpg]



[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_07_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（夕方）******************************************************





我心中有一个决心。我已经决定这次要变身为谁了。
[cpg]


换句话说，就是魔王。我将变身为他，与人类国王进行谈判。
[cpg]


如果人类和恶魔不团结，那么我别无选择，毕竟要结束这场战斗。
[cpg]


如果有人能做到这一点，要么是魔王，要么是我，我可以假装是魔王。
[cpg]


当然，我自己没有法力，即使我伪装成魔王，如果被抓住了，我也无能为力。
[cpg]


这是一个危险的策略，如果你不小心，可能会让你当场死亡。
[cpg]


[OnName num="renzi"]
现在说这个有点晚了，不是吗？......."
[cpg cn=true]


我以前做过很多危险的事情。但我还是想和克拉拉结合在一起。
[cpg]


我必须这样做，不是吗？当初我在这一生中死过一次，我什么都不怕。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="07"]

[window target=true]

;//【ＢＧ】『街』（夜）******************************************************



当我们走向市中心时，建筑物和街道逐渐变得越来越有装饰性。
[cpg]


王宫临近。我仍然不像是一个魔王。
[cpg]


最好让我以魔王的形式存在的时间越短越好。只在需要它的人面前承担这种形式的风险较小。
[cpg]


然后我向王宫走去。士兵们阻止我去，但我希望他们是我可以交谈的人。
[cpg]


[OnName num="renzi"]
'给我接通.......'
[cpg cn=true]


我谈判，想起了魔王会说什么，以及他的行为方式。
[cpg]


[OnName num="soldier"]
'嘿，嘿，你想要什么......，你是来杀我们的？
[cpg cn=true]


士兵们都很惊恐。他们可能对魔王的长相有一些了解，这很方便。
[cpg]


[OnName num="renzi"]
'我需要和国王说话。把他带走。"
[cpg cn=true]


[OnName num="soldier"]
'......，我们该怎么做......？
[cpg cn=true]



[FACE method="feadin" pos="4/7"]
[WAIT time=2000]

我们不知道人类的国王是什么样的性格。
[cpg]


这都是一场赌博。如果他好战，他就会试图杀死我。
[cpg]


他是独自前来的，没有带着他的人。如果是这样的话，他们会认为没有比现在更好的机会了。
[cpg]


另一方面，如果他真的想建立友谊呢？
[cpg]


这样看起来就像魔王冒着孤独的风险来找我。我觉得这将给人以他是认真的印象。
[cpg]


另一方面，我对政治一无所知。我必须守口如瓶，尽量不泄露出去。
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『街』（夜）******************************************************



;//背景と別の場所です　黒帯を入れるなど、それが伝わるような演出をしてください



[OnName num="king"]
'欢迎，欢迎。已经有一段时间了。
[cpg cn=true]


好久没见了？　我们见过面吗？
[cpg]


[OnName num="renzi"]
「……」
[cpg cn=true]


我不知道，所以我保持沉默。不要失去你脸上的严肃表情。我不能害怕。
[cpg]


[OnName num="king"]
'如果你大老远一个人来到这里，你是不是想谈判什么？
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


[OnName num="Chancellor"]
我们怀疑它也可能与克拉拉的逃跑有关。"
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


[OnName num="king"]
'对。怎么说呢？"
[cpg cn=true]


[OnName num="renzi"]
"......"
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『街』（朝）******************************************************



;//背景と別の場所です　黒帯を入れるなど、それが伝わるような演出をしてください





我尽量保持沉默，如果被问到什么，我只说我是来呼吁停火的。
[cpg]


我真的不知道停火这个词是什么意思，但我觉得最好不要说我想结束战争。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（夕方）******************************************************



;//背景と別の場所です　黒帯を入れるなど、それが伝わるような演出をしてください





我拼命想阻止人类和恶魔之间的冲突。为了我所遇到的每一个人，但特别是为了库拉拉。
[cpg]


会谈持续了很长时间，甚至变成了我是否是真正的魔王的问题。就在这时，我被召唤到......。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara331"]
[OnName num="clara"]
......，如果他是真正的魔王？
[cpg cn=true]


[OnName num="king"]
'哦。如果你已经深入地牢，难道你没有看到它吗？
[cpg cn=true]


是库拉拉。我心里很不耐烦，她可能会猜到一切。
[cpg]


[OnName num="renzi"]
「……」
[cpg cn=true]


不过，我还是不得不保持沉默。你可以说我已经做了我能做的一切。
[cpg]


克拉拉知道。有变形金刚。而那个变形金刚，换句话说就是我，喜欢库拉拉。
[cpg]


那么我们该怎么做？这个试图促成休战的恶魔领主到底是谁？
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara332"]
[OnName num="clara"]
'...... 这个人，这个魔王是......'。
[cpg cn=true]


屏气凝神地吞下。姿态不由得让人眼前一亮。
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara333"]
[OnName num="clara"]
'它是真实的。毫无疑问，这正是我看到的恶魔之神。
[cpg cn=true]


[OnName num="king"]
'......，我明白了。
[cpg cn=true]


我松了一口气，但我不能拍胸脯。我继续装下去。
[cpg]



[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="feadin_up" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="07"]

;//【ＢＧ】『街』（夜）******************************************************


;//背景をそのまま表示してください


从克拉拉的证词来看，事情进行得很顺利。
[cpg]


主要是人类方面的大臣们，也就是国王的随从们在交谈，而我只是坐在那里。
[cpg]


即便如此，还是达成了停火。它进行得令人难以置信地顺利。
[cpg]


我想知道克拉拉是否真的没有注意到。我的转变有那么精确吗？
[cpg]


还是她什么都知道，但出于对我的怜悯而错过了？
[cpg]


或者也许不是怜悯，但她能看到我有多认真，她就顺其自然。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（夜）******************************************************





我目前不知道这些事情。
[cpg]


但我现在的当务之急是要回到地牢。
[cpg]


我对真正的魔王说的话，不能和他说的不一样。我必须去告诉她我做了什么。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夜）******************************************************





我想尽快做到这一点，但遗憾的是我没有这个实力。
[cpg]


在路上，我在一个恶魔村停了下来，告诉樱木发生的事情，并要求她在这里过夜。
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Satuki097"]
[OnName num="satsuki"]
'......，你的故事已经在这里讲了一路。
[cpg cn=true]


[OnName num="renzi"]
'是这样的吗？
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Satuki098"]
[OnName num="satsuki"]
'是的。人类似乎没有意识到这一点，但一个冒牌魔王已经设法促成了休战。
[cpg cn=true]


嗯，妖族可能从妖族那边传来了信息。
[cpg]


他们可能能够客观地理解相互冲突的信息。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki099"]
[OnName num="satsuki"]
我想说的是，在我的生活中，有很多事情都是我自己做的，而不是别人做的。　如果我是个坏孩子，我就会被杀死。"
[cpg cn=true]


[OnName num="renzi"]
'然而这很好。如果真的不成功，我还是愿意去死。"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Satuki100"]
[OnName num="satsuki"]
'这种痴迷从何而来？这是爱吗？
[cpg cn=true]


[OnName num="renzi"]
'哦。即使是樱木也能看到这一点。"
[cpg cn=true]


樱木有点不知所措，不知道如何回答。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki101"]
[OnName num="satsuki"]
'是的。我可以看到这一点。"
[cpg cn=true]


他回答说。我希望种族之间的争吵会停止，她的爱有一天会成真。
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





第二天早上，我离开恶魔村，走得更远。最后，......
[cpg]



[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





归还了。是时候解释我所做的一切了。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1" pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/2" time=800]

[VOICE f="Dorothy193"]
[OnName num="dorothy"]
'你是什么意思？　解释这一切。"
[cpg cn=true]


[OnName num="rudolf"]
'桃乐丝，别这么生气。你有一个很好的想法，这是怎么回事。"
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Janice165"]
[OnName num="janice"]
'但......，这意味着你无视我们所有的愿望。
[cpg cn=true]


[OnName num="rudolf"]
'你确定吗？　珍妮丝，你还没有打够人类吗？"
[cpg cn=true]


恶魔领主是一个知道如何说话的人。我以前不知怎么就感觉到了一丝丝这样的感觉。
[cpg]

;//[free]

[FO pos="1/2" time=1000]
[FO pos="2/2" time=1000]

[OnName num="renzi"]
'我很抱歉。这都是为了我自己的方便。"
[cpg cn=true]


[OnName num="rudolf"]
'不，不。从他们带走克拉拉的那一刻起，我就知道会发生这种情况。
[cpg cn=true]


这是真的吗？如果是这样，他能提前读到多少步？
[cpg]


[OnName num="rudolf"]
'即使对我来说，我也知道我们不可能永远争吵下去。但这并不意味着我可以直接与他们进行谈判'。
[cpg cn=true]


对于魔王来说，跳入人类的怀抱是一件可怕的事情。
[cpg]


而我代表他做这件事的意愿也因此受到尊重。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/2" time=800]
[VOICE f="Dorothy194"]
[OnName num="dorothy"]
'嘿，等一下!　爸爸，你确定你要这样做吗？"
[cpg cn=true]


[OnName num="rudolf"]
'这是什么？　有什么问题呢？　所以这是我想要的。"
[cpg cn=true]


[OnName num="rudolf"]
还是多萝西对停火生效有意见？
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Dorothy195"]
[OnName num="dorothy"]
'好了，就这样吧！'。　不，不，但是..."
[cpg cn=true]


...... 桃乐丝在这种情况下可能会有点像个大叔。
[cpg]


我也知道她的感受。但我无法回应。
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『平原』（昼）******************************************************





人类和恶魔之间的紧张关系正在慢慢消解。
[cpg]


我不能满足于此。冲突仍在世界的一些地方持续进行。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（昼）******************************************************


我不得不在人类的城镇和恶魔的地牢之间来回走动。
[cpg]


它是两个种族之间的桥梁。想到这也是为了世界和平的缘故，多少有些收获。
[cpg]


通常情况下，我的样子就像我救出库拉拉时的样子。我不能总是打扮成一个恶魔之王。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[VOICE f="Clara334"]
[OnName num="clara"]
啊......."
[cpg cn=true]


克拉拉在镇上逗留时也看到了他，并接近了他。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara335"]
[OnName num="clara"]
'我更喜欢叫你Renji，而不是Harry。
[cpg cn=true]


[OnName num="renzi"]
'两个都可以，但我想我会觉得更舒服。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（昼）******************************************************





她邀请我去她家。她自己早就意识到了真相，显然已经告诉了她的家人。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara336"]
[OnName num="clara"]
'你真的是一个...... 敢死队。
[cpg cn=true]


[OnName num="renzi"]
'我想它必须是那么好，否则我就无法传达我的感受。我一生都在背叛你'。
[cpg cn=true]


听到这句话，克拉拉有点沉默了。
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara337"]
[OnName num="clara"]
'请稍等一下。我给你沏点茶'。
[cpg cn=true]

;//[free]

[FO pos="2/3" time=1000]
[WAIT time=1100]

她的父母似乎都不在。沉默的气氛莫名其妙地尴尬起来。
[cpg]

[SE f=se011]
;//【ＳＥ】『食器の音』

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara338"]
[OnName num="clara"]
'给你。
[cpg cn=true]


[OnName num="renzi"]
谢谢你。"
[cpg cn=true]


啜饮茶水。我想在这个世界上有这样一种东西，那就是茶。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara339"]
[OnName num="clara"]
'......，我一直想有一天能像这样安静地喝杯茶。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara340"]
[OnName num="clara"]
'而且还和你在一起。我知道，你爱我一定是真的'。
[cpg cn=true]


[OnName num="renzi"]
'......，这是真的。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara341"]
[OnName num="clara"]
有几次我不确定我是否爱你。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara342"]
[OnName num="clara"]
'他只是帮助我，然后他就那样做了。是你干的，是你把我推到了边缘。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara343"]
[OnName num="clara"]
'也许我还在犹豫不决。从现在开始，你会让我检查吗？"
[cpg cn=true]


[OnName num="renzi"]
'当然了。我将成为克拉拉所爱的人'。
[cpg cn=true]


一个暧昧而复杂的关系。
[cpg]


克拉拉可能已经迷失了方向，但我没有。
[cpg]


[FO pos="2/3" time=1000]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





我所做的一切似乎都与这一时刻有关。
[cpg]



;//========================================
;//●ＣＧ（ベッドに隣り合って座っている二人）ev_31
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//備考　：主人公は人間の姿に変身しています
;//========================================

;//*Scene025

[STOPBGM]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_31_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1500]



[VOICE f="sClara009"]
[OnName num="clara"]
'我有点......，比开始时更紧张。
[cpg cn=true]


[OnName num="renzi"]
'第一次是什么时候？　你是说我绑架你的时候？"
[cpg cn=true]


克拉拉摇了摇头。她的脸颊已经变红。
[cpg]



[VOICE f="sClara010"]
[OnName num="clara"]
'就在你救了我之后。我想那时我的感情还不稳定'。
[cpg cn=true]


她当时很紧张。是这样的吗？
[cpg]


回想起来，我觉得她肯定是僵硬的。
[cpg]


那是在她被救出来之后，所以也许她是在她还没有理清自己的感情时做的。
[cpg]


[OnName num="renzi"]
'现在怎么样？　你还在紧张吗？"
[cpg cn=true]

;**【ＣＧ】 ev_31_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sClara011"]
[OnName num="clara"]
'我想知道它现在是否......。你能确定吗？"
[cpg cn=true]


我把我的嘴唇放在她的嘴唇上，就像这样。
[cpg]


她也没有拒绝。最后，我感到我们是真正联系在一起的。
[cpg]


;//移植前シーンカット

;//移植前シーンカット

;//ブラックアウト



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（夕方）******************************************************





无论以后发生什么事，互爱的感觉都不会改变。
[cpg]


这并不是什么诡计。我觉得我可以向她保证这一点。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="Clara396"]
[OnName num="clara"]
...... 你已经要走了吗？
[cpg cn=true]


[OnName num="renzi"]
'好吧，......，我在地牢里又有一些事情。我也要照顾他们在那边的意图。
[cpg cn=true]


克拉拉看起来很惆怅。在沉思片刻后。
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara397"]
[OnName num="clara"]
'嗯，我可以跟着你吗？
[cpg cn=true]


他说。我被这个怪癖吓了一跳。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（夕方）******************************************************

[SE f=se009]
;//【ＳＥ】『歩く』

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

然后库拉拉真的跟着我。
[cpg]


[OnName num="renzi"]
'你要大老远跑到地牢里来吗？　我认为它充满了敌人'。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara398"]
[OnName num="clara"]
'我打算去。你一直住在地牢里'。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara399"]
[OnName num="clara"]
我想知道你们的人是什么样的人。"
[cpg cn=true]


[OnName num="renzi"]
没关系，但有些...... 恶魔仍然很极端，所以要小心。"
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（夜）******************************************************



[SE f=se020]
;//【ＳＥ】『草原歩く』





离开城市，我们在夜里走过平原。库拉拉离城市只有一箭之遥。
[cpg]


我猜她已经习惯了在外面露营什么的。我非常疲惫，我是第一个走的。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara400"]
[OnName num="clara"]
'恋次，你很虚弱，不是吗？
[cpg cn=true]


[OnName num="renzi"]
他说库拉拉太强了。......，我知道你是一个不同的勇敢者。"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara401"]
[OnName num="clara"]
'别逗我了。我也有肌肉，而且我关心'。
[cpg cn=true]


与克拉拉谈论的不是别的。我爱那段时光胜过一切。
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『平原』（朝）******************************************************





当黑夜变成早晨，最终变成白天。
[cpg]




[window target=false]
[BG f="b_09_2.ui" time=1000]
[WAIT time=1500]
[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

我们到达了地牢。从这里开始，真的都是库拉拉的敌人。
[cpg]


我甚至不知道她是否会让我留下来，但我只能推着我的方式去。
[cpg]


[OnName num="renzi"]
'我一直告诉你，要做好准备。'他们中的一些人可能会说一些无情的话。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara402"]
[OnName num="clara"]
'没关系的。我应该被告知这些事情。
[cpg cn=true]


克拉拉是另一个不想战斗的人。
[cpg]


当我想到这一点时，似乎也许我做了正确的事情。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


当我们走过地牢的走廊时，我们聊了起来。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]
[VOICE f="Clara403"]
[OnName num="clara"]
'我是一个精灵，你可以看到。
[cpg cn=true]


[OnName num="renzi"]
'哦，......，那怎么办？
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara404"]
[OnName num="clara"]
'你是亚人。当战斗第一次爆发时，在是站在人类一边还是站在恶魔一边的问题上存在争议'。
[cpg cn=true]


克拉拉开始讲述她如何成为一名英雄的故事，直到现在。
[cpg]


我保持沉默，一边听着一边慢慢地走。
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara405"]
[OnName num="clara"]
'我不是一个纯洁的人，所以我有时会受到迫害。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara406"]
[OnName num="clara"]
'这都是对整个事件的反应。你知道，我花了很多时间去战斗。......"
[cpg cn=true]


他们还致力于通过取得战争胜利来提高精灵的地位。
[cpg]


而在这些努力取得成果的同时，他现在觉得，除了战斗，可能还有其他的解决办法。
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara407"]
[OnName num="clara"]
'......，这对恋次来说可能也是如此。
[cpg cn=true]


[OnName num="renzi"]
'当然，因为我也处在作为恶魔或人类的细微差别中。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara408"]
[OnName num="clara"]
'我们两个人都很难做到半途而废。
[cpg cn=true]


[OnName num="renzi"]
'我可能是半信半疑，但我总是站在库拉拉这边。我不是因为这种感觉而半途而废的。
[cpg cn=true]


克拉拉点了点头。她看起来很高兴。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





我们又走得更远了。他向库拉拉解释了地牢里发生的事情。
[cpg]


[OnName num="renzi"]
'这是我的房间。
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5" pos="2/3" time=800]
[VOICE f="Clara409"]
[OnName num="clara"]
'我的房间，你是说有...... 的房间？
[cpg cn=true]


[OnName num="renzi"]
那是因为它们是生物。...... 即使是蚂蚁也有洞穴。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara410"]
[OnName num="clara"]
'这有点奇怪，不是吗？我以为会更不协调。"
[cpg cn=true]


[OnName num="renzi"]
'他们很像人。他们可能更接近于普通的城堡或其他东西，只是在地下。
[cpg cn=true]


克拉拉急忙跑过去，说。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara411"]
[OnName num="clara"]
'...... 我记得你审问我的时候。
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


我不知道该如何回应，但克拉拉却脸红了。
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clara412"]
[OnName num="clara"]
'我真的不擅长使用触角。他们把我吓坏了'。
[cpg cn=true]


[OnName num="renzi"]
'为什么你说到害怕的时候脸会红？
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara413"]
[OnName num="clara"]
'你为什么不再试试呢？也许现在你可以克服你的苦闷了。
[cpg cn=true]


克拉拉似乎想再一次重温那些日子。
[cpg]


她可能是在试图推翻她身上的创伤。
[cpg]


[OnName num="renzi"]
'......，我明白。留在坏的记忆中很难，不是吗？
[cpg cn=true]


[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=100]
;//ブラックアウト

;//移植前シーンカット


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

然而，责备他们看起来和以前一样并不艺术。我被伪装成像章鱼一样的触角生物。
[cpg]

[VOICE f="sClara012"]
[OnName num="clara"]
'毕竟，这有点吓人......，但当你知道是Renji，你就会爱上他。
[cpg]


我们的关系已经改变。我们不能再回到过去了。我们只能走到我们要去的地方。
[cpg]



;//========================================
;//●ＣＧ（触手責め。ヒロイン仰向けの姿勢でベッドに寝ているヒロイン）ev_33
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公は蛸のような触手生物に変身しています
;//========================================

;//*Scene027

[STOPBGM]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1500]




[VOICE f="Clara441"]
[OnName num="clara"]
'Nn...... 耳朵，你也这样做吗？
[cpg cn=true]


他甚至摸了摸克拉拉的耳朵，她很害羞。
[cpg]



[VOICE f="Clara442"]
[OnName num="clara"]
'Nnnn......，它是粘稠的。这感觉很奇怪'。
[cpg cn=true]


克拉拉在说这句话的时候扭动着身体。
[cpg]


看起来她不喜欢它，但她没有拒绝它。
[cpg]


"奇怪 "一词表明，她并不是全盘拒绝。
[cpg]


触手是湿的，所以一定有一些声波的快感。
[cpg]


男人和女人都有声音癖好。克拉拉呢？
[cpg]


考虑到这一点，我将只滥用耳朵。我将继续这样做一段时间。
[cpg]


当我触摸她时，她说了这样的话。
[cpg]

;**【ＣＧ】 ev_33_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Clara464"]
[OnName num="clara"]
'我爱你，我爱仁慈胜过...... 任何人。
[cpg cn=true]


克拉拉低声说着甜言蜜语，但现在是说这些话的时候吗？
[cpg]


我甚至不打算拒绝克拉拉的邀请。希望我一直在抚摸她。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





最后，我忘记了我最初来这里的目的，和库拉拉调情了一阵子。
[cpg]


地下城有点模糊，所以我对时间的感觉有点模糊。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7" pos="2/3" time=800]
[VOICE f="sClara013"]
[OnName num="clara"]
'...... Renji在这里有事情要做，不是吗？

[cpg cn=true]


[OnName num="renzi"]
'哦，顺便说一下，......'
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_3" pos="2/2" time=800]
[VOICE f="Dorothy196"]
[OnName num="dorothy"]
你已经落后于计划。
[cpg cn=true]


[OnName num="renzi"]
对不起。......
[cpg cn=true]


;//[free]

[OnName num="rudolf"]
'嗯，你来了就好。从那时起，人类的情况如何？
[cpg cn=true]


[OnName num="renzi"]
'进展顺利，我想。国王本人和总理们似乎从一开始就想这样做"。
[cpg cn=true]


[OnName num="rudolf"]
'我明白了。好吧，那我很高兴听到这个消息。"
[cpg cn=true]


[OnName num="rudolf"]
'我们想要同样的东西。我们希望，一步一步地，也能把东西投入流通。"
[cpg cn=true]


就目前而言，仅仅是事实调查。我们曾经谈论过一切都很顺利，但
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7" pos="1/2" time=800]
[VOICE f="Janice166"]
[OnName num="janice"]
'对了，我刚才路过仁济的房间......，那是谁的声音？
[cpg cn=true]


突然，珍妮丝这样说。她知道吗？
[cpg]


[OnName num="renzi"]
'哦，不，那是......。
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Dorothy197"]
[OnName num="dorothy"]
那个精灵？"
[cpg cn=true]


[OnName num="renzi"]
...... 是。"
[cpg cn=true]


我觉得我无法掩饰，所以我回答。
[cpg]


[FACE method="change_4" pos="2/2"]
[VOICE f="Dorothy198"]
[OnName num="dorothy"]
'嗯。我在一个地牢里。嗯'。
[cpg cn=true]


桃乐丝公然不高兴。
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Janice167"]
[OnName num="janice"]
'你可以把他们带到这里来，但会有一些人对它不以为然。你最好小心点'。
[cpg cn=true]


我无法回嘴，所以我闭嘴了。
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Dorothy199"]
[OnName num="dorothy"]
'...... 嗯，好吧。珍妮丝。"
[cpg cn=true]


[FACE method="change_5" pos="1/2"]
[VOICE f="Janice168"]
[OnName num="janice"]
嗯？"
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Dorothy200"]
[OnName num="dorothy"]
'是恋次使我们现在的和平成为可能。如果把她从那里踢出去，那就太可怜了。
[cpg cn=true]


多萝西仍然脾气暴躁。但她并不是想摆脱克拉拉。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





我想这是一个变化。桃乐丝以前不会这样说。
[cpg]


她觉得和平的日子会继续下去。我现在只是觉得很高兴。
[cpg]


如果有一天会有另一场战斗，我觉得我可以阻止它。......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_4" pos="2/3" time=800]
[VOICE f="Clara467"]
[OnName num="clara"]
情况如何？"
[cpg cn=true]


[OnName num="renzi"]
'魔王一直非常合作。事情进展顺利。"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara468"]
[OnName num="clara"]
'我很高兴听到这个消息。我们要不要回城？"
[cpg cn=true]


[OnName num="renzi"]
'是啊，......，我也想念这个房间，虽然我不确定我会想念它。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara469"]
[OnName num="clara"]
'那我们要不要在这里多待一会儿？我总是准备好了'。
[cpg cn=true]


我红着脸说，'在这里，我的父母也不在这里'。
[cpg]


[OnName num="renzi"]
'哦。你可以随心所欲地调情'。
[cpg cn=true]


克拉拉点了点头，显得很尴尬。
[cpg]


;//ブラックアウト


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

我可以随时离开这个地牢，克拉拉说。
[cpg]


就感情而言，我们可以永远做爱。但这是不可能的。
[cpg]


我打算变回我的人形并离开地牢。因为。
[cpg]


[OnName num="renzi"]
'我确信克拉拉的父母很担心她。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara495"]
[OnName num="clara"]
'不，它一直在发生。我一直在执行危险的任务'。
[cpg cn=true]


[OnName num="renzi"]
'但现在你终于得到了安宁。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara496"]
[OnName num="clara"]
'...... 当然，也许是时候回去了。
[cpg cn=true]


在这样的谈话中，他和克拉拉回到了城市。
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************





地牢和城市之间的时间不可能只是一瞬间。
[cpg]


我可以变成一个像鸟一样的恶魔，但我不能带着人飞。
[cpg]


即使我能够模仿他们的生态，我也无法挥舞他们全部的原始力量。
[cpg]


[window target=false]
[STOPBGM]
[BG f="b_09_3.ui" time=1000]
[WAIT time=1500]
[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（夕方）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

库拉拉似乎明白这一点。
[cpg]


我认为在这段旅程中我会感到无聊，但库拉拉在我面前是那么的遥远。
[cpg]


我以前也想过这个问题，但我想她有耐力。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara497"]
[OnName num="clara"]
'你还好吗？　你需要休息一下吗？"
[cpg cn=true]


[OnName num="renzi"]
是的，不，我很好。......
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夜）******************************************************





如果不是我能够沿途接力恶魔定居点，我可能已经摔倒了。
[cpg]


这就是我对樱木的合作所表示的感激。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="1/2" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4" pos="2/2" time=800]

[VOICE f="Satuki102"]
[OnName num="satsuki"]
他说："我知道，我知道，我知道，我知道，我知道，我知道，我知道，我知道，我知道，我知道，我知道，我知道，我知道，我知道，我知道，我知道，我知道，我知道，我知道，我知道。你一定是去而复返过很多次了，但你总是一副很辛苦的样子。
[cpg cn=true]


[FACE method="change_4" pos="1/2"]
[VOICE f="Clara498"]
[OnName num="clara"]
'有没有可能，作为一个变形人，会让人更难长出肌肉？
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Satuki103"]
[OnName num="satsuki"]
来吧，......，我想知道。"
[cpg cn=true]


我注意到，克拉拉和萨特基对彼此的了解越来越多。
[cpg]


各种障碍正在被打破。我希望有一天，我也能和桃乐丝交谈。
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（朝）******************************************************



[SE f=se009]
;//【ＳＥ】『歩く』





我们一边走，一边又回到了城市。
[cpg]


有了地牢和这个小镇，我还是把地牢当成了家。......
[cpg]


但我真正的家是现代日本。
[cpg]


奇怪的是，我不再想念它了。我甚至不想回去。
[cpg]


如果这个世界绝对存在并需要我，我就不会有这种感觉。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（昼）******************************************************

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_1" pos="2/3" time=800]

[OnName num="renzi"]
'进展如何？　感觉对吗？"
[cpg cn=true]


而且我进一步完善了我作为变形金刚的转变。
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara499"]
[OnName num="clara"]
'我觉得我的耳朵可以再大一点。......
[cpg cn=true]


[OnName num="renzi"]
'也许我可以。'我会努力的。
[cpg cn=true]


我的变形能力正变得越来越灵活。
[cpg]


起初，我无法转化为任何我闻不到的东西，但当我...... 闻到各种恶魔时，我的能力就转化了。
[cpg]


在某种程度上，我能够自由地转变为任何我能够想象的气味。
[cpg]


换句话说，我变得能够转化为不存在的生命或人。利用这一点，我试图把自己变成一个谁也不是的精灵。
[cpg]


[OnName num="renzi"]
我不能一直装扮成可能在别的地方的人，因为那会是一个问题。"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara500"]
[OnName num="clara"]
'对。但你为什么是精灵族？
[cpg cn=true]


[OnName num="renzi"]
'我只想尽可能地接近库拉拉。
[cpg cn=true]


我发现自己在说诚实的话。克拉拉脸红了。
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara501"]
[OnName num="clara"]
'真的，我不觉得不舒服。不过，无论你怎么看，仁慈都很可爱。
[cpg cn=true]


克拉拉说了一句话，让我咽了口唾沫。我觉得我现在就想抱抱她。
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『ヒロイン１の家＿ダイニング』（夜）******************************************************

;//移植前シーンカット




一切都将得到解决。人类和恶魔之间也会有某种交易。
[cpg]


如果事情一点一点地发展，人和魔鬼会来来去去。如果发生这种情况，界限将变得越来越模糊。
[cpg]


就像叫我的恶魔和叫库拉拉的精灵结合在一起。
[cpg]


如果这种爱增加了，哪怕只是一点点，那么对我来说，我就没有什么可希望的了。
[cpg]


所有这些都可以说是因为我是一个混血儿和叛徒。
[cpg]



;//========================================
;//●ＣＧ（二人布団の中でいちゃつく。身を寄せ合っている感じ）ev_35
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//備考　：主人公はエルフに変身しています
;//========================================


[STOPBGM]
[BG f="black.ui"  time=1000]
[WAIT time=100]
[BGM f="09"]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1500]






[VOICE f="Clara526"]
[OnName num="clara"]
'......，现在已经是早上了，不是吗？
[cpg cn=true]


[OnName num="renzi"]
这是真的......，我觉得要睡到中午左右。"
[cpg cn=true]



[VOICE f="Clara527"]
[OnName num="clara"]
'不。你说你今天有事情要做'。
[cpg cn=true]


[OnName num="renzi"]
'我明白了。我有事情要告诉这边的国王。
[cpg cn=true]


但这并不改变我们一直以来的友好路线。
[cpg]


我在想，我没有必要去。
[cpg]


[OnName num="renzi"]
让我再睡一会儿。......
[cpg cn=true]

;**【ＣＧ】 ev_35_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Clara528"]
[OnName num="clara"]
'呵。'那好吧，我明天早上叫你起床。
[cpg cn=true]


说到这，克拉拉没有再乱来。
[cpg]


我想库拉拉和我可以从此幸福地生活下去。如果这个世界要变成一个我无法快乐的地方，我就再去改变它。
[cpg]


回顾过去，我认为Kulara一直在努力实现这一目标，已经有很长一段时间了。
[cpg]


我认为我们非常相似。我们是否注定要被对方吸引？
[cpg]



[VOICE f="Clara529"]
[OnName num="clara"]
晚安，仁济。
[cpg cn=true]


[OnName num="renzi"]
哦，晚安。......
[cpg cn=true]


我闭上眼睛，感觉克拉拉在我身边。
[cpg]


下次我醒来的时候，她会在我身边。我现在很高兴，我可以相信这一点。
[cpg]


[SCENE id=18]


;//ＥＮＤ　ヒロイン１ルート


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="epend.ks" target="*start"]


;//==============================
