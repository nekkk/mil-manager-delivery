
*start


;//異世界変態生活　シナリオ
;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//クラーラ　　　　裸　下着　私服　軽装の鎧
;//ドロシー　　　　裸　下着　着衣
;//ジャニス　　　　裸　下着　私服　鎧
;//アーシャ　　　　裸　下着　着衣
;//サツキ　　　　　裸　下着　着衣

;//上記以外のキャラクターには音声がありません

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//クラーラ　　　　一人称「私（わたし）」　ドロシー呼び「ドロシー」　ジャニス呼び「ジャニス」
;//　　　　　　　　アーシャ呼び「アーシャ」　サツキ呼び「サツキ」　蓮司呼び「蓮司」
;//ドロシー　　　　一人称「あたし」　クラーラ呼び「クラーラ」　ジャニス呼び「ジャニス」
;//　　　　　　　　アーシャ呼び「アーシャ」　サツキ呼び「サツキ」　蓮司呼び「蓮司」
;//ジャニス　　　　一人称「私（わたし）」　クラーラ呼び「クラーラ」　ドロシー呼び「姫様」
;//　　　　　　　　アーシャ呼び「アーシャ」　サツキ呼び「サツキ」　蓮司呼び「蓮司」
;//アーシャ　　　　一人称「私（わたし）」　クラーラ呼び「クラーラ」　ドロシー呼び「ドロシー」
;//　　　　　　　　ジャニス呼び「ジャニス」　サツキ呼び「サツキ」　蓮司呼び「蓮司」
;//サツキ　　　　　一人称「私（わたし）」　クラーラ呼び「クラーラさん」　ドロシー呼び「ドロシーさん」
;//　　　　　　　　ジャニス呼び「ジャニスさん」　アーシャ呼び「アーシャさん」　蓮司呼び「蓮司」

;//蓮司　　　　　　一人称「俺」　クラーラ呼び「クラーラ」　ドロシー呼び「ドロシー」
;//　　　　　　　　ジャニス呼び「ジャニス」　アーシャ呼び「アーシャ」　サツキ呼び「サツキ」
;//　　　　　　　　ただし、物語序盤ではさん付けあるいはちゃん付けで呼ぶ

;//クラーラルートの一部では、蓮司は「ハリー」と偽名を使う
;//その間蓮司はクラーラを「クラーラさん」と呼び　クラーラは蓮司を「ハリーさん」と呼ぶ


;//////////////////////////////////////
;///////////////以下本編///////////////
;//////////////////////////////////////

;###################################################################
*Ep000|"変身"
;###################################################################


[SCENE id=0]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
[STOPBGM]


[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 1]
[stflag Cha4flg = 1]
[stflag Cha5flg = 1]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]


[BG f="black.ui"  time=1000]
[WAIT time=100]
[WAIT time=100]
;//ブラックアウト




我想有人把主角转世到另一个世界的故事比作卡夫卡的“变形记”。
[cpg]


我也有点了解这种感觉。我明白你的意思： ......
[cpg]


没想到转世又进一步蜕变。
[cpg]




[window target=false]

[WAIT time=1000]

[BGM f="04"]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="04"]
[window target=true]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





一个生活在现代世界的学生。一个太平凡无话可说的学生。
[cpg]


我没有女朋友，但我有几个朋友。没有不便，但也没有太多的自由。
[cpg]


一般来说，不开心也不不开心……就是这样的生活……
[cpg]


什么观点，这不是我在看这样的观点时所想的。
[cpg]


[OnName num="renzi"]
“……”
[cpg cn=true]


原村连二。我不记得究竟发生了什么以及它是如何发生的。
[cpg]


它似乎在地下的某个地方，就像一个地牢。
[cpg]


本来我是在保护猫的时候被车撞了，但是本来应该保护的猫也不在。
[cpg]


最重要的是，即使我试图站起来，我也做不到。
[cpg]


我不知道我的腿在哪里，我的手在哪里。尽管如此，我还是有一种能够移动的感觉。
[cpg]


我看到我自己。我对自己的长相有一些了解，但我不知道自己长什么样。 ……
[cpg]

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

;//レターボックスin
[FACE method="feadin" pos="4/7"]

[BG f="b_04_5_up.ui" time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_01_1 ***********************
;//カットイン
[CUTIN f="ci_01_1.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

可以说，那是一条蛇。这不是一条普通的蛇。
[cpg]


一个生活在现代的学生。不知道有没有被车撞到转世这种事。
[cpg]


这很可能是我做的一个梦。
[cpg]



可能是真实的我在医院昏迷。
[cpg]


但奇怪的是我的外表。
[cpg]


蛇，蛇……对我来说并不是那么着迷。
[cpg]


[CUTIN f="ci_01_1.ui" show={false} method="feadout"]
;//[WAIT time=1000]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』
[WAIT time=1000]

[window target=true]

一切都感觉非常真实，以确认这不是梦。
[cpg]


没有腿。没有手。然而我知道如何移动我的身体向前移动。
[cpg]


而且我没有任何不适。触觉也在那里。
[cpg]


[OnName num="renzi"]
……
[cpg cn=true]


即使我想自言自语，我也没有声带，无法说话。
[cpg]


我沿着通道爬行，不知道发生了什么事，直到我发现通道中间有一个陡峭的楼梯。
[cpg]


我不能再进一步了。至少，不是我现在的状态。
[cpg]

;//レターボックスout
[FACE method="feadout" pos="4/7"]


[SE f="se007"]
;//【ＳＥ】『ゴーレム足音』

[WAIT time=2000]

;**【ＣＧ】ci_02_0 ***********************
;//カットイン
[CUTIN f="ci_02_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


正当我这么想着的时候，一个高约两米，像魔像一样的大石人偶从我身边经过。
[cpg]


这就像一个“哦，这是一个恶魔。
[cpg]


我并不感到惊讶，因为我看起来像这样。他们也不感到惊讶。
[cpg]


魔像不在乎它是否看到了我。
[cpg]

[CUTIN f="ci_02_0.ui" show={false} method="slideout"]
[WAIT time=1000]



我想知道一个恶魔看一个恶魔是否就像一个人看着一个人。 ……
[cpg]


我们不能再这样下去了。当我凝视着离我而去的魔像时，我想知道我是否可以做点什么。
[cpg]

[SE f=se001]
;//【ＳＥ】『変身音　リバースシンバル』

[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_02_0 ***********************
;//カットイン
[CUTIN f="ci_02_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


我祈祷了。我想了想，然后……发现自己的身体结构发生了变化。
[cpg]


唯一触发它的是我想上楼梯。
[cpg]


仅此而已，我不再是蛇的形式。
[cpg]


转型。有可能转生到异世界，变成不同的形态，但是……
[cpg]


怎么可能从那里进一步采取另一种形式？
[cpg]


不，已经发生的事情已经发生了。我现在已经得到了我的腿，所以我继续走到楼梯的尽头。
[cpg]


[SE f="se007"]
;//【ＳＥ】『ゴーレム足音』


[CUTIN f="ci_02_0.ui" show={false} method="slideout"]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



我的身体很沉重。我走得很慢，但我走不快。
[cpg]


一步一步，恶魔的数量增加了。哥布林，兽人，还有其他的魔像，看到我的时候都没有注意。
[cpg]


当我深入地牢时，我发现了一个稍微开放的区域。
[cpg]


[window target=false]

[STOPBGM]
[transition target={true} rule="tobira2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=1]
[WAIT time=100]
[transition target={false} rule="tobira2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[BGM f="02"]


[SE f="se008"]
;//【ＳＥ】『喧噪』

[window target=true]

有一个地方可以称为总部之类的。
[cpg]


一张大桌子和许多椅子。而当我看着桌子上的食物时，它看起来更像是一个自助餐厅，而不是一个基地。
[cpg]


在那里，各种种族的恶魔聚集在一起，食物由同样做饭的恶魔提供。
[cpg]


这是一个奇怪的景象，但我想恶魔不能不吃任何东西。
[cpg]


[OnName num="renzi"]
“（想想，我饿了……）”
[cpg cn=true]


如果我问，我可能会得到一些东西，但它是一个傀儡，所以它不会说话。
[cpg]


但是我太饿了，所以我决定加入他们。
[cpg]


我不确定我现在加入他们是否可以，但我忍不住。
[cpg]


;//ここから暫くアーシャの名前をunknownと隠してください


[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha001"]
[OnName num="unknown"]
在餐厅里很少见到魔像。我能给你什么？
[cpg cn=true]


一个像兔子一样的兽人正在看着我们。
[cpg]


[OnName num="renzi"]
……”
[cpg cn=true]


我什么都回复不了。毕竟，我没有嘴。
[cpg]


如果我没有嘴，那是否意味着我不能吃东西？你还说过，食堂里来的魔像很不寻常。
[cpg]


我默默点头。我认为这足以传达信息。
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha002"]
[OnName num="unknown"]
我会把它留给你。我的意思是，傀儡吃米饭吗？ ”
[cpg cn=true]


兽人说完，指了指自己的座位。
[cpg]


我想知道他为一个他不知道他是否会吃米饭的人做饭是不是很自然。 ……
[cpg]

现在我什至不能得到一个幸运的休息时间。
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha003"]
[OnName num="unknown"]
我现在什至无法发表评论。我马上把它拿过来。 ”
[cpg cn=true]


[SE f="se007"]
;//【ＳＥ】『ゴーレム足音』


[FO pos="2/3" time=2000]

;//レターボックスin
[FACE method="feadin_up" pos="4/7"]

他说完，我就回到座位上。
[cpg]


我以为椅子要坏了，我可能比现在重。 ……
[cpg]


那是一把坚固的椅子，好像它是为那种东西而设计的。
[cpg]


;//ブラックアウト

但是地牢里的餐厅？
[cpg]


我想知道他们是如何使用火的。它必须让空气通过，不是吗？
[cpg]


我的意思是，他们对这些成分做了什么？
[cpg]


蔬菜可以用魔法什么的，但它们会饲养牲畜吗？ ……
[cpg]


问题是无止境的，但无论如何，我现在都被自己的饥饿感填满了。
[cpg]

[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


[FG f="CHA04_p1_01_a.ui" method="change_2"  pos="2/3" time=1000]
[VOICE f="Arsha004"]
[OnName num="unknown"]
'干得好。不知怎的，我觉得你不会吃肉，所以我决定要一套沙拉。 ”
[cpg cn=true]



[SE f=se011]
;//【ＳＥ】『食器の音』


我相信你是对的，我无法想像一个傀儡吃肉会是什么样子。
[cpg]


另一方面，我不能说它是否会吃蔬菜。
[cpg]


我想原来的傀儡可能不吃米饭，但我想吃它。
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha005"]
[OnName num="unknown"]
我想，“……怎么了，你不想吃？你来了，就是想吃点东西。”
[cpg cn=true]

面包和沙拉放在一个碗里，放在你面前。
[cpg]

我同意。我想吃。但是我没有嘴。
[cpg]


即使我是魔像，我也有视觉、听觉、嗅觉和触觉。
[cpg]


它唯一没有的是味觉。毕竟，它没有嘴。
[cpg]


没有嘴，就不可能吃东西。魔像如何获得营养？
[cpg]


还是原来的傀儡不需要吃？ ……
[cpg]


那么，我想我已经无法模仿魔像本身的机制了，即使我现在已经变成了魔像。
[cpg]

[FO pos="2/3" time=1000]


我看着我旁边。妖精正在吃东西，粗略地说是一道荤菜。
[cpg]


我在想，“即使他是恶魔，他也会使用餐具”，但这不是我现在应该看的。
[cpg]


要是能变成哥布林就好了。至少他有一张嘴。
[cpg]


我想，我试着像以前一样提醒自己，但是......
[cpg]


[OnName num="renzi"]
“……”
[cpg cn=true]


我无法变身。我不知道有什么不同。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha006"]
[OnName num="unknown"]
你不吃，我就不吃了，好吗？ ”
[cpg cn=true]



兔子兽人向我走来。它离我很近，我能闻到它的味道。
[cpg]


我以前从来没有一个女孩这么靠近我。我猜她不在乎我是个魔像，我想。 ……
[cpg]


我知道那是什么味道。它闻起来像香草和肥皂的混合物。
[cpg]


不知何故，这是我想记住的气味。
[cpg]


不过，虽然我是魔像，但我还是有嗅觉的。我一直都有视力和听力，对吧？
[cpg]



我突然想到，我应该试着把自己变成兽人。
[cpg]


我不知道我为什么这么想。但不知怎的，我觉得我可以比我身边的哥布林变形得更好。
[cpg]

[STOPBGM]

[SE f=se001]
;//【ＳＥ】『変身音　リバースシンバルのような音』
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

;//レターボックスout
[FACE method="out" pos="4/7"]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/5" time=1]
[FG f="CHA04_p4_01_a.ui" method="change_7"  pos="4/5" time=1]

[WAIT time=100]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


然后他的身体结构再次发生了变化。它既不是蛇也不是傀儡，而是兽人。
[cpg]

[BGM f="02"]
[SE f="se008"]
;//【ＳＥ】『喧噪』

[OnName num="goblins"]
哇！嘿，你到底是什么鬼？
[cpg cn=true]


周围一片哗然。这只是一个转变，但似乎很不寻常。
[cpg]



[FACE method="change_1" pos="2/5"]
[VOICE f="Arsha007"]
[OnName num="unknown"]
我很惊讶。 ......你是变形者，不是吗？
[cpg cn=true]


[OnName num="goblins"]
我不知道还有幸存者。你来自哪里？ ”
[cpg cn=true]


我可以回复，或者我现在可以。但不仅如此：......
[cpg]

[FO pos="2/5" time=1000]
[FO pos="4/5" time=1000]

[SE f=se011]
;//【ＳＥ】『食器の音』

;//レターボックスin
[FACE method="feadin" pos="4/7"]

我决定亲自动手吃我面前的饭菜。
[cpg]


恶魔们看着我，谈论这个和那个，但我不在乎。
[cpg]


[OnName num="goblins"]
他们一定是真的饿了……但我不知道这个地牢里有变形者。
[cpg cn=true]


以刺耳的语气说话的声音通常是你对我的期望，仅此而已。
[cpg]


事实上，甚至有恶魔来到我身边，试图直接和我说话。
[cpg]


[OnName num="orc_A"]
听说你是变形金刚你真的很像阿莎。 ”
[cpg cn=true]



;//ここからアーシャの名前を隠さないでください



[OnName num="orc_B"]
是真的，……如果你能变的这么近，你的招数就很多了。 ”
[cpg cn=true]

[stopse g=3]
;//通常se

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト


;//レターボックスout
[FACE method="out" pos="4/7"]


根据故事，变形者是一个曾经为恶魔部落做出巨大贡献的种族。
[cpg]


我不知道我应该如何接受它，但我并没有因为被宠坏而感到难过。
[cpg]


[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=100]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************




[window target=true]

另一方面，如果我一直像那个女孩一样打扮，那就太显眼了。
[cpg]


我再次变回魔像形态，离开了食堂。
[cpg]


像往常一样，我无法伪装成妖精。我不知道为什么我能变成那个叫阿莎的女孩。
[cpg]


这是一件很奇怪的事情，但必须有一些条件。
[cpg]


[OnName num="renzi"]
现在肚子已经饱了，我有点困。
[cpg cn=true]


困。我很困，但我不知道在哪里睡觉。
[cpg]


可以睡在地牢中间的任何地方吗？
[cpg]


如果这是一个安全的地方，那很好。但也有可能不是。
[cpg]


恶魔似乎对恶魔置之不理，但也有可能对人类怀有敌意。
[cpg]


有人谈论变形器在某种操作中很有用。
[cpg]


如果有行动，就说明有敌意。
[cpg]


[OnName num="renzi"]
'（不，我现在不想考虑其他任何事情。......）”
[cpg cn=true]


想了很久，还是决定回去睡觉了。
[cpg]



[BG f="black.ui"  time=1000]
[WAIT time=100]
[STOPBGM]
;//ブラックアウト





我在走廊合适的地方躺下。即使有虫子，它们也不会咬我，因为我是傀儡。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[window target=true]

在睡了一夜好觉之后。我不是自己醒的，是我自己醒的。
[cpg]


叫醒我的是蜥蜴人，或者我应该说是直立的爬虫类生物。
[cpg]


[OnName num="lizardman"]
你在干嘛？睡在这种地方干什么？
[cpg cn=true]


[OnName num="renzi"]
“……”
[cpg cn=true]


[OnName num="lizardman"]
你永远不知道那个勇敢的女人什么时候会发动攻击。你不害怕吗？
[cpg cn=true]


我无言以对，无法回话。
[cpg]


[OnName num="lizardman"]
反正我宁愿你去守卫，也不愿睡在这里。 ”
[cpg cn=true]



他们说这样的话。我很不情愿地朝我被领的地方走去。
[cpg]

[SE f=se007]
;//【ＳＥ】『ゴーレム足音』


;//レターボックスin
[FACE method="feadin_up" pos="4/7"]


我猜他们给我分配了一份地牢社区成员的工作。
[cpg]


这不是一份工作，尽管我在值班。我真的只是在那里守望。
[cpg]


我在那里从不孤单，所以我从不觉得无聊。
[cpg]


[OnName num="goblins_A"]
跟魔像呆在一起有点无聊，因为你不能和它说话。 ”
[cpg cn=true]


[OnName num="goblins_B"]
'好吧，不要那么肯定。我听说一个变形者来到我们家。
[cpg cn=true]


[OnName num="goblins_A"]
我在想，“变形者......？如果这是真的，那是一件大事。
[cpg cn=true]


我们在地牢里呆了一段时间，轮流看守。
[cpg]


幸运的是，在我值班时没有人出现。也许他们是敌对的。
[cpg]


如果他们出现了，我要和他们战斗吗？
[cpg]


我尽量让自己看起来很强壮，所以我一直把自己伪装成一个魔像，而不是我原来的蛇形。
[cpg]


它的动作很慢。看起来战斗力不是很好，但即使是原始形式也是如此。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//レターボックスout
[FACE method="out" pos="4/7"]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************

[window target=true]


尽管如此，我还是不能在吃饭时保持魔像形态。
[cpg]


我的变身曲目要么是魔像，要么是野兽人……例如阿莎。
[cpg]


[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="4/5" time=800]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/5" time=800]
[VOICE f="Arsha008"]
[OnName num="asha"]
'哇！惊喜，惊喜，我以为我在那里。 ”
[cpg cn=true]


以她的形式出现在餐桌上可能会导致不必要的误解。
[cpg]


[OnName num="orc"]
'两个阿莎的……？你是不是学了什么魔法？ ”
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Arsha009"]
[OnName num="asha"]
不，不，不，他是一个变形者，而且他......更像一个她而不是一个他。 ”
[cpg cn=true]

[FO pos="2/5" time=1000]
[FO pos="4/5" time=1000]


[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





当我上床睡觉时，我去了一个与餐厅分开的大房间。
[cpg]


它很大，显然是一个公共卧室。
[cpg]


与这间类似的房间有好几间，高阶恶魔也有私人房间。
[cpg]



[window target=false]

[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************

[window target=true]


当我继续守望时，我偶尔会看到一个人。
[cpg]

;**【ＣＧ】ci_02_0 ***********************
;//カットイン
[CUTIN f="ci_02_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

但如果他们伪装成强壮的魔像，他们一遇到就会逃跑。
[cpg]


不管他们是否真的可以战斗，能够改变他们的外表是有用的。
[cpg]

[CUTIN f="ci_02_0.ui" show={false} method="slideout"]
[WAIT time=1000]


[OnName num="goblins"]
'不，它有帮助。你看起来很强壮。
[cpg cn=true]


我周围的人开始知道我是一个变形者。
[cpg]


他们知道我没有足够的力量与自己战斗，他们很支持。
[cpg]


但作为一个永远不会说话的魔像，是个问题。 ……
[cpg]


话虽如此，唯一的说话方式就是借用亚莎的形式。
[cpg]


每次有人看到你在做，误解你的时候，解释起来也很麻烦。
[cpg]


[OnName num="goblins"]
你真的不怎么说话，……或者说，你不会说话。 ”
[cpg cn=true]


[OnName num="renzi"]
（嗯，那是因为它是一个傀儡。）”
[cpg cn=true]


[OnName num="goblins"]
你应该试着变成我，”他说。然后也许你可以谈谈。
[cpg cn=true]


我拼命想变成他，但我做不到。
[cpg]


有什么区别？我努力伪装自己，但我做不到。我什么都不记得了。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="ep001.ks" target="*start"]


