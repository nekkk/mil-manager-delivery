*start

;###################################################################
*Ep006|转化的法则。
;###################################################################


[SCENE id=6]

[window target=false]


[BG f="black.ui"  time=1000]
[WAIT time=1000]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]

[stflag Jumpflg = 0]


[if exp={getFlagValue("Jumpflg") == 0 }]
[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 0]
[stflag Cha4flg = 0]
[stflag Cha5flg = 0]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]
[endif]



[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





他们做任何他们想做的事。我知道这一点，但这并没有阻止我。
[cpg]


没有人可以阻止我。我甚至不能意识到这是我。
[cpg]

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

我变身为珍妮丝的模样，在镜子前检查我的倒影。
[cpg]



;//ここからしばらく、ジャニスのセリフ名前欄を「ジャニス（蓮司）」と置き換えてください



[FG f="CHA03_p4_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Janice051"]
[OnName num="renzi_to_janice"]
'令人惊讶的是，你的乳房很大。...... 哦，这里有一颗痣。
[cpg cn=true]


你可以看到她身体的每一个细节。尽管我没有看到一切。
[cpg]


我可以想象，那里一定有某种神奇的力量在起作用。
[cpg]


必须要有某种触发器才能够转化。你不需要知道所有的事情，就能够进行转变。
[cpg]

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1500]
[WAIT time=1000]
;//ブラックアウト





而那一天，我睡在珍妮丝的身上。
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





当我穿着那套衣服梦游到食堂时。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="4/5" time=800]
[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Dorothy045"]
[OnName num="dorothy"]
'嗯？　珍妮丝，我们刚刚经过对方。"
[cpg cn=true]


桃乐丝让我吃惊。哦，所以我现在打扮成珍妮丝了？
[cpg]

[FACE method="change_7" pos="2/5"]
[VOICE f="Janice052"]
[OnName num="renzi_to_janice"]
'不，我是Renji。
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Dorothy046"]
[OnName num="dorothy"]
'哦，我明白了。......，我很惊讶。
[cpg cn=true]



;//ここからジャニスのセリフ名前欄を元に戻してください


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FO pos="2/5" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



这的确让人困惑，所以我留下了我的转变，没有转变......，或者说穿得不一样。
[cpg]


我通常的格莱姆装束。我穿着这身衣服不能说话，但如果要正常花时间的话，穿着这身衣服走动更方便。
[cpg]


如果我是一个类似人形的粘液，我可以说话，但很难移动。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy047"]
[OnName num="dorothy"]
'但如果我在打扮成珍妮丝的时候遇到珍妮丝，她可能会很惊讶。
[cpg cn=true]


多萝西笑着用手托着下巴，似乎在谋划。
[cpg]


但也许她确实如此。她对鬼魂不是很了解，所以她可能会误以为是二重身之类的。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="07"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



珍妮丝说她正在值夜班，还在睡觉。
[cpg]


我向她的房间走去。当然，我会事先打扮成珍妮丝的样子，给她一个惊喜。
[cpg]


我详细地回忆了她。她的样子，甚至她的气味。......
[cpg]


我已经知道珍妮丝的气味。我记得，事情是这样的。
[cpg]



;////////////////////////
;////////////////////////
;//二度目の変身システム//
;////////////////////////
;////////////////////////


;//選択肢用フラグ
[stflag IseSel02flg = 0]

我相信第一个气味是......
[cpg]


[switch]
[case "香草。"]
	[swap]
	[jump target="*hen21"]
[case "水果"]
	[swap]
	[stflag IseSel02flg = 1]
	[jump target="*hen21"]
[case "花卉"]
	[swap]
	[jump target="*hen21"]
[endswitch]


*hen21|変身の法則


第二种气味是......
[cpg]



[switch]
[case "薄荷。"]
	[swap]
	[stflag IseSel02flg = 1]
	[jump target="*hen22"]
[case "香水"]
	[swap]
	[jump target="*hen22"]
[case "肥皂"]
	[swap]
	[jump target="*hen22"]
[endswitch]

*hen22|変身の法則


[window target=true]

[WAIT time=100]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FACE method="out" pos="4/7"]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="04"]


[window target=true]

[if exp={getFlagValue("IseSel02flg") == 2 }]
[jump target="*select02_2"]
[endif]



[jump target="*select02_1"]

;//■選択肢Ａ
1、香草
2、水果
3, 鲜花

;//■選択肢Ｂ
4、Mint
5、香水
6、肥皂。





;//==============================
;//２、果物　４、ミント　を選んでいた場合
*select02_2|変身の法則

[window target=false]

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

[window target=true]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="2/3" time=800]


我有一个成功的转变，不由自主地嘟囔了一句'好'。
[cpg]



;//どこからどう見てもジャニスだ。その姿のまま、彼女の部屋まで向かう。

就所有意图和目的而言，我是珍妮丝。
[cpg]

我想说的是，转型是成功的。
[cpg]

以这种形式，我向她的房间走去。就一会儿，因为我想出了一个顽皮的想法。
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//ブラックアウト

[window target=true]

[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/5" time=800]

[VOICE f="sJanice002"]
[OnName num="janice"]
'什么...... 我，你们两个......？
[cpg cn=true]


当我以这种形式前往她的房间时，珍妮丝吃了一惊。
[cpg]

[FACE method="change_5" pos="4/5"]

[FO pos="2/5" time=1000]

[SE f=se016]
;//【ＳＥ】『倒れる』

然后，也许意识到发生了什么，她瘫倒在地，晕了过去。
[cpg]


看来，她真的不喜欢鬼。
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[BGM f="02"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/5" time=800]

[VOICE f="sJanice003"]
[OnName num="janice"]
'......，我做了一个奇怪的梦。那是一个有两个我的梦。"
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="sArsha008"]
[OnName num="asha"]
'那是什么？　像星体投射？"
[cpg cn=true]


[FACE method="change_4" pos="2/5"]
[VOICE f="Janice073"]
[OnName num="janice"]
不，......，似乎没有这样的事情。"
[cpg cn=true]


我知道一切，但我保持沉默。
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Arsha093"]
[OnName num="asha"]
'你怎么想的，Renji？　我想知道我是否被某种鬼魂附身了'。
[cpg cn=true]


[OnName num="renzi"]
来吧，来吧。"
[cpg cn=true]


说得真好，但事实是，我知道这一切。
[cpg]


[OnName num="renzi"]
'更重要的是，我的转变，我开始理解法律了。
[cpg cn=true]


我说这话是为了岔开话题。
[cpg]



;//ヒロイン３ルートの可能性が残る

[jump target="*select02_3"]

;//==============================
;//２、果物　４、ミント　のいずれかを外した場合
*select02_1|変身の法則


我不能清楚地记得，我花了很长时间才转变。
[cpg]


我本可以早一点迅速转变。我是否缺少一些改造的信息？
[cpg]


无论如何，我已经筋疲力尽了，当改造成功时，我已经没有精力去对珍妮丝本人进行恶作剧了。
[cpg]


我别无选择，只能以珍妮丝的形式入睡。......
[cpg]




;//ブラックアウト

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[BGM f="02"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=800]

而在第二天。我在食堂遇到了珍妮丝和阿莎。
[cpg]


我已经意识到这次的事情，并决定告诉他们俩。
[cpg]


[OnName num="renzi"]
'我能说句话吗？关于我的转变，我已经想好了法子'。
[cpg cn=true]



;//ヒロイン３ルートの可能性がなくなる


[stflag Cha3flg = -1]


;//==============================

*select02_3|変身の法則



[FACE method="change_1" pos="4/5"]
[VOICE f="Arsha094"]
[OnName num="asha"]
'我明白了。仔细想想，有些东西你是不能变成的'。
[cpg cn=true]


[OnName num="renzi"]
'哦。阿莎以前就能让我变身，现在我知道为什么了。
[cpg cn=true]


而如果我的假设是正确的，这将解释为什么我能够转化为无机物。
[cpg]


[OnName num="renzi"]
'如果仅仅是我可以转化为类似机器的东西或类似的东西，那么我可以转化为阿莎就很奇怪了。
[cpg cn=true]


[OnName num="renzi"]
'我想也许是因为我是一只野兽，但我不能变成另一只野兽......，所以我想这有什么区别。
[cpg cn=true]


[OnName num="renzi"]
'我也不认为这是一条可以划定的界限，仅仅因为我在某种程度上了解阿莎。
[cpg cn=true]


他们点头，听我说。而我讲了他们的结论。
[cpg]


[OnName num="renzi"]
'也许是气味的缘故。我们第一次见面时，阿莎有一种气味，而无机物外观的恶魔从一开始就没有气味。
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Arsha095"]
[OnName num="asha"]
'呐，我明白了。......？　这怎么可能呢？"
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Janice074"]
[OnName num="janice"]
'我还听说，每个变形金刚都有不同的情况，在这些情况下他们可以变形。这是有可能的。"
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Arsha096"]
[OnName num="asha"]
'但是没有办法确定。我们永远不会知道它是真的还是假的。"
[cpg cn=true]


[OnName num="renzi"]
'不，我们可以确定。你所要做的就是闻一闻其他恶魔的味道'。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]
[FO pos="4/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

所以我嗅到了各种恶魔。
[cpg]


我一直打扮成粘液，以免让他们感到惊恐。
[cpg]


如果我打扮成阿莎或珍妮丝那样做，他们会认为我是个变态，而且会惹恼他。
[cpg]


即使在我的粘液状态下，我也有嗅觉。更重要的是，当我是一个戈隆人时，我就有了它。
[cpg]


我想这是我可以做的事情，从我的能力倒推。
[cpg]


如果我不能从我的第一形态中闻到气味，我就不能转变为任何东西。
[cpg]

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

[OnName num="goblins"]
'......?　这些粘液是怎么回事，它变得非常接近。"
[cpg cn=true]


[OnName num="orc"]
我想他在闻你。"
[cpg cn=true]


[OnName num="goblins"]
'不要令人毛骨悚然。这样做有什么意义？
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





然后我回到我的房间，试图变成一个小妖精。
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_09_0 ***********************
;//カットイン
[CUTIN f="ci_09_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


[OnName num="renzi"]
我可以......."
[cpg cn=true]


我的假说是正确的。我现在可以变成一个妖精了。......
[cpg]


我不能这样做。我需要学会闻到更多的恶魔。
[cpg]


我可以做的恶作剧的范围即将扩大，我幸灾乐祸地想。
[cpg]

[CUTIN f="ci_09_0.ui" show={false} method="slideout"]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





所以，我通常会把自己伪装成粘液或果冻，重复接近恶魔和学习他们气味的日子。结果是：......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[BGM f="08"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


[SE f=se017]
;//【ＳＥ】『竜の唸り』

;**【ＣＧ】ci_10_0 ***********************
;//カットイン
[CUTIN f="ci_10_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]


我甚至可以变成一条巨龙。
[cpg]

[CUTIN f="ci_10_0.ui" show={false} method="feadout"]
[WAIT time=1000]

[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/5" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="4/5" time=800]

[OnName num="rudolf"]
'这很精彩，不是吗？
[cpg cn=true]



[VOICE f="Dorothy048"]
[OnName num="dorothy"]
'是啊，这不是很好吗......，比你原来的身高还要大......？
[cpg cn=true]


[OnName num="rudolf"]
'我只能用魔法来形容它。我也很好奇它的重量是多少。
[cpg cn=true]


的确如此。如果它比原来的重量更重，无论你怎么说它的魔力，它似乎都不会加起来。
[cpg]


但是否有召唤魔法这种东西？我想知道在这个世界上是否没有。
[cpg]


[OnName num="renzi"]
谢谢你。"
[cpg cn=true]


当然，还有那条龙是转化的来源，所以你不能转化成你没有的东西。
[cpg]


[FACE method="change_1" pos="2/5"]
[VOICE f="Janice075"]
[OnName num="janice"]
现在，如果它能喷火，那就没什么可说的了。......
[cpg cn=true]


[OnName num="renzi"]
'那是不可能的。'这就是发生在翁丁身上的事情。
[cpg cn=true]


[OnName num="rudolf"]
'那是一种伟大的力量，然后。我们也将在这样的假设下运作，即你可以转变为你想要的任何东西'。
[cpg cn=true]


[OnName num="rudolf"]
'我对你寄予厚望，多萝西也是如此。我希望你能挥洒你的力量。"
[cpg cn=true]


在被表扬的时候，我并不觉得难受，但我心里还是有其他事情。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/5" time=800]

[VOICE f="Janice076"]
[OnName num="janice"]
'......，你只对我和魔王恭敬吗？
[cpg cn=true]


[OnName num="renzi"]
'是的。桃乐丝告诉我不要再使用敬语，所以......
[cpg cn=true]


[FACE method="change_4" pos="2/5"]

[VOICE f="Janice077"]
[OnName num="janice"]
我明白了。......"
[cpg cn=true]


珍妮丝看起来有点失望，不知道为什么。
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Dorothy049"]
[OnName num="dorothy"]
'你是否因为觉得自己被排除在外而感到沮丧？
[cpg cn=true]


[FACE method="change_5" pos="2/5"]
[VOICE f="Janice078"]
[OnName num="janice"]
'是的，不是。不，一点也不'。
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Dorothy050"]
[OnName num="dorothy"]
'Renji，你可以像平常一样和Janice说话。她似乎很孤独。
[cpg cn=true]


[FACE method="change_6" pos="2/5"]
[VOICE f="Janice079"]
[OnName num="janice"]
因此，这就是为什么你不必......。
[cpg cn=true]


我看着他们两个人互相交谈，变得有点尘土飞扬。
[cpg]


[OnName num="renzi"]
'嗯，我想我必须这样做。珍妮丝。"
[cpg cn=true]


我试图叫停她。珍妮丝感到她的表情有点软化了。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





一旦我离开多萝西和珍妮丝，卧室里就只有我一个人了。
[cpg]


我开始构思进一步的恶作剧。例如，我现在可以变身为一个虫妖。
[cpg]


据说虫妖是没有智慧的，所以如果他们攻击一个女孩，他们不会知道是我。
[cpg]


但如果它不聪明，它怎么能知道我将得到什么样的反击？
[cpg]


[OnName num="renzi"]
'但如果是同一个恶魔，它不会伤害我吗？......'
[cpg cn=true]


这些妇女不是纯粹主义者。我想这就是他们在这个地牢里的原因。
[cpg]


因此，也许我有点鲁莽是可以的。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************

;**【ＣＧ】ci_11_0 ***********************
;//カットイン
[CUTIN f="ci_11_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

这就是为什么我被改造成一只巨大的蜜蜂。
[cpg]

[CUTIN f="ci_11_0.ui" show={false} method="slideout"]
[WAIT time=1000]

我看到远处的桃乐丝。在这里的走廊上几乎没有行人。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Dorothy051"]
[OnName num="dorothy"]
'在这样的地方，一个昆虫妖怪......？　我想知道为什么。"
[cpg cn=true]


相反，我不知道桃乐丝怎么会在这样的地方。
[cpg]


总之，我现在的情况是，我的真实本性不会被暴露。
[cpg]



[SE f=se018]
;//【ＳＥ】『蜂の羽音』

[WAIT time=1000]


[FACE method="change_5" pos="2/3"]
[VOICE f="Dorothy052"]
[OnName num="dorothy"]
'Kya!　什么？
[cpg cn=true]

在嘈杂的环境中近距离接触，如果你有胆量，就摸一下我的身体 ......
[cpg]


多么好的想法，但转念一想，我现在不能用手，或者说不能用脚去碰它。
[cpg]


;//移植前シーンカット

[FACE method="change_3" pos="2/3"]
[VOICE f="sDorothy001"]
[OnName num="dorothy"]
'嘘，嘘！　走吧！　你明白我的语言吗！"
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





离开桃乐丝。如果她追着我，抓住我，我就不能告诉她了。
[cpg]


她当时处于混乱状态，所以我迅速离开了那里。
[cpg]



[SE f=se018]
;//【ＳＥ】『蜂の羽音』



我现在是一只蜜蜂，但我的动作很慢。我知道我不能复制这部分。
[cpg]


但这并不意味着我不能飞。这很奇怪。
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep007.ks" target="*start"]


