*start

;###################################################################
*Ep015|你的身体为你而改变。
;###################################################################
;//３、ジャニス

[SCENE id=15]


[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out" pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out" pos="3/5"]


[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]


[window target=true]


珍妮丝。我想到了她。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy447"]
[OnName num="dorothy"]
'不要闭嘴，说点什么。
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


她与多萝西关系密切。我不能直接告诉她。
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy448"]
[OnName num="dorothy"]
'你的脸......，告诉我，你对我以外的人有感情。
[cpg cn=true]


[OnName num="renzi"]
不，不。......，我不知道。"
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy449"]
[OnName num="dorothy"]
'我不知道。你不必这样回应，你可以诚实一点。
[cpg cn=true]


多萝西看起来很不高兴，但这并没有改变我内心的感受。
[cpg]


[FO pos="2/3" time=1000]

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





珍妮丝。不知何故，她对鬼魂和亡灵类型有一种弱点。
[cpg]


我还没有弄清楚原因，但她是一个值得吓唬的对手。
[cpg]


除此以外，从珍妮丝的角度来看，夺取库拉拉将是一项成就。
[cpg]


我有一种感觉，珍妮丝不会强烈拒绝，即使她做了一点鲁莽的事情。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





我意识到自己的感受，恶作剧升级了。
[cpg]


我打扮成一个木乃伊，走到珍妮丝睡觉的地方。
[cpg]


她会有什么反应？　这一定是他不擅长的事情。
[cpg]


如果他在梦游，他可能会试图认为这是一个梦。
[cpg]



[VOICE f="Janice192"]
[OnName num="janice"]
肃然起敬 ...... 肃然起敬。"
[cpg cn=true]


他在睡梦中还在呼吸。我向她靠近。
[cpg]



;//========================================
;//●ＣＧ（寝ているヒロインに近づく主人公。ヒロインは包帯で縛られていて、夢だと思い込もうとして目を閉じている）ev_45
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：包帯
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公はミイラに化けています
;//=======================================

;//*Scene039

[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_45_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1500]



[VOICE f="Janice193"]
[OnName num="janice"]
'Nn......，fu......... ugh。
[cpg cn=true]


绷带包裹着她的身体。她能够在一定程度上随意移动。
[cpg]


我认为她一直是那种恶魔。我不能做原来的恶魔不能做的事。
[cpg]


相反，有时我不能做原来的恶魔能做的事情。
[cpg]


但事实上，我可以移动她，这可能是一个基本的运动。
[cpg]


如果我用这个把他绑起来，我肯定会在他醒来时看到一些有趣的反应。
[cpg]

;**【ＣＧ】 ev_45_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice194"]
[OnName num="janice"]
'（这是什么，......？　(有人想叫醒我吗？)"
[cpg cn=true]


我在她的身体上缠上绷带，并把它绑好。
[cpg]


她叫了几声。她试图醒过来一点。
[cpg]


珍妮丝正努力把眼睛睁得更薄一些。
[cpg]


我等着她醒过来，想知道她会有什么反应。
[cpg]


像这样的时刻，是我要搞恶作剧时最有趣的时刻。
[cpg]

;**【ＣＧ】 ev_45_b ***********************
[CG id=13 index=2 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice195"]
[OnName num="janice"]
'哦，......！
[cpg cn=true]

;**【ＣＧ】 ev_45_c ***********************
[CG id=13 index=3 time=1000]
;***************************************
[WAIT time=1500]

然后珍妮丝就醒了。她立即紧闭双眼，试图再次入睡。
[cpg]


她可能认为这是个梦。当然是这样，当然应该是这样。
[cpg]


她对任何类型的鬼魂都不擅长。
[cpg]



[VOICE f="Janice196"]
[OnName num="janice"]
'（又是一个有趣的梦。......，我一定是很累了。）'
[cpg cn=true]


我不能把话说出来。我也许能做到，但那样他们就会知道是我。
[cpg]


所以我试图什么都不说就再往前走一点。
[cpg]


;//ブラックアウト


但是，似乎还是......，我真的不喜欢鬼。
[cpg]

;//移植前シーンカット


我认为珍妮丝在......，隐藏着她不能告诉我的一些过去。
[cpg]


看着她痛苦的脸，我想我不想再做什么了。
[cpg]



我在想直接离开她。
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





我这一次很满意，但我在考虑我的下一步计划。
[cpg]


她可能会在早上醒来的时候换内衣。因为他们很脏。
[cpg]


所以我又想到了一些不同的东西。
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





我决定换上她的衣服。然后我直接去睡了一晚上。
[cpg]


想象一下，当我早上醒来的时候，她可能会把它们放在我身上。......
[cpg]




[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice212"]
[OnName num="janice"]
'哼。毕竟没有睡得那么好'。
[cpg cn=true]


珍妮丝走近我，揉着她的眼睛。
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="sJanice007"]
[OnName num="janice"]
'我需要穿上衣服。......'
[cpg cn=true]


他在说这句话时试图让我上。我靠近她的身体。
[cpg]


现在我可以一直呆在她身边了。在我认为的同时，......。
[cpg]


他能感觉到她的体温和气味。仅这一点就使我感到高兴。
[cpg]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Janice214"]
[OnName num="janice"]
'早上好。妖王大人，公主大人'。
[cpg cn=true]


[OnName num="rudolf"]
'哦。'早上好。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Dorothy450"]
[OnName num="dorothy"]
'早上好。你看起来今天没有睡好'。
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Janice215"]
[OnName num="janice"]
是的。......，我做了一个最奇怪的梦。"
[cpg cn=true]


珍妮丝向国王的房间走去。桃乐丝和魔王已经在这里了。
[cpg]


我可以在这里吓唬他们。我就是这么想的，而且我还和她保持着密切联系。......。
[cpg]


;//移植前シーンカット

;//ブラックアウト

[SE f=se012]
;//【ＳＥ】『衣擦れ』

我将布条移到我的背上，挠了挠它。
[cpg]

[FACE method="change_5"  pos="2/2"]
[VOICE f="sJanice008"]
[OnName num="janice"]
'呀！'
[cpg cn=true]

[FACE method="change_5"  pos="2/2"]
[VOICE f="sDorothy015"]
[OnName num="dorothy"]
'怎么了？　你听起来很奇怪。"
[cpg cn=true]

[FACE method="change_4"  pos="2/2"]
[VOICE f="sJanice009"]
[OnName num="janice"]
'是的，不是。这不算什么'。
[cpg cn=true]


她在被我指责的同时尽力汇报工作的方式是健康而可爱的。
[cpg]


我越来越多地爱上了珍妮丝。
[cpg]


完成白天的工作后，珍妮丝回到了她的房间。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





她脱掉衣服，或者说是我，和我说话。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Janice231"]
[OnName num="janice"]
'仁济。你是什么意思？
[cpg cn=true]


[OnName num="renzi"]
'......'
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice232"]
[OnName num="janice"]
'不要做这些事情，即使它们发生在你身上。
[cpg cn=true]


我想我不能再保持这种形式了。
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



考虑到这一点，我恢复了人形，向珍妮丝鞠了一躬。
[cpg]


[OnName num="renzi"]
「ごめん」
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice233"]
[OnName num="janice"]
'我希望你能理解。'因为如果你再这样做，我就会非常生气。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





我并不沮丧，我在想我接下来要做什么。
[cpg]


她也会害怕僵尸的东西吗？　如果是这样，我也想试试。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha225"]
[OnName num="asha"]
'你看起来很糟糕，Renji'。
[cpg cn=true]


当我们在工作时，阿莎正过来找我们。
[cpg]


[OnName num="renzi"]
'我不这么认为，'她说。你明白吗？
[cpg cn=true]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Arsha226"]
[OnName num="asha"]
'我可以看到。你最近经常和珍妮丝在一起'。
[cpg cn=true]


[OnName num="renzi"]
'...... 明白吗？
[cpg cn=true]


阿莎咯咯笑了起来，继续工作。
[cpg]


我想知道珍妮丝是否意识到了这一点。那就是她是唯一受到特别威胁的人。......。
[cpg]


如果他们意识到我为什么这么做，他们就会知道我是在帮他们的忙。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





总之，我是想变成一个僵尸。当然，要变成僵尸，你必须知道它是什么味道。
[cpg]


我不想知道这种东西的味道......，所以我决定再次变成鬼。
[cpg]


我可以变身，所以我不需要一开始就做鬼。我在过道上变身为其他东西，一边模仿一边等待，然后她就来了。
[cpg]


我可以变形，所以我不需要一开始就成为一个僵尸。我在过道上变身为类似戈壁的东西，一边模仿一边等待，然后她就来了。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Janice234"]
[OnName num="janice"]
'哇！'
[cpg cn=true]


珍妮丝每次都有一个可爱的反应。但......，很快就意识到是我，并瞪了我一眼。
[cpg]

[FACE method="change_4"  pos="2/3"]
[VOICE f="sJanice010"]
[OnName num="janice"]
'...... Renji, huh?够了。"
[cpg cn=true]



;//【ＢＧ】『ダンジョン＿通路』（暗い）

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



我变回了人形。然后我当面向他道歉。
[cpg]


[OnName num="renzi"]
'我很抱歉。请不要告诉魔王'。
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice255"]
[OnName num="janice"]
'有一天，你只是在道歉。你不会真的认为我不会再这样做吧。
[cpg cn=true]


珍妮丝看起来很生气，但她的脸有点红，而且不知为何她没有直视我们。
[cpg]


有一丝迹象表明她不太对劲。我甚至不知道为什么。......
[cpg]


但这样也许就可以问了。
[cpg]


[OnName num="renzi"]
'......，我也想听听你的意见。为什么珍妮丝不是真的、真的讨厌它呢？"
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice256"]
[OnName num="janice"]
嗯，那是......' 
[cpg cn=true]


珍妮丝公然心慌意乱。
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice257"]
[OnName num="janice"]
'你就是那个......，抓住了克拉拉。此外，你还帮助了负责种植的人'。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice258"]
[OnName num="janice"]
'我确实很感激。这就是为什么我很难拒绝'。
[cpg cn=true]


她说这话的方式有一些特点，不仅仅是她很感激，而且她听起来像一个恋爱中的少女。
[cpg]


与其说是忏悔的正确时间，不如说是忏悔的正确时机。但我认为至少暗示一下我的感受是可以的。
[cpg]


[OnName num="renzi"]
我爱上了珍妮丝。
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice259"]
[OnName num="janice"]
'不要说了。我不想再听了'。
[cpg cn=true]


但在那一刻，珍妮丝的脸色很严峻。
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice260"]
[OnName num="janice"]
'我有比这些事情更重要的事情要处理。
[cpg cn=true]


[OnName num="renzi"]
'......，有什么事情需要我去处理的？
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice261"]
[OnName num="janice"]
'我不能随便谈论它。我可能在我的余生都不会和你谈起这个问题'。
[cpg cn=true]



[SE f=se009]
;//【ＳＥ】『歩く』

[FO pos="2/3" time=1500]
[WAIT time=1500]
;//ブラックアウト



最后，当时并非一切都很清楚。
[cpg]


我很饿，所以我自己去了食堂。
[cpg]

[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************




[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Dorothy454"]
[OnName num="dorothy"]
'啊，Renji。在这里，在这里'。
[cpg cn=true]


多萝西和阿莎在食堂里聊天。
[cpg]


[FACE method="change_7"  pos="1/2"]
[VOICE f="Arsha227"]
[OnName num="asha"]
'从那时起，你和珍妮丝的关系怎么样了？
[cpg cn=true]


阿莎直截了当地问了这样一个问题。
[cpg]


[OnName num="renzi"]
'我有点觉得我被轻率地抛弃了。
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]

[VOICE f="Arsha228"]
[OnName num="asha"]
'我明白了。我想珍妮丝终究还是不喜欢。
[cpg cn=true]


[FACE method="change_1"  pos="2/2"]
[VOICE f="Dorothy455"]
[OnName num="dorothy"]
'是的，什么？　你忏悔了吗？　我的珍妮丝。"
[cpg cn=true]


我被 "我的珍妮丝 "那段话吸引住了。
[cpg]


[OnName num="renzi"]
'但我并没有放弃。我还没有被适当地甩掉'。
[cpg cn=true]


他重新下了决心。我仍然不会停止对她的戏弄。
[cpg]


[OnName num="renzi"]
如果你说你和珍妮丝合得来，那么多萝西也是如此。
[cpg cn=true]

[FACE method="change_7"  pos="2/3"]
[VOICE f="Dorothy457"]
[OnName num="dorothy"]
'嗯，那是我和珍妮丝。而且我们远远领先于仁济。
[cpg cn=true]


[OnName num="renzi"]
'提前了？
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy458"]
[OnName num="dorothy"]
无论如何，Renji甚至还没有吻过她。
[cpg cn=true]

那是什么意思。你正在做。
[cpg]

不，是不发生的故事......？　桃乐丝和珍妮丝的位置很接近，如果她们在这样的地牢里一起生活了很长时间。
[cpg]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Dorothy459"]
[OnName num="dorothy"]
总之，我不会把珍妮丝交给仁济。"
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


当我听到这句话时，在我还没有考虑放弃或不放弃的时候，我想，这可能会成功。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



;//ここからしばらく、ドロシーのセリフ名前欄を「ドロシー（蓮司）」と置き換えてください





那天我是乔装打扮的桃乐丝。
[cpg]


[FG f="CHA02_p4_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Dorothy460"]
[OnName num="renzi_to_dorothy"]
'珍妮丝。你睡着了吗？"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Janice285"]
[OnName num="janice"]
'...... 不。这么晚了，你在这里做什么？"
[cpg cn=true]


珍妮丝和多萝西是好朋友。如果我尝试以这种形式与她进行皮肤接触，他们不会介意。
[cpg]


[FACE method="change_7"  pos="2/2"]
[VOICE f="Dorothy461"]
[OnName num="renzi_to_dorothy"]
'我只是想知道她现在是否会感到孤独。
[cpg cn=true]


我说的都是真实的，也是不真实的。如果我不这么虚张声势，就会被发现。
[cpg]


[FACE method="change_6"  pos="1/2"]
[VOICE f="sJanice011"]
[OnName num="janice"]
'是的，这就对了。你上次来这里是......，半个月前？
[cpg cn=true]


半个月。你清楚地记得。
[cpg]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy462"]
[OnName num="renzi_to_dorothy"]
'我也想你。嘿，珍妮丝，来吧。"
[cpg cn=true]


[FACE method="change_2"  pos="1/2"]
[VOICE f="Janice287"]
[OnName num="janice"]
'...... 是的。我是，只要公主希望我是。
[cpg cn=true]


珍妮丝热情地看着她。
[cpg]

[move from="2/2" to="2/3" ease="easeInOutSine" time=2000]


我想知道这两个人有什么样的关系，但我还是走近了。
[cpg]

;//移植前シーンカット

我抚摸着她的头发，她并不介意。
[cpg]


[FACE method="change_1"  pos="2/3"]
[FACE method="change_1"  pos="1/2"]

[VOICE f="Janice300"]
[OnName num="janice"]
'......，你今天很有攻击性，公主。
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Dorothy472"]
[OnName num="renzi_to_dorothy"]
'真的吗？　像往常一样。"
[cpg cn=true]


如果我们再谈下去，可能会暴露我们的真实身份。
[cpg]


我还不如把我想从珍妮丝那里听到的东西说出来。
[cpg]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Dorothy473"]
[OnName num="renzi_to_dorothy"]
'嘿，珍妮丝。你对仁济有什么看法？"
[cpg cn=true]


[FACE method="change_7"  pos="1/2"]
[VOICE f="Janice301"]
[OnName num="janice"]
'怎么了，突然......'
[cpg cn=true]


珍妮丝有点脸红。然后她把目光移开。
[cpg]


[FACE method="change_1"  pos="1/2"]
[VOICE f="Janice302"]
[OnName num="janice"]
'我不是不喜欢他，但......，我现在有其他事情要关注。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy474"]
[OnName num="renzi_to_dorothy"]
'你想关注的是什么？
[cpg cn=true]


[FACE method="change_3"  pos="1/2"]
[VOICE f="Janice303"]
[OnName num="janice"]
'你知道的，公主。这是对人类的报复。"
[cpg cn=true]


复仇。好吧，我相信有很多你想报仇的复仇者。
[cpg]


不过，这并不只是一个有战友被杀的表情。
[cpg]


这更像是一种悲伤、遗憾的表情。
[cpg]



;//ここからドロシーのセリフ名前欄を元に戻してください



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





珍妮丝说，她毕竟不恨我。她说这话的方式也有一些发人深省的地方。
[cpg]


她还说她想集中精力为人类报仇，但我不知道她为什么如此痴迷。
[cpg]


即便如此，珍妮丝对人类的迷恋似乎也相当强烈。
[cpg]


她似乎认为她将不惜一切代价赢得这场战斗，而且她可能有无法以其他方式澄清的感情。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[SE f=se008]
;//【ＳＥ】『喧噪』


第二天早上。我带着一种有些朦胧的感觉去了食堂。
[cpg]


我不再伪装成桃乐丝了。她是人形。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha229"]
[OnName num="asha"]
早上好，Renji。
[cpg cn=true]


[OnName num="renzi"]
'早上好。你今天有什么建议？
[cpg cn=true]


与阿莎互致问候。但我感觉有点模糊。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="5/3" time=800]


即使我把食物搬到我的办公桌上，我也不觉得很有胃口。
[cpg]

[move from="2/3" to="1/2" ease="easeInOutSine" time=2000]
[move from="5/3" to="2/2" ease="easeInOutSine" time=2000]


[VOICE f="Janice304"]
[OnName num="janice"]
'你看起来很有活力。
[cpg cn=true]


[OnName num="renzi"]
'早上好......，没有什么异常。
[cpg cn=true]


然后珍妮丝出现了。找到她足以让你的心跳动起来。
[cpg]


这不仅仅是快乐的问题。这是一种强烈的紧迫感，要做一些事情。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





晚餐后，我在想如何接近珍妮丝。
[cpg]


当我变成一条浴巾时，她并没有那么介意。这种恶作剧似乎是个好主意。
[cpg]


她对鬼魂之类的东西很弱，但我想知道她对被吓得像个惊喜盒子一样的情况是否也很弱。
[cpg]


我不介意试一试。所以我决定变成一个模仿者。
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Janice305"]
[OnName num="janice"]
'什么......？　在这样一个地方，一个盒子？"
[cpg cn=true]


珍妮丝是警觉型的。如果它看起来像一个普通的宝箱，她可能不会打开它。
[cpg]


当我怀着这种心情等待时，珍妮丝走了过来。
[cpg]


她认真地看着我。只要我伪装成一个模仿者，最好在她打开后吓唬她。......
[cpg]


珍妮丝正准备离开现场。我有点飞了，但我决定自己打开盒子，吓吓她。
[cpg]

;//移植前シーンカット
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]


然后珍妮丝一脸清醒地看着我。
[cpg]


[BG f="b_04_5.ui" time=1000]
[WAIT time=1500]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sJanice012"]
[OnName num="janice"]
'仁济。你到底要转多少次？
[cpg cn=true]



[OnName num="renzi"]
'哦，我很抱歉，'她说。我不会再这样做了'。
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice328"]
[OnName num="janice"]
'我已经说过很多次了。我想这意味着恋次可以在任何地方攻击我。
[cpg cn=true]


珍妮丝盯着我的样子，我有一种感觉，她是一个典型的过去的士兵。
[cpg]


感觉到我有危险，我就跑开了。
[cpg]

[SE f=se010]
;//【ＳＥ】『走る』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





当然，我能够坚持跑步的时间是有限制的。我变成了一个小妖精，与周围的环境融为一体。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/2" time=800]

[VOICE f="Arsha230"]
[OnName num="asha"]
'你的血怎么了？　珍妮丝。"
[cpg cn=true]


[FACE method="change_1"  pos="2/2"]
[VOICE f="Janice329"]
[OnName num="janice"]
'刚才有人来过这里吗？
[cpg cn=true]


[FACE method="change_1"  pos="1/2"]
[VOICE f="Arsha231"]
[OnName num="asha"]
我当时想，"嗯。饭堂是如此的进进出出。"
[cpg cn=true]


珍妮丝环顾了一下食堂，不知为何径直朝我走来。
[cpg]

[FO pos="2/2" time=800]

[FG f="CHA03_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Janice330"]
[OnName num="janice"]
'是你吗？
[cpg cn=true]


[OnName num="renzi"]
'你到底是怎么知道的？
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice331"]
[OnName num="janice"]
'没有食物，没有空碗。你被塞住了，Renji'。
[cpg cn=true]


她抓住我的胳膊，把我拖走。
[cpg]

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





然后她把我带到了她的房间。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sJanice013"]
[OnName num="janice"]
'我必须做什么才能让你停下来？　告诉我是什么惩罚。"
[cpg cn=true]


[OnName num="renzi"]
嘿，什么......"
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="sJanice014"]
[OnName num="janice"]
'回答我这个问题。否则，我将以我认为合适的方式惩罚你。
[cpg cn=true]

它是如此强大，以至于我不得不断然道歉。
[cpg]


;//移植前シーンカット


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sJanice015"]
[OnName num="janice"]
'......，如果你感到抱歉，不要再为我做任何额外的事情。
[cpg cn=true]

我太害怕了，不敢回答，但...
[cpg]



[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice358"]
[OnName num="janice"]
'你有回音吗？
[cpg cn=true]


[OnName num="renzi"]
'是的。......，我不会再这样做了。
[cpg cn=true]


当她这样说时，我别无选择，只能回答。
[cpg]




;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



然后，第二天早上发生了。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy475"]
[OnName num="dorothy"]
'恋次！　嘿，来这里。"
[cpg cn=true]


[OnName num="renzi"]
什么？"
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Dorothy476"]
[OnName num="dorothy"]
嗯？"　不，我没有!　我忘了我做了什么。"
[cpg cn=true]


多萝西看起来也很生气。我不记得她了，我在颤抖，想起了更多关于昨天的事情。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



我被带到了国王的房间。妖王不在，所以只有我和多萝西。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy477"]
[OnName num="dorothy"]
'珍妮丝说了一些疯狂的话，我很惊讶。她一定是在没有告诉我的情况下成为了一个怪物。
[cpg cn=true]


[OnName num="renzi"]
哦，啊......"
[cpg cn=true]


仔细想想，这当然不是冒犯的理由。
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy478"]
[OnName num="dorothy"]
'这并不重要。无论你如何接近Janice。不过我很嫉妒'。
[cpg cn=true]


[OnName num="renzi"]
对不起。"
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Dorothy479"]
[OnName num="dorothy"]
'不，这不是我想让你道歉的事。我希望你能更正确地面对珍妮丝。"
[cpg cn=true]


我不知道多萝西在说什么，所以我反问她。
[cpg]



[OnName num="renzi"]
'......，这是什么意思？
[cpg cn=true]



[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy480"]
[OnName num="dorothy"]
'Renji，你知道为什么Janice对鬼魂的态度这么差吗？
[cpg cn=true]


[OnName num="renzi"]
'不，我不知道。
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy481"]
[OnName num="dorothy"]
'我想是这样的。你没有直接问我，因为你在伪装中与我如此接近'。
[cpg cn=true]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//色調をセピアにしてください



根据。在我来到这个世界之前。
[cpg]




[window target=false]

[STOPBGM]

[FACE method="feadin_up" pos="4/7"]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（暗い）******************************************************





曾经有一段时间，人类和恶魔的冲突比现在更强烈。
[cpg]


发生了一场大的冲突。那是珍妮丝的哥哥在战斗中被杀的地方。
[cpg]


她说她仍然梦想着她的兄弟。
[cpg]



;//色調を戻してください


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[OnName num="renzi"]
...... Janice有一个兄弟？"
[cpg cn=true]


原因比我想象的更严重。我很抱歉直到现在还把你吓跑了。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy482"]
[OnName num="dorothy"]
如果Renji想让Janice开心，他必须做点什么。
[cpg cn=true]


[OnName num="renzi"]
当我说我会做些什么时，我的意思是我将......。
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Dorothy483"]
[OnName num="dorothy"]
'哦，上帝啊!　如果你要这么胡搅蛮缠，那就把珍妮丝还给我。"
[cpg cn=true]


桃乐丝说得很有道理。我爱上了珍妮丝，所以这是我必须要理清的事情。
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy484"]
[OnName num="dorothy"]
'无论如何，我已经说了我要讲的一切。剩下的就看仁济了。
[cpg cn=true]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





由我来决定。我想这正是它将是的，我可以想她多少。
[cpg]


我先去了克拉拉家。她仍然被软禁在地牢里。
[cpg]

[BG f="b_04_5_up.ui" time=1000]
[FACE method="feadin_up" pos="4/7"]
[WAIT time=1500]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clara533"]
[OnName num="clara"]
'这么久了，你想从我这里得到什么？
[cpg cn=true]


[OnName num="renzi"]
'我需要检查一些东西。库拉拉曾与龙族作战吗？
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Clara534"]
[OnName num="clara"]
'龙裔？　我听说他们在恶魔的干部中，但我不认识他们。"
[cpg cn=true]


一个恶魔干部将是珍妮丝。所以不是库拉拉杀了她哥哥。
[cpg]


我有点松了一口气。如果库拉拉是与她有联系的人，珍妮丝就不会放过他。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





但当我想到这一点时，我不确定我是否应该报复。
[cpg]


这感觉有些不同。如果你只是说你要解决一个怨恨，就不会有什么结果。
[cpg]


我不希望珍妮丝因为报复而被别人怨恨。
[cpg]


如果是这样的话，我最好想一个办法来治愈珍妮丝的伤口。......
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Janice359"]
[OnName num="janice"]
'你在喃喃自语什么呢？
[cpg cn=true]


[OnName num="renzi"]
哦，不，......，这没什么。"
[cpg cn=true]


当珍妮丝本人出现时，我意识到我在自言自语。
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice360"]
[OnName num="janice"]
'如果没什么，那就好。你最近没有对我做什么。
[cpg cn=true]


她说完这句话，面对我坐了下来。
[cpg]


这并不是说她不喜欢我。这并不是说她不讨厌我到目前为止所做的事情。
[cpg]


也就是说，如果我现在向她表白，会得到什么样的回应？
[cpg]


从这个角度来看，我在解决问题的顺序上不应该犯错。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





我决定四处打听曾经和珍妮丝一起战斗过的朋友的见证。
[cpg]


在这样做的过程中，出现了珍妮丝的哥哥是什么样的人的画面。
[cpg]


[OnName num="dragonewt_A"]
'塞西尔太勇敢了。除此之外，他还在最后为杰尼斯先生辩护'。
[cpg cn=true]


[OnName num="dragonewt_B"]
'嗯，我当时看不出来，因为他们是...... 姐妹和兄弟，他们是如此接近。
[cpg cn=true]


珍妮丝的哥哥显然叫塞西尔。
[cpg]


我详细询问了他们的性格和他们的说话方式。而这仅仅是个开始。
[cpg]


我在想一个计划。只有我才能做到的事。
[cpg]


[OnName num="renzi"]
我在想一个策略，一个只有我才能做的事情。任何关于塞西尔的纪念品都可以。
[cpg cn=true]


[OnName num="dragonewt_A"]
我想只有珍妮丝有这样的东西。"
[cpg cn=true]


[OnName num="dragonewt_B"]
'不，我有。我有一个他曾经戴过的护身符。
[cpg cn=true]


[OnName num="renzi"]
'如果你愿意，你可以把它借给我。我不会要求你把它送出去。
[cpg cn=true]


[OnName num="dragonewt_B"]
但你会用它来做什么呢？"
[cpg cn=true]


哦，不，这很明显。这是为了转变为塞西尔。
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





护身符上有一股淡淡的别人的气味。
[cpg]


当我不断地把自己改造成变形金刚时，这种改造也越来越灵活。
[cpg]


我认为我能够根据最微弱的线索，完全像......。
[cpg]


[OnName num="renzi"]
'它看起来怎么样？　他是否适当地转变为塞西尔？"
[cpg cn=true]


[OnName num="dragonewt_A"]
是的，......，他们很适合彼此。"
[cpg cn=true]


[OnName num="dragonewt_B"]
'变形金刚是很方便的东西。你能变身为死者的样子吗？
[cpg cn=true]


[OnName num="renzi"]
在我亲自尝试之前，我不知道会有什么期望，......，但它看起来会有效果。"
[cpg cn=true]


[FACE method="slidein" pos="4/7"]

[WAIT time=1500]
;//ブラックアウト





该战略是这样的。我把自己伪装成塞西尔，接近熟睡中的珍妮丝。
[cpg]


我把她叫醒，假装是塞西尔，以解除她的创伤。不过，这真是一个不能轻易用一个词来概括的故事。
[cpg]


我担心的是，正在睡觉的珍妮丝可能会醒过来，然后来找我。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





所以我决定也要争取幽灵部落的帮助。
[cpg]


[OnName num="renzi"]
'谢谢你的合作。这很有帮助'。
[cpg cn=true]


[OnName num="ghost"]
'不，不。我们也被挡在她面前很长时间了，所以我们......，欠她很多。
[cpg cn=true]


[OnName num="renzi"]
'我们能不能把珍妮丝卡住的事情做完？
[cpg cn=true]


[OnName num="ghost"]
这是件小事。
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="feadin_up" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


因此，在手术的当天。
[cpg]

;**【ＣＧ】ci_20_0 ***********************
;//カットイン
[CUTIN f="ci_20_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

当她睡着时，我把自己伪装成塞西尔。
[cpg]



;//[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Janice361"]
[OnName num="janice"]
嗯。......."
[cpg cn=true]


呼唤珍妮丝，叫醒她。
[cpg]


[OnName num="renzi"]
'妹子。醒来吧，姐姐'。
[cpg cn=true]


Cecile显然称Janice为她的妹妹。我们已经对这一领域进行了调查。
[cpg]

[CUTIN f="ci_20_0.ui" show={false} method="slideout"]
[WAIT time=1000]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice362"]
[OnName num="janice"]
'......，又是这个梦？
[cpg cn=true]


珍妮丝看到我时闭上了眼睛。从她的反应来看，她肯定多次梦到过塞西尔。
[cpg]


[OnName num="renzi"]
'我不再梦见自己了。这是最后一次'。
[cpg cn=true]


珍妮丝没有回答。她的眼睛紧紧闭着，仿佛她相信这是一场噩梦。
[cpg]


[OnName num="renzi"]
'谢谢你所做的一切，姐姐。这些年你一直在为我而战'。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice363"]
[OnName num="janice"]
'难怪......，你为保卫我而死。你说你一直讨厌我'。
[cpg cn=true]


我有这样的梦想。她似乎有一种强烈的责任感。
[cpg]


[OnName num="renzi"]
'但这就够了。我收回我所说的一切。
[cpg cn=true]


[OnName num="renzi"]
'我已经很高兴了。你找到了你妹妹的幸福'。
[cpg cn=true]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Janice364"]
[OnName num="janice"]
'......，你今天表现得非常好。我不能相信我做了这个梦。"
[cpg cn=true]


我离开房间。珍妮丝没有跟随。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





[OnName num="ghost"]
'...... 进展顺利吗？
[cpg cn=true]


[OnName num="renzi"]
'不，我也不知道。我想这件事只能继续下去，直到她被说服。
[cpg cn=true]


在这一点上，我已经做好了长期的准备。但第二天。
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[OnName num="renzi"]
'早上好，珍妮丝。
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Janice365"]
[OnName num="janice"]
'哦。怜子，早上好'。
[cpg cn=true]


珍妮丝的表情很不寻常。它几乎是没有表情的，但又有点柔和。
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice366"]
[OnName num="janice"]
'我做了一个梦。一个关于我弟弟的梦'。
[cpg cn=true]


[OnName num="renzi"]
'对。你梦到了什么？
[cpg cn=true]


我听着他的话，尽量不生气。
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice367"]
[OnName num="janice"]
'自从我哥哥死后，我的梦就一直是噩梦。
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Janice368"]
[OnName num="janice"]
'他们一直在说咒骂我的话。我知道这是我的想象，但确实如此。但昨天晚上的梦是不同的。"
[cpg cn=true]


珍妮丝在说这句话的时候，看起来好像迷失了方向。
[cpg]


[OnName num="renzi"]
'那就好，我很高兴。我认为塞西尔也不会对我有意见。"
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice369"]
[OnName num="janice"]
'...... 你怎么知道我的名字？
[cpg cn=true]


[OnName num="renzi"]
哦，不，这没什么。"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



最后，真相没有被珍妮丝发现。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice370"]
[OnName num="janice"]
'今天有一个守卫发烧了,...... Renji，你能代替他吗？'我陪你一起去。
[cpg cn=true]


[OnName num="renzi"]
'哦。当然'。
[cpg cn=true]


我已经很久没有做过望风的工作了。
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_22_0 ***********************
;//カットイン
[CUTIN f="ci_22_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

我决定把自己伪装成一个巨魔，一个更大的恶魔，至少在外表上看起来很强大。
[cpg]

[CUTIN f="ci_22_0.ui" show={false} method="slideout"]
[WAIT time=1000]

我还看了一会儿这段话。我和珍妮丝单独在一起。
[cpg]



[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice371"]
[OnName num="janice"]
'嘿，Renji。为什么我做了那个梦？
[cpg cn=true]


[OnName num="renzi"]
'......，来吧。也许真的是塞西尔的灵魂在这么想。
[cpg cn=true]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Janice372"]
[OnName num="janice"]
'我怀疑。'我想，梦是最深刻的心理表现。如果是这样，也许我想原谅我'。
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice373"]
[OnName num="janice"]
我正在思考其中的原因，这时我想起了......"。
[cpg cn=true]


[OnName num="renzi"]
'为什么？　这与我没有关系。"
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice374"]
[OnName num="janice"]
'这的确很重要。我应该追求我的幸福，塞西尔说。我想要的幸福是一件事了'。
[cpg cn=true]


珍妮丝说这话时脸有点红。
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice375"]
[OnName num="janice"]
'嘿，Renji。你觉得我怎么样？　这段时间以来，你怎么会对我这么上心？"
[cpg cn=true]


等待着我的话语。我明白这一点。
[cpg]


我又不会让珍妮丝告诉我。如果我的态度再暧昧一点，就可能发生这种情况。
[cpg]


[OnName num="renzi"]
'珍妮丝，这是因为我喜欢她。
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Janice376"]
[OnName num="janice"]
'嗯，......，有点让我说出来了，不是吗？对不起。"
[cpg cn=true]


[OnName num="renzi"]
'不，不。我也没能告诉你。对不起'。
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice377"]
[OnName num="janice"]
'一段时间以来，我也很喜欢Renji。我开始认为他是一个勇敢的人，大约在他捕获库拉拉的时候'。
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice378"]
[OnName num="janice"]
......，在这方面有点像塞西尔。"
[cpg cn=true]


珍妮丝一定是个黑人妇女。我有点明白了。
[cpg]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;//ブラックアウト



我仍然是我的巨魔形态，就是我在执行警卫任务时变身的那个。
[cpg]


果不其然，到了我换班的时间，我和Janice一起回去了。 ......
[cpg]


我们两人都没有主动提出。但我们都不想离开对方，我们都不想放手。
[cpg]


[window target=false]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


我发现自己在珍妮丝的房间里。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sJanice016"]
[OnName num="janice"]
'我希望你和我一起呆在......。我想让你抱着我'。
[cpg cn=true]


我没有拒绝，尽管我想知道他是否有这样的侵略性。
[cpg]


回想起来，我觉得我已经催促了很久了。
[cpg]


;//========================================
;//●ＣＧ（主人公に迫るヒロイン。寝ている主人公）ev_50
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公はトロールに化けています
;//=======================================


[SE f=se012]
;//【ＳＥ】『衣擦れ』

;//*Scene046
[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="10"]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1500]






[VOICE f="sJanice017"]
[OnName num="janice"]
'......，又被人这么认真地看了，真不好意思。
[cpg cn=true]


她对这种近距离的接触感到有些尴尬。但她看起来并不反感。
[cpg]


[OnName num="renzi"]
'你看起来很美，珍妮丝。你是世界上最美丽的女人'。
[cpg cn=true]


这句话来得很快。它们是没有任何夸张的话语。
[cpg]


但珍妮丝看开了。
[cpg]

;**【ＣＧ】 ev_50_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice381"]
[OnName num="janice"]
'很美，不是吗？我有一个外貌情结'。
[cpg cn=true]



[OnName num="renzi"]
'不要有这种感觉。
[cpg cn=true]



我抚摸着她的头发。我喜欢这种距离。
[cpg]

;**【ＣＧ】 ev_50_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice401"]
[OnName num="janice"]
'我爱。恋次，也要多爱我。
[cpg cn=true]


[OnName num="renzi"]
「ああ。もちろん」
[cpg cn=true]


你要求我爱你，我就不能不爱你。
[cpg]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





那一天，我们俩都睡在同一张床上。
[cpg]


感受她的体温是一种难以言喻的充实体验。
[cpg]




[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************




从那天起，珍妮丝对我的态度大为改变。
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Janice426"]
[OnName num="janice"]
'我可以坐在你旁边吗？
[cpg cn=true]


[OnName num="renzi"]
呃--哦。"
[cpg cn=true]


他们不是面对面，而是挨在一起。尽管多萝西就在我旁边。
[cpg]


多萝西看着我，而不是珍妮丝，她的眼神很犀利。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Dorothy485"]
[OnName num="dorothy"]
'哦，不。你已经被抢劫了。
[cpg cn=true]


[OnName num="renzi"]
'不要做一个假正经的人。
[cpg cn=true]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy486"]
[OnName num="dorothy"]
'当时只有我和珍妮丝，你知道。好吧，我希望珍妮丝能接受。"
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Janice427"]
[OnName num="janice"]
'...... 抱歉。
[cpg cn=true]


[FACE method="change_1"  pos="2/2"]
[VOICE f="Dorothy487"]
[OnName num="dorothy"]
'这是真的。我只是珍妮丝的一个游戏，不是吗？
[cpg cn=true]


多萝西发誓，但这句话也不觉得是真的。
[cpg]


这就像多萝西的感情流露出来一样，好像她不能直接祝贺他。
[cpg]


珍妮丝也拿着它，显得很尴尬。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





经过一天的工作，我们更经常地睡在同一个房间里。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice428"]
[OnName num="janice"]
'关于克拉拉，有一个让她离开的行动。
[cpg cn=true]


[OnName num="renzi"]
'我明白了。这是否意味着你要做某种交易？
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice429"]
[OnName num="janice"]
'哦。也许会达成停火。巫后正在推动此事。"
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice430"]
[OnName num="janice"]
'我本来是讨厌它的，从前是这样。我本想为他彻底报仇。"
[cpg cn=true]


[OnName num="renzi"]
现在怎么样？"
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice431"]
[OnName num="janice"]
'...... 奇怪的是，我比较平静。塞西尔并不记恨我。我应该意识到这一点。"
[cpg cn=true]


;//ブラックアウト




塞西尔对珍妮丝并不怀恨在心。珍妮丝自己在某些时候也这么认为。
[cpg]


珍妮丝似乎意识到，只有无法保护她的记忆在膨胀。
[cpg]


我想我可能只是最后推了她一把，但如果珍妮丝的疑虑被消除了，那也没什么。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


然后。珍妮丝和我一起过着平静的生活。
[cpg]


桃乐丝还是老样子，但我认为她开始更多地祝福我们了。
[cpg]


而阿莎从一开始就对我们给予了支持。
[cpg]


至于我，我的变形能力变得更加极端，我能够变成'不存在的东西'，或者说是'不存在的人'。
[cpg]

;**【ＣＧ】ci_21_0 ***********************
;//カットイン
[CUTIN f="ci_21_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

我可以莫名其妙地理解龙人的气味，然后我就能化身为一个无人的龙人。
[cpg]


[CUTIN f="ci_21_0.ui" show={false} method="slideout"]
[WAIT time=1000]

珍妮丝很高兴看到我的这种形式。我猜这意味着她在我们的关系中没有感到不自在。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Janice434"]
[OnName num="janice"]
'已经是早上了吗，......，我今天也要工作。
[cpg cn=true]


[OnName num="renzi"]
哦，"他说。有一个好的一天。"
[cpg cn=true]


[SE f=se009]
;//【ＳＥ】『歩く』

[FO pos="2/3" time=1000]
[WAIT time=1100]

;//ブラックアウト



珍妮丝总是很忙，作为魔王的随行人员。
[cpg]


相比之下，我还没有接到非常重要的任务。
[cpg]


我开始认为这不可能永远持续下去，所以我开始自己要求工作。
[cpg]


我一开始只是个望风者，但希望有一天我能够支持珍妮丝。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Janice435"]
[OnName num="janice"]
'释放克拉拉的安排已经到位。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy488"]
[OnName num="dorothy"]
'看来是这样。你的父亲很可爱。
[cpg cn=true]


[OnName num="renzi"]
'但这是一件好事，不是吗？它使我们离和平更近一步，不是吗？"
[cpg cn=true]


[FACE method="change_4"  pos="3/3"]
[VOICE f="Arsha232"]
[OnName num="asha"]
'是的，我想我同意你的看法。我们不能永远互相争吵。
[cpg cn=true]


每个人似乎都对这一点表示赞同。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="3/3" time=1]
[FO pos="2/3" time=1]
[FO pos="1/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





珍妮丝觉得她不再对人类怀恨在心，笑得比以前更开心。
[cpg]


下班后，更多的是我去珍妮丝的房间，珍妮丝来找我。
[cpg]


我们周围的人都知道，我们是恋人。
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





而今天，我和珍妮丝单独在一起。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice436"]
[OnName num="janice"]
'...... Renji。你穿这个很好看。"
[cpg cn=true]


[OnName num="renzi"]
哦，"他说。我也喜欢它。"
[cpg cn=true]


一个例子，一个龙人的出现，他是没有人的。在她身边，却被告知你是一个很合适的人选。
[cpg]

;//移植前シーンカット

;//ブラックアウト


明天是他们两个人的假期。出于这个原因，我们俩都依偎在一起睡觉。
[cpg]



;//========================================
;//●ＣＧロ（寝ている主人公に膝枕をするヒロイン。ベッドの上）ev_70
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公は竜人に化けています
;//=======================================

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_70_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1500]





下一次我们醒来的时候，是这样的。
[cpg]



[VOICE f="Janice458"]
[OnName num="janice"]
'早上好。你有一张可爱的睡脸'。
[cpg cn=true]


[OnName num="renzi"]
哦，......，早上好。"
[cpg cn=true]



[VOICE f="Janice459"]
[OnName num="janice"]
'我最近睡得很多，所以我下床的速度快了很多。
[cpg cn=true]


[OnName num="renzi"]
塞西尔不再做梦了？
[cpg cn=true]

;**【ＣＧ】 ev_70_a ***********************
[CG id=15 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice460"]
[OnName num="janice"]
'不，我不知道。我一直记得他临死时的表情，但......"
[cpg cn=true]



[VOICE f="Janice461"]
[OnName num="janice"]
'奇怪的是，我现在可以记住你的笑容。我想知道为什么'。
[cpg cn=true]


最重要的是。它值得我投入所有的工作。......
[cpg]


[OnName num="renzi"]
我可以睡一会儿吗？
[cpg cn=true]

;**【ＣＧ】 ev_70_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice462"]
[OnName num="janice"]
他有点像塞西尔，他对你的宠爱。
[cpg cn=true]


随着库拉拉的释放，恶魔和人类之间的冲突可能会稍稍平静下来。
[cpg]


然后我可能会有更多的时间与珍妮丝单独相处。
[cpg]


如果这没有发生，我将不惜一切代价使之发生。
[cpg]



;//ブラックアウト

[SCENE id=20]


;//ＥＮＤ　ヒロイン３ルート

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="epend.ks" target="*start"]


;//==============================
