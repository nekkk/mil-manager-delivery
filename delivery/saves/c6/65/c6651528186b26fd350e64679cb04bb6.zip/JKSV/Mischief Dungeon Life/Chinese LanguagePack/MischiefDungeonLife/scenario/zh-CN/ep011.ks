*start

;###################################################################
*Ep011|转化的广度就是祸害的广度。
;###################################################################


[SCENE id=11]


[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
[BG f="black.ui"  time=1000]
[WAIT time=100]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





恶魔可以伪装成魔鬼。可以转化为人。但你不可能变成不存在的东西。
[cpg]


如果你能克服这个问题，这就是一个很大的进步。
[cpg]


这不仅仅是一个打酱油的问题，也是一个正常的战术扩展。
[cpg]


[OnName num="renzi"]
不，我不知道.......
[cpg cn=true]


变成不存在的东西，也意味着重新调整你自己作为一个生命体的机制。
[cpg]


直到现在，我变成龙的时候不能喷火，变成女妖的时候不能控制水。
[cpg]


[OnName num="renzi"]
但你可以复制肌肉的机制，等等。......。
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha135"]
[OnName num="asha"]
'怎么了。自言自语？"
[cpg cn=true]


[OnName num="renzi"]
'阿沙。食堂好吗？
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha136"]
[OnName num="asha"]
'我，我今天休息。仁济似乎每天都很自由'。
[cpg cn=true]


为了表彰我的工作，我已经被免于观看和类似的东西。
[cpg]


这并不意味着我不会受到其他魔鬼的嘲弄。
[cpg]


捕获库拉拉是这样一件大事。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





我打算扩大我一直在做的恶作剧。
[cpg]


但我仍然无法增加我可以变成的东西的数量。
[cpg]


只有懂得嗅觉的东西才能变成怪物的规则仍然没有改变。
[cpg]


有一段时间，我以为这就足够了。
[cpg]


安全的生活得到了暂时的保障。我已经做了那么多。
[cpg]


然后我就可以按照我想要的方式生活，仍然对别人进行恶作剧。
[cpg]


带着这种想法，我穿过走廊，可能是在晚上。
[cpg]



[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト

不知何故，我一个人感到很孤独。这并不是说我在这种时候......，而是......
[cpg]


我想去阿莎家。我知道她总是很孤独。
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





有一段时间，我作为一只青蛙上了阿莎的家。
[cpg]


我不会把我的孤独倾诉给一个聪明的恶魔。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Arsha138"]
[OnName num="asha"]
'什么......？　你是如何来到这里的......"
[cpg cn=true]


现在像我这样的恶魔通常不会进入卧室。
[cpg]


途中有几个门。所以我只是说这是不可能的。......
[cpg]


阿莎咽了一口唾沫。我认为她希望不管是谁或什么东西都能帮助她。
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha139"]
[OnName num="asha"]
'这事好像以前也发生过，......，也许。
[cpg cn=true]


这几乎没有人注意到，但阿莎摇了摇头。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sArsha012"]
[OnName num="asha"]
'嗯，好的。你也想我了'。
[cpg cn=true]

;//ブラックアウト

[SE f=se012]
;//【ＳＥ】『衣擦れ』

阿沙拍拍她的头。我的孤独感与她一起得到了抚慰。
[cpg]

;//移植前シーンカット


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************

正如一个恶魔所期望的那样，我永远不会把一只青蛙的形状养在我的床上。
[cpg]


我没有走到和她一起睡觉的地步，而是默默地离开了房间。我说闭嘴，但我不能说话。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


我回到这段话中，变成了一个人的样子。
[cpg]


我必须为阿莎做点什么。
[cpg]


她很容易坠入爱河，还是？我感觉她并不想这样做。
[cpg]


我所能做的就是我刚刚做的事。......
[cpg]


当她看起来如此悲伤时，我还是不能让她一个人呆着。
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





我回到了我的卧室。一种迷失的朦胧感觉在我身上蔓延。
[cpg]


尽管他们是恶魔，但他们都有自己的情况。
[cpg]


我不知道我是否应该为桃乐丝似乎喜欢我而感到高兴。
[cpg]


我不是在一个可以称之为后宫的情况下，我也没有做任何面对面的事情。
[cpg]


我觉得我不能让事情保持原样。
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[SE f=se008]
;//【ＳＥ】『喧噪』


第二天，我很饿，就去了食堂。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Arsha162"]
[OnName num="asha"]
'早上好。Renji."
[cpg cn=true]


阿莎微笑着，仿佛昨天的事情从未发生过。
[cpg]



[FACE method="change_7" pos="2/5"]

[VOICE f="Janice118"]
[OnName num="janice"]
'怎么了。你不回应我的问候？
[cpg cn=true]


[OnName num="renzi"]
'是的，也不是。'早上好。
[cpg cn=true]


我不知道阿莎对发生的事情有多少了解，所以我不能说什么。
[cpg]


今天晚上她还会安慰自己吗？
[cpg]


她当然说她很孤独。我想填补她心中的空白，即使我不得不伪装成一个不会认出我的人。
[cpg]


[FACE method="feadin_up" pos="4/7"]

;//ブラックアウト





阿沙真的很照顾我。
[cpg]


说我还在照顾她，这样做对吗？
[cpg]


我已经得到了克拉拉。你可以说阿莎做饭，他们只是在做各自的工作。
[cpg]


尽管如此，我认为我们不能说我们是陌生人了。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]
[FO pos="4/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FACE method="out" pos="4/7"]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


;**【ＣＧ】ci_14_0 ***********************
;//カットイン
[CUTIN f="ci_14_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


那一天，我也往她的房间附近走。我走向它，不是以青蛙的形式，而是以猫的形式。
[cpg]

[CUTIN f="ci_14_0.ui" show={false} method="slideout"]
[WAIT time=1000]

今天，这扇门也是微微打开。似乎她在等待着什么。
[cpg]


也许她在等我？我有一种感觉，她是。
[cpg]


不过，我还是想知道我是否应该进入她的房间。连续两天就像在说已经是我了。
[cpg]


就在我犹豫不决的时候，我的目光透过门缝与阿莎的目光相遇。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Arsha163"]
[OnName num="asha"]
'......，你也来安慰我。
[cpg cn=true]


我现在不能退缩。我想治愈阿沙的孤独。
[cpg]



[SE f=se012]
;//【ＳＥ】『衣擦れ』
[FACE method="feadin_up" pos="4/7"]

[FG f="CHA04_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

[WAIT time=1000]

;//ブラックアウト


[FACE method="change_6" pos="2/3"]

[VOICE f="sArsha013"]
[OnName num="asha"]
'我是......，是兔子部落的兽人，所以我很容易爱上。
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[VOICE f="sArsha014"]
[OnName num="asha"]
'即使我看起来不像一个人，我也是和你一样的......。
[cpg cn=true]


她开始多解释了一点。我知道她在当前背景下自言自语，但这是我第一次正确地听到她的话。
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="sArsha015"]
[OnName num="asha"]
'事实是......，我只想喜欢一个人。
[cpg cn=true]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





果不其然，他们一直呆在一起，直到阿霞睡着。
[cpg]


这一次她让我陪着她，直到她睡着之前。
[cpg]


我希望阿莎也能遇到好的人。...... 也许那就是我？
[cpg]


仔细想想，他还说只有一个人是他想喜欢的。
[cpg]


但情况确实并非如此。......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


我通过通道走回我的房间。
[cpg]


穿成猫的样子很难长时间活动，所以我不得不变回人形。
[cpg]


[OnName num="renzi"]
"......""
[cpg cn=true]


但这是一个令人不安的故事。阿莎很难永远保持这样的状态。
[cpg]


这就是说，我不确定我现在是否想被任何一个人束缚住。
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』

[BG f="b_03_5.ui" time=1500]
[WAIT time=1500]
;//ブラックアウト


[SE f=se012]
;//【ＳＥ】『衣擦れ』


我回到我的房间，躺在床上。
[cpg]


我仍然想对女孩们进行一段时间的恶作剧。
[cpg]


这不仅仅是关于阿莎。
[cpg]


有很多事情我还没有做，即使是对克拉拉。
[cpg]



[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』

经过反复思考，我知道我想扩大我的转变。
[cpg]


我不能变身为我以前从未见过的东西。因此，唯一的方法是看各种生物。
[cpg]


而且对我来说，知道它们的气味也很重要。
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[SE f=se008]
;//【ＳＥ】『喧噪』


我不知道该和谁谈这些事情。
[cpg]


我瞒着多萝西玩了一个把戏，而珍妮丝知道这个把戏并拒绝玩。
[cpg]


所以......，我现在应该和阿莎谈谈吗？我觉得我将发现很多东西。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha183"]
[OnName num="asha"]
'转型的广度......？　这是一个很难说的事情。我想你就是要看各种各样的生物，不是吗？"
[cpg cn=true]


[OnName num="renzi"]
我知道这一点。
[cpg cn=true]


这和我想的一样。但我对恶魔了解不多。
[cpg]


[OnName num="renzi"]
如果能变成这样，还有什么妖怪能派上用场吗？"
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Arsha184"]
[OnName num="asha"]
我不知道。......
[cpg cn=true]


阿莎似乎有一个想法。
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha185"]
[OnName num="asha"]
'在这附近，一定有一个。...... 哦，有了。
[cpg cn=true]


阿莎把我带到一个看起来像某种宝箱的地方。
[cpg]


[OnName num="renzi"]
'......，这是一个恶魔吗？
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha186"]
[OnName num="asha"]
是的，"他说。它被称为模仿者，我认为它是变形金刚的一个亲戚。"
[cpg cn=true]


...... 我明白了。一个模仿者。
[cpg]


模仿体可能无法转化为生物，但似乎模仿体可以转化为无机物。
[cpg]


它也许能通过这个变成非生物的东西。
[cpg]


走近模仿者。总之，你必须知道它是什么味道的。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha187"]
[OnName num="asha"]
'当你无法变成某种东西时，除非你知道它的气味，否则这很难。
[cpg cn=true]


[OnName num="renzi"]
'嗯，......，这是真的。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sArsha016"]
[OnName num="asha"]
'仁济闻到了模仿者的味道，有点儿可疑。
[cpg cn=true]


也许是这样，但这是一个无能为力的过程。......
[cpg]


[OnName num="renzi"]
我不想让阿莎告诉我该怎么做。"
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Arsha189"]
[OnName num="asha"]
'什么？　什么，为什么？"
[cpg cn=true]


阿沙有这样的反应。你难道没有意识到，刚才是我做的吗？
[cpg]

如果是这样，我可能说了一些不必要的话。......。
[cpg]

[FACE method="change_1" pos="2/3"]


;//ブラックアウト

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_16_0 ***********************
;//カットイン
[CUTIN f="ci_16_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

这就是为什么我能够变成一个模仿者。
[cpg]

[CUTIN f="ci_16_0.ui" show={false} method="slideout"]
[WAIT time=1000]

我现在还可以在模仿状态下转化为其他无机物。
[cpg]


当然，模仿者不能像我一样转化为活物。
[cpg]


相反，我从来没有能够转化为任何东西。能够转变为模仿者，扩大了我的转变范围。
[cpg]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



能够转化为无机物意味着我也能转化为衣服。
[cpg]


我想出的第一个恶作剧是变成别人的衣服。
[cpg]


这可能有点太离奇了，不能成为任何人的梦想......，但我至少想试试。
[cpg]


作为一个合作伙伴，阿莎是不同的。这对阿莎来说有点太粘了。
[cpg]


对珍妮丝这样做也是不同的。她更像是那种让人害怕的人，很有意思。
[cpg]


所以要做的人是......
[cpg]



[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[FACE method="out" pos="4/7"]


[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="04"]


;//ブラックアウト


桃乐丝。当她洗完澡后，我先潜入她的房间。
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Dorothy121"]
[OnName num="dorothy"]
'呼。今天又是好的热水'。
[cpg cn=true]


;//移植前シーンカット


她很快就穿完了衣服，而我还在等她穿完。我其实是想做她的衣服。
[cpg]


好吧，管它呢，我为什么不变成她身上的毯子呢？
[cpg]


我就是这么想的，我变成了一条毯子。我可以和她亲密接触而不被发现。
[cpg]


;//移植前シーンカット

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[STOPBGM]


这就是所发生的事情。第二天，多萝西说：......
[cpg]



[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy163"]
[OnName num="dorothy"]
Renji ......，早上好。"
[cpg cn=true]


他的表情有些阴沉。
[cpg]


[OnName num="renzi"]
'早上好。有什么问题吗？
[cpg cn=true]




[FACE method="change_7" pos="2/3"]
[VOICE f="sDorothy002"]
[OnName num="dorothy"]
是的，我做了一个奇怪的梦。被褥感觉很重。
[cpg cn=true]


[OnName num="renzi"]
哦，......"
[cpg cn=true]


我感到有些内疚，假装不知道。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1" pos="2/5" time=800]

[OnName num="rudolf"]
'我听说你有更多的东西可以再次变身。
[cpg cn=true]


[OnName num="renzi"]
'是的。既然我变成了一个模仿者，我就能变成东西。
[cpg cn=true]

[FACE method="change_5" pos="2/5"]
[VOICE f="Janice119"]
[OnName num="janice"]
'是这样吗......？　你现在可以变成任何东西，不是吗？"
[cpg cn=true]


[OnName num="renzi"]
'不，它没有。你不可能变成不存在的东西'。
[cpg cn=true]


[OnName num="rudolf"]
'你的潜力是巨大的。正如你抓获克拉拉的事实一样。......"
[cpg cn=true]


[OnName num="rudolf"]
'我相信不仅有可能结束这场战斗，甚至有可能赢得这场战斗。
[cpg cn=true]


[OnName num="renzi"]
'......，买得太多了。但是谢谢你。"
[cpg cn=true]


[OnName num="rudolf"]
'我不买账。如果你能再认真一点就好了'。
[cpg cn=true]


恶魔领主似乎明白我在做什么。
[cpg]


我是否应该拉动一下我的体重？但我不打算停止。
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokie1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



从那时起，我尝试了各种恶作剧。
[cpg]


我把自己伪装成东西的恶作剧，他们并没有发现那是我的方式，他们没有想象到。
[cpg]


另一方面，我开始觉得自己似乎不能仅仅满足于恶作剧。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha190"]
[OnName num="asha"]
'怎么了，你看起来很困难。
[cpg cn=true]


[OnName num="renzi"]
不，......，只是在想即将到来的事情。"
[cpg cn=true]


我已经实现了这一点：到处对女孩进行恶作剧。
[cpg]


但我也有一种感觉，这并不是终点。
[cpg]

[move from="2/3" to="4/5" ease="easeInOutSine" time=1000]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/5" time=1000]
[VOICE f="Janice120"]
[OnName num="janice"]
Fu......."
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Arsha191"]
[OnName num="asha"]
'哦，珍妮丝。干得好。"
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[VOICE f="Janice121"]
[OnName num="janice"]
'完全如此。那位克拉拉似乎口风很紧。或者他已经没有什么可隐瞒的了'。
[cpg cn=true]


[OnName num="renzi"]
在这种情况下，让我帮助你。"
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Janice122"]
[OnName num="janice"]
'...... Renji的眼睛在这种时候真的会发光。
[cpg cn=true]


[OnName num="renzi"]
'是的，是这样的吗？
[cpg cn=true]


你不能隐藏你的人性。珍妮丝可能是一个很好的例子。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]
[FO pos="4/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


然后珍妮丝和我决定一起去克拉拉的住处。
[cpg]



;//俺はもう人間の姿をしてない。これからやる尋問に使う、ある道具に変身していた。[cpg]
;//ブラックアウト



[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]

[VOICE f="Janice123"]
[OnName num="janice"]
'库拉拉。你今天的眼睛里有一种挑衅的神情。
[cpg cn=true]



[VOICE f="Clara074"]
[OnName num="clara"]
'这很明显，......，不是吗？
[cpg cn=true]

珍妮丝带着高高在上的表情告诉克拉拉。
[cpg]


我说我会帮忙，但我什么也做不了。因为......
[cpg]


在任何情况下，库拉拉都不说话。她甚至没有说任何她不想说的东西了。
[cpg]


仿佛珍妮丝会先崩溃。甚至我都在想，'感谢上帝，珍妮丝并不残忍'。
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]
[FO pos="1/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice131"]
[OnName num="janice"]
'进展如何？　克拉拉一定是很顽固的。"
[cpg cn=true]


[OnName num="renzi"]
'...... 哦。
[cpg cn=true]


尽管如此，...... Janice的审讯还是比预期的要温顺。
[cpg]


我之前以为珍妮丝肯定会毫不犹豫地审问库拉拉，但......
[cpg]


令人惊讶的是，情况并非如此。我有相当多的同情心和那种感觉。
[cpg]


意外的是，我被珍妮丝温柔的一面所感动，觉得她有点可爱。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************

[SE f=se008]
;//【ＳＥ】『喧噪』



我回到饭厅拿了些食物。
[cpg]


桃乐丝也在那里。她看到我们并挥手致意。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy166"]
[OnName num="dorothy"]
'怜子，你已经打扮成一个人很久了。
[cpg cn=true]


[OnName num="renzi"]
'那是因为他们曾经是人。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]f
[VOICE f="Dorothy167"]
[OnName num="dorothy"]
'地牢里的每个人都会感到惊讶。不过，他们现在可能已经习惯了'。
[cpg cn=true]


的确，有几次他们被误认为是入侵者，几乎遭到攻击。
[cpg]


但如果事情到了这个地步，你就必须解除转变。
[cpg]


更多的是，我是以轻松的方式来花费时间。
[cpg]


[FO pos="2/3" time=1000]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/5" time=1000]
[VOICE f="Janice132"]
[OnName num="janice"]
'公主，我是库拉拉，但她......，很顽固。
[cpg cn=true]


你告诉我的故事现在要讲给多萝西听。
[cpg]


[FACE method="change_1" pos="2/5"]
[VOICE f="Janice133"]
[OnName num="janice"]
'我担心进一步的审讯可能不会有任何结果。
[cpg cn=true]


[FACE method="change_2" pos="4/5"]
[VOICE f="Dorothy168"]
[OnName num="dorothy"]
'你想让我这样做吗？　我想我很擅长这种事情。"
[cpg cn=true]


这以前就发生过。桃乐丝真的会不遗余力。
[cpg]


[OnName num="renzi"]
'不，不。我来做。"
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Dorothy169"]
[OnName num="dorothy"]
'我明白了。我不介意任何一种方式，但如果你要做，就要做得彻底。
[cpg cn=true]


多萝西的恐惧在这一个词中完全渗透出来。
[cpg]


如果我让她审讯克拉拉，我可能就会杀了她。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





又是一天即将过去。我被免除了看守等事情，所以我的一天非常长。
[cpg]


这就是为什么我对某人进行恶作剧，但是... ......
[cpg]


我所注意到的。这种恶作剧方法的一个关键缺点。
[cpg]


即使你能在不被她们察觉的情况下接近这些女人，也不会导致超越这个范围的关系。
[cpg]


相反，我开始觉得这不是办法，因为我在真正的事情之前一直在重复事情。
[cpg]



[window target=false]
[BG f="b_03_5.ui" time=1000]
[WAIT time=1500]
[window target=true]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





当她没有意识到是我的时候，就不会再发生什么了。
[cpg]


也就是说，强行攻击我也是违反我的原则。
[cpg]


当我考虑这是否是我想做的事时，我认为不是。
[cpg]


[SE f=se002]
;//【ＳＥ】『ベッドに倒れ込む』

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト




我有点走入死胡同了。
[cpg]


只做我想做的事是不够的。我需要对某人有用。
[cpg]




[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





第二天。我在走廊里看到了珍妮丝。
[cpg]


她似乎在思考什么，经过我身边时没有打招呼。
[cpg]


...... 她也是一个可爱的人。我看到了她可爱的一面，这是我没有想到的。
[cpg]


她对克拉拉并不冷酷无情。我以为她是那种做什么都要计算的人。
[cpg]


我觉得我想对她做点什么，所以我再次把自己变成了不同的东西。
[cpg]

[window target=false]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[BG f="white.ui" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

[STOPBGM]

;//ブラックアウト

[BG f="black.ui" time=1000]
[WAIT time=1500]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice134"]
[OnName num="janice"]
'...... 小狗？　你为什么在这里，在地牢的深处？"
[cpg cn=true]

;**【ＣＧ】ci_17_0 ***********************
;//カットイン
[CUTIN f="ci_17_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

我以一只小狗的形式出现在珍妮丝面前。
[cpg]

[CUTIN f="ci_17_0.ui" show={false} method="slideout"]
[WAIT time=1000]

当我走近她时，她的脸从先前的深思熟虑的表情变得有些柔和。
[cpg]



[FACE method="change_1" pos="2/3"]
[VOICE f="Janice135"]
[OnName num="janice"]
'你太友好了。她是某人的宠物吗？
[cpg cn=true]


珍妮丝拍拍我的头。我假装很高兴。
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Janice136"]
[OnName num="janice"]
'好吧，好吧，......，你是个甜心。
[cpg cn=true]


我仍然感到有些空虚。
[cpg]


她认为可爱的不是我，而是那只小狗。
[cpg]


这是一个由我可以转变的事实造成的困境。
[cpg]


[SE f=se012]
;//【ＳＥ】『衣擦れ』


我想为某人做点什么，我想被人喜欢，我实现了，但被喜欢的不是我。
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="sJanice006"]
[OnName num="janice"]
'哦，嘿。你要去哪里？"
[cpg cn=true]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





空虚感只会越来越严重。我跑到过道上。
[cpg]


当珍妮丝离开视线时，我又恢复了人形。
[cpg]


[OnName num="renzi"]
'......'
[cpg cn=true]


我想做什么？现在是明确的时候了。
[cpg]



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="ep012.ks" target="*start"]


