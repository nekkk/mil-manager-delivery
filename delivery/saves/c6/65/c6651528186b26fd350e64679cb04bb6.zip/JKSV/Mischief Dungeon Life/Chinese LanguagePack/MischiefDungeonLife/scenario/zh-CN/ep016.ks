*start

;###################################################################
*Ep016|奇怪的体质，不断变化的身体和不变的思想。
;###################################################################
;//４、アーシャ

[SCENE id=16]


[window target=false]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out" pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out" pos="3/5"]


[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]

[window target=true]


我发现自己在想阿霞。
[cpg]


她是第一个帮助我的人，第一个认识到我有能力转变的人。
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy489"]
[OnName num="dorothy"]
'说点什么吧。你为什么不说话？
[cpg cn=true]


[OnName num="renzi"]
...... 不。"
[cpg cn=true]


我已经意识到我对自己的感觉。我喜欢阿莎。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



然后，要过上平静的生活变得有些困难。
[cpg]


阿莎是个厨师，所以我只是去食堂和阿莎见面。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha233"]
[OnName num="asha"]
'我能为你做些什么呢？
[cpg cn=true]


[OnName num="renzi"]
'哦，嗯，...... 是的。
[cpg cn=true]


我无法再直视阿莎。
[cpg]


我听说阿莎也是那种容易坠入爱河的人，但......，这是不同的。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





我想对阿霞做点什么。
[cpg]


我想知道我是否可以把自己伪装成她熟悉的东西，偷听她对我的看法。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





我潜入阿莎的房间。我有变形的能力，所以如果我听到阿莎的脚步声，我可以变成别的东西。
[cpg]


我环顾房间，想，我应该变成什么？ ......
[cpg]



[SE f=se009]
;//【ＳＥ】『歩く』



然后我听到有人的脚步声。我还听到了一段独白。
[cpg]


[VOICE f="Arsha234"]
[OnName num="asha"]
'呼，今天的热水真不错。
[cpg cn=true]


阿莎刚刚洗完澡，她正试图回到这里。
[cpg]


我惊慌失措，转身走进了那里的东西。即......
[cpg]


[SE f=se023]
;//【ＳＥ】『ドア閉まる・開く』



[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sArsha019"]
[OnName num="asha"]
'...... 嗯？　两本相同的书？"
[cpg cn=true]

;**【ＣＧ】ci_23_0 ***********************
;//カットイン
[CUTIN f="ci_23_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

我变成了一本书，是不是做了什么蠢事？两个相同的人很容易被发现。
[cpg]


[CUTIN f="ci_23_0.ui" show={false} method="feadout"]
[WAIT time=1500]

[FACE method="change_7"  pos="2/3"]
[VOICE f="sArsha020"]
[OnName num="asha"]
'我是不是错买了两本书？
[cpg cn=true]

但阿莎从未再怀疑过。
[cpg]


同一本书的两份副本在其他世界似乎是一件事 ......
[cpg]


[SE f=se012]
;//【ＳＥ】『衣擦れ』
[FO pos="2/3" time=1000]


而阿莎躺下后很快就睡着了。
[cpg]


我确定她已经睡着了，变回了原样，离开了房间。
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





我回到自己的房间，一直在想我要怎么做才能勾搭上阿霞。
[cpg]


她很容易让人爱上。如果我要和她约会，我想这是我要做的 .......
[cpg]


[window target=false]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Arsha261"]
[OnName num="asha"]
'早上好。我能为你做些什么？"
[cpg cn=true]


[OnName num="renzi"]
'哦，早上好。嗯，是的。.......'
[cpg cn=true]


阿莎微笑着，好像什么都没发生。我想这对她来说一定很困难。
[cpg]


[FO pos="2/3" time=1000]


我们坐下来，我正在吃我的早餐。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy490"]
[OnName num="dorothy"]
'早上好，Renji'。
[cpg cn=true]


多萝西在我身边坐下。我知道她也爱慕我。
[cpg]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Dorothy491"]
[OnName num="dorothy"]
'嘿，嘿，你接下来要做什么？　如果Renji得到了Clara，他将会做出更惊人的事情，不是吗？"
[cpg cn=true]


他们说他们对我有这样的期望，但我的想法完全不同。
[cpg]


如何与阿霞相处。这就是全部。
[cpg]


[OnName num="renzi"]
'是的，好吧，......，我在想很多事情。
[cpg cn=true]


还在胡闹，我会继续说下去的。
[cpg]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Dorothy492"]
[OnName num="dorothy"]
'嗯？　不管是什么，我都期待着它。"
[cpg cn=true]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


休闲的日常生活。我会在第一时间尝试与阿莎交谈。
[cpg]


[OnName num="renzi"]
'阿莎，你要去哪里？
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha262"]
[OnName num="asha"]
'什么？　不过，我正在休息，所以我要回我的房间了。"
[cpg cn=true]


[OnName num="renzi"]
我可以在路上跟着你吗？"
[cpg cn=true]


这对我来说是勇气的一步，伪装成随口一说。
[cpg]



[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha263"]
[OnName num="asha"]
'...... 好的。如果你愿意，我们可以到你的房间去？"
[cpg cn=true]


阿莎以一种不介意的方式回应了这一点。我决定顺势而为。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FACE method="feadin_up" pos="4/7"]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Arsha264"]
[OnName num="asha"]
'Renji很了不起，不是吗？我只擅长烹饪。
[cpg cn=true]


[OnName num="renzi"]
'烹饪是你能做的最棒的事情。无论你有多强壮或多伟大，你都不能没有阿莎的烹饪。
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha265"]
[OnName num="asha"]
'嗯。不过，我很高兴你这么说。
[cpg cn=true]


阿莎看起来有点尴尬，她说。
[cpg]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Arsha266"]
[OnName num="asha"]
'...... 嘿，Renji。我有一些事情需要和你讨论。"
[cpg cn=true]


[OnName num="renzi"]
'这是什么？　什么都可以。"
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Arsha267"]
[OnName num="asha"]
'你必须明白，我之所以告诉你这些，是因为我对仁济有一定程度的开放。不要告诉任何人'。
[cpg cn=true]


在做完这个铺垫后，阿莎给我讲了这个故事。
[cpg]


[FACE method="change_6"  pos="2/3"]
[VOICE f="sArsha021"]
[OnName num="asha"]
'我很容易坠入爱河。你已经知道了，我是兔子部落的野兽，这就是我所说的'。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Arsha269"]
[OnName num="asha"]
'最近在.......，情况特别糟糕。到了我在工作中无法思考任何问题的地步'。
[cpg cn=true]


阿莎很尴尬，但以认真的语气说道。
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="sArsha022"]
[OnName num="asha"]
'那么，Renji。你就不能变成什么东西，安抚我的情绪吗？
[cpg cn=true]


[OnName num="renzi"]
这是我......."
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha271"]
[OnName num="asha"]
'天哪，我很抱歉。这听起来像一个忏悔，但它不是'。
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha272"]
[OnName num="asha"]
'Renji认为这很酷。我有库拉拉，我从一开始就认为他是可靠的。"
[cpg cn=true]


[FACE method="change_6"  pos="2/3"]
[VOICE f="sArsha023"]
[OnName num="asha"]
'但......，这不是我的意思。我只是想改变这部宪法'。
[cpg cn=true]


你必须读懂她的想法。看起来我们不会很快坠入爱河，但它仍然是一个进步。
[cpg]


我想这是我不会要求的，如果我觉得不喜欢。我已经下定决心。
[cpg]


[OnName num="renzi"]
休息，多长时间？
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha274"]
[OnName num="asha"]
'还有一个小时。我的时间不多，但我们会看到的。
[cpg cn=true]


[OnName num="renzi"]
'好的。我会处理的'。
[cpg cn=true]


[FO pos="2/3" time=1000]

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
[FACE method="out" pos="4/7"]


[STOPBGM]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[BG f="white.ui" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



;//========================================
;//●ＣＧ（座って、催眠状態にあるヒロイン。うつろな表情）ev_52
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公はインキュバスに化けています
;//=======================================

;//*Scene050


[BGM f="10"]
;**【ＣＧ】 ev_52_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1500]




我被伪装成一个男性梦想家，被称为孵化器。
[cpg]



[VOICE f="sArsha024"]
[OnName num="asha"]
'......，那套衣服，Incubus？　你能用魔法来控制思想或类似的东西吗？
[cpg cn=true]


[OnName num="renzi"]
'我想知道。这就是我变身时的想法'。
[cpg cn=true]


[OnName num="renzi"]
'我不知道我是否能使用它。但我想我会给它一个机会'。
[cpg cn=true]


我要想一想，我也要提醒自己。但......
[cpg]


我甚至不知道我是否可以仅仅通过思考就使用魔法。
[cpg]


如果不是这样，那我就不知道怎么能更多地使用魔法了。
[cpg]


在思考的同时，我一直在想这个问题。
[cpg]


[OnName num="renzi"]
进展如何？我的身体有什么变化吗？"
[cpg cn=true]

;**【ＣＧ】 ev_52_a ***********************
[CG id=16 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sArsha025"]
[OnName num="asha"]
「……」
[cpg cn=true]

眼神略显忧郁。我觉得这很有效。
[cpg]


我只能模仿我复制的恶魔的基本行为，但......
[cpg]


这可能意味着，这是孵化器的基本行为的一部分。
[cpg]


[OnName num="renzi"]
'慢慢地，我的眼皮变得更重......，我睡着了。
[cpg cn=true]


我试着做一些催眠的事情，看看会发生什么，但我不知道这到底是怎么回事。
[cpg]

;**【ＣＧ】 ev_52_b ***********************
[CG id=16 index=2 time=1000]
;***************************************
[WAIT time=1500]

[OnName num="renzi"]
'让我们看看，......，我很容易陷入爱河，但它正在慢慢溜走。
[cpg cn=true]


[OnName num="renzi"]
'你真正爱的人只会有一个：......'
[cpg cn=true]


多么令人尴尬的话语。
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



于是，从那一天起，阿莎的宪法将被改变。
[cpg]


阿莎说，她觉得自己的身体有点轻了。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sArsha026"]
[OnName num="asha"]
'我是......，很好。也许这将有助于我正常地完成我的工作。
[cpg cn=true]


他这么说，但似乎并不像个谎言。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





然后第二天我去了食堂，发现多萝西和阿莎在友好地交谈。
[cpg]


我突然想知道他们有什么样的关系。
[cpg]


多萝西和珍妮丝显然对他们有一种不寻常的感觉，但......
[cpg]


他和阿莎在一起做什么？多么邪恶的想法。
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





那天晚上，我把自己伪装成多萝西，去了阿莎的房间。
[cpg]


如果是这样的话。如果多萝西没有对阿莎做什么，那就好。
[cpg]


另一方面，如果发生了什么事，我也许能从她那里得到一个更深的故事。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



;//ここからしばらく、ドロシーのセリフ名前欄を「ドロシー（蓮司）」と置き換えてください



[FG f="CHA02_p4_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Dorothy493"]
[OnName num="renzi_to_dorothy"]
'晚上好。我现在可以进来了吗？
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Arsha298"]
[OnName num="asha"]
是的。...... 怎么了，桃乐丝？"
[cpg cn=true]


[FACE method="change_1"  pos="1/2"]
[VOICE f="Dorothy494"]
[OnName num="renzi_to_dorothy"]
'我以为你和Renji最近相处得很好。发生了一些事情'。
[cpg cn=true]


这不是很直截了当，但这是问的方式。然后。
[cpg]


[FACE method="change_4"  pos="2/2"]
[VOICE f="sArsha027"]
[OnName num="asha"]
'我想改变我的......《宪法》。我让一个孵化器把我变成一个孵化器，我让它在我身上做手脚。"
[cpg cn=true]


[FACE method="change_1"  pos="2/2"]
[VOICE f="sArsha028"]
[OnName num="asha"]
'另外，......，我想把这个故事告诉别人，你会听吗？
[cpg cn=true]


[FACE method="change_2"  pos="1/2"]
[VOICE f="Dorothy495"]
[OnName num="renzi_to_dorothy"]
只要我没意见，你想听什么我都会听。
[cpg cn=true]


[FACE method="change_4"  pos="2/2"]
[VOICE f="Arsha301"]
[OnName num="asha"]
'我喜欢Renji，我喜欢他，但......
[cpg cn=true]


[FACE method="change_1"  pos="2/2"]
[VOICE f="sArsha029"]
[OnName num="asha"]
即使他不在身边，我仍然发现自己在和别人调情。"
[cpg cn=true]


如果你问他们，他们说他们也会和不是我的人发情，也会和一个女人发情。
[cpg]


[FACE method="change_6"  pos="2/2"]
[VOICE f="sArsha030"]
[OnName num="asha"]
'嘿，你觉得我应该怎么做？　我真的想要一个与这部宪法无关的爱情生活。"
[cpg cn=true]


[FACE method="change_1"  pos="1/2"]
[VOICE f="Dorothy496"]
[OnName num="renzi_to_dorothy"]
'不要担心.......阿莎将是阿莎。"
[cpg cn=true]


这种情况下，我现在就可以向你忏悔，我们就可以出去了。但我想在这之前解决她的问题。
[cpg]


[FACE method="change_3"  pos="1/2"]
[VOICE f="sDorothy016"]
[OnName num="renzi_to_dorothy"]
'阿沙。即使是现在，你的日子也很难过。要不要我再变身为幽灵？"
[cpg cn=true]


[FACE method="change_5"  pos="2/2"]
[VOICE f="Arsha304"]
[OnName num="asha"]
'什么？　你说话的方式......，也许，Renji？"
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Dorothy598"]
[OnName num="renzi_to_dorothy"]
'哦。对不起，我的方式有欺骗性。
[cpg cn=true]



[FACE method="change_6"  pos="2/2"]
[VOICE f="Arsha305"]
[OnName num="asha"]
这是可怕的......，我以为是桃乐丝，我告诉了她一切。"
[cpg cn=true]


说到这里，阿莎似乎觉得说了这些话后感觉好多了。
[cpg]



[FACE method="change_1"  pos="2/2"]
[VOICE f="Arsha316"]
[OnName num="asha"]
'当你打扮成桃乐丝，而你说话像仁慈，这很奇怪。
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Dorothy508"]
[OnName num="renzi_to_dorothy"]
'我不这么认为。我应该模仿桃乐丝吗？
[cpg cn=true]


我们都对彼此微笑。但眼前的问题仍未解决。
[cpg]


我想不惜一切代价帮助阿沙。
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


;//ここからドロシーのセリフ名前欄を元に戻してください


我在思考未来。
[cpg]


催情剂可能是这个世界上的一种东西。它应该有点容易制作。
[cpg]


但反过来就很难了。
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_04_5_up.ui" time=1000]
[FACE method="feadin_up" pos="4/7"]
[WAIT time=1500]


[OnName num="renzi"]
我想知道兔子部落的每个兽人是否都是这样。"
[cpg cn=true]


我曾去找人咨询。这个人就是。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Clara535"]
[OnName num="clara"]
'......，你为什么要向我请教这种事情呢？
[cpg cn=true]


库拉拉。她也是一个亚人。
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="sClara014"]
[OnName num="clara"]
'嗯，......，我听说兔子兽人很容易坠入爱河。
[cpg cn=true]


[OnName num="renzi"]
'我就知道。你有什么可以做的吗？
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Clara537"]
[OnName num="clara"]
我不知道，但在...... 广阔世界的某个地方，一定有一种治疗方法。"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





与克拉拉的谈话结束时，似乎有一个线索，或者说没有。
[cpg]


我无法独自思考这个问题，所以我也去和珍妮丝谈了这个问题。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice463"]
[OnName num="janice"]
'如果你要和那个人约会，你就必须包括这部分内容。
[cpg cn=true]


[OnName num="renzi"]
'我知道这一点，你知道。我不是说这个，我是说阿莎有麻烦了，我想为她解决这个问题。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice464"]
[OnName num="janice"]
'......，我想是的。
[cpg cn=true]


珍妮丝对阿沙并不陌生。她似乎在思考什么，但似乎想不出一个计划来。
[cpg]


;//移植前シーンカット

;//移植前シーンカット



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************




我从早到晚都在阿莎的身边。我日复一日地陪伴着阿莎，抚慰她的孤独，改变她的体质。
[cpg]


但这是一种尴尬的关系。我以为这与普通的情人不同。
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_04_5_up.ui" time=1000]
[FACE method="feadin_up" pos="4/7"]
[WAIT time=1500]




[OnName num="renzi"]
有一种东西叫......'
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Clara538"]
[OnName num="clara"]
'这听起来当然是个大工程，但你为什么要来找我谈这个问题？
[cpg cn=true]


我再次咨询克拉拉。我在地牢里失去了对事物的控制。
[cpg]


[FACE method="change_1"  pos="2/3"]

[VOICE f="Clara539"]
[OnName num="clara"]
'但你一直问我，我就想起来了。'关于树人。
[cpg cn=true]


[OnName num="renzi"]
'树人？　什么是树人？"
[cpg cn=true]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Clara540"]
[OnName num="clara"]
'他们是魔鬼，但我听说树上的人放的果实可以治疗各种不治之症，......，取决于它的混合方式。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Clara541"]
[OnName num="clara"]
但我不知道你是否能得到它，因为我听说它很有价值。"
[cpg cn=true]


[OnName num="renzi"]
"...... 嗯。"
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy520"]
[OnName num="dorothy"]
'Jyuto?　我们为什么突然谈起这个？"
[cpg cn=true]


[OnName num="renzi"]
'是关于阿莎的。我想这可能有助于她的身体。
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy521"]
[OnName num="dorothy"]
'哦......，我不知道。我不知道这是否可以称为一种疾病。"
[cpg cn=true]


当然，它更像是一种体质而不是一种疾病？　难度。
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy522"]
[OnName num="dorothy"]
'但树人不会呆在地牢里。他们不能生活在光照不到的地方。
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy523"]
[OnName num="dorothy"]
他们是恶魔，但他们似乎不喜欢冲突，我想知道他们住在哪里......。"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





桃乐丝告诉我，我做了一张简单的地图。
[cpg]


树人的森林。它似乎离食人魔部落的定居点更远。
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************




[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

阿莎和我谈到了这个问题，日复一日地拥抱着对方。
[cpg]


[OnName num="renzi"]
'嘿。如果有一种药可以改变你的体质，你还会想要它吗？
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="sArsha031"]
[OnName num="asha"]
'好吧，这是我想要的东西，我的喉咙里有。恋次也不喜欢我这样。
[cpg cn=true]


[OnName num="renzi"]
'我不恨你，但......，你还是想要。
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Arsha376"]
[OnName num="asha"]
'是的。我只想爱上仁济。我想只爱我爱的人"。
[cpg cn=true]


这是个有点搞笑的词，但它似乎很好地表达了阿霞的感受。
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト



然后就到了出发的日子。
[cpg]




[window target=false]

[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************





[OnName num="renzi"]
'...... 耀眼的'。
[cpg cn=true]


每当我在很长时间后离开地牢时，阳光似乎总能刺瞎我的眼睛。
[cpg]


我朝树人居住的森林走去。
[cpg]


首先，我必须到达恶魔部落的村庄。我开始行走。
[cpg]


[SE f=se020]
;//【ＳＥ】『草原歩く』



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夕方）******************************************************



[OnName num="demon"]
'等等。人类想要什么？
[cpg cn=true]


为了便于行走，我呈人形。
[cpg]


[OnName num="renzi"]
'不，不，不，我是一个恶魔。
[cpg cn=true]


我穿过大门，无论如何都要问一下樱木的住处，之前在哪里交换过类似的东西。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夕方）******************************************************





[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki104"]
[OnName num="satsuki"]
已经有很长一段时间了。这次是什么风把你吹来了？
[cpg cn=true]


我想在与树上的人谈判之前，先在一定程度上了解一下情况。我毫不犹豫地与樱木交谈。
[cpg]


[OnName num="renzi"]
我想要树上的果实的人。他们在这个村子的深处，不是吗？"
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki105"]
[OnName num="satsuki"]
'......，他们很挑剔。要让他们合作一定很困难。
[cpg cn=true]


樱木的表情有点阴晴不定。这真的有那么难吗？
[cpg]


[OnName num="renzi"]
'我不会放弃。这是为了我爱的人。
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Satuki106"]
[OnName num="satsuki"]
'我想知道他是否有一个女朋友。她是不是患了什么不治之症？
[cpg cn=true]


樱木微微一笑，问道。我公开地回答，因为没有必要隐藏。
[cpg]


[OnName num="renzi"]
'啊。我的女朋友想要树上的果实的人'。
[cpg cn=true]


我觉得已经准备好说这些话了。无论谈判有多困难，我都会设法解决。
[cpg]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





那天，我将在樱木家呆上一天，然后离开。
[cpg]






[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（朝）******************************************************





[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki107"]
[OnName num="satsuki"]
'祝你有个愉快的一天。照顾好自己。"
[cpg cn=true]


[OnName num="renzi"]
'哦。你不是一个凶猛的物种，我会安然无恙地回来'。
[cpg cn=true]


我说完这句话就离开了恶魔部落的定居点。
[cpg]



[SE f=se009]
;//【ＳＥ】『歩く』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************



[SE f=se020]
;//【ＳＥ】『草原歩く』




大约走了半天，这里的树木逐渐多了起来，像一片森林。
[cpg]


然后我们到达了树人居住的森林。
[cpg]


我并不觉得自己很受欢迎。或者说，他们对待我的态度就像我是一个进入的外国人。
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_09_2_up.ui" time=1500]
[FACE method="feadin_up" pos="4/7"]
[WAIT time=2000]


[OnName num="treant"]
「……」
[cpg cn=true]


这些树人真的长得像树，而且不说一句话。
[cpg]


[OnName num="renzi"]
'打扰一下。我在这里寻找树上的人所戴的果实。
[cpg cn=true]


树上的人不会对我说什么。但在他们不和我说话的过程中，我发现了一些问题。
[cpg]


树人是恶魔，是活生生的生物，尽管接近于植物。
[cpg]


而且显然他们不愿意给我水果。
[cpg]


从他们那里拿走水果可以说是侵略，而且他们似乎也有一种难缠的性格，正如Satsuki所说。
[cpg]


要获得他们的合作是很困难的。了解到这一点，我突然想到了一个办法。
[cpg]


[OnName num="renzi"]
'好吧，让我闻闻浆果的味道。我不会把他们带走。"
[cpg cn=true]


[OnName num="treant"]
'......'
[cpg cn=true]


关于这一点，他们没有拒绝。浆果几乎没有气味，但有轻微的水果香味。
[cpg]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『平原』（夜）******************************************************





然后我们再次走到平原上，继续行走，经过了恶魔部落的定居点。
[cpg]


这是相当艰苦的工作，但我有我的收获。也就是说，我能够变成一个结实的树人。
[cpg]


[SE f=se020]
;//【ＳＥ】『草原歩く』



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************





然后我在很长一段时间内第一次回到了地牢。阿霞向我问好。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha377"]
[OnName num="asha"]
'欢迎回来，Renji。我以为你不回来了。
[cpg cn=true]


[OnName num="renzi"]
'不可能。没有发生任何危险。我有更多的好消息。
[cpg cn=true]


[OnName num="renzi"]
'我们已经得到了树的果实的人。它可能能够治疗阿莎的体质。
[cpg cn=true]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





我甚至把这件事告诉了阿霞。但从那时起，我就把它藏了起来。
[cpg]


不知为何，我本能地感觉到这有点冒险，所以我咨询了多萝西和珍妮丝。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Dorothy524"]
[OnName num="dorothy"]
'你想出了一个惊人的想法，......，即使我有同样的能力，我也会害怕，甚至不敢想。
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Janice465"]
[OnName num="janice"]
'对。你知道与他人分享你的果实意味着什么吗？......'？
[cpg cn=true]


我没有点头。我想我不知道，但我还没有准备好。
[cpg]


[FACE method="change_3"  pos="1/2"]
[VOICE f="Janice466"]
[OnName num="janice"]
'毋庸置疑，你将失去你的身体。下次你再伪装成人类的身体或恶魔的身体时，你可能无法恢复到你的完整形态。
[cpg cn=true]


珍妮丝将她的话说得很清楚。从本质上讲，她是说这可能类似于失去一条胳膊或一条腿。
[cpg]


我几乎犹豫不决，但很快就重新考虑了。
[cpg]


如果阿莎能够和平地生活，她至少可以拥有一只手臂。我也是这么想的。
[cpg]


[OnName num="renzi"]
'我很好。我不怕为阿莎失去什么。"
[cpg cn=true]


[FACE method="change_3"  pos="2/2"]
[VOICE f="Dorothy525"]
[OnName num="dorothy"]
'......，听起来你是认真的。好的。"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


;**【ＣＧ】ci_24_0 ***********************
;//カットイン
[CUTIN f="ci_24_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

我本来早就准备好了。我决定把自己伪装成一个带着浆果的树人，让多萝西为我拿浆果。
[cpg]

[CUTIN f="ci_24_0.ui" show={false} method="slideout"]
[WAIT time=1000]

我不能让阿莎出现在这个场景中，我想。......
[cpg]




[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Dorothy526"]
[OnName num="dorothy"]
'我们走吧。Renji."
[cpg cn=true]


那是一个紧张的时刻，但不像痛苦。
[cpg]


[FACE method="feadin" pos="4/7"]
[BG f="b_04_5.ui" time=1500]
[WAIT time=2000]
;//ブラックアウト



恐惧一直都在那里。但如果我不克服它，阿莎的体质将永远不会被治愈。
[cpg]

这个想法让我感到奇怪的稳定。
[cpg]


结果是，没有发生多萝西或珍妮丝所担心的事情。
[cpg]


当我从一个树人转变为另一个树人时，我的胳膊和腿都没有缺失。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





我无法将药水与浆果混合，所以我把它留给了另一个恶魔。
[cpg]


看来，树人的果实真的很珍贵，他们问我是怎么得到的。
[cpg]


我告诉他我是如何得到它的，以及它的用途，药就成功制成了。......。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sArsha032"]
[OnName num="asha"]
'你是说，如果我吃了这个，我就能改变我的...... 体质？
[cpg cn=true]


[OnName num="renzi"]
哦，"他说。理论上，应该如此。"
[cpg cn=true]


阿莎的怀疑是正确的。他们是如何创造出这样一剂灵丹妙药的呢？可以安全饮用吗？
[cpg]


她认为自己不可能不关心这个问题，但她并不关心。
[cpg]


[OnName num="renzi"]
'哦，嘿，......'
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha379"]
[OnName num="asha"]
'福'。'这药很甜，这药很甜。
[cpg cn=true]


阿莎一口气把它全部吞下。她似乎非常信任我。
[cpg]






[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





从那天起，阿莎的体质明显地平静下来了。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Arsha380"]
[OnName num="asha"]
'早上好!　Renji，让我们再过一个好日子。"
[cpg cn=true]


[OnName num="renzi"]
'啊，是的。虽然我没有什么任务要努力工作，'。
[cpg cn=true]


阿莎一直是个爱开玩笑的人，但我觉得她已经在绕圈子了。
[cpg]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





阿莎不知为何似乎也注意到了我所做的事情。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Arsha381"]
[OnName num="asha"]
'这是......，很好。我做到了。"
[cpg cn=true]


[OnName num="renzi"]
'你这话是什么意思？
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha382"]
[OnName num="asha"]
'你有没有想过，你将无法回到你的原形或什么？
[cpg cn=true]


[OnName num="renzi"]
'...... Dorothy告诉你的？你是一个健谈的人。"
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Arsha383"]
[OnName num="asha"]
'不。这是我的想象力。但听起来好像真的是这样。你不害怕吗？"
[cpg cn=true]


[OnName num="renzi"]
'我并不害怕这个。对阿莎来说，没有什么可害怕的。
[cpg cn=true]


阿莎笑了笑，拉着我的手。
[cpg]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha384"]
[OnName num="asha"]
'谢谢你。恋次，我爱你'。
[cpg cn=true]


仔细想想，我还没有正式表白。但我不再需要这些了。
[cpg]


我相信我不需要任何更多的话。
[cpg]

;//移植前シーンカット



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


那天晚上，我和阿霞聊了一会儿。然后这个话题就出现了。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha407"]
[OnName num="asha"]
'嘿，Renji。你已经学会了变成一个树人，对吗？
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha408"]
[OnName num="asha"]
'那么，你可以随心所欲地开花结果，不是吗？　听起来你可以制作无限多的灵药。"
[cpg cn=true]


[OnName num="renzi"]
'...... 的确如此。虽然我的身体可能会发生一些事情或其他事情。
[cpg cn=true]


但如果我们能做到这一点，我们就能解决疾病在地牢中传播的问题。
[cpg]

;//移植前シーンカット




;//その夜、俺はアーシャとベッドで話し込んでいた。
;//[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha429"]
[OnName num="asha"]
'我还是觉得变成树人，做药会比较好。这可能会非常有利可图'。
[cpg cn=true]


[OnName num="renzi"]
'这倒是真的，但你有很多从...... 人类那里掠夺的钱，不是吗？　在地牢里挣钱就没有什么意义了。"
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Arsha430"]
[OnName num="asha"]
'是的，有!　人类将无法触及我们。"
[cpg cn=true]



我注意到你这么说了，但这是事实。我觉得，能够建立友谊是有道理的。
[cpg]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





从那时起，我们开始制作灵药，并将它们卖给人类和恶魔部落。
[cpg]


不用我们做什么，地牢就变得很富裕。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice467"]
[OnName num="janice"]
'这是一个意想不到的副产品。我从未想过事情会发展到这一步。"
[cpg cn=true]


[OnName num="renzi"]
'哦。我也从未想象过'。
[cpg cn=true]


我们不再需要从入侵的冒险者那里掠夺，也不再有任何理由让我们去入侵他们。
[cpg]


结果，连人类和恶魔之间的战争都平静了下来。
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice468"]
[OnName num="janice"]
'现在也有一种解放库拉拉的趋势。如果没有了战斗的理由，那么有战俘就更糟糕了'。
[cpg cn=true]


[OnName num="renzi"]
'也许如此。只要克拉拉在那里，她可能会试着来帮忙'。
[cpg cn=true]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





结果，库拉拉也被释放，地牢里出现了真正的和平。
[cpg]


他们说，这都要归功于我，但这并不令人印象深刻。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha431"]
[OnName num="asha"]
'这要归功于Renji。要更加自信。"
[cpg cn=true]


[OnName num="renzi"]
我不知道该说什么。"
[cpg cn=true]


我最近开始打扮成兽人，以配合阿沙。
[cpg]


为了配合阿莎，我最近一直在打扮成兽人，但做一个长着兔子耳朵的人似乎并不适合我，所以我是一个犬类兽人。
[cpg]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha432"]
[OnName num="asha"]
'这些耳朵在你身上看起来不错。'不过，Renji在任何形式下都是好看的。
[cpg cn=true]


阿莎比以前更爱我了。
[cpg]


她认为她喜欢我，而不管我的体质如何。
[cpg]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





我们在晚上一起闲逛，就像每天一样。
;//＠→そして、夜になると毎日というくらいに二人愛し合った。
[cpg]



;//========================================
;//●ＣＧ（二人寄り添っている。ベッドに二人で腰掛けている感じ）ev_61
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公は犬っぽい獣人に化けています
;//=======================================


[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_61_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1500]

[SE f=se012]
;//【ＳＥ】『衣擦れ』

你永远不知道在这个世界上有什么可以用。当然，如果没有我的变身能力，也没有阿莎的发情倾向，就不会发生这种情况。
[cpg]



[VOICE f="Arsha433"]
[OnName num="asha"]
'嘿，Renji ...... 我们的相遇是缘分，不是吗？
[cpg cn=true]

;**【ＣＧ】 ev_61_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Arsha434"]
[OnName num="asha"]
'就像一切都为这一刻而联系在一起。自从我们第一次见面后，'。
[cpg cn=true]


当然，我觉得这也是命运。仿佛这一刻，现在我们在一起做爱，是不可避免的。
[cpg]


[OnName num="renzi"]
我也有这种感觉。阿莎的体质和其他所有东西都是为了这一刻而准备的，不是吗？
[cpg cn=true]

;**【ＣＧ】 ev_61_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sArsha033"]
[OnName num="asha"]
我一直讨厌自己。我是那个小气的人，爱上了每个人。
[cpg cn=true]



[VOICE f="Arsha436"]
[OnName num="asha"]
'但我觉得我现在可以喜欢自己了。当然，我最爱的是Renji。
[cpg cn=true]


当她说这句话时，她的笑容感觉与我看到的第一个笑容不同。
[cpg]

[SCENE id=21]


;//ＥＮＤ　ヒロイン４ルート

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="epend.ks" target="*start"]


;//==============================
