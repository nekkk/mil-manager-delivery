*start

;###################################################################
*Ep009|你将用你的身体来改变什么？
;###################################################################


[SCENE id=9]

[window target=false]


[BG f="black.ui"  time=1000]
[WAIT time=100]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]

[stflag Jumpflg = 0]


[if exp={getFlagValue("Jumpflg") == 0 }]
[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 0]
[stflag Cha4flg = 0]
[stflag Cha5flg = 0]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]
[endif]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="06"]
;//【ＢＧ】『平原』（昼）******************************************************


[OnName num="renzi"]
炫目的......"
[cpg cn=true]


我喃喃自语，但我很高兴能够作为一个人与自己交谈。
[cpg]


我已经很久没有打扮成人类了。带着某种振奋的心情，我向人类城市出发了。
[cpg]



[SE f=se020]
;//【ＳＥ】『草原歩く』

[window target=false]

[BG f="b_09_3.ui" time=1000]
[WAIT time=1500]

[window target=true]
;//【ＢＧ】『平原』（夕方）******************************************************





这并不是说我对自己的体能没有信心。我和其他人一样经常锻炼。
[cpg]


但我不知道转世后我的身体是否能在这个世界上生存。
[cpg]


事实上，我在行走方面没有任何问题，但仍有一种微妙的不适感。
[cpg]


毕竟，这可能是因为我曾经是一个恶魔。
[cpg]


不一会儿，太阳就落山了。我听说这个小镇位于一个一天之内无法到达的地方，所以我耐心地走了过去。
[cpg]


[SE f=se020]
;//【ＳＥ】『草原歩く』


[window target=false]

[BG f="b_09_4.ui" time=1000]
[WAIT time=1500]

[window target=true]
;//【ＢＧ】『平原』（夜）******************************************************





我们唯一的行李是钱和食物。我们没有带任何东西来营地。
[cpg]


在地牢和人类城镇之间有一个恶魔部落的定居点。
[cpg]


食人魔更像恶魔，而不是人类，根据杰尼斯的说法，它们不会是邪恶的。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『鬼の集落』（夜）******************************************************





[OnName num="renzi"]
...... 这里。
[cpg cn=true]


我们正处于食物的边缘。我们不可能为了省钱而停在这里。......。
[cpg]


不过，它看起来还是有点像旧日本。
[cpg]


这比呆在地牢里更让人放松。我想有一定量的阳光是很重要的。
[cpg]


[OnName num="demon_A"]
等等。你是谁？"
[cpg cn=true]


两个恶魔站在村子的入口处。他们是守门人。
[cpg]



[OnName num="demon_B"]
人类想要什么？我们不能允许你进入。
[cpg cn=true]


[OnName num="renzi"]
'不，我是一个恶魔。我是一个变形人，我来自.......'
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_01_1 ***********************
;//カットイン
[CUTIN f="ci_01_1.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


我决定解除变形，并揭示出我的第一个蛇形结构。
[cpg]


[CUTIN f="ci_01_1.ui" show={false} method="slideout"]
[WAIT time=1000]

恶魔们看起来对这个怪癖有些惊讶，但随后变得相当轻松。
[cpg]


我想这是因为我能够证明我不是人类。
[cpg]


[OnName num="demon_A"]
'...... demons, huh?你不应该像你那样与人类争吵'。
[cpg cn=true]


这不是一个我参与的关于这个的故事。但是......。
[cpg]


[OnName num="renzi"]
...... 是的。"
[cpg cn=true]


多么合适的回答，我决定被放进定居点。
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]




我又一次恢复了我的人形。这种形式比恶魔的形式更平静。
[cpg]


我想说的是，如果你想让你的朋友们知道你的情况，那么你就必须在你的朋友圈里写下你的名字。"我想说的是，如果你想让你的朋友们知道你的情况，那么你就必须在你的朋友圈里写下你的名字。
[cpg]


也许我觉得我会被允许留下来，但......。
[cpg]


[OnName num="renzi"]
对不起。......
[cpg cn=true]


我要在房子的前面呼唤。现在是晚上，但还没有到午夜。
[cpg]


如果恶魔住在房子里，我想他们会醒着，但没有人回答。
[cpg]


我挨家挨户走访。这就像旧日本一样，他们对陌生人的要求很严格。
[cpg]


有时门只开了一点，然后就关上了。
[cpg]


我几乎要气馁了，但我还是绕着房子走了一圈。......
[cpg]

[SE f=se009]
;//【ＳＥ】『歩く』

[window target=true]
[WAIT time=100]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『鬼の集落』（夜）******************************************************


;//暫く、サツキの名前欄を「鬼の娘」と隠してください


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Satuki001"]
[OnName num="demon_girl"]
'......，你是谁？　你看起来是人类，但你是怎么进来的？"
[cpg cn=true]


哦，哦，...... 对了，这就是为什么没有人让我进去。
[cpg]


如果你是人类，他们一开始就不应该让你进入定居点。
[cpg]


[OnName num="renzi"]
'我是一个恶魔。我可以直接变成一个人。......，我可以示范一下吗？'
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


[FACE method="change_5" pos="2/3"]

我显示自己是个妖精，食人魔很惊讶。
[cpg]



[VOICE f="Satuki002"]
[OnName num="demon_girl"]
'有这样的恶魔。我以前从未见过'。
[cpg cn=true]


[OnName num="renzi"]
'我也不太清楚是否有这样的恶魔。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Satuki003"]
[OnName num="demon_girl"]
'你是什么意思？
[cpg cn=true]


[OnName num="renzi"]
'我是这个世界的新人。我知道你不会相信我'。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki004"]
[OnName num="demon_girl"]
你能告诉我更多关于......？
[cpg cn=true]


这有点像他们对你感兴趣。很好，我还担心我不会被允许进入任何一所房子。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************



[SE f=se021]
;//【ＳＥ】『扉開く』



;//ここからサツキの名前欄を隠さないでください




[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki005"]
[OnName num="satsuki"]
'对不起，我自我介绍晚了。我的名字是Satsuki'。
[cpg cn=true]


[OnName num="renzi"]
'嗨。我的名字是Renji'。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Satuki006"]
[OnName num="satsuki"]
'我不能为你提供任何款待，但我至少可以让你住在这里。你饿了吗？"
[cpg cn=true]


[OnName num="renzi"]
我很有空，但我不知道...... 是否可以？
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Satuki007"]
[OnName num="satsuki"]
'对。'没有正常的恶魔会走到这一步。
[cpg cn=true]



[window target=true]
[WAIT time=100]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************



说完这句话，Satsuki离开了房间一次。
[cpg]


然后她给我带来了一些食物。我几乎要哭了，因为我想，也许我今天会呆在田里。
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Satuki008"]
[OnName num="satsuki"]
'谢谢你的长途跋涉。给你'。
[cpg cn=true]


[OnName num="renzi"]
'谢谢你。Bon appétit'。
[cpg cn=true]



[SE f=se011]
;//【ＳＥ】『食器の音』



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Satuki009"]
[OnName num="satsuki"]
'......，我想在这个定居点停留，你们也是要去人类的城市。
[cpg cn=true]


[OnName num="renzi"]
'是的。我只是有些事情要处理。"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki010"]
[OnName num="satsuki"]
他是在用他的能力来欺骗人类吗？
[cpg cn=true]


[OnName num="renzi"]
不，我真的只是需要买点东西。
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Satuki011"]
[OnName num="satsuki"]
'...... 是这样的吗？　如果我有你的能力，我就不会为了购物而试图使用它们。"
[cpg cn=true]


那是肯定的。我可以随意结束冲突，这是肯定的。
[cpg]


但这有点负担，就像侦查或什么.......。
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Satuki012"]
[OnName num="satsuki"]
'人类和恶魔之间的战争已经持续了很久。你不知道这件事吧？"
[cpg cn=true]


[OnName num="renzi"]
'是的。'我从一个不同的世界转世到这个世界。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Satuki013"]
[OnName num="satsuki"]
'我不知道该如何相信你，但如果是真的，那就是一场灾难。
[cpg cn=true]


的确如此。但我觉得比我在当下的时候更有活力。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki014"]
[OnName num="satsuki"]
'如果我可以随意改变我的形状，......，我可以做任何我想做的事情。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Satuki015"]
[OnName num="satsuki"]
'有了你的力量，也许一个和平的、不分裂的世界会到来。
[cpg cn=true]


[OnName num="renzi"]
......，你会同意吗？"
[cpg cn=true]


我们为什么要讨论这个问题？我不知道这样问是否合适。
[cpg]


[OnName num="renzi"]
'你坚持要谈论冲突与和平。发生了什么事？
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Satuki016"]
[OnName num="satsuki"]
'......，'。
[cpg cn=true]


浑浊的表情。不要强迫我约你出去。
[cpg]


[OnName num="renzi"]
'对不起。窥探'。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki017"]
[OnName num="satsuki"]
'没关系的。我也说了一些发人深省的话'。
[cpg cn=true]


沉默了一阵子。然后佐藤说。
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Satuki018"]
[OnName num="satsuki"]
'对人类。我恋爱了。"
[cpg cn=true]


这一个词让我有了一个大致的想法。因为人类不应该被允许进入这个定居点。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki019"]
[OnName num="satsuki"]
在这个冲突不断的世界上，很难做到团结一致。我想说这是不可能的。"
[cpg cn=true]


恶魔部落也被禁止前往人类定居点，而且可能再也见不到了，显然。
[cpg]


[OnName num="renzi"]
'...... 这是个艰难的世界，不是吗？
[cpg cn=true]


我很茫然，但我知道恶魔和人类之间发生冲突的情况并不乐观。
[cpg]


不仅仅是佐藤，全世界都会有各种各样的问题。
[cpg]


我想知道我们是否必须进行和平，否则其中一个种族将完全主宰世界。......
[cpg]


考虑到这一点，Satsuki进一步推动。
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Satuki020"]
[OnName num="satsuki"]
'你觉得怎么样？　你想用你的力量做什么？"
[cpg cn=true]


[OnName num="renzi"]
这是......"
[cpg cn=true]



;//■選択肢

[switch]
[case "用它来与人类建立和平。"]
	[swap]
	[jump target="*IseSel03_1"]
[case "用它来促进恶魔部落的繁荣。"]
	[swap]
	[jump target="*IseSel03_2"]
[endswitch]

1、用它来与人类和平相处。
2.用它来促进恶魔部落的繁荣



;//==============================
;//１、人間族との和平の為に使う
*IseSel03_1|何を変えるためにその身を使うのか




[OnName num="renzi"]
我仍然想用它来实现和平。"
[cpg cn=true]


这可能是为了我，为了地牢里的每个人，或者是为了佐藤。
[cpg]


[OnName num="renzi"]
我直到现在才好好想一想。谢谢你提醒我。"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki021"]
[OnName num="satsuki"]
'我什么都没做。我只是谈到了我希望和平会到来。"
[cpg cn=true]


她说这话时笑了起来，而且非常漂亮。
[cpg]


她有一种与多萝西和阿莎不同的美。她可能和珍妮丝有点接近。
[cpg]

[jump target="*IseSel03_3"]

;//==============================
;//２、魔族の繁栄の為に使う
*IseSel03_2|何を変えるためにその身を使うのか




[OnName num="renzi"]
'我欠恶魔部落的每一个人一份感激。我想报答他们'。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki022"]
[OnName num="satsuki"]
'是的。也许结束这场战斗的将是你'。
[cpg cn=true]


我只想为了魔族的利益使用我的力量。
[cpg]


我没有忘记我对多萝西、珍妮丝和阿莎的亏欠。
[cpg]


我想保护地牢和住在那里的恶魔部落。这些话是来自我的真实内心。
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Satuki023"]
[OnName num="satsuki"]
'你必须是一个善良的人。我有点能理解。
[cpg cn=true]


说这话时，Satsuki笑了起来。那是一个激动人心的微笑。
[cpg]



;//※変数+1
[stflag Gameflg = 1]



;//==============================

*IseSel03_3|何を変えるためにその身を使うのか



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************



我被要求留在会客厅，或者你们叫它什么。
[cpg]


那是在深夜。她可能也在睡觉。
[cpg]


不知何故，在这所房子里，除了她，没有任何人的迹象。......
[cpg]


我想知道她是否因为某些原因而独自生活。
[cpg]


但是，她仍然很美。我对她很好奇。
[cpg]


[SE f=se012]
;//【ＳＥ】『衣擦れ』

[OnName num="renzi"]
'Nn......？
[cpg cn=true]


当我正在睡觉时，一只猫向我走来。
[cpg]


它在我身上蹭来蹭去，我睡觉时拍拍它的头。
[cpg]


但一只猫怎么会跑到这样的私宅里来？
[cpg]


[OnName num="renzi"]
这让我有点困扰。"
[cpg cn=true]


我站起来，去看前门。
[cpg]


然后我看到门是开着的。我把猫放出来，然后把它关上。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





[OnName num="renzi"]
'...... 我想是的。......'
[cpg cn=true]


猫咪，猫咪？我有几个想法。
[cpg]


明天我就得跟她说再见了。想到这些，我不能什么都不做。
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[BG f="white.ui" time=1]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************



[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki024"]
[OnName num="satsuki"]
'变形金刚，你知道。我想知道他能走多远'。
[cpg cn=true]

;**【ＣＧ】ci_14_0 ***********************
;//カットイン
[CUTIN f="ci_14_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


他以一只猫的形式潜入她的房间。
[cpg]

[CUTIN f="ci_14_0.ui" show={false} method="slideout"]
[WAIT time=1000]


闻起来像花，像肥皂。我走近一看，觉得这一定是沙特人的气味。
[cpg]



[FACE method="change_5" pos="2/3"]
[VOICE f="Satuki025"]
[OnName num="satsuki"]
'那是......？　你是怎么来的？"
[cpg cn=true]


我化身为一只猫，假装是她。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki026"]
[OnName num="satsuki"]
'不，你不能未经允许就进入我的房子。
[cpg cn=true]


他温和地笑着说。但......
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Satuki027"]
[OnName num="satsuki"]
'Kya!　什么，什么？
[cpg cn=true]


我跳上了她的身体。她被吓了一跳，摔倒在地。
[cpg]



;//========================================
;//●ＣＧ（猫に変身した主人公。倒れ込んでいるヒロインに近づく）ev_05
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：和風の室内
;//時間　：夜
;//備考　：主人公は猫に変身しています
;//========================================

;//*Scene010
[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="10"]
;**【ＣＧ】 ev_05_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1500]



[VOICE f="Satuki028"]
[OnName num="satsuki"]
'你怎么了......，这么突然？
[cpg cn=true]


樱木惊讶地看着我。
[cpg]


她并不试图强迫我离开她。她认为我是一只猫。
[cpg]


我想这意味着我不能太粗暴地对待她。
[cpg]

;**【ＣＧ】 ev_05_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sSatuki001"]
[OnName num="satsuki"]
'你想让我不再让你一个人呆着吗......？
[cpg cn=true]

当她用手抚摸我的时候，我觉得我想被呵护。
[cpg]


我觉得不可能，连我的心都变成了猫。......
[cpg]


我眼中的景象，或者说是我面前的佐藤，毫不含糊地是佐藤爱着一只猫。
[cpg]

;**【ＣＧ】 ev_05_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sSatuki002"]
[OnName num="satsuki"]
'好吧，好吧。现在我要去睡觉了，我不能让你一个人呆着。
[cpg cn=true]


然而，......，无论你在这种形式下如何宠爱她，似乎都没有意义。
[cpg]


例如，没有办法看到她只对她有感觉的人表现出的那种表情。
[cpg]


在这方面，也有一种徒劳的感觉。
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="07"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************




[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Satuki055"]
[OnName num="satsuki"]
'晚安。猫'。
[cpg cn=true]

[FO pos="2/3" time=1000]
[SE f=se012]
;//【ＳＥ】『衣擦れ』

随着一个个欲望的满足，Satsuki似乎睡着了。
[cpg]


我离开她的房间，回到我之前所在的房间。
[cpg]



;//ここからしばらく、サツキのセリフ名前欄を「サツキ（蓮司）」と置き換えてください




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="07"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************




但我无法入睡。我的眼睛是清醒的，而不是......
[cpg]


一想到我可能会变身为Satsuki，就更难控制自己了。
[cpg]


她就在我旁边，我本来可以闻到她的气味，但我不知道。
[cpg]



;////////////////////////
;////////////////////////
;//三度目の変身システム//
;////////////////////////
;////////////////////////


;//選択肢用フラグ
[stflag IseSel04flg = 0]

我确信第一种气味是......
[cpg]


[switch]
[case "香草。"]
	[swap]
	[jump target="*hen41"]
[case "水果"]
	[swap]
	[jump target="*hen41"]
[case "花卉"]
	[swap]
	[stflag IseSel04flg = 1]
	[jump target="*hen41"]
[endswitch]


*hen41|何を変えるためにその身を使うのか


第二种气味是......
[cpg]



[switch]
[case "薄荷。"]
	[swap]
	[jump target="*hen42"]
[case "香水"]
	[swap]
	[jump target="*hen42"]
[case "肥皂"]
	[swap]
	[stflag IseSel04flg = 1]
	[jump target="*hen42"]
[endswitch]

*hen42|何を変えるためにその身を使うのか


[window target=true]

[WAIT time=100]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FACE method="out" pos="4/7"]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="04"]


[window target=true]


[if exp={getFlagValue("IseSel04flg") == 2 }]
[jump target="*IseSel04_2"]
[endif]


[jump target="*IseSel04_1"]

;//■選択肢Ａ
1、香草
2、水果
3, 鲜花

;//■選択肢Ｂ
4、Mint
5、香水
6、肥皂。





;//==============================
;//３、花　６、石けん　を選んでいた場合
*IseSel04_2|何を変えるためにその身を使うのか



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[FG f="CHA05_p4_01_a.ui" method="change_1"  pos="2/3" time=1]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;//【ＢＧ】『ヒロイン５の家＿室内』（夜）


我也是这么想的，但看来我的担心是没有根据的。我也可以变成Satsuki。
[cpg]

在这种形式下，我仍然想看到自己。
[cpg]


但这个房间里没有镜子。我别无选择，只能观察我从自己身上能看到的东西。
[cpg]

;//移植前シーンカット


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//ヒロイン５ルートの可能性が残る

[jump target="*IseSel04_3"]



;//==============================
;//３、花　６、石けん　のいずれかを外した場合
*IseSel04_1|何を変えるためにその身を使うのか



我还是不能肯定地记得。没有办法改造自己。
[cpg]


我没有选择，所以我带着朦胧的头脑进入了梦乡。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//ヒロイン５ルートの可能性がなくなる

[stflag Cha5flg = -1]

;//==============================

*IseSel04_3|何を変えるためにその身を使うのか





[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ヒロイン５の家＿室内』（朝）******************************************************



第二天早上。我从羽绒被里站起来。
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Satuki083"]
[OnName num="satsuki"]
'早上好。我希望你睡得好。"
[cpg cn=true]


[OnName num="renzi"]
'是的。谢谢你。
[cpg cn=true]


樱木甚至已经准备好了早餐。为什么她要为我做这么多？
[cpg]


我不知道她对恶魔和人类之间的和平是否有很高的期望。
[cpg]


吃完饭后，我环顾房间说。
[cpg]


[OnName num="renzi"]
你是这个房子里唯一的人，不是吗？
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Satuki084"]
[OnName num="satsuki"]
'是的。'我的父亲和母亲都死得很早。
[cpg cn=true]


[OnName num="renzi"]
'......，我明白了。
[cpg cn=true]


我想，也许这与爱上一个人有一点关系。
[cpg]


我一个人住，我不知道我一个人住了多久了。我觉得那里有东西。
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep010.ks" target="*start"]

