*start

;###################################################################
*Ep010|変身はやっぱり最強でした
;###################################################################


[SCENE id=10]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]

[stflag Jumpflg = 0]


[if exp={getFlagValue("Jumpflg") == 0 }]
[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 0]
[stflag Cha4flg = 0]
[stflag Cha5flg = 0]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]
[endif]



[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『鬼の集落』（朝）******************************************************





[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Satuki085"]
[OnName num="satsuki"]
'再见。希望你是安全的。"
[cpg cn=true]


[OnName num="renzi"]
'谢谢你。'再见。
[cpg cn=true]


我决定离开鬼子的村庄。
[cpg]


我已经恢复了足够的力量。这意味着我可以走一阵子。
[cpg]

[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="06"]
[window target=true]
;//【ＢＧ】『平原』（朝）******************************************************




当我离开村子的时候，眼睛所能看到的又是一片平原。
[cpg]


这是个奇怪的世界。每个地区的风景都是不同的。
[cpg]


一定有与地牢中的城镇以及与恶魔定居点不同的城镇。
[cpg]


[BG f="b_09_2.ui" time=1000]
[WAIT time=1000]

[window target=true]
;//【ＢＧ】『平原』（昼）******************************************************



[SE f=se003]
;//【ＳＥ】『平原歩く』




当我带着这样的想法走近小镇时，路上的人越来越多。
[cpg]


我想知道他们是否也要去地牢。当我在想这个问题时。
[cpg]


[OnName num="man"]
'你看起来像是在从地牢回来的路上。情况如何？"
[cpg cn=true]


[OnName num="renzi"]
'不，不。我只是跑回来了'。
[cpg cn=true]


[OnName num="man"]
你看起来不错，......，好吧。"
[cpg cn=true]


虽然他们有点怀疑，但他们并不怀疑我是人类的事实。
[cpg]


我的转变是完美的。我将能够步行进城。
[cpg]


还有。最后，或者说......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="03"]
;//【ＢＧ】『街』（夕方）******************************************************


[SE f=se008]
;//【ＳＥ】『喧噪』


我们来到了人类居住的城市。风景就像一个城市。
[cpg]


它与我所处的现代世界如此不同。我不像见过中世纪的欧洲，但又有点不同。
[cpg]


街上的人穿着不同，有些人穿得像巫师，有些人则像精灵。
[cpg]


[OnName num="renzi"]
'目前，我们需要一个住宿的地方。
[cpg cn=true]


有大量的钱。这是从一个刚到的冒险家那里拿的，所以它可以作为货币使用。
[cpg]


我决定在一个合适的地方获得住宿。
[cpg]

[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[stopse g=3]
;//通常se

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]

[window target=true]
;//【ＢＧ】『街』（夜）******************************************************





[OnName num="Shopkeeper"]
'我不能接受这么多.......你是谁？"
[cpg cn=true]


[OnName num="renzi"]
'什么？　呃，啊，...... eh。"
[cpg cn=true]


硬币上刻有数字，但我可能把其中一个零放错了。
[cpg]


或者也许有两种不同的货币？
[cpg]


[OnName num="Shopkeeper"]
'哦，好吧。只要你付账，我们会让你住在我们的地方。
[cpg cn=true]


[OnName num="renzi"]
哦，谢谢你。"
[cpg cn=true]


我尽量不说太多，以免看起来可疑。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="01"]
;//【ＢＧ】『街』（朝）******************************************************





我对我所做的一切都感到紧张，但这并不是关于我是否是一个恶魔的问题，这是很可疑的。
[cpg]


他们对我是什么样的人感到怀疑。那就好了。
[cpg]


早上我出去买了他们要我买的魔法装备。然后我去了......
[cpg]



[VOICE f="Clara003"]
[OnName num="clara"]
'这里的商品质量总是很好。
[cpg cn=true]


我在店里听到一个熟悉的声音，看到一个熟悉的身影。
[cpg]



[FACE method="feadin_up" pos="4/7"]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]

[WAIT time=1500]


[OnName num="salesperson"]
'你对我这么说，克拉拉。我很高兴'。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara004"]
[OnName num="clara"]
他说："这些箭现在非常罕见。我很高兴能在这里买到它们。"
[cpg cn=true]


克拉拉。是的，她不就是我告诉你的那个勇敢的女人吗？
[cpg]


我被她的美丽所吸引。当我第一次见到她时，我没有好好看她，因为那是一个紧张的场景。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara005"]
[OnName num="clara"]
那我就回来了。
[cpg cn=true]


......，让我想做一些事情。是那种微笑。
[cpg]


当然，如果我在这样的城市里变成一个恶魔，这将是一件大事。
[cpg]


但我现在是人，为什么我不能利用这个优势呢？
[cpg]


首先，我被要求扮演的角色是针对人类的侦查。
[cpg]


如果我可以欺骗库拉拉，让她成为战俘，那就没什么好说的了。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="03"]
;//【ＢＧ】『街』（昼）******************************************************


在我下定决心后，我迅速行动起来。
[cpg]


虽然动机不纯，但我也感觉到，如果我把库拉拉俘虏了，我就能做很多事情。
[cpg]


首先，我听说那里有一个冒险家出没的酒吧，所以我先在那里收集信息。
[cpg]


[OnName num="adventurer_A"]
'库拉拉？　她怎么了？"
[cpg cn=true]


[OnName num="renzi"]
'不，不。我只是想加入她的聚会。
[cpg cn=true]


我的策略是这样的。我设法进入她的聚会，然后在最后一刻背叛了她。
[cpg]


[OnName num="adventurer_B"]
'Kulara女士在云端，......，如此轻松，我怀疑她会雇用一个新的同事。
[cpg cn=true]


[OnName num="adventurer_A"]
'但他们说有一个人离开了库拉拉的聚会。
[cpg cn=true]


[OnName num="renzi"]
你能告诉我更多吗？"
[cpg cn=true]


我一边听着谈话，一边听说一个与库拉拉合作的男剑客发生了某种争执。
[cpg]


这是件好事。如果我能够复制他的外表，我就可以换人了。
[cpg]


然后我就可以带着一定程度的信任开始。该计划似乎正在发挥作用。
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="07"]
;//【ＢＧ】『街』（夕方）******************************************************





[OnName num="swordfighter"]
'来自库拉拉的信使？　我不会再和他争吵了。"
[cpg cn=true]


[OnName num="renzi"]
'是的。这很好。...... 呃'。
[cpg cn=true]


要转型，你必须闻到这个人的味道。
[cpg]


也就是说，如果我走近他并嗅了嗅他，那就很可疑了。
[cpg]


也许这就足以确定我是一个变形人。...... 那么。
[cpg]


[OnName num="renzi"]
'我想买这把剑。你以前用的那把剑。"
[cpg cn=true]


[OnName num="swordfighter"]
'为什么不呢？　这是一把没有名字的剑。
[cpg cn=true]


幸运的是，有足够的钱。而这把剑上会有他的气味。
[cpg]


我有点觉得自己是一只警犬或什么，但交易成功了。
[cpg]



[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



最后，光是获取那个剑客的信息，寻找他并改造他，就花了一整天的时间。
[cpg]


但回报似乎是值得的。
[cpg]


我还买了安眠药给库拉拉闻，以备不时之需。
[cpg]


这可能是用于恶魔的东西。我很容易得到它。......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="03"]
;//【ＢＧ】『街』（昼）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Clara006"]
[OnName num="clara"]
我没有想到你会回来。"
[cpg cn=true]


[OnName num="renzi"]
......"
[cpg cn=true]


尽可能地避免扯皮。最好是装作不说话。
[cpg]


你听起来应该是心情不好，因为你遇到了一些麻烦。
[cpg]


[OnName num="monk"]
'你确定吗？如果他又回来了，一定是有原因的'。
[cpg cn=true]


一位女祭司，似乎是克拉拉的同伴，说。她的打扮可以说是一个姐妹。
[cpg]


而我仍然一如既往地保持沉默。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara007"]
[OnName num="clara"]
'我不会打听得太深，但你必须在适当时候告诉我。
[cpg cn=true]


但是，近距离看，她还是更加美丽。
[cpg]


如果我能够继续走向深渊，并在我心力交瘁、无奈回头的时候背叛她，我就能......。
[cpg]


我有点心动了，但我看起来闷闷不乐。
[cpg]


从此，下一次潜入地宫的时间也很快被安排好了。
[cpg]


她在店里布置了一些东西，可能正打算马上前往那里。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="06"]
;//【ＢＧ】『平原』（昼）******************************************************

[SE f=se020]
;//【ＳＥ】『草原歩く』

我们一行有四个人，包括我和克拉拉。
[cpg]


一个是女和尚。我认为她可能是一个治疗师 .......
[cpg]


我们知道，这个世界上有魔法。或者说，我也被它的力量所改造。
[cpg]


另一个是像我一样的战士型人。然而，他似乎处理的是长矛而不是剑。
[cpg]


看来他是被雇来填补失踪的剑客的空缺的。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

而库拉拉本人既是魔术师又是弓箭手。
[cpg]


我可以想象，他擅长远距离作战，这意味着一旦他被抓，似乎不太可能逃脱。
[cpg]


[OnName num="warrior"]
'......，我没有想到你们四个会来。我被雇佣来代替你的位置。"
[cpg cn=true]


[OnName num="renzi"]
显然是这样。"
[cpg cn=true]


[OnName num="monk"]
是什么风把你吹回来的？"
[cpg cn=true]


在去地牢的路上。有人问我一个问题，我必须回答。
[cpg]


[OnName num="renzi"]
'怎么了？　我回来只是因为我需要钱。"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara008"]
[OnName num="clara"]
'......，你不是说你要接管家族企业吗？
[cpg cn=true]


[OnName num="renzi"]
'嗯，那是......'。
[cpg cn=true]


这些故事并不吻合。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『平原』（夜）******************************************************





去地牢的路很远。即使你在一个食人魔村庄停下来，他们也不会让人类进入。
[cpg]


我们不得不在路上露营，但我无法回答他们在那里问我的问题。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clara009"]
[OnName num="clara"]
从那时起，你提到的那些伤口怎么样了？
[cpg cn=true]


[OnName num="renzi"]
'哦。'变冷的时候还是很疼的。
[cpg cn=true]


[OnName num="monk"]
'当天气变冷时......？　你是什么意思？"
[cpg cn=true]


[OnName num="renzi"]
什么？"　这就是为什么有疤痕。"
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Clara010"]
[OnName num="clara"]
'我以为你说你有一颗破碎的心。'你的心在变冷时也会痛吗？
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


不，不，不，你只是把心碎称为伤口吗？
[cpg]



我甚至认为你把手帕放在我身上是因为我有嫌疑。
[cpg]


我设法用我的猜测来糊弄人。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="07"]
;//【ＢＧ】『平原』（昼）******************************************************


[SE f=se020]
;//【ＳＥ】『草原歩く』


地牢临近。当我们向它走去时，每个人都非常安静，几乎无声无息。
[cpg]


这是由于紧张，还是库拉拉族人从一开始就这样？
[cpg]


还是他们都对我有戒心？
[cpg]


如果是这样，与其说我让库拉拉人成为囚犯，不如说我可以成为他们的囚犯。
[cpg]


他们不会从我这里得到它，但即使如此，他们也不会逃脱。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************

[SE f=se009]
;//【ＳＥ】『歩く』



此外，我实际上无法驾驭一把剑。即使我可以，我也不可能挥舞着剑对付一个魔族同胞。
[cpg]


每个人都问我出了什么问题。我解释说，我的手臂很钝，但我很痛苦。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clara011"]
[OnName num="clara"]
「……」
[cpg cn=true]


他们认为我拖累了他们。或者他们认为我本身就是一个恶魔。
[cpg]


[FO pos="2/3" time=1000]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト




但结果是，我及时坚持住了。
[cpg]


我想这意味着他们很怀疑，但不相信。
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/5" time=800]
[VOICE f="Janice114"]
[OnName num="janice"]
'所以你在这里。库拉拉，让我兑现我长期以来的怨恨。"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="4/5" time=800]
[VOICE f="Clara012"]
[OnName num="clara"]
'你是魔王的亲密伙伴。别担心，你不用再记恨了。"
[cpg cn=true]


珍妮丝正在领先，她身后有很多恶魔。


恶魔和库拉拉人继续在一定距离内瞪着对方。
[cpg]


我决定现在是背叛他们的时候了。现在她在我身后毫无防备。
[cpg]

[FO pos="2/5" time=500]
[FO pos="4/5" time=500]

[SE f=se012]
;//【ＳＥ】『衣擦れ』

我走近库拉拉，让她闻闻我藏起来的安眠药。
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Clara013"]
[OnName num="clara"]
'什么？　唉，什么......啊。"
[cpg cn=true]



[OnName num="warrior"]
这家伙......！"
[cpg cn=true]



战士举起他的长矛。他瞄准了我。
[cpg]


[FACE method="change_4" pos="2/3"]

克拉拉回头看了看我，她的眼睛空洞无神。
[cpg]


[FO pos="2/3" time=800]
[SE f=se016]
;//【ＳＥ】『倒れる』

[WAIT time=1500]


该药已经生效。我决定逃跑。
[cpg]


我的身体是安全的，不会被长矛刺穿，这意味着......
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_06_0 ***********************
;//カットイン
[CUTIN f="ci_06_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

经过一番思考，我变成了一种粘液。
[cpg]


然后，我溜之大吉，朝恶魔那边走去。
[cpg]

[CUTIN f="ci_06_0.ui" show={false} method="slideout"]
;//[WAIT time=1000]

[OnName num="monk"]
'我觉得它看起来很奇怪，但它是一个恶魔。......
[cpg cn=true]

[SE f="se026"]
;//【ＳＥ】『魔法』

和尚正在念某种咒语。光线汇聚在她的手上。
[cpg]


然后它变成一束光，在我身上释放，但珍妮丝站在它的前面。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Janice115"]
[OnName num="janice"]
'恋次！　你快跑吧！"
[cpg cn=true]


我甚至不能以这种形式点头。而其他所有的恶魔都立刻向库拉拉走去。
[cpg]


库拉拉的朋友们会怎么看呢？　他们会不会通过携带克拉拉和逃亡来做到这一点？
[cpg]



[OnName num="monk"]
'这对你来说不是好......，库拉拉小姐。
[cpg cn=true]


[OnName num="warrior"]
'让我们退一步。我们无法独自拖住他们。"
[cpg cn=true]




[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





结果，恶魔们似乎抓住了库拉拉。
[cpg]


我也不能把所有的功劳都归于自己。......。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Dorothy111"]
[OnName num="dorothy"]
'干得好，Renji!　我不相信我抓住了那个勇敢的女人。"
[cpg cn=true]


[FACE method="change_2" pos="2/5"]
[VOICE f="Janice116"]
[OnName num="janice"]
'一点也不。我不相信他们能在我们不知道的情况下做到这一点'。
[cpg cn=true]


桃乐丝和珍妮丝对我赞不绝口。
[cpg]


他们似乎也对这一点相当真诚地感到高兴。我并不感到难过。
[cpg]


[OnName num="rudolf"]
'我想我没有弄错。我知道有一天你会尽到你的责任。
[cpg cn=true]


[OnName num="renzi"]
「ありがとうございます」
[cpg cn=true]


[FACE method="change_6" pos="4/5"]
[VOICE f="Dorothy112"]
[OnName num="dorothy"]
'真的，那个勇敢的人让我很难受。...... Renji，非常感谢你。
[cpg cn=true]


[OnName num="renzi"]
'哦，不。我只是做了我能做的事。"
[cpg cn=true]

[SE f=se012]
;//【ＳＥ】『衣擦れ』

[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/5" time=1]
[VOICE f="Dorothy113"]
[OnName num="dorothy"]
'你也很谦虚，这很酷。我喜欢它。"
[cpg cn=true]


桃乐丝在坚持我。而魔王看到后并没有过多地皱眉。
[cpg]

[FACE method="change_1" pos="2/5"]

我就做了这么多，这就是我的意思。但......
[cpg]


现在克拉拉会怎么样？
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=1]

[OnName num="rudolf"]
'我必须让你拿你的奖励。你有什么想说的吗？"
[cpg cn=true]


[OnName num="renzi"]
「それは……」
[cpg cn=true]





;//■選択肢
[switch]
[case "很高兴能为您提供服务。"]
	[swap]
	[jump target="*IseSel05_1"]
[case "我希望你能尊重克拉拉。"]
	[swap]
	[jump target="*IseSel05_2"]
[endswitch]


1、很高兴能为您提供服务。
第二，我希望你能礼貌地对待库拉拉。



;//==============================
;//１、役に立てて嬉しい
*IseSel05_1|转化仍然是最强大的。




[OnName num="renzi"]
'奖励，没有这样的事。我很高兴能为大家服务'。
[cpg cn=true]


毕竟，我不觉得赞美有什么不好。
[cpg]


我决定为恶魔部落多做一些事情。
[cpg]


我甚至可能做一些有点欺骗性的事情。
[cpg]


[OnName num="rudolf"]
'...... 是的。我让你去审问那个库拉拉。"
[cpg cn=true]


[OnName num="renzi"]
什么？"
[cpg cn=true]


[OnName num="rudolf"]
'我想知道人类方面发生了什么。也许我们可以从她那里得到一些东西。"
[cpg cn=true]


[OnName num="rudolf"]
'通过任何必要的手段。你能为我做这件事吗？"
[cpg cn=true]


[FACE method="change_7" pos="4/5"]

多萝西不解其意。她似乎不知道自己在说什么，但这无疑是对我作为一个男人的奖励。
[cpg]


[OnName num="renzi"]
'我明白。我会处理好的。"
[cpg cn=true]




;//※変数+1
[stflag Gameflg = 1]

[jump target="*IseSel05_3"]

;//==============================
;//２、クラーラを丁重に扱って欲しい
*IseSel05_2|转化仍然是最强大的。




[OnName num="renzi"]
'......，请不要对库拉拉太粗暴。
[cpg cn=true]


[FACE method="change_5" pos="4/5"]
[VOICE f="Dorothy114"]
[OnName num="dorothy"]
'你在说什么呢？　我采取了一个肩膀来依靠。
[cpg cn=true]


[OnName num="renzi"]
'不。即使是库拉拉也是为了一个原因而战斗。
[cpg cn=true]


[FACE method="change_3" pos="4/5"]
[VOICE f="Dorothy115"]
[OnName num="dorothy"]
哦，不!　我不能原谅库拉拉，她是唯一一个为了什么原因杀死我的朋友的人。"
[cpg cn=true]



[OnName num="rudolf"]
'我同意你的观点。但如果你告诉我不要对你动粗，......"
[cpg cn=true]


[OnName num="rudolf"]
我可以让你去审问她吗？
[cpg cn=true]



[OnName num="renzi"]
它是......
[cpg cn=true]


[OnName num="rudolf"]
'我想知道人类方面发生了什么。但如果你想精心对待他们，那就做你想做的。"
[cpg cn=true]


[OnName num="renzi"]
"...... 是的。"
[cpg cn=true]



;//==============================

*IseSel05_3|変身はやっぱり最強でした


[OnName num="rudolf"]
'传言说她对触角类动物有一种弱点。
[cpg cn=true]


[OnName num="rudolf"]
'我让你来决定你要如何使用这些信息。我就指望你了。"
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





所以我被任命为审讯克拉拉的人。
[cpg]


这并不是一个沉重的负担，但我对它的突然性感到惊讶。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Arsha132"]
[OnName num="asha"]
'桃乐丝，你一定很高兴。
[cpg cn=true]


[OnName num="renzi"]
那是，嗯...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha133"]
[OnName num="asha"]
'我也为你感到高兴。我们已经抓住了我们的宿敌。
[cpg cn=true]


[OnName num="renzi"]
也就是说，......，这是一件很懦弱的事情。"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha134"]
[OnName num="asha"]
'每个人都很高兴，即使是懦弱的。我们不必害怕他们何时会入侵。
[cpg cn=true]


...... 这当然是真的？生命危在旦夕，即使是恶魔。
[cpg]


这对阿莎来说可能也是如此。
[cpg]


如果是这样的话，她是否必须在一定程度上对库拉拉放任不管？
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


而在第二天。我正在前往关押库拉拉的地方的路上。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Clara014"]
[OnName num="clara"]
'...... 你是......'
[cpg cn=true]


我看起来像当时的剑客，这样人们就会知道那是我。
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara015"]
[OnName num="clara"]
'你欺骗了我。假装是人类'。
[cpg cn=true]


[OnName num="renzi"]
'哦。'没有难受的感觉。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara016"]
[OnName num="clara"]
'是的。因为这是我的失败。"
[cpg cn=true]


你有一个相当干净的性格。但你的身体正在为之颤抖。
[cpg]


也许他在想他们要对他做什么。
[cpg]


[OnName num="renzi"]
'人类方面要对我们恶魔做什么？　我们要铲除他们吗？"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara017"]
[OnName num="clara"]
'郑重声明，我对你们这些人没有什么可说的。
[cpg cn=true]


[OnName num="renzi"]
'......，我明白了。
[cpg cn=true]


好了，我们开始吧。我怎样才能让她开口呢？
[cpg]

;//＠尋問ということなら、何かいやらしいことをしてやりたい気持ちはある。彼女は、触手が苦手だと言っていたな。
如果你是指审讯，我倾向于做一些色情的事情。你说她不善于使用触手。
[cpg]


[OnName num="renzi"]
她说的不善于使用触手是真的吗？
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Clara018"]
[OnName num="clara"]
我不知道。"
[cpg cn=true]


他不是不知道，但他不打算告诉我。
[cpg]


我有一套可以在这种情况下变身的触角生物的剧目。
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_15_0 ***********************
;//カットイン
[CUTIN f="ci_15_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

[FACE method="change_5" pos="2/3"]
[VOICE f="Clara019"]
[OnName num="clara"]
'Hiccup ......！
[cpg cn=true]


它们变成了触角，似乎有吸盘。克拉拉被吓坏了。
[cpg]

[CUTIN f="ci_15_0.ui" show={false} method="feadout"]
[WAIT time=1000]

'不要难过，'他在心中喃喃自语，同时向她逼近。
[cpg]


;//========================================
;//●ＣＧ（触手に変身した主人公がヒロインを尋問する。くすぐり責め）ev_14
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：ダンジョン＿室内
;//時間　：暗い
;//備考　：主人公は吸盤のあるような触手生物の姿に変身しています
;//========================================

;//*Scene012

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="10"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1500]



[SE f=se015]
;//【ＳＥ】『触手・スライム』


[VOICE f="Clara020"]
[OnName num="clara"]
'放开我，......，如果你这样对我，我就不说话。
[cpg cn=true]


她在某些方面显得很粗壮，但她的反应也表明她可能确实对触角类生物感到不舒服。
[cpg]

;**【ＣＧ】 ev_14_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Clara021"]
[OnName num="clara"]
'哦，......，这样的恶魔，如果我有武器就好了！'
[cpg cn=true]





我以前和女孩调皮过几次，但这次和其他任何一次调皮都不同。
[cpg]


她显然对抵抗毫无用处。所以她怎么反抗都无所谓。
[cpg]


这是那种让你想对她刻薄的人物，或者类似的东西。
[cpg]


另一方面，我也不想对她太粗暴，或者类似的事情。
[cpg]

;**【ＣＧ】 ev_14_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Clara022"]
[OnName num="clara"]
'现在，我还是会原谅你，......，请让我走。
[cpg cn=true]


克拉拉的语气仍然很强硬，不管她是否原谅了我。
[cpg]


这并没有让我想放弃，但它确实让我想做点什么。
[cpg]

[SE f=se015]
;//【ＳＥ】『触手・スライム』


[VOICE f="sClara001"]
[OnName num="clara"]
'你在摸我，哈，哈，好痒啊.......'
[cpg cn=true]


克拉拉畏缩不前，试图逃跑，但无法做到。
[cpg]

;**【ＣＧ】 ev_14_c ***********************
[CG id=5 index=3 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sClara002"]
[OnName num="clara"]
'停，停，唉唉，......'
[cpg cn=true]


我不停地给她挠痒痒，但她从未笑过。看来她在这方面还是相当糟糕。
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





但似乎她真的不喜欢触角。我想知道这其中是否有什么原因。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Clara044"]
[OnName num="clara"]
'Haa, haa......, ah.
[cpg cn=true]


她的额头上有汗珠。你现在可以责备她。......
[cpg]


我是要把我的力量用在我身上。让我们休息一下，好吗？
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]





我又把自己伪装成一个人，告诉她。
[cpg]


[OnName num="renzi"]
'请。告诉我你所知道的一切，这对我们两个人都好。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara045"]
[OnName num="clara"]
'我对......，无话可说'。
[cpg cn=true]


平行线。我这一次背对着她。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



库拉拉有一个瞭望台。我不能轻易逃脱。
[cpg]


她还会被送上一些食物。如果她死了，那就没有意义了。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy116"]
[OnName num="dorothy"]
进展如何？　你从克拉拉那里得到什么了吗？"
[cpg cn=true]


[OnName num="renzi"]
'不，不。到目前为止还没有。"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy117"]
[OnName num="dorothy"]
'我明白了。毕竟，Renji看起来很善良。
[cpg cn=true]


[OnName num="renzi"]
'......'
[cpg cn=true]


的确，这是不可否认的。行为不端是一回事，为了从他们身上得到什么而指责是另一回事。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy118"]
[OnName num="dorothy"]
'你想让我替你接管吗？　如果是我，我会毫不留情。"
[cpg cn=true]


桃乐丝说了一些可怕的事情。的确，我认为她看起来很无辜，但却不依不饶。
[cpg]


会有怨恨。克拉拉开口后，她还会继续指责。
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Dorothy119"]
[OnName num="dorothy"]
'什么，你的脸？我没有那么鲁莽'。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy120"]
[OnName num="dorothy"]
'不过，可能比留给珍妮丝要好。
[cpg cn=true]


[OnName num="renzi"]
'也许如此，但......，不，我怀疑。
[cpg cn=true]


我很害怕这两个人。珍妮丝会采取一种不引人注目但却稳操胜券的方法。
[cpg]


与桃乐丝相比，她还是可能比较理性的。......
[cpg]


我仍然是这个工作的合适人选。我重新考虑了这个问题。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



我再次向克拉拉的住处走去。
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Clara046"]
[OnName num="clara"]
「……」
[cpg cn=true]


克拉拉正朝我的方向瞪眼。
[cpg]


我知道她对我来说是个可恨的对手，但话说回来，库拉拉对所有恶魔来说都是可恨的对手。
[cpg]


[OnName num="renzi"]
'为什么库拉拉决定与恶魔作战？
[cpg cn=true]


她保持沉默，看着我们。
[cpg]


你不是真的想说什么，是吗？她的挑衅相当耐人寻味。
[cpg]


[OnName num="renzi"]
'哦，好吧。我会强迫她说话'。
[cpg cn=true]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

[FACE method="change_5" pos="2/3"]



当她再次变成一个触角状的生物时，她吓坏了。
[cpg]


看到她害怕，我就想做点什么。......
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="sClara003"]
[OnName num="clara"]
'请，......，不要再做任何事情。
[cpg cn=true]


;//ブラックアウト

我做了一连串的审问，但她还是什么都不说。
[cpg]


我觉得我就快到了。......
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

我再次恢复成人形，问她。
[cpg]


[OnName num="renzi"]
'你想做什么？　如果你仍然希望我这样做，我很乐意。
[cpg cn=true]


[OnName num="renzi"]
'我可以永远陪着你。整个晚上都是如此。"
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Clara072"]
[OnName num="clara"]
'嗨-......，那是...'
[cpg cn=true]


克拉拉想象着，叫了几声。
[cpg]


[OnName num="renzi"]
'嘿，克拉拉。你不能想着背叛人类。
[cpg cn=true]


[OnName num="renzi"]
'我做我必须做的事情来拯救我自己。这不是很正常吗？
[cpg cn=true]


我会试着从精神上动摇他。
[cpg]


克拉拉看起来很失落，然后说话了。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara073"]
[OnName num="clara"]
'......，我明白。我将告诉你我所知道的。"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[OnName num="rudolf"]
'嗯。我明白了。......"
[cpg cn=true]


奔向魔王，我向他汇报。
[cpg]


[OnName num="renzi"]
'是的。'人类方面也不希望发生重大冲突。
[cpg cn=true]


我们能够从库拉拉身上得到的是，人类也不希望发生冲突。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Janice117"]
[OnName num="janice"]
'那么我们就没有什么可做的了。
[cpg cn=true]


[OnName num="rudolf"]
'当然了。我不想把事情搞得一团糟'。
[cpg cn=true]


魔鬼们也在想同样的事情，如果没有冲突，那么就没有什么可做的了。
[cpg]


[OnName num="rudolf"]
'无论如何，你做得很好。我也要更好地对待你'。
[cpg cn=true]


[OnName num="renzi"]
谢谢你。"
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=2000]
[WAIT time=2100]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=2000]
[WAIT time=2100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


从那以后，我的房间变得更适合居住。
[cpg]


我从未被分配到一个不同的房间，但家具更好。
[cpg]


床上用品是松软的。仅仅这一点就使我的动机发生了很大的变化。
[cpg]


地牢里的东西有限，但他们正在为我转身。
[cpg]


[OnName num="renzi"]
'...... 吁。
[cpg cn=true]


和平可能会持续一段时间。然后我只有一件事要考虑。
[cpg]


我想发明更多的恶作剧。我不可能因为和平而感到厌烦。
[cpg]



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep011.ks" target="*start"]


