*start


;###################################################################
*Ep012|変わる身体と変わらないもの
;###################################################################


[SCENE id=12]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]

[stflag Jumpflg = 0]


[if exp={getFlagValue("Jumpflg") == 0 }]
[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 0]
[stflag Cha4flg = 0]
[stflag Cha5flg = 0]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]
[endif]



[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************

[SE f=se008]
;//【ＳＥ】『喧噪』



[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha192"]
[OnName num="asha"]
'又是黑脸。怎么了？"
[cpg cn=true]


[OnName num="renzi"]
'......，我最好变成一个不知道怎么看的人。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha193"]
[OnName num="asha"]
如果你这样做，我就知道你更加郁闷了。"
[cpg cn=true]


[OnName num="renzi"]
我明白了。......
[cpg cn=true]


阿莎可以看穿它。她不只是认识我，她会认识所有人。
[cpg]


我不能在那里说什么，尽管我知道我不是她的对手。
[cpg]


[OnName num="renzi"]
'我很好。我没有抑郁症。
[cpg cn=true]


我希望如此，"阿莎回答道。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





日子在似乎是僵持中继续。然后来了一位不速之客。
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]

[VOICE f="Satuki086"]
[OnName num="satsuki"]
'很高兴见到你。我的名字是佐藤志野。
[cpg cn=true]


[OnName num="rudolf"]
'你不必如此深深地鞠躬。所有的恶魔都是这样的吗？
[cpg cn=true]


[FACE method="change_2" pos="2/5"]
[VOICE f="Dorothy170"]
[OnName num="dorothy"]
'我听说了，是吗？　人类也有不同的文化。
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[FACE method="change_3" pos="4/5"]
[VOICE f="Satuki087"]
[OnName num="satsuki"]
我今天在这里传递一个人的信息。
[cpg cn=true]


[OnName num="renzi"]
"人类对......？"
[cpg cn=true]


我不知道为什么我被邀请参加这个重要的会议。我没有资格去团结像珍妮丝和其他人一样的人。
[cpg]


;//[FACE method="change_3" pos="4/5"]
[VOICE f="Satuki088"]
[OnName num="satsuki"]
'他们想要回被俘的女英雄。
[cpg cn=true]


[OnName num="rudolf"]
'我本以为如此，但没有交换条件，我不能这样做。
[cpg cn=true]


从那时起，就开始了艰难的讨价还价。我真的无法跟上它。
[cpg]


例如，以物换人是很困难的。
[cpg]


一旦你把库拉拉还给人类，很明显，他们会来报复的。
[cpg]


而且很难找到能够平衡失去库拉拉的事情。......
[cpg]


[FACE method="change_4" pos="4/5"]
[VOICE f="Satuki089"]
[OnName num="satsuki"]
'你不明白吗？'这意味着整个寄宿的恶魔部落都开始不耐烦了。
[cpg cn=true]


[OnName num="rudolf"]
'我知道，但这并不意味着我必须这样做。
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/5" time=800]
[VOICE f="Janice157"]
[OnName num="janice"]
'一点也不。'为了魔族的利益而做'，这不是一个交易的破坏者。"
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





樱木，而不是恶魔部落的首领，独自骑马进来的事实说明了一切。
[cpg]


樱木个人希望有一个所有种族都能没有分裂地生活的世界。
[cpg]


或者，也许每个人都想这样做，但萨托克没有足够的卡片。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy171"]
[OnName num="dorothy"]
'这个女孩Satsuki似乎认识Renji。
[cpg cn=true]


[OnName num="renzi"]
'真的吗？　你没有这么说。"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy172"]
[OnName num="dorothy"]
'我看到他瞥了一眼Renji。就像他在等待一艘救援船一样'。
[cpg cn=true]


哦，......，我明白了。这就是樱木所期待的？
[cpg]


这是件坏事。也就是说，我不能突然告诉她，她应该让库拉拉走。
[cpg]


从恶魔部落的角度来看，他们是一直在伤害他们的朋友。我自己也无能为力。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





这是一种僵局，每个人都处于停滞状态。似乎不仅仅是我。
[cpg]


樱木可能试图摆脱它。但这并没有发生。
[cpg]


多萝西和珍妮丝可能已经不耐烦了，想从库拉拉身上得到更多的东西，而库拉拉将继续忍受下去。
[cpg]


甚至阿莎可能也希望......，这场战斗结束。
[cpg]


我是我，我不能继续重复这些诡计。
[cpg]


每个人都有自己的问题，但我们好像无能为力，总之我们就像陷入了僵局。
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





由于某种原因，我在房间里坐不住了，所以我离开了房间。
[cpg]


在这种僵局中，人们所做的是重复他们以前做过的事情。
[cpg]


我对他们每个人都玩了一个愚蠢的恶作剧。
[cpg]


渐渐地，人们会开始意识到，这就是我的工作。而这并不是唯一的问题。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha194"]
[OnName num="asha"]
'嘿，一只狗......，在这样的地方做什么？
[cpg cn=true]



他又变成了一条狗，这次是朝阿莎的地方走去。
[cpg]


也许她会接受我。但......
[cpg]


无论你是接近痴情的阿莎、天真的多萝西还是出奇胆小的珍妮丝，都是如此。
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=2000]
;//ブラックアウト





仅仅是调皮并不代表着爱。
[cpg]


我最后所想的是，我希望有人爱我。
[cpg]


想到这里，我向克拉拉的住处走去。
[cpg]

[BG f="b_04_5.ui" time=1000]
[WAIT time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Clara096"]
[OnName num="clara"]
'不管我来多少次，都是一样的。我绝不会向你们中的任何一个人屈服'。
[cpg cn=true]


要想被库拉拉喜欢，那是相当困难的。
[cpg]


我们已经和她对着干了，对她也不好。
[cpg]


我也不能说我与佐藤的关系是友好的。
[cpg]


当时我应该向她伸出援手。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



恰恰是在这样的时候，我感到有些仓促。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Arsha195"]
[OnName num="asha"]
'嘿，Renji。你现在打算怎么做？"
[cpg cn=true]


[OnName num="renzi"]
'......，你是什么意思？
[cpg cn=true]


我脑子里只有一件事。
[cpg]


我希望有人能爱我。有了这种变形能力，这也许是可能的。
[cpg]


例如，我可以成为他们喜欢看到的样子。......
[cpg]


[FACE method="change_3" pos="2/5"]
[VOICE f="Janice158"]
[OnName num="janice"]
'我还想问一下。我假设你原来是人类。
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Arsha196"]
[OnName num="asha"]
'你要作为一个恶魔生活吗？　还是你仍然想作为一个人活着？"
[cpg cn=true]


有了这种力量，我也许能解决他们的一些问题。
[cpg]


但基本的前提是住在哪里的问题。
[cpg]


我现在是一个恶魔。但我原本是人类。
[cpg]


地牢里的生活很有趣，但人类生活的城市也有其魅力。
[cpg]





;//■選択肢
[switch]
[case "我想住在地牢里。"]
	[swap]
	[jump target="*IseSel06_1"]
[case "我想离开地牢。"]
	[swap]
	[jump target="*IseSel06_2"]
[endswitch]


1、我想住在地牢里。
2、我想离开地牢。



;//==============================
;//１、ダンジョンの中で暮らしたい
*IseSel06_1|変わる身体と変わらないもの


[OnName num="renzi"]
我仍然对这个地方有感情。"
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[VOICE f="Janice159"]
[OnName num="janice"]
'对。这让人松了一口气'。
[cpg cn=true]


有很多人欠我很多，我必须要报答他们。
[cpg]


即使我和某人结合在一起，我也不想离开地牢。
[cpg]



;//※変数+1
[stflag Gameflg = 1]

[jump target="*IseSel06_3"]

;//==============================
;//２、ダンジョンを出たい
*IseSel06_2|変わる身体と変わらないもの



[OnName num="renzi"]
'我还在考虑这个问题。
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Janice160"]
[OnName num="janice"]
'对。好吧，不急于给你一个答案'。
[cpg cn=true]


珍妮丝说，但她不能告诉他她的真实感受。
[cpg]


我在想我可能不会坚持做地下城。
[cpg]


我对人类和恶魔种族越来越感兴趣了。
[cpg]


具体而言，我对库拉拉和萨特基也很感兴趣。
[cpg]



;//==============================

*IseSel06_3|変わる身体と変わらないもの



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



此后的一段时间里，他整天对女孩们进行恶作剧。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Dorothy173"]
[OnName num="dorothy"]
'那天的事情，那绝对是恋次，不是吗？
[cpg cn=true]


[OnName num="renzi"]
你在说什么？"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy174"]
[OnName num="dorothy"]
感觉就像...... 羽绒被在移动。"
[cpg cn=true]


[OnName num="renzi"]
我一定是在做梦。"
[cpg cn=true]


我想，这真是一种朦胧。
[cpg]


我想知道如果有一天我和谁绑在一起了。
[cpg]


珍妮丝，阿莎向我表示感谢。
[cpg]


至于桃乐丝，我甚至觉得自己被宠坏了。
[cpg]


就被感谢而言，我可能可以把克拉拉从这里弄出去。
[cpg]


我也许能够解决佐藤的问题。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Dorothy175"]
[OnName num="dorothy"]
...... 嘿，为什么Renji会有这样的恶作剧？"
[cpg cn=true]


[OnName num="renzi"]
我没有。"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Dorothy176"]
[OnName num="dorothy"]
'让我问你。你这样做是因为你喜欢我吗？"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy177"]
[OnName num="dorothy"]
还是你喜欢别人，这真的只是一个恶作剧？"
[cpg cn=true]


桃乐丝抓住了问题的核心。
[cpg]




我意识到自己的想法，即我想被谁爱。
[cpg]




;//ゲームフラグを確認、人鬼か、魔王軍か

[if exp={getFlagValue("Gameflg") == 3 }]
;//魔王軍へ
[jump target="*chackgame"]
[endif]

[if exp={getFlagValue("Gameflg") == 2 }]
;//魔王軍へ
[jump target="*chackgame"]
[endif]


;//人鬼
;=======================================

[if exp={getFlagValue("Cha5flg") == 0 }]
;//クラーラルートへ
[jump storage="ep013.ks" target="*start"]
[endif]


[switch]
[case "克拉拉。"]
	[swap]
	[jump storage="ep013.ks" target="*start"]
[case "樱木。"]
	[swap]
	[jump storage="ep017.ks" target="*start"]
[endswitch]

;=======================================


*chackgame|変わる身体と変わらないもの


*devil|変わる身体と変わらないもの

;//魔王軍
;=======================================


;//ヒロイン３のフラグ
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*Cha3"]
[endif]


;//ヒロイン４のフラグ
[if exp={getFlagValue("Cha4flg") == 1 }]
[jump target="*Cha4"]
[endif]



;//ドロシールートへ
[jump storage="ep014.ks" target="*start"]


;-------------------------------------------
;//ヒロイン３のフラグだけが立ってたなら
*Cha3|变化的身体和不变的事物

;//ヒロイン４のフラグ
[if exp={getFlagValue("Cha4flg") == 1 }]
[jump target="*ChaAll"]
[endif]

[switch]
[case "ドロシー"]
	[swap]
	[jump storage="ep014.ks" target="*start"]
[case "ジャニス"]
	[swap]
	[jump storage="ep015.ks" target="*start"]
[endswitch]


;---------------------------------------------
;//ヒロイン４のフラグだけが立ってたなら
*Cha4|変わる身体と変わらないもの


[switch]
[case "桃乐丝。"]
	[swap]
	[jump storage="ep014.ks" target="*start"]
[case "アーシャ"]
	[swap]
	[jump storage="ep016.ks" target="*start"]
[endswitch]



;------------------------------------------------
;//３人ののフラグが立ってるなら
*ChaAll|变化的身体，不变的事物

[switch]
[case "桃乐丝。"]
	[swap]
	[jump storage="ep014.ks" target="*start"]
[case "珍妮丝。"]
	[swap]
	[jump storage="ep015.ks" target="*start"]
[case "阿沙。"]
	[swap]
	[jump storage="ep016.ks" target="*start"]
[endswitch]





;=======================================




;//【転】
;//※ここまでの選択肢で、変数が２以上ならばヒロイン１、ヒロイン５は選択肢に出てこない
;//変数が１以下ならばヒロイン２、ヒロイン３、ヒロイン４は選択肢に出てこない

;//更に、今までの変身システムで正答を選ばなかったヒロインは選択肢に出てこない
;//ヒロイン１、ヒロイン２のうちいずれかは必ず選択肢に出てくる
;//ヒロイン１、ヒロイン２のうちいずれかしか残っていない場合、選択肢は発生せずそのルートにそのまま進む



;//デバッグ用
*debug

[switch]
[case "克拉拉。"]
	[swap]
	[jump storage="ep013.ks" target="*start"]
[case "ドロシー"]
	[swap]
	[jump storage="ep014.ks" target="*start"]
[case "珍妮丝。"]
	[swap]
	[jump storage="ep015.ks" target="*start"]
[case "阿沙。"]
	[swap]
	[jump storage="ep016.ks" target="*start"]
[case "樱木。"]
	[swap]
	[jump storage="ep017.ks" target="*start"]
[endswitch]

1、Kulara。
2、桃乐丝。
3、珍妮丝。
4、阿沙。
5、佐佐木。



;//==============================
