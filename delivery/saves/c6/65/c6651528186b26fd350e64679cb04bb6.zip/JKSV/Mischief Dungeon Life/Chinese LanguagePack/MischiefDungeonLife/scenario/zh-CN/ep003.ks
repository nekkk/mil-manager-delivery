*start

;###################################################################
*Ep003|这就是我们使用转化的方式。
;###################################################################


[SCENE id=3]

[window target=false]



;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]



[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



[window target=true]


从那时起，我以不止一种形式生活，因为我可以有许多不同的形式。
[cpg]


当我在食堂时，我听到了恶魔们的各种故事。
[cpg]


[OnName num="goblins_A"]
'杰尼斯大师，你太酷了。他们说你没有女朋友是真的吗？
[cpg cn=true]


[OnName num="goblins_B"]
来吧，......，我想你是对的。"
[cpg cn=true]


我听到一些有点令人不安的声音，我呆在那里，假装是粘液。
[cpg]


珍妮丝正坐在远处吃饭。它是以地精的形式瞥见的。
[cpg]


[OnName num="goblins_A"]
'以她的勇敢，很难找到一个能与她匹配的男人。
[cpg cn=true]

[OnName num="goblins_B"]
好吧。有了这样一个完美的战士。......"
[cpg cn=true]


[OnName num="goblins_B"]
'但我听说杰尼斯大师对鬼魂不是很在行。
[cpg cn=true]


哎呀。这是我以前从未听说过的信息。
[cpg]


[OnName num="goblins_A"]
'是的，我以前肯定听说过。我想幽灵们正在哀叹'。
[cpg cn=true]







[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[window target=true]

鬼族，以至于有一个鬼族的部落。
[cpg]


还是他们原本就是不同的恶魔而不是一个种族？
[cpg]


无论怎样，他们都在那里。而且他们可以变成他们。
[cpg]


它既不是无机物，也不是不可描述的。我想法律毕竟是不存在的。
[cpg]


还有其他种类的亡灵，但它们不能变成僵尸。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[window target=true]


;**【ＣＧ】ci_08_0 ***********************
;//カットイン
[CUTIN f="ci_08_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

然后我又以幽灵的形式回到了餐厅。
[cpg]

[CUTIN f="ci_08_0.ui" show={false} method="slideout"]
[WAIT time=1000]

[OnName num="renzi"]
珍妮丝在哪里？
[cpg cn=true]


[OnName num="goblins"]
'嗯？　是的，看起来你现在已经得到了一些休息。我想他已经回他的房间了。"
[cpg cn=true]


珍妮丝也被分配了一个房间。考虑到这一点，我走到了通往包房的走廊上。
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』


;//ブラックアウト



我不知道珍妮丝的房间在哪里，但我在走廊上看到她在我前面。
[cpg]


我从后面跟着她。当我一个人的时候，我会试图吓唬她。
[cpg]


如果她真的不喜欢鬼，她会很惊讶的。......
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice014"]
[OnName num="janice"]
'风：......'
[cpg cn=true]


在她独自回到房间的路上，有人听到她在叹气。
[cpg]


她一定是处于幕僚长的位置，所以她一定经历了很多困难。
[cpg]


我觉得有点抱歉，让她受到这样的惊吓。
[cpg]


[SE f=se012]
;//【ＳＥ】『衣擦れ』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice015"]
[OnName num="janice"]
'Nn......？
[cpg cn=true]


当我们回到我的房间时，我偷偷地和他们一起进去。然后珍妮丝转过身来。
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Janice016"]
[OnName num="janice"]
'哇！'
[cpg cn=true]


一看到我，珍妮丝就变得弯腰驼背，瘫软在地。
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Janice017"]
[OnName num="janice"]
'为什么，这里有一个...... 鬼。
[cpg cn=true]


他给我的声音很颤抖，他为我感到害怕。
[cpg]


[OnName num="renzi"]
'......'
[cpg cn=true]


我已经把他们吓跑了，但我们现在该怎么办呢？
[cpg]


珍妮丝的脸色如此苍白，不做点什么似乎是一种耻辱。
[cpg]


鬼魂能接触人吗？　我也想试试这个。
[cpg]



;//========================================
;//●ＣＧ（へたりこんで、怯えきっているヒロイン）ev_07
;//人物１：ヒロイン３　服装１：私服
;//人物ex：主人公　　　服装ex：無し
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公は幽霊に変身しています　半透明で青白く、人型です
;//========================================

;//*Scene002

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="10"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1500]




[VOICE f="Janice018"]
[OnName num="janice"]
'库，不要来这里！'。　走吧！"
[cpg cn=true]


珍妮丝一直是一个表情从不改变的人，所以当你这样看她的时候，有一种差距。
[cpg]


我更加靠近她，想着这个问题。
[cpg]


尽管我现在是个鬼魂，但我仍然能够说话。
[cpg]


但如果我说话，她可能就不会再受惊吓了。
[cpg]


我走近她，想象着鬼魂是这样的。
[cpg]

;**【ＣＧ】 ev_07_a ***********************
[CG id=1 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice019"]
[OnName num="janice"]
'停止......，啊，原谅我.......'
[cpg cn=true]


她的声音很弱，很难想象是来自她的正常声音。
[cpg]


这也是一种挑逗，让我更想虐待她。
[cpg]


如果我现在碰她，会发生什么？或者说，如果她被我碰了一下，她会有什么感觉？
[cpg]

;**【ＣＧ】 ev_07_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice020"]
[OnName num="janice"]
'嗨!　不要碰我啊。"
[cpg cn=true]


当我触摸到她的皮肤时，感觉到我的皮肤很热。
[cpg]


这意味着这边的体温一定在下降，但奇怪的是，我这具骨骼的身体竟然有触觉。
[cpg]


;**【ＣＧ】 ev_07_b ***********************
[CG id=1 index=2 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sJanice001"]
[OnName num="janice"]
;//「あっ、ああっ、冷たいっ……もう、やめてくれ」
'很冷，......，不要再对我做什么了。
[cpg cn=true]

而从珍妮丝的角度来看，她似乎仍然很冷淡。
[cpg]


我一直吓唬她，希望她不要发现我是谁。
[cpg]


;//移植前シーンカット



[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト


珍妮丝稍稍平静下来，正试图起身。
[cpg]


[VOICE f="Janice039"]
[OnName num="janice"]
'你知道当你这样做时，...... 会发生什么。
[cpg cn=true]




哦，不，我想，我试图移开一点。
[cpg]



[VOICE f="Janice040"]
[OnName num="janice"]
'嗯，等等！'
[cpg cn=true]

[SE f=se010]
;//【ＳＥ】『走る』

[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


我赶紧回到通道，然后在她看不到的地方把自己伪装成一个石像鬼。
[cpg]


我以为她会立即跟着我，但她一定是在改变，她花了很长时间。
[cpg]


然后她来找我，但她直接从我身边走过。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[OnName num="renzi"]
也许这就是最强的力量......？"
[cpg cn=true]


回到我的房间后，我喃喃自语。
[cpg]


一般来说，它不是最强大的。但它有助于我实现我的目的。
[cpg]


我想接近漂亮女孩已经很久了。[cpg]


我目前没有什么可以变成的剧目，但我觉得我可以做更多的事情。
[cpg]


而且我知道一点小小的恶作剧并不会惩罚我。
[cpg]


毕竟，我是魔族的未来。我觉得即使我做了一些鲁莽的事情，也是可以的。
[cpg]



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="ep004.ks" target="*start"]



