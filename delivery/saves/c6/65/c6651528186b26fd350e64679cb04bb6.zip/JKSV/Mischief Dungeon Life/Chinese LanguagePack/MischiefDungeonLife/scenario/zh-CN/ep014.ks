*start

;###################################################################
*Ep014|你不能用转型做什么。
;###################################################################
;//２、ドロシー

[SCENE id=14]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out" pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out" pos="3/5"]


[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]


[window target=true]


......I 喜欢桃乐丝。
[cpg]



我现在不能这么说，只要当事人就在我面前。但我心中有一个坚定的意向。
[cpg]


[FACE method="change_5"  pos="2/3"]
[VOICE f="Dorothy201"]
[OnName num="dorothy"]
'...... 什么？　你为什么盯着我看？"
[cpg cn=true]


[OnName num="renzi"]
'不，不。任何东西都可以'。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





在这一点上，多萝西和我没有再说话。
[cpg]


我想把我的想法说清楚。我认为这种希望多萝西爱我的感觉是真实的。
[cpg]


我想亲自了解一下原因。
[cpg]


[OnName num="renzi"]
「……」
[cpg cn=true]


第一个认识到我的力量的人，我想。
[cpg]


我还觉得，在我成功抓获库拉拉之后，多萝西喜欢上了我。
[cpg]


这可能是她喜欢我，因为她喜欢我。
[cpg]


即使是现在，多萝西也会时不时地接近我，毫无疑问，她至少是在想念我。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





有一天，当我在花时间思考这个问题时。
[cpg]


[OnName num="renzi"]
'那么，今天桃乐丝和珍妮丝都不在这里？
[cpg cn=true]


[OnName num="rudolf"]
哦。我必须请你坐下来，是有原因的。"
[cpg cn=true]


我是被魔王召唤来的。我在等他说话，想知道我是否做错了什么。
[cpg]


[OnName num="rudolf"]
'你对我的女儿有什么看法？
[cpg cn=true]


[OnName num="renzi"]
'...... 在什么意义上，先生？
[cpg cn=true]


[OnName num="rudolf"]
'不，不。恐怕我已经绕了一圈'。
[cpg cn=true]


[OnName num="rudolf"]
'如果你真的想和我女儿发生关系，请做好准备。
[cpg cn=true]


......，我走在了我认为要做的事情的前面。
[cpg]


目前，与桃乐丝最接近的异性肯定是我。这就是为什么魔王会这样说。
[cpg]


[OnName num="renzi"]
'准备，我是说......'。
[cpg cn=true]


[OnName num="rudolf"]
'这意味着你将成为下一个魔王。你能认真支持桃乐丝吗？
[cpg cn=true]


我陷入了沉默。嗯，你当然会。
[cpg]


我还没有准备好走那么远，但我真的很喜欢桃乐丝。
[cpg]


如果有必要，我当然要接受，尽管我不认为我是做魔王的合适人选。
[cpg]


[OnName num="renzi"]
'我已经准备好了。如果你想让我成为魔王，我就会成为。
[cpg cn=true]


[OnName num="rudolf"]
'对。那是我肩上的一个重担。
[cpg cn=true]


恶魔之主只是微微一笑。我想我以前从未见过他笑。
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



我认为这意味着他是被父亲认可的，我想。
[cpg]


最后，这种爱别无选择，只能成真。我不打算放弃。
[cpg]


如果是这样的话，我们必须从填平外部护城河开始。......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FACE method="feadin_up" pos="4/7"]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





;//[FG f="CHA02_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sDorothy003"]
[OnName num="dorothy"]
'......?　哦，我有两件这样的衣服吗？"
[cpg cn=true]


我认为，到目前为止，填补外部护城河的想法很普遍。
[cpg]


但要变成她熟悉的东西，不是每个人都能做到的。
[cpg]


这就是为什么我想知道她的爱好是什么。
[cpg]


;//[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy203"]
[OnName num="dorothy"]
好吧，无所谓。......
[cpg cn=true]

[SE f=se012]
;//【ＳＥ】『衣擦れ』

[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=1000]
洗完澡后，她穿上了衣服。靠近她，闻起来很香。
[cpg]


希望我能听到她自言自语，或与其他人交谈。
[cpg]

[SE f=se019]
;//【ＳＥ】『ノック』
[WAIT time=1100]


[VOICE f="Janice169"]
[OnName num="janice"]
'公主。我可以吗？"
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Dorothy204"]
[OnName num="dorothy"]
'好的--我很好。什么？"
[cpg cn=true]



[FO pos="2/3" time=1]

[SE f=se023]
;//【ＳＥ】『ドア閉まる・開く』




[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=1000]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=1000]

[VOICE f="Janice170"]
[OnName num="janice"]
'最近来自人类的入侵较少。所以我们正在考虑更换我们的耕作官员和看守人。"
[cpg cn=true]


珍妮丝正在咨询多萝西是否要向魔王求婚。
[cpg]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy205"]
[OnName num="dorothy"]
'是的，这很好。祝你好运'。
[cpg cn=true]


桃乐丝似乎对这个不太感兴趣。这并不像她或其他什么人。......
[cpg]


[FACE method="change_3"  pos="1/2"]
[VOICE f="Janice171"]
[OnName num="janice"]
"...... 当然。"
[cpg cn=true]


这是我与珍妮丝的唯一一次谈话。她没有告诉我任何我特别想知道的事情。
[cpg]

[FO pos="1/2" time=800]
[FO pos="2/2" time=800]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





然后。多萝西并没有特别的独白。
[cpg]


;//[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Dorothy206"]
[OnName num="dorothy"]
'晚安......'
[cpg cn=true]


而我已经在努力入睡了。按照这种速度，我们永远也无法从他身上得到什么。
[cpg]


我认为变成她的样子是浪费时间，我想知道我是否至少可以为她做些什么。
[cpg]


;//移植前シーンカット



[window target=false]

[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





第二天早上，在痛苦中。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy226"]
[OnName num="dorothy"]
'嗯，......，还是很困。
[cpg cn=true]


多萝西慢慢地站起来。我在同一时间醒来。
[cpg]


在睡梦中是不可能解除转变的。如果是这样的话，我就不能转化为任何东西。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************




[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Dorothy227"]
[OnName num="dorothy"]
'早上好。阿莎，你今天想要什么？
[cpg cn=true]


[FACE method="change_2"  pos="1/2"]
[VOICE f="Arsha205"]
[OnName num="asha"]
'嗯，我有一些...... 活鱼在那里，我不知道。
[cpg cn=true]


地宫里的活鱼......？　他们是否从其他地方采购？
[cpg]


还是我们在谈论在某个池塘里种植它们？
[cpg]



[FACE method="change_1"  pos="2/2"]
[VOICE f="Dorothy228"]
[OnName num="dorothy"]
'鱼，嗯？我最近没有吃任何东西，所以它可能是个好东西。
[cpg cn=true]


透过她的衣服，她可以隐约看到阿霞。
[cpg]


Dorothy和Asha是好朋友。她可能和珍妮丝也是好朋友。
[cpg]


我不知道，但我不知道是不是两个人，阿沙和珍妮丝：......
[cpg]


而一旦你知道这一点，我可以采取的策略就不会有太大变化。
[cpg]


[FO pos="1/2" time=1000]
[FO pos="2/2" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



然后多萝西看了看修炼室等，然后去找魔王。
[cpg]



[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Dorothy229"]
[OnName num="dorothy"]
'...... 爸爸。我做了一个最奇怪的梦。
[cpg cn=true]


[OnName num="rudolf"]
什么样的梦？"
[cpg cn=true]


窃听父母与子女的谈话。尽管他的良心很痛苦，但他无法在此时此地解除转变。
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy230"]
[OnName num="dorothy"]
'我和Renji在一起。我非常惊讶，他竟然出现在我的梦中'。
[cpg cn=true]


不，我不允许这么说。我只是在想，。
[cpg]


[OnName num="rudolf"]
我明白了。"
[cpg cn=true]


而当魔王听到这句话时，他的反应很简单。
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy231"]
[OnName num="dorothy"]
'从你父亲的角度看，你怎么想？　你认为我们很匹配吗？"
[cpg cn=true]


[OnName num="rudolf"]
'...... 不要问我。我不能回答'。
[cpg cn=true]


这一定很复杂，就像流沙中的父亲一样。出现了短暂的沉默。
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





当我听到这句话时，我忍不住上了心.......。
[cpg]


那天晚上，当我在浴室里脱下衣服的那一刻，我穿着衣服离开了这里。
[cpg]


我很高兴没有人发现我。如果有人发现我在更衣室里穿着衣服爬来爬去，这将是一件大事。
[cpg]



[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FACE method="out" pos="4/7"]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


我不想变成衣服。即使我可以留在她身边，我也无法看到她。
[cpg]


所以我决定把自己伪装成她房间里的一把椅子。
[cpg]


她经常阅读。在此期间，我可以做一些事情。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy232"]
[OnName num="dorothy"]
嘿，......，我动了椅子吗？"
[cpg cn=true]


多萝西洗完澡回来，一边说一边点头。
[cpg]


我想这可能是坏事，但多萝西点了点头，笑了一下。
[cpg]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Dorothy233"]
[OnName num="dorothy"]
'这都是你的想法，不是吗？'是的，是的。昨天晚上也没有发生什么奇怪的事情'。
[cpg cn=true]


...... 你已经被发现了。在明显的基础上，多萝西坐在我身上。
[cpg]



;//========================================
;//●ＣＧ（椅子になってヒロインを観察する主人公。ヒロインは編み物をしている）ev_37
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公は椅子に化けています
;//=======================================

;//*Scene031
[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="10"]
;**【ＣＧ】 ev_37_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1500]





她似乎在瞥见我，而我已经变成了一把椅子。
[cpg]


但我不能确定哪里允许我做什么。
[cpg]



[VOICE f="Dorothy234"]
[OnName num="dorothy"]
'......，我应该怎么做？也许我会做一些编织工作'。
[cpg cn=true]


桃乐丝这样说，好像她敢于让我听。
[cpg]


我，一个字也说不出来，无法确定。
[cpg]


我什么也没做，想知道该怎么做。
[cpg]

;**【ＣＧ】 ev_37_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Dorothy235"]
[OnName num="dorothy"]
'现在要得到新书并不容易。......。
[cpg cn=true]


多萝西的独白越来越多。这可能是因为她已经意识到我是一把椅子。
[cpg]


或者，也许她也意识到我是一件衣服时。
[cpg]


我只是更加困惑，不知道发生了什么事。
[cpg]


而对多萝西来说可能也是如此。她在选择她想让我听到的内容，以独白的形式。
[cpg]

;**【ＣＧ】 ev_37_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sDorothy004"]
[OnName num="dorothy"]
Haa......，做一个恋爱中的少女是很难的。"
[cpg cn=true]


[VOICE f="sDorothy005"]
[OnName num="dorothy"]
'（Renji，我不知道他是否要做什么。我，我在等你）'。
[cpg cn=true]


;//ブラックアウト

[VOICE f="sDorothy006"]
[OnName num="dorothy"]
'我想我也会暂时离开编织工作。
[cpg cn=true]


独白的不自然之词。说完后，她不再坐下。
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Dorothy253"]
[OnName num="dorothy"]
...... 晚安。 " 
[cpg cn=true]


这个晚安不是一个独白。它是针对我的。
[cpg]


他在某种程度上已经原谅了我。他甚至可能希望我在他身边。
[cpg]


但我不认为我现在可以向她表白，并与她相爱。
[cpg]


我也害怕如果我强迫自己接近他，他就会拉开距离。
[cpg]




;//ブラックアウト


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


第二天早上，我再次伪装成多萝西的衣服，等着她给我穿上。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Dorothy254"]
[OnName num="dorothy"]
'嗯 ...... rn, rn。
[cpg cn=true]


桃乐丝的心情总是很好。她是否为自己离我越来越近而高兴？
[cpg]


这可能是一个有点太方便的解释，但......
[cpg]


看到她高兴，我也很高兴。
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



还有食堂。当我吃完饭，和阿莎聊天的时候，她已经下班了。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Dorothy255"]
[OnName num="dorothy"]
'哈哈。'这很艰难。
[cpg cn=true]


[FACE method="change_6"  pos="1/2"]
[VOICE f="sArsha017"]
[OnName num="asha"]
这并不好笑。......，桃乐丝不会知道不能只和你爱的人相爱是什么感觉。"
[cpg cn=true]


他们在谈论这样的话题。这是一个只有两个女孩可以谈论的话题。
[cpg]


[FACE method="change_4"  pos="2/2"]
[VOICE f="sDorothy007"]
[OnName num="dorothy"]
'是的，我想是的。我是一个一心一意的人。
[cpg cn=true]


我想知道'一心一意的......'这个词指的是谁。
[cpg]


;//qwe

;//移植前シーンカット




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



像这样说话......我意识到我已经忘记了我的初衷。
[cpg]



仔细想想，我是想知道桃乐丝喜欢什么。我已经忘记了最重要的事情。
[cpg]

;//ブラックアウト

就在我脱衣服的时候，我再一次溜出了她的房间。
[cpg]


[OnName num="renzi"]
'我们应该怎么做...... 哦，是的。
[cpg cn=true]


我灵机一动，试图把自己伪装成她身边的人。
[cpg]


即使在半夜，珍妮丝也会到多萝西的房间来。
[cpg]


仅仅把自己伪装成一个物体不会让你有任何进展。如果我把自己伪装成与多萝西关系密切的珍妮丝，我就可以向她提问。
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



;//ここからしばらく、ジャニスのセリフ名前欄を「ジャニス（蓮司）」と置き換えてください



一旦我决定这样做，我就迅速采取行动。
[cpg]

[SE f=se019]
;//【ＳＥ】『ノック』

[WAIT time=1500]

;//[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Janice172"]
[OnName num="renzi_to_janice"]
'公主。我现在可以进来了吗？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Dorothy274"]
[OnName num="dorothy"]
'好的。进来吧'。
[cpg cn=true]


[FO pos="2/3" time=1000]


我不知道珍妮丝是如何与多萝西交谈的。
[cpg]


但我仍然想约她出去。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA03_p4_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Janice173"]
[OnName num="renzi_to_janice"]
'你有过恋爱经历吗，...... 公主？
[cpg cn=true]


我决定采取直截了当的方法。如果你在这里走错了路，被发现的风险会增加。
[cpg]


[FACE method="change_4"  pos="2/2"]
[VOICE f="Dorothy275"]
[OnName num="dorothy"]
'怎么了，突然间。珍妮丝，我爱上了一个人'。
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Janice174"]
[OnName num="renzi_to_janice"]
不，这不是......
[cpg cn=true]


我否认了，但采取的立场让人觉得我可能已经这样做了。然后。
[cpg]


[FACE method="change_7"  pos="2/2"]
[VOICE f="Dorothy276"]
[OnName num="dorothy"]
'嗯？　也许你已经爱上了你爸爸？"
[cpg cn=true]


桃乐丝得到一个预感。在这里，多说几句。
[cpg]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy277"]
[OnName num="dorothy"]
'如果是这样，那么你和我就是对手。
[cpg cn=true]


[FACE method="change_5"  pos="1/2"]
[VOICE f="Janice175"]
[OnName num="renzi_to_janice"]
什么？"
[cpg cn=true]


[FACE method="change_1"  pos="2/2"]
[VOICE f="Dorothy278"]
[OnName num="dorothy"]
'我前几天告诉过你。我喜欢你的父亲'。
[cpg cn=true]


...... 古怪而有趣。我以为多萝西与疯王关系密切。
[cpg]


[FACE method="change_7"  pos="1/2"]
[VOICE f="Janice176"]
[OnName num="renzi_to_janice"]
'是这样的吗？　嗯，你知道，Renji是......"
[cpg cn=true]


我问道，想知道我是否有点溜号了。
[cpg]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy279"]
[OnName num="dorothy"]
'我喜欢恋次，但我非常喜欢你的父亲，以至于有点模糊不清。如果你的母亲还活着，我想我会嫉妒的。
[cpg cn=true]


仔细想想，我从来没有见过桃乐丝的母亲，也就是魔王的妻子。
[cpg]


她死了吗？我有一种感觉，她是。
[cpg]


在我不知所措的时候，桃乐丝
[cpg]


[FACE method="change_1"  pos="2/2"]
[VOICE f="Dorothy280"]
[OnName num="dorothy"]
'然后呢？　珍妮丝喜欢谁？"
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Janice177"]
[OnName num="renzi_to_janice"]
'...... 我是......'
[cpg cn=true]


[FACE method="change_2"  pos="2/2"]
[VOICE f="sDorothy008"]
[OnName num="dorothy"]
'你想念人类的皮肤，是吗？
[cpg cn=true]


又来了？　你在说什么呢？　就在我思考的时候，多萝西伪装成珍妮丝向我走来。
[cpg]

[FACE method="change_1"  pos="2/2"]
[WAIT time=1]
[move from="2/2" to="2/3" ease="easeInOutSine" time=1000]


[VOICE f="Dorothy282"]
[OnName num="dorothy"]
'别告诉我你真的爱上我了？
[cpg cn=true]


多萝西离奇地接近并试图脱掉衣服。
[cpg]


珍妮丝和多萝西的关系是这样的吗？如果是这样，我一定是变成了一个错误的人。
[cpg]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy283"]
[OnName num="dorothy"]
'我也喜欢珍妮丝。我也喜欢珍妮丝，排名不分先后。
[cpg cn=true]

[FO pos="1/2" time=1000]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



我们现在必须做好准备。我现在不能说我真的是Renji。
[cpg]


就是在想这个问题的时候。
[cpg]


;//移植前シーンカット

[SE f=se023]
;//【ＳＥ】『扉開く』

[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************




;//ここからジャニスのセリフ名前欄を元に戻してください
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="3/3" time=800]
[FG f="CHA03_p4_01_a.ui" method="change_4"  pos="1/3" time=800]




[VOICE f="Janice186"]
[OnName num="janice"]
'打扰一下。公主，我有一些报告要做: .......'
[cpg cn=true]


真正的珍妮丝进入房间。
[cpg]


[FACE method="change_5"  pos="2/3"]
[VOICE f="Dorothy296"]
[OnName num="dorothy"]
'哦，那个？　两个Janices？"
[cpg cn=true]

[SE f=se010]
;//【ＳＥ】『走る』

[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="3/3" time=1]
[FO pos="2/3" time=1]
[FO pos="1/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]

我迅速起身，跑开了。
[cpg]


这只是暂时的，但我还是不能呆在那里。
[cpg]



[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





当然，我不可能以珍妮丝的形式逃跑。
[cpg]

;**【ＣＧ】ci_06_0 ***********************
;//カットイン
[CUTIN f="ci_06_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

一旦走出房间，我就变成了粘液。现在他们不会知道是我。
[cpg]


这是个千钧一发的时刻。刚好赶上，还是出局？
[cpg]

[CUTIN f="ci_06_0.ui" show={false} method="slideout"]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





在接下来的几天里，我呈现出各种恶魔的样子，并与周围的环境融为一体。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha214"]
[OnName num="asha"]
你看起来并不熟悉。新人？"
[cpg cn=true]


当时我伪装成一个妖精，但阿莎认出了我。流星锤，她负责食堂的工作。
[cpg]


[OnName num="renzi"]
'是我。我是Renji'。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Arsha215"]
[OnName num="asha"]
'啊，原来是这样的。桃乐丝一直在找你。
[cpg cn=true]


[OnName num="renzi"]
我相信你是对的。......
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha216"]
[OnName num="asha"]
'桃乐丝，你很生气......，但你看起来并不是真的生气，所以也许我们应该见面。
[cpg cn=true]


当然是真的。这不是你可以永远推迟的事情。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





这就是为什么我去找多萝西当面道歉。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy297"]
[OnName num="dorothy"]
'这很好。这并不重要。我一直都知道，我是知道的'。
[cpg cn=true]


桃乐丝还是有点生气。阿莎是对的。
[cpg]


[OnName num="renzi"]
'...... 抱歉。
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="sDorothy009"]
[OnName num="dorothy"]
'Renji是这样一个懦夫。我知道你想探测我。
[cpg cn=true]


我不能否认这一点。我默默地坐直了身子。
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="sDorothy010"]
[OnName num="dorothy"]
'我也不恨恋次。也许我有点知道。

[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="sDorothy011"]
[OnName num="dorothy"]
'我希望你是公平的。这不是男人的行为。
[cpg cn=true]


然后多萝西脸红了，颓然倒下。我怎么能接受这个呢？
[cpg]


我知道她是为我好。也就是说，我不知道......，现在做任何事情都是一个好主意。
[cpg]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy301"]
[OnName num="dorothy"]
你想让我......，再多说点什么吗？"
[cpg cn=true]


[OnName num="renzi"]
'...... 不。你不需要说什么'。
[cpg cn=true]


突然间，一个机会出现了。我走近她，感到困惑不解。
[cpg]


仔细想想，她可能已经等了很久了。
[cpg]


我握住她的手，我们都知道她很紧张。
[cpg]


;//移植前シーンカット

;//移植前シーンカット

[SE f=se012]
;//【ＳＥ】『衣擦れ』
[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

轻轻地，我们互相握住对方的手。然后我说出了最重要的一个词。
[cpg]


[OnName num="renzi"]
'桃乐丝。我爱你，我爱你'。
[cpg cn=true]

[FACE method="change_4"  pos="2/3"]
[VOICE f="sDorothy012"]
[OnName num="dorothy"]
'嗯。我希望你在做各种淘气的事情之前就告诉我'。
[cpg cn=true]


多萝西看起来惊呆了，但她笑了起来。
[cpg]


我认为这在任何时候都会是我已经说过的事情。
[cpg]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy347"]
[OnName num="dorothy"]
'但我很高兴。谢谢你。我也喜欢Renji'。
[cpg cn=true]


多萝西说这话时看着我。
[cpg]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



在这样的事情发生后，第二天。
[cpg]


我想我们一定是结了婚，但还是感觉有些不对劲。
[cpg]


她喜欢大魔王的事还在我脑子里挥之不去。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy348"]
[OnName num="dorothy"]
'仁济，早上好。
[cpg cn=true]


[OnName num="renzi"]
上午好。"
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy349"]
[OnName num="dorothy"]
'这是......，有点尴尬。在这样的事情发生后'。
[cpg cn=true]


桃乐丝会这么说，但我心里有另一件事。
[cpg]


[OnName num="renzi"]
'桃乐丝喜欢你的父亲，对吗，魔王......？
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy350"]
[OnName num="dorothy"]
'怎么了，突然之间？
[cpg cn=true]


[OnName num="renzi"]
'我告诉你，我也可以让这个愿望实现。
[cpg cn=true]


[OnName num="renzi"]
我甚至可以化身为魔王的模样，留在多萝西的身边。"
[cpg cn=true]


多萝西听到这句话时犹豫了一会儿。
[cpg]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Dorothy351"]
[OnName num="dorothy"]
...... 呵。的确是这样。"
[cpg cn=true]


她似乎还认为，她一直想实现的爱情会成真，即使只是以一种伪装的方式。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





我和多萝西之间的距离在某种程度上正在缩小。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Janice187"]
[OnName num="janice"]
'公主，你今天又和他一起吃饭了吗？
[cpg cn=true]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy352"]
[OnName num="dorothy"]
是的，"他说。而且我没有忘记珍妮丝，所以不要担心。"
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Janice188"]
[OnName num="janice"]
不，我不担心这个问题。......
[cpg cn=true]


珍妮丝在皱眉头，但似乎是在向我表达一些嫉妒之情。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





然后夜幕再次降临。我正准备实现多萝西的愿望。
[cpg]


我邀请她进入我的卧室。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]






[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Dorothy353"]
[OnName num="dorothy"]
'太好了。真的，你看起来就像你的父亲'。
[cpg cn=true]


[OnName num="renzi"]
那是因为......，我是一个这样的恶魔。"
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="sDorothy013"]
[OnName num="dorothy"]
'......，我希望你现在能像这样拥抱我，穿成这样。
[cpg cn=true]


[OnName num="renzi"]
桃乐丝想要什么我就做什么。
[cpg cn=true]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy355"]
[OnName num="dorothy"]
'不要用你父亲的声音说，......，我会失控的。
[cpg cn=true]


看来多萝西真的很喜欢她的亲生父亲--魔王。
[cpg]


当她面对我时，她的脸上有一种不同的表情。
[cpg]


我想，无论如何，我不能满足她的父亲。我可以想象。
[cpg]


;//移植前シーンカット


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

我正在抚摸多萝西的头，而我是魔王的形态。
[cpg]


但我们越是相互接触，多萝西对自己父亲的爱就越是明显。
[cpg]


[OnName num="renzi"]
'待在我身边。桃乐丝'。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy377"]
[OnName num="dorothy"]
'...... 不要说'我'。说我。"
[cpg cn=true]


[OnName num="renzi"]
'想起来了，我是这么做的。
[cpg cn=true]


这个人物是如此接近理想，以至于多萝西希望自己的行为、言语和动作都像真的一样。
[cpg]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy378"]
[OnName num="dorothy"]
'桃乐丝，我希望你能用这种声音说我爱你......。
[cpg cn=true]


[OnName num="renzi"]
'哦。我爱你'。
[cpg cn=true]


;//ブラックアウト


我试着去回报，但我不觉得我真正满足了多萝西。
[cpg]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Dorothy379"]
[OnName num="dorothy"]
'谢谢你。我一直想让这个梦想成真，我想我可能已经实现了。"
[cpg cn=true]


多萝西在说这句话时显得很俏皮。
[cpg]


[OnName num="renzi"]
'真的吗？　只要告诉我你在想什么。"
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy380"]
[OnName num="dorothy"]
'是的。...... 是的。我是Renji，所以我会告诉你'。
[cpg cn=true]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy381"]
[OnName num="dorothy"]
'这是一种空虚或悲伤。我想我仍然爱我的父亲。"
[cpg cn=true]


[OnName num="renzi"]
'......，我明白了。
[cpg cn=true]


如果我想让桃乐丝真正爱我，我可能必须真正成为她。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





例如，假设我和桃乐丝结婚，成为下一个魔王。
[cpg]


但这并不意味着我可以自己成为她的父亲。
[cpg]


从我只能模仿她的外表就可以看出。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha217"]
[OnName num="asha"]
"......Renji."
[cpg cn=true]


我感到很不安。我当然想实现多萝西未完成的爱情。
[cpg]


当然，与自己的父亲绑在一起是不道德的，即使他是一个恶魔也是如此。
[cpg]


我怎样才能改变这种状况？......
[cpg]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Arsha218"]
[OnName num="asha"]
Renji！"
[cpg cn=true]


[OnName num="renzi"]
'呃？　啊，啊...... Asha？"
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Arsha219"]
[OnName num="asha"]
'阿沙，不。你为什么这么忧郁？
[cpg cn=true]


[OnName num="renzi"]
实际上，......。"
[cpg cn=true]


我和阿莎谈了这个问题。我不知道我是否有什么可以做的。
[cpg]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Arsha220"]
[OnName num="asha"]
'我明白了。桃乐丝，我就知道。
[cpg cn=true]


[OnName num="renzi"]
'我已经和珍妮丝谈过这个问题了。她告诉我这是无法再帮助的事情了'。
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha221"]
[OnName num="asha"]
我想我同意珍妮丝的意见。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="sArsha018"]
[OnName num="asha"]
'桃乐丝是那种喜欢所有人的人，相对而言。像Janice，甚至是我。......'
[cpg cn=true]


[OnName num="renzi"]
我也是，什么？
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha223"]
[OnName num="asha"]
'不。这没什么。我把它留给你的想象力'。
[cpg cn=true]


我可以有点想象。桃乐丝的性欲并不强，但她会感到孤独。
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha224"]
[OnName num="asha"]
但说到最好的，我认为是魔王。对桃乐丝来说，他是一个非常特别的人。
[cpg cn=true]


[FO pos="2/3" time=1000]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_04_5_up.ui" time=1000]

[FACE method="feadin_up" pos="4/7"]

[WAIT time=1500]


我把这件事告诉了任何我可以谈及的人。
[cpg]


[OnName num="renzi"]
'你对这个名为...... 的故事有什么看法？
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Clara530"]
[OnName num="clara"]
'我不知道，我不知道这个。
[cpg cn=true]


最后，他甚至告诉了他的俘虏，克拉拉。
[cpg]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Clara531"]
[OnName num="clara"]
'与其说是爱，难道你没有其他需要警惕的东西吗？
[cpg cn=true]


[OnName num="renzi"]
'你在说什么？
[cpg cn=true]


我不知道克拉拉在说什么。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





经过一番思考，我开始想，我必须让多萝西爱上我，因为我可以做什么。
[cpg]


换句话说，就是改头换面。我是唯一一个能像以前那样对她玩弄花招的人。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy382"]
[OnName num="dorothy"]
'我想我应该去睡觉了......，但我的眼睛已经微微发亮了。
[cpg cn=true]


而今天我被改造成了桃乐丝房间里的一盆植物。
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy383"]
[OnName num="dorothy"]
'哦，是的，我应该给它浇水。让我们来看看，壶的位置在.......'。
[cpg cn=true]


说着，他拿着壶走近我。我向她伸出了我的常春藤。
[cpg]


[FACE method="change_5"  pos="2/3"]
[VOICE f="Dorothy384"]
[OnName num="dorothy"]
'Kyaaaah!　什么？
[cpg cn=true]



;//========================================
;//●ＣＧ（観葉植物から蔦が伸びて、ヒロインの体に巻き付く。ヒロインは立ったまま動けない感じ）ev_02
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：無し
;//場所　：ダンジョン内部
;//時間　：夜
;//備考　：主人公は観葉植物に化けています
;//========================================

;//*Scene037
[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="10"]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1500]


[SE f=se014]
;//【ＳＥ】『弓を引き絞る』

[VOICE f="Dorothy385"]
[OnName num="dorothy"]
'这是什么？　这个植物是一个恶魔。"
[cpg cn=true]



我把自己包裹在多萝西的身体上，让她先不能动。
[cpg]


看着她困惑的表情，很有意思。
[cpg]


我很抱歉，我不能说任何话。......
[cpg]


但有些事情你可以做，因为你不能说什么。
[cpg]

;**【ＣＧ】 ev_02_a ***********************
[CG id=11 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Dorothy386"]
[OnName num="dorothy"]
'我被缠住了，我解不开......！'　住手，让我走！"
[cpg cn=true]


她正试图甩掉它。我紧紧地环绕着她。
[cpg]


我想知道是什么原因，她越是抗拒，我就越想做。
[cpg]



[VOICE f="Dorothy387"]
[OnName num="dorothy"]
'这怎么可能呢......！　以前从来没有发生过这样的事情。"
[cpg cn=true]


我想对多萝西搞个恶作剧。这是我很久没有感受到的一种情绪。
[cpg]


她仍然不明白这是我做的事情，显然。她似乎认为我简单种植的植物是一个恶魔。
[cpg]

;**【ＣＧ】 ev_02_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Dorothy389"]
[OnName num="dorothy"]
'哇，我明白了。是仁吉，对吗？　我已经可以从石头上看出来，告诉我是这样的。"
[cpg cn=true]


...... 错。他们知道。
[cpg]


;//移植前シーンカット


[VOICE f="Dorothy404"]
[OnName num="dorothy"]
Renji，来吧。...... 我真的对你很生气'。
[cpg cn=true]


然后她平静了一下，桃乐丝在告诉我。
[cpg]



[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



我仍然在对她进行愚蠢的恶作剧。
[cpg]


多萝西对我很生气，但我不会停止对她的戏弄。
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





像往常一样，多萝西仍然喜欢自己的父亲--魔王。
[cpg]


这一点还没有得到解决。我开始认为它还是不错的。
[cpg]


我以为这段快乐的时光会永远持续下去。
[cpg]

[FACE method="feadin_up" pos="4/7"]

[BG f="b_03_5_up.ui" time=1500]
[WAIT time=2000]
;//ブラックアウト

打破一切的那一天突然到来。
[cpg]


我想我是一个热爱和平的人。我做梦也没想到会发生这种情况。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





在地牢里，冒险家们为了拯救库拉拉而发动了攻击。
[cpg]


我想这就是库拉拉所说的，于是我进行了反击。
[cpg]


[OnName num="warrior"]
'如果你不想死，就别挡路！'。
[cpg cn=true]



[SE f="se025"]
;//【ＳＥ】『剣戟』





他们的同伴在保护他们，不让他们向地牢深处前进，尽管他们已经受伤了。
[cpg]


不过，人类方面还是寡不敌众。当我们在一个聚会中时，我们有四个人，但现在至少有十个人。
[cpg]


这是个小地牢，所以我们的人数不可能直接推到他们，但他们每一个人都很强壮。
[cpg]


当我们在与组成小集团的人类对抗时遇到了前所未有的困难，是...... 妖王出现。
[cpg]


[OnName num="rudolf"]
'你的要求是什么？你怎么能对我们这样做？"
[cpg cn=true]


[OnName num="monk"]
'是这样的。请把我的克拉拉还给我。
[cpg cn=true]


当恶魔领主施展法术时，战局迅速变化。唯一的怪癖是他在指挥恶魔。
[cpg]




[FACE method="feadin_up" pos="4/7"]
[WAIT time=1100]

;//ブラックアウト



这时就到了推倒重来的时候了。
[cpg]


[OnName num="rudolf"]
该死的......！"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Clara532"]
[OnName num="clara"]
'......，不要感到难过。这是勇敢者的角色。"
[cpg cn=true]


克拉拉陷入了困境，正在逃跑。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



库拉拉已经逃跑了。妖王受了致命的伤。然而，人类并没有进一步介入。
[cpg]


看来，其目的只是为了营救库拉拉。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/2" time=800]

[VOICE f="Janice189"]
[OnName num="janice"]
'事情进展如何，公主？
[cpg cn=true]


[FACE method="change_4"  pos="2/2"]
[VOICE f="Dorothy405"]
[OnName num="dorothy"]
'...... 这不是普通的伤口。看上去她是被一把带着咒语的剑砍伤的'。
[cpg cn=true]


多萝西似乎哭累了，她的声音很低沉。
[cpg]


[FACE method="change_7"  pos="1/2"]
[VOICE f="Janice190"]
[OnName num="janice"]
'我明白了。......'
[cpg cn=true]


珍妮丝觉得自己无话可说。
[cpg]





[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





地牢里有医生。几乎所有的人都在为魔王治疗。
[cpg]


[OnName num="rudolf"]
'我很抱歉......，让你担心了。
[cpg cn=true]


他非常痛苦，我从未见过他如此虚弱。
[cpg]


[OnName num="renzi"]
'...... 恶魔领主，有什么我可以帮忙的吗？
[cpg cn=true]


[OnName num="rudolf"]
'不，不。没有什么。我自己可以看到，我已经没有多少时间了'。
[cpg cn=true]



[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



妖王的情况一天比一天恶化。多萝西日复一日地哭泣。
[cpg]


然后有一天。妖王把我召到国王的房间。
[cpg]


[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





那里没有医生。当他与我独处时，魔王开始说。
[cpg]


[OnName num="rudolf"]
'你会变成我吗？我没有别的人可以问。"
[cpg cn=true]


[OnName num="renzi"]
'......，不知怎的，我以为你会这么说。
[cpg cn=true]


[OnName num="rudolf"]
'那我们说得很快。'你领导魔族的那一天迟早会到来。
[cpg cn=true]


如果你这样做，你会被桃乐丝所爱。
[cpg]


[OnName num="rudolf"]
'我已经告诉我的随行人员，包括珍妮丝，要隐藏他们的死亡。我就指望你了。"
[cpg cn=true]


[OnName num="renzi"]
"...... 是。"
[cpg cn=true]


我点了点头。我已经准备好了，并决心要伪造桃乐丝。
[cpg]

[FACE method="feadin" pos="4/7"]
[BG f="b_01_5_up.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





在魔王死亡的那一刻，我也在场。桃乐丝不在，我被告知她正在康复的路上。
[cpg]


相反，我本来是要去寻找帮助魔王的方法。
[cpg]


这一切都很有意义。从那天起，我把自己伪装成魔王，扮演多萝西的父亲。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************


;**【ＣＧ】ci_18_0 ***********************
;//カットイン
[CUTIN f="ci_18_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

桃乐丝的心情很好，我想。
[cpg]

[CUTIN f="ci_18_0.ui" show={false} method="feadout"]
[WAIT time=1000]


我从心底里不觉得她是幸福的。我想她真的很担心。
[cpg]



或者说，她担心的是人类下一次入侵的时间。
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy406"]
[OnName num="dorothy"]
'...... 爸爸。现在不要轻举妄动，不要丢下我一个人。"
[cpg cn=true]


[OnName num="renzi"]
'哦。我的错。我不会离开你的。
[cpg cn=true]


第一个人，我，不是我，直接出来了。在她面前，我不得不假装一切。
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





有一段时间，我充当魔王。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice191"]
[OnName num="janice"]
'魔王，我想我们必须再次增加守卫。......，你想怎么做？
[cpg cn=true]


[OnName num="renzi"]
哦，"他说。做到这一点。"
[cpg cn=true]


'这样做，'正成为我的一个习惯。
[cpg]


珍妮丝为我着想，代表我提出建议。
[cpg]


我想以前并不是这样的。多萝西很疑惑。
[cpg]


[FACE method="feadin" pos="4/7"]
[BG f="b_01_5_up.ui" time=1000]
[WAIT time=1500]

;//ブラックアウト





多萝西以前也被这样宠坏过吗？
[cpg]


我是魔王，她伪装成她的父亲，多次向我撒娇。
[cpg]


我是她的伙伴，但我不知道我可以对她隐瞒多久。
[cpg]


我还是想把它藏起来。她已经失去了父亲，只要我能够隐藏，我就想保持这种状态。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy407"]
[OnName num="dorothy"]
'嘿，爸爸。珍妮丝最近一直在努力工作'。
[cpg cn=true]


[OnName num="renzi"]
'对。我想他们是在为我分担一些负担'。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy408"]
[OnName num="dorothy"]
'恋次，你还没有回来。在他对我做了这些之后，也许他终究不会再回来了。
[cpg cn=true]


[OnName num="renzi"]
他是怎么了？"
[cpg cn=true]


我尽力做到真诚，不显山露水。
[cpg]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Dorothy409"]
[OnName num="dorothy"]
'爸爸，拍拍我的头。我想你，Renji'。
[cpg cn=true]


[OnName num="renzi"]
'...... 哦。
[cpg cn=true]


我抚摸着多萝西的头。当我抚摸她时，她似乎像一只小猫。
[cpg]


即使在我和多萝西的平静日子里，也很难假装。
[cpg]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Dorothy410"]
[OnName num="dorothy"]
'嘿。其实我对一切都很清楚'。
[cpg cn=true]


[OnName num="renzi"]
'你知道吗？　你在说什么？"
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy411"]
[OnName num="dorothy"]
'所有的。你是Renji，对吗？
[cpg cn=true]


...... 我知道。我知道这一点。
[cpg]


[OnName num="renzi"]
你认识多久了？
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy412"]
[OnName num="dorothy"]
'从一开始。但如果我告诉他，他可能会停止假装是我的父亲。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy413"]
[OnName num="dorothy"]
当我父亲要去世时，我只是无法接受。
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Dorothy414"]
[OnName num="dorothy"]
'你试图缓解这种情况。我很高兴。"
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


多萝西的眼睛里有一种孤独的神情。他们看起来好像她这次失去了什么重要的东西。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





在深夜。她邀请我去她的卧室。
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Dorothy416"]
[OnName num="dorothy"]
'我已经等了你很久，很久。在你假装是我爸爸的时候，我什么都不能做。
[cpg cn=true]


[OnName num="renzi"]
'...... 抱歉。
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="sDorothy014"]
[OnName num="dorothy"]
'你可以随心所欲地伪装自己。作为...... Renji拥抱我，而不是作为你的父亲。"
[cpg cn=true]


他们这么说，我就改变了我的外表。
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy418"]
[OnName num="dorothy"]
我想说的是，如果你是一个人，那么你就应该有一个人的样子，而不是一个人的样子。"我想说的是，如果你是一个人，那么你就应该有一个人的样子。我也不想让Renji对我感到厌烦。
[cpg cn=true]


[OnName num="renzi"]
'我不会对你感到厌烦。从来没有。
[cpg cn=true]


多萝西脸红了，她说是。然后她说。
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3"]
[VOICE f="Dorothy419"]
[OnName num="dorothy"]
我爱你，Renji。我不能取代我的父亲，但我仍然喜欢他。
[cpg cn=true]

;//移植前シーンカット



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





除了魔王的随行人员和桃乐丝，没有人知道魔王已经死了。
[cpg]


桃乐丝会有什么感觉？　这并不能改变我们失去重要人物的事实。
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy440"]
[OnName num="dorothy"]
......"
[cpg cn=true]


偶尔，他也会表现出呼哧呼哧的黑脸。我看到了它，但我觉得不愿意做任何事情。
[cpg]


[OnName num="renzi"]
你还想对...... Klara报仇吗？
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy441"]
[OnName num="dorothy"]
'我不知道。复仇并不能让你的父亲回来。
[cpg cn=true]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Dorothy442"]
[OnName num="dorothy"]
'但这并不能弥补孤独感。所以这是唯一的办法。
[cpg cn=true]



;//========================================
;//●ＣＧ（ベッドに腰掛けてキスをする二人。ヒロインは頬を染めている）ev_44
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ダンジョン＿寝室
;//時間　：夜
;//備考　：主人公は魔王に化けています
;//========================================


[STOPBGM]

[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1500]




[VOICE f="Dorothy443"]
[OnName num="dorothy"]
'吸'。
[cpg cn=true]


她把她的嘴唇送到我的面前。伪装成魔王的我，回应道。
[cpg]



[VOICE f="Dorothy444"]
[OnName num="dorothy"]
'......，我终于意识到我是多么软弱。
[cpg cn=true]


[OnName num="renzi"]
'不，不是的。桃乐丝很坚强'。
[cpg cn=true]

;**【ＣＧ】 ev_44_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Dorothy445"]
[OnName num="dorothy"]
'谢谢你。在我看来，你听起来像个父亲。
[cpg cn=true]


即使多萝西笑了，她还是说同样的话，好像她身上有一些空虚。
[cpg]


[OnName num="renzi"]
'桃乐丝要我做什么，我就做什么。
[cpg cn=true]


这些话并不虚假。我可以做到。
[cpg]

;**【ＣＧ】 ev_44_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Dorothy446"]
[OnName num="dorothy"]
'呵。有了Renji，我真的可以转变。
[cpg cn=true]


我点了点头。然后我再次吻她。
[cpg]



[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





桃乐丝的心中有一个洞，但我可以填补它。
[cpg]

[SCENE id=19]


;//ＥＮＤ　ヒロイン２ルート
[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="epend.ks" target="*start"]



;//==============================
