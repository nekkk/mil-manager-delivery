*start


;###################################################################
*Ep002|转化的用途
;###################################################################

[SCENE id=2]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
;//ブラックアウト

[BG f="black.ui"  time=1000]
[WAIT time=100]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]


;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[window target=true]


而第二天，或者我不知道是否是第二天，因为它一直很暗淡。......。
[cpg]


大概又是一个早晨，我来到了食堂。
[cpg]


我在阿莎的形式下可能会有问题，但还是不能没有嘴吃。
[cpg]



[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************

[window target=true]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="5/3" time=800]
[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/3" time=800]

[SE f=se008]
;//【ＳＥ】『喧噪』

当我打扮成她的样子前往食堂时，所有人都很惊讶。
[cpg]


我觉得我在不必要地迷惑他们，但我别无选择，只能保持这种形式。
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』

[move from="2/3" to="2/5" ease="easeInOutSine" time=1000]

[move from="5/3" to="4/5" ease="easeInOutSine" time=2000]

[VOICE f="Arsha039"]
[OnName num="asha"]
'是的，等着我。多吃点'。
[cpg cn=true]


真正的阿莎把食物送到我面前。
[cpg]


然后她正视我的脸。......
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Arsha040"]
[OnName num="asha"]
'真的，他们看起来很像。就像有另一个我'。
[cpg cn=true]


'谢谢，'我回答，但我不知道这是否是正确的反应。
[cpg]

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

[WAIT time=1000]
[FO pos="2/5" time=1]
[FO pos="4/5" time=1]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

[window target=true]



然后，在我们吃完后，珍妮丝来叫我。
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Janice008"]
[OnName num="janice"]
'魔王要见你。
[cpg cn=true]


她相当沉默寡言。然而，她似乎并不是一个健谈的人。
[cpg]


她还穿着盔甲，所以我在想象她是一个战士。
[cpg]

[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[BGM f="08"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





[OnName num="rudolf"]
'她怎么样了？你有没有试着看看你后来能变成什么？
[cpg cn=true]

[FG f="CHA04_p4_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="3/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Arsha041"]
[OnName num="renzi_to_asha"]
'是的，在某种程度上。毕竟，我只能转化为这个身体或类似无机物的东西。
[cpg cn=true]


法律上的问题仍然让我摸不着头脑，但有些事情已经变得很清楚。
[cpg]


你不能变身为妖精或兽人。你也不能变身为桃乐丝或珍妮丝。
[cpg]


[FACE method="change_7" pos="3/3"]
[VOICE f="Dorothy007"]
[OnName num="dorothy"]
'无机物？　这意味着我不知道杜拉汉或甚至石像鬼是否会起作用。"
[cpg cn=true]


[VOICE f="Arsha042"]
[OnName num="renzi_to_asha"]
'...... 呢？
[cpg cn=true]


没有办法测试它。一块石头不可能变成它以前从未见过的东西。
[cpg]


[FACE method="change_1" pos="1/3"]
[VOICE f="Janice009"]
[OnName num="janice"]
'要我把他带给你吗？
[cpg cn=true]


[OnName num="rudolf"]
'哦。'请。
[cpg cn=true]




;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="3/3" time=1]
[FO pos="2/3" time=1]
[FO pos="1/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[window target=true]


然后，几个无机的恶魔聚集在国王的会议室。
[cpg]


[OnName num="dullahan"]
「……」
[cpg cn=true]


[OnName num="gargoyle"]
'......'
[cpg cn=true]


他们都不说话，所以我也沉默了。
[cpg]


[OnName num="rudolf"]
'怎么样了。你能做到吗？"
[cpg cn=true]


[FG f="CHA04_p4_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha043"]
[OnName num="renzi_to_asha"]
'我不知道，但我会尝试。
[cpg cn=true]


我会试着提醒自己。然后......
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_03_0 ***********************
;//カットイン
[CUTIN f="ci_03_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]


我终于能够做到了。我不知道它是什么，但它与巨魔有一些共同点。
[cpg]

[CUTIN f="ci_03_0.ui" show={false} method="feadout"]
[WAIT time=1000]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Dorothy008"]
[OnName num="dorothy"]
'这真的很神奇。我从来没有见过这样的恶魔，可以变成任何东西。
[cpg cn=true]


[OnName num="renzi"]
'......'
[cpg cn=true]


我正准备回答，但在我的杜拉汉形式下，我仍然没有口。
[cpg]

[FACE method="change_3" pos="2/5"]

[VOICE f="Janice010"]
[OnName num="janice"]
'一定有某种法律。
[cpg cn=true]


[OnName num="rudolf"]
'是的。我不明白阿莎怎么会仅仅因为是无机物而变成一个。
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="4/5" time=1]
[FO pos="2/5" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[window target=true]


我已经被豁免在地牢入口附近站岗一段时间了，因为我是一个罕见的恶魔。
[cpg]


他们说他们不希望我发生任何事情。
[cpg]



;//ここからアーシャのセリフ名前欄を元に戻してください




[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="4/5" time=800]
[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Arsha044"]
[OnName num="asha"]
啊。是我。"
[cpg cn=true]


我在一个不是食堂的地方看到了阿莎。
[cpg]


我走到她面前，说是我，因为现在我看起来也像阿霞。
[cpg]


[FACE method="change_7" pos="4/5"]
[VOICE f="Arsha045"]
[OnName num="asha"]
'不要太多，当你打扮成我的样子时，你无法分辨出区别。
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

我解释说，这已经够糟了，但我没有其他能说话的身体。
[cpg]


[FACE method="change_5" pos="4/5"]
[VOICE f="Arsha046"]
[OnName num="asha"]
'真的......？　我不知道为什么，有些东西你就是不能转化为。"
[cpg cn=true]


[FACE method="change_3" pos="4/5"]
[VOICE f="Arsha047"]
[OnName num="asha"]
'我的意思是，我现在不是真的喜欢这个。嘿，来这里。
[cpg cn=true]


[FO pos="2/5" time=1000]
[FO pos="4/5" time=1000]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





于是她带着我。
[cpg]



[window target=false]

[FACE method="feadin_up" pos="4/7"]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="06"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[window target=true]


在那里，在地牢的更远处。不知为何，它比其他房间更暗，也更亮。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA04_p4_01_a.ui" method="change_7"  pos="2/5" time=800]

[VOICE f="Arsha048"]
[OnName num="asha"]
这是一盏神奇的灯，'她说。这几乎就像阳光一样。......
[cpg cn=true]


显然，这个魔法也被用来种植蔬菜和谷物，并饲养牲畜。
[cpg]


我想知道是否毕竟是这样，但魔法可以是任何东西。
[cpg]


我不禁想，我自己也有点像个魔术师。
[cpg]


[OnName num="therianthropy_A"]
他说："我是一个很有耐心的人，我知道我在做什么。"他说："我是一个很有耐心的人，我知道我在做什么。你来了？"
[cpg cn=true]


他们在那里，是不同种族的兽人。那里也有几个女人。他们似乎正在用他们的农具进行休息。
[cpg]


[FACE method="change_2" pos="4/5"]
[VOICE f="Arsha049"]
[OnName num="asha"]
'他是个变形金刚，我把他带来了。解释给他听'。
[cpg cn=true]


[OnName num="therianthropy_B"]
你就是那个......，是吗？"
[cpg cn=true]


我在听那些野兽的声音。
[cpg]


[OnName num="therianthropy_C"]
'我的意思是，这是一个糟糕的作物，但你就不能做点什么吗？
[cpg cn=true]

[FACE method="change_4" pos="2/5"]

不，既然如此，......，转化的力量与耕作无关。当你这样告诉他们。
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Arsha050"]
[OnName num="asha"]
'好，好，好，别这么说。你可能有一些东西。
[cpg cn=true]


阿沙以这种方式回应。我当然欠她一个人情，如果我们再没有食物，我自己也会有麻烦。
[cpg]


[OnName num="therianthropy_A"]
'也许我们没有足够的水，但水也是一种有限的资源。
[cpg cn=true]


[OnName num="therianthropy_B"]
'是的，是的。而恩迪娜也有自由散漫的个性。
[cpg cn=true]


Undine。有这样的事情吗？它是一种精神还是什么？
[cpg]


[OnName num="therianthropy_C"]
'哦。他们可以随意控制水。
[cpg cn=true]


;//ブラックアウト
[SE f=se009]
;//【ＳＥ】『歩く』

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1000]
[BG f="b_04_5_up.ui" time=1]


于是，我和阿莎一起上路了，去找那个叫Undine的神灵。
[cpg]



[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1500]


[FACE method="change_7" pos="4/5"]

[VOICE f="Arsha051"]
[OnName num="asha"]
'进展如何？　你认为你能变成一个人吗？"
[cpg cn=true]


我会努力的，他回答道，并提醒我。这是问它是否是无机物的一种微妙方式。
[cpg]


当我看向Undine时，我发现它相当小，看起来更像是水本身变成的人形，而不是一个生物。
[cpg]


我不知道我是否能模仿漂浮的特点，但我试图提醒自己。
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FO pos="2/5" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_04_0 ***********************
;//カットイン
[CUTIN f="ci_04_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

然后我成功地变成了自己，并能够漂浮起来。但......
[cpg]

[CUTIN f="ci_04_0.ui" show={false} method="feadout"]

[WAIT time=1000]

[FACE method="change_2" pos="4/5"]
[VOICE f="Arsha052"]
[OnName num="asha"]
'我做到了!　如何，你认为你能控制水吗？"
[cpg cn=true]

[FACE method="change_1" pos="4/5"]

我的效率低下，行动迟缓，即使我一开始是个戈壁人。
[cpg]


考虑到这一点，有一种可能性是，即使我能够像他们一样，我也可能无法复制他们的能力。
[cpg]


[OnName num="renzi"]
'不，我觉得我不能使用像...... 魔法的东西。
[cpg cn=true]



Undine似乎有类似声带的东西，可以说话。
[cpg]


但至少光是想一想是没办法的。
[cpg]


如果魔法的表现背后有一些逻辑，那么就没有什么可以做的了。
[cpg]


[FACE method="change_4" pos="4/5"]
[VOICE f="Arsha053"]
[OnName num="asha"]
我明白了，......，你不能复制权力。
[cpg cn=true]


;//【ＢＧ】『ダンジョン＿通路』（暗い）



Undine操纵水的能力对农业是很有用的。如果我们能争取到Undine本身的帮助，那就最好不过了。
[cpg]


然而，据说居住在地牢的女妖有一种无忧无虑的性格，不能被很好地处理。
[cpg]


[OnName num="therianthropy_A"]
我很茫然。如果作物继续失败，......."
[cpg cn=true]


[FACE method="change_4" pos="4/5"]
[VOICE f="Arsha054"]
[OnName num="asha"]
'是的，......，当食物用完时，我们就只能从人类那里抢夺。
[cpg cn=true]


这将被称为入侵。我可以想象，他们以前是不会这样做的。
[cpg]


至于我，我想在和平中生活，所以我有我的智慧。
[cpg]


...... 不，等等。
[cpg]


[OnName num="renzi"]
嘿，有一个叫Mandracora的恶魔吗？"
[cpg cn=true]


[OnName num="therianthropy_C"]
'是的，有的。虽然那个人也有不受约束的个性'。
[cpg cn=true]


[OnName num="renzi"]
'我想复制这个。你能带我去那里吗？
[cpg cn=true]


所以我决定再次请阿莎帮助我。
[cpg]


她引导我到曼陀罗的位置。
[cpg]


[window target=false]


[SE f=se009]
;//【ＳＥ】『歩く』

[STOPBGM]

[FO pos="4/5" time=1000]

[BG f="black.ui"  time=1000]
[WAIT time=2000]
;//ブラックアウト



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[BG f="black.ui"  time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="06"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************

[window target=true]


;**【ＣＧ】ci_05_0 ***********************
;//カットイン
[CUTIN f="ci_05_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

我也可以复制曼德拉科拉的外观。
[cpg]


看来，我可以复制的不仅仅是无机物。除此以外：......
[cpg]

[CUTIN f="ci_05_0.ui" show={false} method="slideout"]
[WAIT time=1000]



[OnName num="renzi"]
'你可以试着把我埋在地下。也许你能从植物的角度看到一些东西。"
[cpg cn=true]


然而，他们可以说话。Mandrachora是一种神秘的生物。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha055"]
[OnName num="asha"]
'是的。......，我不知道我是否被允许这样做。
[cpg cn=true]



[SE f=se003]
;//【ＳＥ】『スコップで穴を掘る』

[WAIT time=2000]


[SE f=se003]
;//【ＳＥ】『スコップで穴を掘る』


我也不知道是否允许我这样做。
[cpg]


但我想做一些有用的事情。这种感觉是不可否认的。
[cpg]



而当我被埋葬的时候，我开始理解土壤的...... 感觉。
[cpg]


我所说的感觉，并不仅仅是指触觉，而是指土壤中的营养成分。
[cpg]


[OnName num="renzi"]
'我觉得碱不够。也许你应该在上面放一些石灰或其他东西。"
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Arsha056"]
[OnName num="asha"]
'你是什么意思......？　什么是石灰？"
[cpg cn=true]


[OnName num="renzi"]
'我能说什么呢，土壤是酸性的。
[cpg cn=true]


总之，现在他们知道了土壤的性质，就要求他再把它挖出来。
[cpg]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FG f="CHA04_p4_01_a.ui" method="change_3"  pos="2/5" time=1]
[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="4/5" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

我将再一次采取阿莎的形式。然后他们与野兽进行了详细的交谈。
[cpg]



[OnName num="therianthropy_A"]
'嗯，......，事情就是这样发生的。
[cpg cn=true]


至少在这个世界上，酸碱的概念显然是存在的。
[cpg]


[OnName num="therianthropy_B"]
'一旦我们知道这一点，我们需要立即采取行动。
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FACE method="out" pos="4/7"]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[window target=true]

[SE f=se009]
;//【ＳＥ】『歩く』

我也从未想过自己会变成一株植物。
[cpg]


我很感激阿莎和负责修炼的野兽们给我带来的意外能力。
[cpg]


即使我不打仗，我想我仍然可以在这个地方发挥作用。......
[cpg]

[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Arsha057"]
[OnName num="asha"]
'谢谢你!　我有一种感觉，它将会成功的。"
[cpg cn=true]


阿莎拉着我的手，对我微笑。
[cpg]


我可以闻到那种气味，和我们第一次见面时一样。
[cpg]

[window target=false]


[FO pos="2/5" time=1000]
[FO pos="4/5" time=1000]

[BG f="black.ui"  time=1000]
[WAIT time=1500]

[STOPBGM]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************

[window target=true]

我不觉得被人感谢有什么不好。直到现在，我几乎什么都没做，只是为他们吃东西。
[cpg]

;**【ＣＧ】ci_07_0 ***********************
;//カットイン
[CUTIN f="ci_07_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

从那时起，我一直在努力以各种方式改造自己。例如，我能够转变为一种粘液，尽管它似乎不是无机物。
[cpg]



我还能呈现出类似人形的外观，所以我想我将暂时保持这种装束。......
[cpg]

[CUTIN f="ci_07_0.ui" show={false} method="slideout"]
[WAIT time=1000]

[SE f=se009]
;//【ＳＥ】『歩く』

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]

[WAIT time=2000]


[VOICE f="Janice011"]
[OnName num="janice"]
Renji."
[cpg cn=true]


[OnName num="renzi"]
'......，这是什么？
[cpg cn=true]



我打扮成人形黏液，然后回答。
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Janice012"]
[OnName num="janice"]
'我听说你很活跃。
[cpg cn=true]


[OnName num="renzi"]
'是的，好吧，......，我想是的。
[cpg cn=true]


我可以和阿莎一起囤积，但我不能和珍妮丝或多萝西这样做。
[cpg]


珍妮丝对珍妮丝本人有点害怕，多萝西对她的父亲有点害怕。
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Janice013"]
[OnName num="janice"]
'魔王要见你。跟着我。
[cpg cn=true]


她继续像以前一样面无表情，或者说像以前一样面无表情。
[cpg]


她是否在某种程度上原谅了我，还是变得有些软弱？......
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************


[window target=true]


[OnName num="rudolf"]
'从那时起你过得怎么样？你适应了这个世界的生活吗？
[cpg cn=true]


[OnName num="renzi"]
'是啊，......，我不太习惯这个世界，因为我不太习惯我的身体。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Dorothy009"]
[OnName num="dorothy"]
'我想是这样的。如果我可以改造自己，我也无法平静下来'。
[cpg cn=true]


恶魔领主和他的女儿多萝西都在一定程度上理解我的感受。
[cpg]


[OnName num="rudolf"]
'只有你能确定你的力量。如果你学到了什么新东西，请告诉我'。
[cpg cn=true]


[OnName num="renzi"]
是的。......
[cpg cn=true]


从那时起，我就一直试图转化为另一种生物，或者说是另一种形态。
[cpg]


[OnName num="renzi"]
'我只能像我想的那样，转变为类似无机物的东西。我可以变成粘液。
[cpg cn=true]


例如，当她变身为Undine时，她可以漂浮，但她不能控制水。
[cpg]


这可能是我的基本事情。这不是一种万能的变形能力。
[cpg]


[OnName num="renzi"]
'你可以在一定程度上模仿生态环境，比如曼陀罗。
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Dorothy010"]
[OnName num="dorothy"]
'呵。我想这意味着我在模仿方面是完美的，但在战斗中却很弱。
[cpg cn=true]


[OnName num="renzi"]
基本上就是这样。"
[cpg cn=true]


反正在战斗时可能会很弱。如果我为妖族而战，我就会像妖王说的那样，只是去侦察一下。
[cpg]


[OnName num="rudolf"]
'我想我需要做更多的研究，看看他们能转化成的东西有多有限。
[cpg cn=true]


[OnName num="rudolf"]
'无论如何，你可能是个骗子。我对你寄予厚望'。
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[window target=true]


[OnName num="renzi"]
'...... Dorothy，你很可爱。
[cpg cn=true]


离开国王的房间，我不禁自言自语。
[cpg]


她不是唯一的人。甚至珍妮丝也不仅仅是一个漂亮的......，她是一个美丽的人。
[cpg]


我想为她做点什么。如果我是魔族的诡计者。
[cpg]


我不禁想，我至少应该得到一些回报。
[cpg]



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="ep003.ks" target="*start"]


