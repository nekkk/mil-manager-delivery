*start


;###################################################################
*Ep001|转化的线索
;###################################################################

[window target=false]


[SCENE id=1]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]

[stflag Jumpflg = 0]


[if exp={getFlagValue("Jumpflg") == 0 }]
[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 0]
[stflag Cha4flg = 0]
[stflag Cha5flg = 0]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]
[endif]

[BG f="black.ui"  time=1000]
[WAIT time=1000]


[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************

[SE f="se008"]
;//【ＳＥ】『喧噪』

[window target=true]


[OnName num="kobold_A"]
'但在伊格纳地区，事情也变得相当疯狂。
[cpg cn=true]


[OnName num="kobold_B"]
'这在哪里都是一样的。人类和恶魔是不相容的'。
[cpg cn=true]


随着我们在这里呆的时间越来越长，对这个世界的认识也越来越清晰。
[cpg]


似乎这是一个叫 "罗亚 "的世界，这个地牢位于一个叫 "伊格纳地区 "的地方。
[cpg]


地牢本身被简单地称为地府，其本身也指恶魔之国。
[cpg]


而且恶魔的话语比我想象的要多得多。
[cpg]


可能有类似动物的恶魔，但智慧的恶魔更常见。
[cpg]


尽管他们是恶魔，但他们有良好的规范，就像人类一样。
[cpg]


守卫们轮流上阵，休息的恶魔们睡觉和吃饭。
[cpg]


这就像人类守卫城堡一样。
[cpg]


[SE f="se009"]
;//【ＳＥ】『歩く』

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]

[WAIT time=1500]


[OnName num="kobold_A"]
啊，珍妮丝。
[cpg cn=true]


[VOICE f="Janice001"]
[OnName num="janice"]
「……」
[cpg cn=true]


然后一个我以前从未见过的女孩出现了。
[cpg]


不，她不是一个女孩，但她有风格。她是一个女龙人，也可能是一个龙人，或者是介于蜥蜴人和人类之间的东西。
[cpg]

[FO pos="2/3" time=800]

[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="4/5" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/5" time=1000]
[VOICE f="Janice002"]
[OnName num="janice"]
'所以你就是那个被称为变形金刚的人？
[cpg cn=true]


当时我正在吃饭，打扮成阿霞的样子。
[cpg]



;//下記セリフ名前欄を「アーシャ（蓮司）」と置き換えてください


[FACE method="change_7" pos="4/5"]

[VOICE f="Arsha010"]
[OnName num="renzi_to_asha"]
嗯，......，但显然是这样。
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Janice003"]
[OnName num="janice"]
'似乎是这样......？
[cpg cn=true]


我不应该以这种方式说。我还是解释了自己。
[cpg]


当我说我并不真的觉得自己生来就是变形金刚时，他给了我一个疑惑的眼神。
[cpg]


[FACE method="change_3" pos="2/5"]
[VOICE f="Janice004"]
[OnName num="janice"]
'总之，魔王要见你。
[cpg cn=true]


恶魔之王。我们至少知道，他是地牢的主人。
[cpg]


看来我终于要面对那个魔王了。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]

[FO pos="2/5" time=1]
[FO pos="4/5" time=1]


[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************


[window target=true]



[OnName num="devil"]
'......，真的很像阿沙。
[cpg cn=true]

;**【ＣＧ】ci_18_0 ***********************
;//カットイン
[CUTIN f="ci_18_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

妖王是一个相当像人类的人物，虽然他的肤色很差。
[cpg]


他肌肉发达，看起来很有威慑力。
[cpg]


最常见的假设是，高级恶魔有一个类似人类的外表，但也许这就是它的本质。
[cpg]

[CUTIN f="ci_18_0.ui" show={false} method="feadout"]
[WAIT time=1000]

;//下記セリフ名前欄を「魔王の娘？」に置き換えてください





[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Dorothy001"]
[OnName num="devils_daughter"]
......"
[cpg cn=true]


还有一个看起来像他女儿的东西和他在一起。
[cpg]


她，被称为珍妮丝，也和他一起住在那里，可能是一个助手或什么。
[cpg]


[FO pos="4/5" time=1000]

[OnName num="devil"]
'你叫什么名字？
[cpg cn=true]



;//しばらくアーシャのセリフ名前欄を「アーシャ（蓮司）」と置き換えてください





[FG f="CHA04_p4_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha011"]
[OnName num="renzi_to_asha"]
'我的名字是Renji。Renji Hanamura, ......'
[cpg cn=true]


我曾一度怀疑这个世界上是否存在汉字的概念。
[cpg]


我想知道在这个世界上是否有汉字的概念。但他们的名字似乎都是副角。
[cpg]


[OnName num="devil"]
'我听说你是个变形人。证明它的力量'。
[cpg cn=true]


当我在想我在想什么的时候，这就是他们告诉我的。
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha012"]
[OnName num="renzi_to_asha"]
'...... 是'。
[cpg cn=true]


我点了点头，顺其自然。从阿莎的形态来看，我变成了一个格木。
[cpg]



[SE f=se001]
;//【ＳＥ】『変身音』


[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_02_0 ***********************
;//カットイン
[CUTIN f="ci_02_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]


我不知道这个过程是什么，在我看来，这并不是好事。
[cpg]


但这似乎足以让魔王、他的女儿和珍妮丝吃惊。
[cpg]

[CUTIN f="ci_02_0.ui" show={false} method="feadout"]
[WAIT time=1000]

[OnName num="devil"]
'......，你真的是一个变形金刚，对吗？
[cpg cn=true]


她比魔王更惊讶，她似乎是魔王的女儿。
[cpg]



;//下記セリフ名前欄を「魔王の娘？」に置き換えてください





[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Dorothy002"]
[OnName num="devils_daughter"]
'太好了，太好了，太好了!　让我变成他们中的一员。"
[cpg cn=true]


她说这话时，我低头看着她。
[cpg]



;//ここからドロシーの名前欄をそのまま表示してください





[FACE method="change_2" pos="2/3"]
[VOICE f="Dorothy003"]
[OnName num="dorothy"]
'我的名字是多萝西。你可以把我变成你的父亲'。
[cpg cn=true]


他看着魔王，说父亲。她毕竟肯定是他的女儿。
[cpg]


她用呆滞的眼神看着我，我想不辜负她的期望，但......。
[cpg]


[OnName num="renzi"]
「……」
[cpg cn=true]


我不能变成一个怪物。我摇了摇头。
[cpg]


[OnName num="devil"]
'我听说变形金刚变身时有条件。'也许这里面有什么东西。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy004"]
[OnName num="dorothy"]
'我明白了。耻辱'。
[cpg cn=true]


她的名字叫多萝西，她看起来真的很失望。我感到有些遗憾。
[cpg]

[FO pos="2/3" time=1000]


[OnName num="rudolf"]
'很抱歉我错过了你的名字。我的名字是鲁道夫。鲁道夫-汤森。我是这个地牢的主人'。
[cpg cn=true]


我想有礼貌地说声谢谢，但我没有嘴说。
[cpg]


[OnName num="rudolf"]
'你愿意为人类做一些侦查工作吗？你可以欺骗英雄，把他们俘虏。
[cpg cn=true]


搞什么鬼，你怎么突然说起这个了？
[cpg]


我不能承担这么重的任务。我想说，我又要变成阿霞了。
[cpg]



[SE f=se001]
;//【ＳＥ】『変身音』

[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]



[WAIT time=1000]
[FG f="CHA04_p4_01_a.ui" method="change_7"  pos="2/3" time=1]

[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



当我再次打扮成她的样子时，我可以闻到我提到的那种香草和肥皂的味道。
[cpg]


我真的对自己印象深刻，我甚至复制了她身体的气味。
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Arsha013"]
[OnName num="renzi_to_asha"]
'我不能。我刚刚得到了我的变形能力。
[cpg cn=true]


[OnName num="rudolf"]
'你是什么意思？　我以为你是天生的变形金刚。"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Arsha014"]
[OnName num="renzi_to_asha"]
'那是......，我也不太明白，但我是新来的。
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="5/3" time=1]


我决定告诉他们一切。我不能一边隐瞒一边继续说下去。
[cpg]



[move from="2/3" to="2/5" ease="easeInOutSine" time=1000]
[move from="5/3" to="4/5" ease="easeInOutSine" time=1000]

[VOICE f="Dorothy005"]
[OnName num="dorothy"]
'你是说你来自另一个世界？　告诉我更多。"
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Arsha015"]
[OnName num="renzi_to_asha"]
'我不认为是转世，我认为我死过一次。
[cpg cn=true]


当我告诉他们事情的经过时，魔王和桃乐丝都饶有兴趣地听着。
[cpg]


珍妮丝是唯一保持佛教徒身份的人，但仍不时点头。
[cpg]


[FACE method="change_5" pos="4/5"]
[VOICE f="Dorothy006"]
[OnName num="dorothy"]
'那就是说，你转世到这里来了!　你死的时候还疼吗？
[cpg cn=true]


[FACE method="change_4" pos="2/5"]
[VOICE f="Arsha016"]
[OnName num="renzi_to_asha"]
我不记得了。......
[cpg cn=true]


[OnName num="rudolf"]
'总之，特别有意思。如果他们生活在一个我们不知道的世界里，他们也许能想出一些古怪的策略'。
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[FO pos="2/5" time=1]
[FO pos="4/5" time=1]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



[window target=true]


从那以后，治疗方法发生了很大的变化。
[cpg]


我被安排在一个私人房间而不是大房间。
[cpg]

[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Janice005"]
[OnName num="janice"]
'从现在起这是你的房间。你可以自由使用它。"
[cpg cn=true]


[FACE method="change_2" pos="2/5"]
[VOICE f="Arsha017"]
[OnName num="renzi_to_asha"]
谢谢你。"
[cpg cn=true]


[FACE method="change_7" pos="4/5"]

珍妮丝认真地看着我。我猜她还是不相信我的转变。
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Janice006"]
[OnName num="janice"]
'我已经很久没有看到魔王和公主这样的表情了。他们一定对我抱有很大的期望。
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Arsha018"]
[OnName num="renzi_to_asha"]
谢谢你。......"
[cpg cn=true]


我不得不重复同样的话。即使有这样的期望。
[cpg]


[FACE method="change_2" pos="4/5"]
[VOICE f="Janice007"]
[OnName num="janice"]
'我也有很高的期望。祝你好运'。
[cpg cn=true]

[SE f="se009"]
;//【ＳＥ】『歩く』

[move from="4/5" to="5/3" ease="easeInOutSine" time=2000]
[WAIT time=1100]


说完，珍妮丝就离开了。......
[cpg]

[SE f="se001"]
;//【ＳＥ】『変身音』

[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


[FACE method="feadin_up" pos="4/7"]



我一出手就释放转化。我又恢复到最初的蛇形状态。
[cpg]


不知何故，变成别人的感觉很奇怪，我想，如果我恢复到原来的样子，这种感觉就会消失。......
[cpg]


并不是很像那么回事。首先，我不是一个变形金刚，只是一个人。
[cpg]

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

但是，你还是说了很多关于能够采取怪异的策略和期望的事情.......。
[cpg]


我所想的东西与我得到的期望完全不同。
[cpg]


地牢里有漂亮的女孩，即使她们是恶魔女孩。
[cpg]


我在想，我可以对他们做一些调皮的事情。
[cpg]


由于某些原因，我目前没有大量的变换剧目，但如果我可以增加这个......。
[cpg]

;//＠俺は一人考えていると、邪な欲望が高まってきた。
我独自思考，我的欲望在增长，不平衡地增长。
[cpg]


而现在我在想，我甚至可以把自己伪装成一个女孩。如果你问我是否不感兴趣，我是非常感兴趣的。
[cpg]

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

我环顾四周。我不认为这个房间里有什么东西可以监控。
[cpg]


我试图再次将自己伪装成阿霞。但我不能马上变成阿莎，仿佛我缺少一些条件。
[cpg]


[OnName num="renzi"]
啊，那是什么？"
[cpg cn=true]


试试这个，试试那个，想知道为什么。我刚才还能转化。
[cpg]


我是不是忘记了什么？　他试图回忆关于阿莎的事情，思考。
[cpg]


我试图生动地记住她的形态，并试图再次变成她，但我做不到。
[cpg]


再想一想，他想起了关于她的其他信息。例如，气味......
[cpg]


女人的气味可以被男人比作各种好闻的气味。
[cpg]

例如，香草、水果、鲜花。或者薄荷、香水、肥皂。
[cpg]

我认为阿莎闻起来像这两种气味的组合。
[cpg]

如果你能把它们很好地结合起来，你就能改变自己。......
[cpg]

另一方面，如果你弄错了其中的一个，你就不能说你记对了。
[cpg]

考虑到这一点，我想起了她的气味。
[cpg]


;//ゲーム要素のある変身システムをここに挿入します
;//以降、単に変身システムと表記します



;//今作は主人公がヒロインの匂いを覚えていないと変身できないという設定ですので
;//それを利用しつつ選択肢を用いたシステムとなっています



;//例えば今回はヒロイン４へと変身するＨシーンがありますが
;//そのシーン以前に本編で
;//「バニラと石けんを足したような匂い」
;//というようにヒロインの匂いを本編で表記しています



;//そこから暫くして変身するシーンの直前ですが



;//「バニラ」　　「ミント」
;//「果物」　×　「香水」
;//「花」　　　　「石けん」



;//という風に、三つあるいは四つぐらいの選択肢を二つ掛け合わせたものを用意します
;//左から一つ、右から一つというように選びます
;//三つの選択肢であるので、組み合わせは九種類になり、うち正答は一つです
;//二つの選択肢を両方を正しく選ぶことで、変身が成功しＨシーンに進む、という形です
;//失敗した場合はＨシーンに進みません



;//そのＨシーンを通っているかどうかで、後のルート分岐に影響します



;////////////////////////
;////////////////////////
;//一度目の変身システム//
;////////////////////////
;////////////////////////



;//選択肢用フラグ
[stflag IseSel01flg = 0]

第一个气味，我相信是......
[cpg]


[switch]
[case "香草。"]
	[swap]
	[stflag IseSel01flg = 1]
	[jump target="*hen11"]
[case "水果"]
	[swap]
	[jump target="*hen11"]
[case "花卉"]
	[swap]
	[jump target="*hen11"]
[endswitch]


*hen11|转化的线索。


第二种气味是......
[cpg]



[switch]
[case "薄荷。"]
	[swap]
	[jump target="*hen12"]
[case "香水"]
	[swap]
	[jump target="*hen12"]
[case "肥皂"]
	[swap]
	[stflag IseSel01flg = 1]
	[jump target="*hen12"]
[endswitch]

*hen12|変身の手がかり


[window target=true]

[WAIT time=100]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FACE method="out" pos="4/7"]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="04"]


[window target=true]

[if exp={getFlagValue("IseSel01flg") == 2 }]
[jump target="*select01_2"]
[endif]


[jump target="*select01_1"]

;//■選択肢Ａ
1、香草。
2、水果
3, 鲜花

;//■選択肢Ｂ
4、Mint
5、香水
6、肥皂。





;//==============================
;//１、バニラ　６、石けん　を選んでいた場合
*select01_2|変身の手がかり

;//【ＢＧ】『ダンジョン＿寝室』（暗い）


当她更生动地回忆起她的气味时，她就能自然地转变。
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/3" time=1]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



[FACE method="feadin_up" pos="4/7"]


[BG f="b_03_5_up.ui" time=1000]

[WAIT time=1000]


也许这与气味有关，而不是与形状有关。
[cpg]


我低头看了看自己的身材。我真的是一个女孩，从一切到一切。
[cpg]


我很好奇，想看看他们在再现她的过程中做到了什么程度。
[cpg]


当然，阿莎的隐私受到了威胁。我想知道该怎么做。......
[cpg]


[FO pos="2/3" time=1000]
[FACE method="feadout_up" pos="4/7"]
[BG f="black.ui"  time=1000]
[WAIT time=1500]

;//========================================
;//●ＣＧ（鏡の前で自分の姿を確かめるヒロイン＝主人公）ev_17
;//人物１：ヒロイン４　服装１：着衣
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公はヒロイン４の姿に変身しています
;//========================================

;**【ＣＧ】 ev_17_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1500]

;//ここからしばらく、アーシャのセリフ名前欄を「アーシャ（蓮司）」と置き換えてください

我以她的形象站在镜子前。
[cpg]


我已经确信，我已经走到了这一步。我刚刚试过的借口并不奏效。
[cpg]

;**【ＣＧ】 ev_17_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sArsha001"]
[OnName num="renzi_to_asha"]
'这很......，大胸的......'。
[cpg cn=true]

好一个独白，阿莎的声音出来了。
[cpg]


我觉得有点好笑，但我忍住了冲动。
[cpg]


没有了。真的，我不应该做任何事情。
[cpg]


即使是......，我已经能够改造自己了，所以解开自己的心结也是一种浪费。
[cpg]

;**【ＣＧ】 ev_17_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sArsha002"]
[OnName num="renzi_to_asha"]
'你真的很像她。甚至我的声音也是......."
[cpg cn=true]

我深深地感动了一阵子，喃喃自语。
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

;//[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


[window target=true]

我决定以阿莎的形式去睡觉。
[cpg]


我可以用我的格木形态睡觉，但我想被一种好的气味所包围。
[cpg]


闻到...... 气味？有东西卡在空气中了。......
[cpg]



;//ヒロイン４ルートの可能性が残る

[jump target="*select01_3"]

;//==============================
;//１、バニラ　６、石けん　のいずれかを外した場合

*select01_1|変身の手がかり



我试过很多次想变成阿莎，但似乎缺少什么，我无法完全转变。
[cpg]


经过这么多次艰苦卓绝的改造尝试，我感觉自己的力量被耗尽了。
[cpg]


我错过了什么？　他们在不知不觉中转变。
[cpg]


当我继续，试图记住关于她的每一个细节。......。
[cpg]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/3" time=1]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


有一次，我突然变成了阿霞。
[cpg]


我终于实现了我的目标，但我没有足够的精力去做任何事情，因为我已经转变了，也没有任何动力去这样做。
[cpg]



;//ヒロイン４ルートの可能性がなくなる

[stflag Cha4flg = -1]

;//==============================

*select01_3|変身の手がかり



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]


[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="ep002.ks" target="*start"]


