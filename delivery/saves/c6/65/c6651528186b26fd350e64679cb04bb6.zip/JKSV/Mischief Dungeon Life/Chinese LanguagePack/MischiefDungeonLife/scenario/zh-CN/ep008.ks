*start

;###################################################################
*Ep008|被激怒并不能阻止转变。
;###################################################################


[SCENE id=8]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
[BG f="black.ui"  time=1000]
[WAIT time=100]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





[OnName num="goblins"]
嘿，那个变形金刚......
[cpg cn=true]


[OnName num="kobold"]
'哦。我以为这将是改变战争局势的一张王牌。......'
[cpg cn=true]


你更多的是灰心，而不是匆忙。
[cpg]

;//＠
对我来说，这是同一件事，但我的良心因为流沙而有点痛。
[cpg]


我现在的情况是，我只是得到一顿饭和一个房间，靠自己的能力休息。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha128"]
[OnName num="asha"]
'你是在担心那些谣言吗？　Renji."
[cpg cn=true]


[OnName num="renzi"]
是的，好吧，......，我想。"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha129"]
[OnName num="asha"]
'我可以说的不多，但看来魔王正在考虑你的治疗。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha130"]
[OnName num="asha"]
'如果我想拥有自己的卧室，我至少会去侦察一下。
[cpg cn=true]


甚至阿莎也对我的愚蠢行为进行了反击。
[cpg]


按照这种速度，显然，我可能最终又要睡在大房间里了，显然。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



;//ここからしばらく、ドロシーのセリフ名前欄を「ドロシー（蓮司）」と置き換えてください

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[WAIT time=1000]
[FG f="CHA02_p4_01_a.ui" method="change_1"  pos="2/3" time=1]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

[VOICE f="Dorothy082"]
[OnName num="renzi_to_dorothy"]
'...... 一如既往，一个完美的改造。
[cpg cn=true]


但我心里有一件事。
[cpg]


我认为这对我来说是很新鲜的。我想这意味着这个地方毕竟是我的天性。
[cpg]


今天我变成了桃乐丝。与珍妮丝相比，她要矮得多。
[cpg]


我想到了与前几天类似的事情。如果转型如此完美，我就可以冒名顶替，过自己的生活。
[cpg]


我真的应该假装是桃乐丝，活一天。
[cpg]


被大家赞美为公主的感觉也许并不坏。......
[cpg]

;//移植前シーンカット


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


[SE f=se019]
;//【ＳＥ】『ノック』

[WAIT time=1000]


在那里，我听到有人敲门。我急忙回答。
[cpg]


[FG f="CHA02_p4_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Dorothy103"]
[OnName num="renzi_to_dorothy"]
'诶...... 哦，等一下。
[cpg cn=true]



[VOICE f="Janice109"]
[OnName num="janice"]
'......?　对我来说，听起来像是一个公主的声音。"
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_12_0 ***********************
;//カットイン
[CUTIN f="ci_12_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

我迅速转变。我化身为犬牙交错的兽人，打开了门。
[cpg]



;//ここからドロシーのセリフ、名前欄を元に戻してください


[CUTIN f="ci_12_0.ui" show={false} method="slideout"]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Janice110"]
[OnName num="janice"]
'你是伪装成公主的？
[cpg cn=true]


[OnName num="renzi"]
不，......，你一定是听错了。"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Janice111"]
[OnName num="janice"]
'适度'。
[cpg cn=true]


珍妮丝说的时候似乎相当生气。
[cpg]


[OnName num="renzi"]
'那么，你有东西给我。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Janice112"]
[OnName num="janice"]
'哦。公主要见你'。
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]

我被领到了国王的房间，但多萝西正坐在王座上。
[cpg]


[OnName num="renzi"]
'疯王在哪里？
[cpg cn=true]


恶魔领主在哪里？　我本来可以问的，但由于珍妮丝和多萝西在那里，我不得不装出一副'萨玛'的样子。
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy104"]
[OnName num="dorothy"]
'我想他正忙着调节流经地牢的魔法。
[cpg cn=true]


[OnName num="renzi"]
我可以坐在王位上吗？......？"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy105"]
[OnName num="dorothy"]
'这并不重要。如果事情按正确的顺序发展，我就是下一任魔王。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Dorothy106"]
[OnName num="dorothy"]
'更重要的是，我需要你帮我一个忙。
[cpg cn=true]


[OnName num="renzi"]
'哦。如果我可以的话，我会听的'。
[cpg cn=true]


[FO pos="2/3" time=1000]
[FO pos="1/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト

[FACE method="feadin" pos="4/7"]

[BG f="b_04_5.ui" time=1000]

[WAIT time=1000]


据他说，在恶魔居住的地牢里有一些问题。
[cpg]


据说，冒险者偶尔会出现在地牢，并被送回地牢。......。
[cpg]



这些冒险家的金钱和财物被剥夺了。否则，他们会再次进攻。
[cpg]


但他们在地牢里没有用。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FACE method="out" pos="4/7"]


[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]


[OnName num="renzi"]
'当然，光有钱是不行的。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy107"]
[OnName num="dorothy"]
'是的。应该是冒险家们为了冒险家的钱而来。"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy108"]
[OnName num="dorothy"]
'那么......，你为什么不去人类城市买一些魔法装备？　你可以把自己变成一个人。
[cpg cn=true]


[OnName num="renzi"]
也许我可以变成一个。...... 什么是魔法工具？
[cpg cn=true]


[FACE method="change_1" pos="1/3"]

[VOICE f="Janice113"]
[OnName num="janice"]
'从字面上看，它们是神奇的工具。这次我让你去买的是一种能加速蔬菜生长的'。
[cpg cn=true]


我明白了。这就是我们谈到的。
[cpg]


我曾想过，在这样一个山洞般的地方，蔬菜是如何生长的。
[cpg]


[OnName num="renzi"]
'嗯，这听起来很对。我会给它一个机会'。
[cpg cn=true]


这是一个比侦查更轻的任务。我还想在人类身上做手脚。
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Dorothy109"]
[OnName num="dorothy"]
'真的吗？　我很高兴你有一个我可以分配给你的工作。
[cpg cn=true]


[OnName num="renzi"]
那是什么样的......？"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy110"]
[OnName num="dorothy"]
'当你父亲说他要把房间从Renji那里拿走时，我很担心。
[cpg cn=true]


[OnName num="renzi"]
"......"
[cpg cn=true]


我明白了。我已经给了你很多不必要的关注。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FO pos="1/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





但在这一切都安排好后，我不能什么都不做。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha131"]
[OnName num="asha"]
进展如何？　你认为你能变成一个人吗？"
[cpg cn=true]


一个冒险家，他来打败魔王，被退回并打倒在地。我走近他，闻他。
[cpg]


闻到男人的气味不是一件很愉快的事情，更不用说是人了。......
[cpg]


[OnName num="renzi"]
'我可以。只要你能认出这个味道。"
[cpg cn=true]



;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_13_0 ***********************
;//カットイン
[CUTIN f="ci_13_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

我可以很容易地成为人类。我觉得自己像一个有剑客气质的年轻人。
[cpg]


而真正的，或者说是原件的复印件，将被囚禁在地牢里一阵子。
[cpg]


这样一来，就不会出现两个具有相同外表的人。
[cpg]

[CUTIN f="ci_13_0.ui" show={false} method="feadout"]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep009.ks" target="*start"]


