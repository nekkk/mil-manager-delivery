*start


;###################################################################
*Ep017|我将为你改变这个身体和世界。
;###################################################################
;//５、サツキ

[SCENE id=17]


[window target=false]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out" pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out" pos="3/5"]


[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]

[window target=true]



[OnName num="renzi"]
......，我是Satsuki。"
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy527"]
[OnName num="dorothy"]
'什么？　谁是Satsuki？"
[cpg cn=true]


[OnName num="renzi"]
'不，不。这不算什么'。
[cpg cn=true]


我被樱木所吸引。她不是一个我有很多接触的人，但我的那一点接触是很强烈的。
[cpg]


我发现自己有这种感觉，这几乎就像一见钟情。
[cpg]


[FO pos="2/3" time=1000]

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



一旦我意识到这一点，我就无法置身事外。
[cpg]


幸运的是，看来我捕获库拉拉的成就比我想象的要大，这并不妨碍我说我要离开地牢。
[cpg]

[BG f="b_01_5.ui" time=1000]
[WAIT time=1500]

[OnName num="renzi"]
'我很快就会回来。别担心。"
[cpg cn=true]


[OnName num="rudolf"]
'那就好，但对于恶魔来说，地牢外有很多危险。'要小心。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy528"]
[OnName num="dorothy"]
'这是真的。如果你有一天感到孤独，你可以随时回来'。
[cpg cn=true]


桃乐丝说的话就好像她在帮我的忙。
[cpg]


我很抱歉无视这些感受，但我已经下定决心。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************



樱木。我向她的地方走去。
[cpg]


[SE f=se020]
;//【ＳＥ】『草原歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『鬼の集落』（昼）******************************************************





在前往食人魔村的时候，我觉得无论是打扮成食人魔还是人类，都不是一个好主意。
[cpg]


现在，我打扮成妖精，这样可以一眼就认出我是妖族。
[cpg]


[OnName num="demon"]
'什么......？　你们这些恶魔在这里做什么？"
[cpg cn=true]


[OnName num="renzi"]
'我在找人。我不会做任何事情，你能让我进大门吗？
[cpg cn=true]


[OnName num="demon"]
'...... 如果你是人类，我会把你拒之门外。只要确保你不引起任何麻烦。
[cpg cn=true]


然后他们寻找佐藤。我莫名其妙地记住了那一排房子。
[cpg]

[SE f=se009]
;//【ＳＥ】『歩く』

[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





;//[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Satuki108"]
[OnName num="satsuki"]
'......，那个时候的变形金刚？　真的，你可以看起来像任何东西。"
[cpg cn=true]


[OnName num="renzi"]
'我需要和你谈谈。你能让我进入你的房子吗？
[cpg cn=true]





[window target=false]

[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夕方）******************************************************





樱木的房子对一个人来说仍然显得太大。
[cpg]


我想她告诉我，她的父母很早就去世了。
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki109"]
[OnName num="satsuki"]
'那么？　有什么故事？"
[cpg cn=true]


[OnName num="renzi"]
'...... 即可'。
[cpg cn=true]


我选择我的词。樱木一直没有原谅我。
[cpg]


或者说，我有种感觉，我被整个恶魔部落当成了外人。
[cpg]


这是在我们相爱之前。我想知道我如何能向她敞开心扉。
[cpg]


[OnName num="renzi"]
'我想知道人类在做什么。我知道他们与恶魔有矛盾。
[cpg cn=true]


我很快就挥别了这个话题，我对这个话题并不感兴趣。
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki110"]
[OnName num="satsuki"]
'我也不知道。我们是魔鬼。
[cpg cn=true]


在这里，我们走了。最好现在不要插手。......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夕方）******************************************************





我决定先把外侧的护城河填平。我决定把自己伪装成另一个恶魔，以获得有关佐藤的信息。
[cpg]


[OnName num="renzi"]
"......，嘿，好吗？"
[cpg cn=true]


[OnName num="demon_A"]
'哦，是你。怎么了？"
[cpg cn=true]


我伪装成另一个恶魔部落的样子，所以周围的人认为我以前来过这里。
[cpg]


如果我的真实身份被发现，这次他们会怀疑，但我不能这么说。
[cpg]


[OnName num="renzi"]
关于Satsuki，......，她爱上了一个人类，这是真的吗？"
[cpg cn=true]


[OnName num="demon_B"]
'什么？　如果你要争取，就放弃吧。她是一个人类...... 女祭司吗？　我疯狂地爱上了他。"
[cpg cn=true]


[OnName num="renzi"]
告诉我更多。
[cpg cn=true]


[OnName num="demon_A"]
'你不知道吗？　你说当我误入人类定居点时你帮助了我。"
[cpg cn=true]


[OnName num="demon_B"]
'在我印象中，是的。他叫什么名字，呃，......？"
[cpg cn=true]



[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





我在得到牧师的描述后，立即离开了恶魔部落的村庄。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（夜）******************************************************





她所爱的人不会到魔族的定居点来。
[cpg]


如果是这样的话，就意味着我可能会取代这个人。
[cpg]

[SE f=se020]
;//【ＳＥ】『草原歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（朝）******************************************************





我来到人类的小镇，寻找女祭司。
[cpg]


[OnName num="renzi"]
...... 那是.......
[cpg cn=true]


我明白了，他肯定是个有男子气概的人。但他似乎比樱木大一岁。
[cpg]


还有一个女人，看起来像...... 他的妻子和一个孩子。
[cpg]


...... 不，我还可以和樱木在一起，樱木的爱已经变成了未完成的爱。
[cpg]


在任何情况下，我都不能不变身为他而开始。
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





在我能够转变为牧师之后，我再次回到了恶魔部落的村庄。
[cpg]


当时已经很晚了，所以我找了一家客栈，早上就走了。......
[cpg]





[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（昼）******************************************************





如果是一个真正的牧师而不是我这个变形金刚，我在门口就会被拒之门外。
[cpg]


但我可以悄悄地进去。那是我的力量。
[cpg]


[OnName num="demon"]
'你又来了。这么多次，你想要什么？
[cpg cn=true]


我无法诚实地回答，于是编了一个合适的理由，说我是魔王的信使。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夕方）******************************************************

;**【ＣＧ】ci_26_0 ***********************
;//カットイン
[CUTIN f="ci_26_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]



当天晚上的晚些时候。伪装成牧师，我终于见到了樱木。
[cpg]

[CUTIN f="ci_26_0.ui" show={false} method="slideout"]
[WAIT time=1000]

[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Satuki111"]
[OnName num="satsuki"]
你是 .......
[cpg cn=true]


樱木见到他的那一刻，脸上的表情让人难以忘怀。
[cpg]


一张脸，只是看起来很惊讶。也许这就是人们再次遇到命运时的那种表情。
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki112"]
[OnName num="satsuki"]
'我一直想......，见到你。你为什么来这里？"
[cpg cn=true]


[OnName num="renzi"]
'我不得不跑到这里来追寻。我在想你怎么样了。
[cpg cn=true]


他们会因为这是一个夜晚的理由而被说服吗？　我以为......
[cpg]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Satuki113"]
[OnName num="satsuki"]
'我明白了。真的......，比我们第一次见面时好看多了。"
[cpg cn=true]


樱木有一种恋爱中的少女的表情。她似乎并不介意我说的东西不符合事实。
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Satuki114"]
[OnName num="satsuki"]
'你要在......，住一晚上吗？　如果我们现在回城，将是晚上。"
[cpg cn=true]


[OnName num="renzi"]
哦，"他说。我正在考虑这样做。"
[cpg cn=true]


[FACE method="change21"  pos="2/3"]
[VOICE f="Satuki115"]
[OnName num="satsuki"]
'对。我将准备食物。
[cpg cn=true]


樱木有一种我以前从未见过的浮力。我看着她，为她感到有些遗憾。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





晚餐后，她向我走来。
[cpg]


[FG f="CHA05_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki116"]
[OnName num="satsuki"]
'我一直想报答你。
[cpg cn=true]


[OnName num="renzi"]
'......，我明白了。
[cpg cn=true]




[FACE method="change_6"  pos="2/3"]
[VOICE f="satuki117"]
[VOICE f="sSatuki003"]
[OnName num="satsuki"]
;//「いえ……恩返し、なんて言葉じゃ説明つきませんね。貴方に、こういうことがしたかった」
不，...... 还款甚至都不足以描述它。"
[cpg cn=true]


[FACE method="change_6"  pos="2/3"]
[VOICE f="satuki118"]
[VOICE f="sSatuki004"]
[OnName num="satsuki"]
;//「淫乱だって思ってくれて結構です。事実、そうかもしれません」
你认为我是个假正经的人吗？"
[cpg cn=true]


说这话的时候，Satsuki紧紧地贴着我。
[cpg]


[OnName num="renzi"]
'我不这么认为。不，我没有'。
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Satuki119"]
[OnName num="satsuki"]
'...... 你真好。你的这一部分也很可爱。"
[cpg cn=true]

;//移植前シーンカット

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト


然后我和Satsuki谈了一会儿。
[cpg]


起初，我还想骗骗樱木，但渐渐地，我的衣服都被弄破了。
[cpg]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki144"]
[OnName num="satsuki"]
'顺便说一下，这真的是一个很长的时间。你是如何来到这里的？
[cpg cn=true]


[OnName num="renzi"]
这是......."
[cpg cn=true]


对。你能到这里，是不是很奇怪？如果是正常人，就会被打成重伤。
[cpg]


难怪他们已经发现，我是唯一能进入这里的人。
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki145"]
[OnName num="satsuki"]
如果你对答案感到茫然，那么你毕竟是......。"
[cpg cn=true]

吐了口气，萨提亚继续说道。
[cpg]

[FACE method="change_3"  pos="2/3"]
[VOICE f="Satuki146"]
[OnName num="satsuki"]
'所以你是Renji。如果有人能玩出这样的把戏，那一定是他。
[cpg cn=true]


我已经看透了我是谁。我的情节很快就崩溃了。
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki147"]
[OnName num="satsuki"]
'你认为你在做什么？　你是不是想找我麻烦？"
[cpg cn=true]


[OnName num="renzi"]
'...... 抱歉。
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Satuki148"]
[OnName num="satsuki"]
'我对你的感情感到受宠若惊。但我想爱的是真正的他。
[cpg cn=true]


[OnName num="renzi"]
但......，真正的东西是...
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki149"]
[OnName num="satsuki"]
什么是真正的东西？　你还在隐瞒什么吗？"
[cpg cn=true]


[OnName num="renzi"]
'真正的那个人看起来已经结婚了。他有孩子。"
[cpg cn=true]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Satuki150"]
[OnName num="satsuki"]
...... 是的。"
[cpg cn=true]


樱木看起来不止是有点不高兴。
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ヒロイン５の家＿室内』（昼）******************************************************





我不得不在她那里住了一段时间。这是我说的，她也没有拒绝。
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki151"]
[OnName num="satsuki"]
从那时起，......，我整晚都在思考这个问题。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki152"]
[OnName num="satsuki"]
'如果真正的他和别人在一起很开心。我想我不会再破坏他的幸福了'。
[cpg cn=true]


[OnName num="renzi"]
「……そうか」
[cpg cn=true]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Satuki153"]
[OnName num="satsuki"]
'所以我想说的是，做一个...... 冒牌货也是可以的。你能不能在我身边再呆一会儿？"
[cpg cn=true]


他说，如果真正的那个人已经结婚，那么他唯一能爱的就是我这个冒牌货。
[cpg]


我的心情很复杂。也许如果我不再是这种形式，他就不会爱我，但我知道他不会。......。
[cpg]


[OnName num="renzi"]
'哦。好的。"
[cpg cn=true]


有一段时间，我决定花一些时间成为樱木希望我成为的人。
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





又一个夜晚来临了。我是唯一能给她想要的东西的人。
[cpg]


我所要做的就是抚摸她的头发，她看起来很满意。
[cpg]


但在内心深处，我就是不能满足她。
[cpg]


与樱木在一起的时间过去了。是时候看看真爱在哪里了。
[cpg]


我很烦恼，但Satsuki肯定也有复杂的感受。
[cpg]


即使她以女祭司的身份爱我，她也未必能说她自己爱我。
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





我们继续保持距离，遇到了同样的问题。
[cpg]




[window target=false]

[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（朝）******************************************************





[OnName num="demon_A"]
'看来，恶魔和人类又开始胆怯了。
[cpg cn=true]


[OnName num="demon_B"]
'哦。如果这样下去，可能会演变成一场战争。
[cpg cn=true]


在这一切中，我在风中听到，人类和恶魔之间的战斗正变得越来越激烈。
[cpg]


[OnName num="demon_A"]
'显然，魔族那边已经被骗了，......。
[cpg cn=true]


[OnName num="demon_B"]
'有什么会如此无利可图呢？　我以为那是人类编造的。"
[cpg cn=true]


我在远处听着所有这些谈话。
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Satuki178"]
[OnName num="satsuki"]
你不需要战斗吗？"
[cpg cn=true]


樱木问道。我对恶魔部落也有一份感激之情。
[cpg]


[FACE method="change_4"  pos="2/3"]

[VOICE f="Satuki179"]
[OnName num="satsuki"]
'这是我...... 和其他恶魔部落所希望的。我希望战斗能尽快结束。
[cpg cn=true]


结束这场战斗也是为了棋盘上的魔族吗？
[cpg]


[OnName num="renzi"]
'...... 是。
[cpg cn=true]


樱木的话给了我所需的动力，让我决定加入战斗。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************


[SE f=se020]
;//【ＳＥ】『草原歩く』


在正面交锋中我很弱。我决定将自己伪装成人形，以创造一个转移注意力的机会。
[cpg]


因此，如果有什么我可以做的，例如，我可以把自己伪装成国王的随行人员，刺杀他或......？
[cpg]


我没有勇气去杀人。但我必须这样做吗？
[cpg]


我们不能更和平地放弃人类方面的军队吗？......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（昼）******************************************************





考虑到这一点，我变成了一名士兵。
[cpg]


我去找军械库、火药库和其他普通魔鬼难以进入的地方。
[cpg]


[OnName num="soldier"]
'哦，已经轮到你了吗，......？　嗯，好好照顾他们。"
[cpg cn=true]


[OnName num="renzi"]
'交给我吧。我将保护这个地方。
[cpg cn=true]


他说的话，使部队从内部偏离了方向。
[cpg]





[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="07"]

;//【ＢＧ】『街』（夜）******************************************************


这在一段时间内是很好的。人们不知道发生了什么。
[cpg]

但它并没有永远这样下去。
[cpg]

很明显，库拉拉从地牢里逃了出来。她似乎在告诉他们一切。
[cpg]

换句话说，有一种恶魔叫做...... shapeshifters。
[cpg]

[OnName num="citizen_A"]
'是不是真的......，有恶魔可以变成人类？
[cpg cn=true]


[OnName num="citizen_B"]
'哦。'我听说他们在攻击军火库。'他们很快就会杀人。
[cpg cn=true]


[OnName num="citizen_A"]
'有人说要悬赏他们，不是吗？
[cpg cn=true]


[OnName num="citizen_B"]
'显然是这样。即使他们不这样做，人们也在用他们所有的血来寻找他们。"
[cpg cn=true]


[OnName num="renzi"]
......"
[cpg cn=true]


我在城市里不太舒服。无论我走到哪里，每个人都要来抓我。
[cpg]


我试图融入这个城市，我化身为人形，......，但是。
[cpg]



[FACE method="slidein" pos="4/7"]

[BG f="b_07_4_up.ui" time=1500]
[WAIT time=2000]
;//ブラックアウト


[SE f=se010]
;//【ＳＥ】『走る』

[OnName num="wizard"]
'他在那里!　他往那边跑了。"
[cpg cn=true]


[OnName num="soldier"]
'堵住通往大路的路！'。　其他都是死路一条！"
[cpg cn=true]



仅仅伪装成一个人是不够的。
[cpg]


似乎有一个实体被称为 "巫师"。无论我的结果如何，他们都有能力找到我。
[cpg]


[OnName num="renzi"]
该死的。.......
[cpg cn=true]


我在城里被发现了，士兵到处都是。
[cpg]


我终究没能逃脱，他们抓住了我。
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="03"]

;//【ＢＧ】『街』（昼）******************************************************


[SE f=se014]
;//【ＳＥ】『弓を引き絞る・縛る』

当时我是人形。我被捆绑着，无法动弹，但我认为我可以通过转化为另一种形式来逃脱。
[cpg]


然而，巫师对我使用了一个奇怪的把戏，我无法改造自己。
[cpg]


[OnName num="soldier_A"]
'走。你现在无法逃脱。
[cpg cn=true]


[OnName num="soldier_B"]
'你给我带来了很多麻烦。现在你已经完成了。"
[cpg cn=true]


我被送进了刽子手的牢房。如果我像这样死去，这一次肯定会是结束。
[cpg]


有什么可能从中恢复？
[cpg]


我越想，就越觉得自己一无所有。Dorothy或Janice会来吗？
[cpg]


即使他们知道，他们也不会知道是我。他们必须看起来像人类。
[cpg]


他们会看起来像普通的有罪的人。如果发生这种情况，他们就没有理由帮助我。
[cpg]


因此，如果他们愿意帮助我，我将不得不去......。
[cpg]


[SE f=se016]
;//【ＳＥ】『倒れる』


[OnName num="soldier_A"]
'妈的!　这他妈的是什么？
[cpg cn=true]


[OnName num="soldier_B"]
'你是魔族吗......！　等等，嘿！"
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Satuki180"]
[OnName num="satsuki"]
'在这里。Renji."
[cpg cn=true]


樱木来救我了。她怎么知道是我？
[cpg]


不，这不是现在的重点。我只是决定离开那里。
[cpg]




;//ブラックアウト



[SE f=se010]
;//【ＳＥ】『走る』


[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（夕方）******************************************************





[OnName num="renzi"]
'哈，哈，哈'。
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Satuki181"]
[OnName num="satsuki"]
'......，这是一个很接近的问题。这真是太巧合了'。
[cpg cn=true]


显然，当他来拜访牧师时，恰好路过。
[cpg]


他逃过一劫，来到了城郊。巫师的艺术已经被打破，我能够再次变身。
[cpg]


[OnName num="renzi"]
'...... 我的穿着完全不同，他们怎么知道是我？
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Satuki182"]
[OnName num="satsuki"]
'我也不太清楚。但我认出了你'。
[cpg cn=true]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Satuki183"]
[OnName num="satsuki"]
'也许他们认为你在某些方面...... 你，而不是你的外表。
[cpg cn=true]


你是想说，你爱我，因为我的外表不是这样的吗？
[cpg]


我没有这样大声说出来，但有一丝丝的感觉。
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夜）******************************************************





然后我们走回了恶魔部落的定居点。
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="satuki184"]
[VOICE f="sSatuki005"]
[OnName num="satsuki"]
;//「最初はね。私の思い人に化けられるからって理由で、そういうこともしてたわ」
'起初。'起初，我想留在你身边，因为你可以变成我想要的人。
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki185"]
[OnName num="satsuki"]
'但现在不同了。他想为我们结束这场战斗。"
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Satuki186"]
[OnName num="satsuki"]
'这真的让我很高兴。我觉得我必须帮助你。"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





然后他们又回到了她家。
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki187"]
[OnName num="satsuki"]
'......，我已经放弃了我的那份爱。因为我找到了新的爱情。"
[cpg cn=true]


她说的话到底有多少是真的？她真的从这样的事故中喜欢我吗？
[cpg]


[OnName num="renzi"]
'你是认真的吗？　我什么都没做。"
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Satuki188"]
[OnName num="satsuki"]
'你怎么敢。'为了魔族的利益，你差点就把自己给害死了。
[cpg cn=true]


说这话时，Satsuki向我逼近。
[cpg]



;//========================================
;//●ＣＧ（主人公に迫るヒロイン。覆い被さる感じ）ev_64
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン５の部屋
;//時間　：夜
;//備考　：主人公は兵士に化けています
;//=======================================

;//*Scene059
[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="10"]
;**【ＣＧ】 ev_64_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sSatuki006"]
[OnName num="satsuki"]
'...... Renji。靠近我。"
[cpg cn=true]


[VOICE f="sSatuki007"]
[OnName num="satsuki"]
'你不必再去任何地方了。
[cpg cn=true]


然后他将手伸向我的脸颊。
[cpg]


我什么也说不出来，但光是感觉到樱木的体温，我就很开心。
[cpg]


在她爱我之前，我就爱她了。......
[cpg]

;**【ＣＧ】 ev_64_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1500]

;//移植前シーンカット

[VOICE f="sSatuki008"]
[OnName num="satsuki"]
'吻，我想。我可以吗？"
[cpg cn=true]

[OnName num="renzi"]
'...... 哦。
[cpg cn=true]


嘴唇接触。我永远不会忘记这种感觉。
[cpg]


而那一天，我和樱木一起睡着了。
[cpg]


;//ブラックアウト



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（昼）******************************************************



从那时起，我就要留在恶魔村了。
[cpg]


如果我回城，这次可能会被杀。
[cpg]


我本可以回到地牢，但我不能带着樱木。
[cpg]


尽管被当做局外人，我还是决定留下来。
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（昼）******************************************************





我出去的时候感觉不是很好。无论我走多远，对于这个社会来说，我永远是个外国人。
[cpg]


但是，如果我能够留在樱木的身边，我觉得任何压力都会被吹走。
[cpg]


我有很多事情想和樱木谈一谈。
[cpg]


而她那边似乎也是如此。
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki235"]
[OnName num="satsuki"]
我不确定这么多年后你第一次来这里看我时是不是你。
[cpg cn=true]


这是我被告知的。然而，在被处决的边缘，他们认出了我，尽管我看起来与众不同。
[cpg]


[OnName num="renzi"]
'...... 真的，他们怎么会知道？
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki236"]
[OnName num="satsuki"]
'我想这意味着他们并不关心你的长相。
[cpg cn=true]


这是否意味着它是吸引力的证据，而不是外表？
[cpg]


[OnName num="renzi"]
我希望我们都能意识到这一点。"
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Satuki237"]
[OnName num="satsuki"]
这是真的，"他说。恶魔和人类，甚至是恶魔之间的差异是微不足道的。
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夕方）******************************************************




此后，他继续与樱木一起生活。我们分担家务，并努力与恶魔相处融洽。
[cpg]


日子慢慢过去。在樱木的身边感觉很充实。
[cpg]



当我与各种恶魔交流时，我的转化能力也得到了转变。
[cpg]


换句话说，我变得能够转化为其他地方不存在的恶魔。
[cpg]

;**【ＣＧ】ci_25_0 ***********************
;//カットイン
[CUTIN f="ci_25_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

这对我和我周围的人来说都很方便。
[cpg]


只要我的外表是恶魔的样子，我就能更容易地融入其中，而且由于我不是别人，我也不会被误认为是其他人。
[cpg]


[CUTIN f="ci_25_0.ui" show={false} method="feadout"]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Satuki259"]
[OnName num="satsuki"]
'被转化为不存在的东西，感觉很奇怪。
[cpg cn=true]


[OnName num="renzi"]
'我也没有。但我终于觉得自己是真正的我。
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Satuki260"]
[OnName num="satsuki"]
'也许你是对的，我不知道。我真的不关心我看起来像什么'。
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Satuki261"]
[OnName num="satsuki"]
'但如果仁兄满意，那是最好的。
[cpg cn=true]


;//ブラックアウト

她似乎爱上了我。我对此有点歉意。
[cpg]


尽管我也很喜欢她，但这种关系将持续到永远。
[cpg]


我们可以一次又一次地要求对方。即使我们都不缺乏什么，这就是做情人的意义所在。
[cpg]

;//移植前シーンカット


我们两个人一起睡着了。我和Satsuki将永远在一起。
[cpg]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[FO pos="2/3" time=1]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[STOPBGM]
[window target=true]

;//========================================
;//●ＣＧ（キス。朝起きてすぐ、布団にまだ入っているような感じ）ev_68
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン５の部屋
;//時間　：朝
;//備考　：主人公は鬼に化けています
;//=======================================



[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_68_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1500]


[SE f=se024]
;//【ＳＥ】『鳥の鳴き声』


早晨。我被她的吻惊醒。
[cpg]


[OnName num="renzi"]
'......，早上好。
[cpg cn=true]



[VOICE f="Satuki287"]
[OnName num="satsuki"]
'咯咯笑。'早上好，Renji'。
[cpg cn=true]


樱木分开她的嘴唇，对我的梦游大笑起来。
[cpg]



[VOICE f="Satuki288"]
[OnName num="satsuki"]
'我得准备早餐，我想。
[cpg cn=true]


[OnName num="renzi"]
'不，等一下。我们就在这上面再呆一会儿吧。
[cpg cn=true]

;**【ＣＧ】 ev_68_a ***********************
[CG id=19 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Satuki289"]
[OnName num="satsuki"]
'...... 是的。你真是个可爱的人'。
[cpg cn=true]


我再次亲吻樱木。
[cpg]



[VOICE f="Satuki290"]
[OnName num="satsuki"]
我想知道现在会发生什么。魔鬼和人类之间的战争仍在继续。
[cpg cn=true]


[OnName num="renzi"]
'我听说是这样的。有人说，它正在一点点消退。......"
[cpg cn=true]

 

[VOICE f="Satuki291"]
[OnName num="satsuki"]
'有一天，当真正的和平，恶魔和食人魔种族之间不再有分离时，......，让我们结婚吧。
[cpg cn=true]


樱木用了相当大的勇气才说出这句话。
[cpg]


[OnName num="renzi"]
'哦。当然了。我必须为此做我能做的事。
[cpg cn=true]

;**【ＣＧ】 ev_68_b ***********************
[CG id=19 index=2 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Satuki292"]
[OnName num="satsuki"]
'你不能再被抓了。我不想再经历那种可怕的经历。
[cpg cn=true]


[OnName num="renzi"]
我会让它发挥作用的。我觉得我现在可以做到。"
[cpg cn=true]


有一种毫无意义、毫无根据的自信。这也是爱的力量吗？
[cpg]

[SCENE id=22]


;//ＥＮＤ　ヒロイン５ルート

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="epend.ks" target="*start"]


;//==============================



