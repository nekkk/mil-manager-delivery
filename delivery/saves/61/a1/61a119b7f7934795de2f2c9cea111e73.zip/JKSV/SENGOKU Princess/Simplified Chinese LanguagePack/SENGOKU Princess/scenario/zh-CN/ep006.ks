
*start

;//==============================
;//２、信玄に仕える

*select_root23|对信玄大人的忠诚。

;#################################################
*Ep006|对信玄大人的忠诚。
;#################################################
;//ブラックアウト

[SCENE id=6]


[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]


[OnName num="keitarou"]
我是.......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen074"]
[OnName num="shingen"]
我是什么？让我听听你的回答。"
[cpg cn=true]


我想，我和信玄大人在一起比和信长大人在一起要好。
[cpg]

如果历史事实是真实的，她就不会在战场上被杀。
[cpg]

我记得，她死于疾病。与谦信的战斗也是没有结果的，不是吗？......
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="4/5" time=800]

[VOICE f="Ranmaru457"]
[OnName num="ranmaru"]
'嘿，......，你到底在说什么？
[cpg cn=true]


兰丸大人很惊讶，但我却很坚定。
[cpg]

[OnName num="keitarou"]
'是的。我将为信玄大人服务。
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]

[VOICE f="Singen075"]
[OnName num="shingen"]
'我很高兴。你已经下定决心。
[cpg cn=true]


[FACE method="change_3" pos="4/5"]

[VOICE f="Ranmaru458"]
[OnName num="ranmaru"]
我一直在跟踪你，想阻止你。你知道这意味着什么吗？
[cpg cn=true]


[FACE method="change_3" pos="4/5"]

[VOICE f="Ranmaru459"]
[OnName num="ranmaru"]
即使你和我不成为敌人，我也不能离开你。
[cpg cn=true]


[OnName num="keitarou"]
但你不会杀我，对吗？
[cpg cn=true]

[FACE method="change_4" pos="4/5"]
对我来说，这是一个决定性的决定。我相信兰丸大人知道这一点。
[cpg]

[OnName num="keitarou"]
别担心，我不会攻击信长大人。我不会攻击信玄大人。
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru460"]
[OnName num="ranmaru"]
'你会后悔的，.......圭太郎。
[cpg cn=true]


但是兰丸大人没有再说话。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

从那天起，我就要为信玄大人服务。
[cpg]

兰丸大人离开了。我有一段时间不会再见到她了。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen076"]
[OnName num="shingen"]
'真的，你是一个读心者，不是吗？我想知道她是否为我感到遗憾。
[cpg cn=true]


[OnName num="keitarou"]
'我不明白你为什么离我这么近。为什么？
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen077"]
[OnName num="shingen"]
我不知道。我不认为一见钟情足以让你信服。
[cpg cn=true]


信玄大人看向远方。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen078"]
[OnName num="shingen"]
我决心要活下去。在这样的时代，谁不愿意呢？
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen079"]
[OnName num="shingen"]
'让我告诉你一些事情。我没有被你或任何东西吸引。
[cpg cn=true]


[OnName num="keitarou"]
...... 我明白了。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Singen080"]
[OnName num="shingen"]
我需要你，是指我想交更多的朋友。但这就是全部。"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Singen081"]
[OnName num="shingen"]
我听说......，你有奇怪的传言，我不能让你一个人呆着。
[cpg cn=true]


也许对信玄大人来说，她知道未来很重要。
[cpg]

她比大多数人更了解死亡。
[cpg]

当她说她不喜欢我这样的时候，我无话可说。
[cpg]

这很自然。甚至在我看来，这也很好。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen082"]
[OnName num="shingen"]
'我体弱多病，所以我已经放弃了孩子，但......，我会做这些事情来维持你们的关系。
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

然后，信玄大人把他的嘴唇放在我的嘴唇上。
[cpg]

[OnName num="keitarou"]
'......，在这样的地方，这不是好事。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Singen083"]
[OnName num="shingen"]
'如果不是在这样的地方，会不会更好？
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

我吻她。我确定她在那里。
[cpg]

;//移植前シーンカット
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

与其说是我和信玄大人之间的联系越来越紧密......，不如说是我逐渐了解了她的性格。
[cpg]

她仍然很悲观，已经放弃了孩子。我想以某种方式鼓励她。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen136"]
[OnName num="shingen"]
'我想知道你是否不打算上战场。
[cpg cn=true]


[OnName num="keitarou"]
...... 你是什么意思？　你想让我成为一名士兵吗？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Singen137"]
[OnName num="shingen"]
'不，我没有。我想让你成为一个配得上我的军事指挥官。
[cpg cn=true]


信玄大人与谦信战斗了很长时间。
[cpg]

所谓的川中岛之战。信玄大人一定多次经历过死亡。
[cpg]

[OnName num="keitarou"]
信玄大人将在未来留下。......
[cpg cn=true]


我想我说的时候已经说漏嘴了。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Singen138"]
[OnName num="shingen"]
'所以你毕竟是来自未来。我听说了一些传言。"
[cpg cn=true]


我倍感惊讶。第一，你知道这件事，第二，你相信它。
[cpg]

[OnName num="keitarou"]
'......，你相信我吗？这种事情'。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen139"]
[OnName num="shingen"]
是的，我也这么认为。我以为你没有跳出框框思考问题。
[cpg cn=true]


当我来到这个时代，除了信长大人，我不能告诉任何人我来自未来。
[cpg]

但信玄大人马上就相信了我。这让我多少有些高兴。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


然后，几个月过去了。另一场战争即将发生。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『戦場』（昼）******************************************************

即使在今天，人们也知道，信玄大人作为军事指挥官的才能是相当大的。
[cpg]

对谦信来说也是如此。
[cpg]

[OnName num="keitarou"]
'......，我不相信我在做这个。
[cpg cn=true]


我也要在战场上。作为一名指挥官。
[cpg]

信玄大人教会了我们如何在战场上四处走动的基础知识。
[cpg]

他们是优秀的士兵。他甚至告诉我，在最坏的情况下，我不需要做任何事情。
[cpg]

但这并不意味着我可以只听他们的话。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f=se019]
;//【ＳＥ】『つばぜり合い』
[WAIT time=1100]

我取得了一些军事上的成功，但战斗始终没有解决。
[cpg]

这么容易解决，是不是很奇怪？
[cpg]

这是一场将被载入日本历史的战斗。它也因一场从未解决的战斗而闻名。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen140"]
[OnName num="shingen"]
你的工作做得很好。
[cpg cn=true]


[OnName num="keitarou"]
"...... 不。一想到我杀了人，我的手还是会发抖。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Singen141"]
[OnName num="shingen"]
'是的，它是这样。'当我想到你是个杀人犯时，我做不到。
[cpg cn=true]


信玄大人似乎已经猜到我在想什么。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen142"]
[OnName num="shingen"]
我想知道在你生活的世界里是否有战争？
[cpg cn=true]


[OnName num="keitarou"]
'不，它是和平的。我想把信玄大人带到那个时代。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
信玄笑了。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

从那时起，信玄大人的话就没有什么变化。
[cpg]

你不能和我生孩子。即使我可以，我生完孩子后会安全吗？
[cpg]

即使没有，他也说他随时都有可能死亡。
[cpg]

我并不是因为听了她的话而感到沮丧。相反，它让我思考。
[cpg]

我开始思考如何在这个时候利用我的生命。
[cpg]


[window target=false]
[BG f="b_13_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

后来，有一天的下午 在城堡外的一个小地方，我从信玄大人那里听到了这个故事。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen143"]
[OnName num="shingen"]
'我想雇佣一个忍者。你怎么看？"
[cpg cn=true]


[OnName num="keitarou"]
...... 忍者，嗯？
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Singen144"]
[OnName num="shingen"]
'你很了解他们。我也被称为忍者。
[cpg cn=true]


我思索着。我知道，武田信玄是战国时期雇佣忍者最多的封建主。
[cpg]

[OnName num="keitarou"]
'...... 会很好，不是吗？
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen145"]
[OnName num="shingen"]
'是的。如果你这么说，我想知道忍者是否在某种程度上是有效的。
[cpg cn=true]


我没有那方面的详细知识。
[cpg]

我无法给你一个直接的答案，但只要它出现在历史上，它一定在某种程度上起了作用。
[cpg]

[OnName num="keitarou"]
在战国时期，不是有一种非常类似于忍者的东西吗？守园人......？
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Singen146"]
[OnName num="shingen"]
'是的，他们是。我不知道，我从来没有听说过它。
[cpg cn=true]


我告诉信玄大人，想知道那是否是在江户时代。
[cpg]

[OnName num="keitarou"]
'这就是所谓的隐蔽性。'他们是从事间谍活动的人。
[cpg cn=true]


忍者、朝臣和其他各种形式的类似间谍的人都被传到了未来。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen147"]
[OnName num="shingen"]
'...... 右。我已经下定决心了'。
[cpg cn=true]


听到这里，信玄大人似乎下定了决心。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Singen148"]
[OnName num="shingen"]
'我认为你是从事间谍工作的合适人选。你知道未来。
[cpg cn=true]


[OnName num="keitarou"]
'...... me?
[cpg cn=true]


当他这么说时，我很纠结。
[cpg]

如果我在这里成为一名情报人员，我可能会被抓到，并被谦信方面收编。
[cpg]

如果你想接近信玄大人，最好不要接受。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen149"]
[OnName num="shingen"]
你怎么看？你会去找谦信的地方吗？
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


我想了想是否接受，并给出了我的答案。
[cpg]



;//１、受け入れる２、受け入れない　があった場所　必要無し　このままシナリオは進行


[OnName num="keitarou"]
'好的。如果你想让我成为一个秘密特工，我就会成为。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen150"]
[OnName num="shingen"]
'你这么快就回答了。这让人放心。
[cpg cn=true]


我决定接受。我想听从信玄大人的话，虽然我也想知道自己是否能胜任这项工作。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

从那一天起，我开始准备。
[cpg]

我有一次不得不离开信玄大人的地方。尽管那是不可避免的，......
[cpg]

我也不能不为我最终的回归做准备。
[cpg]

我曾经作为指挥官带过兵，打过仗。
[cpg]

考虑到这一点，没有理由......，但我还是很紧张。
[cpg]

[OnName num="keitarou"]
我别无选择，只能...... 做。
[cpg cn=true]


这正是信玄大人的愿望。我没有选择，只能对此作出回应。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

信玄大人已经雇佣了忍者。我是第一个与他们汇合的人。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen151"]
[OnName num="shingen"]
他是忍者的领袖。他有一定的技能。
[cpg cn=true]


[OnName num="ninja"]
'很高兴见到你。要加入我们的人，庆太郎大人，是你，对吗？
[cpg cn=true]


他们似乎对我有些尊敬，因为我原本就站在战场上。
[cpg]

[OnName num="keitarou"]
'......，这些人是谁？
[cpg cn=true]


[OnName num="ninja"]
'他们是女忍者。
[cpg cn=true]


他们没有穿成这样。我想到的第一件事是，妇女们的穿着并不像那样，而是像一个女人。
[cpg]

仔细观察后，似乎这些人是作为行走的女巫潜伏在周围，即不属于神社的女祭司。
[cpg]

[OnName num="keitarou"]
'这不是我所知道的，是吗？
[cpg cn=true]


[OnName num="ninja"]
'可能是这样的。我将把我所有的知识传授给你。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen152"]
[OnName num="shingen"]
'这很令人鼓舞。我认为这对庆太郎来说将是一个很好的经验。
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


他将学习与他所知不同的东西，他将学习如何成为一个隐身的忍者。
[cpg]

这可能不是像漫画中那样使用忍术。
[cpg]

他只需牢记，他不会被发现或注意到。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

虽然他暂时没有直接去谦信的地方，但他潜入的时机终将到来。
[cpg]

[OnName num="keitarou"]
我想我们要和你说再见了，有一段时间了。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen153"]
[OnName num="shingen"]
是的。确保你能活着回来。
[cpg cn=true]


我很遗憾地说再见。信玄大人可能也有同感。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen154"]
[OnName num="shingen"]
嘿，我想请你帮个忙。
[cpg cn=true]


[OnName num="keitarou"]
它是什么？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="sSingen001"]
[OnName num="shingen"]
这是除了你之外我无法要求别人的东西。
[cpg cn=true]


信玄大人带来了一件和服。'一件和服，或者说，这个。
[cpg]

[OnName num="keitarou"]
'忍者的服装，是吗？
[cpg cn=true]


信玄大人点了点头。我想知道她要用它来做什么。......
[cpg]

她开始要求看我换成这样。
[cpg]

[OnName num="keitarou"]
信玄大人，你不会是打算自己去当忍者吧？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
当我问她时，她摇了摇头。
[cpg]

她只是对这种服装感兴趣。
[cpg]

我不知道这是否因为她也是个女人。她可能希望你看到她穿得和平时不一样。......
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（忍び装束のヒロイン。座っている）ev_56
;//人物１：ヒロイン２　服装１：忍装束
;//場所　：城＿室内
;//時間　：夜
;//========================================

[SE f=se001]
;//【ＳＥ】『衣擦れ』

[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_56_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]



我离开房间一次，在她换完衣服后再进去。
[cpg]

信玄大人看起来有点尴尬。
[cpg]

[OnName num="keitarou"]
'这很适合你。
[cpg cn=true]


我不知道我是否可以这样说。但她似乎很高兴。
[cpg]

信玄大人说她愿意不惜一切代价来吸引我的注意。
[cpg]

我看着她，想知道这毕竟是事情的真相。
[cpg]


;**【ＣＧ】 ev_56_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSingen002"]
[OnName num="shingen"]
'我把我的......，所以我不能穿着这身衣服吻你。
[cpg cn=true]


当她说她不喜欢我这样的时候，我无话可说。
[cpg]


;//移植前シーンカット
;//【ＢＧ】『城＿室内』（夜）
;//ブラックアウト
;//移植前シーンカット

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

无论我和信玄大人谈了多少，都不够。
[cpg]

但这一天已经临近，我将在去往谦信家的路上。
[cpg]

我再次下定决心，我要活着回去。
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

于是，我向谦信居住的城堡走去。
[cpg]

我将找出他的行军方式，还是刺杀谦信本人？
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen203"]
[OnName num="shingen"]
'以高超的技巧。
[cpg cn=true]


[OnName num="keitarou"]
是的，我是。我将回报你的帮助。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Singen204"]
[OnName num="shingen"]
和间谍活动一样，别忘了，你活着回来，就欠我一个人情。
[cpg cn=true]


[OnName num="keitarou"]
我明白。那就好。
[cpg cn=true]


我和忍者们一起离开。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

沿着山路行走的忍者速度非常快。
[cpg]

我以前也这样想过，但这个时代的人走得非常快。
[cpg]

[OnName num="ninja"]
'你已经累了吗？如果你想休息，你最好快点说。
[cpg cn=true]


[OnName num="keitarou"]
'...... 不，我很好。我很好。
[cpg cn=true]


在某种程度上，你必须逼迫自己，认为这是为了增强你的体能。
[cpg]


[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

睡在山路中间也是我还不习惯的事情。
[cpg]

忍者们轮流站岗。我不是其中的一员。
[cpg]

每个人都在为我着想。我想部分原因是我直接为信玄大人服务。
[cpg]

我为自己感到羞愧，但同时我也认为我一定会有所作为。
[cpg]


[window target=false]
[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

几天过去了。我终于赶到了城堡。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

[OnName num="ninja"]
'我们要闯进去。你准备好了吗，庆太郎大人？
[cpg cn=true]


[OnName num="keitarou"]
是的，我已经准备好了。我尽量不拖后腿。
[cpg cn=true]


[OnName num="ninja"]
很好。如果逼不得已，我有可能会丢下你而逃跑。
[cpg cn=true]


[OnName num="ninja"]
反过来也是如此。如果我们失败了，你可以直接跑掉。
[cpg cn=true]


[OnName num="keitarou"]
...... 是的。
[cpg cn=true]


我们必须这样做。现在已经没有回头路了。
[cpg]


;//ブラックアウト


;//※ストーリーが分岐
;//　勝利した場合、ヒロイン２ルートへ
;//　敗北した場合、ヒロイン３ルートへ


;//伏兵の代わりに「音の鳴るマス」という部分があります
;//伏兵と同様、二度通ることで敗北判定となります
;//音の鳴るマスは、２、３、７、８に配置されています

;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※謙信の所へ潜入　開始時（１のマスにいる場合のシナリオ）※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※

;//ブラックアウト

;//[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_07"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

;//ヒロイン３の立ち絵を表示してください

我们前往谦信的住处，躲在她居住的城堡阁楼里。
[cpg]

有一些地方的材料似乎是不同的。......，是在东方的方向。
[cpg]

我想知道在这个时期是否有顽童装饰品这种东西。
[cpg]

是否有可能把它种在阁楼上？谨慎行事。
[cpg]


;//■選択肢
[switch]
[case "向南前进。"]
	[swap]
	[jump target="*select04_4"]
[case "继续向东走。"]
	[swap]
	[jump target="*select04_2"]
[endswitch]

1，向南前进。
2，向东行进。


;//==============================
;//１、南へ進む

;//同じイベント中の「４のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「２のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※２のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_2|忠于信玄大人。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン３の立ち絵を表示してください

[SE f=se029]
;//【ＳＥ】『木材きしむ』

;//qwe
[stflag Selectflg4=1]


我听到木头吱吱作响。我停下来，惊慌失措。
[cpg]

就在我下面的谦信，正抬头看着我。我可以通过缝隙看到他: ......
[cpg]

这一边没有光，所以他应该看不到我们。
[cpg]

但我能听到声音。最好的办法是保持警觉。
[cpg]


;//■選択肢
[switch]
[case "继续向南走。"]
	[swap]
	[jump target="*select04_5"]
[case "向东行进。"]
	[swap]
	[jump target="*select04_3"]
[endswitch]

一，向南走。
[cpg]

二，向东前进。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「３のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※３のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_3|对信玄大人的忠诚。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン３の立ち絵を表示してください

[if exp={getFlagValue("Selectflg4") == 1 }]
[jump target="*select04_3_t"]
[endif]

[jump target="*select04_3_f"]


;//==============================
;//２のマスか７のマスを通っている場合

*select04_3_t|对信玄大人的忠诚。

[SE f=se029]
;//【ＳＥ】『木材きしむ』

[WAIT time=1000]

[FACE method="change_3" pos="2/3"]

谦信又看了看我。
[cpg]

我看到他在为人们打电话。按照这种速度，我们甚至有可能回不来了。
[cpg]

[OnName num="keitarou"]
'这不是好事。......
[cpg cn=true]


躲在阁楼上，我甚至可能失去逃跑的路线。
[cpg]

我决定趁着还能逃跑。
[cpg]


;//敗北判定となる
;//「謙信の所へ潜入　二度音の鳴るマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン３ルートへ続く

[jump target="*select04_lose"]


;//==============================
;//２のマス、７のマスいずれも通っていない場合

*select04_3_f|对信玄大人的忠诚。


[SE f=se029]
;//【ＳＥ】『木材きしむ』

[stflag Selectflg4=1]

[WAIT time=1000]

[FACE method="change_7" pos="2/3"]

我听到木头吱吱作响的声音。我惊慌失措，停了下来。
[cpg]

就在我下面的谦信，正抬头看着我。我可以通过缝隙看到他: ......
[cpg]

这一边没有光，所以他应该看不到我们。
[cpg]

但我能听到声音。最好的办法是保持警觉。
[cpg]


;//■選択肢
[switch]
[case "向南前进。"]
	[swap]
	[jump target="*select04_6"]
[endswitch]

1，向南行进。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※４のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_4|忠于信玄大人。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

小心翼翼地前进，以免发出声音。
[cpg]

......，听一听，听一听，听一听谦信。
[cpg]

现在，地板在向南的方向上改变了颜色。你必须要小心。
[cpg]


;//■選択肢
[switch]
[case "继续向南走。"]
	[swap]
	[jump target="*select04_7"]
[case "继续向东走。"]
	[swap]
	[jump target="*select04_5"]
[endswitch]

1，向南行进。
[cpg]

2，向东行进。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「７のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※５のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_5|对信玄大人的忠诚。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

可以听到谦信的独白。也许他正试图给某人打电话。
[cpg]

这是因为他感觉到了我的存在，还是他在和别人谈论即将到来的战斗？
[cpg]

如果是后者，我就不能不听。
[cpg]


;//■選択肢
[switch]
[case "向南前进。"]
	[swap]
	[jump target="*select04_8"]
[case "向东走。"]
	[swap]
	[jump target="*select04_6"]
[endswitch]

1，向南前进。
[cpg]

2，向东行驶。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※６のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_6|对信玄大人的忠诚。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

最后，我们已经走了这么远，可以近距离地看到谦信。
[cpg]

我不能松懈，直到最后。我在慢慢地走。......
[cpg]


;//■選択肢
[switch]
[case "向南行进"]
	[swap]
	[jump target="*select04_9"]
[endswitch]

1，向南前进。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※７のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_7|对信玄大人的忠诚。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン３の立ち絵を表示してください

[SE f=se029]
;//【ＳＥ】『木材きしむ』

[stflag Selectflg4=1]

[WAIT time=1000]

[FACE method="change_7" pos="2/3"]


我听到木头吱吱作响的声音。我停下来，惊慌失措。
[cpg]

就在我下面的谦信，正抬头看着我。我可以通过缝隙看到他: ......
[cpg]

这一边没有光，所以他应该看不到我们。
[cpg]

但我能听到声音。最好的办法是保持警觉。
[cpg]


;//■選択肢
[switch]
[case "继续向东走。"]
	[swap]
	[jump target="*select04_8"]
[endswitch]

1，向东行进。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※８のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_8|对信玄大人的忠诚。

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン３の立ち絵を表示してください

[if exp={getFlagValue("Selectflg4") == 1 }]
[jump target="*select04_8_t"]
[endif]

[jump target="*select04_8_f"]


;//==============================
;//２のマスか７のマスを通っている場合

*select04_8_t|对信玄大人的忠诚。

[SE f=se029]
;//【ＳＥ】『木材きしむ』

[WAIT time=1000]

[FACE method="change_3" pos="2/3"]

谦信又看了看我。
[cpg]

我看到他在为人们打电话。按照这种速度，我们甚至有可能回不来了。
[cpg]

[OnName num="keitarou"]
'这不是好事。......
[cpg cn=true]


躲在阁楼上，我甚至可能失去逃跑的路线。
[cpg]

我决定趁着还能逃跑。
[cpg]


;//敗北判定となる
;//「謙信の所へ潜入　二度音の鳴るマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン３ルートへ続く

[jump target="*select04_lose"]


;//==============================
;//２のマス、７のマスいずれも通っていない場合

*select04_8_f|对信玄大人的忠诚。


[SE f=se029]
;//【ＳＥ】『木材きしむ』

[stflag Selectflg4=1]

[WAIT time=1000]

[FACE method="change_7" pos="2/3"]


我听到木头吱吱作响的声音。我惊慌失措，停了下来。
[cpg]

就在我下面的谦信，正抬头看着我。我可以通过缝隙看到他: ......
[cpg]

这一边没有光，所以他应该看不到我们。
[cpg]

但我能听到声音。最好的办法是保持警觉。
[cpg]


;//■選択肢
[switch]
[case "继续向东走。"]
	[swap]
	[jump target="*select04_9"]
[endswitch]

1，向东行进。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※９のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select04_9|对信玄大人的忠诚。



;//勝利判定

;//謙信の所へ潜入　勝利した場合
;//と書いてあるところまで飛ぶ（ヒロイン２ルートに入る


[jump target="*select04_win"]



*select04_lose
[jump storage="ep007.ks" target="*start"]



*select04_win
[jump storage="ep008.ks" target="*start"]

