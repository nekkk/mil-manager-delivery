
*start

;//==============================
;//１、仕えるつもりはない

*select_root145|对信长的忠诚


;#################################################
*Ep001|对信长大人的忠诚。
;#################################################

[SCENE id=1]

[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]

[stflag Selectflg1=0]
[stflag Selectflg2=0]
[stflag Selectflg3=0]
[stflag Selectflg4=0]


[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]


[OnName num="keitarou"]
'......，我很抱歉，但我没有意愿为你服务。
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

信玄大人怔了一会儿，然后把头转向一边。
[cpg]

[FACE method="bow_4" pos="2/3"]

[VOICE f="Singen067"]
[OnName num="shingen"]
'...... 是的。这真是太可惜了。"
[cpg cn=true]


他看起来很夸张地悲伤。
[cpg]

但它看起来不像是在演戏。他一定是真的喜欢我。
[cpg]

[OnName num="keitarou"]
'我很抱歉。但信长大人也在等我回来。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen068"]
[OnName num="shingen"]
'你不需要道歉。这意味着我还不够好。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

她觉得我有什么吸引人的地方？
[cpg]

你知道我是来自未来吗？
[cpg]

信长大人敢于散布这样的谣言，这可能吗？......
[cpg]

我脑子里有很多想法。你甚至有可能再也见不到信玄大人了。
[cpg]

但我又想，我将为信长大人服务。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（朝）******************************************************

然后早晨就来了。那是出发的日子。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru046"]
[OnName num="ranmaru"]
...... 景太郎，你是不是被信玄大人误导了？
[cpg cn=true]


[OnName num="keitarou"]
你为什么这么想？"
[cpg cn=true]


我回答说，尽量让自己显得平静。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru047"]
[OnName num="ranmaru"]
不，信玄大人可能是想让你站在他那边。
[cpg cn=true]


这句话很有意思。我以为兰丸大人不评价我。
[cpg]

[OnName num="keitarou"]
'......，你怎么会这样想？
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru048"]
[OnName num="ranmaru"]
不要重复说同一件事。只是信长大人这么说而已。
[cpg cn=true]


看来，信长大人也提前看清了形势。
[cpg]

甚至有可能他们会问我从哪里来。
[cpg]

如果我在那里回答的话，信长可能已经想到了。
[cpg]

;//ブラックアウト

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

然后再走山路。如果我真的没有更多的耐力，如果我忽视了俱乐部的活动，我就无法走路。
[cpg]



[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

此外，还有可能会出现土匪。
[cpg]

这个时代真的是充满了不便。......。
[cpg]


[window target=false]
[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

几天和几夜过去了。这是回程，而不是去的路上，而且你在往返的过程中已经疲惫不堪。
[cpg]

然后，在我失去意识的时候...
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

最后，城堡出现在视野中。知道我又回家了，我松了一口气。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru049"]
[OnName num="ranmaru"]
'你真的没有任何耐力，是吗？
[cpg cn=true]


[OnName num="keitarou"]
...... 兰丸大人瘦弱的身体比我有更多的耐力，这真是个奇迹。
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Ranmaru050"]
[OnName num="ranmaru"]
'不要把我当做那些女人之一。即使这样，我相信信长大人在某种程度上还是信任我。
[cpg cn=true]


我想事情就是这样的。身体健康是一切的先决条件。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

当我们在搬家后筋疲力尽时，信长大人叫我。
[cpg]

我担心我可能会和她说话，在这种失势的情况下说些无礼的话，但我还是走了过去。
[cpg]



;//========================================
;//●ＣＧ（紹介ページヒロイン１のＣＧ）ev_91
;//人物１：ヒロイン１　服装１：着衣
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//備考　：可能であれば背景を足してください
;//========================================


[free time=1000]
;**【ＣＧ】 ev_91_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Nobunaga066"]
[OnName num="nobunaga"]
'你已经回来了，很好。你在某种程度上为我着想'。
[cpg cn=true]


信长大人似乎很欣赏我没有和信玄大人调情的事实。
[cpg]

[OnName num="keitarou"]
'......，这是.......
[cpg cn=true]


我不能说这是因为我害怕你。
[cpg]

[OnName num="keitarou"]
'无论如何，都很难走。'在我的时代，就不会有这么多的步行。
[cpg cn=true]



[VOICE f="Nobunaga067"]
[OnName num="nobunaga"]
'我想我也应该体验一下这个时期的交通手段等等。
[cpg cn=true]



[VOICE f="Nobunaga068"]
[OnName num="nobunaga"]
'也许在未来，马匹会更加发达。在未来，马匹可能会更加发达，而且可能会有更多的马匹。
[cpg cn=true]


在这个时代，马匹是非常有价值的。它们不能被轻易使用。
[cpg]

除此之外，信长大人还看到，在未来会有更多的运输工具。
[cpg]

当然，这不是马，而是...... 汽车，我不认为他会得到这个消息。
[cpg]


[VOICE f="sNobunaga001"]
[OnName num="nobunaga"]
'顺便说一句，你不喝酒？
[cpg cn=true]


[OnName num="keitarou"]
'...... 不太擅长。
[cpg cn=true]


我明白了，"信长大人说，看起来有点悲伤。
[cpg]

她可能是个相当爱喝酒的人，不知为何，这很适合她。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我又睡了一会儿，疲惫不堪。
[cpg]

我没有时间再去想什么，也没有时间去做梦。
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

然后第二天早上，我比往常更晚醒来。
[cpg]

我的肌肉又疼了。如果这些日子继续下去，我总有一天会受伤。......
[cpg]


[window target=false]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

但这并不意味着我有什么特别的工作要做。
[cpg]

我有足够的时间来考虑这个和那个。
[cpg]

我怎样才能回到我的世界？
[cpg]

如果屏幕是触发器，在这个世界上是否有对应的东西？
[cpg]

在我这样想的时候，我遇到了另一个女孩。
[cpg]

她正在照看她的盆景。她一看到我，就转过身来，深深地鞠了一躬。
[cpg]


;//光秀の名前を「少女」と隠してください

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mituhide001"]
[OnName num="girl"]
'很高兴见到你。我听说过很多关于你的事情。你当然有一种神秘的气氛。
[cpg cn=true]


[OnName num="keitarou"]
'...... 很高兴见到你。我的名字是须藤景太郎。
[cpg cn=true]



;//ここから光秀の名前を隠さないでください

[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide002"]
[OnName num="mitsuhide"]
我的名字是明智光秀。我也为信长大人服务。"
[cpg cn=true]


光秀明智......，她也是一名军事指挥官。
[cpg]

一个应该背叛信长大人的人。
[cpg]

但是，像光秀这样优秀的将军仍然应该有自己的城堡，不是吗？
[cpg]

[OnName num="keitarou"]
......为什么，在这样的地方？
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
我想知道 "为什么在这里 "这句话是否足以传达这个信息。光秀大人正茫然地盯着。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide003"]
[OnName num="mitsuhide"]
'信长大人喜欢盆景。我被召集到这里是为了谈论盆景。
[cpg cn=true]


[OnName num="keitarou"]
Heh. ......
[cpg cn=true]


这多少有些令人惊讶。信长大人会对这样的事情感兴趣。
[cpg]

[OnName num="keitarou"]
我明白了。这听起来不像是信长大人。"
[cpg cn=true]


我想知道，说这样的话是否有点不礼貌。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide004"]
[OnName num="mitsuhide"]
是这样的吗？　正是因为我们生活在这样一个时代，我认为与生物接触很重要。
[cpg cn=true]


光秀大人说，盆景是一种生物。
[cpg]

这就是即使在这个时代也存在的那种思维。自然如此。......
[cpg]

相反，正因为是战国时期，我们才可能感受到植物中的生物性。
[cpg]

在现代，即使是观赏性植物也是人工的。
[cpg]

[OnName num="keitarou"]
'......，可能是这样的。
[cpg cn=true]


说话的同时，我想了想。如果有一天这个人杀了信长，他会告诉信长吗？
[cpg]

但如果我这样做，我就会改变未来。我不知道会发生什么。
[cpg]


[free time=1]
[WAIT time=1]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Ranmaru051"]
[OnName num="ranmaru"]
'啊，光秀...... 在这里？
[cpg cn=true]


当我在想这个问题的时候，兰丸大人来到我身边。
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="Mituhide005"]
[OnName num="mitsuhide"]
'这是什么？　兰丸，你想从我这里得到什么？
[cpg cn=true]


兰丸大人和光秀大人互相呼唤。
[cpg]

在这个时代的等级制度方面，情况如何？
[cpg]

难道说，这两个人都不占优势吗？首先，他们的立场是完全不同的。
[cpg]

[FACE method="shake_7" pos="4/5"]

[VOICE f="Ranmaru052"]
[OnName num="ranmaru"]
两者在这个时代的地位是不一样的。信长大人要见你，你觉得你来城堡是为了什么？
[cpg cn=true]


兰丸大人的话中带着刺。不知为何，我可以猜到他们三人之间的关系。
[cpg]

光秀大人和兰丸大人都为信长大人服务。
[cpg]

除此之外，兰丸喜欢信长大人，所以也许他把光秀大人视为对手。
[cpg]

如果是这样的话，他们互相呼唤是有道理的。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide006"]
[OnName num="mitsuhide"]
'我明白。然后，让我们再次见面。景太郎先生。
[cpg cn=true]


[OnName num="keitarou"]
是的，是的。
[cpg cn=true]


你叫我 "先生"，而兰丸大人叫我 "先生"。我当时有点紧张。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

在我无所事事的时候，战国的世界正在急剧变化。
[cpg]

我听说一个叫斎藤道三的人已经死了。
[cpg]

我知道他是一个军事指挥官，但我并不清楚他与信长大人有什么样的关系。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Nobunaga069"]
[OnName num="nobunaga"]
'我明白了。这样的意愿，.......'
[cpg cn=true]


我第一次看到他时，觉得太快了，但事情发展得太快了。
[cpg]

我仍然认为这与我知道的历史不同。
[cpg]

[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru053"]
[OnName num="ranmaru"]
我们应该如何处理......？信长大人。"
[cpg cn=true]


据说，他留下了一份遗嘱，说他将把美浓国交给信长大人。
[cpg]

死因没有具体提及，但可能不是死于疾病。
[cpg]

如果他在战斗中死亡......，我不知道信长大人是否知道自己的死亡。
[cpg]

[FACE method="shake_7" pos="2/5"]

[VOICE f="Nobunaga070"]
[OnName num="nobunaga"]
'至于我，是以失去支持的形式。现在我们该怎么做？"
[cpg cn=true]


光秀大人和兰丸大人都显得很紧张。
[cpg]

在这一生中，我从未经历过如此紧张的情况。
[cpg]

这并不奇怪,......，涉及生命和死亡的问题在现代世界并不存在。
[cpg]

[FACE method="bow_3" pos="2/5"]

[VOICE f="Nobunaga071"]
[OnName num="nobunaga"]
'看来柴田胜家也出现了一些令人不安的动作。我们要不要从这里出击？"
[cpg cn=true]


我不知道这个柴田胜己是谁。
[cpg]

我瞥了一眼兰丸大人，但她仍然沉默不语。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru054"]
[OnName num="ranmaru"]
事情变得有点棘手了。但现在看起来已经没有回头路了。
[cpg cn=true]


当我和兰丸大人走在走廊上时，她正在谈论这个问题。
[cpg]

[OnName num="keitarou"]
'战争，是吗？
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Ranmaru055"]
[OnName num="ranmaru"]
'百分之九十九的时间都会如此。我也要离开了'。
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


我无法想象那是什么样子的。信长大人和兰丸大人正在带兵。
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

我回到我指定的房间，思索着。
[cpg]

柴田胜江。我从这个名字中追寻我朦胧的记忆。
[cpg]

伊瑙这个名字也来自信长大人的故事。是否有一场名为伊瑙之战的战斗？
[cpg]

不。......，事实上，我甚至不需要好好回忆。信长大人不应该经历失败。
[cpg]

或者他至少可能已经从战场上逃走了。
[cpg]

无论如何，他在接管国家之前并没有死。我知道这么多。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夕方）******************************************************

我无法站稳脚跟，所以我走出了城堡，待了一会儿。
[cpg]

也许是看到了我，光秀大人来找我了。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Mituhide007"]
[OnName num="mitsuhide"]
我不知道你有什么问题，景太郎先生。你看起来很苍白。
[cpg cn=true]


[OnName num="keitarou"]
哦，那是.......
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide008"]
[OnName num="mitsuhide"]
...... 不，这是没办法的事。....... 这意味着你也可能在战场上"。
[cpg cn=true]


我不这么认为。信长大人还说，他要让我当军事指挥官。
[cpg]

[OnName num="keitarou"]
'别担心。我不期望你只是让我活着，而不做任何事情'。
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Mituhide009"]
[OnName num="mitsuhide"]
'我认为牢记这一点很重要，但请不要过度。
[cpg cn=true]


光秀山说，并显得很担心。
[cpg]

我应该...... 做什么？
[cpg]

如果信长大人让你出去打仗，我会去......？
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

那天晚上。信长大人叫我，我正在去她房间的路上。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga072"]
[OnName num="nobunaga"]
'你也会出征战场吗？　你可以挥舞着剑，不是吗？
[cpg cn=true]


她说出了我所担心的事情。
[cpg]

我在这里如何回答是很重要的。光秀大人曾说，没有必要把自己逼得太紧。
[cpg]

但我也想满足信长大人的期望。......
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga073"]
[OnName num="nobunaga"]
'你不需要马上回答。如果你不想杀人，那也没关系。"
[cpg cn=true]


经过一些犹豫，我给出了我的答案。
[cpg]

[OnName num="keitarou"]
'......，我也要出去。我现在有免费的饭吃了。"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga074"]
[OnName num="nobunaga"]
你很勇敢，这很好。我就指望你了。"
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

那天我无法入睡，因为我的眼睛很模糊。
[cpg]

但我下定决心。我不打算再跑了。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru056"]
[OnName num="ranmaru"]
"嘿，景太郎。我听说你要参加井冈山之战？
[cpg cn=true]


[OnName num="keitarou"]
是的。......，那么...
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru057"]
[OnName num="ranmaru"]
多么不可靠的答案。
[cpg cn=true]


我不太确定，但我问兰丸大人她有什么要说的。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru058"]
[OnName num="ranmaru"]
信长大人要让你成为军事指挥官。这意味着他将把一定数量的部队交给你。
[cpg cn=true]


[OnName num="keitarou"]
'......，我将负责人们的生活？
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Ranmaru059"]
[OnName num="ranmaru"]
当然了。我知道，光秀也知道。"
[cpg cn=true]


...... 是这样的，不是吗？我们的生活中，有很多人都在为自己的生活而奔波，有很多人都在为自己的生活而奔波，有很多人都在为自己的生活而奔波，有很多人都在为自己的生活而奔波。
[cpg]

如果我做不到呢？
[cpg]


[free time=1]
[WAIT time=1]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="4/5" time=800]

[VOICE f="Mituhide010"]
[OnName num="mitsuhide"]
'这是什么？　你们两个人在进行私人谈话吗？
[cpg cn=true]


然后，光秀大人来了。我想到的是，你们两个人的关系并不简单。
[cpg]

[FACE method="shake_7" pos="4/5"]

[VOICE f="Ranmaru060"]
[OnName num="ranmaru"]
'你，......，这就对了。教导景太郎了解孙子兵法。
[cpg cn=true]


[FACE method="change_7" pos="2/5"]

[VOICE f="Mituhide011"]
[OnName num="mitsuhide"]
'在这种情况下，我认为兰丸比我更适合这个角色。......，但这很好。
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

然后，光秀大人和兰丸大人教我基本的战场战术。
[cpg]

基本战略是由信长大人制定的。我只需要遵循它。......
[cpg]

我想知道这样的事情是否可以。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

然后，在战争开始的前一天晚上。我很焦虑，无法入睡。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga075"]
[OnName num="nobunaga"]
...... 景太郎。
[cpg cn=true]


[OnName num="keitarou"]
什么？　信长大人......？"
[cpg cn=true]


信长大人在我的房间里看望我。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga076"]
[OnName num="nobunaga"]
'你睡不着，是吗？
[cpg cn=true]


[OnName num="keitarou"]
'是的，好吧，......，我以前从未发生过这样的事情。
[cpg cn=true]


我半坐起来，说。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga077"]
[OnName num="nobunaga"]
'我在战斗前也睡不着。无论我做多少次，这都是我从未习惯的事情。
[cpg cn=true]


[OnName num="keitarou"]
'像信长大人这样的人也是这样吗？
[cpg cn=true]


我说，信长大人微微皱起了眉头。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga078"]
[OnName num="nobunaga"]
他说："我不知道你是谁，但我知道你是谁。"他说："我不知道你是谁，但我知道你是谁。"他说："我不知道你是谁，但我知道你是谁。你认为我是一个无意识的怪物吗？
[cpg cn=true]


听到......，这倒是让人有些放心。信长大人是这么说的。
[cpg]

这就是他们对我们的重视程度。
[cpg]

[OnName num="keitarou"]
'......'
[cpg cn=true]


尽管如此，我们两个人之间仍然存在着一种奇怪的沉默气氛。
[cpg]


[FACE method="change_2" pos="2/3"]
信长大人正转向我并微笑着。
[cpg]

[OnName num="keitarou"]
'那么，那张脸......，是什么意思？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
没什么，信长大人说。她的笑容有点性感。
[cpg]

我想知道他们是否对我有任何感情。
[cpg]

那是一张让我觉得的脸。......。
[cpg]

[OnName num="keitarou"]
'如果没什么，那就好了。
[cpg cn=true]


但我也忍不住这么想。我想和信长大人发生什么？
[cpg]

我为什么说我要去打仗？我觉得有些深层的心理学在我没有意识到的地方起作用了。
[cpg]

信长大人是一个如此迷人的人，我是这样想的。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

然后我们离开了城堡。每个人都统一穿着厚重的盔甲。
[cpg]

他们的脸是不同的。我想，一场战斗真的要开始了。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga079"]
[OnName num="nobunaga"]
'我们走吧。
[cpg cn=true]


信长大人看起来很平静，很镇定。据她说，这应该是我们不习惯的事情。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


在信长大人的带领下，我们出发了。
[cpg]

我们要对抗的对手是柴田胜家。我甚至不知道这个军阀的名字。
[cpg]

但我们要摧毁他。即使我不亲手做，我也会成为其中的一员。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（昼）******************************************************

而......，战争即将开始。
[cpg]

据说，这场战斗也是一场家族头衔的争夺战。
[cpg]

我以为他的姓氏是不同的......，但似乎他不是为总督而战的人。
[cpg]

很可能是一个叫柴田胜家的人引诱他参与总督府的斗争。
[cpg]

如果他不这样做，他就会更公开地反叛，或者在任何情况下......。
[cpg]

对于信长大人来说，他是一个敌人。他已经成为一个必须被消灭的对手。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Nobunaga080"]
[OnName num="nobunaga"]
'活着回来。景太郎'。
[cpg cn=true]


这一个词就意味着他可能会死。
[cpg]

[OnName num="keitarou"]
'...... 当然了。
[cpg cn=true]


[free time=1000]

我回答说，并与信长大人暂时分开了。
[cpg]

他们事先被告知将有什么样的阵容。
[cpg]

我所要做的很简单。正如她所说，要活着回来。
[cpg]

当然，我不能不参加战斗。即便如此，我还有第二个角色要扮演。
[cpg]

光秀大人和兰丸大人都告诉我，我的首要任务是保护自己的生命。
[cpg]



;//※後のルート分岐に影響
;//　勝利した場合、ヒロイン１ルートへの可能性が残る
;//　敗北した場合、ヒロイン５ルートへの可能性が残る


;//稲生の戦い　マップシステム開始
;//伏兵マスは２、３、７です

;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※稲生の戦い　開始時（１のマスにいる場合のシナリオ）※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

兰丸大人似乎非常紧张。她甚至说，这不是我该做的。
[cpg]

她说，如果我想保住性命，就应该留在城堡里，但这是因为她关心我，不是吗？
[cpg]

如果我听从兰丸大人的话，我可能不必在这场战斗中战斗到最后。
[cpg]

当然，我不能死，所以这将意味着退缩。......
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（昼）******************************************************

而战斗已经开始。不是我要带路，而是我不知道伏击者在哪里。
[cpg]

南面的道路是开放的，但东面的道路则被植被所覆盖。
[cpg]

我应该走哪条路？　无论我离未来有多远，我都不知道那么多。
[cpg]

信长大人也在这个战场上。如果我做出错误的决定，我也会让信长大人的生命陷入危险。
[cpg]

不过，我从光秀大人和兰丸大人那里学到了一定的军事战术。
[cpg]

我不能把一切都交给她。她在某些方面考验我，而我必须做出一些决定。
[cpg]


;//■選択肢
[switch]
[case "向南前进。"]
	[swap]
	[jump target="*select02_4"]
[case "继续向东走。"]
	[swap]
	[jump target="*select02_2"]
[endswitch]

1，向南走。
[cpg]

二，向东前进。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「４のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「２のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※２のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_2|对信长大人的忠诚。


[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

我带领军队，但我有一种不好的感觉。
[cpg]

这就是为什么我要求信长大人留下来。当我继续前进的时候，我说：......
[cpg]

[OnName num="keitarou"]
'该死的......，我知道你还在这里。
[cpg cn=true]


埋伏的士兵在潜伏着。我不是第一个站在他们面前的人，但......
[cpg]

士兵们正在受伤。尽管我没有排在队伍的最前面，但这是我不忍直视的一幕。
[cpg]

我应该准备好因我而流的血。
[cpg]

然后，经过一番拼杀，伏击的士兵又向东移动。
[cpg]


;//■選択肢
[switch]
[case "向南行进。"]
	[swap]
	[jump target="*select02_5"]
[case "向东行进。"]
	[swap]
	[jump target="*select02_3"]
[endswitch]

1，向南行进。
[cpg]

2，向东推进。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「３のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※３のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_3|对信长大人的忠诚。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

我带领我的部队走向他们，追击伏击者。
[cpg]

但有更多的伏击部队潜伏在那里。
[cpg]


;//敗北判定となる
;//「稲生の戦い　二度伏兵のマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン５ルートへの可能性が残る


[jump target="*select02_lose"]


;//※※※※※※※※※※※※※※※※※※※※
;//※※※４のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_4

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

当我们继续行进时，我们发现南方现在是一座山。
[cpg]

如果我们按顺序走，我们应该向东推进，但我们不知道会发生什么。
[cpg]

我们想尽可能不受训练地到达敌人的大本营，但该怎么做呢？
[cpg]


;//■選択肢
[switch]
[case "向南前进。"]
	[swap]
	[jump target="*select02_7"]
[case "继续向东走"]
	[swap]
	[jump target="*select02_5"]
[endswitch]

1，向南前进。
[cpg]

2，继续向东走
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「７のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※５のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_5|对信长大人的忠诚

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン１の立ち絵を表示してください

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]


当我们向前行进时，信长大人跟着我们。
[cpg]

她不能往前走。相反，我们必须保护她。
[cpg]

[OnName num="keitarou"]
'我将带头。这很好'。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga009"]
[OnName num="nobunaga"]
'这很好。别犹豫了。
[cpg cn=true]

看到我的判断，信长大人点了点头。不知道到目前为止我是否站得住脚。
[cpg]

而且渐渐地，敌人的防线越来越近。视野是相当开阔的。
[cpg]

除非我把这里的将军干掉，否则就不是我所知道的历史了。
[cpg]

无论我做不做，我都必须赢得这场战斗。
[cpg]


;//■選択肢
[switch]
[case "向南前进。"]
	[swap]
	[jump target="*select02_8"]
[case "向东走。"]
	[swap]
	[jump target="*select02_6"]
[endswitch]

一，向南前进。
[cpg]

二，向东推进。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※６のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_6|对信长大人的忠诚

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

在我们行进的过程中，光秀大人也加入了我们。
[cpg]

[OnName num="keitarou"]
'我不相信你会参加这场战斗。尽管有兰丸大人，......"
[cpg cn=true]


据我所知，光秀大人没有参加这场战斗。
[cpg]

当我提到这一点时，光秀-大人说。
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mituhide016"]
[OnName num="mitsuhide"]
我明白了。我是不是不够？"
[cpg cn=true]

我被误解了。他似乎认为我被比作兰丸大人。
[cpg]

[OnName num="keitarou"]
'不，我不是这个意思 .......
[cpg cn=true]


敌人的营地就在眼前。我无法使自己平静下来。
[cpg]

在一个生死攸关的地方，要保持冷静是很难的。
[cpg]

但我已经决定了要走的方向。我决定做好准备。
[cpg]


;//■選択肢
[switch]
[case "我要去南方了。"]
	[swap]
	[jump target="*select02_9"]
[endswitch]

1，继续向南走。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※７のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_7|对信长大人的忠诚。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

我带领我的部队，但我有一种不好的感觉。
[cpg]

这就是为什么我要求信长大人留下来。当我继续前进时，我看到......
[cpg]

[OnName num="keitarou"]
'该死的......，我知道你还在这里。
[cpg cn=true]


埋伏的士兵在潜伏着。我不是第一个站在他们面前的人，但......
[cpg]

士兵们正在受伤。尽管我没有排在队伍的最前面，但这是我不忍直视的一幕。
[cpg]

我应该准备好因我而流的血。
[cpg]

[OnName num="keitarou"]
'......，不知何故，你设法坚持了下来，......'
[cpg cn=true]


然后，经过一场比武，我把埋伏的士兵一个个打败了。
[cpg]


;//■選択肢
[switch]
[case "向东行进"]
	[swap]
	[jump target="*select02_8"]
[endswitch]

1、向东推进。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※８のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_8|对信长大人的忠诚

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン５の立ち絵を表示してください

当我们继续前进时，我们遇到了兰丸大师。
[cpg]

她看起来很安全，但她的脸与平时不同。
[cpg]

;//蘭丸「こっちだ。ついてきな」
敌人的营地就在那里。我无法让自己平静下来。
[cpg]

在一个生死攸关的地方，不可能保持冷静。
[cpg]

但我已经决定了要走的方向。我很坚定。
[cpg]


;//■選択肢
[switch]
[case "我要去东部。"]
	[swap]
	[jump target="*select02_9"]
[endswitch]

1，我向东推进。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※９のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select02_9|对信长大人的忠诚。

[jump target="*select02_win"]


;//マップシステム終了。下記のシナリオへ進む

;//==============================
;//稲生の戦い　９のマスに到達した場合


*select02_win|对信长大人的忠诚。

[stflag Selectflg2=1]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（夕方）******************************************************

[SE f=se019]
;//【ＳＥ】『刀　打ち合う』

在兵力上有明显的差别。另一方的人数几乎是另一方的两倍。
[cpg]

即便如此，这也是战略的意义所在。
[cpg]

这不是一个战场，一个人与一个人的冲突，他们肯定会互相消磨。
[cpg]

我只是按照吩咐推进我的部队，但信长的军队仍然获胜。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

我想这意味着我也有军功。
[cpg]

那是一种感觉不真实的东西。我甚至不知道它是否真的发生了。
[cpg]

我是无私的。即使我自己不挥舞剑，也会有士兵在我的命令下受伤。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Nobunaga081"]
[OnName num="nobunaga"]
'你做得很好。继续做好工作，成为一个更强大的人'。
[cpg cn=true]


[OnName num="keitarou"]
......，我什么都没做。
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga082"]
[OnName num="nobunaga"]
不要谦虚。我说的是实话。
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

无论他得到多少赞美，他都没有心情去听。
[cpg]

如果有的话，我的心比战前更不安了。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我杀了一个人，甚至有可能伤害了一个盟友。
[cpg]

我必须在这种情况下保持冷静吗？
[cpg]

信长大人、光秀大人和兰丸大人一定有类似的经历。
[cpg]

或者说，......，他们应该比我更有责任感。
[cpg]

我睡不着。我已经很久没有睡觉了，今天又睡不着了。
[cpg]

当我处于这样的精神状态时，有人来探望我。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga083"]
[OnName num="nobunaga"]
'景太郎。你在睡觉吗？"
[cpg cn=true]


[OnName num="keitarou"]
'...... 不'。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga084"]
[OnName num="nobunaga"]
'你打得非常好。我以为你可能会跑掉。
[cpg cn=true]


[OnName num="keitarou"]
'我没有做任何值得表扬的事情。牵涉到另一个人的生死，......，仍然让我心惊胆战。"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga085"]
[OnName num="nobunaga"]
'未来将比现在更和平。从这样的时代走来，能够马上战斗，这是一种天赋。"
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
 信长大人走近烧伤处，抚摸着我的头发。
[cpg]

[OnName num="keitarou"]
'信长大人，......，你在做什么......？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga086"]
[OnName num="nobunaga"]
'我也不太了解自己。但现在我终于明白，在我心中没有解决的问题。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga087"]
[OnName num="nobunaga"]
现在我知道你是一个能勇敢战斗的人，我明白了我的感受。"
[cpg cn=true]


信长大人是非常牵强的。但......
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（寝ている主人公に近づくヒロイン。キスをする）ev_47
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_47_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]



我可以从她的行动中看出。她在想什么？她把她的脸靠近我。
[cpg]

[OnName num="keitarou"]
'不!　'你一定是信长大人。
[cpg cn=true]



[VOICE f="Nobunaga088"]
[OnName num="nobunaga"]
'就当是一种礼节吧。不要想太多了'。
[cpg cn=true]


信长大人一边说一边把她的嘴唇送到我面前。
[cpg]


;**【ＣＧ】 ev_47_a ***********************
[CG id=1 index=1 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sNobunaga002"]
[OnName num="nobunaga"]
'吸'。
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


在我的生活中，我第一次说不出话来。或者说，如果我说了什么就不好吗？
[cpg]

[OnName num="keitarou"]
'...... 可以了吗？信长大人，做这个。"
[cpg cn=true]


;**【ＣＧ】 ev_47_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNobunaga003"]
[OnName num="nobunaga"]
'我不会对任何人这样做。我对爱情不感兴趣，但我对爱情的兴趣不......。
[cpg cn=true]


[OnName num="keitarou"]
我明白了。
[cpg cn=true]



[VOICE f="sNobunaga004"]
[OnName num="nobunaga"]
我想，我被你吸引了。我自己也想知道。
[cpg cn=true]


是信长大人，他已经在说一些几乎像忏悔的话了。
[cpg]


[VOICE f="Nobunaga110"]
[OnName num="nobunaga"]
生活在这个时代的人，很少有人能在战场上指挥。
[cpg cn=true]



[VOICE f="Nobunaga111"]
[OnName num="nobunaga"]
'此外，他一定是从未来来的。他一定是生活在一个和平的时代'。
[cpg cn=true]


[OnName num="keitarou"]
'...... 那是真的。
[cpg cn=true]



[VOICE f="Nobunaga112"]
[OnName num="nobunaga"]
'我依靠你，我知道我可以依靠你。你取得了再多的勇敢也无法做到的成就'。
[cpg cn=true]


这真是浪费口舌。我甚至觉得很尴尬。
[cpg]


;//ブラックアウト

;//移植前シーンカット

[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************


[VOICE f="sNobunaga005"]
[OnName num="nobunaga"]
'我想知道这种感觉是什么。我是最糊涂的人'。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="sNobunaga006"]
[OnName num="nobunaga"]
'我希望......，和你生个孩子，你知道的。
[cpg cn=true]


信长大人很有魄力。我有些不解。
[cpg]

[OnName num="keitarou"]
你为什么要对我如此费尽心思，......？
[cpg cn=true]


不，不是那样。不是这样的。有件事你需要更加小心。
[cpg]

[OnName num="keitarou"]
如果你现在怀上了孩子，这将是一件大事。"
[cpg cn=true]


信长大人听到这句话，表情变得阴沉。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga140"]
[OnName num="nobunaga"]
'......，是的，没错。如果你是一个男人，你可以有多少个孩子，但我是一个女人。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga141"]
[OnName num="nobunaga"]
'如果我带着孩子，我将无法站在战场上。但我不能让血流尽。
[cpg cn=true]


信长大人似乎很不耐烦。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga142"]
[OnName num="nobunaga"]
'只是，我没有接近你，因为我不想断绝你的血脉。
[cpg cn=true]


这一定是他的真实意图。考虑到这一点，我继续倾听。
[cpg]

我可以想象，信长大人可能是个天生的苦行僧。
[cpg]

我想他只是喜欢我。
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

;//移植前シーンカット

毕竟，我们当时没有什么可做的了。
[cpg]

[OnName num="keitarou"]
'你应该再考虑一下。你知道，关于它是否真的是我。
[cpg cn=true]



[VOICE f="Nobunaga167"]
[OnName num="nobunaga"]
'......，无论我想多少次，我都有同样的感觉，但如果你这么说，我不会强迫你。
[cpg cn=true]


信长大人似乎觉得自己被迂回地拒绝了，显得很伤心。
[cpg]

[jump target="*jump_select02_end"]


;//==============================
;//稲生の戦い　二度伏兵のマスを通った場合

*select02_lose|对信长大人的忠诚

[stflag Selectflg2=0]


我领导的部队已经筋疲力尽。
[cpg]

当然，这并不是说我们人多势众。这不是一场我们无法赢得的战斗。
[cpg]

但我不知道如果我不这样做，我自己是否能达到将军的要求。
[cpg]

[OnName num="keitarou"]
'该死的......，我不得不撤退了。
[cpg cn=true]


我把自己的生命放在第一位，看着当时的情况，决定退缩。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Mituhide012"]
[OnName num="mitsuhide"]
'我听说了。景太郎先生出乎意料地胆小'。
[cpg cn=true]


[OnName num="keitarou"]
'......，说你喜欢的。
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide013"]
[OnName num="mitsuhide"]
'我不认为有什么，但信长大人会因此而恨你。
[cpg cn=true]


就在我们谈论这些的时候，信长大人来了。
[cpg]


[free time=800]
[WAIT time=800]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="4/5" time=800]


[VOICE f="Nobunaga169"]
[OnName num="nobunaga"]
'景太郎不是一个懦夫。有几种情况。
[cpg cn=true]


[OnName num="keitarou"]
信长大人
[cpg cn=true]


信长大人甚至对我进行了跟踪。
[cpg]

 有一个环境的事实意味着它来自另一个时代。
[cpg]

我真的觉得自己无法忍受。我不知道是否会有那么一天，我也能打败敌人的将军。
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]


最后，是信长大人赢得了井冈山之战。
[cpg]

我不在那里。但我不用问也知道。
[cpg]

她不可能会输。因为我有这种信念，所以我能够退缩。......。
[cpg]

在这场战斗中取得最大成功的是兰姆鲁大人。
[cpg]

她似乎心情很好，被信长大人所爱慕。
[cpg]


[jump target="*jump_select02_end"]




*jump_select02_end|奥克哈扎马之战
[jump storage="ep002.ks" target="*start"]

