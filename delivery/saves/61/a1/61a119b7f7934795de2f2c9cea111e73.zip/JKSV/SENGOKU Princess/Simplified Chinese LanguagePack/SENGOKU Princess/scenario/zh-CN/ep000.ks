
*start
;//姫武将　全年齢移植用シナリオ

;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり

;//信長　　　　　　着衣
;//信玄　　　　　　着衣
;//謙信　　　　　　着衣
;//光秀　　　　　　着衣
;//蘭丸　　　　　　着衣

;//上記以外のキャラクターには音声がありません

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//信長　　　　　　一人称「私（わたし）」　信玄呼び「信玄」　謙信呼び「謙信」
;//　　　　　　　　光秀呼び「光秀」　蘭丸呼び「蘭丸」　景太郎呼び「景太郎」
;//信玄　　　　　　一人称「私（わたし）」　信長呼び「信長」　謙信呼び「謙信」
;//　　　　　　　　光秀呼び「光秀」　蘭丸呼び「蘭丸」　景太郎呼び「景太郎」
;//謙信　　　　　　一人称「わたくし」　信長呼び「信長」　信玄呼び「信玄」
;//　　　　　　　　光秀呼び「光秀」　蘭丸呼び「蘭丸」　景太郎呼び「景太郎さん」
;//光秀　　　　　　一人称「私（わたし）」　信長呼び「信長様」　信玄呼び「信玄様」
;//　　　　　　　　謙信呼び「謙信」　蘭丸呼び「蘭丸」　景太郎呼び「景太郎さん」
;//蘭丸　　　　　　一人称「あたし」　信長呼び「信長様」　信玄呼び「信玄様」
;//　　　　　　　　謙信呼び「謙信」　光秀呼び「光秀」　景太郎呼び「景太郎」

;//景太郎　　　　　一人称「俺」　信長呼び「信長様」　信玄呼び「信玄様」
;//　　　　　　　　謙信呼び「謙信」　光秀呼び「光秀様」　蘭丸呼び「蘭丸様」
;//　　　　　　　　ただし、謙信ルートでは謙信を「謙信様」と呼ぶ

;//以下、残したＣＧを列挙いたします
;//信長 ev_01 ev_07 ev_24 ev_47 ev_68 紹介ページのCG
;//信玄 ev_29 ev_56 ev_67 ev_69
;//謙信 ev_48 ev_57 ev_58 ev_63
;//光秀 ev_34 ev_53 紹介ページのCG
;//蘭丸 ev_14 ev_36 紹介ページのCG


;//////////////////////////////////////
;///////////////以下本編///////////////
;//////////////////////////////////////


;#################################################
*Ep000|穿外国服装的人。
;#################################################

[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]

[stflag Selectflg1=0]
[stflag Selectflg2=0]
[stflag Selectflg3=0]
[stflag Selectflg4=0]



[SCENE id=0]

;//ブラックアウト
[window target=true]
[BG f="black.ui" time=1000]
[WAIT time=1000]

不是单纯的睡眠。不过，我还是敢于把它与睡眠相比较：......
[cpg]

这就像在通宵达旦之后，在睡了大约12个小时之后。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『森の中』（夕方）******************************************************

[OnName num="keitarou"]
'这是......？
[cpg cn=true]


我当时完全失去了知觉。我在一个完全未知的地方。
[cpg]

我在一个森林里。我试图追踪我模糊的记忆，但我的意识太过混沌。
[cpg]

须藤景太郎。我可以记住我的名字。
[cpg]

我记得在我睡着之前。我当时正在学校旅行，我想，发生了什么事......。
[cpg]

[OnName num="keitarou"]
'......，我的头很痛。
[cpg cn=true]


我不知道为什么，我不能永远呆在那里，我在森林里行走。
[cpg]


[SE f=se027]
;//【ＳＥ】『山道歩く』

;//ブラックアウト
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

我甚至不知道我已经睡了多久。
[cpg]

这种感觉是，我已经睡了相当长的时间，正如我先前所想的那样。
[cpg]

但奇怪的是，我并不饿。我想知道我是否被置于睡眠状态，而不是被睡了。
[cpg]


[window target=false]
[free time=1000]
[BG f="b_10_3.ui" time=1000]
[WAIT time=2000]
[window target=true]

;//【ＢＧ】『村』（夕方）******************************************************

[OnName num="keitarou"]
'这是个村庄，.......
[cpg cn=true]


但这是一个可怕的农村。我想知道我是否被传送到了其他地方。
[cpg]

我正这么想着，一个看起来像村民的人向我走来。
[cpg]

[OnName num="villager"]
'你是......？　你的穿着很奇怪。
[cpg cn=true]


[OnName num="keitarou"]
'......，这附近不是有一个博物馆吗？
[cpg cn=true]


[OnName num="villager"]
一个博物馆？　那是什么？
[cpg cn=true]


模糊的意识正在被恢复。
[cpg]

仿佛见到人们并与他们交谈使我意识到这不是一个梦。
[cpg]

[OnName num="keitarou"]
'嗯，让我看看。我当时在博物馆里，我想'。
[cpg cn=true]



发生了什么事？如果我不好好记住，那就真的很糟糕了。
[cpg]

我在哪里？你不可能走太远。
[cpg]

[OnName num="keitarou"]
'是的，我是。我听到有声音从折叠式屏幕上传来'。
[cpg cn=true]


有关于战国时期和其他方面的展览，我听到其中一个屏幕上传来的声音。
[cpg]

我想这是一个女孩的声音，但从折叠式屏幕上听到的声音很奇怪。
[cpg]

[OnName num="keitarou"]
...... 不可能。"
[cpg cn=true]

[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

记忆是相通的。事实上，这个声音是一个女孩的声音，这很奇怪，但它是有意义的。
[cpg]

我触摸着折叠式屏幕，仿佛被拉了进去。从那里开始，我就失去了知觉。
[cpg]

而这个村庄不仅仅是农村。
[cpg]

建筑风格过于古老，这意味着。
[cpg]

[OnName num="villager"]
怎么了？　你看起来很苍白。"
[cpg cn=true]


我有一个假设。难道说这个地方是。
[cpg]

[OnName num="keitarou"]
"战国时期......？"
[cpg cn=true]


他点点头，仿佛不认识我嘀咕的话语。
[cpg]

[OnName num="villager"]
总之，如果你没有地方可去，就在这里过夜。
[cpg cn=true]


[free time=1000]
[BG f="b_10_4.ui" time=1000]
[WAIT time=2000]
[window target=true]

;//【ＢＧ】『村』（夜）******************************************************

心烦意乱。虽然我是这样，但我本能地知道不要急于行动。
[cpg]

我有很多问题想问，但我现在不应该着急。
[cpg]

我决定在一家私人住宅过夜。
[cpg]

还向我提供了一些食物作为晚餐。我很感激，但食物太简单了。
[cpg]

我想知道这个地方是否真的很现代？　我想知道这是否真的是现在的日子。
[cpg]

[OnName num="villager_A"]
但是，这仍然是一件奇怪的和服。
[cpg cn=true]


[OnName num="villager_B"]
也许这就是传说中关于他的说法。
[cpg cn=true]


[OnName num="keitarou"]
'罗尔......？
[cpg cn=true]


[OnName num="villager_C"]
'有这样一件事。'穿着外国的衣服的人。'穿异国服装的人，以公主军阀为纽带，将生下吃天的儿子。
[cpg cn=true]


什么是 "公主军阀"？我从来没有听说过它。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

那地方没有电，更没有手机信号。
[cpg]

此外，步行到最近的城镇需要很长的时间。
[cpg]

这是一个很难相信的情况，但似乎每个人都没有说谎。
[cpg]

[SE f=se027]
;//【ＳＥ】『山道歩く』

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『森の中』（夜）******************************************************

然后，在深夜。我听到了奇怪的声音，并向森林走去。......
[cpg]

;//しばらく、信長の名前欄を「謎の少女」と隠してください

他们在那里，一些人穿得像战士，......
[cpg]

有一个女孩，她是如此美丽，以至于我不能不佩服她。出于某种原因，她拿着一把剑。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Nobunaga001"]
[OnName num="mysterious_girl"]
'你是谁？告诉我你的名字。"
[cpg cn=true]


[OnName num="keitarou"]
'我是须藤，...... 须藤景太郎，但你是谁？
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga002"]
[OnName num="mysterious_girl"]
你不知道我是谁吗？你为什么在这里？
[cpg cn=true]


她看起来像一个老公主，但也像一个军阀。
[cpg]

你说的公主军阀，是指这个人......？
[cpg]


;//ここから、信長の名前を隠さないでください

[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga003"]
[OnName num="nobunaga"]
'我是织田信长。你，你叫景太郎'。
[cpg cn=true]


这对我来说太突然了，我无法在脑海中把它搞清楚。
[cpg]

首先，织田信长不仅已经去世，而且生活在几百年前。
[cpg]

第二，那个织田信长不可能是个女孩。
[cpg]

[OnName num="keitarou"]
这很荒唐。......
[cpg cn=true]

[STOPBGM]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga004"]
[OnName num="nobunaga"]
'有什么你不同意的吗？　好吧，不管有没有，你只有一件事要做。"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
那个自称信长的女孩向我伸出了她的剑。
[cpg]

[BGM f="bg_06"]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga005"]
[OnName num="nobunaga"]
'你能驾驭一把剑吗？如果你不能，你现在不拥有它，你可能会死。
[cpg cn=true]


[OnName num="keitarou"]
你是什么意思？"
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga006"]
[OnName num="nobunaga"]
我被强盗包围了。我无法单独与他们战斗。如果你只是站在那里，你很有可能会被杀死。
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


我无法相信这一点。我是在做梦吗？
[cpg]

那个女孩问你是否能驾驭一把剑。这是真的，没有什么是我不能处理的。
[cpg]

我属于剑道俱乐部。我仍然认为我很擅长这个。......
[cpg]

但当涉及到向人挥拳时，情况就不同了。
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Nobunaga007"]
[OnName num="nobunaga"]
'它来了。那里已经有一个标志了'。
[cpg cn=true]



[SE f=se022]
;//【ＳＥ】『草木揺れる』

当我在考虑该怎么做时，我当然能感觉到有人在靠近。
[cpg]

我认为。摆脱这种情况的最好办法是什么？
[cpg]


;////////////////////////////////////////////////////

;//オレは姫武将を孕ませたい！　マップシステムに関して

;//体験版及び本編中に、ゲーム性を持たせるためマップを用いたパートを用意します。
;//マップパートでは選択肢によって、勝利、敗北の二種類に分かれます

;//マップパートでは、

;//１→２→３
;//↓　↓　↓
;//４→５→６
;//↓　↓　↓
;//７→８→９

;//という形で９マスあり「１」のマスからスタートし「９」までたどり着けばクリアとなります
;//下に進むか右に進むかという形で二択あり、合計四回選択します
;//ルートは全六種類になります
;//（選択肢は「南へ進む」「東へ進む」の二種類となります）

;//賊が「２」「６」「７」に待ち構えているという設定で
;//二度通ると敗北となります
;//今回のイベントでは、敗北でゲームオーバーとなりますが、ストーリーが分岐する場合もあります

;////////////////////////////////////////////////////


;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※最初の戦闘　開始時（１のマスにいる場合のシナリオ）※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※

;//ブラックアウト
;//【ＢＧ】『森の中』（夜）
;//ヒロイン１の立ち絵を表示してください

[OnName num="keitarou"]
'总之，我们离开这里吧。
[cpg cn=true]

她点点头。'我们不知道匪徒在哪里。
[cpg]

我想我看到一些灌木丛向东移动。......
[cpg]




;//■選択肢
[switch]
[case "'我们将继续向南。"]
	[swap]
	[jump target="*select01_4"]
[case "向东走。"]
	[swap]
	[jump target="*select01_2"]
[endswitch]

1，向南行进。
2，向东行进。


;//==============================
;//１、南へ進む

;//同じイベント中の「４のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「２のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※２のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_2|'穿外国服装的人。

[stflag Selectflg1=1]


[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


[OnName num="keitarou"]
'¡!　请退开！"
[cpg cn=true]


匪徒出现了。他们向我扑来。
[cpg]


[SE f=se019]
;//【ＳＥ】『剣戟』

经过一场剑斗，我打伤了那个强盗。
[cpg]

他们往回跑，我也不去追他们。
[cpg]

我已经没有力气了。如果我再遇到他们，他们可能会很危险。......
[cpg]


;//■選択肢
[switch]
[case "向南前进。"]
	[swap]
	[jump target="*select01_5"]
[case "向东走。"]
	[swap]
	[jump target="*select01_3"]
[endswitch]

1，向南走。
2、向东走。


;//==============================
;//１、南へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「３のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※３のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_3|那个穿外国斗篷的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン１の立ち絵を表示してください

东面的道路与其说是森林，不如说是陡峭的山峰。
[cpg]

如果发生这种情况，我们别无选择，只能继续南下。
[cpg]

我看着她，她担心地看着我，很累。
[cpg]

[OnName num="keitarou"]
'......，我不会有事的。别担心。"
[cpg cn=true]



;//■選択肢
[switch]
[case "向南行进"]
	[swap]
	[jump target="*select01_6"]
[endswitch]

1，向南行进。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※４のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_4|那个穿外国斗篷的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

这真是太安静了。没有看到强盗。
[cpg]

谨慎行事。在这种情况下，没有安全的把握。
[cpg]

我感觉到来自南方的存在，但我不确定我是否应该继续朝这个方向走。
[cpg]


;//■選択肢
[switch]
[case "向南前进。"]
	[swap]
	[jump target="*select01_7"]
[case "继续向东走。"]
	[swap]
	[jump target="*select01_5"]
[endswitch]

1，向南行进。
2，向东行进。


;//==============================
;//１、南へ進む

;//同じイベント中の「７のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※５のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_5|那个穿外国斗篷的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン１の立ち絵を表示してください

我们现在是在森林中一个稍微开放的地方。
[cpg]

她很紧张，但看起来并不累。
[cpg]

我想知道是否只有我一个人感到紧张。......
[cpg]


;//■選択肢
[switch]
[case "向南行进。"]
	[swap]
	[jump target="*select01_8"]
[case "向东走。"]
	[swap]
	[jump target="*select01_6"]
[endswitch]

1，向南行进。
2，向东行进。


;//==============================
;//１、南へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※６のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_6|穿着外国斗篷的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[if exp={getFlagValue("Selectflg1") == 1 }]
[jump target="*select01_6_2t"]
[endif]

[jump target="*select01_6_2f"]


;//==============================
;//２のマスを通っていた場合

*select01_6_2t|那个穿外国斗篷的人。

再次，土匪从灌木丛中出现。
[cpg]

我措手不及，我以最快的速度走上前去保护她。
[cpg]

[OnName num="keitarou"]
'什么！......'
[cpg cn=true]

[SE f=se020]
;//【ＳＥ】『刀振るう』

[window target=false]
[free time=500]
[BG f="red.ui" time=500]
[WAIT time=500]
[BG f="b_08_4.ui" time=500]
[WAIT time=500]
[window target=true]


当我意识到自己受了致命伤时，已经太晚了。
[cpg]


;//ブラックアウト
[SE f=se016]
;//【ＳＥ】『倒れる』
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

我为什么在这里？她是谁？
[cpg]

一切的真相仍未揭晓，而我也耗尽了力量。......
[cpg]


;//ゲームオーバー

[jump storage="epend.ks" target="*back_title"]


;//==============================
;//２のマスを通っていない場合

*select01_6_2f|穿着异国他乡服装的人

[OnName num="keitarou"]
'嘿!　请留步！"
[cpg cn=true]


一个强盗出现了。他们向我扑来。
[cpg]


[SE f=se019]
;//【ＳＥ】『剣戟』

经过一场剑斗，我打伤了那个强盗。
[cpg]

他们往回跑，我也不去追他们。
[cpg]

我已经没有力气了。如果我再遇到他们，他们可能会很危险。......
[cpg]


;//■選択肢
[switch]
[case "向南行进。"]
	[swap]
	[jump target="*select01_9"]
[endswitch]

1，向南行进。


;//==============================
;//１、南へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※７のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_7|'穿上外国土地的服装的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[SE f=se022]
;//【ＳＥ】『草木揺れる』

[OnName num="keitarou"]
'Psst!　请留步！"
[cpg cn=true]


匪徒出现了。他们向我扑来。
[cpg]


[SE f=se019]
;//【ＳＥ】『剣戟』

经过一场剑斗，我打伤了那个强盗。
[cpg]

他们往回跑，我也不去追他们。
[cpg]

我已经没有力气了。如果我再遇到他们，他们可能会很危险。......
[cpg]


;//■選択肢
[switch]
[case "向东行进。"]
	[swap]
	[jump target="*select01_8"]
[endswitch]

1，向东行进。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※８のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_8|穿着外国衣服的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン１の立ち絵を表示してください

我们快穿过森林了。看起来我们会设法挽救我们的生命。
[cpg]

即便如此，我们也不能放松警惕。她仍然很警觉。
[cpg]


;//■選択肢
[switch]
[case "向东走。"]
	[swap]
	[jump target="*select01_9"]
[endswitch]

1，向东行进。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※９のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select01_9|穿外国服装的人。

[SE f=se023]
;//【ＳＥ】『走る』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//マップシステム終了。下記のシナリオへ進む

如果我不杀她，她可能会杀我。我已经准备好了。
[cpg]

我挥舞着我的剑，打算给那个从灌木丛中出现的人造成致命的伤害。
[cpg]


[SE f=se020]
;//【ＳＥ】『刀振るう』

鲜血飞溅。感觉不是很深的伤口，但足以让他无法战斗。
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Nobunaga009"]
[OnName num="nobunaga"]
这很好。别犹豫了。"
[cpg cn=true]


我可以感觉到肾上腺素在我体内涌动。他继续挥舞着他的剑。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『森の中』（夜）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga010"]
[OnName num="nobunaga"]
'你很会用剑。我以前从未见过这样的剑。
[cpg cn=true]


结果是，我们得到了拯救。土匪们几乎都被武士和信长打败了。
[cpg]

[OnName num="keitarou"]
'...... Hon'ble really, Oda Nobunaga, is it?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Nobunaga011"]
[OnName num="nobunaga"]
'你说我粗鲁。但现在你却救了我的命？
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga012"]
[OnName num="nobunaga"]
'的确，我是织田信长。假设我在撒谎，就没有任何好处了'。
[cpg cn=true]


她又这样称呼自己。'你看起来不像是在撒谎。
[cpg]

她甚至让我拿着剑，砍死强盗。我不认为这都是一个陷阱。
[cpg]

但如果她真的是织田信长，那我就有大麻烦了。
[cpg]

[OnName num="keitarou"]
'这是一个时间滑块......？　不，是一个平行世界'。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga013"]
[OnName num="nobunaga"]
'...... 什么？　这是一个陌生的术语。
[cpg cn=true]


我还认为这是一个平行世界，因为信长不是一个人。
[cpg]

或者说，被认为是男性的历史是错误的。...... 当我在思考这个问题的时候，一个自称信长的女孩插话进来。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga014"]
[OnName num="nobunaga"]
让我们回到城堡去。对不起，占用了你们这么多时间，伙计们。
[cpg cn=true]


她向战士们呼喊。城堡是......，真的是城堡吗？
[cpg]

[OnName num="keitarou"]
'哪里是城堡？
[cpg cn=true]


我可能是在问一个愚蠢的问题。
[cpg]

但我忍不住要问。我只想知道它在哪里，有多少年了。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga015"]
[OnName num="nobunaga"]
'是清洲城。难道你也不知道吗？"
[cpg cn=true]


清洲城。仅仅通过听到这个名字，有些人可能就能知道这是哪一年。
[cpg]

但我不知道。如果要我说，我隐约知道它在哪里。......
[cpg]

它离我搬家前所在的博物馆并不遥远，这是肯定的。
[cpg]

这足以证实这一事件不是一个梦。
[cpg]

[OnName num="keitarou"]
'现在是哪一年？
[cpg cn=true]


信长回答说，脸上带着疑惑的表情。
[cpg]

[FACE method="shake_5" pos="2/3"]

[VOICE f="Nobunaga016"]
[OnName num="nobunaga"]
'你是谁，你不知道现在是什么时候？
[cpg cn=true]

;//様は年号を言うが、俺はそれ聞いてもやっぱりピンとこない。いつ頃だろう。
他告诉我那一年，但我还是无法理解。是什么时候的事？
[cpg]

我可以猜到，这一定是战国时期，但我不知道信长将来会变成什么样子。......
[cpg]


;//ブラックアウト
[SE f=se014]
;//【ＳＥ】『歩く』

[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=1]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

我们走了一会儿。我对战士们的行走速度感到惊讶，尽管他们的武器相当重。
[cpg]

信长正在领导这种形式。这也很令人惊讶，......，尽管她是个女孩。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga017"]
[OnName num="nobunaga"]
'景太郎。你说你不知道现在是哪一年，是什么意思？　还有，这身衣服是怎么回事？
[cpg cn=true]


我很快就被叫了出去。他还问我问题，仿佛我就是那个回到过去的人。
[cpg]

[OnName num="keitarou"]
'我也还没有完全想明白。但......，等我安顿好了，我会告诉你一切。"
[cpg cn=true]


告诉他们我所知道的事情可能是个坏主意。
[cpg]

如果未来被改变，我的存在会发生什么？
[cpg]

我无法想象如果时间悖论真的发生，会发生什么。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

我走了相当长的时间。夜间行走很困难，但我到达了......。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga018"]
[OnName num="nobunaga"]
我们在这里。清洲城"。
[cpg cn=true]


[OnName num="keitarou"]
...... 是惊人的。它看起来像是刚刚建成的。
[cpg cn=true]


在晚上很难看到，但你还是可以看出来。
[cpg]

当我想到城堡时，我想象的是一个古老的结构，但这时的情况并非如此。
[cpg]

[OnName num="keitarou"]
'所以这种技术在这个时间段存在。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga019"]
[OnName num="nobunaga"]
那么你的意思是什么呢？你是说这个时间段吗？
[cpg cn=true]


[OnName num="keitarou"]
'...... 不，我是说......'
[cpg cn=true]

[free time=1000]

正当我不知所措的时候，我听到城堡里传来一个声音。
[cpg]


;//しばらく、蘭丸の名前を「少女」と置き換えてください
;//girl

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="4/5" time=800]

[VOICE f="Ranmaru001"]
[OnName num="girl"]
'你安全吗!　信长大人！'
[cpg cn=true]


另一个女孩出现在去城堡的路上。
[cpg]

[FACE method="shock_4" pos="4/5"]

[VOICE f="Ranmaru002"]
[OnName num="girl"]
'我一直在找你......，请你离开城堡时告诉我。
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga020"]
[OnName num="nobunaga"]
'对不起，我睡不着，因为我的心在狂跳。我正走在我的心所到之处，她就在那里。
[cpg cn=true]


另一个拿着剑的女孩。这在这个世界上是一件正常的事情吗？
[cpg]

如果像信长这样强大的军阀是一个女孩，可能还有其他的例子。
[cpg]

[OnName num="keitarou"]
你是谁......？"
[cpg cn=true]


我问她。我问她，也许她认识这位将军。
[cpg]


;//ここから蘭丸の名前を置き換えないでください

[FACE method="change_7" pos="4/5"]

[VOICE f="Ranmaru003"]
[OnName num="ranmaru"]
我是森兰丸，....... 你是谁？
[cpg cn=true]


[OnName num="keitarou"]
我是须藤景太郎。
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru004"]
[OnName num="ranmaru"]
景太郎 ......?　信长大人，他是谁？
[cpg cn=true]


首先要做的是找出问题所在。
[cpg]

[FACE method="shake_7" pos="2/5"]

[VOICE f="Nobunaga021"]
[OnName num="nobunaga"]
'这我也不知道。我甚至不能让景太郎本人和我说话。
[cpg cn=true]


我什么都答不上来，这是事实。
[cpg]

[FACE method="change_5" pos="4/5"]

[VOICE f="Ranmaru005"]
[OnName num="ranmaru"]
在城堡里有这样一个人，安全吗？"
[cpg cn=true]


兰丸的问题是一个公平的问题。我相信你会这样想的，不是吗？
[cpg]

这是一个人们杀人远比今天多的时代。
[cpg]

我认为可以说这是一个人们难以信任他人的时代。然而。
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="Nobunaga022"]
[OnName num="nobunaga"]
景太郎保护了我。我没有向他宣誓效忠，但他救了我的命。"
[cpg cn=true]


兰丸嗤之以鼻。看着我，他说。
[cpg]

[FACE method="change_7" pos="4/5"]

[VOICE f="Ranmaru006"]
[OnName num="ranmaru"]
'...... 是这样的吗？这样一个看起来很弱的东西.......'
[cpg cn=true]


我认为这确实很不礼貌，但他们确实看起来比女孩们更强壮。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************


我想到的是，当你看到城堡里的女人时，你就会知道你要去见她。在此期间，我想。
[cpg]

自称信长的人和自称兰丸的人看起来都老得可以称为女孩。
[cpg]

更重要的是，他们在年龄上似乎相差不远。
[cpg]

兰丸比她小一点，也可能和她同龄。
[cpg]

从历史事实来看，情况不应该是这样的。这张图片莫名其妙地告诉我们，信长和兰丸的年龄比对方大很多。
[cpg]

我知道我已经误入了一个与历史现实不同的世界。
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Nobunaga023"]
[OnName num="nobunaga"]
怎么了？　你似乎陷入了沉思。
[cpg cn=true]


[OnName num="keitarou"]
'不，我只是有点......，对一些事情感到好奇。
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]

[VOICE f="Nobunaga024"]
[OnName num="nobunaga"]
我明白了。你可以稍后告诉我你在想什么，你是谁。
[cpg cn=true]


他们是非常宽容的。也许我勇敢地战斗是件好事。
[cpg]

信长的形象是一个脾气粗暴的人，但......。
[cpg]

我认为她是一个更高尚的人，而不仅仅是一个脾气粗暴的人。
[cpg]


[SE f=se024]
;//【ＳＥ】『床歩く』

[free time=1000]

在通道的中间，我与信长分开，走得更远。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru007"]
[OnName num="ranmaru"]
'这边走。跟着我。
[cpg cn=true]


[SE f=se024]
;//【ＳＥ】『床歩く』

;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru008"]
[OnName num="ranmaru"]
'暂时睡在这里。你现在被当作客人对待。"
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


它是相当宽敞的。他们要给我一个这样的房间。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru009"]
[OnName num="ranmaru"]
他们怎么能把这样的房间分配给一个身份不明的人呢？"
[cpg cn=true]


而兰丸似乎也是这么想的。
[cpg]

[OnName num="keitarou"]
'我很抱歉.......'
[cpg cn=true]


我尽可能快地道歉了。我感觉兰丸在某种程度上不喜欢我。
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Ranmaru010"]
[OnName num="ranmaru"]
'没有什么可道歉的。'这是信长大人的主意，所以一定有其道理。
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru011"]
[OnName num="ranmaru"]
'我明天会问你的背景和东西。现在，现在就休息。
[cpg cn=true]


[OnName num="keitarou"]
谢谢你。"
[cpg cn=true]


我向她表示感谢，并看着兰丸离开。
[cpg]


[SE f=se025]
;//【ＳＥ】『ふすま閉まる』
[free time=1000]

你是孤独的，你感觉到你遇到了很多麻烦。
[cpg]

我真的不知道发生了什么事。......
[cpg]

与其说是我回到了过去，不如说是我回到了过去本身。
[cpg]

织田信长是个女人的事实。
[cpg]

与我所处的今天真的有联系吗？
[cpg]

我听说日本的历史还有很多方面没有被理解。
[cpg]

即使是这样，日本统治者的性别有可能不同吗？
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我无法正常思考任何问题。我很累，睡得很好。......
[cpg]

第二天早上：......
[cpg]


[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿城内』（朝）******************************************************

被邀请到城堡后的第二天。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru012"]
[OnName num="ranmaru"]
'信长大人要见你。跟着我。"
[cpg cn=true]


兰丸来到了他的房间。
[cpg]

[OnName num="keitarou"]
'...... 是。
[cpg cn=true]


我仍然很困，但我不能呆在床上。
[cpg]


[window target=false]
[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************

[SE f=se024]
;//【ＳＥ】『床歩く』

兰丸带我在陌生的建筑中散步。
[cpg]

我再次意识到，我真的穿越到了过去。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru013"]
[OnName num="ranmaru"]
'......，你昨晚睡觉了吗？
[cpg cn=true]


[OnName num="keitarou"]
'是啊，好在.......'
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru014"]
[OnName num="ranmaru"]
'你的胆子可真大。如果我不知道自己要做什么，我就无法入睡。
[cpg cn=true]


我还不太确定我是否安全。我还不确定我是否安全。
[cpg]

但我确实太累了，以至于我睡着了。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（朝）******************************************************

我走到的地方可能是信长的房间。
[cpg]

这个房间比我所在的房间要豪华几步。
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="Nobunaga025"]
[OnName num="nobunaga"]
兰丸。你在外面等着。"
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru015"]
[OnName num="ranmaru"]
'但是......，只要我们不知道他的身份，我们就不知道他可能会做什么。
[cpg cn=true]


兰丸似乎很担心信长。我没有任何武器。
[cpg]

[FACE method="shake_3" pos="2/5"]

[VOICE f="Nobunaga026"]
[OnName num="nobunaga"]
'没有什么可担心的。
[cpg cn=true]

[free time=1000]

兰丸犹豫了片刻，然后推辞了。
[cpg]

信长随后走过来，认真地看着我。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga027"]
[OnName num="nobunaga"]
'你在灯光明亮的地方看起来更不寻常。
[cpg cn=true]


[OnName num="keitarou"]
'......，我想是的。
[cpg cn=true]


'在这个时代，校服是一种很不寻常的装束。
[cpg]


;//下記のセリフ、台本では
;//「お前はどこから来たんだ？　言葉は通じるようだが、服装はこの国のものではないように見えるが……」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga028"]
[OnName num="nobunaga"]
你来自哪里？　你似乎会说这种语言。
[cpg cn=true]


[OnName num="keitarou"]
那是......."
[cpg cn=true]


当我的回答支支吾吾时，信长说：'我不知道你是谁，但我不能呆在城堡里。
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga029"]
[OnName num="nobunaga"]
'我不能允许一个身份不明的人留在城堡里。回答我'。
[cpg cn=true]


我觉得我别无选择，只能回答。在这个时代，如果没有一个盟友就被扔出去，那就糟糕了。
[cpg]

我没有选择，只能诚实地回答。无论你是否相信我，......
[cpg]

[OnName num="keitarou"]
'......，我来自另一个时代。来自比现在更远的未来。"
[cpg cn=true]


说'时间旅行'首先就不应该表达出横排的字样。
[cpg]

[OnName num="keitarou"]
'把它称为时间旅行会不会更好，......，或者在这个时间段有这样的概念？
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Nobunaga030"]
[OnName num="nobunaga"]
'来自另一个时间段，...... hmm。
[cpg cn=true]


信长陷入了深思。他没有嘲笑我，也没有因为我说了实话而生气。
[cpg]

[OnName num="keitarou"]
'你无法想象我说这话时在说什么。在这个时代，甚至不应该有这样的创造力'。
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga031"]
[OnName num="nobunaga"]
'不，这不是一个我不理解的故事。如果我回到平安时代，我就会因为我的滑稽装束而被人嘲笑'。
[cpg cn=true]


据说，信长是一个非常敏锐的人。
[cpg]

他......，她可能能够理解战国时期的人所不能理解的事情。
[cpg]

在一个本来没有时间滑坡概念的时代，信长是非常敏锐的。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga032"]
[OnName num="nobunaga"]
"你是说，在你的时代，他们可以随意做那种事？　这很有趣。
[cpg cn=true]


[OnName num="keitarou"]
是的，它是。我穿越时空更多是一种巧合，或者说我没有这种技术。......。
[cpg cn=true]


[OnName num="keitarou"]
我在博物馆里摸到了一个折叠屏，被带到了这个世界。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga033"]
[OnName num="nobunaga"]
'这听起来越来越有道理。如果他被卷入超自然现象，就可以解释为什么他在这样的时候独自前来。
[cpg cn=true]


信长并没有怀疑。相反，他思维敏捷，理解得太快了。
[cpg]

[OnName num="keitarou"]
'你相信我吗？
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga034"]
[OnName num="nobunaga"]
'是的，我知道。'是的，我相信他们，如果他们来自未来，我想把他们留在身边。
[cpg cn=true]


...... 我明白了。这样想很自然吗？
[cpg]

我知道信长的事。为人处世，在本能寺事变中自杀。
[cpg]

我知道，如果我跟随信长，未来可能会改变。
[cpg]

换句话说，也许未来会有信长执掌国家大权，统治日本的时候，......。
[cpg]

但就在我这样想的时候。
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga035"]
[OnName num="nobunaga"]
'只是不要告诉我未来的事。而且不要告诉其他人。"
[cpg cn=true]


[OnName num="keitarou"]
为什么？　我也许能够帮助你。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga036"]
[OnName num="nobunaga"]
如果你知道未来，你可以做任何你想做的事。我不想成为一个懦夫。
[cpg cn=true]


...... 是这样想的吗？信长似乎想要一场公平的战斗，即使是在他的生命受到威胁的情况下。
[cpg]

但我确实想成为有用的人。这种生活是互利的。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga037"]
[OnName num="nobunaga"]
'换个话题，你知道我们生活在什么样的时代吗？
[cpg cn=true]


[OnName num="keitarou"]
'在某种程度上。不过，历史从来不是我的强项。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga038"]
[OnName num="nobunaga"]
'关于这一点，你必须从兰丸那里得到一个解释。在任何情况下，你都是有趣的。
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


然后我得到了一顿饭。
[cpg]

至少信长在努力让我活着。
[cpg]

我不知道兰丸对此有何感想，但我知道我受到了某种程度的慷慨对待。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru016"]
[OnName num="ranmaru"]
'搞什么鬼，你......！　你突然来了，信长大人喜欢你'。
[cpg cn=true]


兰丸在我们移动时对我说了这句话。
[cpg]

[OnName num="keitarou"]
我很抱歉。
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]

[VOICE f="Ranmaru017"]
[OnName num="ranmaru"]
不要马上道歉!　你甚至不知道什么是错的。
[cpg cn=true]


我不确定我是否愿意。
[cpg]

我相信兰丸是在本能寺与信长一起丧生的。
[cpg]

它叫做一莲兽，或者是我最亲近的人。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

尽管他很烦躁，兰丸还是向我解释了这一时期的情况。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru018"]
[OnName num="ranmaru"]
'室町幕府，至少你知道。'不管是多少。
[cpg cn=true]


[OnName num="keitarou"]
'不，不，...... 那个。
[cpg cn=true]


'信长阻止我告诉你，我来自另一个时代。
[cpg]

[OnName num="keitarou"]
'我已经告诉了信长，但我不知道我是否能告诉你所有的事情。
[cpg cn=true]


兰姆鲁改变了他血腥的想法，说。
[cpg]

[FACE method="shock_3" pos="2/3"]

[VOICE f="Ranmaru019"]
[OnName num="ranmaru"]
'信长大人，对!　如果你要叫我，就用'Sama'叫我！'
[cpg cn=true]


他说了一句话，似乎当然是对的。
[cpg]

信长大人是对的，不是吗？我才是那个被保住性命的人。
[cpg]

[OnName num="keitarou"]
'......，我已经告诉了信长大人，但我不知道能不能把一切都告诉兰丸大人。
[cpg cn=true]


[FACE method="change_5" pos="2/3"]

[VOICE f="Ranmaru020"]
[OnName num="ranmaru"]
'管他呢，那是......，很好。
[cpg cn=true]


兰丸大人吃了一惊，但还是告诉了我这个时期的情况。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru021"]
[OnName num="ranmaru"]
'幕府失去了权力。说得很简单，守护神们消失了。
[cpg cn=true]


[OnName num="keitarou"]
'守护封建领主......？
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru022"]
[OnName num="ranmaru"]
你真的不知道，是吗？好吧，我告诉你。"
[cpg cn=true]


我甚至在普通教育水平上都不了解日本历史。我对历史真的很不擅长。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru023"]
[OnName num="ranmaru"]
'他们被称为战国大名的东西所取代。就像他们的名字不同一样，他们的性质也完全不同。
[cpg cn=true]


[OnName num="keitarou"]
他们被称为千石，所以他们在战斗，不是吗？
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru024"]
[OnName num="ranmaru"]
'他们在打......？　为什么是过去式呢？
[cpg cn=true]


哦，不。这也很有趣。
[cpg]

[OnName num="keitarou"]
我们在战斗，不是吗？
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru025"]
[OnName num="ranmaru"]
好吧，......，我不知道我明天是否还能活着。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru026"]
[OnName num="ranmaru"]
它随时都可能死亡。甚至信长大人也不能说它不会。
[cpg cn=true]


世界正处于战争状态。在这个敌人和盟友明显分裂的时代，甚至那些站在你这边的人也可能会杀死你。
[cpg]

我们已经来到了一个可怕的地方。我以为我在某种程度上已经做好了准备，但再想一想，这是件大事。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

我换上了这个时代的和服，因为我认为如果我永远穿着校服会很显眼。
[cpg]

我想这是战士会穿的那种东西。如果是信长大人的命令，他是不是想把我变成一个武士？
[cpg]

不过，我不用担心吃和穿的问题，这还是有帮助的。
[cpg]

没想到信长大人对我有好感。
[cpg]

我认为当时我诚实地告诉他一切是好事。
[cpg]

[OnName num="keitarou"]
'我想知道我在...... 元的时候会是什么样子。
[cpg cn=true]


我情不自禁地自言自语。这是我忍不住要想的事情。
[cpg]

如果时间在另一边以同样的方式流动，这将是一个大问题。我将被视为失踪。
[cpg]

这意味着我最好尽快回来。......。
[cpg]

但是，当我真的像这样穿越时空时，时间怎么可能在现在以同样的方式流逝呢？
[cpg]

当然，我们不知道我们将在什么时候返回。在任何情况下，我都必须抓紧时间吗？
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

我从未被放出过城堡，甚至没有被放出过城堡。
[cpg]


[STOPBGM]
[window target=false]
[BG f="b_06_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

我没有电话或其他东西。如果我整天呆在城堡里，我会感到窒息的。
[cpg]

[OnName num="keitarou"]
'但是，这样做可以吗？我可能会跑掉。
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru027"]
[OnName num="ranmaru"]
'那是信长大人的意思。比起你逃跑的风险，有些事情他想照顾的更好。......
[cpg cn=true]


值得珍惜的东西。我不知道，我想知道是否有人在期待我做什么。
[cpg]

但我也告诉他不要谈论来自未来，也不要谈论发生在未来的事情。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru028"]
[OnName num="ranmaru"]
'该死，为什么这家伙...... 信长大人在想什么？
[cpg cn=true]


兰丸大人似乎非常喜欢信长大人。他似乎把他的嫉妒指向了我。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我让兰丸大人跟着我，我又来到了城堡镇。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『街』（朝）******************************************************

然而，在城堡镇上什么都没有。
[cpg]

在这个时代，似乎不存在像江户时代那样具有一定富裕程度的城镇。
[cpg]

我想这一定是真的。这意味着和平时期并没有持续那么久。
[cpg]

[OnName num="keitarou"]
'......，这里什么都没有。
[cpg cn=true]



;//下記のセリフ、台本の「街」がシナリオでは「町」に変わっています

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru029"]
[OnName num="ranmaru"]
'那里似乎没有什么东西？　'这是一个如此丰富的城镇，它是如此的罕见。
[cpg cn=true]


我不是在说那些比我那个时代更矮的建筑......。
[cpg]

这就像在看一部时代剧的布景，但更有生活气息和真实感。
[cpg]

[OnName num="keitarou"]
'是的，它是这样。在这个时代，这很正常，或者......'。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru030"]
[OnName num="ranmaru"]
'在这个时代，......，你说这句话是什么意思？
[cpg cn=true]


尽管这些话是无意中说出来的，但兰丸大人并没有错过。
[cpg]

这个时代的军阀们应该都是相当聪明的人。
[cpg]

他们一定在努力避免错过我说的任何话。
[cpg]

如果这也与保护他们心爱的领主有关，那就更是如此了。
[cpg]

[OnName num="keitarou"]
'不。什么都没有。"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru031"]
[OnName num="ranmaru"]
'......，你是个有趣的人。
[cpg cn=true]


兰丸大人很怀疑，但没有再对我说什么。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（昼）******************************************************

[SE f=se014]
;//【ＳＥ】『歩く』

然后我在城堡镇周围看了一会儿。
[cpg]

我想这是一个惊喜，但他太大了，不可能有任何惊喜。这一次我明白这是真的。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

之后，信长大人叫我去她的房间。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga039"]
[OnName num="nobunaga"]
'进展如何？你已经习惯了吗？"
[cpg cn=true]


[OnName num="keitarou"]
是的，嗯......有一点。
[cpg cn=true]


我可以肯定地认为，信长大人喜欢我。
[cpg]

仅仅是被允许呆在这个城堡里就是一个相当大的成就。
[cpg]

但是，......，有件事一直让我有点困扰。
[cpg]

[OnName num="keitarou"]
信长大人，你知道围绕公主军阀的传说吗？
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga040"]
[OnName num="nobunaga"]
'当然了。'穿着外国的衣服的人。'穿异域服装的人，以战神公主为纽带，将生出吃天的儿子。'......，对吗？"
[cpg cn=true]


[OnName num="keitarou"]
你知道吗？
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga041"]
[OnName num="nobunaga"]
这里的人都知道。但我不知道这意味着什么。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Nobunaga042"]
[OnName num="nobunaga"]
那个穿外国斗篷的人可能是......。
[cpg cn=true]


[OnName num="keitarou"]
如果是这样，那么战神公主...
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Nobunaga043"]
[OnName num="nobunaga"]
...... 的确，如果他们知道你是谁，各种军阀，还有女人，可能会找你。"
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


我想了一会儿。你将会有一个儿子，或者......
[cpg]

为了在这个世界上生存，我愿意做任何事情。
[cpg]

此外，如果和军阀在一起的孩子有神奇的力量，我也许能回到现代世界。
[cpg]

我觉得这就是我的角色所在。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga044"]
[OnName num="nobunaga"]
'但话说回来，你怎么看？'但是怎么办呢？ 作为来自未来的人，一定会有一些不便之处。
[cpg cn=true]


[OnName num="keitarou"]
这已经是......."
[cpg cn=true]


我甚至不知道该说些什么，这太难了。
[cpg]

我不认为我可以从电话中回去向她解释移动电话甚至是普通电话。
[cpg]

这个时期的人是如何与他人交流的？
[cpg]

[FACE method="shake_7" pos="2/3"]

[VOICE f="Nobunaga045"]
[OnName num="nobunaga"]
'我希望兰丸没有意识到我是来自未来。
[cpg cn=true]


[OnName num="keitarou"]
'可能吧，我想他会没事的。
[cpg cn=true]


'我差点就对他破口大骂了，不过我相信他一定会没事的。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga046"]
[OnName num="nobunaga"]
'话虽如此，......，有件事我想告诉你。
[cpg cn=true]


信长大人这时变得有些严肃。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga047"]
[OnName num="nobunaga"]
'看来，凯和越后终于打起来了。这可能会变成一场对峙，......."
[cpg cn=true]


他说。我不明白。
[cpg]

[OnName num="keitarou"]
'...... Kai and Echigo, is it?
[cpg cn=true]


我反问道，尽管我隐约知道凯和越后在哪里。
[cpg]

原因是信长大人在这里，所以应该从这里向东......，对吗？
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga048"]
[OnName num="nobunaga"]
我想你不明白。地名有变化吗？
[cpg cn=true]


信长大人太有洞察力了。
[cpg]

[OnName num="keitarou"]
'你很了解它，不是吗？......？
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Nobunaga049"]
[OnName num="nobunaga"]
'这个国家没有处于无休止的战争状态。未来将是一样的'。
[cpg cn=true]


我想到的是，这两个国家的人都不知道该怎么办。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga050"]
[OnName num="nobunaga"]
'武田和上杉，你能看出吗？
[cpg cn=true]


[OnName num="keitarou"]
'哦。武田谦信 ...... 不，信玄？
[cpg cn=true]


我是根据模糊的记忆说的。信长大人笑了一下。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga051"]
[OnName num="nobunaga"]
这两者是混在一起的，不是吗？但你的意思是这两个人将在未来被提及？
[cpg cn=true]


武田信玄和上杉谦信。这两个人是武田信玄和上杉谦信，我以前至少听说过这些名字。
[cpg]

但我甚至不知道他们中的哪一个与织田家更亲近，或者他们之间的关系是否不好。
[cpg]

[OnName num="keitarou"]
'......，显然仍有他们的名字。虽然没有信长大人那么多，'。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga052"]
[OnName num="nobunaga"]
'我想是的。他不可能是我的对手。
[cpg cn=true]


信长大人是一个相当自信的人。他似乎毫不怀疑自己就是那个名字会留在未来的人。
[cpg]

而且他一定有能力或......，有作为军事指挥官的才能来配合。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga053"]
[OnName num="nobunaga"]
但如果剩下这么多名字，我想你知道从现在开始谁会赢。
[cpg cn=true]


如果你问我，我不知道。它将如何被......？
[cpg]

'我甚至不知道那两个人之间的战斗是否曾经解决。我甚至不知道。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga054"]
[OnName num="nobunaga"]
但不要告诉我。提前了解战争的状况是违反我的原则的。"
[cpg cn=true]


[OnName num="keitarou"]
'不，不，......，不要担心这个问题。我也不知道。
[cpg cn=true]


[FACE method="change_5" pos="2/3"]

[VOICE f="Nobunaga055"]
[OnName num="nobunaga"]
什么？你不关心历史吗？　还是你在未来如此遥远，以至于过去是模糊的？
[cpg cn=true]


两者都是正确的。无论怎样，我都不能告诉你什么。
[cpg]

我对这两所房子的生存状况一无所知。......。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga056"]
[OnName num="nobunaga"]
'我想，无论在多远的未来，这些女人都会成为人人皆知的军阀，但我听说情况并非如此。
[cpg cn=true]


信长大人还说了一句话，有点令人不安。
[cpg]

[OnName num="keitarou"]
'他们，你是说......，那两个也是女人？
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga057"]
[OnName num="nobunaga"]
'是的，他们是。你关心什么？
[cpg cn=true]


我并不好奇，因为根据我所知道的历史，他们两人都是男人。
[cpg]

我是说，所有的军事指挥官都是男人。我也许也不应该这么说。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga058"]
[OnName num="nobunaga"]
'......，这是一个好机会。凯......，我希望你去找武田。
[cpg cn=true]


[OnName num="keitarou"]
我？"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
信长大人点了点头。我不知道他是什么意思。
[cpg]

[OnName num="keitarou"]
你是什么意思，你要告诉他什么？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Nobunaga059"]
[OnName num="nobunaga"]
不，这不是我在这里的原因。我只想让你成为一个好仆人。
[cpg cn=true]


[OnName num="keitarou"]
那是什么样的......？
[cpg cn=true]


我不明白信长大人想做什么。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga060"]
[OnName num="nobunaga"]
我不知道信长大人想做什么。
[cpg cn=true]


显然，他想教我战国时期是怎么回事。然后他继续说。
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga061"]
[OnName num="nobunaga"]
'最终，我将使你成为军阀。你必须为此做好准备。"
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


我甚至无法想象。我是个军阀？
[cpg]

我甚至无法想象，我将会领导一支军队。
[cpg]

此外，在这之前还有一些问题。
[cpg]

[OnName num="keitarou"]
当你说你正在去武田的路上，你确定要我亲自去那里吗？"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Nobunaga062"]
[OnName num="nobunaga"]
'啊。我们的目标是，让所有的人都知道，我们的目标是，让所有的人都知道，我们的目标是，让所有的人都知道。
[cpg cn=true]


'我不认为有问题或什么，我认为这是个大问题。因为......
[cpg]

[OnName num="keitarou"]
'你不觉得我可能......，站在武田那边吗？
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga063"]
[OnName num="nobunaga"]
'如果发生这种情况，我将尽我所能粉碎你。这就是为什么我会让兰丸和你一起去。"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga064"]
[OnName num="nobunaga"]
'如果你不想死，你必须为我服务。如果你不想死，就为我服务，我所有的敌人都会灭亡。
[cpg cn=true]


我颤抖着，但信长大人对我笑了。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga065"]
[OnName num="nobunaga"]
如果你认为背叛我有好处，这就是所有的事情了。我甚至不认为我看起来那么弱。
[cpg cn=true]


我明白了。我一直在思考这个问题。
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[OnName num="keitarou"]
'......，你的麻烦大了......'。
[cpg cn=true]


我将成为一个军阀？也许这就是在这个世界上生存的方式。
[cpg]

如果你是信长大人的手下，但你不是军阀，你可能要作为士兵作战。
[cpg]

如果只是呆在她身边什么都不做，那是不可接受的。
[cpg]

信长大人是个女人，是个军事指挥官，所以我作为一个男人，就更应该如此。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

从那天起，就开始为出发做准备。
[cpg]

我必须要走一段时间吗？还是我得骑马？
[cpg]

无论哪种方式，它看起来都是一个很大的工作。我能够做到吗？
[cpg]


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

当我在思考的时候，夜幕降临。
[cpg]

几个小时似乎在异常漫长的时间里过去了。
[cpg]

没有什么可以打发时间的东西，城堡里到处都是陌生人。
[cpg]

此外，我觉得信长大人因为喜欢我而嫉妒我。
[cpg]

所以我没有和任何人交谈，也没有考虑到未来。
[cpg]

这一定是一个相当大的举措。这是一个没有汽车，没有其他东西的时代。
[cpg]

[OnName num="keitarou"]
我们将不得不这样做。......
[cpg cn=true]


我怀着焦虑的心情自言自语。我擅长运动，我认为我的身体素质很好，但我不知道我会做得多好。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

然后，在出发的那天。
[cpg]

自然，我不可能带着一个小队出去，所以那里有不少战士。
[cpg]

一切都准备好了。我们所要做的就是步行。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru032"]
[OnName num="ranmaru"]
'好的。那我们就出去吧。"
[cpg cn=true]


即便如此，兰丸大人是个女孩，......，身体苗条，似乎没有能力走远路。
[cpg]

[OnName num="keitarou"]
......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru033"]
[OnName num="ranmaru"]
它是什么？　盯着我。"
[cpg cn=true]


[OnName num="keitarou"]
'不，没有什么.......'
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se014]
;//【ＳＥ】『歩く』

但到了开始走的时候，兰丸大人就比较艰难了。
[cpg]

他当然是，因为他在这个时代以军阀的身份生活。
[cpg]

而四处走动，已经超出了艰难这个词的范畴，是对生命的威胁。
[cpg]

我从来没有真正想象过，但在那些日子里，马只在特殊场合使用。
[cpg]


[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

夜里很难受。我无法入睡。
[cpg]

我晚上睡不着觉，但我不能把我疲惫的身体带到明天。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru034"]
[OnName num="ranmaru"]
我想我没有......，因为我认为我很健康。"
[cpg cn=true]


[OnName num="keitarou"]
'对不起，对不起.......'
[cpg cn=true]


我想知道兰丸大人单薄的身体哪里有这样的能量。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

白天，黑夜，白天，黑夜，越来越多的时间过去了。
[cpg]

我的时间感越来越奇怪，我说话越来越少。
[cpg]

我想尽快到达我的目的地，但很难走得快。
[cpg]

而且每个人都走得非常快。如果我被甩在后面，那就完蛋了。
[cpg]


[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]

;//【ＢＧ】『山道』（夜）******************************************************

如果我没有加入体育俱乐部，我现在就已经死了。
[cpg]

我意识到，我很幸运，因为我积累了一些肌肉。
[cpg]

在这个时代，除了你的身体，你能依靠的东西不多：......
[cpg]



[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]


;//【ＢＧ】『山道』（昼）******************************************************

然后，在你走投无路时，......
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『街』（夕方）******************************************************

[OnName num="keitarou"]
"......"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru035"]
[OnName num="ranmaru"]
我们在这里。景太郎，你还好吗？"
[cpg cn=true]


[OnName num="keitarou"]
......，我都快崩溃了。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru036"]
[OnName num="ranmaru"]
你不能在这个......，战场是一个更艰难的地方。"
[cpg cn=true]


是的，这就对了。我很确定这也是它的特点。
[cpg]

但我想就在今天好好睡一觉。......
[cpg]


[SE f=se014]
;//【ＳＥ】『歩く』


;//ブラックアウト
[free time=1000]
[BG f="b_13_4.ui" time=1000]
[WAIT time=1100]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

我们到达了城堡，我睡得像泥巴一样。
[cpg]

武田信玄，这个我从未见过的人。
[cpg]

我决定把困难的事情留给兰丸大人，她有足够的力量：......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（朝）******************************************************



而在第二天早上。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen001"]
[OnName num="shingen"]
'很高兴见到你。你是信长景太郎提到的那个人吗？"
[cpg cn=true]


[OnName num="keitarou"]
'是的，我是。谢谢你昨天让我住在这里。
[cpg cn=true]


与信玄一对一，没有兰丸大人在场。
[cpg]

不，信玄大人，我应该给你打电话。如果信长大人派我来，那我们一定是友好关系。
[cpg]

此时可能没有信长大人或信玄大人的优势地位。
[cpg]

但至少在我看来，他们在云层之上。
[cpg]

[OnName num="keitarou"]
'......，你说战争可能要开始了。
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Singen002"]
[OnName num="shingen"]
'这就对了。这不会很快决定的'。
[cpg cn=true]


川中岛之战。我知道这么多。
[cpg]

信玄和剑心在那里打过架，不是吗？而且他们已经斗争了相当长的时间。
[cpg]

看来我们现在正处于中间阶段。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen003"]
[OnName num="shingen"]
你我之间，......，我不认为我想打这样的仗。
[cpg cn=true]


[OnName num="keitarou"]
嗯？"
[cpg cn=true]


是这样的吗？　如果是这样，感觉有点糟糕。
[cpg]

这意味着历史上曾经发生过的最重要的战役之一将被丢失。
[cpg]

这将改变未来，所以即使我们回到原来的时间，也可能不是我所知道的那个日本。
[cpg]

[OnName num="keitarou"]
'哇，我不知道。如果我们战斗，我们可能很容易获胜'。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen004"]
[OnName num="shingen"]
'你没有依据，......，但如果你支持我，我就接受。
[cpg cn=true]


信玄大人这么一说，我就有点放心了。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen005"]
[OnName num="shingen"]
'那么，关于你。我听说有传言说你从另一个世界混进来了？
[cpg cn=true]


[OnName num="keitarou"]
'......，你对这个问题知道得很多。
[cpg cn=true]


'我听说了一些传言，在这个时代有可能吗？
[cpg]

不知怎的，我以为信长是在故意造谣我。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen006"]
[OnName num="shingen"]
'的确，你身上有一种浮力。...... Gohoho，gohoho。
[cpg cn=true]


[OnName num="keitarou"]
你没事吧！"
[cpg cn=true]


信玄大人突然咳嗽起来。它立即停止了，但是。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen007"]
[OnName num="shingen"]
'打扰一下。我有结核病。不要担心'。
[cpg cn=true]


[OnName num="keitarou"]
'......，我不知道你有这个。
[cpg cn=true]


结核病。结核病，在这个时代是一种不治之症。
[cpg]

仔细想想，虽然我知道信玄大人和谦信之间有矛盾，但我不记得他们中的任何一个打败了对方。
[cpg]

也许信玄大人是病死的。......
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Singen008"]
[OnName num="shingen"]
'这是什么？你似乎在说什么。
[cpg cn=true]


[OnName num="keitarou"]
...... 不。"
[cpg cn=true]


我想，但没有大声说出来。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[OnName num="keitarou"]
啊，兰丸大人。
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru037"]
[OnName num="ranmaru"]
你见过信玄大人吗？　进展如何？
[cpg cn=true]


[OnName num="keitarou"]
怎么样，我听说了。......
[cpg cn=true]


没有什么复杂的事情可谈。
[cpg]

我甚至不知道信玄大人对我有多少了解。
[cpg]

[OnName num="keitarou"]
他是一个很难读懂的人。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru038"]
[OnName num="ranmaru"]
'我想是的。我有同样的印象。
[cpg cn=true]


信长大人是相当容易理解的。她没有来回走动。
[cpg]

 我觉得和信玄大人有一种对比。
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

傍晚时分，我还在城堡里。
[cpg]

我挺累的，很难马上回到信长大人那里。
[cpg]

我将在城堡里待上一段时间。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru039"]
[OnName num="ranmaru"]
'景太郎。你感觉如何？
[cpg cn=true]


[OnName num="keitarou"]
我的腿仍然很疼。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru040"]
[OnName num="ranmaru"]
我明白了。我很抱歉，但你很快又要离开了。
[cpg cn=true]


我沮丧地听着这段对话。然后我听到了一个来自...... 的消息
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]


[VOICE f="Singen009"]
[OnName num="shingen"]
晚上好。景太郎，我可以说句话吗？"
[cpg cn=true]


[FACE method="change_7" pos="4/5"]

[VOICE f="Ranmaru041"]
[OnName num="ranmaru"]
'信玄大人，......，你想要什么？
[cpg cn=true]


兰丸大人看起来很惊慌。
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Singen010"]
[OnName num="shingen"]
'...... 兰丸也在这里，不是吗？嗯，很好。
[cpg cn=true]


然后，信玄大人不看兰丸大人，而是看我。
[cpg]

我有重要的事情要告诉你。说着，信玄大人向我走来。
[cpg]

我觉得信玄大人的脸上有一种性感的表情。
[cpg]

我不知道为什么会有这样的表达。
[cpg]

她是...... 可怕的美丽。你说我是个漂泊者，但她不就是那个人吗？
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Singen011"]
[OnName num="shingen"]
你不想为我服务，是吗？　我不像信长那样残暴和苛刻。"
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="4/5" time=1]
她对我轻声说。然后她向我走来。
[cpg]

[FACE method="change_2" pos="2/5"]
她把她的手放在我的耳朵上。然后他狡黠地笑了笑。
[cpg]

我遇到了麻烦，我不知道该说什么。
[cpg]

事实上，他用 "我不觉得我可以利用你 "这句话来触动我，......。
[cpg]

如果我为你服务，这是否意味着你也会做这些事？
[cpg]

我的脑海中出现了很多想法。在为我服务之前，她可能试图约我出去。
[cpg]

但看到这样的姿态，兰丸大人就生气了。
[cpg]

[FACE method="shock_3" pos="4/5"]

[VOICE f="Ranmaru042"]
[OnName num="ranmaru"]
'嘿!　连信玄大人都听不到。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]

[VOICE f="Singen012"]
[OnName num="shingen"]
'我是在开玩笑。我不打算认真地说，那是不可能的。
[cpg cn=true]


我想了想，不知如何回答。
[cpg]


;//■選択肢
[switch]
[case "我什么都不回答。"]
	[swap]
	[jump target="*select_shingen01"]
[case "我感谢他。"]
	[swap]
	[jump target="*select_shingen02"]
[endswitch]

第一，我什么都不回答。
二，我感谢你。


;//==============================
;//１、何も答えない

*select_shingen01|'穿上外国土地的服装的人。

[OnName num="keitarou"]
'......'
[cpg cn=true]


[FACE method="shake_6" pos="2/5"]

[VOICE f="Singen013"]
[OnName num="shingen"]
'不要给我这种表情。这只是意味着我关心你。
[cpg cn=true]


我没有回答。我对信长大人心存感激。......
[cpg]



[stflag Cha2flg=0]

[jump target="*select_shingen03"]


;//ヒロイン２ルートへの可能性が無くなる

;//==============================
;//２、お礼を言う

*select_shingen02|'穿上异地的袍子的人。

[OnName num="keitarou"]
'谢谢你。
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]

[VOICE f="Ranmaru043"]
[OnName num="ranmaru"]
'即使是景太郎。......！　你真的要背叛我们吗？"
[cpg cn=true]


兰丸大人盯着我。但信玄大人却在对他微笑。
[cpg]

我不知道我是否能为信玄大人服务......
[cpg]


[stflag Cha2flg=1]


[jump target="*select_shingen03"]

;//ヒロイン２ルートへの可能性が残る

;//==============================

*select_shingen03|穿着异国他乡的袍子的人

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

更多的时间过去了，到了晚上。我做了一个梦。
[cpg]


;//ブラックアウト

;//夢の中であるため、色調をグレースケールにしてください
;//＠
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

有一个女人，既不是信长大人，也不是信玄大人。
[cpg]

她穿得像个尼姑。我想知道她是谁。......
[cpg]

[OnName num="samurai"]
'剑圣大人。我们仍然可以战斗，你愿意吗？"
[cpg cn=true]


我听到了'Kenshin-sama'这句话。我在做梦，但我可以很清楚地听到它。
[cpg]

[FACE method="bow_4" pos="2/3"]

[VOICE f="Kensin001"]
[OnName num="kenshin"]
是的。我现在不能退缩。
[cpg cn=true]


这名妇女的表情看起来相当疲惫。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Kensin002"]
[OnName num="kenshin"]
'......，这样的战斗能持续多长时间？
[cpg cn=true]


那个人，谦信,......，不知为何在历史上有勇者的形象，但是。
[cpg]

无论是信玄大人还是谦信，似乎都没有那么好战。
[cpg]


;//ブラックアウト

;//色調を戻してください

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（朝）******************************************************

[OnName num="keitarou"]
......"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru044"]
[OnName num="ranmaru"]
'你醒过来了。你在做梦，但你做了一个梦吗？"
[cpg cn=true]


'你做了个噩梦？我不觉得那是一个多么糟糕的梦。
[cpg]

但......，这是个有点让人无法忍受的梦。
[cpg]

[OnName num="keitarou"]
不，这没什么。"
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

肌肉疼痛终于缓解了，也恢复了一点力量。
[cpg]

兰丸大人甚至看起来都不累。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru045"]
[OnName num="ranmaru"]
'看来我们明天左右又要离开了。同时，你应该做好准备。"
[cpg cn=true]


[OnName num="keitarou"]
'...... 是。
[cpg cn=true]


我只能回答，'是的'。我并不热衷于再次走这条路。......
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

那天晚上，我也是被信玄大人邀请来的。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen014"]
[OnName num="shingen"]
'是的。你做了一个这样的梦。......
[cpg cn=true]


[OnName num="keitarou"]
'是的，......，她似乎处于某种苦恼之中。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen015"]
[OnName num="shingen"]
'是的，她是个修女，这是肯定的。你可能已经看到了真正的她。
[cpg cn=true]


我当然不知道剑圣是一个宗教爱好者。
[cpg]

很奇怪，我看到她是个修女。
[cpg]

我已经回到了过去。
[cpg]

如果我身上再发生任何奇怪的事情，我也不会感到惊讶。......
[cpg]

[FACE method="bow_7" pos="2/3"]

[VOICE f="Singen016"]
[OnName num="shingen"]
'她可能因为她而陷入痛苦之中。她可能真的不想和我打。"
[cpg cn=true]


也许这就是战争的意义所在。我必须为我的生活而奋斗。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen017"]
[OnName num="shingen"]
'所以你真的不打算为我服务？
[cpg cn=true]


[OnName num="keitarou"]
'因为我为...... 信长大人服务。
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

在我回答这个问题时，信玄大人向我走来。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen018"]
[OnName num="shingen"]
'信长......，她不允许你和她发生肢体冲突。她是一个禁欲主义者。但我不是。"
[cpg cn=true]


这变得有点好笑。当她走近时，我无法推开她。
[cpg]

[OnName num="keitarou"]
'你是什么意思？
[cpg cn=true]


我明知故问地问她。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen019"]
[OnName num="shingen"]
'难道你不明白吗？
[cpg cn=true]


我知道。也许信玄大人知道我来自未来。
[cpg]

她很虚弱。考虑到这一点，她不可能不告诉我就让我离开。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Singen020"]
[OnName num="shingen"]
'我将不惜一切代价让我活着。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Singen021"]
[OnName num="shingen"]
'但是......，正如你所看到的，她很虚弱，所以她将无法生育。
[cpg cn=true]


信玄大人把她的脸凑得很近，嘴唇几乎要碰到。
[cpg]

我想，她一定知道自己的长相很好。
[cpg]

[OnName num="keitarou"]
'......，你应该更好地照顾自己。对我来说，做这个......。"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Singen022"]
[OnName num="shingen"]
'这是因为我确实照顾了你。我不认为我的选择是错误的'。
[cpg cn=true]


...... 我要做什么呢？我需要和某人在一起，任何人，有一天。
[cpg]

他们说，我和公主军阀之间的孩子会有神奇的力量。
[cpg]

如果是这样，我真的需要回到未来。
[cpg]

但......，信玄大人是否适合做这个伙伴？
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


最后，由于无法给出答案，我没有接受信玄大人的邀请。
[cpg]


;//移植前シーンカット

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

她看起来有点悲伤。但这也是没办法的事，我还没准备好。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen065"]
[OnName num="shingen"]
'我做这些事情是因为是你。你可能已经猜到了'。
[cpg cn=true]


[OnName num="keitarou"]
'......'
[cpg cn=true]


我陷入了沉默。她正在努力争取我的支持。
[cpg]

当然，我欠信长大人一个人情。我不应该在这里如此轻易地与她调情。
[cpg]

我想了想，想出了一个答案。
[cpg]


;//※ストーリーが分岐
;//　１を選んだ場合、ヒロイン１、ヒロイン４、ヒロイン５ルートへ
;//　２を選んだ場合、ヒロイン２、ヒロイン３ルートへ

;//※ただし、以前の選択肢で「１、何も答えない」を選んでいた場合、この選択肢は発生せず１を選んだことになる



[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*select_root145"]
[endif]

;//■選択肢
[switch]
[case "我不打算为她服务。"]
	[swap]
	[jump target="*select_root145"]
[case "我将为信玄服务。"]
	[swap]
	[jump target="*select_root23"]
[endswitch]

1、我不打算为他服务。
2、我将为信玄服务。


*select_root145
[jump storage="ep001.ks" target="*start"]

*select_root23
[jump storage="ep006.ks" target="*start"]
