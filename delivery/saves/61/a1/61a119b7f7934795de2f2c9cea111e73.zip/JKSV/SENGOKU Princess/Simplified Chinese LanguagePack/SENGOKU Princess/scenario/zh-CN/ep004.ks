
*start

;//==============================
;//稲生の戦いで敗北していた場合

*root_5|吸引了志同道合的人

;#################################################
*Ep004|'我们互相吸引，我们很相似。
;#################################################

[SCENE id=4]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru112"]
[OnName num="ranmaru"]
'嘿。景太郎。
[cpg cn=true]


[OnName num="keitarou"]
怎么了，......？"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru113"]
[OnName num="ranmaru"]
我一直都在嫉妒你。信长大人喜欢你。
[cpg cn=true]


[OnName num="keitarou"]
是这样的吗？
[cpg cn=true]


但我已经意识到了这一点。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru114"]
[OnName num="ranmaru"]
我一直在想。我怎么能让你离开信长大人呢？"
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

[SE f=se014]
;//【ＳＥ】『地面歩く』

说着，兰丸大人带着我走出了城堡。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru115"]
[OnName num="ranmaru"]
我不认为我有任何其他选择。这并不是我想做的。
[cpg cn=true]


[OnName num="keitarou"]
你在说什么呢？　兰丸大师。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="sRanmaru001"]
[OnName num="ranmaru"]
我不打算爱上你。我不会爱上你的，兰丸大人。
[cpg cn=true]

[STOPBGM]

[FG f="CHA05_p5_01_a.ui" method="change_2"  pos="2/3" time=1000]
说着，兰丸大人走到我面前，亲吻了我.......。
[cpg]


;//移植前シーンカット
;//【ＢＧ】『城＿縁側の廊下』（夜）

[FACE method="change_6" pos="2/3"]


[VOICE f="sRanmaru002"]
[OnName num="ranmaru"]
搞什么鬼？不要做这种表情。
[cpg cn=true]


我们分开嘴唇后，她看起来有点尴尬。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我在自己的房间里，有点困惑，这时兰丸大人走到我身边。
[cpg]

为信长大人服务是我的全部工作。这可能没有错。
[cpg]

但如果兰丸大人也是这样，也许我们互相吸引是很自然的。
[cpg]

最后，我想这是关于我做什么和我想做什么。......
[cpg]

我有点纠结，不知道该不该顺着兰丸大人的意思去做。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

有一天，我被信长大人叫住，走向他的房间。
[cpg]

在那里，兰丸大人也在，气氛变得很微妙。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Nobunaga591"]
[OnName num="nobunaga"]
'怎么了，你们两个。你们的脸都红了。
[cpg cn=true]


[OnName num="keitarou"]
'不，不。没有什么。
[cpg cn=true]


[FACE method="shock_3" pos="4/5"]
我第一次见到她时，她有点生气。
[cpg]

[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga592"]
[OnName num="nobunaga"]
'......，好了，这就对了。我希望你们两个会比以前更努力工作。我希望你们两个比以前更努力地工作。"
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

然后我被兰丸大人带到了她的房间。
[cpg]

她问我要做什么。换句话说，她想知道......，我是否会和某人在一起。
[cpg]

[OnName num="keitarou"]
'那是出乎意料的。即使你这么说'。
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru140"]
[OnName num="ranmaru"]
'这很好。只要回答我'。
[cpg cn=true]


她似乎无法直视我的眼睛。硬币的另一面是，这是她非常想听到的东西。
[cpg]

[OnName num="keitarou"]
现在，为信长大人服务是最重要的。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru141"]
[OnName num="ranmaru"]
......真的很像对方。也许这就是我们被对方吸引的原因。
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

然后兰丸大人走过来。
[cpg]


[VOICE f="Ranmaru142"]
[OnName num="ranmaru"]
信长大人和我都是女人。但和你在一起，我们可以有...... 的孩子。
[cpg cn=true]


[OnName num="keitarou"]
'......，你对每个人都这么做？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="sRanmaru003"]
[OnName num="ranmaru"]
不可能。没有人知道这件事。
[cpg cn=true]



;//ブラックアウト

;//========================================
;//●ＣＧ（立っているヒロイン。目を閉じてキスを待つ）ev_14
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="sRanmaru004"]
[OnName num="ranmaru"]
...... 我还是不怎么好，是吗？
[cpg cn=true]


我想知道....... 当然，比正常情况下更积极一些？
[cpg]

[OnName num="keitarou"]
即使那是真的，我也认为兰丸大人是个可爱的人。
[cpg cn=true]



[VOICE f="Ranmaru168"]
[OnName num="ranmaru"]
'你再说一遍，......，这种事。
[cpg cn=true]


;**【ＣＧ】 ev_14_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1000]


她这样说，闭上眼睛，等待我吻她。
[cpg]

我不能就这样算了，所以我把嘴唇凑过去。
[cpg]


[VOICE f="sRanmaru005"]
[OnName num="ranmaru"]
'......'
[cpg cn=true]



;//移植前シーンカット

;//ブラックアウト

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


之后，兰丸大人和我谈到了未来。
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru169"]
[OnName num="ranmaru"]
'我们会比以前更忙。
[cpg cn=true]


[OnName num="keitarou"]
'我相信我们会的。我对政治一无所知。
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru170"]
[OnName num="ranmaru"]
景太郎应该一点一点地学习。信长大人也希望如此。
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
在我们交谈时，我看到信长大人在远处。
[cpg]

[FACE method="shake_6" pos="2/3"]
兰丸大人的脸变红了。看来他仍然喜欢她。
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="4/5" time=800]

[VOICE f="Nobunaga593"]
[OnName num="nobunaga"]
'你这家伙。我听说你们俩这些天相处得很好。
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]

[VOICE f="Ranmaru171"]
[OnName num="ranmaru"]
'是的!　我对信长大人很忠诚。
[cpg cn=true]



[FACE method="bow_2" pos="2/5"]
信长大人笑了起来。我猜他认为她喜欢他是理所当然的。
[cpg]

我想了想。我为信长大人服务，但最终我没有站在战场上。
[cpg]

如果受信长青睐的不是自己，那么站在战场上的就是兰丸了。
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga594"]
[OnName num="nobunaga"]
从现在起，我将要求你为我做很多工作。我请求你的合作。"
[cpg cn=true]

[free time=1000]
信长大人说完就走了。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Ranmaru172"]
[OnName num="ranmaru"]
信长大人，你今天也很漂亮。......。
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


我想了一会儿，陷入了沉默。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru173"]
[OnName num="ranmaru"]
这到底是什么？你那张脸是什么意思？
[cpg cn=true]


[OnName num="keitarou"]
兰丸大人是如何看待信长大人的？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru174"]
[OnName num="ranmaru"]
'嗯，我喜欢他多于我可以说的......。我甚至不打算大声说出来。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

然后是晚上。光秀大人来拜访我的房间。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide043"]
[OnName num="mitsuhide"]
景太郎先生。你要去睡觉了吗？"
[cpg cn=true]


[OnName num="keitarou"]
'不，...... 一点点就可以了。
[cpg cn=true]


[STOPBGM]
[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

光秀大人走近我，在我耳边低声说。
[cpg]

[BGM f="bg_08"]


[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide044"]
[OnName num="mitsuhide"]
最近，你越来越受到信长大人的青睐。
[cpg cn=true]


[OnName num="keitarou"]
'是的，好的，......
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide045"]
[OnName num="mitsuhide"]
我相信这意味着你将有一个光明的未来。你将来可能会成为一个大人物。
[cpg cn=true]


我第一次见到她时，她有点紧张，我有点害怕。试图接近我。......
[cpg]

我不认为她的言行有什么联系，但我想在她心中是一致的。
[cpg]

光秀大人想让被信长大人看重的我站在她那边。
[cpg]

[OnName num="keitarou"]
'不，请不要。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Mituhide046"]
[OnName num="mitsuhide"]
你为什么拒绝？"
[cpg cn=true]


[OnName num="keitarou"]
'你必须只和你真正喜欢的人做这些事情。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

听到我的话后，光秀大人显得有些失望。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


他立即如法炮制，这次我想去睡觉。......
[cpg]

[OnName num="nobunaga_vassal"]
景太郎大人。我可以谈一下吗？"
[cpg cn=true]


[OnName num="keitarou"]
这是什么，......？　我已经很困了。
[cpg cn=true]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga595"]
[OnName num="nobunaga"]
什么？　我已经很困了。
[cpg cn=true]


[OnName num="keitarou"]
是的，......，我也是。
[cpg cn=true]


信长大人的臣子们安排我被带到信长大人的房间。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga596"]
[OnName num="nobunaga"]
你是什么意思？你来找我，对吗？
[cpg cn=true]


[OnName num="keitarou"]
'是的，但是......，那个...... 臣子说你在寻找织田家的继承人。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="sNobunaga020"]
[OnName num="nobunaga"]
他问你？　你的负担太重了。
[cpg cn=true]


我当然这么想，但当信长大人告诉我时，我感到很羞愧。
[cpg]

[OnName num="keitarou"]
'但......，我有别的人爱。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga598"]
[OnName num="nobunaga"]
'你是说兰丸。然后你可以像这样回到你的房间。
[cpg cn=true]


[OnName num="keitarou"]
'我这么说，但如果你现在回家，诸侯们会怎么说......？
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga599"]
[OnName num="nobunaga"]
'我明白了。我不打算借给你被褥。　不过，我不能借给你一个被褥。
[cpg cn=true]


[OnName num="keitarou"]
...... 我会的。
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我会的。" 他没有和信长大人睡在同一个被褥上，而是在榻榻米上过夜。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（朝）******************************************************

我早上醒来后意识到。这有点像后宫的情况。
[cpg]

这是一个梦幻般的情况，被三个人所追捧。
[cpg]

我处于一个在幕后控制世界的位置。我对此丝毫不感到高兴。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga600"]
[OnName num="nobunaga"]
上午好。景太郎，你睡得好吗？
[cpg cn=true]


[OnName num="keitarou"]
是的，嗯，我的......，身体很痛。
[cpg cn=true]



;//ブラックアウト

[window target=false]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の廊下』（朝）******************************************************

我走到走廊上，和信长大人一起走。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga601"]
[OnName num="nobunaga"]
今天又是个好天气，不是吗？
[cpg cn=true]


[OnName num="keitarou"]
是的，真的。
[cpg cn=true]


希望我们能一直谈论这些其他的事情。
[cpg]

如果事情继续下去，信长大人将在本能寺事件中死去。
[cpg]

即使我在那一刻想到兰丸大人的感受，我也别无选择，只能做一些事情。
[cpg]

我必须尽可能地避免改变未来，但这也是没办法的事。
[cpg]

为了避免信长大人的死亡，我别无选择，只能告诉光秀大人他的背叛行为。
[cpg]

[OnName num="keitarou"]
信长大人。告诉光秀大人.......
[cpg cn=true]

[STOPBGM]

在我准备说 "小心 "的那一刻，我的身体发生了变化。
[cpg]


[transition target={true} rule="moya.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1000]

[BGM f="bg_08"]

[FACE method="shock_5" pos="2/3"]
我的身材变得半透明。我的皮肤变得透明，信长大人惊讶地看到我的身材。
[cpg]

当我不再说什么时，这个数字又恢复了正常。
[cpg]

[OnName num="keitarou"]
'现在那是.......
[cpg cn=true]


毕竟，似乎如果我在这里改变了未来，那将是一个我没有出生的未来。
[cpg]

所以我从未来来，我要消失。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga602"]
[OnName num="nobunaga"]
'这算什么魔术呢？　这也是未来的技术吗？
[cpg cn=true]


信长大人这么说，但我认为他其实是知道的。
[cpg]

我正试图改变历史，而我即将为此付出代价。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

[SE f=se014]
;//【ＳＥ】『地面歩く』

离开城堡的那一刻，我想到了未来。
[cpg]

我觉得，我无法改变信长大人在本能寺事件中自杀的未来。
[cpg]

如果我改变它，我不知道我这个应该来自未来的人将会发生什么。事实上，发生了一个现象，我的身体变得透明。
[cpg]

但我想知道兰丸大人会怎么样。
[cpg]

我记得本能寺事件发生时，兰丸大人就在那里，他应该是战死了。
[cpg]

拯救信长大人和拯救兰丸大人是不同的。
[cpg]

救出兰丸大人，未来也不会有什么不同。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

当我回到屋里时，兰丸大人正在房间里等我。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru175"]
[OnName num="ranmaru"]
'你去哪里了？我一直在等你。
[cpg cn=true]


[OnName num="keitarou"]
'对不起，......，我可以帮你吗？
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
兰丸大人在烦躁不安。她看着我，想说些什么。
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（主人公に迫るヒロイン。服を着ているように修正してください）ev_36
;//人物１：ヒロイン５　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


然后兰丸大人向我走来。
[cpg]


[VOICE f="Ranmaru176"]
[OnName num="ranmaru"]
你知道吗？我毕竟是个疯子。
[cpg cn=true]



[VOICE f="sRanmaru006"]
[OnName num="ranmaru"]
当我想到景太郎时，我无法控制自己。
[cpg cn=true]


[OnName num="keitarou"]
'......，我明白了。
[cpg cn=true]


但她仍然可能仍然爱着信长大人。
[cpg]


[VOICE f="Ranmaru178"]
[OnName num="ranmaru"]
我想知道我应该做什么。在这样的时候，我已经厌倦了对爱情和浪漫的困惑。
[cpg cn=true]


[OnName num="keitarou"]
'每个人都是这样的。在这里，我想告诉大家的是，在我们的生活中，有很多事情是需要我们去做的，比如说，在我们的生活中，有很多事情是需要我们去做的。
[cpg cn=true]



[VOICE f="Ranmaru179"]
[OnName num="ranmaru"]
...... 我想知道是否每个人都会对颜色感到兴奋。我想这不仅仅是我。
[cpg cn=true]


我们再一次交换了吻，我不知道有多少次。
[cpg]


;//移植前シーンカット

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

即使你和她一起度过一个快乐的时刻，你的心也不会平静。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru202"]
[OnName num="ranmaru"]
怎么了？景太郎。你看起来很奇怪。"
[cpg cn=true]


[OnName num="keitarou"]
'不，没什么。......
[cpg cn=true]


正确的未来是兰丸大人被打败并被杀死的那个。这意味着......
[cpg]

兰丸大人要活着的事实意味着他不能在更大程度上参与历史。
[cpg]

我想了想，不知道是否应该告诉兰丸大人这件事。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

就在我们绞尽脑汁的时候，杀死信长大人和兰丸大人的事件，即本能寺事件，肯定每分钟都在逼近。
[cpg]

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

我感觉好像晚上睡不着觉一样。
[cpg]

由于无法入睡，我在城堡周围散步。然后......
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Mituhide047"]
[OnName num="mitsuhide"]
'怎么了？你在这个时候散步？"
[cpg cn=true]


[OnName num="keitarou"]
'不，我只是睡不着。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide048"]
[OnName num="mitsuhide"]
'我明白了。'我和你很相似。
[cpg cn=true]


光秀。这个人将杀死兰丸大人和信长大人。
[cpg]

那么，劝阻光秀大人会不会更好呢？
[cpg]

不，它不是。这就等于我告诉他们他们背叛的未来。
[cpg]

这些妇女可能没有按照迄今为止的历史事实行事，但在不同的层面上，未来将发生变化。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide049"]
[OnName num="mitsuhide"]
'看。月亮是那么的美丽'。
[cpg cn=true]


[OnName num="keitarou"]
'......，这是真的。
[cpg cn=true]


光秀大人从未在我面前透露过他的真实本性。月亮很美，他说，简直就是月亮。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『街』（昼）******************************************************

而有一天。我和兰丸大人在城堡的小镇上。
[cpg]


;//下記のセリフ、台本では「街」ですがシナリオでは「町」になっています

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru203"]
[OnName num="ranmaru"]
'镇民们如此平和，这很好。这是我以前从未见过的'。
[cpg cn=true]


[OnName num="keitarou"]
'没错，......，因为战争的世界就要结束了。
[cpg cn=true]


但我知道我还没有完成。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru204"]
[OnName num="ranmaru"]
你知道，有些人因为战争而不爱他们所爱的人。有些人可能被撕碎了。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru205"]
[OnName num="ranmaru"]
如果这些人能够诚实地生活，我就别无他求了。"
[cpg cn=true]


兰丸大人说的事情让我很难过。知道她正在经历的事情，我不禁为她感到难过。
[cpg]

[OnName num="keitarou"]
......兰丸大人。你应该珍惜与信长大人在一起的时间。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru206"]
[OnName num="ranmaru"]
'......?　你这话是什么意思？
[cpg cn=true]


[OnName num="keitarou"]
'我的意思是，它是这样的。我知道会发生什么。
[cpg cn=true]


兰丸大人似乎还是猜不透。
[cpg]

[OnName num="keitarou"]
'如果你喜欢信长大人，你最好大声说出来。
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Ranmaru207"]
[OnName num="ranmaru"]
'那么，你是什么意思？
[cpg cn=true]


'我不能像这样做。我别无选择，只能推兰丸大人的背。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夕方）******************************************************

我正在带她回城堡。
[cpg]


;//下記のセリフ、台本では「街」ですがシナリオでは「町」になっています

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru208"]
[OnName num="ranmaru"]
突然间发生了什么事？我甚至还没有好好看过这个镇子呢。
[cpg cn=true]


[OnName num="keitarou"]
我有更重要的事情要做。
[cpg cn=true]


[OnName num="keitarou"]
'你爱信长大人，对吗？那么就没有时间犹豫或害羞了。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru209"]
[OnName num="ranmaru"]
你说我们没有时间是什么意思？信长大人已经占领了这个国家，似乎不太可能再有什么战斗了。"
[cpg cn=true]


;//ブラックアウト
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

我们两个人一起去了信长大人的房间。你需要做的第一件事是确保你对你所做的事情有充分的了解。
[cpg]

[OnName num="keitarou"]
'听着。'告诉信长大人你的感受。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="sRanmaru007"]
[OnName num="ranmaru"]
'为什么，突然.......'
[cpg cn=true]


我催促她，有点强硬。
[cpg]


[window target=false]
[STOPBGM]
[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/5" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="4/5" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

[SE f=se025]
;//【ＳＥ】『ふすま開く』

[FACE method="change_7" pos="2/5"]

[VOICE f="Nobunaga603"]
[OnName num="nobunaga"]
'什么？你们两个人一起。
[cpg cn=true]


[OnName num="keitarou"]
兰丸大人有话要对你说。
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]

[VOICE f="Ranmaru211"]
[OnName num="ranmaru"]
'嗯，等等，......，为什么一定要现在？
[cpg cn=true]


我不能向兰丸大人解释一切。如果我告诉他时限已经临近，他不会理解。
[cpg]

如果他真的明白，可能是改变未来的时候了。
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Nobunaga604"]
[OnName num="nobunaga"]
'怎么了？　你想告诉我什么呢？"
[cpg cn=true]


信长大人看向兰丸大人。兰丸大人挺直了腰杆。
[cpg]

[FACE method="change_6" pos="4/5"]

[VOICE f="Ranmaru212"]
[OnName num="ranmaru"]
'啊，让我看看...........信长大人。谢谢你一直以来把我留在你身边。
[cpg cn=true]


[FACE method="shake_4" pos="2/5"]

[VOICE f="Nobunaga605"]
[OnName num="nobunaga"]
你想说什么？你想要什么？
[cpg cn=true]


[OnName num="keitarou"]
"......兰丸大人。我不是一个粉丝。
[cpg cn=true]


我要给兰丸大人打气。兰丸大人正在努力传达他堆积的感情 ......
[cpg]

但最后一句话没有说出来。
[cpg]

[FACE method="shock_4" pos="4/5"]

[VOICE f="Ranmaru213"]
[OnName num="ranmaru"]
'我......，想的是信长大人。
[cpg cn=true]

[FACE method="change_4" pos="4/5"]

[OnName num="keitarou"]
......"
[cpg cn=true]


漫长的沉默。是信长大人打破了它。
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga606"]
[OnName num="nobunaga"]
你想说你喜欢他吗？
[cpg cn=true]


[FACE method="shock_4" pos="4/5"]

[VOICE f="Ranmaru214"]
[OnName num="ranmaru"]
不!　不，恐怕不行'。
[cpg cn=true]


兰丸大人先声夺人，急忙纠正了他。但是。
[cpg]

[FACE method="shake_6" pos="2/5"]

[VOICE f="sNobunaga021"]
[OnName num="nobunaga"]
'我很清楚这一点。你认为我是谁？"
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]

[VOICE f="Ranmaru215"]
[OnName num="ranmaru"]
'Nah... ......'
[cpg cn=true]


兰丸大人变红了。看来，他早就意识到了这一点。
[cpg]

[FACE method="change_6" pos="2/5"]

[VOICE f="Nobunaga608"]
[OnName num="nobunaga"]
我不能再假装视而不见了。我也想对你的感受作出回应。
[cpg cn=true]


信长大人似乎接受了他的想法。
[cpg]

[FACE method="change_2" pos="4/5"]
我很高兴看到兰丸大人的脸亮了起来。
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Nobunaga609"]
[OnName num="nobunaga"]
'但你突然愿意坦白的意义何在？
[cpg cn=true]


[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru216"]
[OnName num="ranmaru"]
'景太郎说了一些我不明白的话，好像他没有多少时间。......。
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
'嗯，'信长大人说，正在思索。
[cpg]

自然，我不能告诉她一切。
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga610"]
[OnName num="nobunaga"]
'那么？　你想要什么？　你想让我做什么？"
[cpg cn=true]


[FACE method="shock_4" pos="4/5"]
信长大人这么说的时候，兰丸大人反应过来了。
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru217"]
[OnName num="ranmaru"]
我希望能留在信长大人的身边。......
[cpg cn=true]


[OnName num="keitarou"]
然后就会和以前一样了。
[cpg cn=true]


信长大人点头表示同意。
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="sNobunaga022"]
[OnName num="nobunaga"]
这些年来，你为我服务得很好。至少现在，我想给你你想要的东西。
[cpg cn=true]


兰丸大人的脸变红了，他看起来好像想说什么。
[cpg]

[FACE method="change_6" pos="4/5"]

[VOICE f="Ranmaru218"]
[OnName num="ranmaru"]
'好吧，那么......，.......'
[cpg cn=true]


她接近信长大人。'我可能已经打断了你。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

我决定离开这个房间。我甚至没有想过要在女孩之间闯荡。
[cpg]

我想我至少可以快速浏览一下.......
[cpg]

说我实现了兰丸大人的愿望也不是不可以，......，但我还是不想。
[cpg]


;//移植前シーンカット

;//ブラックアウト
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（朝）******************************************************

还有后来的。信长大人问我这样的问题。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga643"]
[OnName num="nobunaga"]
你为什么派兰丸来找我？"
[cpg cn=true]


[OnName num="keitarou"]
为什么你的意思是......？
[cpg cn=true]


我不能告诉你真相。我以为我是。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga644"]
[OnName num="nobunaga"]
我不能告诉你真相。如果是，请告诉我。
[cpg cn=true]


信长大人如愿以偿，极为敏锐。我不能谈论它。
[cpg]

[OnName num="keitarou"]
'不，没什么。什么都没有。"
[cpg cn=true]


我没有欺骗他，而是撒了谎。但是。
[cpg]

[FACE method="shake_7" pos="2/3"]

[VOICE f="Nobunaga645"]
[OnName num="nobunaga"]
'你不能告诉我。当然，如果我不在我应该死的时候死，那可能是一个你不出生的未来。
[cpg cn=true]


真的，你可以看到一切。......，我想知道信长大人的感知力如何。
[cpg]


;//ブラックアウト

[window target=false]

[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

我带着一颗不平静的心回到我的工作中去。
[cpg]

今天，我被一个臣子教导政治知识。
[cpg]

有一天我可能会成为负责人......。
[cpg]


[window target=false]
[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

我知道那个未来永远不会到来。
[cpg]

信长大人将在本能寺事变中自杀。那么，一个和平的世界仍然是很遥远的事情。
[cpg]

如果是这样的话，我需要学习的不是政治，而是如何在当下生存。
[cpg]


;//ブラックアウト

即使我这样想，也没有人可以教我这样做。
[cpg]

我不得不考虑如何自己走动。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

不管怎么说，这是兰丸大人。我必须独自去救兰丸大人。
[cpg]

我想这样做是出于纯粹的爱，也是因为我在考虑未来。
[cpg]

战争的世界并不那么甜蜜，我可以独自生活。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Nobunaga646"]
[OnName num="nobunaga"]
怎么了，你发呆了。你在想什么吗？
[cpg cn=true]


[OnName num="keitarou"]
不，不。
[cpg cn=true]


在这两个人之间，信长大人和兰丸大人越来越亲密。而这还不是全部。
[cpg]

[FACE method="change_6" pos="4/5"]

[VOICE f="Ranmaru247"]
[OnName num="ranmaru"]
谢谢你，景太郎。我有很长一段时间找不到勇气。
[cpg cn=true]


我和兰丸大人之间的距离也越来越近。
[cpg]

[OnName num="keitarou"]
'如果你爱她，你应该珍惜这种感觉。当你在.......'
[cpg cn=true]


我不经意间让我的话语有了些许疏漏。
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru248"]
[OnName num="ranmaru"]
'......，你说的 "趁早 "是什么意思？
[cpg cn=true]


[FACE method="change_1" pos="2/5"]

[VOICE f="sNobunaga023"]
[OnName num="nobunaga"]
'我想你的意思是，在夜里。
[cpg cn=true]


信长大人欺骗了我，但这是一个很好的选择。
[cpg]


;//移植前シーンカット

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

我知道我，或者说兰丸大人的爱情的结局。
[cpg]

我无法改变未来。我已经知道，我将会消失。......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

兰丸大人还不知道真相。
[cpg]

我不能告诉她。这对她来说是一个太残酷的事实。
[cpg]

当我走在路上思考时，我遇到了光秀大人。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide050"]
[OnName num="mitsuhide"]
'最近，你似乎对兰丸很着迷。
[cpg cn=true]


光秀大人。我想知道她是否就是原来在这个城堡里的那个人。
[cpg]

我想她可能在另一个城堡里。我不太了解历史事实是什么，但......
[cpg]

不知何故，我觉得选择权留给了我，她在这里。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Mituhide051"]
[OnName num="mitsuhide"]
'喂？　你能听到我吗？"
[cpg cn=true]


[OnName num="keitarou"]
'哦，嗯，......，那是什么？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide052"]
[OnName num="mitsuhide"]
'你是如此高高在上。你那么喜欢兰丸吗？
[cpg cn=true]


[OnName num="keitarou"]
'...... 是的。
[cpg cn=true]


我甚至认为我讨厌光秀先生。
[cpg]

我们要记住的是，你不能只看一眼照片就说："我不打算这样做。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_09"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

有很多事情需要考虑。我们别无选择，只能拯救兰丸大人，但......。
[cpg]

这能使我不消失吗？我还不知道。
[cpg]

除此之外，还有一个问题，就是在那之后我将如何与兰丸大人一起度过我的时间。
[cpg]


[VOICE f="Ranmaru259"]
[OnName num="ranmaru"]
景太郎。你在吗？
[cpg cn=true]


[OnName num="keitarou"]
是的。我可以帮你吗？
[cpg cn=true]


[SE f=se025]
;//【ＳＥ】『ふすま開く』
[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]


兰丸大人走进房间。然后，他有点脸红，说。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru260"]
[OnName num="ranmaru"]
'嗯，谢谢你，.......
[cpg cn=true]


[OnName num="keitarou"]
'为了什么？
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru261"]
[OnName num="ranmaru"]
我比以往任何时候都更快乐。景太郎为我安排了一切。
[cpg cn=true]


...... 兰丸大人似乎还没有意识到这个事实。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="sRanmaru008"]
[OnName num="ranmaru"]
'所以，......，我想感谢你。
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
说着，他走近我。
[cpg]

[OnName num="keitarou"]
'你确定吗？　你要到我这里来'。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru263"]
[OnName num="ranmaru"]
'没有理由不这样做。我不知道怎么感谢你才好。
[cpg cn=true]


原本，他们是相似的。他崇拜信长大人，努力工作，帮助她接管国家。
[cpg]

;//ブラックアウト
;//移植前シーンカット
;//【ＢＧ】『城＿室内』（昼）

兰丸大人可能相信......，情况会继续保持下去。
[cpg]

但现实是，信长大人不会活得太久。
[cpg]


;//ブラックアウト

而兰丸大人一定感觉到了我为什么看起来如此沮丧。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru286"]
[OnName num="ranmaru"]
...... 嘿。信长大人会发生什么？
[cpg cn=true]


兰丸大人感觉到我的态度，就这样问我。
[cpg]

我不知道该如何回答，但我告诉了我能说的。
[cpg]

[OnName num="keitarou"]
我不能告诉你一切。我不能告诉你一切，因为在我没有出生的未来，它可能会发生变化。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru287"]
[OnName num="ranmaru"]
我有一种预感，但我不能告诉你。你是来自未来。
[cpg cn=true]


兰丸大人似乎对这一点认识颇深。
[cpg]

我很沮丧，为了保护我自己，我不能告诉他们所有的信息。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru288"]
[OnName num="ranmaru"]
'毕竟，有人背叛了你？或者是一个意外？"
[cpg cn=true]


[OnName num="keitarou"]
'......，我不能告诉你。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru289"]
[OnName num="ranmaru"]
'所以你的意思是你不能告诉我发生了什么事？
[cpg cn=true]


而信长大人比兰丸大人更聪明。她可能早就注意到了。
[cpg]

我为自己无能为力而感到遗憾。
[cpg]

[OnName num="keitarou"]
'我很抱歉。我无法控制自己。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Ranmaru290"]
[OnName num="ranmaru"]
不要道歉。这不是你的错。
[cpg cn=true]



[SE f=se024]
;//【ＳＥ】『通路歩く』

我们都陷入了沉默。这时，脚步声走近了。
[cpg]


[free time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]


[VOICE f="Mituhide053"]
[OnName num="mitsuhide"]
怎么了，有一张神秘的脸？
[cpg cn=true]


光秀大人来了，跟我们说话。兰丸大人回答说，对即将发生的事情视而不见。
[cpg]

[FACE method="bow_7" pos="4/5"]

[VOICE f="Ranmaru291"]
[OnName num="ranmaru"]
'啊。光秀或......，你也是，这个时候你在这里干什么？'
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Mituhide054"]
[OnName num="mitsuhide"]
'不要为我担心。我想到的第一件事是，你们两个人看起来很了不起。
[cpg cn=true]


[OnName num="keitarou"]
'......'
[cpg cn=true]


我想到的是，你们两个人在一起的时候，我也是这样想的。
[cpg]

我恨光秀大人，但我对她无能为力。
[cpg]

即使我可以让她改变主意，也和事先告诉她一样。
[cpg]

;//＠いずれにせよ信長様が長らく国を治めることになり、未来が変わる。
无论如何，信长大人将长期统治国家，未来将发生变化。
[cpg]

[FACE method="change_6" pos="2/5"]

[VOICE f="Mituhide055"]
[OnName num="mitsuhide"]
'不要看起来很害怕。你的眼睛看起来好像是在看你所珍视的人的复仇者'。
[cpg cn=true]


这并没有错。或者说，这正是它的本质。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

信长大人现在是一个人的世界。即使我们不能救她，也许我们至少可以救出兰丸大人。
[cpg]

信长大人将不可避免地无法获救。这将是历史的一个重大改变。
[cpg]

因为他的性格，信长大人也很难作为一个普通人在某个地方生存。
[cpg]

但是兰丸大人呢？
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

今天，我把所有的时间都用来学习政治，以便成为未来的军阀。
[cpg]

即使你认为这是无用的......，你也无法向任何人解释为什么它是无用的。
[cpg]

我不能告诉任何人，信长大人的统治会被推翻。
[cpg]


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[OnName num="keitarou"]
'......，我今天很累。
[cpg cn=true]


我没有时间做这个。但我们还应该做什么？
[cpg]

我只是想不出让信长大人活着的办法。
[cpg]

如果是这样的话，我们至少要救出兰丸大人。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Ranmaru292"]
[OnName num="ranmaru"]
'干得好。扎下太多的根是不好的。"
[cpg cn=true]


我想知道他们是否是这样看待我的。我对学习政治不屑一顾。
[cpg]

[OnName num="keitarou"]
'...... 兰丸大人。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru293"]
[OnName num="ranmaru"]
怎么了，......，你那张神秘的脸？
[cpg cn=true]


[OnName num="keitarou"]
'我只想让你快乐。我似乎无法拥有这一切。
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Ranmaru294"]
[OnName num="ranmaru"]
这就是故事。会不会有一个大事件？
[cpg cn=true]


就连兰丸大人也显得有些愁眉苦脸。
[cpg]

你一定觉得很沮丧，因为你无法从我嘴里套出故事。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="sRanmaru009"]
[OnName num="ranmaru"]
'......，让我们暂时忘掉它吧。只要你在我身边，我就不想要别的东西。
[cpg cn=true]


[OnName num="keitarou"]
我不这么认为。我觉得你也喜欢信长大人。"
[cpg cn=true]


我第一次看到她的时候，我觉得她有点花花肠子。还有。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru296"]
[OnName num="ranmaru"]
'不要对我吝啬。
[cpg cn=true]


他只是说。是的，这是件不必要的事。......。
[cpg]


;//ブラックアウト


兰丸大人可能认为，我和信长大人都很重要。
[cpg]

我仍然认为鼓励兰丸大人的忏悔并不是一个错误。
[cpg]

在结合之前就死去并被分开，这太残酷了。
[cpg]

;//移植前シーンカット
;//【ＢＧ】『城＿室内』（夜）
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

我再一次证实了我的内心感受。
[cpg]

我只想拯救她。这就是全部。
[cpg]


[FO pos="4/7" time=1000]
[WAIT time=1100]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru318"]
[OnName num="ranmaru"]
我想成为你的妻子。我想和你一起度过我的余生。......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru319"]
[OnName num="ranmaru"]
在你的知识中，我也死了吗？"
[cpg cn=true]


如果我在这里点头，我真的会。
[cpg]

我没有选择，只能否认。我已经下定决心，她是我唯一会让其活着的人。
[cpg]

[OnName num="keitarou"]
不，我只救兰丸大人。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
兰丸大人微微一笑，但她的眼神很悲伤。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru320"]
[OnName num="ranmaru"]
'......，我希望这些日子能永远持续下去。
[cpg cn=true]


[FG f="CHA05_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
这句话似乎来自我的心底。我再次拥抱兰丸大人。
[cpg]



[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru321"]
[OnName num="ranmaru"]
'别这样，......，如果你现在拥抱我，你会想哭的。
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_09"]

;//【ＢＧ】『城＿室内』（朝）******************************************************

我们都睡着了，当天亮的时候，...... 兰丸大人说。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru344"]
[OnName num="ranmaru"]
'...... 景太郎。现在可能不是说这个的时候，但......
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru345"]
[OnName num="ranmaru"]
如果你说我们没有时间了，我必须告诉你一些事情。我现在想说的是，我很平静。
[cpg cn=true]


[OnName num="keitarou"]
'......，这是什么？
[cpg cn=true]


我有一些想法，我打算说什么。
[cpg]


;//下記のセリフ、台本では
;//「あんたと結婚したい。あたしの夫になってくれ……景太郎」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru346"]
[OnName num="ranmaru"]
'做我的丈夫，...... 景太郎。
[cpg cn=true]


...... 在这个时代，有向女人求婚这种事吗？
[cpg]

还是因为她仍然是个军阀？
[cpg]

我们可能总是会有些不同。
[cpg]

如果我成为军阀，我想我不可能马上就像兰丸大人那样出色。
[cpg]

这就是为什么我会用她的头衔来称呼她，这也是她向我求婚的原因，尽管.......。
[cpg]

[OnName num="keitarou"]
'谢谢你。你确定你想要我吗？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="sRanmaru010"]
[OnName num="ranmaru"]
'不，不是的。它必须是你。
[cpg cn=true]



;//ブラックアウト

而我成为兰丸大人的丈夫。
[cpg]

在保留对信长大人的爱的同时，兰丸大人已经决定成为我的妻子。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

;//下記のセリフ、台本では
;//「めでたいことだな。蘭丸がついに結婚することになるとは」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="3/3" time=800]


[VOICE f="Nobunaga660"]
[OnName num="nobunaga"]
这是件幸福的事，不是吗？
[cpg cn=true]



[FACE method="bow_1" pos="3/3"]

[VOICE f="Mituhide056"]
[OnName num="mitsuhide"]
是的，真的。兰丸对信长大人忠心耿耿，所以我认为他将长期保持单身。
[cpg cn=true]


信长大人真诚地祝贺兰丸大人。
[cpg]

但光秀大人有点讽刺。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru348"]
[OnName num="ranmaru"]
'啊，光秀，在你面前我很高兴。光秀，我在你之前就已经让你高兴了。
[cpg cn=true]


兰丸大人回答说，他挺起了胸膛。光秀大人耸了耸肩。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru349"]
[OnName num="ranmaru"]
'...... 所以，景太郎。我有话要对你说。
[cpg cn=true]


[OnName num="keitarou"]
它是什么？
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
我想我有孩子了，"兰丸用很小的声音说。兰丸大人用低沉的声音说。
[cpg]

[FACE method="change_5" pos="1/3"]

信长大人惊讶了一会儿，然后笑了。
[cpg]

[FACE method="bow_2" pos="1/3"]

[VOICE f="Nobunaga661"]
[OnName num="nobunaga"]
'我明白了。对你有好处，你将成为一个母亲。
[cpg cn=true]


她似乎和她一样高兴。
[cpg]

兰丸大人在得到信长大人的祝贺后，一定处于梦幻状态。
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Ranmaru351"]
[OnName num="ranmaru"]
'是的。我将把你作为信长大人的孩子来抚养。
[cpg cn=true]


[OnName num="keitarou"]
这有点...... 过分，不是吗？
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru352"]
[OnName num="ranmaru"]
这意味着你也要做父亲了，景太郎。你感觉到了吗？
[cpg cn=true]


[OnName num="keitarou"]
不，......，还没有，真的没有。
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru353"]
[OnName num="ranmaru"]
我不这么认为。我也还没有感觉到。
[cpg cn=true]


[OnName num="keitarou"]
但即便如此，我也没有想到你会说你是信长大人的孩子。
[cpg cn=true]


兰丸大人微微一笑，回答道。
[cpg]

[FACE method="shake_2" pos="2/3"]

[VOICE f="Ranmaru354"]
[OnName num="ranmaru"]
这是一种感觉，这就是我的感觉。当然，我也爱你。
[cpg cn=true]


'你当然知道。尽管我知道，但当它被付诸于文字时，我感到很尴尬。
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

我和兰丸大人在一起的时间就像沙子从我手中洒落一样过去了。
[cpg]

自从她受孕以来，已经过去了四个月。她的腹部膨胀了。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

本野寺事件。我不知道信长大人占领了这个国家之后，需要多长时间才能实现。
[cpg]

但是，如果兰丸大人的生命有危险，我不能只是坐在那里想。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru355"]
[OnName num="ranmaru"]
...... 你看起来像是在思考什么。
[cpg cn=true]


[OnName num="keitarou"]
没有，什么都没有。
[cpg cn=true]


;//移植前シーンカット

我必须把她从叛乱中救出来。
[cpg]

这是我们有朝一日一定要谈的事情。
[cpg]

[OnName num="keitarou"]
兰丸大人。能否给我一点时间？
[cpg cn=true]


当我用严肃的语气说时，兰丸大人也变得有些紧张。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru380"]
[OnName num="ranmaru"]
它是什么？
[cpg cn=true]


[OnName num="keitarou"]
'......，这是关于未来。
[cpg cn=true]


[OnName num="keitarou"]
信长大人将在其中死去的事件将从现在开始发生。你将会被卷入其中。
[cpg cn=true]


兰丸大人已经知道这一点。
[cpg]

不过，我还是忍不住说了出来。
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Ranmaru381"]
[OnName num="ranmaru"]
你是说你要在那里救我？
[cpg cn=true]


[OnName num="keitarou"]
是的，历史没有什么变化，我们只是生存......。我打算这么做，但你愿意吗，兰丸大人？"
[cpg cn=true]


兰丸大人很平静，很镇定，没有濒临流泪。
[cpg]

她并不是没有想过这个问题。事实上，她可能比我想得更多。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru382"]
[OnName num="ranmaru"]
在过去，我会说得不一样。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru383"]
[OnName num="ranmaru"]
她可能会说她会和信长大人一起死。但现在我想和你有一个幸福的未来。
[cpg cn=true]


她似乎已经下定了决心。
[cpg]

我希望得到幸福。我不知道这样的和平是否从现在开始就在等待着我，仍然......。
[cpg]

[OnName num="keitarou"]
'我明白。我也不会再犹豫了。"
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Ranmaru384"]
[OnName num="ranmaru"]
'啊。我很抱歉到现在为止我一直都很烦恼。
[cpg cn=true]


[OnName num="keitarou"]
我不是在向你道歉，兰丸大人。这也是我的问题。
[cpg cn=true]


在某些时候，我都快哭了。兰丸大人用他的手指为我擦拭眼泪。
[cpg]

[FACE method="shake_2" pos="2/3"]

[VOICE f="Ranmaru385"]
[OnName num="ranmaru"]
'......，会没事的。我们会没事的。
[cpg cn=true]


;//ブラックアウト

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[SE f=se024]
;//【ＳＥ】『通路歩く』

;//蘭丸と信長の立ち絵は表示しないでください

有一天，我听到兰丸大人和信长大人的谈话。
[cpg]




[VOICE f="Ranmaru407"]
[OnName num="ranmaru"]
'信长大人，......，关于有关的事情。
[cpg cn=true]


我听到兰丸大人的声音从房间的方向传来。我听了。
[cpg]


[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="4/5" time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

[VOICE f="Ranmaru408"]
[OnName num="ranmaru"]
'看来，离别的时间已经很近了。你有他的消息吗？
[cpg cn=true]


[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga662"]
[OnName num="nobunaga"]
'我没有听说，但他好像已经告诉我了。我有一个想法。
[cpg cn=true]


信长大人似乎并不害怕自己的死亡。
[cpg]

我想知道他怎么会有这样的心理状态，但这似乎是事实。
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru409"]
[OnName num="ranmaru"]
'我很抱歉，.......我不能为你做任何事。
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga663"]
[OnName num="nobunaga"]
不要道歉。我没有做错什么。"
[cpg cn=true]


兰丸大人正与信长大人流着泪交谈。
[cpg]

[FACE method="change_2" pos="2/5"]

[VOICE f="Nobunaga664"]
[OnName num="nobunaga"]
这很有趣。兰丸，到目前为止，没有什么能取代与你一起在这场战争中生存的日子......。
[cpg cn=true]


[FACE method="shock_4" pos="4/5"]

[VOICE f="Ranmaru410"]
[OnName num="ranmaru"]
...... 我也是。
[cpg cn=true]


兰丸终于哭了出来，似乎认为自己终究不想失去信长大人。
[cpg]

我一直在听他们说，没有进去。
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru411"]
[OnName num="ranmaru"]
'信长大人。我应该怎么做？　我不想失去景太郎和信长大人。
[cpg cn=true]


短暂的沉默。然后。
[cpg]

[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga665"]
[OnName num="nobunaga"]
'你仍然很虚弱。如果你想和他单独生活在一起，那还不够好。
[cpg cn=true]


信长大人平静地说道。
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru412"]
[OnName num="ranmaru"]
'我很虚弱。'没有信长大人，我还是活不下去。
[cpg cn=true]


我觉得我不能留下来，但我知道我无论如何也不能改变未来。
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

末日开始了。一个巨大的变化即将到来。
[cpg]

我和兰丸大人之间的关系将不会保持不变。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru413"]
[OnName num="ranmaru"]
...... 信长大人正在向本能寺进发。
[cpg cn=true]


[OnName num="keitarou"]
我明白了。......
[cpg cn=true]


我甚至不能说，信长大人会在那里被出卖。但是。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru414"]
[OnName num="ranmaru"]
嘿，景太郎。最近，光秀的行为很怪异。"难道是......"
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


在历史上，兰丸大人从未意识到叛乱的存在。
[cpg]

所以我认为我说的很多话已经产生了影响。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru415"]
[OnName num="ranmaru"]
如果你不在那里，我也会死的，没有什么可炫耀的。"
[cpg cn=true]


即便如此，兰丸大人也只是这么说。
[cpg]

他似乎无意于帮助信长大人。在这个过程中，你会发现，在你的生活中，有很多事情是你无法想象的。
[cpg]

[OnName num="keitarou"]
'兰丸大人。我将保护你。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Ranmaru416"]
[OnName num="ranmaru"]
这是很自然的。如果你不这么说，我选择你就没有意义了。
[cpg cn=true]


;//ブラックアウト
;//移植前シーンカット


命运的时刻终于来临了。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

此后不久。
[cpg]

光秀大人的叛乱甚至被传到了城堡里。和......
[cpg]

信长大人在本能寺事变中自杀。
[cpg]

兰丸大人在悄悄地哭。我相信你已经为此做好了准备，但即便如此，你仍然必须感到强烈的失落感。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru441"]
[OnName num="ranmaru"]
'从现在开始，我们应该如何生活？
[cpg cn=true]


[OnName num="keitarou"]
'如果我们要活过战争，我们应该跟随秀吉或家康。 ......
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]

[VOICE f="Ranmaru442"]
[OnName num="ranmaru"]
我想知道是谁杀了光秀。谁杀了光秀？她和谁打了一架，或者她会接手吗？"
[cpg cn=true]


[OnName num="keitarou"]
'不。不，他应该和秀吉交手，而且输了。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru443"]
[OnName num="ranmaru"]
那么......，这就是我们应该求助的地方。让我们马上加入他们，我们不能自己去对抗他们。
[cpg cn=true]


兰丸大人比以前更冷静了。他没有因为失去信长大人而心烦意乱。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

而我们决定与秀吉汇合。
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

当我们到达城堡时，兰丸大人告诉我这样的事情。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru444"]
[OnName num="ranmaru"]
'尽管发生了这种情况，我很高兴我选择了你。
[cpg cn=true]


兰丸大人的眼睛在看向未来。我不可能是唯一被遗弃的人。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


此后的几个月和几天都在流逝。我觉得他们好像在慢慢地过去。
[cpg]

在我为信长大人报了仇之后，这一天到来了。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[SE f=se000]
;//【ＳＥ】『赤ちゃんの泣き声』

兰丸大人正在微笑着给婴儿喂奶。
[cpg]

我成了父亲，兰丸大人成了母亲。
[cpg]

一切都不能停留在一个地方。
[cpg]

兰丸大人似乎知道这一点。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru445"]
[OnName num="ranmaru"]
'当这个孩子长大了，爱上了，你知道。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru446"]
[OnName num="ranmaru"]
'我不希望那个未来，她可能会死，离开她所爱的人，你呢？
[cpg cn=true]


[OnName num="keitarou"]
'...... 是的。是的。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru447"]
[OnName num="ranmaru"]
'我将边走边编。光秀也是我的敌人，但这不是我必须打败他的唯一原因。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru448"]
[OnName num="ranmaru"]
我希望未来每个人都能诚实地对待自己的爱情。什么是......"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru449"]
[OnName num="ranmaru"]
如果我说我只想要和平，也许这就是我想要的一切。
[cpg cn=true]


[OnName num="keitarou"]
'不。我认为这是一个不可改变的事实'。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

她有坚强的意志。她比我坚强得多。
[cpg]

她在失去信长大人之前的那个软弱的女友已经不复存在。
[cpg]


;//ブラックアウト


;//＠

;//ＥＮＤ　ヒロイン５ルート

[SCENE id=10]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="epend.ks" target="*start"]


