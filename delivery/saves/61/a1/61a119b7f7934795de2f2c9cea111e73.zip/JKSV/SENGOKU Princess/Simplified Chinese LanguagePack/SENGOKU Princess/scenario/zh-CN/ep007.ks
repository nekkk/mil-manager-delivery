
*start

;//==============================
;//謙信の所へ潜入　二度音の鳴るマスを通った場合

*select04_lose|忠于信玄公。

*root_3|忠诚度受到考验

;#################################################
*Ep007|忠诚度受到了考验。
;#################################################

[SCENE id=7]


[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin003"]
[OnName num="kenshin"]
欢迎来到我的城堡。也许你是信玄的手下。"
[cpg cn=true]


谦信不是唯一在那里的人。除谦信外，其他士兵都站着保护她。
[cpg]

他们拿着剑。我们的武器不是他们的对手。
[cpg]

[OnName num="ninja"]
'该死的......！
[cpg cn=true]


她试图拉回来，但是。
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin004"]
[OnName num="kenshin"]
'他们一定认为我们的武器不够用了。我的手下告诉我们，忍者已经潜入了。
[cpg cn=true]


有士兵围着我们转，要把我们按倒。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

我们中的每一个人都被抓住了。一些忍者因为抵抗而被杀。
[cpg]

我也不例外。即使是现在，我也无法从监狱里出来。
[cpg]

按照这种速度，我将被杀死或被折磨。或者两者都有。
[cpg]

[OnName num="keitarou"]
'...... 不。没有。"
[cpg cn=true]


我必须不惜一切代价活着出去。这是我对信玄大人的承诺。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin005"]
[OnName num="kenshin"]
你很鲁莽，是吗？我们决不能被低估。
[cpg cn=true]


然后谦信就来了。我不由自主地站起来，用手抓住格栅。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin006"]
[OnName num="kenshin"]
'你有什么遗言吗？
[cpg cn=true]


我决定打出我剩下的唯一一张牌。
[cpg]

[OnName num="keitarou"]
'......，我一直在信玄大人身边，我知道她有什么计划。
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Kensin007"]
[OnName num="kenshin"]
'我明白了。每个人都这么说。我不认为我可以相信你说的话。
[cpg cn=true]


谦信不听。
[cpg]

但我有办法证明，我确实一直在信玄身边。
[cpg]

[OnName num="keitarou"]
'我的名字是景太郎。这个名字听起来很熟悉吗？有可能是信玄大人敢于传播谣言。"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin008"]
[OnName num="kenshin"]
'...... 景太郎。你是那个人吗？
[cpg cn=true]


我也欠信玄大人的情。但现在，我必须把拯救自己的生命放在首位。
[cpg]

此外，如果他活着，他可能会再次见到信玄大人。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin009"]
[OnName num="kenshin"]
'我想最好是放弃对你的处决，就这一次。我听说过一些传言。
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

我在监狱里度过了一个不眠之夜。
[cpg]

和我一起潜入的人都会被杀死。
[cpg]

这是很自然的，但我还是有些措手不及。
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿外観＿謙信』（昼）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

我很难入睡，我不知道自己是醒着还是睡着了。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin010"]
[OnName num="kenshin"]
'你好。景太郎先生。"
[cpg cn=true]


[OnName num="keitarou"]
'......!'
[cpg cn=true]


但在一瞬间，我的睡意被吹散了。谦信已经出现了。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin011"]
[OnName num="kenshin"]
'你不需要这么害怕。我已经决定相信你所说的。
[cpg cn=true]


谦信在监狱里告诉我。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Kensin012"]
[OnName num="kenshin"]
'看来你的存在是有传闻的。我不知道这些细节。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin013"]
[OnName num="kenshin"]
'显然，你起初是和信长在一起。从那时起我就听说了你的事。
[cpg cn=true]


[OnName num="keitarou"]
你会帮助我们吗？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin014"]
[OnName num="kenshin"]
'他们是不应该被保留生命的人。但如果杀了他，那就太可惜了。
[cpg cn=true]


[OnName num="keitarou"]
谢谢你，......."
[cpg cn=true]


各种各样的想法都在我的脑海中闪现。
[cpg]

在感谢谦信的同时，我也会背叛信玄大人。我想知道这是否可以。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin015"]
[OnName num="kenshin"]
'但我还不能让你出狱。你永远不知道他何时会背叛你。
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我在没有灯光的监狱里呆了一段时间。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

我不知道他什么时候会杀我，但我知道他不会很快杀我。
[cpg]

我当时没有心情。我不觉得自己还活着。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin016"]
[OnName num="kenshin"]
'这是个美好的夜晚。甚至月光也不能照到这个监狱。
[cpg cn=true]


[OnName num="keitarou"]
'......谦信大人.
[cpg cn=true]


我发现自己在叫她的名字。我再也不能说她只是一个敌人了。
[cpg]

[OnName num="keitarou"]
我不再是一个单纯的敌人了。我不会跑掉。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Kensin017"]
[OnName num="kenshin"]
'你意识到你做了什么吗？　你进去的时候没有想到你会被杀吗？
[cpg cn=true]


我没有什么可说的。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin018"]
[OnName num="kenshin"]
'我已经告诉你很多次了，你不需要害怕。
[cpg cn=true]


[OnName num="keitarou"]
'......，你不可以。我被困在这样的地方。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Kensin019"]
[OnName num="kenshin"]
'如果你想让我离开这里，这是一个交易。如果我把你从这里弄出去，那就成交了。
[cpg cn=true]


[OnName num="keitarou"]
它是......
[cpg cn=true]


我迷路了。我已经迷失了方向，但现在唯一的生存之道可能就是背叛信玄大人。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin020"]
[OnName num="kenshin"]
你就不能至少告诉我们信玄接下来打算做什么吗？让我们交换一下这个信息。
[cpg cn=true]


在这里，说谎和说真话有很大区别。
[cpg]

我们能不能撒个大谎，等着信玄大人来救我们？......
[cpg]

谦信大人说。如果你服从我，我甚至会给你一个奖励：.......
[cpg]

当然，这种话并不能改变我的忠诚。
[cpg]

然而，我的情绪却在不断波动。
[cpg]

如果谦信大人这么说，我应该跟随她吗？
[cpg]

我甚至不知道'奖励'这个词是什么意思。......
[cpg]

我为信玄大人撒谎吗？我有两个选择：为了谦信大人的利益，说出真相。
[cpg]


;//■選択肢
[switch]
[case "说谎"]
	[swap]
	[jump target="*root_3_bad"]
[case "说出真相"]
	[swap]
	[jump target="*root_3_true"]
[endswitch]

1、说谎话
2，说实话。


;//==============================
;//１、嘘をつく

*root_3_bad|鲁莽的忠诚。




[OnName num="keitarou"]
'......，信玄大人正在计划一次突袭。而且我知道日期和时间。"
[cpg cn=true]


经过一番思考，我崩溃了，撒了谎。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin021"]
[OnName num="kenshin"]
'是这样的吗？如果他计划进行这样的突然袭击，......，那么我们就反击他。"
[cpg cn=true]


我决定告诉他们一些与实际入侵计划完全不同的事情，让他们把城堡变薄。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Kensin022"]
[OnName num="kenshin"]
'谢谢你，告诉我这么重要的事情。我应该奖励你吗？
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

他们还把我从监狱里放了出来。
[cpg]

在一些士兵的包围下，被谦信大人带走，我很感动。
[cpg]


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[OnName num="keitarou"]
'......，哈哈......'
[cpg cn=true]


我终于被释放了。当然，这个房间是有警卫的。
[cpg]

我又不能试图逃跑。即便如此，我的感觉还是很不同。
[cpg]

紧张的气氛松动了，我很久以来第一次睡得像泥巴一样。......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

在我意识到我所说的一切都是谎言之前，还需要一些时间。
[cpg]

或者说，战争有可能被颠覆，信玄大人将发动进攻。
[cpg]

如果那样的话，我就完成了我作为一个忍者的角色。
[cpg]

我不知道是否会有那么好的结果，但我赌的是这种可能性。
[cpg]


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

第二天晚上，谦信大人来看我。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin023"]
[OnName num="kenshin"]
'我们现在正准备拦截你们。如果我们赢得这场战斗，那将是对你的感谢。
[cpg cn=true]


谦信大人看起来好像不知道该不该相信我。
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ（隣り合う二人。キスをする）ev_57
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_57_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Kensin024"]
[OnName num="kenshin"]
'你说过我会奖励你的，不是吗？
[cpg cn=true]


说着，他在我身上蹭了蹭。
[cpg]

[OnName num="keitarou"]
'谦信大人，......，什么.......'。
[cpg cn=true]



[VOICE f="Kensin025"]
[OnName num="kenshin"]
'我真的很感谢你，我亲爱的。当然，如果你说的是真的'。
[cpg cn=true]


她说。如果你说实话，我会给你一个奖励。
[cpg]

看来，这即将成为现实。......。
[cpg]


[VOICE f="sKensin001"]
[OnName num="kenshin"]
'Chuu.......'
[cpg cn=true]


她的嘴唇碰到了我的嘴唇。
[cpg]


;//移植前シーンカット

;//ブラックアウト

;//移植前シーンカット

那个吻是有罪的。......
[cpg]

事实上，信玄大人不可能像他那样进行攻击。
[cpg]

谦信大人正试图拦截一个不应该来的敌人。
[cpg]

同时，只要信玄大人能来......。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

并等待着他，但结果却不是这样的。
[cpg]

事实上，他们在任何时间内都没有攻击我们。
[cpg]

信玄大人既没有被拦截，也没有来救我。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin078"]
[OnName num="kenshin"]
'你是什么意思？　你在撒谎吗？"
[cpg cn=true]


谦信大人问我。我急忙找了个借口。
[cpg]

[OnName num="keitarou"]
'他一定以为我知道这些信息，所以敢于出卖我。
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Kensin079"]
[OnName num="kenshin"]
'......，这是有可能的，但那样你就没用了，不是吗？
[cpg cn=true]


你说得很对。我怎么能从这里生存下去呢？
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

如果我什么都不做，谦信大人就会放弃我。
[cpg]

如果发生这种情况，那么将是死亡的时候。我别无选择，只能在这种情况发生之前逃离这里。
[cpg]

这是我甚至不需要考虑的事情。信玄大人是否愿意帮助我，是在此之前的一个问题。
[cpg]

从我目前看到的情况来看，我知道守卫变化时的周期。
[cpg]

我将在那一刻尝试逃跑。......
[cpg]

[OnName num="keitarou"]
......"
[cpg cn=true]



;//ブラックアウト

[SE f=se030]
;//【ＳＥ】『床走る』

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

我曾多次潜入城堡。我对这个城堡是什么样的结构有一些了解。
[cpg]

[OnName num="soldier"]
'等等!　嘿，谁在那里？
[cpg cn=true]


尽管如此，这仍然是相当艰难的。毕竟，我没有武器。
[cpg]

没有武器，我就不能拿他们。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin080"]
[OnName num="kenshin"]
'我知道你会背叛我。你甚至为了保住性命而对我撒谎。"
[cpg cn=true]


最后挡在我面前的是谦信大人。
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Kensin081"]
[OnName num="kenshin"]
'在这种情况下，你是鲁莽而不是勇敢。我对你感到很失望。
[cpg cn=true]


我不能说什么。我只是一想到将要发生的事情就感到害怕。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

我最终被抓住并被关进监狱。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

在监狱里，我以为这一次我会被杀死。
[cpg]

没有理由再让我活着。我从未想过这会发生。......
[cpg]

尽管这是我应得的，但我回想起来，我应该从一开始就在信玄大师身边工作。
[cpg]

或者说，我应该说实话，而不是撒谎。
[cpg]

现在想来，这一切都很不可能。
[cpg]


[window target=false]
[BG f="b_14_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（昼）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

中午时分，谦信大人来拜访我。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Kensin082"]
[OnName num="kenshin"]
'你感觉如何？
[cpg cn=true]


[OnName num="keitarou"]
'......'
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Kensin083"]
[OnName num="kenshin"]
'我在问你，你有什么感觉，欺骗了别人。你为什么不回答我？
[cpg cn=true]


我仍然保持沉默。
[cpg]


;//ブラックアウト

;//移植前シーンカット

;//ブラックアウト

;//========================================
;//●ＣＧ（主人公を足蹴にするヒロイン）ev_58
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：裸
;//場所　：牢の中
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_58_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]



;//移植前シーンカット


[VOICE f="sKensin002"]
[OnName num="kenshin"]
我可以不关心你的生活。
[cpg cn=true]



[VOICE f="sKensin003"]
[OnName num="kenshin"]
'你愿意为忠诚而死吗？　这就是你真正想要的吗？
[cpg cn=true]


我试图保持一颗坚强的心。
[cpg]

她说得没错，我对信玄大人的忠诚是我唯一的依靠。
[cpg]


[VOICE f="sKensin004"]
[OnName num="kenshin"]
'你愿意为我工作吗？
[cpg cn=true]


我保持沉默。我没有回答。
[cpg]


[VOICE f="Kensin141"]
[OnName num="kenshin"]
'我很佩服你直到最后也不背叛我的精神，但这不会让你活得太久。
[cpg cn=true]



[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

;//背景と別の場所なので、上下に黒帯を入れるなどしてください

谦信先生离开后再也没有来看过我。
[cpg]

最后，直到最后，他都没有交待。
[cpg]

在监狱里，我等待着信玄大人来救我。
[cpg]

但我也知道，川中岛之战没有结果。
[cpg]

就这样，我消失在历史的阴影里。......。
[cpg]


;//ブラックアウト

;//ＥＮＤ　バッドエンドルート

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="epend.ks" target="*back_title"]


;//==============================
;//２、本当のことを言う

*root_3_true|相信的心。



[OnName num="keitarou"]
"我明白。......我向你宣誓效忠。"
[cpg cn=true]


我决定转向谦信大人，告诉他真相。
[cpg]

[OnName num="keitarou"]
我知道信玄大人会如何责备我，但我知道更重要的事情。
[cpg cn=true]


没有理由再把它藏起来了。我甚至无法掩盖我来自未来的事实。
[cpg]

[OnName num="keitarou"]
'我是来自未来。起初我是在信长大人那里。......。
[cpg cn=true]


[FACE method="shake_5" pos="2/3"]

[VOICE f="Kensin142"]
[OnName num="kenshin"]
'这突然间是什么？　没有人会相信这样的谎言，即使是为了生存。
[cpg cn=true]


[OnName num="keitarou"]
这是真的。我还知道，这次川中岛之战没有结果。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin143"]
[OnName num="kenshin"]
...... 如果是真的，我想不出还有谁比你更有用。到目前为止，我没有理由相信它。
[cpg cn=true]


我还向他透露了信玄大人的所有计划。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我被放出了监狱，并把细节告诉了谦信大人。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin144"]
[OnName num="kenshin"]
'你是说他们从前面来了。然后我们就可以从我们这边发动突然袭击'。
[cpg cn=true]


[OnName num="keitarou"]
'...... 是的。我想是的。
[cpg cn=true]


我的话即将改变战争局势。
[cpg]

从这一天起，我对待他们的态度也发生了变化。
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Kensin145"]
[OnName num="kenshin"]
'最终，我还是要背叛信玄。我已经等待这一刻很久了'。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（朝）******************************************************

我决定为谦信大人服务。
[cpg]

我告诉他真相，包括我的身份。谦信大人正试图智取信玄大人的策略。
[cpg]

我从未被带到过战场。我猜这意味着他是一个有风险的人。
[cpg]

无论如何，我不得不与信玄大人反目。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夕方）******************************************************

川中岛之战并没有以一次冲突而结束。
[cpg]

这次我加入谦信大人的行列，是一个不正常的现象。漫长的战斗可能在此结束。......
[cpg]

最后，这场战斗没有得到解决。谦信大人没有打败信玄大人就回来了。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Kensin146"]
[OnName num="kenshin"]
'...... 困难，不是吗？这是否意味着我们毕竟是不共戴天的敌人？"
[cpg cn=true]


谦信大人看起来很失望。
[cpg]

我第一次了解到信玄的策略是唯一一次。
[cpg]

我认为这将是一个错过的机会。
[cpg]

[FACE method="bow_6" pos="2/3"]

[VOICE f="Kensin147"]
[OnName num="kenshin"]
但你怎么能在最后一刻决定站在我这边？
[cpg cn=true]


[OnName num="keitarou"]
因为......，这是我必须要做的。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin148"]
[OnName num="kenshin"]
'你在站在我这边时有任何犹豫吗？
[cpg cn=true]


如果我在这里点头，我就是在撒谎。我闭口不谈。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Kensin149"]
[OnName num="kenshin"]
我很高兴他在所有的考虑后选择了我。
[cpg cn=true]

[STOPBGM]

但后来，谦信大人收拾了我。
[cpg]

[BGM f="bg_09"]

[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin150"]
[OnName num="kenshin"]
'如果我说没有神或佛，那真的是真的。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Kensin151"]
[OnName num="kenshin"]
所以，我比别人更看重信仰。...... 我也相信你所说的。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Kensin152"]
[OnName num="kenshin"]
你有一种奇怪的魅力。你有一种奇怪的魅力，以至于即使你告诉我你来自未来，我也会相信你。"
[cpg cn=true]


[OnName num="keitarou"]
'......谦信大人'。
[cpg cn=true]


我不能就这样回避她。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Kensin153"]
[OnName num="kenshin"]
'被这样面对着，你不觉得有什么吗？
[cpg cn=true]


[OnName num="keitarou"]
'不是我不觉得有什么，而是......。
[cpg cn=true]


我为信玄大人服务。然而，我也爱着谦信大人，这实在是太懦弱了。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Kensin154"]
[OnName num="kenshin"]
'你在想你以前的领主，是吗？但我认为你现在做的是最好的选择。"
[cpg cn=true]



;//ブラックアウト

;//========================================
;//●ＣＧ（主人公のすぐ前にいるヒロイン）ev_48
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_48_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]



;//移植前シーンカット

[OnName num="keitarou"]
'我不能......，突然爱上你。这很疯狂。
[cpg cn=true]



[VOICE f="Kensin178"]
[OnName num="kenshin"]
'是的，它是。但如果是这样的话，那么我约你出去就是疯了。
[cpg cn=true]


[OnName num="keitarou"]
不，......，我不是那个意思。
[cpg cn=true]



[VOICE f="Kensin179"]
[OnName num="kenshin"]
我知道。我知道我快疯了。
[cpg cn=true]


谦信大人似乎真的很感激。
[cpg]

而且我的感觉似乎还不止于此。
[cpg]


[VOICE f="Kensin180"]
[OnName num="kenshin"]
我想我是被你吸引了。以及你背叛信玄的事实。......
[cpg cn=true]



[VOICE f="Kensin181"]
[OnName num="kenshin"]
'你有一种不属于这个世界的气息。他不像其他男人'。
[cpg cn=true]


...... 这一点是毫无疑问的。我不是这个时期的人。
[cpg]


;//ブラックアウト

;//移植前シーンカット

[window target=false]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

不过，我还是想知道，我这样做是否正确。
[cpg]

可能还有其他崇拜谦信大人的诸侯。如果她像她一样美丽，他们可能会被她吸引，即使他们不是诸侯。
[cpg]

当我抛开这些人，说出我对....... 的担忧时
[cpg]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin203"]
[OnName num="kenshin"]
'你不需要担心这个问题。
[cpg cn=true]


这位谦信大人的女士回答说。
[cpg]

[OnName num="keitarou"]
'即使你这么说，我还是......，要让你吃醋。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="sKensin005"]
[OnName num="kenshin"]
'你不喜欢我是因为我会让你吃醋？
[cpg cn=true]


......，是的，这是正确的。这就是我应该做的，照顾这种感觉吗？
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（昼）******************************************************

[SE f=se019]
;//【ＳＥ】『剣戟』

然后，谦信大人和信玄大人再次发生冲突。
[cpg]

我不在那里。这意味着谦信大人还没有完全信任我。
[cpg]

谦信大人是信玄大人战略的支持者。如我所料，这次也没有解决。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿謙信』（夕方）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Kensin205"]
[OnName num="kenshin"]
'坚不可摧是这个词的意思，不是吗？另一方可能也在想同样的事情。
[cpg cn=true]


谦信大人似乎感到很沮丧。
[cpg]

然而，当这场战斗结束后，我将失去我的两位领主中的一位。
[cpg]

我所能做的，也是我所想做的，就是在这场战斗中保持平衡。
[cpg]

它将不会被解决。两位将军都不会被杀。我想选择这条道路。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Kensin206"]
[OnName num="kenshin"]
'如果发生这种情况，......，我别无选择，只能再一次把你送回信玄。
[cpg cn=true]


[OnName num="keitarou"]
......，你是什么意思？"
[cpg cn=true]


我很惊讶，听到这么意外的事情，我忍不住发出了赤裸裸的声音。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin207"]
[OnName num="kenshin"]
首先要做的是再次从信玄那里获得信息。'你会再次从信玄那里提取信息吗？
[cpg cn=true]


[OnName num="keitarou"]
'如果我这样做，你不认为我将再次加入信玄大人吗？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin208"]
[OnName num="kenshin"]
'我不这么认为。你和我不再是陌生人了。
[cpg cn=true]


谦信大人自信的这么说，我也是这么想的。
[cpg]

我再也无法动弹，回到信玄大人身边，为谦信大人报仇......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

话虽如此，我也不想为信玄大人报仇。
[cpg]

我想这是自然心理学。谦信大人可能是考虑到这一点才派我去的。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

我再次回到信玄大人身边。
[cpg]

与旅行不同，我的同伴们都走了。但我不能被吓倒。
[cpg]


[window target=false]
[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

我想信玄大人会很高兴看到我回来。但我不能再站在她那边了。
[cpg]

我就像谦信大人的双重间谍。我和信玄大人之间的关系将不再一样了。
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『山道』（夜）******************************************************

而几天过去了。我已经走了这么久，我怕我会崩溃。......
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_13_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

我终于找到了信玄大人。
[cpg]

[OnName num="soldier_A"]
"你是......！　嘿，你是谁？
[cpg cn=true]


[OnName num="soldier_B"]
你还活着!　天哪，我必须告诉信玄大人。......
[cpg cn=true]



[SE f=se016]
;//【ＳＥ】『地面に倒れ込む』

我松了一口气，就这样倒在了地上。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

下一次我醒来的时候，我在我的房间里。
[cpg]

信玄大人就在那里。这段时间他一直在我身边。
[cpg]

[OnName num="keitarou"]
'...... 信玄大人，好久不见了。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen205"]
[OnName num="shingen"]
是的，已经有很长一段时间了。真的'。
[cpg cn=true]


她说，几乎是流着泪。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Singen206"]
[OnName num="shingen"]
'我很高兴你是安全的。我以为你已经被杀了。
[cpg cn=true]


[OnName num="keitarou"]
'我不是那么容易死的，你知道。
[cpg cn=true]


我在说这种毫无根据的话时也开始哭了。
[cpg]

我毕竟不想失去信玄大人。我不能在这里背叛她。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

我知道只有一件事我必须做。
[cpg]

尽量减少信玄大人和谦信大人之间的冲突。这是我能做的一切。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Singen207"]
[OnName num="shingen"]
'...... 是的。谦信不是做这种事的人，......."
[cpg cn=true]


[OnName num="keitarou"]
是的，她说她会的。她说他现在处于防守状态。
[cpg cn=true]


我决定告知他们，我们有完善的防御措施，同时告知他们，我们无意入侵他们。
[cpg]

如果我回去找谦信大人，我也要对她说同样的话。
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Singen208"]
[OnName num="shingen"]
'感谢你在侦查中的辛勤工作。我知道我可以依靠你。
[cpg cn=true]


[OnName num="keitarou"]
'我想去多少次都可以。我相信这次我会更早回来。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen209"]
[OnName num="shingen"]
我指望着你。如果你让我担心，我不会原谅你。
[cpg cn=true]


[OnName num="keitarou"]
没有。我会处理好的。
[cpg cn=true]


我不只是去执行侦察任务。
[cpg]

我得回去找谦信大人，告诉他那边的情况。
[cpg]

避免这两者发生冲突是我的使命。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

离我们下次出发的时间已经不多了。
[cpg]

信玄大人也想摆脱这种局面。
[cpg]

但我不能让这种情况发生。
[cpg]

我不能说我是站在信玄或谦信一边的。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen210"]
[OnName num="shingen"]
'你又要去了，是吗？我会想你的。
[cpg cn=true]


[OnName num="keitarou"]
别担心。信玄大人不在，我是不会走的。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Singen211"]
[OnName num="shingen"]
我相信你。请安全地回来。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

沿着山路走了很多次之后，我的腿和背已经变得很强壮。
[cpg]

同时，我也有一种感觉，我丝毫不会被打败。
[cpg]

我觉得在谦信大人那里，让我长大了。
[cpg]


[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

沿着山路前行。无论我走多少次，这都是一段很长的距离，但我不认为它像以前那样困难。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_14_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

然后我又回到了谦信大人的地方。
[cpg]

[OnName num="keitarou"]
'...... 你又回来了，......'
[cpg cn=true]


我也没想到会是我来做这件事。
[cpg]

这正如谦信大人所希望的那样。仿佛她在控制我。
[cpg]

但这是一种...... 奇怪的感觉，好像还不错。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin209"]
[OnName num="kenshin"]
'你回来的很好。我很高兴见到你，景太郎先生。
[cpg cn=true]


[OnName num="keitarou"]
'......，我已经把信息送到信玄大人那里，让他无法攻击。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin210"]
[OnName num="kenshin"]
'你也用 "先生 "的头衔来称呼她，对吗？好吧，你不需要停下来。
[cpg cn=true]


[OnName num="keitarou"]
我很抱歉。但对我来说，她也是.......
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin211"]
[OnName num="kenshin"]
我想我在某种程度上对他们有所亏欠。"你为他服务，当然了。
[cpg cn=true]


而我在信玄大人那里也说了同样的话，虽然我是在嘲讽谦信大人。
[cpg]

[OnName num="keitarou"]
'信玄大人是在防守。如果我们现在进攻，就会被打回来。
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Kensin212"]
[OnName num="kenshin"]
'...... 是这样的吗？他有没有可能从另一边进攻？
[cpg cn=true]


[OnName num="keitarou"]
'我想这是不可能的。另一方也很警惕，他们处于防守状态。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin213"]
[OnName num="kenshin"]
'这很好。我将信任他们。
[cpg cn=true]


谦信大人这么说，但我不知道他是否能......，看穿这一切。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

然后我不得不在城堡里休息。
[cpg]

如果我呆在一个地方，我就不必经历这些麻烦了。
[cpg]

但现在事情发展到这一步，我别无选择，只能将谎言坚持到底。
[cpg]

[OnName num="kenshin_vassal"]
'这对你来说也很难。你一定是在侦查信玄的住处。
[cpg cn=true]


[OnName num="keitarou"]
是的，嗯，......
[cpg cn=true]


我相信信玄大人的臣子们也会这样告诉你。这是一个蝙蝠眼的情况，不管是哪种情况。
[cpg]

但......，我们现在必须这样做。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[BG f="b_14_3.ui" time=1500]
[WAIT time=3000]
[BG f="b_14_4.ui" time=1500]
[WAIT time=3000]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

我很担心我无法像这里一样度过难关。
[cpg]

即使他们发现了真相，他们也不会杀我。
[cpg]

尽管我明白这一点，但我很难入睡。然后...
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin214"]
[OnName num="kenshin"]
...... 景太郎先生。你睡不着吗？
[cpg cn=true]


[OnName num="keitarou"]
谦信大人就是这样的人。怎么了？
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Kensin215"]
[OnName num="kenshin"]
我还在和信玄对着干，你知道的。当我想到将要发生的事情时，我无法保持平静。
[cpg cn=true]


[OnName num="keitarou"]
我相信你是对的。
[cpg cn=true]


我有点觉得我没有做出正确的反应。
[cpg]

我所讲的谎言影响的不仅仅是她。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin216"]
[OnName num="kenshin"]
掌管士兵的人，就是掌管诸侯和在他们手下作战的士兵。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin217"]
[OnName num="kenshin"]
'因为我的生命并不属于我一个人。
[cpg cn=true]


我不能直视她的脸。当我有这样的感觉时。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Kensin218"]
[OnName num="kenshin"]
你也不例外。我希望能保护你。"
[cpg cn=true]


[OnName num="keitarou"]
'......谦信大人 ......'
[cpg cn=true]


谦信大人看起来好像在等待什么。
[cpg]

在这种情况下，什么都不做可能才是真正的背叛。
[cpg]


;//ブラックアウト
[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

我吻了谦信大人的嘴。
[cpg]

我没有犹豫，尽管我感到内疚。
[cpg]

;//移植前シーンカット

[OnName num="keitarou"]
......谦信大人。我爱你。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="sKensin006"]
[OnName num="kenshin"]
我也是如此。我也喜欢你。
[cpg cn=true]


我想知道谦信大人对我的喜欢是怎么来的。
[cpg]

也许是我来自未来，或者是我为信玄大人服务，并毫不犹豫地背叛了他。......。
[cpg]

我确定这就是它的目的，但这是他第一次告诉我他喜欢我。
[cpg]


;//移植前シーンカット

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我和谦信大人正在谈论未来。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Kensin275"]
[OnName num="kenshin"]
'你怎么看，景太郎先生？　你反对攻击信玄的地方吗？
[cpg cn=true]


[OnName num="keitarou"]
'正如我所说。信玄大人已经做了精心准备。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Kensin276"]
[OnName num="kenshin"]
'......，我明白了。
[cpg cn=true]


谦信大人似乎不相信我，但他似乎相信我。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿謙信』（朝）******************************************************

谦信大人和信玄大人之间的权力平衡是我在操纵他们。
[cpg]

仿佛我在背后操纵着将军们，在幕后控制着战争局势。
[cpg]

我没有选择，只能这样做。一旦战争结束，我们处于合作关系中，未来将被改变。
[cpg]

如果发生这种情况，我不知道我将发生什么。
[cpg]

如果我不在未来出生，我可能会消失。
[cpg]

另一方面，如果我们中的一个人获胜，未来仍然会被改变。
[cpg]

我注视着处于不稳定平衡状态的信玄大人和谦信大人，使他们不至于崩溃。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[BG f="b_01_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『街』（昼）******************************************************

我没有什么特别的事情要做，就来到了城堡镇。
[cpg]

没有人，甚至是他，会去寻找一场战斗。没有一个人认为这是不可能的。
[cpg]

[OnName num="keitarou"]
'......，这是正确的。这很明显吗？"
[cpg cn=true]


我不禁在心里想。这就是我知道战斗没有意义的程度。
[cpg]

如果是真的，最好是能带来合作关系。
[cpg]

我不知道为了自己的方便，继续维持一个士兵将来可能死亡的局面是否好。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin277"]
[OnName num="kenshin"]
你看起来很苦恼。
[cpg cn=true]


[OnName num="keitarou"]
谦信大人 ...... 你为什么在这里？
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Kensin278"]
[OnName num="kenshin"]
'因为我也是，如果我一直呆在城堡里就会感到窒息。
[cpg cn=true]


谦信大人走到我身边，我诚实地回答。
[cpg]

[OnName num="keitarou"]
'我不是在寻找战争的结束，我是在寻找停滞。
[cpg cn=true]


[OnName num="keitarou"]
'我只能说，有一些情况使战争难以结束。......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin279"]
[OnName num="kenshin"]
为什么？　我知道你来自未来，所以你为什么不告诉我一切？
[cpg cn=true]


[OnName num="keitarou"]
......，是的。
[cpg cn=true]


[OnName num="keitarou"]
如果谦信大人和信玄大人合作，他们可能会改变未来。
[cpg cn=true]


[OnName num="keitarou"]
'如果那样的话，一个与我现在所处的时代不同的时代可能会到来。如果发生这种情况，我的存在也可能消失。
[cpg cn=true]


谦信大人把手放在下巴上，思考着。
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin280"]
[OnName num="kenshin"]
'所以这就是你一直在想的事情。但你不需要担心'。
[cpg cn=true]


[OnName num="keitarou"]
'但......，即使有停滞，也会有小规模的冲突。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Kensin281"]
[OnName num="kenshin"]
'的确，有些人可能在那里失去生命。但你看重的是什么呢？
[cpg cn=true]


......，的确如此。没有什么可以代替自己的生命。
[cpg]

谦信大人可能也有同样的感受。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夕方）******************************************************

谦信大人知道我的苦恼。在她的带领下，我再次回到了城堡。
[cpg]

在人前，他向我传授了政治知识。他说，他不想仅仅利用我的情报，而是最终想给我一个更重的角色。
[cpg]


;//ブラックアウト

这是一个渐进的变化。我可以说这是我想要的那种变化。
[cpg]


;//移植前シーンカット

;//移植前シーンカット

;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

如果。如果我和谦信大人有了孩子。
[cpg]

如果那样的话，我可能连往返信玄大人的地方都会变得很困难。
[cpg]

但我认为这样就可以了。我已经准备好为谦信大人服务。
[cpg]

作为一个父亲，离开孩子这么长时间可能是一个问题。
[cpg]

如果是这样的话，我可能就得停止为信玄大人服务了。
[cpg]


[window target=false]
[BG f="b_07_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

但我还是想保持平衡。
[cpg]

如果我追随谦信大人，川中岛之战可能就会解决。
[cpg]

这是一个关于我如何表现的问题。
[cpg]

[OnName num="keitarou"]
'那好吧，我走了。
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin337"]
[OnName num="kenshin"]
是的。我将回来提供更多信息。请确保你回来。
[cpg cn=true]


[OnName num="keitarou"]
当然了。我会处理好的。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

我现在已经习惯了这条道路。我不再犹豫地在没有标志或任何东西的道路上行走。
[cpg]

如果你不犹豫，你就不会浪费你的时间。
[cpg]

我觉得我现在可以做任何事情。
[cpg]

欺骗信玄大人，避免与谦信大人发生冲突。
[cpg]

我以为我可以做一些事情，如果我冷静地想一想，这将是相当困难的。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

然后，我将再次回到信玄大人的地方。
[cpg]

他不再像以前那样一来就倒下了。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen212"]
[OnName num="shingen"]
'你已经变了，我亲爱的。
[cpg cn=true]


[OnName num="keitarou"]
'自从我和她一起躲起来之后，......，已经有很长一段时间了。
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Singen213"]
[OnName num="shingen"]
那么你似乎很奇怪的自信。
[cpg cn=true]


[OnName num="keitarou"]
不，我不知道。
[cpg cn=true]

[STOPBGM]

[FACE method="change_1" pos="2/3"]

[VOICE f="Singen214"]
[OnName num="shingen"]
我不这么认为。而且我还听到了关于这个的传言。
[cpg cn=true]


那个女人说她听到了一些传言，并提到谦信大人已经生了一个孩子。
[cpg]


;//下記のセリフ、台本では
;//「謙信が妊娠したらしいわね。彼女、独り身のはずなのだけど」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください

[FACE method="change_7" pos="2/3"]

[VOICE f="Singen215"]
[OnName num="shingen"]
她应该是单身。
[cpg cn=true]


我几乎要大声喊出来了，但还是忍住了。
[cpg]

[OnName num="keitarou"]
'那是...... 一个快乐的故事，不是吗？
[cpg cn=true]


我说："这是个快乐的故事。
[cpg]

[FACE method="shake_7" pos="2/3"]

[VOICE f="Singen216"]
[OnName num="shingen"]
我说："这有什么好高兴的？我们应该是敌人。
[cpg cn=true]


信玄大人说得很有道理。信玄大人可能真的知道这一切。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『山道』（夜）******************************************************

我在信玄大人的地方和谦信大人的地方之间来回走动。
[cpg]

我对自己在为谁工作变得越来越模糊。
[cpg]

我是两个本质上是敌人的人的中间人。这种事情是......
[cpg]

在过去的历史中，可能是由妇女完成的。
[cpg]

如果军阀是男人，也许约束他们是女人的职责。
[cpg]

而我现在代祷的两个人是女性。作为一个男人，我的角色是要约束他们吗？
[cpg]

在思考这个问题的同时，我出发去了谦信大人的地方。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（昼）******************************************************

信玄大人可能是对的。我一定是变了。
[cpg]

更确切地说，与现在的我相比，我已经改变了很多。
[cpg]

与这些妇女见面，锻炼了我的身心。
[cpg]

我可能已经变得或多或少有点男人味了。我可能是多么的过度自信。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se025]
;//【ＳＥ】『ふすま開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

过了很久，我回到谦信大人那里时，她的肚子已经肿了起来。
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Kensin338"]
[OnName num="kenshin"]
这是一个和你在一起的孩子。你应该给它命名。
[cpg cn=true]


[OnName num="keitarou"]
你为什么不给它起个名字呢，谦信大人？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Kensin339"]
[OnName num="kenshin"]
这很好。没有你，我就不会有孩子。
[cpg cn=true]


[OnName num="keitarou"]
这对我来说也是一样。如果没有你，就不可能有这样的结果。
[cpg cn=true]


多么重复的论调啊！然而，谦信大人决定为他们命名。
[cpg]


[window target=false]
[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

可爱的时间慢慢过去。
[cpg]

我无法相信......，谦信大人肚子里的孩子是谁。
[cpg]

所有接近她的诸侯都知道，我可以告诉他们。
[cpg]

这就是为什么我和谦信大人正式成为夫妻。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

而谦信大人和信玄大人也不再有大的冲突。
[cpg]

当然，我们并没有和解。谦信大人明白这一点。
[cpg]

他可能不会这样做，因为他想的是我。
[cpg]

我不知道他有多相信我来自未来，但我不知道他有多相信。......。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Kensin340"]
[OnName num="kenshin"]
'你是来自未来。多远的未来？"
[cpg cn=true]


[OnName num="keitarou"]
'非常之远。你一定是在五百年后。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Kensin341"]
[OnName num="kenshin"]
'我明白了。这一定是个好时机。
[cpg cn=true]


[OnName num="keitarou"]
是的。是的，这是一个和平的时代，容易生活，没有冲突。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Kensin342"]
[OnName num="kenshin"]
你认为你愿意回来吗，景太郎先生？
[cpg cn=true]


...... 我记得我听到这个消息的时候。
[cpg]

我第一次来到这个时代，就听到了这个传说。
[cpg]

我听说军阀和我生的孩子可能有神奇的力量。
[cpg]

命运的时刻正在来临吗？如果是这样，我就得为之负责。
[cpg]


;//ブラックアウト

她的肚子随着时间的推移而长大。
[cpg]

我的第一个目的是回到今天，或者在这个时代为自己创造一个位置。......
[cpg]

现在说实话，我很高兴能有一个孩子。
[cpg]


;//移植前シーンカット

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

那天晚上我们睡在一起。
[cpg]

这段相处的时间是最可爱的事情。
[cpg]

迟早有一天，我们会有三个人。我们的孩子要出生了。......
[cpg]

这确实是难以想象的，但我们想看看等待我们的是什么样的未来。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************

信玄大人和谦信大人之间的战斗还未结束。
[cpg]

我确信这将永远不会被解决。
[cpg]

[OnName num="keitarou"]
...... 那些穿着外国袍子的人。
[cpg cn=true]


[OnName num="keitarou"]
'以公主战神的纽带，我将给你一个吃天的儿子。......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Kensin391"]
[OnName num="kenshin"]
怎么了？　它是什么？
[cpg cn=true]


[OnName num="keitarou"]
你没听说过吗，谦信大人？　这是我来到这个时代的第一个村庄的一个传统。
[cpg cn=true]


[OnName num="keitarou"]
我的孩子和谦信大人的孩子可能有超越时间的力量。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Kensin392"]
[OnName num="kenshin"]
既然你提到了，......，你想念你的祖国吗？
[cpg cn=true]


[OnName num="keitarou"]
没有。不，恰恰相反。即使我可以回到未来，我也不会回去。
[cpg cn=true]


[OnName num="keitarou"]
'我想和谦信大人一起生活。我想把它全部看完。"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Kensin393"]
[OnName num="kenshin"]
'谢谢你，.......我们的孩子会很高兴'。
[cpg cn=true]


谦信女士的脸上露出了平和的表情。
[cpg]

她正在成为一个母亲，而我正在成为一个父亲。我们的思维方式正在发生变化，这并不令人惊讶。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

几天的通行证。她的肚子越长越大。
[cpg]

我不再回到信玄大人身边了。
[cpg]

我想她一定意识到了真相。
[cpg]

我一直打算留在谦信大人的身边。
[cpg]

[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Kensin394"]
[OnName num="kenshin"]
'景太郎先生。看看它已经变得多么肿大了。
[cpg cn=true]


[OnName num="keitarou"]
'是的，我明白了。我想知道女性的身体。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Kensin395"]
[OnName num="kenshin"]
我不是一个陌生人。很快你也将成为一名父亲。
[cpg cn=true]


;//移植前シーンカット

我想到的第一件事是，这段爱情是从一个非常奇怪的地方开始的。
[cpg]

虽然我们一直是敌人，但我和谦信大人却奇怪地被对方吸引。
[cpg]

我可能因此而被召唤到这个时代，以便我们在这场战斗中都不会被打败。
[cpg]

[OnName num="keitarou"]
'我希望这种和平将永远持续下去。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Kensin421"]
[OnName num="kenshin"]
'与其说是和平，......，还不如说是没有冲突。
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
说完这句话后，谦信大人立即把头转了下来。
[cpg]

[OnName num="keitarou"]
'...... 谦信大人?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Kensin422"]
[OnName num="kenshin"]
'我刚刚有了一个胎动。我肚子里的孩子似乎在告诉我，它也是。
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

又过了几个月，谦信大人和我生了一个孩子。
[cpg]

听说母亲和孩子都很安全，我松了一口气。
[cpg]

我......，不会再回到现在了。我已经决定永远留在这里。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿外観＿謙信』（昼）******************************************************

我不知道我们的孩子是否有任何神奇的力量。
[cpg]

但现在这并不重要。
[cpg]

我可能是为了见谦信大人而来到这个时间段。
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ非エロ（座って、子供をあやすヒロイン。隣に主人公がいる）ev_63
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿縁側の通路
;//時間　：昼
;//備考　：子供は一歳に満たない赤ん坊です
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_63_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Kensin423"]
[OnName num="kenshin"]
'好吧，...... 唷，你看起来有点像景太郎先生。
[cpg cn=true]


[OnName num="keitarou"]
'我有吗？　'我觉得我看起来像谦信大人。
[cpg cn=true]


;//＠
;//[VOICE f="Kensin424"]
;//[OnName num="kenshin"]
;//「その、謙信様というのはやめてくれませんか？　もう夫婦だというのに」
;//[cpg cn=true]

也许是因为我称他们为 "大人"，尽管他们现在是夫妻，但谦信大人的心情似乎有点不好。
[cpg]

;//＠
;//[OnName num="keitarou"]
;//「確かにそうですが……慣れてしまって」
;//[cpg cn=true]

[OnName num="keitarou"]
'......，我很抱歉，......，我已经习惯了。
[cpg cn=true]



[VOICE f="Kensin425"]
[OnName num="kenshin"]
'已经。景太郎。
[cpg cn=true]


[OnName num="keitarou"]
'谦信......-大人。
[cpg cn=true]



[VOICE f="Kensin426"]
[OnName num="kenshin"]
'......，这将需要一些时间来解决。
[cpg cn=true]


谦信大人在笑。'我不是真的生气。
[cpg]


[VOICE f="Kensin427"]
[OnName num="kenshin"]
'这很好，很安静。不久前，因为与信玄的战斗，城堡里的气氛很紧张'。
[cpg cn=true]



[VOICE f="Kensin428"]
[OnName num="kenshin"]
'不,......，即使再发生冲突，与景太郎，......。
[cpg cn=true]


我们在未来可能会继续遇到困难。
[cpg]

但我确信已经没有什么可担心的了。
[cpg]


;//ブラックアウト

;//ＥＮＤ　ヒロイン３ルート

[SCENE id=12]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="epend.ks" target="*start"]


;//==============================

