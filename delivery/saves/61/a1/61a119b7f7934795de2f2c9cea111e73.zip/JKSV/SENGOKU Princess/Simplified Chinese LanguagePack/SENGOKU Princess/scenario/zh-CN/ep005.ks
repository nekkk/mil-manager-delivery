
*start

;//==============================
;//桶狭間の戦い　二度伏兵のマスを通った場合

*select03_lose|奥克哈扎马之战

*root_4|即使你知道这是一种背叛。

;#################################################
*Ep005|即使你知道这是一种背叛。
;#################################################

[SCENE id=5]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我离开战场的部分原因是光秀大人让我这样做。
[cpg]

最后，我没能看到做出决定的那一刻，但......
[cpg]

有人告诉我，信长大人已经赢得了奥克哈扎马。
[cpg]

我再次想起了她的才华。即使我原来不在那里，也可能是一样的。
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

信长大人取得了胜利，但心情不是很好。
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="3/3" time=800]

[VOICE f="Ranmaru450"]
[OnName num="ranmaru"]
'这是个很好的计划。我只能说，它是......，才会有如此好的效果。"
[cpg cn=true]


[OnName num="keitarou"]
我......，无法战斗到最后。我很抱歉。"
[cpg cn=true]


我不得不诚实地表示歉意。当然，我应该站在战场上。
[cpg]



;//このセリフは削除
;//信長「私は不本意だ。景太郎が参戦しなかったからな」


我现在的处境是，我只是被保住了性命。
[cpg]

[FACE method="change_1" pos="1/3"]

[VOICE f="Mituhide058"]
[OnName num="mitsuhide"]
'好吧，景太郎，让我们让你学习一下政治。
[cpg cn=true]


[FACE method="change_6" pos="1/3"]

[VOICE f="Mituhide059"]
[OnName num="mitsuhide"]
这也是报答的一种方式。
[cpg cn=true]


光秀大人跟进了。他在为我着想。......
[cpg]

或者说，光秀大人认为他比信长大人更听我的话。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

[OnName num="keitarou"]
'谢谢你.......因为给了我一个援助之手'。
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide060"]
[OnName num="mitsuhide"]
'不，不，不要担心这么多。
[cpg cn=true]


与信长大人相比，光秀大人的心情很好。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide061"]
[OnName num="mitsuhide"]
我很高兴你对我比对信长大人更有吸引力。
[cpg cn=true]


毕竟，这就是事情的真相。看来，光秀大人是在看我是否会强迫自己去做这件事。
[cpg]

当然，我也有一部分人想跟着光秀大人，......。
[cpg]

[OnName num="keitarou"]
'...... 真心的，还有一种感觉是我不敢再打了。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide062"]
[OnName num="mitsuhide"]
'什么都可以。对我来说，你是一个重要的人。我不想失去你。"
[cpg cn=true]


说这话时，光秀大人拉着我的手。他转向我。......
[cpg]

不知道这意味着什么，我把目光移开。
[cpg]

不，我真的知道。光秀大人也关心我。
[cpg]

这一次是以听从光秀大人的形式。它是......
[cpg]


这可能意味着光秀大人比信长大人更重要。
[cpg]

[OnName num="keitarou"]
'别这么盯着我。
[cpg cn=true]


光秀大人听到我的话，没有放开我的手。
[cpg]

[FACE method="shake_2" pos="2/3"]

谈到这个问题，我想说的是："我想说的是：'我是一个人，我是一个人，我是一个人，我是一个人，我是一个人，我是一个人，我是一个人，我是一个人'。
[cpg]


;//ブラックアウト

[SE f=se000]
;//【ＳＥ】『通路歩く』

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

然后光秀先生拉着我的手，把我带到他的房间。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_09"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide063"]
[OnName num="mitsuhide"]
'景太郎先生。信长大人很喜欢你，对吗？
[cpg cn=true]


[OnName num="keitarou"]
是的，是的。...... 好吧。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide064"]
[OnName num="mitsuhide"]
不是说这是原因。......
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

她说，把她的嘴唇放在我的嘴唇上，同时握住我的手。
[cpg]

我很惊讶，拉开了距离。
[cpg]

[OnName num="keitarou"]
'你想做什么？
[cpg cn=true]


光秀大人在向我示好。她是想把我这个受信长大人宠爱的人抓在手里吗？
[cpg]

首先要做的是射杀马匹。......。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide065"]
[OnName num="mitsuhide"]
'你不逃开我，反而把我推开。
[cpg cn=true]


[OnName num="keitarou"]
......，这是......."
[cpg cn=true]


我对自己的决定并不完全满意。在某种程度上，我没有去参加战斗，回想着光秀大人的话。
[cpg]


;//ブラックアウト

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide066"]
[OnName num="mitsuhide"]
信长大人不会做这样的事情。
[cpg cn=true]


[OnName num="keitarou"]
'这当然是，......
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide067"]
[OnName num="mitsuhide"]
'我相信他会的。我愿意为他做任何事。
[cpg cn=true]



;//移植前シーンカット

我坚持着这种不会消退的感觉，并决定请她离开。
[cpg]

不出所料，这段关系突然变得太短。
[cpg]

[OnName num="keitarou"]
'......，你应该更好地照顾自己。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide094"]
[OnName num="mitsuhide"]
'我正在努力，你知道。好吧，如果你不喜欢，我会改变它的。
[cpg cn=true]



[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

又是一天。我看到光秀先生正在照料他的盆景。
[cpg]

[OnName num="keitarou"]
'你非常热心。盆景真的那么有趣吗？
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide095"]
[OnName num="mitsuhide"]
'是的。对我来说，它似乎代表了世界的兴衰。
[cpg cn=true]


世界的兴衰。她似乎看到了这样的事情。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Mituhide096"]
[OnName num="mitsuhide"]
...... 你怎么看？　你认为信长大人会继续统治吗？"
[cpg cn=true]


光秀大人在照料盆景树时问道。
[cpg]

[OnName num="keitarou"]
是的。
[cpg cn=true]


我回答说，但我知道光秀大人会背叛我。
[cpg]

唯一知道一切的人是我和试图发动叛乱的光秀大人。
[cpg]

当我这样想的时候，光秀大人一环顾四周。在确认没有人之后。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide097"]
[OnName num="mitsuhide"]
'我对这一点多少有些了解。你知道我正在试图发动一场叛乱。
[cpg cn=true]


他告诉了我一切。
[cpg]

[OnName num="keitarou"]
这是......"
[cpg cn=true]


我退缩了，但我无法否认。
[cpg]

我什么都说不出来。我甚至不知道如何正确回答。
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Mituhide098"]
[OnName num="mitsuhide"]
我不知道你从哪里来。而且你对我的警惕性异常高。
[cpg cn=true]



;//下記のセリフ、台本では
;//「何か、魔法めいた力で、景太郎さんは未来を知っているようだ。違いますか」
;//となっていますが、下記の通りになるようにセリフをカットしてください
;//不可能であれば、元のセリフのままにしてください

[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide099"]
[OnName num="mitsuhide"]
'你似乎知道未来，景太郎先生。不是吗？
[cpg cn=true]


你几乎是对的。和信长大人一样，他也相当敏锐。
[cpg]

兰丸大人甚至直到这里才意识到。......
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide100"]
[OnName num="mitsuhide"]
'然而，他仍然不告诉我。在那里，他闻起来就像我。"
[cpg cn=true]


他触及了我的真实感受。
[cpg]

我当然不能说光秀大人会背叛我。
[cpg]

如果我这样做了，光秀大人就会被处决。我担心，如果有任何证据被发现。
[cpg]

[OnName num="keitarou"]
'...... 你在多大程度上看透了这一点？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide101"]
[OnName num="mitsuhide"]
'没有达到信长大人的要求，但大部分是这样。但如果是真的，我就会更喜欢你。
[cpg cn=true]


我没有反驳什么。我确实很关心光秀大人。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide102"]
[OnName num="mitsuhide"]
'我认为我真的很不周到。但有你在我身边，我可以做任何事。
[cpg cn=true]


光秀大人停止照料盆景，拉着我的手。
[cpg]

令人印象深刻的是，他的手在颤抖。
[cpg]

他突然显示出他的弱点。他似乎对违抗信长大人感到恐惧。
[cpg]

[OnName num="keitarou"]
'光秀大人......'
[cpg cn=true]


这就是光秀大人的工作。这可能都是一种行为。
[cpg]

;//＠それでもこのままでは折れてしまいそうな光秀様を見て、俺は心を動かされた。
即便如此，看到看起来像要崩溃的光秀先生这样，我的心也被感动了。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************


;//☆
;//[VOICE f="sMitsuhide001"]
;//[OnName num="mitsuhide"]
;//「……景太郎さん。私は貴方のことを、好きなのだと思います」
;//[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
我告诉光秀大人，我真的很喜欢他。
[cpg]

他说了这么多。光秀大人看起来很严肃。
[cpg]

[OnName num="keitarou"]
'你不应该随便说这种话。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide104"]
[OnName num="mitsuhide"]
'这听起来像我说得很轻巧吗？　我会说多少次，直到它听起来很严肃'。
[cpg cn=true]


[OnName num="keitarou"]
'......'
[cpg cn=true]


光秀大人走到我耳边，低声说。我对此的感觉很复杂。
[cpg]


;//移植前シーンカット

并不是说我对光秀大人没有任何感情。当然那是事实。
[cpg]

相反，它只是爱。但即便如此，我仍然对...... 信长大人心怀感激。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Mituhide129"]
[OnName num="mitsuhide"]
有什么不对吗？　景太郎先生，你看起来好像很痛苦的样子。
[cpg cn=true]


[OnName num="keitarou"]
编号：......
[cpg cn=true]


此外，光秀大人知道他将与秀吉作战，而且会输。
[cpg]

无论你选择谁，信长大人还是光秀大人，你们都不可能一起度过余生。
[cpg]

即使我感到无常，我......
[cpg]

[OnName num="keitarou"]
光秀大人。我也爱你。"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

我选择了光秀大人。她有点惊讶，然后看起来很高兴。
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide130"]
[OnName num="mitsuhide"]
'是的。谢谢你。"
[cpg cn=true]



;//移植前シーンカット

我觉得光秀大人是想用这种爱来支配我。
[cpg]

我不认为如果我对她有完全的感情，就不会发生这种情况。
[cpg]

这就是我对她的迷恋。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide152"]
[OnName num="mitsuhide"]
'我爱你，...... 景太郎先生。我们将永远在一起'。
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


她把目光投向了被信长大人看中的我。
[cpg]

有可能所有这些都是计算的结果。
[cpg]

但知道这一点后，我无法远离她。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

最后，我也会成为一个叛徒吗？
[cpg]

只要我不能阻止光秀大人，就可以说我同样有罪。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Ranmaru451"]
[OnName num="ranmaru"]
...... 景太郎，嗯？你看起来不怎么好。
[cpg cn=true]


[OnName num="keitarou"]
兰丸大人，......，这没什么。
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Ranmaru452"]
[OnName num="ranmaru"]
我希望如此。你和光秀最近花了很多时间在一起。
[cpg cn=true]


......，没事的。我相信兰丸大人没有注意到。
[cpg]

[OnName num="keitarou"]
'这有什么问题吗？
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru453"]
[OnName num="ranmaru"]
不，不，这没什么。我只是想，"你怎么能和这样的人约会？"
[cpg cn=true]


[OnName num="keitarou"]
光秀大人看起来像吗？
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Ranmaru454"]
[OnName num="ranmaru"]
他笑得很开心，但看起来并不像真的在笑。
[cpg cn=true]


在我看来是这样的。我知道这一切的真相，我也在一定程度上知道光秀大人的想法。......
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『街』（夕方）******************************************************

傍晚时分的城堡小镇。我是被信长大人带到这里的。
[cpg]


;//下記のセリフ、台本では「街」ですがシナリオでは「町」になっています

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga670"]
[OnName num="nobunaga"]
'看一看。我从未见过如此平静的城镇。
[cpg cn=true]


[OnName num="keitarou"]
'我肯定你有。当信长大人出生时，战争可能已经开始了。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga671"]
[OnName num="nobunaga"]
是的，但它即将结束。但这即将结束。
[cpg cn=true]


信长大人似乎并不怀疑这一点。
[cpg]

事实上，还有一次动乱。事实上，信长大人还有一波动乱要参与其中。
[cpg]

我只是不能让自己说出来。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我回到我的房间，试图休息，但我的情绪有些不稳定。
[cpg]

光秀大人和我以后想做什么？
[cpg]

即使是她也应该活不长。跟随她真的可以吗？
[cpg]

另一方面，她可能会在本能寺事件后采取行动接管国家。
[cpg]

我不能阻止她这样做。当我在想，。
[cpg]


[VOICE f="Mituhide153"]
[OnName num="mitsuhide"]
'景太郎先生。是我。"
[cpg cn=true]


[OnName num="keitarou"]
啊，请进来......."
[cpg cn=true]



[SE f=se025]
;//【ＳＥ】『ふすま開く』


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]


光秀大人已经到了。
[cpg]

[OnName num="keitarou"]
'你睡不着吗？
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide154"]
[OnName num="mitsuhide"]
'我不禁想到了未来。但我认为我可以和你一起做。
[cpg cn=true]


当然，这一点是毫无疑问的。我将站在光秀大人这一边。
[cpg]

但你无法改变你的命运。光秀大人不能打倒天堂......
[cpg]

那么我们就只有一个办法来获得幸福。
[cpg]

背叛信长大人。这是现在唯一的办法，因为我们无法通过任何方式改变未来。
[cpg]

在此基础上，我们不能试图接管国家。否则，光秀大人就会死。
[cpg]

[OnName num="keitarou"]
'......'
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide155"]
[OnName num="mitsuhide"]
'你在想什么。现在，你不需要考虑其他的事情'。
[cpg cn=true]


光秀大人这样说，但我的心情很复杂。
[cpg]

最终，我需要告诉他我们获得幸福的唯一途径。但是。
[cpg]

出卖了信长大人，我还能说服她吗？
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide156"]
[OnName num="mitsuhide"]
'景太郎先生。看着我。
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

光秀大人这样说，并走近我。然后他吻了我。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide157"]
[OnName num="mitsuhide"]
'...... 未来，你知道。即使是我也不能平静地对待它。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide158"]
[OnName num="mitsuhide"]
但我仍然很高兴能和你在一起。
[cpg cn=true]


;//移植前シーンカット

我被她迷住了。这一点是毫无疑问的。
[cpg]

光秀大人说他喜欢我，但我认为他真的有点强人所难。
[cpg]

她甚至想用爱来维系我。
[cpg]

知道了这一点，我就无法甩掉她。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

随着时间的推移，我从信长大人的诸侯那里学到了越来越多的政治知识。
[cpg]

信长大人可能认为，一个和平的世界即将到来。
[cpg]

事实上，如果她掌握了缰绳，并保持这种方式，甚至有可能。......
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

最终，信长大人统一了全国。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="3/3" time=800]


[VOICE f="Nobunaga672"]
[OnName num="nobunaga"]
'......，到目前为止已经过了很长时间，不是吗？
[cpg cn=true]


[FACE method="bow_2" pos="3/3"]

[VOICE f="Ranmaru455"]
[OnName num="ranmaru"]
是的，它有。但你终于实现了你的愿望，不是吗？
[cpg cn=true]


信长大人看了看光秀大人。光秀大人仍然微笑着。
[cpg]

[FACE method="bow_2" pos="1/3"]

[VOICE f="Mituhide181"]
[OnName num="mitsuhide"]
我很高兴能成为你的附庸。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga673"]
[OnName num="nobunaga"]
我明白了。我也很高兴能有一个优秀的臣子。
[cpg cn=true]


信长大人在笑，但我不知道他是不是真的在笑。
[cpg]

我也在思考如何坚持自己的立场。
[cpg]

如果我和光秀大人一起生活，我会走什么路？
[cpg]

我至少会背叛信长大人和兰丸大人。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga674"]
[OnName num="nobunaga"]
'景太郎似乎并不......，太高兴了。
[cpg cn=true]


[OnName num="keitarou"]
'不。我很高兴'。
[cpg cn=true]


难怪他能在这里看穿我。我会做一个假笑，但我肯定他能看穿我。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

最近，光秀大人甚至想和我生个孩子。
[cpg]

如果我从现在开始要发动叛乱，我就不希望肚子里有孩子。......。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Mituhide182"]
[OnName num="mitsuhide"]
'从现在起，我将无法安静地生活。我想在我还可以的时候和你生个孩子。"
[cpg cn=true]


[OnName num="keitarou"]
'......，我明白了。
[cpg cn=true]


她要做什么？她对自己的生命有任何怀疑吗？
[cpg]

我不能把一切都告诉她。我的心情很复杂。
[cpg]


;//移植前シーンカット

尽管她生性冷漠，但对我却表现出毫不吝啬的感情。
[cpg]

我不知道她的真实感情在哪里。我想这是因为信长大人在某种程度上信任我。
[cpg]

我理解想把我留在她身边的心理。这也可能会让人更容易开始叛乱。但......
[cpg]

我不知道她现在的行为是否真的有这样的计算。
[cpg]

[OnName num="keitarou"]
'...... 光秀大人。你真的要背叛信长大人吗？
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]

[VOICE f="Mituhide204"]
[OnName num="mitsuhide"]
'是的。怎么了？"
[cpg cn=true]


光秀大人毫不犹豫地这样说。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Mituhide205"]
[OnName num="mitsuhide"]
我将让兰丸也死去。让她活着是不安全的。
[cpg cn=true]


他从未在信长大人和其他人面前表现出这种可怕的本性。
[cpg]

本野寺事件即将发生。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Mituhide206"]
[OnName num="mitsuhide"]
'......，我真的不想背叛她。
[cpg cn=true]


是的，她是。为什么她一开始就想背叛我们？
[cpg]

[OnName num="keitarou"]
光秀大人，你是......，想自己接管国家？
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Mituhide207"]
[OnName num="mitsuhide"]
'不。我的真正目的是恢复幕府。我不寻求上升到顶峰。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide208"]
[OnName num="mitsuhide"]
你知道我曾经为足利义昭大人服务吗？
[cpg cn=true]


[OnName num="keitarou"]
不，......，我从未听说过你。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Mituhide209"]
[OnName num="mitsuhide"]
義昭大人下了命令，这整个事情。
[cpg cn=true]


这是否意味着对光秀大人来说，他是比信长大人更值得追随的人？
[cpg]

然而，我无话可说。
[cpg]

我并不关心原因。难道是她对足利义昭这个人的崇拜超过了信长大人？
[cpg]

还是她认为信长大人的统治不能像现在这样继续下去？
[cpg]

现在这已经无关紧要了。无论叛乱者有什么意图，都是一样的。
[cpg]

我不能说什么，因为害怕改变未来。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

不管是光秀大人的意愿改变，还是我说服他，未来最终都会被改变的。
[cpg]

无论他想做什么样的思考，都是一样的。
[cpg]

信长大人注定会死。兰丸大人也是如此。......
[cpg]

当你改变这一点时，可能会是一个我没有出生的未来。
[cpg]

对我的家人和其他人也是如此。我必须千方百计地避免这种情况。
[cpg]

所以我没有选择，只能保持沉默。
[cpg]

如果有什么是我可以改变的，那就是关于光秀先生的未来。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide210"]
[OnName num="mitsuhide"]
这是个美好的夜晚，不是吗？它很安静。"
[cpg cn=true]


[OnName num="keitarou"]
'...... 是的。
[cpg cn=true]



;//ブラックアウト

她没有说一句话，而是慢慢向我靠近。
[cpg]


;//========================================
;//●ＣＧ（主人公の体に手を突いているヒロイン）ev_34
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿縁側の通路
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



我也没有拒绝她。
[cpg]


[VOICE f="Mituhide211"]
[OnName num="mitsuhide"]
我从来没有真正平静过。
[cpg cn=true]



[VOICE f="Mituhide212"]
[OnName num="mitsuhide"]
无论信长大人如何赞美我，无论我为他做了多少事，我都感到空虚。
[cpg cn=true]


[OnName num="keitarou"]
我相信这是真的。
[cpg cn=true]



[VOICE f="Mituhide213"]
[OnName num="mitsuhide"]
另一方面，你知道我的真实本性，但不知为何你一直保持沉默。
[cpg cn=true]



[VOICE f="Mituhide214"]
[OnName num="mitsuhide"]
没有人比你更支持我了。
[cpg cn=true]


她无所畏惧，或者说，她毫不犹豫地在我面前谈论背叛信长大人的事。
[cpg]

也许她真的想被关注。
[cpg]

也许她希望有人能阻止她。
[cpg]

但我无法判断她的真实想法，因为它被隐藏在几层掩饰之下。
[cpg]

[OnName num="keitarou"]
光秀大人。我还是不知道你在想什么。
[cpg cn=true]


;**【ＣＧ】 ev_34_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Mituhide238"]
[OnName num="mitsuhide"]
'我肯定你不知道。我不认为你能找到我自己即将失去视力的东西'。
[cpg cn=true]


我相信，......，她有太多复杂的情况。
[cpg]

而光秀先生很聪明，把它们全部重叠起来，使它们加起来。
[cpg]

我以为这是她用头脑而不是用心灵行事的结果。
[cpg]

只要她能再一次找回自己的心，......
[cpg]

我想知道我在那里灰心丧气会是什么样子。
[cpg]


;//移植前シーンカット

;//ブラックアウト

;//qwe

[window target=false]
[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

[OnName num="keitarou"]
'......，我也开始失去......，不知道自己想做什么。
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide239"]
[OnName num="mitsuhide"]
'这是不可能的，是吗？这是不可能的。只是活在当下。
[cpg cn=true]



;//移植前シーンカット

;//ブラックアウト

;//移植前シーンカット

这是我最后一次能够平静地与她做爱。命运的时刻已经来临了。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

这是我最后一次见到信长大人和兰丸大人。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Nobunaga675"]
[OnName num="nobunaga"]
'...... 怎么了？你似乎比平时更阴沉。"
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


我甚至不能回答说这没什么。
[cpg]

我不能在这里透露一切。
[cpg]

[FACE method="shake_7" pos="4/5"]

[VOICE f="Ranmaru456"]
[OnName num="ranmaru"]
'别担心。信长大人，我们走吧。"
[cpg cn=true]


兰丸大人今天似乎是兰丸大人。与信长大人和光秀大人相比，他很沉闷。
[cpg]

但这是我们最后一次看到她这样的情况。
[cpg]

[FACE method="bow_1" pos="2/5"]

[VOICE f="Nobunaga676"]
[OnName num="nobunaga"]
景太郎。我不知道你发生了什么，但要振作起来。
[cpg cn=true]


我甚至无法回答这些话。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


那是一个糟糕的夜晚。我感觉我被吸进了黑暗中。
[cpg]

我所能做的就是什么都不做，但由于什么都不做，就好像我被困住了。
[cpg]


[VOICE f="Mituhide285"]
[OnName num="mitsuhide"]
'......，现在我们将能够重新建立幕府。
[cpg cn=true]


本能寺正在烧红。我让信长大人和兰丸大人去死。
[cpg]

尽管感到内疚，但我也不明白自己的真实意图。
[cpg]

除了光秀大人，没有其他人了。我认为除了和她在一起，没有其他办法。
[cpg]

但......，这条路也不容易。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

一夜之后，光秀大人身边只有她的盟友。
[cpg]

自然是这样。如果有任何人哪怕是对信长大人稍有忠诚，她就会有危险。
[cpg]

[OnName num="keitarou"]
'......，它非常小心，不是吗？你是否想到了一切，包括你将如何表现？
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide286"]
[OnName num="mitsuhide"]
我想一旦我决定做这样的事情，我就会很快从那里开始。我不认为我是彻底的。
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Mituhide287"]
[OnName num="mitsuhide"]
我只是......，不知道我是否是决定自己要做什么的人了。
[cpg cn=true]


光秀大人一定经历了很多冲突。
[cpg]

他们正在研究我根本无法想象的想法。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide288"]
[OnName num="mitsuhide"]
'...... 更多的是，我有好消息要告诉你。我前几天看了一个医生。......"
[cpg cn=true]


光秀大人揉着我的肚子，告诉我我有了孩子。
[cpg]

我对此并不完全满意。我知道将要发生什么。
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

从那里，其他的将军们开始行动，包围光秀大人。
[cpg]

按照这种速度，光秀先生再次被杀只是时间问题。
[cpg]

但至少这是我所知道的历史事实。
[cpg]

这很奇怪，我觉得还有一些时间可以利用。
[cpg]

通常情况下，光秀大人不会被当作曾经夺取过国家的人对待。
[cpg]

她在叛乱中幸存下来的时间应该是那么短。
[cpg]

正如我所想的那样，这与我所知道的历史有一点不同。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

光秀大人的肚子正在扩大。自从她生下这个孩子以来，大约四个月过去了。
[cpg]

我还活着，她也还活着。我不知道我还剩下多少时间。
[cpg]

我想知道光秀大人现在在想什么。
[cpg]

我确信他知道我的心态，但最可怕的一定是光秀先生本人。
[cpg]


;//ブラックアウト

[window target=false]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我仍然有复杂的感觉。
[cpg]

爱上杀死信长大人和兰丸大人的她是正确的吗？
[cpg]

而从现在开始，连她自己也不会安全了。
[cpg]

[OnName num="keitarou"]
'......，也许我应该把一切都告诉光秀大人。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Mituhide293"]
[OnName num="mitsuhide"]
'是的，这就对了。我很高兴你愿意向我透露，因为看来你对我还有一些秘密。
[cpg cn=true]


我知道我不想失去她。为此，我只能做一件事。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Mituhide317"]
[OnName num="mitsuhide"]
我想我将会遇到秀吉。而且也是在不远的将来。
[cpg cn=true]


[OnName num="keitarou"]
'......，我明白了。
[cpg cn=true]


也许她会死在那里。
[cpg]

我知道这不应该被接受......，但这是历史事实。
[cpg]

我想知道我被允许透露多少信息。
[cpg]

信长大人说他不想知道未来的事情，但是光秀大人呢？
[cpg]

如果他知道自己会死，他可能会努力避免。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夕方）******************************************************

我感到很不安。我很烦恼，但答案必须尽快到来。
[cpg]

没有人可以咨询。信长大人和兰丸大人已经不在这个世界上了。
[cpg]

是光秀大人杀了他们。这是令人难以置信的。
[cpg]

如果你不背叛，你就会被背叛，如果你不杀，你就会被杀。我知道是这样一个时代。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[window target=true]


...... 而我做了一个决定。
[cpg]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide318"]
[OnName num="mitsuhide"]
它是什么？你想和我谈谈吗？"
[cpg cn=true]


[OnName num="keitarou"]
'是的，......，我想告诉你我知道的一切。
[cpg cn=true]


光秀大人的确是认真的。他可能认为他终于可以从我这里听到真相了。
[cpg]

[OnName num="keitarou"]
'我来自未来。你不会相信的，但这是真的'。
[cpg cn=true]


[OnName num="keitarou"]
而且也不是由我来以任何重大方式改变未来。
[cpg cn=true]


事实上，我已经搬到了未来，以至于我从未改变过它。
[cpg]

[FACE method="bow_7" pos="2/3"]

[VOICE f="Mituhide319"]
[OnName num="mitsuhide"]
'......，这很难让人相信，但这样一来，你知道我要背叛你，并对此保持沉默也就说得通了。
[cpg cn=true]


光秀大人似乎很满意。我继续说。
[cpg]

[OnName num="keitarou"]
如果这种情况继续下去，光秀大人就会被秀吉打败。难道你现在也不打算逃跑吗？"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide320"]
[OnName num="mitsuhide"]
不，我不知道。但如果我将来赢了，你就会有麻烦了。
[cpg cn=true]


这当然是真的。如果未来发生变化，这可能意味着我将不会出生。
[cpg]

[OnName num="keitarou"]
'如果我不这样做，未来就会改变。也许这将是一个我永远不会出生的世界。"
[cpg cn=true]


我继续往下讲。我不能只是袖手旁观。
[cpg]

[OnName num="keitarou"]
如果要开战，我将不惜一切代价阻止你。
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Mituhide321"]
[OnName num="mitsuhide"]
'......，我明白了。但我只有一件事可以做。
[cpg cn=true]


即便如此，看来光秀大人的意愿并没有改变。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Mituhide322"]
[OnName num="mitsuhide"]
'我们已经牺牲了太多，不能再回头了。我现在不打算把王国交给秀吉。
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我终究还是无法阻止光秀大人吗？
[cpg]

我想知道是否有什么我可以做的。......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

我多次试图劝说光秀大人，并谈了我要做的事。
[cpg]

但光秀大人的决心似乎很坚定。
[cpg]

[OnName num="keitarou"]
'......，你是否要打仗，通过各种方式？
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]

[VOICE f="Mituhide323"]
[OnName num="mitsuhide"]
是的，我就是要这样做。
[cpg cn=true]


;//ブラックアウト

;//移植前シーンカット
[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我直接和她上床了。
[cpg]

剩下的时间已经不多。我压抑着自己的不耐烦，认为我不能让他知道我的真实感受。
[cpg]

真正的感情，换句话说，是让光秀大人逃跑的感情，即使这意味着绑架她。
[cpg]


[window target=false]
[BG f="b_07_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

而在早晨，......，我是第一个醒来的人。
[cpg]


;//ブラックアウト

;//========================================
;//●ＣＧ微エロ（事後。二人で同じ布団に入っている。眠そうにしながら目を覚ますヒロイン）ev_53
;//人物１：ヒロイン４　服装１：裸
;//人物ex：主人公　　　服装ex：裸
;//場所　：城＿室内
;//時間　：朝
;//備考　：ヒロインは妊娠六ヶ月くらいです
;//========================================


[BGM f="bg_09"]
;**【ＣＧ】 ev_53_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Mituhide348"]
[OnName num="mitsuhide"]
...... 早晨？
[cpg cn=true]


[OnName num="keitarou"]
是的。请起身。
[cpg cn=true]


;//＠二人とも、裸のまま眠ってしまっていた。
我们都赤身裸体地睡着了。
[cpg]

这段平静的时间即将被夺走。
[cpg]

这是一种无法抗拒的感觉。我想不惜一切代价保护她。
[cpg]


[VOICE f="Mituhide349"]
[OnName num="mitsuhide"]
'你有一张可怕的脸，不是吗？你有什么心事吗？"
[cpg cn=true]


[OnName num="keitarou"]
'...... 我已经说了我能说的一切。
[cpg cn=true]



[VOICE f="Mituhide350"]
[OnName num="mitsuhide"]
不要担心。我不会输。"
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


我无话可说。
[cpg]

再说什么也没用了。然后......
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

然后，我策划了一下。
[cpg]

有些士兵比光秀大人更愿意跟着我。
[cpg]

即使他们不知道，当我向他们解释整个情况时，他们也会明白.......。
[cpg]

没有人会相信来自未来的如此离奇的事情？
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Mituhide351"]
[OnName num="mitsuhide"]
'...... 你想做什么？
[cpg cn=true]


[OnName num="soldier_A"]
'我很抱歉。现在，请跟随景太郎大人。
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]

[VOICE f="Mituhide352"]
[OnName num="mitsuhide"]
你是什么意思？景太郎先生。
[cpg cn=true]


[OnName num="soldier_B"]
......
[cpg cn=true]


我们有三个人，包括我。这是防止她逃跑所需的最低数量。
[cpg]

[OnName num="keitarou"]
我要离开城堡。我别无选择，只能这样做'。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

我带着光秀大人，从城堡里逃了出来。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Mituhide353"]
[OnName num="mitsuhide"]
我相信这是毫无意义的。一旦我走了，所有人都会注意到，他们会来找我。
[cpg cn=true]


[OnName num="keitarou"]
'...... 尽管如此，我还是不能放弃。我不想放弃你'。
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夕方）******************************************************

我们无法快速行动。毕竟，光秀大人已经怀孕了。
[cpg]

即使你说你要逃跑，他们追上你也只是时间问题。
[cpg]

但是，我仍然不能什么都不做。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Mituhide354"]
[OnName num="mitsuhide"]
如果......，你如此坚持，我可能真的要失去它了!
[cpg cn=true]


[OnName num="keitarou"]
是的，我知道。根据我知道的历史，下一个掌权的人是秀吉。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Mituhide355"]
[OnName num="mitsuhide"]
'但你现在不能逃跑。正如我之前所说，我已经做出了太多的牺牲'。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

[OnName num="mitsuhide_vassal"]
他在那里!　在这里！"
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


逃跑的尝试没有持续一天。他们当晚就追上了我们。
[cpg]

我想我为自己争取了足够的时间，但这个时代的人脚步很快。
[cpg]

我想到了这一点，但我也意识到，我还是不能永远逃避下去。
[cpg]

也许我终究无能为力。
[cpg]

我心中充满了这种无助的感觉。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

我被带到了城堡，当我回来时，已经是早上了。
[cpg]

光秀先生一定知道所有的事情。不过，他还是认为我现在没有办法逃脱。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Mituhide356"]
[OnName num="mitsuhide"]
'不会有下一次了。如果你再做同样的事，我甚至要处决你。
[cpg cn=true]


光秀山将无法离开那些试图与他们的主子一起逃亡的人。
[cpg]

在士兵面前这么说也是对我的一种威慑。
[cpg]

下次他想绑架光秀山时，可能真的打算处决他。
[cpg]

现在我似乎不得不在我的生命和光秀先生的生命之间进行权衡。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

真让人吃惊。我甚至不需要去称量天平。
[cpg]

我的意愿已经决定了。光秀大人的生命比我的要重得多。
[cpg]

从她的臣子的角度来看，会是这样，而从我的角度来看，更是如此。
[cpg]

从她自己的角度来看呢？　我无法想象那么远。......
[cpg]

但我以为这样就万事大吉了。
[cpg]


;//ブラックアウト

当我以为自己会死的时候，我仍然无法停止颤抖。
[cpg]

但我很高兴，我遇到了比自己更重要的东西。
[cpg]

与光秀大人的爱情不是这样的......，别人可以取代。
[cpg]

即使与我自己的生活相比也是如此。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************

[OnName num="keitarou"]
'...... 这种方式。光秀大人。"
[cpg cn=true]


我正准备再次把光秀大人带出去。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Mituhide357"]
[OnName num="mitsuhide"]
'......，你是一个永不改变的人。我知道你不会这么容易就崩溃。
[cpg cn=true]


[OnName num="keitarou"]
'是的。如果你想，你可以杀了我。
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]

[VOICE f="Mituhide358"]
[OnName num="mitsuhide"]
我这样说也不是为了威胁。我这样说也不是为了威胁。
[cpg cn=true]


光秀大人带着痛苦的表情对我说，几乎是流着泪。
[cpg]

[OnName num="keitarou"]
'这并不重要。反正你的附庸会追上你，但我不能忍受失去你而不做点什么。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Mituhide359"]
[OnName num="mitsuhide"]
'......，我明白了。我不想和你说再见。
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我将尝试第二次将光秀大人带走。
[cpg]

这是一份愿意让自己被杀的声明。
[cpg]

第二次也是如此，把光秀带出去，最后也不会成真。我知道。
[cpg]

我将被处决。我也知道这一点。
[cpg]

[OnName num="mitsuhide_vassal"]
你，......，意识到你做了什么吗？
[cpg cn=true]


[OnName num="keitarou"]
我理解。如果你不知道，你就不能做。
[cpg cn=true]


[OnName num="mitsuhide_vassal"]
我会想你的。但现在是不可避免的。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide360"]
[OnName num="mitsuhide"]
这就够了。你不想假装它从未发生过，是吗，景太郎先生？
[cpg cn=true]


[OnName num="keitarou"]
...... 是的。
[cpg cn=true]


我没有逃跑和躲藏。以我的生命作为交换，如果我能够给她带来哪怕是一个小小的消息。
[cpg]

或者，如果它没有到达她那里，如果它不意味着我让她白白死去。
[cpg]

真的，这就是我想要的一切。......
[cpg]


;//背景と別の場所なので、上下に黒帯を入れるなどしてください

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

他们把我带回去，把我关在监狱里。
[cpg]

我被处决的日子就要到了。奇怪的是，我感到很平静。
[cpg]

我再也没有看到光秀先生的脸了。
[cpg]

她可能也很难看到我。这很好。
[cpg]


;//ホワイトアウト
[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1100]

我不害怕任何东西。最可怕的是，我无法下定决心。
[cpg]

我......，这一切都很好。
[cpg]

[window target=false]
[WAIT time=1000]

;//ここから一人称ではなく三人称に変わります
;//文章を画面中央に表示するなどして、雰囲気を変えてください


;//ゆっくりとブラックアウト
[BG f="black.ui" time=1000]
[WAIT time=1000]

[STOPBGM]
[WAIT time=1000]
[window target=true]


....... 之后
[cpg]

景太郎被处决后，光秀有了一个孩子。
[cpg]

尽管在孩子身上看到了景太郎的脸，光秀还是勇敢地战斗。
[cpg]


[VOICE f="Mituhide361"]
[OnName num="mitsuhide"]
'...... 景太郎先生。我也......."
[cpg cn=true]


现在景太郎走了，他毫不犹豫地赢得这场战斗。
[cpg]

他用尽全力与秀吉发生冲突，但光秀被打败了。
[cpg]


[VOICE f="Mituhide362"]
[OnName num="mitsuhide"]
'我，即使是我，也不惧怕任何东西。
[cpg cn=true]


正是因为景太郎不在那里，光秀才能够全力以赴地战斗。
[cpg]

如果他在全力以赴之后不能获胜，光秀也不后悔。
[cpg]


;//ＥＮＤ　ヒロイン４ルート

[SCENE id=11]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="epend.ks" target="*start"]

