
*start

;//==============================
;//稲生の戦いで勝利していた場合

*root_1|天堂下的织田信长

;#################################################
*Ep003|天下的织田信长。
;#################################################

[SCENE id=3]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru091"]
[OnName num="ranmaru"]
'不，这算什么。这种沉默'。
[cpg cn=true]


兰丸大人首先打破了沉默。一种微妙的尴尬气氛在我们之间流动。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru092"]
[OnName num="ranmaru"]
'总之!　我将不惜一切代价支持信长大人'。
[cpg cn=true]


兰丸大人看着远方说。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru093"]
[OnName num="ranmaru"]
但我想说的是，你可以做的不仅仅是支持他们。
[cpg cn=true]


[OnName num="keitarou"]
你是什么意思？"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru094"]
[OnName num="ranmaru"]
'我是说，你也可以成为信长大人的丈夫。这就是他喜欢你的程度。
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru095"]
[OnName num="ranmaru"]
真的，请。你是唯一的一个。我只是自己做不到。"
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

那天晚上，信长大人给我打电话。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga267"]
[OnName num="nobunaga"]
你已经习惯于住在城堡里了，不是吗？
[cpg cn=true]


[OnName num="keitarou"]
是的，好吧，......，我能为你做什么？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga268"]
[OnName num="nobunaga"]
我能为你做什么？我只是想确认一下。
[cpg cn=true]


它是什么？　它是什么？
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru096"]
[OnName num="ranmaru"]
'......，我还想确定一件事。景太郎和信长大人是......，......."
[cpg cn=true]


不仅是信长大人，兰丸大人和光秀大人也在那里。
[cpg]

[FACE method="shake_7" pos="2/5"]

[VOICE f="Mituhide027"]
[OnName num="mitsuhide"]
他说："我不知道，我不知道。"他说："我不知道。"他说："我不知道。"他说："我不知道。兰丸。
[cpg cn=true]


[FACE method="shock_3" pos="4/5"]

[VOICE f="Ranmaru097"]
[OnName num="ranmaru"]
但......，我对它很好奇。
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Mituhide028"]
[OnName num="mitsuhide"]
'景太郎先生不属于任何人。不是吗？"
[cpg cn=true]


说这话的时候，光秀大人就是光秀大人，我觉得他想独占我。
[cpg]

 兰丸大人对我想不出什么办法。
[cpg]

这就像一个后宫的情况。从幕后来看，这可能是他在控制整个国家。......
[cpg]

[free time=1]
[WAIT time=1]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Nobunaga269"]
[OnName num="nobunaga"]
'呼'。
[cpg cn=true]


信长大人随后做了一些非常不重要的小谈话。
[cpg]

她想确保，我猜，我被所有人喜欢。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_04"]


;//【ＢＧ】『城＿室内』（夜）******************************************************

然后我回到了我的房间。我想到了与信长大人的未来。
[cpg]

兰丸大人认可我。这就是为什么我不需要犹豫了。
[cpg]

自从兰丸大人告诉我之后，我就意识到了成为信长大人丈夫的梦想。
[cpg]

然而，信长大人最终会在本能寺事件中死去。
[cpg]

我必须不惜一切代价避免这种情况。我想和信长大人一起生活。
[cpg]

无眠之夜。我的房间被......
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga270"]
[OnName num="nobunaga"]
'景太郎。你已经睡着了吗？"
[cpg cn=true]


[OnName num="keitarou"]
...... 号。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga271"]
[OnName num="nobunaga"]
'哦，是的。从那时起，我一直在思考你的意思......。
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Nobunaga272"]
[OnName num="nobunaga"]
在我身上发生了一些事情，不是吗？
[cpg cn=true]


信长大人说到了问题的核心。
[cpg]


;//ブラックアウト

;//移植前シーンカット

;//========================================
;//●ＣＧ（主人公に迫るヒロイン。主人公の体に触れている）ev_01
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ヒロイン１の部屋
;//時間　：夜
;//備考　：ヒロイン１の部屋は城内の一室です
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]



她接近我。我想到的第一件事是，我不是一个好的人。
[cpg]


[VOICE f="sNobunaga013"]
[OnName num="nobunaga"]
景太郎的身体仍然很有肌肉。我再次被提醒，他是一个男人。
[cpg cn=true]


[OnName num="keitarou"]
信长大人 ......
[cpg cn=true]



[VOICE f="sNobunaga014"]
[OnName num="nobunaga"]
继续听。
[cpg cn=true]



[VOICE f="Nobunaga273"]
[OnName num="nobunaga"]
你不需要马上回答。你可能也迷路了'。
[cpg cn=true]


信长大人似乎理解我对改变未来的恐惧。
[cpg]

我现在所处的时代可能会消失。我再也不能回家了。
[cpg]


;**【ＣＧ】 ev_01_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNobunaga015"]
[OnName num="nobunaga"]
'但我希望你能帮我这个忙。景太郎, ......
[cpg cn=true]



[VOICE f="sNobunaga016"]
[OnName num="nobunaga"]
我想和你生个孩子。
[cpg cn=true]


[OnName num="keitarou"]
...... 信长大人
[cpg cn=true]


信长大人似乎深爱着我。
[cpg]


;//移植前シーンカット

;//ブラックアウト

[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************


[VOICE f="Nobunaga323"]
[OnName num="nobunaga"]
'......，我不想让任何人看到我这样在这里。
[cpg cn=true]


[OnName num="keitarou"]
'这就对了，.......
[cpg cn=true]


我从来没有这么高兴过。但这种幸福有一天会失去。
[cpg]

我想我别无选择，只能采取行动。她终于要告诉我一切了。
[cpg]

她将在本能寺事件中死去。我要防止这种情况，我说。
[cpg]

也许未来会被扭曲。知道如果我这样做，我不知道会有什么反作用。
[cpg]

[STOPBGM]


[OnName num="keitarou"]
'信长大人。我有重要的事情要告诉你。
[cpg cn=true]

[BGM f="bg_04"]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga324"]
[OnName num="nobunaga"]
它是什么？　是不是你对我隐瞒了很久的事情？
[cpg cn=true]


[OnName num="keitarou"]
'你什么都知道，不是吗？这就对了。"
[cpg cn=true]


我深吸一口气，让自己平静下来。然后我说出了这句话。
[cpg]

[OnName num="keitarou"]
'信长大人。我要告诉光秀大人：.......'。
[cpg cn=true]


此刻我正准备说，'注意光秀大人'。
[cpg]


[transition target={true} rule="moya.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1000]

我的身体逐渐变得透明和半透明。
[cpg]

[FACE method="shock_5" pos="2/3"]

[VOICE f="Nobunaga325"]
[OnName num="nobunaga"]
'什么！？　关于......，那是什么？
[cpg cn=true]


当我在 "给光秀大人 "这句话之后没有说什么，我的身体就恢复了正常。
[cpg]

[OnName num="keitarou"]
'哦，所以这就是你的意思.......'。
[cpg cn=true]


我有一个想法。通过改变未来，你会改变未来发生的事情。
[cpg]

这意味着将有一个我不会出生的未来。
[cpg]

我本应来自那个未来，但我注定要消失。
[cpg]

[OnName num="keitarou"]
......，哈哈。
[cpg cn=true]


显然，我救不了信长大人。意识到这一点，我开始干笑。
[cpg]

[FACE method="shake_3" pos="2/3"]

[VOICE f="Nobunaga326"]
[OnName num="nobunaga"]
'景太郎，你是什么意思？解释一下'。
[cpg cn=true]


[OnName num="keitarou"]
'......'
[cpg cn=true]


我没有向信长大人解释，当时只是保持沉默。
[cpg]

我第一次见到他的时候，他有点紧张。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

信长大人随后回到了他的房间。
[cpg]

早上来了。无论我有多大的麻烦，我都累了，睡着了。
[cpg]

[OnName num="keitarou"]
'...... 上午或......'
[cpg cn=true]


当我醒来的时候，信长大人不在那里，我感到很焦急。
[cpg]

我们不知道本能寺事件何时会发生。
[cpg]

首先，在我所在的这个世界上，时间比历史上的事实要快。
[cpg]

下一次我醒来的时候，有可能就再也见不到他了。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru098"]
[OnName num="ranmaru"]
'景太郎。你醒了，你一直在做恶梦。
[cpg cn=true]


[OnName num="keitarou"]
'......兰丸大人
[cpg cn=true]


看到她让我感觉更安全一些。
[cpg]

兰丸大人一定是在本能寺事变中跟随信长大人。
[cpg]

这意味着，至少在她在这里的时候是可以的。......
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Ranmaru099"]
[OnName num="ranmaru"]
你看起来很苍白。你没有睡好吗？"
[cpg cn=true]


[OnName num="keitarou"]
不，我不介意。
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]

[VOICE f="Ranmaru100"]
[OnName num="ranmaru"]
...... 我不介意，但不要在信长大人面前做这种表情。他一定很担心。
[cpg cn=true]


我不知道我的脸上是否有这种表情。如果是这样的话，我必须要坚定。
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

我在城堡里坐不住了，所以我到了外面。
[cpg]

我想可以说，它是和平的。国家正在统一。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_01_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（昼）******************************************************

当我看到城堡小镇上熙熙攘攘的人群时，我觉得这种平静似乎会永远持续下去。
[cpg]

但这是一个错误。她永远不会像这样统治日本。
[cpg]

我觉得不甘心。我应该怎么做？
[cpg]


[window target=false]
[BG f="b_01_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************

我想她，信长大人，想要的就是这种和平。
[cpg]

然而，这一定也是镇民们一直在等待的东西。
[cpg]

为什么本应贡献最大的信长大人要遭受这样的不幸？
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


起初我认为我必须和光秀大人谈谈，但最后如果我让她劝阻我，也是一样的。
[cpg]

我将会消失，我将会结束在一个我不会出生的未来。
[cpg]

这就是以大方式改变历史的意义。......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『村』（夜）******************************************************

当我被传送到这个时间段时，我已经来到了我所在的第一个村庄，因为我有心事。
[cpg]

这个传说真的是传说吗？如果是自发的，连信长大人都知道。
[cpg]

我觉得它已经被人们添加到了。这似乎是被刻意纳入的东西。
[cpg]

[OnName num="villager"]
'......，是你，对吗？已经有一段时间了。
[cpg cn=true]


[OnName num="keitarou"]
你能告诉我更多关于这个传说吗？"
[cpg cn=true]


[OnName num="villager"]
'我不知道你要我告诉你什么，但传说就是传说。我不比你知道的更多。
[cpg cn=true]


[OnName num="keitarou"]
'我对它感到不舒服。感觉不像是传说。
[cpg cn=true]


[OnName num="villager"]
...... 是的，那是真的。它可能是可疑的。
[cpg cn=true]


村民们沉默了一会儿，然后说。
[cpg]

[OnName num="villager"]
'我只是在想象我将要告诉你的事情。带着这个想法听我说。
[cpg cn=true]


[OnName num="villager"]
'从现在开始，在未来很长一段时间内。如果我们能够操纵时间，......
[cpg cn=true]


[OnName num="villager"]
'也许有这样一种情况，即压制过去发生的异常现象。
[cpg cn=true]


[OnName num="keitarou"]
'......，这就是我被传唤到这里的原因吗？
[cpg cn=true]


[OnName num="villager"]
'好吧，听我说。你如何恢复一个已经不再按照历史运作的伟人？
[cpg cn=true]


[OnName num="villager"]
对于一个知道一点未来...... 历史的人来说，可能比来自未来的、知道这一切的人改变它更自然地行动。"
[cpg cn=true]


我默默地听着。这个人可能是伪装成这个时代的人类的未来主义者。
[cpg]

[OnName num="villager"]
'这就像把细胞植入受损的内部器官。你明白吗？"
[cpg cn=true]


[OnName num="keitarou"]
我不能改变历史，是你的意思。
[cpg cn=true]


[OnName num="villager"]
我将把这个问题留给你来决定。这也是我叫你来的部分原因。
[cpg cn=true]



;//ブラックアウト
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[WAIT time=1500]

[FACE method="in" pos="4/7"]

...... 这是个疯狂的故事。但这并不是一个我不理解的故事。
[cpg]

植入细胞。好吧，完全是人造的东西当然会有出错的地方。
[cpg]

也许历史能被连接起来是因为那些对历史一无所知的人的意愿。
[cpg]

如果是这样的话，......，我应该怎么做？
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夕方）******************************************************

我正在去她房间的路上，信长大人叫我。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Nobunaga327"]
[OnName num="nobunaga"]
'我有兰丸的消息。她有些不对劲。"
[cpg cn=true]


[OnName num="keitarou"]
'......'
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga328"]
[OnName num="nobunaga"]
'有一天，你的身体似乎是透明的。除非我弄错了。
[cpg cn=true]


[OnName num="keitarou"]
这就是.......
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga329"]
[OnName num="nobunaga"]
如果你不能告诉我一切，你就不必告诉我。但至少现在要做你正常的景太郎。"
[cpg cn=true]


信长大人似乎知道她正处于危险之中。
[cpg]

我诅咒自己不能救她，但我至少想满足她的愿望，成为正常的我。......
[cpg]


;//========================================
;//●ＣＧ（主人公を抱きしめるヒロイン）ev_68
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿ヒロイン１の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_68_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="keitarou"]
'信长大人，......，我爱你。
[cpg cn=true]



[VOICE f="Nobunaga330"]
[OnName num="nobunaga"]
'我知道，但敢于说出来是很尴尬的。
[cpg cn=true]


这段时间不会无限期地持续下去。相反，很快，我们将被分开。
[cpg]

我只是想忘记我的焦虑，只是现在。
[cpg]


[VOICE f="sNobunaga017"]
[OnName num="nobunaga"]
......景太郎。别用那种眼神看我。
[cpg cn=true]


我看起来很悲伤吗？我看起来很后悔吗？
[cpg]

刚才我确实想让信长大人放心。
[cpg]


;//移植前シーンカット
;//ブラックアウト
;//移植前シーンカット
;//ブラックアウト

[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夕方）******************************************************


[VOICE f="Nobunaga377"]
[OnName num="nobunaga"]
...... 嘿。景太郎。
[cpg cn=true]


[OnName num="keitarou"]
它是什么？　信长大人。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga378"]
[OnName num="nobunaga"]
'我想有一天能拥有你的孩子。当和平的时间到来时。"
[cpg cn=true]


[OnName num="keitarou"]
'......，是的，没错。如果那是真的，那就像一个梦。
[cpg cn=true]


在与信长大人拥抱的时候，我们谈论这样的事情。
[cpg]

但只有我知道，这是一个未完成的愿望。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga379"]
[OnName num="nobunaga"]
'我以前从未如此想要一个人。景太郎是第一个'。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga380"]
[OnName num="nobunaga"]
'你能满足我的愿望吗？　景太郎'。
[cpg cn=true]


我无法回答任何问题。和她生个孩子是可能的，但是。
[cpg]

我可能无法以任何方式与她一起抚养孩子。
[cpg]

而我却不能大声说出来。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我不能说任何重要的事情。
[cpg]

但我没有选择。没有其他办法。
[cpg]

为了改变未来，我几乎消失了，这是事实。
[cpg]

简而言之，我必须在两个......。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

晚上。走在走廊上，我看到了光秀大人。
[cpg]

[OnName num="keitarou"]
'...... 光秀大人。
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide029"]
[OnName num="mitsuhide"]
'晚上好。有什么不对吗？"
[cpg cn=true]


她要去杀信长大人。我的心情很复杂。
[cpg]

光秀大人会做这种事吗？　不，我有这种感觉已经有一段时间了。
[cpg]

[OnName num="keitarou"]
'不，没什么。
[cpg cn=true]


她曾经走近我，与我调情。
[cpg]

她一定是认真的。如果不是这样，我的失踪就没有任何解释。
[cpg]

[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide030"]
[OnName num="mitsuhide"]
我第一次见到她时，我想："景太郎先生，你似乎遇到了什么麻烦。如果我没意见，我就听着'。
[cpg cn=true]


光秀大人这么说，但和她说也没用。
[cpg]

如果我劝阻她背叛信长大人，那也是一样的。
[cpg]

我将不可避免地消失，我知道我可能无法劝阻她。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我回到了我的房间。我独自一人在思考。
[cpg]

我的脑海中只有糟糕的想象。我和信长大人在一起的日子是如此的愉快，以至于太多。
[cpg]

但......，我将别无选择，只能接受吗？
[cpg]

这是我所知道的历史上最大的事件。如果是这样，这一定是命运。
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

很快，早晨就会到来。我没有选择，只能珍惜这一天。
[cpg]

这也很难。因为我知道即将到来的命运。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

仿佛一切都从我手中溢出来。
[cpg]

我被信长大人叫住了，虽然我们在交谈，但我还是有些心不在焉。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga381"]
[OnName num="nobunaga"]
......，我有点发懵。与本案有关吗？"
[cpg cn=true]


信长大人一定是在说，我几乎消失了。
[cpg]

[OnName num="keitarou"]
我很好。我很好。"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="sNobunaga018"]
[OnName num="nobunaga"]
'......，我明白了。
[cpg cn=true]


听到我的回答，信长大人从他的房间里看出来并说。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="sNobunaga019"]
[OnName num="nobunaga"]
'仔细想想，这个被战争蹂躏的世界已经改变了。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga404"]
[OnName num="nobunaga"]
'一定程度的和平已经到来。这要归功于你'。
[cpg cn=true]


这完全是夸大其词。我什么都没做。
[cpg]

[OnName num="keitarou"]
我对你没有用处，信长大人。
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga405"]
[OnName num="nobunaga"]
没有。我是指情感支持。服兵役是一回事，服兵役是另一回事。
[cpg cn=true]


这些话对我来说真的太好听了。他说："我想，如果我是一个人，那我就不会有任何帮助。"他说："我想，如果我是一个人，那我就不会有任何帮助。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

今天和昨天是一样的。明天和今天一样。
[cpg]

快乐的时光很快就过去了。就像它以一种可怕的方式匆匆而过。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

我不能再这样下去了。但我不能告诉他们一切。
[cpg]

她走出城堡，去呼吸一些新鲜空气。在那里，她来到了。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga406"]
[OnName num="nobunaga"]
'......，不知为何我有一种感觉，景太郎在这里。
[cpg cn=true]


我转过身来，无法对她微笑。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga407"]
[OnName num="nobunaga"]
'你看起来和以前一样不慌不忙。
[cpg cn=true]


如果我不说，信长大人就会在本能寺事件中死去。
[cpg]

另一方面，如果我告诉你将会发生什么，我将会消失。
[cpg]

不仅如此，我那些应该在未来的家人和朋友也会消失。
[cpg]

不，......，这并不重要。重要的是。
[cpg]

无论是哪种方式，我们都注定不会自己团结起来。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga408"]
[OnName num="nobunaga"]
'我仍然认为他们在隐藏什么。我知道这都是你不能告诉我的事情。......
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga409"]
[OnName num="nobunaga"]
'但这并不意味着一切都不能被隐藏，显然。
[cpg cn=true]


信长大人比其他人更了解我。
[cpg]

纵观历史，我们不难发现，在过去的几十年里，我们一直都是以 "人 "为中心，而不是以 "物 "为中心。"人 "是指 "人"，"物 "是指 "人"。我张开嘴沉思着。
[cpg]

[OnName num="keitarou"]
'...... 信长大人。你是......."
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我不能告诉你一切。但我不能隐藏一切。信长大人是对的。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************


[VOICE f="Nobunaga410"]
[OnName num="nobunaga"]
这是否意味着，由于某种原因，我将会死亡，尽管我将在天堂的统治之下？
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Nobunaga411"]
[OnName num="nobunaga"]
'如果这个事实被改写，将要出生的你就会消失。
[cpg cn=true]


[OnName num="keitarou"]
'...... 这就是我的意思。我们就是不能在一起'。
[cpg cn=true]


信长大人的表情很悲伤。
[cpg]

但这并不意味着他感到惊讶。我想他知道这一点。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga412"]
[OnName num="nobunaga"]
'我明白。你可以默默地看着我的结局。没有你，我就没有理由活下去'。
[cpg cn=true]


[OnName num="keitarou"]
'哦，不，......！
[cpg cn=true]


我没料到他会说那么多。我被吓了一跳。
[cpg]

[OnName num="keitarou"]
'这恰恰相反。如果不是因为你，我就不是我了。
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]

我以强烈的语气告诉她，但信长大人摇了摇头。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga413"]
[OnName num="nobunaga"]
'我一生都很孤独。你在这一切中出现，是一盏明灯'。
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=1000]

说着，信长大人走过来，拥抱了我。
[cpg]

泪水顺着我的脸颊流了下来。我发现自己在哭。
[cpg]


;//ブラックアウト

;//移植前シーンカット

;//========================================
;//●ＣＧ（屋外でヒロインが主人公を抱きしめる）ev_24
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：屋外＿城近く
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_24_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Nobunaga414"]
[OnName num="nobunaga"]
'景太郎。我很高兴遇到你。
[cpg cn=true]


[OnName num="keitarou"]
我也很高兴认识你。我不希望认为......，你已经走了。
[cpg cn=true]



[VOICE f="Nobunaga415"]
[OnName num="nobunaga"]
我不想再去想它了。现在，让我们确保我们有一个和平的时刻。
[cpg cn=true]


我们将确保彼此的存在。她还活着。
[cpg]

我决定不去想未来她会离开的事情，就在这一刻，就像信长大人说的那样。
[cpg]

那天的月亮和星星都很美，但一切似乎都在增强信长大人。
[cpg]

我拥抱了她。好像她哪里也不去。
[cpg]

我还确保我不能去任何地方。
[cpg]

我们俩紧紧地拥抱在一起。
[cpg]


;//移植前シーンカット

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

回到城堡后，我们想留在一起。
[cpg]

我们不是正式的夫妻，但人们仍然会知道我们的关系。
[cpg]

我觉得兰丸，尤其是兰丸，告诉了我很多关于我们的事情。
[cpg]


;//ブラックアウト


[window target=false]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我们还是不能睡在一起。
[cpg]

如果早上有人来，看到我和信长大人睡在一起，那就太可怕了。
[cpg]

所以我又独自睡觉了。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

我在早晨醒来。兰丸大人来叫我起床。
[cpg]

[OnName num="keitarou"]
'早上好，.......'
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru101"]
[OnName num="ranmaru"]
'好一张脸。你一定做了一个非常可怕的梦。
[cpg cn=true]


最近，它一直是这样的。当我想到未来时，我忍不住要这样做。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]


数月和数日过去了。正在作出决定。
[cpg]

本野寺事件何时发生？这与我知道的历史不同。
[cpg]

几十年后应该发生的事情可能明天就会发生。
[cpg]


[window target=false]
[BG f="b_03_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（朝）******************************************************

我正在去找信长大人的路上。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga464"]
[OnName num="nobunaga"]
'...... 我听说你有事情要告诉我。怎么了？"
[cpg cn=true]


谈论什么。这很明显。我将帮助她。我想帮助她，但......
[cpg]

它将改变未来。当然，对我来说，她是我想保护的人，即使我不得不交换一切。
[cpg]

......，但我已经迷失了方向。
[cpg]

[OnName num="keitarou"]
'我想拯救信长大人。但......."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Nobunaga465"]
[OnName num="nobunaga"]
'别这么说。信玄不是也告诉你不要留下我一个人吗？"
[cpg cn=true]


我还是想保护信长大人。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga466"]
[OnName num="nobunaga"]
我现在最害怕的事情是独自生活。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga467"]
[OnName num="nobunaga"]
'嘿，景太郎。告诉我你会永远在我身边。
[cpg cn=true]


我不知道如果我可以这样说会有多好。但我不能。
[cpg]

[OnName num="keitarou"]
我不能肯定地说。
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Nobunaga468"]
[OnName num="nobunaga"]
...... 我明白了。
[cpg cn=true]


信长大人似乎已经明白了我的意图。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の廊下』（昼）******************************************************

我还不能做出决定。但如果有什么不同的话，那就是我们什么时候会分道扬镳，就是这样。
[cpg]

信长大人不知道我在本能寺会被出卖。
[cpg]

因此，当我们前往本之岛时，他会对我说些什么。那时再阻止他还不算太晚。
[cpg]

当然，它可能会更早。唯一的区别是我消失的时候。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Ranmaru102"]
[OnName num="ranmaru"]
'景太郎。你跟信长大人说了些什么？
[cpg cn=true]


[OnName num="keitarou"]
...... 总有一天，我会把一切都告诉兰丸大人。
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]

[VOICE f="Ranmaru103"]
[OnName num="ranmaru"]
我是唯一剩下的人。我担心你会离开。
[cpg cn=true]


甚至兰丸大人也在为我担心。
[cpg]

我是个幸运的人。我现在不怕死，这有什么奇怪的？
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_01_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************

我莫名其妙地发现自己来到了城堡小镇，那里的人们正匆匆忙忙地进行着他们的日常生活。
[cpg]

在我的时代，人们没有如此激烈地生活。
[cpg]

我想今天对死亡的恐惧已经不存在了。
[cpg]

当然，我不认为这是件坏事。我想这是和平的标志。
[cpg]

但正是在我的时代，我感到了人生的目标感。
[cpg]

这并不是说我享受可能死亡的快感或类似的东西。
[cpg]

我不知道我什么时候会死，所以我必须珍惜这一刻。
[cpg]

当我想到这一点时，生活的想法就会闪现出来。
[cpg]

信长大人还活着。他还活着。
[cpg]

如果我不保护他呢？这就是我当时的心理状态。
[cpg]


[window target=false]
[BG f="b_01_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（夜）******************************************************

希望，......，我想纯粹地作为这个时代的人生活。
[cpg]

但这样一来，信长大人就不能被救了吗？
[cpg]

我也不可能认识到本能寺事件的发生。我不知道哪个会让我更高兴。
[cpg]


;//ブラックアウト

[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

我又一次去了信长大人的地方。我打算告诉他一切。
[cpg]


[OnName num="keitarou"]
'信长大人。你是在反叛。
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[OnName num="keitarou"]
是叛逆杀死了你，......."
[cpg cn=true]


我的身体正变得有点透明。我还是很害怕。
[cpg]

我想我当时吓得浑身发抖。纵观历史，我们不难发现，在过去的几十年里，我们一直都是以 "人 "为本位，以 "物 "为本位，以 "人 "为本位。
[cpg]

[FACE method="change_3" pos="2/3"]
而就在我准备说出光秀大人的名字时。
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=1000]
她吻了我。她覆盖了我的嘴唇。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga469"]
[OnName num="nobunaga"]
'...... Fuu。我还是不让你说。"
[cpg cn=true]


[OnName num="keitarou"]
信长大人, ......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga470"]
[OnName num="nobunaga"]
'我总是希望我可以再做一次。尽管我知道这是不可能的。
[cpg cn=true]


她似乎仍然想要我。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga471"]
[OnName num="nobunaga"]
'我知道你认为这可能是最后一次，但在某个地方......。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga472"]
[OnName num="nobunaga"]
'我仍然希望我可以和你联系。我想知道为什么'。
[cpg cn=true]


信长大人的声音逐渐变得含泪。然后，我意识到。
[cpg]

我在哭，信长大人也在哭。我不想把这场爱情想成是一场悲剧。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga473"]
[OnName num="nobunaga"]
'即使你已经做了决定，我还没有。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga474"]
[OnName num="nobunaga"]
请。留在我身边。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我总是认为这是最后一次。
[cpg]

我有同样的感觉。这是最后一次了。
[cpg]

我希望有一天，当时间真的来到最后一次时，我将无怨无悔。
[cpg]


;//移植前シーンカット

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

最初，信长大人似乎把所有时间都花在了政治和战争上。
[cpg]

但现在他已经完全不同了。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Nobunaga497"]
[OnName num="nobunaga"]
'我从来没有想到我会对多彩的爱情如此斤斤计较。
[cpg cn=true]


[OnName num="keitarou"]
'......，你会想和我有个孩子吗？
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga498"]
[OnName num="nobunaga"]
'当然不是。即使我最终会死。
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

然后，早晨又来了。我在走廊上遇到兰丸大人。
[cpg]


[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（朝）******************************************************



[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru104"]
[OnName num="ranmaru"]
'...... 景太郎
[cpg cn=true]


[OnName num="keitarou"]
'是的，先生？　兰丸大师。
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru105"]
[OnName num="ranmaru"]
你在想什么？　你不会告诉我任何事情，对吗？
[cpg cn=true]


[OnName num="keitarou"]
没有。这是因为它不是那么容易说的。
[cpg cn=true]


兰丸大人没有再追究。
[cpg]

这对我来说是一种解脱。......
[cpg]


[free time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]


[VOICE f="Nobunaga499"]
[OnName num="nobunaga"]
怎么了？你们两个在谈论什么？"
[cpg cn=true]


信长大人的声音传来，我们转过身来。
[cpg]

[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru106"]
[OnName num="ranmaru"]
'怎么了？　信长大人，你看起来有点沮丧。
[cpg cn=true]


兰丸大人真的是一个能注意到最小事情的人。
[cpg]

[STOPBGM]

[FACE method="change_4" pos="2/5"]

[VOICE f="Nobunaga500"]
[OnName num="nobunaga"]
'......，我最近不太舒服。也许...... ugh"。
[cpg cn=true]


信长大人握住他的嘴。
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

不久之后，我发现信长大人怀上了一个孩子。
[cpg]

我不知道要到什么时候才能发生本能寺事件。
[cpg]

她能生下孩子吗？我们甚至不知道这一点。......
[cpg]

我甚至不知道信长大人掌权和叛乱之间有多少时间。
[cpg]

如果是这样的话，我应该马上告诉她一切。......
[cpg]

但我又不知道和我在一起的孩子是否会存在？
[cpg]

至少......，我希望我和她的孩子能活着。
[cpg]

没有它，我就无法生活。
[cpg]

否则，我将不得不告诉她叛乱的情况，并重新安排历史。
[cpg]


;//ブラックアウト





[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

然后我们成为了丈夫和妻子。
[cpg]

这并不以任何方式改变我们的关系。我仍然称信长大人为'Sama-sama'。
[cpg]

我想这就像过去军阀的妻子们一样。
[cpg]

到目前为止，信长大人的权力更大。......
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夕方）******************************************************

她的肚子越来越大了。
[cpg]

时间在流逝。我不知道她什么时候会死。......
[cpg]

不过，我还是希望她能有个孩子。
[cpg]

[OnName num="keitarou"]
'...... 信长大人,......
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Nobunaga501"]
[OnName num="nobunaga"]
'不要给我这种表情。在这个孩子出生后再做所有的决定也不迟。
[cpg cn=true]


那么可能就太晚了。我的内心是一片混乱，百感交集。
[cpg]

当我要开始哭的时候，信长大人向我走来。
[cpg]

[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga502"]
[OnName num="nobunaga"]
'你很弱。但我不是也很坚强吗？
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

他把他的手放在我的脸颊上。然后他吻了我。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[VOICE f="Nobunaga503"]
[OnName num="nobunaga"]
'我希望我能忘记所有困难的事情。
[cpg cn=true]


信长大人这样说，并要求我。
[cpg]

没有理由拒绝。我宁愿感受到她离我很近。
[cpg]


;//移植前シーンカット
[BG f="b_06_2.ui" time=1000]
[WAIT time=1100]


我感觉她也意识到了自己的死亡。我做不到，但我能做的也不多。
[cpg]

要么我消失，要么信长大人死亡。
[cpg]

如果我消失，未来将被改变。
[cpg]

这不可能只是我的问题。我不能做出这样的决定。......
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

又过了两个月。我正在去往光秀大人家的路上。
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Mituhide031"]
[OnName num="mitsuhide"]
你跟我有什么关系？"
[cpg cn=true]


[OnName num="keitarou"]
...... 我不再试图阻止你了。
[cpg cn=true]


[OnName num="keitarou"]
'即使我试图阻止你，你也无法阻止我。但至少......"
[cpg cn=true]


我想知道三秀大人如何看待我。
[cpg]

你是否认为在某种程度上你有一种预感？
[cpg]

还是他也知道我是来自未来？
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide032"]
[OnName num="mitsuhide"]
'我们是在谈论孩子吗？　不用担心。"
[cpg cn=true]


[OnName num="keitarou"]
'诶，......'
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Mituhide033"]
[OnName num="mitsuhide"]
'我也不是一个恶魔。即使孩子活下来，我也不认为会像她那样构成威胁。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Mituhide034"]
[OnName num="mitsuhide"]
我不会做这么可怕的事，我会考虑你的感受。
[cpg cn=true]


光秀大人的话让我感到安心，但我还是忍不住......。
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Mituhide035"]
[OnName num="mitsuhide"]
别挡我的路。显然，由于某种原因，我不能这样做。
[cpg cn=true]


[OnName num="keitarou"]
"......""
[cpg cn=true]


我只说了这一点。
[cpg]

她告诉我不要挡她的路。不过，她说她会等到孩子出生。
[cpg]

我不知道真正的本能寺事件是什么样的。
[cpg]

但信长大人不可能没有孩子。
[cpg]

因此，未来将是一样的，包括在那里。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

[SE f=se024]
;//【ＳＥ】『通路歩く』

我在城堡里走来走去，有一种不安的感觉。
[cpg]

我知道谁要杀她。而且这还不是全部。
[cpg]

我甚至可以拯救信长大人。不过，我还是无法选择。
[cpg]

我害怕自己会消失。我现在不得不承认这一点。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru107"]
[OnName num="ranmaru"]
"......，你又是这个样子。"
[cpg cn=true]


[OnName num="keitarou"]
兰丸大人，......，这没什么。
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Ranmaru108"]
[OnName num="ranmaru"]
'你不会再对我说什么了，是吗？我知道。"
[cpg cn=true]


兰丸大人看起来有点吃惊。
[cpg]

[FACE method="bow_3" pos="2/3"]

[VOICE f="Ranmaru109"]
[OnName num="ranmaru"]
'只是不要误会，你并不孤单。
[cpg cn=true]


如果本能寺事件像历史事实中那样发生，她也会死。
[cpg]

它不会像兰丸大人说的那样。我将是孤独的。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

我独自一人，回到了我的房间。
[cpg]

已经做出了决定。只要她生下孩子，......
[cpg]


[VOICE f="Nobunaga526"]
[OnName num="nobunaga"]
'景太郎。你在这里吗？"
[cpg cn=true]


信长大人在那里拜访了我。我回答说。
[cpg]

[OnName num="keitarou"]
'是的。它是什么？
[cpg cn=true]


[SE f=se025]
;//【ＳＥ】『ふすま開く』

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[WAIT time=1100]


[VOICE f="Nobunaga527"]
[OnName num="nobunaga"]
'完全没有。我只是想看看你。
[cpg cn=true]


[OnName num="keitarou"]
'......，我明白了。
[cpg cn=true]


信长大人仍然对我有这种想法。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga528"]
[OnName num="nobunaga"]
'当我一个人的时候，我往往会变得多愁善感，这可不行。
[cpg cn=true]


[OnName num="keitarou"]
'我也是。我想接近信长大人'。
[cpg cn=true]


[OnName num="keitarou"]
'你知道.......'我听说，悲伤的感觉并不是一种不愉快的情绪。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Nobunaga529"]
[OnName num="nobunaga"]
'也许是这样。相反，它是相反的。
[cpg cn=true]


[OnName num="keitarou"]
'是的。这更像是你沉浸其中的东西，显然。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga530"]
[OnName num="nobunaga"]
好吧，那么......，你不可能永远停留在悲伤中。"
[cpg cn=true]


信长转向我，揉着肚子。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga531"]
[OnName num="nobunaga"]
'景太郎。你和这个孩子有一个未来'。
[cpg cn=true]


我无法回答。我没有足够的决心立即给出答案。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Nobunaga532"]
[OnName num="nobunaga"]
我没有选择，只能说："记住我。这就是我所要求的。
[cpg cn=true]



;//移植前シーンカット

不可言喻的情绪在我心中涌动。但我无法说话。
[cpg]

[OnName num="keitarou"]
'...... 信长大人。我是.......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga556"]
[OnName num="nobunaga"]
怎么了？　你还在迷路吗？"
[cpg cn=true]

;//裸になった彼女を見つめながら、また振り切ったはずの感情が湧いてくる。
当我盯着她时，我本该甩掉的感觉又出现了。
[cpg]

我还在为此事耿耿于怀。但我不能让她做决定。
[cpg]

首先，她不应该让我活着。
[cpg]

我的一句话就能解决一切问题。
[cpg]

光秀大人背叛了我。就凭这一个字，......
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga557"]
[OnName num="nobunaga"]
'你很害怕。我知道你的感受。"
[cpg cn=true]


我发现自己在颤抖。我仍然害怕我将会消失。
[cpg]

[FACE method="shake_2" pos="2/3"]

[VOICE f="Nobunaga558"]
[OnName num="nobunaga"]
'想都别想。你已经为我做得够多了。"
[cpg cn=true]



;//ブラックアウト

这很容易让人相信她的话。但这是不够的。
[cpg]

一点都不足够。如果我不能帮助她，那就没有意义了。
[cpg]

我无法说出最后一个字，尽管我想到了这一点。
[cpg]


;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

又过了几个月，她的肚子肿得更大了。
[cpg]

整个城堡都在骚动，因为一个贵族要生孩子了。
[cpg]


[window target=false]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

然而，信长本人却不以为然。
[cpg]

她保持着冷静的表情，似乎在说她周围的人都太吵了。......
[cpg]


[window target=false]
[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************


[VOICE f="Nobunaga581"]
[OnName num="nobunaga"]
'不要为我担心。不过我不认为我有那么害怕。"
[cpg cn=true]


[OnName num="keitarou"]
'......，我认为有点害怕是可以的。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Nobunaga582"]
[OnName num="nobunaga"]
'也许你是对的。但分娩疼痛是我无法适应的。我从来没有过这样的痛苦，甚至在战场上也没有过。"
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


当我看到信长大人的柔和表情时，我的心情很复杂。
[cpg]

如果她生下孩子，光秀大人会毫不留情地采取行动。
[cpg]

到那时，如果我们什么都不做，信长大人会......。
[cpg]

[STOPBGM]

[FACE method="shock_4" pos="2/3"]

[VOICE f="Nobunaga583"]
[OnName num="nobunaga"]
'Ugh ...... kuuuuh!
[cpg cn=true]


[OnName num="keitarou"]
'怎么了？　信长大人，你还好吗？"
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


我不能在她出生时在场。
[cpg]

我想在这个时代可能是这样的，但我没有心情去想。
[cpg]

我不认为这是说母亲和孩子都很健康的方式。
[cpg]

但这意味着信长大人自己和新生儿都很健康。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１』（夜）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Ranmaru110"]
[OnName num="ranmaru"]
'恭喜你，信长大人。......，这是一个可爱的孩子。
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]

[VOICE f="Nobunaga584"]
[OnName num="nobunaga"]
'这是我和景太郎的孩子。这是很自然的'。
[cpg cn=true]


信长大人笑着说这话。首先想到的是，这个女人是个母亲。
[cpg]

我必须保护她。我试图坚定地讲出来，但我的声音在颤抖。
[cpg]

[OnName num="keitarou"]
'...... 信长大人。我是.......'。
[cpg cn=true]


[FACE method="shake_6" pos="2/5"]

[VOICE f="Nobunaga585"]
[OnName num="nobunaga"]
'这就够了。景太郎，如果你迷路了，那一定意味着你是那么害怕。
[cpg cn=true]

[FACE method="bow_6" pos="2/5"]
信长大人看了看兰丸大人。和......
[cpg]


[STOPBGM]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga586"]
[OnName num="nobunaga"]
'只要有你，我就不怕死。所以我不会再从你那里听到任何关于未来的消息。"
[cpg cn=true]


他说。兰丸大人接近我。
[cpg]

[OnName num="keitarou"]
'兰丸大人，什么......
[cpg cn=true]


[FACE method="shake_4" pos="4/5"]

[VOICE f="Ranmaru111"]
[OnName num="ranmaru"]
'我也不太了解。我不太了解，但这是信长大人的命令，所以不要觉得不好。
[cpg cn=true]


我想到的是，当我看到一个女人的时候，我很惊讶，转过身来看到她。我很惊讶，转过身去。......
[cpg]


;//ブラックアウト
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=1]
[WAIT time=1500]

[FACE method="in" pos="4/7"]


当我意识到信长大人的意图时，已经太晚了。
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

即使信长大人自己死了，他也是为了救我。
[cpg]

我被锁在城堡的一个房间里。我无法向外迈出半步。
[cpg]

我不能再告诉她未来了。...... 不。
[cpg]

[OnName num="keitarou"]
'我知道你有一个望风的人!　听我说！"
[cpg cn=true]


[OnName num="keitarou"]
信长大人将在本能寺被出卖！？　有人，请告诉她。
[cpg cn=true]


有守卫。
[cpg]


[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

回想起来，没有时间犹豫了。
[cpg]

不过，在看到孩子和她在一起后，我还是想消失。
[cpg]

信长大人一定也看穿了这一点。
[cpg]

[OnName num="keitarou"]
'...... 光秀大人
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Mituhide036"]
[OnName num="mitsuhide"]
'你的麻烦大了。你到底是谁？
[cpg cn=true]


[OnName num="keitarou"]
'请......，信长大人，如果我失去你，我将......
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Mituhide037"]
[OnName num="mitsuhide"]
显然，你也知道我的动机。但信长大人并不听我的，而是......。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Mituhide038"]
[OnName num="mitsuhide"]
他不想和你接触，而你正在闻到它。好像你不怕死一样。"
[cpg cn=true]


[OnName num="keitarou"]
"......"
[cpg cn=true]


我憎恨光秀大人。但这并不是说杀了她就能解决一切问题。
[cpg]

最终，未来将被改变。这是不可避免的。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide039"]
[OnName num="mitsuhide"]
'只是，景太郎先生。我不认为她的决心会白费。
[cpg cn=true]


[OnName num="keitarou"]
'那个......，是什么意思？
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]

[VOICE f="Mituhide040"]
[OnName num="mitsuhide"]
如果她有比自己更想保护的东西，那就是你，她不应该活着吗？
[cpg cn=true]


光秀大人正在策划一切。我认为她一定是一个邪恶的人。
[cpg]

但......，她这样对我说。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Mituhide041"]
[OnName num="mitsuhide"]
'逆时代潮流而动是很难的。即使对我来说也是如此。"
[cpg cn=true]


;//[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide042"]
[OnName num="mitsuhide"]
'不过，你也不应该绝望。我们都不应该'。
[cpg cn=true]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

然后，城堡里突然开始骚动起来。
[cpg]

大家都在说本能寺已经被烧毁了。
[cpg]

警卫们都走了。我到外面去了。
[cpg]

我意识到，信长大人已经不在这个世界上了。
[cpg]

兰丸大人一定是陪着他。光秀先生从现在开始就会有敌意。
[cpg]

我再也没有可以依靠的人了。
[cpg]

[OnName num="keitarou"]
...... 尽管如此，我还得活着吗？信长大人。
[cpg cn=true]


我已经想把一切都扔掉了。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

信长大人在准备工作中非常谨慎。他尽可能地避免与儿童一起工作。
[cpg]

信长大人自己也不知道她会在本能寺被杀。
[cpg]

但在她死后，他似乎告诉他的家臣带着孩子跑了。
[cpg]

而且无论我从这里做什么，历史都不会有太大的改变。看来他已经看了那么远，并且已经安排好了释放我。
[cpg]

[OnName num="vassal"]
'我们逃跑吧，景太郎大人。如果你在这里被杀，信长大人所做的一切就都白费了。
[cpg cn=true]


如果你留在这里，你可能会杀死我和我的孩子。现在唯一能做的就是逃亡。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の廊下』（昼）******************************************************

在我们逃跑的城堡里，我和信长大人抱着孩子。
[cpg]

我无法停止哭泣。她仿佛在替我哭泣，因为我的眼泪也已经干涸了。
[cpg]

当时，信长大人的附庸已经到来。
[cpg]

[OnName num="vassal"]
'我有一封信长大人写给景太郎大人的信，.......'
[cpg cn=true]


我一定看起来很糟糕。臣子犹豫着要不要把它交出来。
[cpg]

[OnName num="keitarou"]
'让我看看.......'
[cpg cn=true]


我把信拿在手里。一张小纸片被折叠起来。
[cpg]


;//ブラックアウト

;//可能であればここから一連の音声にリバーブをかけてください

[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[WAIT time=1500]

[FACE method="in" pos="4/7"]


[VOICE f="Nobunaga587"]
[OnName num="nobunaga"]
'景太郎，谢谢你做的一切。我一点也不想死'。
[cpg cn=true]



[VOICE f="Nobunaga588"]
[OnName num="nobunaga"]
'不过，我还是能从你的态度中看到这一切。
[cpg cn=true]



[VOICE f="Nobunaga589"]
[OnName num="nobunaga"]
'我想我已经不在这个世界上了。我将要写的东西是毫无根据的'。
[cpg cn=true]



[VOICE f="Nobunaga590"]
[OnName num="nobunaga"]
'还是要活下去。如果你活着，你会再次找到幸福。
[cpg cn=true]



[free time=1000]
[WAIT time=1100]

;//【ＢＧ】『城＿縁側の廊下』（昼）******************************************************

...... 信长大人并没有选择一个他活下来而我消失不见的未来。
[cpg]

[OnName num="keitarou"]
'信长大人，.......'
[cpg cn=true]


我叫着那个我不知道叫了多少次的名字，我再叫一次。
[cpg]

我现在唯一能做的就是无论如何都要活下去，为信长大人感到高兴。
[cpg]

这就对了。我知道所有的未来。如果我改成偏离这一点的历史，我将在第一时间消失。
[cpg]

我现在应该跟随的人不是秀吉就是家康。......
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

我决定生活在一个被战争蹂躏的世界里，同时思考。
[cpg]

我不会死。我不会消失。
[cpg]

为了信长大人，为了我的孩子们，......，我将活得最精彩。
[cpg]

我将活下去。
[cpg]



;//ＥＮＤ　ヒロイン１ルート
;//＠
[SCENE id=9]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="epend.ks" target="*start"]

