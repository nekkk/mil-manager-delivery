
*start

;//==============================
;//謙信の所へ潜入　勝利した場合

*select04_win|

*root_2|再次见到对方

;#################################################
*Ep008|再一次见面。
;#################################################

[SCENE id=8]


[STOPBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//[BGM f="bg_07"]


;//【ＢＧ】『城＿室内』（夜）


谦信不知道我在那里，叫他的臣子们谈各种事情。
[cpg]

我可以说，我的目标已经实现了。有了这个，与谦信的战斗就可以解决了。
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_14_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿謙信』（夜）******************************************************

我已经发现了我想知道的东西。没有必要徘徊不前。
[cpg]

刺杀他不是我的职责，我也没有必要这样做。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『山道』（朝）******************************************************

我已经取得了一些成就。她似乎没有认出我，所以她不可能是在撒谎。
[cpg]

我兴致勃勃地回到了信玄大人那里。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

当我回到她的住处时，她表扬了我。
[cpg]

只要听到她说我做得很好，我就很高兴。
[cpg]

这值得我冒生命危险。......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

信玄大人把我留在他身边。
[cpg]

当然，这并不意味着我只是站在他身边什么都不做。我会考虑我可以做什么。
[cpg]

信玄大人的臣子们教我如何站在战场上，政治，等等。
[cpg]


[window target=false]
[BG f="b_13_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

我有很多东西要学。在这个时代，这个时代有常识。
[cpg]

学习一些东西比我整天无所事事地度过更有成就感。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（昼）******************************************************

在那些日子里，有时会发生一些不正常的情况。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Ranmaru461"]
[OnName num="ranmaru"]
'嘿，你......，不打算回信长大人那里去了？
[cpg cn=true]


兰丸大人来拜访我和信玄大人。
[cpg]

[FACE method="change_7" pos="2/5"]

[VOICE f="Singen218"]
[OnName num="shingen"]
'你打算怎么做？　我打算留下来。
[cpg cn=true]


[OnName num="keitarou"]
'不，......，我不会回到信长大人身边。
[cpg cn=true]


我摇了摇头。兰丸小姐看起来很遗憾。
[cpg]

[FACE method="change_3" pos="4/5"]

[VOICE f="Ranmaru462"]
[OnName num="ranmaru"]
'信长大人还在等你。
[cpg cn=true]


[OnName num="keitarou"]
'对信玄大人来说也是如此。他需要我'。
[cpg cn=true]


兰丸大人似乎无法放弃。
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我从来没有被如此需要过。
[cpg]

我来自未来，但我从未被如此善待过。
[cpg]

所以，当我把这件事告诉信玄大人时...
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen219"]
[OnName num="shingen"]
'这还不是全部。你有一种神秘的魅力。
[cpg cn=true]


她一边回答一边非常靠近我，"你有一种神秘的魅力。
[cpg]


;//========================================
;//●ＣＧ（主人公の体に両手を突いているヒロイン）ev_69
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_09"]
;**【ＣＧ】 ev_69_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="keitarou"]
'...... 是这样吗？
[cpg cn=true]


我感觉每个人都在这么说，但我到底有什么魅力呢？
[cpg]

在我看来，这只是因为我来自一个不同的时代。
[cpg]

[OnName num="keitarou"]
'我不觉得我没有辜负任何人的期望。然而兰丸大人却想把我带回去。
[cpg cn=true]



[VOICE f="Singen220"]
[OnName num="shingen"]
'是的，你是对的。也许你应该有更多的信心。
[cpg cn=true]


[OnName num="keitarou"]
...... 你是什么意思？"
[cpg cn=true]



[VOICE f="Singen221"]
[OnName num="shingen"]
'你在战场上打得很好。我的意思是，你应该意识到，你只有在你的名声好的时候才会好。
[cpg cn=true]


这个女人的眼睛似乎在诉说着一种不寻常的心境。
[cpg]


;//移植前シーンカット

诸侯们都知道我们的关系。我想说这不是一个问题。......
[cpg]

但我肯定他们是嫉妒的。我必须为它工作。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

与谦信的另一场战争即将开始。
[cpg]

我将作为一名将军站在战场上，领导士兵。
[cpg]

[OnName num="keitarou"]
那我们可以走了吗？
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Singen248"]
[OnName num="shingen"]
'是的。我会再见到你的，我们会一见如故。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（昼）******************************************************

当我们在一起时，没有什么可害怕的。
[cpg]

我和信玄大人虽然相距甚远，但我们的心是一体的。
[cpg]


[STOPBGM]
[window target=false]
[BG f="b_09_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（夕方）******************************************************

[SE f=se019]
;//【ＳＥ】『剣戟』

我意识到，作为一名军事指挥官，我已经变得更加强大。
[cpg]

当我为信玄大人战斗时，他在与谦信的战斗中逐渐占了上风。
[cpg]

如果事情像这样发展下去，就会与我所知道的历史有些不同。
[cpg]

我记得，这场战斗应该是没有结果的。
[cpg]

但由于我的缘故，这场战斗可能会发生倾斜。
[cpg]

如果未来被改变了，我不知道会发生什么。这可能是我从未存在过。
[cpg]

为了防止这种情况，我做了一些事情，比如在最后一刻操纵战争局势......，而没有打败谦信。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen249"]
[OnName num="shingen"]
'......，你做得非常好。你有打仗的天赋'。
[cpg cn=true]


[OnName num="keitarou"]
'是这样的吗？你不是信玄大人的对手。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen250"]
[OnName num="shingen"]
这并不令人惊讶。如果有比我强的军阀这么容易，我就麻烦了。
[cpg cn=true]


我明白了。你是这样的军阀，你把你的名字留在了未来。
[cpg]


;//ブラックアウト

;//移植前シーンカット
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

时间在流逝。无法解决的战斗仍在继续。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen280"]
[OnName num="shingen"]
'我派出去战斗的忍者已经回来了，看来下一场战斗将是一场全面的战争。
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


全面战争。这是否意味着信玄大人或谦信大人都会输？
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Singen281"]
[OnName num="shingen"]
下一次，将决定是我还是谦信灭亡。
[cpg cn=true]


我已准备好为信玄大人付出一切。
[cpg]

[OnName num="keitarou"]
信玄大人。我与你同在。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen282"]
[OnName num="shingen"]
谢谢你。我以前说过，我对你没有吸引力，但我收回这句话。
[cpg cn=true]


他们对我有一定的帮助。这是我已经知道的事情。
[cpg]

继续为信玄大人而战是一回事。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen283"]
[OnName num="shingen"]
'...... 不错的夕阳，不是吗？每当太阳落山时，我总是想知道今天的日落是否会是最后一次'。
[cpg cn=true]


即使像信玄大人这样优秀的人也会感到害怕。
[cpg]

不过，我还是不想看到她看起来很焦虑。
[cpg]

[OnName num="keitarou"]
'这不会发生，我亲爱的。只要我在这里'。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Singen284"]
[OnName num="shingen"]
'我想要永生。如果我在这场战斗中幸存下来，我也会得到这些吗？
[cpg cn=true]


[FACE method="bows_4" pos="2/3"]

[VOICE f="Singen285"]
[OnName num="shingen"]
'但即使我赢得这场战斗，...... kehoh, kohoh。
[cpg cn=true]


[OnName num="keitarou"]
你没事吧，信玄大人？信玄大人。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Singen286"]
[OnName num="shingen"]
'......，即使我赢得了与谦信的这场战斗，我也终究无法赢得对疾病的胜利。
[cpg cn=true]


;//ブラックアウト

;//移植前シーンカット

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

你越想珍惜它，时间就会越快过去。决定性战斗的日子很快就到了。
[cpg]

一个矛盾的情况是，我们要想获得和平，唯一的办法就是战斗。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

我希望我是在，比如说，现在，而不是在这个时代遇到她。
[cpg]

结核病本来是可以被治愈的。我可以想象的东西是没有尽头的。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『戦場』（朝）******************************************************

然后，到了决定性战斗的日子。
[cpg]

[FG f="CHA02_p3_02_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Singen314"]
[OnName num="shingen"]
'我可以做到，我们走吧。我今天会完成。"
[cpg cn=true]


[OnName num="keitarou"]
是的，我会做的。交给我吧。"
[cpg cn=true]


但我不能让这场战斗结束。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（昼）******************************************************

[SE f=se019]
;//【ＳＥ】『剣戟』

我以自己的判断力控制了战争局势，因为历史如果得到解决，就会改变。
[cpg]

而与谦信的战斗最后也没有解决。......。
[cpg]

不过，我一定给他造成了很大的痛苦。
[cpg]

如果有的话，信玄大人仍然有优势。
[cpg]

如果他再倾斜的话，他就快要失去谦信了。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="Singen315"]
[OnName num="shingen"]
'你已经做得很好了。优秀的工作'。
[cpg cn=true]


[OnName num="keitarou"]
'谢谢你。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Singen316"]
[OnName num="shingen"]
'但这有一些不自然的地方。我不相信战斗已经倾斜到如此程度，而且还没有解决。
[cpg cn=true]


[OnName num="keitarou"]
这就是.......
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen317"]
[OnName num="shingen"]
我知道大部分的情况。等一切都解决了，你就麻烦了。
[cpg cn=true]


我听着她说，无法回话。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen318"]
[OnName num="shingen"]
'如果你来自未来，你有我无法想象的情况，我敢肯定。
[cpg cn=true]


[OnName num="keitarou"]
'我很抱歉，.......'
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Singen319"]
[OnName num="shingen"]
'不需要道歉。不要遗憾，我很感激。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen320"]
[OnName num="shingen"]
谢谢你。真的，这要感谢你。......谦信不会那么容易攻击我们。不过，还有一件需要担心的事情已经过去了。
[cpg cn=true]


[OnName num="keitarou"]
你在想你的病吗？
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Singen321"]
[OnName num="shingen"]
'是的。我确定我没有死在战场上？
[cpg cn=true]


这一部分是一个模糊的记忆。但如果信玄和谦信的战斗在历史事实中没有定论，他一定是在某个地方病死的.......。
[cpg]

[OnName num="keitarou"]
'我害怕失去你。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Singen322"]
[OnName num="shingen"]
'......，即使你这么说。'我的生活是任何人都无法控制的。
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット

;//移植前シーンカット

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（昼）******************************************************

第二天，我离开城堡，眺望小镇。
[cpg]

这是信玄大人所保护的城镇。即使它不像五代时期那样热闹，它仍然是一个有很多优点的城镇。......
[cpg]

毫无疑问，人们仍在这里生活。我感觉到了。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen377"]
[OnName num="shingen"]
......，我希望他们能够专心于自己的幸福，没有任何顾虑。"
[cpg cn=true]


信玄大人和谦信之间的战斗仍未解决。
[cpg]

信玄大人可能觉得他最终必须杀死他们，因为他们已经是多年的敌人了。
[cpg]

也许谦信也有同样的愿望，而他们彼此之间存在矛盾。
[cpg]

[OnName num="keitarou"]
'我有点讨厌它。这是无法帮助的事情吗？
[cpg cn=true]


这种事情在我所处的现代社会也可能发生。
[cpg]

每个人都在为他人着想，希望世界和平，但这不可能实现。
[cpg]

在全国范围内或在个人范围内可能都是如此。
[cpg]

人们希望彼此相爱，但这往往不会发生。
[cpg]

[OnName num="keitarou"]
'人们的爱怎么能如此扭曲呢？
[cpg cn=true]


[OnName num="keitarou"]
'我们想要的东西，或者我们都应该希望的东西，不是那么容易实现的。
[cpg cn=true]


当我和信玄大人谈起这些想法时...
[cpg]

[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen378"]
[OnName num="shingen"]
'是的，那是真的。你和我能够相爱，一定是个奇迹。
[cpg cn=true]

[STOPBGM]
信玄大人回答说，但不久之后，他又说。
[cpg]

[FACE method="bows_4" pos="2/3"]

[VOICE f="Singen379"]
[OnName num="shingen"]
'葛浩！'。　Gohoho！"
[cpg cn=true]


[OnName num="keitarou"]
你没事吧，信玄大人？
[cpg cn=true]


她突然咳嗽起来，用手捂住嘴。她的手掌沾满了血。
[cpg]

这种神奇的爱是否也将被夺走？
[cpg]

肺结核的疾病正在将我们撕裂。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

[OnName num="keitarou"]
'......，没关系。当然，信玄大人的病会被治愈的。"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen381"]
[OnName num="shingen"]
'我不能。是我，我知道我在说什么。
[cpg cn=true]


[OnName num="keitarou"]
'即使信玄大人放弃了，我也不会。
[cpg cn=true]


信玄大人体弱多病，想放弃这个孩子。
[cpg]

但我一直鼓励他。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


生孩子很困难，即使生了，我也不知道信玄大人是否安全。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen382"]
[OnName num="shingen"]
'也许你是对的。仅有爱可能是不够的。
[cpg cn=true]


[OnName num="keitarou"]
'我说的不是这个。我说的是爱本身被扭曲了。
[cpg cn=true]


[OnName num="keitarou"]
'我认为信玄大人的爱根本就不是这样的。
[cpg cn=true]


我对信玄大人说这样的话，他感到很虚弱。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen383"]
[OnName num="shingen"]
'......，我不需要任何安慰。
[cpg cn=true]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

而她的愿望实现了。
[cpg]


;//========================================
;//●ＣＧ（妊娠しているヒロインが前のめりで主人公に近づく）ev_29
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城＿室内
;//時間　：夜
;//備考　：ヒロインは妊娠四ヶ月くらいです
;//========================================


[BGM f="bg_05"]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]



她的肚子肿了起来。对我们来说没有什么是不可能的。
[cpg]


[VOICE f="Singen384"]
[OnName num="shingen"]
'也许我生孩子的时候就是我死的时候。
[cpg cn=true]


[OnName num="keitarou"]
'话说回来，你不必担心......。
[cpg cn=true]



[VOICE f="Singen385"]
[OnName num="shingen"]
'我不知道？　你没有证据来支持这一点'。
[cpg cn=true]


[OnName num="keitarou"]
据我所知，历史上没有人因为生孩子而死亡。
[cpg cn=true]


说到这里，我不能说我......，因为她基本上一开始就是个男人，所以我觉得很安全。
[cpg]


;**【ＣＧ】 ev_29_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSingen003"]
[OnName num="shingen"]
......"
[cpg cn=true]


她本该为生下孩子而感到高兴，但她还是有些忧郁。
[cpg]

信玄大人的肚子膨胀了，快乐的日子过去了。
[cpg]

就像她说的，我也有一种感觉，一切都会过去。
[cpg]

信玄大人患有肺结核。即使她能生孩子，......
[cpg]

她可能比我先死。这是我不得不考虑的事情，即使我不愿意。
[cpg]


;//移植前シーンカット

;//ブラックアウト

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

谦信和我僵持了一下。
[cpg]

我和信玄大人已经关注了很久了。我不可能不去管它。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen436"]
[OnName num="shingen"]
'在你的时代，它是一个国家，日本，不是吗？
[cpg cn=true]


[OnName num="keitarou"]
是的，这是正确的。你也没有军队。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Singen437"]
[OnName num="shingen"]
我很羡慕你。在这个时代，一个国家可以没有士兵而存在，这是不可想象的。
[cpg cn=true]


信玄大人的话让我感到很沮丧。
[cpg]

[OnName num="keitarou"]
'我所处的世界也不会改变。它正在改变它的形式，而像战争这样的事情不断发生'。
[cpg cn=true]


她想要的和平终究没有实现。
[cpg]

'如果我能回到以前的时代，我不会想在闲置中生活。
[cpg]

[FACE method="change_4" pos="2/3"]

[VOICE f="Singen438"]
[OnName num="shingen"]
'难道你不愿意回到以前的样子吗？
[cpg cn=true]


我稍微沉思了一下，想了想。
[cpg]

[OnName num="keitarou"]
'我会的。我想把治疗肺结核的药带回来，拯救你们。
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

想到信玄大人，我回答道。
[cpg]

[FACE method="shake_6" pos="2/3"]

[VOICE f="Singen439"]
[OnName num="shingen"]
'你说这种话。但对我的病来说已经太晚了。
[cpg cn=true]


[OnName num="keitarou"]
'那不是真的，在我的时代，应该有治疗肺结核的药物。
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

信玄大人是否相信我的话？
[cpg]

无论是哪种方式，都是一样的，因为没有办法返回到今天。
[cpg]

我最多只能做到认真地爱她。......
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sSingen004"]
[OnName num="shingen"]
'只要我和景太郎在一起，我就可以忘记一切。
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Singen465"]
[OnName num="shingen"]
'还有我自己的死亡。当我和庆太郎在一起的时候，我可以忘记一切，甚至是我自己的死亡，以及这个孩子是否会平安出生。
[cpg cn=true]


[OnName num="keitarou"]
'你没有什么可担心的。我反复说着同样的话。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Singen466"]
[OnName num="shingen"]
是的。如果你说了，我想我可能不用担心了。
[cpg cn=true]


毕竟，她将不可避免地感到脆弱。我想支持她。
[cpg]

可能是我，而不是信玄大人，正在寻找一个可靠的联系。......
[cpg]


;//ブラックアウト

;//移植前シーンカット

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）

我想知道我们还有多少时间可以分享。
[cpg]

信玄大人的肚子继续咆哮着。而且她的结核病越来越严重。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

是时候了，她终于快要生了。
[cpg]

我一直都在她身边。再加上结核病，她已经不怎么起床了。
[cpg]

;//[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Singen491"]
[OnName num="shingen"]
'......，对不起，让你担心了。
[cpg cn=true]


[OnName num="keitarou"]
'不要道歉。我确实担心，但我这样做是因为我想这样做。
[cpg cn=true]


;//[FACE method="shock_4" pos="2/3"]

[VOICE f="Singen492"]
[OnName num="shingen"]
'所以...... keh, geez.
[cpg cn=true]


;//[FACE method="change_6" pos="2/3"]

[VOICE f="Singen493"]
[OnName num="shingen"]
你即将有一个孩子。我希望你能见到你的孩子。
[cpg cn=true]


[OnName num="keitarou"]
不要担心。这正是你需要担心的问题。
[cpg cn=true]


信玄大人没有回报。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

我祈祷着。我一次又一次地祈祷。愿她平安。
[cpg]

愿孩子能安全出生。如果我愿意，我愿意用我的生命换取她的生命。
[cpg]

也许这个愿望得到了回应，她生下了......。
[cpg]

她生下了一个孩子。我和信玄大人想要的孩子在这个世界上诞生了。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

;//[SE f=se000]
;//【ＳＥ】『赤子の泣き声』

[OnName num="keitarou"]
我很高兴。......，我真的，真的很高兴。"
[cpg cn=true]


我们的孩子是个男孩。他正在欢快地哭泣。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Singen494"]
[OnName num="shingen"]
'我以前从未见过你哭。
[cpg cn=true]


[OnName num="keitarou"]
'我是那么的高兴。我们真的要成为一个家庭'。
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]

[VOICE f="Singen495"]
[OnName num="shingen"]
'是的。...... Geehaw, kehaw!　哈.......'。
[cpg cn=true]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_13_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信玄』（夜）******************************************************

母亲和孩子都是安全的。然而，信玄大人的肺结核并没有痊愈。
[cpg]

我不知道信玄大人是否有可能继续看着这个孩子长大。
[cpg]


[window target=false]
[BG f="b_13_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿外観＿信玄』（昼）******************************************************

几个月和几天过去了。我们的孩子已经长大了，而与谦信的战斗仍然没有得到解决。
[cpg]

今天，兰丸大人从信长大人那里过来。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_5"  pos="2/3" time=800]

[VOICE f="Ranmaru463"]
[OnName num="ranmaru"]
'...... 你是父亲？我无法想象那是什么样子的'。
[cpg cn=true]


[OnName num="keitarou"]
'我也没有想象，但我终于开始感觉到了。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru464"]
[OnName num="ranmaru"]
 信玄大人还好吗？
[cpg cn=true]


[OnName num="keitarou"]
这就是.......
[cpg cn=true]



[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

信玄大人的情况并不乐观。如果他的情况继续下去，他的寿命将不足五年。
[cpg]

想象一下与她死后的离别是很痛苦的。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Singen496"]
[OnName num="shingen"]
'兰丸_......，你来了。
[cpg cn=true]


[FACE method="bow_4" pos="4/5"]

[VOICE f="Ranmaru465"]
[OnName num="ranmaru"]
'是的。你的健康状况如何？"
[cpg cn=true]


[FACE method="shake_4" pos="2/5"]

[VOICE f="Singen497"]
[OnName num="shingen"]
......，不那么好，不那么好。我不得不振作起来。
[cpg cn=true]


信玄大人看起来非常虚弱。我不希望看到她这样的脸。
[cpg]

我想不惜一切代价救她。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


而有一条道路可能使这成为可能。
[cpg]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

随着我们的孩子长大，她发展了神奇的能力。
[cpg]

这是传说中的事。也就是说，超越时间的力量。
[cpg]

他有能力使他所接触的物体在他的思想状态下消失。
[cpg]

这可能是让他们飞向未来。利用这种力量，我也许能回到今天。
[cpg]

也许。也许。......
[cpg]

[OnName num="keitarou"]
'信玄大人。我也许能给你带来治疗你的肺结核的药。"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Singen498"]
[OnName num="shingen"]
'...... 我们在谈论时间旅行，不是吗？
[cpg cn=true]


我已经向信玄大人解释过很多次了。在时间上来回走，即使在我的时代也没有做过，但......。
[cpg]

我有一个想法，那就是我们的孩子在做什么。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Singen499"]
[OnName num="shingen"]
'我还是很迷茫。不能保证你会回到未来，再次回到这里。
[cpg cn=true]


[OnName num="keitarou"]
我会回来的。我甚至可以为你发明一台时间机器。
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Singen500"]
[OnName num="shingen"]
什么是时间机器？
[cpg cn=true]


信玄大人咯咯笑着。但他的脸色并不好。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

我没有时间再花时间来做决定了。如果我现在不离开，我可能就做不到了。
[cpg]

[OnName num="keitarou"]
'......，那我就走了。
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Singen501"]
[OnName num="shingen"]
'你真的要去。请确保你回来。
[cpg cn=true]


[OnName num="keitarou"]
'是的，我会的。我保证。"
[cpg cn=true]


我拉着我孩子的手，我求他。
[cpg]

[OnName num="keitarou"]
我希望你能提醒我，就像你一直做的那样。我希望你能让我消失。
[cpg cn=true]


不知怎的，我有种感觉，这个孩子也明白我的意图。
[cpg]

最后，我看着信玄大人，闭上了眼睛。
[cpg]


;//画面ゆがむ

[SE f=se018]
;//【ＳＥ】『タイムリープ　シンセ系の効果音』

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0xffffffff} time=2000]
[FACE method="change_4" pos="2/3"]
[WAIT time=500]
[WAIT time=2000]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1500]

[BG f="black.ui" time=1000]

[WAIT time=2000]
[BG f="b_11_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『博物館＿現代』（夕方）******************************************************

;//画面元に戻る

[OnName num="keitarou"]
'...... 这个地方。
[cpg cn=true]


在我回到过去之前，我已经回到了今天。
[cpg]

我环顾四周。我又回到了现在，而本该装饰的折叠屏风本身已经消失了。
[cpg]

[OnName num="classmate_A"]
怎么了，景太郎？你去哪里了？
[cpg cn=true]


[OnName num="classmate_B"]
'......，你的肌肉变得更发达了吗？　这是我的想象吗？
[cpg cn=true]


甚至一个小时都没有过去。自从我来到这里，一切都没有改变，除了折叠式屏幕。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


这一切都是幻觉吗？它是真的吗？
[cpg]

我在无法确认的情况下与家人团聚了。
[cpg]

但信玄大人和我们的孩子还在过去。
[cpg]

没有办法回去治愈信玄大人的肺结核。......。
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_11_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『博物館＿現代』（昼）******************************************************

然后我开始参观城堡和博物馆，仿佛被什么东西附身了。
[cpg]

从历史事实来看，信玄是否留下了任何子女？我认识的信玄有孩子。
[cpg]

我查了一下，发现他有一些后人。这一点我已经发现了。
[cpg]

我离开博物馆，想象着如果我没有和信玄大人生下孩子，就不会发生这种事。
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

然后我离开博物馆，走了一会儿。
[cpg]

我只是情不自禁地再次见到她。
[cpg]

但还是......，也许。
[cpg]

[WAIT time=1100]

;//以降セリフ名前欄を「少女」と置き換えてください
[STOPBGM]


[VOICE f="Singen502"]
[OnName num="girl"]
'......，我在哪里见过你吗？
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（街を歩くヒロイン。主人公の方を向いてびっくりしている）ev_67
;//人物１：ヒロイン２　服装１：制服
;//場所　：現代＿街
;//時間　：昼
;//備考　：信玄本人ではなく、末裔です
;//========================================


;**【ＣＧ】 ev_67_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

[BGM f="bg_05"]


女孩看了看我，显得很惊讶。
[cpg]

她的外表与信玄大人非常相似。
[cpg]

[OnName num="keitarou"]
你是 .......
[cpg cn=true]



[VOICE f="Singen503"]
[OnName num="girl"]
那个女孩看着我，显得很惊讶。我不知道为什么。
[cpg cn=true]


甚至他们说话的方式也完全一样。我发现自己流下了眼泪。
[cpg]


[VOICE f="Singen504"]
[OnName num="girl"]
我想我......，看到你在什么地方流泪了。
[cpg cn=true]



;//ブラックアウト

;//ＥＮＤ　ヒロイン２ルート

[SCENE id=13]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="epend.ks" target="*start"]

;//==============================





