*start


;#################################################
*Ep002|奥克哈扎马之战
;#################################################

[SCENE id=2]


[stflag Cha2flg=0]
[stflag Cha3flg=0]
[stflag Cha4flg=0]
[stflag Cha5flg=0]

[stflag Selectflg1=0]
[stflag Selectflg2=0]
[stflag Selectflg3=0]
[stflag Selectflg4=0]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『城＿縁側の通路』（夜）******************************************************

时间过去了一段时间，日子似乎平静而黯淡。
[cpg]

我不能什么都不做，但当我做家务等事情时，周围的人都会阻止我。
[cpg]

我想这是因为我是信长大人身边的人。
[cpg]

而且在那个年代，做饭和其他杂事都是由妇女来做的，这是众所周知的。......。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Nobunaga170"]
[OnName num="nobunaga"]
'你看起来很无聊。景太郎。"
[cpg cn=true]


[OnName num="keitarou"]
'...... 或 ......'
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]

[VOICE f="Ranmaru061"]
[OnName num="ranmaru"]
如果你不忙，我可以给你一些剑术训练。
[cpg cn=true]


兰丸大人建议。这是一件相当令人欣慰的事情。
[cpg]

[OnName num="keitarou"]
是的，我是。我对自己的剑术还是很有信心的。
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]

[VOICE f="Ranmaru062"]
[OnName num="ranmaru"]
'...... 你怎么敢在我面前说这种话？
[cpg cn=true]


不知道这意味着什么，我看着信长大人。
[cpg]

[FACE method="bow_2" pos="2/5"]

[VOICE f="Nobunaga171"]
[OnName num="nobunaga"]
兰丸用长矛更好，但他用剑也相当好。
[cpg cn=true]


[OnName num="keitarou"]
'我明白了。'那么我就更有动力去做了。
[cpg cn=true]


[FACE method="change_3" pos="4/5"]

[VOICE f="Ranmaru063"]
[OnName num="ranmaru"]
'你说......？
[cpg cn=true]


然后决定我们要进行徒手搏斗，所以我们必须做好准备。
[cpg]

有人告诉我，在这个时期，神奈仍然存在。我听说他们已经很老了。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Ranmaru064"]
[OnName num="ranmaru"]
'如果你如此自信，你就不需要护具。
[cpg cn=true]


[OnName num="keitarou"]
'......，我不能对你轻易下手。这样做还行吗？"
[cpg cn=true]



;//ブラックアウト

;//戦闘シーン　武器を振るうようなエフェクトなどつけられたらお願いします

;//========================================
;//●ＣＧ（紹介ページヒロイン５のＣＧ）ev_95
;//人物１：ヒロイン５　服装１：着衣
;//場所　：城＿外観
;//時間　：昼
;//備考　：可能であれば背景を足してください
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;**【ＣＧ】 ev_95_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]



[SE f=se028]
;//【ＳＥ】『竹刀打ち合う』

[BG f="white.ui" time=100]
[WAIT time=100]
;**【ＣＧ】 ev_95_0 ***********************
[CG id=2 index=0 time=100]
;***************************************
[WAIT time=100]

在这个时代，信长大人被公认为是一个熟练的战士。而我则是像其他地方一样的剑道俱乐部成员。
[cpg]

但各时代之间存在着差距。我认为这将是一个很好的搭配，当我们互相撞击的时候，我......
[cpg]


[VOICE f="Ranmaru065"]
[OnName num="ranmaru"]
'啊!　赛亚啊！"
[cpg cn=true]


兰丸大人的太极图是如此的笔直。也有许多初步的运动。
[cpg]

我想，自从剑道变得更像一项运动以来，它的质量可能已经发生了变化。
[cpg]

能在实际战斗中使用的剑术可能更多的是挥舞重剑的力量或类似的东西。
[cpg]

还是说男女之间根本就有区别？......，这就像没有比赛。
[cpg]


[window target=false]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/5" time=1000]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************


[VOICE f="Ranmaru066"]
[OnName num="ranmaru"]
'哈，哈，哈'。
[cpg cn=true]


[OnName num="keitarou"]
......"
[cpg cn=true]


我觉得打一个没有穿防护装备的女孩不舒服，所以我在沙沙地打了一会儿神棍。
[cpg]

看到兰丸大人即将耗尽力量，信长大人饶有兴趣地看着。
[cpg]

[FACE method="bow_7" pos="2/5"]

[VOICE f="Nobunaga172"]
[OnName num="nobunaga"]
'把你的耳朵借给我听一下。景太郎'。
[cpg cn=true]


[OnName num="keitarou"]
'是的，怎么了，......？
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]

[VOICE f="Nobunaga173"]
[OnName num="nobunaga"]
'你不是生活在一个比现在更和平的时代吗？你怎么能驾驭这样的一把剑？"
[cpg cn=true]


[OnName num="keitarou"]
'......，这是.......'
[cpg cn=true]


'你是说，因为我们生活在一个和平的时代，所以有些事情我们可以做？
[cpg]

[OnName num="keitarou"]
'即使在今天，剑道，这种剑术仍然存在。我想这意味着它以自己的方式进化了，假设你不使用真正的剑。
[cpg cn=true]

[FACE method="shake_4" pos="4/5"]
[FACE method="change_1" pos="2/5"]

兰丸大人看起来很沮丧。想到这里，我不应该对一个女孩的对手这样做。
[cpg]

在这样想的时候，信长大人显得很感动。总的来说，我想知道进行徒手搏斗是否是一个好主意。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（昼）******************************************************

时间就这样进一步流逝。
[cpg]

有好几次，我不得不从一个城堡搬到另一个城堡，以适应信长大人。在某种程度上，我习惯了四处走动。
[cpg]

我们在城堡里听说，他终于要统一欧瓦里......。
[cpg]

这个时期的地名和我所在的时期的地名不太相符。
[cpg]

对信长大人来说，一个叫岩仓城的地方似乎是他的下一个目标，但我甚至不知道谁在那里。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夕方）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Nobunaga174"]
[OnName num="nobunaga"]
'从现在开始，我打算接管这个国家。我将结束这场战斗。
[cpg cn=true]


我和兰丸被传唤到信长大人的房间。
[cpg]

[FACE method="bow_2" pos="4/5"]

[VOICE f="Ranmaru067"]
[OnName num="ranmaru"]
'当然了。信长大人，我毫不怀疑你会成为这片土地的统治者。
[cpg cn=true]


兰丸大人现在是、过去是、将来可能也是一心一意为信长大人服务。
[cpg]

[FACE method="shake_3" pos="2/5"]

[VOICE f="Nobunaga175"]
[OnName num="nobunaga"]
我不知道在世界统一之后还有什么。我不认为和平会很快到来。
[cpg cn=true]


我一直在想我是否应该说些什么。
[cpg]

她会遇到什么样的结局？......
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

我敢肯定，如果放任不管，信长大人会在本能寺事件中自杀，因为我知道这段历史。
[cpg]

但我可以改变这一点吗？
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

我遇到光秀先生的时候，我的心情还很复杂。
[cpg]

[OnName num="keitarou"]
'你又在照顾...... 盆景吗？
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Mituhide014"]
[OnName num="mitsuhide"]
'是的。你也想试试吗？
[cpg cn=true]


[OnName num="keitarou"]
'不，我是......
[cpg cn=true]


在闲聊的时候。光秀大人突然改变了话题。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide015"]
[OnName num="mitsuhide"]
你对信长大人有什么看法？
[cpg cn=true]


[OnName num="keitarou"]
是的，...... 我仍然会说是一个可靠的人。"
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]

[VOICE f="Mituhide016"]
[OnName num="mitsuhide"]
是这样的吗？我对你来说还不够好吗？"
[cpg cn=true]


她的话，如果从正常意义上讲，就是指你愿意为我服务吗？
[cpg]

但我知道光秀大人的野心。所以我不能说什么。
[cpg]

[OnName num="keitarou"]
'......，至少，我现在只为信长大人服务。
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide017"]
[OnName num="mitsuhide"]
'我喜欢你，我的夫人。我们闻起来都一样。
[cpg cn=true]


[OnName num="keitarou"]
同样的气味？"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide018"]
[OnName num="mitsuhide"]
'是的，我知道。事实上，你难道不厌倦为别人服务吗？
[cpg cn=true]


光秀大人正在展示他的野心的一瞥。也许他认为我看穿了这一切。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Mituhide019"]
[OnName num="mitsuhide"]
我会以平等的态度对待你。我不会把你当成我的仆人。
[cpg cn=true]


[OnName num="keitarou"]
你是什么意思？光秀大人没有宣誓效忠信长大人？
[cpg cn=true]


当我问光秀大人时，她笑了一下。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Mituhide020"]
[OnName num="mitsuhide"]
我不这么认为。没有人比我对信长大人更有用。
[cpg cn=true]


我无法读懂她的真实意图。我知道她喜欢我，但......
[cpg]

也许她想让我在她背叛我时跟随她的朋友。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

我必须要考虑一下。即使是和以前一样。......
[cpg]

这一次不仅仅是为了生存。
[cpg]

在这里，它是关于我们的人和我们所做的事。我不禁对这一点感到担忧。
[cpg]


[window target=false]
[BG f="b_07_1.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（朝）******************************************************

[SE f=se026]
;//【ＳＥ】『鳥の鳴き声』

这并不是说我的时间太少，以至于我无法思考任何问题。
[cpg]

事实上，我有足够多的东西。我必须思考，思考，思考，想出答案。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

时间流逝，但它比这更快。
[cpg]

比我知道的历史要快得多。一个叫今川义元的军阀和信长大人发生了冲突。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Mituhide021"]
[OnName num="mitsuhide"]
他将带领多少部队？
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga176"]
[OnName num="nobunaga"]
'他不会放过任何一个人。这将是一场全面的战斗。"
[cpg cn=true]


奥克哈扎马之战。我不是一个历史爱好者，但我知道这场战斗。
[cpg]

我还记得，信长将赢得这场战斗。我清楚地知道，我们不可能在这场战斗中失败。
[cpg]

[FACE method="change_3" pos="2/5"]

[VOICE f="Nobunaga177"]
[OnName num="nobunaga"]
我要发动一场突袭。你怎么看，兰丸？"
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="4/5" time=800]

[VOICE f="Ranmaru068"]
[OnName num="ranmaru"]
'突然袭击？......，我认为我们应该公平公正地战斗。
[cpg cn=true]


没有。我想知道是否是这样的情况...... 在我的印象中，奥凯哈扎马应该是日本历史上最著名的突袭之一。
[cpg]

这意味着，如果你迎面撞上他们，你可能会输。
[cpg]

[FACE method="change_3" pos="2/5"]

[VOICE f="Nobunaga178"]
[OnName num="nobunaga"]
'那景太郎呢？　你有什么要说的吗？
[cpg cn=true]


[OnName num="keitarou"]
'......，我认为突袭是个好办法。
[cpg cn=true]


[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga179"]
[OnName num="nobunaga"]
我相信你会这么说。你会这么说的'。
[cpg cn=true]

[FACE method="change_3" pos="4/5"]
兰丸大人瞪了我一眼，但我没有选择。
[cpg]

信长大人一定知道我来自未来，他一定在听我说什么。
[cpg]

[FACE method="change_1" pos="2/5"]

[VOICE f="Nobunaga180"]
[OnName num="nobunaga"]
你呢，景太郎？你会去战斗的，对吗？
[cpg cn=true]


我想了想。我想到的第一件事是，该公司的总裁是天津分公司的一名成员。
[cpg]

首先，即使没有我，信长也会接管这个国家。......。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

他说他不会在信长大人面前回答，但会和光秀大人单独呆在一起。......
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Mituhide022"]
[OnName num="mitsuhide"]
'你不必强迫自己参加战斗。你对我来说是那么重要。"
[cpg cn=true]


光秀大人说。选择是跟随信长大人还是光秀大人。
[cpg]

我应该怎么做？我应该选择谁？
[cpg]


毕竟，我想帮助...... 信长大人。他是第一个认出我的人。
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Mituhide023"]
[OnName num="mitsuhide"]
'景太郎先生？　你要去哪里？
[cpg cn=true]


我将原路返回，回到信长大人身边。
[cpg]


;//ブラックアウト

[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga181"]
[OnName num="nobunaga"]
'怎么了？　你下定决心了吗？
[cpg cn=true]


[OnName num="keitarou"]
'是的。'是的，我也要去。我想帮助信长大人'。
[cpg cn=true]


信长大人看起来很满意。
[cpg]

[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga182"]
[OnName num="nobunaga"]
'这很有希望。我指望着你。
[cpg cn=true]


他对我说了这些话。我也感到高兴。
[cpg]

既然我已经说了这些，就没有回头路可走了。
[cpg]

就我而言，这场战斗应该解决一切问题。
[cpg]

即使将来有小规模的战斗，大部分的战斗也会在奥克哈扎马解决。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

信长大人正在为即将到来的战斗计划一次突袭。
[cpg]

我将是执行它的人。这是一个重要的角色。
[cpg]

如果我不小心，我可能会死在这里。
[cpg]

但信长大人对这种恐惧的感受一定更强烈。
[cpg]

想到这里，我很奇怪地没有害怕。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_06"]

;//【ＢＧ】『戦場』（昼）******************************************************

奥克哈扎马之战。我知道，信长大人是出其不意地赢得了它。
[cpg]

我记得，兵力上的差异接近十倍。因为我们有3000人，他们有30000人......？
[cpg]

我们能在这么大的数字面前获胜吗？在担心这个问题的同时，......
[cpg]

我只相信信长大人。
[cpg]



;//※ストーリーが分岐
;//　勝利した場合、ヒロイン１、ヒロイン５ルートへ
;//　敗北した場合、ヒロイン４ルートへ


;//伏兵は２、５、８に配置されています

;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※
;//※※※桶狭間の戦い　開始時（１のマスにいる場合のシナリオ）※※※
;//※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※※

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


光秀大人说她不希望我被强迫去战斗。
[cpg]

如果我听从她的建议，我是否应该敢于考虑撤回自己？
[cpg]

我认为这仍然是你要站在哪一边的问题，信长大人的还是光秀大人的。
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_07"]

;//【ＢＧ】『戦場』（夜）******************************************************

;//ヒロイン１の立ち絵を表示してください

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]


信长大人插话了。她说，在他们行军至此的过程中，今川的军队经常将他们的伏击部队排成一列。
[cpg]

当然，并非所有的人都可能是这样，但我们必须意识到这一点。
[cpg]

我下定决心并前进。
[cpg]


;//■選択肢
[switch]
[case "向南行进。"]
	[swap]
	[jump target="*select03_4"]
[case "继续向东走。"]
	[swap]
	[jump target="*select03_2"]
[endswitch]

1，往南走。
2，向东行进。


;//==============================
;//１、南へ進む

;//同じイベント中の「４のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「２のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※２のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_2|奥克哈扎马之战


[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


前方潜伏着一个埋伏。我大胆地面对他们。
[cpg]


[SE f=se019]
;//【ＳＥ】『つばぜり合い』

我打败了伏击者，但我不能放松警惕。如果我们再遇到他们，我们就会有危险了。
[cpg]

我们小心翼翼地前进。......
[cpg]

[stflag Selectflg3=1]


;//■選択肢
[switch]
[case "向南前进。"]
	[swap]
	[jump target="*select03_5"]
[case "向东走。"]
	[swap]
	[jump target="*select03_3"]
[endswitch]

1，向南走。

2、向东走。


;//==============================
;//１、南へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「３のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※３のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_3|奥克哈扎马之战

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン４の立ち絵を表示してください

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/3" time=800]


在我们前进的过程中，我们与光秀女士相遇。
[cpg]

她的脸上有一种不赞同的表情。因为我没有听从光秀大人的话。
[cpg]

[OnName num="keitarou"]
'突袭似乎进展顺利。光秀大人'。
[cpg cn=true]


光秀大人仍然显得很不满意。但这并不意味着我们现在不能退缩。
[cpg]


;//■選択肢
[switch]
[case "向南行进。"]
	[swap]
	[jump target="*select03_6"]
[endswitch]

1，向南推进。


;//==============================
;//１、南へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※４のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_4|奥克哈扎马之战

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//ヒロイン５の立ち絵を表示してください

[FG f="CHA05_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

在路上，我们与兰丸大人碰面。
[cpg]

兰丸大人正在英勇地战斗。尽管她是一个苗条的女孩，......
[cpg]

我很佩服她，但我知道我不能只佩服她，所以我向前看。
[cpg]


;//■選択肢
[switch]
[case "我往南走。"]
	[swap]
	[jump target="*select03_7"]
[case "向东走。"]
	[swap]
	[jump target="*select03_5"]
[endswitch]

1，向南走。
2、向东走。


;//==============================
;//１、南へ進む

;//同じイベント中の「７のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「５のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※５のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※


*select03_5|奥克哈扎马之战

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[if exp={getFlagValue("Selectflg3") == 1 }]
[jump target="*select03_5_t"]
[endif]

[jump target="*select03_5_f"]


;//==============================
;//２のマスを通っていた場合

*select03_5_t|奥克哈扎马之战

再往前走，又有一个伏击。
[cpg]

[OnName num="keitarou"]
'该死的......，如果我们继续这样走下去......。
[cpg cn=true]


我已经耗尽了我的部队，以至于我没有选择，只能撤退。
[cpg]

我不能再往前走了。我想我必须把它交给信长大人。
[cpg]


;//敗北判定となる
;//「桶狭間の戦い　二度伏兵のマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン４ルートへの可能性が残る

[jump target="*select03_lose"]


;//==============================
;//２のマスを通っていない場合

*select03_5_f|奥克哈扎马之战

前方潜伏着一个埋伏。我大胆地与他们对抗。
[cpg]


[SE f=se019]
;//【ＳＥ】『つばぜり合い』

我打败了伏击者，但我不能放松警惕。如果我们再遇到他们，我们就会有危险了。
[cpg]

我们小心翼翼地前进。......
[cpg]

[stflag Selectflg3=1]


;//■選択肢
[switch]
[case "向南前进。"]
	[swap]
	[jump target="*select03_8"]
[case "向东走。"]
	[swap]
	[jump target="*select03_6"]
[endswitch]

1，向南走。
[cpg]

2、向东走。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================
;//２、東へ進む

;//同じイベント中の「６のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※６のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_6|奥克哈扎马之战

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


;//ヒロイン４の立ち絵を表示してください

与光秀先生一起，我们继续前进。
[cpg]

她有些不高兴，似乎不赞成我在这里。
[cpg]

但我已经决定为信长大人服务。我不会从这里转身离开。
[cpg]


;//■選択肢
[switch]
[case "我要去南方了。"]
	[swap]
	[jump target="*select03_9"]
[endswitch]

1，向南推进。
[cpg]


;//==============================
;//１、南へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※７のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_7|奥克哈扎马之战

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

最后，这场漫长的战斗即将结束。
[cpg]

到目前为止，我们还没有遇到任何伏击兵。这意味着我们的突袭很可能会很顺利。
[cpg]


;//■選択肢
[switch]
[case "向东行进"]
	[swap]
	[jump target="*select03_8"]
[endswitch]

1，向东推进。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「８のマスにいる場合のシナリオ」へ飛ぶ

;//==============================

;//※※※※※※※※※※※※※※※※※※※※
;//※※※８のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_8|奥克哈扎马之战

[SE f=se014]
;//【ＳＥ】『歩く』
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[if exp={getFlagValue("Selectflg3") == 1 }]
[jump target="*select03_8_t"]
[endif]

[jump target="*select03_8_f"]


;//==============================
;//２あるいは５のマスを通っていた場合

*select03_8_t|奥克哈扎马之战

再往前走，又有一个伏击。
[cpg]

[OnName num="keitarou"]
'该死的......，如果我继续这样走下去......。
[cpg cn=true]


我已经耗尽了我的部队，以至于我没有选择，只能撤退。
[cpg]

我不能再往前走了。我想我必须把它交给信长大人。
[cpg]


;//敗北判定となる
;//「桶狭間の戦い　二度伏兵のマスを通った場合」と書いてある所まで進む
;//ゲームオーバーにはならず、ヒロイン４ルートへの可能性が残る

[jump target="*select03_lose"]


;//==============================
;//２、５いずれののマスを通っていない場合

*select03_8_f|奥克哈扎马之战


前方潜伏着一个埋伏。我大胆地与他们对抗。
[cpg]


[SE f=se019]
;//【ＳＥ】『つばぜり合い』

我打败了伏击者，但我不能放松警惕。如果我们再遇到他们，我们就会有危险了。
[cpg]

我们小心翼翼地前进。......
[cpg]

[stflag Selectflg3=1]


;//■選択肢
[switch]
[case "继续向东走。"]
	[swap]
	[jump target="*select03_9"]
[endswitch]

1，向东推进。
[cpg]


;//==============================
;//１、東へ進む

;//同じイベント中の「９のマスにいる場合のシナリオ」へ飛ぶ

;//==============================


;//※※※※※※※※※※※※※※※※※※※※
;//※※※９のマスにいる場合のシナリオ※※※
;//※※※※※※※※※※※※※※※※※※※※

*select03_9|奥克哈扎马之战


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（夕方）******************************************************

[SE f=se019]
;//【ＳＥ】『刀打ち合う』

一切都是战斗，直到敌人的将军今川义元被打败。
[cpg]

不一定要打败所有的士兵，或许那可能不足以取胜。
[cpg]

什么事情，信长大人已经想到了。
[cpg]

我们所要做的就是按照指示行动，战斗的进展是有利的。
[cpg]


[window target=false]
[BG f="b_09_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『戦場』（夜）******************************************************

而在击败今川义元后，敌人已经失去了战斗意志。
[cpg]

这事就这么定了。如果我们赢了，就意味着信长大人已经接管了这个国家。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Mituhide024"]
[OnName num="mitsuhide"]
'每次我都会爱上信长大人的计划。我很自豪能成为他的附庸。
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
信长大人听了光秀大人的话，点了点头啊。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Nobunaga183"]
[OnName num="nobunaga"]
'现在失眠的一个种子已经消失了，我必须感谢你。
[cpg cn=true]


[OnName num="keitarou"]
'不客气。我只做了我能做的事。
[cpg cn=true]


[FACE method="shake_1" pos="2/5"]

[VOICE f="Nobunaga184"]
[OnName num="nobunaga"]
不要谦虚。你已经成长为一个男人了，景太郎。
[cpg cn=true]


[OnName num="keitarou"]
......
[cpg cn=true]


我在思考未来。信长大人赢得了大江山之战。......。
[cpg]

清算的日子终于来临了。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿縁側の通路』（昼）******************************************************

我想不出别的办法。
[cpg]

我甚至可以否定这个世界，认为它与我所知道的历史毫无关系。
[cpg]

但无论我怎么想，命运都不会改变，未来会到来。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_02"]

;//【ＢＧ】『城＿室内』（夜）******************************************************

不过，当战斗结束后紧张气氛消散时，兰丸大人还是来看望我。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

[VOICE f="Ranmaru069"]
[OnName num="ranmaru"]
...... 景太郎。我可以说句话吗？
[cpg cn=true]


[OnName num="keitarou"]
兰丸大人，...... 有什么问题吗？
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru070"]
[OnName num="ranmaru"]
我想感谢你。我已经很久没有说过了。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru071"]
[OnName num="ranmaru"]
谢谢你。多亏了你，信长大人似乎能更轻松地战斗。
[cpg cn=true]


[OnName num="keitarou"]
不可能。这是信长大人自己的力量。
[cpg cn=true]


[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru072"]
[OnName num="ranmaru"]
当你这样站在信长大人面前时，你必须像...... 我。"
[cpg cn=true]


兰丸大人不再像以前那样吃醋了。
[cpg]

相反，她很感激......，我以前从未见过她做出这样的表情。
[cpg]

[OnName num="keitarou"]
'兰丸大人对信长大人也是一心一意的，不是吗？
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

'是的，'兰丸大人回答，然后继续说。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru073"]
[OnName num="ranmaru"]
'没有什么比被信长大人称赞和崇拜更快乐的了。
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

我们越来越接近国家的统一。信长大人正处于无人能阻止他的境地。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Nobunaga185"]
[OnName num="nobunaga"]
'我正在考虑与武田结成联盟。他们不会拒绝。"
[cpg cn=true]


[OnName num="keitarou"]
...... 是的。
[cpg cn=true]


[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga186"]
[OnName num="nobunaga"]
怎么了？你看起来很不开心。
[cpg cn=true]


我已经想了很久了。到目前为止，没有多少时间了。
[cpg]

我认为，原来的历史发展得比较慢。
[cpg]

[OnName num="keitarou"]
'我已经想了很久，这段历史与我所知道的历史不同。
[cpg cn=true]


[OnName num="keitarou"]
'可能信长大人是个女人，但时间的流逝太快了。
[cpg cn=true]


这可能与兰丸大人和信长大人之间没有太大的年龄差异有关。
[cpg]

[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga187"]
[OnName num="nobunaga"]
'但我赢得了奥克哈扎马。现在，对我来说，接管国家都不是不可能。
[cpg cn=true]


这当然是真的，我不认为从现在开始，接管国家的未来会改变。
[cpg]

如果要......，本能寺事件怎么办？
[cpg]

如果在叛乱发生前采取措施，未来可能会改变。
[cpg]

那么信长大人是否能够继续生活下去，想：......
[cpg]

[OnName num="keitarou"]
'是的。这就对了。"
[cpg cn=true]


现在，他只是向信长大人宣誓效忠。
[cpg]

[if exp={getFlagValue("Selectflg2") == 1 }]
[jump target="*select03_ex"]
[endif]


[jump target="*select03_end"]


;//==============================
;//稲生の戦いで勝利していた場合のみ下記のシナリオを通る

*select03_ex|奥克哈扎马之战。

[FACE method="change_7" pos="2/3"]

[VOICE f="Nobunaga188"]
[OnName num="nobunaga"]
'嗯。景太郎，你还是有些紧张'。
[cpg cn=true]


[OnName num="keitarou"]
'不，我不是这个意思。......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga189"]
[OnName num="nobunaga"]
'我需要为你打破紧张的局面，我想。
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

说着，她走近我。
[cpg]

[OnName num="keitarou"]
'信长大人，......，这是没有用的。这对我来说是如此的浪费时间。
[cpg cn=true]


[OnName num="keitarou"]
'此外，你甚至不会知道谁在看。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga190"]
[OnName num="nobunaga"]
'......，我明白了。如果你拒绝，我不会强迫你'。
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（朝）******************************************************

...... 我拒绝了信长大人的邀请。
[cpg]

这有点让人心碎。但这也是没办法的事。
[cpg]

我也没有准备好。
[cpg]


[window target=false]
[BG f="b_06_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（夕方）******************************************************

但很快我就不能再毫无准备了。
[cpg]

我不是被信长大人召唤的，而是被他的一个臣子召唤的。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_04"]

;//【ＢＧ】『城＿室内』（夕方）******************************************************

诸侯们都是男人。而且他们有神秘的面孔。
[cpg]

[OnName num="vassal_A"]
'听着，景太郎。信长大人，如你所知，让男人远离'。
[cpg cn=true]


[OnName num="keitarou"]
'是的。......，我相信他是个大忙人。
[cpg cn=true]


[OnName num="vassal_B"]
'啊。但我不能再这么说了。
[cpg cn=true]


[OnName num="vassal_A"]
我听说，作为一个男人，景太郎受到信长大人的青睐，这一点很不寻常。
[cpg cn=true]


我想知道....... 我想知道外面是否有比我更信任我的男人。
[cpg]

兰丸大人和光秀大人是女性。
[cpg]

[OnName num="vassal_A"]
所以，我想请你帮个忙。
[cpg cn=true]



;//ブラックアウト

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（夜）******************************************************

因此，我已经被安排到......
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="sNobunaga007"]
[OnName num="nobunaga"]
'一个继承人。我也要考虑这个问题吗？
[cpg cn=true]


[OnName num="keitarou"]
'...... 是。
[cpg cn=true]


我只能给出一个愚蠢的回答。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="sNobunaga008"]
[OnName num="nobunaga"]
'但如果对方是景太郎，我就不介意了。
[cpg cn=true]


[OnName num="keitarou"]
但...... 信长大人。
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="sNobunaga009"]
[OnName num="nobunaga"]
你不必认真遵守你说的或做的任何事情。可以说，我不能生孩子。
[cpg cn=true]


...... 信长大人似乎仍然不打算生孩子。
[cpg]


;//ブラックアウト

;//移植前シーンカット

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_03"]

;//【ＢＧ】『街』（昼）******************************************************

第二天。不知怎的，我在房间里坐不住了，我走到了城堡镇。
[cpg]

战国时期的一个城镇。它与今天的人不同。
[cpg]

它与魅力无关，目之所及，建筑都很低矮。
[cpg]

不过，还是有人类的生命。我想这是信长大人的职责，要保护这个。
[cpg]

还是说这也是我的角色？当我边走边想的时候，我看到......
[cpg]


;//========================================
;//●ＣＧ（紹介ページヒロイン４のＣＧ）ev_
;//人物１：ヒロイン４　服装１：着衣
;//場所　：城下町
;//時間　：昼
;//備考　：可能であれば背景を足してください
;//========================================


[free time=1000]
;**【ＣＧ】 ev_00_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]



我看到了光秀大人。兰丸大人也在附近。
[cpg]


[VOICE f="Mituhide025"]
[OnName num="mitsuhide"]
看来信长大人最近对你很有好感。
[cpg cn=true]



[VOICE f="Ranmaru074"]
[OnName num="ranmaru"]
'嗯，是的。'嗯，不只是最近，而是一直都在。你吃醋了吗？
[cpg cn=true]


我决定从后面听一听这段对话。
[cpg]


[VOICE f="Mituhide026"]
[OnName num="mitsuhide"]
不，我只是觉得如果我不像你那样思考，我会很高兴。
[cpg cn=true]



[VOICE f="Ranmaru075"]
[OnName num="ranmaru"]
'......，你是什么意思？
[cpg cn=true]


从外面看，这是一场为同一个人服务的两个人之间的小规模冲突。
[cpg]

但对我来说，谁知道未来，这听起来是完全不同的细微差别。
[cpg]

我当时无法开口说话。
[cpg]

...... 但话说回来，光秀大师也会到茶馆这样的地方来。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

[OnName num="keitarou"]
......"
[cpg cn=true]


从外面看城堡。小镇没有灯光，所以月亮和星星都格外美丽。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga215"]
[OnName num="nobunaga"]
睡不着吗？景太郎。
[cpg cn=true]


[OnName num="keitarou"]
...... 信长大人也是？
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]

[VOICE f="Nobunaga216"]
[OnName num="nobunaga"]
'不。我在思考未来。我已经投入了太多的工作，所以我需要休息一下'。
[cpg cn=true]


信长大人可能正在考虑如何从现在开始治理日本。
[cpg]

我甚至无法想象。
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Nobunaga217"]
[OnName num="nobunaga"]
我们从现在开始需要思考的问题，与我们为赢得战争而需要采取的措施不同。你永远不知道谁会恨你。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Nobunaga218"]
[OnName num="nobunaga"]
甚至我也害怕死亡。接下来会发生什么......
[cpg cn=true]


她并没有在表情上表现出来。不过，我还是能看出她很担心。
[cpg]

[OnName num="keitarou"]
只要我在这里，信长大人就会保护你。
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

[VOICE f="Nobunaga219"]
[OnName num="nobunaga"]
'啊。我也会保护你。
[cpg cn=true]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]


[VOICE f="Nobunaga220"]
[OnName num="nobunaga"]
'......，不要在这里被人看到。
[cpg cn=true]



[SE f=se027]
;//【ＳＥ】『茂みを歩く』

我被信长大人带进了森林灌木丛。
[cpg]


;//========================================
;//●ＣＧ（接近してキスをする）ev_07
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：森の茂み
;//時間　：夜
;//========================================



[BGM f="bg_09"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]



;//移植前シーンカット

进入森林灌木丛后，她正要吻我的嘴。
[cpg]


[VOICE f="sNobunaga010"]
[OnName num="nobunaga"]
'Chuu......, nn.
[cpg cn=true]


当我在抚摸她时，我不能再高兴了。
[cpg]

我不需要别的东西。如果我不能回到原来的时间，我也不在意。
[cpg]

我真希望这段时间能永远持续下去。
[cpg]


;**【ＣＧ】 ev_07_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNobunaga011"]
[OnName num="nobunaga"]
我希望......，与你生孩子。"
[cpg cn=true]


不过，当她这么说时，我还是很犹豫。
[cpg]

如果你在这个时间段和她有了孩子，你将最终无法返回。
[cpg]

[OnName num="keitarou"]
'这是......
[cpg cn=true]



[VOICE f="sNobunaga012"]
[OnName num="nobunaga"]
'......，你不必现在就给我一个答案。
[cpg cn=true]


我采取了相信信长大人的话的形式。
[cpg]

这种关系仍将在模糊中继续下去。
[cpg]


;//移植前シーンカット

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『森の中』（夜）******************************************************

那是一段可爱的时光。我觉得我已经没有多少时间了。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Nobunaga262"]
[OnName num="nobunaga"]
'我们是否应该尽快回去，......，现在是什么时候？
[cpg cn=true]


不过，我们还是互相寻找对方，以至于忘记了时间。
[cpg]

我可以为她做什么？
[cpg]

我可以防止即将发生的事情吗？
[cpg]


;//==============================

*select03_end|奥克哈扎马之战

;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿外観＿信長』（夜）******************************************************

然后。坏消息传到我们这里。
[cpg]

信玄大人非常虚弱。
[cpg]

她患有肺结核。一个在这个时代无法治愈的疾病。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

[SE f=se027]
;//【ＳＥ】『山道歩く』

兰丸大人和我奉信长大人之命前往信玄大人居住的城堡。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Ranmaru076"]
[OnName num="ranmaru"]
'你变得更强壮了，是吗？
[cpg cn=true]


[OnName num="keitarou"]
我已经开始习惯了.......
[cpg cn=true]


兰丸大人的催促越来越少，也许在某种程度上认可了我的努力。
[cpg]

我什至怀念那些日子。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Ranmaru077"]
[OnName num="ranmaru"]
然而，那个信玄大人。她是无敌的，似乎是不朽的。
[cpg cn=true]


[OnName num="keitarou"]
'我想这是真的，没有人能够战胜疾病。
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Ranmaru078"]
[OnName num="ranmaru"]
'...... 是这样的吗？我很奇怪地感到孤独。
[cpg cn=true]


[OnName num="keitarou"]
'这不是一个好兆头。你还不应该这么说'。
[cpg cn=true]


兰丸大人看起来真的很孤独。
[cpg]

我想，他和信玄大人一定认识很久了。
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

山路没有像以前那样困扰我了。
[cpg]

我已经经历了比我的份额更多的shuraku。
[cpg]

然后，通过持续的山路，......
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_01_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『街』（夜）******************************************************

我们来到了城堡镇。我就快到信玄大人那里了。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru079"]
[OnName num="ranmaru"]
...... 信玄大人可能已经睡着了。"
[cpg cn=true]


于是决定明天去信玄大人那里。
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_08"]

;//【ＢＧ】『城＿室内』（朝）******************************************************

第二天早上。信玄大人的脸色比我们之前见到他时还要苍白。
[cpg]

他躺在地上，呼吸缓慢。他可能已经病得起不来了。
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="4/5" time=800]

[VOICE f="Singen069"]
[OnName num="shingen"]
'你让我很担心。如果我再强壮一点就好了。"
[cpg cn=true]


信玄大人比我想象的还要虚弱。就连兰丸大人也是一副不忍直视的样子。
[cpg]

[FACE method="change_4" pos="4/5"]

[VOICE f="Ranmaru080"]
[OnName num="ranmaru"]
'信玄大人，......，医生是怎么说的？
[cpg cn=true]


[FACE method="shake_4" pos="2/5"]

[VOICE f="Singen070"]
[OnName num="shingen"]
'他们说他撑不了多久了。他无法停止咳嗽。......
[cpg cn=true]


兰丸大师眼里含着泪水。如果信长大人知道这件事，一定会很郁闷。
[cpg]

然后，信玄大人拉着我的手。那是一只出乎意料的冰冷的手。
[cpg]

[FACE method="bow_4" pos="2/5"]

[VOICE f="Singen071"]
[OnName num="shingen"]
'信长......，她是.......'
[cpg cn=true]


[OnName num="keitarou"]
'这是什么？　是要告诉信长大人吗？
[cpg cn=true]


[FACE method="bow_6" pos="2/5"]

[VOICE f="Singen072"]
[OnName num="shingen"]
不要让她一个人呆着。如果她不能快乐，我也不能死。
[cpg cn=true]


信玄大人在说出他对信长大人的爱时，显得很苦恼。
[cpg]

这与其说是身体上的痛苦，不如说是精神上的痛苦。
[cpg]

她可能害怕这样死了，就不知道信长大人会怎么样了。
[cpg]

[FACE method="shake_6" pos="4/5"]

[VOICE f="Ranmaru081"]
[OnName num="ranmaru"]
'别担心。信玄大人不会死。"
[cpg cn=true]


[FACE method="change_2" pos="2/5"]

[VOICE f="Singen073"]
[OnName num="shingen"]
 兰丸。你真是太善良了。支持信长。
[cpg cn=true]


兰丸大人终于流下了眼泪。
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿室内』（夜）******************************************************

就在第二天晚上，她去世了。我和兰丸大人都在场。
[cpg]

当时，兰丸大人像个孩子一样哭泣。
[cpg]

我在想我应该对信长大人说些什么。......
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（昼）******************************************************

我们按原路返回。我在想和兰丸大人一样的事情。
[cpg]

我不想看到信长大人情绪低落。
[cpg]

但我不能不告诉他真相。......
[cpg]


[window target=false]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『山道』（夜）******************************************************

晚上，当我们安营扎寨时，我被兰丸大人的声音吵醒了。
[cpg]

[OnName num="keitarou"]
'...... 兰丸大人。
[cpg cn=true]


[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru082"]
[OnName num="ranmaru"]
'什么？我没有哭'。
[cpg cn=true]


天太黑看不清楚，但我觉得兰丸大人在哭。
[cpg]

那么，也许唤醒我的声音也是一个啜泣的声音。
[cpg]

...... 这是一个人们的生活比较轻松的时候吗？会不会相当重，只有一个区别？
[cpg]

对我来说，信长大人的生命是不可替代的。
[cpg]

信玄大人的死让我想起了即将到来的事情。
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿外観＿信長』（昼）******************************************************

然后，我走出山路：......
[cpg]

很久以来，我第一次回到了信长大人的地方。
[cpg]

仅此一点就使我感到有些欣慰。
[cpg]


;//ブラックアウト

[window target=false]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『城＿ヒロイン１の部屋』（昼）******************************************************

我正在去找信长大人的路上，准备告诉他一切。
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Nobunaga263"]
[OnName num="nobunaga"]
'我明白了。信玄已经死了？
[cpg cn=true]


信长大人的眼睛是浑浊的。我找不到任何话可以说。
[cpg]

[FACE method="shake_4" pos="2/3"]

[VOICE f="Nobunaga264"]
[OnName num="nobunaga"]
'为了她，我必须活下去。
[cpg cn=true]


[OnName num="keitarou"]
'是的。如果信长大人也死了，我就.......'
[cpg cn=true]


信长大人看起来有点惊讶。
[cpg]

[FACE method="change_5" pos="2/3"]

[VOICE f="Nobunaga265"]
[OnName num="nobunaga"]
你为什么这么说？到目前为止，我还没有得过任何严重的疾病。
[cpg cn=true]


[OnName num="keitarou"]
'......，这是真的，但是......'
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Nobunaga266"]
[OnName num="nobunaga"]
'你不必担心。我将在太阳底下，不是吗？　还是你在隐瞒什么？
[cpg cn=true]


我无法回答，不知道歪曲历史是否真的是个好主意。
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_05"]

;//【ＢＧ】『城＿縁側の通路』（夕方）******************************************************

城堡内。在走廊里，我遇到了兰丸大师。
[cpg]

[FG f="CHA05_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Ranmaru083"]
[OnName num="ranmaru"]
'我都告诉你了，不是吗？我告诉信长大人.......'
[cpg cn=true]


[OnName num="keitarou"]
'是的。
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]

[VOICE f="Ranmaru084"]
[OnName num="ranmaru"]
我明白了。我不能告诉他。我又要哭了'。
[cpg cn=true]


兰丸大人在自嘲中这样说。
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Ranmaru085"]
[OnName num="ranmaru"]
'但是谢谢你.......自从你来之后，信长大人已经改变了很多。
[cpg cn=true]


[OnName num="keitarou"]
是这样吗，......？"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]

[VOICE f="Ranmaru086"]
[OnName num="ranmaru"]
'他是一个更冷酷的人，除了他自己的成功之外，对任何事情都不贪婪。但现在他不同了，......，而且更亲切。"
[cpg cn=true]


我不明白，兰丸大人是比我更看重信长大人的人。
[cpg]

[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru087"]
[OnName num="ranmaru"]
'我认为他可能和其他人一样贪婪，希望被人们喜欢，......，虽然我不能说什么好话。
[cpg cn=true]


兰丸大人似乎在用她自己的方式思考信长大人。
[cpg]

她甚至可能在想，她的心态变化可能会在未来影响日本。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru088"]
[OnName num="ranmaru"]
'我喜欢老信长大人，但我更喜欢现在的信长大人。我得感谢你'。
[cpg cn=true]


兰丸大人似乎在感谢我。
[cpg]

[OnName num="keitarou"]
'兰丸大人也变了。我想他更多的是在嫉妒我。
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]

[VOICE f="Ranmaru089"]
[OnName num="ranmaru"]
我不喜欢你，但我也不喜欢你。除了信长大人，我没有别的人了。
[cpg cn=true]


我想我们都认为，除了为信长大人服务，没有其他办法。
[cpg]

[FACE method="change_2" pos="2/3"]

[VOICE f="Ranmaru090"]
[OnName num="ranmaru"]
你和我有点像，不是吗？
[cpg cn=true]


我第一次见到她时，她的表情与第一次见到她时不同。
[cpg]

他们看起来相当自信。这也不仅仅是一种相似性。
[cpg]

我们可以称他们为战友，还是说这种关系不止于此？
[cpg]

我想了想，怎么......，我不能这么轻易地说出来。
[cpg]

[OnName num="keitarou"]
'......，也许我们是。
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

我们互相凝视了一会儿。
[cpg]

兰丸大人现在不能告诉我，他对我没有任何想法。
[cpg]

但这并不意味着你不能如此轻易地触摸它们。
[cpg]

而且我知道这里的一个词有很大的分量。
[cpg]

我不能粗心地推开她，也不能把她拉近。
[cpg]

如果我在这里说一些接受她的话，我很可能会做......，因为它是的东西。
[cpg]

我们都感觉到了这一点，但不能说什么。
[cpg]


;//※ストーリーが分岐
;//　稲生の戦いで勝利していた場合のみ、ヒロイン１ルートへ
;//　稲生の戦いで敗北していた場合のみ、ヒロイン５ルートへ


[if exp={getFlagValue("Selectflg2") == 1 }]
[jump target="*root_1"]
[endif]

[jump target="*root_5"]


*root_1
[jump storage="ep003.ks" target="*start"]


*root_5
[jump storage="ep004.ks" target="*start"]


*select03_lose
*root_4
[jump storage="ep005.ks" target="*start"]


