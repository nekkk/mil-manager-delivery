
;//==============================
;//３、シャルティエ

*start

*ep004
*IseSel08_3|Peace. Chartier

[SCENE id=4]


The Chartier thing came to mind.
[cpg]


Chartier has an ideology that is far from peaceful.
[cpg]


In fact, I think it's a good idea for a demon king to conquer the world.
[cpg]


But for some reason, it was Chartier that came to mind.
[cpg]



;//ブラックアウト
[window target=false]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]

[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************

[window target=true]




[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye188"]
[OnName num="schartye"]
What is it?　What do you want from me?
[cpg cn=true]


[OnName num="kousuke"]
I want to talk to you about ....... Okay?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye189"]
[OnName num="schartye"]
Yeah. No problem. What's going on?
[cpg cn=true]


[OnName num="kousuke"]
I still want peace. I don't care if I'm not a demon king anymore, there has to be a way.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

Chartier looked a little bitter.
[cpg]


[OnName num="kousuke"]
I'm sure you'll be able to understand why. You probably want to take over the world, don't you?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye190"]
[OnName num="schartye"]
Well. For me, the greatest wish was to revive the Demon Lord.
[cpg cn=true]


I'm sure you'll be able to understand why.
[cpg]


Chartier must have mixed feelings about this.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye191"]
[OnName num="schartye"]
"There's a way to do that. There's a way to separate the Demon Lord's power from the Demon Lord himself."
[cpg cn=true]


[OnName num="kousuke"]
"Is that so?　If you can do that: ......"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye192"]
[OnName num="schartye"]
But I don't want to do that. As you know, it's a long-cherished wish.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye193"]
[OnName num="schartye"]
...... Don't let anyone ask you any more questions. Would you like to come into my room?
[cpg cn=true]


[OnName num="kousuke"]
Oh, yeah, ......."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


Then we head to Chartier 's room.
[cpg]



[SE f="se004"]
;//【ＳＥ】『ドア閉まる』


[BG f="b_06_4_l.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************



[FG f="CHA03_p7_01_a.ui" method="change_1"  pos="2/3" time=800]
As soon as Chartier entered the room, he grabbed my hand.
[cpg]


[OnName num="kousuke"]
"What the hell, Chartier ......?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Schartye194"]
[OnName num="schartye"]
"Don't you understand? I want you to be a master to me.
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]

I think it's because I'm the Demon Lord. Maybe he wants to be enchanted by me.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//Ｈシーンカット

And so we stayed together for a while. However, it was not possible to enjoy the time alone with him ...... forever.
[cpg]

A little while later. I had gathered everyone in my room.
[cpg]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]




[FG f="CHA04_p5_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Clolowlude244"]
[OnName num="clolowlude"]
"Throwing away the power of the Demon Lord ......?　Are you insane?
[cpg cn=true]


[OnName num="kousuke"]
I am sane.
[cpg cn=true]


I don't think I really want to live my life as a Demon Lord.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Fia301"]
[OnName num="fia"]
I'm for it. This country has flourished thanks to the power of the Demon Lord, but on the contrary, it is threatened by the power of the Demon Lord.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="sFia029"]
[OnName num="fia"]
And because the ...... Demon Lord is dangerous, he's being targeted.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Meile346"]
[OnName num="meile"]
What about Chartier , do you agree ......?"
[cpg cn=true]


[free time=800]

Chartier became a little silent. But then ......
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Schartye216"]
[OnName num="schartye"]
"I'm willing to fulfill ...... the Demon Lord's wishes," he said.
[cpg cn=true]


He said. It seems that Chartier has no choice but to help me get rid of the demon king's power.
[cpg]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[STOPBGM]


However, it would later become clear that Chartier was not just trying to get rid of the power .......
[cpg]

[WAIT time=500]

[BG f="b_06_3.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





Of course, it cannot be disclosed to the public. Everything was done in secret.
[cpg]


It was decided that Chartier , who is skilled in magic, would create all the techniques.
[cpg]


The power of the demon king was stripped away. What would happen after that, Chartier said he did not know.
[cpg]


He said that maybe only the remaining power of the Demon Lord would go out of control.
[cpg]


Even if not, there is no telling what will happen to the country if the Demon Lord is lost.
[cpg]


Even so,......, I didn't want to live in danger anymore.
[cpg]

*effect|Peace. Chartier

;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=1500]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************

[window target=true]



[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye217"]
[OnName num="schartye"]
"Are you sure about this? Demon Lord, if you activate this technique, you will no longer be a Demon Lord.
[cpg cn=true]


[OnName num="kousuke"]
"I have no more doubts. Do it.
[cpg cn=true]

;//[move from="2/3" to="2/2" ease="easeInOutSine" time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Fia302"]
[OnName num="fia"]
...... We'll be there. We will be there, Kullulu and Mr. Wurde will be at .......
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="3/3" time=800]
[VOICE f="Clolowlude245"]
[OnName num="clolowlude"]
Of course. It's unheard of. You never know what might happen.
[cpg cn=true]


So, Fia , Kullulu , and Chartier agreed to be there.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
[STOPBGM]

;//ブラックアウト


[BG f="e_01_1.ui" time=1000]



We headed to a large room with a magic circle drawn on it. I stood in the center of it.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="3/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Schartye218"]
[OnName num="schartye"]
I stood in the center.
[cpg cn=true]


Then Chartier chanted a spell.
[cpg]



[SE f="se005"]
;//【ＳＥ】『魔法の音　低め』



;//画面徐々に白く
[FG f="e_02_2.ui" method="change_1"  pos="3/5" time=1]
[WAIT time=2000]

[BGM f="bg_ma"]




The magic circle glows. The magic circle glows, and I feel a creeping sensation throughout my body.
[cpg]


Then I felt as if something was slipping out of my body.
[cpg]


;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[transition target={true} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=1100]

[free time=1]
[BG f="e_01_3.ui" time=1]
[WAIT time=10]




I fall down involuntarily. Above my head, I saw ......
[cpg]


[transition target={false} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=1500]



There was a black sphere floating above me, bubbling away.
[cpg]


[SE f="se008"]
;//【ＳＥ】『歩く』

[FG f="CHA03_p5_01_a.ui" method="change_3"  pos="2/3" time=1000]

[WAIT time=1500]

;//[FACE method="change_5" pos="1/3"]
;//[FACE method="change_7" pos="3/3"]

And then Chartier came closer to me.
[cpg]

[move from="2/3" to="1/2" ease="easeInOutSine" time=1000]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="4/4" time=800]
;//[FACE method="change_3" pos="3/3"]

[VOICE f="Clolowlude246"]
[OnName num="clolowlude"]
"Hey!　 Chartier , what are you doing?
[cpg cn=true]

[FACE method="change_3" pos="1/2"]
[FACE method="change_5" pos="4/4"]
;//[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/4" time=800]
[VOICE f="Schartye219"]
[OnName num="schartye"]
"Don't you see? This is what you do."
[cpg cn=true]


[free time=800]

Chartier approaches the sphere. Then you hold your hand over it.
[cpg]




[SE f="se013"]
;//【ＳＥ】『触手絡みつく』
[WAIT time=1500]

When it touched the fingers of the Chartier , a black thing tangled from the fingers to the whole body.
[cpg]



;//画面まだらに黒く
[window target=false]
[transition target={true} rule="dark.webp" color={0x550055ff} time=1000]
[WAIT time=2100]
[transition target={false} rule="dark.webp" color={0x550055ff} time=1000]
[WAIT time=1500]


[window target=true]



[FG f="CHA03_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Schartye220"]
[OnName num="schartye"]
"Ugh. ......"
[cpg cn=true]

[free time=800]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

This time, Chartier collapsed. Fia rushed over to him.
[cpg]



[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="1/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/2" time=800]

[VOICE f="Fia303"]
[OnName num="fia"]
" Chartier -san!　What did you do?
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Schartye221"]
[OnName num="schartye"]
If you interfere with my ...... wish, I'll show you no mercy.
[cpg cn=true]


A wish. What's her wish, ......?
[cpg]

[free time=1000]
[WAIT time=1000]

[FG f="CHA03_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Schartye222"]
[OnName num="schartye"]
"If I ...... become the Demon Lord, all will be well."
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************






;//……それから。全てはフィアの口から明かされた。
I passed out in the middle of the sealing process, and after I woke up, Fia and the others told me what had happened.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia304"]
[OnName num="fia"]
"The Demon Lord's power was assumed by Chartier."
[cpg cn=true]


[OnName num="kousuke"]
I don't understand ....... Can you explain more?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia305"]
[OnName num="fia"]
I don't understand Chartier . Please explain more." "Right now, is the one who has the power as the Demon Lord. Kosuke is back to being just a person.
[cpg cn=true]


[OnName num="kousuke"]
How is that possible?
[cpg cn=true]


[free time=800]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/2" time=800]

[VOICE f="Clolowlude247"]
[OnName num="clolowlude"]
It is possible. It's possible. That was the magic circle from the beginning. ...... I didn't notice that at all."
[cpg cn=true]


Kullulu I'm not going to get into the details of magic.
[cpg]


I don't know the details of magic. I don't know much about magic, but if it's possible ......
[cpg]


If Chartier had been trying to do that for a long time, they could have done it from the beginning, couldn't they?
[cpg]


[STOPBGM]

;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************




[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/2" time=1]

After that, I went back to my room with an unsettled mind.
[cpg]

[move from="4/2" to="2/3" ease="easeInOutSine" time=1000]

Then Chartier came in.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye223"]
[OnName num="schartye"]
You don't look happy, do you? Kosuke "
[cpg cn=true]


[OnName num="kousuke"]
...... You don't call me "Demon Lord" anymore, do you?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye224"]
[OnName num="schartye"]
"Of course. From now on, I will reign as the Demon Lord. I have no objection.
[cpg cn=true]


Chartier originally possessed a considerable amount of magical power.
[cpg]


You can imagine that if the power I had was added to it, I would be unbeatable.
[cpg]


[OnName num="kousuke"]
I'm sure you'll be able to understand why.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye225"]
[OnName num="schartye"]
"It's not that simple. It's not that easy, and you couldn't have done it unless Kosuke you wanted to give up your power.
[cpg cn=true]


It's a good idea to have a good idea of what you're looking for.
[cpg]


It's a good idea to have a good idea of what you're looking for.
[cpg]

[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=2000]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[window target=true]


[SE f="se011"]
;//【ＳＥ】『人混み』(喧騒、ガヤガヤ)

But I never left the land of the Demon King.
[cpg]


The new Demon King, Chartier , has gained tremendous support.
[cpg]


Chartier In the event that you've got any questions regarding where by and how to use the internet, you'll be able to contact us at our own web site.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia306"]
[OnName num="fia"]
"Doesn't ...... make sense to you?"
[cpg cn=true]


[OnName num="kousuke"]
"No, I don't understand what ...... Chartier is going through."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia307"]
[OnName num="fia"]
"Maybe Chartier is a rather honest person."
[cpg cn=true]


[OnName num="kousuke"]
"What do you mean?"
[cpg cn=true]


I asked, but Fia did not answer.
[cpg]



[BG f="b_05_3.ui" time=1000]

[WAIT time=1500]
;//【ＢＧ】『城下町＿魔王の国』（夕方）******************************************************


[SE f="se011"]
;//【ＳＥ】『人混み』(喧騒、ガヤガヤ)


In the evening, the city was still in a festive mood.
[cpg]


I don't know if subhumans like to celebrate or not.
[cpg]


But I'm so happy that a new demon king has taken over. ......
[cpg]


[OnName num="kousuke"]
"My people were never there in the first place. ......?"
[cpg cn=true]


That's what I was saying to myself. The one who heard it was.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Schartye226"]
[OnName num="schartye"]
"No. I guess I'm just too good for the job.
[cpg cn=true]


[OnName num="kousuke"]
"What? You're here, Chartier ."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye227"]
[OnName num="schartye"]
"That's my line. You're not leaving the country, are you, Kosuke ?
[cpg cn=true]


[OnName num="kousuke"]
Well, ...... has no place in Japan anymore.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye228"]
[OnName num="schartye"]
Then you should be happy. I'll make you my servant.
[cpg cn=true]


...... I knew he would say something like that.
[cpg]


I'm attracted to Chartier . I'm sure you're aware of that.
[cpg]



;//ブラックアウト
[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_4.ui" time=1000]

[WAIT time=1500]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye229"]
[OnName num="schartye"]
It's a little too big a room for you ...... who is not a demon king.
[cpg cn=true]


[OnName num="kousuke"]
What's that? What? I thought you were going to let me live in this castle.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye230"]
[OnName num="schartye"]
Yes, you can live in this room.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye231"]
[OnName num="schartye"]
But my room will be more luxurious. But my room will be more luxurious. It's not a good example.
[cpg cn=true]


[OnName num="kousuke"]
...... I see.
[cpg cn=true]


I guess Chartier is really going to reign as a demon king.
[cpg]


In fact, I'm still thinking about that .......
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye232"]
[OnName num="schartye"]
Now, my first task as a servant. Kosuke "
[cpg cn=true]


So said Chartier , sitting on the bed. And then he said.
[cpg]


[FG f="CHA03_p7_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSchartye022"]
[OnName num="schartye"]
You may kneel. As a sign of my service."
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


I had no reason to refuse. I had no reason to refuse, but then again, Chartier should have no reason to be attracted to me anymore.
[cpg]


I wondered, but I went along with what Chartier said.
[cpg]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[VOICE f="sSchartye023"]
[OnName num="schartye"]
"Yeah, that's fine. Phew."
[cpg cn=true]

[free time=1000]

[BG f="black.ui" time=1000]
[WAIT time=100]

[VOICE f="sSchartye024"]
[OnName num="schartye"]
"Right, now, ......."
[cpg cn=true]

;//========================================
;//●ＣＧ（ベッドに仰向けになっているヒロイン）ev_39
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城内＿主人公の部屋
;//時間　：夜
;//========================================

*Scene031

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]
;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_39_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sSchartye025"]
[OnName num="schartye"]
"I want you to hold me. Can you do that?"
[cpg cn=true]


As she said this, she was on her back on the bed.
[cpg]

She was so sexy now, it was harder to tell her not to hug me.
[cpg]

[OnName num="kousuke"]
It's ....... Oh no."
[cpg cn=true]

I couldn't help but say that, but Chartier looked a little puzzled.
[cpg]

[VOICE f="sSchartye026"]
[OnName num="schartye"]
That's what I've been waiting for. It's something I've been waiting for.
[cpg cn=true]

He looked away a little as he said this. That's a shame.
[cpg]

[OnName num="kousuke"]
I meant to say, "That's no big deal."
[cpg cn=true]

I corrected him, and Chartier smiled.
[cpg]

;**【ＣＧ】 ev_39_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sSchartye027"]
[OnName num="schartye"]
"Hmm. Then it's easy.
[cpg cn=true]

[VOICE f="sSchartye028"]
[OnName num="schartye"]
"I'll take that as a sign of your loyalty. Come on."
[cpg cn=true]

I moved closer to her as she lay on the bed.
[cpg]

I just hugged her. No kissing, just a hug.
[cpg]

I was comfortable with this distance.
[cpg]

;//Ｈシーンカット


;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]


Chartier stares at me. Her gaze is even more piercing than before.
[cpg]

No, sharp is the wrong word. It's scary and beautiful.
[cpg]

[OnName num="kousuke"]
"...... Chartier , you're so beautiful.
[cpg cn=true]


[FG f="CHA03_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Schartye255"]
[OnName num="schartye"]
"I'm sure you are. My good looks have charmed many a man.
[cpg cn=true]


She said confidently. You've always had that personality.
[cpg]


[OnName num="kousuke"]
Does Chartier still love me?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye256"]
[OnName num="schartye"]
Of course. If they didn't, they wouldn't be asking for Kosuke ."
[cpg cn=true]


[OnName num="kousuke"]
I don't know, I guess. I'm not a demon king anymore, so I have no reason to like you.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye257"]
[OnName num="schartye"]
I'm not a demon king anymore, so there's no reason to like me. I'm sure we'll have another chance to talk about it.
[cpg cn=true]


Say something you don't understand. Is it a story that can't be told right away?
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Schartye258"]
[OnName num="schartye"]
For now, can you just accept that I love Kosuke ?
[cpg cn=true]


Chartier This is the first time that I've ever seen such a thing.
[cpg]



;//Ｈシーンカット


;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************





After that, Chartier is in charge of the politics of the demon king's country.
[cpg]


It's not just politics, it was originally military as well.
[cpg]


All the power in this country is concentrated in Chartier .
[cpg]


However, she does not force her troops to march.
[cpg]


Although it is peaceful, Chartier 's life may be in danger .......
[cpg]


[OnName num="kousuke"]
"...... Chartier . Is this what you want?"
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye279"]
[OnName num="schartye"]
"Don't worry about it. It's better for Kosuke to take on that role than to be frightened and unable to sleep.
[cpg cn=true]


When I heard that, I realized something.
[cpg]


[OnName num="kousuke"]
So that's what ...... you mean.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye280"]
[OnName num="schartye"]
"So that's what this is all about." "You finally noticed?　I really like Kosuke ."
[cpg cn=true]


Could it be that Chartier cares about me more than anyone else? No, I'm sure he does.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye281"]
[OnName num="schartye"]
If the power of the demon king had been sealed away, Kosuke would have remained king.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye282"]
[OnName num="schartye"]
Of course, the threat to his life is not as great as before, but I can imagine the responsibility that remains.
[cpg cn=true]


[OnName num="kousuke"]
Did ...... Chartier take care of everything?
[cpg cn=true]


[free time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Clolowlude248"]
[OnName num="clolowlude"]
It's too late to find out. Chartier is pretty single-minded."
[cpg cn=true]


[OnName num="kousuke"]
Oh, ...... Kullulu , there you are.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye283"]
[OnName num="schartye"]
"Don't say that too much. Kullulu Urud."
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude249"]
[OnName num="clolowlude"]
"Let me tell you something. He's too insensitive.
[cpg cn=true]


I've been called "this guy". But I might have been too insensitive.
[cpg]



;//ブラックアウト
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_3.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夕方）******************************************************





[OnName num="kousuke"]
...... I'm sorry, man. I didn't realize it until now."
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Schartye284"]
[OnName num="schartye"]
It's okay. And I just did what I wanted to do."
[cpg cn=true]


You may be right. But the thing that you want to do is probably to love me.
[cpg]


I feel like I have no way to describe it. I'm sorry, I love you, it's a strange feeling.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye285"]
[OnName num="schartye"]
I've just finished ...... work. I've got a new room in my house that I want you to take a look at.
[cpg cn=true]


[OnName num="kousuke"]
"...... Oh."
[cpg cn=true]



[SE f="se002"]
;//【ＳＥ】『ドア開く』



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





The Chartier room was certainly more luxurious than my room.
[cpg]


[OnName num="kousuke"]
It's the kind of room ...... one person can't have.
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye286"]
[OnName num="schartye"]
Yeah. Do you want Kosuke to sleep here, too?
[cpg cn=true]


[OnName num="kousuke"]
Are you sure?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Schartye287"]
[OnName num="schartye"]
Of course. I'd like to be around Kosuke as much as possible.
[cpg cn=true]


...... really is very straightforward. Your attitude is different from before.
[cpg]


[OnName num="kousuke"]
"I'm not a servant?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye288"]
[OnName num="schartye"]
I think I may have said something like that to you, .......
[cpg cn=true]


I think it's pretty recent, though. But okay.
[cpg]


If Chartier loves me, I want to respond.
[cpg]

;//Ｈシーンカット

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト



It was dusk. Me and Chartier were sitting on the bed together.
[cpg]



[VOICE f="Schartye309"]
[OnName num="schartye"]
" Kosuke . Look at me."
[cpg cn=true]


[OnName num="kousuke"]
"What ......?　Yeah.
[cpg cn=true]



;//========================================
;//●ＣＧ（キス。ベッドに腰掛けている）ev_42
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城内＿ヒロイン３の部屋
;//時間　：夕方
;//========================================

*Scene012

[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_42_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=100]



Chartier kissed me. It's very aggressive.
[cpg]


I'm sure you've already done more than that.
[cpg]



[VOICE f="Schartye310"]
[OnName num="schartye"]
"Will you always love me, ......?"
[cpg cn=true]


[OnName num="kousuke"]
Yeah. Of course.
[cpg cn=true]


[VOICE f="Schartye311"]
[OnName num="schartye"]
I've done some selfish things, considering.
[cpg cn=true]


[OnName num="kousuke"]
That's not true. I know you're thinking about me.
[cpg cn=true]


When I say that, Chartier looks embarrassed.
[cpg]

;**【ＣＧ】 ev_42_a ***********************
[CG id=11 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Schartye312"]
[OnName num="schartye"]
It's hard to ...... answer that immediately.
[cpg cn=true]


I think I understand what Kullulu was saying about Chartier being single-minded.
[cpg]


[OnName num="kousuke"]
"Well, it doesn't matter what. From now on, Chartier is the demon king ...... or something, that's more appropriate.
[cpg cn=true]



[VOICE f="Schartye313"]
[OnName num="schartye"]
"Maybe so. Maybe Kosuke is not really a demon king. You're too kind.
[cpg cn=true]


[OnName num="kousuke"]
You're telling me, .......
[cpg cn=true]



[VOICE f="sSchartye029"]
[OnName num="schartye"]
It's actually kind. I've had my fair share of selfishness.
[cpg cn=true]


[OnName num="kousuke"]
I don't think you're being selfish. It's my Chartier ."
[cpg cn=true]

;**【ＣＧ】 ev_42_b ***********************
[CG id=11 index=2 time=1000]
;***************************************
[WAIT time=100]

I don't think it's selfish. It's my Chartier ." Hearing me say this, purses his lips again.
[cpg]



[VOICE f="Schartye315"]
[OnName num="schartye"]
I don't think you're being selfish.
[cpg cn=true]


He doesn't put his tongue in. After such a kiss, I say.
[cpg]



[VOICE f="Schartye316"]
[OnName num="schartye"]
I'm sure you'll be pleased to know that Kosuke is my Kosuke .
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



;//ＥＮＤ　ヒロイン３平和ルート

[WAIT time=100]
[jump storage="epend.ks" target="*start"]
[WAIT time=100]
;[s]
[WAIT time=100]
[WAIT time=100]

