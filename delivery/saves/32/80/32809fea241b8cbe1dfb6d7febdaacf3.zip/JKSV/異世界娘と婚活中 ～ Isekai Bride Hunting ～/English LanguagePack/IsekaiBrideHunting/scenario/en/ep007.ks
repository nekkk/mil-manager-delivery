
;//==============================
;//３、ヒロイン３

*start

*ep007
*IseSel09_3|Demon king. Chartier

[SCENE id=7]


I thought of Chartier .
[cpg]


I could say that she was the only one for me. I could say that I had met her before Fia or Meir .
[cpg]



;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye352"]
[OnName num="schartye"]
"What's wrong?　"What's wrong, Demon Lord?"
[cpg cn=true]


That's why I invited Chartier to my room.
[cpg]


[OnName num="kousuke"]
I've decided to conquer the ...... world. I've decided to conquer the world and I need your wisdom to do it."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye353"]
[OnName num="schartye"]
"Hmm. That's what the demon lord said before his ...... rebirth.
[cpg cn=true]


[OnName num="kousuke"]
I've always wondered if you knew me before my reincarnation.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye354"]
[OnName num="schartye"]
That's right. I've been wondering if you knew me before I was reincarnated. - That's right. I saw how the pre-reincarnation Demon Lord connected the other world with this one.
[cpg cn=true]


[OnName num="kousuke"]
...... You mean the pre-reincarnation me. Why did you do it?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye355"]
[OnName num="schartye"]
It's not enough to just conquer the other worlds of the past. ...... In a nutshell, yes. There are many more reasons.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye356"]
[OnName num="schartye"]
But in order to connect this world with the other world, I had to expend too much magic power. My body just couldn't take it anymore."
[cpg cn=true]


At that moment, he was reincarnated as a human being, or Kosuke , and carried his ambition to fulfill it over to the next generation.
[cpg]


[OnName num="kousuke"]
"So that's what happened. ......"
[cpg cn=true]


I was a pretty gutsy guy before my reincarnation. I can't believe I have ambitions that I want to fulfill even after dying.
[cpg]


The fact that I want it now after all seems to be some kind of fate.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye357"]
[OnName num="schartye"]
Now, if you want to take over the world, you're going to need more troops than this.
[cpg cn=true]


[OnName num="kousuke"]
That's the way it's going to be. Do you have any idea?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Schartye358"]
[OnName num="schartye"]
...... You know what I mean, Demon Lord. I can't tell you what to do without anything."
[cpg cn=true]


Chartier stains her cheeks. It seems that I need to satisfy her.
[cpg]


[OnName num="kousuke"]
I'll do whatever you want. What do you want?　I'll do whatever you want.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]


[VOICE f="sSchartye030"]
[OnName num="schartye"]
"Then I need a favor."
[cpg cn=true]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="CHA03_p7_01_a.ui" method="change_6"  pos="2/3" time=1000]
[BG f="b_06_4_l.ui" time=1000]
[WAIT time=1500]


She said and closed her eyes. I knew what she meant, but I was confused.
[cpg]

[VOICE f="sSchartye031"]
[OnName num="schartye"]
What is it? You're not going to do it?
[cpg cn=true]

[OnName num="kousuke"]
"No, no. I will."
[cpg cn=true]

I kissed her on the mouth. I must have been waiting for this moment for a long time.
[cpg]



[STOPBGM]

[WAIT time=1500]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[window target=true]


Then, the next afternoon.
[cpg]


[OnName num="kousuke"]
"Hey. I thought you were going to help me.
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye379"]
[OnName num="schartye"]
Wait a minute. I still have something to tell the Demon Lord.
[cpg cn=true]


[OnName num="kousuke"]
What do you mean, "something I want to tell him?" ......
[cpg cn=true]


We had come to the outskirts of the castle town.
[cpg]


The further we went, the further there was no more road.
[cpg]


[OnName num="kousuke"]
"Where are you taking me, Chartier ?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye380"]
[OnName num="schartye"]
"Just follow me. I'll show you where."
[cpg cn=true]


We walked some more. We walk further and further until we reach the edge of the city.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_13_4.ui" time=1000]
[WAIT time=1500]



And then you'll go into a cave like place Chartier .
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Schartye381"]
[OnName num="schartye"]
It's a place that I remember with the former ...... Demon Lord before his reincarnation.
[cpg cn=true]


[OnName num="kousuke"]
"This is it?　It looks like just a cave.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye382"]
[OnName num="schartye"]
In the past, I was a difficult child. I used to run away from home all the time.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye383"]
[OnName num="schartye"]
I ran away from home, and I was crying here, and the Demon Lord found me.
[cpg cn=true]


Did ...... Chartier live near the former land of the beastmen? How is that not the main topic?
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sSchartye032"]
[OnName num="schartye"]
It's not the main point. "I and the former Demon Lord were lovers. It was platonic, though."
[cpg cn=true]


That's a strange story. That's a strange story, it's different from what I've heard so far.
[cpg]



[OnName num="kousuke"]
The previous Demon Lord was not a womanizer? Platonic? That's weird.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye385"]
[OnName num="schartye"]
It's not for me to say, but ...... I guess I was special. And I was very young.
[cpg cn=true]


[OnName num="kousuke"]
You're talking about ...... finally getting his wish now?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Schartye386"]
[OnName num="schartye"]
Yeah. It's the demon king .......
[cpg cn=true]


I have a pretty good idea what Chartier wants.
[cpg]


I wanted to respond to him. But I just couldn't muster up the courage.
[cpg]



[SE f="se005"]
;//【ＳＥ】『魔法の音』


[WAIT time=1500]


I cast a spell. I thought about what she needed right now.
[cpg]



;//========================================
;//●ＣＧエロ（スライム姦。ヒロイン嫌がっていない感じ）ev_63
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：スライム　　服装ex：無し
;//場所　：洞窟
;//時間　：昼
;//備考　：公式サイト二枚目のＣＧです
;//========================================

*Scene052

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_63_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=100]




[VOICE f="sSchartye033"]
[OnName num="schartye"]
What do you mean, "......"?　I'm not asking for this.
[cpg cn=true]

[OnName num="kousuke"]
"Well, listen to me. This slime is specially made.
[cpg cn=true]

[OnName num="kousuke"]
It is the slime of sleep, and it will give you the most convenient dreams. It's so good, you won't even remember it was a dream.
[cpg cn=true]

[VOICE f="sSchartye034"]
[OnName num="schartye"]
Why don't you just ...... give me a hug?
[cpg cn=true]

That's not very brave. I don't think she'll be happy to hear you say that.
[cpg]

[VOICE f="sSchartye035"]
[OnName num="schartye"]
"Oh, ......, ......."
[cpg cn=true]

Little by little, Chartier's expression became more and more depressed. I'm sure she's hugging me in her dreams right now.
[cpg]

I'm disgusted with myself for not being good enough, but I can't help it. ......
[cpg]

;**【ＣＧ】 ev_63_a ***********************
[CG id=16 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sSchartye036"]
[OnName num="schartye"]
......
[cpg cn=true]

And she seems to have completely let go of her consciousness.
[cpg]

A look of peace. And she loses the memory of having done this to her.
[cpg]

[OnName num="kousuke"]
I'm sorry."
[cpg cn=true]

I'm sorry," she said, "but I can't keep fooling around like this.
[cpg]

I knew I had to accept the love of Chartier head on.
[cpg]



;//ブラックアウト




[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1]


The next day, a night passed. The next day, me and Chartier had gathered the remaining three people.
[cpg]

[STOPBGM]
[WAIT time=1000]

[window target=false]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Schartye412"]
[OnName num="schartye"]
We're going to invade the land of the elves. That's what the Demon Lord has decided."
[cpg cn=true]



[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Fia600"]
[OnName num="fia"]
I'm against it. As a former citizen, I cannot allow that to happen.
[cpg cn=true]


[OnName num="kousuke"]
"Even if Fia doesn't allow it, I will. That's not the point.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Meile542"]
[OnName num="meile"]
But I'm curious about the difference in strength. ...... Do you have a chance of winning?
[cpg cn=true]


Meir turned to Chartier . nodded. Chartier I'm going to do it.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye413"]
[OnName num="schartye"]
"That's right. The other worlds that have merged with this world have merged completely, but ......"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye414"]
[OnName num="schartye"]
But there is another world, the underworld.
[cpg cn=true]


I just heard that too. It is a third world, different from the two merged worlds.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude272"]
[OnName num="clolowlude"]
That's where I'm from, too. I'm from there, too. There are subhumans living in the underworld. ......
[cpg cn=true]


[OnName num="kousuke"]
Maybe they'll follow me.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Fia601"]
[OnName num="fia"]
You're going in with something you're not sure of?
[cpg cn=true]


[OnName num="kousuke"]
I'm not sure, so I'll just try. It's only after that that we go on the offensive.
[cpg cn=true]


That's what I said, and I told everyone my intentions.
[cpg]


I will conquer the world. I'm going to conquer the world.
[cpg]


I'm going to conquer the world, and I'm going to do it so that Chartier and I can live happily ever after without anyone trying to kill us.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************



[SE f="se08"]
;//【ＳＥ】『歩く』

[WAIT time=1000]




At night, I was walking around the castle, unable to sleep.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye415"]
[OnName num="schartye"]
"Demon Lord. You can't sleep either?"
[cpg cn=true]


[OnName num="kousuke"]
" Chartier ...... you can't sleep either?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye416"]
[OnName num="schartye"]
"Well, yeah. The reason for this is different for the Demon Lord and me.
[cpg cn=true]


Chartier has a flushed face. It's a good idea to have a good time.
[cpg]


[OnName num="kousuke"]
"Chartier. If you can't sleep, I can distract you with ......."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]


With a flushed face, Chartier nodded.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_06_4_l.ui" time=1000]
[WAIT time=1500]



I walked into Chartier 's room. I could have summoned the slime again, but ......
[cpg]


You can't fake it forever. I can't fake it, and neither can I fake my own feelings.
[cpg]






;//ブラックアウト




[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]


[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




My love for Chartier has only deepened. In the meantime, there is a movement to tear us apart.
[cpg]


Before we invaded, there was talk of the elven nation marching in.
[cpg]


It's a good idea to have a good idea of what you're looking for.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





It's also a good idea to have a good idea of what you're doing.
[cpg]


Fia is not in favor of fighting. The three of us, Chartier , Kullulu and I, will study the magic.
[cpg]


Finally, after several ...... days and nights, we finally did.
[cpg]



[SE f="se006"]
;//【ＳＥ】『魔法の音　衝撃波』



;//フラッシュ
[window target=false]
[transition target={true} rule="cube.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


[transition target={true} rule="cube.webp" color={0xffffffff} time=1]
[WAIT time=100]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0xffffffff} time=1000]
[WAIT time=1500]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]





In the center of the magic circle, there was a humanoid shadow.
[cpg]


It's not a simple life form, like tentacles or slime.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Clolowlude273"]
[OnName num="clolowlude"]
...... Looks like it worked.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]

[VOICE f="Schartye439"]
[OnName num="schartye"]
"Yeah. Hey, you. Do you know who this person is?
[cpg cn=true]


[OnName num="devil_woman"]
You're ....... Maybe you're .......
[cpg cn=true]


Chartier and Kullulu are looking at me.
[cpg]


[OnName num="kousuke"]
"I'm ....... I'm the Demon Lord.
[cpg cn=true]


I guess I'll just have to call myself this. As I was thinking this, the summoned demon knelt down to me.
[cpg]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[BGM f="bg_d3"]




So, I had to summon a subhuman from the underworld.
[cpg]


Without anyone noticing, I gradually increase my troops.
[cpg]


All the while, my pheromones were mesmerizing the people around me.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye440"]
[OnName num="schartye"]
"......, Demon Lord. It seems that your summoning from the underworld is going well."
[cpg cn=true]


[OnName num="kousuke"]
Yeah. If you're a woman, it's a bit of a problem that you're attracted to me. ......
[cpg cn=true]


But it helps to know that they will follow me without fail.
[cpg]


Even men wouldn't have disobeyed me if they knew I was the Demon Lord.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye441"]
[OnName num="schartye"]
I think about it sometimes. I sometimes wonder if the Demon Lord will always love me.
[cpg cn=true]


[OnName num="kousuke"]
"Don't doubt that. It's nothing to be concerned about.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye442"]
[OnName num="schartye"]
Do you think so?　Then let me prove it to you.
[cpg cn=true]




When you put it like that, I can't help but do something.
[cpg]

[OnName num="kousuke"]
I think about it sometimes, too. I sometimes wonder how much Chartier likes me.
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_06_4_l.ui" time=1000]
[WAIT time=1500]


[OnName num="kousuke"]
"Will you love anything I summon?"
[cpg cn=true]

[VOICE f="sSchartye037"]
[OnName num="schartye"]
Yeah. I'll accept anything you do, Demon Lord.
[cpg cn=true]

[OnName num="kousuke"]
You said it."
[cpg cn=true]

As I watched her nod, I cast a spell.
[cpg]





;//========================================
;//●ＣＧ（ヒロインの体を蜘蛛が這う）ev_64
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：蜘蛛　　　　服装ex：無し
;//人ex２：主人公　　　服ex２：着衣
;//場所　：城内＿主人公の部屋
;//時間　：夜
;//========================================

*Scene054

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

[WAIT time=1000]
[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』

[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_64_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=100]



I wondered if she really wouldn't mind whatever I did to her.
[cpg]

It's not really an experiment, but I wanted to try it.
[cpg]

[VOICE f="sSchartye038"]
[OnName num="schartye"]
"What are you thinking, ......, Demon Lord?
[cpg cn=true]

[OnName num="kousuke"]
What do you mean, she'll accept anything I do?
[cpg cn=true]

[VOICE f="sSchartye039"]
[OnName num="schartye"]
Yeah. I do. ......
[cpg cn=true]

A spider crawls over her body.
[cpg]

[OnName num="kousuke"]
You know this spider, right?　It's a demon.
[cpg cn=true]

[OnName num="kousuke"]
I'm sure you've heard of them. You'll be glad to know that Chartier also uses magic.
[cpg cn=true]

[VOICE f="sSchartye040"]
[OnName num="schartye"]
"Of course, ...... I'm fine with this."
[cpg cn=true]

The way she said she was fine, I could tell she was not fine.
[cpg]

But still, he is trying hard to endure. It's a lovely person.
[cpg]

;**【ＣＧ】 ev_64_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sSchartye041"]
[OnName num="schartye"]
If you want to solve the ...... stagnation of magic power, shall we do the same to the demon king later?
[cpg cn=true]

[OnName num="kousuke"]
No, no, no. I'm good.
[cpg cn=true]

I'm fine with that. Chartier is a bit nasty.
[cpg]

I love the fact that this power relationship is not so easily changed.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]


And then. I made the Demon King's army stronger. I recruited helpers from the underworld.
[cpg]


As a result, the Demon Lord's army was growing in number.
[cpg]


No one could notice it. If I may say so, this development would be unexpected for any country.
[cpg]


I think that the elven nation must have some slack in their minds.
[cpg]


[STOPBGM]


[window target=false]


[transition target={true} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1500]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1500]
[BGM f="bg_si"]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************

[window target=true]




[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye469"]
[OnName num="schartye"]
...... Tomorrow, the battle will begin, won't it?
[cpg cn=true]


[OnName num="kousuke"]
"Yes. But I have no doubts.
[cpg cn=true]


[OnName num="kousuke"]
Kill them before they kill us. It's the only way.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye470"]
[OnName num="schartye"]
Take it easy. We're the ones who have to get our hands dirty.
[cpg cn=true]


[OnName num="kousuke"]
Sorry, ....... Chartier
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Schartye471"]
[OnName num="schartye"]
Don't worry about it. It's all because I love you, the Demon Lord.
[cpg cn=true]

[free time=800]

[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Clolowlude274"]
[OnName num="clolowlude"]
What a good mood you two are getting into. It's not like it's the night before the battle.
[cpg cn=true]


[OnName num="kousuke"]
You're here, Kullulu .
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Clolowlude275"]
[OnName num="clolowlude"]
Yeah. The soldiers all think they can win. Maybe you should inspire them in person, Demon Lord.
[cpg cn=true]


[OnName num="kousuke"]
"...... Yes."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]



I decided to inspire them directly in front of the soldiers.
[cpg]


They all seemed to have a lot of blood in their veins and were listening to my words with fervor and stillness.
[cpg]


[OnName num="kousuke"]
We will reclaim our world!　We're going to make the world of subhumans again!"
[cpg cn=true]


Still, I shouted, and the soldiers shouted. I heard a voice that sounded like the earth shaking back.
[cpg]


I think I've finally reached a point where I can't turn back. But this is good.
[cpg]


It's what Chartier wants, too. So this is what ......
[cpg]


[STOPBGM]

[window target=false]


[transition target={true} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_tc"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************

[window target=true]




And so we invaded the land of the elves.
[cpg]


Of course, I'm not talking about me taking the lead or anything like that.
[cpg]


I'm not talking about me taking the lead, of course. Chartier She won't even be on the front lines.
[cpg]


There is also a difference in military strength. In the unlikely event that Chartier or I fall.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





It's a good idea to have a good idea of what you're looking for.
[cpg]


They must have thought that it was a declaration of war and that they could be attacked at any time.
[cpg]


[STOPBGM]

[BG f="b_09_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_de"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************





But I had built up enough of an army to conquer the land of the elves.
[cpg]


If I did this, it would be war at last, but I didn't mind.
[cpg]


I knew why dictators around the world liked to invade.
[cpg]


In other words, I knew what it was like to have your life threatened.
[cpg]


What it means to have the whole world as your enemy. I thought I knew. ......
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Schartye472"]
[OnName num="schartye"]
"Let's go!　Prepare to sacrifice your life for the Demon Lord!"
[cpg cn=true]


Countless soldiers responded to Chartier 's words.
[cpg]


There's no way you can't win. The question is, how long will it take to ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//＠
[SE f="se018"]
;//【ＳＥ】『剣戟』

[WAIT time=3000]

[stopse g=2]
;//通常se

[STOPBGM]


[BG f="b_09_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『草原』（夕方）******************************************************

[window target=true]






I thought so, but the battle with the Elf Nation was over in an instant.
[cpg]


It was too one-sided. There was no way for Chartier me or anyone else to get involved.
[cpg]


[OnName num="kousuke"]
It was too easy. It's a trap.
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye473"]
[OnName num="schartye"]
"Trap?　What kind of trap would you set, abandoning your entire country?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye474"]
[OnName num="schartye"]
"It's hard to imagine. It's hard to imagine, and it makes you wonder who's behind it.
[cpg cn=true]


You're absolutely right. The elven nation has no choice but to fight with all its might.
[cpg]


In the first place, the magical soldiers of the elven army were boned.
[cpg]


If there is a difference in the strength of the troops, it may be natural for this to happen. ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_11_3.ui" time=1000]
[WAIT time=1500]



In this way, the country of the demon king gained territory across the sea.
[cpg]


I'm sure you'll be able to understand why. It's not the subhumans that belong to the Demon Lord's country, but the elves.
[cpg]


My heart hurts and I am riddled with guilt. Still, ......
[cpg]


Still, I found myself feeling relieved.
[cpg]


I was thinking that the chances of me not dying had increased.
[cpg]




[window target=false]
[STOPBGM]

[WAIT time=1000]


[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




The sub-people of the demon king's country were happy about this victory.
[cpg]


Fia seemed to have mixed feelings, but Kullulu celebrated.
[cpg]


The Meir seemed to be pleased with the ...... stance that I could do as I pleased.
[cpg]

[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
After all the festivities had passed, Chartier and I were left alone.
[cpg]


[OnName num="kousuke"]
...... This was the right thing to do, maybe."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye475"]
[OnName num="schartye"]
"What do you mean now? What do you mean now? Of course it's good, it's what we've always wanted.
[cpg cn=true]


[OnName num="kousuke"]
It's good. It's for the best."
[cpg cn=true]


The decisive battle was over. I couldn't have been more nervous.
[cpg]


We were both feeling a bit out of sorts.
[cpg]




[OnName num="kousuke"]
" Chartier . What am I supposed to think?
[cpg cn=true]


[VOICE f="sSchartye042"]
[OnName num="schartye"]
What do you mean, "how?　What do you mean, what do you mean?
[cpg cn=true]


[OnName num="kousuke"]
Yeah, ...... a little bit of relief would be nice.
[cpg cn=true]


[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1500]
[WAIT time=2500]
;//ブラックアウト




;//[BG f="b_02_2.ui" time=10]

[BGM f="bg_ma"]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************


[CG id=20 index=0 time=1000]

[WAIT time=1000]


[window target=true]




And then we're going to rule the land of the elves.
[cpg]


It's better to say the country of the former elves, because now it is the country of the demon king.
[cpg]


Reinforcements from the underworld were no longer needed.
[cpg]


The newly conquered elf nation has had its talented wizards study new military magic.
[cpg]


They have become powerful enough to compete with the great powers. ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_11_2.ui" time=1000]
[WAIT time=1500]


In this day and age, it is said that if we were to start a serious war, the earth would be destroyed.
[cpg]


But we had enough power to prevent that from happening.
[cpg]


Even if all the weapons in the world were to be launched at the Demon Lord's country, we and our people would be safe.
[cpg]


That's how much magic technology we've acquired.
[cpg]

[STOPBGM]
[WAIT time=1500]


[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





While making love to Chartier , I continued to go further and further down the path of evil.
[cpg]


Eventually, the day will come when this world will surrender to the demon king that is me.
[cpg]


I may have been just an ordinary person, but I had the makings of an evil person.
[cpg]


And more than that, I could say that Chartier was a great evil.
[cpg]


To tell you the truth, this country would be running without me.
[cpg]


It could do better than me with just one person, Chartier .
[cpg]


Still, Chartier loves me.
[cpg]


On top of that, I had a magical power that no one else could match. We were invincible.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Schartye505"]
[OnName num="schartye"]
"Hey, Demon Lord. I broke up with my former lover in death.
[cpg cn=true]


[OnName num="kousuke"]
"...... I see."
[cpg cn=true]


Next to me, sitting on the bed, Chartier talked about the past.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye506"]
[OnName num="schartye"]
It's a good idea to take a look at the actual information on the web.
[cpg cn=true]


Chartier had a thoughtful look on his face. However.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye507"]
[OnName num="schartye"]
It's because of you, ......, that I was able to fulfill the wishes of my former demon lord.
[cpg cn=true]


Chartier begins to talk. The unfulfilled tragic love was revealed.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye508"]
[OnName num="schartye"]
The world of the werewolves before they were connected to this world was a terrible place.
[cpg cn=true]


In the past, even after the Demon King conquered the world, the other world was still impoverished.
[cpg]


Due to abnormal weather, crops could not be grown. It seemed that without food, no matter what kind of magic technology was available, a nation could not survive.
[cpg]


For the sake of the people, I sacrificed my own life, hoping to connect with the other world, the world where I originally lived.
[cpg]


As a result, the countries ruled by a single Demon King were torn apart.
[cpg]


[OnName num="kousuke"]
I didn't know that was possible. ......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye509"]
[OnName num="schartye"]
Yeah. In the end, he sacrificed his life for his people.
[cpg cn=true]


He was a demon king who had developed a personality, even though he had been reborn as me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye510"]
[OnName num="schartye"]
But he's about to return to his original form again. The world that was once conquered by the Demon Lord is now ......."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye511"]
[OnName num="schartye"]
It was never a world where people could complain. You can find a lot of people who are interested in this kind of thing.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye512"]
[OnName num="schartye"]
You must have inherited that character. I believe in you.
[cpg cn=true]


[OnName num="kousuke"]
"...... Chartier
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye513"]
[OnName num="schartye"]
I want you to rule this world. That's what I want, and that's what the former Demon Lord wanted.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_11_2.ui" time=1000]
[WAIT time=1500]



I decided to conquer this world in order to make the world that Chartier and the former Demon Lord dreamed of come true.
[cpg]


This is not just a path of evil. This was not just a path of evil, but a necessary one, mixed with justice.
[cpg]


Above all, if this is what Chartier wished for, I want it to come true. That's all.
[cpg]


There was a love that transcended what was justice and what was evil.
[cpg]



;//ＥＮＤ　ヒロイン３征服ルート

[WAIT time=100]
[jump storage="epend.ks" target="*start"]
[WAIT time=100]




