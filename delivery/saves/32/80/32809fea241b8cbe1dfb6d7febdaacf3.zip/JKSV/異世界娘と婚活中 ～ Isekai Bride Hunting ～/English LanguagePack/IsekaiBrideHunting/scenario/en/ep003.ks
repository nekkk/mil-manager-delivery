
;//==============================
;//２、ヒロイン２

*start

*ep003
*IseSel08_2|Peace. Meir

[SCENE id=3]

Meir . The first thing that came to my mind was her.
[cpg]


She's always been close to me, and I've always been comfortable with that, but ......
[cpg]


It's not just that. I'm originally from the land of the beasts.
[cpg]


It might be Meir that she wanted peace more than anyone else.
[cpg]



;//ブラックアウト
[window target=false]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************


[window target=true]


The next day. I went to Meir .
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile204"]
[OnName num="meile"]
"Oh, Kosuke . What's wrong?"
[cpg cn=true]


[OnName num="kousuke"]
"...... Meir . Can I talk to you for a minute?"
[cpg cn=true]


I told her everything I was feeling.
[cpg]


I want to stop fighting right now. It may not have started yet, but I want to make sure it doesn't happen.
[cpg]


I don't care if I'm not the Demon Lord anymore. That's how I felt.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile205"]
[OnName num="meile"]
"I see. That's what you were thinking?
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. I want to hear what Meir has to say. Can you think of a way to do that?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile206"]
[OnName num="meile"]
I don't know if that's too much to ask.
[cpg cn=true]


[OnName num="kousuke"]
Please. I don't care what it is, I think some ideas come from people who don't know as much about magic as you do.
[cpg cn=true]


I'll just say what I want to say.
[cpg]


But the fact is, it doesn't matter what you say to Chartier or Kullulu .
[cpg]


I'm sure they're against my desire for peace.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile207"]
[OnName num="meile"]
I'm sure you'll be able to find a way to separate the power of ...... Kosuke as a demon king from the power of ......?
[cpg cn=true]


[OnName num="kousuke"]
"...... that's ......."
[cpg cn=true]


I, for one, would like it best if such a thing were possible.
[cpg]


I wondered if it was possible. You can't do that.
[cpg]


It's a great way to make sure you're getting the most out of your money.
[cpg]


[OnName num="kousuke"]
If I could, that would be ideal. You mean I'll be a normal person again?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile208"]
[OnName num="meile"]
Yes. I guess we'll have to ask Chartier and Kullulu if that's possible.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Meile209"]
[OnName num="meile"]
I'd rather go to ...... Kosuke . Can I have a word?"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


Meir had a dazed look on his face. It seems to have been affected by my magical element.
[cpg]

[OnName num="kousuke"]
I'm not going to flirt in public. You can't flirt in public, can you?
[cpg cn=true]


I was in the mood for it. I want to be near her.
[cpg]


[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[window target=true]




I walked out of the castle and headed further out into the city.
[cpg]


I went outside the castle and headed further out of town, into the woods where no one would find me.
[cpg]

[VOICE f="sMeile023"]
[OnName num="meile"]
I feel at home in the woods.
[cpg cn=true]

[VOICE f="sMeile024"]
[OnName num="meile"]
When I'm with Kosuke , I feel like it's just the two of us.
[cpg cn=true]

[OnName num="kousuke"]
Yeah.
[cpg cn=true]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




Hopefully, I really do. I've been in too many positions where it's not my intention to be.
[cpg]

The only thing I really want is Meir .
[cpg]

As I was walking along, Meir tripped over a tree root and nearly fell.
[cpg]

[VOICE f="sMeile025"]
[OnName num="meile"]
"Ouch!"
[cpg cn=true]

[OnName num="kousuke"]
Oops."
[cpg cn=true]

;//========================================
;//●ＣＧ（後ろからヒロインの手を掴む主人公）ev_33
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：魔王の国＿森の中
;//時間　：昼
;//備考　：公式サイト三枚目のCGです
;//========================================

*Scene012

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile026"]
[OnName num="meile"]
Thank you, ....... That was a close one."
[cpg cn=true]

[OnName num="kousuke"]
"Oh, yeah, ......."
[cpg cn=true]

I'm looking kind of funny now.
[cpg]

I can feel Meir 's body heat. It's a good idea to have a good idea of what you're doing.
[cpg]

Or does he have some thoughts about this situation?
[cpg]

I think ...... again, Meir is quite stylish.
[cpg]

;**【ＣＧ】 ev_33_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile027"]
[OnName num="meile"]
...... hehe. Kosuke 's hands are warm, aren't they?
[cpg cn=true]

[OnName num="kousuke"]
Is that so?　I feel your hands are warm.
[cpg cn=true]

[VOICE f="sMeile028"]
[OnName num="meile"]
Maybe so. Beastmen tend to have high body temperature.
[cpg cn=true]

I wondered if that was true, but a silence ensued that I couldn't quite understand.
[cpg]

We both felt like we wanted to say something, but couldn't.
[cpg]

[OnName num="kousuke"]
"How long are you going to stay in that position?
[cpg cn=true]

;**【ＣＧ】 ev_33_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile029"]
[OnName num="meile"]
Sorry, sorry, I just wanted to hold your hand.
[cpg cn=true]

[OnName num="kousuke"]
Well then, let's just hold hands.
[cpg cn=true]

[VOICE f="sMeile030"]
[OnName num="meile"]
"Yeah. Sure."
[cpg cn=true]

Then we can hold hands normally.
[cpg]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//Ｈシーンカット


[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Meile233"]
[OnName num="meile"]
"...... Hey, Kosuke . Do you like me?
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. Yeah, I like Meir .
[cpg cn=true]

[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Meile234"]
[OnName num="meile"]
"I see. ...... I'm glad. I love Kosuke too.
[cpg cn=true]


I know that Meir likes me. That's because I'm the Demon Lord.
[cpg]


But what would happen if ...... I was no longer a demon king?
[cpg]


[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************


[window target=true]



[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude232"]
[OnName num="clolowlude"]
"...... Ripping the power out of the Demon Lord?　That's an interesting idea."
[cpg cn=true]


Later, after consulting with Kullulu , it seemed possible.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude233"]
[OnName num="clolowlude"]
If anything, it's easier to rip off the Demon Lord's power than to just seal off his magic.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude234"]
[OnName num="clolowlude"]
If you only seal the magic power, you will be sealing the element that makes you the Demon Lord.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude235"]
[OnName num="clolowlude"]
There might be something wrong with the Demon Lord's body. It's dangerous.
[cpg cn=true]


[OnName num="kousuke"]
So there's no disadvantage to ripping out the ...... magic power instead of sealing it?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude236"]
[OnName num="clolowlude"]
But then only the stripped magic will exist on its own.
[cpg cn=true]


It's a difficult subject. I'm not really following, and Meir wasn't trying to understand in the first place.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude237"]
[OnName num="clolowlude"]
I don't know if the magic has a will or not, but it could go out of control.
[cpg cn=true]


[OnName num="kousuke"]
"Oh, yeah? ......?"
[cpg cn=true]


I can't quite picture it. I'm sure it's a big deal.
[cpg]


Only power can run amok. It's a good idea to have a good idea of what you're looking for.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************

[window target=true]




We decided to ask the opinion of Chartier as well.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Schartye180"]
[OnName num="schartye"]
It's a good idea to have a good idea of what you're looking for.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye181"]
[OnName num="schartye"]
It might even turn against us. It's dangerous to hold them back.
[cpg cn=true]


However, it seems that if Chartier and Kullulu were here, it would not be impossible to fight.
[cpg]


[FACE method="change_7" pos="2/2"]
[VOICE f="Meile235"]
[OnName num="meile"]
"Can we win ......?"
[cpg cn=true]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye182"]
[OnName num="schartye"]
"I don't know if I'll win or lose. I don't know if I'm going to win or lose. If I lose, then I'm probably going to die.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



...... Chartier has also raised other concerns.
[cpg]


This means that if you are successful in fighting and sealing the power of the demon king, you will be able to ......
[cpg]


This is the reason why it is so important for you to have a good idea of what you are doing.
[cpg]


;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[window target=true]




I came out to the city. The people of this country have come together for me.
[cpg]


[OnName num="kousuke"]
...... What am I supposed to do?
[cpg cn=true]

[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
I murmured. Next to me was Meir .
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile236"]
[OnName num="meile"]
"Whatever you want to do, Kosuke. That's what makes me happy, Kosuke."
[cpg cn=true]


[OnName num="kousuke"]
"Well, ......."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]


I felt as if I couldn't feel anything at all.
[cpg]

[free time=1000]

I don't know if I can do as I please. And what will happen to this country as a result of me behaving as I please?
[cpg]


I couldn't imagine anything well.
[cpg]


I guess I'm not in a calm mood. You can find me at ......
[cpg]


[VOICE f="Meile237"]
[OnName num="meile"]
"...... Kosuke "
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]


Meir hugged me from behind.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile238"]
[OnName num="meile"]
He said, "I'm here for you. Don't worry."
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





In fact, Meir doesn't have any special powers.
[cpg]


But it felt more reassuring than the words of Chartier or Kullulu .
[cpg]

[STOPBGM]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]



[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
We were coming back to my room.
[cpg]


[OnName num="kousuke"]
"What if ...... I'm not a demon king anymore?"
[cpg cn=true]


[OnName num="kousuke"]
"You might not be attracted to me anymore. You won't have any pheromones or anything.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile239"]
[OnName num="meile"]
I told you not to worry. I'll always like Kosuke no matter what.
[cpg cn=true]


[OnName num="kousuke"]
......, why are you so crazy about me?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile240"]
[OnName num="meile"]
I don't know. I don't know, but I think it started with ...... when I came on to him.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sMeile031"]
[OnName num="meile"]
Kosuke , you didn't mind, but you looked happy. It made me happy too.
[cpg cn=true]


[OnName num="kousuke"]
...... There was a time when that happened.
[cpg cn=true]




;//ブラックアウト



;//========================================
;//●ＣＧ（主人公にのしかかるヒロイン）ev_34
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城内＿主人公の部屋
;//時間　：昼
;//========================================

*Scene027

[BG f="black.ui" time=1000]
[free time=1000]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile032"]
[OnName num="meile"]
I'm pretty sure it was something like .......
[cpg cn=true]

[OnName num="kousuke"]
I don't think so. It's after we met.
[cpg cn=true]

[VOICE f="sMeile033"]
[OnName num="meile"]
No?　 I think I remember Kosuke pretty well.
[cpg cn=true]

[OnName num="kousuke"]
I'm pretty sure I remember Meir , too.
[cpg cn=true]

As we talked, I felt her presence very close to me.
[cpg]

Then Meir leaned forward.
[cpg]

;**【ＣＧ】 ev_34_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile034"]
[OnName num="meile"]
Do you want me to kiss you like this?
[cpg cn=true]

[OnName num="kousuke"]
You'd better not. I've heard that my saliva contains magical elements.
[cpg cn=true]

;**【ＣＧ】 ev_34_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=100]

Meir was puzzled and said, "Really?　I'm sure you've heard of it.
[cpg cn=true]

[VOICE f="sMeile035"]
[OnName num="meile"]
Who told you that?
[cpg cn=true]

[OnName num="kousuke"]
I'm pretty sure Chartier told me.
[cpg cn=true]

[VOICE f="sMeile036"]
[OnName num="meile"]
If I kiss you, I might fall in love with you even more.
[cpg cn=true]

[OnName num="kousuke"]
Want to try it?　I don't know what would happen."
[cpg cn=true]

We talked and talked, but in the end we didn't kiss.
[cpg]

I wanted to take care of Meir without ...... being too early for us.
[cpg]

Of course, taking the right steps is not the same as taking care of yourself.
[cpg]

But if ...... this time is going to pass too quickly, it would be a waste.
[cpg]

I had such a feeling in me.
[cpg]

;//Ｈシーンカット

;//ブラックアウト
[STOPBGM]


*effect|Peace. Meir

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




Night. It was going to take place in my room.
[cpg]

[BG f="e_01_1.ui" time=1000]
[WAIT time=1000]

There is a magic circle on the floor. It was drawn by Fia and Chartier .
[cpg]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1000]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Schartye183"]
[OnName num="schartye"]
I have to say, I'm not in favor of this.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude238"]
[OnName num="clolowlude"]
"Me too. I don't know what this country will be like without you as the Demon Lord."
[cpg cn=true]


[OnName num="kousuke"]
...... I know, I know. But ......
[cpg cn=true]

[free time=800]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Meile263"]
[OnName num="meile"]
But there's also the danger of having a ...... Demon Lord.
[cpg cn=true]

Meir was not pressured by Chartier and the others.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sFia025"]
[OnName num="fia"]
I think so too. It's the only way to solve everything peacefully."
[cpg cn=true]

[FACE method="change_1" pos="1/2"]
[VOICE f="sMeile037"]
[OnName num="meile"]
" Fia ......."
[cpg cn=true]


And then my power ...... as a demon king was stripped away.
[cpg]


[free time=800]

I'm in the center of the magic circle. It seems to be easier than sealing the magic power as a demon king.
[cpg]


However, this also means that there is another danger.
[cpg]


He also said that the magic power might go out of control.
[cpg]


[STOPBGM]

[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Schartye184"]
[OnName num="schartye"]
So, let's go. Prepare yourself, Demon Lord."
[cpg cn=true]


Chartier chants a spell. And ......
[cpg]



[SE f="se005"]
;//【ＳＥ】『魔法の音　低め』
[free time=1000]



[BGM f="bg_ma"]

;//画面白く
[BG f="e_01_1.ui" time=1000]
[WAIT time=2000]

[FG f="e_02_2.ui" method="change_1"  pos="3/5" time=1]
[WAIT time=3000]

[BG f="black.ui" time=1000]


;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]


I fell down on the spot. My legs lost their strength.
[cpg]


[SE f="se014"]
;//【ＳＥ】『地鳴りのような音』


[window target=false]
[transition target={true} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=2100]

[BG f="e_01_3.ui" time=1]
[free time=1]
[WAIT time=10]

[WAIT time=200]
[transition target={false} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=1500]

[window target=true]


The only thing that was stripped from my body was my magic power. As expected, the Demon Lord's power is out of control without any substance. ......
[cpg]


A black sphere was bubbling away. A black sphere is bubbling and floating above my fallen body.
[cpg]

;//＠
[SE f="se005"]
;//【ＳＥ】魔法攻撃

Then he shoots a beam of light. It's going to attack the Meirs. ......!
[cpg]




[SE f="se005"]
;//【ＳＥ】『バリア　金属音のような感じ』





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye185"]
[OnName num="schartye"]
"Oh, ......, I knew this would happen."
[cpg cn=true]

[stopse g=2]
;//通常se

[SE f="se005"]
;//【ＳＥ】魔法攻撃

[transition target={true} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=1100]

[free time=1]
[BG f="e_01_3.ui" time=1]
[WAIT time=10]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/2" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=1]
;//[FG f="e_02_2.ui" method="change_2"  pos="3/5" time=1]


[WAIT time=200]
[transition target={false} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=1500]


[SE f="se005"]
;//【ＳＥ】『バリア　金属音のような感じ』

[FACE method="change_5" pos="2/2"]
[VOICE f="Clolowlude239"]
[OnName num="clolowlude"]
What to do, even if you attack back, the Demon Lord will ......!
[cpg cn=true]



[FACE method="change_3" pos="1/2"]
[VOICE f="Fia297"]
[OnName num="fia"]
It's a good idea to have a good idea of what you're doing.
[cpg cn=true]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=2100]
[free time=1]
[BG f="black.ui" time=1]


I couldn't do anything about it. It's a good idea to have a good idea of what to do.
[cpg]


[WAIT time=1000]

[SE f="se008"]
;//【ＳＥ】『歩く』
[BG f="e_01_3.ui" time=1]

[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=1]


[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1000]


But then, Meir approaches the black ball ...... demon king's power that is being held back.
[cpg]


[VOICE f="Fia298"]
[OnName num="fia"]
" Meir !　It's dangerous, get away!
[cpg cn=true]


I was wondering what Meir was trying to do.
[cpg]

[FACE method="change_2" pos="2/3"]


I was wondering what Meir was trying to do, when said something to me. Then ......
[cpg]



The demon king's power subsided as I watched. He stopped attacking.
[cpg]


I don't know what's going on, and I don't know what Meir has done.
[cpg]


But Chartier would not miss the opportunity.
[cpg]



[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]

[free time=1]
[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="1/2" time=1]

[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=1]
[BG f="e_01_3.ui" time=1]



[WAIT time=200]
[transition target={false} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1500]

[window target=true]


[VOICE f="Schartye186"]
[OnName num="schartye"]
"Now!"
[cpg cn=true]


[VOICE f="Fia299"]
[OnName num="fia"]
"Yes, yes."
[cpg cn=true]

[SE f="se005"]
;//【ＳＥ】『バリア　金属音のような感じ』

[FG f="e_02_2.ui" method="change_2"  pos="3/5" time=2000]
[WAIT time=3000]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
;//ブラックアウト



As it is, the power of the demon king was sealed by the power of Fia and others.
[cpg]


In the end, I had no idea what Meir had done. ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye187"]
[OnName num="schartye"]
"Huh, huh, I got it ......?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Fia300"]
[OnName num="fia"]
"Yes ...... maybe, it worked."
[cpg cn=true]


There was nothing left of it. There was nothing left in there. I guess it is more correct to say that it was erased rather than sealed.
[cpg]


[OnName num="kousuke"]
"Did you delete ......?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude240"]
[OnName num="clolowlude"]
No. It's just a seal. It's only a seal, it's invisible in this world.
[cpg cn=true]


[OnName num="kousuke"]
Is that right, ......?
[cpg cn=true]


I still don't know much about magic.
[cpg]


But I do know one thing for sure. I am no longer the Demon Lord.
[cpg]



;//ブラックアウト
[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_05_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************

[window target=true]




The people still don't know that the Demon Lord is gone.
[cpg]


Will they be disappointed? This country might as well have lost its reason for existence.
[cpg]


But ...... somehow, it seemed to be inevitable. This is what the demon king, the demon king himself, wanted.
[cpg]


But what did Meir he say at that time?
[cpg]


[OnName num="kousuke"]
What did Meir ...... you do back then?
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile265"]
[OnName num="meile"]
"Nothing. I didn't do anything important.
[cpg cn=true]


[OnName num="kousuke"]
No, you didn't. Obviously, they stopped attacking us.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile266"]
[OnName num="meile"]
But ...... you're right. If the Demon Lord's power has been stripped from you, then ......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile267"]
[OnName num="meile"]
I was wondering if there was any of your nature left. So...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile268"]
[OnName num="meile"]
I said. I said, "I love you for who you are as a human being, and I want you to sleep peacefully for now."
[cpg cn=true]


[OnName num="kousuke"]
"...... You said that?"
[cpg cn=true]


It seems that the power of the demon king, which seemed to have no substance, had some personality left. He was appealing to it.
[cpg]


[OnName num="kousuke"]
Thank you. Meir . I can't thank you enough."
[cpg cn=true]


I thanked Meir and thought about what I would do.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile269"]
[OnName num="meile"]
No need to thank me. It's more like..."
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMeile038"]
[OnName num="meile"]
Let's just make out. It's been a long time since you've felt that safe, since no one is trying to kill you.
[cpg cn=true]


[OnName num="kousuke"]
...... Well.
[cpg cn=true]



;//ブラックアウト
[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_07_4.ui" time=1000]

[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************

[window target=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

Meir and I walked back to the castle.
[cpg]


We decided to head to her room. Meir and the two of us, to be together.
[cpg]


We have nothing to fear anymore, to say that we have nothing to fear.
[cpg]


[OnName num="kousuke"]
I suppose we should announce that the ...... Demon Lord is no longer in power.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile271"]
[OnName num="meile"]
I don't know.　I don't know, maybe someone in the elven lands who is skilled in magic has already figured it out.
[cpg cn=true]


That's true. I'm sure they've already figured out that I'm the Demon Lord.
[cpg]


It is possible that the reverse may also be true,......, as you walk into the room of Meir .
[cpg]



[SE f="se002"]
;//【ＳＥ】『ドア開く』




;//ブラックアウト


;//Ｈシーンカット

;//========================================
;//●ＣＧ（キスをするヒロインと主人公）ev_03
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城内＿ヒロイン２の部屋
;//時間　：夜
;//========================================

*Scene031

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
;[Event g="ev_03_0" a=false f=false]
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=100]

The moment happened abruptly. Something I couldn't do the other day.
[cpg]

[OnName num="kousuke"]
"......, that's pretty sudden."
[cpg cn=true]

;**【ＣＧ】 ev_03_a ***********************
[CG id=1 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile039"]
[OnName num="meile"]
"Hmm. I did. It's not sudden, because I couldn't do it the other day.
[cpg cn=true]

[VOICE f="sMeile040"]
[OnName num="meile"]
Maybe now I've got your magic.
[cpg cn=true]

[VOICE f="sMeile041"]
[OnName num="meile"]
Maybe there will be more miracles like the last one.
[cpg cn=true]

[OnName num="kousuke"]
I don't know. I don't know. It's already a miracle we're both here.
[cpg cn=true]

[VOICE f="sMeile042"]
[OnName num="meile"]
You're starting to sound like a king. You're looking good.
[cpg cn=true]

[OnName num="kousuke"]
Well, ......, I've been a Demon Lord for a long time.
[cpg cn=true]


;**【ＣＧ】 ev_03_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile043"]
[OnName num="meile"]
I've been a Demon Lord for a long time. You've been a Demon Lord since the beginning.
[cpg cn=true]

[VOICE f="sMeile044"]
[OnName num="meile"]
And now you're not a demon king, you're a king.
[cpg cn=true]

[OnName num="kousuke"]
Yeah. That's right.
[cpg cn=true]

We kissed again while talking about such trivial things.
[cpg]

It's a shame to let such a happy time pass by.
[cpg]

Meir seemed to be thinking the same thing, and wouldn't let me go.
[cpg]


;//Ｈシーンカット



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





The night dawns. I'm no longer the Demon King, but I'm still the King.
[cpg]

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[window target=true]





All over the world, it was reported that the power of the Demon King was gone.
[cpg]


In other words, the world knew that I was no longer a marvel. And this country was no exception.
[cpg]


I thought I would no longer be able to be king, but ......
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





The reality was not that simple. It seems that I have the credit of having united the subhumans.
[cpg]


You can find a lot of people who are looking for the best way to get the best results.
[cpg]


As a former demon king, I became a mere king.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile314"]
[OnName num="meile"]
I wonder what the name of this country will be. "I wonder what the name of this country will be.
[cpg cn=true]


[OnName num="kousuke"]
"I'm going to change it back to the Land of Beastmen. That's what it used to be.
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sFia026"]
[OnName num="fia"]
I think that's a good idea. I think that's a good idea. The beasts will be familiar with it.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude241"]
[OnName num="clolowlude"]
I can't believe I'm not the Witch King anymore.
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Clolowlude242"]
[OnName num="clolowlude"]
If I were in that position, I would put my faith in the power of the Demon Lord, no matter the risk.
[cpg cn=true]


[OnName num="kousuke"]
It's not that simple, you know. It's not that simple. As long as the Demon Lord's power exists, you have to keep fighting.
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="sFia027"]
[OnName num="fia"]
I guess that's the way it is. ......
[cpg cn=true]


Conquering power with power doesn't seem like a good idea in this day and age.
[cpg]


I think I've got it the way I want it.
[cpg]


I think I got what I wanted, and the power of Meir was essential to that.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Meile315"]
[OnName num="meile"]
"Hey, Kosuke . Anyway, are you free today?"
[cpg cn=true]


[OnName num="kousuke"]
"No, I'm not free. ...... I've got a lot of work to do. ......
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sFia028"]
[OnName num="fia"]
Looks like we're in the way.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude243"]
[OnName num="clolowlude"]
That's so .......
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]

;//ブラックアウト



[SE f="se004"]
;//【ＳＥ】『ドア閉まる』

[STOPBGM]
[WAIT time=1000]



[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile316"]
[OnName num="meile"]
Heh. It's just you and me now.
[cpg cn=true]


[OnName num="kousuke"]
Don't you ever get embarrassed?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sMeile045"]
[OnName num="meile"]
Why?　It's normal for two people who like each other to be together.
[cpg cn=true]


[OnName num="kousuke"]
Maybe so, but ...... is too obvious.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile318"]
[OnName num="meile"]
That's fine. I'm ready to be Kosuke 's wife.
[cpg cn=true]


What? I don't need to tell you that ......
[cpg]


[OnName num="kousuke"]
I don't need to tell you that now. You're the only one for me.
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile319"]
[OnName num="meile"]
...... "Hmmm. I'm glad.
[cpg cn=true]

;//Ｈシーンカット

;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]




Peaceful time passed.
[cpg]


There was no longer any reason for anyone to try to kill me.
[cpg]


But I'm still the king. You can find a lot of things to do, even if it's peace.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile340"]
[OnName num="meile"]
"Hey, Kosuke . Don't spend all your time working, take care of me.
[cpg cn=true]


[OnName num="kousuke"]
I'll see you later. ...... A messenger is coming from the land of the elves today as well.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile341"]
[OnName num="meile"]
"Moo ......, you said later. I promise.
[cpg cn=true]


Meir is still the same, but maybe I'm still the same.
[cpg]


It's not that I'm not a demon king anymore, but it doesn't mean that anything is going to change dramatically. ......
[cpg]


Me and Meir lived happily ever after.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_mi"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************

[window target=true]




Then, at night in the castle town. We were walking together.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile342"]
[OnName num="meile"]
It's become a great town, isn't it? Just a while ago, there was nothing here.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile343"]
[OnName num="meile"]
I don't think the subhumans have ever been so united. Kosuke "
[cpg cn=true]


[OnName num="kousuke"]
I think you're right, .......
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile344"]
[OnName num="meile"]
It's all thanks to Kosuke . He may not be the Demon Lord anymore, but he'll always be special to me.
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile345"]
[OnName num="meile"]
I won't let you go. Be prepared.
[cpg cn=true]


[OnName num="kousuke"]
"...... Oh."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//ＥＮＤ　ヒロイン２平和ルート

[WAIT time=100]
[jump storage="epend.ks" target="*start"]
[WAIT time=100]
;[s]
[WAIT time=100]
[WAIT time=100]

