
;//==============================
;//１、フィア
*start

*ep002
*IseSel08_1|Peace. Fia

[SCENE id=2]


It was Fia . I want to live a quiet life with Fia .
[cpg]


To make that wish come true, I decided to call Fia .
[cpg]


[window target=false]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]


[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia171"]
[OnName num="fia"]
"What is ......?　 Mr. Kosuke ."
[cpg cn=true]


[OnName num="kousuke"]
" Fia . Do you want peace?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia172"]
[OnName num="fia"]
"Of course I do. If possible, I don't want Kosuke to become a murderer.
[cpg cn=true]


[OnName num="kousuke"]
I'm the same way. I don't want Fia to be in danger.
[cpg cn=true]


[OnName num="kousuke"]
This whole thing started with you and me, right?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia173"]
[OnName num="fia"]
...... Yes. When I think about it, yes.
[cpg cn=true]


[OnName num="kousuke"]
I want to live with you. I want to live with you, in peace, forever.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Fia174"]
[OnName num="fia"]
Kosuke and ......
[cpg cn=true]


[OnName num="kousuke"]
Can you help me figure out how to do that? Fia
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia175"]
[OnName num="fia"]
Of course. If there is anything I can do, I will.
[cpg cn=true]


We were both thinking the same thing.
[cpg]


Fia was also looking at me and had a kind of enraptured look on her face.
[cpg]

There was a word I had been holding back. I had no choice but to say it now.
[cpg]

[OnName num="kousuke"]
I had to say it now: " Fia . I love you."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Fia176"]
[OnName num="fia"]
"I like ...... too. Kosuke ."
[cpg cn=true]

[FG f="CHA01_p7_01_a.ui" method="change_2"  pos="2/3" time=1000]
;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=2000]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト


I spent that night cuddling with Fia . And then the night was over.
[cpg]

[window target=false]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（朝）******************************************************

[window target=true]


Me and Fia decided to come up with a peaceful solution together.
[cpg]


In the castle town, you can see many different species.
[cpg]


All of them are people that I have to protect.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia198"]
[OnName num="fia"]
"I think ...... I think ......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia199"]
[OnName num="fia"]
I think that Kosuke being the king of this country is not a problem.
[cpg cn=true]


[OnName num="kousuke"]
I guess so. It's just that he has a lot of magic power.
[cpg cn=true]


Even though I haven't fully awakened yet, it seems I have the power to conquer the world.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia200"]
[OnName num="fia"]
I'm sure they don't think I have any radical ideas either. If that's the case, ......"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia201"]
[OnName num="fia"]
If that's the case, why don't we just seal off the Demon Lord's power?
[cpg cn=true]


[OnName num="kousuke"]
You ...... know, if it was that convenient, I would have done it in the first place.
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="4/2" time=1]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia202"]
[OnName num="fia"]
That's true, but ......
[cpg cn=true]


[move from="2/3" to="1/2" ease="easeInOutSine" time=1000]

[move from="4/2" to="2/2" ease="easeInOutSine" time=1000]

[WAIT time=1500]

[FACE method="change_2" pos="2/2"]

[VOICE f="Clolowlude223"]
[OnName num="clolowlude"]
You two are so close. I hope I didn't interrupt your date.
[cpg cn=true]


[FACE method="change_6" pos="1/2"]
[VOICE f="Fia203"]
[OnName num="fia"]
So, it's not a date. ...... Maybe.
[cpg cn=true]


I'm not on a date. Fia Maybe." The way he said "maybe" was very .
[cpg]


But ...... this time, it might be a good time to ask.
[cpg]


[OnName num="kousuke"]
Kullulu. Is there a way to seal off only the Demon Lord's power?
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Clolowlude224"]
[OnName num="clolowlude"]
"...... What do you mean?　Do you mean you want to be a normal person again?
[cpg cn=true]


[OnName num="kousuke"]
Yes, in a manner of speaking, yes.
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude225"]
[OnName num="clolowlude"]
I wonder if there is. But I'm not going to help you find out.
[cpg cn=true]


I don't think so. I'm not going to help you find out." "Of course you won't, because you'll lose the Demon Lord, the one thing that subhumans can count on.
[cpg]


But I was trying to find a peaceful solution, even if it was just me.
[cpg]

[STOPBGM]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





But even if I were to investigate ...... on my own, there would be limits.
[cpg]


Without the help of Fia , it seems impossible. However, Fia is cooperating with me.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドアノック』


[WAIT time=1500]



[OnName num="kousuke"]
"Hmm?　Who is it?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="4/2" time=1]

[SE f="se002"]
;//【ＳＥ】『ドア開く』


[WAIT time=1000]

[move from="4/2" to="2/3" ease="easeInOutSine" time=1000]


[VOICE f="Meile199"]
[OnName num="meile"]
" Kosuke . Let's play.
[cpg cn=true]


[OnName num="kousuke"]
Play? ...... I don't have time for this.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile200"]
[OnName num="meile"]
You have to understand. It's not just me. I'm fascinated by Kosuke .
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


It's not just me. I'm fascinated by . Even in my research, the girls want me.
[cpg]


It's a good idea to have a good idea of what you're looking for.
[cpg]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夕方）******************************************************





[OnName num="kousuke"]
"Phew. ......"
[cpg cn=true]


I was tired of researching and went out for the evening in the city.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia204"]
[OnName num="fia"]
I was out in the evening, tired of my research. ...... I don't think this is a research that will yield immediate results. There's no hurry.
[cpg cn=true]


[OnName num="kousuke"]
"Well, maybe so, but ...... too."
[cpg cn=true]


I'm in a hurry to hurry. It's too late to wait for a big battle to break out.
[cpg]


It's too late for a big fight to happen someday, I think, but if I don't refresh myself appropriately, I'll go crazy.
[cpg]



[FACE method="change_1" pos="2/3"]
[VOICE f="sFia024"]
[OnName num="fia"]
You look tired. Would you like to take a walk around the city to take your mind off things?
[cpg cn=true]

[OnName num="kousuke"]
"Yeah. I'd like to take a walk with Fia .
[cpg cn=true]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト




Me and Fia proceeded with our research to seal the Demon Lord's power.
[cpg]


We both knew that it was not going to be completed anytime soon.
[cpg]


But the conclusion came much sooner than we expected. ......
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





[OnName num="kousuke"]
...... Are you sure this is right?　Can we really do this?"
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Fia228"]
[OnName num="fia"]
I think ...... it's probably complete.
[cpg cn=true]


We had perfected the secret art of sealing only the power of the Demon Lord. We had perfected it.
[cpg]


It was surprisingly easy. Fia It's a great way to get the most out of your money.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia229"]
[OnName num="fia"]
Kosuke This is the reason why it is so important for you to have a good idea of what you are doing.
[cpg cn=true]


It's like a snake biting its own tail.
[cpg]

[free time=800]
[STOPBGM]

In any case, I want to try it right away. That's what I'm thinking. ......
[cpg]



[SE f="se002"]
;//【ＳＥ】『ドア乱暴に開く』


[FG f="CHA03_p5_01_a.ui" method="change_3"  pos="4/2" time=1]

[WAIT time=1500]


[BGM f="bg_tc"]

[move from="4/2" to="2/3" ease="easeInOutSine" time=1000]


[VOICE f="Schartye172"]
[OnName num="schartye"]
"I heard that!　Demon Lord, what are you thinking!"
[cpg cn=true]


[OnName num="kousuke"]
" Chartier ......"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye173"]
[OnName num="schartye"]
I'm not a fan of the idea, even if it is the Demon Lord's will. This country will go back to being a land of beasts.
[cpg cn=true]


Next to him, Kullulu was also there. I guess Kullulu told him off.
[cpg]

[free time=800]
[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Clolowlude226"]
[OnName num="clolowlude"]
I'm sorry, ....... I'm sorry I said that."
[cpg cn=true]


I knew it. But I'm sure she disagrees with me.
[cpg]


[OnName num="kousuke"]
" Kullulu . What do you think?
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude227"]
[OnName num="clolowlude"]
Of course I disagree. You'll be giving up the harem you've built.
[cpg cn=true]


[OnName num="kousuke"]
"...... What do you mean?"
[cpg cn=true]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye174"]
[OnName num="schartye"]
It's simple. The pheromones and magical elements you had as a Demon Lord will be lost.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye175"]
[OnName num="schartye"]
It's not just straw and Kullulu wolrd. Don't forget that even Fia is the same.
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


He says something that blows my mind. It's the ultimate choice.
[cpg]


[free time=1000]

[BG f="black.ui" time=1000]
[WAIT time=100]
[STOPBGM]
;//ブラックアウト





I asked Chartier and Kullulu to leave, telling them I would think about it for a while.
[cpg]



[window target=false]

[WAIT time=1000]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[STOPBGM]
[BGM f="bg_d3"]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




If I use this magic, I'll go back to being just an ordinary person.
[cpg]


Is that what you want? Maybe not.
[cpg]


Maybe Fia won't be attracted to me anymore.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia230"]
[OnName num="fia"]
"...... Kosuke ."
[cpg cn=true]


[OnName num="kousuke"]
" Fia . Aren't you afraid?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia231"]
[OnName num="fia"]
I'm not afraid. I'm fine.
[cpg cn=true]


[OnName num="kousuke"]
I don't know if this is the end of my love affair with you.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia232"]
[OnName num="fia"]
Please don't say that. We'll always be together.
[cpg cn=true]


[OnName num="kousuke"]
You can't be sure, can you? ...... What if you're just attracted to my pheromones, too?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia233"]
[OnName num="fia"]
"......"
[cpg cn=true]


I was feeling lonely and desperate.
[cpg]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************




[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
The two of us walked out to the castle town. Fia also had an unhappy look on her face.
[cpg]


I get the feeling that this might be the last time.
[cpg]


[OnName num="kousuke"]
"....... Fear"
[cpg cn=true]


[OnName num="kousuke"]
"Why don't we make one last memory?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Fia234"]
[OnName num="fia"]
...... Yes. I'm always willing to work with Kosuke .
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia235"]
[OnName num="fia"]
"Even if I'm no longer a demon lord, I'll still love ...... you."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





We went out for a night on the town, just the two of us. We made happy memories, thinking it might be our last.
[cpg]


It was as if we were saying goodbye. I only hoped it would not be the last time.
[cpg]




[window target=false]
[transition target={true} rule="39.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="39.png" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]




Then, on the day of the magic sealing ceremony.
[cpg]


I had decided everything on my own. I didn't tell the people anything.
[cpg]


Of course, I did tell Fia , Meir , Chartier , and Kullulu . ......
[cpg]


[STOPBGM]

*effect|Peace. Fia

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_2.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************

[window target=true]




[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye176"]
[OnName num="schartye"]
"I was really looking forward to the return of the ...... Demon King. I didn't expect you to be so spineless."
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Clolowlude228"]
[OnName num="clolowlude"]
It's true. It was our long-cherished wish.
[cpg cn=true]


I'm sure Chartier and Kullulu were against it until the end, but I guess they like him before he was a demon king.
[cpg]


[free time=800]


It's not like they were going against my will by any means.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia236"]
[OnName num="fia"]
"...... Kosuke ?"
[cpg cn=true]


[OnName num="kousuke"]
Yeah. I'm going back to being just a person now."
[cpg cn=true]


[free time=800]


It's a huge magic. A magic circle had already been drawn in the large room.
[cpg]


All I have to do is go there alone. You don't need Fia to be there.
[cpg]


In fact, it would be better if you weren't there, just in case the magic gets out of control.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sMeile022"]
[OnName num="meile"]
This will be the last time we see Kosuke as the ...... Demon Lord.
[cpg cn=true]


[OnName num="kousuke"]
Yeah. You've been a pain in the ass.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile201"]
[OnName num="meile"]
No, you haven't bothered me at all. I'm just a little sad.
[cpg cn=true]




;//ブラックアウト
[SE f="se004"]
;//【ＳＥ】『重い扉が閉まる』

[window target=false]
[transition target={true} rule="tobira2.png" color={0x000000ff} time=2000]
[WAIT time=2100]
[BG f="black.ui" time=10]
[free time=10]
[WAIT time=200]
[transition target={false} rule="tobira2.png" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


Then I entered the large room alone.
[cpg]



I drew the magic circle myself. It's a magic circle I drew myself, and once I activate it, I'm just a person again.
[cpg]



;//画面徐々に白く
[BG f="e_01_3.ui" time=2000]
[WAIT time=100]






[OnName num="kousuke"]
"...... haha."
[cpg cn=true]


Thinking about it, this is what I was originally supposed to look like.
[cpg]


[window target=false]
[transition target={true} rule="amamori3.webp" color={0x000000ff} time=2000]
[WAIT time=1100]
[window target=true]

I've been an unremarkable businessman to begin with.
[cpg]


Everything I've done so far has been unnatural.
[cpg]

[window target=false]
[BG f="e_01_1.ui" time=10]
[free time=10]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=2000]
[WAIT time=2100]
[window target=true]
[WAIT time=100]


The fact that I almost got together with Fia was just a ...... dream.
[cpg]



I don't need to feel lost in any way.
[cpg]

[BG f="black.ui" time=1000]

[FG f="e_02_2.ui" method="change_1" pos="2/3" time=1]
[WAIT time=100]


Even though I know it, even though I know it. I might be separated from Fia .
[cpg]


I almost cried a little at the thought of it.
[cpg]

[WAIT time=100]
[window target=false]



[SE f="se005"]
;//【ＳＥ】『低めの魔法の音』


[window target=false]
[transition target={true} rule="ue.webp" color={0xffffffff} time=3000]

[WAIT time=3000]
[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=2000]

[transition target={false} rule="ue.webp" color={0xffffffff} time=1000]
[WAIT time=3000]
[window target=true]


;//画面白く



[BG f="black.ui" time=2000]

[WAIT time=2500]


[window target=true]

And then.
[cpg]


My magic power has been completely sealed. I'm not a demon king, I'm a person again.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************





It seems that the demon king's magic power can be grasped to some extent even when he is far away.
[cpg]


The Elf Nation immediately reported that the wonder of the Demon King was gone.
[cpg]



;//ブラックアウト

[window target=false]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_03_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『街＿現代』（昼）******************************************************

[window target=true]




The elven nations immediately reported that the Demon Lord was no longer a threat to them, so they had no reason to target me.
[cpg]


In other words, I was no longer the one being hunted.
[cpg]

[window target=false]

[STOPBGM]

;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[window target=true]




What was left was this city that had been built with the expectation of a Demon Lord.
[cpg]


Little by little, the people learned that I, the Demon Lord, had lost my power.
[cpg]


They will be very disappointed. A riot might break out.
[cpg]


If you're not careful, they'll try to kill you again. ...... Then you can run away with Fia .
[cpg]


It's a good thing, too, because you'll be less likely to be targeted than when you were a demon king.
[cpg]

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="kousuke"]
It's a good idea. Fia I think I might have made the wrong choice.
[cpg cn=true]


[OnName num="kousuke"]
The land of the Demon Lord that people dreamed of is nowhere to be found.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia237"]
[OnName num="fia"]
"Don't worry about ......, Mr. Kosuke . Here."
[cpg cn=true]

[free time=1000]
[WAIT time=1500]

[OnName num="therianthropy_A"]
I heard!　The Demon Lord has lost his power!
[cpg cn=true]


[OnName num="kousuke"]
Yeah. That's right.
[cpg cn=true]


;//＠
[SE f="se011"]
;//【ＳＥ】『人混み』
[WAIT time=1500]

Next to me is Fia . It's not like he's going to stab you out of the blue. ......
[cpg]


[OnName num="kousuke"]
You're disillusioned with ......, aren't you? I'm sorry."
[cpg cn=true]


[OnName num="therianthropy_B"]
"No way!　This will bring peace to this country.
[cpg cn=true]


[OnName num="therianthropy_C"]
Yes. And we won't have to be afraid of a war at any moment.
[cpg cn=true]


...... I see. Maybe they were all the same on the inside.
[cpg]


It's a good thing that you're not the only one.
[cpg]


That, in turn, meant that the subhumans would be seen as a marvel.
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************





After all, it seemed that I had done a great job of uniting the subhumans.
[cpg]


I wanted a chance to unite them. That's what the Demon Lord was.
[cpg]


From that point on, maybe I didn't need the power of the Demon Lord.
[cpg]


In the end, I was left with only the title of king. But the name of the country would return to its original form.
[cpg]


I became the king of a country of beastmen despite being a human.
[cpg]



;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=1500]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




[OnName num="kousuke"]
Meir . Are you still attracted to me?
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile202"]
[OnName num="meile"]
What?　Well, I think ...... you're cool, but .........
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Schartye177"]
[OnName num="schartye"]
"Not as much as before, I guess. You can't help it, that's what you chose to do.
[cpg cn=true]


Chartier I'm not going to call you a demon king anymore.
[cpg]


I felt a little sad, but I accepted the situation. And ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Fia238"]
[OnName num="fia"]
"I still love you, Kosuke ."
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude229"]
[OnName num="clolowlude"]
How can you say that in public?
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia239"]
[OnName num="fia"]
It's the truth. I wasn't attracted to Kosuke because he was a demon king."
[cpg cn=true]


Fia was still attracted to me.
[cpg]


The other three didn't tell me they liked me as much as they used to.
[cpg]


It seems that Fia was the only one who was truly connected to me without pheromones.
[cpg]


But that was enough. I became a mere king, and my next thought was ......
[cpg]


[OnName num="kousuke"]
Fia . Are you going to be a queen?"
[cpg cn=true]


[FACE method="change_5" pos="1/2"]
[VOICE f="Fia240"]
[OnName num="fia"]
"What ......?　Is that...
[cpg cn=true]

[FACE method="change_7" pos="2/2"]

[VOICE f="sClolowlude013"]
[OnName num="clolowlude"]
"...... Proposal?　In front of all these people?
[cpg cn=true]


After all, my goal was also to make a subhuman wife.
[cpg]


[OnName num="kousuke"]
"What do you think? You'll get a lot of power."
[cpg cn=true]


That's just a pretext. The truth is, I want you to be attracted to me because of my original humanity.
[cpg]


That's all I want Fia .
[cpg]

[free time=800]
[WAIT time=1]
[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Fia241"]
[OnName num="fia"]
"...... Yes. If it's okay with me."
[cpg cn=true]


Fia smiled and said.
[cpg]


[free time=800]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile203"]
[OnName num="meile"]
I don't want to bother you any more. Let's go home, people.
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sSchartye021"]
[OnName num="schartye"]
"Well, ......, let's just say be happy, shall we?"
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. I will be happy."
[cpg cn=true]


[free time=800]
[WAIT time=800]


[SE f="se004"]
;//【ＳＥ】『ドア閉まる』





And then it's just the two of us. We look at each other at close range.
[cpg]


[FG f="CHA01_p7_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia242"]
[OnName num="fia"]
" Kosuke . I've always wanted to be by your side.
[cpg cn=true]


[OnName num="kousuke"]
"It's always been that way. And I always will."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Fia243"]
[OnName num="fia"]
"...... Yes. I'm glad.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//Ｈシーンカット



[BG f="b_11_4.ui" time=1000]
[WAIT time=1100]
;//【ＢＧ】『空』（夜）******************************************************



There is nothing that can disturb us anymore.
[cpg]


In the past, it was inevitable that we would be disturbed. ......
[cpg]


I'm not a demon king anymore. As a result, I'm the king of a country.
[cpg]


But even so, the chances of an attempt on your life have been drastically reduced.
[cpg]



;//ブラックアウト
[WAIT time=1000]

[STOPBGM]


[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************





As I looked around the castle town, I saw a gentle flow of time.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye178"]
[OnName num="schartye"]
It's peaceful.
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude230"]
[OnName num="clolowlude"]
It's true. It's so peaceful.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye179"]
[OnName num="schartye"]
If you'd like, you can try ...... the Demon Lord's power again.
[cpg cn=true]


[OnName num="kousuke"]
What are you talking about, you two?
[cpg cn=true]

[FACE method="change_1" pos="1/2"]
[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude231"]
[OnName num="clolowlude"]
Oh, there you are. It's nothing. You're not a demon king anymore.
[cpg cn=true]


It's pretty cold, but Chartier and Kullulu are still in the country.
[cpg]


You will find a lot of things that you can do to make your life easier.
[cpg]


Even if they are, I'll stop them this time. That's what I thought.
[cpg]

[STOPBGM]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





After all, I was able to create a harem because I was the Demon King.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia264"]
[OnName num="fia"]
Kosuke . It seems that the wheat crop is failing in Japan.
[cpg cn=true]


[OnName num="kousuke"]
Oh, we have to do something about that. ...... But it's impossible to do anything about it with magic anymore. ......
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia265"]
[OnName num="fia"]
This is why your skills will be tested. Good luck, Kosuke ."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Fia266"]
[OnName num="fia"]
"I'll do my best too. As your queen.
[cpg cn=true]


Now that I'm just a person, I can feel more that Fia really loves me.
[cpg]


Although Fia and I stood at the top of the beast kingdom, that doesn't mean we control everything.
[cpg]


Still, I wanted to do what I could.
[cpg]


It was like I was paying for building a harem as a demon king. That may have been the only reason.
[cpg]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[STOPBGM]
[BG f="black.ui" time=1]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]

[WAIT time=1000]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




And even if you think about it, you're happy now.
[cpg]


Fia is right next to me. We didn't have anything else to ask for.
[cpg]


[FG f="CHA01_p7_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Fia267"]
[OnName num="fia"]
"...... Kosuke . Do you want to have a baby?
[cpg cn=true]


[OnName num="kousuke"]
"Yes. Yes, I do.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia268"]
[OnName num="fia"]
"When you have a baby, you'll be a princess or a prince. ......
[cpg cn=true]


[OnName num="kousuke"]
Yeah. ...... I can't imagine what that would be like.
[cpg cn=true]


I've got the life I've always dreamed of with my subhuman wife.
[cpg]


It's a good idea to have a good idea of what you're looking for.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト

;//========================================
;//●ＣＧ（二人ベッドで寄り添っている）ev_32
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城内＿主人公の部屋
;//時間　：夜
;//========================================

*Scene012

[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[STOPBGM]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_32_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="Fia289"]
[OnName num="fia"]
...... I wonder what will happen to us now.
[cpg cn=true]


[OnName num="kousuke"]
That's not like you. Is that what you're worried about?
[cpg cn=true]



[VOICE f="Fia290"]
[OnName num="fia"]
I don't think I'll ever stop loving you, Kosuke .
[cpg cn=true]



[VOICE f="Fia291"]
[OnName num="fia"]
But when you're the king and queen, ...... you may not be able to have a normal relationship.
[cpg cn=true]


[OnName num="kousuke"]
It's too late for that. We're not in love, we're married.
[cpg cn=true]



[VOICE f="Fia292"]
[OnName num="fia"]
...... Is a king and queen still a couple?
[cpg cn=true]


[OnName num="kousuke"]
That's right. If they are not husband and wife, what are they?
[cpg cn=true]


Such an idle conversation. We are getting sleepy as we repeat this conversation.
[cpg]



[VOICE f="Fia293"]
[OnName num="fia"]
I'll do my best to help ...... Kosuke more.
[cpg cn=true]



[VOICE f="Fia294"]
[OnName num="fia"]
I want to have a baby and be a proud mother to her child.
[cpg cn=true]


Even as she said this, Fia was looking rather sleepy.
[cpg]


[VOICE f="Fia295"]
[OnName num="fia"]
Then ...... Kosuke Mr. ......."
[cpg cn=true]

;**【ＣＧ】 ev_32_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=100]

And then Fia fell completely asleep.
[cpg]



[VOICE f="Fia296"]
[OnName num="fia"]
"...... sigh, sigh ......."
[cpg cn=true]


I cuddled up with him and decided to go to sleep.
[cpg]


I close my eyes, hoping for the same peaceful morning tomorrow.
[cpg]



;//ＥＮＤ　ヒロイン１平和ルート

[WAIT time=100]
[jump storage="epend.ks" target="*start"]


