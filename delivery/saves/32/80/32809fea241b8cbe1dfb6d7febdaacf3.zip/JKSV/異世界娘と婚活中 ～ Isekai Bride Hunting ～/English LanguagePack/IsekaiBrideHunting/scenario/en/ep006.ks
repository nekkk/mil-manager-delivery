
;//==============================
;//２、メイル

*start

*ep006
*IseSel09_2|I'm a demon king. Meir

[SCENE id=6]


It was Meir . I want her and I to rule this world together.
[cpg]


I don't know if Meir is good at magic, and I don't know what kind of opinion I can get from her. ......
[cpg]


Still, I went to Meir 's room.
[cpg]




;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]

[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************





[OnName num="kousuke"]
That's why I need your wisdom. Meir "
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile361"]
[OnName num="meile"]
"You're going to ...... talk to me?　Why me?
[cpg cn=true]


[OnName num="kousuke"]
I can't ask anyone but you. You have to understand.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile362"]
[OnName num="meile"]
I don't understand. There are a lot of people smarter than me.
[cpg cn=true]


[OnName num="kousuke"]
That's not the point. I want Meir .
[cpg cn=true]


I wonder if Meir knows what I'm thinking.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile363"]
[OnName num="meile"]
I'm not very smart, so I might not be able to come up with anything .......
[cpg cn=true]


[OnName num="kousuke"]
"That's okay. Meir is my ......."
[cpg cn=true]


I didn't say anything else. Meir blushes.
[cpg]


He seemed to have guessed. We don't say it in words, but we both like each other.
[cpg]


From Meir 's perspective, I owe him my life. It's not surprising that this is the case.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile364"]
[OnName num="meile"]
I don't know much about magic, but I'm not a fan. I don't know much about magic, ...... but maybe that's why I can think of something."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. Can you think of anything?
[cpg cn=true]


Meir and I talked about this and that for a while.
[cpg]


Some of the things Meir said were ridiculous, but some of them were good ideas.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile365"]
[OnName num="meile"]
The other day, we cut the elf nation to the bone. I wonder if we can apply that to humans instead of subhumans?"
[cpg cn=true]


[OnName num="kousuke"]
"...... sure ......."
[cpg cn=true]


Why do my pheromones only work on subhumans?
[cpg]


If this were to expand its range to humans, it could be applied to other countries.
[cpg]


Maybe we can create magic on a larger scale.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile366"]
[OnName num="meile"]
Oh, did I say something good?
[cpg cn=true]


[OnName num="kousuke"]
"Yes, you did. Well said.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Meile367"]
[OnName num="meile"]
Now, give me your ...... reward.
[cpg cn=true]



Then give me that Meir reward." Sighing, squirmed. In a roundabout way, ......
[cpg]

[VOICE f="sMeile051"]
[OnName num="meile"]
It's not that we don't like each other, it's just that we want to be warm.
[cpg cn=true]

I'm not saying that I like each other. But there was definitely love there.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[BG f="b_06_4_l.ui" time=1000]
[WAIT time=1100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************




I go into Meir 's room. Then I chanted a spell.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile368"]
[OnName num="meile"]
What?　What are you doing?"
[cpg cn=true]


[OnName num="kousuke"]
"No. You want some warmth.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Meile369"]
[OnName num="meile"]
Wait, wait, wait. I don't want it to be too uncomfortable. ...... Hey, are you listening?
[cpg cn=true]






;//========================================
;//●ＣＧ（スライムに包み込まれるヒロイン）ev_56
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：スライム　　服装ex：無し
;//場所　：城内＿ヒロイン２の部屋
;//時間　：夜
;//========================================

*Scene045

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]
[WAIT time=1000]


[BGM f="bg_h1"]
;**【ＣＧ】 ev_56_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=100]


In response to Meir , who sensed a bad premonition, I chanted a spell while playing dumb.
[cpg]

[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』
[WAIT time=1000]


And then the demon called slime was summoned.
[cpg]

[VOICE f="sMeile052"]
[OnName num="meile"]
"Hey, I told you so. ......!"
[cpg cn=true]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

The slime is clinging to Meir me.
[cpg]

[OnName num="kousuke"]
"It's a feverish slime, so if you're talking warmth, you've got plenty."
[cpg cn=true]

[VOICE f="sMeile053"]
[OnName num="meile"]
That's not what I meant.
[cpg cn=true]

[OnName num="kousuke"]
Don't be so selfish.
[cpg cn=true]

;**【ＣＧ】 ev_56_a ***********************
[CG id=15 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile054"]
[OnName num="meile"]
Ugh, it's slimy ...... and gross.
[cpg cn=true]

[OnName num="kousuke"]
Don't say too much about what I've summoned.
[cpg cn=true]

[VOICE f="sMeile055"]
[OnName num="meile"]
"Don't be so mean, ......!"
[cpg cn=true]

She did not like it, but she did not run away from the scene.
[cpg]

Or rather, even if you wanted to escape, you couldn't?
[cpg]

A slime, once swallowed, is said to make it difficult to move the body freely,.......
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


After playing with it for a while, I released the summoning magic.
[cpg]


[OnName num="kousuke"]
I'm sorry. I just want to make fun of types like Meir ."
[cpg cn=true]


[VOICE f="sMeile056"]
[OnName num="meile"]
...... is awful.
[cpg cn=true]



[STOPBGM]

[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_06_4.ui" time=1000]
[WAIT time=200]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile390"]
[OnName num="meile"]
"....... Do Kosuke ...... Kosuke like me?"
[cpg cn=true]


Suddenly, Meir started to ask.
[cpg]


Is it a casual question, or was it something he wanted to say from the bottom of his heart?
[cpg]


[OnName num="kousuke"]
"Of course. I love you, Meir ."
[cpg cn=true]

[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]

Meir smiled, satisfied. I stroked her head, and she purred like a cat.
[cpg]


She and I have developed an unusual relationship.
[cpg]


It's different from Fia , Chartier , and Kullulu .
[cpg]


Maybe this is what you call love.
[cpg]





;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





But I'm trying to manipulate that love.
[cpg]


The magic of fascination. I'm going to make every woman in the world, human or otherwise, mine.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Fia595"]
[OnName num="fia"]
...... was too far-fetched for me to come up with.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye343"]
[OnName num="schartye"]
That's true. It's not easy to charm a human woman.
[cpg cn=true]


[FACE method="change_2" pos="3/3"]
[VOICE f="Clolowlude271"]
[OnName num="clolowlude"]
But I'm sure Kosuke would do it.
[cpg cn=true]


[OnName num="kousuke"]
You know what I mean. I do.
[cpg cn=true]


If this were to happen, it would lead to world domination.
[cpg]


Even if you consider that most military personnel are men, in the long run, a nation cannot exist without women.
[cpg]


Depending on how you use them, you might be able to treat them like hostages, right?
[cpg]


I was going to gather all the women in the world into the Demon Lord's country.
[cpg]

[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





I'm going to research magic. The magic of fascination is a strange thing, and the degree of liking seems to be fixed.
[cpg]


Even if the magic can lead you to the stage where you don't want to disobey because you like him,......
[cpg]


From that point on. It seems that there is nothing that magic can do to help you fall in love.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile391"]
[OnName num="meile"]
So that means that me and Kosuke are connected regardless of magic, right?
[cpg cn=true]


[OnName num="kousuke"]
I don't know. I don't know. There's also the pheromone thing.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile392"]
[OnName num="meile"]
I don't know. Tell me you're lying about that.
[cpg cn=true]


[OnName num="kousuke"]
But if you can charm me to the point where I can't resist, that's all that matters. This magic is truly invincible, if you use it right.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile393"]
[OnName num="meile"]
Not that it matters to me, because I'm already mesmerized.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile394"]
[OnName num="meile"]
Hey, Kosuke . Hey, Kosuke . I don't think magic or pheromones have anything to do with ."
[cpg cn=true]


She' s trying to make me say it. I could only nod.
[cpg]


[OnName num="kousuke"]
...... Yeah.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile395"]
[OnName num="meile"]
"Hmmm. We'll always be together, Kosuke .
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************




Fia , Chartier , Kullulu The three Uruds are skilled in magic.
[cpg]


It's a good idea to have a good idea of what you're looking for.
[cpg]



So I couldn't leave Meir out of the group. The five of us, including me, were in the room most of the time.
[cpg]

The opinions of Meir , who had no knowledge of magic, seemed new to Fia and the others.
[cpg]

But with five people in the room, my room was a bit cramped, even though it was large.
[cpg]


[STOPBGM]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]

[BG f="b_06_4.ui" time=1000]

[BGM f="bg_d3"]
[WAIT time=1000]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





And at night, I was finally alone .......
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile396"]
[OnName num="meile"]
"Hey, hey, Kosuke . Is there really such a thing as beastmen magic?
[cpg cn=true]


I was not alone. Meir didn't come back.
[cpg]


[OnName num="kousuke"]
"What's with the sudden ......, I heard there is such magic.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile397"]
[OnName num="meile"]
I want you to try it. I've been a beast since I was born, you know.
[cpg cn=true]


[OnName num="kousuke"]
Well, yeah.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMeile057"]
[OnName num="meile"]
I'd like to see what happens when Kosuke turns into a beast.
[cpg cn=true]


[OnName num="kousuke"]
That's an interesting hobby. No, it's .......
[cpg cn=true]

It's not like humans are attracted to beastmen.
[cpg]

In fact, from her point of view, it is more normal to be a beastman.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I don't know if there are any side effects to the magic of beastmen or not.
[cpg]


I don't know if there are any side effects to this magic, but I thought I'd just try. Because Meir is asking for it.
[cpg]


[OnName num="kousuke"]
The magic of beastmen.
[cpg cn=true]


It's the magic of beastmen. It's really a battle magic.
[cpg]


It's a good idea to have a good idea of what you're doing. It's also a strange kind of excitement.
[cpg]


It's a good idea to have a good idea of what you're looking for.
[cpg]


And from that point on, the memory of the rest of the day flew away.
[cpg]










;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]



[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************

[window target=true]


[SE f="se017"]
;//【ＳＥ】『鳥の鳴き声』



[WAIT time=1000]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye344"]
[OnName num="schartye"]
"You two are getting along great."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Meile446"]
[OnName num="meile"]
"What ......?　Oh, this is..."
[cpg cn=true]


My magic was broken, and we were both on the futon together in our human form.
[cpg]


[OnName num="kousuke"]
"Knock, please. Knock on Chartier ."
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye345"]
[OnName num="schartye"]
I did. You were worried when you didn't get an answer.
[cpg cn=true]


[OnName num="kousuke"]
...... I see. So, what do you want?
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Schartye346"]
[OnName num="schartye"]
My business is with Meir rather than with you, Demon Lord.
[cpg cn=true]


Meir was flabbergasted at the sudden turn of events.
[cpg]


[FACE method="change_5" pos="2/2"]
[VOICE f="Meile447"]
[OnName num="meile"]
"What?　Me?"
[cpg cn=true]


[OnName num="kousuke"]
What is it? What's going on?
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye347"]
[OnName num="schartye"]
It's not that something happened, it's that something's going to happen.
[cpg cn=true]


[free time=800]
[STOPBGM]


I couldn't see what he was saying. I waited for Chartier to speak.
[cpg]

[BGM f="bg_si"]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Schartye348"]
[OnName num="schartye"]
In other words, Meir ...... do you know what it means for the Demon Lord to acquire further enchantment magic?
[cpg cn=true]

[FACE method="change_7" pos="2/2"]
[OnName num="kousuke"]
"......"
[cpg cn=true]


Somehow, I've come to understand. I wondered if Meir could remain in love with me.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye349"]
[OnName num="schartye"]
I don't care what you say. But I also feel sorry for him.
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Meile448"]
[OnName num="meile"]
"What does ...... mean?"
[cpg cn=true]


Since Meir doesn't seem to understand yet, I'll explain.
[cpg]


[OnName num="kousuke"]
Maybe humans and subhumans will come to me without distinction.
[cpg cn=true]


[OnName num="kousuke"]
"How can you not be jealous?"
[cpg cn=true]


Can you not be jealous?" Meir was silent for a moment and then said, "I am jealous.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Meile449"]
[OnName num="meile"]
I'm jealous. Of course I'm jealous. Of course I'm jealous of Fia and Chartier ."
[cpg cn=true]


Is that so?　Then why are they making me develop this magic?
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Meile450"]
[OnName num="meile"]
But more than that, I want to fulfill Kosuke 's wishes. If you're afraid for your life, I want to solve it."
[cpg cn=true]


Chartier sighed a little. And.
[cpg]


[FACE method="change_2" pos="1/2"]
[VOICE f="Schartye350"]
[OnName num="schartye"]
You didn't have to worry about it. It's nothing, just forget it.
[cpg cn=true]



[free time=800]


[SE f="se008"]
;//【ＳＥ】『歩く』





And then he left. I was a bit taken aback.
[cpg]


[OnName num="kousuke"]
"......, don't you ever get possessive?"
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile451"]
[OnName num="meile"]
I said, "Yes, I do. It's more that I want Kosuke to be happy."
[cpg cn=true]


...... I'm kind of scared that I'm too single-minded. It makes me wonder if I'm being the person she wants me to be.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_d2"]
[WAIT time=1000]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************





However, if you think about it, the fact that I chose Meir may also be a story that will make ...... people jealous.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="1/2" time=800]

[VOICE f="Fia596"]
[OnName num="fia"]
"Oh, Kosuke . Good morning, ...... and Meir ."
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Meile452"]
[OnName num="meile"]
"Yes. Good morning, Fia ."
[cpg cn=true]


I'm sure Fia is jealous of Meir . It's not like she doesn't have any feelings for me.
[cpg]


When I think about it, I'm probably doing something pretty sinful.
[cpg]


But it's impossible to love everyone equally.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia597"]
[OnName num="fia"]
"What's wrong, Kosuke ?"
[cpg cn=true]


[OnName num="kousuke"]
Oh, no, it's nothing ....... Just ......."
[cpg cn=true]


[OnName num="kousuke"]
I'm just wondering if maybe I'm guilty of something.
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Meile453"]
[OnName num="meile"]
...... Why?
[cpg cn=true]


[OnName num="kousuke"]
Everyone is attracted to my pheromones, but only one person can respond to them.
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="Fia598"]
[OnName num="fia"]
You don't have to worry about that. You're a demon king, you should be able to stand your ground.
[cpg cn=true]


[OnName num="kousuke"]
...... You're right.
[cpg cn=true]


I know. I just love Meir as much as I can.
[cpg]



;//ブラックアウト

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





I will continue to research magic. In the meantime, I've been taking care of Meir .
[cpg]

[FG f="CHA02_p7_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sMeile058"]
[OnName num="meile"]
"...... Hey, Kosuke. You can't summon the slime from that time anymore."
[cpg cn=true]

[OnName num="kousuke"]
"You're the one asking for it. Have you become addicted to it?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="sMeile059"]
[OnName num="meile"]
"Heh heh."
[cpg cn=true]

As we talked, the magic was nearing completion.
[cpg]








;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





While occasionally flirting with Meir , I did what I had to do.
[cpg]


While loving on my beloved, my life was in imminent danger.
[cpg]


[OnName num="kousuke"]
Okay, it's done. ......
[cpg cn=true]


The magic of enchantment has been completed. It was possible to create a magic that could encompass this world with my magic power.
[cpg]


[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************





You will need a very large magic circle. It needed to encompass this country and the entire world.
[cpg]


I'm sure you'll be able to figure out how to make it happen.
[cpg]


[OnName num="kousuke"]
...... It seems like the people in this country will really listen to anything I have to say.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Meile477"]
[OnName num="meile"]
"I guess so. They love Kosuke .
[cpg cn=true]


I had the whole city, the whole country, drawing magic circles.
[cpg]


A magic circle can be drawn in blood, but it is difficult to draw something of this scale in blood.
[cpg]


It's more important to have an undisturbed pattern.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye351"]
[OnName num="schartye"]
The current Demon Lord could probably summon a dragon. I'm sure you'll be able to figure out how to do it.
[cpg cn=true]


[OnName num="kousuke"]
I don't want to play with life like that.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Fia599"]
[OnName num="fia"]
It seems that Kosuke also summons demons for women, doesn't it?
[cpg cn=true]


[OnName num="kousuke"]
It's different from that. It's different when you take a life.
[cpg cn=true]


What a quibbling thing to say.
[cpg]



;//ブラックアウト
[STOPBGM]


[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[free time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_02_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（夜）******************************************************

[window target=true]




The magic was activated. The ultimate magic of fascination.
[cpg]


From that day on, women all over the world will be fascinated by me and will be aiming for the land of the Demon King .......
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_03_4.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『街＿現代』（夜）******************************************************





It does not matter what race you are, of course.
[cpg]


For example, it would have an effect on women in Japan, a neighboring country.
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[transition target={true} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************





The effect appeared in a few days.
[cpg]


The demon king's country is not that big, but all the women are gathering there.
[cpg]


Buildings were being built and more and more developed.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile478"]
[OnName num="meile"]
The other countries seem to be on alert. They can't leave Kosuke alone.
[cpg cn=true]


[OnName num="kousuke"]
"I guess so, .......
[cpg cn=true]


But I think I've won the battle.
[cpg]


Without women, the population will only decrease, so other countries will start to take advantage of the deal.
[cpg]


I think we're going to have to start competing with other countries on things that aren't military power.
[cpg]


The country of the Demon King is unique, and it would not be possible without magic.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile479"]
[OnName num="meile"]
You see, the magic of enchantment ...... shouldn't work on people who are already enchanted, right?
[cpg cn=true]


[OnName num="kousuke"]
But ...... Meir 's face is red, isn't it?
[cpg cn=true]


[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile480"]
[OnName num="meile"]
"Heh, they'll know."
[cpg cn=true]


Meir is rubbing off on me. He's like an animal, really.
[cpg]


[OnName num="kousuke"]
He's a cute guy.
[cpg cn=true]


[VOICE f="sMeile060"]
[OnName num="meile"]
I got a compliment. I got a compliment.
[cpg cn=true]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】衣擦れ


Afterwards, I gave Meir a gentle hug.
[cpg]



The Meir looked satisfied ...... and seemed to have forgiven me.
[cpg]


And then the night comes again.
[cpg]

[STOPBGM]

[WAIT time=1100]


[BG f="b_05_4.ui" time=1000]

[WAIT time=1100]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************



There are still many women in the land of the Demon King, and the one closest to me Meir has become jealous.
[cpg]


[OnName num="kousuke"]
You're in a lot of trouble, aren't you, ......? You're in a tight spot."
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile501"]
[OnName num="meile"]
"Why?　I don't care about that.
[cpg cn=true]


[OnName num="kousuke"]
But that doesn't mean you don't think about it.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile502"]
[OnName num="meile"]
Yeah, but ...... it's also kind of nice to be jealous.
[cpg cn=true]


Meir It's an uncharacteristic thing to say. Is it a feeling of superiority?
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile503"]
[OnName num="meile"]
It's nice when someone you like Kosuke is liked by everyone.
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


I guess I've been thinking in a twisted way. Maybe Meir is just as single-minded as they come.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile504"]
[OnName num="meile"]
I'm sure you'll be happy to hear that.
[cpg cn=true]


[OnName num="kousuke"]
It's ......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile505"]
[OnName num="meile"]
If we could do that, no one would have anything to fight over. It would be a world where we could all live in peace.
[cpg cn=true]


...... Of course that's not possible. It's not a magic that you need as a demon king, so you can't make it.
[cpg]


But I didn't want to give up too soon.
[cpg]


I wanted to conquer the world so that there would be no conflict for the Meir sake.
[cpg]



;//ブラックアウト
[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





At night, I always slept with Meir .
[cpg]


I didn't officially make Meir my queen. Still, ......
[cpg]


I wanted to stay by her side for as long as possible.
[cpg]


That's probably what Meir is thinking as well.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************



[SE f="se017"]
;//【ＳＥ】『鳥の鳴き声』

Then we both wake up. Sometimes I wake Meir up, sometimes the other way around.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile506"]
[OnName num="meile"]
"...... wow, is it morning already ......?"
[cpg cn=true]


Today I was the first to wake up.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile507"]
[OnName num="meile"]
"Good morning, Kosuke ......."
[cpg cn=true]


[OnName num="kousuke"]
Oh, good morning.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile508"]
[OnName num="meile"]
Um, what are we doing today?
[cpg cn=true]


[OnName num="kousuke"]
For the time being, I have to deal with politics, not magic research.
[cpg cn=true]


Politics is not my thing. But it was not something that could be left to Meir .
[cpg]



;//ブラックアウト
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************





Even so, my position will never be changed.
[cpg]


After all, most of the people in this country are under the spell of my enchantment.
[cpg]


[OnName num="therianthropy_woman"]
"Oh, Demon Lord!
[cpg cn=true]


[OnName num="human_woman"]
Good morning!　Today is another interesting day. ......"
[cpg cn=true]


What kind of reaction is that? I wonder if Meir really thinks nothing of it.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="1/2" time=800]

When I looked at Meir next to her, she was smiling.
[cpg]


If she's okay with this, then I'm okay with it.
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]

When I got back to the castle, Meir was rubbing up against me more than in person.
[cpg]



When I patted her on the head, she seemed really happy.
[cpg]

[OnName num="kousuke"]
He's really like an animal.
[cpg cn=true]

[VOICE f="sMeile061"]
[OnName num="meile"]
He's a beastman.
[cpg cn=true]

"He's a beastman," he said only when it suited him. But that part was cute too.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト



After that, we were flirting in peace.
[cpg]


It's good to have a reward like this for overcoming a crisis that threatened your life. ......
[cpg]

[STOPBGM]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




With the magic of enchantment, the immediate crisis was averted.
[cpg]


To a certain extent, the political situation in the country has been stabilized. I'm going to do what I have to do next.
[cpg]

[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="kousuke"]
I have to do what I have to do next. ...... Would you like to be my queen, Meir ?"
[cpg cn=true]


I'm embarrassed to admit that my proposal was a bit over the top. This is the kind of relationship we had.
[cpg]


It's a bit far-fetched to say that I'm going to be a queen. But I was okay with it.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile532"]
[OnName num="meile"]
"Yes, I will. You'll be Kosuke's wife."
[cpg cn=true]


Meir laughed, and I laughed along with him.
[cpg]


[OnName num="kousuke"]
I knew there was no way ...... would say no, but I was a little nervous.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile533"]
[OnName num="meile"]
"I see. You don't have to be nervous.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile534"]
[OnName num="meile"]
Hey, Kosuke ......, I remember something from when I was really little.
[cpg cn=true]


[OnName num="kousuke"]
What is it?　What do you mean, "I remember." ......
[cpg cn=true]


No, wait. Meir has been asleep for a long time. It never got old. ......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile535"]
[OnName num="meile"]
"Maybe I met Kosuke before I was reincarnated. I think."
[cpg cn=true]


The disease of Meir is a disease that causes the body to stop time. It's like a magical curse.
[cpg]


In other words, Meir was born a long time ago.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile536"]
[OnName num="meile"]
Before he got sick, a pre-incarnated Kosuke came to our village, I think.
[cpg cn=true]


The young Meir remembers the pre-reincarnation demon king playing with him there.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile537"]
[OnName num="meile"]
I'm sure you'll agree. I told him I wanted to be his wife.
[cpg cn=true]


[OnName num="kousuke"]
How did you respond to ...... that?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile538"]
[OnName num="meile"]
He said, "I have Chartier ," he said. I have a different lifespan than you.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile539"]
[OnName num="meile"]
"But he said we might be reincarnated and get together. That time, Kosuke ......."
[cpg cn=true]


In fact, Meir was never reborn, time stopped and only I was reborn, and now we are together.
[cpg]


[OnName num="kousuke"]
It's a romantic story. You're not making this up, are you?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Meile540"]
[OnName num="meile"]
"Oh, you don't believe me?　That's terrible.
[cpg cn=true]


[OnName num="kousuke"]
I'm kidding. I think it was fate that brought me to Meir .
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[FG f="CHA02_p7_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile541"]
[OnName num="meile"]
Yeah, ......, that's right. It's fate, isn't it?
[cpg cn=true]


Me and Meir kissed each other. For a while, this country will remain peaceful.
[cpg]


You will find a lot of people who are interested in this kind of thing.
[cpg]


So, I guess it's okay to just bask in it for now.
[cpg]



;//ＥＮＤ　ヒロイン２征服ルート

[WAIT time=100]
[jump storage="epend.ks" target="*start"]
[WAIT time=100]
;[s]
[WAIT time=100]
[WAIT time=100]



