
;//==============================
;//１、フィア

*start

*ep005
*IseSel09_1|Demon King. Fia

[SCENE id=5]


Fia . I want to make her my queen, the Demon King.
[cpg]


With that in mind, I decided to go to the room where Fia lived.
[cpg]



[window target=false]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]

[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************


[window target=true]



[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia318"]
[OnName num="fia"]
...... What is it?　At this time of night?
[cpg cn=true]


[OnName num="kousuke"]
"I have a few things to discuss."
[cpg cn=true]


I explained to him. I explained to him that I was determined to conquer this world.
[cpg]


The expression on Fia 's face grew cloudy. I'm sure the pacifist in you won't agree with that.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia319"]
[OnName num="fia"]
I think there are ways to live in peace without ...... world domination.
[cpg cn=true]


[OnName num="kousuke"]
"You defy me? You mean defying the Demon Lord.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia320"]
[OnName num="fia"]
...... Still, I can't do it. I want peace.
[cpg cn=true]


Fia I don't know if I'll ever be able to keep you as a friend.
[cpg]


Even though I thought that, I still wanted to make Fia my queen.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト


[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]



[OnName num="kousuke"]
"Not a ...... mate, but a queen."
[cpg cn=true]

I thought about it in my head, and it felt right.
[cpg]

We are attracted to each other because of our conflicting thoughts.
[cpg]

;//Ｈシーンカット


;//ブラックアウト


[WAIT time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************






The next day. The next day, I gathered the four of us together and decided to talk about what we were going to do.
[cpg]


[OnName num="kousuke"]
I've already told Fia that I'm going to take over the world. I'm going to take over the world so that I can live in peace."
[cpg cn=true]


The four of us were silent for a moment, but then Chartier spoke up.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Schartye333"]
[OnName num="schartye"]
I've already said it. That's what the Demon Lord is all about.
[cpg cn=true]


And then they clapped. Kullulu also clapped.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Clolowlude260"]
[OnName num="clolowlude"]
My arms are ringing. I'm sure you can handle any kind of magic, so ...... I'll teach you.
[cpg cn=true]





[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="sMeile046"]
[OnName num="meile"]
"Yeah, why not?　I'll go along with whatever Kosuke wants to do."
[cpg cn=true]


Meir seems to respect my opinion.
[cpg]




Fia seems to respect my opinion. , on the other hand, is confused. Only one person seemed to have a different opinion.
[cpg]

[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=1000]
[VOICE f="Fia343"]
[OnName num="fia"]
I'm against it. As I said yesterday, Kosuke ..."
[cpg cn=true]


[OnName num="kousuke"]
I'm going to do it even if you disagree. I just wanted to let you know, I'm not asking for your opinion.
[cpg cn=true]


Fia couldn't say anything and slumped down.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





I then worked with Chartier and Kullulu to develop magic for the military.
[cpg]


Even though Fia had knowledge of magic and could have helped, they did not.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye334"]
[OnName num="schartye"]
This is where the power would be increased.
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude261"]
[OnName num="clolowlude"]
Chartier , there's no need to go overboard with the power here, a half-kill would be fine.
[cpg cn=true]


Chartier and Kullulu responded to my suggestion with some crazy replies, but ......
[cpg]


It was the noise of things that I had asked for in the first place. Finally, I was about to become a real demon king.
[cpg]



;//ブラックアウト

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_3.ui" time=1000]

[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夕方）******************************************************





[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia344"]
[OnName num="fia"]
...... I'm not convinced."
[cpg cn=true]


I'm sure you are. He might have thought that being loved by me was somehow white.
[cpg]

[OnName num="kousuke"]
I'll keep saying I love you until Fia feels the same way."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sFia030"]
[OnName num="fia"]
I'll keep saying I love you until ...... feels the same way. You can't say you like me.
[cpg cn=true]

[OnName num="kousuke"]
I don't know, man. I still like you.
[cpg cn=true]

She didn't answer anything. But I felt that this was one answer.
[cpg cn=true]

Fia is lost. It's not the only way to get rid of me.
[cpg cn=true]


;//ブラックアウト


;//Ｈシーンカット

;//Ｈシーンカット


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************



[OnName num="kousuke"]
I'm thinking of invading the land of the elves soon .......
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia394"]
[OnName num="fia"]
Yes ......, finally.
[cpg cn=true]


Fia had an unhappy expression on her face. That's right.
[cpg]


It's a good idea to have a good idea of what you're looking for.
[cpg]


It's not like I'm trying to destroy everything and kill everyone.
[cpg]


I'm not trying to destroy everything and kill everyone, but I'm also trying to create magic that only diminishes our ability to fight.
[cpg]


I still thought it would be better to have as few deaths as possible.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia395"]
[OnName num="fia"]
Kosuke I still thought it would be better to have as few deaths as possible. I have a favor to ask of you.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia396"]
[OnName num="fia"]
The land of the elves is my home. So...
[cpg cn=true]


[OnName num="kousuke"]
" Fia . It doesn't matter if you stop me.
[cpg cn=true]


[OnName num="kousuke"]
I just thought I'd tell you before anyone else does.
[cpg cn=true]


I just wanted to tell you before anyone else. Fia said nothing and slumped.
[cpg]



;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="162.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="162.jpg" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]


[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************


[window target=true]



The next day. I had gathered the four of us together.
[cpg]


The next day, I gathered the four of us together, and they all seemed to have some idea of what I had decided.
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[OnName num="kousuke"]
I've perfected a new spell. I've perfected a new spell, tentatively named Sleep Magic."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye335"]
[OnName num="schartye"]
"Oh, come on. I'm sure the Demon Lord didn't perfect it with my help.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Clolowlude262"]
[OnName num="clolowlude"]
Well, well, well. It's okay, you seem to want to say it.
[cpg cn=true]


Chartier interjects. But that's not the main point.
[cpg]


[OnName num="kousuke"]
It will have a tremendous effect on the battlefield. It's the kind of magic that makes it impossible to stand still, even if you don't go to sleep.
[cpg cn=true]


[OnName num="kousuke"]
It's also very far-reaching. If I go in alone, and then call in the soldiers, I can ......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile353"]
[OnName num="meile"]
"It might be able to neutralize any country. I'm not sure I understand."
[cpg cn=true]


[OnName num="kousuke"]
I think the first place I'm going to use this magic is in the land of the elves.
[cpg cn=true]


Fia bites his lip. I'm sure you'll get that look.
[cpg]


[OnName num="kousuke"]
"I'm sorry Fia , but ...... is the country that is most hostile to me. I want to take it down first."
[cpg cn=true]

;//;[FO layer="2/2"]



[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sFia031"]
[OnName num="fia"]
"You mean ...... warfare, right?"
[cpg cn=true]


[OnName num="kousuke"]
As much as possible, I don't want to kill them. It's more efficient to capture them and turn them into soldiers.
[cpg cn=true]


I don't agree with Fia . You don't have to say anything, but everyone knows it.
[cpg]


[OnName num="kousuke"]
" Fia . You still don't like it?
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia397"]
[OnName num="fia"]
"......, of course."
[cpg cn=true]


I'm sure you do. Even if you don't go around killing people, it's still conquest.
[cpg]


My relationship with Fia may one day prevent me from conquering the world.
[cpg]


I wonder what I'll do then. I just want to live in peace with Fia .
[cpg]


I just want to live in peace with Fia , but if disappears, that goal itself will be lost.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile354"]
[OnName num="meile"]
"Well, well, well, there's no use thinking about it. If we don't do something, we might be invaded, right?"
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. You're right. We're not going to do nothing.
[cpg cn=true]



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye336"]
[OnName num="schartye"]
That's reassuring. It's reassuring. You're starting to look like a demon king.
[cpg cn=true]


Chartier smiled at that. Kullulu was smiling too.
[cpg]


Fia It's a good idea to have a good idea of what you're looking for.
[cpg]

[free time=800]

[OnName num="kousuke"]
" Fia . Let's go outside for a while.
[cpg cn=true]


[FACE method="change_5" pos="2/2"]
[VOICE f="Fia398"]
[OnName num="fia"]
What?　Yes, yes .......
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

;//＠
[SE f="se011"]
;//【ＳＥ】『人混み』

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

I took only Fia and went out to the city.
[cpg]


This city is full of activity. It may be a result of the ambition of the lower-ranking subordinates to reverse their position.
[cpg]


Or maybe they're simply expecting me to do the same.
[cpg]


Either way, these are the people who can give me a boost.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia399"]
[OnName num="fia"]
"...... I'm still not sure. Do we really need to invade the land of the elves?"
[cpg cn=true]


[OnName num="kousuke"]
If you don't, you will. Wouldn't Fia you be sad if I died?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia400"]
[OnName num="fia"]
I don't think they'd kill me.
[cpg cn=true]


[OnName num="kousuke"]
It was a seal. Either way, it's like dying."
[cpg cn=true]


Fia fell silent. I was supposed to be trying to convince her, but it turned into an argument.
[cpg]


I don't want to do this either.
[cpg]


[OnName num="kousuke"]
I can't ...... go on. It's not like there's a race barrier or anything, is there?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia401"]
[OnName num="fia"]
Yes. Because Kosuke is a demon king.
[cpg cn=true]


You may have to curse your fate. But.
[cpg]


[OnName num="kousuke"]
But if I wasn't a demon king, I wouldn't have been able to get together with Fia ."
[cpg cn=true]


Fia looked a little sad. He seemed to be pessimistic about this fate.
[cpg]


[OnName num="kousuke"]
"Let's walk the streets. I'm sure Fia can tell you what the subalterns want."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_3.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城下町＿魔王の国』（夕方）******************************************************



[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]


As we walked through the city, the subalterns said to each other.
[cpg]


It's not like they're going to invade Elf country yet, or even Japan if they're from Japan.
[cpg]


They seemed to be ready at any time. If anything, even the non-soldiers were bloodthirsty.
[cpg]


I guess that's how dissatisfied they were until now.
[cpg]


It was true that the country of the beastmen, unlike the country of the elves, could not be called a developed country.
[cpg]


It was impossible not to complain about being left behind by the rest of the world.
[cpg]


[OnName num="therianthropy_A"]
"You're developing a new magic, aren't you, Demon Lord?
[cpg cn=true]


[OnName num="therianthropy_B"]
Let's invade the land of the elves!　If we can get the elves to follow us, we can really take over the world.
[cpg cn=true]


[OnName num="kousuke"]
"You hear that, Fia ? This is what people are saying.
[cpg cn=true]


[VOICE f="Fia402"]
[OnName num="fia"]
"I know, I know. I know, I know, but ......
[cpg cn=true]


[OnName num="kousuke"]
I'm not talking about destroying the land of elves. The land of the Demon Lord will follow.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia403"]
[OnName num="fia"]
But you can't promise that you won't do terrible things to the ...... elves.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia404"]
[OnName num="fia"]
No. Even if they do, I still don't think it will happen.
[cpg cn=true]


[OnName num="kousuke"]
You are stubborn.
[cpg cn=true]


You're stubborn, but I understand what you're saying. If I were in the same position, I might have argued that way.
[cpg]



;//ブラックアウト

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





I was alone with Fia in my room.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia405"]
[OnName num="fia"]
"...... Kosuke . I don't understand anymore."
[cpg cn=true]


[OnName num="kousuke"]
"You don't know what?　Why don't you just do what I say?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia406"]
[OnName num="fia"]
My mind is a mess. ...... What can I do to help you, Kosuke ?
[cpg cn=true]


[OnName num="kousuke"]
It's obvious. I need your help.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia407"]
[OnName num="fia"]
I can't ...... do that.
[cpg cn=true]


[OnName num="kousuke"]
You're a stubborn son of a bitch.
[cpg cn=true]


You need to be reminded, even if it's a little rough, that you're mine.
[cpg]

[OnName num="kousuke"]
I love you, Fia . I love you, Fia . You know what I need from .
[cpg cn=true]

[OnName num="kousuke"]
"Don't hesitate. I'll give you whatever you want.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia408"]
[OnName num="fia"]
...... I may be stubborn and stubborn, but Kosuke you are pushy.
[cpg cn=true]


[OnName num="kousuke"]
Yeah, I know that. Yeah, I know that.
[cpg cn=true]

;//Ｈシーンカット

I had slowly come to understand that Fia was stubborn.
[cpg]

No matter how many times I tried to seduce him, tell him I loved him, or convince him that this was the only way, he would always be the same.
[cpg]


There was a part of me that thought, "Of course he's stubborn. Nothing is going to change because of this.
[cpg]


[OnName num="kousuke"]
"...... Fia "
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia432"]
[OnName num="fia"]
"What is ......?　I don't care how many times you say it, my opinion is the same.
[cpg cn=true]


[OnName num="kousuke"]
"I know. I'm not asking you to accept it. But please forgive me.
[cpg cn=true]


[OnName num="kousuke"]
It's so I can live without being hunted. That's why I go to .......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia433"]
[OnName num="fia"]
...... I can't respond to something like that.
[cpg cn=true]


Fia has a troubled look on his face.
[cpg]


I also have a delicate feeling. I don't know how much I can say about this.
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Night. I was alone in my room.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドアノック』





[OnName num="kousuke"]
"Who is it?"
[cpg cn=true]



[VOICE f="Schartye337"]
[OnName num="schartye"]
"It's me. Can I come in?
[cpg cn=true]


[OnName num="kousuke"]
Yes. Come in.
[cpg cn=true]



[SE f="se002"]
;//【ＳＥ】『ドア開く』





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye338"]
[OnName num="schartye"]
You don't look so good, My Lord.
[cpg cn=true]


Chartier didn't seem to be worried about me.
[cpg]


Rather, he looked as if he wanted to tell me not to hesitate now.
[cpg]


[OnName num="kousuke"]
What is it that you want? Tell me in a few words.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye339"]
[OnName num="schartye"]
My men are ready. My men are ready, and so are the Kullulu wurds, they say.
[cpg cn=true]


[OnName num="kousuke"]
...... I see. It's time.
[cpg cn=true]


I have to make up my mind. I'm going to invade the land where Fia used to live.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_02_2.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_tc"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************

[window target=true]




I had come to the land of the elves earlier.
[cpg]


The magic of sleep. In the end, the provisional name became the name.
[cpg]


This magic works indiscriminately. The only way to make the mission work was for me to go in almost alone.
[cpg]


If they find out that I'm a demon king and surround me, that's the end of it.
[cpg]


I really need to leave Chartier and Kullulu in the Demon Lord's country.
[cpg]


It's a good idea to have a good idea of what you're doing.
[cpg]


[OnName num="kousuke"]
Let's go to .......
[cpg cn=true]


It was a very one-sided development from there.
[cpg]


[SE f="se016"]
;//【ＳＥ】状態異常魔法

;//画面薄く赤色に
[BG f="red.ui" time=1000]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_de"]




Very few of them were resistant to magic. Some of the wizards noticed something was wrong and put up wards, but ......
[cpg]


We were outnumbered. The soldiers of the demon king's country were also brave.
[cpg]


And on top of that, I have my magic. It was no longer a contest.
[cpg]


No more screams, just one-sided domination. The elven kingdom was neutralized in a matter of hours.
[cpg]

[window target=false]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


;//色調元に戻る


[BG f="b_02_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（夜）******************************************************



[window target=true]


By the time night fell, the news had swept the world.
[cpg]


The land of the Demon King had invaded the land of the elves. They are steadily trying to take over the world. ......
[cpg]


I don't know if it's my reputation, or if it's my danger in the eyes of the world .......
[cpg]


In any case, I've become someone who can't be left alone, but I've also become someone who's difficult to deal with.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia434"]
[OnName num="fia"]
...... Are you sure you want to do this?
[cpg cn=true]


[OnName num="kousuke"]
It's okay. We've captured all the soldiers and the people in the center of the country.
[cpg cn=true]


[OnName num="kousuke"]
We'll be able to control this country as we see fit. Maybe more subhumans will come.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia435"]
[OnName num="fia"]
I have mixed feelings about ....... It's my home.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia436"]
[OnName num="fia"]
To overrun it unilaterally, without dialogue, is ......
[cpg cn=true]


[OnName num="kousuke"]
You have to understand. There is no other way."
[cpg cn=true]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************





The next day, I returned to the land of the Demon King.
[cpg]


After all, I feel more at home here. I left the control of the elven kingdom to my minions.
[cpg]


The minions are not Chartier or Kullulu , but those who were her subordinates.
[cpg]


There were plenty of people who were better than me at politics.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[OnName num="kousuke"]
" Fia . Don't look at me like that."
[cpg cn=true]


The two of them walked together with Fia who kept silent.
[cpg]


In the midst of this, one of the citizens stood in front of me.
[cpg]


It looked like a beast, but on closer inspection it was an elf.
[cpg]



[OnName num="elf_man"]
"How dare you do this to me, ......!"
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

He had a blade in his hand. I immediately shielded Fia .
[cpg]


[SE f="se006"]
;//【ＳＥ】『魔法発動する』
[WAIT time=1000]

[OnName num="elf_man"]
"......!　Phew!"
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『倒れる』
[WAIT time=1000]


[BG f="b_05_2.ui" time=1000]


The elf man collapsed on the spot. He was attacked from behind by someone.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude263"]
[OnName num="clolowlude"]
It's not a good time to go out. You should not be walking around right now.
[cpg cn=true]


[OnName num="kousuke"]
"...... bad."
[cpg cn=true]


[free time=800]

[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
I looked back at Fia and saw him rolling his eyes.
[cpg]


[OnName num="kousuke"]
Are you okay? You're not hurt, are you?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Fia437"]
[OnName num="fia"]
...... I just remembered.
[cpg cn=true]

[free time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="1/2" time=800]

[VOICE f="Clolowlude264"]
[OnName num="clolowlude"]
"Remembered?　Remembered what?
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia438"]
[OnName num="fia"]
We elves have a long life. I met Kosuke once before I was reborn.
[cpg cn=true]


[OnName num="kousuke"]
What?
[cpg cn=true]


Fia It's a good idea to have a good idea of what you're looking for.
[cpg]


They say that the Demon Lord of those days, though abhorrent, had a gentle nature.
[cpg]



[FACE method="change_6" pos="1/2"]
[VOICE f="sFia032"]
[OnName num="fia"]
It's a good idea to have a good idea of what you're looking for.
[cpg cn=true]


Fia will tell you that I was saved by you before I was reincarnated.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia440"]
[OnName num="fia"]
I said, "I want to thank you for ...... saving me."
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude265"]
[OnName num="clolowlude"]
"Hmm. What did the Demon Lord say then?
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia441"]
[OnName num="fia"]
He said, "No thanks. ...... Instead, he said that if we met again somewhere, he would help me. ......
[cpg cn=true]


[OnName num="kousuke"]
......Oh, I see."
[cpg cn=true]


Fia had met me before I was reincarnated. I have no memory of it.
[cpg]


[OnName num="kousuke"]
Forget about it. I'm not asking for your help.
[cpg cn=true]


[FACE method="change_3" pos="1/2"]
[VOICE f="Fia442"]
[OnName num="fia"]
"No. I'm going to get you out. I'm going to help Kosuke ."
[cpg cn=true]


Fia looked as if he had made a decision.
[cpg]


[OnName num="kousuke"]
I said I don't want it.
[cpg cn=true]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************



[FG f="CHA01_p5_01_a.ui" method="change_3"  pos="2/3" time=800]

Fia followed me to my room. You said you were going to help me.
[cpg]


[OnName num="kousuke"]
If you're not going to do anything, don't force yourself to stay here.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia443"]
[OnName num="fia"]
I'm ...... thinking about it right now. What's really going to help Kosuke you?"
[cpg cn=true]


It's not like Fia to follow my lead without thinking. That's part of what I fell in love with.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



It's a great way to make sure you're getting the most out of your money.
[cpg]

If you're a demon king, act like a demon king. That's all.
[cpg]


;//Ｈシーンカット



[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[OnName num="kousuke"]
Next, I'm going to declare war on humans.
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia465"]
[OnName num="fia"]
...... I see.
[cpg cn=true]


[OnName num="kousuke"]
My family is human, too. I want the whole world to be mine."
[cpg cn=true]


Fia 's expression only grew cloudier.
[cpg]


[OnName num="kousuke"]
You're not convinced yet? I'd like to conquer as much of the world as possible in its original form.
[cpg cn=true]


[OnName num="kousuke"]
We'll try to minimize the number of deaths. That's why we're using magic to neutralize them. ......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia466"]
[OnName num="fia"]
...... Let's call it quits.
[cpg cn=true]


[OnName num="kousuke"]
Stop what?　Stop what?　You can't go back now.
[cpg cn=true]


I was a little annoyed by the incomprehensible Fia and tried to do something different.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_06_2_l.ui" time=1000]
[WAIT time=1000]


[OnName num="kousuke"]
I tried something a little different: " Fia . Sit here, please."
[cpg cn=true]

[VOICE f="sFia033"]
[OnName num="fia"]
"Yeah, ...... what?"
[cpg cn=true]

I sat her down right in front of me and pinned her down from behind. Then ......
[cpg]

I cast a summoning spell.
[cpg]


;//========================================
;//●ＣＧ（ヒロインが主人公のすぐ前に居る。さらにその前から触手が伸びている）ev_51
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//人ex２：触手　　　　服ex２：無し
;//場所　：城内＿主人公の部屋
;//時間　：昼
;//========================================

*Scene041

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』

[WAIT time=1000]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[BGM f="bg_h2"]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sFia034"]
[OnName num="fia"]
What the hell are you doing?
[cpg cn=true]

[OnName num="kousuke"]
No. You're not listening to me very well.
[cpg cn=true]

[VOICE f="sFia035"]
[OnName num="fia"]
Are you going to threaten me with this?
[cpg cn=true]

She is still resolute, or at least she is trying to be.
[cpg]

But her body seems to be trembling.
[cpg]

[OnName num="kousuke"]
It's not that I'm trying to do anything. It's just that ......
[cpg cn=true]

[OnName num="kousuke"]
Tentacles are disgusting, aren't they? You don't want to just be touched.
[cpg cn=true]

Fia "I'm not trying to do anything.
[cpg]

;**【ＣＧ】 ev_51_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia036"]
[OnName num="fia"]
...... is fine. I don't care what you do to me.
[cpg cn=true]

[VOICE f="sFia037"]
[OnName num="fia"]
"I'll accept anything. I'll accept anything, as long as I can change your mind."
[cpg cn=true]

[OnName num="kousuke"]
"......"
[cpg cn=true]

How stubborn can you be? It's not easy for me to do this.
[cpg]

You can't get what you want out of me this way.
[cpg]

;//Ｈシーンカット


;//ブラックアウト


[STOPBGM]

[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]




It's a good idea to have a good idea of what you're doing.
[cpg]

Then Fia fell silent and said nothing.
[cpg]


[OnName num="kousuke"]
Fia . You like me, don't you?"
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia485"]
[OnName num="fia"]
"...... Yes."
[cpg cn=true]


[OnName num="kousuke"]
Why don't you follow me? Isn't what I want what you want?
[cpg cn=true]


They were silent again for a while. Then Fia opened his mouth.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia486"]
[OnName num="fia"]
I've ...... figured out why I fell in love with you at first sight.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia487"]
[OnName num="fia"]
No, it wasn't really love at first sight, was it? I'm sure you'll be able to understand why. ......
[cpg cn=true]


You're talking about me before I was reincarnated. I want to say that the love began there.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia488"]
[OnName num="fia"]
I know that you are really a kind person. I want you to be the real you again."
[cpg cn=true]


[OnName num="kousuke"]
"What's the real me? What's the real me?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia489"]
[OnName num="fia"]
No, you're not. Maybe I do things I don't want to do out of fear for my life."
[cpg cn=true]


[OnName num="kousuke"]
......"
[cpg cn=true]


I couldn't say anything back. I couldn't even deny it out of my mind. ......
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BG f="b_06_3.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





I then gathered the Meir people.
[cpg]


[OnName num="kousuke"]
I'm declaring war on humans. If we could do it in Elfland, we can do it.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Schartye340"]
[OnName num="schartye"]
"That's brave and good. I agree.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude266"]
[OnName num="clolowlude"]
I agree. Though it may be a bit premature.
[cpg cn=true]


I knew these two would agree with me. The problem is, Fia , right?
[cpg]

;//;[FO layer="2/2"]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sMeile047"]
[OnName num="meile"]
"Let's see, ...... Fia ."
[cpg cn=true]

Meir glanced around awkwardly. Fia did not say anything.
[cpg]

[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile048"]
[OnName num="meile"]
I think I agree with ....... Don't be reckless. Everyone here loves you.
[cpg cn=true]

It's not just the four of us. You can say that all the people in the country of the demon king have placed their hopes in me.
[cpg]


I think I understand that.
[cpg]


;//ブラックアウト
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************



[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]


The final battle is near. With this in mind, Fia and I went outside.
[cpg]

[OnName num="kousuke"]
"Hey, Fia . "Hey, , do you still like me after all this?
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

When I asked Fia that, his cheeks flushed without saying a word.
[cpg]

[OnName num="kousuke"]
In the next battle, I might die. I don't plan on it, though."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="sFia038"]
[OnName num="fia"]
'I won't let that happen, ....... I will not let that happen, and I will make sure that the fight itself does not happen.
[cpg cn=true]

Fia is as stubborn as ever. It's a good idea to have a good idea of what you're looking for.
[cpg]


[SE f="se008"]
;//【ＳＥ】『歩く』

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





;//========================================
;//●ＣＧ（樹のそばに立っているヒロイン）ev_52
;//人物１：ヒロイン１　服装１：着衣
;//場所　：森の茂み
;//時間　：夜
;//========================================

*Scene042

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_52_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sFia039"]
[OnName num="fia"]
Uh, ...... Kosuke ?
[cpg cn=true]

[OnName num="kousuke"]
Stay with me."
[cpg cn=true]

I close in on her. There's a tree behind her and she can't escape.
[cpg]

Or is it correct to say that you can stay at ...... and not run away?
[cpg]

;**【ＣＧ】 ev_52_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia040"]
[OnName num="fia"]
"......"
[cpg cn=true]

And Fia closes her eyes. He understands me.
[cpg]

I'm sure she already knows what it's like to be taken to a secluded place like this.
[cpg]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]

Then I kissed her on the mouth.
[cpg]

Of course, it was a calculated move. Of course, I did it with a hint of calculation, thinking that she might listen to me.
[cpg]


;**【ＣＧ】 ev_52_b ***********************
[CG id=13 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia041"]
[OnName num="fia"]
"I'm glad you're here, ....... Kosuke "
[cpg cn=true]

[OnName num="kousuke"]
"That's good. Fia , please stay by my side forever and ever."
[cpg cn=true]

[VOICE f="sFia042"]
[OnName num="fia"]
Yes. Yes, of course."
[cpg cn=true]


He said this, but lowered his eyes a little. I didn't know what that meant at the time.
[cpg]

;//Ｈシーンカット

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_11_4.ui" time=1000]
[WAIT time=1000]



Thinking about it, Fia must have been thinking about it a lot. I've destroyed the country of Fia .
[cpg]


I guess they thought that if they left me alone, I might actually take over the world.
[cpg]


That's what I thought, and that's why I did this.
[cpg]



[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]



[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************

[window target=true]




[OnName num="kousuke"]
......"
[cpg cn=true]


I wake up alone. I thought I slept with Fia , but she was gone.
[cpg]


[STOPBGM]
[BGM f="bg_tc"]

[SE f="se009"]
;//【ＳＥ】『走る』

[WAIT time=1000]

[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile356"]
[OnName num="meile"]
"Oh my god, Kosuke !　 Fia is gone, nowhere!"
[cpg cn=true]


[OnName num="kousuke"]
"...... what?"
[cpg cn=true]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城内＿廊下』（昼）******************************************************





I wandered around looking for Fia . Of course, I wasn't the only one looking for Fia .
[cpg]


The whole castle is looking for Fia , but he's nowhere to be found.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMeile049"]
[OnName num="meile"]
I wonder if ...... has left the country.
[cpg cn=true]


[OnName num="kousuke"]
What do you mean?　He can't do this by himself.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMeile050"]
[OnName num="meile"]
It's possible, you know. It's possible, because some of the Harpy people want peace, not invasion.
[cpg cn=true]


So those people helped him. Did Chartier and the others know about it and just let it happen?
[cpg]


No, now is not the time to blame them. Where did Fia go?
[cpg]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





Later that day, the harpy that had apparently carried Fia had returned.
[cpg]


[OnName num="kousuke"]
"...... you took Fia with you?"
[cpg cn=true]


[OnName num="harpy_woman"]
Yes. Yes, it was all Fia 's idea, and it was for the good of the country.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye341"]
[OnName num="schartye"]
I'm missing the point. Just say it.
[cpg cn=true]


[OnName num="harpy_woman"]
Fia is now in Japan. He's in Japan right now to tell the Demon Lord that his country is about to be invaded.
[cpg cn=true]


[OnName num="kousuke"]
...... I see.
[cpg cn=true]


I knew it would be something like that. I've been trying to keep them from invading Japan.
[cpg]


But even if I did, I could still invade other countries.
[cpg]


This is only a stopgap measure,......, I thought, but.
[cpg]


[free time=800]


[OnName num="harpy_woman"]
Now, he is being held hostage in Japan.
[cpg cn=true]


[OnName num="kousuke"]
What?
[cpg cn=true]


[OnName num="harpy_woman"]
I'm also in charge of the Japanese demands.
[cpg cn=true]


The main demand was the liberation of the Elven lands.
[cpg]


The main demand was the liberation of the Elven lands, and the demand was that there be no further invasions.
[cpg]


If we break that, Fia will be dead.
[cpg]


Of course, it is a promise that can be broken at any time if Fia you come back. ......
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude267"]
[OnName num="clolowlude"]
"It's funny, ...... the story is going on under the assumption that the Demon Lord likes Fia ."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile357"]
[OnName num="meile"]
I think Fia said it himself. I think Kosuke told him himself that likes him.
[cpg cn=true]


[OnName num="kousuke"]
"What does ...... mean?"
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile358"]
[OnName num="meile"]
"It means he went to Japan to be a hostage."
[cpg cn=true]


The harpy woman nodded. I couldn't say anything.
[cpg]



[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye342"]
[OnName num="schartye"]
What do we do now? What should I do, Demon Lord? If I give in here, I'll have to give up the land of the elves.
[cpg cn=true]


[OnName num="kousuke"]
I've already decided my answer. There is no substitute for Fia ."
[cpg cn=true]


[FACE method="change_5" pos="2/2"]
[VOICE f="Clolowlude268"]
[OnName num="clolowlude"]
"Hey!　I've gone to a lot of trouble to rule the land of the elves.
[cpg cn=true]


[OnName num="kousuke"]
I don't care about ...... anymore. I knew this would happen one day.
[cpg cn=true]



;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="cube.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_02_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************


[window target=true]



I decided to let go of the land of the elves.
[cpg]


It didn't take me long to make my decision.
[cpg]


I can say that it all started when I fell in love with Fia . ......
[cpg]


I felt that if the people I loved wanted peace, this was the way it had to be.
[cpg]

[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





No more invasions. I also liberated the land of the elves.
[cpg]


I think the situation is worse than when this demon king's country was established, let alone world domination.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia515"]
[OnName num="fia"]
I'm sorry for the trouble ...... caused. Mr. Kosuke ."
[cpg cn=true]


But I was still relieved when I saw Fia had returned.
[cpg]


[OnName num="kousuke"]
"You know what's coming. Fia "
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia516"]
[OnName num="fia"]
"Yes, I do. I'll take any punishment I can get.
[cpg cn=true]


My wish for world domination did not come true, but I was able to protect the people I cared about.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[SE f="se008"]
;//【ＳＥ】『歩く』

[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]



[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
I take Fia to the basement.
[cpg]


[OnName num="kousuke"]
What I'm going to do now, as you say, is punish you.
[cpg cn=true]


[OnName num="kousuke"]
I'm not going to threaten you like I have in the past. You know that, right?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia517"]
[OnName num="fia"]
"...... Yes."
[cpg cn=true]


Then I thought about what Fia hates the most. It was time to try a new summoning spell.
[cpg]

;//Ｈシーンカット


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//＠地下室
[BG f="b_12_4.ui" time=1000]
[WAIT time=1000]

[OnName num="kousuke"]
You don't seem to like bugs much, do you?
[cpg cn=true]



[VOICE f="sFia043"]
[OnName num="fia"]
Not many people would dare to ...... say they like them.
[cpg cn=true]


[OnName num="kousuke"]
You're honest. You know you're pushing yourself.
[cpg cn=true]



[VOICE f="Fia540"]
[OnName num="fia"]
Yeah, that's ......
[cpg cn=true]


[OnName num="kousuke"]
But I'm glad you don't like it."
[cpg cn=true]


I said, and cast a summoning spell.
[cpg]


It's a magic I've never used before. I've never used it before and I don't know what it will do.
[cpg]


[OnName num="kousuke"]
"Here we go, Fia . If you stay sane, I will praise you."
[cpg cn=true]



;//========================================
;//●ＣＧ（大量のワーム状の虫が体中を這っている。膣に何匹も入り込まれるヒロイン）ev_54
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：ワーム　　　服装ex：なし
;//場所　：城内＿地下室
;//時間　：夜
;//========================================

*Scene012

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』

[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_54_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia044"]
[OnName num="fia"]
Oh, my God. ...... Oh, my God.
[cpg cn=true]

[OnName num="kousuke"]
It's not just a bug. It's more like a slime.
[cpg cn=true]

[OnName num="kousuke"]
It's an individual that can grow on its own. If you wait long enough, it will multiply.
[cpg cn=true]

[VOICE f="sFia045"]
[OnName num="fia"]
No, no, no, ...... delete it, please.
[cpg cn=true]

[OnName num="kousuke"]
You said I'd be punished. Now you're whining."
[cpg cn=true]

I said, and turned away.
[cpg]

[OnName num="kousuke"]
I'll see you later. I'll let you out later and you can take care of me.
[cpg cn=true]

;**【ＣＧ】 ev_54_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia046"]
[OnName num="fia"]
Wait, Kosuke and ......!
[cpg cn=true]

This is not a big deal.
[cpg]

It's not a big deal. When I said it would increase, I only meant it as a scare tactic. In fact, there is no way such a phenomenon will happen.
[cpg]

Maybe Fia knows what's going on.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[STOPBGM]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]



[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]


Then, a few hours later, I let Fia out of the room.
[cpg]


He looked tired, but he hadn't lost the light in his ...... eyes.
[cpg]


[OnName num="kousuke"]
"You're sorry. Fia "
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Fia562"]
[OnName num="fia"]
"...... Yes."
[cpg cn=true]


But no matter how much Fia you regret it, it doesn't change the fact that I'm now limited in what I can do.
[cpg]


The land of the elves is back to normal. It is no longer the territory of the Demon Lord.
[cpg]


From Fia 's point of view, it means that I could have protected my homeland.
[cpg]


Maybe Fia is a very cunning guy.
[cpg]


And maybe it is we who are being conquered, maybe it is we who are being fascinated. ......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia563"]
[OnName num="fia"]
...... Can I help you, Kosuke ?
[cpg cn=true]


[OnName num="kousuke"]
"No, nothing. It's nothing.
[cpg cn=true]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





And then the country of the demon king and myself were in a tight spot.
[cpg]


You will find a lot of things that you can do to make your life easier.
[cpg]


The fact that they are being targeted for their lives doesn't change anything. In fact, it's worse than before.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Clolowlude269"]
[OnName num="clolowlude"]
It seems that no other country is going to invade, but the number of assassins is increasing again.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Meile359"]
[OnName num="meile"]
I wonder if people are thinking that now is the time to contain ...... Kosuke .
[cpg cn=true]


[OnName num="kousuke"]
...... I see.
[cpg cn=true]


It's Fia 's fault, but if I'm left alone with my world domination ambitions, ......
[cpg]


That's exactly why I might have died somewhere along the line.
[cpg]


I'm not sure we're in a position to say which was better.
[cpg]


[FACE method="change_2" pos="2/2"]
[VOICE f="Meile360"]
[OnName num="meile"]
But I think it's good. But I think it's good. Kosuke was so dangerous a while ago that I couldn't watch it.
[cpg cn=true]


[OnName num="kousuke"]
Was that so?
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Clolowlude270"]
[OnName num="clolowlude"]
That's true. You really wanted to collide with the world, didn't you?
[cpg cn=true]


...... When I think about it, I wonder if Fia did a good job of stopping me.
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





And after that, I was alone with Fia .
[cpg]


[OnName num="kousuke"]
" Fia . I can't read the bottom of your stomach.
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia564"]
[OnName num="fia"]
...... I'm a simple minded person. I just keep believing that Kosuke is a kind person."
[cpg cn=true]


Maybe you're right. But in the end, ......
[cpg]


[OnName num="kousuke"]
I'm in a life-threatening situation. Are you happy with this?"
[cpg cn=true]


The Fia did not nod. But.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia565"]
[OnName num="fia"]
I like you now, Kosuke ," he said. I like the Kosuke you are now, just like the you were when you saved me. ......"
[cpg cn=true]


He must be talking about before his reincarnation. I have no memory of that time.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia566"]
[OnName num="fia"]
Do you hate me now, ...... Kosuke ?
[cpg cn=true]


[OnName num="kousuke"]
"No. I don't. No, not at all.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Fia567"]
[OnName num="fia"]
"Then ...... that ......."
[cpg cn=true]


Fia is about to say something. I think he's still attracted by the pheromones.
[cpg]


[OnName num="kousuke"]
"Yeah. I'll kiss you. I'll still like you, thank you."
[cpg cn=true]

It was like he was a real demon king.
[cpg]



;//ブラックアウト

[STOPBGM]


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************


[window target=true]



Time passed, and it was night.
[cpg]


Me and Fia were cuddling and sleeping. We were both sleeping ...... with Fia , who was supposed to have betrayed me.
[cpg]


[OnName num="kousuke"]
"......, you're probably smarter than me."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia589"]
[OnName num="fia"]
"No, I'm not. No, I'm not.
[cpg cn=true]


[OnName num="kousuke"]
I'm not buying it. It's like you know exactly what I'm thinking and you're doing it.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia590"]
[OnName num="fia"]
...... is a coincidence.
[cpg cn=true]


Fia is humble. It's a good idea to have a good idea of what you're looking for.
[cpg]


It's a good idea to have a good idea of what you're doing.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia591"]
[OnName num="fia"]
Kosuke I'm sure you'll be able to understand that I'm not the only one.
[cpg cn=true]


[OnName num="kousuke"]
You said that. You met me before you reincarnated, didn't you?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia592"]
[OnName num="fia"]
Yes. Looking back, I've been in love with you since then.
[cpg cn=true]


So you're saying that you died once, but your love was fulfilled. Maybe it's romantic, I don't know.
[cpg]


But for me, I'm just happy to be with Fia .
[cpg]


It's not the process that matters to me, it's what I'm doing now that matters.
[cpg]


Of course, there is an attempt on my life. I'm far from safe.
[cpg]


Even so, I was happy to be spending time with Fia .
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia593"]
[OnName num="fia"]
...... My species is quite long-lived. Maybe Kosuke will get to ...... before I do.
[cpg cn=true]


[OnName num="kousuke"]
"Then, next time you are reborn, let's be together again."
[cpg cn=true]


I said this without hesitation. I said without hesitation. Fia smiled and replied.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia594"]
[OnName num="fia"]
You're right. I was about to say the same thing.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//ＥＮＤ　ヒロイン１征服ルート



[WAIT time=100]
[jump storage="epend.ks" target="*start"]
[WAIT time=100]
;[s]
[WAIT time=100]
[WAIT time=100]


;//==============================

