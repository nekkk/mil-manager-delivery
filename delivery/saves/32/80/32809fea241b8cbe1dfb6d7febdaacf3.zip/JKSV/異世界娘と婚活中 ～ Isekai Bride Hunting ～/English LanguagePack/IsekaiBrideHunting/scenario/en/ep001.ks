

;=========================================================================================

*start

*ep001|A Journey Around the World

[SCENE id=1]

[stflag Cha1flg=1]
[stflag Cha2flg=0]
[stflag Cha3flg=1]
[stflag Cha4flg=0]

[stflag Cha2flg_s=0]
[stflag Cha3flg_s=0]
[stflag Cha4flg_s=0]



[window target=false]

[STOPBGM]

[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[free time=1]
[BG f="b_10_1.ui" time=11]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



And the next morning. I was invited to stay at Meir 's house for a while.
[cpg]


Considering what I had done, it seemed natural, but I didn't feel it.
[cpg]


As I was thinking about this, I was in a daze.
[cpg]


[OnName num="kousuke"]
"It's kind of a peaceful place, .......
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile004"]
[OnName num="meile"]
It's a holiday, you know. It's a holiday today, so people won't be working in the fields today. ...... Maybe.
[cpg cn=true]


Maybe because I've been asleep for a long time.
[cpg]


But it is a farming village. It's strange to see a beastman doing farming. ......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile005"]
[OnName num="meile"]
But your brother is a strange man, isn't he? It smells like our world, it feels strange.
[cpg cn=true]


[OnName num="kousuke"]
What's that? ......
[cpg cn=true]

[window target=false]
[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]


[BG f="b_10_3.ui" time=1000]
[WAIT time=1500]

[WAIT time=100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



At first, I went around the village and tried to find a way to get back to Japan.
[cpg]


It seems that this is the most rural part of the beast country.
[cpg]


The airport is in the city. But ......
[cpg]


There's no point in going there, right? I've been smuggled into Japan twice now.
[cpg]


I don't think I can go to the airport and return to Japan properly.
[cpg]



;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く

[BG f="b_10_3_up_l.ui" time=1000]
[WAIT time=1500]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]

[WAIT time=1000]

[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile006"]
[OnName num="meile"]
You're thinking too much. You're thinking too much. If you're in trouble, why don't you ask for help?
[cpg cn=true]


As I walked back to my house, Meir greeted me.
[cpg]


[OnName num="kousuke"]
I came home and was greeted by ....... "Where are your parents, ......?　Aren't they on holiday today?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile007"]
[OnName num="meile"]
They're at church. I'm at church. It's my day off.
[cpg cn=true]


You go to church in the evening? I wonder if it's a cross-cultural thing.
[cpg]


[OnName num="kousuke"]
Aren't you going to Meir ?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile008"]
[OnName num="meile"]
"Well, I've got something I'd rather be doing, you know, ......."
[cpg cn=true]


Then she invites me in. I'm wondering what it is.
[cpg]



[window target=false]

[free time=1000]

[WAIT time=1000]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1500]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=100]
;//ブラックアウト

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


[window target=true]


[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1000]


;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

When I was wondering what was going on, Meir sat down on the bed in my bedroom.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile009"]
[OnName num="meile"]
...... I've been strange since I met you.
[cpg cn=true]


[OnName num="kousuke"]
What do you mean strange?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Meile010"]
[OnName num="meile"]
I've never felt this way before. I don't know if this is love.
[cpg cn=true]


...... Again. It's the same as when I was at Fia . I can't help but think there's something wrong with my body.
[cpg]


I've never felt this way before, and if that's true, it's even stranger.
[cpg]


I've never been in love with anyone, but you're in love with me. ......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile011"]
[OnName num="meile"]
"What's wrong with you, you weird-looking ...... person, aren't you happy to hear this?"
[cpg cn=true]


[OnName num="kousuke"]
"No. No. ......"
[cpg cn=true]


In the end, I'm going to go back to Japan, but I don't think it's a good idea to do anything too suggestive in different places.
[cpg]


But the original purpose is to get a subhuman wife, right?
[cpg]


If you ask me if Meir is my type, I think she is cute.
[cpg]


Well, what should I do? ......
[cpg]





;//■選択肢
[switch]
[case "Hit on Meir"]
	[swap]
	[jump target="*IseSel01_1"]
[case "I'm not going to do anything."]
	[swap]
	[jump target="*IseSel01_2"]
[endswitch]




One, hit on Meir
Two, do nothing.



;//==============================
;//１、メイルを口説く
*IseSel01_1|A Journey Around the World


;//ヒロイン２が攻略対象になる
[stflag Cha2flg_s=1]



[OnName num="kousuke"]
...... You're not telling everyone, are you?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile012"]
[OnName num="meile"]
Of course not. I told you I've never felt this way before.
[cpg cn=true]


[OnName num="kousuke"]
I started traveling because I wanted a subhuman wife.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile013"]
[OnName num="meile"]
Then we'd be a good match, wouldn't we?
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ
[FG f="CHA02_p7_01_a.ui" method="change_6"  pos="2/3" time=800]


We sat down on the bed next to each other and he put his head on my lap.
[cpg]


[VOICE f="Meile014"]
[OnName num="meile"]
It smells ...... soothing.
[cpg cn=true]

;//＠
[FACE method="change_6" pos="2/3"]
[VOICE f="sMeile001"]
[OnName num="meile"]
...... Hey, can I sleep like this?
[cpg cn=true]


I wonder if I can do this. I wondered the same thing about Fia .
[cpg]


However, there is a part of me that thinks that sinfulness is no longer a problem. ......
[cpg]

;//Ｈシーンカット


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト

[jump target="*IseSel01_3"]

;//==============================
;//２、何もしない
*IseSel01_2|A Journey Around the World




[OnName num="kousuke"]
......I knew you couldn't do it, you're not my girlfriend."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile073"]
[OnName num="meile"]
What? ...... Don't embarrass the girl.
[cpg cn=true]


[OnName num="kousuke"]
I don't care what you say, I'm not doing it. I'm not that unprincipled.
[cpg cn=true]


I waited for her parents to come home while I exchanged these words with Meir .
[cpg]



;//==============================

*IseSel01_3|A trip around the world


[window target=false]

[free time=1000]

[WAIT time=1000]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4_up_l.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[STOPBGM]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************


[window target=true]



Later, my parents from Meir came home.
[cpg]


I felt ...... sorry to have them serve me dinner again, but I knew I had to find a way to get back to Japan as soon as possible.
[cpg]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************


[window target=true]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1500]


Information gathering. That's why I went to the beastmen's village to ask around. ......
[cpg]


[OnName num="therianthropy_girl_A"]
"Hey, hey ......, you smell good."
[cpg cn=true]


[OnName num="therianthropy_girl_B"]
It's true, ...... and you don't seem like a normal guy.
[cpg cn=true]


I've been very popular. I had never experienced anything like this before.
[cpg]


[OnName num="therianthropy_girl_A"]
If you want, you can come over to my place.　I have some delicious herbal tea.
[cpg cn=true]


[OnName num="therianthropy_girl_B"]
Oh, no fair!　I'm first.
[cpg cn=true]


[OnName num="kousuke"]
No, that's not the point. Just tell me how to get back to Japan.
[cpg cn=true]


Unlike in the land of the elves, they seem to be uninhibited in their love affairs.
[cpg]


I knew I would never be able to go back to Japan, but I was also happy about the harem-like situation.
[cpg]


[window target=false]
[BG f="b_10_3.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]

[BG f="b_10_3_up_l.ui" time=1000]
[WAIT time=1000]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]
[WAIT time=1000]


The evening would come again. I know I'm safe as long as I stay here, but if I don't, I won't make any progress.
[cpg]


[OnName num="meile_mother"]
Well, ...... if you head north from here, there is a settlement where the Harpies live.
[cpg cn=true]


[OnName num="kousuke"]
I see. ......
[cpg cn=true]


Harpies. Harpies are a species of bird people, right?
[cpg]


If the location is in the north, can we return to Japan from there?
[cpg]


[OnName num="kousuke"]
Thank you for telling me. I think I'll head to the Harpy settlement.
[cpg cn=true]


[OnName num="meile_mother"]
"I see. It's quite a distance, so you'd better take some food with you.
[cpg cn=true]


The mother of Meir has prepared a lot of things for us. I'm sorry.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile074"]
[OnName num="meile"]
Are you sure you want to go?　No, Kosuke will stay here forever.
[cpg cn=true]


[OnName num="kousuke"]
We can't do that. ...... The elves might be closing in on us.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile075"]
[OnName num="meile"]
The others will stop you. They say Kosuke is cool.
[cpg cn=true]


I'm not sure what to say. I was thinking ......
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile076"]
[OnName num="meile"]
"Please stay here just for today. Please."
[cpg cn=true]


[OnName num="kousuke"]
"...... can't help it."
[cpg cn=true]

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1000]

;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]


That's why I stayed at Meir 's house today.
[cpg]


[OnName num="kousuke"]
"......"
[cpg cn=true]


But I decided to leave. It's not just that it's bad to stay longer.
[cpg]


I'm not a fan of the idea of the elves coming after me and bothering them.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[STOPBGM]

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


[WAIT time=1000]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[BG f="b_09_1.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『草原』（朝）******************************************************


[window target=true]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1000]

So before Meir woke up, I had left.
[cpg]


I could see that they would say this and that when we parted.
[cpg]


[OnName num="kousuke"]
"But it's a big place, .......
[cpg cn=true]


I don't even know how far I have to walk to get to the Harpy village.
[cpg]


There was some kind of sign. I could barely read the numbers.
[cpg]


I could barely read the numbers, and I knew how much further I had to walk to get to the next village or town.
[cpg]


It looks like we'll have to stay in the field for a day. ......
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[window target=false]

[BG f="b_09_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『草原』（昼）******************************************************


[window target=true]


;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

It's not easy to walk all day long.
[cpg]


It's hard on my back. If I keep doing this, I'm going to have a lot of chronic diseases by the time I get to Japan.
[cpg]


But now I'm being treated as a criminal. Besides, I have to get back to Japan before my work starts.
[cpg]


With that in mind, I couldn't help but walk.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_09_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


[window target=true]



And I had to stay in the field along the way.
[cpg]


I was afraid of running out of food, but I was even more afraid of being caught by the elves.
[cpg]


[OnName num="kousuke"]
"...... hmm?"
[cpg cn=true]


As I was trying to sleep, I felt someone appear in front of me.
[cpg]


When I was thinking about ...... in this empty plain, a demon-like silhouette appeared.
[cpg]



;//クロロウルードの名前を「悪魔」と隠してください





[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=1500]
[WAIT time=2000]
[VOICE f="Clolowlude001"]
[OnName num="devil"]
I thought, "...... what? Don't look so curious."
[cpg cn=true]


No, that's my line. The demon-like something was looking down at me.
[cpg]


[OnName num="kousuke"]
You're ......?
[cpg cn=true]



;//クロロウルードの名前を表示してください





[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude002"]
[OnName num="clolowlude"]
"I'm Kullulu Urud. I'm a demon from the underworld.
[cpg cn=true]


[OnName num="kousuke"]
...... Really?"
[cpg cn=true]


I would have been more surprised, but all I could think was, "Really? I've never met a demon before. ......
[cpg]


It's not something I'm willing to experience, but I've already been through a lot.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude003"]
[OnName num="clolowlude"]
You should be more surprised.
[cpg cn=true]


[OnName num="kousuke"]
I'm sleepy. Later, please.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude004"]
[OnName num="clolowlude"]
So, you're the guy ...... Chartier was talking about?　Are you sure you're this weak-looking guy?
[cpg cn=true]


What was the word that followed "really"?
[cpg]


[OnName num="kousuke"]
What do you want from me?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude005"]
[OnName num="clolowlude"]
What do you want? What do you want?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude006"]
[OnName num="clolowlude"]
I don't know where you're going, but this is a big country for ...... steps.
[cpg cn=true]


[OnName num="kousuke"]
Yeah, well, ......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude007"]
[OnName num="clolowlude"]
I'm a demon, I can do magic. I'm a demon and I can do magic. You might be interested in that.
[cpg cn=true]


[OnName num="kousuke"]
...... are you going to send me back to Japan?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude008"]
[OnName num="clolowlude"]
You can use transference magic to get back to Japan in an instant. You can use transference magic to get back to Japan in an instant, but it also consumes a lot of magic power, so you can't use it unnecessarily.
[cpg cn=true]


What? You're not going to send me home after all? I rolled over and turned my back on her.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude009"]
[OnName num="clolowlude"]
"Hey!　Your attitude is too blatant.
[cpg cn=true]


[OnName num="kousuke"]
Kullulu isn't going to let me leave, is it?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude010"]
[OnName num="clolowlude"]
Don't say " Kullulu . It's too familiar.
[cpg cn=true]


[OnName num="kousuke"]
Whatever it is, I don't need you anymore. Let me sleep."
[cpg cn=true]


He clears his throat, Kullulu . And ......
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude011"]
[OnName num="clolowlude"]
My ancestors served the Demon Lord for generations.
[cpg cn=true]


[OnName num="kousuke"]
"Demon Lord?　I've never heard of such a thing.
[cpg cn=true]


I've never heard of such a thing." Even though I've merged with another world, I've never heard of a demon king.
[cpg]


If they were here, would they try to take over this world?
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude012"]
[OnName num="clolowlude"]
I've never heard of them. That's okay.
[cpg cn=true]


What's good about it? I have no idea what's good for me.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude013"]
[OnName num="clolowlude"]
If you go back four generations in my family, you'll find a demon who was the queen of a demon lord.
[cpg cn=true]


[OnName num="kousuke"]
"So what's the point? I don't know if I'm bragging or not.
[cpg cn=true]


I was frank, but Kullulu did not stop speaking.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude014"]
[OnName num="clolowlude"]
The great astrologers of the demon tribe also do this kind of divination.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude015"]
[OnName num="clolowlude"]
I am the one who will be the new queen of the demon king. ...... So I have always admired the new demon king.
[cpg cn=true]


[OnName num="kousuke"]
I can't see what you're saying. Just get to the point."
[cpg cn=true]


Kullulu blushes a little what to make of that. I don't know why I blushed there or why I stammered.
[cpg]



[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_09_2.ui" time=1000]

[WAIT time=1100]
;//【ＢＧ】『草原』（昼）******************************************************

[window target=true]




The next day, Kullulu was still following me around.
[cpg]


[OnName num="kousuke"]
What do you want from me after all?
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Clolowlude016"]
[OnName num="clolowlude"]
I'm trying to find out. I'm trying to figure out if you're the right guy for me.
[cpg cn=true]


[OnName num="kousuke"]
...... Don't tell me you're in love with me, too.
[cpg cn=true]


Kullulu doesn't answer. This is a bit strange after all.
[cpg]

[free time=800]

You are acting like you have a thing for him. I've never had any luck with humans.
[cpg]


Last night, they were talking about a new demon queen. ......
[cpg]


I don't know what the Queen of the Demon King is. I don't know what the new demon king means either.
[cpg]


[OnName num="kousuke"]
"The new Demon Lord, right?　If you're going to be her queen, you might as well go to her."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude017"]
[OnName num="clolowlude"]
"Yes. That's why I'm following you.
[cpg cn=true]


[OnName num="kousuke"]
"You mean ...... in the Harpy settlement?"
[cpg cn=true]


Kullulu still didn't answer. What is it?
[cpg]

[window target=false]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]

[BG f="b_09_4.ui" time=1000]

[WAIT time=1000]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『草原』（夜）******************************************************


[window target=true]



Night is coming again. Our food supply is slowly dwindling, and we're feeling impatient. ......
[cpg]

[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
The fact that Kullulu was next to me was a little supportive.
[cpg]


If I were to starve to death, I thought, Kullulu would take care of me.
[cpg]


[OnName num="kousuke"]
If I were to starve to death, I thought ...... might be able to help.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude018"]
[OnName num="clolowlude"]
There are many reasons why you cannot return to Japan immediately. You, after all, are ......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude019"]
[OnName num="clolowlude"]
You have a strange attraction to me. Pheromones, if you will.
[cpg cn=true]


I don't know what you're talking about. I have a lot of questions for Kullulu , but I don't know where to start.
[cpg]





;//■選択肢
[switch]
[case "What are pheromones?"]
	[swap]
	[jump target="*IseSel02_1"]
[case "I can't wait to go back to Japan."]
	[swap]
	[jump target="*IseSel02_2"]
[endswitch]



1. What are pheromones?
2. I want to go back to Japan as soon as possible.



;//==============================
;//１、フェロモンって何だ？


*IseSel02_1|A Journey Around the World


;//ヒロイン４が攻略対象になる
[stflag Cha4flg_s=1]



[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude020"]
[OnName num="clolowlude"]
Don't you get it?　Well, if you don't, that's okay, too. I'm not going to explain everything to you."
[cpg cn=true]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

;//========================================
;//●ＣＧエロ（ヒロインに迫られる。至近距離）ev_07
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：私服
;//場所　：草原
;//時間　：夜
;//========================================

*Scene000|A Journey Around the World

[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]

[STOPBGM]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=100]

With that, she brought her face close to mine. She sniffed her nose.
[cpg]


[OnName num="kousuke"]
"Hey, ......, you too?"
[cpg cn=true]


[VOICE f="Clolowlude021"]
[OnName num="clolowlude"]
You've been through a lot, haven't you? I'm also attracted to ...... you.
[cpg cn=true]


How do you know that I've been through a lot? While you're thinking about it, she's still at close range.
[cpg]

[OnName num="kousuke"]
Wait a minute. Just move away from me for now.
[cpg cn=true]

;**【ＣＧ】 ev_07_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sClolowlude002"]
[OnName num="clolowlude"]
You smell so good, I'd like to smell you some more.
[cpg cn=true]

I don't know if I can handle that. All this is going on and ......
[cpg]



My body is not normal. I kind of knew that from the Fia and Meir incidents.
[cpg]


However, the fact that she is suddenly approaching ...... as fast as she is is just not right.
[cpg]


[OnName num="kousuke"]
What are you looking for when you approach me?
[cpg cn=true]

;**【ＣＧ】 ev_07_b ***********************
[CG id=2 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Clolowlude053"]
[OnName num="clolowlude"]
You don't even know it yourself, do you? How could you live with that?
[cpg cn=true]


[OnName num="kousuke"]
Don't be a prude. Tell me.
[cpg cn=true]


[VOICE f="Clolowlude054"]
[OnName num="clolowlude"]
Go to Chartier and ask for me.
[cpg cn=true]


What, you're not going to tell me ......?
[cpg]


[VOICE f="sClolowlude003"]
[OnName num="clolowlude"]
But ......, if you're still awake, I'd like to talk to you some more.
[cpg cn=true]


[OnName num="kousuke"]
Yeah. Yeah, I want to know about me too.
[cpg cn=true]

;//＠
;[SceneEnd f="sc_005"]

;//ブラックアウト

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="heart.webp" color={0x000000ff} time=1]

[WAIT time=1100]

[BG f="b_09_4.ui" time=1000]

[BGM f="bg_d3"]
[WAIT time=1000]
;//【ＢＧ】『草原』（夜）******************************************************


[window target=true]



After that, Kullulu wouldn't let me sleep. I don't mean that in a funny way.
[cpg]


He seemed to have something to tell me. Kullulu starts talking about Chartier .
[cpg]

[jump target="*IseSel02_3"]

;//==============================
;//２、早く日本に帰りたい

*IseSel02_2|A Journey Around the World



[OnName num="kousuke"]
I want to go back to Japan as soon as possible. Please let me go home.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude086"]
[OnName num="clolowlude"]
"It's easy to use transference magic. But I won't let you.
[cpg cn=true]


[OnName num="kousuke"]
What's with the ......? Do you have feelings for me?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude087"]
[OnName num="clolowlude"]
Don't get cocky. It's not ...... a mistake.
[cpg cn=true]


So what is it ...... that makes it seem like no one is attacking me just because I'm subhuman?
[cpg]


Is there something wrong with my body?
[cpg]



;//==============================


*IseSel02_3|A Journey Around the World


[OnName num="kousuke"]
'...... Oh, by the way, you said your name was Chartier . Who's that?
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Clolowlude088"]
[OnName num="clolowlude"]
You've met him, haven't you?　She's the one who put you in the amphibian.
[cpg cn=true]


I'm sure she's right. And Kullulu is apparently acquainted with Chartier . ......
[cpg]


Then we have the fastest way to get back to Japan.
[cpg]


[OnName num="kousuke"]
If you could, could you tell Chartier ...... that I want to go back to Japan?
[cpg cn=true]


[OnName num="kousuke"]
With that amphibian, you should be able to get back to Japan.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude089"]
[OnName num="clolowlude"]
I'd be happy to put you on an amphibian, but I'm afraid they'll take you to another country.
[cpg cn=true]


[OnName num="kousuke"]
Why ......?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clolowlude090"]
[OnName num="clolowlude"]
Because Chartier is not going to let you go back to Japan.
[cpg cn=true]


I don't know what you're talking about. But ......
[cpg]


It looks like I'll have to return to Japan in something other than her flying boat.
[cpg]

[window target=false]

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_09_1.ui" time=1000]
[WAIT time=1100]
;//【ＢＧ】『草原』（朝）******************************************************


[window target=true]



I had a lot of questions. But I couldn't overcome my drowsiness, and by the time I woke up, Kullulu was gone.
[cpg]


I walked along the road, still unsure of what was happening.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『草原』（昼）******************************************************



;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1000]


My food supply was running out. At that time, I came across three beastman women who seemed to be traveling.
[cpg]


[OnName num="kousuke"]
"Please, can you share some food with us?"
[cpg cn=true]


[OnName num="therianthropy_girl_A"]
...... What's this guy ...... doing here?
[cpg cn=true]


[OnName num="therianthropy_girl_B"]
Can you feel it?　It's kind of weird, isn't it?
[cpg cn=true]


Again. I don't want to talk about it anymore, just give me some food. ......
[cpg]



[window target=false]

[BG f="b_09_3.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『草原』（夕方）******************************************************

[window target=true]




I continued to look for someone who could help me get back to Japan, while I was worn out and almost attacked by the occasional beastman.
[cpg]


Finally, I found ......
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[STOPBGM]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（夕方）******************************************************

[window target=true]




[OnName num="kousuke"]
"So this is it, ......."
[cpg cn=true]


I arrived at the site. This must be the village where the Harpy tribe lives.
[cpg]


Harpies have wings. If I'm lucky, they'll let me go back to Japan.
[cpg]



[SE f="se001"]
;//【ＳＥ】『倒れる』





But by the time I thought that, I had run out of energy and collapsed.
[cpg]


I thought dimly that people really do collapse when they are tired.
[cpg]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="e_01_3.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





In the meantime, I had a dream. I wasn't asleep, I was supposed to be in a coma, but I had a dream.
[cpg]


There was someone next to me. I don't know who it is.
[cpg]


I mean, I don't even know who I am. The clothes I see from my perspective are not my taste.
[cpg]


I dream that I am someone else. It was a hazy, yet strangely familiar scene.
[cpg]


I'm in a place that looks like a castle. ...... Maybe it's not Japan.
[cpg]


I wonder where it is. ...... Many subhumans are kneeling down to me.
[cpg]


They treated me as if I were a king or something.
[cpg]



;//画面白く

[BG f="white.ui" time=1000]
[WAIT time=100]

[STOPBGM]

The next time I woke up, everything was still a bit hazy.
[cpg]


The next time I woke up, I was in a room.
[cpg]


Someone's house, lying on a bed.
[cpg]




[window target=false]

[transition target={true} rule="tobira2.png" color={0xffffffff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tobira2.png" color={0xffffffff} time=1000]

;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く

[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（朝）******************************************************

[window target=true]



[WAIT time=1100]


I got up and walked outside, where I met a harpy woman.
[cpg]


[OnName num="harpy_A"]
"Oh, you're ...... awake, aren't you ......?"
[cpg cn=true]


[OnName num="kousuke"]
"......, you saved me?"
[cpg cn=true]



[OnName num="harpy_A"]
Well, it was someone else who found ...... me, but my room was empty.
[cpg cn=true]


I guess you could say that you helped me too.
[cpg]


In any case, it seems that the Harpy people are mild-mannered.
[cpg]


I'm glad I'm not one of those people who would strip a fallen man of his body. I guess they don't have anything to take from me, though.
[cpg]


[OnName num="kousuke"]
Thank you for your kindness.
[cpg cn=true]



[OnName num="harpy_A"]
"Oh, no, I'm not thanking you, I'm just doing what's ...... natural."
[cpg cn=true]


[OnName num="harpy_B"]
Oh!　You're awake, you know. ......
[cpg cn=true]


[OnName num="harpy_C"]
How are you feeling?　Are you hungry?"
[cpg cn=true]


Seeing me and her talking, other harpies came by. They're all women.
[cpg]


There may be male harpies, but they never came to me.
[cpg]


I've never been this popular with humans.
[cpg]


There was something odd about them, but I couldn't figure out what it was.
[cpg]


[OnName num="harpy_B"]
It's not good to keep them all to yourself.
[cpg cn=true]


[OnName num="harpy_C"]
Come to my house, I'll buy you breakfast.
[cpg cn=true]


[OnName num="harpy_A"]
Hey, hey!
[cpg cn=true]


The first girl I met also pulled her hand away from mine. It's like we're fighting over it.
[cpg]


[OnName num="kousuke"]
Don't pull me away. ......
[cpg cn=true]


This feeling of discomfort has been with me ever since I arrived here in the land of the sub-humans.
[cpg]


I wondered why this was happening. The answer to that question was hard to come by.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（昼）******************************************************


;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1100]

I walked around the village of the Harpy tribe for a while.
[cpg]


I tried to make arrangements to return to Japan.
[cpg]


The men in the village were sympathetic, but not kind.
[cpg]


Only the women, after all. Only women would be kind to me. ......
[cpg]


But then, I should have just relied on women.
[cpg]


I had a lot to think about, but it looked like I wouldn't have to worry about food for a while.
[cpg]




[window target=false]

[BG f="b_01_3.ui" time=1500]
[WAIT time=1500]
;//【ＢＧ】『ハーピー族の集落』（夕方）******************************************************

[window target=true]


But still, I couldn't find anyone who looked like her family. I wondered about that, so I asked her.
[cpg]

[OnName num="kousuke"]
Do you live alone?"
[cpg cn=true]


[OnName num="harpy_A"]
Yes, but my parents live just around the ...... corner.
[cpg cn=true]


[OnName num="kousuke"]
Why?　Why?
[cpg cn=true]


[OnName num="harpy_A"]
I have to get married soon. ......
[cpg cn=true]



[OnName num="harpy_A"]
That's why my parents built their house first.
[cpg cn=true]


I wonder if that is possible. I don't know, I guess our culture is different from humans.
[cpg]


[OnName num="kousuke"]
More importantly, ...... can I stay at your house again today?
[cpg cn=true]



[OnName num="harpy_A"]
"Yes. If it's okay with me.
[cpg cn=true]


She looked embarrassed, and her cheeks were strangely red.
[cpg]


This is a great way to get the most out of your business. It's not normal, no matter how much you try.
[cpg]


[OnName num="kousuke"]
"....... What kind of state are you in right now?
[cpg cn=true]



[OnName num="harpy_A"]
What do you mean by that?
[cpg cn=true]


[OnName num="kousuke"]
I've seen this happen to subhumans too many times to count.
[cpg cn=true]


[OnName num="kousuke"]
Is there something wrong with me?　What do you see in me now?
[cpg cn=true]



[OnName num="harpy_A"]
There is something ...... magical about you, you don't seem ...... like a normal person.
[cpg cn=true]


I've been told that, but no matter how many times I thought about it, I couldn't remember it.
[cpg]




[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=10]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（夜）******************************************************

[window target=true]
[WAIT time=100]

A few days after that. As I spent time in the Harpy clan's village, this is what happened.
[cpg]


[OnName num="harpy_A"]
'...... The stars are beautiful, aren't they?
[cpg cn=true]


[OnName num="kousuke"]
"Yes, they are. They don't look this beautiful in Japan.
[cpg cn=true]



[OnName num="harpy_A"]
You know, Kosuke and ......, I thought love at first sight was out of this world.
[cpg cn=true]


See? This is what happens.
[cpg]


[OnName num="harpy_A"]
But then I saw Kosuke , and I realized it really does exist.
[cpg cn=true]


[OnName num="kousuke"]
"Love at first sight."
[cpg cn=true]


Love at first sight, love at first sight. Isn't that what happens to everyone?
[cpg]



[OnName num="harpy_A"]
I have a brother who is dead. I have a dead brother. Kosuke is just like him.
[cpg cn=true]



[OnName num="harpy_A"]
It's not that I was in love with my brother, but I feel so much more relaxed when I'm with ...... you.
[cpg cn=true]


I'm not in love with my brother, but I feel very comfortable with you.
[cpg]


Should I just accept it here?
[cpg]


Of course, it would be a bad idea to cause trouble, but I was beginning to think that I didn't care anymore.
[cpg]



The fact that I want a subhuman wife hasn't changed my mind.
[cpg]


It's not a bad feeling to be courted by a girl.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_11_4.ui" time=1000]
[WAIT time=1000]

I couldn't do nothing, but I couldn't think of what to do.
[cpg]

I was afraid that if I tried to kiss her, something would happen to me.
[cpg]

[OnName num="harpy_A"]
"What do you mean by something, ......?"
[cpg cn=true]

[OnName num="kousuke"]
No, if there's magic in my body, it could be transferred to ...... me.
[cpg cn=true]

I'm talking in my imagination, but I don't think I'm way off.
[cpg]

But what should I do? Would a hug be enough? Would I make her feel uncomfortable?
[cpg]

;//Ｈシーンカット

[STOPBGM]

[WAIT time=1000]


[window target=false]

[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[BGM f="bg_tc"]
[WAIT time=100]
;//【ＢＧ】『ハーピー族の集落』（朝）******************************************************

[window target=true]



Then, early in the morning, I got some news.
[cpg]


[OnName num="harpy_B"]
"Oh my God!　 The elves are looking for you, Kosuke !
[cpg cn=true]


[OnName num="harpy_A"]
"Oh, really, ......?　 What are you doing here, Kosuke ?
[cpg cn=true]


[OnName num="kousuke"]
"Well, it's a little ...... like a crime of passion.
[cpg cn=true]


I don't think he'll be convinced if I just tell him. I decided to explain everything.
[cpg]


He was seen to have seduced an elven woman, and was accused of doing so.
[cpg]


As I listened to the story, the first girl I met had a bit of a clouded expression on her face, but well, that's what's going to happen. ...... I know the feeling.
[cpg]


[OnName num="harpy_C"]
What should we do, Kosuke Mr. ...... should we run away?
[cpg cn=true]


[OnName num="kousuke"]
When you say run away, how do you mean?
[cpg cn=true]


It's more like "where" than "how.
[cpg]



[OnName num="harpy_A"]
You should run away to ...... Japan. You won't be able to get in right away from the land of the elves.
[cpg cn=true]


If I could do that, I wouldn't be struggling. I thought to myself.
[cpg]



[OnName num="harpy_A"]
I was thinking, "Couldn't we Harpies deliver Mr. Kosuke to Japan at ......?"
[cpg cn=true]


[OnName num="harpy_B"]
...... Yes, we could. We don't know what will happen if the elves catch him.
[cpg cn=true]


[OnName num="kousuke"]
Are you sure?　I don't even have any money.
[cpg cn=true]


[OnName num="harpy_C"]
You can pay for it later. For now, you can rely on us.
[cpg cn=true]


They are so kind to me that I don't know why they are doing this.
[cpg]


But I guess ...... Chartier knows why.
[cpg]


[OnName num="kousuke"]
But ...... we can't ask them to carry us, it's too far away.
[cpg cn=true]


[OnName num="harpy_A"]
"We Harpies can use wind magic, so we can fly as fast as an airplane."
[cpg cn=true]


I didn't know that. That's new to me. I've never heard of that, but isn't about as fast as an airplane ......?
[cpg]


[OnName num="harpy_B"]
"Whatever it is, the sooner we leave, the better. What do you say?"
[cpg cn=true]


[OnName num="kousuke"]
Well, can you ask ......?
[cpg cn=true]


[OnName num="harpy_A"]
Yes, sir. No problem.
[cpg cn=true]



[BG f="black.ui" time=1000]
[STOPBGM]
;//ブラックアウト



[SE f="se001"]
;//【ＳＥ】『羽ばたく』

[WAIT time=2000]


[BG f="b_11_1.ui" time=1000]


[WAIT time=1000]

[BGM f="bg_d1"]


So, with the help of the three harpies, we made our way back to Japan.
[cpg]


The posture was like being held in a hug. It's the opposite of a piggyback.
[cpg]


It was wrapped in a unique cloth that looked like a larger version of the one used for babies.
[cpg]


Because of its wings, it could not be used as a piggyback.
[cpg]


And the fact that he had such a tool meant that he probably made a living out of it.
[cpg]


I mean, if he fell, he would die, right? More to the point, don't harpies get tired?
[cpg]


[OnName num="harpy_A"]
No, they don't get tired. We're a species that specializes in that ...... flying."
[cpg cn=true]


I wonder if that's possible. How can it be possible to carry a single person and not be bothered by flying?
[cpg]


[free time=800]


As I was thinking, I was replaced by another harpy in the middle of the quicksand.
[cpg]


After doing this several times, Japan came into view.
[cpg]


I was so relieved that I almost cried.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="101.jpg" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="101.jpg" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="101.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（昼）******************************************************


;//＠
[SE f="se011"]
;//【ＳＥ】『人混み』


Probably Kyushu. When I got there, I saw a modern town.
[cpg]



[OnName num="harpy_A"]
...... This is Japan. It's so close, but I've never been here before.
[cpg cn=true]


[OnName num="harpy_B"]
"That's true. Shall we do some sightseeing?
[cpg cn=true]


[OnName num="harpy_C"]
I'd like to take a break.
[cpg cn=true]


[OnName num="kousuke"]
Hold on a second.
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



[SE f="se009"]
;//【ＳＥ】『走る』





I run to the nearest bank. I run to the nearest bank, withdraw some money and come back ......
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[WAIT time=1]
[STOPBGM]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（昼）******************************************************


[window target=true]

[WAIT time=100]


[OnName num="kousuke"]
Thanks for the ride. If you can exchange the money there, use it.
[cpg cn=true]


I gave him enough money that it might not take much to fly, but I also thanked him for saving my life.
[cpg]


[OnName num="harpy_A"]
Thank you very much. But I'm only happy with my feelings.
[cpg cn=true]


[OnName num="kousuke"]
You can't just give a feeling. ...... Thank you so much for saving my life.
[cpg cn=true]



[OnName num="harpy_A"]
So we'll leave it at that. I'm sure the elven nation will not interfere with Japan.
[cpg cn=true]


[OnName num="kousuke"]
Then ...... I really appreciate your help.
[cpg cn=true]



;//ブラックアウト

[window target=false]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『街＿現代』（夜）******************************************************

[window target=true]



By the time I got back to my house, it was midnight.
[cpg]


By the time I got home, it was midnight and I was about to start work tomorrow. ......
[cpg]


[OnName num="kousuke"]
That was close. ......
[cpg cn=true]


It really was a close call. I could have given it all away.
[cpg]



[free time=1000]
;//[BG f="black.ui" time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************



I feel like I've been through a lot, and I feel like I've had some good things happen to me.
[cpg]


Eventually, I was able to smuggle myself out and sneak back in.
[cpg]


I even managed to make it back home during my vacation.
[cpg]


I was relieved, but I thought about it again. What would it be like to marry a subhuman girl?
[cpg]


After all, the differences in culture and race are a thick wall. I've even been chased by the elves.
[cpg]


And then there are the legal procedures and the customs of the otherworlders. In a word, it's a hassle.
[cpg]


The next morning, I was very tired.
[cpg]

[STOPBGM]
[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_03_1.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
;//【ＢＧ】『街＿現代』（朝）******************************************************


[window target=true]


The next morning, I headed to work, feeling quite exhausted.
[cpg]


Work was not waiting for me. I whipped my tired body into shape.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





My co-workers asked me if I had lost weight. I guess I have lost weight.
[cpg]


I'm sure I've lost weight, because really, there's more to it than one word can say.
[cpg]


But when I look back, I see ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

Fia . Meir . Chartier . Kullulu . ......
[cpg]

[free time=800]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

They were all cute and beautiful, but I'll never see them again.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[free time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『街＿現代』（夕方）******************************************************

[window target=true]
[WAIT time=100]



Should I have exchanged contact information with at least one of them? I don't even know if I have any contact information to begin with.
[cpg]


If I had given them my phone number, would they have called me?
[cpg]


I returned home with an indescribable feeling.
[cpg]


The work was surprisingly manageable.
[cpg]


But my heart felt inexplicably empty.
[cpg]


I headed home, and there it was: .......
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1500]
[STOPBGM]
;//ブラックアウト





[OnName num="kousuke"]
"......"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Fia056"]
[OnName num="fia"]
"......"
[cpg cn=true]


I froze in front of the door. There was a familiar face there.
[cpg]


[window target=false]

[free time=1000]
[WAIT time=1500]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************

[window target=true]




[OnName num="kousuke"]
"...... Well, come on up."
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Fia057"]
[OnName num="fia"]
Sorry to bother you.
[cpg cn=true]


Fia . Why is she here?
[cpg]


[OnName num="kousuke"]
How did she get here? I mean, what for?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Fia058"]
[OnName num="fia"]
I've been wanting to meet ...... you, Kosuke .
[cpg cn=true]


After all, she has an unusual way of being popular.
[cpg]


I can't believe that someone I've only met once likes me so much.
[cpg]


I'm surprised, but Fia says he's always wanted to meet her.
[cpg]


[OnName num="kousuke"]
What are you going to do? Are you going to stay here?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia059"]
[OnName num="fia"]
If you don't mind, I'm prepared to stay here.
[cpg cn=true]


[OnName num="kousuke"]
I can't let you do that. ......
[cpg cn=true]


I had an indescribable feeling.
[cpg]


You can say that you have a subhuman lover, if not your dream subhuman wife .......
[cpg]


I'm also worried that the elves will come after me here again.
[cpg]


[OnName num="kousuke"]
My room is pretty big, right? I think two or three people could stay in it.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Fia060"]
[OnName num="fia"]
"Then go to .......
[cpg cn=true]


[OnName num="kousuke"]
"You can stay here. I won't be able to pay for food or anything for a very long time, though.
[cpg cn=true]


Fia had a big smile on his face.
[cpg]


[FACE method="change_2" pos="2/3"]
;;[t_move pos=C 下礼]
[VOICE f="Fia061"]
[OnName num="fia"]
"Thank you very much!"
[cpg cn=true]


He bowed his head. I really felt ...... unspeakable.
[cpg]


What will happen to me now?
[cpg]

[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_03_1.ui" time=1000]
[WAIT time=1500]

[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（朝）******************************************************

[window target=true]



I had left some money for food at home. I even have a place to sleep.
[cpg]


So, there is no way that Fia can't survive here.
[cpg]


My face smiled. I've never lived with a girl before.
[cpg]



;//※ヒロイン１とヒロイン３は最初から攻略対象となっている

;//■分岐

;//==============================
;//ヒロイン２が攻略対象となっている場合のみイベント発生

[if exp={getFlagValue("Cha2flg_s") == 1 }]
[jump target="*eve_01_1"]
[else]
[jump target="*eve_01_2"]
[endif]


*eve_01_1|A Journey Around the World


[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夕方）******************************************************



;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[WAIT time=1000]


While I was thinking about it, I met another subhuman.
[cpg]


Not just any subhuman, but the one I met during my trip, she was ......
[cpg]


[BG f="b_03_3_up_l.ui" time=1000]
[WAIT time=1500]

[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile077"]
[OnName num="meile"]
Oh.
[cpg cn=true]


[OnName num="kousuke"]
"...... Meir ?"
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile078"]
[OnName num="meile"]
I looked for you, Kosuke . I could smell her, though.
[cpg cn=true]


[OnName num="kousuke"]
No, no, wait. You're not supposed to do magic.
[cpg cn=true]


I can still see how Fia found my house. It must have been magic or something.
[cpg]


But isn't it weird that Meir can do the same thing?
[cpg]


[OnName num="kousuke"]
"How did you find me?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile079"]
[OnName num="meile"]
I told you, I found you by smell.
[cpg cn=true]


That's ridiculous. But then again, they did find me.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile080"]
[OnName num="meile"]
"Hey, can I go to Kosuke 's house?　I came all the way to Japan just for you.
[cpg cn=true]


I couldn't say no, so I headed to the house. ......
[cpg]


Even if you refuse, you still have to go home. Even if I refuse, I still have to go home. Even if I leave it alone, Meir will come to my house.
[cpg]



;//ブラックアウト
[window target=false]
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************

[window target=true]

;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く
[WAIT time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Fia062"]
[OnName num="fia"]
Welcome home ......, the beastly one ......?
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile081"]
[OnName num="meile"]
"Huh?　Elf ......?　 What do you mean, Kosuke ?
[cpg cn=true]


The two of them had never met before. I'm sure you'll be able to tell.
[cpg]


[OnName num="kousuke"]
"Well, ......, she's Fia . I told you I'm being chased."
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Meile082"]
[OnName num="meile"]
Yeah. You followed Kosuke here, too.
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="Meile083"]
[OnName num="meile"]
I'm Meir . Nice to meet you.
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Fia063"]
[OnName num="fia"]
Yes, ......."
[cpg cn=true]


I'm , and it's nice to meet you.
[cpg]


Meir You can find a lot of things that you can do to make your life easier.
[cpg]

[window target=false]

[STOPBGM]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（朝）******************************************************

[window target=true]




The three of us were cramped together. The situation was like a man's dream, but it was still hard to sleep.
[cpg]


I woke up early in the morning and decided to leave the house before the two of us.
[cpg]


Leave a note. I leave a note for Fia and Meir , telling them to go sightseeing in Japan during the day.
[cpg]


Especially Meir , who can't stand to be stuck in a small space.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





The weekday continues. I'd like to spend some time with my suburban girlfriend, but that's not allowed.
[cpg]


I have a normal day of work ahead of me. It's been a long holiday weekend, so I've been dizzyingly busy.
[cpg]

[window target=false]

[STOPBGM]
[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]

[transition target={true} rule="39.png" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="39.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************


[window target=true]



In the evening, I could finally be with the two of them. ......
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sMeile002"]
[OnName num="meile"]
"Hey, Kosuke . Do you have anything for me?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Fia064"]
[OnName num="fia"]
"Hey, you're a little ...... too close."
[cpg cn=true]


While Meir is attached to me, Fia is trying to pull me away.
[cpg]

[free time=800]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/2" time=800]

[VOICE f="sMeile003"]
[OnName num="meile"]
"Didn't Fia have something to do with Kosuke ?　Don't stop me."
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia065"]
[OnName num="fia"]
...... That's true, but...
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile086"]
[OnName num="meile"]
You don't like subhumans or beastmen or ......?
[cpg cn=true]


Even as Meir was closing in on me, he seemed to have a complex about himself as a beastman.
[cpg]


I was not sure what to say.
[cpg]





;//■選択肢
[switch]
[case "No answer."]
	[swap]
	[jump target="*IseSel04_1"]
[case "I don't hate them."]
	[swap]
	[jump target="*IseSel04_2"]
[endswitch]



One, I won't answer.
2, I don't hate it.



;//==============================
;//１、答えない
*IseSel04_1|A Journey Around the World



[OnName num="kousuke"]
......
[cpg cn=true]


[FACE method="change_5" pos="1/2"]
[VOICE f="Meile087"]
[OnName num="meile"]
"......"
[cpg cn=true]


[FACE method="change_4" pos="2/2"]
[VOICE f="Fia066"]
[OnName num="fia"]
Oh, um, I don't think ...... Kosuke is the kind of person who would discriminate like that.
[cpg cn=true]


[FACE method="change_4" pos="1/2"]
[VOICE f="Meile088"]
[OnName num="meile"]
Yeah, I know. I know. I know, right?　 Kosuke "
[cpg cn=true]


I couldn't reply. I was a little annoyed that he had barged in out of the blue.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[if exp={getFlagValue("Cha2flg") == 1 }]
[stflag Cha2flg=-1]
[endif]


;//ヒロイン２は攻略対象でなくなる

[jump target="*IseSel04_3"]

;//==============================
;//２、嫌いじゃない

*IseSel04_2|A Journey Around the World



[OnName num="kousuke"]
"I don't hate you. No, you don't.
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Meile089"]
[OnName num="meile"]
Thank you."
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

Meir hugs me and pushes me down.
[cpg]


[FACE method="change_7" pos="1/2"]
[FACE method="change_7" pos="2/2"]
[VOICE f="sMeile004"]
[OnName num="meile"]
"...... Kosuke . Hey, I ...... want to be around you more."
[cpg cn=true]


I was going to say, "There's Fia next to me.
[cpg]


[FACE method="change_2" pos="2/2"]
[VOICE f="Fia067"]
[OnName num="fia"]
I was going to say, "Oh, ...... I'm going to go shopping."
[cpg cn=true]



[move from="2/2" to="5/3" ease="easeInOutSine" time=1000]

[SE f="se004"]
;//【ＳＥ】『ドア閉まる』





Fia left the room without any money.
[cpg]


[FACE method="change_6" pos="1/2"]
[WAIT time=1]
[move from="1/2" to="2/3" ease="easeInOutSine" time=1000]

[VOICE f="sMeile005"]
[OnName num="meile"]
" Fia , you're so considerate."
[cpg cn=true]


[OnName num="kousuke"]
"...... ah."
[cpg cn=true]




;//ブラックアウト

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]



I wondered if it was a good idea, but I felt like I was trying to make up for the cost of housing him.
[cpg]

[VOICE f="sMeile006"]
[OnName num="meile"]
After all, Kosuke smells good, doesn't it?
[cpg cn=true]

[OnName num="kousuke"]
So you're not aware of that. ......
[cpg cn=true]

[VOICE f="sMeile007"]
Soooo ...... soooo ...... mmmm, so irresistible!
[cpg cn=true]


;//========================================
;//●ＣＧエロ（主人公に迫るヒロイン。体の上に乗っている）ev_01
;//人物１：ヒロイン２　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：主人公の部屋＿現代
;//時間　：夜
;//========================================

*Scene007|A Journey Around the World

[STOPBGM]


[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[BGM f="bg_h1"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=100]


And just as I was about to say that, Meir came crashing down on me!
[cpg]

[OnName num="kousuke"]
"Wait a minute. Wait a minute, aren't you going wild?
[cpg cn=true]


;**【ＣＧ】 ev_01_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=100]

When I said that, Meir puffed out his cheeks and got an angry look on his face.
[cpg]

[VOICE f="sMeile008"]
[OnName num="meile"]
No, I'm not. You're making fun of me because I'm a beastman.
[cpg cn=true]

It is true that the term "wild" is not appropriate for a beastman.
[cpg]

[OnName num="kousuke"]
No, no, ......."
[cpg cn=true]

In any case, I don't think they will do anything to me.
[cpg]

I'm not ready for that either, I thought, as she leaned down and put his face close to my chest.
[cpg]


;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile009"]
[OnName num="meile"]
I want to stay with you forever."
[cpg cn=true]

She said this and went back to her original position.
[cpg]

[VOICE f="sMeile010"]
[OnName num="meile"]
I'd do anything for you if Fia wasn't here.
[cpg cn=true]

Meir says thoughtfully. Confused, I asked.
[cpg]

[OnName num="kousuke"]
What do you mean by "anything"?
[cpg cn=true]

I ask, confused. "What do you mean, what for?" Meir smirks and brings her face close to mine again.
[cpg]

;**【ＣＧ】 ev_01_b ***********************
[CG id=0 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sMeile011"]
[OnName num="meile"]
You're thinking dirty thoughts.
[cpg cn=true]

[OnName num="kousuke"]
It's your fault!
[cpg cn=true]

[VOICE f="sMeile012"]
[OnName num="meile"]
It's your fault! It's your fault!
[cpg cn=true]

Meir seems to be a mischievous character. No, I kind of knew that. ......
[cpg]

;//Ｈシーンカット


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_04_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d3"]

[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************


[window target=true]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="4/2" time=1]
[WAIT time=1]



[move from="4/2" to="2/2" ease="easeInOutSine" time=1000]

[VOICE f="Fia068"]
[OnName num="fia"]
"Oh, sorry to bother you, ......."
[cpg cn=true]


After a while of flirting, Fia came back into the room with trepidation.
[cpg]


It was awkward. So did Fia , and so did Meir .
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="sMeile013"]
[OnName num="meile"]
I'd like to be alone with you for a while longer.
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="sFia005"]
[OnName num="fia"]
"That's not fair to Meir ."
[cpg cn=true]

;//＠
;//フィアが謝ることは何も無いと思うが、それでも謝ってきた。
;//[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]
;//ブラックアウト



[stflag Cha2flg=1]
;//ヒロイン２は攻略対象のまま



;//==============================


*IseSel04_3|

*eve_01_2|A Journey Around the World

;//==============================


;//■分岐


;//==============================

;//ヒロイン４が攻略対象となっている場合のみイベント発生

[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_04_1"]
[else]
[jump target="*eve_04_2"]
[endif]


*eve_04_1|A Journey Around the World

;//■分岐

;//■分岐

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夜）******************************************************





One weekday evening. She showed up.
[cpg]


[BG f="b_03_4_up_l.ui" time=1000]
[WAIT time=1500]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]


[OnName num="kousuke"]
"...... you."
[cpg cn=true]


[VOICE f="Clolowlude091"]
[OnName num="clolowlude"]
I came for you. You should be grateful."
[cpg cn=true]


Kullulu was there. I reminded myself that I'd done something rude to Kullulu .
[cpg]


I was still on my way back to the house. I wondered what Fia would think if I took him home. ......
[cpg]


What would Kullulu think if I took her home?
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude092"]
[OnName num="clolowlude"]
Where's your house?　Where is your house?" "I'd like you to take me there if you like.
[cpg cn=true]


It's almost a compulsion, though I say "if you want.
[cpg]


She is a magician. I don't know what will happen if I refuse her.
[cpg]



;//ブラックアウト
[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************


[window target=true]



[OnName num="kousuke"]
"So, you're the demon from Kullulu ......?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Clolowlude093"]
[OnName num="clolowlude"]
"Yes, a demon. And your name is Kullulu Urud, not Kullulu ."
[cpg cn=true]

;//[free time=800]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Fia075"]
[OnName num="fia"]
"......."
[cpg cn=true]


Fia would be flabbergasted. He's probably wondering how many women he's approached.
[cpg]



*eve_05_2|A Journey Around the World

;//■分岐

;//[free time=800]


[FACE method="change_1" pos="1/2"]
[FACE method="change_1" pos="2/2"]

[VOICE f="Fia077"]
[OnName num="fia"]
Nice to meet you, ...... Kullulu Mr. Wolrd."
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude096"]
[OnName num="clolowlude"]
"Yes, it's nice to meet you. It's nice of you to call me that without abbreviating."
[cpg cn=true]


Kullulu , I knew you had a thing for that.
[cpg]



;//ブラックアウト

[STOPBGM]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[free time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（朝）******************************************************


[window target=true]



And before Fia woke me up. Before Kullulu woke up, woke me up.
[cpg]


*eve_05_3|A Journey Around the World



[OnName num="kousuke"]
...... What the fuck?
[cpg cn=true]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Clolowlude097"]
[OnName num="clolowlude"]
Your pheromones are alive and well.
[cpg cn=true]


[OnName num="kousuke"]
I don't know what you're talking about. I don't know what you're talking about.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clolowlude098"]
[OnName num="clolowlude"]
"I don't know," is not good enough. You can't just say you don't know. I'm a ...... prisoner of pheromones.
[cpg cn=true]


This. This is not a good trend.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude099"]
[OnName num="clolowlude"]
...... Fia wouldn't leave you alone.
[cpg cn=true]


[OnName num="kousuke"]
And that's not the same thing.
[cpg cn=true]


Even though I refused, Kullulu kept coming on to me.
[cpg]

[OnName num="kousuke"]
What if something ...... Fia happens?
[cpg cn=true]

*eve_06_3|A Journey Around the World


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude122"]
[OnName num="clolowlude"]
I'm just showing you."
[cpg cn=true]


Kullulu was a pretty crazy thing to say. But if you were in my shoes, you might be right. ......
[cpg]


[OnName num="kousuke"]
...... If we're going to flirt, let's at least do it when no one else is around.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sClolowlude004"]
[OnName num="clolowlude"]
You don't mind flirting, do you?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clolowlude124"]
[OnName num="clolowlude"]
You should be grateful. You should be grateful that a beautiful woman like me is coming on to you so much.
[cpg cn=true]


I'm not sure if I'd say it myself, but ...... she's certainly beautiful.
[cpg]

;//Ｈシーンカット



;//==============================

*eve_04_2|A Journey Around the World

;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[STOPBGM]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_04_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夕方）******************************************************

[window target=true]




I was going to be living with a subhuman girl for a while.
[cpg]


Fia was cooking for me, using Japanese ingredients that I was not familiar with.
[cpg]


I didn't understand the situation, but I thought it was okay because I was happy.
[cpg]


The cost of living is a bit high, but I can manage that for a while with my savings.
[cpg]


[OnName num="kousuke"]
" Fia , what's for dinner today?"
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia078"]
[OnName num="fia"]
I tried to make miso soup, but I'm not too sure about ...... it.
[cpg cn=true]


[OnName num="kousuke"]
It's amazing. They don't have miso soup in elf country.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia079"]
[OnName num="fia"]
Yes, ......, but there was something on TV the other day about miso soup being good for you.
[cpg cn=true]


Elf watching TV. It's kind of strange.
[cpg]

[free time=1000]

;//＠
[SE f="se012"]
;//【ＳＥ】テレビをつける（スイッチを押す）

I went to the dining table and turned on the TV.
[cpg]


[OnName num="kousuke"]
"...... what?"
[cpg cn=true]


I was carefree and enjoying living together. However, the situation was more serious than I thought.
[cpg]


What I saw on the TV news was my face.
[cpg]


I was so surprised that I could not react. If you ask me what I had done to make the news, I might have done it.
[cpg]


[OnName num="news_caster"]
"Wanted criminal last seen in elf country ......"
[cpg cn=true]


Wanted criminal. I was surprised by the word "wanted", but even more so by ......
[cpg]


The reason why I was being hunted in the land of the elves seemed to be for a reason other than to catch me for the crime of tricking Fia .
[cpg]


The person on the TV, who seemed to be the chief of the elves, said this.
[cpg]


[OnName num="elven_chief"]
It is the reincarnation of the Demon Lord. ...... There have been signs of this for some time.
[cpg cn=true]


[OnName num="elven_chief"]
It seems to be a man in his twenties, but he must have just woken up. The prophecy is true.
[cpg cn=true]


In the event that you're looking for the best way to get the most out of your business, you'll want to look at the following tips.
[cpg]


I'm not aware of that at all. I'm not aware of it at all, or rather, it's so sudden that I don't understand.
[cpg]


In the first place, I had broken the law to come to the land of the elves, and even then I was being hunted. ......
[cpg]


It's a good idea to take a look at the website and see if you can find any useful information.
[cpg]



;//==============================
;//ヒロイン２が攻略対象となっている場合のテキスト

;//■分岐
[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*eve_07_1"]
[else]
[jump target="*eve_07_2"]
[endif]


*eve_07_1|A Journey Around the World

[free time=800]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Meile119"]
[OnName num="meile"]
"Wow, Kosuke !　I'm the reincarnation of a demon king.
[cpg cn=true]


[OnName num="kousuke"]
"Wait a minute. I don't know anything about that.
[cpg cn=true]

[jump target="*eve_07_3"]

;//==============================
;//ヒロイン２が攻略対象となっていない場合のテキスト

;//■分岐

*eve_07_2|A Journey Around the World


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia080"]
[OnName num="fia"]
Kosuke Mr. ......, is that right?"
[cpg cn=true]


[OnName num="kousuke"]
No, no ...... I don't know either."
[cpg cn=true]



;//==============================

*eve_07_3|A Journey Around the World

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]

[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************





The television continued to show the news. There seemed to be an announcement from the land of the elves this afternoon, and the news was all over the news throughout the night.
[cpg]


The Demon Lord has so much power that weapons are useless.
[cpg]


It was even said that the world would become his ...... when he appears.
[cpg]


It's not enough to just be thrown in jail if you get caught.
[cpg]

[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[OnName num="kousuke"]
"What should I do, Fia ......, I don't want to die."
[cpg cn=true]


Fia makes a difficult face. And then.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia081"]
[OnName num="fia"]
I don't want to die." "Then why don't you go to ...... the land of the beasts?
[cpg cn=true]


He said. You're right.
[cpg]


[free time=800]

I don't think it would be a good idea to stay in Japan or head to the land of the elves.
[cpg]


The country of the beastmen is probably the slowest to come after us. But it's only slow.
[cpg]


It doesn't directly help you protect yourself. ......
[cpg]




;//==============================
;//ヒロイン４が攻略対象となっている場合のテキスト

;//■分岐
[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_08_1"]
[else]
[jump target="*eve_08_2"]
[endif]



*eve_08_1|A Journey Around the World



[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude148"]
[OnName num="clolowlude"]
'You can't be frightened now, can you?
[cpg cn=true]


[OnName num="kousuke"]
You've known about Kullulu for a long time?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude149"]
[OnName num="clolowlude"]
Yes, of course.
[cpg cn=true]


Was that so? ...... Did the subhumans want me because I was a demon king?
[cpg]

[jump target="*eve_08_3"]

;//==============================
;//ヒロイン４が攻略対象となっていない場合のテキスト

;//■分岐

*eve_08_2|A Journey Around the World


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia082"]
[OnName num="fia"]
"You don't look so good, Kosuke Mr. ......."
[cpg cn=true]


[OnName num="kousuke"]
"...... Oh, yeah, ...... that's right."
[cpg cn=true]



;//==============================

*eve_08_3|A Journey Around the World

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_04_4.ui" time=1000]

[WAIT time=1500]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************

[window target=true]



It's night. If I don't sleep, I won't be able to go to the office tomorrow, but going to the office is also a bad idea.
[cpg]


What should I do? Will I even be able to eat tomorrow?
[cpg]



[SE f="se010"]
;//【ＳＥ】『玄関のチャイム』

[WAIT time=1100]



Just as I was thinking this, I saw someone coming to my house.
[cpg]


The police. I was scared, but I couldn't not answer.
[cpg]


With determination, I unlocked the door before .......
[cpg]


It opened from the outside. I was wondering what it was, when I saw the face of the person who opened the door.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye018"]
[OnName num="schartye"]
"What a look on his face. The Demon Lord..."
[cpg cn=true]


[OnName num="kousuke"]
You, ......, now what?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye019"]
[OnName num="schartye"]
"Is that how you want to talk about it?　Doesn't the Demon Lord need any help?"
[cpg cn=true]


[OnName num="kousuke"]
...... No, no. I'd appreciate it if you could help me.
[cpg cn=true]

[free time=800]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Fia083"]
[OnName num="fia"]
Well, who is this guy?
[cpg cn=true]


[OnName num="kousuke"]
Chartier . It's a long story, but it's .......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Schartye020"]
[OnName num="schartye"]
"To put it simply, he took my Demon Lord around the world.
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Schartye021"]
[OnName num="schartye"]
It was all a setup for this day. Demon Lord.
[cpg cn=true]


[OnName num="kousuke"]
...... Please don't call me the Demon Lord.
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Schartye022"]
[OnName num="schartye"]
The beastman kingdom is still in its infancy. You know that, don't you, Demon Lord?
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Schartye023"]
[OnName num="schartye"]
That means you can literally be a king too.
[cpg cn=true]


[OnName num="kousuke"]
What do you mean, ......?
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Schartye024"]
[OnName num="schartye"]
If you're a king, you need to be a king and build your kingdom.
[cpg cn=true]




[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[free time=1]
[STOPBGM]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="163.jpg" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_03_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夜）******************************************************


[window target=true]



I'm sure you've heard of it.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia084"]
[OnName num="fia"]
I've heard rumors about the amphibian ......, but I've never seen one before.
[cpg cn=true]

[VOICE f="sFia006"]
[OnName num="fia"]
I don't know how something so big can float.
[cpg cn=true]


[OnName num="kousuke"]
I don't know either. ...... It must be magic or something.
[cpg cn=true]



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye025"]
[OnName num="schartye"]
Don't get spooked. Let's go."
[cpg cn=true]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト
;//【ＢＧ】『空』（夜）******************************************************



[SE f="se005"]
;//【ＳＥ】『魔法発動する音　シンセパッド系』


[WAIT time=1500]



Then we flew out of Japan with the subhuman girl.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
During the journey, Chartier explained to me about my constitution.
[cpg]


Apparently, I have a pheromone that makes subhumans go into heat, and my saliva, for example, contains magical elements.
[cpg]

[VOICE f="sSchartye001"]
[OnName num="schartye"]
The subhuman who is kissed by you might have an increase in magic power. That's how much magic element it contains."
[cpg cn=true]

[OnName num="kousuke"]
You're lying. ......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSchartye002"]
[OnName num="schartye"]
It's not a lie. It has the power to attract mainly women, but even men will be happy to see the Demon Lord return if they are subhuman.
[cpg cn=true]


[OnName num="kousuke"]
Is that what ...... is?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye027"]
[OnName num="schartye"]
It's a good thing. Subhumans don't take kindly to being vulnerable even now."
[cpg cn=true]


While we are talking about this, the airship goes.
[cpg]


The suspicious passengers are also not here today.
[cpg]

[free time=800]


;//==============================
;//ヒロイン４が攻略対象となっていない場合のみイベント発生

;//■分岐
[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_10_2"]
[endif]




[OnName num="kousuke"]
"So, ...... where is she?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude150"]
[OnName num="clolowlude"]
"...... what?"
[cpg cn=true]


Before you know it, you're with Chartier Kullulu Urud.
[cpg]


She's apparently acquainted with Chartier .
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude151"]
[OnName num="clolowlude"]
I'm here to help. I hope you don't mind.
[cpg cn=true]


For some reason, she wants to help me build my country.
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Clolowlude152"]
[OnName num="clolowlude"]
"The return of the Demon Lord is a long-cherished dream for us subhumans," she said.
[cpg cn=true]


He said the same thing as Chartier .
[cpg]



;//==============================


*eve_10_2|A Journey Around the World


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[STOPBGM]
[BG f="b_10_1.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



Then we arrived at the Land of Beasts. There is no way I can suddenly declare myself a king and become one.
[cpg]


At any rate, I headed to the village where Meir was.
[cpg]



;//==============================
;//ヒロイン２が攻略対象となっていない場合のみイベント発生

;//■分岐
[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*eve_11_2"]
[endif]



On my way there, I naturally met Meir again.
[cpg]


She was surprised, but still looked happy.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile120"]
[OnName num="meile"]
" Kosuke ......!　Why are you here?"
[cpg cn=true]


[OnName num="kousuke"]
"Oh, oh, ......, it's a long story."
[cpg cn=true]


I recounted the story. I told him that I was being hunted more than ever before.
[cpg]


I explained that I was going to start my own country and he said he would help me with that.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile121"]
[OnName num="meile"]
"So you're a demon king. Kosuke is ......!　No wonder I thought you were out of the ordinary."
[cpg cn=true]


I couldn't keep up with the tension. I was rather worried.
[cpg]


And isn't it too early to accept?　I still haven't caught up with it.
[cpg]


Maybe it's because it's my own thing. ......
[cpg]


;//続くのでリセットで転調



;//==============================

*eve_11_2|A Journey Around the World




;//続くのでリセットで転調
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_1.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


;//==============================

*eve_12_2|A Journey Around the World



Then Chartier starts.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye028"]
[OnName num="schartye"]
I will gather the people of this village. The Demon Lord himself will not go to the village.
[cpg cn=true]


[OnName num="kousuke"]
"But, but ......
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye029"]
[OnName num="schartye"]
"All you have to do is stay put."
[cpg cn=true]

[free time=800]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Clolowlude153"]
[OnName num="clolowlude"]
That's right. You don't need to be afraid.
[cpg cn=true]


You don't have to be afraid. ......
[cpg]

[STOPBGM]


[free time=1000]
[window target=false]

[BG f="b_10_3.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



The beastmen from all over the village have gathered. No, they're gathering from outside the village?
[cpg]


There are so many of them. There are about a thousand of them.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Schartye030"]
[OnName num="schartye"]
"Listen up!　The Demon Lord has been resurrected here and now!
[cpg cn=true]


[VOICE f="Clolowlude154"]
[OnName num="clolowlude"]
We are his dependents!　In order to protect the Demon Lord, and to create a world for him, ......
[cpg cn=true]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye031"]
[OnName num="schartye"]
What is our longing?　What is our longing?
[cpg cn=true]


It's a strange atmosphere. Fia was a little frightened, but Meir was swallowed by the air.
[cpg]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye032"]
[OnName num="schartye"]
What is our longing?
[cpg cn=true]


Cheers erupt. This is not good. I'm not that kind of person.
[cpg]


[OnName num="therianthropy_A"]
"Oh, Demon Lord ......, I would give my life for you."
[cpg cn=true]


[OnName num="therianthropy_B"]
I'll challenge you to any kind of battle. I won't let the humans and elves have their way with you!
[cpg cn=true]


[free time=800]

In any case, they seem to be pleased with the Demon Lord's resurrection, and everyone is worshipping me.
[cpg]


[OnName num="kousuke"]
"...... Oh, yeah. I'm the Demon Lord, maybe ......."
[cpg cn=true]


I decided to call myself the Demon King, feeling unsettled.
[cpg]

[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]




That night, it was like a banquet. It seems that the demon king is a very important person to the subhumans.
[cpg]


A short distance away from the party, Chartier and I talked.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye033"]
[OnName num="schartye"]
"Maybe it's time to tell him everything."
[cpg cn=true]


[OnName num="kousuke"]
What do you mean, "everything" ......?　What's going on?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye034"]
[OnName num="schartye"]
It's not much, but it's important. It's not much, but it's important.
[cpg cn=true]


Chartier opens her mouth. She said that she had already discovered that she was the reincarnation of the Demon King.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye035"]
[OnName num="schartye"]
"I took you on a trip as a prelude to this. I didn't send you back to Japan right away so that you could make friends in each place."
[cpg cn=true]


Chartier explained. Then Kullulu came in.
[cpg]


[free time=800]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Clolowlude155"]
[OnName num="clolowlude"]
What?　The two of you are talking.
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Schartye036"]
[OnName num="schartye"]
We were talking about why we took the Demon Lord on the trip.
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude156"]
[OnName num="clolowlude"]
Oh. Well, it's hard to understand without an explanation, isn't it?
[cpg cn=true]


I was becoming more and more aware of it as he said it.
[cpg]


It is true that Fia would not have become one of us if we had not gone to the land of the elves.
[cpg]


It's also possible that if you hadn't met Meir in person, you wouldn't have been able to ask for his help right away.
[cpg]


[OnName num="kousuke"]
It's a good idea to have a good idea of what you're looking for.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye037"]
[OnName num="schartye"]
It's not surprising that he was suddenly discovered to be the reincarnation of the demon king and was killed.
[cpg cn=true]


I shuddered. Was it just a hair's breadth away, or did this journey lead to my awakening as a demon king?
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="sSchartye003"]
[OnName num="schartye"]
Let me tell you one more thing. Your qualities as a demon lord are awakened when you connect with a subhuman.
[cpg cn=true]


[OnName num="kousuke"]
"Awakening ...... what?"
[cpg cn=true]


When I asked him about the details, he said that falling in love with a subhuman, kissing her, or something like that would remind his soul that he was a demon king.
[cpg]


The theory seemed to be that it was because they had created a harem of subhumans in the past.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="sSchartye004"]
[OnName num="schartye"]
"The former Demon Lord had countless children with subhuman daughters. What about the current Demon Lord?"
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


I think back. It's not so much a replacement as it is a ......
[cpg]


[FACE method="change_7" pos="2/2"]
[VOICE f="sClolowlude005"]
[OnName num="clolowlude"]
In any case, the number of people you connect with in the future will probably change your personality as well.
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Schartye040"]
[OnName num="schartye"]
That's right. Whether you want world domination or peace depends on how much of your nature as a demon lord returns.
[cpg cn=true]


[OnName num="kousuke"]
...... Is it true, Kullulu . Everything you've said so far is true?
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude158"]
[OnName num="clolowlude"]
There's nothing to deny.
[cpg cn=true]


I knew it. ...... My nature changes when I fall in love with a subhuman girl.
[cpg]


If everyone is tempted too much, I guess his predisposition as a demon king will be revived.
[cpg]


I couldn't imagine if that was a good thing or a bad thing.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude159"]
[OnName num="clolowlude"]
I couldn't imagine if that was a good thing or a bad thing. "Whatever it is, you should be grateful to Chartier . You're still in danger of being killed."
[cpg cn=true]


I felt like I had gotten myself into a terrible situation, but I was determined to protect myself as the Demon Lord.
[cpg]



;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[free time=1]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="163.jpg" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_10_1.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



It was morning, and everyone's excitement had calmed down a bit.
[cpg]


Still, it seemed that everyone respected me.
[cpg]


Men and women alike bowed deeply when confronted with me.
[cpg]


[OnName num="kousuke"]
"The Demon King, the Demon King, or ......."
[cpg cn=true]


But even though I'm the Demon King, there's no sign that I can use magic.
[cpg]


You can't use magic because you've never used it before. I decided to talk to Fia and Meir about it.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile122"]
[OnName num="meile"]
I don't know much about magic myself.
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="Fia085"]
[OnName num="fia"]
"I do have some knowledge."
[cpg cn=true]


[OnName num="kousuke"]
I have some knowledge. Well, why don't you teach me?　You're a demon king, you should be able to use some of it.
[cpg cn=true]


It's a matter of image. It's a matter of image. Since he's a demon king, he should be able to use magic.
[cpg]


So the three of us, Fia and Meir , talked about magic.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia086"]
[OnName num="fia"]
Magic, like anything else, can only be achieved through a combination of ...... effort and talent.
[cpg cn=true]


[OnName num="kousuke"]
What about me? Hard work, but talent?
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Meile123"]
[OnName num="meile"]
I think I can sense some kind of magical power from Kosuke , but ......
[cpg cn=true]


Meir doesn't refer to me as the Demon Lord, does it? Well, that's about it.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia087"]
[OnName num="fia"]
You're not wrong. I'm sure you're not the only one. Kosuke seems to have ...... tremendous magical qualities."
[cpg cn=true]


So says Fia , holding out his hand towards me.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia088"]
[OnName num="fia"]
...... Perhaps Chartier or Kullulu-Urd would be a better choice than me to teach you.
[cpg cn=true]


[OnName num="kousuke"]
"Well, I guess those two can do magic."
[cpg cn=true]


Fia tells me that they have strong magical qualities, but they don't know how to use them.
[cpg]


So, I was taught magic by Fia , Chartier and Kullulu .
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=100]
;//ブラックアウト





Fia and Kullulu were not so keen, but Chartier was willing to teach me magic.
[cpg]


He wasn't talking too fast, but he was giving me so much information that I was confused.
[cpg]


[WAIT time=500]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye041"]
[OnName num="schartye"]
You get the gist?　Now let's talk about how summoning magic works.
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Fia089"]
[OnName num="fia"]
No, let's take a break here. Kosuke , you look tired.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye042"]
[OnName num="schartye"]
Are you?　I don't know.
[cpg cn=true]


I was so tired that I deliberately showed it in my attitude. I don't understand even if you explain everything to me out of the blue.
[cpg]


But it was a matter of life and death for me, so I took it seriously.
[cpg]


[window target=false]
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]


Several days and nights passed.
[cpg]


I was to stay in the country of the beastmen, in a house that was intended for ...... guests in that village.
[cpg]


But sooner or later, I'll have to build a castle or something, or I'll suddenly find myself on the wrong side of the bed.
[cpg]

[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





With that in mind, I was successfully performing my first magic.
[cpg]



[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』



;//フラッシュ
[BG f="white.ui" time=1000]
[WAIT time=1000]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1000]

;//【ＢＧ】『村＿獣人の国』（昼）******************************************************






The three of us, Fia , Chartier , and I, were in a magic class. However, it seems that Fia doesn't know as much as Chartier .
[cpg]


[OnName num="kousuke"]
"Did it work?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Fia090"]
[OnName num="fia"]
Yes, it did. The magic of summoning ...... should have summoned the ideal demon you envisioned, but this is not .......
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="sSchartye005"]
[OnName num="schartye"]
A tentacled creature. Wonderful."
[cpg cn=true]


Tentacles. They are buzzing and wriggling.
[cpg]


It's red and black and creepy, but I see, this is the demon I've been looking for.
[cpg]


[OnName num="kousuke"]
"......"
[cpg cn=true]

It's an indescribable feeling to be told that these demons lived inside my head.
[cpg]

But it's true that I don't like dragons, gryphons, and other cool demons.
[cpg]


I also like horror movies. I guess that's the image I have.
[cpg]



[FACE method="change_7" pos="1/2"]
[VOICE f="sSchartye006"]
[OnName num="schartye"]
"After all, he is the reincarnation of the former Demon Lord. I can feel the remnants of that man."
[cpg cn=true]


[OnName num="kousuke"]
...... Is that so?
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="sSchartye007"]
[OnName num="schartye"]
Yeah. You should be able to control it as you wish. You can use it as you wish.
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


I even got a seal of approval from Chartier .
[cpg]

The tentacled creature was still buzzing. The tentacled creature was still writhing about, and Fia was frightened to see it.
[cpg]

[FACE method="change_7" pos="2/2"]
[VOICE f="sFia007"]
[OnName num="fia"]
"Yes, in case of emergency, ...... it might be a fighting force."
[cpg cn=true]

Fia I'm going to use it to help her get through the day.
[cpg]

I was wondering if I could use this to play a trick on the girls.
[cpg]

It's not that I've regained my old memories, but I think I was thinking something similar before I was reincarnated. ......
[cpg]


I had such a vague memory in my mind.
[cpg]


[OnName num="kousuke"]
How do I get rid of this ......?
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Fia091"]
[OnName num="fia"]
Wait a minute, please.
[cpg cn=true]


[FACE method="change_5" pos="1/2"]
[VOICE f="Schartye046"]
[OnName num="schartye"]
...... Hey, you're getting tangled up.
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia092"]
[OnName num="fia"]
...... Wait a minute, please.
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『触手絡みつく』


[BG f="b_10_2_l.ui" time=1000]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



Then there was an agony. My magic power was too strong and the tentacle creature went out of control.
[cpg]


It got entangled in Chartier 's body and wouldn't leave.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Schartye047"]
[OnName num="schartye"]
"Demon Lord! ...... What am I supposed to do with this?"
[cpg cn=true]


[OnName num="kousuke"]
"Oh, don't ask me!　 Fia , what should I do ......?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Fia093"]
[OnName num="fia"]
"Wait a minute, you can do the opposite of summoning. ...... Uh, wait a minute."
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Fia094"]
[OnName num="fia"]
Where did I put the grimoire to erase ......?
[cpg cn=true]


[OnName num="kousuke"]
I don't know!　You don't have it?
[cpg cn=true]

[FACE method="change_5" pos="2/2"]
[VOICE f="sFia008"]
[OnName num="fia"]
I'll go look for it!
[cpg cn=true]

[move from="2/2" to="4/2" ease="easeInOutSine" time=1000]




I'm going to go look for it!" With that, Fia left the scene to get out of danger.
[cpg]


I'll go look for it!" Then Chartier left the scene to get out of danger. I turned to , thinking, "Oh, come on.
[cpg]



;//========================================
;//●ＣＧ（触手に絡まれるヒロイン。逃げだそうとしている）ev_14
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：触手　　　　服装ex：無し
;//場所　：村＿獣人の国
;//時間　：昼
;//========================================

*Scene012|A Journey Around the World

[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=100]


[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[WAIT time=1000]


[VOICE f="sSchartye008"]
[OnName num="schartye"]
"I can't ...... unwind.
[cpg cn=true]
[OnName num="kousuke"]
You all right, Chartier ?
[cpg cn=true]

[VOICE f="sSchartye009"]
[OnName num="schartye"]
"It's slimy and not very pleasant. ......
[cpg cn=true]

[VOICE f="sSchartye010"]
[OnName num="schartye"]
"But when I think of the demons that the Demon Lord created, I..."
[cpg cn=true]

[OnName num="kousuke"]
Don't raise your voice. ......
[cpg cn=true]

I feel like I'm being naughty.
[cpg]

[OnName num="kousuke"]
I don't know what to do, I don't want to do this either.
[cpg cn=true]

;**【ＣＧ】 ev_14_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sSchartye011"]
[OnName num="schartye"]
I don't know, either. I think the Demon Lord can control it to some extent. ......
[cpg cn=true]


I see. If I can manipulate her to my will, then I can just remind her to let go.
[cpg]

[OnName num="kousuke"]
Hold on a second, Chartier .
[cpg cn=true]

[VOICE f="sSchartye012"]
[OnName num="schartye"]
I can't wait, because I'm stuck.
[cpg cn=true]
[OnName num="kousuke"]
"I'm sorry, ......."
[cpg cn=true]

I apologize and try my best to imagine releasing her.
[cpg]

But that was not enough to control the demons.
[cpg]

It's a good idea to take a look at the website and see if there is anything you can do to help.
[cpg]



;[SceneEnd f="sc_012"]

;[Live2d target=0]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



After all, the scene looked familiar when I tried it. I told it to Chartier .
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sSchartye013"]
[OnName num="schartye"]
I told it to . "I see. The more you do this, the more your qualities as a demon lord will come back.
[cpg cn=true]

[FACE method="change_6" pos="1/2"]
[VOICE f="sSchartye014"]
[OnName num="schartye"]
I'm not going to be displeased. It's not that I can't say anything I don't like.
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="4/2" time=1]

This was the same as his previous claim.
[cpg]

[move from="4/2" to="2/2" ease="easeInOutSine" time=1000]

[VOICE f="Fia095"]
[OnName num="fia"]
" Chartier , I figured out how to delete it!　I'm going to delete it now!"
[cpg cn=true]


But then Fia came back.
[cpg]


After that, I figured out how to remove the tentacles and Chartier was released. ......
[cpg]


[STOPBGM]

[free time=1000]
[WAIT time=1000]
[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************

[window target=true]




A few days passed. A few days passed, and I was gradually gaining more and more magic that I could use.
[cpg]


One day, a messenger from Japan and the land of the elves came to visit.
[cpg]


Fia took care of it for me. Or rather, I ordered him to do it.
[cpg]


I'm afraid to meet them in person. On the other hand, Chartier or Kullulu might take the messenger alive.
[cpg]


I thought that Fia would be the best choice.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Fia096"]
[OnName num="fia"]
He said he would not kill them if they surrendered ...... meekly.
[cpg cn=true]


[OnName num="kousuke"]
...... What do you think?
[cpg cn=true]



[VOICE f="Meile124"]
[OnName num="meile"]
Hmmm ...... I think it's best not to trust them.
[cpg cn=true]


Meir looks at Kullulu .
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude160"]
[OnName num="clolowlude"]
Maybe the elven magic will seal you in for life and you won't be able to die.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Schartye070"]
[OnName num="schartye"]
"Probably."
[cpg cn=true]


They say. Fia did not deny it. It's a much worse situation than you might imagine.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト





It's a good idea to have a good idea of what you're looking for.
[cpg]


It's a temporary one. The village where Meir lived, the place where the sheik lived.
[cpg]


It's a good idea to have a good idea of what you're looking for and what you can do to help.
[cpg]


Of course, it's not as defensible as a castle.
[cpg]


But of course, it doesn't have the defensive capabilities of a castle. Still, if the other side uses force, Chartier and Kullulu say they'll take care of it.
[cpg]


Without knowing how much we can rely on them, our days of studying magic passed by.
[cpg]



;//==============================
;//ヒロイン２が攻略対象となっている場合のみイベント発生

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*eve_13_1"]
[else]
[jump target="*eve_13_2"]
[endif]



*eve_13_1|A Journey Around the World


;//■分岐
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************





I couldn't sleep, so I decided to walk around the village at night.
[cpg]


Everyone is so carefree. This village could have been invaded.
[cpg]


But ...... do you think they would do anything for me?
[cpg]


Or do they think that if they were to be killed, it would only be me?
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile125"]
[OnName num="meile"]
"Ah. Kosuke."
[cpg cn=true]


[OnName num="kousuke"]
"Oh. ...... Meir ?"
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile126"]
[OnName num="meile"]
What's wrong with you?　You don't look well.
[cpg cn=true]


[OnName num="kousuke"]
No, nothing's wrong.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Meile127"]
[OnName num="meile"]
Everyone in my village welcomes you. You should be proud of yourself.
[cpg cn=true]


[OnName num="kousuke"]
You say that, but ...... I'm in fear of my life.
[cpg cn=true]


You may be right," Meir said.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile128"]
[OnName num="meile"]
"We subhumans have been discriminated against just because we are subhumans.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile129"]
[OnName num="meile"]
I'm sure everyone is thinking about the chance to change that.
[cpg cn=true]


That's too much to ask. But I couldn't stop myself from doing something about it.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Meile130"]
[OnName num="meile"]
Are you watching ...... Fia ?
[cpg cn=true]


[OnName num="kousuke"]
" Fia ?　 What about Fia ?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sMeile014"]
[OnName num="meile"]
"It's not just Fia . It's not just ......, it's me and ....... We're all crazy about you.
[cpg cn=true]


[OnName num="kousuke"]
....... Yeah, that's true.
[cpg cn=true]


They are all under the influence of my pheromones.
[cpg]


You may want to understand that.
[cpg]


Maybe you should at least love the Meir people who are near you.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile132"]
[OnName num="meile"]
"Hey, Kosuke . Come here for a minute."
[cpg cn=true]


Meir is looking for something. I knew it, and I took her up on her offer.
[cpg]


[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト

[BG f="b_10_4_l.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************



I stayed by her side for a while. It's a great way to get to know someone.
[cpg]

[FG f="CHA02_p7_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMeile015"]
[OnName num="meile"]
"Hey ...... Kosuke ."
[cpg cn=true]

She seemed to be begging for a kiss, but my kisses contain magic elements.
[cpg]

So I didn't want to get Meir into any trouble. ......
[cpg]



I decided to stop there for the day.
[cpg]



[VOICE f="sMeile016"]
[OnName num="meile"]
I don't care about ...... Kosuke . I don't want to do anything."
[cpg cn=true]


[OnName num="kousuke"]
"It's not that I don't want to, but there are ...... circumstances."
[cpg cn=true]


I wondered if Meir would be convinced if I explained everything.
[cpg]


I was wondering if Meir would agree with me if I explained everything to them. looked sad, but nodded.
[cpg]


;//==============================

*eve_13_2|A Journey Around the World

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





A few more days pass. My efforts were about to bear fruit.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye071"]
[OnName num="schartye"]
"......, that's about right. That's about as good as it gets."
[cpg cn=true]


[OnName num="kousuke"]
"Huh, huh, how's ......?"
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Fia097"]
[OnName num="fia"]
It's amazing, Kosuke . It's really a level that no ordinary wizard can reach.
[cpg cn=true]


As a result of his training, he was able to use magic, albeit falteringly.
[cpg]


It's a good idea to have a good idea of what you're doing.
[cpg]


[FACE method="change_1" pos="2/2"]
[VOICE f="sFia009"]
[OnName num="fia"]
This is the reincarnation of the demon king,......, more than you can imagine.
[cpg cn=true]

;//;[FO layer="1/2"]



[FACE method="change_2" pos="1/2"]
[VOICE f="Schartye072"]
[OnName num="schartye"]
I'm not surprised. I'm sure you'll agree with my assessment.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude161"]
[OnName num="clolowlude"]
You're right, it's more than I imagined. I'm a little more impressed.
[cpg cn=true]


[OnName num="kousuke"]
"Oh, yeah? ......?"
[cpg cn=true]


I didn't feel so bad. And I wondered if I could protect myself a little ......
[cpg]

[window target=false]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_3.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



Well, now that I can protect myself. What to do next: ......
[cpg]


[OnName num="kousuke"]
The next thing to do is to get a castle. We are too careless as it is now."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Fia098"]
[OnName num="fia"]
I agree, but there's no way ...... we're going to get the manpower.
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[FACE method="change_7" pos="1/2"]

[VOICE f="Meile183"]
[OnName num="meile"]
You know what?　Don't you think there are more people in this village?
[cpg cn=true]


[OnName num="kousuke"]
Sure. There's been a lot of people here lately.
[cpg cn=true]


Beastmen and sub-humans have been gathering around us.
[cpg]

[FACE method="change_2" pos="2/2"]
[FACE method="change_7" pos="1/2"]
[VOICE f="Fia099"]
[OnName num="fia"]
I wonder why they're gathering. ......
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[FACE method="change_7" pos="1/2"]

[VOICE f="Meile184"]
[OnName num="meile"]
It's all over the news. They want to help Kosuke ."
[cpg cn=true]


[OnName num="kousuke"]
I see. ......
[cpg cn=true]


It seems that they are coming from all over the beastman country.
[cpg]


If that's the case, let's get them to help us build the castle.
[cpg]


[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_10_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************


[window target=true]



So, the castle is being built little by little.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
I was not in charge of the construction, but Chartier was.
[cpg]


[OnName num="kousuke"]
"Does Chartier know anything about construction?"
[cpg cn=true]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye073"]
[OnName num="schartye"]
No. It's a good idea to have someone to give instructions to in order to make people aware that they are working for the Demon Lord.
[cpg cn=true]


[OnName num="kousuke"]
Is that what ...... is for?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye074"]
[OnName num="schartye"]
It's like that. The Demon Lord only gives orders when it's really important.
[cpg cn=true]


[OnName num="kousuke"]
All right. I will do that.
[cpg cn=true]


Having said that, I still can't really feel it.
[cpg]



;//ブラックアウト
[window target=false]
[STOPBGM]

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_03_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（昼）******************************************************

[window target=true]




The time is ticking away. I could easily imagine that the way the world looked at me would gradually change. It was easy to imagine.
[cpg]


The fact that I was gaining power as the Demon King, and that I was starting to build a castle, someone must be watching me.
[cpg]


[window target=false]

;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_02_2.ui" time=1000]

[WAIT time=1500]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************

[window target=true]




Although the whole country is not trying to destroy me, ......
[cpg]


The same thing was already about to happen.
[cpg]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************





[OnName num="kousuke"]
"Assassins ......?"
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Fia100"]
[OnName num="fia"]
Yes. Chartier and Kullulu Urud said they found ...... it."
[cpg cn=true]


It seemed that many assassins had come from the land of the elves, who particularly abhorred the Demon Lord.
[cpg]


[FACE method="change_3" pos="1/2"]
[VOICE f="Schartye075"]
[OnName num="schartye"]
There's nothing to worry about. So far, the straw and the Kullulu wolrd have managed to do everything.
[cpg cn=true]


Chartier said, but I was not in the mood.
[cpg]


I just hope that the castle will be completed soon. ......
[cpg]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_10_4.ui" time=1000]

[WAIT time=1500]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************

[window target=true]


;//==============================
;//ヒロイン４が攻略対象となっている場合のみイベント発生
[if exp={getFlagValue("Cha4flg_s") == 1 }]
[jump target="*eve_14_1"]
[else]
[jump target="*eve_14_2"]
[endif]


*eve_14_1|A Journey Around the World


[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1500]


;//■分岐

;//室内ですので上下に黒帯を入れてください

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]


[FG f="CHA04_p5_01_a.ui" method="change_1"  pos="2/3" time=1000]
That night, I shared my concerns with Kullulu .
[cpg]


She had been assigned a guest bedroom, and I asked her where it was.
[cpg]


I asked her where she was. Kullulu had just gone to bed, and was getting up from the bed, rubbing her eyes.
[cpg]


[OnName num="kousuke"]
...... Sorry. This late at night.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude162"]
[OnName num="clolowlude"]
Don't apologize, and don't worry about it. Don't apologize and don't worry about it, you seem to have good luck.
[cpg cn=true]


I wondered if he was complimenting me or what, but then I remembered that Kullulu had been coming on to me, too.
[cpg]


[OnName num="kousuke"]
"Are you also now attracted to ...... my magical element?"
[cpg cn=true]


Kullulu doesn't say anything. Then, he looks away for a moment.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Clolowlude163"]
[OnName num="clolowlude"]
Don't make me say it. ...... I can't say it.
[cpg cn=true]


He looks a little uncomfortable Kullulu . I wondered what he meant by that.
[cpg]





;//■選択肢
[switch]
[case "I wondered if he was expecting something."]
	[swap]
	[jump target="*IseSel05_1"]
[case "Maybe you're not attracted to yourself."]
	[swap]
	[jump target="*IseSel05_2"]
[endswitch]


One, I wonder if I'm expecting something.
2. Maybe I'm not attracted to myself.



;//==============================
;//１、何か期待しているのだろうか
*IseSel05_1|A Journey Around the World




[OnName num="kousuke"]
...... Kullulu . I haven't been able to take care of you in a long time, you know.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sClolowlude006"]
[OnName num="clolowlude"]
Yeah. I've been waiting for ......."
[cpg cn=true]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


[BG f="b_10_4_l.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************


;//Ｈシーンカット

And then one thing came to my mind.
[cpg]

[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[OnName num="kousuke"]
" Kullulu . I have a good massage technique.
[cpg cn=true]

[OnName num="kousuke"]
And one more question, are you comfortable with tentacled creatures?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[VOICE f="Clolowlude187"]
[OnName num="clolowlude"]
What are you talking about, ......?　Tentacles?
[cpg cn=true]


[OnName num="kousuke"]
You know you can summon tentacles now, don't you? Use them.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Clolowlude188"]
[OnName num="clolowlude"]
Don't be ridiculous. You should use Chartier for that.
[cpg cn=true]


Chartier is definitely a place where you can do whatever you want.
[cpg]


There is a certain amount of fun in that. But there's also a certain amount of fun to be had with someone like Kullulu who doesn't like you.
[cpg]


[OnName num="kousuke"]
All right, let's subpoena it. Don't run away.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clolowlude189"]
[OnName num="clolowlude"]
"Wait, wait, wait, don't cast a spell!"
[cpg cn=true]


In the meantime, I had succeeded in summoning her.
[cpg]


[OnName num="kousuke"]
Don't worry, it's just a massage."
[cpg cn=true]


She was terrified. But even if she tried to escape, she couldn't.
[cpg]


I decided to use my tentacles to entangle Kullulu 's body.
[cpg]

[free time=800]

;//========================================
;//●ＣＧ（触手プレイ。マッサージと称している）ev_18
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：触手　　　　服装ex：無し
;//場所　：獣人の国＿室内寝室
;//時間　：夜
;//========================================

*Scene012|A Journey Around the World

[BG f="black.ui" time=1000]
[free time=1000]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sClolowlude007"]
[OnName num="clolowlude"]
Hey, ......, this is really weird.
[cpg cn=true]

[OnName num="kousuke"]
Don't move too much or you might stimulate some weird pressure points.
[cpg cn=true]

But I don't know anything about massage.
[cpg]

In addition to that, it is not possible to stimulate the ...... acupuncture points with tentacles that you are not used to moving.
[cpg]

It's not a normal massage, but it's not a massage at all.
[cpg]


;**【ＣＧ】 ev_18_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sClolowlude008"]
[OnName num="clolowlude"]
Ugh, I'm being touched. ...... It feels weird.
[cpg cn=true]

[OnName num="kousuke"]
I heard that the soles of the feet have many acupuncture points.
[cpg cn=true]

I've heard that the soles of the feet have a lot of acupuncture points," he said as he began to massage her body.
[cpg]

[VOICE f="sClolowlude009"]
[OnName num="clolowlude"]
"No, stop, you're tickling me.
[cpg cn=true]

[VOICE f="sClolowlude010"]
[OnName num="clolowlude"]
"It's so slimy. ...... Really, stop it."
[cpg cn=true]

She tried to shake him off, but was unable to escape.
[cpg]

[VOICE f="sClolowlude011"]
[OnName num="clolowlude"]
If you're going to give me a massage, I want it to be normal.
[cpg cn=true]

[OnName num="kousuke"]
"You're probably stronger than I am. I'm probably stronger than I am as a human, so I thought it might be a good fit.
[cpg cn=true]

It was all very sophomoric, but she accepted it, even though she didn't like it.
[cpg]

;**【ＣＧ】 ev_18_b ***********************
[CG id=4 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sClolowlude012"]
[OnName num="clolowlude"]
I'm sure you can massage her. It's weird ......."
[cpg cn=true]

[OnName num="kousuke"]
I've summoned one before. I've learned to control it a little bit."
[cpg cn=true]

I was enjoying her reaction for a while as we talked about this.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


[stflag Cha4flg=1]
;//ヒロイン４は攻略対象のまま
;//■分岐

[jump target="*IseSel05_3"]

;//==============================
;//２、自分に惹かれてないのかもしれない

*IseSel05_2|A Journey Around the World



I don't know, maybe Kullulu doesn't mean they're attracted to me.
[cpg]


I may have fallen in love with her because of pheromones or something, but I don't think she likes me.
[cpg]


[OnName num="kousuke"]
"Sorry. Sorry to interrupt."
[cpg cn=true]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
With that, I left Kullulu .
[cpg]

[FACE method="change_4" pos="2/3"]
I think Kullulu looked at me as if to say, "Why?" ......
[cpg]


[if exp={getFlagValue("Cha4flg") == 1 }]
[stflag Cha4flg=-1]
[endif]

;//ヒロイン４は攻略対象でなくなる


;//■分岐

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]


;//==============================

*IseSel05_3|

*eve_14_2|A Journey Around the World

;//==============================





Then. The construction of the Demon King's Castle proceeded smoothly.
[cpg]


The construction of the Demon King's Castle went smoothly, as there was an abundance of manpower.
[cpg]


I wondered where the supplies were, but there were so many people that I had no trouble getting them.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************





[OnName num="kousuke"]
It's coming along nicely. ......
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Meile185"]
[OnName num="meile"]
"Yeah. It's almost finished. Is that what you call a finished castle?
[cpg cn=true]


But other than the castle, the rest of the village hasn't changed much from the original.
[cpg]


It would be cool if there was a castle town or something like that.
[cpg]

[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





After several days and nights, we finally arrived at .......
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[OnName num="kousuke"]
...... Nice chair.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye076"]
[OnName num="schartye"]
"It looks good on you, Demon Lord."
[cpg cn=true]


I don't feel bad. I guess I really am a Demon Lord now.
[cpg]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude210"]
[OnName num="clolowlude"]
You'll want to dress accordingly. Cloak."
[cpg cn=true]


[OnName num="kousuke"]
I'll leave that to you guys.
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sFia010"]
[OnName num="fia"]
I'll leave that up to you. ...... Actually, I already have.
[cpg cn=true]

;//;[FO layer="2/2"]


I'll leave that to you guys." "Then Fia I've already got something for you," said as he went to get something.
[cpg]

[OnName num="kousuke"]
Is ...... Fia particular about what they wear?
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sMeile017"]
[OnName num="meile"]
Maybe so. Maybe so. Fia I mean, elves are fashionable even in their simple clothes."
[cpg cn=true]

And when he returned, Fia brought with him the bad taste and over-decorated clothes of a demon king.
[cpg]

[OnName num="kousuke"]
"Simple and fashionable ......."
[cpg cn=true]

He and Meir looked at each other. Aside from that.
[cpg]


I wonder how long he's been making them. It's not something I can prepare right away.
[cpg]


But it seemed to suit me now.
[cpg]


[OnName num="kousuke"]
I'll start wearing it today. I'll start wearing it today.
[cpg cn=true]


[FACE method="change_2" pos="1/2"]
[VOICE f="sFia011"]
[OnName num="fia"]
"Yes. Yes, it's worth the effort.
[cpg cn=true]


She laughed. That's enough about the clothes. ......
[cpg]


It's a pretty big castle. It must be able to house a lot of people.
[cpg]


But even this is not enough, the number of subhumans coming here is increasing day by day.
[cpg]


It seemed that subhumans were gathering from other continents and islands across the sea.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="sFia012"]
[OnName num="fia"]
Yes, some of them have volunteered to be soldiers to protect Kosuke you. What should we do, ......?"
[cpg cn=true]


[OnName num="kousuke"]
There's nothing to be done. If we don't use who we can, I'm going to get killed.
[cpg cn=true]


;//;[FO layer="4/4"]

[FACE method="change_2" pos="2/2"]
[VOICE f="Meile186"]
[OnName num="meile"]
You're right. You can't be too carefree about it, can you?
[cpg cn=true]


After that, we started talking about creating a Demon Lord army.
[cpg]


I'm not going to be able to command it by myself anymore.
[cpg]


[OnName num="kousuke"]
I'm sure you'll be happy to know that I'm not the only one who has a problem with this.
[cpg cn=true]


[OnName num="kousuke"]
"I think Chartier and Kullulu are the right people for the military. Can I leave it to them?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye077"]
[OnName num="schartye"]
"You don't have to tell me, I'm doing it. I'm doing it without being told, because I'm the one who's organizing the people who are volunteering to be soldiers.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude211"]
[OnName num="clolowlude"]
...... I'll help you as much as I can. I'll help as much as I can. I'm trying to protect the Demon Lord.
[cpg cn=true]


[OnName num="kousuke"]
Internal affairs are ...... Meir .
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile187"]
[OnName num="meile"]
I don't even know what internal politics is. I don't know anything about politics.
[cpg cn=true]

;//;[FO layer="2/2"]

[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile018"]
[OnName num="meile"]
I mean, I've never been in charge of ...... a group of people.
[cpg cn=true]


Meir was not going to listen to me. I don't think I have a choice. ......
[cpg]


[FACE method="change_3" pos="2/2"]
[VOICE f="Clolowlude212"]
[OnName num="clolowlude"]
You are going to defy the demon lord's orders?
[cpg cn=true]

[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile019"]
[OnName num="meile"]
I'm sure you'll agree that it's a great idea.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Schartye078"]
[OnName num="schartye"]
But for you guys, the Demon Lord is your hope to elevate the status of subhumans.
[cpg cn=true]


[OnName num="kousuke"]
Please. You've been my friends since the beginning.
[cpg cn=true]


[OnName num="kousuke"]
I want you to stay by my side as much as possible. Can't you ......?
[cpg cn=true]


[FACE method="change_4" pos="1/2"]
[VOICE f="sMeile020"]
[OnName num="meile"]
It's hard for me to say no when you're acting like that.
[cpg cn=true]


[OnName num="kousuke"]
Don't worry, I'm going to get you an aide who knows politics. Can you just accept my title?
[cpg cn=true]


But I'm sure Chartier will choose the person who will do that.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile021"]
[OnName num="meile"]
"...... can't help it."
[cpg cn=true]


[OnName num="kousuke"]
"Okay. It's settled.
[cpg cn=true]



[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Fia103"]
[OnName num="fia"]
Um, I'm ......?
[cpg cn=true]


Only Fia has not been assigned a role. I was thinking about that too.
[cpg]


[OnName num="kousuke"]
I'd like Fia to do some diplomacy, or ...... some negotiations, especially with the elven nations.
[cpg cn=true]


It's not just elf country. It is not only the Elf Nation, but also the human nation of Japan, which is right next to us, that sees me as a problem.
[cpg]


It's a good idea to have a good idea of what you're looking for.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Schartye079"]
[OnName num="schartye"]
I can't blame them. When the other world and this world were still separate, the Elves and the Demon Lord were at odds with each other.
[cpg cn=true]


[OnName num="kousuke"]
That's right. If not, it would be strange for them to be in conflict even though they are subhuman.
[cpg cn=true]


[FACE method="change_3" pos="2/2"]
[VOICE f="Fia104"]
[OnName num="fia"]
Yes, ......, this feud goes back quite a ways. It's not something that can be managed through discussion.
[cpg cn=true]


[OnName num="kousuke"]
"Still, I want to reduce the number of useless fights. Fia "
[cpg cn=true]


[OnName num="kousuke"]
You're an elf by nature, you know. I think you're the right person for the job. What do you think?
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Fia105"]
[OnName num="fia"]
...... I understand.
[cpg cn=true]


Fia I'm sure you'll find a lot of people who are interested in this topic. That's convenient. ......
[cpg]

In the event that you have any questions regarding where and how to use the internet, you can call us at the web site.
[cpg]

Before assigning them to their first job, I was made to wear a dress.
[cpg]

[FACE method="change_2" pos="1/2"]
[VOICE f="Schartye080"]
[OnName num="schartye"]
It's interesting, Demon Lord. It suits you well.
[cpg cn=true]


I'll have to wear such ostentatious clothes on a regular basis from now on. ...... Oh well.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Meile190"]
[OnName num="meile"]
I'm sure you'll be happy to hear that.　Are you going to take over the name of the beastman country?"
[cpg cn=true]


[OnName num="kousuke"]
...... Since we're here, I'd like to give it a different name.
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia106"]
[OnName num="fia"]
What kind of name would you like?　We don't want to offend the other countries too much. ......
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye081"]
[OnName num="schartye"]
No. No, we should suggest that we dare to fight.
[cpg cn=true]


The girls are divided in their opinions, but ......
[cpg]


[OnName num="kousuke"]
I think we should simply call it the Land of the Demon King.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile191"]
[OnName num="meile"]
Yes, I agree. I'm with you.
[cpg cn=true]


[FACE method="change_7" pos="2/2"]

[VOICE f="Fia107"]
[OnName num="fia"]
Is that so? ......?　Doesn't it give a scary impression?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye082"]
[OnName num="schartye"]
The opposite. We can't maintain our dignity with a name like that.
[cpg cn=true]


After balancing the various opinions, the name "Land of the Demon King" was chosen.
[cpg]


The "Land of the Demon King" was newly established within the Land of the Beasts.
[cpg]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト
;//【ＢＧ】『空』（夜）******************************************************





Some of the beastmen were against the rule of the Demon Lord.
[cpg]


There was also the fact that the borders of the country hadn't been decided in the first place, so there were now two forces within the beast country.
[cpg]


And the anxiety in my heart did not disappear just because a castle was built.
[cpg]


My days passed by as I held the subhumans in my arms one by one, faking the anxiety of not knowing when I would be killed.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************





[OnName num="kousuke"]
"......?"
[cpg cn=true]


In the quiet corridor, I heard a singing voice coming from somewhere. It was a familiar voice.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia108"]
[OnName num="fia"]
It was a familiar voice: "Ah, ...... Kosuke ."
[cpg cn=true]


The voice belonged to Fia .
[cpg]


[OnName num="kousuke"]
" Fia . Do you like to sing?
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Fia109"]
[OnName num="fia"]
Yes, I do. I like to sing. ...... In times like these, I don't want to forget what I like.
[cpg cn=true]


[OnName num="kousuke"]
What's the song called?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia110"]
[OnName num="fia"]
There are many names for it. I don't know which one is the right one. ...... But it's a song that's been handed down in Elf country since I was a child.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia111"]
[OnName num="fia"]
It's a song that soothes my soul. It's also a reminder of a happy past.
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


A happy past. I was a little confused by that phrase.
[cpg]


Fia It's a good idea to have a good idea of what you're looking for.
[cpg]


[OnName num="kousuke"]
" Fia . Where was your room?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia112"]
[OnName num="fia"]
"Yeah, it's ...... right around the corner.
[cpg cn=true]


[OnName num="kousuke"]
Can I go? If you can't sleep, I'll stay with you.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="sFia013"]
[OnName num="fia"]
...... I can see why you can't sleep.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


We both walked to Fia 's room.
[cpg]


I snuggled up next to her and stayed with her until she fell asleep. ......
[cpg]

;//Ｈシーンカット



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_10_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************





After that, I continued to work on my magic.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Fia135"]
[OnName num="fia"]
Your magic has become quite stable.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Schartye083"]
[OnName num="schartye"]
No, not at all. No matter how good you are, it usually takes five years to get to this point.
[cpg cn=true]


[OnName num="kousuke"]
Is that what ......?
[cpg cn=true]


I'm starting to be able to summon not only tentacles, but simple creatures like slime.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Meile192"]
[OnName num="meile"]
It's a good thing Kosuke can now defend itself, right?
[cpg cn=true]


[OnName num="kousuke"]
Yes, it is. Chartier It's good that Kullulu can now protect itself.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Clolowlude213"]
[OnName num="clolowlude"]
Really. How many assassins have you killed, ......?"
[cpg cn=true]


I shuddered when I heard that, but I was somewhat relieved.
[cpg]


I'll take care of myself. Not only that, but I have friends now.
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_07_1.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城内＿廊下』（朝）******************************************************





[OnName num="soldier_A"]
I can't believe the Demon Lord is back. ......
[cpg cn=true]


[OnName num="soldier_B"]
Yeah. It won't be long before we beastmen get our just desserts.
[cpg cn=true]


[OnName num="soldier_A"]
That's right. You have no idea how oppressed we've been. ......
[cpg cn=true]


I'm sure you'll be able to understand.
[cpg]


[OnName num="kousuke"]
"......"
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

As I walked through the corridors of the castle, soldiers would salute me.
[cpg]


It was probably planted by Chartier or Kullulu . Maybe it's Chartier .
[cpg]


I don't know, it's not annoying, but it's a bit disturbing. ......
[cpg]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

I went outside again, thinking what to do. Next to me is Fia with me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia136"]
[OnName num="fia"]
"Well, ......, what can I do for you?"
[cpg cn=true]


[OnName num="kousuke"]
"No. I heard there's a wild tentacled creature around here.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia137"]
[OnName num="fia"]
What ......?　What are you talking about, Kosuke ?
[cpg cn=true]

[OnName num="kousuke"]
We have to study the wildlife before we can use summoning magic.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sFia014"]
[OnName num="fia"]
You know, I'm not very good with ...... creatures like that.
[cpg cn=true]


[OnName num="kousuke"]
Oh well. I'm not good with such creatures.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト




As soon as I entered the forest, I saw the creature.
[cpg]

[VOICE f="sFia015"]
[OnName num="fia"]
"What?"
[cpg cn=true]

;//========================================
;//●ＣＧ（触手がフィアに絡まる）ev_20
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：触手　　　　服装ex：無し
;//場所　：森
;//時間　：昼
;//備考　：公式サイト一枚目のＣＧです
;//========================================

*Scene016|A Journey Around the World

[BG f="black.ui" time=1000]
[free time=1000]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[WAIT time=1000]
[STOPBGM]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sFia016"]
[OnName num="fia"]
"I can't untie it. ......!　What power!
[cpg cn=true]

[OnName num="kousuke"]
Wait for me. I'll help you now. ...... No, ......."
[cpg cn=true]

I suddenly thought. It's boring to rescue Fia right away.
[cpg]

It's a good idea to have a good idea of what you're doing.
[cpg]

[OnName num="kousuke"]
I'm sure you'll be able to keep her interested for a while while you untie her.
[cpg cn=true]

Fia looked at me with a surprised look.
[cpg]

;**【ＣＧ】 ev_20_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia017"]
[OnName num="fia"]
"Hey!　I'm really in trouble.
[cpg cn=true]

I know you're in trouble. But I had to come up with an excuse.
[cpg]

[OnName num="kousuke"]
I'm sure you'll be pleased to know that I'm not the only one.
[cpg cn=true]

[VOICE f="sFia018"]
[OnName num="fia"]
"That's terrible, Kosuke and ......!"
[cpg cn=true]

[OnName num="kousuke"]
I know it's terrible, but bear with me.
[cpg cn=true]

[VOICE f="sFia019"]
[OnName num="fia"]
It's almost as if I'm the bait.
[cpg cn=true]

It's like I'm the bait, or rather, I am.
[cpg]

[OnName num="kousuke"]
Well, the mouth is in this position. It's like an octopus.
[cpg cn=true]

;**【ＣＧ】 ev_20_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia020"]
[OnName num="fia"]
Stop observing and help me!
[cpg cn=true]

Pretending to examine the tentacled creature, I observed ...... while also observing Fia .
[cpg]

After that, I rescued her after I understood her biology.
[cpg]




;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_10_3.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************

[window target=true]




In the meantime, it was evening.
[cpg]


I have to go back to the castle soon. The actual command center is Chartier , but it's not a good thing that I'm not in the castle.
[cpg]


[OnName num="kousuke"]
I should go back to the castle. Fia "
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sFia021"]
[OnName num="fia"]
"...... Yes. Please don't ask me to do this again.
[cpg cn=true]


[OnName num="kousuke"]
I don't know. No promises."
[cpg cn=true]


Fia gave him a subtle look. Well, okay.
[cpg]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





And then, it's night in my room.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドアノック』





I hear a knock on my door and I answer it.
[cpg]


[OnName num="kousuke"]
"Who is it?"
[cpg cn=true]



[VOICE f="Schartye084"]
[OnName num="schartye"]
It's Chartier . Can I come in?
[cpg cn=true]


[OnName num="kousuke"]
"......, yeah. Sure.
[cpg cn=true]



[SE f="se002"]
;//【ＳＥ】『ドア開く』





[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSchartye015"]
[OnName num="schartye"]
How's it going? How's it going with the subhuman girl?
[cpg cn=true]


[OnName num="kousuke"]
I've been pretty good. ......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sSchartye016"]
[OnName num="schartye"]
That's not good enough. I'm going to be awakened as a demon king.
[cpg cn=true]


As I was saying this, Chartier was also coming on to me.
[cpg]


I'm sure she has feelings for me as well. It's not just the pheromones that are seducing you.
[cpg]


[OnName num="kousuke"]
...... I've never been this popular.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye087"]
[OnName num="schartye"]
It's a good idea to take it in stride. The demon king is the demon king.
[cpg cn=true]


Maybe so, but I'm not sure. ......
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye088"]
[OnName num="schartye"]
It is a great honor to be touched by a demon king. I'm glad to hear that.
[cpg cn=true]


[OnName num="kousuke"]
...... I see."
[cpg cn=true]


Chartier says something like that. It's hard to say.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



You can't read her mind. I don't know how much ...... she's really saying.
[cpg]


;//Ｈシーンカット

;//ブラックアウト

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Then I had an idle chat with Chartier .
[cpg]


I couldn't refuse, even though I wondered if she would be jealous Fia or something.
[cpg]


In addition, I had a great reason to wake up as a demon king.
[cpg]


I'm sure that Fia will understand ...... how naive I am to think that.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





And the night dawns. The country of the demon king, so far, everything was going well.
[cpg]


More people, more things. The beastmen were self-sufficient to begin with.
[cpg]


There was never a shortage of food and they never complained.
[cpg]


As the number of people increased, the types of business increased. And as the number of people increased, so did the need for places to live.
[cpg]


The city was being developed. Houses and stores were built and developed.
[cpg]


In the end, I realized that a nation is run by its people.
[cpg]



;//ブラックアウト

[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=100]

[BG f="b_10_2.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



;//背景が変化　村の背景が徐々に薄くなって城下町になる感じ




[BG f="b_05_2.ui" time=2500]
[WAIT time=2500]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

[BGM f="bg_d3"]


[window target=true]



As a result, the area around the Demon King's Castle had become quite like a castle town.
[cpg]


The sub-people who had been scattered in different areas and races were now gathering here.
[cpg]


Of course, the Elf Nation and Japan wouldn't take it well. That much.
[cpg]


If you're not careful, they might march on you. ......
[cpg]


[OnName num="kousuke"]
You can't blame them for thinking about .......
[cpg cn=true]


Somehow, I was walking with Meir next to me. She was optimistic, but...
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile193"]
[OnName num="meile"]
She was optimistic, but said, "Well, you know. I'm sure that day will come.
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="4/2" time=800]


She wasn't the type of person who fooled around with reality. I'm not saying that we'll always be at peace.
[cpg]



[SE f="se009"]
;//【ＳＥ】『走る』

[move from="2/3" to="1/2" ease="easeInOutSine" time=1000]

[move from="4/2" to="2/2" ease="easeInOutSine" time=1000]


[STOPBGM]




Then Fia came running in. He was out of breath and didn't look like he was here to give us good news.
[cpg]



[OnName num="kousuke"]
"What's up? Fia "
[cpg cn=true]



[VOICE f="Fia160"]
[OnName num="fia"]
"...... Elven soldiers are trying to invade."
[cpg cn=true]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_ma"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************






I hurriedly gathered all four of us together and discussed it.
[cpg]


In the end, the land of the elves is going to lead an army to invade the land of the demon king. What I feared is going to happen.
[cpg]

[free time=800]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye110"]
[OnName num="schartye"]
There is nothing to worry about. There is no need to worry, the difference in strength is clear.
[cpg cn=true]


Chartier said there was no need to worry, but I had a lot to think about.
[cpg]


Will the land of the elves lose? Will the land of the Demon King lose?
[cpg]


Either way, it could mean that soldiers would die for me.
[cpg]


Whether it's the soldiers of the Demon King's country or the soldiers of the Elf country, neither of them will be safe.
[cpg]


Is that really the right thing to do? ......
[cpg]


[OnName num="kousuke"]
Fia ...... What do you think?
[cpg cn=true]

[free time=800]
[WAIT time=1]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Fia161"]
[OnName num="fia"]
I'm also looking for a dialogue with the Elf Nation,......, but it's difficult.
[cpg cn=true]


After all, we have been bickering for years. However, I couldn't just surrender.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Clolowlude214"]
[OnName num="clolowlude"]
Don't worry," he said. My army is quite large, and I have weapons.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Schartye111"]
[OnName num="schartye"]
In the first place, the straw and the Kullulu wolrd alone are quite a force to be reckoned with. You can't lose.
[cpg cn=true]


It's a good idea to have a good idea of what you're doing.
[cpg]

[free time=800]
[WAIT time=1]
[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile194"]
[OnName num="meile"]
"You look pale. I think you need to calm down.
[cpg cn=true]


[OnName num="kousuke"]
"...... Oh."
[cpg cn=true]


*IseSel06_3|
*eve_15_2|A Journey Around the World


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





Morning is coming. My anxiety continued to flow underneath.
[cpg]


Not just anxiety, but outright fear.
[cpg]


People are going to die because of me. Even if they are subhuman, it's the same thing.
[cpg]


[FG f="CHA04_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude215"]
[OnName num="clolowlude"]
"Are you scared?"
[cpg cn=true]


At that time, Kullulu was visiting my room, and I was asking him about it.
[cpg]


[OnName num="kousuke"]
I'm not saying I'm scared, I'm just saying that I'm not ...... willing to die for my life anymore.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clolowlude216"]
[OnName num="clolowlude"]
It's not your life alone anymore. If I lose you, the Demon Lord's kingdom will collapse."
[cpg cn=true]


That's a good argument. You're right. ......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clolowlude217"]
[OnName num="clolowlude"]
Then all of us subhumans will be persecuted even more than before.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clolowlude218"]
[OnName num="clolowlude"]
It's not just that. Not only that, but those of us who are complicit with the Demon Lord may be killed.
[cpg cn=true]


It's not that I haven't thought about that possibility.
[cpg]


It's not only Kullulu , but also Fia , which is originally an elf.
[cpg]


I'm not going to go back. Even though I knew it, I was scared, as Kullulu said. ......
[cpg]

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************





So I tried to learn a new magic.
[cpg]


There was no other way. I would create a magic that would save me from fighting.
[cpg]


I don't know if there is such a thing, but I have to find out.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia162"]
[OnName num="fia"]
If there were such a thing as ...... convenient, I feel like I wouldn't have any trouble. ......
[cpg cn=true]


[OnName num="kousuke"]
Don't say that. ...... It's depressing.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Fia163"]
[OnName num="fia"]
I'm sorry.
[cpg cn=true]

[free time=800]

[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Clolowlude219"]
[OnName num="clolowlude"]
I know how you feel, Fia . Why don't you just fight like a normal person?
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye112"]
[OnName num="schartye"]
Totally.
[cpg cn=true]


Fia did not seem to agree. I'm a resident of the land of the elves.
[cpg]


Anyway, these three are skilled in magic. We'll just have to find out from them.
[cpg]


The castle had just been built and there was no room for books.
[cpg]


So, I had to ask them steadily. I went to every wizard in the castle.
[cpg]



[free time=1000]

;//ブラックアウト

[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************



[OnName num="therianthropy_A"]
Are there any beastmen who can use magic ......?　I'm sure they do.
[cpg cn=true]


[OnName num="therianthropy_B"]
But there's no such thing as magic that doesn't involve fighting. ......
[cpg cn=true]


[OnName num="therianthropy_C"]
"Oh. I've heard of this kind of magic.
[cpg cn=true]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夕方）******************************************************





So I finally found it. I've heard of this kind of magic.
[cpg]


It was a magic that a normal subhuman could not handle, but as a Demon Lord, I might be able to use it.
[cpg]


It seems to be a way to further enhance my original power of attracting subhumans .......
[cpg]


[OnName num="kousuke"]
"What do you think? Fia"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Fia164"]
[OnName num="fia"]
I think it might have been a blind spot. I think it's a good idea.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye113"]
[OnName num="schartye"]
"I don't agree with it. It's a coward's idea.
[cpg cn=true]


Ignore what Chartier says for the moment and move on.
[cpg]


In the event that you've got a lot more than one of these, you'll be able to find a lot more.
[cpg]


If you are a woman, you must be fascinated by the magical element of the demon king. As Fia does, so does ......
[cpg]


[OnName num="kousuke"]
"Are there any women in the elven army?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Clolowlude220"]
[OnName num="clolowlude"]
I'm sure there are. I think about half of them are women.
[cpg cn=true]


In the elven race, it seems that women are the most skilled magicians .......
[cpg]


This is why there are women on the front lines, and in fact the generals are women.
[cpg]

[STOPBGM]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





Once I had decided that, my actions were swift.
[cpg]


Rather, I couldn't help but hurry. The war was about to start.
[cpg]


Preventing it from happening depended entirely on my magic.
[cpg]


In the first place, even if you call yourself a demon king, it does not mean that you have become a demon king in your heart.
[cpg]


I've been living my life as an ordinary businessman, if not a good ...... man.
[cpg]


I can't stand the thought of people dying to protect my orders or my life.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************





I stayed up all night for a night or two to design and complete the ...... magic circle.
[cpg]


[OnName num="kousuke"]
I think ...... it's done.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia165"]
[OnName num="fia"]
"What do you think, ......?　Is it going to work?
[cpg cn=true]


[OnName num="kousuke"]
We can't use it here. I don't know what the side effects will be.
[cpg cn=true]


Besides, we can't afford to attract more sub-humans to this country than we already have.
[cpg]


[OnName num="kousuke"]
We've got one shot at this. They've already declared war on us, so we'd better hurry."
[cpg cn=true]


As we were discussing this, Meir came strolling in.
[cpg]

[free time=800]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile195"]
[OnName num="meile"]
What's wrong?　 Kosuke , you look like you haven't slept well.
[cpg cn=true]


He said, "What's wrong? Meir doesn't know anything, it's so easy ......
[cpg]


I guess he doesn't think that his life is at stake.
[cpg]


[OnName num="kousuke"]
I can't do this. We have to sneak into elf country."
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Meile196"]
[OnName num="meile"]
"Uh-huh. What's the plan?
[cpg cn=true]


[OnName num="kousuke"]
...... Fia , explain it to him.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





The mission was immediately put into action.
[cpg]


I enlisted the help of the Harpies. It's a good idea to have a good idea of what you're looking for.
[cpg]


They said it would be no problem at all to carry me alone.
[cpg]


In the first place, when I returned to Japan, I was carried by the Harpies.
[cpg]


[OnName num="kousuke"]
"Then, will you carry ...... for me?"
[cpg cn=true]

[OnName num="harpy_A"]
"Yes. You look tired, Mr. Kosuke ."
[cpg cn=true]


[OnName num="kousuke"]
Yeah, well, I'm tired of .......
[cpg cn=true]


I was so exhausted that I fell asleep while the harpies carried me.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************





I was tired and fell asleep while the harpies carried me.
[cpg]


It took quite a while, but after a long time, I landed in the land of the elves.
[cpg]


[OnName num="suspicious_man"]
"We've been waiting for you, sir.
[cpg cn=true]


In the land of the elves, there was a suspicious man I had met in an airship.
[cpg]


[OnName num="kousuke"]
"......, what were you after all?"
[cpg cn=true]


[OnName num="suspicious_man"]
Chartier I'm sort of your henchman, sir.
[cpg cn=true]


[OnName num="kousuke"]
You've been in elf country all this time?　Scouting?
[cpg cn=true]


[OnName num="suspicious_man"]
That's about right. Come on, let's go.
[cpg cn=true]


I'm sure he has his own difficulties.
[cpg]


Chartier It's a good idea to have a good idea of what you're looking for.
[cpg]


It's a good idea to have a good idea of what you're looking for.
[cpg]


If that's the case, I knew I couldn't fail in this mission.
[cpg]

;//qwe

;//上下に黒帯を入れてください
[STOPBGM]
[BGM f="bg_si"]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]



I disguised myself as a member of the military in the land of the elves and snuck in.
[cpg]


I had asked the man in question to get me some armor that looked like that.
[cpg]


I hadn't thought about that at all. To be honest, it was a great help to have it prepared.
[cpg]


If this plan goes well, at least the female elves won't be able to attack me.
[cpg]


If half of the army is boned, it will be difficult to invade.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
He was accompanied by Fia and several harpies.
[cpg]


Ostensibly, Fia had come to negotiate a deal that would prevent a fight.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia166"]
[OnName num="fia"]
"Good luck with ......, Mr. Kosuke ."
[cpg cn=true]


[OnName num="kousuke"]
"Ah. Good luck Fia with your escape."
[cpg cn=true]


In the meantime, I decided to head to the elf army's headquarters and use my charm magic.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]

[WAIT time=100]
[BG f="b_02_2_l.ui" time=1000]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************




I really needed to get to a place where there were a lot of soldiers.
[cpg]


For that, maybe the quarters would be better than the training grounds or something. And it was night.
[cpg]


I deployed my magic. I'm not perfect, I'm just trying to get some idea of where they are.
[cpg]


I'm not perfect, but I'm doing my best to avoid a fight.
[cpg]


[OnName num="elf_soldier"]
"What's ......?　You're new?"
[cpg cn=true]


[OnName num="kousuke"]
Yes, yes!　I'm looking forward to your guidance!
[cpg cn=true]


[OnName num="elf_soldier"]
"......?"
[cpg cn=true]


I could see that he was looking at me suspiciously. But he did not pursue me too deeply.
[cpg]


I was nervous, but I tried not to say anything unnecessary.
[cpg]


[OnName num="harpy_A"]
...... With this armor, it's hard to tell if it's a hand or a feather.
[cpg cn=true]


The harpy girl was also wearing the armor of the elves. This way, even if you can't fly, you can still accompany me.
[cpg]


This means that if the need arises, we can escape together.
[cpg]


[OnName num="kousuke"]
When the spell is activated, there will probably be people chasing me.
[cpg cn=true]


[OnName num="kousuke"]
If I have to run, you'll be there.
[cpg cn=true]


[OnName num="harpy_A"]
You can count on me. I'll protect you, Kosuke ."
[cpg cn=true]


That's good. In the meantime, I had arrived at the center of the dormitory.
[cpg]




I had to draw a magic circle. It wasn't going to take more than a second.
[cpg]


If Chartier or Kullulu were here, they would be able to knock me out if one or two people spotted me. ......
[cpg]


But there's no point in thinking about that now. I hurriedly drew the magic circle in blood.
[cpg]


The size of the magic circle was not that big. However, it seems that my blood is flowing with magical power.
[cpg]


Even though it was a small magic circle, its effect should be far-reaching.
[cpg]



[SE f="se014"]
;//【ＳＥ】『地鳴りのような音』



A powerful magic is activated. The earth starts to rumble. ......
[cpg]


This is definitely going to get noticed. But I don't care if they notice me now.
[cpg]


[STOPBGM]
[BGM f="bg_tc"]



[OnName num="elf_soldier"]
"What the hell are you doing?　What are you doing?
[cpg cn=true]


[OnName num="harpy_A"]
Kosuke What the hell are you doing?
[cpg cn=true]


The magic is already activated. All that's left is to escape.
[cpg]


[OnName num="kousuke"]
Let's go!
[cpg cn=true]


[window target=false]

[transition target={true} rule="108.jpg" color={0x000000ff} time=1]
[WAIT time=1]
[free time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="108.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『街＿エルフの国』（夜）******************************************************

[window target=true]


[SE f="se009"]
;//【ＳＥ】『走る』


[OnName num="elf_soldier_A"]
He's gone!　That way!
[cpg cn=true]


[OnName num="elf_soldier_B"]
Damn it, what did the Witch Queen do to deserve this?
[cpg cn=true]


[OnName num="elf_soldier_A"]
I don't know!　We've got to get him now!
[cpg cn=true]


We're going to run for our lives. If we get caught, it's really over.
[cpg]


But with a few harpies on our side, it was almost a given that we could escape.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1500]
;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】『羽ばたく』
[BG f="b_11_4.ui" time=1000]

[WAIT time=1500]

[BGM f="bg_si"]
;//【ＢＧ】『空』（夜）******************************************************



I was carried by a harpy who took off her armor and left the land of the elves, and now I'm on the sea.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="kousuke"]
Fia !　You're all right, aren't you?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia167"]
[OnName num="fia"]
Yes, I did. You're safe too, Kosuke ?
[cpg cn=true]


[OnName num="kousuke"]
Yeah. I think the magic worked, but I can't ...... be sure.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sFia022"]
[OnName num="fia"]
Maybe it's working. Even though the magic had just been activated, my heart was still pounding.
[cpg cn=true]


I see. It seems to work, since it does so in a short time.
[cpg]


It is still too early to be relieved. Even though I knew that, I still went to ......
[cpg]


I had a sense of accomplishment for the time being. I felt like I had fulfilled my role as a demon king and that I was on my way to a peaceful resolution.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





Exhausted, I slept soundly that night. It wasn't until noon that I woke up.
[cpg]


The good news was immediate. The good news was that half of the elven army was no longer able to attack the Demon Lord.
[cpg]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile197"]
[OnName num="meile"]
"Some of them would rather join the Demon Lord's kingdom. It seems that the elven army can no longer advance.
[cpg cn=true]


[OnName num="kousuke"]
"Oh, I see. ...... Huh."
[cpg cn=true]


I took a breath. I'm sure you'll be happy to hear that.
[cpg]


Meir looked like he deserved this, but he was pretty close.
[cpg]


I was even more relieved now because I thought it was 50-50 whether it would work or not.
[cpg]



[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1500]
[STOPBGM]
;//ブラックアウト


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_05_3_l.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城下町＿魔王の国』（夕方）******************************************************



That evening, I showed up at the castle, still tired.
[cpg]



[BGM f="bg_mi"]



[OnName num="therianthropy_A"]
Welcome back, Demon Lord!
[cpg cn=true]


[OnName num="therianthropy_B"]
Your mission was a great success!　That's great!
[cpg cn=true]


[OnName num="kousuke"]
No, no, no. ...... There's no need to make such a fuss. ......
[cpg cn=true]


[OnName num="therianthropy_A"]
"Let's have a feast today, everyone is happy that it didn't turn into a war.
[cpg cn=true]


[OnName num="kousuke"]
"So ...... there's nothing to be too happy about."
[cpg cn=true]


But I was relieved inside.
[cpg]


Everyone wanted to avoid a fight. That's a good thing.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************





The whole country was celebrating. There are even people who want to make it an annual holiday.
[cpg]


Everyone is happy and sad about what I do. Well, if I die, this country will be turned upside down. ......
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Fia168"]
[OnName num="fia"]
...... Good for you, Kosuke ."
[cpg cn=true]


[OnName num="kousuke"]
"Well, yeah. My life depends on it."
[cpg cn=true]


The party was going to last all night. ......
[cpg]


[STOPBGM]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I was still tired and went back to my room.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye114"]
[OnName num="schartye"]
I was still tired and went back to my room. You're gutless."
[cpg cn=true]


[OnName num="kousuke"]
"...... Chartier . Don't come into my room without permission.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye115"]
[OnName num="schartye"]
That's good. If it weren't for me, you'd have been assassinated by now.
[cpg cn=true]


[OnName num="kousuke"]
But the fact is, I drove the Elves away all by myself.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye116"]
[OnName num="schartye"]
That's why you're in a celebratory mood. I don't understand, it's not like you won the battle.
[cpg cn=true]


...... Chartier is hateful.
[cpg]


But Chartier is supposed to be fascinated by me all the time.
[cpg]


But he wasn't as aggressive as the rest of them. Maybe there's something he's holding back.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye117"]
[OnName num="schartye"]
"Look. There was so much alcohol left over from the celebration. Maybe subhumans have a weakness for alcohol.
[cpg cn=true]


[OnName num="kousuke"]
What about you?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Schartye118"]
[OnName num="schartye"]
I'm strong. Shall we play?
[cpg cn=true]


I'm not that strong, and I'm tired.
[cpg]


[OnName num="kousuke"]
Let's just drink to this victory.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye119"]
[OnName num="schartye"]
So it's not a victory. ......
[cpg cn=true]



[SE f="se00"]
;//【ＳＥ】『乾杯』





From there, the two of us drank together for a while.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye120"]
[OnName num="schartye"]
"......, Demon Lord. What do you think of me?
[cpg cn=true]


[OnName num="kousuke"]
"What do you mean, ...... I'm grateful."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye121"]
[OnName num="schartye"]
"I see. Is that all?
[cpg cn=true]


I wonder if Chartier is really a strong drinker. Or is this pretending to be drunk?
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Schartye122"]
[OnName num="schartye"]
It's not just that I'm grateful to you, Demon Lord. I'm feeling something else."
[cpg cn=true]


She sounded as if she was expecting something.
[cpg]


She's also confused by the pheromones. ......
[cpg]


I was unsure what to do, but I decided.
[cpg]





;//■選択肢
[switch]
[case "I'm too tired to do anything."]
	[swap]
	[jump target="*IseSel07_1"]
[case "Respond to the feelings of Chartier"]
	[swap]
	[jump target="*IseSel07_2"]
[endswitch]



1. I'm too tired to say anything.
2. Respond to Chartier 's feelings



;//==============================
;//１、疲れているので何も言わない
*IseSel07_1|A Journey Around the World


[OnName num="kousuke"]
......"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sSchartye018"]
[OnName num="schartye"]
"Hmm. You've said all this and gotten nothing back."
[cpg cn=true]


He smiled a little ruefully at Chartier . After that, he said.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="sSchartye019"]
[OnName num="schartye"]
You are free to choose not to accept my invitation here, too. After all, you are the Demon Lord.
[cpg cn=true]


And then he said nothing more.
[cpg]


It's a good idea to have a good idea of what you're looking for.
[cpg]



;//ヒロイン３は攻略対象でなくなる
[if exp={getFlagValue("Cha3flg") == 1 }]
[stflag Cha3flg=-1]
[endif]

;//■分岐

[jump target="*IseSel07_3"]

;//==============================
;//２、シャルティエの気持ちに応える

*IseSel07_2|A Journey Around the World



[OnName num="kousuke"]
"I'm grateful to Chartier . If it weren't for Chartier , I'd be long dead."
[cpg cn=true]


Chartier looked happy. I guess he was thinking about me all the time, even though he always seemed so cruel.
[cpg]


You'll be able to see that, and nod your head.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="sSchartye020"]
[OnName num="schartye"]
"I can't believe ...... the Demon Lord is doing this to me."
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. You've been waiting for this.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye150"]
[OnName num="schartye"]
"Of course you are. I'm sure the other girls will too.
[cpg cn=true]


...... You're right. I have a lot of people I need to love.
[cpg]


It's all because of the pheromones that attract subhumans.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

;//Ｈシーンカット


;//ブラックアウト


;//ヒロイン３は攻略対象のまま
;//■分岐

;//==============================

*IseSel07_3|A Journey Around the World

;//ブラックアウト
[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]




Then. The fact that the Demon Lord had defeated the soldiers of the Elf Nation became known all over the world.
[cpg]


It's not just Japan, but the whole world is coming after me, the Demon Lord.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Meile198"]
[OnName num="meile"]
What should I do?　 Kosuke ......"
[cpg cn=true]


[OnName num="kousuke"]
"What do you want me to do? The whole world is my enemy.
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia169"]
[OnName num="fia"]
There's a movement in the world to create a coalition army. They want Kosuke to be sealed off at all costs. ......
[cpg cn=true]


I was faced with a further decision. They're all connected, country by country, and they're all against me.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia170"]
[OnName num="fia"]
I need to do something to let them know that the Demon Lord is not dangerous. ......
[cpg cn=true]


Fia tries to make things go smoothly. But...
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude221"]
[OnName num="clolowlude"]
But?　I think you can conquer the world with the power of the demon king.
[cpg cn=true]


Kullulu says. I'm confused again.
[cpg]


[free time=800]

Do I want peace or do I want world domination?
[cpg]


I think it probably depends on what I've done so far.
[cpg]


To what extent am I awakening as a demon king?
[cpg]


I think it also means how many subhuman girls I've accepted ......'s advances.
[cpg]


How many thought-provoking replies have I given?
[cpg]


As I thought about this, I had one thing on my mind.
[cpg]


;//※攻略ヒロインがどれだけ居るか　によって分岐
;//※全てのヒロインを攻略対象にしている場合、魔王として覚醒　世界を征服するルートへ分岐
;//※そうで無い場合、魔王として覚醒していない　平和を望むルートへ分岐



[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*root_heiwa"]
[endif]


[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*root_heiwa"]
[endif]


[if exp={getFlagValue("Cha4flg") == 0 }]
[jump target="*root_heiwa"]
[endif]

[jump target="*root_mao"]

;//qwe

;//[jump target="*root_heiwa"]

;//==============================
;//攻略対象になっていないヒロインが居る場合


*root_heiwa|A Journey Around the World


[OnName num="kousuke"]
...... I'd like to get things done in peace.
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude222"]
[OnName num="clolowlude"]
I knew you would say that. You're an idiot, Demon Lord.
[cpg cn=true]


[OnName num="kousuke"]
Say what you want.
[cpg cn=true]


All I wanted was to find peace.
[cpg]


My desire was to seek peace. I was told that if I came into contact with too many subhumans, I would awaken as a Demon Lord. ......
[cpg]


Now, I wasn't so much tempted as I was uncontrolled.
[cpg]


I knew that I did not want to kill people.
[cpg]


It's not that I can't handle the fact that I've become a demon king, but I didn't think about expanding my power from this country to other countries.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





I didn't want to kill anyone and gather wisdom to make it all work out.
[cpg]


Fia and Meir seemed to be taking it seriously, but ......
[cpg]


The Chartier and Kullulu wurds seemed to be trying to tell me that I wasn't fighting hard enough.
[cpg]


Sleepless nights. I went to visit a woman.
[cpg]


I went to ......
[cpg]


;//＠
;//※ここまでの選択肢で攻略対象になっているヒロインのみ選択肢に出てくる
;//※ヒロイン１は必ず選択肢に残る
;//※ヒロイン１しか残っていない場合、選択肢は発生せずヒロイン１ルートへ

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*GoRoot_1"]
[endif]

;//10?0?
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*GoRoot_01"]
[endif]

;//1000?


;//10000	フィアのみなのでフィアルート
[jump storage="ep002.ks" target="*start"]


;//1010?
*GoRoot_01


;//1010
;//■選択肢
[switch]
[case "Fia"]
	[swap]
	[jump storage="ep002.ks" target="*start"]
[case "Chartier"]
	[swap]
	[jump storage="ep004.ks" target="*start"]
[endswitch]



;//11?0?
*GoRoot_1
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*GoRoot_11"]
[endif]


;//1100
;//■選択肢
[switch]
[case "Fia"]
	[swap]
	[jump storage="ep002.ks" target="*start"]
[case "Meir"]
	[swap]
	[jump storage="ep003.ks" target="*start"]
[endswitch]



;//1110?
*GoRoot_11


;//11100
;//■選択肢
[switch]
[case "Fia"]
	[swap]
	[jump storage="ep002.ks" target="*start"]
[case "Meir"]
	[swap]
	[jump storage="ep003.ks" target="*start"]
[case "Chartier"]
	[swap]
	[jump storage="ep004.ks" target="*start"]
[endswitch]



One. Fia
Two. Meir
Three. Chartier



;//==============================

;//全てのヒロインが攻略対象になっている場合
;//asd
*root_mao|The Demon King



All I ever wanted was to conquer the world.
[cpg]


I guess I'm awakening as a Demon Lord now that I've been in contact with so many subhumans.
[cpg]


I wondered what steps I could take to conquer the world.
[cpg]


It may be something I can do on my own.
[cpg]


Still, I wanted to ask for someone's help. I didn't feel comfortable going it alone.
[cpg]


To tell the truth, it was also a journey to find my subhuman wife.
[cpg]


It would be good to choose one person as a partner.
[cpg]


[STOPBGM]


[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[free time=1]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]




It was night. I had no more doubts about plotting world domination or choosing one person to be my partner.
[cpg]


There is only one person I love. It's ......
[cpg]



;//※全てのヒロインが攻略対象になっているため、必ず全ての選択肢がある


;//■選択肢
[switch]
[case "Fia"]
	[swap]
	[jump storage="ep005.ks" target="*start"]
[case "Meir"]
	[swap]
	[jump storage="ep006.ks" target="*start"]
[case "Chartier"]
	[swap]
	[jump storage="ep007.ks" target="*start"]
[case "Kullulu urud"]
	[swap]
	[jump storage="ep008.ks" target="*start"]
[endswitch]


One. Fia
Two. Meir
Three. Chartier
4, Kullulu urud



