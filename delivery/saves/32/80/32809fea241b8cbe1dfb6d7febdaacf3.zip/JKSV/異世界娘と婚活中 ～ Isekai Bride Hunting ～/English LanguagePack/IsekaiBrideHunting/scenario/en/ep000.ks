*start

*ep000|Prologue

[SCENE id=0]

[OnName num=""]
;//異世界娘発情中　シナリオ
;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり

;//フィア　　　　　着衣
;//メイル　　　　　着衣
;//シャルティエ　　着衣
;//クロロウルード　着衣

;//上記以外のキャラクターには音声がありません

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//フィア　　　　　一人称「わたくし」　メイル呼び「メイルさん」　シャルティエ呼び「シャルティエさん」
;//　　　　　　　　クロロウルード呼び「クロロウルードさん」　康介呼び「康介さん」
;//メイル　　　　　一人称「あたし」　フィア呼び「フィア」　シャルティエ呼び「シャルティエ」
;//　　　　　　　　クロロウルード呼び「クロロ」　康介呼び「康介」
;//シャルティエ　　一人称「わらわ」　フィア呼び「フィア」　メイル呼び「メイル」
;//　　　　　　　　クロロウルード呼び「クロロウルード」　康介呼び「魔王様」　ルートによって「康介」
;//クロロウルード　一人称「わたし」　フィア呼び「フィア」　メイル呼び「メイル」
;//　　　　　　　　シャルティエ呼び「シャルティエ」　康介呼び「康介」→「魔王様」
;//康介　　　　　　一人称「俺」　フィア呼び「フィア」　メイル呼び「メイル」　シャルティエ呼び「シャルティエ」
;//　　　　　　　　クロロウルード呼び「クロロ」

;//以下、残したＣＧを列挙いたします
;//フィア　　　　　ev_31 ev_20 ev_32 ev_51 ev_52 ev_54
;//メイル　　　　　ev_01 ev_33 ev_34 ev_03 ev_56
;//シャルティエ　　ev_14 ev_39 ev_42 ev_63 ev_64
;//クロロウルード　ev_07 ev_18 ev_66 ev_70

;//うち、ev_31は物語冒頭に移動しています

;//////////////////////////////////////
;///////////////以下本編///////////////
;//////////////////////////////////////


[BG f="black.ui" time=1000]
[WAIT time=100]
[BGM f="bg_d3"]
;//ブラックアウト




;//デバッグ用魔方陣確認
;//[cpg]
;//■選択肢
;//[switch]
;//[case "このまま最初から"]
;//	[swap]
;//	[jump target="*konomama"]
;//[case "平和フィア"]
;//	[swap]
;//	[jump storage="ep002.ks" target="*effect"]
;//[case "平和メイル"]
;//	[swap]
;//	[jump storage="ep003.ks" target="*effect"]
;//[case "平和シャルティエ"]
;//	[swap]
;//	[jump storage="ep004.ks" target="*effect"]
;//[endswitch]
;//
;//*konomama|プロローグ




I was on my way home from work. I looked at the street trees and suddenly thought.
[cpg]

;//[jump target="*asd"]

Plants are living things, too, right?
[cpg]


It's the same with all living things. They crossbreed and leave behind the next generation.
[cpg]


They exist in various places, in various forms, scattered all over the place.
[cpg]


It is the fate of living things to increase in number, entrusting their potential to new life.
[cpg]


If that's the case, then I'm out of line with that fate.
[cpg]



[BG f="b_03_3.ui" time=2000]
[WAIT time=2000]
;//【ＢＧ】『街＿現代』（夕方）******************************************************





My impatience grew. There was also the mere fear that I would be alone for the rest of my life.
[cpg]


But I'm ready to put those thoughts to rest. This Golden Week, I'm going to find the love of my life.
[cpg]


I, Kosuke Hazama (Kousuke Hazama), was about to take the first step.
[cpg]


[OnName num="kousuke"]
I was about to take my first step. "......Come on, it's almost ......."
[cpg cn=true]


It was the end of the work day just before the start of the big holidays. The holidays at my workplace were quite long.
[cpg]


Of course, I wouldn't be going home for this vacation. Instead, I'll be able to make my parents happy with the results.
[cpg]


I was thinking of going on a trip during this holiday.
[cpg]


A trip is a trip to meet people. I was also planning to marry a cute subhuman: ......
[cpg]




;//ブラックアウト
;//回想ですのでセピア調にしてください
[STOPBGM]
[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff}  time=1000]
[WAIT time=1100]
[WAIT time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="163.jpg" color={0x000000ff} time=1]
[WAIT time=1000]



[BG f="b_02_5.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************





It was a few decades ago now.
[cpg]


This earth has been fused with another world.
[cpg]


New continents have appeared all over the world, and sub-humans have come to live in this world.
[cpg]


The sub-humans do not know why they came to this world.
[cpg]


There has been a lot of research done, but nothing is certain.
[cpg]


The land of the elves is in the Pacific Ocean, and the land of the beastmen is in the East China Sea. ...... Islands and continents have appeared everywhere.
[cpg]



;//ブラックアウト


[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_10_5.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************





In the beginning, there were many conflicts, but over the years, the sub-humans made peace with each other.
[cpg]


To begin with, Earth had overwhelming science and technology, and the sub-humans also had terrifying magic in their hands.
[cpg]


The world would collapse if there was a proper war.
[cpg]


That's why they went down the path of reconciliation.
[cpg]



;//回想終わり　色調を戻してください



;//ブラックアウト

[window target=false]
[transition target={true} rule="163.jpg" color={0x000000ff}  time=1000]
[WAIT time=1100]
[WAIT time=1]

[STOPBGM]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="163.jpg" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_03_3.ui" time=1500]
[WAIT time=1500]
[window target=true]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夕方）******************************************************




[OnName num="elf_woman"]
"Japan is so convenient, isn't it? Science is more like magic.
[cpg cn=true]


[OnName num="office_worker"]
I guess so. It's easy to live in Japan, isn't it?
[cpg cn=true]


[OnName num="elf_woman"]
Yes!　I'm so happy to have met you.
[cpg cn=true]


Today, I saw a couple of subhuman and human on the street.
[cpg]


This is not called an international marriage. It's commonly called inter-world marriage or inter-species marriage.
[cpg]


If that's the case, international marriage should be called interracial marriage, but it's still called that.
[cpg]


That being the case, there are many cases of cross-world marriages where the couple met overseas.
[cpg]


That's true. It's hard to believe that a single subhuman would come to Japan without being married to anyone.
[cpg]


On the contrary, if you see a subhuman in this country, there is a high possibility that he or she is married or in love with someone.
[cpg]


Even though Japan is peaceful, it's still very noisy these days, and when you're a subhuman, you're bound to stand out.
[cpg]


I've always dreamed of having a cute subhuman wife. ......
[cpg]


In the first place, it's difficult to get married to one of the few subhumans in Japan.
[cpg]


[STOPBGM]
[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=2000]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夕方）******************************************************





But it's almost Golden Week.
[cpg]


I was going to head to the other world continent no matter who stopped me.
[cpg]


I was going to the most popular spot, the land of the elves. ......
[cpg]


[OnName num="kousuke"]
The problem is ...... money, isn't it ......?"
[cpg cn=true]


I've been working diligently. I'm not sure why I can't save money, but I'm not sure why I can't save money.
[cpg]


Where did I spend so much money ......?　I can't think of anything.
[cpg]


I know that my sloppy nature is keeping me from getting married.
[cpg]


That's why I have to take the plunge. But....
[cpg]


[OnName num="kousuke"]
"Ummm... ......"
[cpg cn=true]


Facing my phone, I looked up the government's plans for sightseeing trips.
[cpg]


No matter how many times I checked, the prices did not go down, in fact, they became more expensive as they were booked up.
[cpg]


It seems like the world doesn't want me to get married.
[cpg]


I guess I have no choice then!　I can't help it. I'm just impatient.
[cpg]


I was both looking forward to the trip and feeling like I wouldn't be able to go in the first place.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=10]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1100]

[BG f="b_03_1.ui" time=1500]
[WAIT time=2000]


[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（朝）******************************************************

;//＠
[SE f="se011"]
;//【ＳＥ】『人混み』


Time flies when you're commuting to work and getting things done.
[cpg]


I'll be old before I know it. I'm not kidding.
[cpg]




[window target=false]

[BG f="b_03_3.ui" time=2000]
[WAIT time=2000]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街＿現代』（夕方）******************************************************

[window target=true]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』


If I'm still single this year, I'll probably be single next year and ten years from now. It's easy to imagine.
[cpg]


Even so, I was troubled by the amount of money I had to spend on travel plans that made me want to give up.
[cpg]


As I walked, I stared at the screen of my phone. The prices kept going up and up.
[cpg]



[SE f="se001"]
;//【ＳＥ】『ぶつかる』

[STOPBGM]


[WAIT time=500]


[OnName num="kousuke"]
"Ouch. ......"
[cpg cn=true]


Because I was doing that, I wasn't looking ahead properly.
[cpg]


I dropped my phone and hurriedly picked it up. The screen showed a travel plan.
[cpg]

[BG f="b_03_4_up_l.ui" time=1000]
[WAIT time=1000]
;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]
[WAIT time=1000]

[BGM f="bg_si"]

[OnName num="suspicious_man"]
...... Are you planning a trip to the land of the elves, mister?
[cpg cn=true]


The man who said this to me in a suspicious tone was also suspicious looking.
[cpg]


I think he might be a subhuman. He wore a robe and a mask to hide his face, which was a mismatch.
[cpg]


As I was thinking this, an even more suspicious woman appeared from behind me.
[cpg]



;//シャルティエの立ち絵表示
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1500]


I wondered if she was a vampire. She seemed to be a vampire.
[cpg]



;//シャルティエの名前をしばらく「謎の女性」と隠してください
;//かなり長い間名前が判明しませんが、指定があるまで表示しないでください



[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye001"]
[OnName num="mysterious_woman"]
There is an airship that will take you to the land of the elves at a discounted price. What do you think?
[cpg cn=true]


[OnName num="kousuke"]
"What? ...... What's with the suddenness?"
[cpg cn=true]


I picked up my phone and tried to walk away.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye002"]
[OnName num="mysterious_woman"]
Just ask me how much. Hey."
[cpg cn=true]


[OnName num="suspicious_man"]
Hey. I'm not carrying you alone this time, you know.
[cpg cn=true]


The man flicked his abacus. What is an abacus nowadays? ......
[cpg]


But it's not like I can't read the numbers on an abacus. So I thought.
[cpg]


[OnName num="kousuke"]
"Is it really this cheap ......?"
[cpg cn=true]


I was presented with a price that made me think that this was a domestic trip.
[cpg]


[OnName num="kousuke"]
"Is there a return flight?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye003"]
[OnName num="mysterious_woman"]
"Don't be a pussy. I'm sure you're single because of that.
[cpg cn=true]


[OnName num="kousuke"]
......
[cpg cn=true]


I was almost angry, but I don't know how he knew I was single.
[cpg]


I don't know if I'm that dull looking.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye004"]
[OnName num="mysterious_woman"]
Anyway, I'll just tell them when and where the amphibian will be leaving.
[cpg cn=true]


The mysterious woman handed me a note and smiled wryly.
[cpg]

 
[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye005"]
[OnName num="mysterious_woman"]
I'll look forward to seeing you again.
[cpg cn=true]

[move from="2/3" to="5/3" ease="easeInOutSine" time=2000]
[WAIT time=2200]

[free]

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]
[BG f="b_03_3.ui" time=1000]
[WAIT time=1000]


Then the duo disappeared back into the crowd.
[cpg]


[OnName num="kousuke"]
...... What the hell?"
[cpg cn=true]


But if she's someone who makes money from travel, ......
[cpg]


How is it possible that the person I bumped into by accident was planning a trip?
[cpg]


Maybe this is not a coincidence.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=10]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1100]

[BG f="b_04_4.ui" time=1000]
[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋＿現代』（夜）******************************************************


[window target=true]



[OnName num="kousuke"]
Maybe it's not a port or ...... airport.
[cpg cn=true]


In the note handed to me, the location of the airship was written in beautiful letters.
[cpg]


...... Oh, by the way, I had also spotted that you were single, but maybe ......
[cpg]


Was he using magic or something to survey people who wanted to go on the trip?
[cpg]


Suppose it wasn't.
[cpg]


[OnName num="kousuke"]
"Have you seen that man ...... anywhere?"
[cpg cn=true]


The woman looked familiar to me. If you ask me where I saw her, I can't answer.
[cpg]


That's what makes me think of a past life or something plain crazy like that.
[cpg]


In any case, I couldn't let this chance go to waste.
[cpg]


If I can't catch the return flight, I'll probably be fired from my job, but I'll take that risk and go.
[cpg]



[BG f="black.ui" time=2000]
[WAIT time=2000]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//ブラックアウト





So, the port at night.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=10]
[STOPBGM]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1100]

[BG f="b_11_4.ui" time=1000]
[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『空』（夜）******************************************************

[window target=true]




[OnName num="kousuke"]
"Wow, ......, that really is an amphibian.
[cpg cn=true]


I don't know what kind of power it uses, but it looks like something that someone from the past would have thought of.
[cpg]


I don't know what kind of power it uses, but it looks like an old-fashioned airship, floating on the sea, and it looks like a sailing ship.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye006"]
[OnName num="mysterious_woman"]
"There you are. I knew you'd come."
[cpg cn=true]


[OnName num="kousuke"]
"...... is this thing really going to fly?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye007"]
[OnName num="mysterious_woman"]
It will fly. Did you bring the money?
[cpg cn=true]


[OnName num="kousuke"]
Oh, yeah, I brought cash, just in case.
[cpg cn=true]


I pulled the money out of my wallet and the woman took it without checking the amount.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye008"]
[OnName num="mysterious_woman"]
I'm sure I got it. Now, come on inside."
[cpg cn=true]


[free time=800]

When I entered the amphibian, I found that it was full of passengers who were ...... too suspicious to be considered.
[cpg]


Half of them were subhuman. The other half are human, but some of them look extremely frightened, while others have already reopened their eyes and are imposing themselves. ......
[cpg]


Am I allowed to be on this ship ......?
[cpg]


[OnName num="suspicious_man"]
So that's all of them, right?　Let's go to Chartier Hey."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye009"]
[OnName num="mysterious_woman"]
Yeah. Take the helm.
[cpg cn=true]



[free time=800]


[SE f="se005"]
;//【ＳＥ】『魔法発動する　シンセパッド系の音』





[OnName num="kousuke"]
Whoa!
[cpg cn=true]


Didn't we just shake?　We're already floating?
[cpg]


But I was the only one who raised my voice. I wondered what the rest of them had in their guts.
[cpg]


I can't help it now that I'm on board. No matter where we arrived, I couldn't escape, and even if we didn't get anywhere, I couldn't escape.
[cpg]




[BG f="b_11_4.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


;//＠空背景


I had never been on an overseas trip before.
[cpg]


This would be my first trip abroad, but it would also be my first trip to another world.
[cpg]


The other passengers didn't say a word. So I don't say anything either.
[cpg]


She and the suspicious man, who called me " Chartier ", are apparently in another part of the airship.
[cpg]


I can't even talk to them to find out what it is.
[cpg]


I think I was on the airship for a few hours, but the experience was much longer.
[cpg]




[BG f="b_02_5.ui" time=1500]
[WAIT time=2000]

[WAIT time=100]
;//[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（夜）******************************************************





The land of the elves. As the name suggests, elves literally make up most of the population there.
[cpg]


They are a race skilled in magic and do not rely much on science and technology.
[cpg]


I've only heard rumors, but I've also heard that there are no power plants there.
[cpg]


Of course, they would need to generate some electricity for the tourists, but ......
[cpg]


It seems that this is also covered by magic. It's hard to believe, but I wonder if it's true.
[cpg]


That's what we're about to find out: ......
[cpg]



[window target=false]
[transition target={true} rule="39.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[transition target={false} rule="39.png" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_02_1.ui" time=1500]
[WAIT time=2000]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（朝）******************************************************


[window target=true]



[OnName num="kousuke"]
"Are you here ......?"
[cpg cn=true]


I went outside. The sun was shining brightly.
[cpg]


The other passengers were getting out of the airship without saying a word.
[cpg]

[STOPBGM]

Some of them didn't get off. So, that means ......
[cpg]


[BGM f="bg_tc"]


[OnName num="kousuke"]
"Wait, wait, wait!"
[cpg cn=true]



[SE f="se005"]
;//【ＳＥ】『魔法発動する　シンセパッド系の音』





The amphibian is about to fly again. This is not the end of the line.
[cpg]


We're going to get left behind. And that amphibian is probably not going to come back here.
[cpg]


The amphibian is slowly rising to the surface. You can find a lot more information on this topic at ......
[cpg]


[OnName num="kousuke"]
......
[cpg cn=true]


Maybe, no, definitely illegal entry. And it's a strange land.
[cpg]


I've had a pretty rough time of it, haven't I ......?
[cpg]



;//ブラックアウト
[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1500]

[BG f="b_02_2.ui" time=1000]
[WAIT time=1100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************



[window target=true]


What happens to a human being when he or she is trapped beyond control?
[cpg]


In my case, it was the kind of courage that doesn't usually come out. I'm sure that's the case for most people.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="kousuke"]
"Hey!　Do you understand what I'm saying?
[cpg cn=true]


I've heard that the elves and those skilled in magic can use automatic translation magic.
[cpg]


Then you can understand what I'm saying, can't you?
[cpg]



;//フィアの名前を「エルフの女性」と隠してください





[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia001"]
[OnName num="elf_woman"]
"Yes. Is it ......?"
[cpg cn=true]


[OnName num="kousuke"]
"Where am I in ...... the land of the elves, is that correct?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia002"]
[OnName num="elf_woman"]
Yes, it's a bit far from the central city of ...... Elf Country, but...
[cpg cn=true]


Is this still far from the city? It looks like a pretty good town.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia003"]
[OnName num="elf_woman"]
Are you here for sightseeing?　You look like a human.
[cpg cn=true]


[OnName num="kousuke"]
Yeah, I'm from Japan. I'm from Japan.
[cpg cn=true]



;//ここから、フィアの名前を隠さないでください





[FACE method="change_2" pos="2/3"]
[VOICE f="Fia004"]
[OnName num="fia"]
You're from Japan? Nice to meet you. My name is Fia ."
[cpg cn=true]


He politely told me his name. I said my name back.
[cpg]


[OnName num="kousuke"]
"I'm Kosuke and ....... How do I get back to Japan from here?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia005"]
[OnName num="fia"]
Well, ...... it's quite far away, but if you head to the airport, there are flights there.
[cpg cn=true]


Airport. That might be a bad idea.
[cpg]


After all, I'm in the country illegally. I'm supposed to be in Japan right now, so I'm pretty sure I'll be caught. ......
[cpg]


No, is that okay?　If I can force them to let me go back to Japan.
[cpg]


[OnName num="kousuke"]
No, it's not good. ......"
[cpg cn=true]


I mumble to myself. The best thing to do would be to go back to Japan again without anyone finding me.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia006"]
[OnName num="fia"]
What's wrong with you?　You have a difficult look on your face.
[cpg cn=true]


[OnName num="kousuke"]
No, no, it's ...... nothing. Then I'm sorry for keeping you.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Fia007"]
[OnName num="fia"]
...... Oh, um... Wait a minute.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia008"]
[OnName num="fia"]
If you are in trouble, I can help you. My house is just around the corner. ......"
[cpg cn=true]


......?　What's this all about?　What kind of country invites a foreigner to its home?
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia009"]
[OnName num="fia"]
If you like, why don't you take a break and go? You must be tired from your long journey.
[cpg cn=true]


I was indeed tired. I walked suspiciously to Fia 's house.
[cpg]



;//ブラックアウト


[window target=false]
[transition target={true} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[BG f="black.ui" time=10]
[free time=10]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_08_2.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】『森の中の集落＿エルフの国』（昼）******************************************************



[window target=true]


I headed to a forest-like area a little outside the city. But there was a path.
[cpg]


I walked along it and came to a little open village.
[cpg]


There were several houses lined up ......, and one of them seemed to be the house of Fia .
[cpg]



;//室内であるため、上下に黒帯を入れてください

;//[BG f="black.ui" time=1000]
;//[BG f="b_08_2_l.ui" time=1000]
;//[WAIT time=1000]

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]
[WAIT time=1000]
[BG f="b_08_2_up_l.ui" time=1000]
[WAIT time=1000]



I was invited into the house. The room was neat and tidy.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Fia010"]
[OnName num="fia"]
He said, "It's a mess, but please have a seat if you want.
[cpg cn=true]

[free time=800]

So I sat down on a chair.
[cpg]


So I sat down on a chair. I thought to myself.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia011"]
[OnName num="fia"]
"......"
[cpg cn=true]


Fia is sitting on the chair facing me, staring at me.
[cpg]


[OnName num="kousuke"]
"Is there something on my face?"
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Fia012"]
[OnName num="fia"]
"No, nothing. No, nothing."
[cpg cn=true]


Then he averts his gaze.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia013"]
[OnName num="fia"]
I'm sorry about ....... I'm sorry for inviting you here so suddenly.
[cpg cn=true]


I could see that Fia was getting weirder and weirder.
[cpg]


I don't know why this is happening to me. I don't know why this is happening, but if I were a very handsome man, it would be possible, but I'm not.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia014"]
[OnName num="fia"]
"Have you and I met at ...... somewhere?"
[cpg cn=true]


[OnName num="kousuke"]
No, I don't remember .......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia015"]
[OnName num="fia"]
I have a feeling that ...... you helped me a long time ago.
[cpg cn=true]


A long time ago. The old me has never been abroad. It's impossible, I thought, as I sipped the tea that was offered to me.
[cpg]


[OnName num="kousuke"]
But I have to admit, it was nice of you to let me come home. ...... I was thirsty.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia016"]
[OnName num="fia"]
I was thirsty." "I see. I'm glad to hear that.
[cpg cn=true]


[OnName num="kousuke"]
But I don't know what to do. ...... I should tell you everything.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
So, I decided to tell him everything.
[cpg]

[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]


I decided to tell them everything: that I had been smuggled into the country and that I had been left behind. That's the big two.
[cpg]


I didn't dare mention that I was here to find my destiny.
[cpg]


[BG f="b_08_2_up_l.ui" time=1000]
[WAIT time=1000]

[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia017"]
[OnName num="fia"]
I'm sure you'll be happy to hear that.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia018"]
[OnName num="fia"]
I think the only way to get help is to talk to the Elf Nation or the Japanese government and ask them for help.
[cpg cn=true]


[OnName num="kousuke"]
That's the only way. ......
[cpg cn=true]


I wonder what the crime of smuggling is. I'm sure they'll take more than the cost of a stingy trip.
[cpg]


Oh," he said, holding his head. I can't believe this is happening.
[cpg]


[OnName num="kousuke"]
I don't know what to do, but I guess I'll just have to do it. ...... Huh.
[cpg cn=true]


The battery in my cell phone had run out before I knew it. This means I can't contact anyone.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia019"]
[OnName num="fia"]
It's not that urgent. Why don't you stay at my house for a while?
[cpg cn=true]


[OnName num="kousuke"]
Are you sure?　Are the elves so open-minded?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia020"]
[OnName num="fia"]
I don't think so either. ...... But that ......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia021"]
[OnName num="fia"]
Please take this as pure good will.
[cpg cn=true]


...... Do you think so? I think there's something behind it.
[cpg]




[window target=false]
[WAIT time=1000]
[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=1000]
;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]

[BG f="b_08_4_up_l.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落＿エルフの国』（夜）******************************************************





However, if they could let me stay, I was grateful for that.
[cpg]


If it were to rain, I would not be able to stay in the field.
[cpg]


So I was asked to stay at Fia 's house for the night. ......
[cpg]


Fia even served me dinner, and I was just touched by their kindness.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia022"]
[OnName num="fia"]
I was just touched by their kindness. I hope it's to your taste.
[cpg cn=true]


[OnName num="kousuke"]
"Why are you doing this to me?"
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
I asked a similar question again. I asked a similar question again, only this time Fia looked embarrassed.
[cpg]


This is a great way to get the most out of your time and money.
[cpg]

;//qwe

;//ブラックアウト

[window target=false]
[transition target={true} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[STOPBGM]

[BG f="black.ui" time=1]
[free time=1]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_02_1.ui" time=1000]

[WAIT time=1100]
[WAIT time=100]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（朝）******************************************************

[window target=true]



The next morning. I think about what I should do.
[cpg]


There was a part of me that wished I could see that amphibian again, somewhere ......
[cpg]


I wanted to go back to Japan without anyone knowing, so that I could pretend that everything had never happened.
[cpg]


[OnName num="kousuke"]
But then again, it's a strange place. ......
[cpg cn=true]


I walked around the city, away from Fia . It was interesting simply as sightseeing.
[cpg]


There were no electrical appliances or machinery. It's like medieval Europe.
[cpg]


If you're asking me if I've ever seen anything like it, I'd say no. ......
[cpg]


But then again, there's really nothing modern about it.
[cpg]


Perhaps near the airport or in the tourist areas, but apparently not in other places.
[cpg]




[BG f="b_02_2.ui" time=2000]
[WAIT time=2500]

;//[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************





Time passed in vain. I was getting hungry and looked at the money in my hand.
[cpg]


I can't use Japanese currency. I might be able to exchange money somewhere, but ......
[cpg]


Still, Fia had given me some money for lunch.
[cpg]


I returned the money to Fia , which was probably enough to pay for my lunch, but it was in Japanese currency.
[cpg]


I really can't thank her enough for that.
[cpg]


[OnName num="kousuke"]
I'm hungry, .......
[cpg cn=true]


I walked into some random restaurant. This is the kind of thing where if you're not brazen about it, you'll look suspicious.
[cpg]



[free time=800]
;//[BG f="black.ui" time=1000]
[BG f="b_02_2_l.ui" time=1000]
[WAIT time=100]
;//ブラックアウト

;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く


When I look at this city, I think that magic must have developed more than science.
[cpg]


I can hear the conversation in the store. They were talking about how they had seen a doctor at the hospital the other day.
[cpg]


The hospital uses magic to heal injuries and illnesses,.......
[cpg]


And the most amazing thing is that I can even hear what they are saying.
[cpg]


My ears would still be the same, so any human could hear what they were saying.
[cpg]


There must be some kind of translation magic going on all the time. There must be a lot of tourists here.
[cpg]


It's amazing, then.
[cpg]


Or maybe the whole country is under such magic?　I wonder if it's the same in other countries, such as the Land of the Beasts. ......
[cpg]


[WAIT time=1500]
[window target=false]


[BG f="b_02_3.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『街＿エルフの国』（夕方）******************************************************


[window target=true]



And it's evening again. Just walking around the city is interesting, but that's not the purpose of the trip.
[cpg]


More importantly, I don't know if I can achieve the purpose of the trip.
[cpg]


I doubt if I will ever be able to return to Japan, let alone get a cute suburban wife.
[cpg]


In the meantime, I'm getting hungry again. I have no choice but to go back to the house of Fia .
[cpg]


I decided to go back to the village where she lived.
[cpg]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』


[window target=false]
[transition target={true} rule="101.jpg" color={0x000000ff} time=2000]
[WAIT time=2100]
[STOPBGM]
[WAIT time=1]
[BG f="black.ui" time=10]
[WAIT time=10]
[transition target={false} rule="101.jpg" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_08_4.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『森の中の集落＿エルフの国』（夜）******************************************************

[window target=true]


;//上下に黒帯を入れてください


;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]
[BG f="b_08_4_up_l.ui" time=1000]
[WAIT time=1500]



I remembered the road better than I thought I would. I ended up staying at Fia 's house for the second night.
[cpg]

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
At Fia 's house, we talked about this and that.
[cpg]


[OnName num="kousuke"]
"Does Fia live alone at ......?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia023"]
[OnName num="fia"]
"Yes. Both my mother and father died early.
[cpg cn=true]


[OnName num="kousuke"]
Sorry about ....... I'm sorry. I didn't mean to remind you of that.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia024"]
[OnName num="fia"]
No. It's okay. I can live on my own.
[cpg cn=true]


Fia is still squirming today.
[cpg]


It's as if they have a big reaction to my casual words.
[cpg]


[BG f="black.ui" time=1000]
[free time=1000]
[WAIT time=2000]

[BG f="b_08_4_up_l.ui" time=1000]
[WAIT time=1000]

And after dinner, it was night. Fia is in bed, and I'm sleeping on the floor outside the bedroom.
[cpg]


In the middle of this, I heard a voice from Fia .
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia025"]
[OnName num="fia"]
Do you want to sleep in the bed, ...... Kosuke ?"
[cpg cn=true]


[OnName num="kousuke"]
No, I can't let ...... Fia sleep on the floor.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia026"]
[OnName num="fia"]
There's enough room for the two of us to sleep. How about it?
[cpg cn=true]


You're really being very aggressive. I don't know why this is happening.
[cpg]


Am I really as handsome as the elves think I am?　No way.
[cpg]


It doesn't look like their aesthetic senses are all that different. I'd be reluctant to ......
[cpg]


[OnName num="kousuke"]
I'm sorry to say no to your offer.
[cpg cn=true]


I was hoping that the subhuman wife of my fate might be Fia .
[cpg]


[free time=800]

I cuddled up with Fia , but asleep with my back to ......
[cpg]


I saw Fia turn over in her sleep. It's facing me.
[cpg]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ


[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]

;//========================================
;//●ＣＧ（主人公にのしかかっているヒロイン。顔を赤くしている）ev_31
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：城内＿主人公の部屋
;//時間　：夜
;//備考　：原作から位置が移動しています
;//========================================

*Scene000|Prologue

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]
[WAIT time=1500]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_31_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]



Then I heard a noise, and I felt a weight on my body.
[cpg]


I didn't need to think about it anymore, but it was Fia 's weight.
[cpg]


It took me a while to understand the situation, but I couldn't understand her feeling itself even after a while.
[cpg]

[OnName num="kousuke"]
She said, "...... Fia . How much is that?"
[cpg cn=true]

;**【ＣＧ】 ev_31_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Fia027"]
[OnName num="fia"]
I'm sorry. I just can't help myself. ...... I've never felt like this before in my life.
[cpg cn=true]


No, no, no. It's happening too fast. You've only just met him yesterday.
[cpg]


But it doesn't look like Fia likes men.
[cpg]


So, is there a problem on my end?　Is there some unseen force at work?
[cpg]

[OnName num="kousuke"]
"Are Elves allowed to do this?"
[cpg cn=true]

In my own imagination, elves have an image of being reserved in love.
[cpg]

It may be a prejudice associated with their longevity, but ......
[cpg]


[VOICE f="sFia001"]
[OnName num="fia"]
Yes, ...... if it's true, it's not something humans should be allowed to do.
[cpg cn=true]

But apparently, it wasn't prejudice.
[cpg]

[VOICE f="sFia002"]
[OnName num="fia"]
It's not okay to seduce people in public, even your own kind. ......
[cpg cn=true]

[OnName num="kousuke"]
Are you saying that ...... Fia is not that type of person?
[cpg cn=true]

[VOICE f="Fia011"]
[OnName num="fia"]
"......"
[cpg cn=true]


;**【ＣＧ】 ev_31_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]

Fia fell silent and slumped. His face turned bright red.
[cpg cn=true]

[VOICE f="sFia003"]
[OnName num="fia"]
I'm sorry. I don't know if I can answer any more questions.
[cpg cn=true]

[VOICE f="sFia004"]
[OnName num="fia"]
My head is spinning, I'm going crazy. ......"
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

She comes closer. She leans down and her face, or rather her lips, come closer.
[cpg]

It's not a good idea for anyone to see me covered up like this.
[cpg]

In ...... my defense, I'm not the kind of guy who would do anything to a total stranger.
[cpg]


[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


So in the end, this is like a total loss, but there was a problem.
[cpg]
;//Ｈシーンカット


[OnName num="elf_woman"]
" Fia ......?　Who are you ......?　What are you doing?
[cpg cn=true]


[OnName num="kousuke"]
"...... what?"
[cpg cn=true]




[window target=false]
[transition target={true} rule="encount.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]

[STOPBGM]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="encount.png" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_02_2.ui" time=2000]
[WAIT time=2000]

[BGM f="bg_tc"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************


[window target=true]

;//＠
[SE f="se011"]
;//【ＳＥ】『人混み』

Why? Why is this happening?
[cpg]


[OnName num="elf_man"]
Walk. There's no point in trying to escape.
[cpg cn=true]


You've been seen. There's nothing you can do about it.
[cpg]


I don't know if you're a friend of Fia or a colleague of ...... or even what Fia does for a living in the first place, but... ...
[cpg]


Either way, we were misled. And then the elf men came to get me.
[cpg]


A few men surrounded me and forced me towards the city.
[cpg]


[OnName num="kousuke"]
What are you going to do with me? ......
[cpg cn=true]


[OnName num="elf_man"]
I will be put on trial for my shameful actions. In some cases, you may even be executed.
[cpg cn=true]


Execution. Does that mean the death penalty? Isn't that too harsh?
[cpg]


However, there seems to be a difference in the way of thinking about love and the system of trial. After all, it was a different world until a while ago.
[cpg]


[OnName num="elf_man"]
"Elves don't usually have children with different races. This is a serious crime."
[cpg cn=true]


[OnName num="kousuke"]
Wait, ......, I didn't do anything.
[cpg cn=true]


I wonder where Fia is. Is there any way you can clear your name?
[cpg]


Or is it possible that it was all a trap or something ......?
[cpg]


[OnName num="elf_man"]
"This is the courthouse. Come in."
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


If you go in, there's no way you can escape. That's what I was thinking.
[cpg]



[SE f="se006"]
;//【ＳＥ】『魔法発動する』

[transition target={true} rule="pipo-tr005.png" color={0x000000ff} time=1000]
[WAIT time=1500]
[transition target={false} rule="pipo-tr005.png" color={0x000000ff} time=1000]
[WAIT time=1000]



[OnName num="elf_man"]
"What the hell is ......?
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="5/3" time=800]


It's hard to describe, but it's like a magical restraint. Something that could be called glowing ivy stretched out from under my feet.
[cpg]

[move from="5/3" to="3/3" ease="easeInOutSine" time=1000]

[VOICE f="Fia054"]
[OnName num="fia"]
Kosuke It's a good idea to have a good idea of what you're looking for.
[cpg cn=true]


The elven men stopped moving. Did Fia do that for you?
[cpg]


[OnName num="kousuke"]
" Fia ......."
[cpg cn=true]


[FACE method="change_3" pos="3/3"]
[VOICE f="Fia055"]
[OnName num="fia"]
Don't worry about me, just run!
[cpg cn=true]


[OnName num="elf_man"]
You're covering for this guy?　What are you doing?
[cpg cn=true]


I did as I was told and ran from the side of the men who had stopped moving.
[cpg]

;//＠
[SE f="se009"]
;//【ＳＥ】『走る』

;//ブラックアウト


[window target=false]
[transition target={true} rule="108.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=1]
[free time=1]
[WAIT time=200]
[transition target={false} rule="108.jpg" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_02_3_up_l.ui" time=1500]
[WAIT time=2000]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（夕方）******************************************************


[window target=true]



[OnName num="kousuke"]
"Huh, huh, huh."
[cpg cn=true]


With Fia's help, I narrowly escaped with my life.
[cpg]


You can't stay in the land of the elves anymore. I have to go back to Japan right now. ......
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Schartye010"]
[OnName num="mysterious_woman"]
You've been through a lot, haven't you?
[cpg cn=true]


[OnName num="kousuke"]
You ......!　Well, my name is .......
[cpg cn=true]



;//シャルティエの名前を表示してください





[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye011"]
[OnName num="schartye"]
Oh, I never told you my name. I'm Chartier . I'm a vampire.
[cpg cn=true]


I'm a vampire named Chartier , not lady or whatever they call me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye012"]
[OnName num="schartye"]
You want to get away, don't you?　You want to get in the airship?
[cpg cn=true]


[OnName num="kousuke"]
You're going to let me go?　I mean, how do you know I'm running away?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Schartye013"]
[OnName num="schartye"]
I've been monitoring the whole thing with my teleportation magic. It seems that your qualities are real after all."
[cpg cn=true]


Qualities. I don't know what you're talking about. Still, I'd appreciate it if you'd let me go. ......
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye014"]
[OnName num="schartye"]
"Anyway, in a city like this, we're going to be seen. Let's take a little walk."
[cpg cn=true]


Chartier led me to the outskirts of the city.
[cpg]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[window target=false]
[free time=2000]
[BG f="black.ui" time=2000]
[WAIT time=2500]

[BG f="b_08_3.ui" time=2000]
[WAIT time=2500]
;//【ＢＧ】『森の中の集落＿エルフの国』（夕方）******************************************************

[window target=true]




[OnName num="suspicious_man"]
"Sorry to hear that, mister.
[cpg cn=true]


The man was there with me. Who the hell are these two?
[cpg]


They said they were vampires, but I couldn't understand why they were helping me so much.
[cpg]


There were also a number of suspicious passengers on the airship. ......
[cpg]


What was different from the last time was that there were many sub-humans instead of humans. I also saw some elves.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye015"]
[OnName num="schartye"]
Now we're going to the land of the beastmen.
[cpg cn=true]


[OnName num="kousuke"]
Wait a minute!　I want to go back to Japan.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye016"]
[OnName num="schartye"]
That's not going to happen. I've already decided where I'm going.
[cpg cn=true]


I'm grateful to have escaped the land of the elves, but I still want to go back to Japan.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Schartye017"]
[OnName num="schartye"]
I'm sure you'll be glad to get out of elf country, but I still want to go back to Japan. I want to revive the Demon Lord. I want you to play a role in that."
[cpg cn=true]


[OnName num="kousuke"]
"Resurrection of the Demon Lord: ......?"
[cpg cn=true]


What does that mean? Am I to be sacrificed?
[cpg]


I'm sure you'll be able to figure out the best way to get the most out of this.
[cpg]

;//＠
[SE f="se008"]
;//【ＳＥ】『歩き』

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[SE f="se005"]
;//【ＳＥ】『魔法発動する　シンセパッド系の音』

[WAIT time=2000]


[BG f="b_11_3.ui" time=1000]
[WAIT time=2000]

The airship is on its way. The next destination was said to be the land of the beastmen.
[cpg]


I only know the name of it. I know that beastmen live there, but I can't imagine what kind of culture it is.
[cpg]


The passengers still didn't say anything.
[cpg]


I'm still worried. I don't know if I'll be safe on land this time.
[cpg]


Again, Chartier and the suspicious man were not in the same room. ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=1]
[STOPBGM]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=2000]

[BG f="b_10_3.ui" time=1500]
[WAIT time=2000]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夕方）******************************************************


[window target=true]



Then we arrived at a village.
[cpg]


[OnName num="kousuke"]
"...... This is the Land of the Beasts."
[cpg cn=true]


I know it's located in the East China Sea. I know it's located in the East China Sea, pretty close to Japan.
[cpg]


I know it's pretty close to Japan, and I feel like I could cross the sea by boat or something, but ......
[cpg]


The land of the beastmen was a more primitive place than the land of the elves.
[cpg]


There is no mechanical technology and probably no magic, so it is not a good place for tourism.
[cpg]


I wonder if it's governed properly as a nation. ......
[cpg]


But I have no choice but to ask the beastmen for help. Otherwise, I'd have to ask for help from the beastmen, or get a ride on one of Chartier 's airships. ......
[cpg]


[STOPBGM]

[SE f="se005"]
;//【ＳＥ】『魔法発動する　シンセパッド系の音』

[WAIT time=2000]


But then the airship was about to take off.
[cpg]


[OnName num="kousuke"]
"Hey, wait a minute!"
[cpg cn=true]


I couldn't hear him. What does Chartier want me to do?
[cpg]



;//ブラックアウト

[STOPBGM]

[window target=false]

[BG f="b_10_4.ui" time=2000]
[WAIT time=2500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（夜）******************************************************


[window target=true]



I was wondering if I should talk to someone or if I would get hurt again.
[cpg]


[OnName num="kousuke"]
I'm hungry. ......
[cpg cn=true]


I don't think I've eaten a proper meal today. I think I'm going to starve to death.
[cpg]


I can see the lights from my house. I knocked on the door with all my might.
[cpg]

[BG f="b_10_4_up_l.ui" time=1000]

[WAIT time=1000]

;//＠
[SE f="se003"]
;//【ＳＥ】ドアノック

[WAIT time=2500]


;//＠
[SE f="se002"]
;//【ＳＥ】ドア開く

[WAIT time=1000]


[OnName num="therianthropy_woman"]
I knocked on the door. "Um, ......, who are you?"
[cpg cn=true]


A beastly woman who could have been an old man came out. She had cat ears, and I could tell just by looking at her that she was a subhuman.
[cpg]


[OnName num="kousuke"]
I'm from Japan, but I'm lost or ...... stranded."
[cpg cn=true]


I explained the whole situation. Then the woman said.
[cpg]


[OnName num="therianthropy_woman"]
I explained the whole situation. If that's the case, please come up.
[cpg cn=true]


She said. I was almost moved to tears by the warmth of the people.
[cpg]



;//[free time=800]
[BG f="black.ui" time=1000]
[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1500]
[BG f="b_10_4_up_l.ui" time=1000]
[WAIT time=1500]

;//ブラックアウト





The house seemed to be occupied by a couple.
[cpg]


I couldn't find anyone who looked like their son or daughter.
[cpg]


[OnName num="therianthropy_man"]
"Actually, our daughter is suffering from a ...... strange disease, or rather a curse.
[cpg cn=true]


[OnName num="kousuke"]
"A curse?"
[cpg cn=true]


I was told that a girl named Meir was still sleeping in this house.
[cpg]


Time has stopped for Meir , and she is still young.
[cpg]


[OnName num="therianthropy_woman"]
She was cursed with the ...... curse after entering the forest alone, where no one is allowed to enter.
[cpg cn=true]


They don't know what the curse is, or who did what.
[cpg]


The girl, Meir , and the beastman couple are said to be unmistakably daughters, although they appear to be quite a few years apart.
[cpg]


As I watched them tearfully talk about what had happened, I could not help myself.
[cpg]



[window target=false]

[WAIT time=1]
[transition target={true} rule="162.png" color={0x000000ff} time=1]
[WAIT time=1]
[WAIT time=1000]
[STOPBGM]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="162.png" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（朝）******************************************************


[window target=true]



In the morning, I decided to walk around the village of the beasts.
[cpg]


I thought to myself, "I need to find a way to get back to Japan .......
[cpg]


;//＠
[SE f="se009"]
;//【ＳＥ】『走る』

[WAIT time=1000]


[OnName num="therianthropy_youth"]
"Hey, there!　Where are you from?
[cpg cn=true]


[OnName num="kousuke"]
"I'm from Japan, what's wrong?"
[cpg cn=true]


[OnName num="therianthropy_youth"]
"What magic ......!　Have you been practicing magic somewhere?
[cpg cn=true]


That's a strange thing to say. You think I have magic?
[cpg]


[OnName num="therianthropy_youth"]
I can't be like this. There's a girl in this village named Meir who has a curse that can't be broken.
[cpg cn=true]


[OnName num="kousuke"]
I know her. Her parents let me stay with them.
[cpg cn=true]


[OnName num="therianthropy_youth"]
That's easy for you to say!　You might be able to lift the curse!
[cpg cn=true]


What's with the suddenness? That's absurd, isn't it?
[cpg]


[OnName num="kousuke"]
Wait a minute. What are you?
[cpg cn=true]


[OnName num="therianthropy_youth"]
I'm a magician, as you can see. ...... It's rare for a beastman, but that's not important right now.
[cpg cn=true]


[OnName num="therianthropy_youth"]
Anyway, you have a tremendous amount of magic in you.
[cpg cn=true]


[OnName num="kousuke"]
"......"
[cpg cn=true]


I wonder if that's why Fia was attracted to me. It's a great way to make sure you're getting the most out of your money.
[cpg]


If that's the case, maybe I should listen to what he has to say to see what I can do.
[cpg]



;//ブラックアウト

[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=1000]

[BG f="b_10_2_up_l.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************

[window target=true]


;//上下に黒帯を入れてください

;//[CUTIN f="ci_lbox.ui" show={true} method="slidein"]

[WAIT time=1500]


Then I went back to the old couple's house again.
[cpg]


I cut the tips of my fingers and drew a simple magic circle as the young man told me to do.
[cpg]


Even though it is a simple magic circle, I'm not sure if it works as a magic circle. ......
[cpg]


In the beginning, I wondered what a magic circle was, but then I made a mark with blood.
[cpg]


[OnName num="therianthropy_youth"]
"Follow my lead and cast the spell, okay?"
[cpg cn=true]


[OnName num="kousuke"]
Oh, oh."
[cpg cn=true]


The young man chanted some words that were hard to remember, or rather, some spells, and I followed him.
[cpg]


The old couple is looking at me nervously. I don't want to betray their expectations.
[cpg]


As I recited the incantation that the young man was chanting, ......
[cpg]


;//画面徐々に白く

;//＠
[SE f="se006"]
;//【ＳＥ】魔法（できれば回復系）

[transition target={true} rule="amamori3.webp" color={0xffffffff} time=1000]
[WAIT time=2000]


[STOPBGM]

As the young man recited the incantation, Meir 's body and chest began to glow.
[cpg]


I continued to chant, wondering if I was going to be okay.
[cpg]



[WAIT time=1000]


;//画面元に戻る
[transition target={false} rule="amamori3.webp" color={0xffffffff} time=1000]
[WAIT time=1500]

;//【ＢＧ】『村＿獣人の国』（昼）******************************************************



And when the ...... light subsided.
[cpg]

[BGM f="bg_d1"]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Meile001"]
[OnName num="meile"]
"......Hmm ......, is that your mother?　Your father is also ......."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Meile002"]
[OnName num="meile"]
"You both suddenly look so old ...... and your hair is all white."
[cpg cn=true]


[OnName num="meile_mother"]
"Oh, Meir !　That's good, that's good."
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[FACE method="change_5" pos="2/3"]
The mother hugged Meir . The father was also in tears.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//[CUTIN f="ci_lbox.ui" show={false} method="slideout"]



It took a while for the girl, Meir , to understand the situation.
[cpg]


It took a while for the girl, , to understand what was going on, but her parents think that I helped her.
[cpg]


I didn't do anything, I think it was the young man who did something. ......
[cpg]


Still, I was worshipped like a god by the parents of Meir .
[cpg]

[window target=false]

[STOPBGM]
[WAIT time=1500]


[BG f="b_10_2.ui" time=1000]
[WAIT time=1000]


[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『村＿獣人の国』（昼）******************************************************


[window target=true]


[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Meile003"]
[OnName num="meile"]
"Your brother ...... saved you. Thank you, you saved my life."
[cpg cn=true]


The girl Meir herself also thanked me. It's kind of awkward.
[cpg]


[jump storage="ep001.ks" target="*start"]

;=========================================================================================


