
;//麻里ルート
*root2|

;//*test|

*start


;#################################################
*Ep005|The Spirit of Revenge
;#################################################

[SCENE id=5]





[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]

From then on, I was surprisingly calm, even to myself.
[cpg]

If Hayashida had not taken the bait, there might have been another way, but now that I had come this far, all I could think about was getting revenge on him.
[cpg]

;//麻里のマンション　部屋の前
[free time=1000]
[BG f="b_09_2.ui" time=1000]
[WAIT time=1000]

The apartment where Hayashida lived was a few minutes away from my house by train.
[cpg]

The auto-locked entrance was nothing more than an unsecured automatic door, and once I followed the occupants in, I was able to easily get to the front of the apartment.
[cpg]

[OnName num="keisuke"]
「………………」
[cpg cn=true]



I put my cap on deeply. I can't help but get a warrior's shiver.
[cpg]



If I can get revenge on that woman, I don't care what happens to the rest of my life.
[cpg]

Today, I sent a direct message to Hayashida.
[cpg]

I used a dumped e-mail address and pretended to be Brajo.
[cpg]


Can I come over now?
[cpg cn=true]



While I was composing the text, using hiragana for all the words, I burst out laughing.
[cpg]

I felt like an idiot....
[cpg]

But Hayashida jumped on it without a doubt and sent me a quick reply saying he would be waiting for me at home.
[cpg]

[SE f="se003"]
;//【ＳＥ】インターフォン（ピンポーン）

[VOICE f="Mari263"]
[OnName num="mari"]
Yes, yes, yes!"
[cpg cn=true]



Soon a familiar voice responded, and I whispered, conscious of my cap.
[cpg]

[OnName num="keisuke"]
Hello, Mari. Hajimemashite."
[cpg cn=true]



I hear footsteps clattering from inside the room, approaching the front door.
[cpg]

[SE f="se001"]
;//【ＳＥ】鍵を開け、ドアが開く

[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Mari264"]
[OnName num="mari"]
'Nice to meet you ...... eh?'
[cpg cn=true]



[SE f="se023"]
;//【ＳＥ】ドドドド（雪崩れ込む）

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

As soon as the door opened to reveal Hayashida's dumb face, I shoved him as hard as I could into the room.
[cpg]

[BG f="b_07_2.ui" time=1000]
[WAIT time=1000]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Mari265"]
[OnName num="mari"]
What the hell?　What the hell?
[cpg cn=true]



Startled and confused, Hayashida slumped to the floor and fell on his butt in the hallway.
[cpg]



[FACE method="change_5" pos="2/3"]

[OnName num="keisuke"]
I don't think Brajo would come to you, ......."
[cpg cn=true]



Hayashida's eyes widened as he took off his hat and revealed his face.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Mari213"]
[OnName num="mari"]
Oh, you ......."
[cpg cn=true]



Apparently, he remembered his face, but his mouth was still agape and no words came out.
[cpg]

[OnName num="keisuke"]
Say my name.
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Mari214"]
[OnName num="mari"]
Hey, your name is ............."
[cpg cn=true]



[OnName num="keisuke"]
Don't tell me you don't remember ......?
[cpg cn=true]



Or maybe you didn't know it all along: ......
[cpg]

Either way, it anointed me with anger.
[cpg]

[OnName num="keisuke"]
"You've been namecalling me rotten to no end!"
[cpg cn=true]



[SE f="se023"]
;//【ＳＥ】蹴り

[FACE method="change_3" pos="2/3"]
[VOICE f="sMari016"]
[OnName num="mari"]
What the hell!　What the hell are you doing?　You think you can get away with this?
[cpg cn=true]



[OnName num="keisuke"]
Aaaaah!
[cpg cn=true]



[FACE method="change_4" pos="2/3"]
[VOICE f="Mari216"]
[OnName num="mari"]
Hyah!
[cpg cn=true]



[SE f="se020"]
;//【ＳＥ】叩き付ける

[free time=1000]

I grabbed Hayashida by the hair and slammed his head into the floor.
[cpg]

[OnName num="keisuke"]
You've ruined my life!　I don't care what happens to you!"
[cpg cn=true]



I was surprised at how loud my voice was.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Mari217"]
[OnName num="mari"]
Help me, I'm sorry!　I'm really, really sorry!
[cpg cn=true]



I'm so sorry!" The apology was incredibly flimsy.
[cpg]

I wouldn't have come all this way if I thought that was enough to get me to back down.
[cpg]

[OnName num="keisuke"]
I've been watching your video feed every day.
[cpg cn=true]



[FACE method="change_5" pos="2/3"]
[VOICE f="Mari266"]
[OnName num="mari"]
You're the one who talked about Brajo!　Then, you can't be serious, Kei...?
[cpg cn=true]



[OnName num="keisuke"]
"Oh yeah, that's me. It's me, Keisuke Oshida!
[cpg cn=true]



I was the one who was going to get him.
[cpg]

[OnName num="keisuke"]
I'm going to upload your video on the Internet just like you did to me!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Mari218"]
[OnName num="mari"]
No, stop it!　Get off me, you pervert!
[cpg cn=true]



[OnName num="keisuke"]
Who's the pervert?
[cpg cn=true]



[OnName num="keisuke"]
What the ...... is weak at all? Without your cronies, you're nothing like this. ......
[cpg cn=true]



I looked down at Hayashida and felt a strange feeling.
[cpg]

The most important thing to remember is that you can't be afraid to take advantage of the best of the best.
[cpg]

What had I been afraid of all this time?
[cpg]

[OnName num="keisuke"]
I'm going to give you plenty in return, so get ready for it.
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Mari219"]
[OnName num="mari"]
No, don't... don't... don't!
[cpg cn=true]



[FACE method="change_4" pos="2/3"]
[VOICE f="Mari267"]
[OnName num="mari"]
Stop it!　That's right, I'll give you money!　You can have all the money in my desk drawer!
[cpg cn=true]



[OnName num="keisuke"]
I don't want your money!
[cpg cn=true]



In a fit of anger, I grabbed Hayashida's chest. His face contorted as his fingernails dug in.
[cpg]


[OnName num="keisuke"]
I was so angry that I grabbed Hayashida's chest with my fists. How much money did you make here?　Aah!
[cpg cn=true]



[SE f="se023"]
;//【ＳＥ】蹴る

[FACE method="change_3" pos="2/3"]
[VOICE f="Mari269"]
[OnName num="mari"]
Ow...!　You ......, you ......, you!
[cpg cn=true]

;//＠
[SE f="se023"]
;//【ＳＥ】蹴る
[FACE method="change_3" pos="2/3"]
[WAIT time=1000]

[VOICE f="Mari272"]
[OnName num="mari"]
I told you to stop!　What the fuck do you think you're doing...
[cpg cn=true]



[OnName num="keisuke"]
I don't care what happens.
[cpg cn=true]



I don't care what happens to me." The blood on Hayashida's face suddenly drained from his face as if he finally understood how serious I was.
[cpg]


Hayashida's eyes, which were full of false eyelashes, widened.
[cpg]


;//●ＣＧ（麻里：拘束されているヒロイン。服は着ている）ev_27
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=100]



I leaned on Hayashida from above.
[cpg]

[VOICE f="Mari277"]
[OnName num="mari"]
No, no, no!　Stop it!　Stop it, please!
[cpg cn=true]



He tried to push me back with his restrained hands, but his attacks were completely impenetrable to me.
[cpg]


[VOICE f="sMari019"]
[OnName num="mari"]
I'm sorry, let go of me, let go of me!"
[cpg cn=true]



[OnName num="keisuke"]
I'm sorry?　What kind of apology is that?
[cpg cn=true]


;**【ＣＧ】 ev_27_a ***********************
[CG id=11 index=1 time=100]
;***************************************
[WAIT time=100]


[VOICE f="sMari020"]
[OnName num="mari"]
He says he's really sorry!"
[cpg cn=true]



Well, it doesn't matter how sorry I am.
[cpg]


It makes no difference to me what I'm going to do. Anyway, I'm going to go to ......
[cpg]


[OnName num="keisuke"]
I'll just take a picture of it anyway.
[cpg cn=true]


;**【ＣＧ】 ev_27_0 ***********************
[CG id=11 index=0 time=100]
;***************************************
[WAIT time=100]


[VOICE f="sMari021"]
[OnName num="mari"]
"No, don't ......
[cpg cn=true]




[SE f="se022"]
;//【ＳＥ】シャッター
[BG f="white.ui" time=100]
[WAIT time=100]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=11 index=0 time=100]
;***************************************
[WAIT time=100]

It's even more lenient than what he did to me. The most important thing to remember is that you can't just take a picture of a person and expect them to be happy.
[cpg]


It was fun just to watch him like that.
[cpg]


I don't know what I'm going to do now...
[cpg]



;//移植前シーンカット

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
;//エフェクト

Then I decided to lock myself in Hayashida's room.
[cpg]

His parents were both on business trips and would not be home for a while.
[cpg]

I wonder how many days have passed since then. ......
[cpg]

Hayashida's phone was flooded with messages from his cronies, and I got tired of replying to every one of them with lies, so I decided to let him go to class.
[cpg]

Of course, in doing so, I threatened to immediately spread his identity and photo all over the Internet if he told on me or reported me. ......
[cpg]

Hayashida understood the horror of having that done to him after what happened to me, so he was very quiet at that point.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『麻里の部屋』

[OnName num="keisuke"]
He was already quiet by then, because he understood the horror of what had happened to me.
[cpg cn=true]



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mari318"]
[OnName num="mari"]
"......... understands."
[cpg cn=true]



[OnName num="keisuke"]
Then I'll give you a mission after class."
[cpg cn=true]



I had sent a message from Hayashida's phone during the night to the right person.
[cpg]

It asked me to go on a date with a guy I didn't know, and the guy immediately jumped at the chance.
[cpg]

[OnName num="keisuke"]
'Women are nice. It's an easy job, just date a middle-aged guy and you get a present.
[cpg cn=true]



[FACE method="change_3" pos="2/3"]
[VOICE f="Mari319"]
[OnName num="mari"]
"Oh, you ...... are the worst."
[cpg cn=true]



[OnName num="keisuke"]
"Me?　That's what you've always done, isn't it? I don't care if you don't want to do it.　If you don't want to tell your parents who you really are, that's fine with me.
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Mari320"]
[OnName num="mari"]
Fuck you.
[cpg cn=true]



Thus, I sent Mari out of the room. ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『公園』




In the afternoon, I woke up from a nap and went to Hayashida's workplace at the appointed time.
[cpg]

I was going to capture him working hard on video. This would serve as a deterrent.
[cpg]

;//公園のしげみ

;//移植前シーンカット


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]

[OnName num="middle_aged_man"]
If you don't want this picture to be passed around, I'll ask you again.
[cpg cn=true]

And the guy had another associate film him on a date, apparently.
[cpg]



[VOICE f="Mari358"]
[OnName num="mari"]
Turn it off, turn it off now!
[cpg cn=true]



[OnName num="middle_aged_man"]
No, no, no. It's insurance.
[cpg cn=true]



The guy leaves. I look at Hayashida, who is crying and wiping his face.
[cpg]


[OnName num="keisuke"]
"........."
[cpg cn=true]



[FACE method="change_4" pos="2/3"]
[VOICE f="Mari359"]
[OnName num="mari"]
He takes a picture of me.... If that stuff ...... leaked out, it would be ...... really bad. ...... ugh."
[cpg cn=true]



[SE f="se030"]
;//【ＳＥ】心臓ドックン

[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1000]
;//ホワイトアウト

;//画面ネガポジ反転

[OnName num="keisuke"]
"Oh, ......, ......?"
[cpg cn=true]



[SE f="se030"]
;//【ＳＥ】心臓ドックン

;//啓介のイジメ動画カット表示

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[OnName num="keisuke"]
Ugh......."
[cpg cn=true]



The fear of the image being leaked flashed back so strongly that I couldn't stop my heart from palpitating.
[cpg]

;//画面ネガポジ反転

[SE f="se030"]
;//【ＳＥ】心臓ドックン

[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1000]
;//ホワイトアウト

Embarrassing images......
[cpg]

The sound of ridicule......
[cpg]

The daily life that is breaking down......
[cpg]

Me collapsing......
[cpg]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[OnName num="keisuke"]
'Ugh......'
[cpg cn=true]



Cold sweat won't stop......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=1000]

[FACE method="change_7" pos="2/3"]
[VOICE f="Mari360"]
[OnName num="mari"]
"Eh......"
[cpg cn=true]



Hayashida notices me and gets a quizzical look on his face.
[cpg]

[SE f="se030"]
;//【ＳＥ】動悸激しくなる

[OnName num="keisuke"]
"Oh...oh...... wow!"
[cpg cn=true]



[FACE method="change_5" pos="2/3"]
[VOICE f="Mari361"]
[OnName num="mari"]
What!　What's wrong!
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
I crouched down with my head in my hands, and Hayashida walked up to me with a panicked look on his face.
[cpg]

But I was having a panic attack that I couldn't help myself, and I had no idea what to do.
[cpg]

[OnName num="keisuke"]
Aaaaahhhh!"
[cpg cn=true]



[OnName num="keisuke"]
I'm sorry, I'm sorry, I'll do anything, just don't post it on the Internet!"
[cpg cn=true]



I hear my own voice echoing in my head, ranting without exhaling.
[cpg]

[OnName num="keisuke"]
'I can't live if it's on the internet, that's all I ask, please forgive me!
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Mari362"]
[OnName num="mari"]
'Eh...ah...anta......'
[cpg cn=true]



[OnName num="keisuke"]
I'm sorry, I'm sorry, I'm sorry.
[cpg cn=true]



[FACE method="change_4" pos="2/3"]
[VOICE f="Mari363"]
[OnName num="mari"]
"Oh no,......, there...so broken,......?"
[cpg cn=true]



Hayashida's hand touched his shoulder and he brushed it off as hard as he could.
[cpg]

[SE f="se020"]
;//【ＳＥ】バシッ

[OnName num="keisuke"]
I'm sorry, I'm sorry, I'm sorry, please help me.
[cpg cn=true]



[FACE method="change_5" pos="2/3"]
[VOICE f="Mari364"]
[OnName num="mari"]
I... broke ...... it... it's my fault... ......
[cpg cn=true]



[OnName num="keisuke"]
I'm sorry, I'm sorry, I'm sorry!
[cpg cn=true]


[SE f="se008"]
;//【ＳＥ】嘔吐

Suddenly vomiting. The most important thing to remember is that you should not be afraid to ask for help from your doctor.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Mari365"]
[OnName num="mari"]
"Yup, forgive me, I didn't ...... expect it to be this ...... bad.
[cpg cn=true]



[OnName num="keisuke"]
I'm going to kill you, I'm going to kill you, I'm going to kill you, I'm going to kill you, I'm going to kill you.
[cpg cn=true]



[FACE method="change_4" pos="2/3"]
[VOICE f="Mari366"]
[OnName num="mari"]
I'm sorry......I'm really sorry......!
[cpg cn=true]



Hayashida hugged my head tightly.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mari367"]
[OnName num="mari"]
I never thought... people could be so broken Atashi ...... really do anything!　I'll do anything you say until you get better!
[cpg cn=true]



[OnName num="keisuke"]
"Ugh...hah...hah...ugh..."
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Mari368"]
[OnName num="mari"]
"I swear, ......, I swear ......
[cpg cn=true]



[OnName num="keisuke"]
".................."
[cpg cn=true]



That was the moment ...... Hayashida was converted.
[cpg]


;//ブラックアウト
;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『麻里の部屋』

[SE f="se032"]
;//【ＳＥ】調理

It had probably been ten days since he had broken into Hayashida's room.
[cpg]

The first time I saw him, I thought, "I'm not going to let him get away with that.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se
[WAIT time=500]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mari393"]
[OnName num="mari"]
"Omelette rice ...... is ready."
[cpg cn=true]



[OnName num="keisuke"]
Oh ......."
[cpg cn=true]



Hayashida now prepares the meals that I initially relied on him to deliver to me.
[cpg]

 Surprisingly, it's something I'm used to, and I really think it doesn't taste bad.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Mari394"]
[OnName num="mari"]
"How does that ...... taste?"
[cpg cn=true]



[OnName num="keisuke"]
He said, "It's ......... good. It's delicious.
[cpg cn=true]



[FACE method="change_2" pos="2/3"]
[VOICE f="Mari395"]
[OnName num="mari"]
"Really?　That's good.
[cpg cn=true]



[OnName num="keisuke"]
..................
[cpg cn=true]



As these days went by, I slowly began to accept that Hayashida's apology was sincere.
[cpg]

I could not forgive him for that tragic act, but I had to admit that my anger was shrinking.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Mari396"]
[OnName num="mari"]
I made you some pudding.
[cpg cn=true]



[OnName num="keisuke"]
......... yeah."
[cpg cn=true]



Pudding placed on the table for dessert.
[cpg]

What ...... is this like a boyfriend and girlfriend relationship?
[cpg]

The woman in front of me is a hateful enemy, but why do I eat what was served silently and even think it's delicious?
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Mari397"]
[OnName num="mari"]
The bath is boiling, so you can take it whenever you like.
[cpg cn=true]



Hayashida smiles a little.
[cpg]

His face is always somewhat apologetic, and I can tell he's looking at me.
[cpg]

I felt a small pain in my chest.
[cpg]

When will I ever forgive ...... this guy?
[cpg]

I don't feel at all like I can hold on to my hatred forever.
[cpg]

The first thing that comes to mind is the fact that the two of you are not the only ones who have been through this.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Mari398"]
[OnName num="mari"]
I was so happy to see him.　Are you okay?
[cpg cn=true]



I looked up at his voice and saw a worried-looking Hayashida staring at me, and I felt my face heat up and stood up.
[cpg]

[OnName num="keisuke"]
I'm coming out for a minute. ......
[cpg cn=true]



;//ブラックアウト
;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『公園』




[OnName num="keisuke"]
................"
[cpg cn=true]



Alone, I reflected on what I had just said.
[cpg]

I thought about it. That moment .......
[cpg]

I thought Hayashida was ......... a little bit cute.
[cpg]

I'm an idiot, I'm that ...... Hayashida.
[cpg]

She's vain, stupid, vindictive, arrogant, and has trampled on my life.
[cpg]

And what the hell am I doing?
[cpg]

Every day, day after day, I let her stream my videos and pick up my money. ......
[cpg]

Don't the things Hayashida has done to me and the things I'm doing to Hayashida already cancel each other out?
[cpg]

[OnName num="keisuke"]
'No... that's not the point.
[cpg cn=true]



There's no way to compare and measure suffering that can't be quantified.
[cpg]

I'm broken, but he's not.
[cpg]

I'm broken, but he's not, and there's no way I can make up for it!
[cpg]

I sit on the bench, sigh, and start playing with my phone in a daze.
[cpg]

;//ワクテカ動画

Looking back, the ...... wakteka video is where it all started.
[cpg]

I came here, met my mentor, got a peek into Hayashida's room, and ended up here at .......
[cpg]

If it wasn't for that chance, I might have just rotted away.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『リアンズワールド』


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="3/7" time=800]

[OnName num="keisuke"]
I'm not sure if I'd have made it to ......."
[cpg cn=true]



I look twice involuntarily when I see that Lian's World is now being distributed.
[cpg]

That's strange, ...... I didn't give any instructions.
[cpg]




[VOICE f="sMari022"]
[OnName num="mari"]
'Mi, guys...thanks for coming. What do you want me to do today?"
[cpg cn=true]



[OnName num="keisuke"]
That bitch!
[cpg cn=true]



Blood rushed to my head and I ran out.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_an"]
[WAIT time=100]
;//【ＢＧ】『麻里の部屋』

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[SE f="se020"]
;//【ＳＥ】ドア乱暴に開く

[OnName num="keisuke"]
What are you doing?
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Mari402"]
[OnName num="mari"]
What are you...?
[cpg cn=true]



[OnName num="keisuke"]
I said, "I'm asking you what you're doing!"
[cpg cn=true]



I turned off Hayashida's computer and yanked his arm.
[cpg]

[FACE method="change_4" pos="2/3"]
Hayashida fell to the ground.
[cpg]



[VOICE f="Mari403"]
[OnName num="mari"]
I'm trying to make a little money ...... by doing guerrilla work.
[cpg cn=true]



[OnName num="keisuke"]
Who told you to do that ......!
[cpg cn=true]



He stops dead in his tracks. Why am I so angry...?
[cpg]

I'm not sure what to do about it, but I'm not sure I'm going to be able to do it.
[cpg]

Why do I hate it so much?
[cpg]


;//[free time=1000]
[OnName num="keisuke"]
Son...na ......
[cpg cn=true]



Yeah, I'm ...... no longer wanting to show ...... Hayashida to others. ......?
[cpg]

Why?
[cpg]

It's a lie. ...... I'm beginning to be attracted ...... to this woman, of all people?
[cpg]

I was astonished that my mind had already tolerated Hayashida.
[cpg]

Don't...don't...don't...don't...don't...yadda yadda yadda yadda!
[cpg]

If you allow it, the next thing that will come will be regret!
[cpg]

[OnName num="keisuke"]
Ah... ah... ah!"
[cpg cn=true]



Thoughts rush into my brain like a raging wave.
[cpg]

Do you want to be tormented by regret and self-loathing?
[cpg]



Put aside your infatuation and swelling, if you want to get laid, you have to behave the way you've always behaved!
[cpg]



[OnName num="keisuke"]
............"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Mari404"]
[OnName num="mari"]
What...what ......?"
[cpg cn=true]



I look down at Hayashida, who is starting to seem cute.
[cpg]



If you admit that you have forgiven him, that's where it ends.
[cpg]

[OnName num="keisuke"]
"Aaaaaaah!
[cpg cn=true]



[SE f="se023"]
;//【ＳＥ】押し倒す


[FACE method="change_5" pos="2/3"]
[VOICE f="Mari405"]
[OnName num="mari"]
Kyaaaah!
[cpg cn=true]

;//●ＣＧ（麻里：倒れ込むヒロイン。怯えきっている）ev_34
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=100]


[OnName num="keisuke"]
How much more do you have to make fun of me?
[cpg cn=true]


[VOICE f="sMari023"]
[OnName num="mari"]
I'm not mocking you.
[cpg cn=true]



That's a lie. He's still looking down on me.
[cpg]


It must be all an act to get out. He's trying to trick me.
[cpg]


Then there's nothing to hold back about. I can do whatever I want.
[cpg]


;**【ＣＧ】 ev_34_a ***********************
[CG id=12 index=1 time=100]
;***************************************
[WAIT time=100]

[VOICE f="sMari024"]
[OnName num="mari"]
I want to ......
[cpg cn=true]



I grab her arm. But I can't do anything from there.
[cpg]


[OnName num="keisuke"]
"Oh, oh, oh, oh, oh, oh!"
[cpg cn=true]



I try to scream, but that's all I can do. I can't even hit her.
[cpg]


How weak am I? No. ......
[cpg]


Is it my inner essence that's holding me back from this heinous act of ......?
[cpg]


[OnName num="keisuke"]
"...me, I'm the one who's ......
[cpg cn=true]



[OnName num="keisuke"]
I'm ...... sorry."
[cpg cn=true]



;//移植前シーンカット
;//移植前シーンカット

;//麻里の部屋
[BG f="b_07_2.ui" time=1000]
[WAIT time=1000]

I cried in front of her for a while after that.
[cpg]


Hayashida didn't give up or make fun of me, on the contrary, he patted my head.
[cpg]


Something is broken once again...or maybe broken things are being put back together.
[cpg]


Maybe I have to change now.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

...... and then a little later that night.
[cpg]

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[BGM f="bg_ya"]
;//●ＣＧ（麻里：安らかな表情のヒロイン）ev_47
;**【ＣＧ】 ev_47_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=100]

The first time I saw him, I thought, "I'm not going to be able to do that," and I said to myself, "I'm not going to be able to do that.
[cpg]

[OnName num="keisuke"]
'Ehhh ......!'
[cpg cn=true]



My heart, not my brain, realized the meaning of what I had done.
[cpg]


[VOICE f="Mari444"]
[OnName num="mari"]
'Oshida...kun.......'
[cpg cn=true]



Hayashida's face, which looked at me with a kyoton, was strangely kawaii .......
[cpg]


[VOICE f="Mari445"]
[OnName num="mari"]
I'm not sure if it's a matter of Atashi. I'm not sure if you don't dislike me a little bit more now...?
[cpg cn=true]



[OnName num="keisuke"]
That's ...... not possible.
[cpg cn=true]



It's no good,......, I can't do this anymore,.......
[cpg]

I was convinced of that.
[cpg]

I've already forgiven Hayashida.
[cpg]

[OnName num="keisuke"]
"Well... maybe. ......
[cpg cn=true]



I couldn't look him in the eye, so I turned to the wall and confided in him.
[cpg]

[OnName num="keisuke"]
I understand Hayashida's ...... feelings. I'm going to ...... end it now."
[cpg cn=true]



I knew that if I continued to do the same thing while feeling this way, my spirit would split.
[cpg]

[VOICE f="Mari446"]
[OnName num="mari"]
"Is today the end of ......?"
[cpg cn=true]



[OnName num="keisuke"]
「ああ……」
[cpg cn=true]



Revenge is over, and I'll be alone and lonely in that room again tomorrow.
[cpg]

The most important thing to remember is that you can't be too careful when you are making a purchase.
[cpg]


[VOICE f="Mari447"]
[OnName num="mari"]
"Is that ...... then, that ......?"
[cpg cn=true]



Right beside me, Hayashida was about to say something in a hushed tone.
[cpg]

 Looking back, there is a woman's face that looks embarrassed with her cheeks dyed a little.
[cpg]


[VOICE f="Mari448"]
[OnName num="mari"]
She said, "Hey ......, will you make me your ...... girlfriend?"
[cpg cn=true]



[OnName num="keisuke"]
Eh...?
[cpg cn=true]



I was so surprised that my mind went blank.
[cpg]

[OnName num="keisuke"]
I was so surprised that my mind went blank. "What are you talking ...... about?
[cpg cn=true]



What am I thinking?
[cpg]

The most important thing to remember is that you can't just go out and buy a new car.
[cpg]



[OnName num="keisuke"]
On ...... for real?"
[cpg cn=true]


[VOICE f="Mari451"]
[OnName num="mari"]
Yeah. ......"
[cpg cn=true]



I wonder if Hayashida really likes me, not brainwashing or anything like that.
[cpg]

[OnName num="keisuke"]
But on the contrary, can you forgive me ......?
[cpg cn=true]


[VOICE f="Mari452"]
[OnName num="mari"]
If Oshida-kun forgives me, then ......
[cpg cn=true]


[BG f="black.ui" time=1000]
[WAIT time=1000]

I'm not sure if I'm going to be able to do that, but I'm sure I'm going to be able to do that.
[cpg]



[VOICE f="Mari453"]
[OnName num="mari"]
I was so happy to see her.
[cpg cn=true]



The two of them kissed, and their tongues reached out from between their overlapping lips and entwined with each other.
[cpg]


[OnName num="keisuke"]
I'm glad ...... we're going out," she said.
[cpg cn=true]


;**【ＣＧ】 ev_47_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Mari455"]
[OnName num="mari"]
"I'm glad ...... we're going to start over, ......2 together."
[cpg cn=true]



[OnName num="keisuke"]
"Yeah, let's ...... do that."
[cpg cn=true]



I took out my phone and deleted all of Hayashida's images that I had put up in the cloud.
[cpg]

[VOICE f="Mari456"]
[OnName num="mari"]
I then took out my phone and deleted all the images of Hayashida that I had uploaded to the cloud.　You deleted all of them ......?
[cpg cn=true]



[OnName num="keisuke"]
I said, "Yes, I did. I don't need them anymore.
[cpg cn=true]



I told him with a smile and kissed Hayashida again.
[cpg]


[SE f="se038"]
;//【ＳＥ】麻里のスマホに電話着信




[window target=false]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『麻里の部屋』




At that moment, Hayashida's phone played a lively melody.
[cpg]


[VOICE f="Mari457"]
[OnName num="mari"]
Oh, I'm sorry. ......."
[cpg cn=true]



Hayashida gets up from the bed and takes the call with the phone on the table in his hand.
[cpg]




[VOICE f="Mari458"]
[OnName num="mari"]
Oh, really?　Thank you!"
[cpg cn=true]



The caller seems to be a superior, judging from the honorifics he uses.
[cpg]

The tone of his voice suggests that he's happy about something, and I can't help but smile.
[cpg]


[VOICE f="Mari459"]
[OnName num="mari"]
Thank you very much. Yes...yes, ....... Oh, I understand, I'll see you later. Okay, see you later.
[cpg cn=true]



[SE f="se000"]
;//【ＳＥ】スマホ切る

;**【ＣＧ】 ev_47_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="Mari460"]
[OnName num="mari"]
"Okay.
[cpg cn=true]



[OnName num="keisuke"]
Something good?
[cpg cn=true]


[VOICE f="sMari025"]
[OnName num="mari"]
"Yes. You know that picture of me in the park?　They erased it.
[cpg cn=true]



[OnName num="keisuke"]
Who did?
[cpg cn=true]


[VOICE f="Mari462"]
[OnName num="mari"]
The guy who manages the Wacky Videos.
[cpg cn=true]



[OnName num="keisuke"]
Wow.
[cpg cn=true]



I was impressed that he could do such a thing.
[cpg]

I don't know who manages the site, but I wonder if they have some kind of contact with the person who opens the room.
[cpg]


[VOICE f="Mari463"]
[OnName num="mari"]
I guess I don't have to worry about that anymore.
[cpg cn=true]



[OnName num="keisuke"]
I guess so."
[cpg cn=true]



Seeing Hayashida's cheerful face made me happy, too.
[cpg]

Today, from this moment on, we have put aside our hatred for each other and are now lovers.
[cpg]



You never know where happiness may lie. ......
[cpg]

I never imagined it would turn out this way.
[cpg]

I closed my eyes, letting the pleasures of life's conundrums wash over me.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[STOPBGM]

[VOICE f="sMari026"]
[OnName num="mari"]
I think to myself, "...... yeah, that's right. My worries are gone. You made them disappear, too.
[cpg cn=true]

[SE f="se047"]
;//【ＳＥ】手錠かかる

[WAIT time=1000]

[OnName num="keisuke"]
What?"
[cpg cn=true]



Then I feel a disturbing sound and a cold touch on my wrist, and I open my eyes and ......
[cpg]

;//●ＣＧ（麻里：拘束された主人公を足蹴にして見下ろす）ev_48
;**【ＣＧ】 ev_48_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=100]
[BGM f="bg_an"]

;//手錠でベッドに繋がれている啓介

[OnName num="keisuke"]
What...?
[cpg cn=true]



My wrists had been handcuffed and fastened to a bed pole.
[cpg]


[VOICE f="Mari467"]
[OnName num="mari"]
How dare you do whatever you want to me. ......
[cpg cn=true]



[OnName num="keisuke"]
What?
[cpg cn=true]



I looked up at the voice and saw Hayashida standing over my upper body, looking down at me with upturned eyes.
[cpg]

[OnName num="keisuke"]
What do you mean?
[cpg cn=true]


[VOICE f="Mari468"]
[OnName num="mari"]
You still don't get it, do you?　From now on, you're going to be on the receiving end of revenge!
[cpg cn=true]



[SE f="se023"]
;//【ＳＥ】蹴る


[BG f="white.ui" time=100]
[WAIT time=100]
;**【ＣＧ】 ev_48_0 ***********************
[CG id=14 index=0 time=100]
;***************************************
[WAIT time=100]


[OnName num="keisuke"]
Ugh!
[cpg cn=true]



He stomped on my solar plexus and my breath caught in pain.
[cpg]


[VOICE f="Mari469"]
[OnName num="mari"]
The actuality of the actuality is that you can't get rid of the actuality.　I'm seriously horny?"
[cpg cn=true]



No way. ...... his goal all along was to make me delete my saved images!
[cpg]


[VOICE f="Mari470"]
[OnName num="mari"]
I was about to get cut off because of you.
[cpg cn=true]



[OnName num="keisuke"]
Cut off?
[cpg cn=true]


[VOICE f="Mari471"]
[OnName num="mari"]
By my precious master.
[cpg cn=true]



[OnName num="keisuke"]
......?
[cpg cn=true]



Hayashida stared at me with cold eyes.
[cpg]


[VOICE f="Mari472"]
[OnName num="mari"]
"Gross...!
[cpg cn=true]



[OnName num="keisuke"]
Gross...!"
[cpg cn=true]



I screamed as I was stepped on with the sole of my foot.
[cpg]


[VOICE f="Mari473"]
[OnName num="mari"]
'You'll never get a second chance, so ......
[cpg cn=true]



Serious face and voice .......
[cpg]

I was sure the cuffs would never come off my wrists. ......
[cpg]

[OnName num="keisuke"]
"Oh, what are you going to ...... do with me?"
[cpg cn=true]


[VOICE f="sMari027"]
[OnName num="mari"]
I don't know. I don't know. It's not my place. But just know that you're not safe.
[cpg cn=true]



[OnName num="keisuke"]
Ah... ah... ah.
[cpg cn=true]



[VOICE f="sMari028"]
[OnName num="mari"]
I would never fall for a guy like you. If you were seriously fooled even for a moment, you must have been happy.
[cpg cn=true]



[SE f="se033"]
;//【ＳＥ】チャイム（小さく）

In the distance, I hear a chime ring and someone comes in.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[VOICE f="Mari476"]
[OnName num="mari"]
You're going to be a ......... bully for the rest of your life."
[cpg cn=true]



Hayashida says and turns his back on me.
[cpg]

[OnName num="keisuke"]
I turn my back to him and say, "......, let's not do this anymore."
[cpg cn=true]


I don't know what words I can use to convince him from here.
[cpg]

I don't know what words I can use to convince him to stop.
[cpg]

[OnName num="keisuke"]
I don't know what kind of words I can use to convince him to stop, but I said exactly what I was thinking.
[cpg cn=true]

This is not a line I could say, since I was the one who decided to retaliate in the first place.
[cpg]

But I felt it was so barren that, apart from my intention to persuade him, I couldn't help but say it.
[cpg]

Hayashida turned around a little and looked a little pained.
[cpg]

Then he mouthed the words, "I'm sorry.
[cpg]

After that, he looked lost. Then I understood that I was right.
[cpg]

Hayashida was talking about the master and his jurisdiction.
[cpg]

She, too, is being manipulated by someone. She can't help but hand me over.
[cpg]

I don't even ...... know if she meant to deceive me.
[cpg]

How could I have let this happen? Is there any chance that Hayashida will rescue me after this?
[cpg]

I don't know. I don't know, but I kept her words of "I'm sorry" in my heart and closed my eyes.
[cpg]


[SCENE id=10]

;//麻里ＥＮＤ
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*start"]


