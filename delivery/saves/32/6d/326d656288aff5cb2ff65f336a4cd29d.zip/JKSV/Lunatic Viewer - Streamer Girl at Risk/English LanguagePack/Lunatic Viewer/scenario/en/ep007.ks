;//師匠ルート
*root5|

;//*test|

*start

;#################################################
*Ep007|The unquenchable desire for revenge
;#################################################

[SCENE id=7]






[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_7.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『雑談ルーム』

[OnName num="KEI"]
'I tried to have fun, just like my master told me to. But I can't do it anymore.
[cpg cn=true]



That night, I called my mentor to the chat room and told him what was on my mind.
[cpg]

[OnName num="siren"]
'I see. ......'
[cpg cn=true]



The master listened to everything in silence, then said a few words and fell silent for a bit.
[cpg]

[OnName num="KEI"]
'This blurred feeling will not disappear unless I get revenge on him, after all. I really want to get back at Hayashida. I have to do it.
[cpg cn=true]



[OnName num="siren"]
'Well, I thought he would say something like that someday... I'm sorry.
[cpg cn=true]



[OnName num="KEI"]
I'm sorry.
[cpg cn=true]



I thought I had discouraged my mentor, who had been so kind to me, and I apologized honestly.
[cpg]

[OnName num="siren"]
But honestly, I understand how you feel. So I will cooperate with you on the condition that you erase all the history of this site.
[cpg cn=true]



[OnName num="KEI"]
"Cooperate?"
[cpg cn=true]



[OnName num="siren"]
'Actually, ever since you told me about the bullying, I've been thinking about Liane Hayashida. I've been looking for information on her personally.
[cpg cn=true]



[OnName num="KEI"]
'Oh, you did?　So, what did you find out?
[cpg cn=true]



I took in the encouraging words of my mentor and stared at the chat room.
[cpg]

[OnName num="siren"]
'It seems that Mari Hayashida, a.k.a. Lian, was not only chatting with a guy using Wakuteka Video, but was also trying to meet him in real life.
[cpg cn=true]



[OnName num="KEI"]
That doesn't surprise me at all.
[cpg cn=true]



[OnName num="siren"]
'Yes, that's not surprising at all. So I pretended to take her up on her offer and got her contact information, and from there I was able to track down her current address.
[cpg cn=true]



[OnName num="KEI"]
What?　I'm impressed. As expected of you, master!
[cpg cn=true]



I wonder who this person really is, that he was able to find out Hayashida's address, which I, a classmate, didn't know.
[cpg]

[OnName num="siren"]
How do you like it?　The condition for me to give it to you is, as I said before, that you erase the history of this site and never come back here again.
[cpg cn=true]



[OnName num="KEI"]
I promise!
[cpg cn=true]



[OnName num="siren"]
Is that true?
[cpg cn=true]



[OnName num="KEI"]
Yes!　But .........
[cpg cn=true]



[OnName num="siren"]
Hmm?
[cpg cn=true]



[OnName num="KEI"]
Why are you being so nice to me, a stranger?
[cpg cn=true]



[OnName num="siren"]
'Oh, well, you know, the more we talked, the more I felt like you were like a brother to me. I felt sorry for you. I'm the kind of person who doesn't tolerate bullies.
[cpg cn=true]



[OnName num="KEI"]
'Thank you very much. Thank you very much, Master. When I met Hayashida again on this site, I thought that hell had started all over again, but thanks to you, I felt that this world is not so bad after all.
[cpg cn=true]



[OnName num="siren"]
'That's good to hear. I'm glad to hear that.
[cpg cn=true]



>Message received from Mr. Siren.
[cpg]

The last message received from the master.
[cpg]

It contained Mari Hayashida's home address.
[cpg]

[OnName num="KEI"]
'Thank you very much. Then I'm going to log out and delete my history. Master, thank you so much for everything you've done for me.
[cpg cn=true]



[OnName num="siren"]
Oh, wait a minute.
[cpg cn=true]



[OnName num="KEI"]
What?"
[cpg cn=true]



[OnName num="siren"]
I don't really want you to get your revenge, okay?　I'm still hoping that you'll stop.
[cpg cn=true]



[OnName num="KEI"]
It's my life. It's my life. Goodbye.
[cpg cn=true]



With a tug on my hair, I said goodbye to my mentor and logged out.
[cpg]

[OnName num="keisuke"]
'Clear all history: ......'
[cpg cn=true]



[SE f="se024"]
;//【ＳＥ】マウス数回クリック

I erased all the history of WAKUTEKA video as I was told, wrote down Hayashida's address on my phone, and got up.
[cpg]

[OnName num="keisuke"]
Okay, ......."
[cpg cn=true]



Now, the revenge drama begins. ......
[cpg]

;//麻里のマンション　部屋の前
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

[BG f="b_09_2.ui" time=1000]
[WAIT time=2000]

;//ブラックアウト
The apartment where Hayashida lived was a few minutes away from my house by train.
[cpg]

The auto-locked entrance was nothing more than an unsecured, automatic door, and I could easily walk up to the front of the room after following the occupants.
[cpg]

[OnName num="keisuke"]
.................."
[cpg cn=true]



I put my cap on blindly. I can't help but get a warrior's shiver.
[cpg]

What if he has a family...?
[cpg]

[OnName num="keisuke"]
No, I don't care what happens to that guy's family. ......
[cpg cn=true]



I was completely broken.
[cpg]

I don't care if I become a criminal.
[cpg]

I wouldn't care what happened to the rest of my life if I could get revenge on that woman.
[cpg]

I reached for the intercom button with my right hand.
[cpg]

[SE f="se003"]
;//【ＳＥ】インターフォン（ピンポーン）

Soon a familiar voice answers, and I whisper, conscious of my cap.
[cpg]

[OnName num="keisuke"]
A delivery for you.
[cpg cn=true]



;//[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mari208"]
[OnName num="mari"]
Oh, yes."
[cpg cn=true]



I hear footsteps clattering from inside the room, approaching the front door.
[cpg]

[SE f="se011"]
;//【ＳＥ】鍵を開け、ドアが開く

[FG f="CHA02_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Mari209"]
[OnName num="mari"]
Who is it?　What?
[cpg cn=true]


[BGM f="bg_an"]
[SE f="se020"]
;//【ＳＥ】ドドドド（雪崩れ込む）
[free time=1000]
As soon as the door opens and Hayashida's dumb face appears, I shove him into the room as hard as I can.
[cpg]


[BG f="b_07_2.ui" time=1000]
[WAIT time=1000]

[FG f="CHA02_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Mari210"]
[OnName num="mari"]
Who?　Who's there?　What's going on?
[cpg cn=true]



Startled and confused, Hayashida slumped to the floor and fell on his butt in the hallway.
[cpg]


[OnName num="keisuke"]
........."
[cpg cn=true]



[FACE method="change_4" pos="2/3"]
[VOICE f="Mari211"]
[OnName num="mari"]
H...?　I don't have any money!　I don't have any money!
[cpg cn=true]



Hayashida turned blue and began to backpedal.
[cpg]

[OnName num="keisuke"]
Don't lie to me. I know you have it, the money you made from the video.
[cpg cn=true]



[FACE method="change_5" pos="2/3"]
[VOICE f="Mari212"]
[OnName num="mari"]
What?　Who are you?
[cpg cn=true]



[OnName num="keisuke"]
Have you forgotten?　Have you forgotten my face?
[cpg cn=true]



When he took off his hat and exposed his face, Hayashida's eyes widened.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Mari213"]
[OnName num="mari"]
He took off his hat and revealed his face. Ah, you ......."
[cpg cn=true]



Apparently, he remembered his face, but no words came out with his mouth agape.
[cpg]

[OnName num="keisuke"]
Say my name.
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Mari214"]
[OnName num="mari"]
Hey, your name is ............."
[cpg cn=true]



[OnName num="keisuke"]
Don't tell me you don't remember ......?
[cpg cn=true]



Or maybe you didn't know it all along: ......
[cpg]

Either way, it anointed me with anger.
[cpg]

[OnName num="keisuke"]
You!"　You've been fucking rotting me to death!"
[cpg cn=true]



[SE f="se023"]
;//【ＳＥ】蹴り

[FACE method="change_3" pos="2/3"]
[VOICE f="sMari016"]
[OnName num="mari"]
What the hell!　What the hell are you doing?　You think you can get away with this?
[cpg cn=true]



[OnName num="keisuke"]
Aaaaah!
[cpg cn=true]



[FACE method="change_4" pos="2/3"]
[VOICE f="Mari216"]
[OnName num="mari"]
Hyah!
[cpg cn=true]



[SE f="se020"]
;//【ＳＥ】叩き付ける
[free time=1000]

I grabbed Hayashida by the hair and slammed his head into the floor.
[cpg]

[OnName num="keisuke"]
You're the reason my life is over!　I don't care what happens to you!"
[cpg cn=true]



I was surprised at how loud my voice was.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Mari217"]
[OnName num="mari"]
Help me, I'm sorry!　I'm really, really sorry!
[cpg cn=true]



I'm so sorry!" The apology was incredibly flimsy.
[cpg]

I wouldn't have come all this way if I thought that was enough to get me to back down.
[cpg]

[OnName num="keisuke"]
I've been watching your video feed every day. You didn't know, did you?　It's me. I'm Kay."
[cpg cn=true]


He was absolutely stunned to find out that I was Kei. I went straight for Hayashida.
[cpg]

[OnName num="keisuke"]
I'm going to upload your embarrassing video on the Internet just like you did to me!
[cpg cn=true]



[FACE method="change_3" pos="2/3"]
[VOICE f="sMari017"]
[OnName num="mari"]
No, no, no!　Get off me!
[cpg cn=true]



[OnName num="keisuke"]
What's the matter ......, you're not weak at all? Without your cronies, you're nothing like this. ......
[cpg cn=true]



I looked down at Hayashida and felt a strange feeling.
[cpg]

The most important thing to remember is that you can't be afraid to take advantage of the best of the best.
[cpg]

What had I been afraid of all this time?
[cpg]

[OnName num="keisuke"]
I'm going to give you plenty in return, so get ready for it.
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Mari219"]
[OnName num="mari"]
No, no, no, forgive me!
[cpg cn=true]



My revenge for all those years will be fulfilled. Just when I thought that, ......
[cpg]

[free time=1000]

[SE f="se003"]
;//【ＳＥ】インターフォン（ピンポーン）
[WAIT time=1500]

[OnName num="keisuke"]
I was so surprised that I was sweating from every pore in my body.
[cpg cn=true]



Sweat broke out from every pore in my body in surprise.
[cpg]

I turned around to see if my family had returned.
[cpg]


;/[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
;/[VOICE f="Mari220"]
;/[OnName num="mari"]
;/「んーーんんーーーっ！」
;/[cpg cn=true]



[OnName num="keisuke"]
Shut up!
[cpg cn=true]



[SE f="se038"]
;//【ＳＥ】メール着信

[OnName num="keisuke"]
「！！」
[cpg cn=true]



A text message then came through on my phone, and I rushed to check the screen.
[cpg]

[OnName num="keisuke"]
What...?"
[cpg cn=true]



I looked and it was an incoming call to the messenger for the Wakuteka video: ......
[cpg]


'It's me. It's a siren. I'm in front of Mari Hayashida's room because I'm really worried about her.
[cpg cn=true]



[OnName num="keisuke"]
'Master...'
[cpg cn=true]



I stiffened, not knowing how to respond to being told that I was worried.
[cpg]

The master, with whom I had only exchanged messages until now, is on the other side of the door. ......
[cpg]

Part of me wanted to thank him at first sight, but if he had come to stop me, I couldn't just unlock the door.
[cpg]

I returned the message to Hayashida, still on horseback.
[cpg]
What are you doing here? There's no point in stopping him.
[cpg cn=true]



[SE f="se038"]
;//【ＳＥ】メール着信
That's not what I came here to do. I'm here to help. I've thought of a way for you to avoid getting caught by the police. Just let me in.
[cpg cn=true]



[OnName num="keisuke"]
"Oh...that's all ...... for me."
[cpg cn=true]



I didn't want to get involved if I could help it, but nothing would be more reassuring than if he would help me.
[cpg]

As soon as I read Master's reply, I stood up and put my hand on the front door.
[cpg]

[SE f="se011"]
;//【ＳＥ】ドア開ける

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

[OnName num="keisuke"]
Master!"
[cpg cn=true]



I opened the door as wide as I could and gave my utmost respect to my master, whom I had never met before. ......
[cpg]

[SE f="se040"]
;//【ＳＥ】スプレー噴射

;//画面が曇る
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]



[OnName num="keisuke"]
"......... eh?"
[cpg cn=true]



The moment ......
[cpg]

something was sprayed in front of me, and as soon as I thought my vision had clouded over, I couldn't think of ...... anything else.
[cpg]

;//暗転

[BG f="black.ui" time=1000]
[WAIT time=2000]


[OnName num="keisuke"]
I was like, ".........?"
[cpg cn=true]


And then...I woke up with a physical pain.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]
;//【ＢＧ】『麻里の部屋』


[OnName num="keisuke"]
'Nah ......, nah!'
[cpg cn=true]



For some reason, I was bound by both arms and legs and rolled on the floor.
[cpg]

;//＠
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=800]
There was Hayashida and one other person...
[cpg]


[FG f="CHA03_p1_03_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Hitomi141"]
[OnName num="SB"]
"You're finally awake."
[cpg cn=true]



[OnName num="keisuke"]
What?
[cpg cn=true]



[OnName num="keisuke"]
Oh, you're the ...... butterfly!
[cpg cn=true]



Oh, you remember me? What a reaction.
[cpg]

Once you see her, you will never forget her quirky outfit of butterfly mask, bonnet and lab coat.
[cpg]

It was S. Butterfly, the organizer of H Castle.
[cpg]

[OnName num="keisuke"]
What is ......?　What...so?
[cpg cn=true]


I couldn't calm down at all, even though I wanted to clear my confused head.
[cpg]



[OnName num="keisuke"]
What the hell is this?　Where's the master...where's Mr. Siren!"
[cpg cn=true]



Hearing my words, SB laughs.
[cpg]



[FACE method="change_1" pos="2/5"]
[VOICE f="Hitomi142"]
[OnName num="SB"]
I am your master. I am the siren.
[cpg cn=true]



[OnName num="keisuke"]
What? What?
[cpg cn=true]



Hayashida approaches me. I wanted to brace myself, but I was restrained and couldn't do so.
[cpg]


[VOICE f="Hitomi144"]
[OnName num="SB"]
I'm also the administrator of that video streaming site. And I'm the head of the women who have a room there.
[cpg cn=true]



[OnName num="keisuke"]
The head of the site?
[cpg cn=true]



The first time I heard this title, I felt something unusual, and my mouth started to dry up.
[cpg]

The actual "siren" is usually a name that patrols each room and gives nails and instructions to users who might cause problems.
[cpg]

But that day ...... she met me.
[cpg]

SB looks down at me and talks while playing with a stick whip with her hand.
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Hitomi145"]
[OnName num="SB"]
If they commit the crime of revenge, my site will be involved. It's an important source of funding for me, and I couldn't let you go on a rampage.
[cpg cn=true]



If you had just stopped, none of this would have happened....
[cpg]

[OnName num="keisuke"]
What is this?"
[cpg cn=true]



SB tells the story. Mari Hayashida is a major earner, and it would be a big blow if she were to be destroyed.
[cpg]

So, to prevent that from happening, and to make amends for wasting her head and time over the past few days, he lured her to this room.
[cpg]



He says that SB is only an entertainer...that is what the guys want, to provide dreams in a girl's room and get paid for it...that is the kind of business he is in.
[cpg]


[FACE method="change_1" pos="2/5"]
[VOICE f="Hitomi146"]
[OnName num="SB"]
The video supply business ...... is where your redemption begins, you know?"
[cpg cn=true]



[OnName num="keisuke"]
What...business!"
[cpg cn=true]



I looked up to find an unbelievable object on the wall of the room.
[cpg]

[OnName num="keisuke"]
I looked up and saw an unbelievable object on the wall of the room.
[cpg cn=true]



There it was, a mute video camera.
[cpg]

There was a small red light on the lens.
[cpg]

It was a sign that it was a REC, meaning that this act was now being recorded.
[cpg]

[OnName num="keisuke"]
"Are you kidding me?
[cpg cn=true]



[SE f="se025"]
;//【ＳＥ】キーボード叩く

[OnName num="keisuke"]
What?
[cpg cn=true]



When SB touches the keyboard of the computer, a wakteka video appears on the monitor.
[cpg]

On the screen was Leanne's room at ...... and me.
[cpg]



[OnName num="keisuke"]
"What the hell are you doing...?"
[cpg cn=true]




[OnName num="john_doe0817"]
Who is this guy?
[cpg cn=true]


[OnName num="john_doe1223"]
I've paid him ten thousand dollars.
[cpg cn=true]


[OnName num="john_doe0826"]
I paid 10,000 for this, so show me something good.
[cpg cn=true]



[OnName num="keisuke"]
"10,000?
[cpg cn=true]



The chat room was filled with eerie nanashis.
[cpg]

The number of people is growing by the minute.
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Hitomi147"]
[OnName num="SB"]
The men...are idiots. I know who they are because their names are numbered.
[cpg cn=true]



[OnName num="keisuke"]
Oh, no. ......
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[VOICE f="Hitomi148"]
[OnName num="SB"]
You were great, by the way. You did exactly what I told you to do afterwards.
[cpg cn=true]



[OnName num="keisuke"]
How do you know?
[cpg cn=true]



SB laughed and said, "Because I hacked your computer. He says it's because I hacked into his computer.
[cpg]

He said he was going to have the fact that I had anything to do with this site erased.
[cpg]



[OnName num="keisuke"]
'And that's why you did this!　But I want revenge on this woman!"
[cpg cn=true]



[VOICE f="Hitomi149"]
[OnName num="SB"]
Well, it depends on how you look at it. Enjoy or suffer, it's up to you. ......
[cpg cn=true]



With this muttering, SB stood up.
[cpg]

Then, when the whip held in his right hand was made to flutter in the palm of his left hand a few times, he swung it down to Hayashida.
[cpg]



[SE f="se009"]
;//【ＳＥ】棒鞭


[FACE method="change_5" pos="4/5"]
[VOICE f="sMari018"]
[OnName num="mari"]
"Aaaaah!"
[cpg cn=true]



[FACE method="change_3" pos="2/5"]
[VOICE f="sHitomi012"]
[OnName num="SB"]
Look, don't just stand there. Satisfy both Kay and Nanashi!
[cpg cn=true]



Satisfy them. It's easy to say, but it's not easy to make a movie or a show that you want to pay 10,000 yen to see.
[cpg]



Hayashida probably knows that and still approaches me...
[cpg]



;//移植前シーンカット

Then SB pulled out a few 10,000 yen bills from his white coat pocket and they fell in front of my eyes.
[cpg]


[FACE method="change_1" pos="2/5"]
[VOICE f="sHitomi013"]
[OnName num="SB"]
He said, "If you forget about revenge and become a part of my system from now on, I promise you a reward from now on. But if you don't want to do that, go to ......."
[cpg cn=true]



[OnName num="keisuke"]
......."
[cpg cn=true]



I don't have to tell you what he said after that.
[cpg]

My videos will be scattered all over the internet world.
[cpg]

Not only the old ones, but also the newly recorded ones...
[cpg]

I had no choice from the beginning.
[cpg]

The master, whom I had so carelessly trusted in the world I had entered, had intended to prey on me from the very beginning.
[cpg]

[OnName num="keisuke"]
"Become ...... a part of the ......... system."
[cpg cn=true]



Even though I was plunged into darkness and felt like a dongdang, I also felt a sense of joy.
[cpg]

Once a loser, my life was already doomed to defeat.
[cpg]


[FACE method="change_2" pos="2/5"]
[VOICE f="Hitomi187"]
[OnName num="SB"]
From now on," he said, "we're going to start bringing in female viewers, too. Using you."
[cpg cn=true]



The face under the sneaky mask was smiling a big smile.
[cpg]

[SCENE id=12]

;//師匠ルート
;//悪ルート・終
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*start"]

