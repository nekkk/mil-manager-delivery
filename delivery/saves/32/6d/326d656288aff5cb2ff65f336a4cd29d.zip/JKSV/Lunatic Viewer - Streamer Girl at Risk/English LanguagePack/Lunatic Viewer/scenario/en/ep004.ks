


;//美咲ルート

*root1|

;//*test|

*start

;#################################################
*Ep004|Pale love turned to hatred.
;#################################################

[SCENE id=4]





[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公（啓介）の部屋』・昼

After that, I fell into emotional instability to the extent that even I could understand it.
[cpg]

I had a faint infatuation with a girl named Emu at first....
[cpg]

I was so ashamed and ashamed of myself when she saw me in my lascivious state.
[cpg]

I might have had a chance when she didn't know how pathetic I was, but now, her eyes would never look at me with more than pity.
[cpg]

In fact, they may even be disgusted with me.
[cpg]

When you're across the screen, you can pretend or say whatever you want.
[cpg]

Because Emu is the kind of woman who can play with ...... men.
[cpg]

I'm sure she can play with me as much as she wants.
[cpg]

[OnName num="keisuke"]
Ah...ah...but...but ......
[cpg cn=true]



I can't forget Emu's gentle smile.
[cpg]

I can't believe it's someone other than me who's directly touching that angel and hugging her soft skin. ......
[cpg]

[OnName num="keisuke"]
No...no...no...no...no...no...no...no...no...no...no.........
[cpg cn=true]



I can hear the sound of scratching my head echoing against my skull.
[cpg]

[OnName num="keisuke"]
I hate it... I hate it..."
[cpg cn=true]



I've been hurt, I've lost everything, I shouldn't be any more unhappy than I am.
[cpg]

I should be more, I should be able to see the good in my eyes .......
[cpg]

[OnName num="keisuke"]
That's right ...... that's right ......
[cpg cn=true]



I need to act fast myself, rather than let other people take my happiness away from me.
[cpg]

That's what I thought. ......
[cpg]

[OnName num="keisuke"]
I'm going to do it......."
[cpg cn=true]



Determined, I connected the information I had gathered so far, which was only a "dot", and made it into a "line".
[cpg]

[OnName num="keisuke"]
"Here it is.... I'm sure."
[cpg cn=true]



I spread out the map, and based on what she said and did, what I saw and heard, I found out the address of Emu's house.
[cpg]

Then I packed all the tools I could think of in my backpack and left the room with firm steps.
[cpg]

;//ぇむ宅前（住宅地）

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[OnName num="keisuke"]
"You don't mean ...... this?"
[cpg cn=true]



I stood stunned as I reached the house diagonally across the street from the delivery center.
[cpg]

The house was large enough to be called a mansion.
[cpg]

[OnName num="keisuke"]
Tokura ......"
[cpg cn=true]



The family name on the magnificent nameplate was probably that of HAYUMU.
[cpg]

I felt like I was one step closer to her just by saying it.
[cpg]

But ......
[cpg]

[OnName num="keisuke"]
How can I ......?"
[cpg cn=true]



The first thing to do is to make sure that you have a good idea of what you are looking for.
[cpg]

The most important thing to do is to make sure that you have a good idea of what you're doing.
[cpg]

What if someone sees me ......
[cpg]

I hated myself for still hesitating, even though I had already made up my mind.
[cpg]

How much more of a pathetic man am I?
[cpg]

[SE f="se038"]
;//【ＳＥ】メール着信

[OnName num="keisuke"]
Hmm...?"
[cpg cn=true]



At that time, I received a "notice" from Wakuteka Video on my phone.
[cpg]

It stated that Emu was going to start a guerrilla broadcast.
[cpg]

[OnName num="keisuke"]
"Kuh...?"
[cpg cn=true]



A sense of frustration gnawed at me at once.
[cpg]


While I'm waiting for this to happen, someone might befriend her or head for the Secret.
[cpg]


[OnName num="keisuke"]
I won't let that happen. ......
[cpg cn=true]



Oddly enough, that sense of urgency strengthened my heart, and I jumped at once to the wall of the Tokugura mansion as soon as I got a running start.
[cpg]


;//ブラックアウト
;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_an"]
[WAIT time=100]
;//【ＢＧ】『美咲の部屋』

[OnName num="keisuke"]
.................."
[cpg cn=true]



I entered the yard and first checked the doors and windows on the first floor, but they were all locked, so I scrambled up to the second floor balcony and peeked inside through a nearby window.
[cpg]


Then I climbed onto the second-floor balcony and peeked in through a nearby window, and found her in that familiar room, the one I had dreamed of.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misaki218"]
[OnName num="eMU"]
I thought to myself, "Well, now that I think about it, it's not even lunchtime.... I think I'll wait for about 3 more minutes and close it if no one comes. ......"
[cpg cn=true]



The excitement of watching a broadcast that I would normally watch on my computer monitor, but now I was seeing it with my naked eye.
[cpg]

It made me take action.
[cpg]

[SE f="se036"]
;//【ＳＥ】窓ノック（コンコン）


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
I knocked on the window, and Emu got up and came over to me.
[cpg]

[SE f="se037"]
;//【ＳＥ】窓開ける

[WAIT time=1000]

[FACE method="change_5" pos="2/3"]
[OnName num="keisuke"]
"Don't make a sound.
[cpg cn=true]



As soon as she peeks out of the window, I cover her mouth with my hand and push her body into the room.
[cpg]

[VOICE f="Misaki219"]
[OnName num="eMU"]
What?
[cpg cn=true]



[OnName num="keisuke"]
Be quiet."
[cpg cn=true]



I felt adrenaline spurting into my brain.
[cpg]

;//qwe

[free time=1000]

[SE f="se023"]
;//【ＳＥ】転倒

[free time=1000]

[VOICE f="Misaki220"]
[OnName num="eMU"]
"Kya!
[cpg cn=true]



The struggle lasted only a few seconds, and then he lost his balance and pushed her to the floor.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misaki221"]
[OnName num="eMU"]
I've got ...... for the money."
[cpg cn=true]



She might have mistaken him for a robber, but for some reason she froze when he started to speak in a trembling voice.
[cpg]

His frightened eyes caught me under his distorted eyebrows.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Misaki222"]
[OnName num="eMU"]
'Ke......Kay...kun...?
[cpg cn=true]



[OnName num="keisuke"]
!"
[cpg cn=true]



Emu, who had been watching the bullying video, seemed to have realized who I was.
[cpg]

There was no way I could recognize her face after seeing her once or twice in that rampaging and shaking video.
[cpg]

This woman had seen ...... it so many times!
[cpg]

The images of me being humiliated, over and over and over again!
[cpg]


[OnName num="keisuke"]
Aaaaahhhh!"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

I scream in anger. Emu is frightened and doesn't seem to be resisting.
[cpg]


There is no need to do anything by force. So, the revenge I have to take is ...... this.
[cpg]


[OnName num="keisuke"]
If you don't want to ...... die, be quiet.
[cpg cn=true]

[FACE method="change_5" pos="2/3"]


[OnName num="keisuke"]
I'm serious. If you get away with it, I'll tell everyone who you are, your real name, and your picture.
[cpg cn=true]



[OnName num="keisuke"]
I have nothing more to lose, and when I'm done with this plan, ...... I'll end it myself."
[cpg cn=true]



With that, I pointed the camera on my phone at her.
[cpg]


;//ブラックアウト
;//エフェクト

[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『美咲の部屋』(夜)


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Misaki262"]
[OnName num="eMU"]
'I won't tell anyone, ...... don't do this to me.'
[cpg cn=true]



[OnName num="keisuke"]
'No...'
[cpg cn=true]



[SE f="se022"]
;//【ＳＥ】シャッター

[free time=500]
[BG f="white.ui" time=500]
[WAIT time=500]
[BG f="b_08_4.ui" time=500]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=500]
[WAIT time=500]

[VOICE f="Misaki263"]
[OnName num="eMU"]
'This... this is the same thing that was done to you. ......
[cpg cn=true]



[OnName num="keisuke"]
"........."
[cpg cn=true]



[SE f="se022"]
;//【ＳＥ】シャッター



[free time=500]
[BG f="white.ui" time=500]
[WAIT time=500]
[BG f="b_08_4.ui" time=500]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=500]
[WAIT time=500]



They already know what I look like, and if they follow the bullying videos, they can easily find out who I am and where I am from.
[cpg]

That meant that no matter where I ran to, the police would catch me one day anyway.
[cpg]

If that's the case, I'd better enjoy myself for as long as I can .......
[cpg]

I'm sorry, but I'm going to let this girl take all the resentment and bitterness towards all the women in my life.
[cpg]

[OnName num="keisuke"]
Is it that time already?"
[cpg cn=true]



I looked at the clock and helped her to her desk chair, causing her to slump to the floor.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misaki265"]
[OnName num="eMU"]
What are you doing at ......?
[cpg cn=true]



[OnName num="keisuke"]
It's time for the live feed."
[cpg cn=true]



Her shoulders shook at the words.
[cpg]


[OnName num="keisuke"]
The viewers are looking forward to it."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sMisaki010"]
[OnName num="eMU"]
'Oh, no. ...... what are you talking about?
[cpg cn=true]



[OnName num="keisuke"]
You've been rushing everyone so far, let's make today a service day."
[cpg cn=true]



I stopped Emu, who was trying to escape, and started up my computer.
[cpg]


The most important thing to remember is that you can't be too careful when it comes to your health and wellness. Come on in.
[cpg cn=true]



I typed that into the notice box and set the price.
[cpg]

I'll charge about 10,000 yen.
[cpg]

I send the pass to everyone on my friends list at once.
[cpg]


I get under his feet, under his desk, and say, "You're going to do exactly what I tell you.
[cpg]


[OnName num="keisuke"]
"You do what I tell you to do," I say. Or else... you know what I mean?"
[cpg cn=true]


At my words, Emu seems to have lost her nerve and turns back to the camera.
[cpg]


[OnName num="keisuke"]
I told her, "Tell everyone to look at me naked. I want to thank you for everything you've done for me."
[cpg cn=true]


I instructed her from under the desk while watching the video on the viewer's side with my phone.
[cpg]

I had to pay 10,000 yen for it, but I could collect it later.
[cpg]

[OnName num="kanata"]
What's the matter with you, suddenly you're secret?
[cpg cn=true]



[OnName num="kumachan"]
"Hey, are you trying to take off your clothes?
[cpg cn=true]



[OnName num="aaa"]
Oh, my God!
[cpg cn=true]



They were all very upset when they came into the Secret.
[cpg]



[VOICE f="Misaki269"]
[OnName num="eMU"]
"Yes, I want to thank you ...... for everything you've done for me..."
[cpg cn=true]



I whispered in a whisper that didn't get on the microphone.
[cpg]

[OnName num="keisuke"]
If you can't take it off, I can take it off for you.
[cpg cn=true]



[VOICE f="sMisaki011"]
[OnName num="eMU"]
Ummm....thank you....for....seeing....me....naked.............. I'll let you see... me... naked..."
[cpg cn=true]



[OnName num="oac"]
"I'm so glad I'm alive!
[cpg cn=true]



[OnName num="yaminabebugyo"]
This is great!　Get on with it."
[cpg cn=true]



;//移植前シーンカット

;//移植前シーンカット

;//移植前シーンカット

She puts her hands on her clothes. I'll put my hand on it, but.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="sMisaki012"]
[OnName num="eMU"]
'I can't ...... do this after all.'
[cpg cn=true]


She stops, just in time.
[cpg]


I've been in worse trouble than this.
[cpg]


[OnName num="keisuke"]
I can't help it. I'm going to take it off.
[cpg cn=true]


;//ＣＧ位置移動しています

;//●ＣＧ（美咲。配信中。背後に主人公が居る。二人とも服を着ている）ev_20
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=100]


[OnName num="yaminabebugyo"]
"What?
[cpg cn=true]



[OnName num="kumachan"]
Who the hell is that?
[cpg cn=true]



[OnName num="kanata"]
There's a guy in there?
[cpg cn=true]



[OnName num="aaa"]
"You gotta be kidding me!"
[cpg cn=true]



The regulars, surprised by the intruder, cursed Niemu and me verbally, but no one logged out.
[cpg]


They probably wanted to see Niemu naked that badly.
[cpg]


The "Emu's Room" broadcasts the tears overflowing and her beautiful face getting all smudged up.
[cpg]


[OnName num="keisuke"]
She says, "I can't undress you unless you put your hands up. I'd be happy to rip it off for you."
[cpg cn=true]



[FACE method="change_1" pos="2/3"]
[VOICE f="sMisaki013"]
[OnName num="eMU"]
'Hiccup ......'
[cpg cn=true]



[OnName num="keisuke"]
It's up to you. I'm going to finish it either way.
[cpg cn=true]


;**【ＣＧ】 ev_20_a ***********************
[CG id=8 index=1 time=100]
;***************************************
[WAIT time=100]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMisaki014"]
[OnName num="eMU"]
No, I knew it, no......!"
[cpg cn=true]



With that, she reached for the mouse and forcibly terminated the delivery.
[cpg]


She had a lot of guts, even though I could have done anything I wanted.
[cpg]


But if she doesn't want to be seen naked that much, it makes her even more passionate.
[cpg]


[OnName num="keisuke"]
You've got some guts.
[cpg cn=true]



From that day on, my and Emu's confinement delivery started. ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
;//エフェクト

It's been a few days since then.
[cpg]

It was unclear if my family was in this house, as it was too big to hear anything at all and no one called out to this room.
[cpg]

For several days, Emu did not scream as ordered, nor did she show any signs of running away in a violent manner.
[cpg]

So I tried little by little, unbinding his legs and freeing his hands, but he still didn't run away, he didn't call anywhere, and when his homeroom teacher called, he lied and said his cold had gotten worse.
[cpg]

As a reward, I gave her permission to take a shower for the first time in the past few days.
[cpg]

She thanked me for the bath and even thanked me.
[cpg]

I wondered if this was what brainwashing was all about. ......
[cpg]

Emu would never cheat on me again.
[cpg]

She didn't run away when I sent her to the door to pick up the pizza delivery, and she didn't call the police when I sent her to the kitchen to get a drink.
[cpg]


;//ブラックアウト
;//エフェクト



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


And tonight, too, it's time for the delivery to start.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ぇむの部屋』

[OnName num="taimeshi"]
'I think we should call the cops on this one.
[cpg cn=true]


[OnName num="romeo"]
'What are you talking about, it's just role-playing.
[cpg cn=true]

;//●ＣＧ（美咲。ヒロインの口の中に指を入れる主人公）ev_21
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_21_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=100]

She has her arms restrained. I'm wearing clothes, but I'm not complaining about what they're doing to me.
[cpg]


Everyone knows that. I might really be locked up.
[cpg]


But still, they didn't call the police. People want to see this kind of thrilling delivery.
[cpg]


[OnName num="keisuke"]
"Look. Open your mouth, and Master will touch you.
[cpg cn=true]


[VOICE f="sMisaki015"]
[OnName num="eMU"]
Ah......, ugh."
[cpg cn=true]


I made her open her mouth and put my finger inside.
[cpg]


As I teased her tongue, the chat section was springing up as well.
[cpg]



[OnName num="yaminabebugyo"]
'Wonderful Master. May I ask your name?'
[cpg cn=true]



Kay.
[cpg]


Feeling good about the praise, I passed it on.
[cpg]


;//ブラックアウト

[OnName num="kanata"]
Kay?　You can't be that Kay!
[cpg cn=true]



[OnName num="yaminabebugyo"]
'My God!　This is a surprise!
[cpg cn=true]



[OnName num="kumachan"]
What's going on?
[cpg cn=true]



[OnName num="inudoshi"]
What?　What is it?　Do you know him?
[cpg cn=true]




[OnName num="keisuke"]
"Hmph!"
[cpg cn=true]



I closed my computer and enjoyed myself while the others were upset.
[cpg]

I wonder how jealous they would be if they knew that I, who was not only in their league but also below them a while ago, was now with their idol.
[cpg]

It was so amusing to me.
[cpg]

[OnName num="keisuke"]
"They're happy because of you," he said.
[cpg cn=true]



;**【ＣＧ】 ev_21_a ***********************
[CG id=9 index=1 time=100]
;***************************************
[WAIT time=100]


;//[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Misaki392"]
[OnName num="eMU"]
"Ugh...... ugh...ugh..."
[cpg cn=true]



Again.
[cpg]


He cries as soon as the delivery is over.
[cpg]

The first time I saw him, I thought it was a beauty of style, and it was rather funny.
[cpg]

[OnName num="keisuke"]
"........., take a bath.
[cpg cn=true]


;**【ＣＧ】 ev_21_b ***********************
[CG id=9 index=2 time=100]
;***************************************
[WAIT time=100]

;//[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki393"]
[OnName num="eMU"]
"......... hey."
[cpg cn=true]



It's funny to comfort her, and I'm a little tired too.
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『美咲の部屋』

[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]


The first thing you need to do is to take a look at the following.
[cpg]

[OnName num="keisuke"]
.................."
[cpg cn=true]



How long have I been in this room?
[cpg]

First it was on the other side of the monitor.
[cpg]

Now I'm on this side of the camera.
[cpg]

Even though it is the same "Emu's room," the feeling is completely different.
[cpg]

Even though he has been shut up for several days, there has been no contact from his family.
[cpg]

His homeroom teacher has only called once, and there are no texts from anyone who seems to be his friend.
[cpg]

I take out my phone and look at it.
[cpg]

It's the same on my end, no sign of an incoming call from anyone.
[cpg]

I didn't have any friends to begin with, and even acquaintances had become my enemies after the incident, so it was no surprise...
[cpg]

[OnName num="keisuke"]
「………」
[cpg cn=true]



Silently closing my eyes, I fell into darkness as a heavy sense of fatigue overtook me. ......
[cpg]


;//暗転
[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se011"]
;//【ＳＥ】ドア開く

;//明転


[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『美咲の部屋』(夜)

;//[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]

I jumped up with a start at the sound of the door opening, and there was Emu standing there after taking a bath.
[cpg]

I checked to see how much time had passed, and it was well over half an hour.
[cpg]

[OnName num="keisuke"]
I wondered if he had been asleep for more than half an hour.
[cpg cn=true]



She sat down on the bed and started to wipe her wet hair with a towel.
[cpg]

There was enough time, but she still didn't run away.
[cpg]

That's what I can't figure out.
[cpg]

[OnName num="keisuke"]
Why ......"
[cpg cn=true]



I was so surprised that I couldn't help but say it.
[cpg]

[OnName num="keisuke"]
"Why ...... not run away?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki394"]
[OnName num="eMU"]
She said, "Don't run away ......."
[cpg cn=true]



[OnName num="keisuke"]
"Are you an idiot?　I'm not going to run away because you told me not to run away, that's crazy!　Ah ......"
[cpg cn=true]



Yes....
[cpg]

I thought to myself, "What am I talking about?
[cpg]

Because I threatened to tell you who I am and my real name. ......?
[cpg]

That's right, .......
[cpg]

[OnName num="keisuke"]
Are you that afraid of a leak?"
[cpg cn=true]



That was a dumb question, too.
[cpg]

Because I was the one who got sick at heart because of it.
[cpg]
[FACE method="change_4" pos="2/3"]
[VOICE f="Misaki395"]
[OnName num="eMU"]
I'm scared.... All of it. I'm afraid that someone will find out.... I'm afraid of what was done to me... and that I'm distributing videos like this ......... everything."
[cpg cn=true]



Even though she had just finished bathing, Emu's body was trembling.
[cpg]

She was frightened and crying in the darkness that spread out before her.
[cpg]

That's exactly what I looked like not too long ago. ......
[cpg]

Like me, he will hate me.
[cpg]

Eventually, he will seek revenge on me.
[cpg]

Maybe she will follow in my footsteps .......
[cpg]

I am to her what Mari Hayashida is to me. ......
[cpg]

[OnName num="keisuke"]
「！！」
[cpg cn=true]



The moment I came to that thought, my body began to convulse.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misaki396"]
[OnName num="eMU"]
What's wrong?
[cpg cn=true]



Suddenly surprised, Emu stood up and reached for my body.
[cpg]

[OnName num="keisuke"]
Oh...ah ...... ah..."
[cpg cn=true]



I'm Hayashida......!
[cpg]

I'm the same ...... as that devilish woman!
[cpg]

[OnName num="keisuke"]
Ohhhhhh!
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Misaki397"]
[OnName num="eMU"]
Kay?
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[OnName num="keisuke"]
.........?
[cpg cn=true]



Emu's hand is rubbing my back .......
[cpg]

Why ......?
[cpg]

Why do you look at the demon animal that humiliated you with such ...... eyes?
[cpg]

Why are you rubbing my body......?
[cpg]

[OnName num="keisuke"]
Why don't you just run away while you have the chance!"
[cpg cn=true]



Emu shakes her head.
[cpg]

[OnName num="keisuke"]
"Are you that afraid of leakage......?"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misaki398"]
[OnName num="eMU"]
Because if I run away,...... Kay-kun, you'll die,......?
[cpg cn=true]



[OnName num="keisuke"]
"What...?
[cpg cn=true]


;//[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki399"]
[OnName num="eMU"]
"Isn't that what you meant when you said you'd end it,......?"
[cpg cn=true]



[OnName num="keisuke"]
「………」
[cpg cn=true]



I did say that a few days ago.
[cpg]

I was sure ...... that I was going to end it before the police caught up with me.
[cpg]

[OnName num="keisuke"]
"So what ...... about it. Wouldn't you be better off if I were dead?"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misaki400"]
[OnName num="eMU"]
"It's not better....... After what you've been through, you can't ...... just die and be done with it.
[cpg cn=true]



[OnName num="keisuke"]
No, why are you crying? You've been through too much with me!　And you can't ......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki401"]
[OnName num="eMU"]
You can't ...... die. That's too ...... sad.
[cpg cn=true]



[OnName num="keisuke"]
"Uh...oh ...... ahhhhh!"
[cpg cn=true]



I broke down on the spot and cried out.
[cpg]

I'm not sure what to do.
[cpg]

[OnName num="keisuke"]
'Oh, my God, I never meant to kill or hurt you!　Please forgive me!　I saw the video and assumed a lot of things on my own, and then I got so worked up that I did this to you, an innocent person!　I'm sorry!　I'm sorry!"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki402"]
[OnName num="eMU"]
"I don't know if I can forgive you for what ...... you did to Kay-kun. But ...... I'm sure you are ...... hurt and broken, so I won't ...... blame you."
[cpg cn=true]



[OnName num="keisuke"]
'Uggghhhh!　I'm sorry ...... sorry ......!"
[cpg cn=true]



Like a running memory, I saw in my mind's eye the flow of events from the bullying to the video site.
[cpg]

I was wondering how long it had been eating away at me, when it had broken ......, and why I had become like this.
[cpg]

[OnName num="keisuke"]
'Emu.......
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Misaki403"]
[OnName num="eMU"]
Misaki...my name ...... is Misaki Tokura."
[cpg cn=true]



That's when I saw her smiling for the first time ...... since I came to this room.
[cpg]

[OnName num="keisuke"]
I ......"
[cpg cn=true]



[SE f="se027"]
;//【ＳＥ】破壊音

[FO pos="2/3" time=1000]

At that moment, I heard a sound like something breaking nearby.
[cpg]

[OnName num="keisuke"]
What ......?
[cpg cn=true]



[SE f="se023"]
;//【ＳＥ】人が数人雪崩れ込む

I looked in the direction of the sound, and at the same time something came crashing through the door and avalanched in.
[cpg]

It took me a few seconds to realize it was a couple of guys, and I was pinned to the floor by their hands.
[cpg]

[OnName num="keisuke"]
What the hell?
[cpg cn=true]



[OnName num="man_1"]
What the hell, Kay?
[cpg cn=true]



[OnName num="man_2"]
You're the only one that smells like water!
[cpg cn=true]



[OnName num="keisuke"]
You're the only one who smells water!
[cpg cn=true]



[OnName num="man_3"]
I'm a watered-down friend. I'm just trying to learn from you.
[cpg cn=true]



From their words and actions, I realized that they were the ones who had gathered in "Emu's Room.
[cpg]

I'm not sure why the regulars couldn't do the same thing since I was able to identify them.
[cpg]

[OnName num="man_4"]
I really didn't think I could do something like this, so you really gave me courage.
[cpg cn=true]



I was the catalyst.
[cpg]

I was the one that called them out. I was the one that encouraged them, because I had just exposed their names!
[cpg]

[OnName num="keisuke"]
How did you do it so fast?
[cpg cn=true]



[OnName num="man_1"]
"Don't you know?　The WAKUTEKA video is a region-specific system that gathers people within your area of residence when you register for credit. However, it's a big area because it's all about Tokyo and so on.
[cpg cn=true]



[OnName num="keisuke"]
I didn't know that!　I didn't know that!
[cpg cn=true]



[OnName num="man_2"]
"Ah, you registered before it was too early. If you had been more careful, you would not have been able to see the previous rooms after you registered, or you would have been introduced to more new rooms.
[cpg cn=true]



[OnName num="keisuke"]
"Oh, no..."
[cpg cn=true]



The master never told me that.
[cpg]

No ......, on the contrary, if ......
[cpg]

[OnName num="keisuke"]
"Is the master here too?
[cpg cn=true]



[OnName num="man_1"]
What?　Master?　Are you someone's disciple?　Hyahahaha!"
[cpg cn=true]



[OnName num="keisuke"]
I'm a siren!　Handle, siren!
[cpg cn=true]



[OnName num="man_2"]
"Oh, yeah, there's that guy, too. He's just a ghost viewer who's been lurking in various rooms.
[cpg cn=true]




[VOICE f="Misaki404"]
[OnName num="misaki"]
No, no, no, no, no, no, no, no, no!
[cpg cn=true]



[OnName num="keisuke"]
No!
[cpg cn=true]



The high pitched screams made me look over and I saw Misaki being put together by a group of men.
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Misaki405"]
[OnName num="misaki"]
Stop it!
[cpg cn=true]



She was in the middle of being stripped of her clothes by the men.
[cpg]

[FO pos="2/3" time=1000]
[OnName num="keisuke"]
Stop it!
[cpg cn=true]



[OnName num="man_1"]
What?　You've got to be kidding me. You're the only one who's going to get a good look at her.
[cpg cn=true]



[OnName num="man_2"]
Hey, Emu-chan. Let us do to you what you let us do to him.
[cpg cn=true]


;//移植前シーンカット

[OnName num="keisuke"]
No, please!　Please!
[cpg cn=true]



[OnName num="man_1"]
It's your turn to watch.
[cpg cn=true]



;//ＢＫ

[SE f="se020"]
;//【ＳＥ】体当たり
[WAIT time=1000]

[SE f="se020"]
;//【ＳＥ】転倒

I hit the big guy as hard as I could, then I took a box cutter knife and swung it around like crazy.
[cpg]

[OnName num="keisuke"]
Aaaaahhh!
[cpg cn=true]



[OnName num="man_3"]
No, no, no!　Come on!
[cpg cn=true]



[OnName num="man_2"]
Oh, shit!
[cpg cn=true]



[OnName num="man_4"]
Let's get out of here!
[cpg cn=true]



[OnName num="man_1"]
Wait, wait, wait, wait...!
[cpg cn=true]



Perhaps they were scared by my crazed appearance, or perhaps they were intimidated by the knife, but the men jumped down from the second-story window and ran away.
[cpg]

I heard a scream of "Gyah!" from below, so someone must have hurt their leg.
[cpg]




[OnName num="keisuke"]
Hahahaha ...... Mi, Misaki... san."
[cpg cn=true]



I noticed that Misaki was curled up in the corner of the room, looking terrified.
[cpg]



[OnName num="keisuke"]
'......... to the police.'
[cpg cn=true]



I held out my phone, but she just shook her head violently with her tear-stained eyes closed.
[cpg]

I guess Misaki forgives them as she forgave me,.......
[cpg]

But that would be too ...... painful only for her.
[cpg]

[free time=1000]

[OnName num="keisuke"]
"Is there anyone I can talk to,......?"
[cpg cn=true]



And the existence that snatched my head.
[cpg]

I'll talk to my mentor,.......
[cpg]

He was the only person I could turn to.
[cpg]

From the computer on Misaki's desk, I start up Messenger and notice that the address has "Siren" in it.
[cpg]

So that means ...... I had sent him a secret invitation, too.
[cpg]

I didn't notice it, but maybe that was because I had gone so crazy.
[cpg]


I'm sorry. I need to talk to you urgently about a secret matter.
[cpg]



I typed the text and added a postscript saying that I would set the minimum amount, but that I would pay for it.
[cpg]

Then ......
[cpg]

＞Siren has entered the room.
[cpg]

A few minutes later, a message appeared and my mentor came to see me.
[cpg]

[BG f="b_05_7.ui" time=1000]
[WAIT time=2000]

[OnName num="siren"]
'What do you want?'
[cpg cn=true]



[OnName num="eMU"]
'I'm having a little trouble talking to you.'
[cpg cn=true]



[OnName num="keisuke"]
'Ah ......'
[cpg cn=true]



Because I accessed the site from Misaki's computer, her name was displayed as "Emu".
[cpg]

Of course, the master didn't notice this, and spoke to Emu.
[cpg]

[OnName num="siren"]
You must be referring to the recent money-making scheme.
[cpg cn=true]



[OnName num="eMU"]
I'm sorry.
[cpg cn=true]



[OnName num="siren"]
It's all right. I don't want to be too conspicuous.
[cpg cn=true]



I apologized to him for what I had done, but I wondered if he was an advisor to Misaki as well.
[cpg]

I could tell from the content that he was an advisor to Misaki.
[cpg]

[OnName num="siren"]
But what kind of windfall?　How could he suddenly start doing secret work so aggressively? Is it something that requires money?
[cpg cn=true]



[OnName num="eMU"]
No.
[cpg cn=true]



[OnName num="siren"]
No, you don't have to go that far out of the blue, just take your time.
[cpg cn=true]



I don't know what you're talking about.
[cpg]

In any case, I can't just continue the conversation pretending to be a "friend".
[cpg]

[OnName num="eMU"]
I'm Kay, but you have the wrong address.
[cpg cn=true]



[OnName num="siren"]
Kay?　What do you mean?　Why do you have access to the site at the address you gave me?
[cpg cn=true]



[OnName num="eMU"]
"Actually..."
[cpg cn=true]



I told him everything that had happened.
[cpg]

[OnName num="siren"]
"I'm in a lot of trouble.
[cpg cn=true]



[OnName num="eMU"]
『すいません』
[cpg cn=true]



There was a moment of silence.
[cpg]

[OnName num="siren"]
'What are you going to do about it?
[cpg cn=true]



[OnName num="eMU"]
I don't care what happens to me. I don't care what happens to me, so I'm going to call the police. I know it's a nuisance to the site, so I'll do whatever I can to make amends when I get out of jail.
[cpg cn=true]



[OnName num="siren"]
'You're going to get caught?
[cpg cn=true]



[OnName num="eMU"]
"That's all I've done.
[cpg cn=true]



[OnName num="siren"]
I know how you feel. I understand how you feel. I'll take care of the police report and everything else.
[cpg cn=true]



[OnName num="eMU"]
What do you mean?
[cpg cn=true]



[OnName num="siren"]
Think about how you felt when you refused to report it.
[cpg cn=true]



[OnName num="eMU"]
But...
[cpg cn=true]



[OnName num="siren"]
It doesn't matter. You don't do anything. We'll be in touch."
[cpg cn=true]

;//*test|

＞サイレンさんが退室されました
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『美咲の部屋』(夜)


[OnName num="keisuke"]
Ah!
[cpg cn=true]



I was at a loss when my master logged me out.
[cpg]


[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]


When I looked at Misaki, she was still in the same state as before, shaking slightly.
[cpg]


[OnName num="keisuke"]
"Master told me to think about how you felt when you refused to report ......
[cpg cn=true]



[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misaki427"]
[OnName num="misaki"]
"Master ......?"
[cpg cn=true]



[OnName num="keisuke"]
"It's Mr. Siren. ......
[cpg cn=true]



[OnName num="keisuke"]
"I know it's hard for you to talk about what's been done to you, but if you don't ......
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki428"]
[OnName num="misaki"]
Kay, you're going to get ...... caught, okay?
[cpg cn=true]



[OnName num="keisuke"]
I can't ......... be caught, no way."
[cpg cn=true]



I'm not sure if Misaki is saying she's not going to report me because she cares about me.
[cpg]

[OnName num="keisuke"]
Why ......
[cpg cn=true]



[FACE method="change_4" pos="2/3"]
[VOICE f="Misaki429"]
[OnName num="misaki"]
I don't ...... have a place to be either. I don't belong in class or at ...... anywhere."
[cpg cn=true]



The video was originally distributed to the upperclassmen in the class.
[cpg]

The video streaming was originally ordered by the top caste kids in the class.
[cpg]

It seems that he was told to choose whether to shoplift or earn money from videos.
[cpg]

[OnName num="keisuke"]
"So that's how it was. ......
[cpg cn=true]



[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki430"]
[OnName num="misaki"]
"So when ...... Kay told me about the bullying, I didn't feel like it was anyone else's business, and I even felt a kinship ....... I thought, "Maybe I'm not alone.... It's pathetic... ......"
[cpg cn=true]



[OnName num="keisuke"]
That's not true...!"
[cpg cn=true]



The same is true for her.
[cpg]

The most important thing to remember is that you can't just take a look at your own personal life.
[cpg]

And yet, I was!
[cpg]

[SE f="se020"]
;//【ＳＥ】床に頭ぶつける
[WAIT time=1000]

[OnName num="keisuke"]
Please forgive me!　I'm so sorry!　I didn't know ...... anything about you!"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[SE f="se020"]
;//【ＳＥ】床に頭ぶつける
[WAIT time=1000]

I continued to apologize on my knees, repeatedly slamming my forehead into the floor.
[cpg]

[SE f="se020"]
;//【ＳＥ】床に頭ぶつける
[WAIT time=1000]

I had been looking on the bright side, dancing with others, and I had acted like the devil.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Misaki431"]
[OnName num="misaki"]
I was so afraid that I would hurt myself. Don't hurt yourself...don't hurt yourself."
[cpg cn=true]



[OnName num="keisuke"]
It's okay!　If only I had broken down and disappeared sooner, I wouldn't have hurt you!
[cpg cn=true]



[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki432"]
[OnName num="misaki"]
Hey ......, tell me your name ...... your real name."
[cpg cn=true]



Misaki's cold hand touches my cheek.
[cpg]

[OnName num="keisuke"]
"Oshida...... Keisuke."
[cpg cn=true]



[FACE method="change_2" pos="2/3"]
[VOICE f="Misaki433"]
[OnName num="misaki"]
Keisuke-kun......"
[cpg cn=true]



[OnName num="keisuke"]
'.......'
[cpg cn=true]



I cried .......
[cpg]

I can't stop crying because of Misaki's warm heart that is so kind to me, such a helpless piece of trash.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Misaki434"]
[OnName num="misaki"]
I'm not going to cry anymore. It's okay ...... already."
[cpg cn=true]



[OnName num="keisuke"]
"Misaki......-san."
[cpg cn=true]



I gently put my own hand on her too cold and shaking hand.
[cpg]

I reached my other hand to the painful skin where she had been beaten, but she didn't back away.
[cpg]

[OnName num="keisuke"]
'Aren't you afraid of me ......?
[cpg cn=true]



[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki435"]
[OnName num="misaki"]
Because you already have ...... kind eyes."
[cpg cn=true]



Misaki's arms wrapped around my head and held it to her chest as she murmured this.
[cpg]

My heart was racing with a feeling that was completely different from either inferiority or lewdness.
[cpg]

[OnName num="keisuke"]
'It hurt ...... when you hit me, didn't it?
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="sMisaki016"]
[OnName num="misaki"]
Yes,......, but it's okay,......."
[cpg cn=true]



;//移植前シーンカット


;//移植前シーンカット



I stroked its soft hair and made up my mind to spend the rest of my life making amends to this angel.
[cpg]

I will no longer let anyone or my heart dance with me. ......
[cpg]

I will take whatever painful punishment I receive and I will take it well.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki476"]
[OnName num="misaki"]
I feel ...... sleepy. ......
[cpg cn=true]



As soon as she finished, Misaki began to breathe quietly in her sleep.
[cpg]

It's not hard to imagine that you haven't been able to sleep properly for the past few days,.......
[cpg]

The most important thing to remember is that you can't just go to the store and ask for a discount on a new product or service.
[cpg]

[OnName num="keisuke"]
I said, "......... I will never hurt you again."
[cpg cn=true]


;//ブラックアウト
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]


What could I do to make amends?
[cpg]

No, surely I did something that no amount of action could atone for.
[cpg]

......Then, until I was punished.
[cpg]

At least I didn't want to run away from her now.
[cpg]

It wasn't like I just wanted to be liked or anything.
[cpg]

She fell asleep. Her grip on my hand weakened.
[cpg]

I wanted to grab her hand this time, but I couldn't stay awake much longer.
[cpg]


I lay down beside her, closed my eyes, and slowly fell asleep. ......
[cpg]


;//ブラックアウト
;//エフェクト

;//スタッフロール





[STOPBGM]



[jump storage="epend.ks" target="*ending_ep004"]


*backep004|I decided I would spend the rest of my life making amends to this angel.

[STOPBGM]
[WAIT time=100]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=2100]
;//【ＢＧ】『美咲の部屋』


[BG f="b_05_7.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
;//【ＢＧ】『雑談ルーム』

A few weeks after that incident......
[cpg]

I got a call from my mentor and learned that the men in question had been arrested in a different case.
[cpg]

It seemed that it was a very serious matter, and they would not be spared from jail time.
[cpg]

[OnName num="siren"]
I heard that you stopped streaming videos. Well, that's understandable.
[cpg cn=true]



[OnName num="KEI"]
"I think I'm going to stop coming here for the last time today.
[cpg cn=true]



[OnName num="siren"]
I'm sorry to hear that.
[cpg cn=true]



[OnName num="KEI"]
'I've put you through a lot of trouble, Master. How can I apologize? Is there anything I can do?
[cpg cn=true]



[OnName num="siren"]
What can I do for you?
[cpg cn=true]



[OnName num="KEI"]
It's .......
[cpg cn=true]



[OnName num="siren"]
It's . I had a good thing going with their arrest.
[cpg cn=true]



[OnName num="KEI"]
What?　What do you mean?
[cpg cn=true]



[OnName num="siren"]
I don't have to tell you, you've never seen me before. Good day to you.
[cpg cn=true]



[OnName num="KEI"]
"Oh, Master... I'd like to keep in touch by e-mail, if you don't mind.
[cpg cn=true]



[OnName num="siren"]
I don't want to. Go eat your parfait, child.
[cpg cn=true]



＞Siren has left the room.
[cpg]

[OnName num="keisuke"]
「あ……」
[cpg cn=true]



[window target=false]
[BG f="b_08_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『美咲の部屋』


I felt a little space in my heart after the master logged out, but I went ahead and unsubscribed and erased Kay's existence from WAKUTEKA Video.
[cpg]

Master Kay was a mysterious presence from who-knows-where.
[cpg]

If we had met in the real world, would we have become friends?
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misaki477"]
[OnName num="misaki"]
"Kay, are you done with your story?"
[cpg cn=true]



[OnName num="keisuke"]
Yes.
[cpg cn=true]



Misaki called out to me from behind my computer.
[cpg]

Since then, we have ...... mysteriously started a kind of "relationship".
[cpg]

The first thing to do is to make sure that you have a good understanding of what you're doing and how to do it.
[cpg]

Because of this, I started using "tameguchi" and Misaki called me "Kei" because it was easier for her to call me.
[cpg]

I thought it was a handle that would leave a lasting impression, but she accepts it because Kay is the first person of the opposite sex she feels close to.
[cpg]


;//ブラックアウト

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=100]

The days were full of firsts, and I was bewildered.
[cpg]


I clearly remember things like my first date with Misaki and my first kiss.
[cpg]

Not that there was anything more than that yet. ......
[cpg]

It seems strange that I would have such a healthy relationship with this guy.
[cpg]

I guess all of this is because Misaki changed me.
[cpg]

I want to keep protecting Misaki and she has stayed by my side.
[cpg]


[WAIT time=100]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=2100]
;//美咲の部屋


Thanks to Misaki's presence, I was able to get back to my normal life.
[cpg]

Even though I was back in a class with no allies, my heart was not broken, and Misaki's lonely life was made a little more fulfilling by my presence.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Misaki478"]
[OnName num="misaki"]
She said, "Hey, hey, will you try this on?"
[cpg cn=true]



[OnName num="keisuke"]
What, again...?"
[cpg cn=true]



She was usually not very proactive and left it up to me when we went out or had fun, but in one respect, she began to show more initiative.
[cpg]

She enjoys making stuffed animals out of her hobby of handicrafts and putting them on me.
[cpg]

[OnName num="keisuke"]
Is this a cat?　I put it on, but what are you going to do with it?
[cpg cn=true]



[FACE method="change_6" pos="2/3"]
[VOICE f="sMisaki017"]
[OnName num="misaki"]
"Uh-huh. I wanted to play with it like a cat.
[cpg cn=true]

;//移植前シーンカット

;//●ＣＧ（美咲。猫耳をつけている）ev_25
[free time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_25_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=100]



[VOICE f="Misaki481"]
[OnName num="misaki"]
"Nnnya~...ah?"
[cpg cn=true]


[OnName num="keisuke"]
I'm going to have a baby now, .......
[cpg cn=true]


[VOICE f="Misaki500"]
[OnName num="misaki"]
?"
[cpg cn=true]



[OnName num="keisuke"]
"Do you want to make a video of the whole birth process?"
[cpg cn=true]


[VOICE f="Misaki501"]
[OnName num="misaki"]
That might be a nice thing to do. ......
[cpg cn=true]



The exciting life of Misaki and I has just begun. ......
[cpg]

[SCENE id=9]


;//美咲ＥＮＤ
[jump storage="epend.ks" target="*back_title"]


