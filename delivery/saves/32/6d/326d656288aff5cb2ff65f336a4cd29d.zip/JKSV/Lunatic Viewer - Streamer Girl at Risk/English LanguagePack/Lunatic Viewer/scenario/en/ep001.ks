

*start

;//２日目昼
*select03_9|話題を集めるために外へ

;#################################################
*Ep001|話題を集めるために外へ
;#################################################

[SCENE id=1]



[stflag Jump_flg = 0]

[if exp={getFlagValue("Jump_flg") == 0 }]


[stflag Jump_flg = 1]

;//フラグ　初期化
[stflag Cha1flg_A = 0]
[stflag Cha1flg_B = 0]
[stflag Cha1flg_C = 0]

[stflag Cha2flg_A = 0]
[stflag Cha2flg_B = 0]
;//[stflag Cha2flg_C = 0]
[stflag Cha3flg_A = 0]
[stflag Cha3flg_B = 0]
[stflag Cha3flg_C = 0]
[stflag Cha3flg_D = 0]

[stflag Cha1flg_la = 0]
[stflag Cha2flg_la = 0]
[stflag Cha3flg_la = 0]

[stflag Cha1flg_lb = 0]
[stflag Cha2flg_lb = 0]
[stflag Cha3flg_lb = 0]
[stflag Cha1flg_lc = 0]

[stflag Evelflg = 0]
[stflag Bad_flg = 0]

[endif]


;//ブラックアウト
;//エフェクト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公（啓介）の部屋』

[OnName num="keisuke"]
'Is it noon already...'
[cpg cn=true]



Without dreaming, it feels like a momentary event until I fall asleep and wake up.
[cpg]

I wonder if this is how I will repeat sleeping and waking up and rotting away....
[cpg]

......No, no, no, no.
[cpg]

I have to rehabilitate myself with the goal of making a comeback as a human being.
[cpg]

[OnName num="keisuke"]
Now... what shall I do today?
[cpg cn=true]



;//■選択肢（２日目昼）四択
[switch]
[case "Go to the grocery store"]
	[swap]
	[jump target="*select05_1"]
[case "Go to a bookstore"]
	[swap]
	[jump target="*select05_2"]
[case "I'm going to a cafe."]
	[swap]
	[jump target="*select05_3"]
[case "Go to the park"]
	[swap]
	[jump target="*select05_4"]
[endswitch]

1, Go to the general store;// (*MISAKI b)
2、Go to the bookstore;// (★Mari b Acquisition)
3、Go to the cafe;// (Get ◆Eye Flag B)
4、Go to the park;// (*Weakness +1)

;//==========================
;//a,雑貨屋
*select05_1|話題を集めるために外へ

[stflag Cha1flg_lb = 1]

[OnName num="keisuke"]
Let's go to the grocery store.
[cpg cn=true]



In a general store, you can get information about what girls like.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『雑貨屋』



[OnName num="staff"]
Welcome, please take your time."
[cpg cn=true]



The clerk cheerfully greeted me as I entered the store, but I didn't care and went to the back to look at the various items.
[cpg]

There were mugs with Scandinavian or some other character, pastel-colored towels, and so on.
[cpg]

At that moment, a woman with her two friends, probably office workers on their way home from lunch, came into the store, giggling.
[cpg]

[OnName num="glasses_office_worker"]
They said, "Look, look, aren't these cute?
[cpg cn=true]



[OnName num="short_hair_office_worker"]
"It's a stuffed animal. It's a stuffed animal, and it's wearing clothes.
[cpg cn=true]



I don't like animals wearing clothes, so I don't understand why stuffed animals are wearing clothes.
[cpg]

But women seem to like that kind of thing.
[cpg]

[OnName num="glasses_office_worker"]
She said, "You know, you can buy just the clothes.
[cpg cn=true]



[OnName num="short_hair_office_worker"]
"Oh, so you can change the clothes?"
[cpg cn=true]



[OnName num="staff"]
There are various kinds of clothes, and people who enjoy sewing sometimes make matching clothes for their own children.
[cpg cn=true]



[OnName num="short_hair_office_worker"]
Wow, that's amazing!
[cpg cn=true]



That's amazing," she said.
[cpg]

But what are they going to do if they wear the same clothes as their stuffed animals?
[cpg]

[OnName num="glasses_office_worker"]
People who like handicrafts find that kind of thing therapeutic, don't they?
[cpg cn=true]



I don't know if that's healing...all I can think is that it makes my eyes tired.
[cpg]

The three women started to get excited, and I, feeling a little out of place, quietly left the restaurant.
[cpg]

[jump target="*2day_night"]
;//==========================
;//b,本屋（★麻里b）
*select05_2|話題を集めるために外へ

[stflag Cha2flg_lb = 1]

[OnName num="keisuke"]
I thought, "Let's go to a bookstore.
[cpg cn=true]



I could find out what's popular on the Internet, but I felt like I was in the underground.
[cpg]

I thought that magazines would be the best way to get a sense of reality.
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『本屋』

I went into the bookstore and looked for something interesting in the magazine section.
[cpg]

[OnName num="keisuke"]
What is this?
[cpg cn=true]



I wondered, "What the heck is this?
[cpg]

I took a closer look and found that it was a fashion magazine with a freebie inside.
[cpg]

On the cover, it said, "This season's hottest makeup bag!
[cpg]

[OnName num="keisuke"]
Who is Mariane?
[cpg cn=true]



The bag had a flower pattern that I thought was too toxic and a little creepy.
[cpg]

I wondered if women would like this kind of thing.
[cpg]

I picked up the magazine that I could browse through and flipped through it.
[cpg]

I picked up a copy of the magazine that was available for browsing next to it and flipped through it.
[cpg]

[OnName num="keisuke"]
Oh... Marian of Marian Joyce.
[cpg cn=true]



That's a blonde-haired, blue-eyed supermodel that even I know.
[cpg]

I have seen her featured on a variety of TV programs, saying that she is a celebrity model.
[cpg]

She is indeed a beautiful woman with an incredible style, just like a video game character.
[cpg]

[OnName num="keisuke"]
I felt like a dwarf when I stood next to her.
[cpg cn=true]



Feeling defeated, I left the restaurant with a sinking feeling.
[cpg]

;//２日目夜へ
[jump target="*2day_night"]
;//==========================
;//c,カフェ（▲瞳フラグＢ）
*select05_3|話題を集めるために外へ

[stflag Cha3flg_B = 1]

[OnName num="keisuke"]
I need coffee..."
[cpg cn=true]



Since I woke up in the light of day, I decided to have a cup of coffee to wake up.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『カフェ』



I came to the café and ordered a cappuccino, and spent a peaceful moment.
[cpg]

Well...I was so nervous that I had to recite "cappuccino cappuccino" over and over before ordering, but I'll leave that aside.
[cpg]

Anyway, if you take away the moment when I was sipping from the steaming cup like this, I would have been no different from a person in the rear .......
[cpg]

It's a time when I would normally be studying in my school building, but in my condition, it can't be helped .......
[cpg]

[OnName num="keisuke"]
I'm not sure what I'm supposed to be doing.
[cpg cn=true]



The first thing you need to do is to look around you, and you will see a man working on his computer and another man sipping coffee while writing something in his notebook.
[cpg]

The other middle-aged women who were on their way home from shopping and taking a breather made me feel that they are all really fulfilled, unlike me.
[cpg]

I can't wait to get back to true fulfillment myself....
[cpg]

I was not so determined, but I thought so and drank my cappuccino and went to the cash register with the slip.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hitomi056"]
[OnName num="sober_staff"]
Four hundred... eighty... yen... that's all..."
[cpg cn=true]



[OnName num="keisuke"]
Eh...?"
[cpg cn=true]



I couldn't understand the voice of the plain clerk at the cash register, so I involuntarily asked back.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi057"]
[OnName num="sober_staff"]
It will be...four hundred...eighty...yen..."
[cpg cn=true]



[OnName num="keisuke"]
Ah...yo, 480........."
[cpg cn=true]



The clerk, a plain woman with a strange air of tension about her, dragged me along and I stammered too.
[cpg]

[OnName num="keisuke"]
I was so nervous that even I stammered.
[cpg cn=true]



Thanks to this, my hand slipped as I tried to take out the money, and I almost lost the coins.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Hitomi058"]
[OnName num="sober_staff"]
Oh!
[cpg cn=true]



[OnName num="keisuke"]
Ah!
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi059"]
[OnName num="sober_staff"]
Aah!
[cpg cn=true]



The clerk and I quickly reached for the coins that were about to fall out of my hand, and as a result, my hand, coincidentally, ended up grabbing the clerk's hand.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Hitomi060"]
[OnName num="sober_staff"]
"Hey...hey...!"
[cpg cn=true]



[OnName num="keisuke"]
I'm sorry.
[cpg cn=true]



[FACE method="change_6" pos="2/3"]
[VOICE f="Hitomi061"]
[OnName num="sober_staff"]
I'm soooooooooooooooooooooooooooooooooooooooooooo!
[cpg cn=true]



[OnName num="keisuke"]
I'm sorry!　Oh, your change is fine!"
[cpg cn=true]



The clerk's face instantly turned red, and I was so flustered that I ran out of the café without picking up the coins I had scattered on the counter.
[cpg]

I felt like a pervert....
[cpg]

But why did I have to react like that even though it was an accident?
[cpg]

Or...was I that creepy?
[cpg]

[OnName num="keisuke"]
.........Ugh.
[cpg cn=true]



My chest hurts. The wound was gouged out.
[cpg]

I'm not sure what to do....
[cpg]

[jump target="*2day_night"]
;//==========================
;//d,公園（★凶＋１）
*select05_4|話題を集めるために外へ

[stflag Evelflg=-1]

[OnName num="keisuke"]
"Let's go to the park and eat some bread..."
[cpg cn=true]



Since it was a sunny day, I thought, "Let's go out in the sun like a human being.
[cpg]

I bought some bread at a convenience store and headed to the park.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『公園』




[SE f="se002"]
;//【ＳＥ】子供達の遊ぶ声

[OnName num="keisuke"]
Moshamosha ......
[cpg cn=true]



After all, melon bread is delicious.
[cpg]

I sat down on a park bench and had a late lunch.
[cpg]

[OnName num="keisuke"]
Moshamosha...ng, keho keho!　Kehokehokehokehokehokehokehokehokehokehokehokehoke!"
[cpg cn=true]



I slapped myself on the chest, choking as the bread took all the moisture out of my mouth.
[cpg]

[OnName num="unknown"]
I slapped myself on the chest.　Here, if you want.
[cpg cn=true]



[OnName num="keisuke"]
"What...?"
[cpg cn=true]



I looked up in surprise to see a strange middle-aged man standing in front of me.
[cpg]

[OnName num="keisuke"]
I looked up in surprise to see a strange middle-aged man standing there.
[cpg cn=true]



[OnName num="middle_aged_man"]
It's okay. I bought it by mistake.
[cpg cn=true]



[OnName num="keisuke"]
Keho-keho-ho!　Well, then... sorry.
[cpg cn=true]



I was in so much pain that I decided to accept the help and opened the coffee can.
[cpg]

When I was finally comfortable, I reached into my pocket to pay for it.
[cpg]

[OnName num="middle_aged_man"]
"That's okay, that's enough. You're still in school, right?"
[cpg cn=true]



[OnName num="keisuke"]
"Yeah, but..."
[cpg cn=true]



It's kind of embarrassing to accept charity from a stranger.
[cpg]

[OnName num="middle_aged_man"]
"That's good. Put it in your piggy bank when you get home.
[cpg cn=true]



[OnName num="keisuke"]
Okay, then...yes. Thank you very much. Thank you very much.
[cpg cn=true]



Since it looked like he was not going to accept the money, I had no choice but to bow to the middle-aged man and thank him.
[cpg]

[OnName num="middle_aged_man"]
I was so glad that he was so honest. I am so glad to hear you thank me like that for something as trivial as a canned coffee.
[cpg cn=true]



He was a middle-aged man in a suit, the kind of man you would see anywhere.
[cpg]

He was a small, fat, middle-aged man in an ordinary suit with an attempt at resistance, perhaps a little thinning hair on his head.
[cpg]

[OnName num="middle_aged_man"]
He was a little too short for a girl your age. That's all they do.
[cpg cn=true]



[OnName num="keisuke"]
"Huh..."
[cpg cn=true]



[OnName num="middle_aged_man"]
"You know the story of the legendary black guy?　He told the women working in the cabarets.
[cpg cn=true]



[OnName num="middle_aged_man"]
He told them, "When a customer gives you a thousand yen, you should be so happy that you overreact. If they are so happy with 1,000 yen, think how happy they will be if you give them 10,000 yen.
[cpg cn=true]


[OnName num="keisuke"]
「はあ…」
[cpg cn=true]



The middle-aged man sat down beside me and told me such a story.
[cpg]

[OnName num="middle_aged_man"]
I wish all the women of today could hear this story.
[cpg cn=true]



[OnName num="keisuke"]
He said, "Well, I'm sorry. I've got to go.
[cpg cn=true]



I was now too much of a stranger to have a long conversation with him.
[cpg]

I had to leave early because my back was starting to sweat.
[cpg]

[OnName num="middle_aged_man"]
I said, "Yeah, I'm sorry... Sorry..."
[cpg cn=true]



As I left, I noticed that the stranger looked strangely sad, but I quickly left the place.
[cpg]

;//２日目夜へ
[jump target="*2day_night"]
;//==========================
;//２日目夜
*2day_night|話題を集めるために外へ



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公（啓介）の部屋』(夜)


After dinner, I sat down in front of the computer.
[cpg]

;//パソコン画面：ワクテカ動画
Emu's Room": Opens today at 7:00 p.m.[r]
Lian's World": Opens today at 8pm[r]
H Castle": Opens today at 10:00 p.m.
[cpg]

[OnName num="keisuke"]
Now, which room shall we go to today?
[cpg cn=true]


;//■選択肢（２日目夜）
[switch]
[case "Emu's Room"]
	[swap]
	[jump target="*select06_1"]
[case "Lian's World"]
	[swap]
	[jump target="*select06_2"]
[case "H Castle"]
	[swap]
	[jump target="*select06_3"]
[endswitch]

1、Gemu's room;// (*MISAKI b) (content changes depending on presence/absence)
2，Lian's World;// (*Mari b. Contents change depending on presence or absence)
3，H Castle;// （◆ Eye Flag B (Contents change depending on presence or absence of ◆Hitomi flag B)
;//=============================================================================
;//１，ぇむの部屋
*select06_1|話題を集めるために外へ

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ぇむの部屋』

＞ケイさんが入室されました
[cpg]

[FG f="CHA01_p5_02_a.ui" method="change_2"  pos="3/7" time=800]
[VOICE f="Misaki032"]
[OnName num="eMU"]
Kay, you're here again. Good evening.
[cpg cn=true]



[OnName num="KEI"]
Good evening.
[cpg cn=true]



Ah...what a boring reply, I think to myself.
[cpg]

I think to myself, what a boring reply.
[cpg]

[OnName num="KEI"]
Is it possible that I'm the only one in the room right now?
[cpg cn=true]



I ask, noticing that the number of participants in the chat box is 1.
[cpg]
[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki033"]
[OnName num="eMU"]
I ask, noticing that the number of participants is 1 in the chat box. I'm here a little earlier than usual today.　Let's talk alone until you all get here.
[cpg cn=true]



Wow...how nice.
[cpg]

Emu-chan's smile on the screen is now directed only at me.
[cpg]

[OnName num="KEI"]
Let's talk to each other as a friend, Emu-chan.
[cpg cn=true]



At my offer, Emu-chan tilted her head and hesitated a little.
[cpg]

[OnName num="KEI"]
She tilted her head and hesitated a little.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki034"]
[OnName num="eMU"]
Is that so?　Oh, I mean...is that so?　So you're a student then, Kay?"
[cpg cn=true]



[OnName num="keisuke"]
'.........'
[cpg cn=true]



I hesitated a little at that question, but that's the good thing about text chat.
[cpg]

[OnName num="KEI"]
I'm not sure if it's a good idea or not.
[cpg cn=true]



I typed in without any hesitation.
[cpg]

I'm sure this would not have happened in a voice chat room.
[cpg]

[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki035"]
[OnName num="eMU"]
I felt a sense of familiarity.　Everyone else seems to be working."
[cpg cn=true]



I see....
[cpg]

I mean, after all, you already talk about such things with the regulars and get along with them to some extent.
[cpg]

[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki036"]
[OnName num="eMU"]
I'm not sure what to say, but I'm sure you've already talked about such things with the regulars and gotten to know them well.　Uniform?
[cpg cn=true]



[OnName num="KEI"]
Uniform. Blazer. What about you, Emu-chan?
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki037"]
[OnName num="eMU"]
Uniforms at my school, too. I wear sailor-fuku.
[cpg cn=true]



I see...Emu-chan goes to a place with sailor uniforms.
[cpg]

I wonder where that is...?
[cpg]

[OnName num="KEI"]
Sailor uniforms have a different atmosphere depending on the color of the ribbon or scarf or whatever it is that's waving around.
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki038"]
[OnName num="eMU"]
I guess so. The color is different depending on the grade at my school. I'm in the second grade, so it's red.
[cpg cn=true]



Hmmm......... isn't that kind of thing unusual?
[cpg]

It's common to have different colors of school shoes for different grades, but a tie in a different color is ...... where?
[cpg]

＞Mr. Bear has entered the room.
[cpg]

[OnName num="kumachan"]
"Good morning.
[cpg cn=true]



[OnName num="keisuke"]
"...... tsk."
[cpg cn=true]



I was going to ask for more details, but more and more regulars started to gather, starting with Lord Bear.
[cpg]

So I decided to refrain from speaking for a bit and observe Kumu-chan's room.
[cpg]

[OnName num="keisuke"]
Where should I look..."
[cpg cn=true]


;//■選択肢_夜_２日目_ぇむ

[stflag mselecter12_cnt = 2]

*mselecter02|話題を集めるために外へ
;//今回は回数ではなく「ドアで強制移行」

[if exp={getFlagValue("mselecter12_cnt") == 0}]
[jump target="*2niend_em"]
[endif]

[switch]
[case "Emu's face"]
	[swap]
	[jump target="*Msel2_01"]
[case "Emu's chest"]
	[swap]
	[jump target="*Msel2_02"]
[case "Emu's head"]
	[swap]
	[jump target="*Msel2_03"]
[case "窓"]
	[swap]
	[jump target="*Msel2_04"]
[case "ベッド"]
	[swap]
	[jump target="*Msel2_05"]
[case "Stuffed animal"]
	[swap]
	[jump target="*Msel2_06"]
[case "The door"]
	[swap]
	[jump target="*Msel2_07"]
[endswitch]
;//==========================
;//ぇむの顔
*Msel2_01|話題を集めるために外へ

Emu-chan's face.
[cpg]

Her carefree smile is the cutest.
[cpg]

It's like she's a purist.
[cpg]

[jump target="*mselecter02"]
;//==========================
;//ぇむの胸
*Msel2_02|話題を集めるために外へ

It's so big...
[cpg]

She must have stiff shoulders or something.
[cpg]

[jump target="*mselecter02"]
;//==========================
;//ぇむの頭
*Msel2_03|話題を集めるために外へ

I wonder what kind of shampoo she uses to make her hair so beautiful.
[cpg]

Too bad I can't smell it through the screen.
[cpg]

[jump target="*mselecter02"]
;//==========================
;//窓
*Msel2_04|話題を集めるために外へ

It's nighttime, so I can't see anything outside.
[cpg]

I don't even know what floor my room is on.
[cpg]

[jump target="*mselecter02"]
;//==========================
;//ベッド
*Msel2_05|話題を集めるために外へ

You must sleep here everyday....
[cpg]

I wonder if you could stream a video of your sleeping face....
[cpg]

[jump target="*mselecter02"]
;//==========================
;//ぬいぐるみ
*Msel2_06|話題を集めるために外へ
Did you buy this stuffed animal yourself?
[cpg]

Or was it a gift from someone else?
[cpg]

Don't tell me they are all handmade or something....
[cpg]

[jump target="*mselecter02"]
;//==========================
;//ドア
;//※ドアをクリックしたら他を見ていなくても進行
*Msel2_07|話題を集めるために外へ

It would be embarrassing if parents or others came in during the delivery.
[cpg]

I often see a pattern in foreign videos where parents come in when they are dancing or something....
[cpg]



[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki039"]
[OnName num="eMU"]
'Oh no, Mr. Dark Pot Inquisitor, you're awful!
[cpg cn=true]



[OnName num="aaa"]
"Wahahaha, nice Inquisitor!
[cpg cn=true]



At that time, Emu-chan started to speak rather loudly, and I couldn't help but speak up.
[cpg]

[OnName num="KEI"]
I was surprised to see Emu-chan's loud voice at that moment, so I spoke up.
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki040"]
[OnName num="eMU"]
I said, "Oh, yes. "Oh, yes, I'm fine. The family room is quite far away from the house, so we can't hear each other's daily life noises at all. Even with music playing, it's usually quiet as long as the door is not open.
[cpg cn=true]



[OnName num="oac"]
Wow, you must have a big house!　My house has thin walls, so I can hear everything.
[cpg cn=true]



It really is.
[cpg]

Emu-chan's house is big and the walls are thick....
[cpg]

;//★美咲b　がある場合→;//★美咲b　へ進行
[if exp={getFlagValue("Cha1flg_lb") == 1}]
[jump target="*misa_lb"]
[endif]

;//★美咲bがない場合→;//２日目夜ぇむ終了　へ進行
;//２日目夜ぇむ終了

Well, after all that happened, it was nice to have a little conversation with Emu today.
[cpg]

The end.
[cpg]

;//３日目昼へ
[jump target="*day2_end"]
;//==========================
;//★美咲b
*misa_lb|話題を集めるために外へ

＞Kanata-san has entered the room.
[cpg]

[OnName num="kanata"]
"Hello.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki041"]
[OnName num="eMU"]
"Good evening, Kanata-kun. Long time no see."
[cpg cn=true]



Then a guy whose name I had never seen before came in, but from the way Emu-chan looked, he seemed to be a regular.
[cpg]

[OnName num="kanata"]
He said, "I was on a business trip for a while. I was on a business trip for a bit, and I saw the cosplayers you mentioned on the trip.
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki042"]
[OnName num="eMU"]
I saw the costume you were talking about on your business trip.　I'm so jealous.
[cpg cn=true]



[OnName num="oac"]
He said, "You've been talking a lot, Kanata-dono. What are you talking about?
[cpg cn=true]



[OnName num="kanata"]
"Well, I'm talking about a game industry event where I saw a companion in a character costume.
[cpg cn=true]



[OnName num="KEI"]
What game?
[cpg cn=true]



[OnName num="kanata"]
What game is it?　Nice to meet you?
[cpg cn=true]



[OnName num="KEI"]
I'm sorry. My name is Kay.
[cpg cn=true]



[OnName num="kanata"]
I'm Kanata. Nice to meet you. So, to get back to the story, I'm the heroine cosmetics of "The Fierce Demon 2".
[cpg cn=true]



[OnName num="yaminabebugyo"]
"Oh, I know that one. I saw it in a magazine.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki043"]
[OnName num="eMU"]
I saw it in a magazine. I like it. I have the old one..." "What...?
[cpg cn=true]



I have the old one.
[cpg]

[OnName num="aaa"]
What?
[cpg cn=true]



[OnName num="oac"]
Boo-hoo!
[cpg cn=true]



I guess we all feel the same way....
[cpg]

[OnName num="kumachan"]
"Emu-chan, do you have the heroine cosplay of "The Fierce Demon"?
[cpg cn=true]


[FACE method="change_5" pos="3/7"]
Emu-chan's expression turned into a "Oh no..." expression, but it was too late.
[cpg]

[OnName num="aaa"]
I want to see that!　I want to see that!
[cpg cn=true]



[OnName num="yaminabebugyo"]
I'd love to see that! I'd love to see it.
[cpg cn=true]



[OnName num="oac"]
"I want to see it, I want to see it, I want to see it, I want to see it!
[cpg cn=true]



[OnName num="KEI"]
I want to see it, I want to see it, I want to see it!
[cpg cn=true]



I want to see it!" "I want to see it!" "I want to see it!
[cpg]

[OnName num="KEI"]
'I mean, did you make that cosplay yourself?
[cpg cn=true]


[FACE method="change_6" pos="3/7"]
[VOICE f="Misaki044"]
[OnName num="eMU"]
"Uh...yeah."
[cpg cn=true]



[OnName num="KEI"]
I'm sure if you're good at handicrafts, you can do such things. I'm sure sewing is very relaxing, isn't it?
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki045"]
[OnName num="eMU"]
Yes...sewing has that effect on me. Kei-kun, you understand me, don't you..." "Yes.
[cpg cn=true]



I feel like Emu-chan is turning towards me and opening her heart to me!　I'm delusional, but....
[cpg]

[OnName num="KEI"]
I'm delusional, but.... So I'd like to see the results of that healing.
[cpg cn=true]


[FACE method="change_6" pos="3/7"]
[VOICE f="Misaki046"]
[OnName num="eMU"]
'Yeah...but I'm embarrassed...'
[cpg cn=true]



[OnName num="kanata"]
'You say so, but it would be a waste if you don't wear it even though you have it.
[cpg cn=true]



[OnName num="KEI"]
"That's right, that's right.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki047"]
[OnName num="eMU"]
I wonder if that's true. Then...just wait a little while..."
[cpg cn=true]



Emu-chan stood up after saying that and disappeared off the screen.
[cpg]

[OnName num="aaa"]
Muhu, I'm so excited!
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
;//エフェクト

A few minutes later......
[cpg]

[VOICE f="Misaki048"]
[OnName num="eMU"]
'How about...?
[cpg cn=true]



;//ぇむ、コスプレ衣装装着
;//●ＣＧ（美咲コスプレ）ev_06


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=100]

;//※場合によってはプレイ追加
[OnName num="oac"]
 "Boooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo! !! 』\
[cpg cn=true]



[OnName num="keisuke"]
'Ka...kawae ......'
[cpg cn=true]



Emu-chan, wearing the game heroine's outfit, was incredibly attractive, helped by her plain cuteness.
[cpg]

This is already several times more beautiful than the game picture!
[cpg]

[OnName num="kanata"]
I love it.... Would you like to work as a companion?
[cpg cn=true]



[VOICE f="Misaki049"]
[OnName num="eMU"]
"No, I won't!"
[cpg cn=true]



Her shy expression is also irresistible....
[cpg]

[OnName num="aaa"]
I love it! I want you to do that!　Do that one!　The movie scene where the princess knight is cornered!
[cpg cn=true]



[VOICE f="Misaki050"]
[OnName num="eMU"]
"What, you're going to imitate that...eeeeeeeeeeeee?
[cpg cn=true]



I played that game too...
[cpg]

I played that game too.......the part where the long movie plays when Shayla, the princess knight, is cornered and captured by the enemy.
[cpg]

[OnName num="KEI"]
I want to see it! I want to see it!
[cpg cn=true]



[OnName num="kanata"]
I want to see it even if I have to pay for it!　I'd pay money to see it!
[cpg cn=true]



[VOICE f="Misaki051"]
[OnName num="eMU"]
"Oh, no, you don't have to go that far. ......"
[cpg cn=true]



Emu-chan was puzzled when Kanata said "secret," and then put her hand on her chest as if she had made up her mind.
[cpg]

And...
[cpg]

;**【ＣＧ】 ev_06_a ***********************
[CG id=3 index=1 time=100]
;***************************************
[WAIT time=100]

[VOICE f="Misaki052"]
[OnName num="eMU"]
I'll give you everything I can. Now, now, do as you please!
[cpg cn=true]



[OnName num="keisuke"]
Oh, oh..."
[cpg cn=true]



Emu-chan utters a line from the game.
[cpg]

Then the regulars say the villain's lines.
[cpg]

[OnName num="kanata"]
The regulars then say the villain's line: "Good spirit, then, let all be exposed before my eyes. Then lay it all out before my eyes, and take away your tacky armor.
[cpg cn=true]



Geeeeeeeee ......
[cpg]

The armor part, of course, is not made of steel, but comes off with a zipper.
[cpg]


The breast parts split to the left and right, exposing her ample cleavage.
[cpg]


[OnName num="oac"]
'Bwheeee!
[cpg cn=true]



[VOICE f="Misaki055"]
[OnName num="eMU"]
Kill me.
[cpg cn=true]



[OnName num="keisuke"]
'Kuhhhh......'
[cpg cn=true]



This is...amazing.
[cpg]

I was attacking the princess knight in my head. The chat was quiet, as if the regulars were the same.
[cpg]

[OnName num="kanata"]
Well, this is where the main character intervenes and saves the princess.
[cpg cn=true]


;**【ＣＧ】 ev_06_0 ***********************
[CG id=3 index=0 time=100]
;***************************************
[WAIT time=100]


[VOICE f="Misaki056"]
[OnName num="eMU"]
'Hey, something ...... um... didn't you guys lose your image...?　Are you okay?
[cpg cn=true]



[OnName num="aaa"]
"It's okay"
[cpg cn=true]



[OnName num="yaminabebugyo"]
"Just hold it, hold it, hold it."
[cpg cn=true]



[VOICE f="Misaki057"]
[OnName num="eMU"]
Still...?
[cpg cn=true]



[OnName num="oac"]
A little more.
[cpg cn=true]



She was embarrassed. She is not the only one who is upset.
[cpg]

[OnName num="KEI"]
I'm not the only one who's upset.
[cpg cn=true]



[VOICE f="Misaki058"]
[OnName num="eMU"]
I'm not amazing at all. But I've been looking at fashion magazines and learning a bit about regular clothes, and I'm thinking of making some everyday clothes someday.
[cpg cn=true]



[OnName num="KEI"]
I'm thinking of making some everyday clothes someday.　Fashion magazines...' 'That's something I have nothing to do with.
[cpg cn=true]



I'm not even sure what I'm supposed to be doing.
[cpg]

[OnName num="oac"]
'Bwahhhhhh...'
[cpg cn=true]



I'm still working on it...
[cpg]

[OnName num="KEI"]
'I'd better be off now...'
[cpg cn=true]


Let's go to bed today.
[cpg]


;//３日目昼へ
[jump target="*day2_end"]
;//=============================================================================
;//２，リアンズワールド
*select06_2|話題を集めるために外へ

[OnName num="keisuke"]
'We need to get a hold of Hayashida's weakness. ......
[cpg cn=true]



I just can't suppress my vengeance at night.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『リアンズワールド』

＞ケイさんが入室されました
[cpg]

[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="3/7" time=800]

[VOICE f="Mari048"]
[OnName num="Lian"]
"Yoo-hoo, Kay-chan ♥"
[cpg cn=true]



[OnName num="KEI"]
Good evening.
[cpg cn=true]



[OnName num="john_doe0624"]
What color are your pants today?
[cpg cn=true]



[OnName num="KEI"]
"What color are your pants today?
[cpg cn=true]



[OnName num="john_doe0624"]
I'm sorry.
[cpg cn=true]



......... Can't even get a joke in this room?
[cpg]

I mean, suddenly it's a joke.
[cpg]

[FACE method="change_6" pos="3/7"]
[VOICE f="sMari005"]
[OnName num="Lian"]
"You want to know?"
[cpg cn=true]



[OnName num="john_doe0110"]
I want to know!　Tell me!
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="sMari006"]
[OnName num="Lian"]
What shall we do?
[cpg cn=true]



Hayashida was agitating Nanashi and the others.
[cpg]

I can't keep up with this kind of thing.
[cpg]

I abandoned the chat and ransacked Hayashida's room.
[cpg]

;//■選択肢_夜_２日目_リアン

[stflag Rselecter22_cnt = 2]

*Rselecter02|話題を集めるために外へ

[if exp={getFlagValue("Rselecter22_cnt") == 0}]
[jump target="*2niend_ri"]
[endif]

[switch]
[case "Leanne's face"]
	[swap]
	[jump target="*Rsel2_01"]
[case "Leanne's chest"]
	[swap]
	[jump target="*Rsel2_02"]
[case "Leanne's head"]
	[swap]
	[jump target="*Rsel2_03"]
[case "The window"]
	[swap]
	[jump target="*Rsel2_04"]
[case "The bed"]
	[swap]
	[jump target="*Rsel2_05"]
[case "Table"]
	[swap]
	[jump target="*Rsel2_06"]
[case "Closet"]
	[swap]
	[jump target="*Rsel2_07"]
[case "Leanne"]
	[swap]
	[jump target="*Rsel2_01"]
[endswitch]

;//==========================
;//リアンの顔
*Rsel2_01|話題を集めるために外へ

[stflag Rselecter22_cnt=-1]

The flakey makeup.
[cpg]

I hate fake eyelashes and shiny lips.
[cpg]

[jump target="*Rselecter02"]
;//==========================
;//リアンの胸
*Rsel2_02|話題を集めるために外へ

[stflag Rselecter22_cnt=-1]

This guy must be an A-cup.
[cpg]

If I had the balls, I could have made fun of her in class...
[cpg]

[jump target="*Rselecter02"]
;//==========================
;//リアンの頭
*Rsel2_03|話題を集めるために外へ

[stflag Rselecter22_cnt=-1]

I wonder how much time he spends taking care of them, they are perfectly shaped.
[cpg]

I wonder if he uses a hair dryer or something to pinch and twist them.
[cpg]

[jump target="*Rselecter02"]
;//==========================
;//窓
*Rsel2_04|話題を集めるために外へ

[stflag Rselecter22_cnt=-1]

Someone please break in here and blow this woman away....
[cpg]

[jump target="*Rselecter02"]
;//==========================
;//ベッド
*Rsel2_05|話題を集めるために外へ

[stflag Rselecter22_cnt=-1]

What are you going to do when you go to bed with all this stuff on the floor?
[cpg]

Throw it downstairs and put it back up again when you wake up...?
[cpg]

Useless!
[cpg]

[jump target="*Rselecter02"]
;//==========================
;//テーブル（１回目）
*Rsel2_06|話題を集めるために外へ

[stflag Rselecter22_cnt=-1]

Mirrors, pouches, and cosmetics are placed in a mess.
[cpg]

Lotion... I can only make out the lotion... but what are the rest of the bottles?
[cpg]

[jump target="*Rselecter02"]
;//==========================
;//クローゼット
*Rsel2_07|話題を集めるために外へ

[stflag Rselecter22_cnt=-1]

Is she buying clothes with the money she's raking in from the Secret?
[cpg]

Bloody hell....
[cpg]

[jump target="*Rselecter02"]
;//==========================
;//２日目夜リアン終了
*2niend_ri|話題を集めるために外へ

;//★麻里bがある場合→;//★麻里b　へ
;//★麻里bがない場合　２箇所クリック後→;//２日目夜リアン終了　へ進行

[if exp={getFlagValue("Cha2flg_lb") == 1}]
[jump target="*mari_lb"]
[endif]

[FACE method="change_7" pos="3/7"]
[VOICE f="Mari051"]
[OnName num="mari"]
Ah, I'm kind of tired today. See you later."
[cpg cn=true]



[OnName num="john_doe1201"]
'Eh!　Where's your secret?'
[cpg cn=true]



[FACE method="change_1" pos="3/7"]
[VOICE f="Mari052"]
[OnName num="mari"]
"No, not today. Do it somewhere else.
[cpg cn=true]



[OnName num="john_doe0516"]
I came all this way!
[cpg cn=true]



[FACE method="change_3" pos="3/7"]
[VOICE f="Mari053"]
[OnName num="mari"]
"Shut up. I told you I don't do that.
[cpg cn=true]



;//画面単色に
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[OnName num="keisuke"]
What a woman. ......
[cpg cn=true]



I didn't see him, but I guess his conversation with Nanashi had offended him somehow, and Hayashida closed the room.
[cpg]

I was so frustrated that I couldn't accomplish anything, I started up the game.
[cpg]

[OnName num="keisuke"]
I'm going to play and then go to bed..."
[cpg cn=true]



Oh, that's so annoying.
[cpg]

;//３日目昼へ
[jump target="*day2_end"]
;//==========================
;//★麻里b
*mari_lb|話題を集めるために外へ
;//テーブル（２回目）

I look closer and see an accessory I saw in a magazine lying on the table.
[cpg]

It's that model who was wearing this...
[cpg]

[OnName num="KEI"]
'You have the same accessory as Marian Joyce, don't you?
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari054"]
[OnName num="Lian"]
'Wow, that's amazing!　Did you notice?
[cpg cn=true]



Hayashida bites my casual remark.
[cpg]

[FACE method="change_1" pos="3/7"]
[VOICE f="Mari055"]
[OnName num="Lian"]
Marianne is so beautiful, isn't she?　I want to be like her!
[cpg cn=true]



Is he an idiot?
[cpg]

Compared to that model, she is inferior in every way.
[cpg]

I can see a future where she spends millions of dollars on plastic surgery and fails.
[cpg]

[OnName num="keisuke"]
"Hmm...?　Marian?
[cpg cn=true]



Mari...Anne...Ma...... lian...Mari Hayashida...Mari....
[cpg]

[OnName num="keisuke"]
Bwahahaha!"
[cpg cn=true]



This guy is 'Lian' by combining Mari and Marian!
[cpg]

Wow, that's stupid.
[cpg]

I knew that it would do me no good to find out, but I knew that Hayashida's brains were too big for him.
[cpg]

[OnName num="KEI"]
I see, so that's why you're Liane.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari056"]
[OnName num="Lian"]
Yes, that's why you're Lian!　I'm so glad you understand!　Do you like Marian, too, Kay?
[cpg cn=true]



[OnName num="KEI"]
Yes, I do. It's so good.
[cpg cn=true]



I continued the conversation with the knowledge I had just acquired from a magazine and a search in another window.
[cpg]

[OnName num="KEI"]
She drinks mineral water when she wakes up from sleep to gauge her physical condition and decide what she will eat that day.
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Mari057"]
[OnName num="Lian"]
'You know so much!　She says she can tell what her body wants by how she feels about the taste of the water. Isn't that amazing?
[cpg cn=true]



[OnName num="KEI"]
"Does Leanne do that too?"
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari058"]
[OnName num="Lian"]
"Yes, I'm doing it. I'm drinking hydrogen water.
[cpg cn=true]



[OnName num="keisuke"]
Bwahaha...!
[cpg cn=true]



Hydrogen water!
[cpg]

I thought that was already proven to be pointless.
[cpg]

[OnName num="KEI"]
You're so conscious.
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Mari059"]
[OnName num="Lian"]
Right?　You have to have a high sense of beauty.
[cpg cn=true]



I'm not going to cleanse you of your meanness by making you more conscious!
[cpg]

I never let my inner feelings out in words, but continued chatting.
[cpg]

[OnName num="KEI"]
But did you know that Marian actually likes sweets?
[cpg cn=true]



This is what a well-informed Japanese Marian fan said to me after reading a site that translates her blog.
[cpg]

[FACE method="change_2" pos="3/7"]
[VOICE f="Mari060"]
[OnName num="Lian"]
'Ah!　I know that much!　She loves ice cream, and whenever she comes to Japan, she eats Gorigokun every day!'
[cpg cn=true]



Seriously...that's not even on her blog.
[cpg]

[OnName num="KEI"]
'Top models eat Gorigori-kun!　Cheap!
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Mari061"]
[OnName num="Lian"]
I used to eat expensive food like Hagendazi, but after I heard that, I've been eating Gorigori-kun all the time!
[cpg cn=true]



[FACE method="change_2" pos="3/7"]
[VOICE f="Mari961"]
[OnName num="Lian"]
He lives in France, so he can't have it when he comes back, but I can buy it every day..."
[cpg cn=true]



I can buy it every day....
[cpg]

No, I can't be like that just because I ate that ice cream.
[cpg]

As I was thinking about what to do with this conversation, Hayashida asked, "Oh, I'm feeling good today.
[cpg]

[FACE method="change_1" pos="3/7"]
[VOICE f="Mari062"]
[OnName num="Lian"]
I was in a bad mood today. Wanna go to Secret?
[cpg cn=true]



[OnName num="john_doe0913"]
I'm going, I'm going!
[cpg cn=true]



[OnName num="ナナ1002"]
I'm coming!
[cpg cn=true]



These guys....
[cpg]

I was the one who made them feel good, but a bunch of Nanashi joined in the fun.
[cpg]

[FACE method="change_6" pos="3/7"]
[VOICE f="Mari063"]
[OnName num="Lian"]
"Kei, Mochi's coming!"
[cpg cn=true]



;//入金画面に

[OnName num="keisuke"]
This again..."
[cpg cn=true]



I sighed as the monitor switched to the payment screen.
[cpg]

The amount of 1,000 yen is high for a student.
[cpg]


The first thing to do is to make sure that you have a good time.
[cpg]

I'm not sure if Lian, in a good mood, won't come out with a rag.
[cpg]

I'll follow him wherever he goes....
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_6.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『リアンズワールドシークレットルーム』
;//●ＣＧ（麻里。アイスを舐めるヒロイン）ev_07

[BGM f="bg_h1"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Mari064"]
[OnName num="Lian"]
Ta-da!　It's you, Gorigori-kun~!"
[cpg cn=true]



When I entered the secret room, Hayashida was standing there with an ice cream cone in his hand.
[cpg]

[VOICE f="Mari065"]
[OnName num="Lian"]
I'm going to make sure everyone thinks I'm Marian Joyce and enjoys themselves.
[cpg cn=true]



[OnName num="keisuke"]
'It seems like it, bitch...'
[cpg cn=true]



[OnName num="KEI"]
'Yes!　I've been waiting for you!
[cpg cn=true]



[OnName num="john_doe0407"]
"Hugh, Hugh, Hugh!"
[cpg cn=true]



I'm afraid I'm going to split my personality if I keep saying things in chat rooms that I don't think are true.
[cpg]

But after being so excited by me and Nanashi, Hayashida got all worked up and started to lick the ice cream.
[cpg]

[VOICE f="Mari066"]
[OnName num="Lian"]
"Nn...lello......"
[cpg cn=true]



[OnName num="john_doe1027"]
Oh, oh, that's good.
[cpg cn=true]




The licked ice cream melted and changed its shape.
[cpg]

;**【ＣＧ】 ev_07_a ***********************
[CG id=4 index=1 time=100]
;***************************************
[WAIT time=100]

[VOICE f="Mari069"]
[OnName num="Lian"]
"Oh...it's getting dirty."
[cpg cn=true]



[VOICE f="Mari072"]
[OnName num="Lian"]
It's so cold."
[cpg cn=true]



Ice cream dripped from his chin to his chest.
[cpg]

[VOICE f="Mari073"]
[OnName num="Lian"]
"Oh...oh...sticky..."
[cpg cn=true]


;**【ＣＧ】 ev_07_0 ***********************
[CG id=4 index=0 time=100]
;***************************************
[WAIT time=100]


[VOICE f="sMari007"]
[OnName num="Lian"]
"Nuh-uh...... Kay-chan?
[cpg cn=true]



[OnName num="keisuke"]
「！」
[cpg cn=true]



[OnName num="KEI"]
What?"
[cpg cn=true]



The first thing that comes to mind is the fact that the two of you have been in the same room together for a long time.
[cpg]

[VOICE f="sMari008"]
[OnName num="Lian"]
I'm sure you're not imagining anything strange, are you?
[cpg cn=true]



[OnName num="keisuke"]
I'm not imagining anything strange, am I?
[cpg cn=true]



I logged out, unable to stay there, feeling neither anger nor embarrassment.
[cpg]



[OnName num="keisuke"]
'Someday...someday ......'
[cpg cn=true]



At this point, my purpose became clear.
[cpg]

I wanted to give Hayashida, who seemed to be so proud of his victory, a shot in the arm.
[cpg]





;//３日目昼　へ
[jump target="*day2_end"]
;//=============================================================================
;//３，Ｈキャッスル
*select06_3|話題を集めるために外へ

[OnName num="keisuke"]
Maybe I should go to JoOusama's room..."
[cpg cn=true]


;//qwe
I didn't think of anything in particular, but decided to wait for the time and enter H-Castle.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『Ｈキャッスル』

＞ケイさんが入室されました
[cpg]

[FG f="CHA03_p5_03_a.ui" method="change_1"  pos="3/7" time=800]
[VOICE f="Hitomi062"]
[OnName num="SB"]
"You're here."
[cpg cn=true]



[OnName num="KEI"]
'S. Butterfly-sama, I'm sorry to disturb you.
[cpg cn=true]



I greet her as if I made up the atmosphere of this room.
[cpg]

Looking at the number of people entering the room, it seems that all the other regulars are already here.
[cpg]

[OnName num="pig"]
Ah, JoOusama. You look even more beautiful today.
[cpg cn=true]



[OnName num="deku"]
You seem to be purged of the impurities that have accumulated in your floating life.
[cpg cn=true]



[OnName num="mercenary"]
You are my goddess.
[cpg cn=true]



Is this a time of praise?
[cpg]

In the chat section, both familiar and unfamiliar names are praising SB together.
[cpg]

I'm not a very good talker, so I decided to observe SB's room while I was there.
[cpg]


;//■選択肢_夜_２日目_ＳＢ

[stflag Hselecter32_cnt = 2]

*Hselecter02|話題を集めるために外へ

[if exp={getFlagValue("Hselecter32_cnt") == 0}]
[jump target="*2niend_hi"]
[endif]

[switch]
[case "SB's face"]
	[swap]
	[jump target="*Hsel2_01"]
[case "SB's chest"]
	[swap]
	[jump target="*Hsel2_02"]
[case "SB's head"]
	[swap]
	[jump target="*Hsel2_03"]
[case "Candlestick"]
	[swap]
	[jump target="*Hsel2_04"]
[case "ベッド"]
	[swap]
	[jump target="*Hsel2_05"]
[case "Wall"]
	[swap]
	[jump target="*Hsel2_06"]
[case "Floor"]
	[swap]
	[jump target="*Hsel2_07"]
[case "ＳＢ"]
	[swap]
	[jump target="*Hsel2_01"]
[case "SB"]
	[swap]
	[jump target="*Hsel2_01"]
[endswitch]

;//==========================
;//ＳＢの顔
*Hsel2_01|話題を集めるために外へ

[stflag Hselecter32_cnt=-1]

I wonder where that mask is sold....
[cpg]

I wish I could see their faces when they are hidden.
[cpg]

[jump target="*Hselecter02"]
;//==========================
;//ＳＢの胸
*Hsel2_02|話題を集めるために外へ

[stflag Hselecter32_cnt=-1]

Because she is wearing a white coat, I can only catch a glimpse of her breasts.
[cpg]

But why does that make me even more excited?
[cpg]

[jump target="*Hselecter02"]
;//==========================
;//ＳＢの頭
*Hsel2_03|話題を集めるために外へ

[stflag Hselecter32_cnt=-1]

I wonder if JoOusama washes her own head....
[cpg]

Some clichéd fantasy arises, and I shake my head to drown it out.
[cpg]

Let's replace it with a picture of a slave washing herself....
[cpg]

[jump target="*Hselecter02"]
;//==========================
;//燭台
*Hsel2_04|話題を集めるために外へ

[stflag Hselecter32_cnt=-1]

I still wonder if they play with those candles....
[cpg]

I know in my knowledge how hot it is....
[cpg]

I definitely don't want to do that.
[cpg]

[jump target="*Hselecter02"]
;//==========================
;//ベッド
*Hsel2_05|話題を集めるために外へ

[stflag Hselecter32_cnt=-1]

It's a simple pipe bed.
[cpg]

Does JoOusama sleep here...?
[cpg]

Maybe she is surprisingly poor.
[cpg]

[jump target="*Hselecter02"]
;//==========================
;//壁
*Hsel2_06|話題を集めるために外へ

[stflag Hselecter32_cnt=-1]

Poured concrete.
[cpg]

No sense of life at all.
[cpg]

Could it be that this room is simply for taking videos?
[cpg]

[jump target="*Hselecter02"]
;//==========================
;//床
*Hsel2_07|Outside to get people talking.

[stflag Hselecter32_cnt=-1]

The sound of SB's shoes clacking on the concrete?
[cpg]

What kind of place is this...?
[cpg]

[jump target="*Hselecter02"]
;//==========================
;//２箇所クリック後　進行
*2niend_hi|話題を集めるために外へ

SB starts talking, and I decide to listen properly and straighten my back.
[cpg]

I don't care if he's lying down or blowing his nose, since I can't see him, but.........................
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Hitomi063"]
[OnName num="SB"]
Have you ever been molested in the daytime?
[cpg cn=true]



[OnName num="keisuke"]
What, molested? ......
[cpg cn=true]



I wonder what the intention is in asking such a question.
[cpg]

I don't know what the correct answer is....
[cpg]

[OnName num="kugutsu"]
I've never experienced such a thing.
[cpg cn=true]



Well, that's what I would say...normally.
[cpg]

But SB's response was... "Well, that sounds boring...?
[cpg]

[OnName num="deku"]
"Is that on a train or something?"
[cpg cn=true]


[FACE method="change_3" pos="3/7"]
[VOICE f="Hitomi064"]
[OnName num="SB"]
'I don't think molesters only do it on trains!'
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】棒鞭

The whip attack flew.
[cpg]

It seems questions are not allowed.
[cpg]

[OnName num="mercenary"]
'I've been mistaken before! I was grabbed by the hand on a crowded train and told that I had touched him even though I hadn't... I ran away. I ran away.
[cpg cn=true]

;//qwe
[FACE method="change_7" pos="3/7"]
[VOICE f="Hitomi065"]
[OnName num="SB"]
"Hmmm... Next.
[cpg cn=true]



He doesn't seem to be interested in false accusations.
[cpg]

[OnName num="pig"]
"Such a big deal... for a pig..."
[cpg cn=true]


[FACE method="change_3" pos="3/7"]
[VOICE f="Hitomi066"]
[OnName num="SB"]
"They're all..."
[cpg cn=true]



He didn't seem to get the answer he was looking for.
[cpg]

And, of course, the next point of contention is with me, who hasn't answered yet. ......
[cpg]


;//▲瞳フラグＢがある場合→;//▲瞳フラグ　へ

;//▲瞳フラグＢがない場合→　;//２日目夜ＳＢ終了　へ進行
[if exp={getFlagValue("Cha3flg_B") == 1}]
[jump target="*hitomiflgB"]
[endif]

[jump target="*2hinisbend"]

;//▲瞳フラグ
*hitomiflgB|話題を集めるために外へ

I remember today, he looked at me like he was looking at a pervert....
[cpg]

[OnName num="KEI"]
'Oh, there is...'
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Hitomi067"]
[OnName num="SB"]
'Heh?　Under what circumstances?
[cpg cn=true]



[OnName num="KEI"]
'I held the hand of a female clerk at the cash register of a coffee shop.
[cpg cn=true]



That was an accidental incident, but I probably shouldn't say so....
[cpg]

I decided to make up a fake story about the incident.
[cpg]

[OnName num="KEI"]
'She was beautiful and I wanted to hold her hand longer. ......
[cpg cn=true]


[FACE method="change_4" pos="3/7"]
[VOICE f="Hitomi068"]
[OnName num="SB"]
That sucks. It's scum like you that make it necessary to have women-only cars.
[cpg cn=true]



[OnName num="KEI"]
'I'm sorry.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="sHitomi010"]
[OnName num="SB"]
Scumbags like you need to be punished.
[cpg cn=true]



[OnName num="keisuke"]
Hmm...?"
[cpg cn=true]



"secret pass code 'slave_boy_KEI' by S.B."
[cpg cn=true]



SB sent me a secret pass.
[cpg]

[FACE method="change_1" pos="3/7"]
[VOICE f="Hitomi070"]
[OnName num="SB"]
'I'll be waiting for you in the secret room.
[cpg cn=true]



[OnName num="deku"]
'Oh, no...'
[cpg cn=true]



[OnName num="kugutsu"]
It's not fair..."
[cpg cn=true]



I felt the slaves looking at me with envy .......
[cpg]

The most important thing to remember is that you should never be afraid of being spanked.
[cpg]

[free time=1000]
I was so happy to be able to get a new job.
[cpg]

[OnName num="keisuke"]
What's that?
[cpg cn=true]



The deposit system is not working.
[cpg]

On the contrary, "free" is displayed in the amount column.
[cpg]

I entered the room as soon as I entered the passcode.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『Ｈキャッスルシークレットルーム』

＞Mr. Kay entered the room.
[cpg]

[FG f="CHA03_p5_03_a.ui" method="change_7"  pos="3/7" time=800]
[VOICE f="Hitomi028"]
[OnName num="SB"]
Too late.
[cpg cn=true]



[OnName num="KEI"]
『申し訳ございません』
[cpg cn=true]



[FACE method="change_1" pos="3/7"]
[VOICE f="Hitomi072"]
[OnName num="SB"]
'Keep your hands on the keyboard until I tell you it's okay now.
[cpg cn=true]



[OnName num="KEI"]
Yes, sir.
[cpg cn=true]



I put my hands on the keyboard.
[cpg]


;//移植前シーンカット

Then SB came closer to the camera.
[cpg]


She licks her tongue. It's so close up that I can almost touch those lips.
[cpg]


Of course, it's through the screen, so it's not like that. ...... but it's like I want to touch them.
[cpg]


I think so and touch her lips on the screen. And then...
[cpg]


[FACE method="change_3" pos="3/7"]
[VOICE f="sHitomi011"]
[OnName num="SB"]
I told you to keep them on the keyboard!
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】棒鞭

[OnName num="keisuke"]
!"
[cpg cn=true]



I'm scolded as if I can see him, and in surprise, I tap a strange key.
[cpg]

[OnName num="KEI"]
I tap a strange key in surprise.
[cpg cn=true]



[FACE method="change_1" pos="3/7"]
[VOICE f="Hitomi096"]
[OnName num="SB"]
'I can see that much. Who do you think I am?"
[cpg cn=true]



No ...... I don't know.
[cpg]

I don't even know the rank of SB's queen because my face is hidden by a mask and I don't know anything about the other side of the world.
[cpg]

I'm not even sure if there is such a rank. ......
[cpg]

When I shut up, SB turned her head lazily and brushed her long hair off her shoulders and back...
[cpg]

Today's spanking was over and the secret room was closed.
[cpg]


;//３日目昼へ
[jump target="*day2_end"]
;//==========================
;//２日目夜ＳＢ終了
*2hinisbend|話題を集めるために外へ

[OnName num="KEI"]
'No, I don't...'
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
I replied, and SB only uttered, 'Really boring guys...'...
[cpg]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[OnName num="keisuke"]
'Ah.'
[cpg cn=true]



SB closed the room....
[cpg]

I had no choice but to quietly end the wakuteka video as it was and end the day.
[cpg]

;//３日目昼へ
[jump target="*day2_end"]
;//=============================================================================
;//３日目昼

*select06_9|話題を集めるために外へ
*select07_9|話題を集めるために外へ

*day2_end|Out to get people talking

[jump storage="ep002.ks" target="*start"]

