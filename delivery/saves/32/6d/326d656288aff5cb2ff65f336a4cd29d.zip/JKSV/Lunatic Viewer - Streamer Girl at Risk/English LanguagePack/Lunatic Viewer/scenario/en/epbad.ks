
;//※以前の作品を担当した時のようなルート表をいただけていないので、ルート管理に不安が出ておりまして、ここにどのルートにも接続できなかった場合の、回避エンドを加えさせていただきます（使わないに越したことはないです）。

*root4
;//病みルート


*start

;#################################################
*EpBad|A world that is neither exciting nor shiny
;#################################################



;//真っ白な部屋

[SE f="se000"]
;//【ＳＥ】空調

[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1000]

[OnName num="keisuke"]
「……………」
[cpg cn=true]



I woke up as usual and looked up at the wall clock as I always do.
[cpg]

........., but there was no clock there.
[cpg]

[OnName num="keisuke"]
................"
[cpg cn=true]



I had no choice but to go to my computer and try to open the exciting video .........
[cpg]

[OnName num="keisuke"]
............?"
[cpg cn=true]



There is no ......... computer.
[cpg]

Huh?　Where am I?
[cpg]

On second thought, I guess this is not my room.
[cpg]

Then where is it?
[cpg]

What did I do yesterday.......
[cpg]

Last night I watched a wakteka video......... and then what?
[cpg]

Well, ...... what was I going to do today......?
[cpg]

It's time for breakfast."
[cpg cn=true]



A section of the all-white wall opened and a tray with food on it nuzzled out.
[cpg]

I munched on a piece of bread.
[cpg]

I couldn't taste it.
[cpg]

It's time for your medicine.
[cpg cn=true]



[SE f="se000"]
;//【ＳＥ】鉄扉が開く

Three men and a woman emerge from the white wall and put a few pills in a small cup into my mouth.
[cpg]

[OnName num="keisuke"]
"Um, I think I ...... had to do something."
[cpg cn=true]



[OnName num="man"]
No problem, you didn't have to do anything."
[cpg cn=true]



[OnName num="keisuke"]
Why?"
[cpg cn=true]



[OnName num="man"]
You're, you're sick.
[cpg cn=true]



[OnName num="keisuke"]
Me?　Of what?"
[cpg cn=true]



[OnName num="man"]
You've been hurt. You're broken. That's why they put you here instead of in ...... prison, because you hurt other people."
[cpg cn=true]



[OnName num="woman"]
"Hey, you don't have to say that much. ......
[cpg cn=true]



[OnName num="man"]
'You wouldn't understand anyway, you're completely broken. You're completely broken.
[cpg cn=true]



Broken?　Me?
[cpg]

Yeah, yeah. ......
[cpg]

I've been forced to do a lot of things, and I've had to do a lot of legwork, and I've been forced into ...... this place.
[cpg]

Unconnected actions, haphazard decisions ...... that were made by my broken mind, I guess.
[cpg]

Suddenly, I feel sleepy and collapse to the floor.
[cpg]

Let's go to sleep.
[cpg]

Once I'm here, it's the only option I have left. ......
[cpg]

Good night. Good night.
[cpg]

I'm off to a world that is neither exciting nor shiny. .........
[cpg]

;//静かな破損ＥＮＤ
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*back_title"]


