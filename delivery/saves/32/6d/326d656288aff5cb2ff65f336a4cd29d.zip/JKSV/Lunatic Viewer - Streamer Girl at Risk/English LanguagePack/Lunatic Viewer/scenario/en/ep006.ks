;//瞳ルート
*root3|

;//*test|

*start

;#################################################
*Ep006|The identity of Master SB
;#################################################

[SCENE id=6]





[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_7.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『雑談ルーム』

[OnName num="KEI"]
'I tried to have fun, like Master told me to. But I can't anymore.'
[cpg cn=true]



That night, I called my mentor to the chat room and told him what was on my mind.
[cpg]

[OnName num="siren"]
『そうか』
[cpg cn=true]



The master listened to everything in silence, then said a few words and fell silent for a moment.
[cpg]

[OnName num="KEI"]
I knew that I had to take revenge on him to get rid of this blurred feeling. No, I mean that guy, or rather, anyone at all, I want to take out this frustration on them.
[cpg cn=true]



[OnName num="siren"]
'Well, I thought you might say something like that at some point.
[cpg cn=true]



[OnName num="KEI"]
I'm sorry.
[cpg cn=true]



I apologize honestly, thinking that I have discouraged my mentor, who has been so kind to me.
[cpg]

[OnName num="siren"]
But even if you do get your revenge, you'll be worse off than they are, okay?
[cpg cn=true]



[OnName num="KEI"]
'Yeah, why?
[cpg cn=true]



[OnName num="siren"]
'Because no matter what you do, you'll usually get caught. If you are prosecuted, you will have a criminal record, if it is a felony, you will serve time, and the next time you see the light of day, you will be a middle-aged man. Are you okay with that?
[cpg cn=true]



[OnName num="KEI"]
"Old Man ......"
[cpg cn=true]



I can't imagine what it will be like when I reach that age.
[cpg]

I can't even imagine living in prison until I'm that old.
[cpg]

[OnName num="siren"]
I think it would be boring. I don't think it's boring. If you can't find anyone to chat with, do something constructive in real life.
[cpg cn=true]



[OnName num="KEI"]
'What constructive things?
[cpg cn=true]



[OnName num="siren"]
"Well, I don't know. Maybe get a part-time job.
[cpg cn=true]



[OnName num="KEI"]
Part-time job.
[cpg cn=true]



[OnName num="siren"]
'If you meet people, you'll be more or less influenced by them, you'll be cheered up, you'll be mentally rehabilitated, and if you work part-time, you'll make some money at the same time. It's all good, isn't it?
[cpg cn=true]



[OnName num="KEI"]
If you ask me.
[cpg cn=true]



The master had a point, and I was swayed by his suggestion.
[cpg]

[OnName num="KEI"]
I was swayed by his suggestion: "I'll think about it.
[cpg cn=true]



[OnName num="siren"]
That's a good idea. Good luck.
[cpg cn=true]




;//ブラックアウト
;//エフェクト

;//[SE f="se002"]
;//【ＳＥ】街の雑踏

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『カフェ』




The next day, I was at a café in town.
[cpg]

I thought about it for a while, but I was worried about online job applications because I couldn't see what was going on.
[cpg]

But I knew the atmosphere here, and although I would meet a lot of people, I figured I would mostly be asking about the menu and not chatting with the customers.
[cpg]

I knew that in a grocery store or a bookstore, I would probably get inquiries from customers, and that seemed like a tough hurdle to overcome out of the blue.
[cpg]

[OnName num="keisuke"]
I thought, "Well...maybe I should ask the guy if he's looking for a part-time job."
[cpg cn=true]



I stopped to look at the plain-looking clerk and was about to raise my hand to ask her ...... when she said, "Hey!
[cpg]

[OnName num="店長"]
"Hey, Mr. Kamimura!
[cpg cn=true]



[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hitomi188"]
[OnName num="sober_staff"]
Yes,......?"
[cpg cn=true]



The waitress was called "Uemura," and someone who seemed to be the manager spoke to her.
[cpg]

[free time=1000]
[OnName num="keisuke"]
......... Uemura?"
[cpg cn=true]



The name stuck in my brain somewhere, and I thought about it.
[cpg]

[OnName num="keisuke"]
Oh, ......."
[cpg cn=true]



But not only did the answer come immediately, but various data began to fit together like a puzzle.
[cpg]

H. UEMURA...... from the butterfly's pocket. The name on the nameplate that fell out.
[cpg]

The small burn on his hand from a fallen candle.
[cpg]

The mannerisms were completely different, but perhaps this sober clerk was ......
[cpg]

[OnName num="keisuke"]
Oh, sir!
[cpg cn=true]



[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hitomi189"]
[OnName num="sober_staff"]
Here you are, .......
[cpg cn=true]



[OnName num="keisuke"]
"Are you Butterfly-sama?
[cpg cn=true]



[FACE method="change_5" pos="2/3"]
[VOICE f="Hitomi190"]
[OnName num="sober_staff"]
「！？」
[cpg cn=true]



The clerk was so upset that she cut in without any preamble, and the clerk looked very surprised and speechless ......
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Hitomi191"]
[OnName num="sober_staff"]
I'm not sure what to say, but I'm sure you'll be able to find something that will help you.
[cpg cn=true]



[free time=1000]
The clerk was so startled that she lost her words and ran out of the store.
[cpg]

[OnName num="store_manager"]
Ah!　Mr. Kamimura!
[cpg cn=true]



Both the manager and I were left with nothing to do but to open our mouths in shock.
[cpg]

What was that about ......?
[cpg]

From her reaction, there was no doubt that she was an SB.
[cpg]

But even so, that panic.
[cpg]

It was totally unthinkable from her appearance at night.
[cpg]

[OnName num="store_manager"]
I'm sorry, sir. Are you ready to order?
[cpg cn=true]



[OnName num="keisuke"]
Oh, no, I'm sorry, ....... I'm going home.
[cpg cn=true]



;//ブラックアウト
;//エフェクト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

;//【ＢＧ】『主人公（啓介）の部屋』(夜)

[BG f="b_05_7.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『雑談ルーム』

After that, the delivery of "H Castle" was stopped for days.
[cpg]

[OnName num="KEI"]
Then, by chance, I thought it must be SB's identity.
[cpg cn=true]



[OnName num="siren"]
'Oh well.
[cpg cn=true]



[OnName num="KEI"]
'What am I supposed to do now?
[cpg cn=true]



[OnName num="siren"]
'There's nothing we can do about it, is there?'
[cpg cn=true]



[OnName num="KEI"]
'Don't say that, please lend me your wisdom. I'm too heavy to have my room destroyed because of me.' 'Don't ask me.
[cpg cn=true]



[OnName num="siren"]
'Don't ask me to do anything about it.
[cpg cn=true]



I consulted with my mentor, but I didn't get the answer I was hoping for, and I was left with a different kind of blur.
[cpg]

[OnName num="siren"]
Why do you care so much about SB? It's none of your business if one of the many rooms is gone.
[cpg cn=true]



[OnName num="KEI"]
'That's true, but ...... something about that guy bothers me because he's full of mystery.
[cpg cn=true]



The face is not visible, the strange construction of the room, that confident speech and behavior.
[cpg]

It's hard not to care about SB because he's so out of touch with the world.
[cpg]

[OnName num="siren"]
'I thought you said you didn't have a room you were hooked on?'
[cpg cn=true]



[OnName num="KEI"]
'Yes, but it's kind of a scary thing to see.
[cpg cn=true]



[OnName num="siren"]
'That room is special, don't get too deep into it and forget about it.'
[cpg cn=true]



[OnName num="KEI"]
What?
[cpg cn=true]



[OnName num="siren"]
See you later.
[cpg cn=true]



＞Mr. Siren has left the room.
[cpg]

The master who said this unusually quickly logged out, and I sighed with a sense of helplessness.
[cpg]

[OnName num="keisuke"]
'I don't see him at the coffee shop anymore, how can I see SB again ......'
[cpg cn=true]



I had never cared that much about him until the day I called out to him, but now that I had made contact with him in the real world, a sort of obsession with SB had sprouted inside me.
[cpg]

[SE f="se024"]
;//【ＳＥ】マウス数回クリック

Queen ......, butterfly mask ......
[cpg]

I typed all the words I could think of into my computer and looked at various sites.
[cpg]

There was no way I could find what I was looking for, but I was that hungry for information that would lead me to SB.
[cpg]

[OnName num="keisuke"]
I thought to myself, "Wow, ......, what the heck is this ......?"
[cpg cn=true]



However, when I searched with these words, I found a lot of outrageous images.
[cpg]

I could tell it was something I didn't want to know about or see, and I knew it wasn't for me.
[cpg]

I don't know what's so good about painful or embarrassing .......
[cpg]

＞Rianne is in the room.[r]
＞Rian has entered the room.
[cpg]

[OnName num="keisuke"]
Hmmm...?
[cpg cn=true]



Emu and Hayashida entered the chat room, which was still logged in.
[cpg]

[OnName num="eMU"]
"Good evening.
[cpg cn=true]



[OnName num="Lian"]
Hello, hello.
[cpg cn=true]



[OnName num="KEI"]
Hello.
[cpg cn=true]



[OnName num="Lian"]
What's the matter, nobody's here, what were you doing alone?"
[cpg cn=true]



Hayashida was talking to me in a familiar manner.
[cpg]

I was pissed off, but since Emu was there too, I decided to pretend I didn't know him.
[cpg]

[OnName num="KEI"]
He said, "I was here just now. Mr. Siren was there.
[cpg cn=true]



[OnName num="eMU"]
Oh, I see.
[cpg cn=true]



[OnName num="Lian"]
Are you two good friends?　I can't imagine what they're talking about.
[cpg cn=true]



[OnName num="KEI"]
"I mean, he's my mentor, so I asked him for advice.
[cpg cn=true]



[OnName num="eMU"]
He's a kind man, so I'm sure he gave you good advice.
[cpg cn=true]



[OnName num="KEI"]
Not so much.
[cpg cn=true]



[OnName num="Lian"]
"What?　What did you ask him about?
[cpg cn=true]



[OnName num="KEI"]
"Well, I asked him about the owner of a room called H Castle."
[cpg cn=true]



[OnName num="Lian"]
H-Castle?　You have a hobby like that?
[cpg cn=true]



Since I knew Hayashida, I could easily imagine his curious tone, and it was extremely unpleasant.
[cpg]

I was so upset that I decided not to speak until the two of them left the chat room.
[cpg]

If I keep quiet for a while, they'll think I've frozen.
[cpg]

[OnName num="Lian"]
'Huh?　Hey, Kay-chan?　Did I fall in?'
[cpg cn=true]



[OnName num="eMU"]
'Maybe it's the bathroom.'
[cpg cn=true]



The two of them continued to chat about their unimportant conversation, and eventually, after 30 minutes ......
[cpg]

[OnName num="Lian"]
'That guy hasn't come back. I wonder if he has machine trouble.
[cpg cn=true]



[OnName num="eMU"]
'Is he interested in SB?
[cpg cn=true]



[OnName num="Lian"]
'Well, if you see that room, anyone would be a little bit interested.
[cpg cn=true]



They realized I was not coming back and started to gossip.
[cpg]

It was surprising that both of them knew each other, but it was no surprise that they were friends with other distributors who were close in age.
[cpg]

[OnName num="Lian"]
Speaking of SB, I finally made it there the other day, but I got lost. I was in a real hurry because I thought I was going to be late.
[cpg cn=true]



[OnName num="eMU"]
It's hard to tell, you know. There are many buildings of the same shape on the pier.
[cpg cn=true]



[OnName num="Lian"]
But I was impressed when I found the landmark. I had never seen a butterfly stained glass window before.
[cpg cn=true]



[OnName num="eMU"]
Me too. By the way, Mr. Lian, what is your current level?
[cpg cn=true]



[OnName num="Lian"]
What's yours?
[cpg cn=true]



[OnName num="eMU"]
Twelve.
[cpg cn=true]



[OnName num="Lian"]
Seriously?　How can you do that with your pretty face? I'm only 8.
[cpg cn=true]



What the hell are we talking about here?
[cpg]

What is this building they were talking about?
[cpg]

The butterfly stained glass windows in a row of similar buildings on the pier?
[cpg]

Could it be ...... that's where SB is?
[cpg]

[OnName num="KEI"]
'You know what?
[cpg cn=true]



[OnName num="Lian"]
'Oh, there you are!
[cpg cn=true]



[OnName num="eMU"]
'Since when?'
[cpg cn=true]



[OnName num="KEI"]
'Do you two know SB's real room?
[cpg cn=true]



＞You have left the room.[r]
＞Rian has left the room.
[cpg]

[OnName num="keisuke"]
Ah!
[cpg cn=true]



As soon as I asked them a question, they immediately logged out.
[cpg]

But that only means that my question was affirmed.
[cpg]

[OnName num="keisuke"]
The pier: ...... butterfly stained glass: ......
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
;//エフェクト

;//埠頭

[SE f="se052"]
;//【ＳＥ】歩き

The next day, without much thought, I went to the wharf closest to my house.
[cpg]

There are many wharfs in Japan, but I thought that if Hayashida had been there, it might be in Tokyo.
[cpg]

[OnName num="keisuke"]
A similar building is the ...... warehouse, right?"
[cpg cn=true]



Feeling myself being rejected by the cold sea breeze, I look around at the rows of rugged brick buildings.
[cpg]

[OnName num="keisuke"]
'There's a lot of them. ......
[cpg cn=true]



But I have plenty of time.
[cpg]

No matter how many warehouses there are, if I keep walking with the butterfly as my landmark, one day I will ...... find it.
[cpg]

;//時間経過

;//夕方

[SE f="se000"]
;//【ＳＥ】カモメの鳴き声

[OnName num="keisuke"]
"Ugh...... finally...... finally......"
[cpg cn=true]



After walking for several hours, I was moved to finally find a small stained glass window with a butterfly in it.
[cpg]

Until I came here, I had thought that after checking it out, I could just go home and ask Emu again, but I was so happy that I got carried away and unintentionally pressed the doorbell on the small door by the shutters.
[cpg]

[SE f="se048"]
;//【ＳＥ】ジリリリーーンッ！
[WAIT time=1000]

[OnName num="keisuke"]
「！？」
[cpg cn=true]



I jumped up when I heard a rasping sound, not the simple "ping-pong" sound I had imagined.
[cpg]

[SE f="se042"]
;//【ＳＥ】走り寄る足音

[WAIT time=2000]

[SE f="se049"]
;//【ＳＥ】鉄扉が開く

[WAIT time=2000]

[FG f="CHA03_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Hitomi192"]
[OnName num="sober_staff"]
What is it?
[cpg cn=true]



[OnName num="keisuke"]
Oh, .......
[cpg cn=true]



[FACE method="change_4" pos="2/3"]
[VOICE f="Hitomi193"]
[OnName num="sober_staff"]
What ......, that's not possible. .........
[cpg cn=true]



The person who opened the small iron door and came out was a sober waiter of the cafe, who could not be mistaken for SB.......
[cpg]

She wore a white coat, but her clothes are no different from ordinary women.
[cpg]

[OnName num="keisuke"]
I knew it was ......!
[cpg cn=true]



I realized that all my thoughts and actions were correct, and my mood suddenly brightened.
[cpg]

[OnName num="keisuke"]
I'm sorry to interrupt!　But I..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi194"]
[OnName num="SB"]
I'm just going to go to ...... for the time being.
[cpg cn=true]



[OnName num="keisuke"]
Oh, hi. ......
[cpg cn=true]



I was invited into the steel door, and I followed SB's lead.
[cpg]

;//ＳＢの部屋（Ｈキャッスルで映っている部屋）
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『瞳の部屋』

[OnName num="keisuke"]
Wow,......, this really is the place.
[cpg cn=true]



Concrete walls, candlesticks, hard floor and a pipe bed .......
[cpg]

I was taken into a room just as I had seen in the video, and I felt as if I had wandered into a fantasy world.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Hitomi195"]
[OnName num="SB"]
I was in a fantasy world. "This is ...... stalking...do you understand ...... that?"
[cpg cn=true]



[OnName num="keisuke"]
"Stalking?　No, no, no, no!
[cpg cn=true]



I had no intention of doing so, but when the disturbing word was brought up, I was instantly frustrated.
[cpg]

I had a light feeling that I wanted to see a celebrity or a celebrity close to me with my own eyes, but when I learned that it would be a criminal act, my fear grew.
[cpg]

[OnName num="keisuke"]
I didn't mean it!"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi196"]
[OnName num="SB"]
I've been to ...... cafes and ...... things like that.
[cpg cn=true]



[OnName num="keisuke"]
I'm not going to do that! I'm not going to do that!
[cpg cn=true]



I saw SB's hand reach for the phone on my desk and I knew I was going to be reported.
[cpg]

So I had no choice but to hold ...... her back with all my might.
[cpg]

[OnName num="keisuke"]
'Wait!　No, no!"
[cpg cn=true]



[SE f="se020"]
;//【ＳＥ】飛びかかり揉み合う

[FG f="CHA03_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Hitomi197"]
[OnName num="SB"]
Noooooo!"　Let go of me!
[cpg cn=true]



As I was struggling with SB, who was resisting, she screamed out.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="sHitomi014"]
[OnName num="SB"]
Stop ......, really, please."
[cpg cn=true]


It's not a serious resistance, but a voice that sounds like it's already on the verge of breaking.
[cpg]



At the same time, they huffed ......, but their brains were surely flooded with completely different emotions from each other.
[cpg]

On SB's side, fear and panic.
[cpg]

On my side, feelings bordering on excitement.
[cpg]

[OnName num="keisuke"]
"Shhhh, be quiet!"
[cpg cn=true]



I pushed SB down on the bed with all my might.
[cpg]



;//●ＣＧ（瞳：倒れ込んでいるヒロイン）ev_36
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Hitomi198"]
[OnName num="SB"]
"Hiccup...!　Please don't do that!
[cpg cn=true]



SB was still using honorifics at this stage.
[cpg]



[VOICE f="Hitomi200"]
[OnName num="SB"]
"No, no....
[cpg cn=true]



[OnName num="keisuke"]
.................."
[cpg cn=true]



The frightened look in his eyes.
[cpg]

It was the eye of a weak man who admits that he is weaker than I am.
[cpg]

The first time I realized this, a certainty came over me.
[cpg]

Now, now, now I can love her.
[cpg]


;**【ＣＧ】 ev_36_a ***********************
[CG id=15 index=1 time=100]
;***************************************
[WAIT time=100]


[VOICE f="Hitomi201"]
[OnName num="SB"]
Don't....yeah."
[cpg cn=true]



Cute. It's so different from my impression of SB up until now.
[cpg]


Maybe that's the kind of moment people get excited about.
[cpg]


There is no doubt that I have the upper hand now.
[cpg]


I am sure, but...I wonder what I can really do.
[cpg]



;//移植前シーンカット

A slight hesitation arose. It was at that moment.
[cpg]



[SE f="se020"]
;//【ＳＥ】突き飛ばす

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[OnName num="keisuke"]
What?
[cpg cn=true]



Just as I was about to break my horseback-riding stance, SB pushed me off and jumped off the bed.
[cpg]

However, because I was too weak, I quickly caught her and pulled her toward me again.
[cpg]

[OnName num="keisuke"]
She's not giving up.
[cpg cn=true]



[SE f="se023"]
;//【ＳＥ】押し倒す

;//移植前シーンカット


[VOICE f="Hitomi232"]
[OnName num="SB"]
Nooooooooooooooooooooooooooooooooooooooooooooooooooo!"
[cpg cn=true]



The woman's high-pitched scream echoed off the cold, hard concrete walls. ......
[cpg]


;//ブラックアウト
;//エフェクト


[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『瞳の部屋』
;//ＳＢの部屋

;//移植前シーンカット

[FG f="CHA03_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHitomi015"]
[OnName num="SB"]
Do you know what will happen to you if you do this?
[cpg cn=true]



[OnName num="keisuke"]
What's going to happen?　Do you expect anyone to come to your rescue?"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Hitomi240"]
[OnName num="SB"]
'Oh, you... you don't understand ...... anything. ......
[cpg cn=true]



I'm intrigued ...... by the way she looks up at me, her face contorted in pain.
[cpg]




[SE f="se004"]
;//【ＳＥ】ガバッ


;//●ＣＧ（瞳：背後から体を掴まれているヒロイン）ev_39
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_39_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=100]



[OnName num="keisuke"]
How does it feel to be the tormentor being tormented?　Oh?"
[cpg cn=true]



I was under the illusion that I was bullying the bully back.
[cpg]

How does it feel to be tormented by someone who is usually the tormentor of others?
[cpg]

That, paradoxically, explains my current state of mind.
[cpg]

[OnName num="keisuke"]
How do you feel?　Do you think it's good to be afraid?"
[cpg cn=true]



[VOICE f="Hitomi244"]
[OnName num="SB"]
"Oh, I don't think so...not like this..."
[cpg cn=true]



I felt the blood rush to my head when I heard that answer.
[cpg]

[OnName num="keisuke"]
Then why are you torturing people?
[cpg cn=true]



And I had one idea in my head.
[cpg]


;//移植前シーンカット


[SE f="se051"]
;//【ＳＥ】パソコン起動


[VOICE f="Hitomi252"]
[OnName num="SB"]
What the hell are you doing?
[cpg cn=true]



I operate the computer. She knows what I'm going to do.
[cpg]

[OnName num="keisuke"]
"Start the delivery..."
[cpg cn=true]



[VOICE f="Hitomi253"]
[OnName num="SB"]
Stop it!
[cpg cn=true]



＞Puppet has entered the room.[r]
＞Pigs have entered the room.
[cpg]

;//移植前シーンカット


[OnName num="kugutsu"]
"Oh, no.
[cpg cn=true]



[OnName num="deku"]
What is this?
[cpg cn=true]



You can see the expressions on the faces of the stunned slaves on the other side of the computer.
[cpg]

[OnName num="keisuke"]
Look, how dare you thank the viewers!
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】叩く



Strangely enough, wearing the SB butterfly mask, I was filled with a sense of omnipotence.
[cpg]

There was nothing to be afraid of.
[cpg]

I had become a tyrant over power and women.
[cpg]


;//移植前シーンカット


[OnName num="deku"]
This is not true.
[cpg cn=true]



[OnName num="pig"]
My queen, I have failed you.
[cpg cn=true]



[OnName num="mercenary"]
"I can't believe I ever served such a man.
[cpg cn=true]



[OnName num="kugutsu"]
I can't believe I ever served such a man.
[cpg cn=true]



I have shown them a good thing, but they logged out one by one, leaving behind their discarded words.
[cpg]

You idiots ...... don't understand anything.
[cpg]


[VOICE f="Hitomi270"]
[OnName num="SB"]
"U...u...u...u...u...u...u...u...u.........
[cpg cn=true]



SB grunts as he looks at me, but doesn't speak a word of defiance.
[cpg]

I saw this and I knew I had won.
[cpg]

This beautiful woman is still at my mercy .......
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//ブラックアウト
;//エフェクト


;//移植前シーンカット


A few days passed, and I kept SB locked up.
[cpg]

Hitomi Uemura...... was SB's real name.
[cpg]

Her true form was that of a researcher at an obscure scientific research institute, which was the reason for the white coat.
[cpg]

The reason why I don't understand it well is because I didn't understand it when I heard the explanation, and the organization she belonged to had a cool name that was somehow abbreviated from English.
[cpg]

According to what I had heard through violence, the reason she was working part-time at the cafe during the day was to take human data samples.
[cpg]

She was living in this warehouse because she had been ordered by her superiors to conduct chemical experiments in another room.
[cpg]




[OnName num="keisuke"]
So, what is your research?"
[cpg cn=true]



[VOICE f="sHitomi016"]
[OnName num="hitomi"]
I specialize in ...... brain science ......."
[cpg cn=true]



He said something else, but I honestly ...... have no idea what he was talking about.
[cpg]


Since then, pupils have been obedient to me.
[cpg]


;//移植前シーンカット


The most important thing to remember is that you can't just take a look at the information you have on the internet.
[cpg]

The most important thing to remember is that you can't just take a look at the actual product or service and expect it to be good for you.
[cpg]

If this was the case, I probably should have just watched her in S. Butterfly's .......
[cpg]


[OnName num="keisuke"]
Ha ......."
[cpg cn=true]



The butterfly mask suddenly enters my eyes as I sit up in bed with a sigh.
[cpg]

[OnName num="keisuke"]
I'm not sure what to make of it, but I'm sure I'll be able to find it.
[cpg cn=true]



[free time=1000]
[WAIT time=1500]


I had just put it on my pupil's face in a moment of whimsy, when ......
[cpg]

[STOPBGM]

[VOICE f="Hitomi276"]
[OnName num="hitomi"]
You fucking pervert!
[cpg cn=true]



[SE f="se020"]
;//【ＳＥ】衝撃

[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=500]
[WAIT time=500]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]
[WAIT time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1100]
[window target=true]

;//画面揺れる

[OnName num="keisuke"]
「！？」
[cpg cn=true]



With a sudden jolt, I rolled off the bed and fell to the floor.
[cpg]


[FG f="CHA03_p1_04_a.ui" method="change_3"  pos="2/3" time=800]
[BGM f="bg_h2"]
[WAIT time=800]


I looked in surprise, and to my surprise, there were the eyes ...... or SB standing there, looking down at me with arrogance.
[cpg]


[VOICE f="Hitomi277"]
[OnName num="SB"]
I'm done here, you little worm!
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】ビンタ

[OnName num="keisuke"]
What...what...ah?
[cpg cn=true]



I was slapped with a lot of force, and my head was spinning and I was confused.
[cpg]

[OnName num="keisuke"]
What the hell is going on?
[cpg cn=true]



[VOICE f="Hitomi278"]
[OnName num="SB"]
Shut up!
[cpg cn=true]


[SE f="se009"]
;//【ＳＥ】ビンタ

[OnName num="keisuke"]
Agh!
[cpg cn=true]



My cheeks are hot and numb.
[cpg]


But for some reason, I don't feel uncomfortable.
[cpg]


[VOICE f="Hitomi279"]
[OnName num="SB"]
After all, you're just a lowly male.
[cpg cn=true]



[OnName num="keisuke"]
What?
[cpg cn=true]



[SE f="se021"]
;//【ＳＥ】結束バンド


;//●ＣＧ（瞳：主人公が拘束されて、平手で打たれる）ev_42
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_42_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=100]

SB quickly reaches under the bed mat and pulls out a cable tie, tying my right hand to my right ankle and my left hand to my left ankle.
[cpg]

[OnName num="keisuke"]
'Whoa...!'
[cpg cn=true]



It all happened so fast that I was helplessly rolled onto the hard floor in a heap.
[cpg]

[VOICE f="Hitomi280"]
[OnName num="SB"]
I'm going to show you what real training is like.
[cpg cn=true]



[OnName num="keisuke"]
"Hee....
[cpg cn=true]



I can't help but get goosebumps all over my body.
[cpg]

I can't help but get goosebumps all over my body.
[cpg]


[VOICE f="sHitomi017"]
[OnName num="SB"]
What do you want me to do to you?　What do you want me to do?
[cpg cn=true]



[OnName num="keisuke"]
"Don't...do...that."
[cpg cn=true]



[VOICE f="sHitomi018"]
[OnName num="SB"]
You make such a cute sound. It sounds like you want me to do something.
[cpg cn=true]



She giggles and slaps me on the body.
[cpg]



[OnName num="keisuke"]
She giggles and shakes her hand at me, "Hi, please, forgive me."
[cpg cn=true]



[VOICE f="sHitomi019"]
[OnName num="SB"]
Well... this is where delivery comes in handy.
[cpg cn=true]


[SE f="se024"]
;//【ＳＥ】パソコン操作

;//ワクテカ動画
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『Ｈキャッスルシークレット』

＞Puppet has entered the room.[r]
＞Mercenary has entered the room.
[cpg]

[FG f="CHA03_p5_03_a.ui" method="change_1"  pos="3/7" time=800]
SB operates the computer on his desk and opens a video site.
[cpg]

One by one, the regulars start to appear on the screen, which seems to be a secret.
[cpg]

[OnName num="pig"]
JoOusama!　Oh, that mask!
[cpg cn=true]



[OnName num="deku"]
You have returned from your nightmare!
[cpg cn=true]



The chat room is abuzz with excitement at the queen's return.
[cpg]

[OnName num="mercenary"]
"Forgive our slave who almost betrayed us, Master Butterfly!
[cpg cn=true]


[FG f="CHA03_p5_03_a.ui" method="change_2"  pos="3/7" time=800]
[VOICE f="Hitomi297"]
[OnName num="SB"]
I'm going to need you to help me train this man.
[cpg cn=true]



[OnName num="keisuke"]
"Ugh. ......"
[cpg cn=true]



[OnName num="kugutsu"]
"Oh, that's him!
[cpg cn=true]



The SB binds me with ropes and hangs my arms from hooks in the ceiling.
[cpg]

 Its appearance was that of a slave who was deprived of human dignity.
[cpg]

[OnName num="keisuke"]
No, don't do this. ......
[cpg cn=true]



The excitement I had felt earlier was still unquenchable, but the fear was added to it.
[cpg]

[OnName num="pig"]
I'm not going to let you do this to me," she said.　I suggest muzzling the noisy bastard.
[cpg cn=true]



[OnName num="keisuke"]
What?
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
My mouth is sealed by a ping-pong ball-like device with a belt, and I can no longer speak.
[cpg]

[OnName num="keisuke"]
"Mmmmmm..."
[cpg cn=true]



I tried to say something, but all I could do was moan and drool.
[cpg]


;//●ＣＧ（瞳：主人公は拘束、口輪状態で鞭打ちされる）ev_50
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=100]


[OnName num="deku"]
I want to see how you whip me, Mistress!
[cpg cn=true]


[VOICE f="Hitomi299"]
[OnName num="SB"]
It's been a long time, hasn't it? I will allow it.
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】鞭

[BG f="white.ui" time=500]
[WAIT time=500]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=18 index=0 time=500]
;***************************************
[WAIT time=500]

[OnName num="keisuke"]
I will allow it.
[cpg cn=true]



The whip swung down repeatedly on my bare skin.
[cpg]

Every time it passes through my body, it leaves a red worm sore.
[cpg]

[OnName num="keisuke"]
"Aaaaah!
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】鞭
[BG f="white.ui" time=500]
[WAIT time=500]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=18 index=0 time=500]
;***************************************
[WAIT time=500]

[VOICE f="Hitomi300"]
[OnName num="SB"]
Cry!　More, more, more!
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】鞭
[BG f="white.ui" time=500]
[WAIT time=500]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=18 index=0 time=500]
;***************************************
[WAIT time=500]

[OnName num="keisuke"]
 "Uguuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu!"
[cpg cn=true]



Her whip is taking away my sanity.
[cpg]


The pain was so great that I couldn't think about anything else.
[cpg]



[SE f="se009"]
;//【ＳＥ】鞭
[BG f="white.ui" time=500]
[WAIT time=500]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=18 index=0 time=500]
;***************************************
[WAIT time=500]

;//移植前シーンカット


Eventually I couldn't stay conscious and closed my eyes.
[cpg]


If I continue to sleep, ...... my body will go crazy .......
[cpg]


I was so exhausted that I couldn't resist even though I knew it was happening. ......
[cpg]


;//ブラックアウト
;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『瞳の部屋』

I don't know how long I've been asleep,...... but when I open my eyes again, I'm lying down normally and there's a blanket over my body.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
Surprised, I turned my eyes to the bed, and there, instead of SB, I saw an unmasked eye sitting there, staring silently at me.
[cpg]

[OnName num="keisuke"]
I said, "Oh ...... that ......."
[cpg cn=true]



I didn't know what to say to her.
[cpg]



 Normally, I wouldn't be able to talk, but I didn't think things would progress even if I kept silent.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi309"]
[OnName num="hitomi"]
 "No ... it hurts ... no ... is ...?"
[cpg cn=true]



[OnName num="keisuke"]
What?
[cpg cn=true]



[FACE method="change_1" pos="2/3"]
[VOICE f="Hitomi310"]
[OnName num="hitomi"]
"Here...this........."
[cpg cn=true]



What was offered to me was a tube type of wound medicine.
[cpg]

The eyes seem to be worried about my buttocks .......
[cpg]

The first thing you need to do is to make sure that you have a good idea of what you're doing.
[cpg]

[OnName num="keisuke"]
You did it to yourself,......."
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi311"]
[OnName num="hitomi"]
I'm sorry...sorry...n......"
[cpg cn=true]



The most important thing to remember is that the best way to get the most out of your money is to be honest with yourself.
[cpg]

The most important thing to remember is that the best way to get the most out of your money is to use a good credit card.
[cpg]

The most important thing to remember is that the best way to get the most out of your money is to be prepared to pay for it.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Hitomi312"]
[OnName num="hitomi"]
"When I put on the mask, I ...... can't control ...... myself.
[cpg cn=true]



[OnName num="keisuke"]
Is that ......?"
[cpg cn=true]



[FACE method="change_1" pos="2/3"]
[VOICE f="Hitomi313"]
[OnName num="hitomi"]
"I'm ...... running that video site ...... and it's me ......."
[cpg cn=true]



[OnName num="keisuke"]
What?　What the hell does that mean ......?
[cpg cn=true]



When I asked, Hitomi began to speak in small, guttural tones.
[cpg]

Here's what it's all about: ......
[cpg]

As part of her research on the brain and psychology, Hitomi started a video streaming site for chat dialogues. She found that she was liberated by the mask she tried on just to hide her face, and she was hooked on the elation.
[cpg]

Eventually, his bossy, go-getter persona, SB, began to venture into relationships with the women and male viewers for whom he was taking data.
[cpg]

He began to manage the pay-per-view rules, and it was getting to the point where it was impossible for the pupil to stop him.
[cpg]

The reason she was working at the cafe was because she wanted to overcome her communal disorder in order to compete with SB as much as possible.
[cpg]

But in the end, the pupils were too weak, and SB continued to run amok, pinching from the women and cunningly taking money from the viewers.
[cpg]

When he took off his mask and returned to his pupil, he felt so guilty that he was left to drift away.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sHitomi020"]
[OnName num="hitomi"]
"Such a horrible thing ...... to me so ......."
[cpg cn=true]



The eyes that spoke as she wiped away her tears didn't seem to be lying at all.
[cpg]

But it's also true that it's so strange that it's hard to believe it.
[cpg]

[OnName num="keisuke"]
'Isn't your brain research ...... useless?'
[cpg cn=true]



[FACE method="change_1" pos="2/3"]
[VOICE f="Hitomi315"]
[OnName num="hitomi"]
"My this is ...... probably something akin to psychosis, and ...... even if I tried to get data, the SB would get in the way... ..."
[cpg cn=true]



[OnName num="keisuke"]
"Yeah. ......"
[cpg cn=true]



I thought ...... that I had done something that I didn't mean to do, and that I was in my own way, but then I changed my mind, thinking that maybe I was a little close to that, as I devoured pleasure in spite of the pain SB had caused me.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Hitomi316"]
[OnName num="hitomi"]
"Ugh,...... such a woman,...... is disgusting,...... isn't she?"
[cpg cn=true]



Her eyes lamented as she arched her back and shrugged a little.
[cpg]


[free time=1000]
Out of curiosity, I let her put the butterfly mask on her face as a test.
[cpg]

Immediately after that ......
[cpg]

[FG f="CHA03_p1_04_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Hitomi317"]
[OnName num="SB"]
I'm not going to leave you alone now that you know my secret!
[cpg cn=true]



[OnName num="keisuke"]
Ugh...."
[cpg cn=true]

[free time=1000]

In an instant, he recognizes that his eyes have changed to SB, and he immediately removes his mask.
[cpg]

[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Hitomi318"]
[OnName num="hitomi"]
'Oh.....oh....sorry....sorry ......'
[cpg cn=true]



This time, he instantly went back from SB to eyes.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi319"]
[OnName num="hitomi"]
I'm sorry for what you did to me...and what I did to you...and what I did to you...and what you did to me...and what I did to you. ......"
[cpg cn=true]

...... she says. I think that might be a good idea.
[cpg]

I'm not sure if I'm in love with her or not, but I've already had some serious feelings for her.
[cpg]

I'm not sure if I'd call it love. The most important thing to remember is that you can't just take a chance on a new person.
[cpg]

In any case, I can't leave like this.
[cpg]


[OnName num="keisuke"]
I don't want to do that.
[cpg cn=true]


[free time=1000]
I willingly put on the mask again on the face of pupil.
[cpg]

[OnName num="keisuke"]
My queen, ...... punish me!"
[cpg cn=true]



I was licking SB's feet, flat on the floor, begging.
[cpg]

[FG f="CHA03_p1_04_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Hitomi320"]
[OnName num="SB"]
'I don't mind an honest girl.'
[cpg cn=true]



SB smiled and stroked my cheek to neck with her toes.
[cpg]

So ...... I became a slave to the pleasure she brought me.
[cpg]

The pleasure of conquering her eyes seemed like a wonderful thing, but the pleasure SB gives me is many times greater than that.
[cpg]

If any man would give up such a thing, he would be a real fool.
[cpg]

;//移植前シーンカット



;//ブラックアウト
;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『瞳の部屋』

[OnName num="keisuke"]
......... ugh."
[cpg cn=true]



I wonder how many weeks have passed since then .......
[cpg]

I lay my creaking body on the cold floor and thought in a daze.
[cpg]

I have red scars on my back and stomach and rope marks all over my skin.
[cpg]

What am I going to ...... do now?
[cpg]

Every day I experience as much pain and pleasure as I want to by SB.
[cpg]

I don't know where it will lead ...... me.
[cpg]

[OnName num="keisuke"]
My queen. ......?"
[cpg cn=true]



I don't see her in the room.
[cpg]

The warehouse is large, and there are several other rooms, the pupil seems to be doing serious research or something there.
[cpg]

 I may still be writing in a treatise.
[cpg]

I'm sure that's important, but for me, there are more important things to be concerned about.
[cpg]

In other words, I was getting frustrated.
[cpg]

[OnName num="keisuke"]
I've been thinking, "..............."
[cpg cn=true]

I think I had been overstimulated. Suddenly I couldn't give him anything, I...
[cpg]

I hesitated for a moment and reached for the computer on my desk.
[cpg]

;//ワクテカ動画
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『ぇむの部屋』

Just as no one was still in Emu-chan's room, I visited her just to kill some time.
[cpg]

＞Mr. SB has entered the room.
[cpg]
[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="3/7" time=800]
[OnName num="keisuke"]
Oh shit. ......."
[cpg cn=true]



I entered without changing my ID, so SB's name was displayed.
[cpg]

She is a resident of a special room, so it is not surprising that Emu-chan is surprised.
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki502"]
[OnName num="eMU"]
She said, "What?　It's so unusual for ......... to keep that name.'
[cpg cn=true]



[OnName num="SB"]
『え？』
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki503"]
[OnName num="eMU"]
Because you always use the siren's name when you come in.
[cpg cn=true]



[OnName num="keisuke"]
What?
[cpg cn=true]



Siren ......?
[cpg]

Isn't that the nickname you use?
[cpg]

I don't think so. ...... Master's true identity is SB!
[cpg]

I don't know what this means, but it means there's a side of her I haven't been told about yet.
[cpg]

[OnName num="SB"]
'Um, SB's ID, but I'm Kay.'
[cpg cn=true]


[FACE method="change_5" pos="3/7"]
[VOICE f="Misaki504"]
[OnName num="eMU"]
What?　What do you mean?
[cpg cn=true]



When I explained the situation in summary, she hurriedly opened the secret room and urged me to talk about the details there.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ぇむの部屋シークレットルーム』

[FG f="CHA01_p5_02_a.ui" method="change_7"  pos="3/7" time=800]
[VOICE f="Misaki505"]
[OnName num="eMU"]
'So you've been at ...... all the way to Mr. SB's place?
[cpg cn=true]



[OnName num="SB"]
Yes.
[cpg cn=true]



I don't know if I'm enjoying it.
[cpg]

But I'm sure I'm captivated by her.
[cpg]

Then...it's hard to say...," he prefaced, as he listened to her.
[cpg]


[FACE method="change_4" pos="3/7"]
[VOICE f="Misaki506"]
[OnName num="eMU"]
There's a rumor that she's enslaved several people in the past, and when she gets tired of them, she throws them away. ......
[cpg cn=true]



[OnName num="SB"]
'What's that ....... Are you trying to tell me that I'm going to be one of those ......?"
[cpg cn=true]



I said and she apologized.
[cpg]

I'm the one who should be apologizing. She is genuinely concerned about me.
[cpg]

I've heard that many men are torn apart, body and soul.
[cpg]

[OnName num="keisuke"]
「………………」
[cpg cn=true]



I was indeed already a wreck.
[cpg]

My body is being hurt, of course, and I've become a person who can't do without the stimulation.
[cpg]

The most important thing to remember is that you can't just say goodbye to your body and go crazy.
[cpg]

[OnName num="keisuke"]
Oh, no. ......
[cpg cn=true]



I was horrified.
[cpg]

[OnName num="SB"]
No, I don't want to do that!　I'd rather die like that!
[cpg cn=true]


;//＠
[FACE method="change_3" pos="3/7"]
[VOICE f="Misaki507"]
[OnName num="eMU"]
Oh, calm down. I'd rather die like that! If you want to do something H, I'll help you. ......
[cpg cn=true]



[OnName num="SB"]
What?
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki508"]
[OnName num="eMU"]
So please ...... don't tell me you're going to die. Don't tell me you're going to die. ......"
[cpg cn=true]



I'm not going to die," Emu whispered and tried to pull off the front of her clothes.
[cpg]

I felt her white skin heal me from my scars. ......
[cpg]

[OnName num="SB"]
'You're beautiful, Emu-chan. ......
[cpg cn=true]


;//asd
[FACE method="change_7" pos="3/7"]
[VOICE f="sMisaki018"]
[OnName num="eMU"]
'Or does it still have to hurt?
[cpg cn=true]



[OnName num="SB"]
'No, it doesn't......"
[cpg cn=true]


Right after the conversation.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『瞳の部屋』

[SE f="se011"]
;//【ＳＥ】ドア開閉

[FG f="CHA03_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Hitomi341"]
[OnName num="hitomi"]
"Oh ............"
[cpg cn=true]



[OnName num="keisuke"]
!"
[cpg cn=true]



I was relieved that it was the eyes, not SB, that came back into the room, but I was also slightly disappointed.
[cpg]

[OnName num="keisuke"]
I was relieved to see that it was not SB who came back to the room, but an eye, but I was slightly disappointed. Um, where's SB?　I owe my queen an apology!"
[cpg cn=true]



I log out as fast as I can and sit upright on the floor.
[cpg]

Just because it was my eyes that were seen doesn't mean I can hide the memory itself, because it is shared.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Hitomi342"]
[OnName num="hitomi"]
If that is ...... what you want, then .......
[cpg cn=true]



The pupil approaches me with a look of impatience and puts a mask on my face that had been on the pillow.
[cpg]


[FG f="CHA03_p1_04_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Hitomi343"]
[OnName num="SB"]
What do you want...?"
[cpg cn=true]



[OnName num="keisuke"]
Ah!　I'm not sure what to do. That was just a sign of evil ......!
[cpg cn=true]



[VOICE f="Hitomi344"]
[OnName num="SB"]
So ......
[cpg cn=true]



[OnName num="keisuke"]
It won't happen again!　Please punish me!
[cpg cn=true]



[VOICE f="Hitomi345"]
[OnName num="SB"]
No need.
[cpg cn=true]



[OnName num="keisuke"]
「えっ」
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Hitomi346"]
[OnName num="SB"]
And by the way, since I'm no longer streaming videos on you, you can leave anytime you want.
[cpg cn=true]



[OnName num="keisuke"]
"What...what...e......?"
[cpg cn=true]



The words that were just told to me by Emu earlier rushed to my heart.
[cpg]

SB is going to dump me ......?
[cpg]

[OnName num="keisuke"]
'Oh, no, I don't want to do that!　I'll do anything, just let me stay here!"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi347"]
[OnName num="SB"]
'Well, ...... you can do whatever you want, but...'
[cpg cn=true]



The eyes I could see under the mask were boredly looking somewhere that wasn't ...... me.
[cpg]

Am I getting bored ......?
[cpg]

Am I destined to be discarded like a rag in the near future,......?
[cpg]

Thinking of this, I couldn't stop the tears from welling up, but I hid them and turned my back to SB and held my knees in a single thought, not wanting to seem annoying.
[cpg]

Let's just be happy that we have time to make up our minds.
[cpg]

Otherwise, the next time my heart breaks, I'll really ...... be dead.
[cpg]


;//ブラックアウト
;//エフェクト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『瞳の部屋』

It's been a few days since SB stopped playing with me.
[cpg]

I am now just a puppet in this room, eating and breathing the food that Hitomi serves me.
[cpg]

SB and pupil just look at me and don't speak, and don't ask me to leave.
[cpg]

It was as if they were killing me alive, and when I started to think about leaving on my own, it came ......
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Mari477"]
[OnName num="mari"]
'Wow, ...... you really were there.'
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Misaki511"]
[OnName num="eMU"]
I told you, didn't I?　I told you."
[cpg cn=true]



[OnName num="keisuke"]
What the ......?
[cpg cn=true]



In the pupil's room, Emu and Hayashida suddenly appeared and giggled when they saw me lying on the floor.
[cpg]

Why are you two here...?
[cpg]

[free time=800]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_04_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="Hitomi348"]
[OnName num="SB"]
Get your stuff out of here.
[cpg cn=true]


[VOICE f="Misaki512"]
[OnName num="eMU"]
Um, this is ...... for this month."
[cpg cn=true]



The thick envelope that the two offered to SB contained a number of ten thousand bills.
[cpg]

If this is what Hitomi was talking about, then not only Hayashida but also Emu-chan had done such an act.
[cpg]

Or perhaps there is no woman on that site who has not done so.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Mari478"]
[OnName num="mari"]
"That ...... you, if you look closely, Oshida ......!　Psycho...... woman king, this is the guy Atashi was bullying!"
[cpg cn=true]



Hayashida's vulgar laugh gnawed at my heart, but I, lacking spirit, couldn't say anything back.
[cpg]


[FACE method="change_7" pos="3/3"]
[VOICE f="sHitomi021"]
[OnName num="SB"]
So what? So what, you want me to take off my clothes again?"
[cpg cn=true]



[FACE method="change_2" pos="2/3"]
[VOICE f="Mari479"]
[OnName num="mari"]
"Aha, did you see that video?"
[cpg cn=true]



[OnName num="keisuke"]
「！！」
[cpg cn=true]



I was shocked.
[cpg]

I had done many more embarrassing things, but the fact that he had seen that was more painful and embarrassing.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="sMari029"]
[OnName num="mari"]
I was shocked and ashamed. Do you want me to torture you again?"
[cpg cn=true]

Hayashida teased me, even though he had no intention of doing so.
[cpg]



[FACE method="change_7" pos="3/3"]
[VOICE f="sHitomi022"]
[OnName num="SB"]
No, you can't. This is my own slave. This is my own slave. I won't give it to anyone else.
[cpg cn=true]



[OnName num="keisuke"]
"What...what did you just say ......?"
[cpg cn=true]



My hand stopped in surprise.
[cpg]

I looked and saw SB staring at me with his eyes behind the mask.
[cpg]


[FACE method="change_3" pos="3/3"]
[VOICE f="Hitomi356"]
[OnName num="SB"]
I've been hacking into your computer and observing you on a regular basis since we first met on the site.
[cpg cn=true]



[OnName num="keisuke"]
What, huh?
[cpg cn=true]



[FACE method="change_1" pos="3/3"]
[VOICE f="Hitomi357"]
[OnName num="SB"]
'So when you first came to the café, your eyes recognized you.
[cpg cn=true]



[FACE method="change_1" pos="1/3"]
[FACE method="change_1" pos="2/3"]
I couldn't read ahead at all, but I realized that it was something important to talk about and shut up.
[cpg]

The two women also stood upright and stared at SB.
[cpg]

[FACE method="change_7" pos="3/3"]
[VOICE f="Hitomi358"]
[OnName num="SB"]
'Originally it was about stopping your dangerous urge for revenge, but eventually it turned into a personal interest.
[cpg cn=true]



[free time=1000]
SB gently removes his mask and reveals his eyes.
[cpg]

[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Hitomi359"]
[OnName num="hitomi"]
'I was attracted to your ...... dangerous or ...... naïve mind. But ...... I'm like this, so ...... SB invites you to ...... Secret for free and ...... me to ...... a lot of things and ...... me."
[cpg cn=true]



[OnName num="keisuke"]
"Oh ...... you were able to do those things because you were an administrator ......?"
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi360"]
[OnName num="hitomi"]
"SB is so great in many ways that ...... dangerous people can get ...... personal information from your credit card.... "SB was so great at all kinds of things, ...... that they would go through your credit cards, ...... your personal information if you were dangerous, ...... your credit card information if you were dangerous, ...... your personal information if you were dangerous, ...... your secrets by hacking, ...... and extorting you.
[cpg cn=true]



[OnName num="keisuke"]
「えええ……」
[cpg cn=true]



[free time=1000]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Misaki516"]
[OnName num="eMU"]
"But it's also ...... that keeps us safe.
[cpg cn=true]



[FACE method="change_7" pos="4/5"]
[VOICE f="Mari483"]
[OnName num="mari"]
"and we're able to make money safely. ......"
[cpg cn=true]



Apparently, the two also knew SB's secret, and they complemented the pupil's words.
[cpg]

[free time=1000]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Hitomi361"]
[OnName num="hitomi"]
But ......SB was very angry with you ...... for behaving that way and ...... did terrible things to you. And then he did it back."
[cpg cn=true]



[OnName num="keisuke"]
"Well, that's ...... natural,......."
[cpg cn=true]



[FACE method="change_3" pos="2/3"]
[VOICE f="Hitomi362"]
[OnName num="hitomi"]
"But I ...... quieted her down and we finally decided together in our hearts recently to end ...... it! ......"
[cpg cn=true]


[free time=1000]
Eyes turned over and put on the mask again.
[cpg]

[FG f="CHA03_p1_04_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Hitomi363"]
[OnName num="SB"]
'But it didn't work.
[cpg cn=true]



[OnName num="keisuke"]
'What about ......?'
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sHitomi023"]
[OnName num="SB"]
'I, who also played your master, knew from the beginning that you were an honest guy, but you were really cute when you became obedient.'
[cpg cn=true]


;//＠
[FACE method="change_7" pos="2/3"]
[VOICE f="sHitomi923"]
[OnName num="SB"]
He was so cute when he became obedient. "He kept telling me that this was not a good idea, and well, I was beginning to think it was, but when I found out that you were getting along with ...... Emu, I was ......... jealous. Intensely."
[cpg cn=true]



[OnName num="keisuke"]
"Yeah,...... well, that's,......
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Hitomi365"]
[OnName num="SB"]
'I am S. Butterfly. As your queen, I love you, my slave."
[cpg cn=true]



I love you. Those words made me tremble from the bottom of my heart.
[cpg]

I had thought about whether this feeling was love or not.
[cpg]

But it was not. I was not satisfied with such ordinary words.
[cpg]

Something more sublime had sprouted in my heart, something I should bet my life on.
[cpg]

[OnName num="keisuke"]
"Ah...ah......joOu, JoOusama!
[cpg cn=true]



[FACE method="change_3" pos="2/3"]
[VOICE f="Hitomi366"]
[OnName num="SB"]
I'm the one who's going to break you. Good!
[cpg cn=true]

I can't believe how pleased I am to be told that I'm going to break you.
[cpg]

I thought that I was already broken, but I was okay with that.
[cpg]

[SE f="se009"]
;//【ＳＥ】鞭

[OnName num="keisuke"]
Hahiii!"
[cpg cn=true]



Who could have imagined that pain and pleasure mixed together would be so good?
[cpg]

I was thinking that I had been thinking of revenge, of mere sexual desire, but now I felt like a phantom.
[cpg]



[free time=1000]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA03_p1_04_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="sMari030"]
[OnName num="mari"]
Ugh,......, my queen,......, what should I do,......?"
[cpg cn=true]



[VOICE f="sHitomi024"]
[OnName num="SB"]
You are watching there, aren't you? I'm not going to let you go to the bathroom.
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Mari485"]
[OnName num="mari"]
Oh, no. ......
[cpg cn=true]



The most important thing to remember is that you can't just take a look at the actual situation and also the way it is going to be.
[cpg]

But I'm already the best.
[cpg]

[free time=1000]
[FG f="CHA03_p1_04_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="keisuke"]
O Mistress, please give me the pleasure of your service.
[cpg cn=true]

;//移植前シーンカット


If the people of the world saw this, they would probably pity and despise me.
[cpg]

But I am much higher than they are.
[cpg]

I am in a spiritual world that cannot be described in such light terms as spirituality.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Hitomi385"]
[OnName num="SB"]
Today is the day you, the human being, became an official slave. So...I will give you a special reward."
[cpg cn=true]



[SE f="se023"]
;//【ＳＥ】蹴る


;//●ＣＧ（瞳：ヒロインにのしかかられる）ev_46
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_46_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=100]

I twisted around and turned onto my back to see two women standing and looking down at me.
[cpg]

[VOICE f="sMari031"]
[OnName num="mari"]
I said, "...... I can't stand it if you don't do anything for me."
[cpg cn=true]



[VOICE f="sMisaki019"]
[OnName num="eMU"]
I'm not going to stand for nothing."
[cpg cn=true]


The two of them also approach me. If I had lived any other way, I would never have found myself in this situation.
[cpg]



;//移植前シーンカット

JoOusama gently strokes my head.
[cpg]



[VOICE f="Hitomi420"]
[OnName num="SB"]
"Let's ...... live like this for the rest of our lives."
[cpg cn=true]



[OnName num="keisuke"]
As you wish, ...... mistress.
[cpg cn=true]



Thus I became a resident of H Castle with the promise of eternal pleasure.
[cpg]

I don't have to worry about my life, my eyes, my life, or anything else.
[cpg]

Everything is decided by Butterfly-sama.
[cpg]

I am the happiest slave in the world. ......
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]


...... what will happen to me in the future.
[cpg]

Normal people would be worried, but I was no longer normal.
[cpg]

It's not so much that I've stepped out of the normal into the abnormal, but more that I've stepped out into a world where I don't have to worry about unnecessary things.
[cpg]

Perhaps this is what we call love? No. ......
[cpg]

Even if it is, I can't really say it to her.
[cpg]

I love her so much that the word "love" is too much to use. What a contradiction.
[cpg]

And I don't care if I can't tell her that. I was happy with the way things were.
[cpg]


[SCENE id=11]

;//瞳ルート・完
;//瞳ＥＮＤ

[jump storage="epend.ks" target="*start"]

