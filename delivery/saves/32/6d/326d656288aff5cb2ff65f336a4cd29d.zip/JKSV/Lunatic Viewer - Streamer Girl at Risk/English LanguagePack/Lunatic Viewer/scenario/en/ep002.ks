
*start

;#################################################
*Ep002|観察し耳を澄ませる事
;#################################################

[SCENE id=2]



[stflag Jump_flg = 0]

[if exp={getFlagValue("Jump_flg") == 0 }]


[stflag Jump_flg = 1]

;//フラグ　初期化
[stflag Cha1flg_A = 0]
[stflag Cha1flg_B = 0]
[stflag Cha1flg_C = 0]

[stflag Cha2flg_A = 0]
[stflag Cha2flg_B = 0]
;//[stflag Cha2flg_C = 0]
[stflag Cha3flg_A = 0]
[stflag Cha3flg_B = 0]
[stflag Cha3flg_C = 0]
[stflag Cha3flg_D = 0]

[stflag Cha1flg_la = 0]
[stflag Cha2flg_la = 0]
[stflag Cha3flg_la = 0]

[stflag Cha1flg_lb = 0]
[stflag Cha2flg_lb = 0]
[stflag Cha3flg_lb = 0]
[stflag Cha1flg_lc = 0]

[stflag Evelflg = 0]
[stflag Bad_flg = 0]

[endif]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公（啓介）の部屋』


[OnName num="keisuke"]
Fluffy, ...... it's morning already?"
[cpg cn=true]



It is actually around noon, but for me, all daytime is morning.
[cpg]

As soon as I woke up, I started up my computer and found a message from my mentor.
[cpg]


'Dear Kay: Have you changed your mind since then?　Have you gotten a little closer to the girls?'
[cpg]


'If you're feeling impatient, I'd recommend you to be more attentive and observant, and listen carefully to conversations you're not interested in.
[cpg]


If you pay attention to the changing situation, you may become more imaginative and have more fun. From the Master.
[cpg]



[OnName num="keisuke"]
I don't understand what you mean when you say that.
[cpg cn=true]



By changing situations, do you mean chatting?
[cpg]

Frankly, I don't need female conversations with other guys...
[cpg]

I want one-on-one contact if possible.
[cpg]

Especially...with Emu.
[cpg]

That girl is really kawaii.
[cpg]

She probably doesn't know that the site is a den of old men.
[cpg]

That's why she genuinely enjoys interacting with everyone like she's talking to a friend.
[cpg]

I wish she would stop doing that ......, but if she does, I'll never see her again.
[cpg]

This kind of thing is called a dilemma.
[cpg]

[OnName num="keisuke"]
"Well ...... what shall I do today?"
[cpg cn=true]



;//■選択肢（３日目昼）四択
[switch]
[case "Go online"]
	[swap]
	[jump target="*select08_1"]
[case "Go to a bookstore"]
	[swap]
	[jump target="*select09_2"]
[case "Go to a cafe"]
	[swap]
	[jump target="*select09_3"]
[case "Go to the park"]
	[swap]
	[jump target="*select09_4"]
[endswitch]

1. go online;// (*evil +1)
2、Go to a bookstore;// (★MISAKI c acquired)
3, Go to the cafe;// (◆Mari Flag A) (*Eye a)
4、Go to the park;// (*Evil +1)

;//==========================
;//１，ネットをする（★悪＋１）
*select08_1|観察し耳を澄ませる事

[stflag Bad_flg=-1]

[OnName num="keisuke"]
"Is there a room that's open during the day?"
[cpg cn=true]



I quickly hovered over the wacky video, as if I'd already reopened it.
[cpg]

;//ワクテカ動画

[OnName num="keisuke"]
Hmmm...not so good."
[cpg cn=true]



I checked out the distributors currently broadcasting live at the entrance, but I couldn't seem to get a bite.
[cpg]

I had already learned my lesson with Hayashida, so suddenly going secret was out of the question, and even other than that, many of them looked like housewives with children or women of the night, so I was put off.
[cpg]

But when I thought about it, there was no way that a decent girl of my age would be delivering at this hour of the night.
[cpg]

[OnName num="keisuke"]
I guess it can't be helped..."
[cpg cn=true]



I'll look in the chat room and if no one is there, I'll give up.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_7.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『雑談ルーム』

＞ケイさんが入室されました
[cpg]

There were apparently several people in the chat room, and I could see a few familiar names among them.
[cpg]

[OnName num="kumachan"]
'Oh, Mr. Kay.
[cpg cn=true]



[OnName num="KEI"]
'Oh, hi. Mr. Kumachan.
[cpg cn=true]



[OnName num="kumachan"]
'You can call me Bear-chan.
[cpg cn=true]



You can't say I don't like ......, after all.
[cpg]

[OnName num="KEI"]
"Well, let's call him Bear."
[cpg cn=true]



[OnName num="oac"]
Hi, hello. Off today?
[cpg cn=true]



[OnName num="KEI"]
'Hello, Mr. Oak. Speaking of vacations, I'm off. Are you two off too?
[cpg cn=true]



The bear and the orc continued their conversation, thinking that since they were regulars in Emu's room, there would be no harm in being friendly with them.
[cpg]

[OnName num="oac"]
I'm on my lunch break. I'm on my phone, so sorry if I'm typing too slowly.
[cpg cn=true]



[OnName num="kumachan"]
I'm at work.
[cpg cn=true]



[OnName num="KEI"]
Are you sure you're okay?
[cpg cn=true]



[OnName num="oac"]
I'm fine. I'm working on my phone, so I'm sorry if I'm late.
[cpg cn=true]



[OnName num="kumachan"]
Don't be so sure.
[cpg cn=true]



[OnName num="KEI"]
Home security?
[cpg cn=true]



[OnName num="kumachan"]
What?
[cpg cn=true]



[OnName num="oac"]
"Oh, Mr. Kay, you don't know?　You're new to the Internet, aren't you?
[cpg cn=true]



[OnName num="KEI"]
I'm sorry...
[cpg cn=true]



[OnName num="oac"]
I'm sorry... A home security guard is a person who is a stay-at-home NEET.
[cpg cn=true]



[OnName num="kumachan"]
Duplicate.
[cpg cn=true]



I didn't know there was another way to put it.
[cpg]

I'm a home security guard. ...... me too.
[cpg]

[OnName num="kumachan"]
Well, because I'm a home security guard, I can respond to any live feed at any time, so I have nothing to be ashamed of!
[cpg cn=true]



No, you should be ashamed...
[cpg]

I thought to myself, "Well, I'm a home security guard, so I can handle a live delivery at any time.
[cpg]

[OnName num="KEI"]
'When and when, Emu-chan, do you sometimes deliver during the daytime?
[cpg cn=true]



[OnName num="kumachan"]
'Sometimes.
[cpg cn=true]



[OnName num="KEI"]
'Heh.
[cpg cn=true]



[OnName num="oac"]
"That's why I check it during my break.
[cpg cn=true]



[OnName num="KEI"]
I see.
[cpg cn=true]



Daytime was a blind spot.
[cpg]

I thought it was only during the night when it is usually fixed.
[cpg]

[OnName num="oac"]
The actuality is that the actuality is that the actuality is not really a good idea. You are quite tough, aren't you, Emu-chan?
[cpg cn=true]



[OnName num="kumachan"]
I'll never go to Secret. I never go to secret places.
[cpg cn=true]



Is that so...?
[cpg]

I'm sure she's as innocent as I imagined her to be.
[cpg]

[OnName num="yaminabebugyo"]
That's not true.
[cpg cn=true]



[OnName num="kumachan"]
Hey, Inquisitor... how long have you been here?
[cpg cn=true]



[OnName num="oac"]
What do you mean, that's not true?
[cpg cn=true]



[OnName num="yaminabebugyo"]
Because I've been in a secret room with her.
[cpg cn=true]



[OnName num="KEI"]
『え』
[cpg cn=true]



[OnName num="kumachan"]
What?
[cpg cn=true]



[OnName num="oac"]
Are you serious?
[cpg cn=true]



[OnName num="kumachan"]
What did you talk about?　And what did you tell her?
[cpg cn=true]



[OnName num="yaminabebugyo"]
"Well, something I'm not at liberty to say."
[cpg cn=true]



[OnName num="oac"]
"What?　Seriously?
[cpg cn=true]



[OnName num="KEI"]
What's that?
[cpg cn=true]



[OnName num="kumachan"]
No, no, no, no!　That's impossible!
[cpg cn=true]



My eyes went blank. It was enough to shatter my faint hope cruelly.
[cpg]



[OnName num="yaminabebugyo"]
I'm not lying. It was very good.
[cpg cn=true]


What did he mean by "good"?
[cpg]


[OnName num="oac"]
Noooooooooooooooooooooooooooooooooooooooooooooooooooo!　I'm so shocked...'
[cpg cn=true]



[OnName num="kumachan"]
I thought Emu-chan was everyone's idol. ......
[cpg cn=true]



[OnName num="yaminabebugyo"]
'Well, don't be so disappointed. If you guys can negotiate a good time when you are alone, you will be able to get him to ask you out.
[cpg cn=true]



The inorganic text showed no sign of my upset, sadness, or anger.
[cpg]



[OnName num="KEI"]
'How many times have you gone secret?
[cpg cn=true]



[OnName num="yaminabebugyo"]
'Mm-hmm. Besides, she wants to meet me in person.
[cpg cn=true]

[OnName num="yaminabebugyo"]
She made me buy her dinner, she begged me for presents, and it was difficult..."
[cpg cn=true]


＞Oak has left the room.[r]
＞Bear has left the room.[r]
[cpg]

The ......2 person fell silent, probably because he couldn't stay.
[cpg]




[OnName num="yaminabebugyo"]
The first time I saw him, I thought, 'Well, I don't know what they'll make me give away this time, but I'm going to get my money back.
[cpg cn=true]



[OnName num="keisuke"]
'..................'
[cpg cn=true]



I'm at the end of my rope, too, and log out without even saying hello, just like the two before me.
[cpg]

I'm not sure if I'm in love with her or not, but I don't think I'm in love with her.
[cpg]

It's not love or anything like that, but it's just too much .......
[cpg]

At least I got to know her true nature before I got too serious and didn't have to pay her a tribute.
[cpg]

In that sense, I have to thank the Dark Pot Inquisitor.
[cpg]

[OnName num="keisuke"]
Damn ...... and all of them."
[cpg cn=true]



Hayashida, Emu, and in the end, women are all shit. ......
[cpg]

They all make fun of me.
[cpg]

They despise me, they play with me, they treat me like an insect, and they enjoy it. ......
[cpg]

[OnName num="keisuke"]
Fuck you!"
[cpg cn=true]



I pound my fist on the bed mat over and over again.
[cpg]

[OnName num="keisuke"]
'I'm sick of being the fucked ...... I'll be the one doing it .......
[cpg cn=true]



Revenge .......
[cpg]

The two words were blazing up in my mind.
[cpg]

[OnName num="keisuke"]
"Be cool,...... and do it calmly,......."
[cpg cn=true]



Keep your normal self until you get the chance.
[cpg]

Keep your normal, unsuspecting ...... face and wait for the ...... opportunity. ......
[cpg]

;//３日目夜へ

[jump target="*select08_9"]
;//==========================
*select08_2|観察し耳を澄ませる事

;//b,本屋（★美咲c）
*select09_2|観察し耳を澄ませる事

[stflag Cha1flg_lc = 1]

[OnName num="keisuke"]
"Let's go to the bookstore..."
[cpg cn=true]



I decided to go to the bookstore.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『本屋』

When I arrived at the bookstore, I looked around the magazine section.
[cpg]

[OnName num="keisuke"]
I found this one: "Oh...this is ......."
[cpg cn=true]



Among the fashion magazines, a slightly sexy cover caught my eye.
[cpg]

I glanced around and saw that it appeared to be a magazine specializing in women's lingerie.
[cpg]

[OnName num="keisuke"]
Hmmm...I see."
[cpg cn=true]



It explains the materials used, such as lace and silk, and recommends uses for them, in detail next to the underwear models.
[cpg]

Since the models were foreigners, all the underwear looked extremely expensive, but when I looked at the prices, I found that they were not so expensive.
[cpg]

The prices are quite different from those of the underwear I wear, but they are different from the ones I have seen on the Internet that cost more than 10,000 yen per piece.
[cpg]

They look the same, but I don't know what the difference is...
[cpg]

By the way, my underwear is the kind that my mother buys in bulk, three pairs for 1,000 yen or so.
[cpg]

I wonder if I should just graduate from those and go for something cooler....
[cpg]

But I think it's not a waste of money, since no one will see them anyway, but I also think it's not a waste of money to buy boxer shorts rather than have my pants pulled down in class and be laughed at.
[cpg]

But...there's something crazy about changing your underwear in preparation for that.
[cpg]

What am I supposed to do .......
[cpg]

[OnName num="keisuke"]
I shouldn't..."
[cpg cn=true]



It's unhealthy to think like this.
[cpg]

Instead, you should be thinking about women, since you're looking at a women's lingerie magazine.
[cpg]

Emu-chan ...... what kind of underwear do they usually wear?
[cpg]

The face of the foreign model changes to Emu-chan in my brain.
[cpg]

[OnName num="keisuke"]
Oh..."
[cpg cn=true]



Then, for some reason, her face changes to Hayashida's. "You're not wanted.
[cpg]

[OnName num="keisuke"]
I don't want you here.
[cpg cn=true]



I don't care what Hayashida is wearing.
[cpg]

I don't care what Hayashida is wearing. ......... ha.
[cpg]

I'm not sure how long it's been since I've seen a female customer in a bookstore looking at me from a distance.
[cpg]

I'm sure she must have thought I was suspicious as I opened a lingerie magazine while mumbling to myself.
[cpg]

[OnName num="keisuke"]
Oh man..."
[cpg cn=true]



I didn't want to be treated like a pervert.
[cpg]

I quietly closed the magazine, put it back in its original position, and quickly walked away.
[cpg]

[jump target="*select09_9"]
;//==========================
;//c,カフェ（▼麻里フラグA）（★瞳a）
*select09_3|観察し耳を澄ませる事
[stflag Cha2flg_A = 1]
[stflag Cha3flg_la = 1]

[OnName num="keisuke"]
I'm going out for coffee.
[cpg cn=true]



I went outside and headed for a café.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『カフェ』




As I sat down at the cafe and opened the menu, I noticed the words "limited time offer.
[cpg]

I was a little intrigued, so I took a closer look and saw "Banana Parfait.
[cpg]

The banana parfait was limited to this store, and other stores seemed to sell different fruit parfaits.
[cpg]

For example, the west exit store on the other side of the station offers a marron parfait.
[cpg]

For example, the West Exit store on the other side of the station sells a marron parfait, while the store in the next town offers a muscat parfait, and so on.
[cpg]

Indeed, all the pictures on the website look delicious.
[cpg]

I don't feel like going to many places just for the sake of it, but I decided to try their parfait.
[cpg]

[OnName num="keisuke"]
Excuse me, sir...
[cpg cn=true]

;//qwe

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hitomi097"]
[OnName num="sober_staff"]
...... yes."
[cpg cn=true]



I raised my hand and a plain female waitress came up to me with a small reply.
[cpg]

It was a little creepy....
[cpg]

[OnName num="keisuke"]
American and...this...banana parfait one ......
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi098"]
[OnName num="sober_staff"]
"We can also...increase the banana .........but ......"
[cpg cn=true]



[OnName num="keisuke"]
"Well... then, please. ......
[cpg cn=true]



[FACE method="change_1" pos="2/3"]
[VOICE f="Hitomi099"]
[OnName num="sober_staff"]
Yes, sir. ......
[cpg cn=true]



[free time=1000]
Even the picture on the menu shows a lot of bananas, so where would they put more bananas?
[cpg]

I ordered more bananas and made it my snack for the day.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Hitomi100"]
[OnName num="sober_staff"]
Here you go: ......
[cpg cn=true]



[OnName num="keisuke"]
Dowwww!
[cpg cn=true]



The parfait with more bananas that was brought to me shortly after was so full of bananas that I could hardly contain my screams.
[cpg]

But when I took a bite of it, I found that it was really delicious, especially with the chocolate sauce on top.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi101"]
[OnName num="sober_staff"]
How do you like it.........
[cpg cn=true]



[OnName num="keisuke"]
It's like...I feel like I'm in the Philippines..."
[cpg cn=true]



[FACE method="change_5" pos="2/3"]
[VOICE f="Hitomi102"]
[OnName num="sober_staff"]
What about ......?
[cpg cn=true]



[OnName num="keisuke"]
"Well, uh...bananas...I had an image that they originated in the Philippines. ......"
[cpg cn=true]



Was it a little strange to bring up the place of origin when commenting on food?
[cpg]

I should have said "mild" or "exquisitely sweet.
[cpg]

[free time=1000]

I was so relieved when the humble waitress went away, and I ate the parfait as much as I wanted to.
[cpg]

It was delicious.
[cpg]

I was satisfied.
[cpg]

[jump target="*select09_9"]
;//==========================
;//d,公園（★凶＋１）（※他も回れる仕様にしている場合も、公園のイベント後は強制帰宅）
*select09_4|観察し耳を澄ませる事

[stflag Evelflg=-1]

[OnName num="keisuke"]
"Let's go hang out in the park..."
[cpg cn=true]



My body has been so limp since I came into this life that I decided to at least imitate walking in the park.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『公園』




[SE f="se002"]
;//【ＳＥ】子供の遊ぶ声

[OnName num="keisuke"]
I thought I'd at least try to mimic walking in the park. ......
[cpg cn=true]



The park is rather large, but it is a place with playground equipment for children, and not a single person is walking there.
[cpg]

[OnName num="keisuke"]
How is it to walk around here ......?
[cpg cn=true]



In this day and age, you can't be sure you won't be treated as a prowler.
[cpg]

I'd better not do that....
[cpg]

I gave up on exercise and sat down on a bench. ......
[cpg]

[OnName num="keisuke"]
What the...?
[cpg cn=true]



I scooted behind the back of the bench in a panic as I was about to sit down.
[cpg]

I was about to sit down when I crouched down behind the back of the bench, because I saw a familiar uniform at the entrance to the park.
[cpg]

;//制服姿の林田麻里

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mari084"]
[OnName num="mari"]
.........?"
[cpg cn=true]



It's not time for classes to end yet, so why is that guy here?
[cpg]

I can feel the greasy sweat soaking my forehead.
[cpg]

No kidding....
[cpg]

If I run into him in a place like this, what will he say to me again?
[cpg]

I had to somehow avoid him and escape....
[cpg]

That's what I thought, but Hayashida was scurrying around near the entrance and wouldn't move.
[cpg]

Damn it, get out of my way.
[cpg]

Or better yet, go home!
[cpg]

In the meantime, I saw an old man who looked like a businessman approaching Hayashida.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Mari085"]
[OnName num="mari"]
â™"
[cpg cn=true]



Then, Hayashida's face turns into a quick smile, and his arms naturally intertwine into the old man's arms.
[cpg]

Do you know him...?
[cpg]

No, but a fat little middle-aged man like that, who even leaves class to come see me....
[cpg]

It had nothing to do with me, but I was a little curious.
[cpg]

Hayashida and the old man exchanged a few words, and then immediately started walking away.
[cpg]

[OnName num="keisuke"]
........."
[cpg cn=true]



So I quietly followed them both, forgetting to run away.
[cpg]

This so-called ...... tailgating.
[cpg]



I'm not directly contributing money...but...that guy Hayashida skipped class and did something outrageous.
[cpg]

But this is an opportunity ......
[cpg]

Thinking that, I quietly held up my phone ......
[cpg]

But...wait, the shutter makes a pretty loud noise.
[cpg]



If it was just Hayashida, or if there was a guy, I would be caught and beaten to a pulp in no time.
[cpg]

[OnName num="keisuke"]
Damn...I've just ......
[cpg cn=true]



I bite my lip in frustration as I come to the conclusion that I have no choice but to pass up the opportunity.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Mari091"]
[OnName num="mari"]
See you later."
[cpg cn=true]




And the day seemed to end without incident, but...
[cpg]



;//●ＣＧ（麻里。背後から迫られる、背景はトイレから公園の茂みに変更）ev_08
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=100]

;//移植前シーンカット

[VOICE f="sMari009"]
[OnName num="mari"]
I was like, "Hey, ......, you can't do that. What are you going to do?
[cpg cn=true]



[OnName num="middle_aged_man"]
You smell good.
[cpg cn=true]

[VOICE f="sMari010"]
[OnName num="mari"]
You can't flatter me by saying anything.
[cpg cn=true]


The man who is closely following Hayashida.
[cpg]


I can't watch him, but I have to watch him, and more importantly, I have to take his picture.
[cpg]


But the courage to do so didn't come from me.
[cpg]


As far as distance, I'm close enough to escape if I wanted to.
[cpg]


;**【ＣＧ】 ev_08_0 ***********************
[CG id=5 index=1 time=100]
;***************************************
[WAIT time=100]


[VOICE f="sMari011"]
[OnName num="mari"]
"Ticklish. ...... nn."
[cpg cn=true]



A man touching her hair. Hayashida doesn't seem to really dislike it.
[cpg]


He also said there was something he wanted.
[cpg]

;**【ＣＧ】 ev_08_0 ***********************
[CG id=5 index=0 time=100]
;***************************************
[WAIT time=100]


[VOICE f="sMari012"]
[OnName num="mari"]
I'm really not going to do that. Yes, that's it for today."
[cpg cn=true]



[OnName num="middle_aged_man"]
I don't have a choice.
[cpg cn=true]


The man withdrew very easily.
[cpg]


But in a place like this, where you don't know who's around, just being shouted at is the end of it.
[cpg]


When I think about it, I can understand his behavior.
[cpg]



;//公園

[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=2000]

And this was after Hayashida left the place.
[cpg]


[BGM f="bg_d1"]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]

[OnName num="middle_aged_man"]
"......... you can come out now."
[cpg cn=true]






[OnName num="keisuke"]
"......?
[cpg cn=true]



[OnName num="middle_aged_man"]
I knew you were watching."
[cpg cn=true]



Seriously...huh?
[cpg]

I thought all was well when the old man called out to me and I showed up.
[cpg]

[OnName num="keisuke"]
He says, "......, sir, I'm sorry."
[cpg cn=true]



[OnName num="middle_aged_man"]
It's okay. It doesn't make me look any less of a person.
[cpg cn=true]



The old man didn't seem to be offended and even smiled quietly.
[cpg]

[OnName num="keisuke"]
I will not tell anyone about this.
[cpg cn=true]



[OnName num="middle_aged_man"]
Yes, please. I'll ask you to do that. But, you know, ......
[cpg cn=true]



[OnName num="keisuke"]
What?
[cpg cn=true]



[OnName num="middle_aged_man"]
Why are women so dry nowadays? And they're dirty with money.
[cpg cn=true]



[OnName num="keisuke"]
Huh..."
[cpg cn=true]



I thought ...... that it's not just nowadays, or just that Hayashida is like that, but I don't want to say it out loud.
[cpg]

[OnName num="middle_aged_man"]
'You lick an adult.... You're going to get hurt someday..."
[cpg cn=true]



The angry look on his face was quite scary, so I bailed and left the place as if to run away.
[cpg]


I had never felt such a sense of relief from the sunlight and fresh air.
[cpg]


[OnName num="keisuke"]
Reality is a bitch. ......
[cpg cn=true]


[jump target="*select09_9"]
;//この日の外出を終えたら、以下に展開
;//==========================
*select08_9|観察し耳を澄ませる事
*select09_9|観察し耳を澄ませる事

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=100]

;//【ＢＧ】『主人公（啓介）の部屋』




When I returned to my room and started up my computer, I received a message.
[cpg]

It was from my mentor, and it said only, "Someone is saying something in the chat room.
[cpg]

I checked the time I received the message and it was only a few minutes before, so I decided to go to the chat room of Wakuteka Video.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_7.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『雑談ルーム』

[OnName num="yaminabebugyo"]
'I'm telling you it's true!
[cpg cn=true]



[OnName num="oac"]
'I told you it's not true!
[cpg cn=true]



There was some kind of argument going on.
[cpg]

[OnName num="KEI"]
'Um, what's going on?'
[cpg cn=true]



[OnName num="siren"]
'Oh, you're here.
[cpg cn=true]



When I called out to him, only the master responded.
[cpg]

[OnName num="siren"]
'Yami Nabe-kun blew the whistle that he and Emu-chan had joined Secret, and the other regulars in that room took a bite out of it.
[cpg cn=true]



[OnName num="KEI"]
『え？』
[cpg cn=true]



[OnName num="siren"]
"I don't hear much about Emu-chan doing Secret, so I thought Yakanabe-kun was lying.
[cpg cn=true]



[OnName num="yaminabebugyo"]
"You don't believe me if you want, but I paid to get in!
[cpg cn=true]



[OnName num="oac"]
"No way!"
[cpg cn=true]



[OnName num="KEI"]
"You wouldn't do that, would you?
[cpg cn=true]



[OnName num="yaminabebugyo"]
You don't believe me either?　But you do realize that all the girls on live TV are attention-seeking, man-hungry guys, right?
[cpg cn=true]



That's ......
[cpg]

It's true that I don't understand why the innocent Emu-chan is doing live-distribution .......
[cpg]

She doesn't seem to be a show-off, so what's the point of going out of her way to expose herself and her room and invite a lot of strangers?
[cpg]

[OnName num="KEI"]
What do you think, siren?"
[cpg cn=true]



Once I typed with my mentor and quickly typed back, I asked him for his opinion.
[cpg]

[OnName num="siren"]
'The girls are flesh and blood too. Just like in the real world, if they like someone, it is natural for them to get close to him or her.
[cpg cn=true]



[OnName num="siren"]
Even idols in the real world, who have been banned from romance, actually go out at night and have fun, and are immediately reported in the photo magazines.
[cpg cn=true]



[OnName num="KEI"]
'So you think it's the same with Emu-chan?
[cpg cn=true]



[OnName num="siren"]
"I'm not sure, but I don't think you should have too many illusions either.
[cpg cn=true]



[OnName num="keisuke"]
「………………」
[cpg cn=true]



The words of the master, the words of the dark pot. ......
[cpg]

That's right. ...... Every woman is in love for herself behind the scenes.
[cpg]


Emu-chan was not the only exception. All women are in love with someone else, just not with me.
[cpg]

When I thought about that, I started to feel a strange blurring in my heart.
[cpg]

I want to ...... do something about it.
[cpg]



[OnName num="yaminabebugyo"]
I'm sure you guys will do your best to get to the secret. Of course, I'll be working hard until I meet you in real life, too!
[cpg cn=true]



I'll do my best until I meet him in real life!
[cpg]

Is this guy even thinking about losing that girl in the real world?
[cpg]

I don't want to lose ..........
[cpg]

I don't know what kind of man Yami Nabe is, but I'm going to ...... clench my fists before he does.
[cpg]

[OnName num="siren"]
'Well, well, don't think too much.'
[cpg cn=true]




;//ブラックアウト
;//エフェクト

;//３日目夜
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公（啓介）の部屋』



Night falls, and as usual, I sit down in front of my computer.
[cpg]

;//パソコン画面：ワクテカ動画
Emu's Room": opens today at 8:00 p.m.[r]
Lian's World" opens today at 8:00 p.m.[r]
H Castle": Opens today at 10:00 p.m.
[cpg]

[OnName num="keisuke"]
Now, which room shall we go to today?
[cpg cn=true]



;//■選択肢（３日目夜）３択
[switch]
[case "Emu's Room"]
	[swap]
	[jump target="*select10_1"]
[case "Lian's World"]
	[swap]
	[jump target="*select10_2"]
[case "H Castle"]
	[swap]
	[jump target="*select10_3"]
[endswitch]

1，Gemu's Room;// (◆MISAKI gets Flag A)
2，Lian's World;// (◆Mari Flag A)
3，H Castle;// (◆Eye Flag C obtained depending on whether or not *Eye a exists) C obtained)
;//=============================================================================
;//１，ぇむの部屋
*select10_1|観察し耳を澄ませる事

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ぇむの部屋』

＞Kay has entered the room.[r]
[cpg]

[FG f="CHA01_p5_02_a.ui" method="change_2"  pos="3/7" time=800]
[VOICE f="Misaki059"]
[OnName num="eMU"]
"Ah, Kay, welcome."
[cpg cn=true]



[OnName num="aaa"]
"Don't change the subject.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki060"]
[OnName num="eMU"]
"I'm not trying to distract you..."
[cpg cn=true]



[OnName num="kumachan"]
I am!
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki061"]
[OnName num="eMU"]
"Well... my favorite convenience store is Seven Top."
[cpg cn=true]



[OnName num="yaminabebugyo"]
"Which one?"
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki062"]
[OnName num="eMU"]
Where? In my neighborhood.
[cpg cn=true]



[OnName num="oac"]
Neighborhood? What's the nearest station?
[cpg cn=true]



What the hell?　What are you talking about?
[cpg]

I thought I was the first one to arrive, but I was already very excited.
[cpg]

[OnName num="kanata"]
For example, how many minutes walk from your house is there a Seven Top?
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki063"]
[OnName num="eMU"]
'About five minutes...?'
[cpg cn=true]



I thought, "What are they going to do when they hear that?
[cpg]

Perhaps these guys are trying to locate Emu-chan's home based on that information?
[cpg]

However, Seven Top is a major convenience store that can be found anywhere within a short walk.
[cpg]

A five-minute walk from there would be enough for most people's residences, wouldn't it?
[cpg]

Ah...so you're also trying to find the nearest train station.
[cpg]

But even if they could identify the station, there's no way they would know that...
[cpg]

I decided not to join them in their futile efforts, but to observe Emu-chan's room.
[cpg]

That's when ......
[cpg]

Noboru Yamadayama!　Please cast a clean vote for Noboru Yamadayama!"
[cpg]



I heard the sound of an election car coming from the speakers of my computer.
[cpg]

[OnName num="keisuke"]
"How noisy..."
[cpg cn=true]



Election cars aren't supposed to make noise at night, but the voting day is coming, so they're getting desperate?
[cpg]

But I guess this candidate will be eliminated from the race at the drop of a hat because of the infraction.
[cpg]

Not that it matters to me....
[cpg]

But where is this sound coming from: .......
[cpg]


;//■選択肢_夜_３日目_ぇむ

;//クリックポイント
[stflag mselecter13_cnt = 2]
*mselecter03|To observe and listen carefully.
[if exp={getFlagValue("mselecter13_cnt") == 0}]
[jump target="*3niend_em"]
[endif]

[switch]
[case "Emu's face"]
	[swap]
	[jump target="*Msel3_01"]
[case "Emu's chest"]
	[swap]
	[jump target="*Msel3_02"]
[case "Emu's head."]
	[swap]
	[jump target="*Msel3_03"]
[case "The window."]
	[swap]
	[jump target="*Msel3_04"]
[case "ベッド"]
	[swap]
	[jump target="*Msel3_05"]
[case "Stuffed animal"]
	[swap]
	[jump target="*Msel3_06"]
[case "The door."]
	[swap]
	[jump target="*Msel3_07"]
[endswitch]

;//==========================
;//ぇむの顔
*Msel3_01|観察し耳を澄ませる事

[stflag mselecter13_cnt=-1]

Emu's face.
[cpg]

Her smooth skin.
[cpg]

I want to touch her cheeks just once.
[cpg]

[jump target="*mselecter03"]
;//==========================
;//ぇむの胸
*Msel3_02|観察し耳を澄ませる事

[stflag mselecter13_cnt=-1]

Her breasts are like Kagamimochi (mirror-shaped rice cakes).
[cpg]

I wonder what it would feel like to touch them...
[cpg]

[jump target="*mselecter03"]
;//==========================
;//ぇむの頭
*Msel3_03|観察し耳を澄ませる事

[stflag mselecter13_cnt=-1]

I heard that girls like to have their heads nudged.
[cpg]

I wonder if it feels good when she does that....
[cpg]

I would do that much for her anytime.
[cpg]

[jump target="*mselecter03"]
;//==========================
;//窓（◆美咲フラグＡ　取得）
*Msel3_04|観察し耳を澄ませる事

[stflag mselecter13_cnt=-1]

[if exp={getFlagValue("Cha1flg_A") == 0 }]
[stflag Cha1flg_A = 1]
[endif]


"Noboru Yamadayama is here to make a final request!"
[cpg]

Here we are!
[cpg]

That noisy sound of the campaign car seemed to be coming from her broadcast.
[cpg]

I found out that a campaign car was passing outside Emu-chan's window.
[cpg]

What a nuisance....
[cpg]


[jump target="*mselecter03"]
;//==========================
;//ベッド
*Msel3_05|観察し耳を澄ませる事

[stflag mselecter13_cnt=-1]

I'm almost jealous of the bed when I think she's sleeping in this lovely bed.
[cpg]

[jump target="*mselecter03"]
;//==========================
;//ぬいぐるみ
*Msel3_06|観察し耳を澄ませる事

[stflag mselecter13_cnt=-1]

If it's a gift from a man, I wouldn't be surprised if there are listening devices or hidden cameras inside.
[cpg]

If that's the case, only that guy can hear her embarrassing voice and see her in a way she never shows anyone....
[cpg]

Unforgivable....
[cpg]

[jump target="*mselecter03"]
;//==========================
;//ドア
*Msel3_07|観察し耳を澄ませる事

[stflag mselecter13_cnt=-1]

I want to open that door right now and enter the real Emu's room.
[cpg]

And I want to touch her and enjoy the reality as much as I want....
[cpg]

[jump target="*mselecter03"]
;//==========================
;//２箇所クリック後
*3niend_em|観察し耳を澄ませる事
[OnName num="yaminabebugyo"]
"So, what kind of underwear are you wearing today?
[cpg cn=true]



[OnName num="aaa"]
What color?
[cpg cn=true]


[FACE method="change_6" pos="3/7"]
[VOICE f="sMisaki001"]
[OnName num="eMU"]
I can't tell you that."
[cpg cn=true]



Apparently, the regulars are getting excited tonight...
[cpg]

[OnName num="kanata"]
'Where's the underwear from?
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki065"]
[OnName num="eMU"]
"It's called, um, P.S."
[cpg cn=true]



[OnName num="kumachan"]
What's that?
[cpg cn=true]



[VOICE f="Misaki066"]
[OnName num="eMU"]
"No, it's called ....... Do you know what it is, Kay?
[cpg cn=true]



[OnName num="keisuke"]
What is ......?
[cpg cn=true]



;//★美咲cがない場合　→;//3日目夜ぇむ終了　へ進行
[if exp={getFlagValue("Cha1flg_lc") == 1}]
[jump target="*misaki_lc"]
[endif]

;//3日目夜ぇむ終了

[OnName num="KEI"]
"P-S is ...... P.S."
[cpg cn=true]



[OnName num="kumachan"]
I'm sure it's not. No, it's right in a way.
[cpg cn=true]



No, it's not... but I have no idea.
[cpg]

[OnName num="yaminabebugyo"]
"Since no one else can, why don't we have a secret unveiling of it now?
[cpg cn=true]



[OnName num="oac"]
"Aye!
[cpg cn=true]



[OnName num="aaa"]
"Aye!"
[cpg cn=true]


[FACE method="change_4" pos="3/7"]
[VOICE f="Misaki067"]
[OnName num="eMU"]
Yes!　...I don't know, you all seem a little strange today. I'm feeling a little under the weather and I'm going to ...... close it now. Sorry ......."
[cpg cn=true]



[OnName num="keisuke"]
「あ」
[cpg cn=true]



;//単色画面
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

I got dropped.
[cpg]

It's because of these guys' guts.
[cpg]

I guess when they heard about the dark pot, they were in a hurry and tried to make things more H, but it turned out to be the opposite of what they wanted.
[cpg]

I'm really annoyed that I'm the one who got dragged into it.
[cpg]



;//＠
[if exp={getFlagValue("Cha1flg_A") == 1 }]
[jump target="*cha1flg_A"]
[endif]


But there was nothing I could do about it, so I logged out and played the game until I fell asleep.
[cpg]

;//３日目の師匠　へ
[jump target="*3day_end"]
;//==========================
;//★美咲cがある場合

*misaki_lc|観察し耳を澄ませる事

[OnName num="KEI"]
"What is P.S.?
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki068"]
[OnName num="eMU"]
What's P.S.?"
[cpg cn=true]



[OnName num="KEI"]
"It stands for a brand of underwear called Peach Shot."
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki069"]
[OnName num="eMU"]
Correct!　Kay, that's amazing.
[cpg cn=true]



[OnName num="kanata"]
Seriously?
[cpg cn=true]



[OnName num="kumachan"]
Who is Mr. Kay?
[cpg cn=true]



[OnName num="yaminabebugyo"]
"Not to be underestimated..."
[cpg cn=true]



[OnName num="keisuke"]
"Hmm, hmm..."
[cpg cn=true]



It was a good thing I had looked at the magazine during the day.
[cpg]

I remembered the name of the manufacturer because it was mentioned many times in the book.
[cpg]

[OnName num="aaa"]
I had remembered it because the name of the manufacturer had been mentioned so many times in the book. I don't care about the maker. What's important is you, Emu-chan.
[cpg cn=true]




[FACE method="change_7" pos="3/7"]
[VOICE f="sMisaki002"]
[OnName num="eMU"]
"...Everyone is a little strange ...... today. Kay-kun, um, ...... would you like to talk alone tonight?
[cpg cn=true]



[OnName num="KEI"]
I'm not sure what to say, but I'm sure I'll be fine. Of course.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki071"]
[OnName num="eMU"]
I'll send you a message. I'll send you a message and you can come to the secret room.
[cpg cn=true]



[OnName num="yaminabebugyo"]
"Hey, that's not gonna happen!
[cpg cn=true]



[OnName num="kumachan"]
I won't say it again!
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki072"]
[OnName num="eMU"]
I'm not going to tell you again!" "You should feel a little sorry for yourself. See you all tomorrow.
[cpg cn=true]



[OnName num="oac"]
'Eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee!
[cpg cn=true]



Suck on that.
[cpg]

I wouldn't like that kind of blatant attitude, even if I were a woman.
[cpg]

I open the message I received right after that, get the code, and head to the secret room.
[cpg]

The screen asking me to make a deposit showed a minimum amount of 100 yen, which made me doubt my eyes a little, but I felt relieved and entered without hesitation.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_ya"]
[WAIT time=100]
;//【ＢＧ】『ぇむの部屋シークレットルーム』

[FG f="CHA01_p5_02_a.ui" method="change_2"  pos="3/7" time=800]
[VOICE f="Misaki073"]
[OnName num="eMU"]
I was a bit skeptical, but I didn't hesitate to enter the room.
[cpg cn=true]



[OnName num="KEI"]
Hello.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki074"]
[OnName num="eMU"]
I'm sorry about today. Something is wrong with everyone.
[cpg cn=true]



[OnName num="KEI"]
It's not your fault.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki075"]
[OnName num="eMU"]
Thank you. It helps me if you say so.
[cpg cn=true]



Emu-chan smiled a little apologetically.
[cpg]

The face is really angelic, and it is hard to believe that there is something behind the scenes like Yami Nabe said.
[cpg]

[OnName num="KEI"]
'Is P.S. your favorite?
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki076"]
[OnName num="eMU"]
'Yes. It's a little expensive, but it's gentle on the skin. My skin is a little sensitive, and some products make my skin itch.
[cpg cn=true]



[OnName num="KEI"]
I see. If it's that good, I want to wear P.S. underwear too.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki077"]
[OnName num="eMU"]
"Oh no, hahaha. No, men are not allowed.
[cpg cn=true]



She laughed at my joke.
[cpg]

She is cute...cute...cute. ......
[cpg]

While we were talking like that, she asked me an unexpected question about which lingerie I was wearing.
[cpg]

[OnName num="keisuke"]
Which...where...?
[cpg cn=true]



I panicked.
[cpg]

I immediately searched the Internet for cool underwear.
[cpg]

[OnName num="KEI"]
I always settle for B-B-B boxer shorts.
[cpg cn=true]


[FACE method="change_3" pos="3/7"]
[VOICE f="Misaki078"]
[OnName num="eMU"]
I know!　I know! They're for Hollywood actors, right?　They're cool.
[cpg cn=true]



[OnName num="KEI"]
'Want me to show you?'
[cpg cn=true]



What a surprise. Pfft, I can't show you, that's the good thing about chatting.
[cpg]

But ......
[cpg]

[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki079"]
[OnName num="eMU"]
'Kay, do you have a camera on your computer?　Would you like to video chat with me?"
[cpg cn=true]



[OnName num="keisuke"]
What?　Is that even possible?
[cpg cn=true]



Oh no... even if it were possible, I only have a pair of white briefs!
[cpg]

[OnName num="KEI"]
I'm sorry, I don't have a camera. I don't have a camera.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki080"]
[OnName num="eMU"]
Oh, I see...too bad."
[cpg cn=true]



That was close....
[cpg]

I'm not going to get carried away.
[cpg]

[OnName num="KEI"]
But I'll buy one someday. I'd like to talk to Emu directly.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki081"]
[OnName num="eMU"]
Really?　I'm so happy!　But...don't be too hard on yourself. I got 100 yen from you earlier.
[cpg cn=true]



[OnName num="KEI"]
That's not so much..." "Secret is that you have to pay to open it.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki082"]
[OnName num="eMU"]
I'm sorry, but you have to pay to open the secret.
[cpg cn=true]



[OnName num="KEI"]
I'm sorry.　Is it a system that can't be free?
[cpg cn=true]



According to Emu-chan's explanation, they use a different system from normal rooms to protect users.
[cpg]

He said he couldn't do it here without charging a fee by all means.
[cpg]

She also said that she had been contacted by the manager.
[cpg]
[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki083"]
[OnName num="eMU"]
So, if you want to show me your B.B.B. underwear, I'll pay you 100 yen."
[cpg cn=true]



Emu-chan laughed at the joke.
[cpg]

[OnName num="KEI"]
She laughed and said, "So, does that mean that since I paid 100 yen today, you'll show me P.S.'s underwear?"
[cpg cn=true]


[FACE method="change_6" pos="3/7"]
[VOICE f="Misaki084"]
[OnName num="eMU"]
'Eh, that...?　I wonder if that's what it's going to come down to.
[cpg cn=true]



When Emu-chan realized that she had choked, her eyes swam a little and she was puzzled.
[cpg]

I was impressed just by the fact that she showed this kind of reaction and didn't hate it.
[cpg]


[FACE method="change_7" pos="3/7"]
[VOICE f="sMisaki003"]
[OnName num="eMU"]
I was impressed that she didn't mind showing me this kind of reaction. You mustn't tell anyone.'
[cpg cn=true]



[OnName num="KEI"]
I won't tell.
[cpg cn=true]



I won't tell.
[cpg]

This is my own precious memory.
[cpg]

I won't imitate blowing it up to brag to others like the bastard in the dark pot.
[cpg]

Emu-chan is ......... mine and mine alone.
[cpg]


;//＠
*cha1flg_A|観察し耳を澄ませる事



[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公（啓介）の部屋』




[SE f="se025"]
;//【ＳＥ】キーボード打つ

[OnName num="keisuke"]
If you check out that guy I just mentioned, you'll see ......."
[cpg cn=true]



After I logged out, I started looking into one thing.
[cpg]

It was the constituency of a candidate named "Noboru Yamadayama.
[cpg]

That's because that's where Emu-chan lives.
[cpg]

I guess this is what my teacher was talking about.
[cpg]

Paying attention to the changing situation, I will find a way and open the way.
[cpg]

Where in this district did they break time tonight and run the campaign car at 8:00 p.m.?
[cpg]

Where is the nearest train station?
[cpg]

I pull out a map and mark all the Seven Tops in the district.
[cpg]

Then, I could already feel the presence of Emu-chan in "somewhere in this small circle," whereas it should have been "somewhere in the whole world.
[cpg]

I could already feel the presence of Emu-chan, whose wonderful body I had just seen.
[cpg]

If I looked harder, I could meet her in real life.
[cpg]

If I worked harder, I could touch her in real life.
[cpg]

I must have been possessed by something at this moment.
[cpg]

Something different from revenge, something blacker. ......
[cpg]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
;//エフェクト

;//３日目の師匠　へ
[jump target="*3day_end"]
;//==========================
;//２，リアンズワールド
*select10_2|観察し耳を澄ませる事

[OnName num="keisuke"]
"Let's gather information about Hayashida. ......
[cpg cn=true]



I decide to visit Lian's World.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『リアンズワールド』

[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="3/7" time=800]
[OnName num="john_doe0122"]
'What's on the menu today?
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari115"]
[OnName num="Lian"]
"Well, I haven't thought about it yet.
[cpg cn=true]



[OnName num="john_doe1019"]
"You don't look like you're going to do it.
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_7"  pos="3/7" time=800]
[VOICE f="Mari116"]
[OnName num="Lian"]
"Well, I'm a little tired."
[cpg cn=true]



Hayashida raised one of his legs on a chair and looked very tired.
[cpg]

Not wanting to talk to a guy like that, I quickly went into observation mode.
[cpg]

;//■選択肢_夜_３日目_リアン

[stflag Rselecter23_cnt = 2]

*Rselecter03|観察し耳を澄ませる事

[if exp={getFlagValue("Rselecter23_cnt") == 0}]
[jump target="*3niend_ri"]
[endif]

[switch]
[case "Leanne's face"]
	[swap]
	[jump target="*Rsel3_01"]
[case "Leanne's chest"]
	[swap]
	[jump target="*Rsel3_02"]
[case "Leanne's head"]
	[swap]
	[jump target="*Rsel3_03"]
[case "窓"]
	[swap]
	[jump target="*Rsel3_04"]
[case "ベッド"]
	[swap]
	[jump target="*Rsel3_05"]
[case "Table"]
	[swap]
	[jump target="*Rsel3_06"]
[case "Closet"]
	[swap]
	[jump target="*Rsel3_07"]
[case "Leanne"]
	[swap]
	[jump target="*Rsel3_01"]
[endswitch]

;//==========================
;//リアンの顔
*Rsel3_01|観察し耳を澄ませる事

[stflag Rselecter23_cnt=-1]

You are sleepy, or your eyelids look a little heavy.
[cpg]

And yet, she's delivering, is it because she wants to make money?
[cpg]

What a greedy bitch.
[cpg]

[jump target="*Rselecter03"]
;//==========================
;//リアンの胸
*Rsel3_02|観察し耳を澄ませる事

[stflag Rselecter23_cnt=-1]

Maybe it's because they are hidden when they are in uniform, but the impression of their size is different.
[cpg]

Mmmm......... they're pretty big, huh?
[cpg]

I'm not interested in this guy's chest.
[cpg]

[jump target="*Rselecter03"]
;//==========================
;//リアンの頭
*Rsel3_03|観察し耳を澄ませる事

[stflag Rselecter23_cnt=-1]

I bet the only thing on this guy's mind is money and fashion.
[cpg]

He cheats on tests, and his intelligence must be that of an ape.
[cpg]

I can't allow myself to remain defeated....
[cpg]

[jump target="*Rselecter03"]
;//==========================
;//窓
*Rsel3_04|観察し耳を澄ませる事

[stflag Rselecter23_cnt=-1]

How good it would feel to throw a rock and have it break....
[cpg]

[jump target="*Rselecter03"]
;//==========================
;//ベッド
*Rsel3_05|観察し耳を澄ませる事

[stflag Rselecter23_cnt=-1]

I don't want to sleep in this dirty bed even if you ask me to.
[cpg]

I bet you haven't washed these clothes you're wearing.
[cpg]

Slutty women really do exist....
[cpg]

[jump target="*Rselecter03"]
;//==========================
;//テーブル
*Rsel3_06|観察し耳を澄ませる事

[stflag Rselecter23_cnt=-1]

This cosmetics are expensive ones you can only find in department stores....
[cpg]

Are you buying all these things with the money you extracted from those wakuteka guys?
[cpg]

She's like a queen bee, this one.
[cpg]

[jump target="*Rselecter03"]
;//==========================
;//クローゼット
*Rsel3_07|観察し耳を澄ませる事

[stflag Rselecter23_cnt=-1]

In a horror movie, a killer would come out of one of these.
[cpg]

I really hope he comes out.
[cpg]

I would pay 10,000 yen for that.
[cpg]

[jump target="*Rselecter03"]
;//==========================
;//２箇所クリック後
*3niend_ri|観察し耳を澄ませる事

[FACE method="change_2" pos="3/7"]
[VOICE f="Mari117"]
[OnName num="Lian"]
So, you know, on the way home today, I stopped by a cafe and had a muscat parfait.
[cpg cn=true]



[OnName num="john_doe0723"]
I'm not going to talk about that. Let's not talk about that.
[cpg cn=true]



[OnName num="john_doe0810"]
Let's go to the secret place.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Mari118"]
[OnName num="Lian"]
I'm not going to talk about it. I mean, I have money today, so there's no need to go overboard.
[cpg cn=true]



[OnName num="john_doe0513"]
I don't care how much money you have.
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Mari119"]
[OnName num="Lian"]
'Well, yes, but...'
[cpg cn=true]



;//▼麻里フラグＡがある場合→;//▼麻里フラグＡ　へ

;//▼麻里フラグＡがない場合　→;//３日目夜リアン終了　へ進行
[if exp={getFlagValue("Cha2flg_A") == 1}]
[jump target="*mariflgA"]
[endif]

;//３日目夜リアン終了

Hayashida speaks while touching his hair and checking the chat column with glances.
[cpg]

The Nanashi and the others are trying hard to get him to move to the secret room somehow.
[cpg]

Do you really want to see ...... this guy's pornography that badly?
[cpg]

I'm sick of it.
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Mari120"]
[OnName num="Lian"]
I'm sleepy, I worked so hard during the day.
[cpg cn=true]



Hayashida yawns loudly, not even bothering to cover his mouth.
[cpg]

[OnName num="john_doe0323"]
'Don't say that.
[cpg cn=true]



[OnName num="john_doe0102"]
'You're so cute, Rian-chan!
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari121"]
[OnName num="Lian"]
Thanks, but I'm not sure I'll be able to do it today. But, oh, good morning.
[cpg cn=true]



;//画面単色
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[OnName num="keisuke"]
Oh, he fell..."
[cpg cn=true]



How is it that the organizer drops out within a few minutes of the start of the event?
[cpg]

But there was no way that common sense would work with Hayashida.
[cpg]

I had no further choice but to switch to the game course and hold the control pad until the morning.
[cpg]

;//３日目の師匠　へ
[jump target="*3day_end"]
;//==========================
;//▼麻里フラグＡ
*mariflgA|観察し耳を澄ませる事

[OnName num="KEI"]
I had a banana parfait today.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari122"]
[OnName num="Lian"]
Oh, really?"
[cpg cn=true]



I picked up Hayashida's muscat parfait and started, and he took a bite out of my statement.
[cpg]

[FACE method="change_1" pos="3/7"]
[VOICE f="Mari123"]
[OnName num="Lian"]
I picked up Hayashida's muscat parfait and started to talk about it, and he bit my comment.　It's a limited edition, right?
[cpg cn=true]



[OnName num="KEI"]
Yes.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Mari124"]
[OnName num="Lian"]
I wanted to eat a banana too. But it's at a different station. Was it good?
[cpg cn=true]



[OnName num="KEI"]
Yes, it was covered with chocolate and went well with coffee.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari125"]
[OnName num="Lian"]
I see... I think I'll go eat it again.
[cpg cn=true]



[OnName num="KEI"]
On the other hand, which store is Muscat's?
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari126"]
[OnName num="Lian"]
'On the west side of the station next to Banana. It's the store behind the pachinko parlor. The Muscat's is juicy, not too sweet and goes well with tea, so if you get a chance, try it!
[cpg cn=true]



[OnName num="KEI"]
Okay."
[cpg cn=true]



So ...... Hayashida lives in the next town over.
[cpg]

The most important thing to remember is that you should never be afraid to ask for personal information.
[cpg]

[SE f="se038"]
;//【ＳＥ】携帯着信

[WAIT time=1000]

[FACE method="change_1" pos="3/7"]
[VOICE f="Mari127"]
[OnName num="Lian"]
He said, "Oh, wait a minute. Hi, Mosshi."
[cpg cn=true]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

At that moment, I heard my cell phone ring and immediately saw Hayashida answering it on the screen.
[cpg]

[OnName num="john_doe0606"]
This is the real pleasure of live broadcasting,' he said.
[cpg cn=true]



[OnName num="john_doe1101"]
Who is it? Is it a man?
[cpg cn=true]



I thought to myself, "I don't care who it is. ......" and turned up the volume on my speakers.
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Mari128"]
[OnName num="Lian"]
I know who it is.... I'm not going to skip it!　That's it?　I've got to go, I'm busy!　I'm sorry about .......
[cpg cn=true]



[OnName num="KEI"]
What are you skipping?
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Mari129"]
[OnName num="Lian"]
Oh, did you hear me?　I'm sorry, I've got to go now. She's so annoying, isn't she?
[cpg cn=true]



[OnName num="KEI"]
"You go to cram school?
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari999"]
[OnName num="Lian"]
"Oh, you laugh there?"
[cpg cn=true]



[OnName num="KEI"]
No, but what cram school?　If you can always be home at this time, isn't that a pretty relaxed school?
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Mari130"]
[OnName num="Lian"]
The one I go to is called "Nisshin Seminar" which is quite famous. I go to a well-known cram school called Nisshin Seminar.
[cpg cn=true]



[OnName num="KEI"]
I'm sure it's not too strict or too loose. Why did you choose it?
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Mari131"]
[OnName num="Lian"]
"Nothing, because it's close?
[cpg cn=true]



[OnName num="KEI"]
I see, but it's dangerous at night, so be careful on your way home.
[cpg cn=true]



When I said something I hadn't expected, Hayashida made a grin and made a sword, perhaps because he felt better.
[cpg]

[FACE method="change_2" pos="3/7"]
[VOICE f="Mari132"]
[OnName num="Lian"]
I'm so sweet, Kei-chan, I'm falling in love with you.
[cpg cn=true]



I don't want you!
[cpg]

[FACE method="change_1" pos="3/7"]
[VOICE f="Mari133"]
[OnName num="Lian"]
But I'm fine. I have an auto-locking door, so if I run to my apartment, the pervert won't be able to chase me, right?
[cpg cn=true]



[OnName num="keisuke"]
「………………」
[cpg cn=true]



Hayashida lives in an auto-locking apartment near Nisshin Seminar in the next town over. ......
[cpg]

The information was like a puzzle in my brain, and it was taking shape.
[cpg]

At the same time, I felt my revenge plan in my mind change from a dream to a reality.
[cpg]

I thought I could do it ...... in reality.
[cpg]

It might not be impossible to take revenge directly on Mari Hayashida. ......
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Mari134"]
[OnName num="Lian"]
Kei-chan?　Hey?　Is that a freeze?　...... umm, then Atashi too Ochi!"
[cpg cn=true]



[OnName num="john_doe1215"]
'Eh, hey, not that one.'
[cpg cn=true]



;//画面単色
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

I fell silent, and as fast as I could, so did Hayashida.
[cpg]



I'm not sure how much I'm going to be able to do with this.
[cpg]

I'll beat you so bad you'll never be able to deliver again. ......
[cpg]

;//３日目の師匠　へ
[jump target="*3day_end"]
;//==========================
;//３，Ｈキャッスル
*select10_3|観察し耳を澄ませる事

[OnName num="keisuke"]
H Castle ......."
[cpg cn=true]



I don't have any deep feelings for H-Castle, but for some reason I walked in.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『Ｈキャッスル』

＞ケイさんが入室されました
[cpg]

[FG f="CHA03_p5_03_a.ui" method="change_1"  pos="3/7" time=800]
[OnName num="KEI"]
"My queen, you have a good day.
[cpg cn=true]



I greeted him cordially and looked at the conversation among the regulars instead of listening to it.
[cpg]

[OnName num="deku"]
Today, I had the fried oyster set meal.
[cpg cn=true]



[OnName num="pig"]
I had the pork cutlet lunch box.
[cpg cn=true]



[OnName num="keisuke"]
I'll have the tonkatsu bento.
[cpg cn=true]



Apparently, it is now time for the lunch report.
[cpg]

I was not intrigued and decided to observe SB's room.
[cpg]

;//■選択肢_夜_３日目_ＳＢ

[stflag Hselecter33_cnt = 2]

*Hselecter03|観察し耳を澄ませる事

[if exp={getFlagValue("Hselecter33_cnt") == 0}]
[jump target="*3niend_hi"]
[endif]

[switch]
[case "SB's face"]
	[swap]
	[jump target="*Hsel3_01"]
[case "SB's chest"]
	[swap]
	[jump target="*Hsel3_02"]
[case "SB's head"]
	[swap]
	[jump target="*Hsel3_03"]
[case "Candlestick"]
	[swap]
	[jump target="*Hsel3_04"]
[case "The bed"]
	[swap]
	[jump target="*Hsel3_05"]
[case "Wall"]
	[swap]
	[jump target="*Hsel3_06"]
[case "Floor"]
	[swap]
	[jump target="*Hsel3_07"]
[case "SB"]
	[swap]
	[jump target="*Hsel3_01"]
[case "ＳＢ"]
	[swap]
	[jump target="*Hsel3_01"]
[endswitch]

;//==========================
;//ＳＢの顔
*Hsel3_01|観察し耳を澄ませる事

[stflag Hselecter33_cnt=-1]

Eyes slightly visible through the hole are clearly double-layered with long eyelashes.
[cpg]

I have a fantasy that she might be a very beautiful woman.
[cpg]

I have a fantasy that she might be a very beautiful woman. ......
[cpg]

[jump target="*Hselecter03"]
;//==========================
;//ＳＢの胸
*Hsel3_02|観察し耳を澄ませる事

[stflag Hselecter33_cnt=-1]

I wonder if she wears leather clothes every day and if they don't chafe.
[cpg]

I'm curious because when I wear a t-shirt with a little stiff print, my nipples get chafed and itchy.
[cpg]

Well...no one cares about my nipples.
[cpg]

[jump target="*Hselecter03"]
;//==========================
;//ＳＢの頭
*Hsel3_03|観察し耳を澄ませる事

[stflag Hselecter33_cnt=-1]

If that hair were to fall in my room, it would definitely be the type of long hair that would make her suspect I was cheating on her.
[cpg]

Well...I don't need to worry about that at all.
[cpg]

[jump target="*Hselecter03"]
;//==========================
;//燭台
*Hsel3_04|観察し耳を澄ませる事

[stflag Hselecter33_cnt=-1]

Is it true that Japanese candles have a higher temperature than ordinary candles?
[cpg]

I mean, who measured such a thing...?
[cpg]

After all, was it the result of a person who tested it with his or her own body?
[cpg]

[jump target="*Hselecter03"]
;//==========================
;//ベッド
*Hsel3_05|観察し耳を澄ませる事

[stflag Hselecter33_cnt=-1]

Does SB sleep alone...?
[cpg]

Or with a slave?
[cpg]

No... I've never heard of a queen who sleeps with a slave.
[cpg]

[jump target="*Hselecter03"]
;//==========================
;//壁
*Hsel3_06|Observe and listen carefully.

[stflag Hselecter33_cnt=-1]

I wonder what kind of soundproofing concrete has.
[cpg]

If I heard the sound of a whip, I would be reported, so is it still excellent?
[cpg]

[jump target="*Hselecter03"]
;//==========================
;//床
*Hsel3_07|観察し耳を澄ませる事

[stflag Hselecter33_cnt=-1]

I've never seen an apartment building built like this or anything like it.
[cpg]

Is it some kind of warehouse or some special building?
[cpg]

[jump target="*Hselecter03"]
;//==========================
;//２箇所クリック後　進行
*3niend_hi|観察し耳を澄ませる事

[if exp={getFlagValue("Cha3flg_la") == 1}]
[jump target="*hitomi_la"]
[endif]

;//★瞳aがない場合→;//３日目瞳終了　へ

;//★瞳aがある場合→;//★瞳a　へ
;//３日目瞳終了

[FACE method="change_7" pos="3/7"]
[VOICE f="Hitomi103"]
[OnName num="SB"]
What did Kay eat?
[cpg cn=true]



[OnName num="keisuke"]
"Hyah, yikes...."
[cpg cn=true]



I was taking my hands off the keyboard and thinking in a hurry when a voice called out to me.
[cpg]

[OnName num="KEI"]
I had taken my hand off the keyboard and was thinking in a panic when I heard the voice.
[cpg cn=true]



In my haste, I made a slight typo.
[cpg]

SB blatantly turns his head and sighs.
[cpg]

Even though I know it's nothing serious, it's still sad to be disappointed by someone.
[cpg]

[OnName num="KEI"]
I'm sorry.
[cpg cn=true]


[FACE method="change_3" pos="3/7"]
[VOICE f="Hitomi104"]
[OnName num="SB"]
It's not sorry, it's not sorry!
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】棒鞭

[OnName num="keisuke"]
Ah!"
[cpg cn=true]



I was yelled at and whipped, and I realized the type of mistake I'd made again.
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Hitomi105"]
[OnName num="SB"]
What is it?　If you're so unwilling to fuck, why are you coming?"
[cpg cn=true]



[OnName num="keisuke"]
'Awww.
[cpg cn=true]



It's not that I don't want to get laid, but it seems I've pissed off SB.
[cpg]

I can't type anymore because I'm afraid of making a mistake.
[cpg]

[FACE method="change_1" pos="3/7"]
[VOICE f="Hitomi106"]
[OnName num="SB"]
"That's enough. I'll get out of here.
[cpg cn=true]



[OnName num="KEI"]
『え』
[cpg cn=true]



[OnName num="mercenary"]
Get out of here!　You're useless!
[cpg cn=true]



[OnName num="kugutsu"]
Get the hell out of here!　You're a fucking cripple!
[cpg cn=true]



[OnName num="pig"]
"You fucking kay, log out, boo hoo!"
[cpg cn=true]



[OnName num="keisuke"]
'Ugh ......, you're terrible.'
[cpg cn=true]



Even the regulars cursed at me and I logged out, almost in tears.
[cpg]

;//３日目の師匠　へ
[jump target="*3day_end"]
;//==========================
;//★瞳a
*hitomi_la|観察し耳を澄ませる事

[OnName num="KEI"]
I had a banana parfait today, sir.
[cpg cn=true]



I answered truthfully.
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Hitomi107"]
[OnName num="SB"]
'Well... a banana parfait?'
[cpg cn=true]



Then, perhaps interested, SB turned straight to the camera.
[cpg]

[OnName num="KEI"]
It's sweet enough to go well with coffee, and even with the extra bananas, I was able to enjoy it without a second thought!
[cpg cn=true]



I hurriedly reiterated.
[cpg]

I even confessed to having more bananas.
[cpg]

Oh, how silly of me....
[cpg]

But...what? SB seemed to be laughing a little with his fist in his mouth, as if it was funny.
[cpg]

Somehow, that gesture is a bit cute.
[cpg]

[FACE method="change_2" pos="3/7"]
[VOICE f="Hitomi108"]
[OnName num="SB"]
'...... I like your answer now, so I'll allow you one question.'
[cpg cn=true]



Seriously?　Lucky.
[cpg]

However, just saying it means that if I don't like it, I won't answer it?
[cpg]

Hmmm... ......
[cpg]

[OnName num="KEI"]
'Why do you wear a white coat, JoOusama?'
[cpg cn=true]



At any rate, I asked something that had been bothering me for a long time.
[cpg]

Then ......
[cpg]


[FACE method="change_7" pos="3/7"]
[VOICE f="Hitomi109"]
[OnName num="SB"]
'Humph, nonsense. You pretend to care about the white robe, but your interest is below it anyway!"
[cpg cn=true]



[SE f="se004"]
;//【ＳＥ】白衣翻す

Basa!
[cpg]

and, just as SB flipped off the white coat he was wearing, there was a light clang and something fell onto the desk.
[cpg]

[OnName num="keisuke"]
Huh?"
[cpg cn=true]



I happened to focus on it for a moment, and I could read the words written on the dropped object.
[cpg]


H-UEMURA.
[cpg cn=true]



[OnName num="keisuke"]
...?"
[cpg cn=true]



It fell, and it looked like a nameplate. ......
[cpg]

[FACE method="change_5" pos="3/7"]
[VOICE f="Hitomi110"]
[OnName num="SB"]
!!!"
[cpg cn=true]



It was quickly hidden by SB who instantly noticed it.
[cpg]

So, it is unknown if other viewers were able to confirm it.
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Hitomi111"]
[OnName num="SB"]
Ah!　......!"
[cpg cn=true]



[OnName num="keisuke"]
「え？」
[cpg cn=true]



[OnName num="deku"]
'Mistress!
[cpg cn=true]



[OnName num="pig"]
'Oh, Butterfly-sama!
[cpg cn=true]



[OnName num="mercenary"]
Are you hurt?　Are you all right?
[cpg cn=true]



The regulars called out in unison, panicking to see what was going on.
[cpg]

The SB on the screen was in pain, holding the back of his hand.
[cpg]

[FACE method="change_1" pos="3/7"]
[VOICE f="Hitomi112"]
[OnName num="SB"]
'This is nothing to worry about...'
[cpg cn=true]



It seems that when he quickly hid the nameplate, he accidentally touched the candlestick and found a candle lying on the floor, which had fallen and gone out.
[cpg]

[OnName num="kugutsu"]
It's your fault, you fucking Kay!
[cpg cn=true]



Such a fucking pig of a person. ......
[cpg]

[FACE method="change_3" pos="3/7"]
[VOICE f="Hitomi113"]
[OnName num="SB"]
'Anyway, you...Kay, did you see that?
[cpg cn=true]



[OnName num="KEI"]
'No.'
[cpg cn=true]



I answered instantly.
[cpg]

I clearly remembered his name tag saying H. UEMURA, but
[cpg]

I knew it was not a good idea to be honest.
[cpg]

I guessed it was something he didn't want to be seen, since he was in such a hurry to hide it.
[cpg]

;//（◆瞳フラグＣ）取得
[stflag Cha3flg_C = 1]

;//ＳＢ合流　へ
*selectNeme_4|観察し耳を澄ませる事

;//ＳＢ合流
[FACE method="change_7" pos="3/7"]
[VOICE f="Hitomi114"]
[OnName num="SB"]
I said, "Well.... Then it's okay."
[cpg cn=true]



SB seemed relieved at my answer.
[cpg]

The regulars began to call out to her in an effort to comfort her.
[cpg]

[OnName num="pig"]
'Buhey!　My queen, how kind you are to those who gave you burns!'
[cpg cn=true]



What, it's my fault!
[cpg]

[OnName num="kugutsu"]
'Our Lady S. Butterfly!
[cpg cn=true]



[OnName num="mercenary"]
"Not only the most beautiful woman in the world, but also the most beautiful in her heart!"
[cpg cn=true]



[OnName num="keisuke"]
"Oh, uh, uh..."
[cpg cn=true]



The slaves praised and praised SB verbally.
[cpg]

I couldn't find the right words and was lagging behind.
[cpg]

I had to say something too. Let's see... ......
[cpg]

[OnName num="KEI"]
There has never been a more noble queen in the history of the world!
[cpg cn=true]



I had some French queen in my head, but it's nothing like that, so I decided SB is the best ever.
[cpg]


[FACE method="change_2" pos="3/7"]
[VOICE f="Hitomi115"]
[OnName num="SB"]
"History?　Ho-ho-ho-ho!"
[cpg cn=true]



SB laughed, as if he liked what I said.
[cpg]


[FACE method="change_1" pos="3/7"]
[VOICE f="Hitomi116"]
[OnName num="SB"]
You're funny, you know that? I'd like to hear more.
[cpg cn=true]



[OnName num="KEI"]
I'd love to hear more.
[cpg cn=true]



I was reminded more and more of a line from a knight in a fantasy game.
[cpg]

An itinerant knight who used language that was grand and formal, yet indulgent.
[cpg]

I think I'm going to treat SB like that.
[cpg]


[FACE method="change_6" pos="3/7"]
[VOICE f="Hitomi117"]
[OnName num="SB"]
"Welcome, Kay. Come to my secret room.
[cpg cn=true]



[OnName num="KEI"]
"I'm so happy to see you."
[cpg cn=true]



[OnName num="kugutsu"]
What?　How could a newbie like you?
[cpg cn=true]



[OnName num="pig"]
Boo hoo!"
[cpg cn=true]



The slaves complained, but SB didn't care at all.
[cpg]

The secret pass arrives to me, and the screen immediately switches.
[cpg]
[free time=1000]

;//入金画面

On the deposit screen, the word FREE was displayed.
[cpg]

SB is so generous that I don't have to pay anything.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_h1"]
;//【ＢＧ】『Ｈキャッスルシークレット』ルーム

[FG f="CHA03_p5_03_a.ui" method="change_1"  pos="3/7" time=800]



When I entered the secret room, I was already alone in the chat room.
[cpg]

[VOICE f="Hitomi118"]
[OnName num="SB"]
"Come on, make me feel good with your words.
[cpg cn=true]



[OnName num="keisuke"]
I see..."
[cpg cn=true]



I thought, "So that's what this evening is all about.
[cpg]

I stocked my brain with words of praise.
[cpg]

[OnName num="KEI"]
"Your beauty, my queen, is like a crimson rose.
[cpg cn=true]



[OnName num="KEI"]
She radiates a passionate and seductive fragrance that beckons us males to her, but when we reach out to touch her, we are hurt by her sharp thorns.
[cpg cn=true]



Incidentally, this is a line from a game I completed last month.
[cpg]

But SB, who did not know that this was the case, nodded his head several times in a small, somewhat impressed manner.
[cpg]


[FACE method="change_2" pos="3/7"]
[VOICE f="Hitomi119"]
[OnName num="SB"]
'That's good, you. You're like a poet. You're the kind of slave I've never had before.
[cpg cn=true]



[OnName num="KEI"]
But no matter how much they hurt me, I will continue to reach out my hand, covered in blood, until I pluck the flower that is you.
[cpg cn=true]



SB touches her lips, her cheeks flushed.
[cpg]



[OnName num="KEI"]
Oh, my queen. Please give me that noble flower, my lowly servant!
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Hitomi120"]
[OnName num="SB"]
I will repay your blood."
[cpg cn=true]


She seemed to respond to my words.
[cpg]


The strange exchange continued as I wondered if it was the other way around.
[cpg]



;//移植前シーンカット


SB......
[cpg]

S. Butterfly......
[cpg]

I wonder what kind of woman she actually is.
[cpg]

Is she someone who does this kind of thing in the real world?
[cpg]

My interest is endless.
[cpg]



;//ブラックアウト
;//エフェクト

;//３日目の師匠　へ
[jump target="*3day_end"]
;//=============================================================================
;//３日目の師匠
*3day_end|観察し耳を澄ませる事

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_7.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『雑談ルーム』

Before I finished my day... I had called my mentor into the chat room.
[cpg]

I wanted to talk to him a little and ask him something.
[cpg]

[OnName num="siren"]
What's up?
[cpg cn=true]



[OnName num="KEI"]
"Well, thanks to you, I'm starting to enjoy it a little more.
[cpg cn=true]



[OnName num="siren"]
'That's good to hear.
[cpg cn=true]



[OnName num="KEI"]
'So, I have a question for you.
[cpg cn=true]



[OnName num="siren"]
'Yes, I have a question for you. Ask me anything.
[cpg cn=true]



[OnName num="KEI"]
"Have you ever actually met the distributor?"
[cpg cn=true]



[OnName num="siren"]
"Ha-ha-ha, you ask a question like that, does that mean you'd like to meet someone?"
[cpg cn=true]



[OnName num="KEI"]
'No, I'm just asking...'
[cpg cn=true]



[OnName num="siren"]
'Well, there are some distributors who do meet offline, but it's not very practical.
[cpg cn=true]



[OnName num="KEI"]
'Why is that?
[cpg cn=true]



[OnName num="siren"]
'Well, let me ask you, why do you want to meet them?　I've always been able to see and talk with them on the screen. What do you want to do in person?
[cpg cn=true]



[OnName num="KEI"]
That's the thing ......."
[cpg cn=true]



I was about to blurt it out, but my mentor knew what I was talking about.
[cpg]

[OnName num="siren"]
I know what a guy is looking for when he meets a distributor," he said. "Sometimes, Kay, are you a good-looking guy?
[cpg cn=true]



[OnName num="KEI"]
No, no..."
[cpg cn=true]



If I could answer, "Yes, I am," I wouldn't be living this life.
[cpg]

I don't think I'm ugly, but I don't have an advanced face that women would fall in love with at first sight.
[cpg]

[OnName num="siren"]
I don't think I'm ugly, but I don't have an advanced enough face for women to fall in love with me at first sight.
[cpg cn=true]



[OnName num="siren"]
"Most people who go offline are cut off because of their looks.
[cpg cn=true]



[OnName num="siren"]
"Until then, they may like you because you're nice or funny in chat rooms, but in the end, it's all about face value.
[cpg cn=true]



[OnName num="KEI"]
It's a nasty world!
[cpg cn=true]


;//＠
[OnName num="siren"]
Awww."
[cpg cn=true]



My mentor weeded through my lamentations.
[cpg]

[OnName num="KEI"]
I'm not sure if it's the face after all!
[cpg cn=true]



[OnName num="siren"]
The other thing is the ability to communicate. You can be eloquent in a chat room, but if you can't speak the same way in person, you'll be disillusioned.
[cpg cn=true]


[OnName num="siren"]
"I don't like a guy who talks a lot, but when I meet him, he's all shy and hesitant..."
[cpg cn=true]



[OnName num="KEI"]
Oh, there's that kind of thing too. ......
[cpg cn=true]



It's true that if you're bossy in chat rooms, you come off as macho and violent, but in real life, skinny little guys are the object of laughter....
[cpg]

I'm a mojo in chat and in real life, so I don't think there's a gap. ...... I guess that's just normal and weird.
[cpg]

Like Hayashida and the guys in my class said, I'm a creepy enough guy in the real world alone. ......
[cpg]

I must be happier just chatting.
[cpg]

[OnName num="siren"]
'By the way, I digress.
[cpg cn=true]



I was so depressed that I fell silent for a bit, and my mentor took care to change the subject.
[cpg]

[OnName num="siren"]
You remember I told you about that stalking incident that happened a while ago?　The guy who did it found out the distributor and locked him up in his house for a few days.
[cpg cn=true]



[OnName num="siren"]
I heard it was his parents' house, and I don't think it's easy to do something like that, but I wonder how on earth he did it. I wonder how he did it. I wonder if he had some kind of a weak point against him.
[cpg cn=true]



[OnName num="KEI"]
Weakness?　What does weakness have to do with it?
[cpg cn=true]



[OnName num="siren"]
No, I mean, normally, if you are locked up and somehow get out of control or make noise, the people who live in the same house will definitely notice.
[cpg cn=true]



[OnName num="siren"]
'Well, Japanese houses are small. Don't you think that the fact that this didn't happen means that the victim was quiet?
[cpg cn=true]



[OnName num="KEI"]
'Oh, I see. For example, "If you don't want your embarrassing picture to be spread around"?
[cpg cn=true]



[OnName num="siren"]
Well, yeah. Well, in any case, the culprit was caught in the end, and it is better not to do anything wrong.
[cpg cn=true]



The master then dropped out of the chat room.
[cpg]

[OnName num="keisuke"]
「………」
[cpg cn=true]



I was left behind, ruminating over the words that remained in my head.
[cpg]
'Did you have some kind of weakness against them?
[cpg cn=true]



Weakness...weakness...... If we have our opponent's weakness, we have the advantage.
[cpg]

How you use it is a story for later, but it is better to have it.
[cpg]

I may be going a little crazy as I grow more vengeful and sexually desirous day by day. ......
[cpg]


;//ブラックアウト
;//エフェクト


;//=============================================================================


[jump storage="ep003.ks" target="*start"]






