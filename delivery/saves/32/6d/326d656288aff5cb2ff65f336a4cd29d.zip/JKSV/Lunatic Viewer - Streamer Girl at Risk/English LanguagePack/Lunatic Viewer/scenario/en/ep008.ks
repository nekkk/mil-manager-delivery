;//凶行ルート
*root6|

;//*test|

*start

;#################################################
*Ep008|Catching the Light with the Darkness
;#################################################

[SCENE id=8]





[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公（啓介）の部屋』・昼

The next day, I was in the chat room, listening to my mentor ask me how I was feeling.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_7.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『雑談ルーム』

[OnName num="KEI"]
'What is it with these women who open the room here?
[cpg cn=true]



[OnName num="siren"]
' 'What do you mean?'
[cpg cn=true]



[OnName num="KEI"]
'I don't understand what the fun is in opening up your life to the public and talking to people you don't know.
[cpg cn=true]



[OnName num="siren"]
"Well, when you get right down to it, they're all the same.
[cpg cn=true]



[OnName num="KEI"]
The same?
[cpg cn=true]



[OnName num="siren"]
"This is, after all, where they make their money.
[cpg cn=true]



[OnName num="KEI"]
You mean they're all in it for the money?
[cpg cn=true]



[OnName num="siren"]
That's right. There are plenty of other sites out there that don't have a secret system.
[cpg cn=true]


[OnName num="siren"]
"But if they use this place, it's obviously to extract money from men by using the secure and safe secret room as a bait.
[cpg cn=true]



[OnName num="KEI"]
But some girls don't...
[cpg cn=true]



[OnName num="siren"]
You don't know this because you're still a beginner, but some of them will say, "I don't want your money," and they'll be friendly with you first.
[cpg cn=true]


[OnName num="siren"]
But if you've known them long enough, they'll say, "I'm in a bit of a pinch this month..." or "My parents are sick..." and that's what they usually say.
[cpg cn=true]



[OnName num="KEI"]
'But is that all of ......?'
[cpg cn=true]



[OnName num="siren"]
But is that all of ? Because it costs money to open a room here, right?
[cpg cn=true]



[OnName num="KEI"]
'Oh, you all pay to open a room?
[cpg cn=true]



[OnName num="siren"]
Yes, we do. You wouldn't do that if you didn't get something more in return.
[cpg cn=true]



[OnName num="KEI"]
'Well...'
[cpg cn=true]



I was astonished at the new revelation my mentor revealed to me.
[cpg]

I was astonished at the new revelation that my mentor had revealed to me.
[cpg]

If I had remained ignorant, I would have been easily tricked into paying more and more.
[cpg]

Thinking of this, my resentment toward the women began to boil over.
[cpg]

[OnName num="KEI"]
I was starting to get angry.
[cpg cn=true]



[OnName num="siren"]
Well, don't say that. The most important thing to remember is that every kind of enjoyment requires a certain amount of money. You can decide how much you want to spend and enjoy yourself.
[cpg cn=true]



[OnName num="KEI"]
I agree.
[cpg cn=true]



The conversation with the master ended there, but my resentment did not subside.
[cpg]

Not only Hayashida, who humiliated me, but also that innocent-looking Emu, in the end, wanted money.
[cpg]

Women, who prey on men, are all enemies to me.
[cpg]

How could she do such a thing?
[cpg]

They are already a con artist, showing their faces, smiling, and using all kinds of methods to pull in money.
[cpg]

Even I, in my weakness, was about to be preyed upon. ......
[cpg]

But that's not going to happen.
[cpg]

I have suffered enough.
[cpg]

I've suffered enough, and I've had enough of being tormented and abused.
[cpg]

I would rather be the one to bring down the hammer on all the women like the female spiders that nest here.
[cpg]

With these dark thoughts in my mind, I staggered out of the house.
[cpg]

My brain is craving oxygen .......
[cpg]

I want to think about what I'm going to do. ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『公園』




[SE f="se002" loop=true]
;//【ＳＥ】子供たちの声

[OnName num="keisuke"]
........................."
[cpg cn=true]



I came to a park and sat on a bench alone, pondering.
[cpg]

I'm not going to be eaten by a bait. ......
[cpg]

I'm not going to be eaten by a woman. ......
[cpg]

[OnName num="middle_aged_man"]
"Hey."
[cpg cn=true]



[OnName num="keisuke"]
"...... ah."
[cpg cn=true]



I looked up when a voice suddenly called out to me and saw a man with a familiar face standing there.
[cpg]

[OnName num="keisuke"]
"Hi,......."
[cpg cn=true]



I felt like I saw him every time I came here.
[cpg]

He smiled weakly and pointed to the side of me...
[cpg]

[OnName num="middle_aged_man"]
'Here, may I?'
[cpg cn=true]



He offered me a can of coffee.
[cpg]

[OnName num="keisuke"]
"Oh, thanks..."
[cpg cn=true]



I took the drink from him, filled it up a little, and sat back down.
[cpg]

[SE f="se031"]
;//【ＳＥ】缶コーヒー開ける
[WAIT time=500]

[OnName num="middle_aged_man"]
"You look the same today..."
[cpg cn=true]



[OnName num="keisuke"]
"Huh..."
[cpg cn=true]



I sipped on the canned coffee I had received and made a few small comments.
[cpg]

I was not sure if it was the people in the park or me personally that didn't seem to be changing.
[cpg]

[OnName num="middle_aged_man"]
You're always here, aren't you?
[cpg cn=true]



[OnName num="keisuke"]
"Well... you're also ......."
[cpg cn=true]



[OnName num="middle_aged_man"]
"Yeah. I'm in the restructuring group, so I have no choice.
[cpg cn=true]



[OnName num="keisuke"]
Oh, yeah, that's right. I'm sorry. ......
[cpg cn=true]



[OnName num="middle_aged_man"]
It's okay, it's okay. I'm not sure if I'm looking for a job or starting my own business...it's not easy at my age. ......
[cpg cn=true]



I thought the old man was around 40, but he looked like he was in his 50s.
[cpg]

I feel like I'm getting old even more when I'm slumping and dropping my shoulders.
[cpg]

[OnName num="keisuke"]
I'm not sure what I wanted to do that we talked about the other day, .......
[cpg cn=true]



I thought back to the time when I had a rather deep conversation with this person.
[cpg]

We were both in different environments, but we were both bullied, and as people who hang out in parks like this, we are able to interact with each other without being overbearing.
[cpg]

[OnName num="middle_aged_man"]
I think back to the time when I was a kid, and I thought, "Oh, that's it. ....... Well, I couldn't make up my mind or find a trigger. It's not that I don't have ...... the will to do it.
[cpg cn=true]



[OnName num="keisuke"]
I understand. That's how I feel.
[cpg cn=true]



[OnName num="middle_aged_man"]
Really?　Is there something you want to do right now?
[cpg cn=true]



[OnName num="keisuke"]
Well, yeah. It's just... it's not realistic for me, it's... it's almost impossible, and I feel like I'm just being emotionally passionate about it. ......
[cpg cn=true]



In fact, when I went out like this, I felt like I was so tiny, like an ant to the world, and I felt like I couldn't do anything about it, even if I got angry.
[cpg]

[OnName num="middle_aged_man"]
When you are young, there is a frustrating time when you want to do something that is righteous to you but evil to the world, but you have no choice but to give up.
[cpg cn=true]



[OnName num="keisuke"]
Yes, that's right!
[cpg cn=true]



It seemed to be exactly what I was going through right now, and I began to feel closer to this old man.
[cpg]

[OnName num="middle_aged_man"]
"Hmmm?　So, what kind of thing is it?　Thief or something like that?
[cpg cn=true]



[OnName num="keisuke"]
No, no, it's not like that.
[cpg cn=true]



[OnName num="middle_aged_man"]
I'm not the police, so let's talk about what we want to do.
[cpg cn=true]



The old man took out a piece of pastry from the convenience store bag in his hand and shared it with me.
[cpg]

[OnName num="keisuke"]
It's good. ......
[cpg cn=true]



[OnName num="middle_aged_man"]
I'm not..."
[cpg cn=true]



The old man, perhaps seeing that I was still a little lost, began to speak on his own.
[cpg]

[OnName num="middle_aged_man"]
I've been trying to get her to go for it, but it's just not working out. But I really want to make a move on her.
[cpg cn=true]



[OnName num="keisuke"]
"Oh...that's right. But I'm a little bit like you.
[cpg cn=true]



I was so excited to have a senior in my life reveal her heart to me that I couldn't help but talk about it.
[cpg]

[OnName num="keisuke"]
At first, I wanted to take revenge on the girl who bullied me. But recently I got hooked on a website full of women who looked like scammers..."
[cpg cn=true]


[OnName num="keisuke"]
But when I saw that, I felt like I wanted to put not only her, but all the women on that site to death.... It's twisted, isn't it?
[cpg cn=true]



[OnName num="middle_aged_man"]
No...it's not like that."
[cpg cn=true]



I laughed at myself, and the old man stared straight at me without laughing.
[cpg]

[OnName num="middle_aged_man"]
There are a lot of women in the world who are like cheaters," he said. My partner is one of them. No...to tell you the truth, I met this one on the Internet.
[cpg cn=true]



[OnName num="keisuke"]
"Really?　I didn't know that!
[cpg cn=true]



We hit it off more and more, and we started talking about the sites we were both into.
[cpg]

[OnName num="middle_aged_man"]
I'm the one, you know?　It's called Wakuteka Video, ......."
[cpg cn=true]



[OnName num="keisuke"]
What?
[cpg cn=true]



What?" It seems that the old man and I were talking about the same site.
[cpg]

How small is the world that there is such a coincidence?
[cpg]

[OnName num="keisuke"]
Oh, I'm on that site too!
[cpg cn=true]



[OnName num="middle_aged_man"]
Really?　I'm surprised. ......"
[cpg cn=true]



[OnName num="keisuke"]
"........."
[cpg cn=true]



[OnName num="middle_aged_man"]
".........."
[cpg cn=true]



This was somewhat of a bad rule.
[cpg]

The old man and I both fell silent at the same time.
[cpg]

[OnName num="keisuke"]
"Oh, um, ...... you don't think I've ever ...... talked to you on the Internet, do you?"
[cpg cn=true]



[OnName num="middle_aged_man"]
"Well, ......, that's..."
[cpg cn=true]



[OnName num="keisuke"]
"Well, ...... my handle is ...... Kay.
[cpg cn=true]



[OnName num="middle_aged_man"]
Kay?
[cpg cn=true]



As soon as he heard my handle, the old man's eyes widened in surprise.
[cpg]

[OnName num="middle_aged_man"]
I'm the Yami Nabe Inquisitor!
[cpg cn=true]



[OnName num="keisuke"]
Eeeeeeeeeeeeeeee!
[cpg cn=true]



What a surprise. ......
[cpg]

This timid-looking old man was the Yami Nabe Inquisitor with a peculiar personality?
[cpg]

I was so surprised that I didn't know what to say next.
[cpg]

[OnName num="middle_aged_man"]
I was so surprised that I didn't know what to say next. Well, I'm sorry for being so strange over there. I get so worked up on the Internet..."
[cpg cn=true]



[OnName num="keisuke"]
No, I understand.
[cpg cn=true]



I can't blame Yami Nabe, because I said some things there that I didn't mean.
[cpg]

[OnName num="middle_aged_man"]
I'm sure you already know that, don't you? The person I'm interested in is..."
[cpg cn=true]



[OnName num="keisuke"]
"Yes, it's ......, isn't it?"
[cpg cn=true]



[OnName num="middle_aged_man"]
"Oh, ......."
[cpg cn=true]



The old man nodded, rolled his back and scratched his head.
[cpg]

[OnName num="middle_aged_man"]
What the hell..." "Oh my God. I can't help but think this is some kind of a coincidence.
[cpg cn=true]



[OnName num="keisuke"]
'Yes. ......
[cpg cn=true]



What are the odds that I would run into someone I met on a single site in real life, on the Internet, which is spread all over the world, by chance?
[cpg]

I...maybe even the old man, couldn't help but feel a sense of destiny.
[cpg]

[OnName num="keisuke"]
"Um...the magistrate..."
[cpg cn=true]



[OnName num="middle_aged_man"]
"Haha, I'm good with the dark pot."
[cpg cn=true]



[OnName num="keisuke"]
Mr. Dark Pot said...he went to Secret with Emu. ......
[cpg cn=true]



[OnName num="middle_aged_man"]
"Oh, that's a lie.  That's how impatient I was.
[cpg cn=true]



[OnName num="keisuke"]
That's how it was. ......
[cpg cn=true]



The most important thing to remember is that you can't just take a look at the actual product or service and expect it to be good.
[cpg]

 But I didn't know if it was because Emu was innocent, or because the yaminabe between them didn't get the poisonous fangs of the female fraudster.
[cpg]

Looking back, that was my gross negligence.
[cpg]

[OnName num="middle_aged_man"]
I'm not sure if it's a big deal. I'd like to talk to you about something. ......"
[cpg cn=true]



Yakanabe straightened his posture and began to speak.
[cpg]

[OnName num="middle_aged_man"]
I think you and I have the same goals," he said. So why don't we join forces and turn our desires into reality?
[cpg cn=true]



[OnName num="keisuke"]
What do you mean?
[cpg cn=true]



The dark pot that began to talk seemed a little younger, his eyes shining brighter than before.
[cpg]

[OnName num="middle_aged_man"]
We are going to see Emu together.
[cpg cn=true]



[OnName num="keisuke"]
What?
[cpg cn=true]



I held my mouth as I realized how loud my voice was.
[cpg]

[OnName num="keisuke"]
Oh, we're going to see him!　But how?　Do you know where they are?
[cpg cn=true]



[OnName num="middle_aged_man"]
I have a vague idea where he is.
[cpg cn=true]



[OnName num="keisuke"]
"Ma, seriously?　Oh, I'm sorry.
[cpg cn=true]



[OnName num="middle_aged_man"]
Don't worry about your language. You and I know each other.
[cpg cn=true]



I'm not sure if it's an exaggeration to say that we've never met before, but there was a strange sense of solidarity developing between me and Yami Nabe.
[cpg]

[OnName num="keisuke"]
But if I went to see her, if I could see her in real life ...... then what?"
[cpg cn=true]



[OnName num="middle_aged_man"]
You take your resentment out on her. I tell her how I feel. I've already lost everything, so I wanted to take action so I wouldn't have any more regrets.
[cpg cn=true]



[OnName num="keisuke"]
..................
[cpg cn=true]



I've lost everything.
[cpg]

The most important thing to remember is that you can't just go out and buy a new pair of shoes.
[cpg]

If I continue to be holed up in that room every day, I am sure I will never be able to go back to my class again.
[cpg]

But if I could accomplish something that seemed impossible with this person right here and now,...... something would probably change.
[cpg]

I thought like that and replied to the dark pot.
[cpg]

[OnName num="keisuke"]
"Well, ...... let's just give it a try."
[cpg cn=true]



[OnName num="middle_aged_man"]
I was glad to hear that. It's reassuring to have a friend!
[cpg cn=true]



Thus I grabbed his proffered hand and shook it firmly.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
;//エフェクト

And a few days later......
[cpg]


;//乗用車の中
;//＠
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[BG f="b_09_2.ui" time=1000]
[WAIT time=1000]


I sat in the passenger seat of the car driven by Yakanabe and held my heart beating wildly.
[cpg]

Since then, Yayakanabe and I had been looking around the area he had spotted, and over the next few days we tracked down the town where Emu lived.
[cpg]

Yakanabe's sensors were amazing, and he had even predicted the train she would take and the route she would take to school, based on the sounds she made into the microphone during her live broadcast and a few words she said.
[cpg]

[OnName num="keisuke"]
I'm sorry about that. I've been treating you to dinner and stuff since then.
[cpg cn=true]



During the several days we spent exchanging information and conducting research, we would go into coffee shops and family restaurants, and she would buy us drinks.
[cpg]

[OnName num="middle_aged_man"]
What are you talking about? You're a student, right?　We're all friends, so whoever can pay should pay.
[cpg cn=true]



[OnName num="keisuke"]
But you're going through a hard time, too, with the restructuring and all. ......
[cpg cn=true]



[OnName num="middle_aged_man"]
But you're also having a hard time with restructuring and such. And if you run out of money, you can always get back on your feet and work again.
[cpg cn=true]



That's cool.
[cpg]

I was not a fan of Yami Nabe at first, but he turned out to be a very nice person, and I felt like I was his junior or his disciple.
[cpg]

He never made fun of me or made fun of my truancy or mental illness.
[cpg]

You don't really understand people until you actually get to know them.
[cpg]

What I thought was good was evil, and what I thought was evil was good.
[cpg]

I guess I still need to learn more about society.
[cpg]

[OnName num="middle_aged_man"]
It's about time..."
[cpg cn=true]



Dark Pot checked his watch and looked out the window.
[cpg]

This is a residential area with few pedestrians, and it's also the route to school for Emu.
[cpg]

And according to my checks of student websites, she should be passing through here on her way home at this time of the day on this day of the week.
[cpg]

[OnName num="keisuke"]
I'm getting kind of nervous ......
[cpg cn=true]



[OnName num="middle_aged_man"]
Me too. ......
[cpg cn=true]



Here's our plan.
[cpg]

First, I'll stop her when she passes by and tell her I know what's going on at the site.
[cpg]

Then I'll ask her why she's using the site, and depending on her answer, I'll try to convince her to stop.
[cpg]

Then, depending on how it goes, after that, Yakanabe confesses her unspoken feelings to me, and if it goes well, she and I have a regrettable party.
[cpg]

If it goes well, I will disappear on the spot and they will go on their first date.
[cpg]

And so on and so forth.
[cpg]

It was a bit pure of me, but I really enjoyed the time I spent with Yami Nabe working out this plan, and even if it turned out badly, I knew it would be all right.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]


[OnName num="middle_aged_man"]
Oh, here it comes!　That's it!
[cpg cn=true]



[OnName num="keisuke"]
Oh, that's it!
[cpg cn=true]



;//制服姿で１人歩く美咲
[FO pos="2/3" time=1000]
[WAIT time=1000]

Seeing Emu with the naked eye was much cuter than seeing her on the monitor.
[cpg]

I was so nervous that I was struggling to hold back the pounding in my chest.
[cpg]




[OnName num="middle_aged_man"]
Let's go!
[cpg cn=true]



[SE f="se041"]
;//【ＳＥ】車のドア開く




[OnName num="keisuke"]
Oh, wait ......!
[cpg cn=true]



I was late getting out of the car, but I quickly got out of the passenger seat and followed Yami Nabe.
[cpg]

[SE f="se042"]
;//【ＳＥ】ダッシュ

[free time=1000]

I'm sure you're Emu-chan, can I talk to you for a moment?
[cpg]



I've been practicing this line over and over again, and I'm going to run out and say it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
I stand in front of her and say these words.
[cpg]

That's all you need to think about first!
[cpg]

Then the dark pot will connect the rest of the conversation. ......
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Misaki178"]
[OnName num="eMU"]
Mugu...!　Nnooooooooooooooooooooooooooooooooooooooooooooooo!
[cpg cn=true]



[OnName num="middle_aged_man"]
Keep your voice down!
[cpg cn=true]



[free time=1000]
[OnName num="keisuke"]
"Eh......?"
[cpg cn=true]



I stood there, unable to immediately grasp what had happened.
[cpg]

Why is Yami Nabe clutching his wings and holding his mouth...?
[cpg]

I took down my student bag, and with a surprised look on my face, I struggled to get a hold of myself. ......
[cpg]

[OnName num="middle_aged_man"]
What are you doing!　Hurry up and open the car door!"
[cpg cn=true]



[OnName num="keisuke"]
Eh...eh!"
[cpg cn=true]



With my extremely confused mind, I could do nothing but obey what was said in a strong tone of voice as if it were an order.
[cpg]

[OnName num="middle_aged_man"]
You get in the back too!
[cpg cn=true]



[OnName num="keisuke"]
!
[cpg cn=true]



Before I could interject what was going on, I jumped into the back seat, Yami Nabe into the driver's seat, and the car started off.
[cpg]


[SE f="se043"]
;//【ＳＥ】車発信し、猛スピード

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[WAIT time=4000]
[window target=true]

[SE f="se044" loop=true]
;//【ＳＥ】車走行

;//＠
[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[VOICE f="Misaki179"]
[OnName num="eMU"]
What is it with you people!　Please let me out!
[cpg cn=true]



I was so flustered that I had to regain my position and yell out to him.
[cpg]

She looked at me with the worst eyes I've ever seen, as if she was looking at a caterpillar...
[cpg]



[FACE method="change_4" pos="2/3"]
[VOICE f="Misaki180"]
[OnName num="eMU"]
No, don't!　Please let me down!
[cpg cn=true]



[SE f="se046"]
;//【ＳＥ】車の窓開く（パワーウィンドー）

[FACE method="change_3" pos="2/3"]
[VOICE f="Misaki181"]
[OnName num="eMU"]
Somebody help me!
[cpg cn=true]



[OnName num="keisuke"]
「！！」
[cpg cn=true]



Emu opened the car window by herself and shouted loudly outside.
[cpg]

[free time=1000]

Startled by that, I held her down on the seat and covered her mouth with my hand.
[cpg]


[VOICE f="Misaki182"]
[OnName num="eMU"]
Nnoooooooooooooooooooooooooooo!!!!
[cpg cn=true]



[OnName num="keisuke"]
How did this happen?
[cpg cn=true]



I, still not grasping the situation, leaned forward from the back seat in dismay and asked the dark pot.
[cpg]

But ......
[cpg]

[OnName num="middle_aged_man"]
"Come on, ......, why not?"
[cpg cn=true]



Yakanabe stared ahead with dead eyes and seemed to be concentrating solely on driving.
[cpg]


[VOICE f="Misaki183"]
[OnName num="eMU"]
'Nnooooooooooooo!　Nnooooooooo!!!!"
[cpg cn=true]



Naturally, being suddenly abducted by a group of strangers, Emu was frantically flailing about.
[cpg]

[OnName num="middle_aged_man"]
It's dangerous, so let him be quiet.... We'll be there soon. ......
[cpg cn=true]



[OnName num="keisuke"]
"What... how do you ......
[cpg cn=true]



[OnName num="middle_aged_man"]
You can beat him up..."
[cpg cn=true]



[OnName num="keisuke"]
"What...?"
[cpg cn=true]



Fortunately, when Emu heard what Yami Nabe said, she stopped lashing out, probably due to fear.
[cpg]

That's why I didn't hit her. ......
[cpg]

[OnName num="middle_aged_man"]
............
[cpg cn=true]



The dark pot, who just a few minutes ago would have been talking smilingly, instantly changed, and even I was gripped by fear.
[cpg]

Is this some kind of joke ......?
[cpg]

[OnName num="keisuke"]
"Oh, um..., isn't this going to turn into a ...... kidnapping or something? ......
[cpg cn=true]



[OnName num="middle_aged_man"]
"It could be. ......
[cpg cn=true]



[OnName num="keisuke"]
;//「し、知れないなって…！」
"Maybe it's not...!"
[cpg cn=true]



[OnName num="middle_aged_man"]
Shut the fuck up, ......!
[cpg cn=true]



[OnName num="keisuke"]
Shut up!
[cpg cn=true]



The voice was terribly dusky and low .......
[cpg]

The actual "I'm not a fan of the way you do it," he said, "but I'm not a fan of the way you do it.
[cpg]

But it was powerful enough to scare the crap out of me, and the backseat went silent.
[cpg]

A dozen minutes pass with no word of what's going to happen or where we're going.
[cpg]

Then ......
[cpg]

[SE f="se000"]
;//【ＳＥ】車停止

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

Finally, the car came to a stop in the garage of a house, out of sight from every window.
[cpg]

[OnName num="middle_aged_man"]
'Come on, you two, get out. We're inviting you to our house!"
[cpg cn=true]



The sudden bright voice made me feel even more terrified.
[cpg]

I naturally helped her out of the car and followed Yakanabe without saying a word.
[cpg]

;//＠
;//一軒家の中・リビング
[BG f="b_10_3.ui" time=1000]
[WAIT time=1000]

;//qwe



We were allowed to enter the house directly from the garage, and neither Emu nor I could ask for help, but we were led to a room that looked like a living room.
[cpg]

It was a very spacious room that could be described as a mansion, and from all the furniture in the room, it seemed to be quite expensive.
[cpg]

[OnName num="middle_aged_man"]
He said, "Please make yourself comfortable. Just sit down at your leisure."
[cpg cn=true]



Yami Nabe is smiling in an eerie way.
[cpg]

But I'm not human enough to smile back under such circumstances.
[cpg]

[OnName num="keisuke"]
What is the meaning of this? This is not at all what you planned!
[cpg cn=true]



[OnName num="middle_aged_man"]
It's not true. It's all the same.
[cpg cn=true]



[OnName num="keisuke"]
What?
[cpg cn=true]



[OnName num="middle_aged_man"]
I... wanted to make your wish come true.
[cpg cn=true]



[OnName num="keisuke"]
What?　What are you talking about?
[cpg cn=true]



[OnName num="middle_aged_man"]
You know... no matter how nicely you put it in your mouth... you wanted to make her feel something, didn't you?
[cpg cn=true]



[OnName num="middle_aged_man"]
You wanted to show all women, including your tormentor, how strong and scary you ...... are as a man?
[cpg cn=true]


[OnName num="keisuke"]
Oh, no...!"
[cpg cn=true]



The first thing you need to do is to make sure that you have a good understanding of what you're doing.
[cpg]

She was pale, trembling slightly, and looking at me with frightened eyes.
[cpg]

Oh ...... I'm sure she must have looked at me like this while I was being bullied .......
[cpg]

That's what I thought.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]


And then, Emu appealed with tears spilling from her big eyes.
[cpg]


[VOICE f="Misaki184"]
[OnName num="eMU"]
I won't tell anyone. I won't even report you to the police... please let me go home like this ...... please."
[cpg cn=true]



His appearance was weak, like a rabbit locked on by a wolf.
[cpg]

But what was returned in response were the cold words of the dark pot.
[cpg]


[STOPBGM]

[OnName num="middle_aged_man"]
'Do you really think...you can go home?
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】ビンタ


[FACE method="change_5" pos="2/3"]

[VOICE f="Misaki185"]
[OnName num="eMU"]
Kyaaaah!"
[cpg cn=true]


[BGM f="bg_h2"]

A strong slap, as if he were swinging out with the back of his hand.
[cpg]

The dark cooking pot had slapped him across the cheek.
[cpg]


[free time=1000]

The first thing that comes to mind is the fact that the sofa was at the end of her fall, and her body sank down as if wrapped in its cushion.
[cpg]

[OnName num="keisuke"]
Nah...!　Hey, Mr. Yakanabe!
[cpg cn=true]



I shouted, and at my words, Emu, who had just collapsed, rouses herself.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Misaki186"]
[OnName num="eMU"]
"Ya...Yami...nabe ......?"
[cpg cn=true]



[OnName num="middle_aged_man"]
...... tsk."
[cpg cn=true]



For a moment, I clicked my tongue, but Yami Nabe looked down at Emu and said, "It can't be helped if they find out.
[cpg]

[OnName num="middle_aged_man"]
I'm that dark pot magistrate.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]

[VOICE f="Misaki187"]
[OnName num="eMU"]
He was in a state of shock and disbelief.
[cpg cn=true]



She was absolutely stunned.
[cpg]

 Emu seems to be surprised and her head turned white.
[cpg]

[OnName num="middle_aged_man"]
I'm the black pot master.　This guy over here is Kei-kun!
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Misaki188"]
[OnName num="eMU"]
"Kei-kun...kun......, that's not possible......."
[cpg cn=true]



[OnName num="keisuke"]
..................."
[cpg cn=true]



The look was a mixture of surprise and disdain.
[cpg]

 I couldn't stand it and went down.
[cpg]

[OnName num="middle_aged_man"]
The first thing to do is to get a good look at the site.　I'm not sure what to say. Why don't you tell us your name, too?
[cpg cn=true]



Saying this, Yami nabe picked up the student notebook in Emu's breast pocket and examined it.
[cpg]

[OnName num="middle_aged_man"]
Oh, you're Misaki Tokugura, aren't you? That's a cute name. So you are Misaki's M, huh?
[cpg cn=true]



Yami nodded in satisfaction and tossed the notebook away.
[cpg]

[OnName num="keisuke"]
"Oh, you ...... tricked me, didn't you!
[cpg cn=true]



[OnName num="middle_aged_man"]
What are you talking about? I told you.　I wanted to help you.
[cpg cn=true]



I'm so angry with you, but you still say such a stupid thing.
[cpg]


[OnName num="middle_aged_man"]
This is my home now," he said. My wife, my kids, they're all gone.
[cpg cn=true]

[OnName num="middle_aged_man"]
"How can you joke that I'm going to give it to you and do you a favor?
[cpg cn=true]


[SE f="se023"]
;//【ＳＥ】引き倒す


;//●ＣＧ（美咲。横たわっていて、怯えている）ev_14

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=100]


[OnName num="middle_aged_man"]
Look at her. Look how scared she is.
[cpg cn=true]


[OnName num="middle_aged_man"]
With the power we have, I'd do anything for you.
[cpg cn=true]



[OnName num="keisuke"]
Oh, no. ....... ......
[cpg cn=true]


[VOICE f="sMisaki009"]
[OnName num="misaki"]
No, no, no, ......, please.
[cpg cn=true]



[OnName num="middle_aged_man"]
This is what you call a death sentence. This is our punishment for the wrong girls who exploit men on our site. Here, ......."
[cpg cn=true]


;**【ＣＧ】 ev_14_a ***********************
[CG id=7 index=1 time=100]
;***************************************
[WAIT time=100]


[VOICE f="Misaki191"]
[OnName num="misaki"]
No!
[cpg cn=true]



The dark pot moves closer to her. He's trying to touch her clothes.
[cpg]



[OnName num="keisuke"]
"Gobble........."
[cpg cn=true]


[VOICE f="Misaki192"]
[OnName num="misaki"]
"Ke-Kay...kun, you're lying. ...... You're such a ......
[cpg cn=true]



[OnName num="middle_aged_man"]
'You're such a what?　You can't get through to him now, no matter what you say to him."
[cpg cn=true]



[OnName num="keisuke"]
"Ah...ah......"
[cpg cn=true]



[OnName num="middle_aged_man"]
You know?" "Yeah?　It's a purge. You represent us, the men. Don't let him change his mind.
[cpg cn=true]


[OnName num="keisuke"]
"......, let's stop."
[cpg cn=true]


[OnName num="middle_aged_man"]
What ......?
[cpg cn=true]


;//移植前シーンカット

;//@
;//一軒家の中・リビング
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1000]
[BG f="b_10_3.ui" time=1000]
[WAIT time=1000]



[OnName num="keisuke"]
"If you go to the police now, you'll get off easy because ......
[cpg cn=true]



The dark pot looked deeply disappointed.
[cpg]


Then he clenched his ...... fists tightly.
[cpg]


[OnName num="middle_aged_man"]
"Why..., why don't you do what I want ....... Does every one of these guys ...... hate me that much ah!"
[cpg cn=true]



[SE f="se027"]
;//【ＳＥ】ガラスが割れる

[WAIT time=1500]



[FACE method="change_5" pos="2/3"]
[OnName num="keisuke"]
What?"
[cpg cn=true]



He shouted and picked up a blade.
[cpg]

And with the blade pointed at us, he starts swinging it around mangled.
[cpg]


Emu turns pale and looks at the dark pot. I guess I'm just like him.
[cpg]

I reach out to get him to safety.
[cpg]

[OnName num="keisuke"]
Come here!
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misaki217"]
[OnName num="misaki"]
No!
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】叩く



But his hand is repelled.
[cpg]


...... From her point of view, I'm the same as this guy.
[cpg]


[OnName num="middle_aged_man"]
Aaahhhh!"
[cpg cn=true]


And the man gradually closes the distance between us.
[cpg]


I ...... was prepared to take a risk and hit him with all the force I could muster.
[cpg]



The blade hits my skin. A sharp pain runs through me.
[cpg]


[SE f="se023"]
;//【ＳＥ】押し倒す


[OnName num="middle_aged_man"]
"Ugh!
[cpg cn=true]



[OnName num="keisuke"]
Run, run, run!"
[cpg cn=true]


[free time=1000]



Before I can say anything, Emu runs away.
[cpg]


......That's better. I know she won't be thanking me, but I've finally made myself useful.
[cpg]


[OnName num="middle_aged_man"]
"Get out of my way, ......!"
[cpg cn=true]


And then, the knife in the dark pot's hand is pointed at me.
[cpg]


;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]


Would the dark pot try to kill me? Even though he has a blade, if I'm like a dung beetle, I won't die right away.
[cpg]


I curl up with that thought. I would curl up, hoping to buy a little time so that I could save her.
[cpg]


I messed up my relationship with her with my own hands.
[cpg]



In the meantime, I hear the sirens of police cars.
[cpg]


They will question me about what I did.
[cpg]


I closed my eyes, thinking that I had survived and at the same time I didn't want to ...... know any more about it.
[cpg]

[SCENE id=13]

;//凶行・終

[jump storage="epend.ks" target="*start"]

