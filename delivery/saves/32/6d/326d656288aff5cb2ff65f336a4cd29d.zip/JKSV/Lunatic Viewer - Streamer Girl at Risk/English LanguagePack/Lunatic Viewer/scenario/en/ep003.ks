

*start

;#################################################
*Ep003|チャンスを逃すな
;#################################################

[SCENE id=3]



[stflag Jump_flg = 0]

[if exp={getFlagValue("Jump_flg") == 0 }]


[stflag Jump_flg = 1]

;//フラグ　初期化
[stflag Cha1flg_A = 0]
[stflag Cha1flg_B = 0]
[stflag Cha1flg_C = 0]

[stflag Cha2flg_A = 0]
[stflag Cha2flg_B = 0]
;//[stflag Cha2flg_C = 0]
[stflag Cha3flg_A = 0]
[stflag Cha3flg_B = 0]
[stflag Cha3flg_C = 0]
[stflag Cha3flg_D = 0]

[stflag Cha1flg_la = 0]
[stflag Cha2flg_la = 0]
[stflag Cha3flg_la = 0]

[stflag Cha1flg_lb = 0]
[stflag Cha2flg_lb = 0]
[stflag Cha3flg_lb = 0]
[stflag Cha1flg_lc = 0]

[stflag Evelflg = 0]
[stflag Bad_flg = 0]

[endif]

;//４日目昼

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公（啓介）の部屋』

When I woke up in the morning...or rather at noon, I received an announcement from Wakuteka Video.
[cpg]

Guerrilla Broadcasting in Emu's Room.
[cpg]



[OnName num="keisuke"]
What?　At this hour?
[cpg cn=true]



It was 11:00 in the afternoon, when the sun was still high in the sky.
[cpg]

Why was Emu-chan doing a guerrilla broadcast?
[cpg]

Well, what should we do?
[cpg]

If I go to see the guerrilla broadcast, I can't do anything else during the day.
[cpg]

I could spend half the day in Emu's room, or I could do something else. ......
[cpg]

;//qwe
;//■選択肢４日目昼　四択
[switch]
[case "Go to Emu's room."]
	[swap]
	[jump target="*select11_1"]
[case "go to the internet"]
	[swap]
	[jump target="*select11_2"]
[case "Go to a cafe"]
	[swap]
	[jump target="*select12_3"]
[case "Go to the park"]
	[swap]
	[jump target="*select12_4"]
[endswitch]

1, go to Emu's room;// (◆MISAKI gets Flag B)
2、Go to the internet;// (*Evil +1)
3、Go to the cafe;// (gets ◆Eye Flag D depending on whether or not ◆Eye Flag C is obtained) Flag D is obtained)
4、Go to the park;// (*Evil + 1)
;//==========================
;//１，ぇむの部屋へ行く（◆美咲フラグＢ）
*select11_1|チャンスを逃すな

[stflag Cha1flg_B = 1]

[OnName num="keisuke"]
You've got to go..."
[cpg cn=true]



It's rare to see a guerrilla broadcast, and I'm sure there won't be many people there in the afternoon.
[cpg]

I'm not a man to pass up an opportunity like this.
[cpg]

So I sat down at the computer desk and headed for the office.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ぇむの部屋』

＞ケイさんが入室されました
[cpg]

[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="3/7" time=800]

[OnName num="KEI"]
Good morning. Broadcasting at this hour? What a surprise.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki109"]
[OnName num="eMU"]
'Good morning, Kay-kun. Good morning. Yes, it is. I've never been on the air at this hour.
[cpg cn=true]



It seems I'm the only one here.
[cpg]

The others had gone down for the night. I heard they said they would be back soon. It's just before noon, so they must be busy.
[cpg]

Emu-chan was talking to me in the same way as at night.
[cpg]


;//＠
;//でも、いつもは部屋の蛍光灯に照らされての放送だが、今日は窓からの太陽光。
;//[cpg]
;//それが妙に新鮮で、彼女の肌色も透き通るように綺麗に見えた。
;//[cpg]

[OnName num="KEI"]
Why are you broadcasting at this hour?
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki110"]
[OnName num="eMU"]
She said, "Today, the school was closed because of the flu.
[cpg cn=true]



She was bored because she was told not to leave the house, so she decided to give it a try.
[cpg]

[OnName num="KEI"]
I see. Are you okay with the flu, Emu-chan?
[cpg cn=true]



[OnName num="keisuke"]
"..............."
[cpg cn=true]



[SE f="se025"]
;//【ＳＥ】パソコンタイプ

Behind my worrying about Emu-chan, I was typing on the keyboard.
[cpg]

The student site ...... is the one to access.
[cpg]

The site has threads for the schools and academies to which the students belong, and even threads for each class beyond that.
[cpg]

There, students chat, advertise events, schedule club games, talk about today's principal, and even talk about bullying at ..........
[cpg]

I went there and checked to see if any classes were closed today.
[cpg]

The answer is immediate.
[cpg]

"Kousei Gakuen 2A.
[cpg]


"Private Katsuragi Gakuen, 3rd Grade, Class 1, 2nd Grade, Class 3."
[cpg]



[OnName num="keisuke"]
Kousei Gakuen!
[cpg cn=true]



The other Katsuragi Gakuen is a boys' school, so there is no doubt anymore.
[cpg]

The other Katsuragi Gakuen is a boys' school, so there's no doubt about it.
[cpg]

[OnName num="keisuke"]
Oh, you're a student there ......?"
[cpg cn=true]



A little tension went up my spine.
[cpg]

Kosei Gakuen is a prestigious school where many daughters and celebrities from large companies attend.
[cpg]

 If so, Emu-chan must be a rich daughter.
[cpg]

But why is she doing video streaming?
[cpg]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki111"]
[OnName num="eMU"]
Why are you doing it, Kei-kun?　Is the class closed after all?"
[cpg cn=true]



She smiles wryly and asks me without any malice, and I feel bad about keeping it a secret forever.
[cpg]

I didn't have to tell her everything, but now that I had revealed one of her secrets, I felt I had to give something back to her.
[cpg]

I think there is a psychological term for this, but my mind couldn't recall it and my typing hand moved spontaneously.
[cpg]

[OnName num="KEI"]
I'm not going to school.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki112"]
[OnName num="eMU"]
'Oh, ......, that's right, .......'
[cpg cn=true]



The smile faded from Emu-chan's face when she saw what I had typed.
[cpg]

[OnName num="KEI"]
The reason is bullying.
[cpg cn=true]



I tell him myself even though he doesn't ask me. Or maybe she wants me to listen to her.
[cpg]

[FACE method="change_4" pos="3/7"]
[VOICE f="Misaki113"]
[OnName num="eMU"]
"......Go, I'm sorry. I'm...."
[cpg cn=true]



A small exclamation.
[cpg]

It was obvious that Emu was puzzled.
[cpg]

Of course she was.
[cpg]

We were having a good time talking, and then suddenly this heavy topic was dropped on us.
[cpg]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki114"]
[OnName num="eMU"]
Kay-kun...there are things you can talk about that will make you feel better, so if it's okay with me, I'll listen to what you have to say."
[cpg cn=true]



Her gentle smile looks like that of an angel in the sunlight.
[cpg]

Has anyone ever smiled at me like this before?
[cpg]

Reality was hard on me.
[cpg]

No one was on my side.
[cpg]

Even my family was like touching something swollen.
[cpg]

But I had an angel here.
[cpg]

[OnName num="KEI"]
The girl who was the center of my class bullied me, took embarrassing pictures of me, and posted them on the Internet.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki115"]
[OnName num="eMU"]
'Hi...that's too much ......'
[cpg cn=true]



[OnName num="KEI"]
'Since then, I just can't get up in the morning and go outside. The most important thing to remember is that you can't just take a look at the pictures of your family members.
[cpg cn=true]



Emu-chan held her mouth and seemed to sympathize with me wholeheartedly.
[cpg]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki116"]
[OnName num="eMU"]
But I'm on your side. Whenever you are in pain, you can tell me. If you use the secret room, you can talk about things you don't want people to hear. Right?
[cpg cn=true]



[OnName num="KEI"]
Why are you so kind, Emu-chan?
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki117"]
[OnName num="eMU"]
'It's normal to be kind to people who are hurting.
[cpg cn=true]



[OnName num="keisuke"]
「………………」
[cpg cn=true]



That's right.
[cpg]

It's normal for people to be kind to people who are hurting.
[cpg]

The only place in the world that teaches you such a thing is at your school.
[cpg]

I'm sure there are no bullies at her school.
[cpg]

She looks down from her untainted lofty vantage point and reaches out to me, the wretched one.
[cpg]

[OnName num="keisuke"]
"Oh, how far am I... distorted ......?"
[cpg cn=true]



While I am moved by the cuteness of Emu-chan visually and savoring the kindness that touches my heart, I am angry at the other side of ...... her.
[cpg]

The most important thing to remember is that the best way to get the most out of your money is to be honest with yourself.
[cpg]

The cute Emu-chan and the hateful Mari Hayashida are both just women at their core.
[cpg]

[OnName num="keisuke"]
If you would rather be deceived, it is better to be distorted. ......
[cpg cn=true]



＞Yami Nabe Inquisitor has entered the room.
[cpg]

[OnName num="yaminabebugyo"]
I'm home. I'm home.
[cpg cn=true]



The dark pot says it as if he had just returned home.
[cpg]

I'm not sure if he's a husband or a wife, but I'm sure he's a husband.
[cpg]

[OnName num="KEI"]
He says, "Hello.
[cpg cn=true]



[OnName num="yaminabebugyo"]
"Are you a NEET, chatting at this hour?
[cpg cn=true]



[OnName num="keisuke"]
You're here too, aren't you?
[cpg cn=true]



[OnName num="yaminabebugyo"]
"Anyway, Emu-chan, do you want to go incognito right now? Do you want to play secret now?
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki118"]
[OnName num="eMU"]
I don't want to. Kay is here too.
[cpg cn=true]



[OnName num="yaminabebugyo"]
He'll be down soon.
[cpg cn=true]



[OnName num="keisuke"]
".................."
[cpg cn=true]



How brazen can this bastard be?
[cpg]

I don't know what kind of horse you are, but do you enjoy acting as a strongman on the Internet?
[cpg]

[OnName num="KEI"]
I'll stay until you drop.
[cpg cn=true]



[OnName num="yaminabebugyo"]
"Why don't you show a little tact?"
[cpg cn=true]



[OnName num="KEI"]
"I'm staying because I'm smart."
[cpg cn=true]



[OnName num="yaminabebugyo"]
You're not going to get in a fight with me.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki119"]
[OnName num="eMU"]
'Can you please stop that kind of thing in my room ....... I'm sorry, I'm going to close ...... now because I did a guerrilla broadcast. I will see you all at night.
[cpg cn=true]



;//単色画面
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

After saying that, Emu-chan closed the room.
[cpg]

The bastard of the dark pot .......
[cpg]

But wait...if I wasn't there, would Emu-chan have gone to the secret with him?
[cpg]



[OnName num="keisuke"]
Uh-uh."
[cpg cn=true]



I don't want to. I don't want it to belong to anyone else.
[cpg]



;//４日目夜へ
[jump target="*day4_night"]
　;//==========================

;//２，ネットをする（★悪＋１）
*select11_2|チャンスを逃すな

[stflag Bad_flg=-1]

[OnName num="keisuke"]
'If I go to see her at this hour, she'll know I'm a NEET...'
[cpg cn=true]



I didn't want Emu-chan to find out about my backward life.
[cpg]

So I decided to go to the chat room and ask my mentor to talk to me honestly.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_7.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『雑談ルーム』

[OnName num="siren"]
You're thinking too much.
[cpg cn=true]



He laughed at my petulance.
[cpg]

[OnName num="siren"]
If there's a girl you're looking for, I think you should go there without looking aside.
[cpg cn=true]



[OnName num="KEI"]
I don't know.
[cpg cn=true]



[OnName num="siren"]
I'm sure you're right.' 'You have to study the girl's hobbies, observe her, and know everything about her to have a conversation that will please her. Once you miss an opportunity, someone else will pick it up and take advantage of it, right?
[cpg cn=true]



[OnName num="KEI"]
'Huh.'
[cpg cn=true]



As I was being lectured, it occurred to me...
[cpg]

[OnName num="KEI"]
"Let me change the subject..."
[cpg cn=true]



[OnName num="siren"]
"Yes.
[cpg cn=true]



[OnName num="KEI"]
"You're always here during the day, aren't you, Master?
[cpg cn=true]



[OnName num="siren"]
"Oh, I knew it!"
[cpg cn=true]



The master again let grass grow at the end of his sentence.
[cpg]

[OnName num="siren"]
I do work, but I also have a lot of free time.
[cpg cn=true]



[OnName num="KEI"]
'May I ask what kind of work you do?
[cpg cn=true]



[OnName num="siren"]
'It depends on the day and the time of day. It just so happens that my hours are more suited to you.
[cpg cn=true]



[OnName num="KEI"]
"Hmm."
[cpg cn=true]



I felt somewhat left out of the conversation, but it's not a good idea to probe into the personal information of someone who's been so kind to me.
[cpg]

I ended up having a nice conversation with my mentor that day and spent the rest of the time playing games.
[cpg]

;//４日目夜へ
[jump target="*day4_night"]
;//==========================
;//３，外出する　
*select11_3|チャンスを逃すな
;//c,カフェ
*select12_3|チャンスを逃すな

[OnName num="keisuke"]
I need a cup of coffee..."
[cpg cn=true]



I decided to go to a cafe.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『カフェ』



I order a wiener coffee at the café and spend an elegant moment.
[cpg]

The wiener coffee is a great value coffee that allows you to taste the bitterness of the coffee without dissolving the cream first, and then you can enjoy the sweetness of the coffee in different stages if you dissolve the cream little by little.
[cpg]

[SE f="se038"]
;//【ＳＥ】お知らせ着信

[OnName num="keisuke"]
Hm?"
[cpg cn=true]



My phone made an unusual sound, and I looked at the screen to see what it was...
[cpg]
I looked at the screen and saw that I had received a message informing me that "Lian's World Guerrilla Broadcasting" was on.
[cpg]

[OnName num="keisuke"]
Guerrilla?
[cpg cn=true]



That Hayashida guy skipped class at this hour!
[cpg]

I immediately accessed Wakuteka Video from my phone and entered Lian's World.
[cpg]

Then an unfriendly deposit screen appeared, with a statement that it would collect 1,000 yen....
[cpg]

[OnName num="keisuke"]
Damn. ......."
[cpg cn=true]



A bitter taste like drinking espresso spread in my mouth, and I pressed the deposit button.
[cpg]

Then, what was unfolding in the secret room was ......
[cpg]



[VOICE f="sMari013"]
[OnName num="Lian"]
Look at that!
[cpg cn=true]



[OnName num="keisuke"]
!!!!"
[cpg cn=true]


I switch to silent mode as the voice plays back.
[cpg]

I'm wearing a uniform that I don't know where it comes from, and my skirt is rolled up, and my legs are showing.
[cpg]

[VOICE f="Mari136"]
[OnName num="Lian"]
........................"
[cpg cn=true]



Even though I turned off the sound, I could tell by the movement of her mouth that she was saying something obscene.
[cpg]

What the hell is this guy thinking in the middle of the day!
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[VOICE f="Hitomi135"]
[OnName num="sober_staff"]
"Pour ...... some water. .........
[cpg cn=true]



[OnName num="keisuke"]
「………………」
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi136"]
[OnName num="sober_staff"]
「………？」
[cpg cn=true]



[OnName num="keisuke"]
Whoa!
[cpg cn=true]



[SE f="se027"]
;//【ＳＥ】コップ割れる
[FACE method="change_5" pos="2/3"]
I was so startled by the unassuming female waitress who was standing by me before I knew it, that I took down my glass of water and broke it.
[cpg]

[OnName num="keisuke"]
I was so surprised by the plain female waitress standing beside me that I dropped the glass of water and broke it.　I'm sorry!　I'll pay for it.
[cpg cn=true]



[FACE method="change_1" pos="2/3"]
[VOICE f="Hitomi137"]
[OnName num="sober_staff"]
No. ......"
[cpg cn=true]



The sober waitress cleaning up the broken glass.
[cpg]

[OnName num="keisuke"]
Oh, let me help you. ......
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi138"]
[OnName num="sober_staff"]
No...it's dangerous. ......
[cpg cn=true]



[OnName num="keisuke"]
I'm sorry. ......
[cpg cn=true]



;//▲瞳フラグＣがない場合、このまま進行

;//▲瞳フラグＣがある場合　→　;//火傷　へ
[if exp={getFlagValue("Cha3flg_C") == 1}]
[jump target="*yakedo"]
[endif]

Hayashida delivered this video...
[cpg]

Maybe that sober clerk saw me.
[cpg]

If so, I might have been blacklisted as a pervert customer who watches videos like that while drinking coffee in the backyard...
[cpg]

Damn it, it's Hayashida's fault. ......
[cpg]

Everything that's wrong with me is his fault now.
[cpg]

The red mailbox, the tall telegraph pole, it's all her fault!
[cpg]

And so I returned home, exasperated. ......
[cpg]

;//『カフェ』からは強制帰宅

;//４日目夜へ
[jump target="*day4_night"]
;//==========================
;//火傷
*yakedo|チャンスを逃すな

I can only watch the work and stare blankly at the clerk's hand movements without looking.
[cpg]

Then I see ......
[cpg]

[OnName num="keisuke"]
.........?"
[cpg cn=true]



I could see a red burn mark on the back of the sober clerk's hand.
[cpg]

It wasn't that bad, but it was still fresh and red, almost tingly.
[cpg]

[OnName num="keisuke"]
'Um, ...... hand, is it a burn?'
[cpg cn=true]



[FACE method="change_5" pos="2/3"]
[VOICE f="Hitomi139"]
[OnName num="sober_staff"]
"Yes........"
[cpg cn=true]



The shopkeeper quickly retracted his hand in a hurry when I asked him.
[cpg]

[OnName num="keisuke"]
It looked like ...... you were in pain.
[cpg cn=true]



[FACE method="change_4" pos="2/3"]
[VOICE f="Hitomi140"]
[OnName num="sober_staff"]
I'm fine...it's fine...I'm sorry ......."
[cpg cn=true]



[OnName num="keisuke"]
I'm sorry ...... too.
[cpg cn=true]



The clerk, who had finished cleaning up, disappeared into the back of the room as if to run away.
[cpg]

But the burns are strangely worrisome.
[cpg]

It's not unnatural for a café waitress to suffer such an injury while cooking.
[cpg]

However, I was still bothered by it.
[cpg]

I don't know why, but my interest in this cafe ......, or rather in that waitress, has increased.
[cpg]

[OnName num="keisuke"]
Thank you for the food. ......
[cpg cn=true]



That day, when I paid the bill, the plain waitress did not come out, and I returned to my house in a bewildered mood.
[cpg]

;//（▲瞳フラグＤ）
[stflag Cha3flg_D = 1]

;//『カフェ』からは強制帰宅

;//４日目夜へ
[jump target="*day4_night"]
;//==========================
;//d,公園（★凶＋１）
*select12_4|Don't take chances.

[stflag Evelflg=-1]

[OnName num="keisuke"]
Let's relax in the park..."
[cpg cn=true]



I was still a little sleepy, so I decided to take a nap in the park in the sun.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『公園』



[SE f="se002"]
;//【ＳＥ】子供達の遊ぶ声

[OnName num="keisuke"]
Oh my~......"
[cpg cn=true]



The park benches were filled with mothers.
[cpg]

The most important thing to keep in mind is that you should never be afraid to ask for help from a friend or family member.
[cpg]

[OnName num="keisuke"]
What is this ......?
[cpg cn=true]



The sign at the entrance says that the park belongs to everyone.
[cpg]

As I was thinking this and feeling indignant inside, I saw someone beckoning to me from the other side.
[cpg]

[OnName num="middle_aged_man"]
「…………」
[cpg cn=true]



It was a middle-aged businessman with a smiling, good-natured smile on his face.
[cpg]

[OnName num="keisuke"]
「………………」
[cpg cn=true]



It was a cliché, but I didn't feel comfortable not saying hello even though he recognized me, so I moved a little closer and just bailed.
[cpg]

[OnName num="middle_aged_man"]
You don't have anywhere to go either, do you?
[cpg cn=true]



[OnName num="keisuke"]
No...ha...well, ......."
[cpg cn=true]



He says clearly what is hard to hear and hard to say....
[cpg]

[OnName num="middle_aged_man"]
I've been laid off for six months now. Fortunately, I had some savings, and I'm thinking of making a fresh start with them, but I haven't had a chance to do so.
[cpg cn=true]



[OnName num="keisuke"]
"Oh..."
[cpg cn=true]



I'm sorry to hear that, but I'm not sure I'm the right person to talk to about it.
[cpg]

[OnName num="middle_aged_man"]
What about you?
[cpg cn=true]



[OnName num="keisuke"]
Oh, I'm ...... well, I'm ...... not going to school.
[cpg cn=true]



[OnName num="middle_aged_man"]
Were you bullied?
[cpg cn=true]



[OnName num="keisuke"]
......?
[cpg cn=true]



[OnName num="middle_aged_man"]
I'm sorry. I was bullied at work too. ......
[cpg cn=true]



[OnName num="keisuke"]
What?
[cpg cn=true]



I was bullied at work .......
[cpg]

The fact that I would be bullied in the workforce plunged me into a dark place.
[cpg]

If I'm going to be bullied even as an adult in the future, there's no point in living....
[cpg]

[OnName num="middle_aged_man"]
What is the world like? Bullies like us are bullied by everyone, no matter where we go.
[cpg cn=true]

[OnName num="middle_aged_man"]
I wonder if I will end my life as a loser who is looked down upon by both younger men and women, made fun of, and exploited all the time. ......
[cpg cn=true]


[OnName num="keisuke"]
Oh, um...excuse me, but ...... I can't believe you killed yourself."
[cpg cn=true]



I was worried about the worst when I saw the old man start to mumble and mutter.
[cpg]

The best way to get a good idea of what to expect from the site is to read the site's privacy policy.
[cpg]

[OnName num="middle_aged_man"]
I've thought about that a lot. ......
[cpg cn=true]



[OnName num="keisuke"]
No, you can't. ......
[cpg cn=true]



[OnName num="middle_aged_man"]
Why?　No one needs me..." The old man smiled sadly.
[cpg cn=true]



The old man smiled sadly.
[cpg]

[OnName num="keisuke"]
I'm sure there are things you still ...... want to do, things you have left to do, things you've always wanted to do, right?　You said earlier that you have savings, and it's not too late to do something with them. ......
[cpg cn=true]



Not knowing how to dissuade a suicidal person, I just blurted out a few random words.
[cpg]

I didn't want to be the last person the old man spoke to. ......
[cpg]

[OnName num="middle_aged_man"]
I said, "Well, that's ...... what I'd like to do. That's what I want to do. ......
[cpg cn=true]



[OnName num="keisuke"]
"...... hot."
[cpg cn=true]



The old man seemed to have managed to change the direction of his thinking, and he stretched out his rounded back and leaned against the back of the bench.
[cpg]

[OnName num="middle_aged_man"]
If you were an adult, you could have taken him out for a drink and had a bitchfest with him.
[cpg cn=true]



[OnName num="keisuke"]
............"
[cpg cn=true]



I'm not going to do that, even if I were an adult.
[cpg]

[OnName num="middle_aged_man"]
I was just starting out 24 years ago,.......
[cpg cn=true]



[OnName num="keisuke"]
Wow. ......
[cpg cn=true]



I spent a lot of wasted time in the park that day with an old man who started talking back a long time ago.
[cpg]

;//４日目夜へ
[jump target="*day4_night"]

;//==========================


*day4_night|チャンスを逃すな


;//４日目夜
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公（啓介）の部屋』




[OnName num="keisuke"]
When the day comes, the night comes again with ......
[cpg cn=true]



I finished my dinner as usual, and stood in front of the computer.
[cpg]

;//パソコン画面：ワクテカ動画
Emu's Room": Opens today at 8:00 p.m.[r]
Lian's World" opens today at 8:00 p.m.[r]
H Castle": not scheduled to be released today
[cpg]

[OnName num="keisuke"]
What's that?　H Castle is closed..."
[cpg cn=true]



Something about the fact that they've been distributing every day since then, I thought that was the way it was supposed to be, but of course there are days when they don't.
[cpg]

I felt uncomfortable for a moment, but I reconsidered, and then I changed my mind and chose a room again.
[cpg]

[OnName num="keisuke"]
Now, which way shall we go...?
[cpg cn=true]



;//■選択肢（４日目夜）２択
[switch]
[case "Emu's room"]
	[swap]
	[jump target="*select13_1"]
[case "Rian's World"]
	[swap]
	[jump target="*select13_2"]
[endswitch]

1，Gemu's Room;// (◆MISAKI Flag C obtained)
2，Lian's World;// (◆Mari Flag B obtained)
;//==========================
;//１，ぇむの部屋
*select13_1|チャンスを逃すな


;//（;//◆美咲フラグＣ）
[stflag Cha1flg_C = 1]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ぇむの部屋』

＞ケイさんが入室されました
[cpg]

[FG f="CHA01_p5_02_a.ui" method="change_2"  pos="3/7" time=800]
[VOICE f="Misaki120"]
[OnName num="eMU"]
Good evening, Kay.
[cpg cn=true]



[OnName num="KEI"]
Hello.
[cpg cn=true]



[OnName num="kumachan"]
Hello.
[cpg cn=true]



[OnName num="oac"]
Hello.
[cpg cn=true]



The usual members seemed to be getting to know each other quite well.
[cpg]

I felt relieved when I saw the names of these people.
[cpg]

[OnName num="KEI"]
What were you talking about?
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki121"]
[OnName num="eMU"]
'You know, about Seven Top's pudding buns.
[cpg cn=true]



[OnName num="aaa"]
'I don't like that it tastes like pudding but it's warm...'
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki122"]
[OnName num="eMU"]
'Oh, even though it tastes good.
[cpg cn=true]



[OnName num="kanata"]
I was talking about Seven Top's pudding buns. But Pizza Man's is good.
[cpg cn=true]



[OnName num="oac"]
But Pizza Man is better.
[cpg cn=true]



[OnName num="kanata"]
That's true.
[cpg cn=true]



I don't care what you say.
[cpg]

[OnName num="kumachan"]
I don't care about that kind of talk. What do you think, Mr. Kay?
[cpg cn=true]



[OnName num="keisuke"]
"Well, I like ......
[cpg cn=true]



;//窓が一瞬、外からのハイビームで強く発光する

[OnName num="KEI"]
I like curry buns.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki123"]
[OnName num="eMU"]
"Well...could it be that pudding buns are unpopular...?　Shocking.
[cpg cn=true]



[OnName num="kanata"]
"Because pudding is ......
[cpg cn=true]



[OnName num="aaa"]
I'm shocked.
[cpg cn=true]



While the chatting continues, I observe Emu-chan's room because I'm a little curious about something.
[cpg]


;//■選択肢_夜_４日目_ぇむ

[stflag mselecter14_cnt = 2]

*mselecter04|チャンスを逃すな

[if exp={getFlagValue("mselecter14_cnt") == 0}]
[jump target="*4niend_em"]
[endif]

[switch]
[case "Emu's face"]
	[swap]
	[jump target="*Msel4_01"]
[case "Emu's chest"]
	[swap]
	[jump target="*Msel4_02"]
[case "Emu's head"]
	[swap]
	[jump target="*Msel4_03"]
[case "The window"]
	[swap]
	[jump target="*Msel4_04"]
[case "The bed."]
	[swap]
	[jump target="*Msel4_05"]
[case "Stuffed animal"]
	[swap]
	[jump target="*Msel4_06"]
[case "The door."]
	[swap]
	[jump target="*Msel4_07"]
[endswitch]

;//==========================
;//ぇむの顔
*Msel4_01|チャンスを逃すな

[stflag mselecter14_cnt=-1]

Emu-chan's face.
[cpg]

A smile as unblemished as an angel's.
[cpg]

If there had been a girl like this in my class, my destiny might have changed.
[cpg]

[jump target="*mselecter04"]
;//==========================
;//ぇむの胸
*Msel4_02|Don't miss your chance.

[stflag mselecter14_cnt=-1]

I want to bury my face in that cleavage....
[cpg]

If I can do that, I promise to come to school.
[cpg]

[jump target="*mselecter04"]
;//==========================
;//ぇむの頭
*Msel4_03|チャンスを逃すな

[stflag mselecter14_cnt=-1]

I want to twirl my fingers in that hair.
[cpg]

My thoughts have been perverted lately, but I believe this is a man's instinct.
[cpg]

[jump target="*mselecter04"]
;//==========================
;//窓（※最初に窓をクリックすると、再びハイビーム）
*Msel4_04|チャンスを逃すな

[stflag mselecter14_cnt=-1]

;//窓にハイビームが差し込んで一瞬明るくなる

[free time=500]
[BG f="white.ui" time=500]
[WAIT time=500]
[FG f="CHA01_p5_02_a.ui" method="change_7"  pos="3/7" time=500]
[BG f="b_05_3.ui" time=500]
[WAIT time=500]

[OnName num="keisuke"]
「！？」
[cpg cn=true]



What was that?
[cpg]

Suddenly the window seemed to glow like a water mirror shield...
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki124"]
[OnName num="eMU"]
I'm sorry, there's a delivery center diagonally across the street, and when the trucks have their high beams on, it's just like now. Don't worry about it too much."
[cpg cn=true]



;//（;//◆美咲フラグＣ）
[if exp={getFlagValue("Cha1flg_C") == 0 }]
[stflag Cha1flg_C = 1]
[endif]



[FACE method="change_1" pos="3/7"]


[jump target="*mselecter04"]
;//==========================
;//ベッド
*Msel4_05|チャンスを逃すな

[stflag mselecter14_cnt=-1]

I want to sleep here too.
[cpg]

I want to sleep here with you.
[cpg]

[jump target="*mselecter04"]
;//==========================
;//ぬいぐるみ
*Msel4_06|チャンスを逃すな

[stflag mselecter14_cnt=-1]

I really envy these stuffed animals.
[cpg]

They are always here watching Emu-chan change her clothes and sleep.
[cpg]

I want to be a stuffed animal when I am reborn.
[cpg]

[jump target="*mselecter04"]
;//==========================
;//ドア
*Msel4_07|チャンスを逃すな

[stflag mselecter14_cnt=-1]

I wish the door to my room was connected to this door when I open it.
[cpg]

Then she wouldn't be able to go anywhere without going through my room....
[cpg]

That would be great .......
[cpg]

[jump target="*mselecter04"]
;//==========================
;//２箇所クリック後
*4niend_em|チャンスを逃すな

[OnName num="aaa"]
'After all, the best thing to do is to buy meat buns and pudding separately.
[cpg cn=true]



[OnName num="kumachan"]
Oh, I agree with that.
[cpg cn=true]



I didn't know this topic was still going on...
[cpg]

＞Mr. Yami Nabe Inquisitor has entered the room.
[cpg]

Due to his recent attitude, the atmosphere changes when the Yami Nabe Inquisitor enters the room.
[cpg]

But I can't tell in the chat room, so I just thought so on my own....
[cpg]

But it soon became clear that it was not my imagination.
[cpg]

[OnName num="yaminabebugyo"]
What's the topic of conversation tonight?
[cpg cn=true]



[OnName num="oac"]
"It's about pudding buns.
[cpg cn=true]



[OnName num="yaminabebugyo"]
'Oh, no, not that kind of nonsense again...'
[cpg cn=true]



[OnName num="kanata"]
'It's good that everyone is having fun, isn't it?
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki125"]
[OnName num="eMU"]
"Yeah, yeah, yeah. I love pudding buns. Pudding buns.
[cpg cn=true]



[OnName num="yaminabebugyo"]
"You know what I love more than that?
[cpg cn=true]



[OnName num="yaminabebugyo"]
"A tough guy like me."
[cpg cn=true]


[FACE method="change_5" pos="3/7"]
[VOICE f="Misaki126"]
[OnName num="eMU"]
"Nah...!"
[cpg cn=true]



The place froze at the vulgar remarks of the dark pot.
[cpg]

[OnName num="kanata"]
You!
[cpg cn=true]



[OnName num="oac"]
What are you talking about all of a sudden?
[cpg cn=true]



[OnName num="aaa"]
You're the worst!
[cpg cn=true]



The regulars' anger spilled over into the dark pot.
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki127"]
[OnName num="eMU"]
What's the matter, Inquisitor? Are you drunk?"
[cpg cn=true]



Emu-chan was trying to smile, but she had a cramp.
[cpg]

[OnName num="yaminabebugyo"]
'I was just telling the truth. Or so you say!　You were saying what you've been saying in some kind of metaphor.'
[cpg cn=true]



[OnName num="KEI"]
'I wonder... are you stupid?'
[cpg cn=true]



I couldn't help but tsk tsk into the dark pot too.
[cpg]

[OnName num="yaminabebugyo"]
I've been here for a long time and I'm tired of this kind of meaningless chit-chat. We're all after money and men anyway, so let's just move on to the secret.
[cpg cn=true]


[FACE method="change_3" pos="3/7"]
[VOICE f="Misaki128"]
[OnName num="eMU"]
'Enough!
[cpg cn=true]



[OnName num="kumachan"]
You're being too rude!
[cpg cn=true]



[OnName num="yaminabebugyo"]
'Well, let me ask you, who among you doesn't want the Secret at least a little bit?　Raise your hand if you don't want to go.
[cpg cn=true]



Scene .......
[cpg]

Even the chat seemed to be a bunch of honest people who couldn't lie, and no one refuted the dark pot.
[cpg]

I felt that there was something wrong with me, too.
[cpg]

[OnName num="yaminabebugyo"]
So, for today, everyone pays 10,000 each.
[cpg cn=true]



>By the organizer's authority, Mr. Dark Pot Inquisitor has been forcibly logged out.[r]
>If the account is found to be malicious in a future review, the account of Mr. Yami Nabe Inquisitor will be suspended.
[cpg]

[OnName num="aaa"]
This is the first time I've seen this. Is this a cutout?
[cpg cn=true]



As I recall, the organizers have the authority to forcibly remove viewers who disrupt the place...
[cpg]

What kind of a guy from Yami no Nabe is going to get so excited knowing that?
[cpg]
[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki129"]
[OnName num="eMU"]
'I'm sorry, folks, for ....... I couldn't take it any longer..."
[cpg cn=true]



With a sad look on her face, Emu apologizes.
[cpg]

[OnName num="oac"]
You don't have to apologize, Emu-chan!
[cpg cn=true]



[OnName num="kumachan"]
'Yes, it's the Dark Pot Inquisitor who is to blame. The one to blame is the Yami Nabe Inquisitor.
[cpg cn=true]



[OnName num="kanata"]
It's all right. We felt bad too.
[cpg cn=true]



None of them denied what Yami Nabe had said, but the regulars instantly looked like the good guys.
[cpg]

I couldn't say anything. ......
[cpg]


I'm just as dirty and scumbag inside as Yami Nabe.
[cpg]


[FACE method="change_4" pos="3/7"]
[VOICE f="Misaki130"]
[OnName num="eMU"]
No.... The truth is, I should be able to contain the situation better... because I'm the organizer. I'm really sorry. Please let me end today with this."
[cpg cn=true]



Everyone exchanged a few parting words as Emu-chan bowed her head deeply, and one by one, they all dropped off one by one.
[cpg]

[OnName num="oac"]
Don't worry, just get some rest.
[cpg cn=true]



＞Mr. Oak has left the room.
[cpg]

[OnName num="aaa"]
I'm going to buy some pudding buns.
[cpg cn=true]



＞Ahhhh, you have left the room.
[cpg]

And so the night ended. ......
[cpg]

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

;//◆美咲フラグＢがない場合　このまま大分岐へ
[if exp={getFlagValue("Cha1flg_B") == 1}]
[jump target="*misakiflg_B"]
[endif]



[jump target="*Abranch"]

;//◆美咲フラグＢがある場合　→;//◆美咲フラグＢ　へ

;//◆美咲フラグＢ
*misakiflg_B|チャンスを逃すな



It seemed that...
[cpg]

For some reason, I received a message, and when I opened it, it was a secret pass from Emu-chan.
[cpg]

I was surprised, but I didn't know what it was until I went there, so I transferred the 100 yen specified on the deposit page and went straight to the secret room.
[cpg]




[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_ya"]
[WAIT time=100]
;//【ＢＧ】『ぇむの部屋シークレットルーム』

[FG f="CHA01_p5_02_a.ui" method="change_7"  pos="3/7" time=800]
[VOICE f="Misaki131"]
[OnName num="eMU"]
I was surprised, but I couldn't figure out what was going on there.
[cpg cn=true]



[OnName num="KEI"]
'No, what's wrong?'
[cpg cn=true]



Emu-chan was visibly depressed in her usual room.
[cpg]

[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="3/7" time=800]
[VOICE f="Misaki132"]
[OnName num="eMU"]
'It's not the first time someone said something like that to me...' I ......"
[cpg cn=true]



[OnName num="KEI"]
'I see...'
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki133"]
[OnName num="eMU"]
'And you know...I do understand. ......
[cpg cn=true]



[OnName num="KEI"]
"Yeah, what?"
[cpg cn=true]


[FACE method="change_6" pos="3/7"]
[VOICE f="sMisaki004"]
[OnName num="eMU"]
'Everybody ...... knows that guys come here for that kind of ...... thing .......
[cpg cn=true]



[OnName num="KEI"]
"That's..."
[cpg cn=true]



The most important thing to remember is that you can't just go to the store and ask for a discount.
[cpg]

 So I was just stuck in words.
[cpg]
[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki135"]
[OnName num="eMU"]
The most important thing to remember is that you can't just say "I'm sorry, I'm sorry, I'm sorry, I'm sorry.
[cpg cn=true]



[OnName num="KEI"]
Yeah."
[cpg cn=true]


[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="3/7" time=800]
[VOICE f="Misaki136"]
[OnName num="eMU"]
I thought again today that ...... I am just taking advantage of everyone's feelings.
[cpg cn=true]



[OnName num="KEI"]
I didn't mean to take advantage of you.
[cpg cn=true]


[FG f="CHA01_p5_02_a.ui" method="change_7"  pos="3/7" time=800]
[VOICE f="sMisaki005"]
[OnName num="eMU"]
I've been lonely... I'm always home alone... but if I come here, someone will come and tell me all kinds of fun stories... and then more and more people will gather and we can all have a good time together. ......
[cpg cn=true]


[VOICE f="sMisaki905"]
[OnName num="eMU"]
So I thought of the video streaming as just opening up my room. I was just enjoying myself, leaving everyone else's purpose behind..."
[cpg cn=true]



[OnName num="KEI"]
'I think you're thinking too much ......'
[cpg cn=true]



I felt a little pain in my heart when I heard Emu's monologue.
[cpg]




[OnName num="KEI"]
I was a bit heartbroken when I heard Emu's monologue. Some people leave when they realize that you don't do anything, and some people stay because they still want to talk to you.
[cpg cn=true]



[OnName num="KEI"]
'Sure, they're all guys and they think about that kind of thing, but still...with or without that, I think there are a lot of people who come to the room just to talk to Emu-chan.
[cpg cn=true]



As I wrote these things down, I was suppressing the black thing inside me.
[cpg]

I'm one of the worst users of the room, thinking all kinds of dirty things, looking at Emu-chan's breasts while talking to her, and having weird fantasies about her.
[cpg]

But I don't want to be the only one to be the bad guy when you talk to me like this,.......
[cpg]

[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki138"]
[OnName num="eMU"]
"Kay, you know,...... there's actually something I wanted to talk to you about."
[cpg cn=true]



[OnName num="KEI"]
What?"
[cpg cn=true]



 I thought that I wanted to talk about it now, so I stared at Emu-chan's face no matter what.
[cpg]

The actual "I'm not sure what you're talking about, but I'm not sure what you're talking about.
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki139"]
[OnName num="eMU"]
I think I ...... might have seen Kay.
[cpg cn=true]



[OnName num="KEI"]
What do you mean?
[cpg cn=true]



I'm not sure if I've seen her on the street?
[cpg]

Passing each other?
[cpg]

No,...... I can find her if that's the case, but it should be impossible for her to recognize me.
[cpg]

Then why?
[cpg]

[VOICE f="Misaki140"]
[OnName num="eMU"]
I didn't do it on purpose. Actually..."
[cpg cn=true]



She speaks softly. When I was absent due to a class closure, I received various e-mails from people in the same class who were having too much time on their hands.
[cpg]

One of them had a video attached that came from a student website: ......
[cpg]

[OnName num="keisuke"]
I thought to myself, "No...no way.........."
[cpg cn=true]



No way. ...... Hey, that's a lie. ......
[cpg]

The worst possible continuation unfolds in my head.
[cpg]

I would have stopped time here if I could have, and I definitely didn't want to hear the rest of it.
[cpg]

[VOICE f="Misaki141"]
[OnName num="eMU"]
The video is ......, and it looks exactly like the one Kay told me about at lunch... .......
[cpg cn=true]



[OnName num="KEI"]
Did you watch it?
[cpg cn=true]


[FACE method="change_5" pos="3/7"]
[VOICE f="Misaki142"]
[OnName num="eMU"]
I didn't watch the whole thing!　I thought it might be, and immediately stopped looking at it ......, so I don't know if it's really ......."
[cpg cn=true]



I saw all of them, but I can't judge if they are real or not because you don't know what I look like.
[cpg]

But if you've seen the video with the same content I talked about, it doesn't matter if it's me or not.
[cpg]

It's the same thing as if Emu-chan had already seen me in all my glory, and that's it!
[cpg]



[OnName num="keisuke"]
Damn it!　Damn fucking kusoooooooooooooooooooooooooooooooooooooooooooooooooooo!"
[cpg cn=true]



I never thought that Emu would see me in the white briefs that she made fun of so much!
[cpg]

Why, why, why!
[cpg]

Why did I talk like an idiot about how this girl did that to me!
[cpg]

If I hadn't told her, it would have been just a bullying video, but because I let her hear it, she recognized it as "my video"!
[cpg]

[OnName num="keisuke"]
Ohhhhhhhhhh ！！！！"
[cpg cn=true]



I reeled and bounced off the things on the desk with a swoosh.
[cpg]

The thing on the floor made a broken sound, but I don't care.
[cpg]

I just want to get myself out of the way already.
[cpg]

I just want to be a broken corpse that doesn't understand anything!
[cpg]

[FACE method="change_4" pos="3/7"]
[VOICE f="Misaki144"]
[OnName num="eMU"]
I'm sorry. I don't want to report that I saw it. I just wanted to tell you..."
[cpg cn=true]



It's not my fault that he did that to you, you didn't do anything wrong ...... she says.
[cpg]

She crosses her hands in front of her chest as if praying and desperately appeals to me.......
[cpg]

[OnName num="keisuke"]
'You hypocrite,.......
[cpg cn=true]



My vision is distorted...
[cpg]

I wipe my tears and stare at her through the monitor.
[cpg]

[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki145"]
[OnName num="eMU"]
Kay, you're the victim, you shouldn't care about those people. ......
[cpg cn=true]




[OnName num="KEI"]
Who are those people? The guy who made the video to you?　Who are the guys who forwarded the video to you?　What about the people who thought it was funny and forwarded it to their friends?
[cpg cn=true]


[OnName num="KEI"]
Who copied and pasted it onto some website?　Who cares if they're going to be staring at that mess for the rest of their lives?　That's easy for you to say, isn't it!
[cpg cn=true]



What a moron, crying, tapping the keys, and putting a ! mark at the end of the word.
[cpg]

I'm half laughing as I cry.
[cpg]

[OnName num="keisuke"]
'Ugh, heh...ghuhuhuhu......'
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki146"]
[OnName num="eMU"]
I know how you feel. ......
[cpg cn=true]



[OnName num="keisuke"]
"Hehe...hehe...I understand how you feel...ohhhh!　I'm not sure if the celebrity students at a prestigious young lady's academy can understand how I feel.　Hahahahahahahahahahaha!
[cpg cn=true]



I don't think Emu can even understand what I'm going through in front of the computer right now.
[cpg]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki147"]
[OnName num="eMU"]
I'm going to help you, Kay-kun. ......
[cpg cn=true]



[OnName num="KEI"]
"Then comfort me.
[cpg cn=true]



[VOICE f="Misaki148"]
[OnName num="eMU"]
「………………」
[cpg cn=true]



[OnName num="KEI"]
I can't help you!　I'm just a stranger who met in a chat room!　I'm just a guy like everyone else, a helpless guy, just like Dark Pot says!　And you're just a girl who wants to talk!
[cpg cn=true]



[FG f="CHA01_p5_02_a.ui" method="change_6"  pos="3/7" time=800]
[VOICE f="Misaki149"]
[OnName num="eMU"]
If it's any consolation to ...... Kay.
[cpg cn=true]



[OnName num="keisuke"]
What ...... to ......?"
[cpg cn=true]


;//●ＣＧ（美咲。足を少し開いている）ev_10
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=100]


Emu changes her sitting position and opens her legs a little.
[cpg]


[FACE method="change_6" pos="3/7"]
[VOICE f="sMisaki006"]
[OnName num="eMU"]
I don't know what I can do to comfort you..."
[cpg cn=true]


[VOICE f="sMisaki007"]
[OnName num="eMU"]
But you tell me what to say, what you want me to say..."
[cpg cn=true]

[OnName num="keisuke"]
"Which...what ...... are you going......... to do?"
[cpg cn=true]



A shaky snarl escaped my throat, and I bit down on the monitor to look at Emu.
[cpg]

I looked at her, her face averted and her eyes closed.
[cpg]

[OnName num="keisuke"]
"You're going to do this ...... for me... ........."
[cpg cn=true]



If he can do this just to comfort his tormentor, I wonder what he would do to a man who's been through worse.
[cpg]

I guess I was already too shocked to think like a normal human being after seeing that.
[cpg]

[OnName num="KEI"]
That's not what I wanted to see.
[cpg cn=true]


[OnName num="KEI"]
You saw me being bullied!　You saw it and thought it was me!　You saw me embarrassed!
[cpg cn=true]


;**【ＣＧ】 ev_10_a ***********************
[CG id=6 index=1 time=100]
;***************************************
[WAIT time=100]


[FACE method="change_4" pos="3/7"]
[VOICE f="Misaki152"]
[OnName num="eMU"]
'I'm sorry ...... forgive me ......'
[cpg cn=true]



Emu's eyebrows twisted in grief.
[cpg]

I know in my head that it's not her fault that I saw the video, but I can't stop my emotions.
[cpg]


[OnName num="KEI"]
The most important thing to remember is that you can't just say anything to comfort you. There's nothing I want you to say.
[cpg cn=true]



[VOICE f="sMisaki008"]
[OnName num="eMU"]
' ......"
[cpg cn=true]



I'm saying things that annoy her. I know it, but I couldn't stop me.
[cpg]


And yet... I also feel my emotions switching at a tremendous speed.
[cpg]



;//移植前シーンカット


I was sobbing a little, and I was so cold.
[cpg]


I was even scared of the tremendous swell of emotions that was happening inside me at this moment.
[cpg]



Anger, shame, and excitement were all mixed together in a way that I could not suppress.
[cpg]

I was at a loss as to what to do about it.
[cpg]

[OnName num="keisuke"]
I think you need to cool down a bit. ......
[cpg cn=true]






;//大分岐へ
[jump target="*Abranch"]
;//２，リアンズワールド
;//==========================
*select13_2|チャンスを逃すな

[stflag Cha2flg_B = 1]

[OnName num="keisuke"]
............
[cpg cn=true]



I go to Hayashida, whom I don't want to see or meet.
[cpg]

I wonder if I'm being haunted by something. ......
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『リアンズワールド』

＞Kei has entered the room.
[cpg]

[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="3/7" time=800]

[VOICE f="Mari137"]
[OnName num="Lian"]
"Kay-chan halo-halo!"
[cpg cn=true]



[OnName num="KEI"]
"Hallo Hallo."
[cpg cn=true]


[OnName num="john_doe0814"]
'Rian-chan, did you get a haircut?
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="sMari014"]
[OnName num="Lian"]
"Cahahaha!　You think you'll get it right if you say it just right.
[cpg cn=true]



Hayashida laughs at Nanashi's comment.
[cpg]

Is it only me whose high-pitched voice is getting on my nerves?
[cpg]

I don't join in the chat and ransack Hayashida's room.
[cpg]


;//■選択肢_夜_４日目_リアン

[stflag Rselecter24_cnt = 2]


*Rselecter04|チャンスを逃すな

[if exp={getFlagValue("Rselecter24_cnt") == 0}]
[jump target="*4niend_ri"]
[endif]


;//＠qwe
[switch]
[case "Leanne's face"]
	[swap]
	[jump target="*Rsel4_01"]
[case "Leanne's chest"]
	[swap]
	[jump target="*Rsel4_02"]
[case "Leanne's head"]
	[swap]
	[jump target="*Rsel4_03"]
[case "窓"]
	[swap]
	[jump target="*Rsel4_04"]
[case "ベッド"]
	[swap]
	[jump target="*Rsel4_05"]
[case "Table"]
	[swap]
	[jump target="*Rsel4_06"]
[case "Closet"]
	[swap]
	[jump target="*Rsel4_07"]
[case "Leanne"]
	[swap]
	[jump target="*Rsel4_01"]
[endswitch]

;//==========================
;//リアンの顔
*Rsel4_01|チャンスを逃すな

[stflag Rselecter24_cnt=-1]

Duck mouths piss me off.
[cpg]

I don't like the duck mouth itself, even when it's serious, it seems to have a thin smile on its face.
[cpg]

What's so cute about that thing?
[cpg]

[jump target="*Rselecter04"]
;//==========================
;//リアンの胸
*Rsel4_02|チャンスを逃すな

[stflag Rselecter24_cnt=-1]

A bra would be a waste on her breasts.
[cpg]


[jump target="*Rselecter04"]
;//==========================
;//リアンの頭
*Rsel4_03|チャンスを逃すな

[stflag Rselecter24_cnt=-1]

There is definitely a worm inside her head.
[cpg]

He is so stupid because those worms are eating his brain.
[cpg]

[jump target="*Rselecter04"]
;//==========================
;//窓
*Rsel4_04|チャンスを逃すな

[stflag Rselecter24_cnt=-1]

When I die, I'll become a ghost and come in here.
[cpg]

And I'm going to strangle this guy in his sleep and make him suffer. ......
[cpg]

[jump target="*Rselecter04"]
;//==========================
;//ベッド
*Rsel4_05|チャンスを逃すな

[stflag Rselecter24_cnt=-1]

It's such a mess, even the bed is strewn with stuff, that if you call the cops, they'll think you're a thief when they arrive.
[cpg]

Then it would be very embarrassing to explain that it's always like this. Yeah, that's one way to harass people.
[cpg]

[jump target="*Rselecter04"]
;//==========================
;//テーブル
*Rsel4_06|チャンスを逃すな

[stflag Rselecter24_cnt=-1]

Even if I am reborn, I don't want to be just this mirror.
[cpg]

It would be a living hell to keep seeing this ugly face every day.
[cpg]

[jump target="*Rselecter04"]
;//==========================
;//クローゼット
*Rsel4_07|チャンスを逃すな

[stflag Rselecter24_cnt=-1]

If I tie him up and lock him up, how long will it take for him to die....
[cpg]

I might be happy if he dies buried in his clothes.
[cpg]

[jump target="*Rselecter04"]
;//==========================
;//２箇所クリック後
*4niend_ri|チャンスを逃すな

[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="3/7" time=800]
[VOICE f="Mari141"]
[OnName num="Lian"]
Hey, by the way, something good happened today and we want to celebrate, so let's all go to Secret..."
[cpg cn=true]



Hayashida suddenly said something like that, and Nanashi and the others were overjoyed.
[cpg]

[OnName num="john_doe0708"]
"I'm going to go to the secret place with you guys!
[cpg cn=true]



[OnName num="john_doe1213"]
Let's go!
[cpg cn=true]



;//入金画面に
[free time=1000]

[OnName num="keisuke"]
You're looking down on me..."
[cpg cn=true]



I sighed as the monitor switched to the deposit screen.
[cpg]

One thousand yen is a lot of money for a student...
[cpg]

3,000 yen today ......!
[cpg]

What the hell did they think they were doing raising the price?
[cpg]

No, does the fact that they raised the price mean there is something to it?
[cpg]

[OnName num="keisuke"]
Damn...!"
[cpg cn=true]



I was a little lost, but I pressed the button to make the transfer and went into the secret room.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_6.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『リアンズワールドシークレットルーム』

[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="3/7" time=800]
[VOICE f="Mari142"]
[OnName num="Lian"]
Today, a video I posted made the top three!
[cpg cn=true]



[OnName num="john_doe0617"]
8888888888."
[cpg cn=true]



[OnName num="john_doe0908"]
"Oh, wow!　That's great.
[cpg cn=true]



[OnName num="john_doe1102"]
"What kind of video?"
[cpg cn=true]


[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="3/7" time=800]
[VOICE f="Mari143"]
[OnName num="Lian"]
"Watch it, watch it, watch it.　"Okay, I'll give it to you all as a thank you for your continued patronage.
[cpg cn=true]


"I received a message from Rian.
[cpg cn=true]



[OnName num="keisuke"]
What is it?
[cpg cn=true]



I received a message too, and when I opened it, only the URL was displayed.
[cpg]

I opened it without any alarm and found a message from ......
[cpg]

[OnName num="keisuke"]
What is this?
[cpg cn=true]



[OnName num="john_doe1026"]
What is this?
[cpg cn=true]



[OnName num="john_doe0808"]
I don't want no naked men."
[cpg cn=true]



[OnName num="keisuke"]
Oh...oh...oh...oh..."
[cpg cn=true]



The video was distributed to everyone, including me.
[cpg]

It was the video of that abominable bullying.
[cpg]

On the screen, I was verbally abused and stripped of my uniform.
[cpg]

My skinny body was so poor that I felt pathetic even when I looked at it.
[cpg]



[OnName num="keisuke"]
'Ohhhhhhhhhh ！！！！'
[cpg cn=true]



[SE f="se020"]
;//【ＳＥ】破壊音

He reaves everything on the desk with his arms and stomps on various objects on the floor.
[cpg]

[OnName num="keisuke"]
'Why oh why oh why oh why oh ！！！！
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="sMari015"]
[OnName num="Lian"]
What's going on?　It's funny, isn't it? I thought, "There are boys who are just beaten and don't resist.
[cpg cn=true]



[OnName num="john_doe0303"]
"Please don't do that to him.
[cpg cn=true]



[OnName num="john_doe0417"]
I'm sure you're scared of him.
[cpg cn=true]



The two men, Hayashida and Nanashi, began to talk as they pleased, unaware that the person in question was here.
[cpg]



[OnName num="keisuke"]
"Gugu...gu......"
[cpg cn=true]



I was so angry that my whole body went rigid and I couldn't move a single finger.
[cpg]



;//移植前シーンカット


I was so angry that I couldn't move a finger.
[cpg]

I had certainly enjoyed the wakuteka videos for the past few days.
[cpg]

But I've reached my limit.
[cpg]

All of the women who distribute here are just like Hayashida.
[cpg]

They are all devils who sell sex and play with men.
[cpg]

I won't allow it.
[cpg]

If we let these people go unchecked, more and more men will end up like me.
[cpg]

So I must purge the women here.
[cpg]

I'll do it. ......
[cpg]

I'll eat them ......... rather than let them eat me.
[cpg]

[OnName num="KEI"]
I'm going to eat them.
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Mari194"]
[OnName num="Lian"]
Really?"
[cpg cn=true]



In Lian's World, where everyone had left the room, I spoke to Hayashida while holding in my nausea.
[cpg]

[OnName num="KEI"]
I was so nauseous that I spoke to Hayashida. I voted for you.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari195"]
[OnName num="Lian"]
Really?　I'm so happy!
[cpg cn=true]



[OnName num="KEI"]
By the way, I'm looking for a girl to set up a blind date with.
[cpg cn=true]



[FACE method="change_7" pos="3/7"]
[VOICE f="Mari196"]
[OnName num="Lian"]
"Well, I'm not sure.
[cpg cn=true]



The words I brought up didn't interest Hayashida much.
[cpg]

I'm not sure if I'm going to be able to get a good deal on the level of the team.
[cpg]

[OnName num="KEI"]
I'm confident in the level of the group," Hayashida said. I'm friends with Anjay's son.
[cpg cn=true]



[FACE method="change_5" pos="3/7"]
[VOICE f="Mari197"]
[OnName num="Lian"]
Anjay?　You mean Anjaina Jungri?　The Hollywood celebrity?
[cpg cn=true]



[OnName num="KEI"]
Yeah, yeah.
[cpg cn=true]



[FACE method="change_2" pos="3/7"]
[VOICE f="Mari198"]
[OnName num="Lian"]
No way!　Seriously!　You're my son, that means I get to go on a blind date with BlaJo?
[cpg cn=true]



[OnName num="KEI"]
"Yes, that's right."
[cpg cn=true]



To be honest, my knowledge was limited to the actress Anjaina, and I had no idea who her son was.
[cpg]

But sure enough, Hayashida got into the conversation and started to get excited on his own.
[cpg]


[FACE method="change_3" pos="3/7"]
[VOICE f="Mari199"]
[OnName num="Lian"]
I'll go!　I promise!　How many people do I need?
[cpg cn=true]



[OnName num="KEI"]
Five.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari200"]
[OnName num="Lian"]
"Leave it to me!　I'll get all the good ones!
[cpg cn=true]



Bullshit.
[cpg]

I'll get you the best girls!
[cpg]


[FACE method="change_7" pos="3/7"]
[VOICE f="Mari201"]
[OnName num="Lian"]
So, where are you from, Brajo?
[cpg cn=true]



Yaba...... didn't think that far ahead.
[cpg]



[OnName num="KEI"]
I'm not going to tell anyone. I can't reveal information about celebrities.
[cpg cn=true]



[FACE method="change_1" pos="3/7"]
[VOICE f="Mari202"]
[OnName num="Lian"]
I see.　That's right!
[cpg cn=true]



The idiot is easily fooled by ...... my improvisation.
[cpg]

[OnName num="KEI"]
If you decide to go out with Brajo, he'll tell you.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari203"]
[OnName num="Lian"]
'Ahhh!　Brajo and his boyfriend-girlfriend, that would be awesome!'
[cpg cn=true]



[OnName num="KEI"]
'Yes, that's right. Can you give me your direct address?
[cpg cn=true]



[VOICE f="Mari204"]
[OnName num="Lian"]
I'll send it to your e-mail address.　I'll send it to you on your e-mail address.
[cpg cn=true]



[OnName num="KEI"]
I'll send it to you at the mailbox and you'll get back to me. I just sent an e-mail to Brajo, and he replied right away.
[cpg cn=true]


[FACE method="change_5" pos="3/7"]
[VOICE f="Mari205"]
[OnName num="Lian"]
"Really?　What?
[cpg cn=true]



[OnName num="KEI"]
"On the day of the party, I'm going to pick up your number one in a limousine and she wants me to get her address.
[cpg cn=true]


[FACE method="change_5" pos="3/7"]
[VOICE f="Mari206"]
[OnName num="Lian"]
"Eeeeeeeee?　Oh no!　What?　What?
[cpg cn=true]



[OnName num="KEI"]
What's wrong?
[cpg cn=true]


I received a message from Rian-san.
[cpg cn=true]



When I opened the message, it contained not only a direct e-mail, but also a home phone number, address, and personal PR.
[cpg]

[OnName num="KEI"]
I'll talk to him and set up a meeting. I'll text you when I've made a decision.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari207"]
[OnName num="Lian"]
I'll text you when I've made a decision.　Oh, Kei-chan, don't tell him you met me on WAKUTEKA, okay?　I'm really going for brajo, so I don't want him to think I'm a bitch.
[cpg cn=true]



[OnName num="KEI"]
I don't want people to think I'm a bitch. I don't want people to think I'm a bitch.
[cpg cn=true]



What the fuck is that bitch talking about?
[cpg]

I logged out and beat the hell out of the bed mat as fast as I could.
[cpg]

No way Brajo would drop me for you!
[cpg]

......... Well, I don't know what kind of man he is.
[cpg]

But still, all I can say is that Hayashida is an idiot.
[cpg]

I've managed to get all of his personal information.
[cpg]

What I do with it is up to me. ......
[cpg]

When I think of this, what little rationality I have left asks my brain, "How can I use this information?
[cpg]

If I take revenge, I may lose my entire life.
[cpg]

Still, I'm not ......?
[cpg]

[OnName num="keisuke"]
.........aaaahhhh."
[cpg cn=true]



My head ached like a cracked bell.
[cpg]

Forget it.
[cpg]

No, no.
[cpg]

This is ...... revenge!
[cpg]



I hear a loud sound, shaking my skull with a gunshot.
[cpg]

This must be the sound of my heart.
[cpg]

It's a state similar to a warrior's tremor when making some serious decision.
[cpg]

I don't know where my heart is going, I can't even measure it myself. ......
[cpg]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
;//エフェクト

;//大分岐　へ
[jump target="*Abranch"]
;//=============================================================================
;//大分岐
*Abranch|チャンスを逃すな

;//qwe

;//・◆美咲フラグＡ、Ｂ、Ｃ　が三つ揃っている　→　美咲ルート　へ
;//*root1
[if exp={getFlagValue("Cha1flg_A") == 1}]
[if exp={getFlagValue("Cha1flg_B") == 1}]
[if exp={getFlagValue("Cha1flg_C") == 1}]
[jump target="*root1"]
[endif]
[endif]
[endif]
;//・▼麻里フラグＡ、Ｂ、Ｃ　が三つ揃っている　→　麻里ルート　へ
;//・▼麻里フラグＡ、Ｂ　が三つ揃っている　→　麻里ルート　へ
;//*root2_chak
[if exp={getFlagValue("Cha2flg_A") == 1}]
[if exp={getFlagValue("Cha2flg_B") == 1}]
;//[if exp={getFlagValue("Cha2flg_C") == 1}]
[jump target="*root2"]
;//[endif]
[endif]
[endif]
;//・▲瞳フラグＡ、Ｂ、Ｃ、Ｄ　が四つ揃っている　→　瞳ルート　へ
;//*root3
[if exp={getFlagValue("Cha3flg_A") == 1}]
[if exp={getFlagValue("Cha3flg_B") == 1}]
[if exp={getFlagValue("Cha3flg_C") == 1}]
[if exp={getFlagValue("Cha3flg_D") == 1}]
[jump target="*root3"]
[endif]
[endif]
[endif]
[endif]

;//・女のフラグが揃わず、★悪　の数字が　★凶　より多い　→　師匠ルート　へ
;//*root5
[if exp={getFlagValue("Bad_flg") == 0}]
[jump target="*root5"]
[endif]
[if exp={getFlagValue("Bad_flg") == 1}]
[jump target="*root5"]
[endif]
[if exp={getFlagValue("Bad_flg") == 2}]
[if exp={getFlagValue("Evelflg") == 3}]
[jump target="*root5"]
[endif]
[endif]

;//・女のフラグが揃わず　★凶　の数字が　★悪　より多い　→　凶行ルート　へ
;//*root6
[if exp={getFlagValue("Evelflg") == 0}]
[jump target="*root6"]
[endif]
[if exp={getFlagValue("Evelflg") == 1}]
[jump target="*root6"]
[endif]
[if exp={getFlagValue("Evelflg") == 2}]
[if exp={getFlagValue("Bad_flg") == 3}]
[jump target="*root6"]
[endif]
[endif]

;//どこでもない場合
;//*root4
[jump target="*root5"]

[jump target="*root4"]


*root1|
;//美咲
[jump storage="ep004.ks" target="*start"]
*root2|
;//麻里
[jump storage="ep005.ks" target="*start"]
*root3|
;//瞳
[jump storage="ep006.ks" target="*start"]
*root5|
;//師匠
[jump storage="ep007.ks" target="*start"]
*root6|
;//凶行
[jump storage="ep008.ks" target="*start"]

*root4|
;//病み
[jump storage="epbad.ks" target="*start"]

