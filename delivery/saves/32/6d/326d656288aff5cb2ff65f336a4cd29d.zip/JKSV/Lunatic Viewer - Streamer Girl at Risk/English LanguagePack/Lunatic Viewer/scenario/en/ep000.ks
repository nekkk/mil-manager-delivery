
*start


;//差分振りについて■■■■31,32,31の順になっているところがあるので注意■■■■
;//＜牝イキ生放送＞
;//『』はチャット文なので音声は不要です。
;//啓介は普段スェット着用。回想などの学園シーンは男子も女子もブレザー
;//美咲や麻里は動画では私服。美咲の学校制服はセーラー。

;//ハンドルネーム一覧（同一キャラになります）
;//啓介＝ケイ
;//美咲＝ぇむ
;//麻里＝リアン
;//瞳　＝ＳＢ（Ｓ・バタフライ）


;#################################################
*Ep000|ようこそワクテカ動画へ！
;#################################################

[SCENE id=0]

[stflag Jump_flg = 1]

;//フラグ　初期化
[stflag Cha1flg_A = 0]
[stflag Cha1flg_B = 0]
[stflag Cha1flg_C = 0]

[stflag Cha2flg_A = 0]
[stflag Cha2flg_B = 0]
;//[stflag Cha2flg_C = 0]
[stflag Cha3flg_A = 0]
[stflag Cha3flg_B = 0]
[stflag Cha3flg_C = 0]
[stflag Cha3flg_D = 0]

[stflag Cha1flg_la = 0]
[stflag Cha2flg_la = 0]
[stflag Cha3flg_la = 0]

[stflag Cha1flg_lb = 0]
[stflag Cha2flg_lb = 0]
[stflag Cha3flg_lb = 0]
[stflag Cha1flg_lc = 0]

[stflag Evelflg = 3]
[stflag Bad_flg = 3]



;//[SCENE id=1]
;//[SCENE id=2]
;//[SCENE id=3]
;//[SCENE id=4]
;//[SCENE id=5]
;//[SCENE id=6]
;//[SCENE id=7]
;//[SCENE id=8]
;//[SCENE id=9]
;//[SCENE id=10]
;//[SCENE id=11]
;//[SCENE id=12]
;//[SCENE id=13]

;//[jump target="*test"]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公（啓介）の部屋』

;//カーテンが閉め切られ薄暗く、パソコンのモニター明かりだけ

[SE f="se025"]
;//【ＳＥ】断続的なタイピング



Sinitai...
[cpg]

How to die...
[cpg]

The easy way to kill yourself...
[cpg]

I can't tell you how many times I've typed these words.
[cpg]

At the bottom of the search page, there is a line of text that says, "You accessed this site on XXXX.
[cpg]

But...I have yet to find a satisfactory answer.
[cpg]

My name is Keisuke Oshida.
[cpg]

My status is a student, but I'm not attending school at the moment.
[cpg]

I know in my head that I have to go to my school, Higashino Gakuin, but in the morning I get nausea, headache, stomachache, shaking, and other bad symptoms, so I have been living only in this room for half a year now.
[cpg]

Can it be said that I am alive?
[cpg]

A gobbledegook of wasted food.
[cpg]

I am wasting the tuition money my parents paid for me, wasting oxygen and food that I have no productivity, and wasting water and electricity that I don't even pay for myself.
[cpg]

I don't deserve to live like this.
[cpg]

So, it's time for me to get back to my student life.
[cpg]

I have to.
[cpg]

Starting tomorrow. Tomorrow, I'm sure.
[cpg]

Everyday before I go to bed, I make up my mind to do so, only to betray myself in the morning.
[cpg]

I can't stand it anymore...
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_12_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



Isn't that gross?"
[cpg]

The scene and those words flash back to me whenever I let my guard down.
[cpg]

That one word was the catalyst for everything.
[cpg]

I had a clear file on my desk in the classroom.
[cpg]

A girl in my class said that just because it had a cartoon character printed on it.
[cpg]

Because the woman who said it was a charismatic and outspoken person, many of my classmates made fun of me in sympathy with her.
[cpg]

The behavior turned from light mockery to cursing, and finally to severe bullying.
[cpg]

It eventually became a severe form of bullying, and even reached the level of a criminal act called "bullying.
[cpg]

Finally, I was stripped naked and had embarrassing pictures taken of me, which were then spread all over the Internet.
[cpg]

The words "disgusting," "too gross," "ugh," and "creepy geek" kept coming from morning to night to my picture, which she kindly put in my eyes, and she went to the trouble of sending me a summary of them.
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

In the end, that was the final blow, and I stopped going to school.
[cpg]

I didn't tell my teachers, my parents, or the police.
[cpg]

There was no way I could tell them.
[cpg]

If I did, even adults would see my embarrassing photo.
[cpg]

If it became a news story, a lot of strangers would search the Internet for that picture.
[cpg]

In this society, once something is on the Internet, it can never be recovered.
[cpg]

Even I, a weak-minded person, know that.
[cpg]

In other words, I have no choice but to stay shut up like this.
[cpg]

My parents want me to go to the hospital.
[cpg]

But if I go to the hospital, they will ask me how I came to be like this, and since I can't tell them that, there is nothing I can do.
[cpg]

At the very least, I should think about ending my life as soon as possible so that I don't become a burden.
[cpg]

[SE f="se025"]
;//【ＳＥ】タイプ

How can I die?
[cpg]

I typed this into a suicide site again.
[cpg]

Then, a person whose name and face I don't know replied to me again today.
[cpg]


Why do you want to die so badly?
[cpg]

[SE f="se025"]
;//【ＳＥ】タイプ

I really want to die.
[cpg]

[OnName num="keisuke"]
Don't ask me why..."
[cpg cn=true]



I muttered quietly in my mouth.
[cpg]


I said, "Well, well, well, cheer up and watch a video or something."
[cpg]
[OnName num="keisuke"]
I don't even want to go to a video site..."
[cpg cn=true]



What if my image comes up?
[cpg]

Even if no one else notices, I myself would notice.
[cpg]

If that happened, I would probably go crazy.
[cpg]

[SE f="se025"]
;//【ＳＥ】タイプ

I don't want to see any videos or pictures.
[cpg]

"What about live broadcasts?"
[cpg]

[OnName num="keisuke"]
"Live broadcast?"
[cpg cn=true]



I had no idea what it was, so I asked the person who sent me the message.
[cpg]

I asked the person who sent me the message.
[cpg]

The website allows amateur women to freely broadcast live and anyone can watch the video for free.
[cpg]

Well, I guess I won't have to be afraid of my own image then.
[cpg]

I immediately decided to visit the URL I had been given.
[cpg]

After passing the preliminary age verification, I saw a list of distributors' handles and the names of their rooms or programs.
[cpg]


;//*test|ようこそワクテカ動画へ！

I clicked on one of the names at random, not knowing what was going on on the left or right.
[cpg]

[SE f="se024"]
;//【ＳＥ】ダブルクリック


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ぇむの部屋』
[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="3/7" time=800]

Then, a girl's pink-colored room appeared on my computer screen.
[cpg]

[OnName num="keisuke"]
Wow..."
[cpg cn=true]



In the middle of the screen is a girl with a beautiful face.
[cpg]

Is this room really this girl's room?
[cpg]

On the screen, the girl was speaking something, and a zlinch of text was being brought up in the chat box next to her.
[cpg]

As far as I could see, they were the words of the viewers watching this broadcast.
[cpg]
What did you have for lunch today, Emu-chan?
[cpg]

[VOICE f="Misaki001"]
[OnName num="eMU"]
'Well...my lunch consisted of fried eggs and fried chicken.
[cpg cn=true]


"Do you prefer fried eggs with salt or sugar?　Or do you prefer sugar?
[cpg]

[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki002"]
[OnName num="eMU"]
"I like it sweet."
[cpg cn=true]


"Me too, me too!
[cpg]
I like grated daikon!
[cpg]

It was a strange scene of conversation in writing and in flesh and blood.
[cpg]

At first glance, it seemed like a tedious process, but it seemed quite reassuring that this side did not have to expose its voice and face to this girl.
[cpg]


;//●ＣＧ（美咲登場）ev_01
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Misaki003"]
[OnName num="eMU"]
She said, "Huh?　Hey...are you okay?"
[cpg cn=true]



[OnName num="keisuke"]
Eh?"
[cpg cn=true]



A girl named "Emu" tilted her head and looked at me from inside the monitor.
[cpg]

For a moment, I had the illusion that she could see me, and I felt the discomfort of all the pores on my back opening up.
[cpg]

But it was nothing...
[cpg]

[VOICE f="Misaki004"]
[OnName num="eMU"]
'The one who just came in, sir. Are you still here?　You've been quiet for a long time, but I'm wondering if you're a lomophobe.　If possible, I'd like you to join me and the others for a nice chat..."
[cpg cn=true]



[VOICE f="Misaki005"]
[OnName num="eMU"]
But if you are shy, please take your time.
[cpg cn=true]



[OnName num="keisuke"]
「………………」
[cpg cn=true]



The only thing is that this girl also saw the automatic message that was displayed when she entered the room, "Nanashi 1 person entered the room.
[cpg]

But I felt healed by Emu-chan's cute voice, gentle tone of voice, and most importantly, her expression.
[cpg]
She said, "You are so kind, Emu-taso.
[cpg]
It wouldn't be a man if he didn't respond to this.
[cpg]

[OnName num="keisuke"]
".................."
[cpg cn=true]



Perhaps, but a message from men.
[cpg]

My fingers tap the keys without thinking.
[cpg]

Hello!
[cpg]

[VOICE f="Misaki006"]
[OnName num="eMU"]
'Hello ......!
[cpg cn=true]



[OnName num="keisuke"]
Ah ......"
[cpg cn=true]



How long had it been since I had exchanged greetings with someone?
[cpg]

I was so sick that I was greatly moved by that mere fact.
[cpg]

[VOICE f="Misaki007"]
[OnName num="eMU"]
Is this your first time?
[cpg cn=true]



Yes.
[cpg]

[VOICE f="Misaki008"]
[OnName num="eMU"]
When you go to the registration page, you can choose your own nickname. If you like, tell me your name.
[cpg cn=true]



[OnName num="keisuke"]
"My name is ......."
[cpg cn=true]



My real name is not good. What should I do?
[cpg]


What should I do?
[cpg cn=true]



[VOICE f="Misaki009"]
[OnName num="eMU"]
Kay!　Kay-kun?　Which one should I call you?"
[cpg cn=true]



She smiled and tilted her head in a small gesture.
[cpg]

It was as innocent as an angel.
[cpg]


I was like a little angel.
[cpg cn=true]


;**【ＣＧ】 ev_01_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="Misaki010"]
[OnName num="eMU"]
Yes, I'll be happy to have you on the air. I hope my broadcast will cheer you up. Kay-kun.
[cpg cn=true]



[OnName num="keisuke"]
'......!'
[cpg cn=true]



At that moment, a light shone on my life.
[cpg]

;//オープニング映像
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公（啓介）の部屋』




[SE f="se025"]
;//【ＳＥ】タイピング

Since then, I have been watching the live broadcast every day.
[cpg]

By the way, the name of the site itself is "Wakuteka Video," a system that allows anyone to anonymously enter and chat in an "open room" that the distributor opens at will.
[cpg]

Viewers can speak by sending text, but trolls can be blocked by the distributor, so basically anyone who doesn't behave in a manner that is not respectful is rapidly eliminated.
[cpg]

That's another thing I liked about it.
[cpg]

Anyone who speaks out of turn or makes offensive remarks can just disappear from the world.
[cpg]

Also, it seems that the distributors have a "secret room" to which only viewers who have been invited by the distributor and given a pass code can pay to enter.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_ya"]
[WAIT time=100]
;//【ＢＧ】『ぇむの部屋』
[FG f="CHA01_p5_02_a.ui" method="change_2"  pos="3/7" time=800]
[VOICE f="Misaki011"]
[OnName num="eMU"]
'Good to see you all here today.
[cpg cn=true]


Me too, me too!
[cpg]
Me too!
[cpg]

[OnName num="KEI"]
Me too.
[cpg cn=true]



[VOICE f="Misaki012"]
[OnName num="eMU"]
'Well... bear, Mr. Yami Nabe Inquisitor, Mr. Oha-san, Mr. Oak, and Mr. Kay. Thank you for everything.
[cpg cn=true]



Whenever you start chatting or whenever someone comes in, Emu-chan always greets you by your nickname.
[cpg]

That makes me unbearably happy.
[cpg]

I mocked myself for how hungry I was for people, but what makes me happy is that it makes me happy.
[cpg]

[OnName num="yaminabebugyo"]
"You don't open secret?
[cpg cn=true]



When one of them suddenly asked such a question, Emu-chan laughed as if she was a little troubled.
[cpg]

She said she wasn't thinking about it right now.
[cpg]
[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki013"]
[OnName num="eMU"]
She said, "I'm a little embarrassed after all,...... but I might think about it when I get to know you guys better,......."
[cpg cn=true]



[OnName num="kumachan"]
Seriously?"
[cpg cn=true]



[OnName num="aaa"]
'It's a beautiful thing to be good friends!'
[cpg cn=true]



[OnName num="oac"]
'Minnanakayoku!!!'
[cpg cn=true]



[OnName num="keisuke"]
Oh...oh...?"
[cpg cn=true]



The chat room was filled with characters that were so excited all at once that I didn't have time to write anything down, even though we were a small group.
[cpg]

[OnName num="kumachan"]
I bought a cup of tea that you recommended!　It's really delicious!
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki014"]
[OnName num="eMU"]
I'm glad you tried it. I'm glad it suits your taste.
[cpg cn=true]



[OnName num="KEI"]
"Is this tea black tea?　Do you like tea?
[cpg cn=true]



[VOICE f="Misaki015"]
[OnName num="eMU"]
"Oh, yes. Yes, I do.
[cpg cn=true]



[OnName num="oac"]
You said before that you like scones with your tea, so I baked my own scones.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki016"]
[OnName num="eMU"]
I baked my own scones.　That's amazing!
[cpg cn=true]



[OnName num="aaa"]
That's amazing.
[cpg cn=true]



[OnName num="yaminabebugyo"]
"That's too good to be true."
[cpg cn=true]



[OnName num="oac"]
"Ffffffff."
[cpg cn=true]



[OnName num="KEI"]
"What's a scone?"
[cpg cn=true]



[OnName num="oac"]
"What's a scone?"
[cpg cn=true]



[OnName num="aaa"]
Oops.
[cpg cn=true]



[OnName num="yaminabebugyo"]
"ggrks."
[cpg cn=true]



[OnName num="keisuke"]
"........."
[cpg cn=true]



Of course, as a newcomer, I had far less information about her than the regulars, and our conversation didn't go very well.
[cpg]

I was a little sad about that.
[cpg]

[OnName num="siren"]
I was a little sad to hear that.
[cpg cn=true]



[OnName num="keisuke"]
Hmm...?"
[cpg cn=true]



At that moment, I noticed a person named Siren, who was addressing me by name in the chat section.
[cpg]

I wondered how long this person had been around.
[cpg]

I don't think Emu-chan had greeted me either...
[cpg]

[OnName num="KEI"]
'What is it?'
[cpg cn=true]



[OnName num="siren"]
'Can we talk in the chat room for a minute?
[cpg cn=true]



[OnName num="KEI"]
What? Why?
[cpg cn=true]



[OnName num="siren"]
"Well, well, well, I'll tell you something good.
[cpg cn=true]



[OnName num="KEI"]
Huh?
[cpg cn=true]



For some reason, the siren invited me to a free chat space called the chat room.
[cpg]

I thought it was suspicious, but I decided to go for a little while to see if they would do anything to me on the Internet.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_7.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『雑談ルーム』

[OnName num="siren"]
I decided to go for a little chat.
[cpg cn=true]



[OnName num="KEI"]
『はあ』
[cpg cn=true]



[OnName num="siren"]
The regulars are trying to get the girls to hold their own secret show, and they're trying to get the distributors' attention in every way possible, so you'll make enemies if you talk too much.
[cpg cn=true]



[OnName num="KEI"]
I see...'
[cpg cn=true]



In other words, this guy is blaming me for my bad interjection earlier.
[cpg]

[OnName num="KEI"]
'I'm sorry.
[cpg cn=true]



[OnName num="siren"]
'So, you can read the distributor's profile by clicking on the part where the room name is displayed, so you should check it out.
[cpg cn=true]



[OnName num="KEI"]
"Oh, I didn't know that.
[cpg cn=true]



[OnName num="siren"]
I didn't know that." "Also, you should check out not only Emu-chan's room, but also other distributors' rooms. I think you can meet girls who have the same interests as you and girls who can show you a new world.
[cpg cn=true]



[OnName num="KEI"]
'But you don't know much yet, and it's hard to read everyone's profile, isn't it?
[cpg cn=true]



[OnName num="siren"]
I think so. Recently, the rooms called 'Lian's World' and 'H Castle' are gaining popularity. The former is delivered by Rian-chan, an active schoolgirl, and the latter is delivered by a dominatrix named S Butterfly-sama.
[cpg cn=true]



[OnName num="KEI"]
Sounds amazing.
[cpg cn=true]



[OnName num="siren"]
But it doesn't mean that my face or personal information will be leaked, so feel free to enter anywhere. It's just like watching TV.
[cpg cn=true]



[OnName num="KEI"]
I see. I see. It's okay to be lighthearted...' 'Also, here's my advice.
[cpg cn=true]



[OnName num="siren"]
And here's my advice. The distributors are real girls, and they can be in a good mood or a bad mood depending on what you say to them. They don't want to talk to people they don't like.
[cpg cn=true]



[OnName num="KEI"]
What service?
[cpg cn=true]



[OnName num="siren"]
You know what they do in the secret room?　Only those whom the girls trust are allowed in that locked room. So they are vulnerable and open to you.
[cpg cn=true]



[OnName num="KEI"]
Body and soul?　That's..." "Body and soul?
[cpg cn=true]



The girls are only allowed to enter the room if they are trusted.
[cpg]

[OnName num="siren"]
I think it's just as you'd imagine. It's the kind of thing any man would want to see... you know?
[cpg cn=true]



[OnName num="KEI"]
'Have you ever seen anything like that, Mr. Siren?
[cpg cn=true]



[OnName num="siren"]
'I've been here a long time. I've been here a long time.
[cpg cn=true]



[OnName num="KEI"]
"But won't someone find out about it?
[cpg cn=true]



[OnName num="siren"]
You mean your family?　I mean, do you erase your own history or something?
[cpg cn=true]



[OnName num="KEI"]
No, I mean to the public...
[cpg cn=true]



[OnName num="siren"]
No, I mean, unless the police confiscate your computer, you should be fine. Are you afraid of that?
[cpg cn=true]



[OnName num="KEI"]
No, I'm not.
[cpg cn=true]



[OnName num="siren"]
Then you don't have to worry about it!
[cpg cn=true]



[OnName num="keisuke"]
I see. ......
[cpg cn=true]



Since the incident, I have become paranoid and worried about every little thing.
[cpg]

But I was a little relieved when a siren who seemed to be a regular told me once and for all, "Why are you being so nice to me?
[cpg]

[OnName num="KEI"]
Why are you being so nice to me?
[cpg cn=true]



I asked, and after a pause, she typed, "Because this is my playground.
[cpg]

[OnName num="siren"]
'Because this is my playground and I want everyone to have fun.
[cpg cn=true]



[OnName num="KEI"]
'Thank you. Please continue to teach me things!
[cpg cn=true]



[OnName num="siren"]
'If it's okay with me. Oh, by the way, if you register as a friend, you can message each other directly. Of course, you don't have to worry about being identified by that, so if you need anything, you can contact me anytime.
[cpg cn=true]



[OnName num="KEI"]
I understand.　I'm looking forward to working with you from now on, Master.
[cpg cn=true]



[OnName num="siren"]
Master?
[cpg cn=true]



I decided to call Mr. Siren "master" out of respect.
[cpg]

I knew that having someone who knows the subject well teach me would be easier than Googling it.
[cpg]

[OnName num="keisuke"]
I was told by my teacher, "Let's go to the room you told me about..." I said to myself.
[cpg cn=true]



I was a little unsure whether I should go to "Lian's World" or "H Castle," but my curiosity was piqued by the unknown presence of JoOusama, and I decided to take a peek at that one.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『Ｈキャッスル』

＞Kay-san entered the room.
[cpg]

When I entered that room, my entry was displayed.
[cpg]

However, no one, not even the distributor, mentioned it.
[cpg]

But that was not the problem.
[cpg]

What mattered was the room and the distributor itself.
[cpg]

[OnName num="keisuke"]
This is ......."
[cpg cn=true]



The concrete walls surrounding the room appeared to shimmer in the candlelight.
[cpg]

[FG f="CHA03_p5_03_a.ui" method="change_1"  pos="3/7" time=800]
The woman in the middle of it, wearing a butterfly mask, was somehow wearing a white robe over her bondage fashion.
[cpg]

Bondage is fine for a queen, but why a white robe?
[cpg]

Could it be that she is a pervert?
[cpg]

[OnName num="deku"]
Butterfly-sama!　Please have mercy on me!
[cpg cn=true]



[OnName num="kugutsu"]
My Queen, have mercy!
[cpg cn=true]


;//●ＣＧ（瞳登場）ev_02
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Hitomi001"]
[OnName num="SB"]
"You noisy pigs. Will you shut up?
[cpg cn=true]



[OnName num="pig"]
Boo-boo!
[cpg cn=true]



[VOICE f="Hitomi002"]
[OnName num="SB"]
Who told you to squeal?
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】バシッ（棒鞭）

[OnName num="pig"]
Boo-heen!
[cpg cn=true]



[OnName num="keisuke"]
What the... ......
[cpg cn=true]



I was a bit put off by the bizarre exchange, but decided to read the distributor's profile.
[cpg]

Deliverer: S. Butterfly (a.k.a. SB)
[cpg]
I am looking for an obedient servant.
[cpg]

If you come into my castle, don't complain no matter what they do to you.
[cpg]
I only want someone who takes pleasure in pain.
[cpg]

[OnName num="keisuke"]
Yeah. ......
[cpg cn=true]



I'm not even sure if this can really be called a profile.
[cpg]

I mean, it doesn't say much about myself....
[cpg]

Stunned, I turned my gaze back to the video once more.
[cpg]

[OnName num="keisuke"]
But ...... might be great."
[cpg cn=true]



Looking closely, S. Butterfly's body is quite good-looking, not to mention flattering.
[cpg]

Her breasts were taut and swayed with every movement, just like the adult women you see in gravure or professional models.
[cpg]

The contrast between her black bondage fashion and her white skin, illuminated by a red candle, was a fantastic sight.
[cpg]

[OnName num="keisuke"]
I guess there are queens where there are queens..."
[cpg cn=true]



Except for the part hidden by the mask, the lines of her face are smart, and there is nothing strange about her.
[cpg]

In fact, her long, silky hair combined with her good looks suggest that she is a very beautiful woman.
[cpg]

[VOICE f="Hitomi003"]
[OnName num="SB"]
Look, more words!"
[cpg cn=true]



Butterfly's sharp proclamation came out of my headphones, and I involuntarily jumped.
[cpg]

I looked over at the chat room, where a group of men, all of whom appeared to be M-rated, were typing something.
[cpg]

[OnName num="kugutsu"]
I was surprised to see that the men who appeared to be M were all typing something along the lines of, "The happiness of seeing the face of Butterfly-sama is greater than anything!
[cpg cn=true]



[OnName num="pig"]
The beautiful Butterfly!　Your beautiful voice is all I need to live!
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】棒鞭数回

[OnName num="keisuke"]
"Ugh...!"
[cpg cn=true]



As Butterfly repeatedly accustoms herself to the stick whip, the chat section turns into a festival.
[cpg]

[OnName num="pig"]
'Buhhhhiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii!
[cpg cn=true]



[OnName num="deku"]
'Oh, more!　More please, JoOusama!
[cpg cn=true]



[VOICE f="sHitomi001"]
[OnName num="SB"]
'Is this really that good!
[cpg cn=true]



[OnName num="keisuke"]
The Deep World ......
[cpg cn=true]



This was the first time I had ever seen anything like this in the world.
[cpg]

I was just stunned and could only stare at Butterfly's swaying breasts.
[cpg]

But ......
[cpg]

[VOICE f="Hitomi005"]
[OnName num="SB"]
I'm not sure what I'm supposed to be doing here.　What are you doing here?　Kay."
[cpg cn=true]



[OnName num="keisuke"]
Whoa!"
[cpg cn=true]



I was surprised to the point of jumping when I was suddenly called by name.
[cpg]

No wonder it was displayed when I entered the room, but I was surprised that JoOusama on this screen recognized it.
[cpg]

[VOICE f="Hitomi006"]
[OnName num="SB"]
She said, "Are you listening to me?　Answer me quickly.
[cpg cn=true]



[OnName num="keisuke"]
'Well, um...'
[cpg cn=true]



[OnName num="KEI"]
I'm Kay. My name is Kay.
[cpg cn=true]



[VOICE f="Hitomi007"]
[OnName num="SB"]
I know who you are. You're a stupid slave.
[cpg cn=true]



[OnName num="keisuke"]
"Uh..."
[cpg cn=true]



I was flustered and typed frantically, trying to make conversation.
[cpg]

[OnName num="KEI"]
'You're so pretty, Mistress.
[cpg cn=true]



[VOICE f="Hitomi008"]
[OnName num="SB"]
...... is boring.
[cpg cn=true]



[OnName num="keisuke"]
"What ......?"
[cpg cn=true]


[OnName num="pig"]
'This piggy has fantasies of being abused by Butterfly-sama even on the train!
[cpg cn=true]


After that, Butterfly never spoke to me again...
[cpg]

[OnName num="keisuke"]
Damn it... ......
[cpg cn=true]



I don't think I have any M-ness in me, but it was very frustrating.
[cpg]

I had no intention to be liked by the butterfly, nor did I like this room, so why should I feel so defeated...?
[cpg]

I left H Castle in a huff, and decided to check out the profile of the owner of "Lian's World", the other place that was recommended to me.
[cpg]

;//以降♥をハートの記号に変換してください
Distributor: Liane[r]
Birthday: Everyday ♥[r]
Hobby: Shopping & Makeup
[cpg]
Favorite thing: Sweets[r]
Favorite type: People who like Leanne ♥[r]
[cpg]
PR: Hallo Hallo♥ Welcome to Leanne's world![r]
Lian is an active gal. If you are interested in me, please feel free to come and visit me.
[cpg]
I'll show you something nice to you.
[cpg]
[OnName num="keisuke"]
In contrast, this one is a bit lighter..."
[cpg cn=true]



After reading the profile full of hearts, I decided to take a peek at this room, not to cleanse my palate.
[cpg]

But as I recall, that was the beginning of my mistake. ......
[cpg]

;//単色画面が表示され、そこにメッセージが
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[OnName num="keisuke"]
What's going on?　That's weird. I don't see anything..."
[cpg cn=true]



I entered the room, but there was nothing on the screen.
[cpg]

Upon closer inspection, only the words of the message were displayed.
[cpg]

'Secret only. Please come after making a deposit with the passcode 'rian_love'.
[cpg]

[OnName num="keisuke"]
What? Secret?　Out of the blue?"
[cpg cn=true]



Isn't it meaningless to have a passcode displayed so blatantly...?
[cpg]

But I was excited to have a chance to enter the secret room for the first time.
[cpg]

So, without thinking, I went to the Help button and looked up "Secret.
[cpg]

＜To viewers using the Secret Room
[cpg]
This room is only available to those who have received a password from the distributor and have deposited the amount of money set by the distributor.
[cpg]

The amount of money is left to the discretion of the distributor, so we do not recommend that you deposit if you feel uneasy about paying a large amount.
[cpg]

We do not recommend that you deposit if you are not comfortable paying a large amount of money.
[cpg]

For more information, please read the following terms and conditions and visit ......
[cpg]

[OnName num="keisuke"]
「ふむふむ……」
[cpg cn=true]



We accept payment by credit card only, so please fill out the form below and click on the "Credit Card Only ?
[cpg]

[OnName num="keisuke"]
"Credit card only ......?"
[cpg cn=true]



I don't have a credit card myself, but when I became a shut-in, my parents entered my credit card information so that I could buy music and games on the Internet to relieve myself.
[cpg]

I made a note of that data, so if I put it in here, I can get it from ......
[cpg]

Wait, if I use it here, won't the debit reveal it...?
[cpg]

But then I read the help page again, and it said that the debit would be made under the name of a company that could be anywhere.
[cpg]

This way, I don't have to worry about being thought of as a shady site.
[cpg]

Then, I had to ask myself how much it would cost...
[cpg]

[OnName num="keisuke"]
"Oh, a thousand yen?"
[cpg cn=true]



I was not sure what I was going to be shown, but I thought the price was cheap, and it wiped away all my worries, so I clicked on the button without hesitation.
[cpg]

すると…
[cpg]

Welcome to Liane's World Secret Room!
[cpg]

was displayed with a flourish, and I was able to enter.
[cpg]

＞ケイさんが入室されました
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『リアンズワールド』　


;//●ＣＧ（麻里登場）ev_03
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="Mari001"]
[OnName num="Lian"]
"Yoo-hoo Kay-chan, halo-halo ♥"
[cpg cn=true]



[OnName num="keisuke"]
"E......?
[cpg cn=true]



I was shocked and trembled as soon as I saw the image.
[cpg]

[VOICE f="Mari002"]
[OnName num="Lian"]
I was shocked and shook all over as soon as I saw the video.　It's nice to meet you...I'm Liane..."
[cpg cn=true]



[OnName num="keisuke"]
What...what...is.........?
[cpg cn=true]



[VOICE f="Mari003"]
[OnName num="Lian"]
"Oh, no?　Is it connected?　Is Kay there?
[cpg cn=true]



[OnName num="keisuke"]
"What's with you, Rian, you bitch?
[cpg cn=true]



[SE f="se020"]
;//【ＳＥ】モニターを乱暴に掴む（ガシッ）
[WAIT time=1000]

The face of the "Rian" distributor is Mari Hayashida, a classmate of mine whom I will never forget.
[cpg]

It was that woman who called me a creep and took the initiative in bullying me.
[cpg]

;//フラッシュバック回想

;//教室
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin" layer=20 pos="4/7"]
[BG f="b_11_2.ui" time=1000]
[WAIT time=1000]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mari004"]
[OnName num="mari"]
She said, "Gross, you're so dirty, I'm going to wash you."
[cpg cn=true]



[SE f="se019"]
;//【ＳＥ】ホースで水をかける

[OnName num="keisuke"]
"No, don't..."
[cpg cn=true]



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mari005"]
[OnName num="mari"]
What?　If you want me to stop, you should take a bath every day. Don't you help me take off your clothes?
[cpg cn=true]



[OnName num="male_student"]
"Okay, I'll do it. Come on, get your clothes off.
[cpg cn=true]



[OnName num="female_student"]
Come on, come on, don't be shy.
[cpg cn=true]



[OnName num="keisuke"]
Stop, stop, stop.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Mari006"]
[OnName num="mari"]
Gross.
[cpg cn=true]



[OnName num="keisuke"]
Ugh...
[cpg cn=true]



[OnName num="female_student"]
Oh, no, she's crying. That's really gross.
[cpg cn=true]



[FACE method="change_3" pos="2/3"]
[VOICE f="Mari007"]
[OnName num="mari"]
Come on, come on, say "banzai. Banzai.
[cpg cn=true]



[OnName num="male_student"]
"Hey, you guys, spread your legs and hold them down. There you go. Banzai.
[cpg cn=true]



[OnName num="keisuke"]
Uh... ah!
[cpg cn=true]



[OnName num="female_student"]
Ha-ha-ha!　What was that?
[cpg cn=true]



[FACE method="change_2" pos="2/3"]
[VOICE f="sMari001"]
[OnName num="mari"]
That's so funny!
[cpg cn=true]



[SE f="se022"]
;//【ＳＥ】カメラのシャッター

[OnName num="keisuke"]
Stop it...!　Don't film me!
[cpg cn=true]



[FACE method="change_7" pos="2/3"]
[VOICE f="sMari002"]
[OnName num="mari"]
What?　I went to the trouble of using the space on my phone for you, and you can't complain. I'm going to send your picture to the whole class as punishment.
[cpg cn=true]



[OnName num="keisuke"]
"Aaaaah!　Please don't do that, please!
[cpg cn=true]



[FACE method="change_2" pos="2/3"]
[VOICE f="Mari010"]
[OnName num="mari"]
"Yes, group transmission complete... I'm a woman who can get the job done."
[cpg cn=true]



[OnName num="keisuke"]
Aaaaahhhhhhh!
[cpg cn=true]



;//回想明け

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1]
;***************************************
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


[OnName num="keisuke"]
"Oh, fuck, fuck, fuck, fuck, fuck, fuck!"
[cpg cn=true]


[VOICE f="Mari011"]
[OnName num="mari"]
"Yes, I'm here to serve everyone. Flicker..."
[cpg cn=true]



[OnName num="keisuke"]
?"
[cpg cn=true]



On the screen, Mari Hayashida rolled up the skirt of her school uniform to show a glimpse of her thighs.
[cpg]

In the chat box, the words of delight danced in the air.
[cpg]
;//qwe
[OnName num="john_doe0126"]
"Ooooooooooooo!
[cpg cn=true]



[OnName num="john_doe1113"]
I can almost see her pants!
[cpg cn=true]



[OnName num="john_doe0719"]
Look more!
[cpg cn=true]


[VOICE f="sMari003"]
[OnName num="mari"]
I don't know what to do.
[cpg cn=true]



Hayashida, in a fit of excitement, shows his thighs longer than before.
[cpg]

The face of the guy seemed to be slightly uplifted and excited.
[cpg]

But what the hell does that mean?
[cpg]

I had paid a thousand yen for this devilish woman.
[cpg]

How humiliating could this be?
[cpg]

The woman who spread my lasciviousness all over the Internet, showing her legs to an unspecified number of people in a place like this. ......
[cpg]

[OnName num="keisuke"]
Yes, ......."
[cpg cn=true]



A black vengeance wells up inside me.
[cpg]

Can't I expose this video to the class and the world?
[cpg]

A charismatic girl at the top of the class caste showing off her underwear on an erotic website by herself is the best scandal of all.
[cpg]

I'm sure she can save the video somehow.
[cpg]

But...
[cpg]

[OnName num="keisuke"]
How do I do it?
[cpg cn=true]



I don't know much about computers, so I don't even know how to do that.
[cpg]

I tried searching the Internet to find out, but to my dismay, I was too stupid to even understand.
[cpg]

[OnName num="keisuke"]
Damn...!"
[cpg cn=true]



At that moment, a good idea came to my mind and I opened the message box.
[cpg]

I typed a question in the body of the message, sent it, and shortly after received a reply.
[cpg]

[OnName num="siren"]
Come to the chat room.
[cpg cn=true]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_7.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『雑談ルーム』

[OnName num="siren"]
What a question out of the blue..." "I don't know how to save it.
[cpg cn=true]



[OnName num="KEI"]
"Is there any way to save it?"
[cpg cn=true]



[OnName num="siren"]
I don't know if I can tell you that..."
[cpg cn=true]



The master saw my message and was reluctant to provide the means.
[cpg]

[OnName num="siren"]
He was reluctant to provide a means of doing so.　Is it a personal hobby?　Or is it something you want to do?
[cpg cn=true]



[OnName num="KEI"]
'It's a personal thing.
[cpg cn=true]



[OnName num="siren"]
'I'm sorry, but I don't believe you.'
[cpg cn=true]



[OnName num="keisuke"]
".................."
[cpg cn=true]



I felt as if he could see right through me, and I was repeatedly shaking my head in frustration in front of the computer.
[cpg]

[OnName num="siren"]
'What's going on?　'The secret room is a tacit agreement, and if the video leaks, how do I know it won't lead to the social exposure you've been fearing?
[cpg cn=true]



[OnName num="siren"]
'And you want to save it?　You can watch those videos on any number of other sites.
[cpg cn=true]



[OnName num="KEI"]
I really want to get my hands on Hayashida's videos.
[cpg cn=true]



[OnName num="siren"]
"Hayashida?"
[cpg cn=true]



[OnName num="keisuke"]
Oh, no!
[cpg cn=true]



I was so excited that I typed in the woman's real name.
[cpg]

I couldn't take back what I had done.
[cpg]

[OnName num="KEI"]
I was so excited that I typed in the woman's real name.
[cpg cn=true]



I had to confess to my master what had happened to me.
[cpg]

It was a long story, but my mentor listened to me, sometimes giving me a sympathetic ear, as if he were in real life.
[cpg]

And then...
[cpg]

[OnName num="siren"]
I was in a lot of pain.
[cpg cn=true]



He threw words of comfort at me.
[cpg]

[OnName num="KEI"]
Do you understand how I feel when I want to take revenge?
[cpg cn=true]



[OnName num="siren"]
I understand. But I still want to stop you.
[cpg cn=true]



[OnName num="KEI"]
Why?
[cpg cn=true]



[OnName num="siren"]
Wait a minute. I've just found this site, so it's not too late to have a little fun, right?　First of all, it's not a good idea to spread around your saved videos and pictures, even for revenge.
[cpg cn=true]



[OnName num="KEI"]
She was the first one to do that!
[cpg cn=true]



[OnName num="siren"]
She did it first! But whatever legitimacy you have for your own revenge is irrelevant to me and other viewers. We will all suffer if this place is shut down because of your crimes.
[cpg cn=true]



[OnName num="keisuke"]
"......""
[cpg cn=true]



I was so angry that I had no idea of the inconvenience to others.
[cpg]

I was so angry that I didn't even think about the damage it would do to others.
[cpg]

[OnName num="siren"]
'Just the other day, a stalker who identified the distributor on another distribution site assaulted him, and even that's going to be restricted for free.
[cpg cn=true]



[OnName num="siren"]
'If you want revenge, could you please keep the site out of it and only target the people you have a vendetta against?
[cpg cn=true]



[OnName num="KEI"]
"Okay, I'll give up on the ...... save and all that.
[cpg cn=true]



[OnName num="siren"]
You're kind of a nice guy, aren't you?
[cpg cn=true]



[OnName num="KEI"]
"What's that about?"
[cpg cn=true]



[OnName num="siren"]
I'm not sure what you're talking about, but if you really want to do what I just said, you can take a picture of the screen with your phone, right?　But you went to the trouble of asking me, and when I asked you to stop, you said you'd stop.
[cpg cn=true]



[OnName num="keisuke"]
Ah..."
[cpg cn=true]



I'm not sure if it's a good idea to take a picture with your phone or not.
[cpg]

The most important thing to remember is that the best way to get the most out of your phone is to use it.
[cpg]

[OnName num="KEI"]
I'm not so much naive as I am a fool. No wonder I get bullied...'
[cpg cn=true]



[OnName num="siren"]
No way!　No way. No one deserves to be bullied. Anyway, I'm grateful that you stopped to think about it.
[cpg cn=true]



[OnName num="KEI"]
『はあ』
[cpg cn=true]



I couldn't think of anything else to do, but I agreed.
[cpg]

I don't want to bring a third party into this, either.
[cpg]

[OnName num="siren"]
I'm sure you've been hurt and you've been thinking about it, but I'm sure your wounds will heal someday. At least have fun with the other girls and forget about it as soon as possible.
[cpg cn=true]



[OnName num="KEI"]
'I wish I could.
[cpg cn=true]



[OnName num="siren"]
'Okay, advice from the master!　To get close to the girls, you should gather information about their favorite topics on a regular basis.
[cpg cn=true]



[OnName num="siren"]
You can do this outside of the live broadcast, or you can visit places that you think the girl you are looking for might like. Good luck, my student Kay. Do not fall into the dark side.
[cpg cn=true]



[OnName num="KEI"]
I see. Thank you, Master.
[cpg cn=true]



I could feel from the text that he was trying to distract me, and I thanked him sincerely and fell in.
[cpg]

I regretted the thousand yen I had paid, but I didn't have the energy to look at Hayashida's hateful face.
[cpg]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
;//エフェクト

;//翌朝
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公（啓介）の部屋』(昼)
;//朝ここだけなので昼で良い

The next morning, I woke up and was distracted by the light leaking through the curtains.
[cpg]

[OnName num="keisuke"]
I thought to myself, "Is it outside .........?"
[cpg cn=true]



I hadn't been outside for half a year.
[cpg]

The only food and drink I had was what my parents bought for me.
[cpg]

I thought I would end up like this for the rest of my life, but yesterday, my mentor told me

I thought I would end up like this for the rest of my life.
[cpg]

I had never imagined that I would come up with such an idea.
[cpg]

I was surprised that I would come up with such an idea.
[cpg]

Until now, I had never wanted to leave this house because I had always been afraid of what would happen if I met someone who saw that image, or of being laughed at by someone pointing at me behind my back.
[cpg]

But I don't want to ...... stay here until I die.
[cpg]

I saw Hayashida's happy face yesterday......
[cpg]

I'm sure it's wrong for him to enjoy himself and for me to just suffer.
[cpg]

I thought so, and decided to first do as my mentor said and enjoy myself as much as I could on that site.
[cpg]

;//*test|ようこそワクテカ動画へ！

[OnName num="keisuke"]
So...what am I going to do today?
[cpg cn=true]



;//■選択肢（１日目昼）三択
[switch]
[case "Go online"]
	[swap]
	[jump target="*select01_1"]
[case "Go to the grocery store"]
	[swap]
	[jump target="*select01_2"]
[case "Go to a cafe"]
	[swap]
	[jump target="*select01_3"]
[endswitch]

1, go online;// (*evil +1)
2、Go to the general store;// (★MISAKI a acquired)
3, Go to the cafe;// (★Mari a obtained) (◆Eye Flag A obtained)



;//=============================================================================

;//１，ネットをする（★悪＋１）
*select01_1|Welcome to WAKUTEKA Video!

[stflag Bad_flg=-1]

[OnName num="keisuke"]
"I don't dare go outside yet. ......
[cpg cn=true]



I'm pathetic, but I felt my hands trembling, I decided to be mature and go online.
[cpg]

Come to think of it, what kind of case was the online stalking that my mentor was talking about?
[cpg]

I decided to send a message to my mentor.
[cpg]

He immediately responded and we moved to the chat room.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_7.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『雑談ルーム』

[OnName num="siren"]
He says, 'Hey, it's me. What do you want to know?'
[cpg cn=true]



[OnName num="KEI"]
Good morning, sir.
[cpg cn=true]



[OnName num="siren"]
'It's already noon.
[cpg cn=true]



[OnName num="KEI"]
'It's about the assault by the internet stalker you mentioned yesterday.
[cpg cn=true]



[OnName num="siren"]
Oh, that..."
[cpg cn=true]



The master then gave me a brief summary of the incident.
[cpg]

It seems that a man who became obsessed with a girl in a chat room somewhere collected personal information from her videos, tracked down her home, and coerced her into going out with him.
[cpg]

When the girl refused to go out with him, he reported the incident to the police, who instructed him to go back to her house.
[cpg]

[OnName num="siren"]
The culprit was caught, but it's really annoying when incidents like that happen, because this place gets marked.
[cpg cn=true]



[OnName num="KEI"]
That's right.
[cpg cn=true]



But how did he get the girl's personal information from the video?
[cpg]

I asked my mentor about it.
[cpg]

[OnName num="siren"]
Well, with a little knowledge, there are technical ways, such as using IP addresses, but this guy seemed to be more primitive.
[cpg cn=true]



[OnName num="KEI"]
"What do you mean by that?"
[cpg cn=true]



[OnName num="siren"]
"He recorded all the little things the girl said during the conversation, like what stores are in the neighborhood, what line she takes the train to school, and he derived it from there.
[cpg cn=true]



[OnName num="KEI"]
"Oh, that's not why..."
[cpg cn=true]



[OnName num="siren"]
He said, "Sticky people are scary, you know. They have their eyes on the wrong things.
[cpg cn=true]



[OnName num="siren"]
"If a video shows the inside of a girl's room, he can get some information from which direction the light is coming from, or even from a glimpse of the scenery outside the window.
[cpg cn=true]



[OnName num="KEI"]
It's like being a detective.
[cpg cn=true]



[OnName num="siren"]
If you have such a talent, why don't you get a job like that?
[cpg cn=true]



The master was weeded out, but I respected the criminal a little.
[cpg]

Even if you don't have any special skills, you can do such a thing just by being obsessed....
[cpg]

[OnName num="KEI"]
Thank you very much."
[cpg cn=true]



I thanked my mentor and logged out, and from then on I immersed myself in my normal surfing and gaming.
[cpg]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
;//エフェクト
[jump target="*select01_end"]

;//=============================================================================

;//２，外へ出る
*select01_2|ようこそワクテカ動画へ！

[stflag Cha1flg_la = 1]

[OnName num="keisuke"]
'Maybe I should go outside...'
[cpg cn=true]



If I keep shutting myself in forever, I'm really going to lose it.
[cpg]

I should rehabilitate myself here....
[cpg]

I decided to go out somewhere.
[cpg]

[OnName num="keisuke"]
Maybe I'll go to the grocery store..."
[cpg cn=true]



I left my house for the first time in half a year and headed for a general store on the street in front of the station with slow steps, puzzled by the brightness of the sun.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]

;//【ＢＧ】『雑貨屋』

The store itself was small, but I got the impression that it had a wide variety of products.
[cpg]

From daily necessities to toys of which I had no idea how to use, it was exactly like a general store.
[cpg]

There were only about three customers in the store, including me.
[cpg]

[OnName num="staff"]
I asked, "Are you looking for something?"
[cpg cn=true]



[OnName num="keisuke"]
"Uh...no, no..."
[cpg cn=true]



As I was about to reach for something I didn't understand on the shelf, a clerk approached me from the side, and I quickly pulled my hand away.
[cpg]

[OnName num="staff"]
Oh, that's rather popular right now," she said. It's very popular among girls who like handicrafts.
[cpg cn=true]



[OnName num="keisuke"]
What's this?
[cpg cn=true]



[OnName num="staff"]
It is called "Needfelt" or "wool felt." By pricking fluffy wool with a needle, you can make this kind of stuffed animal by yourself. This is a starter kit.
[cpg cn=true]



[OnName num="keisuke"]
"Really..."
[cpg cn=true]



Making a stuffed animal by oneself is a troublesome thing.
[cpg]

But the fact that it is so popular means that there must be a lot of people who don't think so.
[cpg]

I picked up the doll in front of me that was labeled as a sample.
[cpg]

A little shiny to the touch, is this a ...... cat?
[cpg]

[OnName num="staff"]
Isn't it amazing that they can take this shaggy wool and make it look like this?
[cpg cn=true]



[OnName num="keisuke"]
Huh..."
[cpg cn=true]



[OnName num="staff"]
It's easy to make, and the initial cost is less than 2,000 yen, so it seems to be an attractive hobby for girls who like kawaii things. Would you like one?
[cpg cn=true]



[OnName num="keisuke"]
"Oh...no, ......."
[cpg cn=true]



I looked at the starter kit for a moment, saw some pictures of lions and bears on it, and left the store.
[cpg]

It's been a while since I've had a real conversation with a stranger, and I'm exhausted from that alone.
[cpg]

I want to go back to .......
[cpg]

[jump target="*select01_end"]

;//=============================================================================
;//c,カフェ（▲瞳フラグA）（★麻里a）
*select01_3|ようこそワクテカ動画へ！
[stflag Cha3flg_A = 1]
[stflag Cha2flg_la = 1]

[OnName num="keisuke"]
Let's have some coffee..."
[cpg cn=true]



First of all, even if it's rehabilitation, I don't think I can walk around in a crowded place.
[cpg]

So I set myself the task of going to a cafe and having a cup of coffee.
[cpg]

I order directly from the waiter.
[cpg]

I felt that was the best I could do at the moment.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『カフェ』

;//瞳　の名前を　地味店員　にして下さい

[OnName num="keisuke"]
"Hands up...blend...hands up...blend..."
[cpg cn=true]



I sat in the corner and mumbled and repeated the image training.
[cpg]

But the place was packed with customers, as if it was a busy restaurant.
[cpg]

[OnName num="keisuke"]
"Uh...uh..."
[cpg cn=true]



Even though I know that no one is paying attention to me, I can't help but feel that everyone is glancing at me.
[cpg]

I can't help but think that if there are this many people here, some of them might have seen my embarrassing ...... image, and that fear just makes me turn my head down.
[cpg]

[OnName num="keisuke"]
'Blend...blend at ......'
[cpg cn=true]



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Hitomi009"]
[OnName num="sober_staff"]
On blend.........
[cpg cn=true]



[OnName num="keisuke"]
「！？」
[cpg cn=true]



I wondered when he had come by and blurted it out right next to me.
[cpg]

I looked up in surprise and saw a plain female clerk with glasses standing there holding a slip of paper.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Hitomi010"]
[OnName num="sober_staff"]
She said, "What else... can I get for you at ......?
[cpg cn=true]



[OnName num="keisuke"]
Uh...uh, ......."
[cpg cn=true]



At first, I thought she was imitating me, because she was talking so softly.
[cpg]

But I was wrong.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Hitomi011"]
[OnName num="sober_staff"]
I said, "Blend...is that right, ......?"
[cpg cn=true]



[OnName num="keisuke"]
Ah...ha, hai ......."
[cpg cn=true]



[free time=1000]
The shopkeeper bowed his head and went into the back of the room.
[cpg]

......... sober!
[cpg]

The most important thing to keep in mind is that the person who is in charge of the store is not the one who is in charge of the customer.
[cpg]

I don't know if I can say this, but I don't think she is the type of person who is suited for customer service.
[cpg]

I was strangely impressed that she was able to work so well.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Hitomi012"]
[OnName num="sober_staff"]
"...... sorry to keep you waiting."
[cpg cn=true]



[OnName num="keisuke"]
......!
[cpg cn=true]



I thought my heart would stop when he suddenly called out to me again, and a cup of blended coffee was placed on the table.
[cpg]

The cups were filled with steam and the aroma of goodness was rising from the cups.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Hitomi013"]
[OnName num="sober_staff"]
Please take your time...please.........."
[cpg cn=true]



[free time=1000]
As the unassuming waitress walks away, I slowly bring the cup to my mouth and send the coffee down my throat.
[cpg]

[OnName num="keisuke"]
Delicious ......."
[cpg cn=true]



It tastes different from the canned coffee or the instant coffee I drink at home.
[cpg]

I was glad to be out of the house, I could feel it a little.
[cpg]

I exhale loudly, and the delicious aroma of coffee escapes my nostrils.
[cpg]

Then, naturally, I overheard the conversations of the people around me.
[cpg]

[OnName num="skinny_woman"]
"Hey, have you eaten rolled ice cream yet?
[cpg cn=true]



[OnName num="fat_woman"]
I asked, "I haven't yet. Wanna go out sometime?
[cpg cn=true]



[OnName num="skinny_woman"]
I'll go next time. Where is that from?
[cpg cn=true]



[OnName num="fat_woman"]
Thailand, right?
[cpg cn=true]



What's Roll Ice ......?
[cpg]

I try to search on my phone from the conversation I overheard.
[cpg]

[OnName num="keisuke"]
"Hmmm.........."
[cpg cn=true]



It seemed to be a trendy sweet, and the information was readily available.
[cpg]

It was knowledge that I would never have had if I had stayed in my room, and I felt like I was getting something out of it.
[cpg]

Maybe it's a good thing I came to the cafe...
[cpg]

[jump target="*select01_end"]

;//=============================================================================

*select01_end|ようこそワクテカ動画へ！

;//ブラックアウト
;//エフェクト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公（啓介）の部屋』（１日目夜）

As night falls, I try to access WAKUTEKA VIDEO.
[cpg]

I've learned a little since then, and it seems that the rooms I've set as "favorites" are supposed to display "notices" here when they are opened or when the organizer enters contact information.
[cpg]

I can see the new information on my computer screen as well.
[cpg]
Emu's Room": Opens today at 20:00[r]
Liane's World": Opens today at 20:00[r]
H Castle": Opens today at 22:00
[cpg]

[OnName num="keisuke"]
「………………」
[cpg cn=true]


I registered "Emu's Room" because Emu is cute.
[cpg]
I registered "H Castle" because I was curious about the unknown.
[cpg]

And I registered the abominable Hayashida's "Lian's World" because I'm looking for an opportunity for ...... revenge.
[cpg]

As the master says, you should not peek into Hayashida's room if you want to have fun getting into it and forgetting about it.
[cpg]

I understand that very well.
[cpg]

But I can't get rid of my grudge so easily....
[cpg]

[OnName num="keisuke"]
What shall we do tonight...?"
[cpg cn=true]


;//qwe
;//■選択肢（１日目夜）３択
[switch]
[case "Emu's room"]
	[swap]
	[jump target="*day01_1"]
[case "Lian's World"]
	[swap]
	[jump target="*day01_2"]
[case "H Castle"]
	[swap]
	[jump target="*day01_3"]
[endswitch]

1, Emu's room;// (*MISAKI a) (Contents change depending on presence or absence of *MISAKIa)
2，Liane's World;// (*Mari a, contents change depending on presence or absence of Mari a)
3，H Castle;// (Contents change depending on presence or absence of ◆Pupil Flag A) (Contents change depending on presence or absence of ◆His pupil flag A)

;//=============================================================================

;//１，ぇむの部屋
*day01_1|ようこそワクテカ動画へ！
Come to think of it, I didn't check Emu's profile.
[cpg]

I decided to get some information about her before entering the room.
[cpg]
;//ぇむのプロフィール表示
Distributor: Emu[r]
Birthday: May 6[r]
Blood type: O
[cpg]
Hobbies: Internet, handicrafts, a little game[r]
Favorite color: pink[r]
Favorite animal: I like all animals!
[cpg]

PR: I'm really shy, but I do my best to chat in chat rooms. Come visit me if you like!
[cpg]
Hmmm, wonderful.
[cpg]

It exudes a human quality that can't be compared to Hayashida or SB.
[cpg]

[OnName num="keisuke"]
Well, let's go then. ......
[cpg cn=true]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ぇむの部屋』

＞Mr. Kay has entered the room.
[cpg]

Just at 20:00.
[cpg]

I entered "Emu's room" as soon as it opened.
[cpg]
[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="3/7" time=800]
[VOICE f="Misaki017"]
[OnName num="eMU"]
"Ah, Kay, good evening.
[cpg cn=true]



[OnName num="KEI"]
Good evening.
[cpg cn=true]



As soon as I entered, Emu-chan turned her smile to me and greeted me.
[cpg]

I was happy to see her cute expression.
[cpg]
[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki018"]
[OnName num="eMU"]
Kay-kun is the first one to greet me.
[cpg cn=true]



[OnName num="KEI"]
Yay!
[cpg cn=true]



チャットは良い。
[cpg]

It doesn't necessarily have to be cheerful, but if you put "! at the end of a word, you can create an energetic atmosphere.
[cpg]

[OnName num="aaa"]
"Hello, Emu-chan!
[cpg cn=true]



[OnName num="yaminabebugyo"]
I'm interrupting, that I am.
[cpg cn=true]



[OnName num="keisuke"]
「……………」
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
In the meantime, the regulars started to arrive one after another, and as usual, I couldn't say much.
[cpg]

But even if I don't talk, it's fun just to listen to the conversation, and seeing her on the screen soothes my soul.
[cpg]

Besides, I can see Emu-chan's real room ...... spreading out as a background.
[cpg]

It felt good to observe it.
[cpg]

[OnName num="keisuke"]
Let's take a better look at ......."
[cpg cn=true]




Hover over the point you want to see and pay attention....
[cpg]



;//■選択肢_夜_１日目_ぇむ

;//画面にカーソル表示　注目ポイントとメッセージ
;//※現時点で絵が分からないので、色や形など随時そちらでメッセージを足して結構です
[stflag mselecter11_cnt = 2]

*mselecter01|ようこそワクテカ動画へ！

[if exp={getFlagValue("mselecter11_cnt") == 0}]
[jump target="*1niend_em"]
[endif]

;//＠qwe



[switch]
[case "Emu's face"]
	[swap]
	[jump target="*Msel1_01"]
[case "Emu's breast"]
	[swap]
	[jump target="*Msel1_02"]
[case "Emu's head"]
	[swap]
	[jump target="*Msel1_03"]
[case "Window"]
	[swap]
	[jump target="*Msel1_04"]
[case "ベッド"]
	[swap]
	[jump target="*Msel1_05"]
[case "Stuffed animal"]
	[swap]
	[jump target="*Msel1_06"]
[case "A door."]
	[swap]
	[jump target="*Msel1_07"]
[endswitch]


1,Emu's face
2,Emu's chest
3,Emu's head
４,窓
５,ベッド
6,stuffed animal
7,door


;//==========================
;//ぇむの顔
*Msel1_01|ようこそワクテカ動画へ！

[stflag mselecter11_cnt=-1]

Emu-chan's face.
[cpg]

Her eyes are big and pale, and she is so cute that I would believe her even if she were said to be an idol somewhere.
[cpg]

I think she is a student, but I bet she is irresistible...
[cpg]

[jump target="*mselecter01"]

;//==========================

;//ぇむの胸
*Msel1_02|ようこそワクテカ動画へ！
[stflag mselecter11_cnt=-1]
Not to match her innocent face, she is quite no...quite big....
[cpg]

I don't get the feeling that she is intentionally exposing it, but you can't hide its flabbyness.
[cpg]

Emu-chan has ...... some pretty big tits!
[cpg]

[jump target="*mselecter01"]

;//==========================
;//ぇむの頭
*Msel1_03|ようこそワクテカ動画へ！
[stflag mselecter11_cnt=-1]

Beautiful hair.
[cpg]

Girls seem to have a hard time taking care of their hair.
[cpg]

[jump target="*mselecter01"]

;//==========================
;//窓
*Msel1_04|ようこそワクテカ動画へ！
[stflag mselecter11_cnt=-1]

It's nighttime, so you can't see anything outside.
[cpg]

I don't even know what floor I'm on.
[cpg]

[jump target="*mselecter01"]

;//==========================
;//ベッド
*Msel1_05|ようこそワクテカ動画へ！
[stflag mselecter11_cnt=-1]

It's a pretty bedspread, just like a girl.
[cpg]

The size of this bed is probably a single bed.
[cpg]

[jump target="*mselecter01"]

;//==========================
;//ぬいぐるみ（★美咲a　がない場合の内容）
*Msel1_06|ようこそワクテカ動画へ！

[if exp={getFlagValue("Cha1flg_la") == 1}]
[jump target="*misaki_la"]
[endif]

[stflag mselecter11_cnt=-1]
There are many stuffed animals of various sizes.
[cpg]


I wonder if they don't get sick of feeling like they are being watched...
[cpg]

[jump target="*mselecter01"]

;//==========================
;//ドア
*Msel1_07|ようこそワクテカ動画へ！
[stflag mselecter11_cnt=-1]
It doesn't look like a front door, so it must be the door to Emu-chan's private room.
[cpg]

How many other rooms are there?
[cpg]

[jump target="*mselecter01"]

;//==========================

;//★美咲aがない場合　２箇所クリック後→１日目夜ぇむ終了　へ進行
;//１日目夜ぇむ終了

*1niend_em|ようこそワクテカ動画へ！
[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="3/7" time=800]
[VOICE f="Misaki019"]
[OnName num="eMU"]
Kay-kun, are you still there?
[cpg cn=true]



[OnName num="keisuke"]
What...!
[cpg cn=true]



I was surprised to see Emu-chan staring at me through the monitor.
[cpg]

[OnName num="KEI"]
I'm here.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki020"]
[OnName num="eMU"]
I thought I had fallen.
[cpg cn=true]



I had not been participating in the conversation at all, so I must have made her anxious.
[cpg]

[OnName num="oac"]
'Mr. Kay doesn't talk much, does he?
[cpg cn=true]



[OnName num="yaminabebugyo"]
'It's hard for me to keep up with the Roms because of their names.
[cpg cn=true]



I was a little too absorbed in observing the room.
[cpg]
[FACE method="change_1" pos="3/7"]
[OnName num="kumachan"]
'By the way, Emu-chan, that stuffed bear...I knew you liked bears!　I'm thrilled for you, bear!
[cpg cn=true]



[OnName num="aaa"]
"This has nothing to do with you.
[cpg cn=true]



[OnName num="kumachan"]
I want to be your bear.
[cpg cn=true]



What's with that approach? I can't follow that kind of tension.
[cpg]

[OnName num="yaminabebugyo"]
I want to be your bear.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki021"]
[OnName num="eMU"]
"Your majesty, you are very knowledgeable. You know so much, don't you?
[cpg cn=true]



Suddenly, Emu-chan looked at me with respect.
[cpg]
[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki022"]
[OnName num="eMU"]
You mean you know wool felt, don't you?　I'm kind of happy.
[cpg cn=true]



[OnName num="keisuke"]
Mmu......"
[cpg cn=true]



After that, Yami Nabe and Emu-chan were talking about stuffed animals as if it were their own world, and the other regulars, including me, could no longer interrupt them.
[cpg]

The day ended with no personal gains at all, and I ended up just staring at the screen.
[cpg]


;//→２日目昼　へ
[jump target="*day01_end"]

;//==========================

;//ぬいぐるみ（★美咲a　がある場合進行）
*misaki_la|ようこそワクテカ動画へ！

I found a small bear made of a slightly different material in the nugui.
[cpg]

Could this be ......
[cpg]

[OnName num="KEI"]
'Hey, is that stuffed bear wool felt?
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki023"]
[OnName num="eMU"]
'Yes, Kay-kun, do you know wool felt?'
[cpg cn=true]



I asked, and Emu-chan rolled her eyes at my question.
[cpg]

I typed a hasty reply.
[cpg]

[OnName num="KEI"]
Yes, I do. You make it by pricking it with a needle, right?
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki024"]
[OnName num="eMU"]
Wow, it's rare to find a man who knows how to make one, so I'm very happy!
[cpg cn=true]



[OnName num="KEI"]
Did you make it yourself?
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki025"]
[OnName num="eMU"]
'Yes, I did. I'm a homecoming club member, so I do handicrafts in my spare time.
[cpg cn=true]



[OnName num="KEI"]
You are very good at it.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki026"]
[OnName num="eMU"]
Thank you!
[cpg cn=true]



＞Yami Nabeyobo has left the room.
[cpg]
[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki027"]
[OnName num="eMU"]
"Do you like to do handicrafts too, Kay?
[cpg cn=true]



I found out that one of the regulars left the room without saying hello.
[cpg]

I guess he probably didn't like the fact that I monopolized Emu-chan.
[cpg]

But I didn't care and continued my conversation with Emu-chan.
[cpg]

[OnName num="KEI"]
I often go to grocery stores and such because I'm interested in them," she said.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Misaki028"]
[OnName num="eMU"]
I'm sure you and Kaye get along well.
[cpg cn=true]



[OnName num="aaa"]
"Hey, it's bad manners for you two to be alone in the world.
[cpg cn=true]



[OnName num="oac"]
Oko.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki029"]
[OnName num="eMU"]
Oh, I'm sorry.
[cpg cn=true]



[OnName num="kumachan"]
Inquisitor, you've fallen.
[cpg cn=true]



[OnName num="KEI"]
I'm sorry. I'm sorry, Emu-chan. I'm sorry to all of you.
[cpg cn=true]



[OnName num="kumachan"]
"You're new at this, but you'd better get used to reading the air."
[cpg cn=true]



[OnName num="KEI"]
Yes, I'm sorry.
[cpg cn=true]



The world of chatting is also quite a hassle.
[cpg]

I'm fine as long as I can talk only with Emu, but I wonder if I have to pay attention to the people around me.
[cpg]
[FACE method="change_1" pos="3/7"]
[VOICE f="Misaki030"]
[OnName num="eMU"]
I'm not a bad person, Kei-kun. This room is mine, so I have to take care of it.
[cpg cn=true]



[OnName num="kumachan"]
'I'll forgive you if you give me a bear giggle as an apology!
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Misaki031"]
[OnName num="eMU"]
'Eh?　Gimme a bear?　Like this?"
[cpg cn=true]



[SE f="se034"]
;//【ＳＥ】ぎゅー


[FACE method="change_2" pos="3/7"]
[OnName num="keisuke"]
'Oh...!
[cpg cn=true]



Emu-chan showed a wool felt stuffed animal pressed against her chest as if to pinch it.
[cpg]

Because of the way she was leaning forward, her chest was gaping up, giving her the best angle.
[cpg]

[OnName num="aaa"]
"Aaahhh!
[cpg cn=true]



[OnName num="oac"]
Ohohoooo!"
[cpg cn=true]



This made the rest of the gallery ecstatic.
[cpg]

[OnName num="kumachan"]
I forgive you!　I mean, thanks to Mr. Kay, I got to see something good, thank you!
[cpg cn=true]



Damn, these guys....
[cpg]

Well, I wouldn't have been able to see this scene without Kumanoro's recklessness, so I guess it's all good.
[cpg]

I ended the day with Emu-chan's cleavage burned into my eyes.
[cpg]

;//→２日目昼へ
[jump target="*day01_end"]

;//=============================================================================

;//２，リアンズワールド
*day01_2|ようこそワクテカ動画へ！

[OnName num="keisuke"]
"I'll be there..."
[cpg cn=true]



Unable to put out the black flame in my chest, I decided to enter Hayashida's room.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『リアンズワールド』

＞Kei-san has entered the room.
[cpg]

[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="3/7" time=800]
[VOICE f="Mari013"]
[OnName num="Lian"]
"Kay-chan, hallo hallo ♥"
[cpg cn=true]



Damn...she greeted me so annoyingly.
[cpg]

I send a fake message to Hayashida, resisting the urge to scream at the mere sight of his face.
[cpg]

[OnName num="KEI"]
I send a fake message to Hayashida: "Hallo Hallo."
[cpg cn=true]



＞Nanashi0815 has entered the room.[r]
＞Nanashi1010 has entered the room.[r]
＞Nanashi0922 has entered the room.
[cpg]

[FACE method="change_1" pos="3/7"]
[VOICE f="Mari014"]
[OnName num="Lian"]
Hello, hello, hello. How is everyone?
[cpg cn=true]



What the...?
[cpg]

Why do all the people who come to this room have names with "Nanashi" followed by a number?
[cpg]

It's like Hayashida is too lazy to call out the numbers, or maybe he doesn't recognize the individuals, or maybe he's speaking to an unspecified number of people.
[cpg]

[OnName num="john_doe0815"]
'How are you feeling today?'
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari015"]
[OnName num="Lian"]
'Depends on how you feel?'
[cpg cn=true]



[OnName num="john_doe1010"]
'Ageteko ageteko.'
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Mari016"]
[OnName num="Lian"]
Ageteko ageteko."
[cpg cn=true]



I find the multitude of Nanashi a little creepy, and begin to rummage around the room that serves as a backdrop as they and Hayashida start to talk.
[cpg]


;//■選択肢_夜_１日目_リアン

;//画面にカーソル表示　注目ポイントとメッセージ

;//※現時点で絵が分からないので、色や形など随時そちらでメッセージを足して結構です
[stflag Rselecter21_cnt = 2]
*Rselecter01|ようこそワクテカ動画へ！

[if exp={getFlagValue("Rselecter21_cnt") == 0}]
[jump target="*1niend_ri"]
[endif]

[switch]
[case "Leanne's face"]
	[swap]
	[jump target="*Rsel1_01"]
[case "Leanne's chest"]
	[swap]
	[jump target="*Rsel1_02"]
[case "Leanne's head"]
	[swap]
	[jump target="*Rsel1_03"]
[case "窓"]
	[swap]
	[jump target="*Rsel1_04"]
[case "The bed"]
	[swap]
	[jump target="*Rsel1_05"]
[case "Table"]
	[swap]
	[jump target="*Rsel1_06"]
[case "Closet"]
	[swap]
	[jump target="*Rsel1_07"]
[case "Leanne"]
	[swap]
	[jump target="*Rsel1_01"]
[endswitch]


1,Leanne's face
2,Leanne's chest
3,Leanne's head
4,Window
5,bed
6,Table
7,Closet


;//==========================
;//リアンの顔（★麻里a　がない場合）
*Rsel1_01|ようこそワクテカ動画へ！
[if exp={getFlagValue("Cha2flg_la") == 1}]
[jump target="*1mariflgla"]
[endif]

[stflag Rselecter21_cnt=-1]

Hateful Mari Hayashida's face.
[cpg]

I don't know if it's called "gal makeup", but she wears makeup even though she's a student.
[cpg]

You think you're cute, bitch!
[cpg]

[jump target="*Rselecter01"]
;//==========================
;//リアンの胸
*Rsel1_02|ようこそワクテカ動画へ！

[stflag Rselecter21_cnt=-1]

I think it's a decent size.
[cpg]

No, it's big...but I don't like to admit it. Let's call it normal.
[cpg]

[jump target="*Rselecter01"]
;//==========================
;//リアンの頭
*Rsel1_03|ようこそワクテカ動画へ！

[stflag Rselecter21_cnt=-1]

If you crack it open, you'll probably find an empty head.
[cpg]

And yet, her hair is so well done, it's disgusting.
[cpg]

[jump target="*Rselecter01"]
;//==========================
;//窓
*Rsel1_04|ようこそワクテカ動画へ！

[stflag Rselecter21_cnt=-1]

You can't see what's going on outside, so you don't even know what floor you're on.
[cpg]

If it's a high-rise apartment building, I really hope he jumps down.
[cpg]

[jump target="*Rselecter01"]
;//==========================
;//ベッド
*Rsel1_05|ようこそワクテカ動画へ！

[stflag Rselecter21_cnt=-1]

The sheets are crumpled up, and the clothes have been taken off on top.
[cpg]

What a slut!
[cpg]

There are even magazines on the floor.
[cpg]

Fashion magazines, I guess.
[cpg]

I wonder if she reads anything like this.
[cpg]

[jump target="*Rselecter01"]
;//==========================
;//テーブル
*Rsel1_06|ようこそワクテカ動画へ！

[stflag Rselecter21_cnt=-1]

Mirrors, pouches, and cosmetics are placed in a mess.
[cpg]

It's hard to tell what's what because of the mess.
[cpg]

[jump target="*Rselecter01"]
;//==========================
;//クローゼット
*Rsel1_07|ようこそワクテカ動画へ！

[stflag Rselecter21_cnt=-1]

The door is slightly open and clothes are sticking out.
[cpg]

I'm afraid that if I open the door, an avalanche will start.
[cpg]

[jump target="*Rselecter01"]
;//==========================
;//★麻里aがない場合　２箇所クリック後→;//１日目夜リアン終了　へ進行

;//１日目夜リアン終了
*1niend_ri|ようこそワクテカ動画へ！

[FACE method="change_7" pos="3/7"]
[VOICE f="Mari017"]
[OnName num="Lian"]
Aaaaah!　I'm not in the mood today.
[cpg cn=true]



[OnName num="keisuke"]
"......?"
[cpg cn=true]



[OnName num="john_doe0920"]
Wait a minute!
[cpg cn=true]



[OnName num="john_doe0706"]
Let's talk some more!"
[cpg cn=true]



The number of nasanashi, which had increased before I knew it, started typing messages at once, and the chat room began to show a furious flow of messages.
[cpg]

However, Hayashida arrogantly leaned back in his chair and began to play with his long fingernails as if he was bored.
[cpg]

[FACE method="change_2" pos="3/7"]
[VOICE f="Mari018"]
[OnName num="Lian"]
He then began to play with his long fingernails, as if to say, "That's it. See you later.
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】ブチッ

;//画面黒
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[OnName num="keisuke"]
「えっ！？」
[cpg cn=true]



Suddenly the screen went black and a message appeared saying that Lian had closed the room.
[cpg]

I was thrown out of the room, and all I could do was stare at the black screen in amazement.
[cpg]

[OnName num="keisuke"]
What the hell is that bitch!
[cpg cn=true]



Even the organizers are too selfish!
[cpg]

What kind of treatment is this!
[cpg]

I was so angry that I couldn't say anything to anyone, and on this day, I just had to go to sleep...
[cpg]

;//→２日目昼　へ
[jump target="*day01_end"]
;//==========================

;//リアンの顔（★麻里a　がある場合クリックで進行）
*1mariflgla|ようこそワクテカ動画へ！


After watching it for a while, I began to notice not only the hatred on Hayashida's face, but also a subtle difference from before.
[cpg]

I wondered what it was, and upon closer inspection, I saw a slight puckering rise on his chin.
[cpg]

[OnName num="KEI"]
I looked closely and saw a slight puckering on my chin.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Mari019"]
[OnName num="Lian"]
Oh, you figured it out?　Oh, you got it?　That's so disgusting!
[cpg cn=true]



Hayashida, exaggerating his reaction, picked up a mirror from the table and checked his chin.
[cpg]

[OnName num="john_doe0814"]
He picked up the mirror on the table and checked his chin. Usually.
[cpg cn=true]



[OnName num="john_doe0303"]
You're not popular, that's for sure.
[cpg cn=true]



[OnName num="ナナ1111"]
You're bald, aren't you?
[cpg cn=true]



The number of nashi, which had increased before I knew it, all criticized my comment at once.
[cpg]

Surprisingly, however, Hayashida did not seem to be angry with me...
[cpg]

[FACE method="change_2" pos="3/7"]
[VOICE f="Mari020"]
[OnName num="Lian"]
He said, "You hid it with concealer and foundation, but you got it so well, Kay-chan. I'm surprised that you looked at Leanne so closely.
[cpg cn=true]



Every time this guy speaks, my gut starts to churn.
[cpg]

I hate her!
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Mari021"]
[OnName num="Lian"]
I'm really disgusted by her pimples. I wonder why I got them. Did I eat too many sweets?
[cpg cn=true]



[OnName num="john_doe1010"]
What kind of sweets did you eat?
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Mari022"]
[OnName num="Lian"]
"Well, you know who?　Super cute ice cream from Thailand.
[cpg cn=true]



[OnName num="KEI"]
"Ice cream rolls?
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari023"]
[OnName num="Lian"]
Yes!　You're amazing, Kay-chan. Have you ever had it?
[cpg cn=true]



I generously shared the knowledge I had just acquired by accident today.
[cpg]

[OnName num="KEI"]
Yes, I have. You know, the kind where you roll up liquid ice cream dripping on a cold plate with a spatula and serve it up like flower petals? Isn't it cute and delicious?
[cpg cn=true]


[FACE method="change_6" pos="3/7"]
[VOICE f="Mari024"]
[OnName num="Lian"]
No, Kay, you know what I'm talking about!　I'm addicted to their honey sauce!
[cpg cn=true]



Oh, yeah!　But I don't care!
[cpg]

Chatting is fine.
[cpg]

I may look like a king, but in text you're all smiles...
[cpg]

[OnName num="KEI"]
'Oh yeah! Chocolate sauce is my favorite.
[cpg cn=true]



I'm a sucker for chocolate sauce.
[cpg]

In fact, Hayashida was in a good mood.
[cpg]


[FACE method="change_1" pos="3/7"]
[VOICE f="Mari025"]
[OnName num="Lian"]
I'm feeling good today, so I'm going to go.　The secret room is open!
[cpg cn=true]



[OnName num="john_doe0429"]
Oh!
[cpg cn=true]



[OnName num="john_doe0810"]
Yes!
[cpg cn=true]


;//＠
[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1500]

As Nanashi and the others rejoiced at Lian's comment, the screen immediately turned white and a message appeared.
[cpg]

'Secret only. Please use the passcode "rian_love" to make a deposit before you come.[r]
Special 1000 yen for today.
[cpg cn=true]



[OnName num="keisuke"]
What...what...oh oh oh..."
[cpg cn=true]



Why did you switch to paying when you feel better, bitch!
[cpg]

I was angry, but I soon remembered the meaning of the room.
[cpg]

Hayashida casually issued a pass, making it almost meaningless in a situation like this, but secret rooms are supposed to exist for sharing secrets in a closed room.
[cpg]

And seeing that Nanashi and the others were so happy, there must be a flavor to entering that room.
[cpg]

[OnName num="keisuke"]
Ummm ......"
[cpg cn=true]



I had already wasted 1,000 yen once, but I should go in again to get a feel for Hayashida's weakness.
[cpg]

I thought so and decided to deposit the money with some hesitation.
[cpg]

[STOPBGM]
[window target=false]
[BG f="b_05_6.ui" time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『リアンズワールド』
;//リアンズルーム（シークレットでも背景は同じ部屋）

[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="3/7" time=800]

[VOICE f="Mari026"]
[OnName num="Lian"]
I'm late, Kei-chan. I was about to start.
[cpg cn=true]



[OnName num="KEI"]
Oh, I'm sorry. What do you mean you were just about to start?
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Mari027"]
[OnName num="Lian"]
"Liane's honey show time.
[cpg cn=true]



[OnName num="keisuke"]
What?
[cpg cn=true]



Unexpectedly, a frightened voice came out, but Hayashida picked up a bowl containing something that looked like honey.
[cpg]

[OnName num="keisuke"]
Nah...!"
[cpg cn=true]


He then spilled the honey onto his own body.
[cpg]

The chat section went into a frenzy. I just watched her do it, stunned.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sMari004"]
[OnName num="Lian"]
I changed the honey from the last one... ...... a little too sticky, don't you think?
[cpg cn=true]


She was scooping the honey off her skin and licking it off.
[cpg]


A request was posted in the chat room. They are extreme requests, as if there is no way she could do such a thing.
[cpg]


She was dodging them and keeping the show on the edge of her seat.
[cpg]

;//移植前シーンカット



Come to think of it, how many people were in this room right now?
[cpg]

Did they all come knowing that Leanne was going to do this?
[cpg]



[OnName num="keisuke"]
..............."
[cpg cn=true]



I felt like I was doing myself a disservice by just watching and not doing anything.
[cpg]

But the other party was Mari Hayashida. I thought back on it and became calm.
[cpg]


[OnName num="keisuke"]
I'll definitely expose this act to the light of day someday, so be prepared..."
[cpg cn=true]



As soon as I muttered this, the secret room closed and Hayashida disappeared from the screen.
[cpg]


;//→２日目昼へ

[jump target="*day01_end"]
;//=============================================================================

;//３，Ｈキャッスル
*day01_3|ようこそワクテカ動画へ！
[OnName num="keisuke"]
Let's go to JoOusama's room..."
[cpg cn=true]



I suppressed my smoldering curiosity and decided to wait for the right moment to enter the H Castle.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『Ｈキャッスル』

＞ケイさんが入室されました
[cpg]

[FG f="CHA03_p5_03_a.ui" method="change_1"  pos="3/7" time=800]

[VOICE f="Hitomi014"]
[OnName num="SB"]
"Oh?　You're here again.
[cpg cn=true]



[OnName num="KEI"]
'Is it me?　Oh, good evening. I'm Kay.
[cpg cn=true]



[OnName num="kugutsu"]
"Dear Butterfly, how are you?
[cpg cn=true]



[OnName num="pig"]
"My queen, thank you again for the honor of an audience today."
[cpg cn=true]



[OnName num="keisuke"]
Oh...I see...I had to greet you like this..."
[cpg cn=true]



It was not the time to say hello or good evening.
[cpg]

[FACE method="change_2" pos="3/7"]
While glancing at the conversation between the regulars and SB, which I don't really understand, I observe the room in the background.
[cpg]

;//■選択肢_夜_１日目_ＳＢ

;//画面にカーソル表示　注目ポイントとメッセージ

[stflag Hselecter31_cnt = 2]

*Hselecter01|ようこそワクテカ動画へ！

[if exp={getFlagValue("Hselecter31_cnt") == 0}]
[jump target="*1niend_hi"]
[endif]

[switch]
[case "SB's face"]
	[swap]
	[jump target="*Hsel1_01"]
[case "SB's chest"]
	[swap]
	[jump target="*Hsel1_02"]
[case "SB's head"]
	[swap]
	[jump target="*Hsel1_03"]
[case "Candlestick"]
	[swap]
	[jump target="*Hsel1_04"]
[case "ベッド"]
	[swap]
	[jump target="*Hsel1_05"]
[case "Wall"]
	[swap]
	[jump target="*Hsel1_06"]
[case "Floor"]
	[swap]
	[jump target="*Hsel1_07"]
[case "SB"]
	[swap]
	[jump target="*Hsel1_01"]
[case "SB"]
	[swap]
	[jump target="*Hsel1_01"]
[endswitch]

;//==========================
;//ＳＢの顔
*Hsel1_01|ようこそワクテカ動画へ！

[stflag Hselecter31_cnt=-1]

He wears a mask that resembles a butterfly, and we don't know what he looks like.
[cpg]

Whether it is this mask because he is a butterfly or this mask because he is a butterfly is a mystery.
[cpg]

[jump target="*Hselecter01"]
;//==========================
;//ＳＢの胸
*Hsel1_02|ようこそワクテカ動画へ！

[stflag Hselecter31_cnt=-1]

Her breasts are beautiful, not too big, not too small, and as far as I can see, well-shaped.
[cpg]

I guess you have to have good style to wear bondage fashion.
[cpg]

[jump target="*Hselecter01"]
;//==========================
;//ＳＢの頭
*Hsel1_03|ようこそワクテカ動画へ！

[stflag Hselecter31_cnt=-1]

She has beautiful long hair.
[cpg]

When I think of a queen, I think of a long, lush, vertical rolls, but I don't hear such a thing in the world of SM.
[cpg]

I wonder why...
[cpg]

[jump target="*Hselecter01"]
;//==========================
;//燭台
*Hsel1_04|ようこそワクテカ動画へ！

[stflag Hselecter31_cnt=-1]

A few candles on a silver candlestick light up the room fantastically.
[cpg]

The wax is dripping, but isn't it hard to clean it?
[cpg]

[jump target="*Hselecter01"]
;//==========================
;//ベッド
*Hsel1_05|ようこそワクテカ動画へ！

[stflag Hselecter31_cnt=-1]
A tasteless and plain pipe bed.
[cpg]

The handcuffs on the pipe are very disturbing...
[cpg]

[jump target="*Hselecter01"]
;//==========================
;//壁
*Hsel1_06|ようこそワクテカ動画へ！

[stflag Hselecter31_cnt=-1]

Poured concrete.
[cpg]

This kind of thing looks like the room would be cold, but I wonder if it's ok to wear SB's outfit?
[cpg]

[jump target="*Hselecter01"]
;//==========================
;//床
*Hsel1_07|ようこそワクテカ動画へ！

[stflag Hselecter31_cnt=-1]

Flooring?　Concrete?
[cpg]

It's too dim to see clearly, but nothing is falling.
[cpg]

[jump target="*Hselecter01"]
;//==========================
;//１日目夜ＳＢ終了
*1niend_hi|ようこそワクテカ動画へ！

;//◆瞳フラグＡがない場合　２箇所クリック後→;//１日目夜ＳＢ終了　へ進行
[if exp={getFlagValue("Cha3flg_A") == 1}]
[jump target="*1hinisben"]
[endif]


[FACE method="change_1" pos="3/7"]
[VOICE f="Hitomi015"]
[OnName num="SB"]
I'm like, "Hey, Kay. How have you been today?
[cpg cn=true]



[OnName num="keisuke"]
「やべ…っ」
[cpg cn=true]



I was so engrossed in observing the room that I couldn't think of anything to say in reply to SB.
[cpg]

[OnName num="KEI"]
Nothing in particular.
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Hitomi016"]
[OnName num="SB"]
「……………」
[cpg cn=true]



SB saw my reply and shook his head in an obvious lackadaisical manner.
[cpg]

Then...
[cpg]

[OnName num="deku"]
You!　How dare you speak to Master S. Butterfly!
[cpg cn=true]



[OnName num="kugutsu"]
Even if you put aside the stupidity of your answer, you should have said, "Nothing in particular, sir!
[cpg cn=true]



[OnName num="KEI"]
I'm sorry, I'm not used to this...
[cpg cn=true]



[OnName num="pig"]
"JoOusama has just called on you, and you're acting so irreverently!　You deserve to die!
[cpg cn=true]



[OnName num="keisuke"]
「えええ……」
[cpg cn=true]



What's with this flow....
[cpg]

I don't care if it's SB himself, why do I have to be denounced by the regular M-men?
[cpg]

Even if it's just for fun, it makes me feel bad.
[cpg]

[OnName num="KEI"]
I've already apologized to you.
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Hitomi017"]
[OnName num="SB"]
'You...do you have a belt or a tie?'
[cpg cn=true]



SB, who was watching the exchange, ruffles up his hair in a troublesome manner and says.
[cpg]

[OnName num="KEI"]
'Yes.'
[cpg cn=true]



[VOICE f="Hitomi018"]
[OnName num="SB"]
'Either one is fine, just hold it in your hand.
[cpg cn=true]



I was instructed to do so, and for some reason, I honestly picked up one of the belts.
[cpg]

[OnName num="KEI"]
『はい』
[cpg cn=true]



[VOICE f="Hitomi019"]
[OnName num="SB"]
Then gag yourself with it.
[cpg cn=true]



[OnName num="keisuke"]
?
[cpg cn=true]



I wondered what was going on, but I did it.
[cpg]

[OnName num="KEI"]
I did it.
[cpg cn=true]


[FACE method="change_3" pos="3/7"]
[VOICE f="Hitomi020"]
[OnName num="SB"]
I didn't do it!
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】棒ムチ（バシッ）

[OnName num="keisuke"]
「！？」
[cpg cn=true]



When SB swung down the stick whip, there was a tremendous sound and my body jerked for a moment.
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Hitomi021"]
[OnName num="SB"]
I was shocked and felt a tremendous sound as SB swung the stick whip down.
[cpg cn=true]



[OnName num="keisuke"]
I'll let you know if that's what you want to do. ......
[cpg cn=true]



I'm not going to say that I can't speak, but since this is a chat room, I can speak freely in writing.
[cpg]

But since the gag is a punishment and a warning to me, I should have pretended that I could not speak even in writing.
[cpg]

[OnName num="KEI"]
I should have pretended that I couldn't even speak in writing.
[cpg cn=true]


[FACE method="change_2" pos="3/7"]
[VOICE f="Hitomi022"]
[OnName num="SB"]
"'You'll have to stay that way for the rest of the day. Ha ha ha ha ha!
[cpg cn=true]



[OnName num="KEI"]
Ha ha ha ha!
[cpg cn=true]



SB laughed in satisfaction at my reaction.
[cpg]

If I had said ......... farce, he would have slapped me.
[cpg]

I still didn't understand the fun in this room, but I still kept the gag on for the rest of the day.
[cpg]

And by the time H Castle closed, my belt was already soggy and sticky. ......
[cpg]

;//→２日目昼　へ
[jump target="*day01_end"]
;//==========================
;//▲瞳フラグＡ　がある場合
*1hinisben|ようこそワクテカ動画へ！

[FACE method="change_1" pos="3/7"]
[VOICE f="Hitomi015"]
[OnName num="SB"]
「ケイとかいうの。お前は今日どうしていたの？」
[cpg cn=true]



[OnName num="keisuke"]
"Oh man...!"
[cpg cn=true]



部屋の観察に夢中になっていた俺は、ＳＢへの返事に頭が回らない。
[cpg]

[OnName num="KEI"]
I went to a cafe.
[cpg cn=true]


[FACE method="change_5" pos="3/7"]
[VOICE f="Hitomi016"]
[OnName num="SB"]
「……………」
[cpg cn=true]



When SB saw my reply, he froze for a moment as if he had been caught off guard.
[cpg]

[FACE method="change_7" pos="3/7"]
[VOICE f="Hitomi023"]
[OnName num="SB"]
What do you mean you went to a café?
[cpg cn=true]



[OnName num="KEI"]
'I saw a surprisingly plain waitress there. She was a woman of a level of sobriety that is rare nowadays, and then'
[cpg cn=true]



I sent it on its way, trying to make the story interesting, and as I was typing the rest of the story...
[cpg]

[OnName num="deku"]
"You!　What nonsense you have done to Lady S. Butterfly!
[cpg cn=true]



[OnName num="kugutsu"]
Boring!　Boring, indeed!
[cpg cn=true]



[OnName num="KEI"]
"I'm sorry, but it's true.
[cpg cn=true]



[OnName num="pig"]
But it's true. My queen has asked me to speak to you!　Boo-hoo!　Go die once!"
[cpg cn=true]



[OnName num="keisuke"]
「えええ……」
[cpg cn=true]



The regulars gave me a hard time, but I answered honestly, so there was nothing I could do to mend the situation.
[cpg]

As I was at a loss to type my next words, SB said in a quiet voice.
[cpg]

[FACE method="change_6" pos="3/7"]
[VOICE f="Hitomi024"]
[OnName num="SB"]
'Really, the slaves are right. You're a boring man, Kay ......, and you're going to be punished.'
[cpg cn=true]



[OnName num="KEI"]
『え』
[cpg cn=true]



This time I was caught off guard.
[cpg]

The chat room was closing in on me.
[cpg]

[OnName num="pig"]
Butterfly!　Oh no!
[cpg cn=true]



[OnName num="deku"]
What a waste of a man like him!
[cpg cn=true]



[OnName num="kugutsu"]
What will happen to us?
[cpg cn=true]


[FACE method="change_3" pos="3/7"]
[VOICE f="Hitomi025"]
[OnName num="SB"]
Silence!
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】棒鞭（バシッ）

Something slammed into the screen I was watching so vigorously.
[cpg]

If you think about it, you will realize that SB hit the camera with a stick whip, but in that instant, you could not understand that much on the spur of the moment.
[cpg]

[OnName num="deku"]
'Ah!　Forgive us!
[cpg cn=true]



[OnName num="kugutsu"]
'Please punish us, too, for being so stupid!
[cpg cn=true]


[FACE method="change_7" pos="3/7"]
[VOICE f="Hitomi026"]
[OnName num="SB"]
'Didn't you hear me when I told you to shut up?　We'll leave you alone. Be thankful for that."
[cpg cn=true]



[OnName num="pig"]
"Boo-hoo-hoo!　Leave us alone!　What a heartless punishment!
[cpg cn=true]



I was even more confused when I saw the pigs start to bleat.
[cpg]

On the other hand, SB did not move his eyes under the mask even a little and pointed the stick whip at us and said.
[cpg]

[FACE method="change_3" pos="3/7"]
[VOICE f="Hitomi027"]
[OnName num="SB"]
Kay. Come here at once. This is an order.
[cpg cn=true]



[OnName num="keisuke"]
What?
[cpg cn=true]


;//＠
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

Then, just as I thought the image suddenly disappeared from the screen, I received a message.
[cpg]

I clicked on it and opened it...
[cpg]

It said, "secret pass code 'slave_boy_KEI' by S.B."
[cpg]



And that was all it said.
[cpg]

But with that I understood what S.B. was asking for and immediately headed for the secret room.
[cpg]

I found the room of the user S. Butterfly, clicked on it, and was shown the system explanation of the fee payment, just like in Hayashida's case: ......
[cpg]

[OnName num="keisuke"]
Huh?"
[cpg cn=true]



There was no amount shown there, and the payment text was grayed out.
[cpg]

I thought it might be an error, but upon closer inspection, I saw the word 'free' in the amount column.
[cpg]

So I entered the room with a passcode and entered the room with some trepidation.
[cpg]


[STOPBGM]
[window target=false]
[BG f="b_05_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_h1"]
;//【ＢＧ】『Ｈキャッスルシークレットルーム』

＞ケイさんが入室されました
[cpg]

[FG f="CHA03_p5_03_a.ui" method="change_3"  pos="3/7" time=800]

[VOICE f="Hitomi028"]
[OnName num="SB"]
Too late.
[cpg cn=true]



[OnName num="KEI"]
Sorry."
[cpg cn=true]



I wanted to say, "I'm sorry, I'm sorry! I wanted to say, "I'm so sorry!" but I thought it would sound cold if I displayed it in writing.
[cpg]

Forgive me, JoOusama...?
[cpg]

Is "Buhey..." correct?
[cpg]


[FACE method="change_1" pos="3/7"]
[VOICE f="Hitomi029"]
[OnName num="SB"]
Is this the first time you've been spanked by someone?
[cpg cn=true]



[OnName num="KEI"]
'Yes, I have.
[cpg cn=true]



A test to try out a little polite language.
[cpg]


[FACE method="change_2" pos="3/7"]
[VOICE f="sHitomi002"]
[OnName num="SB"]
'Good. Then, for starters, take off what you're wearing right there.
[cpg cn=true]



[OnName num="keisuke"]
"Yes. ......"
[cpg cn=true]



I don't know what she meant by this, but Butterfly demanded that I take off my clothes.
[cpg]

However, I was a little uncomfortable taking off my clothes even though it was in my room and not in the bath.
[cpg]

So, taking advantage of the fact that she couldn't see me, I took a few moments to reply.
[cpg]

[OnName num="KEI"]
『脱ぎました』
[cpg cn=true]



[SE f="se009"]
;//【ＳＥ】棒鞭
[FACE method="change_3" pos="3/7"]
[WAIT time=1000]

[OnName num="keisuke"]
Eh?"
[cpg cn=true]



The sound of the stick whip being violently slammed into my ears through my headphones.
[cpg]

[VOICE f="Hitomi031"]
[OnName num="SB"]
I was licked too.　I've been licked too, haven't I?
[cpg cn=true]



What do you mean...?
[cpg]

It's as if SB is acting as if he can see me.
[cpg]

I was not supposed to be able to see him, but his confident attitude made me feel fear.
[cpg]

[FACE method="change_3" pos="3/7"]
[VOICE f="Hitomi032"]
[OnName num="SB"]
He said, "If you don't take off your clothes before the count of three, you'll never be allowed in the room again. One...two........."
[cpg cn=true]



[OnName num="keisuke"]
Wow....
[cpg cn=true]



I don't know what in the world I'm afraid of, but as if by magic, my own hands stripped off my own clothes.
[cpg]


[OnName num="KEI"]
I took off my clothes.
[cpg cn=true]


[FACE method="change_1" pos="3/7"]
[VOICE f="Hitomi033"]
[OnName num="SB"]
Good. And now what?　Is that a chair you're sitting on?　Or the floor?"
[cpg cn=true]



[OnName num="keisuke"]
'Oh... so it's not like I can see after all. ......'
[cpg cn=true]



I was so relieved at the completely natural thing that I'm currently in my underwear....
[cpg]

[OnName num="KEI"]
Chair.
[cpg cn=true]



I reply, and the next order is given: "Then sit down on the floor right now.
[cpg]


[FACE method="change_1" pos="3/7"]
[VOICE f="sHitomi003"]
[OnName num="SB"]
Then sit on the floor right now. Sit on the floor.
[cpg cn=true]



Sitting on the floor, of course, makes it impossible to type right away. I guess she is okay with that, too.
[cpg]


When I sat down on the floor, she said the following words to me: "You look so ugly.
[cpg]


[FACE method="change_2" pos="3/7"]
[VOICE f="sHitomi004"]
[OnName num="SB"]
You look so ugly. I know you want to be spanked from now on.
[cpg cn=true]



[FACE method="change_1" pos="3/7"]
[VOICE f="sHitomi005"]
[OnName num="SB"]
But if I do what you want, I won't be spanked.
[cpg cn=true]



[OnName num="keisuke"]
Oh no,...... I don't want to be spanked,......."
[cpg cn=true]



These words were mumbled by one person. The other side couldn't hear me and couldn't see me.
[cpg]


[FACE method="change_3" pos="3/7"]
[VOICE f="Hitomi037"]
[OnName num="SB"]
You miserable little rat.
[cpg cn=true]



[OnName num="keisuke"]
"Dodgy rat..."
[cpg cn=true]



Before I knew it, I felt like I was having a direct conversation with SB's voice echoing in my ears.
[cpg]

[VOICE f="Hitomi038"]
[OnName num="SB"]
Yes, you're dirty and pathetic. You are a dirty, pathetic rat. You've just been poked like this, and now you're going to squeal and beg for forgiveness.
[cpg cn=true]



The tip of the stick whip was being thrust at the monitor.
[cpg]


It felt as if it was touching my body.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sHitomi006"]
[OnName num="SB"]
'May I?　I'm going to touch you now. Just as my hand touches you, you touch yourself."
[cpg cn=true]


[OnName num="keisuke"]
E......"
[cpg cn=true]


For a moment I wondered what she was talking about, but the bottom line is that I can't touch her directly.
[cpg]


She is reaching for the camera. That means it's reaching for me.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="sHitomi007"]
[OnName num="SB"]
She says, "Look ...... my hand is going to touch your cheek."
[cpg cn=true]



I touch my cheek as the hand approaches me.
[cpg]


It feels like it is not my own hand. It really feels like she is touching me.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sHitomi008"]
[OnName num="SB"]
Now, I wonder what part of my cheek I should touch to punish her.
[cpg cn=true]



My pulse quickened. I was anticipating what she was going to do to me.
[cpg]


I was expecting her to do it to me. ...... Then she began to play around with my body, calling it a spanking.
[cpg]


I didn't feel like it, even though of course it was me who was being touched.
[cpg]



;//移植前シーンカット

[FACE method="change_2" pos="2/3"]
[VOICE f="sHitomi009"]
[OnName num="SB"]
'...... hahahahahaha!'　That was pretty funny, Dobbermouse. Come back to the castle. Okay?"
[cpg cn=true]



[OnName num="KEI"]
'Yes, yes, yes, yes, yes, yes.
[cpg cn=true]



[OnName num="keisuke"]
"........................... ........."
[cpg cn=true]



When SB logged out and nothing appeared on the screen, I remained for a while stunned, hunched over, like a cripple.
[cpg]

[OnName num="keisuke"]
'What happened to ......?'
[cpg cn=true]



Is that the one called Queen ......?
[cpg]

I was a mess of feelings of utter defeat, respect, emotion, and incomprehension.
[cpg]

The only thing that is clear is that I don't want this first experience to be the last.
[cpg]

Let's go back to ......H Castle.
[cpg]



;//→２日目昼へ
;//[jump target="*day01_end"]

;//=============================================================================

*day01_end|ようこそワクテカ動画へ！


[jump storage="ep001.ks" target="*start"]

