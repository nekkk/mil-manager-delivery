*start

;#################################################
*Ep010|M's Disease
;#################################################

[SCENE id=10]


[stflag jump_scene=0]
[window target=false]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]

[SE f=se060 loop=true]
;//【ＳＥ】『強い日差し』
;//※SEかもしくは演出で

[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

;//【ＢＧ】『空』（昼）******************************************************



[BGM f="d1"]

[window target=true]


The sun's rays shine intensely, It's even hotter today.
[cpg]

As I was weeding in the garden of the mansion, sweat was pouring out like a waterfall.
[cpg]

[OnName num="masato"]
"It's hot...
[cpg cn=true]


It's hard to work outside in the hot sun.
[cpg]

[OnName num="masato"]
Water. Water.
[cpg cn=true]


The water that moistens my throat feels so good.
[cpg]

I really need to rehydrate often, because I might get heat stroke.
[cpg]

[OnName num="butler"]
It's pretty hard to work outside in today's weather, isn't it?
[cpg cn=true]


[OnName num="masato"]
Mr. Tanaka.
[cpg cn=true]


[OnName num="butler"]
It's good to drink fluids, but it's better to have some salt in it.
[cpg cn=true]


[OnName num="masato"]
''Oh...that's right.
[cpg cn=true]


I wonder if it will become a sports drink or something like that.
[cpg]

[OnName num="butler"]
"Well, I'm off to it. Don't take too much of it.
[cpg cn=true]


[OnName num="masato"]
Yes, sir.
[cpg cn=true]

[BG f="black.ui" time=1000]
;//ＢＫ

Alright, let's try one more time.
He continued to work afterwards, staying hydrated.
[cpg]

[BG f="b_07_2.ui" time=1000]

[OnName num="masato"]
''Ha, ha...it's hot...no matter how much I drink, I get thirsty. Water, water...
[cpg cn=true]


There was no more water left in the plastic bottle I had brought with me.
[cpg]

No choice, let's go back to the house and get some water.
[cpg]

Yeah, but...Tanaka-san said it would be better to have more salt. I don't know what to do.....
[cpg]

There's salt, too, and speaking of drinkable things...
[cpg]

[OnName num="masato"]
Sigh.................................................................................................................
[cpg cn=true]


It fits the situation. I'm sure you'll be overwhelmed with motivation.
[cpg]

Since that last incident... not only have I been able to drink Master's pee, but I've been able to crave it once in a while.
[cpg]

[OnName num="masato"]
But you can't...
[cpg cn=true]


They won't give me a drink. You don't have that kind of opportunity.
[cpg]

Once he refused, once he was in the middle of sleeping, which is a long shot.
[cpg]


[SE f="se060"]
;//【ＳＥ】『強い日差し』ギラギラ
;//※SEかもしくは演出で


[OnName num="masato"]
Phew...it's hot, hot.
[cpg cn=true]


I'm going to go back to the house and--


;//暗転と共に画面が揺れ、傾き倒れる演出


[OnName num="masato"]
 "……that?" 
[cpg cn=true]




[SE f="se007"]
;//【ＳＥ】『倒れる』バタッ


[BG f="black.ui" time=1000]
[WAIT time=600]
;//ＢＫ

[BGM f="se"]
[BG f="b_06_2.ui" time=1000]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（昼）******************************************************


[OnName num="masato"]
''Ugh...ugh...''
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0693"]
[OnName num="sayo"]
Are you awake?
[cpg cn=true]


[OnName num="masato"]
Master? Hey, this is...
[cpg cn=true]


I don't know what I'm doing here, but it looks like my room. I'm sure he was working outside.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0694"]
[OnName num="sayo"]
"You're an idiot... He collapsed from heatstroke.
[cpg cn=true]


[OnName num="masato"]
''Eh, it's not like that... was it?''
[cpg cn=true]


I've made another mistake.
[cpg]

[OnName num="masato"]
I apologize for any inconvenience this may cause.
[cpg cn=true]


[VOICE f="Sayo0695"]
[OnName num="sayo"]
'Well, good. And it doesn't seem to have been a big deal.
[cpg cn=true]


I wonder if he was worried about me and came to check on me. I'm very happy to hear that.
[cpg]

[FG f="CHA01_p2_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0696"]
[OnName num="sayo"]
Is there anything you want?
[cpg cn=true]


[OnName num="masato"]
''No, I'm fine. I'm already feeling well again.
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0697"]
[OnName num="sayo"]
''So...''
[cpg cn=true]


For a moment, Master's eyes narrowed.
[cpg]

[FG f="CHA01_p2_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo0698"]
[OnName num="sayo"]
You've been saying "I need to pee, I need to drink..." in your sleep, but you don't want it...?
[cpg cn=true]


[OnName num="masato"]
Huh.
[cpg cn=true]


[VOICE f="Sayo0699"]
[OnName num="sayo"]
It's scary how true the perverted guts live on until you're asleep.
[cpg cn=true]


Wait a minute, I was talking in my sleep about my desires in my sleep!
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0700"]
[OnName num="sayo"]
Do you want it?
[cpg cn=true]


[OnName num="masato"]
''Well, it was... it was hot outside, so as something that could rehydrate and replenish salt at the same time, so...''
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0701"]
[OnName num="sayo"]
What do you want...?
[cpg cn=true]


[OnName num="masato"]
'...I want it.''
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0702"]
[OnName num="sayo"]
''Humph.''
[cpg cn=true]

*Scene11|M. Neutrino.

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ

[BGM f="h1" time=1000]

;//●ＣＧエロ（雅人＆小夜・小夜の聖水を欲しがるが焦らしプレイ。素足コキ＋舐めさせられる：雅人の部屋）ev_09
;//※おしっこプレイ３。雅人がおしっこを欲しがる様になっている。でもちょっとずつしか飲ませてくれない
;//※ちんこに掛けられて必死に自分のチンポを咥えて舐めようとするが、届かず…その姿を見て笑われる
;//※尿まみれのチンコを素足で踏まれイカされる。その後に尿と精液まみれの足を舐めさせられる

;**【ＣＧ】ev_09_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************

[VOICE f="Sayo0703"]
[OnName num="sayo"]
I was about to go to the bathroom, so that's just fine.
[cpg cn=true]

So the master straddles me asleep and brings his crotch in front of my face.
[cpg]

[OnName num="masato"]
''Master, I'm sorry for making you do this...''
[cpg cn=true]


[VOICE f="Sayo0704"]
[OnName num="sayo"]
"I don't need you to apologize now... you've been a handful of times since I made you my servant.
[cpg cn=true]


[OnName num="masato"]
''Ugh...I'm sorry...I'm sorry...
[cpg cn=true]


[SE f="se013"]
;//【ＳＥ】『衣類を脱ぐ』シュルシュル


;**【ＣＧ】ev_09_a ***********************
[CG id=8 index=1 time=1000]
;***************************************

[VOICE f="Sayo0705"]
[OnName num="sayo"]
"You told me you wanted it. If you spill it, you'll never know.
[cpg cn=true]


[OnName num="masato"]
"Yes, yes..."
[cpg cn=true]


Oh, how many times have I been looked down upon by the master like this?
[cpg]

I wonder how many times I've looked up at her pussy from below like this.
[cpg]

This angle is a very comforting sight for me.
[cpg]


[VOICE f="Sayo0706"]
[OnName num="sayo"]
Keep your mouth wide open and don't spill.
[cpg cn=true]


[OnName num="masato"]
"Hey. Ahhhh...
[cpg cn=true]


[VOICE f="Sayo0707"]
[OnName num="sayo"]
''Hmmm...hmmm...hmmm...it's coming out.
[cpg cn=true]


Holy water came out of the master's private parts.
[cpg]



;**【ＣＧ】ev_09_b ***********************
[CG id=8 index=2 time=1000]
;***************************************

[SE f="se032"]
;//【ＳＥ】『放尿』チョロチョロ


Cholo...Cholo...Cholo...Cholo...Cholo...Cholo.
[cpg]

[OnName num="masato"]
"Huh, ah...fuh? The five wheelers?
[cpg cn=true]


[VOICE f="Sayo0708"]
[OnName num="sayo"]
Here, it's spilling out.
[cpg cn=true]


[OnName num="masato"]
"Fuhi.
[cpg cn=true]




[SE f="se032"]
;//【ＳＥ】『放尿』チョロチョロ


[VOICE f="Sayo0709"]
[OnName num="sayo"]
''Huh...huh...huh...huh...huh...''
[cpg cn=true]


I can't put it in my mouth well. Or rather, the master is so delicately disheveled that I can't drink.
[cpg]

[OnName num="masato"]
Master?
[cpg cn=true]


[VOICE f="Sayo0710"]
[OnName num="sayo"]
Mm-hmm."
[cpg cn=true]


He grins. That's when I realized the same thing.
[cpg]

Yes, you can't just say you want it... and then give it to you so easily.
[cpg]

If I keep this up, it's all over my face and I'm done.
[cpg]

[OnName num="masato"]
Huh! Huff, huff, huff!
[cpg cn=true]


I try desperately to follow the urine line and try to drink my pee. But we've been ducked.
[cpg]


[VOICE f="Sayo0711"]
[OnName num="sayo"]
"There you go, what's the matter? You love to pee, don't you? If you don't drink it, it won't come out soon enough.
[cpg cn=true]


[OnName num="masato"]
''(Ugh, that's not...that's not true...!)''
[cpg cn=true]


The master is getting impatient and mean. I'm not going to let this...
[cpg]

But after all, it is difficult to do so when you are sleeping.
[cpg]


[VOICE f="Sayo0712"]
[OnName num="sayo"]
"Not at all... the bed isn't covered in urine.
[cpg cn=true]


[OnName num="masato"]
''Ughhhhhh...Master...''
[cpg cn=true]


[VOICE f="Sayo0713"]
[OnName num="sayo"]
A lousy servant. I told you not to spill the beans... then I guess it's better this way.
[cpg cn=true]


[OnName num="masato"]
!?
[cpg cn=true]



;**【ＣＧ】ev_09_c ***********************
[CG id=8 index=3 time=1000]
;***************************************

[SE f="se029"]
;//【ＳＥ】『ベルト＆ファスナー』カチャカチャ、ジーッ


As I said that, Master pulled down my pants and took my cock out.
[cpg]

And we're headed there...
[cpg]


;**【ＣＧ】ev_09_d ***********************
[CG id=8 index=4 time=1000]
;***************************************


[SE f="se032"]
;//【ＳＥ】『放尿』じょろろーっ


[VOICE f="Sayo0714"]
[OnName num="sayo"]
Hmmm...haaaahhhhhh...
[cpg cn=true]


This time, the pee is being sprayed with more momentum than before.
[cpg]

A chill runs through me at the sight of it. This is the way to release it... this is the way to release all the rest of it!
[cpg]


[OnName num="masato"]
''Ah, ah...ahhhh!
[cpg cn=true]


[VOICE f="Sayo0715"]
[OnName num="sayo"]
Hmmm...hmmm...hmmm...hmmm...
[cpg cn=true]


[SE f="se032"]
;//【ＳＥ】『放尿』チョロチョロ


[OnName num="masato"]
''Ahhhh...''
[cpg cn=true]


A few seconds of surprise and bewilderment. In the meantime, it was all over.
[cpg]

All the pee that was left in Master's bladder was hung up on my dick.
[cpg]

He is knocked down from hope to despair.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ


[STOPBGM]
[BG f="b_06_2.ui" time=1000]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（昼）******************************************************


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0716"]
[OnName num="sayo"]
Lick your urine off your own pussy.
[cpg cn=true]


[OnName num="masato"]
''Ahhhhhh...''
[cpg cn=true]


In the midst of grief, I still want to put my master's pee in my mouth, even if only a little.
[cpg]

With that thought, she folds her body and desperately tries to crawl her mouth into her own cock.
[cpg]

[OnName num="masato"]
''Ugh, Ugh...Ugh, Ugh...Ugh, Ugh, Ugh, Ugh!''
[cpg cn=true]


But no matter what, it doesn't reach.
[cpg]

Even if you are a gymnast, you probably can't lick your own things.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo0717"]
[OnName num="sayo"]
''Ahahahahaha. How awkward you look... you're the most ridiculous thing I've ever seen.
[cpg cn=true]


[OnName num="masato"]
''Ugh, Ugh...''
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo0718"]
[OnName num="sayo"]
'Oh my gosh, are you going to cry? What kind of a man cries because he can't drink his pee...
[cpg cn=true]


[OnName num="masato"]
I'm at ......."
[cpg cn=true]


I don't think so, Master.
[cpg]


[SE f="se061"]
;//【ＳＥ】『踏みつけられる』ガッ


[OnName num="masato"]
!?
[cpg cn=true]


[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[BGM f="h1"]

;//☆ＣＧエロ（雅人＆小夜・小夜の聖水を欲しがるが焦らしプレイ。素足コキ＋舐めさせられる：雅人の部屋）ev_09
;//※尿まみれのチンコを素足で踏まれイカされる。その後に尿と精液まみれの足を舐めさせられる

;**【ＣＧ】ev_09_e ***********************
[CG id=8 index=5 time=1000]
;***************************************

I felt the weight and shock in my crotch and opened my closed eyes in sadness and frustration.
[cpg]

And then, the master's raw foot...stomped on my cock.
[cpg]

[OnName num="masato"]
Master...?
[cpg cn=true]


[VOICE f="Sayo0719"]
[OnName num="sayo"]
That's good enough for you right now.
[cpg cn=true]


Guriiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii.
[cpg]

[OnName num="masato"]
''Oooh!''
[cpg cn=true]


Suddenly, it is stepped on strongly and pressure is applied to the meat rod.
[cpg]


[VOICE f="Sayo0720"]
[OnName num="sayo"]
"It's so hard...I wonder if it's all I can do to get an erection!
[cpg cn=true]


[OnName num="masato"]
Ugh, ahhhhhhh!
[cpg cn=true]


[VOICE f="Sayo0721"]
[OnName num="sayo"]
Here, here, here!
[cpg cn=true]


[OnName num="masato"]
''Huh, ah...uhh, geez!''
[cpg cn=true]


Master fiercely teases the meat stick with his legs.
[cpg]

I stepped on it like I was crushing it, or I rubbed it on, each one of which felt good.
[cpg]


[VOICE f="Sayo0722"]
[OnName num="sayo"]
It's slimy, so it's easy to play with. Around here or something...
[cpg cn=true]


[OnName num="masato"]
Oooohhhhhh.....
[cpg cn=true]


[VOICE f="Sayo0723"]
[OnName num="sayo"]
Here and there.
[cpg cn=true]


[OnName num="masato"]
Whoo-hoo-hoo!
[cpg cn=true]


The master skillfully used his legs to tease the meat stick.
[cpg]

[VOICE f="Sayo0724"]
[OnName num="sayo"]
Ho!
[cpg cn=true]




[SE f="se062"]
;//【ＳＥ】『かかと落とし？』パァンッ


[OnName num="masato"]
"Aaaaah!
[cpg cn=true]


[VOICE f="Sayo0725"]
[OnName num="sayo"]
''Ahahahaha, what a miserable voice. It wasn't just a light tap.
[cpg cn=true]


The master's legs swung down to the rod with great vigor.
[cpg]

[VOICE f="Sayo0726"]
[OnName num="sayo"]
"I've been a little too easy on you lately... you're less stubborn than you used to be.
[cpg cn=true]


[VOICE f="Sayo0727"]
[OnName num="sayo"]
There's more to come. Feel it firmly.
[cpg cn=true]




[SE f="se062"]
;//【ＳＥ】『かかと落とし？』パァンッ


[VOICE f="Sayo0728"]
[OnName num="sayo"]
Hey! Ho, that!
[cpg cn=true]

[SE f="se062"]
;//【ＳＥ】『かかと落とし？』パァンッ

[OnName num="masato"]
"Whoosh! Yikes, yikes, yikes!
[cpg cn=true]



[SE f="se062"]
;//【ＳＥ】『かかと落とし？』パァンッ


[OnName num="masato"]
''Hahaha, ahhh...ahhh...ahhh...''
[cpg cn=true]


It is true that the body reacts to the strong stimulation given to it after a long time. My tolerance may have waned a bit.
[cpg]

But more than that, my whole body is delighted with this stimulation after a long time.
[cpg]


[VOICE f="Sayo0729"]
[OnName num="sayo"]
''Hmmm~. Maybe I'm getting better at using my toes, too.
[cpg cn=true]


Grrrrrrrr...........
[cpg]

[OnName num="masato"]
'Hi, there...ahhh...ahhh...there, there...ahhh...master ahhh...'
[cpg cn=true]



[VOICE f="Sayo0730"]
[OnName num="sayo"]
No? What's wrong with you? Your manhood is so pleased with you!
[cpg cn=true]


The strength of his strikes, the angle at which he put his blows in, the way he poked the back of the ball with his fingertips, the way he pinched and pinched various places with his toes...Master's skills had certainly improved.
[cpg]

[OnName num="masato"]
"Hi! No, no, no, master... master can't use those vulgar words like "cock"...
[cpg cn=true]



;**【ＣＧ】ev_09_f ***********************
[CG id=8 index=6 time=1000]
;***************************************

[VOICE f="Sayo0731"]
[OnName num="sayo"]
Shut up! I'm sure it's all in my wheelhouse! A cock is a cock!
[cpg cn=true]




[SE f="se062"]
;//【ＳＥ】『かかと落とし？』パァンッ

[OnName num="masato"]
Aaaaahhhhhh!
[cpg cn=true]


[VOICE f="Sayo0732"]
[OnName num="sayo"]
Your cock feels good, doesn't it? It must feel good to be doing this to you!
[cpg cn=true]

[SE f="se062"]
;//【ＳＥ】『かかと落とし？』パァンッ


[OnName num="masato"]
"Ahhhh, yes! That's so good! I don't know what you're talking about... but I want you to torment my cock!
[cpg cn=true]


I get excited just when the word "cock" comes out from the master who usually uses the word well.
[cpg]

And with that, it's a great pleasure to be tortured so hard.
[cpg]


;**【ＣＧ】ev_09_g ***********************
[CG id=8 index=7 time=1000]
;***************************************
[VOICE f="Sayo0733"]
[OnName num="sayo"]
''Oh, I've already got my filthy juices coming out. Have you come yet? Are you going to cum?
[cpg cn=true]


[OnName num="masato"]
'Ahhhhhhhhhh, I'm coming...I'm coming! It's ready to go!
[cpg cn=true]


[VOICE f="Sayo0734"]
[OnName num="sayo"]
Do you want to cum like this? Or is there someplace else where you want this male juice to come out...?
[cpg cn=true]


Master asked me that, and I replied frankly.
[cpg]

[OnName num="masato"]
"Ha................................................................................................................................
[cpg cn=true]


[VOICE f="Sayo0735"]
[OnName num="sayo"]
I can't hear you. Where?
[cpg cn=true]


[OnName num="masato"]
"Master's oh...inside...oh...I really want to let you out in my pussy...I want to let you out!
[cpg cn=true]


I'm afraid and I know it's unforgivable, but inevitably it doesn't go away as a sexual desire.
[cpg]

[VOICE f="Sayo0736"]
[OnName num="sayo"]
Ha. You're a servant who doesn't know what he's doing when he wants to get inside his master.
[cpg cn=true]


[OnName num="masato"]
I'm sorry, sir.
[cpg cn=true]


[VOICE f="Sayo0737"]
[OnName num="sayo"]
A servant like that isn't even worth giving an ejaculation to.
[cpg cn=true]


Giiiiiiiiy.
[cpg]

[OnName num="masato"]
"Hakahaha!
[cpg cn=true]


I said, and Master crushed my urethra with his toe. I can't ejaculate like this.
[cpg]

[OnName num="masato"]
What? Ahhhhhh! I'm not going to let it go, master... and it won't go, it won't go, it won't go, it won't go, it won't go, it won't go.
[cpg cn=true]


[VOICE f="Sayo0738"]
[OnName num="sayo"]
'Let it out in me, I don't give you permission. So it's okay if we don't cum like this.
[cpg cn=true]


[OnName num="masato"]
I want to let you out, I want to let you out! I want to squeak it out! I'll leave it at that, please!
[cpg cn=true]


[VOICE f="Sayo0739"]
[OnName num="sayo"]
I don't like selfish servants.
[cpg cn=true]


[OnName num="masato"]
''I'm sorry, I'm sorry... Master! I love the Master's feet... and all I needed was a foot rub! I'll stop being so selfish! I'm happy just to get my cock kicked by my master's springy legs!
[cpg cn=true]


[VOICE f="Sayo0740"]
[OnName num="sayo"]
Couscous, yes, that's what I'm talking about.
[cpg cn=true]


[VOICE f="Sayo0741"]
[OnName num="sayo"]
"This leg is your very own pussy. Do you understand? All you have to do is keep squirting your seed to get my feet pregnant, understand?
[cpg cn=true]


[OnName num="masato"]
"I understand...hahahahahaha...I'll make Master's pussy and foot...pregnant! So, please, let me cum...
[cpg cn=true]


[VOICE f="Sayo0742"]
[OnName num="sayo"]
All right, let's see it. Now cum in front of me while I watch.
[cpg cn=true]


[VOICE f="Sayo0743"]
[OnName num="sayo"]
Show me how rude you are, squirting your male juices from being played with!
[cpg cn=true]


[OnName num="masato"]
Aaaaahhhh, I'm getting out!
[cpg cn=true]


;**【ＣＧ】ev_09_h ***********************
[CG id=8 index=8 time=1000]
;***************************************


;//フラッシュ


[SE f="se026"]
;//【ＳＥ】『射精音』


-- sizzle, sizzle, sizzle, sizzle, sizzle!!!!
[cpg]

[OnName num="masato"]
''Hahhhh, hahhhh...''
[cpg cn=true]


The moment the toe that had blocked my urethra was dismissed, I ejaculated with a flourish.
[cpg]


[VOICE f="Sayo0744"]
[OnName num="sayo"]
How was your leggings?
[cpg cn=true]


[OnName num="masato"]
Ha, ha...ha-hee, that was very good...
[cpg cn=true]


[VOICE f="Sayo0745"]
[OnName num="sayo"]
Yes. Then you'll have to pay your respects... to the Kore.
[cpg cn=true]


[OnName num="masato"]
"Huh...hmm, jerk. Squishy, Lero Lero...
[cpg cn=true]


Master's feet were offered to me. I lick and clean that leg that is soaked with urine and cum.
[cpg]

[OnName num="masato"]
Squishy, squishy...
[cpg cn=true]


[VOICE f="Sayo0746"]
[OnName num="sayo"]
''Phew~...I think I got a little too excited too...''
[cpg cn=true]


[OnName num="masato"]
"Pita, Lero...I'm sorry for me.
[cpg cn=true]


[VOICE f="Sayo0747"]
[OnName num="sayo"]
It's not for your sake. You just bullied me because you wanted me to bully you.
[cpg cn=true]


[OnName num="masato"]
"That's it...aww, chill...chill, chill...twitch. 
[cpg cn=true]


[VOICE f="Sayo0748"]
[OnName num="sayo"]
''Hmm. Thank you for your time. You've gotten better at it.
[cpg cn=true]


I'm most happy when people compliment me on something like this.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ

[SCENE id=10]
[ENDPARTIAL]


[STOPBGM]
[BGM f="d1"]
[BG f="b_06_2.ui" time=1000]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（昼）******************************************************


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0749"]
[OnName num="sayo"]
''And yet, you've become a real pee drinker... you've become a real urine lover, haven't you?
[cpg cn=true]


[OnName num="masato"]
''Ugh...I'm embarrassed...yes, you're right.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0750"]
[OnName num="sayo"]
If you want it, encourage it more.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[VOICE f="Sayo0751"]
[OnName num="sayo"]
'Work more for me, do more for me, and live more for me. Do that, and I'll give you exactly what you want as a reward.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0752"]
[OnName num="sayo"]
''Well... not only pee, but next time I'll let you do something like my side penis...''
[cpg cn=true]


Oh, not just my pee, but my side! To be able to taste the master's new full body pussy is an absolute pleasure!
[cpg]


[OnName num="masato"]
"Yes, sir! I'll do my best! More, more! With all my heart and all my soul... for my master!
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0753"]
[OnName num="sayo"]
Shush. It's for my pee, isn't it? Couscous.
[cpg cn=true]


[OnName num="masato"]
''Eh, uh...no, I'm not. That too, but also purely to play the role of a master...
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0754"]
[OnName num="sayo"]
I know. I'm counting on you, so go for it.
[cpg cn=true]


[OnName num="masato"]
Ha...yes!
[cpg cn=true]


I vowed to work even harder for my master, not to pee or peek...
[cpg]

[OnName num="masato"]
However, Master... it's not too much for me to say, but the use of words such as "pee" and "pussy"... if the Master were to hear it...
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0756"]
[OnName num="sayo"]
''I'll be careful about that much too. Besides, it wouldn't do any good to dress up in front of you, would it?
[cpg cn=true]


[OnName num="masato"]
! Yes, of course. Expose more of your master.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0757"]
[OnName num="sayo"]
Don't you dare ride Chosh.
[cpg cn=true]




[SE f="se020"]
;//【ＳＥ】『軽いデコピン』ぺちっ


[OnName num="masato"]
"It's over. Ahahahahaha.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0758"]
[OnName num="sayo"]
“♪”
[cpg cn=true]


I really, really want to work harder for this guy...and harder.
[cpg]



;//ＢＫ


[STOPBGM]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="ep011.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////
