*start

;#################################################
*Ep011|Sing & Dance M Ondo
;#################################################

[SCENE id=11]


[stflag jump_scene=0]
[window target=false]

[STOPBGM]



;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]

[FG f="line.ui" method="out"  pos="3/5"]


[SE f=se018]
;//【ＳＥ】『鳥の鳴き声』

[BG f="black.ui" time=1000]
[WAIT time=1000]



[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]
[BGM f="d1"]
[WAIT time=100]

;//【ＢＧ】『豪邸、廊下』（朝）******************************************************


[SE f="se016"]
;//【ＳＥ】『ドアを開ける』ガチャ

[window target=true]


[OnName num="masato"]
Wow!
[cpg cn=true]


[OnName num="butler"]
Good morning, Mr. Masato.
[cpg cn=true]


Usual wake-up time.
I opened the door and greeted Mr. Tanaka, rubbing my eyes that had not yet awakened.
[cpg]

[OnName num="masato"]
Oh, Tanaka-san. Good morning...wow...
[cpg cn=true]


[OnName num="butler"]
You look sleepy.
[cpg cn=true]


[OnName num="masato"]
Excuse me. I've been staying up late reading...
[cpg cn=true]




[SE f="se016"]
;//【ＳＥ】『ドアを開ける』ガチャ


[OnName num="maid_A"]
Wah~. Good morning to you~
[cpg cn=true]


[OnName num="butler"]
Well, well, well, this way too.
[cpg cn=true]


[OnName num="maid_B"]
I don't... you two need to be more polished.
[cpg cn=true]


[OnName num="butlerA&maidA"]
I'm sorry.
[cpg cn=true]


[OnName num="butler"]
Well, let's go.
[cpg cn=true]


[OnName num="maid_B"]
I'm afraid I'll have to keep you waiting, miss.
[cpg cn=true]


[OnName num="masato"]
Yes!
[cpg cn=true]


[OnName num="maid_A"]
Yes, ma'am.
[cpg cn=true]




[SE f="se042"]
;//【ＳＥ】『小走り』タタタ


I've gotten used to living here, and it feels like I've been here for years now, and I'm getting used to it.
[cpg]

After greeting my colleagues like this, I headed to the master. He was also happy to have a mundane morning.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BGM f="d1"]
[BG f="b_04_1.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（朝）******************************************************


[OnName num="butler"]
Good morning, Miss.
[cpg cn=true]


[OnName num="maid_A"]
Good morning to you. It's good weather today too!
[cpg cn=true]


[OnName num="masato"]
Good morning, Master.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0291"]
[OnName num="sayo"]
Good morning."
[cpg cn=true]


A gentle smile that smiles at you. Just to see this smile on my face makes me happy.
[cpg]

I can't compare it to my old life, it's smooth sailing.
[cpg]

I work for the master, I do my best, and sometimes (a big lie) I get pushed around...happy days.
[cpg]


[OnName num="masato"]
(Alright, I'll do my best for the master today...!)
[cpg cn=true]


--But that is... as long as there is nothing wrong with it.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BGM f="sl"]
[BG f="b_01_2.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************


[SE f="se063"]
;//【ＳＥ】『掃除音』


[OnName num="maid_A"]
''Oh, Mr. Masato. Just in the right place.
[cpg cn=true]


[OnName num="masato"]
What?"
[cpg cn=true]


As I was cleaning the corridor, which was designated as the scope of my work, Mr. Ochiai called out to me.
[cpg]


[OnName num="maid_A"]
Can you help me with this?
[cpg cn=true]


[OnName num="masato"]
Of course it's good.
[cpg cn=true]


[OnName num="maid_A"]
Thank you!
[cpg cn=true]


[OnName num="masato"]
No problem, sir.
[cpg cn=true]




[BG f="black.ui" time=1000]
;//ＢＫ





Squeak.
[cpg]

[OnName num="masato"]
Ugh...!
[cpg cn=true]


That's what it sounds like when you step on someone, isn't it?
[cpg]

I thought about that as I listened to the sounds coming from my own back.
[cpg]


[BG f="b_02_2.ui" time=1000]
;//【ＢＧ】『豪邸、ダイニング』（昼）******************************************************


[OnName num="maid_A"]
Are you all right? Isn't it heavy?
[cpg cn=true]


[OnName num="masato"]
"It's totally hysterical... Please, go ahead.
[cpg cn=true]


[OnName num="maid_A"]
Yes. Well....
[cpg cn=true]


Her full weight rested on her back.
[cpg]

Naturally, I'm on all fours and it's a platform for her to ride.
[cpg]


[SE f="se064"]
;//【ＳＥ】『電球交換』カチャカチャ


[OnName num="maid_A"]
I'm sorry, the bulbs here are too expensive to reach...
[cpg cn=true]


[OnName num="masato"]
''Ahaha...that's right.
[cpg cn=true]


The house is big and spacious. The lighting that illuminates the room is also set high throughout.
[cpg]

Even a man can't reach the light bulb on the wall without getting on a stand to change it.
[cpg]

I was asked to help out there, and this is what I'm using as a stepping stone...
[cpg]


[SE f="se064"]
;//【ＳＥ】『電球交換』カチャカチャ


[OnName num="maid_A"]
I'm sure we'll get this done soon.
[cpg cn=true]


[OnName num="masato"]
Don't be hasty, take your time.
[cpg cn=true]


Perhaps because she was using me as a stand, I stopped her from hurriedly changing the light bulb.
[cpg]

Even if it's just a light bulb change, you have to be polite about your work. You never know what's going to happen later.
[cpg]

[OnName num="maid_A"]
But Mr. Masato...
[cpg cn=true]


[OnName num="masato"]
I'm fine. I'm used to this kind of thing.
[cpg cn=true]


[OnName num="maid_A"]
Shush. Is that so? Well then...
[cpg cn=true]




[SE f="se064"]
;//【ＳＥ】『電球交換』カチャカチャ


[OnName num="masato"]
'(Thank goodness...)''
[cpg cn=true]


The sound of work in my ears stabilized, and I stroked my chest in relief.
[cpg]


[OnName num="masato"]
(We can stay like this a little longer!)
[cpg cn=true]


[OnName num="maid_A"]
Hmmm, right.
[cpg cn=true]


Squeak, squeak, squeak.
The comfortable feel of your feet and the exquisite weight of your feet spread all over your back.
[cpg]


[OnName num="masato"]
''(Ah...good. (There...hahaha!)
[cpg cn=true]


I'm being stepped on by a girl now.
I mean, I'm happy.
[cpg]


[OnName num="masato"]
"Hmm...phew, phew...
[cpg cn=true]


It's normal to want to feel a little bit longer in a happy time.
[cpg]

Of course, I didn't want her to worry... and I wanted her to be polite and do her work for me.
[cpg]

It's not that I'm feeling good, it's that I'm more focused on my work.
[cpg]


[OnName num="masato"]
Ha ha ha ha ha ha ha.
[cpg cn=true]


Honestly, I'm okay with being trodden on for an hour or so at this point. It's good.
[cpg]

I can't believe I'm feeling good while still doing my job... it's a good day. You're a lucky M.
[cpg]


[OnName num="maid_A"]
Um...Mr. Masato? Are you sure you're okay? I feel like I'm breathing hard for something...
[cpg cn=true]


[OnName num="masato"]
''Totally, totally fine! It's all green!
[cpg cn=true]


[OnName num="maid_A"]
''Well, I see...that's fine then...''
[cpg cn=true]


It's such a happy thing to be used as a stepping stone by a girl.
Naturally, tears seem to come to my eyes.
[cpg]


[OnName num="masato"]
''(Although heavier than the master, this weight is also quite a bit...)''
[cpg cn=true]


Incidentally, this isn't a saddle change or...cheating or anything like that.
[cpg]

It's the same with punchlines.
[cpg]

A natural byproduct of the work of changing light bulbs. It just so happened to be a happy event.
[cpg]

It was a reward for me, that's all.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ


[WAIT time=600]



[BG f="b_02_2.ui" time=1000]
;//【ＢＧ】『豪邸、ダイニング』（昼）******************************************************


[OnName num="maid_A"]
'Yes, I'm done. Thank you for your hard work.
[cpg cn=true]


[OnName num="masato"]
''Phew...''
[cpg cn=true]


[OnName num="maid_A"]
''Thank you very much, Masato. It saved my life.
[cpg cn=true]


In about half an hour, we finished changing all the light bulbs in the dining room.
[cpg]

Well... it's just been a stand all along, though I haven't done anything about it.
[cpg]

[OnName num="maid_A"]
Is your back okay? Doesn't it hurt?
[cpg cn=true]


[OnName num="masato"]
''I'm fine with this. Ochiai-san, you were light.
[cpg cn=true]


It's good enough to give me another 30 minutes.
[cpg]


[OnName num="maid_A"]
Couscous, Mr. Masato, you're very dependable.
[cpg cn=true]


[OnName num="masato"]
No...no...no... If it's okay with me, I'm always here to help.
[cpg cn=true]


[OnName num="maid_A"]
Really? Then, I'll ask you to do it again if something happens.
[cpg cn=true]


[OnName num="masato"]
I'll take care of it!
[cpg cn=true]


She and I are close to each other because we are close in age among the people who work here. Incidentally, she is older than me.
[cpg]

And I'm a guy, too. When a girl asks me to do something, I can't say no.
[cpg]

I often help out in this way because I want to show the good parts of myself...
[cpg]


--Yes. I may have had a little ulterior motive...I was just helping out out of the goodness of my heart.
[cpg]

As it started to get a little crazy, the clouds started to look suspicious.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ


[STOPBGM]
[BGM f="sl" time=1000]
[BG f="b_06_2.ui" time=1000]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（昼）******************************************************


[OnName num="butler"]
You've been hanging out with Mr. Ochiai a lot lately.
[cpg cn=true]


That's what Tanaka-san said to me when we were having tea together at the break.
[cpg]


[OnName num="masato"]
'........what? Is that so?
[cpg cn=true]


[OnName num="butler"]
Yes. Most of the time when I see them... they seem to be on good terms with each other, so maybe that's how it feels.
[cpg cn=true]


[OnName num="masato"]
「……」
[cpg cn=true]


[OnName num="butler"]
Excuse me. That's just what I thought, so... I hope you don't mind.
[cpg cn=true]


[OnName num="masato"]
''Yes...Ochiai-san often asks me for help, so it must be because of that.
[cpg cn=true]


[OnName num="butler"]
I see. I guess they trust you.
[cpg cn=true]


[OnName num="masato"]
''Ahaha, is that so?''
[cpg cn=true]


[OnName num="butler"]
Relying on them is a sign that you trust them.
[cpg cn=true]


Trusted. When Mr. Tanaka told me so clearly, I felt even more happy.
[cpg]

She's counting on me, and I'm helping her...I feel more fulfilled by the appreciation of others, not just myself.
[cpg]


[OnName num="butler"]
It's just...
[cpg cn=true]


[OnName num="masato"]
?"
[cpg cn=true]


[OnName num="butler"]
''No...it's nothing.
[cpg cn=true]


Putting down the empty teacup, Tanaka-san stood up and straightened his collar.
[cpg]

[OnName num="masato"]
Mr. Tanaka?
[cpg cn=true]


[OnName num="butler"]
The one you are working for, Masato, is a young lady. I hope you don't forget that...
[cpg cn=true]


[OnName num="masato"]
"What? Yes. Of course...
[cpg cn=true]


[OnName num="butler"]
''Then there's no problem. Come on, let's get back to work.
[cpg cn=true]


What Mr. Tanaka was saying was so obvious that I couldn't really understand it, so I tilted my head.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BGM f="se" time=1000]
[BG f="b_01_3.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（夕方）******************************************************


[OnName num="masato"]
What was the point...?
[cpg cn=true]


As I resumed work and walked down the corridor alone, I was reminded of Mr. Tanaka's words.
[cpg]

Something... felt like a nail in the coffin... but there's nothing wrong with that.
[cpg]

I'm just helping Ochiai, and she's just relying on me.
[cpg]

You can't go wrong there.
[cpg]


[SE f="se042"]
;//【ＳＥ】『小走り』タッタッタ


[OnName num="maid_A"]
Oh, Mr. Masato.
[cpg cn=true]


[OnName num="masato"]
Ochiai-san...
[cpg cn=true]


And yet...why did Mr. Tanaka have such a worried look on his face...
[cpg]


[OnName num="maid_A"]
Thank God you found her.
[cpg cn=true]


[OnName num="masato"]
「？」
[cpg cn=true]


[OnName num="maid_A"]
Can I ask you again...is that okay?
[cpg cn=true]


[OnName num="masato"]
Eh."
[cpg cn=true]


[OnName num="maid_A"]
'...no...I don't know...'
[cpg cn=true]


[OnName num="masato"]
No, it's fine.
[cpg cn=true]


For a moment, I thought about saying no, but then I said yes with two answers.
[cpg]

I couldn't refuse her when I saw her smiling happily.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ




[BG f="b_00_4.ui" time=1000]
;//【ＢＧ】『豪邸、ホール』（夜）******************************************************


[OnName num="maid_A"]
Thank you so much for everything. Thanks for the help.
[cpg cn=true]


[OnName num="masato"]
It's okay~. It's a man's job to carry the heavy stuff.
[cpg cn=true]


[OnName num="maid_A"]
I'm sorry, Masato-san, that you are so dependable...I've been asking you for a lot of things...
[cpg cn=true]


[OnName num="masato"]
No, it's not like that. I don't mind at all.
[cpg cn=true]


Helping others. It helps someone.
[cpg]

I'm just doing it because I'm so happy about it...so I'm just doing it.
[cpg]


[OnName num="maid_A"]
Mr. Masato... there's something I'd like to ask you.
[cpg cn=true]


[OnName num="masato"]
Yes? What is it?
[cpg cn=true]


But then I thought.
[cpg]

The things that Mr. Ochiai has been asking for help for up until now, I don't think I'll be the same whether I'm there or not...
[cpg]


[OnName num="maid_A"]
Um...isn't it hard to serve a young lady sometimes?
[cpg cn=true]


[OnName num="masato"]
Huh?
[cpg cn=true]


Yes, even then...the bulb change could have been done using a chair.
[cpg]

The luggage wasn't too heavy either. One woman could have had it.
[cpg]


[OnName num="maid_A"]
''I think I can...treat you better, Masato-san...''
[cpg cn=true]


[OnName num="masato"]
'Well, what does that mean...'
[cpg cn=true]


If so, why did she ask me to help her every time?
[cpg]

I don't know why... he's saying this to me.
[cpg]


[OnName num="maid_A"]
''How about I...the new master...?''
[cpg cn=true]


[OnName num="masato"]
Ew--
[cpg cn=true]


What the hell is that suggestion... you're not supposed to listen to that.
[cpg]

Because my master is "Sayo-sama" and he's the only one.
[cpg]


[OnName num="maid_A"]
''How about it, that's good. I don't think it's a bad story.
[cpg cn=true]


[OnName num="masato"]
"Hey, Mr. Ochiai...please calm down. What's the matter with you!
[cpg cn=true]


[OnName num="maid_A"]
Shush. I didn't do anything... it's just that I was feeling... uncontrollable.
[cpg cn=true]


Like a frog glaring at a snake, our body does not move.
[cpg]

Her body, her lips...they're getting closer and closer.
[cpg]


[OnName num="masato"]
(Wait...wait...wait...wait...wait...)
[cpg cn=true]

[STOPBGM]

[SE f="se065"]
;//【ＳＥ】『靴音』コツン


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0759"]
[OnName num="sayo"]
 "... Kohon" 
[cpg cn=true]


[OnName num="maid_A"]
"Ah.
[cpg cn=true]


[OnName num="masato"]
''Huh!''
[cpg cn=true]


There was the sound of shoes behind him, and there was the Master.
[cpg]

I don't know how long I've been there, or if I've just arrived... I was in a hurry and both I and Mr. Ochiai moved away.
[cpg]


[OnName num="masato"]
Master...
[cpg cn=true]

[BGM f="se" time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0760"]
[OnName num="sayo"]
What are you doing?
[cpg cn=true]


[OnName num="masato"]
Let's see, this is the...
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0761"]
[OnName num="sayo"]
So why don't you get on with your work and get on with it, instead of chatting?
[cpg cn=true]


[OnName num="maid_A"]
''Ha, yes! Wow, I...I'm still cleaning over there...
[cpg cn=true]


Unimpressed, she swiftly left the scene.
[cpg]

I wanted to leave this place together, but we lost our chance and I was left alone with the master.
[cpg]


[OnName num="masato"]
「あ、あの…」
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0762"]
[OnName num="sayo"]
You too. Flirting with a coworker at work is... well, you're in good hands.
[cpg cn=true]


[FG f="CHA01_p4_01_a.ui" method="change_3"  pos="2/3" time=800]

[SE f="se047"]
;//【ＳＥ】『殴る』バキッ


[OnName num="masato"]
It hurts!
[cpg cn=true]


It hit me. The master is somehow unhappy.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0763"]
[OnName num="sayo"]
Now get back to work. Come on, come on!
[cpg cn=true]


[OnName num="masato"]
Ha-ha-ha-ha-ha-ha-ha!
[cpg cn=true]

[SE f="se042"]
;//【ＳＥ】『走る』ダッダッダッ

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=600]


[FO pos="2/3" time=1000]
[BG f="black" time=1000]

;//ＢＫ



[STOPBGM]
[BGM f="sl" time=1000]
[BG f="b_04_4.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（夜）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0764"]
[OnName num="sayo"]
"(That servant and pet is...so annoying. I hope I'm a servant.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0765"]
[OnName num="sayo"]
That servant... he's getting a little carried away these days.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0766"]
[OnName num="sayo"]
And...
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0767"]
[OnName num="sayo"]
 I think I'm going to have to do a little squash.
[cpg cn=true]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ



[STOPBGM]
[BGM f="d1" time=1000]
[BG f="b_04_3.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（夕方）******************************************************


An evening a few days after such a thing happened.
Master called his servant, who had finished his work as usual, to his room.
[cpg]

[OnName num="masato"]
''Um, Tanaka-san. (What the hell is this gathering about today?)
[cpg cn=true]


[OnName num="butler"]
''(No, no, no. (That's the thing...)
[cpg cn=true]




[SE f="se005"]
;//【ＳＥ】『歩く』コツコツ


[OnName num="masato"]
Oh, that guy... he looks familiar.
[cpg cn=true]


Master standing in front of everyone. And next to him, there was a man.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0768"]
[OnName num="sayo"]
I'd like you to meet him...
[cpg cn=true]


[OnName num="glasses_man"]
I'm Ryuhei. It's a pleasure to meet you.
[cpg cn=true]


He hadn't been told what he had been called in for, but he knew that right away.
[cpg]

There's been a "major announcement"...
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0769"]
[OnName num="sayo"]
''He's going to be working here today too. You guys have to teach them a lot of things.
[cpg cn=true]


[OnName num="all_members"]
"""Yes!""
[cpg cn=true]


[OnName num="masato"]
''What...?''
[cpg cn=true]


I was surprised because it was so sudden. I had no idea it was a colleague's introduction...
[cpg]


[OnName num="glasses_man"]
It's a pleasure.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


And the man who showed up was... that man from back then. The man with the glasses I was interviewing with.
[cpg]

If you're here, it looks like you've passed the test.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0770"]
[OnName num="sayo"]
Masato.
[cpg cn=true]


[OnName num="masato"]
'Ha, yes!'
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0771"]
[OnName num="sayo"]
You're the senior member of the team, so teach them well.
[cpg cn=true]


[OnName num="masato"]
''I understand...but...as for seniority...''
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0772"]
[OnName num="sayo"]
Shush. It's pretty obvious. I mean, as a servant, a senior.
[cpg cn=true]


[OnName num="masato"]
「！？」
[cpg cn=true]


My chest squeezed and tightened.
[cpg]

It's been a long time since I've been called a name, and I can't afford to be happy about it.
[cpg]

Because, this is... in short.....
[cpg]

[FO pos="2/3" time=1000]

[OnName num="glasses_man"]
My name is Ryuhei. The senior's name is...
[cpg cn=true]


[OnName num="masato"]
Ah....yeah...I'm Masato...
[cpg cn=true]


A new servant other than me. In other words, it's the new master's servant.
[cpg]

A first-time colleague, a colleague who is close in age... and a 'rival'.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0773"]
[OnName num="sayo"]
''I've been getting bored lately...I wanted a new girl, you know...''
[cpg cn=true]


[OnName num="masato"]
!?
[cpg cn=true]


The impact was like being hit in the back of the head by an unprotected hammer.
[cpg]

What the... what the... what the... the floor is spinning in circles.
[cpg]

No, no, no...no way...no way...no way. Are you getting tired of me having new servants?

[FO pos="2/3" time=1000]

[OnName num="glasses_man"]
You're Masato senior! Thank you very much for your guidance and encouragement!
[cpg cn=true]


[OnName num="masato"]
Hmmm..........................................................
[cpg cn=true]


So... he's not your servant number two, he's my replacement?
Your new servant? Are you sure you don't want me anymore?
That's ridiculous.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0774"]
[OnName num="sayo"]
''(Phew. (It's working, it's working... it's going to be fun for a while).
[cpg cn=true]


[OnName num="butler"]
''Lady... you're a devil.''
[cpg cn=true]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ





--that was the beginning of hell.
[cpg]


[STOPBGM]
[BGM f="h1" time=1000]
[BG f="b_04_2.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************


Next day.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0775"]
[OnName num="sayo"]
It's looking pretty good, isn't it?
[cpg cn=true]


[OnName num="glasses_man"]
"Oh, thank you... thank you!
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0776"]
[OnName num="sayo"]
Were you shitting yourself?
[cpg cn=true]


[OnName num="glasses_man"]
Yes..."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0777"]
[OnName num="sayo"]
Shush. So... it's a great way to save you a lot of trouble.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]

[FO pos="2/3" time=1000]


A man's nagging voice echoes in the master's room.
[cpg]

I've always been the only one in this room who's been shouting like this.
[cpg]

I'm here on guard, trying to keep him from misbehaving, but... this is torture.
[cpg]


[OnName num="glasses_man"]
''Ahhhh...Master, that's great. I've always wanted to do this... I've always wanted a master, like a master.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0778"]
[OnName num="sayo"]
Oh, I'm glad. I like a straightforward girl too.
[cpg cn=true]


The same thing that was done to me when I was new here is being done to him.
[cpg]

It even seems nostalgic now. It's a ritual-like act of receiving the Master's favor.
[cpg]

I was unmistakably jealous of the limited pleasure I would never be able to taste again, and the sight of a man other than myself being subjected to it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0779"]
[OnName num="sayo"]
You're very... nice.
[cpg cn=true]


[OnName num="glasses_man"]
'Well, I don't know...'
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0780"]
[OnName num="sayo"]
I know the poorest manhood in the world. So I think it's a hell of a good thing compared to that.
[cpg cn=true]


[OnName num="masato"]
'(Ugh...!)''
[cpg cn=true]


I'm sure it's your own thing that's swelling healthily in your clothes.
[cpg]

My crotch gets hot when I'm shown such an affair in front of me.
[cpg]

However, compared to my time...Master's response is also completely different. I guess that's how much I like him....
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0781"]
[OnName num="sayo"]
''Well, it's disrespectful to the other dicks compared to the short partials and virgin trash dicks...''
[cpg cn=true]


[OnName num="masato"]
''(Nothing... you don't have to say that much...)''
[cpg cn=true]


Normally this verbal torture would have seemed gratifying, but now it felt painful.
[cpg]


[OnName num="glasses_man"]
''Master...I'm sorry. I'm about to cum.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0782"]
[OnName num="sayo"]
I'll give you special permission. Let it out as it is.
[cpg cn=true]


[OnName num="glasses_man"]
'Ah, ah...come! My ass is cumming!
[cpg cn=true]




--Swoosh, swoosh, swoosh, swoosh.
[cpg]

He ejaculated as loudly as he was told.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0783"]
[OnName num="sayo"]
''Hmmm...''
[cpg cn=true]


[OnName num="masato"]
Aha!
[cpg cn=true]


It was good until I ejaculated, but I had too much momentum...and that's why my master got the cum on me.
[cpg]


[SE f="se042"]
;//【ＳＥ】『駆け寄る』ダダダダダ


[OnName num="masato"]
''Master, are you alright!''
[cpg cn=true]


I immediately ran over and offered Teysh a drink and she took it and wiped her face.
[cpg]

[OnName num="masato"]
Hey! How rude of you! Apologize now!
[cpg cn=true]


[OnName num="glasses_man"]
''Ahhhhhh...''
[cpg cn=true]


You're new here, and your first act is to suddenly shower your face... that's pretty rude.
[cpg]

He's trying to make me get down on my knees to apologize.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0784"]
[OnName num="sayo"]
Don't do that.
[cpg cn=true]


[OnName num="masato"]
"Master..."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0785"]
[OnName num="sayo"]
It's the first time, so failure is natural. To just blame it on that is something an incompetent person would do.
[cpg cn=true]


[OnName num="masato"]
"Ugh..."
[cpg cn=true]


Instead of being angry, the master blamed me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0786"]
[OnName num="sayo"]
It's okay. Gusu, that's a lot of stuff coming out.
[cpg cn=true]


[OnName num="glasses_man"]
Oh, um..."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0787"]
[OnName num="sayo"]
Do a little better next time.
[cpg cn=true]


[OnName num="glasses_man"]
''Ha, yes! I'll be careful!
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0788"]
[OnName num="sayo"]
"Ejaculating without touching the rod... you're a hopeful pervert.
[cpg cn=true]


[OnName num="glasses_man"]
'Oh, thank you... thank you...'
[cpg cn=true]


[OnName num="masato"]
「………」
[cpg cn=true]



[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ



[STOPBGM]
[BGM f="d1" time=1000]
[BG f="b_00_2.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（夜）******************************************************


[OnName num="glasses_man"]
''Well then, senior. Good night.
[cpg cn=true]


[OnName num="masato"]
Uh...yeah. Good night...
[cpg cn=true]




[STOPBGM]
[BGM f="se"]
[BG f="b_06_4.ui" time=1000]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夜）******************************************************


[SE f="se015"]
;//【ＳＥ】『ベッドに座る』ボフッ


[OnName num="masato"]
"Huh... what am I doing, I...
[cpg cn=true]


A man other than herself is treated well by her master, and she is jealous at the sight of such things... and then she is angry.
[cpg]

There are times when I don't do my day-to-day work properly.
[cpg]

It's really not working like this. It's no wonder the master has run out of patience with me...
[cpg]

[OnName num="masato"]
"What to do...what to do...what to do...master...
[cpg cn=true]


I was about to be crushed by anxiety.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ



[STOPBGM]
[BGM f="sl" time=1000]
[BG f="b_06_2.ui" time=1000]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（昼）******************************************************


;//自分のテリトリーが犯されていく恐怖に、ちょっと意地悪をする主人公
;//彼女がふだん着ないパジャマを持たせる



[OnName num="masato"]
''Master is going to bathe, so please follow me as I bring a change of clothes.
[cpg cn=true]


[OnName num="glasses_man"]
Yes, I understand.
[cpg cn=true]


One of my jobs is to deliver a change of clothes to the master before he takes a bath.
[cpg]

However, it's easy because you just have to deliver it.
[cpg]

Yes, yes, mistakes are not made.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ



[BGM f="sl" time=1000]
[BG f="b_01_2.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************


[SE f="se005"]
;//【ＳＥ】『歩く』


[OnName num="masato"]
「……」
[cpg cn=true]


[OnName num="glasses_man"]
Um, senior.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[OnName num="glasses_man"]
You have your own, master's change of clothes... are you sure about this?
[cpg cn=true]


My heart raced at his question, which I hadn't expected to hear from him.
[cpg]

[OnName num="masato"]
Why, why not?
[cpg cn=true]


[OnName num="glasses_man"]
''No, I mean...I didn't think it was very much in keeping with the master's taste.
[cpg cn=true]


[OnName num="masato"]
「………」
[cpg cn=true]


[OnName num="glasses_man"]
Senior?
[cpg cn=true]


[OnName num="masato"]
''It's okay, don't worry about it. That one's a backup...
[cpg cn=true]


[OnName num="glasses_man"]
''Huh...''
[cpg cn=true]


My hands were trembling slightly.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ



[STOPBGM]
[BGM f="d1" time=1000]
[BG f="b_01_2.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************


[OnName num="masato"]
"Master, I have brought you a change of clothes.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0789"]
[OnName num="sayo"]
Thank you."
[cpg cn=true]


[OnName num="glasses_man"]
「……」
[cpg cn=true]


Just in time to go into the bathroom, I went to the master and offered him a change of clothes.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0084"]
[OnName num="sayo"]
「……」
[cpg cn=true]


However, the master did not accept the change of clothes easily.
[cpg]


[OnName num="masato"]
...uh...um, you know what?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0790"]
[OnName num="sayo"]
I think I'll go with that one today.
[cpg cn=true]


I was anxious to ask if something was wrong, but Master pointed to the one that Ryouhei was holding instead of the change of clothes that I was holding.
[cpg]


[OnName num="glasses_man"]
Huh? Is it this way? Here you go!
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0791"]
[OnName num="sayo"]
Thank you.
[cpg cn=true]


[OnName num="glasses_man"]
'No, no,'
[cpg cn=true]

[FO pos="2/3" time=1000]

[OnName num="masato"]
"........."
[cpg cn=true]


How come... you're usually in these pajamas.
[cpg]

You couldn't have been more wrong in your choice of clothes.
[cpg]

How dare you pick up what he has brought me... master.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BGM f="se" time=1000]
[BG f="b_01_4.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（夜）******************************************************


[OnName num="glasses_man"]
''Ah, ah...Master Ah!
[cpg cn=true]


[VOICE f="Sayo0792"]
[OnName num="sayo"]
Here, purr in a better voice!
[cpg cn=true]


[OnName num="glasses_man"]
Ahiyyy!
[cpg cn=true]




His loud voice reached into the hallway...even if I covered my ears with both hands, I could hear it.
[cpg]

It was painful to watch the two of them in action, so I asked them to stay in the hallway, but...not much changed.
[cpg]

The more I can't see it, the more I'm concerned about it.
[cpg]


[OnName num="masato"]
''Ugh...''
[cpg cn=true]

[BG f="black.ui" time=1000]
;//ＢＫ

I wonder what the hell is going on inside.
[cpg]

I wonder if he's still doing things that I've never done before.
[cpg]

I haven't been treated well lately, and there are no rewards.
[cpg]

No...a reward isn't something you get very often...and with the way I work now, it's just a distant dream.
[cpg]

I'm aware of that. But............
[cpg]


[OnName num="masato"]
 "Uhhhhh ... Master ... Uhhh ..." 
[cpg cn=true]


The master is only concerned about that man with the glasses, and the two of them are getting along well...
[cpg]

I don't know if I'm here or not... but I've become the same whether I am or not.
[cpg]

...Honestly, I'm going to cry.
[cpg]

[BG f="b_01_4.ui" time=1000]
;//ＢＫ

[SE f="se065"]
;//【ＳＥ】『足音』コツン


[OnName num="maid_A"]
Mr. Masato? Are you okay?
[cpg cn=true]


[OnName num="masato"]
''Oh, Mr. Ochiai...''
[cpg cn=true]


As I was crouched in the hallway, Mr. Ochiai called out to me.
[cpg]

It's been a long time since the two of us had a face-to-face conversation like this.
[cpg]


[OnName num="maid_A"]
"...it's hard, isn't it? I know exactly how you feel.
[cpg cn=true]


[OnName num="masato"]
What?"
[cpg cn=true]


[OnName num="maid_A"]
Let me help you heal you.
[cpg cn=true]


[OnName num="masato"]
'Well, no... no, no, no...'
[cpg cn=true]


[OnName num="maid_A"]
''Don't worry, don't worry. I won't tell anyone.
[cpg cn=true]


[OnName num="maid_A"]
And... actually, I'm very good at... teasing.
[cpg cn=true]


[OnName num="masato"]
「……」
[cpg cn=true]




[BG f="black.ui" time=1000]
;//ＢＫ



[STOPBGM]
[BGM f="h1" time=1000]
[BG f="b_06_4.ui" time=1000]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夜）******************************************************


[OnName num="masato"]
''Ahhhhh...Ochiai-san...''
[cpg cn=true]


[OnName num="maid_A"]
How do you like it? My blame will be good, too!
[cpg cn=true]


[OnName num="masato"]
Aaaaah...Mr. Ochiai...that's great, that's great! That's good!
[cpg cn=true]

[BG f="black.ui" time=1000]
;//ＢＫ

[OnName num="masato"]
Ahhhhhhhhhh!
[cpg cn=true]

It's evil.
[cpg]

That's not even an excuse for the word.
[cpg]

But when I think that the master doesn't need me anymore...it's hard, it's hard.
[cpg]

She needs me... and I've taken her up on her offer.
[cpg]


[STOPBGM]
[BG f="b_01_4.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（夜）******************************************************


[OnName num="glasses_man"]
'........................................................................................................................................................
[cpg cn=true]




[BG f="black.ui" time=1000]
;//ＢＫ





--After that, it went on like that for a while.
[cpg]

While Master is training Ryuhei, he runs away and goes to Mr. Ochiai's place...to be comforted.
[cpg]

She gently wraps me up in her arms and gives me the pleasure I seek.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ



[STOPBGM]
[BGM f="h1"]
[BG f="b_06_4.ui" time=1000]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夜）******************************************************


[OnName num="masato"]
"Whew, whew...Mr. Ochiai, you were great today...too. Thank you.
[cpg cn=true]


[OnName num="maid_A"]
''Uh-huh. I can't believe I ejaculated so much after being crushed by a gold ball...Masato-san, you are such a pervert!
[cpg cn=true]


[OnName num="masato"]
''Ahahaha, you know...I get embarrassed when you praise me.
[cpg cn=true]


She lies on her back on the bed, feeling happy and in sexual satisfaction after the act.
[cpg]


[OnName num="maid_A"]
What are we going to do tomorrow?
[cpg cn=true]


[OnName num="masato"]
''Hmmm... what should I do?
[cpg cn=true]

[BG f="black.ui" time=1000]
;//ＢＫ

It's fun, it's pleasant...I couldn't be happier.
[cpg]

After all...I feel like there's a gaping hole in my heart. It doesn't fill up, no matter how good it feels.
[cpg]


[SE f="se016"]
;//【ＳＥ】『扉を開ける』

[WAIT time=600]



[STOPBGM]
[BG f="b_06_4.ui" time=1000]

[OnName num="glasses_man"]
「………」
[cpg cn=true]


[OnName num="masato"]
Huh...? Lyu, Ryuhei-kun...?
[cpg cn=true]


Suddenly, the door opened and people came in, so we hurriedly hid ourselves with the sheets.
[cpg]

[OnName num="maid_A"]
Ryu-chan...
[cpg cn=true]


[OnName num="glasses_man"]
''Senior, the master wants to see you. They want you here right away.
[cpg cn=true]


[OnName num="masato"]
'..........okay.
[cpg cn=true]


His atmosphere and the fact that he was being summoned at this time, I somehow got the idea.
[cpg]

It didn't take long for this affair to be uncovered by the brilliant master.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ



[STOPBGM]
[BGM f="h1" time=1000]
[BG f="b_04_4.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0793"]
[OnName num="sayo"]
...now you know why I'm here, don't you?
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]


The master is in front of me when I am called into the room.
[cpg]

He seemed to be looking the same as usual, but angry...I could feel it enough.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0794"]
[OnName num="sayo"]
Let's hear some excuses, shall we?
[cpg cn=true]


[OnName num="masato"]
'...no, sir.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0795"]
[OnName num="sayo"]
? Don't you have any? Did I just say no?
[cpg cn=true]


[OnName num="masato"]
「はい」
[cpg cn=true]


There is no excuse for what happened this time. Whatever the reason, you are the one who is at fault.
[cpg]

It was also an act of being convinced of that.
[cpg]

And... excuses and all that... don't really matter anymore.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0796"]
[OnName num="sayo"]
So...you have no excuse to tell your master that you've been fucking the maid.
[cpg cn=true]


[OnName num="masato"]
Master... you won't need me anymore.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0797"]
[OnName num="sayo"]
Huh?
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0798"]
[OnName num="sayo"]
'............yes. Apparently, you want to piss me off.
[cpg cn=true]



[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BGM f="h1"]
[BG f="b_04_4.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************


[OnName num="maid_A"]
"Excuse me...miss, what can I do for you...aha!
[cpg cn=true]


[OnName num="masato"]
''Ughhhhhhhh...ooohhhh...ooohhhh...ooohhhh...ooohhhh.
[cpg cn=true]


A few dozen minutes later.
[cpg]

As soon as he entered the room, Ochiai-san, who had been summoned just like me, screamed.
[cpg]


[OnName num="maid_A"]
Wha...wha...what are you doing!
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0799"]
[OnName num="sayo"]
As you can see, I'm giving my servant a Kee-Too spanking.
[cpg cn=true]


I'm tied with a rope, suspended in midair... I'm rocking my body like I'm being rocked in a cradle.
[cpg]

A number of whip marks on his body. Everyone would scream if they were suddenly exposed to such a scene.
[cpg]


[OnName num="masato"]
Whew...whew...whew...
[cpg cn=true]


[OnName num="maid_A"]
''So...it's not like that...playing this hard...it's poor!
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0800"]
[OnName num="sayo"]
Hard? And that's just the beginning. Besides, my servant is so pleased.
[cpg cn=true]


[OnName num="maid_A"]
''Ahh...Masato-san, your cock is amazing...!''
[cpg cn=true]


My body...my crotch...was shaking with pleasure, even though I was given a perfect, no-holds-barred masturbation.
[cpg]

It's the first time in a few months that the master has tortured her, and she has become comfortable enough to ejaculate four times in 10 minutes.
[cpg]

No matter how hard it is...no matter how much it hurts...the body will honestly accept it as pleasure.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0801"]
[OnName num="sayo"]
You couldn't have made him like this.
[cpg cn=true]


[OnName num="maid_A"]
Shoo......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0802"]
[OnName num="sayo"]
If you mess with my toys too much...
[cpg cn=true]


[OnName num="maid_A"]
It's wonderful!!!!
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0803"]
[OnName num="sayo"]
''Heh...?''
[cpg cn=true]


Interrupting Master's words, Mr. Ochiai said with a twinkle in his eye.
[cpg]

[OnName num="maid_A"]
''I'm sorry, miss. My selfishness has made me... uncomfortable.
[cpg cn=true]


Acknowledging and apologizing for her mistake, she bowed her head deeply.
[cpg]

[OnName num="masato"]
''Whew...whew...whew...(What the hell...what's going on?)''
[cpg cn=true]




[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BGM f="se" time=1000]
[BG f="b_04_4.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************


[OnName num="butler"]
Ho!"
[cpg cn=true]


[OnName num="masato"]
"It was...it was...
[cpg cn=true]


[OnName num="butler"]
Dear Masato, take this.
[cpg cn=true]


[OnName num="masato"]
Thank you, Mr. Tanaka.
[cpg cn=true]


Thanks...it seems that there's something going on, and I've been told about it, and for the time being I've been released from the suspension.
[cpg]


[OnName num="maid_A"]
I'm really... sorry.
[cpg cn=true]


Again, she lowered her head.
[cpg]

[OnName num="masato"]
Mr. Ochiai... what in the world is going on...?
[cpg cn=true]


[OnName num="maid_A"]
''Actually, Mr. Masato...you know...I have a pet.
[cpg cn=true]


[OnName num="butler"]
"Pet...?
[cpg cn=true]


[OnName num="maid_A"]
Yes. The...
[cpg cn=true]


She stammered a little and glanced in my direction.
[cpg]

[OnName num="maid_A"]
''I had a pet, like Mr. Masato... a little like the pet he had (my brother)...''
[cpg cn=true]


[OnName num="masato"]
Huh?
[cpg cn=true]


[OnName num="maid_A"]
"When I see Masato-san, I can't help but feel...horny...I can't help it, and I want to...bully her.
[cpg cn=true]


Ochiai said something outrageous.
[cpg]

She is amazed at the presence of her pet (her brother).
[cpg]

It seems that a pet isn't a dog or a cat or anything like that... like me... that person.
[cpg]


[OnName num="maid_A"]
"I'm taking a weekend off to relieve some of the stress, but I just...
[cpg cn=true]


[OnName num="maid_A"]
I think it would be nice to be able to leave play when the period is over...
[cpg cn=true]


Your brother may be more senior than me.
[cpg]

But it's true...I know how hard it is. I know this because I'm in the same position.
[cpg]

It's from the pet's (brother's) point of view, but it's hard to be left alone for a long time.
[cpg]

[OnName num="maid_A"]
I knew it wasn't right, but I couldn't go against my desire...I'm so sorry!
[cpg cn=true]


[OnName num="masato"]
So that's what it was about...
[cpg cn=true]




I mean, she also had a masterly relationship with me...a servant (pet and brother).
[cpg]

But... because you're a live-in at the house, you can't come home every day and train your... pet.
[cpg]

I guess that's where they want me to be...
[cpg]

I was also surprised by the intricate and special circumstances, but that's why he was bullying me, isn't it?
[cpg]

No, I don't have a problem with that, because supply and demand was established.
[cpg]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0804"]
[OnName num="sayo"]
"Well, I understand how you feel... painfully so.
[cpg cn=true]


[OnName num="maid_A"]
''Miss...''
[cpg cn=true]


[OnName num="maid_A"]
I'm really, really sorry about that.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0805"]
[OnName num="sayo"]
It's okay. It's not something to apologize for.
[cpg cn=true]


[OnName num="maid_A"]
''Miss...ahhhhh...ughhhh...ughhhh...ughhhh.
[cpg cn=true]




[SE f="se066"]
;//【ＳＥ】『』キラキラキラ〜


With tears in her eyes, she apologized, and the Master took it in with a bodhisattva-like generosity.
[cpg]

Ochiai apologized several times while being patted on the head.
[cpg]

I want to be rubbed on the head too.
[cpg]

[STOPBGM]
[BGM f="co" time=1000]

[OnName num="butler"]
''Hmmm-hmmm. Somehow... it's all settled.
[cpg cn=true]


[OnName num="masato"]
''Are you okay with it, this atmosphere...there's something familiar about it...?
[cpg cn=true]


It seems that the S's had their own feelings about each other.
[cpg]

If this case can be solved without Ochiai being punished, that's fine.
[cpg]


[OnName num="maid_A"]
''And besides...there was a part of me that was jealous of the Lady too...''
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0806"]
[OnName num="sayo"]
Jealousy? For me?
[cpg cn=true]


[OnName num="maid_A"]
Yes. As a matter of fact, that... new servant, the one with the glasses, is... my...
[cpg cn=true]




[SE f="se067"]
;//【ＳＥ】『扉を開ける』バンッ！


[OnName num="glasses_man"]
"Sis!
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0807"]
[OnName num="sayo"]
"Sis!
[cpg cn=true]


[OnName num="maid_A"]
Ryu-chan!
[cpg cn=true]


[OnName num="masato"]
"Ryu-chan!
[cpg cn=true]




Just when you thought the story was getting into the wrap-up phase, this is where the burglars came in.
[cpg]

It was...a new servant, Ryuhei, who joined the company.
[cpg]

[OnName num="masato"]
"Ryu-chan...well, you can't be...
[cpg cn=true]


[OnName num="glasses_man"]
"Yes...my name is Ryuhei Ochiai. I've just...come up with...my sister's pet!!!!
[cpg cn=true]




[SE f="se067"]
;//【ＳＥ】『』どーん！

[FO pos="2/3" time=1000]
[FG f="CHA01_p2_01_a.ui" method="change_5"  pos="4/4" time=800]

Yes, he has declared himself a pet, and he is the pet and brother of Mr. Ochiai, who has been in the news for some time now.
[cpg]

I knew it was, since they're rushing in at such a good time.
[cpg]


[OnName num="maid_A"]
''Ryu-chan...why...''
[cpg cn=true]


[OnName num="glasses_man"]
It's your sister's fault!
[cpg cn=true]


[OnName num="maid_A"]
!?
[cpg cn=true]


[OnName num="glasses_man"]
"Before I got this job, my sister... she was more of a bully to me. But that time is dwindling, too...
[cpg cn=true]


[OnName num="maid_A"]
I can't help it, it's my job...
[cpg cn=true]


[OnName num="glasses_man"]
I know. I know it's selfish, but the thought of my sister bullying another man is just too much for me to handle.
[cpg cn=true]




Now that his sister was in her current job, he was having a hard time because he had less time to be bullied than before.
[cpg]

When I think of someone else, I feel anxious and angry even more so.
[cpg]

I remembered that feeling too.
[cpg]


[OnName num="glasses_man"]
I decided to work here on my own... and I'm sorry I didn't tell you. But...I couldn't even stand to be there...so I came here to make sure!
[cpg cn=true]


[OnName num="glasses_man"]
''And then your sister... she was making out with this guy... and I was so frustrated...''
[cpg cn=true]


[OnName num="masato"]
"What, me!
[cpg cn=true]


[OnName num="butler"]
There's no one else.
[cpg cn=true]


[OnName num="glasses_man"]
"So I was going to be a little mean to you... to make your master like you...
[cpg cn=true]


[OnName num="maid_A"]
''That's a misunderstanding, Ryu-chan, because even though I'm good friends with Mr. Masato, he was honestly just a consolation person!
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="4/4" time=800]

[OnName num="masato"]
Eeeeeeeeeeeeeeeeeeeeeeeeeeee! That's terrible as hell!
[cpg cn=true]




[OnName num="glasses_man"]
''Ho, really...?''
[cpg cn=true]


[OnName num="maid_A"]
''Yes, because I only think of Mr. Masato as a trash can.
[cpg cn=true]


[OnName num="masato"]
"It's even worse!
[cpg cn=true]


[OnName num="glasses_man"]
"Sis...I...want to spend more time with you. I want you to bully me more!
[cpg cn=true]


[OnName num="maid_A"]
''Ryu-chan...(Uru-ru)''
[cpg cn=true]


[OnName num="glasses_man"]
''Sis...(Uruuuuuu)''
[cpg cn=true]


The two of them exchanged a hot embrace.
[cpg]

[OnName num="maid_A"]
I'm sorry, I'm sorry...I'm sorry Ryu-chan.
[cpg cn=true]


[OnName num="glasses_man"]
I'm sorry, too. But I can't live without my sister...
[cpg cn=true]


[OnName num="maid_A"]
''Me too, me too. I can't live without you, Ryu-chan.
[cpg cn=true]


[FO pos="4/4"]


[SE f="se066"]
;//【ＳＥ】『』キラキラキラ〜


[OnName num="masato"]
"What the hell...?
[cpg cn=true]


Ahh... somehow a second nice space has been formed. It's hard to look directly at it because it's too dazzling.
[cpg]

Or rather, it bothers me that the rant against me has already gone through.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0808"]
[OnName num="sayo"]
Ruh.
[cpg cn=true]


[OnName num="butler"]
Lulu...
[cpg cn=true]


[OnName num="maid_B"]
Lulu-ruu.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0809"]
[OnName num="sayo"]
"That's a good story...
[cpg cn=true]


[OnName num="masato"]
Huh! Why are you crying!
[cpg cn=true]


[OnName num="butler"]
It's a beautiful brotherly love.
[cpg cn=true]


[OnName num="masato"]
Brotherly love! It's jumping over in one foot! Tanaka-san, have you been paying attention? Do you have rotten eyes? Do you want me to refer you to an eye doctor!
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0810"]
[OnName num="sayo"]
Shut up!
[cpg cn=true]




[SE f="se068"]
;//【ＳＥ】『叩く』ペチンッ


[OnName num="masato"]
It hurts.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0811"]
[OnName num="sayo"]
It's a nice place, so keep quiet.
[cpg cn=true]


[OnName num="glasses_man"]
"Sis, please pick on me... this. Here, it's like...well, like always.
[cpg cn=true]


[OnName num="maid_A"]
Yeah. Can you undress your ass? I'm going to go so far as to leave no trace for a week.
[cpg cn=true]


[OnName num="masato"]
"Hey, hey, hey! You in public! No! Get over there! Don't get horny in your master's room!
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0812"]
[OnName num="sayo"]
"Thump...
[cpg cn=true]


[OnName num="butler"]
I'm excited...
[cpg cn=true]


[OnName num="masato"]
"Hey! Don't get your hopes up! Stop, stop, stop!
[cpg cn=true]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BGM f="se" time=1000]
[BG f="b_04_4.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（夜）******************************************************


[SE f="se017"]
;//【ＳＥ】『扉を閉める』バタン


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0813"]
[OnName num="sayo"]
Phew. I guess we're done here, huh? Well, that's good.
[cpg cn=true]


[OnName num="masato"]
「……」
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0814"]
[OnName num="sayo"]
What's going on?
[cpg cn=true]


[OnName num="masato"]
''Ugh...ugh...ugh...ugh...ugh...ugh.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0815"]
[OnName num="sayo"]
! Oh, why are you crying!
[cpg cn=true]


[OnName num="masato"]
I was so scared... so... so scared...
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0816"]
[OnName num="sayo"]
...........................................................................................................................
[cpg cn=true]


[OnName num="masato"]
"My master told me that he didn't like me...that he was going to leave me...that he was afraid...afraid...sad...
[cpg cn=true]


The emotions I had been hoarding began to flow with relief.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0817"]
[OnName num="sayo"]
...come here.
[cpg cn=true]


[OnName num="masato"]
''Ugh, Ugh.''
[cpg cn=true]


Master hugged me gently as I cried like a child.
[cpg]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0818"]
[OnName num="sayo"]
I'm sorry. I've gone too far, too far.
[cpg cn=true]


[OnName num="masato"]
''Ughhhhhh...''
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0819"]
[OnName num="sayo"]
''You've been getting a little carried away lately, so I thought I'd give you a little moxie...''
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0820"]
[OnName num="sayo"]
I'm sorry you had to go through so much. I'm sorry...I'm sorry.
[cpg cn=true]


[OnName num="masato"]
'No, it's not...it's not...I'm...I'm...'
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0821"]
[OnName num="sayo"]
"Don't worry. There's no way I'd dump a cute little servant on you just because of one or two failures.
[cpg cn=true]


[OnName num="masato"]
"Master...
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0822"]
[OnName num="sayo"]
If I get really bored, I'll just throw it away without saying a word.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0823"]
[OnName num="sayo"]
As long as you're willing to serve me, that future won't come.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0824"]
[OnName num="sayo"]
Don't worry...will you be there for me again tomorrow?
[cpg cn=true]


[OnName num="masato"]
''Yes, yes... I give my body and my heart to the master...''
[cpg cn=true]


I continued to cry for a while afterwards.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ





This is the end of the case where the four of them had a complicated intermingling of their feelings.
[cpg]

Ryouhei is no longer the master's servant, and will continue to work as a live-in servant.
[cpg]

I think that one case was settled...
[cpg]


[STOPBGM]
[BGM f="d1" time=1000]
[BG f="b_01_2.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************


[OnName num="glasses_man"]
Oh, thanks.
[cpg cn=true]


[OnName num="maid_A"]
Hi.
[cpg cn=true]


[OnName num="masato"]
Thank you...
[cpg cn=true]


Since then, the two of them have been together everywhere they go (even in the mansion).
[cpg]

It's a bit of a challenge to be able to show them how much you love them morning, noon and night. I'm envious.
[cpg]

But you seem to be doing a good job, so I don't have a problem with that.
[cpg]

[OnName num="masato"]
"Well, sweep, sweep, sweep.
[cpg cn=true]

[BG f="black.ui" time=1000]
;//ＢＫ


[SE f="se016"]
;//【ＳＥ】『扉を開ける』ガチャ

[WAIT time=600]


[BG f="b_06_2.ui" time=1000]
;//【ＢＧ】『使用人の部屋（執事、田中の部屋）』（昼）******************************************************
;//ここは空き部屋の設定



I walked into an empty room where they came out to clean up...
[OnName num="masato"]
It stinks! It smells like sperm! Ventilation, ventilation!
[cpg cn=true]

[STOPBGM]
[BGM f="co" time=1000]

[BG f="black.ui" time=1000]
;//ＢＫ

[SE f="se016"]
;//【ＳＥ】『窓を開ける』ガラッ


There was a tremendous smell in the room.
[cpg]

I was wondering why they came out of this room...totally, those people.
[cpg]

No, maybe I'm not doing my job right.
[cpg]

[BG f="b_06_2.ui" time=1000]

[OnName num="masato"]
''Huh... this place is full of weirdos.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0825"]
[OnName num="sayo"]
You're the most perverted person I've ever met.
[cpg cn=true]


[OnName num="masato"]
Hi! Master...how long have you been there...
[cpg cn=true]


Can you stop creeping up behind me like a ninja, please? I thought my heart was going to skip a beat.
[cpg]

[STOPBGM]
[BGM f="d1" time=1000]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0826"]
[OnName num="sayo"]
What about those two?
[cpg cn=true]


[OnName num="masato"]
''Ah~...it seems like they're getting along.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0827"]
[OnName num="sayo"]
 "... Sunsun ... seems like that ..." 
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0828"]
[OnName num="sayo"]
Keep it clean.
[cpg cn=true]


[OnName num="masato"]
「はい」
[cpg cn=true]

[FO pos="2/3" time=1000]


[SE f="se063"]
;//【ＳＥ】『掃除音』ガタガタ

[WAIT time=600]



[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0829"]
[OnName num="sayo"]
Well, I'm glad it all fell into place.
[cpg cn=true]


[OnName num="masato"]
Both the master and the master...they have a lot of nostalgia.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0830"]
[OnName num="sayo"]
It's not a given. I'm letting a pervert like you live here.
[cpg cn=true]


[OnName num="masato"]
"Ugh... it hurts when you say it to me face-to-face.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0831"]
[OnName num="sayo"]
"But...
[cpg cn=true]


[OnName num="masato"]
「？」
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0832"]
[OnName num="sayo"]
I'm glad the bugs didn't stick around.
[cpg cn=true]


[OnName num="masato"]
I'm at ......."
[cpg cn=true]


Master said with a grin.
[cpg]

[OnName num="masato"]
''Uh, um... master...''
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0833"]
[OnName num="sayo"]
Something.
[cpg cn=true]


[OnName num="masato"]
Well...since the last thing...it's been a bit of a mess...that time was in the middle of it, and there hasn't been any lately...so...
[cpg cn=true]


I'm not sure if it's because of the fact that I'm not the only one who's going to be able to do that.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0834"]
[OnName num="sayo"]
So what? Say it more plainly.
[cpg cn=true]


[OnName num="masato"]
''Goh, master...I want you to bully me too..... Bully me, please...
[cpg cn=true]


Then the corners of her mouth rose more.
[cpg]

[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0835"]
[OnName num="sayo"]
You say you'll do it when I feel like it, and then you order me to do it... you've gotten a lot better.
[cpg cn=true]


But the master is not angry, he seems to be enjoying himself.
[cpg]

[OnName num="masato"]
I'm sorry. But I can't help it... I want it...
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0836"]
[OnName num="sayo"]
A moment ago, I ordered you to clean up this room. Get it done first. After that, I'll do it for you when I feel like it.
[cpg cn=true]


[OnName num="masato"]
I'm afraid...I don't see the point in cleaning.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0837"]
[OnName num="sayo"]
? I wonder why?
[cpg cn=true]


[OnName num="masato"]
''I'm sure the kind-hearted master will have mercy on you. If I do that, I'll make a mess of the room again... and I'll have to clean it twice, and I don't think there's any point.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0838"]
[OnName num="sayo"]
 Couscous. ''Ahahaha, ahahaha, fluffy...''
[cpg cn=true]


The master laughed heartily.
[cpg]

[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0839"]
[OnName num="sayo"]
''Sigh... I'm hungry. I can't believe you're asking me to go that far...you're so impatient.
[cpg cn=true]


[OnName num="masato"]
「……」
[cpg cn=true]


I wordlessly held out my lower half of the body, which already contained a sizzling cock, in front of me.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0840"]
[OnName num="sayo"]
Oh. You've already done this...
[cpg cn=true]


[OnName num="masato"]
"Master...
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0841"]
[OnName num="sayo"]
''Humph, it's a good boy. Well then, today is special.
[cpg cn=true]

[FO pos="2/3" time=1000]

The smell of males and females filled the room. Maybe that's what was going on with me and my master.
[cpg]

It was a different time, a different place...he bullied me on the spur of the moment.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ



[STOPBGM]
[BGM f="co" time=1000]
[BG f="b_00_2.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************


[OnName num="maid_B"]
No, this room stinks.
[cpg cn=true]


[OnName num="maid_C"]
Seriously.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0842"]
[OnName num="sayo"]
「……」
[cpg cn=true]


[OnName num="masato"]
「……」
[cpg cn=true]




[SE f="se040"]
;//【ＳＥ】『蹴る』げしっ


[OnName num="masato"]
"Ouch."
[cpg cn=true]



[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ

[STOPBGM]


[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

;//ＢＫ


[jump storage="ep012.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////
