*start



;#################################################
*Ep005|Water for M
;#################################################

[SCENE id=5]


[stflag jump_scene=0]
[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


[BG f="black.ui" time=1000]
[WAIT time=1500]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]

[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

[BGM f="d1"]

;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[BG f="b_01_2_up.ui" time=1000]

;//レターボックスin
[FACE method="feadin" pos="4/7"]

[SE f=se087 loop=true]
;//【ＳＥ】『洗濯機の音』

[WAIT time=1000]


[window target=true]


The box rattles and shakes up and down and left and right in front of you, It's fine vibration is like a natural vibration.
[cpg]

[OnName num="masato"]
「……………」
[cpg cn=true]


I've always thought that it would feel good to have my pubic area pressed against it.
[cpg]

[OnName num="maid_A"]
'um... um... I wonder what you're doing.
[cpg cn=true]


[OnName num="masato"]
Huh?
[cpg cn=true]

[SE f=se033 loop=true]
;//【ＳＥ】『心音』

I came to my senses when I noticed the maid squinting at me from the entrance.
[cpg]

This is the Misanagi family's laundry.
[cpg]

I have been instructed to do my laundry here today.
[cpg]


[SE f="se028"]
;//【ＳＥ】『慌てる』バタバタ


[OnName num="masato"]
Nah, it's nothing! How can I help you?
[cpg cn=true]


I felt like it was too late to say something like this, but the maid didn't even mention what she had seen and started talking about the requirements.
[cpg]


[stopse g=6]
;//ループse


[OnName num="maid_A"]
''Mr. Masato, I'm sorry... but I'd like to take this with me.
[cpg cn=true]


[OnName num="masato"]
'Oh, yes! I understand!
[cpg cn=true]


[SE f=se078]
;//【ＳＥ】『衣擦れ』

[WAIT time=1000]


[OnName num="masato"]
Whew. And...that's quite a bit too.
[cpg cn=true]


[OnName num="maid_A"]
Yes, it's always hard.
[cpg cn=true]


The clothes we received were quite thick. So this one has to be laundered too.
[cpg]

I still have some laundry waiting for my turn....
[cpg]

[OnName num="maid_A"]
Well then, please.
[cpg cn=true]


[OnName num="masato"]
Yes. I'll take care of it.
[cpg cn=true]


[OnName num="maid_A"]
Couscous. Please make sure you don't slack off.
[cpg cn=true]


[OnName num="masato"]
Ugh...forget it.
[cpg cn=true]


[OnName num="maid_A"]
Oh...your laundry seems to be finished.
[cpg cn=true]


[OnName num="masato"]
'Oh, yes. Thank you, sir.
[cpg cn=true]

[SE f=se005]
;//【ＳＥ】『歩く』

The young maid smiles and waves a fluttering hand as she walks away. She's always been an embarrassing failure to watch.
[cpg]

I've got to work harder too.
[cpg]

Laundry, of course, is the first thing to be done in this house. However, the number of servants is enormous, so there is a lot of laundry for them.
[cpg]

We have to hurry, we're not going to make it in time.
[cpg]

[OnName num="masato"]
Okay, let's go for it!
[cpg cn=true]




[SE f="se005"]
;//【ＳＥ】『歩く』コツコツコツ

[WAIT time=1500]


[OnName num="butler"]
"Oh, Mr. Masato. Just when you think you hear some kind of spirited voice... it's like you've got a lot of energy.
[cpg cn=true]


[OnName num="masato"]
Mr. Tanaka.
[cpg cn=true]


[OnName num="butler"]
Keep up the good work. For your daughter's sake.
[cpg cn=true]


[OnName num="masato"]
''Ha, yes. I'll do my best.
[cpg cn=true]


I put in my best effort to do the laundry, but I think Tanaka-san meant it in a broader sense.
[cpg]

Either way, it's expected of me, so I'm motivated to do my best.
[cpg]

[OnName num="masato"]
Alright, alright!
[cpg cn=true]


[SE f=se087 loop=true]
;//【ＳＥ】『洗濯機の音』


[OnName num="masato"]
「………」
[cpg cn=true]


[OnName num="masato"]
 “... But do your best, civilization's profit instrument!” 
[cpg cn=true]


I couldn't exercise my motivation, and I was running on empty. It was all up to the mass-production washing machine.
[cpg]


[stopse g=6]
;//ループse

[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]



[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[SE f=se005]
;//【ＳＥ】『歩く』
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1000]
[WAIT time=1000]
[stopse g=2]
;//通常se
[window target=true]


[VOICE f="Sayo0428"]
[OnName num="sayo"]
You seem to be doing a good job.
[cpg cn=true]


[OnName num="masato"]
"Oh, Master! Welcome back, madam"
[cpg cn=true]


As I was washing the laundry as ordered, the master appeared.
[cpg]

It looks like he's come home from school. Is it that time already?
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0429"]
[OnName num="sayo"]
You didn't come to pick me up, so I was wondering if you were selling oil somewhere...phew.
[cpg cn=true]


[OnName num="masato"]
I'm sorry.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0430"]
[OnName num="sayo"]
It's not that I'm angry about anything.
[cpg cn=true]


It would have been nice if you'd said so, but I still wanted to greet you.
[cpg]


[OnName num="masato"]
! Master, I'm sweating...
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0431"]
[OnName num="sayo"]
''Hmm...yeah. It's been sunny and hot today.
[cpg cn=true]


When I looked at him, he was sweating quite a bit.
[cpg]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[OnName num="masato"]
Here you go.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0432"]
[OnName num="sayo"]
Oh, thank you.
[cpg cn=true]


He takes a handkerchief from his pocket and hands it over. I'm not in the habit of carrying it around, but Tanaka-san told me to keep it.
[cpg]

I guess that comes in handy at times like this... hmmm.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0433"]
[OnName num="sayo"]
Yes. I'm just saying...
[cpg cn=true]


[OnName num="masato"]
?"
[cpg cn=true]



[FACE method="change_1" pos="2/3"]
As she said that, she lowered the student bag she was holding in her hand...and slipped both hands into her skirt.
[cpg]


[OnName num="masato"]
! Master...what...are you...?
[cpg cn=true]


Don't look. Quickly, I thought so and looked away.
[cpg]


[FG f="CHA01_p4_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0434"]
[OnName num="sayo"]
''Mm-hmm.''
[cpg cn=true]


[SE f="se013"]
;//【ＳＥ】『衣類を脱ぐ』


Even judging by the sounds that reached his ears, it was obvious that she was taking off her clothing.
[cpg]

I don't suppose it's a whim of the master... to be in a place like this again? Thump...thump...thump...thump.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0435"]
[OnName num="sayo"]
Yes, this.
[cpg cn=true]


[OnName num="masato"]
Huh...? Ahhhhhh!
[cpg cn=true]


I returned my gaze, and what I received from the master was..........pants.
[cpg]

What is this... and where did it come from?
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0436"]
[OnName num="sayo"]
I'm soaked with sweat, so you can wash it off by the way.
[cpg cn=true]


[OnName num="masato"]
"........."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0437"]
[OnName num="sayo"]
Are you listening to me?
[cpg cn=true]


[OnName num="masato"]
''Ha, yes! I'm awed! I'll wash it and put it away...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0438"]
[OnName num="sayo"]
I asked.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0439"]
[OnName num="sayo"]
''Oh, and... come to your room as soon as you're done with the laundry.
[cpg cn=true]


[OnName num="masato"]
Yes. I was in awe.
[cpg cn=true]

[STOPBGM]

[SE f=se005]
;//【ＳＥ】『歩く』コツコツ
[FO pos="2/3" time=1500]
[WAIT time=1500]


[OnName num="masato"]
「……」
[cpg cn=true]


I was left alone with my master's pants, which were soaked with sweat.
[cpg]


I don't know what's going on here.
[cpg]

I never thought I would take off my underwear on the spot just because I was sweating and feeling uncomfortable.
[cpg]

I know it's uncomfortable to wear sweat-soaked clothing...why don't you just change in your room...
[cpg]

The fact that she deliberately takes off her underwear in front of her must be provoked.
[cpg]

As evidence of this, my lower body...........
[cpg]

[BG f="b_01_2_up.ui" time=1000]
[WAIT time=1500]

[BGM f="h1"]

[SE f=se033 loop=true]
;//【ＳＥ】『心音』

[WAIT time=1500]

[OnName num="masato"]
"Ugh...no, no, no! Get rid of all evil! It's laundry, you rinse!
[cpg cn=true]


I have to throw this magical genie into the washing machine as soon as possible.
[cpg]

But...
[cpg]


[OnName num="masato"]
............................................................
[cpg cn=true]



It didn't work out so well when you took something fluffy and fragrant from your hand into your nasal cavity along with the air.
[cpg]

I've already been fascinated by the divine weapon, and I've received its great power in my body.
[cpg]

[OnName num="masato"]
''(This, just a moment ago... the master was wearing it, right?)''
[cpg cn=true]


The clothing that protected an important part of the master all day long.
[cpg]

I would like to say thank you for your hard work, but I also want to rip it out of envy. I wouldn't want to waste it on you.
[cpg]

Anyway, these pants have spent time with the Master for a day. That alone is a steep increase in value.
[cpg]

It's the same with Brucella, whose price goes up if you don't wash it.
[cpg]

But that's not all he did... he was stripped naked a while ago. I've already got 7 or 8 zeroes on this one. It's not good.
[cpg]

There's more.
[cpg]

These pants are actually heavy. He's getting heavy with plenty of Master's sweat.
[cpg]

This sweat will probably drip out if you squeeze it. It's worth more than 100 million tons of natural water from Alxx.
[cpg]

On top of that, with the sweat around your vagina, oh my gosh...you're going to get five or six more zeroes.
[cpg]

And then... it's this scent that tickles your nasal passages even from your hand, which is 30 centimeters away from your face.
[cpg]

A floral and exciting master's scent. This guy is awesome.
[cpg]

The smell is quite stimulating. To put it another way, it's a steamy smell that sticks to your nose.
[cpg]

It has a lingering aroma, but also a firm, steaming smell...a rich aroma.
[cpg]

The master attends the ladies' school, where all the rich people gather. I'm sure that if I had just been spending my time normally, I wouldn't have been sublimated to such a scent.
[cpg]

I'm sure they had PE today.
[cpg]

The sweat shed by moving the body in a healthy way. Inside the clothing where humidity rises. The aroma of maturation.
[cpg]

After such a miraculous process, it took one day to complete the whole thing. It's the pants I have now that are giving off this scent. It's inspiring.
[cpg]

I can't put a price tag on these pants any longer. This alone is enough to eat 10 cups of rice.
[cpg]

[OnName num="masato"]
"Ha, ha..."
[cpg cn=true]


Master's pants. Undressed. Sweat wicking. Steaming. Defilement...there were too many elements that would blow my mind.
[cpg]

[OnName num="masato"]
(I'm not having any more patience for this!)
[cpg cn=true]


At that moment, I pressed Master's freshly undressed pants against my face with my own hand, like a pie crust thrown at my face.
[cpg]

[OnName num="masato"]
 "Soooooooooooooooooooooooooooooooooooooooo ... 
[cpg cn=true]


Great. It smells so good. My tongue and head went numb, and in a second, my meat rod swelled to its maximum.
[cpg]

[OnName num="masato"]
''Hmmm...hmmm...hmmm...hmmm...hmmm...master, master...hmmm...hmmm!
[cpg cn=true]


I know I'd be mad if I was caught doing this without a job.
[cpg]

I don't think it can't be helped that I was given such a thing.
[cpg]

It's just that I've given in to lust.
[cpg]

I'm sorry, Master, but I can't stand the thought of handling your pussy.
[cpg]


[SE f="se029"]
;//【ＳＥ】『ベルトとファスナー』カチャカチャ、ジーッ


[OnName num="masato"]
Swoosh...hahhhh...swoosh...hahhhh.
[cpg cn=true]


I sniffed so hard that my lungs and all the oxygen going to my brain smelled like Master's.
[cpg]

She was happy just sniffing it, and her manhood was very happy.
[cpg]

[OnName num="masato"]
"Ha ha, ha...great. I've never smelled anything like it before..."
[cpg cn=true]


He smelled it for a few minutes. Just keep sniffing it like this and you'll ejaculate even if you don't touch the meat stick at all.
[cpg]

So much so that her scent heightens the sexual excitement.
[cpg]

[OnName num="masato"]
Okay, now...
[cpg cn=true]


Honestly, I want to cum once just for the smell and then do something else.
[cpg]

I want to take my time and enjoy it. There are several fun points in the pants.
[cpg]

But there's no time. The master is calling and these pants have to be washed soon. It's a shame.
[cpg]

[OnName num="masato"]
"Master's Sweat..."
[cpg cn=true]


After you've enjoyed the aroma, enjoy it on your tongue. Her lips and tongue shed the sweat that was abundantly contained in the dough.
[cpg]

[OnName num="masato"]
"Chill, chill...chill, chill, chill...chill...chill..."
[cpg cn=true]


Oh, it's sour. But it's delicious. The back of my throat is happy.
[cpg]

[OnName num="masato"]
''Hmmm, hmmm, hmmm...''
[cpg cn=true]


The new stimulation and arousal caused my flesh rod to twitch and shudder. I really feel like I'm going to ejaculate even if I don't touch it like this.
[cpg]

Bliss. It's the perfect time to say that.
[cpg]

But actually, there's still...this higher up. I haven't even touched it yet.
[cpg]

[OnName num="masato"]
''Hah, hah... okay, next, finally... here it is.
[cpg cn=true]


I can't help but swallow my saliva without thinking about it.
[cpg]

You can taste climaxes time and time again with either the aroma or the taste, but you treat it like a stepping stone.
[cpg]

It's such a blasphemy that you end up drinking the rarely available fine wines in one gulp rather than a few.
[cpg]

But you'll have to forgive me for being short on time.
[cpg]

[OnName num="masato"]
''Ahhhh...this...is...my master's...!''
[cpg cn=true]


I slowly flipped my pants over and pushed the inside out...the crotch area.
[cpg]

This is the most sacred place for pants.
[cpg]

The part that gently wrapped and protected the master's delicate parts for a day. The most important part of her, so to speak, is the place she's been in touch with the longest.
[cpg]

If this is not a sanctuary, what will it say? If not, let me know.
[cpg]

[OnName num="masato"]
''Ha, ah... master, I'm really sorry...''
[cpg cn=true]


Apologizing, I smelled my crotch and then fearfully turned my mouth on it.
[cpg]

[OnName num="masato"]
Hmmm...hmmm...hmmm...hmmm...hmmm...hmmm...hmmm...hmmm...hmmm...hmmm...hmmm.
[cpg cn=true]


It was an aroma and taste that cannot be easily described.
[cpg]

There's a little ammonia in the mix, but it turns me on even more.
[cpg]

[OnName num="masato"]
''(Oh, I can't do this... I can't stand a few seconds of this!)''
[cpg cn=true]


Squeak, squeak, squeak.
[cpg]

The cock starts preparing to ejaculate on its own.
[cpg]

If it were true, I would hesitate whether to come while licking the crotch or putting these pants on my dick...but I didn't have time for that.
[cpg]

[OnName num="masato"]
(Oh, it's coming...so much ejaculation!)
[cpg cn=true]


The adrenaline is over-secreted and climaxes with the highest sexual pleasure.
[cpg]

And then...


[stopse g=6]
;//ループse

[STOPBGM]

[SE f=se016]
;//【ＳＥ】『扉を開ける』


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=1000]
[WAIT time=500]

[VOICE f="Sayo0440"]
[OnName num="sayo"]
You're late! How long did you keep me waiting...?
[cpg cn=true]


[OnName num="masato"]
"What..."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo0441"]
[OnName num="sayo"]
"...... what?"
[cpg cn=true]

[SE f=se014]
;//【ＳＥ】『衝撃』

If I had finished my work as soon as I was told, the Master would not have come.
[cpg]

But it has come. It was late, so the master came to check on him and found him.
[cpg]

And then they saw my perverted behavior.
[cpg]

[BGM f="h1"]

[OnName num="masato"]
''Master... ah, this... this...''
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0442"]
[OnName num="sayo"]
「………」
[cpg cn=true]


The ejaculation stopped just in time. Rather, the blood on my head comes down and I'm forcefully pulled back to reality.
[cpg]

This is not the time to ejaculate and feel good.
[cpg]


[VOICE f="Sayo0443"]
[OnName num="sayo"]
It's late, so why don't you bother going to the trouble of visiting...
[cpg cn=true]


[OnName num="masato"]
''Oh, uh...well...that...excuse me!''
[cpg cn=true]


Giri could hear her biting her lip.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0444"]
[OnName num="sayo"]
Ignore what you're saying, you're getting a dick!
[cpg cn=true]


[window target=false]


[SE f=se030]
;//【ＳＥ】『風切音』
[FO pos="2/3" time=800]
[BG f="black.ui" time=800]
[WAIT time=800]
;//ＢＫ

[WAIT time=1000]

;//画面揺れる演出

[SE f=se001]
;//【ＳＥ】『金的』ゴキンッ


[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=500]
[WAIT time=1100]
[BG f="white.ui" time=1]
;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]
[WAIT time=1000]

[BG f="b_01_2_up.ui" time=1000]

;//レターボックスin
[FACE method="feadin" pos="4/7"]

[window target=true]


--I'm not sure what to do about this.
[cpg]

[OnName num="masato"]
''Hiuuuuuuuuu!''
[cpg cn=true]


 Miss, Missimi ... Gili ... 
[cpg]

The unrelenting and strong kick of a piece thrusts into the unprotected crotch.
[cpg]

[OnName num="masato"]
 "Uhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh" 
[cpg cn=true]




;//フラッシュ


[SE f="se026"]
;//【ＳＥ】『射精音』


The blow evoked the sense of ejaculation that had lingered and brought him to a climax.
[cpg]

A strong stimulation that exceeds the state of cumming if the pubic area is stimulated even slightly.
[cpg]

I'm going to spurt my sperm in a big way.
[cpg]

[OnName num="masato"]
''Hmmm, hmmm...ahhh, ahhh...ahhh...ahhh...''
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0445"]
[OnName num="sayo"]
''Wha...?''
[cpg cn=true]


I think Master was surprised that I ejaculated too.
[cpg]

My body shifted reflexively.
[cpg]

Out of fear that she would cum on him if he let her out in her current state, he quickly folded himself up and dropped to his knees on the floor.
[cpg]

No, maybe it was just the pain that got him into that position.
[cpg]

Even though he did that, he still ejaculated mercilessly and released so much sperm that it looked like he was going to impregnate the floor in front of his master's eyes.
[cpg]

[SE f=se062]
;//【ＳＥ】『倒れる』

[window target=false]
[STOPBGM]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2_up.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[BGM f="h1"]
[window target=true]


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0446"]
[OnName num="sayo"]
Stand up.
[cpg cn=true]


I don't know how much time has passed...I'm not sure because of the lingering effects of ejaculation, but the master finally called out to me.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0447"]
[OnName num="sayo"]
Answer me. What were you doing here?
[cpg cn=true]


[OnName num="masato"]
''Well, that's...''
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0448"]
[OnName num="sayo"]
Answer me.
[cpg cn=true]


The master was uncharacteristically scary.
[cpg]


[OnName num="masato"]
''Ugh...o...I was...masturbating...''
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0449"]
[OnName num="sayo"]
You'll know it when you see it. Why were you doing that?
[cpg cn=true]


[OnName num="masato"]
"...wow...they gave me...wow...master's...underwear...I looked at them...I couldn't take it anymore...I was so excited...
[cpg cn=true]


[VOICE f="Sayo0450"]
[OnName num="sayo"]
I looked at my underwear and got horny. I guess so.
[cpg cn=true]


He didn't return the words, but nodded.
[cpg]

To say it out loud again, I feel like I'm doing something outrageously perverted. No, it's actually a perverted act.
[cpg]

I feel embarrassed because I am reminded of that.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0451"]
[OnName num="sayo"]
I'm angry. Do you understand?
[cpg cn=true]


[OnName num="masato"]
"...... yes."
[cpg cn=true]


[VOICE f="Sayo0452"]
[OnName num="sayo"]
Do you know why?
[cpg cn=true]


[OnName num="masato"]
"I did this... in my master's... underwear...
[cpg cn=true]


I don't know if that's the right answer. She didn't say anything about it.
[cpg]


[FG f="CHA01_p4_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0453"]
[OnName num="sayo"]
...let's spank them a little too hard.
[cpg cn=true]


[OnName num="masato"]
「？」
[cpg cn=true]


After a moment's pause and saying so, the Master ordered further.
[cpg]


[VOICE f="Sayo0454"]
[OnName num="sayo"]
Lie on your back right there.
[cpg cn=true]


[OnName num="masato"]
''Ha, yes...''
[cpg cn=true]


I do what I'm told, without ever having to fight back.
[cpg]

*Scene05|Water for M

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ
;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=1]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

;//●ＣＧエロ（雅人＆小夜・顔面騎乗で強制クンニ。尿意をもよおし掛けられ、飲まされる→更にオシオキでパンツ足コキ：洗濯場）ev_06
;//※おしっこプレイ１。おしっこ掛けられたり、飲まされそうになるが飲めずに吐き出してしまう。
;//※最初はパンツを履いた状態。雅人はブリッジっぽい状態で乗られ顔面騎乗。


[STOPBGM]
[BGM f="h1"]

As she lay on her back, she could see her master's underwear hidden in her skirt and her pigtails.
[cpg]


[VOICE f="Sayo0455"]
[OnName num="sayo"]
I'm telling you it's a spanking. What do you expect?
[cpg cn=true]


[OnName num="masato"]
"...! Oh, this is...
[cpg cn=true]


I have no control over my lower body. After all this, I'm already feeling energized even though I've only just come out.
[cpg]


[VOICE f="Sayo0456"]
[OnName num="sayo"]
Don't move.
[cpg cn=true]


[OnName num="masato"]
''Ha, yes...!''
[cpg cn=true]


She gets embarrassed and tries to hide it with her hands, but that too is prevented.
[cpg]


[VOICE f="Sayo0457"]
[OnName num="sayo"]
Don't do anything other than what I tell you to do. That's nice.
[cpg cn=true]


[OnName num="masato"]
Yes..."
[cpg cn=true]


When I say so, Master opened his legs and straddled my head. Just ahead of me, right above me...her crotch wrapped in her underwear.
[cpg]

Next thing you know...it's closing in.
[cpg]

;**【ＣＧ】ev_06_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1500]


[VOICE f="Sayo0458"]
[OnName num="sayo"]
Hmmm.
[cpg cn=true]


[OnName num="masato"]
Muuuuuuuuuuh!
[cpg cn=true]


Master sat on my face as it was. Master's crotch is pressed against her with a grind.
[cpg]


[VOICE f="Sayo0459"]
[OnName num="sayo"]
"You're such a pervert for lusting after your underwear. Well, I knew he was a pervert, but...
[cpg cn=true]


[OnName num="masato"]
''Ugh, Ugh~!''
[cpg cn=true]


[VOICE f="Sayo0460"]
[OnName num="sayo"]
See, this is what you wanted, right? Enjoy it to your heart's content.
[cpg cn=true]


Freshly stripped and used is good, but this is not the time to say, "This is good too...
[cpg]

[OnName num="masato"]
Muuuuuuuuu! Ughhhhhh!
[cpg cn=true]


[VOICE f="Sayo0461"]
[OnName num="sayo"]
"Hmm...shut up. Don't talk. It's loud and ticklish.
[cpg cn=true]


[OnName num="masato"]
''Unh...unh...unh...unh...unh...unh...unh.
[cpg cn=true]


I don't know why in the world I'm doing this.
[cpg]

But...even with something like this, I'm turned on. It gets me excited.
[cpg]

The evidence of this is that the penis, which had regained its vigor, became even stronger as if it was appealing to its master.
[cpg]

;**【ＣＧ】ev_06_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1500]


[VOICE f="Sayo0462"]
[OnName num="sayo"]
Oh, my goodness, you're in such good spirits.
[cpg cn=true]


[OnName num="masato"]
''Oooohhhhhh...''
[cpg cn=true]


[VOICE f="Sayo0463"]
[OnName num="sayo"]
''You know, the simple question is... how can a man be so excited about something as his underwear?
[cpg cn=true]


[OnName num="masato"]
Oooooooooooooooooooo! It's not like that!
[cpg cn=true]


[VOICE f="Sayo0464"]
[OnName num="sayo"]
I don't think there's any element of excitement anywhere compared to a woman in the flesh...I don't know.
[cpg cn=true]


I'm sure it's the difference between the senses of a man and a woman. However, even as I tried to explain it, my master's ass was riding on my face.
[cpg]

By not being able to speak, it becomes the master's monologue.
[cpg]


[VOICE f="Sayo0465"]
[OnName num="sayo"]
I wonder if it smells good. Does that excite you? You were sniffing desperately earlier too, weren't you?
[cpg cn=true]


[OnName num="masato"]
''Oooooooooooooooooooooooooo! (It's not just that, but it's good too!)
[cpg cn=true]


[VOICE f="Sayo0466"]
[OnName num="sayo"]
I get sexual arousal from body odor, or smelling it...I can kind of figure that out...
[cpg cn=true]


[OnName num="masato"]
 (Master's is enough to take the money on its own!)
[cpg cn=true]


[VOICE f="Sayo0467"]
[OnName num="sayo"]
But... you also lick them. I saw it, but... what about it?
[cpg cn=true]


[VOICE f="Sayo0468"]
[OnName num="sayo"]
The underwear I wore all day was unsanitary, and to lick it...I'm like, what's the fun in licking it?
[cpg cn=true]


[OnName num="masato"]
 (Yes!)
[cpg cn=true]


[VOICE f="Sayo0469"]
[OnName num="sayo"]
''You have a considerable perverted taste. Hey?
[cpg cn=true]


[OnName num="masato"]
 (That's...well...uh...hah...what?)
[cpg cn=true]


When I came here, I finally noticed something unusual. Or rather, it's too late.
[cpg]

I was desperately trying to answer the questions my master asked me, and I had forgotten.
[cpg]


[OnName num="masato"]
''ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh.
[cpg cn=true]


I am now being stepped on all over my face by Master's buttocks. Even the air mouths, such as the mouth and nose, are closed.
[cpg]

I can't breathe. In such a state, it is bound to be painful.
[cpg]

There, the Master laughed.
[cpg]

;**【ＣＧ】ev_06_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1500]


[VOICE f="Sayo0470"]
[OnName num="sayo"]
What's the matter? You look...pale, but I don't know if that's just my imagination.
[cpg cn=true]


[OnName num="masato"]
''(It's painful... it's painful, master.)''
[cpg cn=true]


[VOICE f="Sayo0471"]
[OnName num="sayo"]
You seem to have something to say.
[cpg cn=true]


[OnName num="masato"]
''(It's painful, painful, painful.)''
[cpg cn=true]


[VOICE f="Sayo0472"]
[OnName num="sayo"]
Oh, I get it. Are you in pain? You're an idiot... you have to breathe.
[cpg cn=true]


[OnName num="masato"]
''Fuhee...Fuhee...Fuhee...''
[cpg cn=true]


He moved his face and tried desperately to make a gap and breathe, but he only sucked a little... and soon his hips moved again and blocked.
[cpg]


[OnName num="masato"]
'Wooo...oooh...hmmmmm...'
[cpg cn=true]


[VOICE f="Sayo0473"]
[OnName num="sayo"]
Why are you running away? They can smell your favorite underwear, can't they? I think it's more of a reward than an Oshioki.
[cpg cn=true]


[OnName num="masato"]
「ふーっ…うぅーっ…ふぅーっ…」
[cpg cn=true]


[VOICE f="Sayo0474"]
[OnName num="sayo"]
''See, I know you like this. This is what you wanted.
[cpg cn=true]


Deeper and deeper, Master dropped his hips and pushed his hips and crotch harder into his face.
[cpg]


[OnName num="masato"]
Uggghhhh...ughhhh!"
[cpg cn=true]


If we don't keep this up, we will suffocate.
[cpg]

There's no room for this when you're pressed up against your master's crotch... and you can smell it all you want.
[cpg]

It's the only way I can think of to escape.
[cpg]


[VOICE f="Sayo0475"]
[OnName num="sayo"]
Painful? So painful that you're going to die?
[cpg cn=true]


[VOICE f="Sayo0476"]
[OnName num="sayo"]
You seem more pleased with your shabby little thing than you were earlier.
[cpg cn=true]


[OnName num="masato"]
「うぐーっ、うぅーっ…うぅーっ！」
[cpg cn=true]


I didn't even know what she was saying, so I went on a tirade.
[cpg]


[VOICE f="Sayo0477"]
[OnName num="sayo"]
"It can't be helped...I'll step back for a moment. Ready? Just for a second? Just take a firm breath, okay?
[cpg cn=true]


[OnName num="masato"]
"Buh-ha!
[cpg cn=true]


Master lifted his hips slightly, and the hips that were so close together left him and he could breathe.
[cpg]


[VOICE f="Sayo0478"]
[OnName num="sayo"]
Yes, I'm done.
[cpg cn=true]


[OnName num="masato"]
Muguh!
[cpg cn=true]


But it really was a moment. I can't breathe much.
[cpg]

On the contrary, the situation was made worse by the large mouth that I opened to take in a large amount of air and was covered with my ass.
[cpg]


[OnName num="masato"]
Ughhhhhh!
[cpg cn=true]


[VOICE f="Sayo0479"]
[OnName num="sayo"]
;「暫くはこうして居てあげるから、存分に盛りなさい」
[cpg cn=true]

The master is blocking his mouth and he can't breathe well.
[cpg]


[OnName num="masato"]
Fuu-u-u-u-u, Fuu-u-u, Fuu-u-u!
[cpg cn=true]


[VOICE f="Sayo0480"]
[OnName num="sayo"]
"Oh. Hey, you can suck on my crotch...it won't give you any air.
[cpg cn=true]


Even though I knew it, I could only make him pucker his mouth like a goldfish in search of food. I want to breathe, I want to breathe air.
[cpg]

Even with my own mouth full of Master's, pussy through my underwear...I'm not happy now! I don't want it!
[cpg]


[VOICE f="Sayo0481"]
[OnName num="sayo"]
''Hmmm...yes, you can move your mouth more. You might not be able to taste my pussy anymore, you know.
[cpg cn=true]


[OnName num="masato"]
Whew......................................................................................
[cpg cn=true]


Air! Air! Air! I need air!
[cpg]

I don't want to lick your pussy! Give me some air!
[cpg]


[VOICE f="Sayo0482"]
[OnName num="sayo"]
''Ah, huh...hmmm. Here, have some more. No matter how much you smoke, no air will come out of it, so suck on your pussy.
[cpg cn=true]


[OnName num="masato"]
'....................................................................................................................................................
[cpg cn=true]


No, this isn't going to work...if it doesn't go on like this, I really don't know.
[cpg]

Paku... paku... paku. His mouth also gradually stopped working.
[cpg]


[VOICE f="Sayo0483"]
[OnName num="sayo"]
Hmm...you're losing your energy. It's like a fish being raised on land.
[cpg cn=true]


[VOICE f="Sayo0484"]
[OnName num="sayo"]
But in contrast, my manhood is swollen like never before...
[cpg cn=true]


[OnName num="masato"]
''................................................................................................................................................
[cpg cn=true]


I can't, I can't, I really can't...
[cpg]


[VOICE f="Sayo0485"]
[OnName num="sayo"]
I think it's about time.
[cpg cn=true]

[BG f="b_01_2" time=1000]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

Just as his consciousness was fading away, the thing that was blocking his mouth and nose was gone.
[cpg]


[OnName num="masato"]
Buhaaaaaaahhhh! Haha, haha, haha...gheh, gheh gheh...
[cpg cn=true]


The air you take into your lungs is so delicious.
[cpg]

It looks like the master retreated just in time to save the day.
[cpg]


[OnName num="masato"]
''Hah, hah... hah, hah... hah... ah...''
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0486"]
[OnName num="sayo"]
「………」
[cpg cn=true]


Master was standing up with my face straddled and looking down at me.
[cpg]

There are no words.
[cpg]

Her eyes threw something tighter than words at him.
[cpg]

[OnName num="masato"]
''Ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo0487"]
[OnName num="sayo"]
「……え？」
[cpg cn=true]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=2100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************
[window target=true]
[BGM f="h1"]

[OnName num="masato"]
"Hiccup, hiccup...hiccup, hiccup...hiccup...hiccup...hiccup...hiccup...hiccup...hiccup...hiccup.
[cpg cn=true]


I cried so miserably.
[cpg]

[FG f="CHA01_p4_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0488"]
[OnName num="sayo"]
"Oh my gosh, you're crying all of a sudden... like a baby.
[cpg cn=true]


The master was more seriously angry than ever before. That's what I was afraid of.
[cpg]

I was afraid that I would really die if I couldn't breathe, and that's what I was afraid of.
[cpg]

I was afraid that my master would hate me, and that was what I was afraid of.
[cpg]

But most of all... I'm the one who brought this on. I felt so ashamed of myself for being so stupid and weak, I cried.
[cpg]

[OnName num="masato"]
"Hiccup, hiccup...ugh, hiccup...ugh...ugh, hiccup...ugh...ugh.
[cpg cn=true]


[SE f=se078]
;//【ＳＥ】『衣擦れ』

[BG f="b_01_2_up.ui" time=1500]

[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=1500]

;//レターボックスin
[FACE method="feadin_up" pos="4/7"]

[WAIT time=1500]

[VOICE f="Sayo0489"]
[OnName num="sayo"]
'Hey, don't cry. I'm sorry, too. So, don't cry.
[cpg cn=true]


[OnName num="masato"]
''Ugh...I'm sorry, master...I'm sorry, I'm sorry...''
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0490"]
[OnName num="sayo"]
"Good, good. Good boy, good boy.
[cpg cn=true]


[VOICE f="Sayo0491"]
[OnName num="sayo"]
"A perverted, stupid girl who only thinks about making her manhood feel good...
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[VOICE f="Sayo0492"]
[OnName num="sayo"]
But...I don't hate you. I don't like idiots, but I do like idiots.
[cpg cn=true]


[OnName num="masato"]
''I'm sorry, Master...Ugh, Ugh...I'm sorry...I'm sorry...!
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0493"]
[OnName num="sayo"]
''I've been too rough with you too. Reflections. So stop shedding tears.
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

Master folded his knees and sat on the floor, putting my head on his lap and stroking my head as I cried in my sleep.
[cpg]

I'm the one who's to blame. Such kindness of hers brought tears to my eyes again.
[cpg]

As it was, I plopped down in my lap...stroking my head, and Master waited until I had calmed down.
[cpg]


[VOICE f="Sayo0494"]
[OnName num="sayo"]
You've calmed down, haven't you?
[cpg cn=true]


[OnName num="masato"]
'Yes...I'm sorry...I'm sorry...I'm sorry...I'm sorry.
[cpg cn=true]



[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0495"]
[OnName num="sayo"]
I'm angry because I put my own pleasure ahead of my orders... and I'm angry about that.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0496"]
[OnName num="sayo"]
You understand now, don't you?
[cpg cn=true]


[OnName num="masato"]
''Ugh, gulp...yes...''
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0497"]
[OnName num="sayo"]
But I'm going to make my body understand. So I'm still going to continue.
[cpg cn=true]


[OnName num="masato"]
"Huh. Yes, yes... please, please... scold me.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0498"]
[OnName num="sayo"]
"Shush... that's good. That's why you're my servant.
[cpg cn=true]

[FACE method="feadin_out" pos="4/7"]

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＣＧエロ（雅人＆小夜・顔面騎乗で強制クンニ。尿意をもよおし掛けられ、飲まされる→更にオシオキでパンツ手コキ：洗濯場）
[BGM f="h1"]
;**【ＣＧ】ev_06_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1500]

It was in the same state as before, and now it was time for the real Oshioki.
[cpg]


[VOICE f="Sayo0499"]
[OnName num="sayo"]
I'm going to go easy on you a little bit.
[cpg cn=true]


[OnName num="masato"]
"Ha, yes."
[cpg cn=true]


I feel like I was getting enough candy and kindness even in my current state...
[cpg]

The Master isn't just strict or harsh. Compassionate. That's why he's a master.
[cpg]


[VOICE f="Sayo0500"]
[OnName num="sayo"]
"Your drool is making my underwear soggy...
[cpg cn=true]


[SE f="se013"]
;//【ＳＥ】『下着を脱ぐ』シュルッ

;**【ＣＧ】ev_06_c ***********************
[CG id=5 index=3 time=1000]
;***************************************
[WAIT time=1500]


[OnName num="masato"]
''Ah...!''
[cpg cn=true]


[VOICE f="Sayo0501"]
[OnName num="sayo"]
This would be more pleasing, wouldn't it?
[cpg cn=true]


The underwear that had covered and protected her private parts until now was removed. And this time, Master's pussy with no cloth...comes on my face.
[cpg]


[OnName num="masato"]
"Mugu.
[cpg cn=true]


[VOICE f="Sayo0502"]
[OnName num="sayo"]
I'll train you in the spirit of service. Just keep licking until I say yes.
[cpg cn=true]


[OnName num="masato"]
''Huh, huh. Aww, aww, aww, aww...
[cpg cn=true]


[VOICE f="Sayo0503"]
[OnName num="sayo"]
''Huh. Already, it's like this, it's so vibrant... it's an irresistible pervert.
[cpg cn=true]


It's delicious. Master's pussy is delicious. I'd like to keep licking it for the rest of my life.
[cpg]


[OnName num="masato"]
Hmmm, hmmm.
[cpg cn=true]


[VOICE f="Sayo0504"]
[OnName num="sayo"]
"Ah...hmmm...hmmm...yeah, you're good. I keep getting better and better at these things... ahhh.
[cpg cn=true]


[OnName num="masato"]
"Cheep, cheep, cheep.
[cpg cn=true]


[VOICE f="Sayo0505"]
[OnName num="sayo"]
''Huh...huh...huh...huh...more.
[cpg cn=true]


While saying so, the master presses his crotch with a grit.
[cpg]

I do as I'm told and lick up my private parts more carefully and furiously.
[cpg]


[VOICE f="Sayo0506"]
[OnName num="sayo"]
'................................................. N...when I started to feel better, I wanted to...let it out.
[cpg cn=true]


[OnName num="masato"]
"Juppu, hmmm...hmmm?
[cpg cn=true]


[VOICE f="Sayo0507"]
[OnName num="sayo"]
Shush. This is another one of the Oshioki, so take it well.
[cpg cn=true]


[OnName num="masato"]
!
[cpg cn=true]

[SE f="se032"]
;//【ＳＥ】『放尿』

;**【ＣＧ】ev_06_d ***********************
[CG id=5 index=4 time=1000]
;***************************************


じょろろろろろろ〜〜〜っ…。
[cpg]

[OnName num="masato"]
Ugh!
[cpg cn=true]


[VOICE f="Sayo0508"]
[OnName num="sayo"]
What are you going to do now that you can't take care of your master? Servant.
[cpg cn=true]


Master's pee that is forcibly taken out.
[cpg]

Urine came into my mouth without my permission, but the suddenness and the strong ammonia smell made me choke.
[cpg]

[OnName num="masato"]
"Ugh, blah, blah... gah, gah, gah, gah, gah.
[cpg cn=true]


[VOICE f="Sayo0509"]
[OnName num="sayo"]
There's more to come.
[cpg cn=true]


[SE f="se032"]
;//【ＳＥ】『放尿』


It's sloppy ~~~ ...
[cpg]

[OnName num="masato"]
 "Ugh, huh, uh ... ng, ng ... ug ..." 
[cpg cn=true]


[VOICE f="Sayo0510"]
[OnName num="sayo"]
Â"
[cpg cn=true]


This can't be done drastically. He still tries to process a little bit and repeatedly swallows his urine in his mouth.
[cpg]


[VOICE f="Sayo0511"]
[OnName num="sayo"]
"Hmm, that's snappy.
[cpg cn=true]


[OnName num="masato"]
''Huh-uh-uh...''
[cpg cn=true]


[VOICE f="Sayo0512"]
[OnName num="sayo"]
Well? How does it feel to be covered in my husband's urine?
[cpg cn=true]


[OnName num="masato"]
"Huh, huh, huh...well, that's great...
[cpg cn=true]


[VOICE f="Sayo0513"]
[OnName num="sayo"]
"I'm sure you are, pervert. You've been having a blast with the shoddy stuff since earlier.
[cpg cn=true]


I couldn't drink Master's pee, but my flesh sticks were gouged with excitement.
[cpg]


[VOICE f="Sayo0514"]
[OnName num="sayo"]
"Look, since you're the reason I'm so dirty... clean this place up.
[cpg cn=true]


[OnName num="masato"]
"Hey. Mug, chug, chug.
[cpg cn=true]


She licks her master's crotch, which is covered in urine and dirty, with her tongue and cleans it up.
[cpg]

The taste of pee spreads in your mouth. But you can still do it, rather than drink it.
[cpg]


[VOICE f="Sayo0515"]
[OnName num="sayo"]
Do you want me to come over here and get you?
[cpg cn=true]


[OnName num="masato"]
"Huh!
[cpg cn=true]

;**【ＣＧ】ev_06_e ***********************
[CG id=5 index=5 time=1000]
;***************************************
[WAIT time=1500]


I'm sure you'll find that you'll be able to get a better idea of what's going on.
[cpg]

The underwear that I had been smelling until just a few moments ago... is wrapping around my cock.
[cpg]

[OnName num="masato"]
''Sir, Master...?''
[cpg cn=true]


[VOICE f="Sayo0516"]
[OnName num="sayo"]
You've been a pain in the ass, so I'm going to deflate you.
[cpg cn=true]


Shush shush.
[cpg]

And her two legs treat the meat rod.
[cpg]


[OnName num="masato"]
''Ah, ah... master, that's... awesome!
[cpg cn=true]


[VOICE f="Sayo0517"]
[OnName num="sayo"]
Don't rest, move your mouth.
[cpg cn=true]


[OnName num="masato"]
"Yes, sir! Aww, ngh...chug...chug.
[cpg cn=true]


[VOICE f="Sayo0518"]
[OnName num="sayo"]
"It's the underwear you've been sniffing like a madman. How are you feeling?
[cpg cn=true]


[OnName num="masato"]
''Ugh, Ugh, Ugh, Ugh! (It's great, it's great, it's great, it's awesome!)
[cpg cn=true]


[VOICE f="Sayo0519"]
[OnName num="sayo"]
''Ahahaha. I don't know what you're talking about.
[cpg cn=true]


[OnName num="masato"]
 "Juru ... Nchu, Nchu, Chu" 
[cpg cn=true]


[VOICE f="Sayo0520"]
[OnName num="sayo"]
''Hmm, ahhh. Yes, it's good. No matter what, I will faithfully... do what I am told. That's what a servant is.
[cpg cn=true]


シュッシュッシュッ。
[cpg]

Juju Juju.
[cpg]

For a while, the only sound in the room was the licking and rubbing of his privates.
[cpg]


[OnName num="masato"]
Phew. Master, I'm already...ugh...
[cpg cn=true]


[VOICE f="Sayo0521"]
[OnName num="sayo"]
I forgive you. Let it out as it is.
[cpg cn=true]


[OnName num="masato"]
''Ha, ha...yes, I'm going to cum! I'm going to cum now! I'm coming out!
[cpg cn=true]



;//フラッシュ

[SE f="se026"]
;//【ＳＥ】『射精音』
[BG f="white.ui" time=500]
[WAIT time=800]
;**【ＣＧ】ev_06_f ***********************
[CG id=5 index=6 time=1000]
;***************************************
[WAIT time=1000]


--thump, thump, thump, thump, thump!!!!
[cpg]

I was covered with Master's pants, treated with Master's legs...I ejaculated.
[cpg]


[VOICE f="Sayo0522"]
[OnName num="sayo"]
Aha. It's so great, so much male juices are spilling out of my underwear.
[cpg cn=true]


[OnName num="masato"]
''Ahhhhhhhhhh! Ahhhh!
[cpg cn=true]


[VOICE f="Sayo0523"]
[OnName num="sayo"]
''You're sticking your hips out like that... and it's not like you're putting them inside a woman. Are you trying to get me pregnant in my underwear? Couscous.
[cpg cn=true]


[OnName num="masato"]
''Ha, ha...ha...ha...''
[cpg cn=true]


[VOICE f="Sayo0524"]
[OnName num="sayo"]
"Hey. Are you done making out with yourself?
[cpg cn=true]


[OnName num="masato"]
'No, no, of course! I'm going to make your master... feel good about himself! I'm sure you'll be happy to hear that.
[cpg cn=true]


[VOICE f="Sayo0525"]
[OnName num="sayo"]
''Hmm. Oh...yeah. That's a good boy.
[cpg cn=true]


[VOICE f="Sayo0526"]
[OnName num="sayo"]
''Hah, hah, hah...I like meek servants.''
[cpg cn=true]


I licked Master's private parts more fiercely than before. It's not like cleaning, it's about making her feel good and making her cum.
[cpg]

Squeak, squeak, squeak.
[cpg]


[VOICE f="Sayo0527"]
[OnName num="sayo"]
''Ahhhh...hhhh...hhhh...hhhh...hhhh...hhhh.
[cpg cn=true]


[VOICE f="Sayo0528"]
[OnName num="sayo"]
"...hmmm...good...hmmm...I'm about to...hmmm...hmmm...hmmm...hmmm.
[cpg cn=true]


[OnName num="masato"]
"Chug, chug, chug, chug, chug, chug, chug!
[cpg cn=true]




;//フラッシュ


[SE f="se033"]
;//【ＳＥ】『絶頂』
[BG f="white.ui" time=500]
[WAIT time=800]
;**【ＣＧ】ev_06_g ***********************
[CG id=5 index=7 time=1000]
;***************************************
[WAIT time=1000]


--bump, bump, bump, bump! thump... thump, thump, thump!
[cpg]


[VOICE f="Sayo0529"]
[OnName num="sayo"]
''Aaahhhhhhhhhhhhhhhhhhhhhh!!!!''
[cpg cn=true]


[VOICE f="Sayo0530"]
[OnName num="sayo"]
Hahahahaha.............................................................................................................. I'll give you a compliment.
[cpg cn=true]


[OnName num="masato"]
Thank you very much.
[cpg cn=true]


This is how I thought that Oshioki was over for the time being.
[cpg]


[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[FACE method="feadin_in" pos="4/7"]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ＢＫ
[window target=true]


[SCENE id=4]
[ENDPARTIAL]


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1500]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="sl"]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[SE f=se013]
;//【ＳＥ】『服を着る音』シュルッ

[window target=true]


After Osioki was done, the master arranged the mess of his clothes. I'm sweeping the dirty floor.
[cpg]

[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0531"]
[OnName num="sayo"]
Hey, stand there.
[cpg cn=true]


[OnName num="masato"]
「は、はい」
[cpg cn=true]


Master said as he prepared himself.
[cpg]

I startled myself, wondering if they're still going to make me squeal.
[cpg]


[VOICE f="Sayo0532"]
[OnName num="sayo"]
Don't you dare move.
[cpg cn=true]


[OnName num="masato"]
Master, what are you...?
[cpg cn=true]


I'm exposed from the waist down because I started cleaning without changing my clothes.
[cpg]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[FG f="CHA01_p5_02_a.ui" method="change_3"  pos="2/3" time=800]


The master made his lower body put on the pants he had used earlier.
[cpg]


[OnName num="masato"]
Huh! It's cold!
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0533"]
[OnName num="sayo"]
"It will be my own. Be patient.
[cpg cn=true]


As she moves unresistingly, I put on a woman's underwear (goo goo goo) from myself as well.
[cpg]

And then the master watches as he licks around the scene.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0534"]
[OnName num="sayo"]
''Hmmm. You look even more atrocious than I imagined...
[cpg cn=true]


[OnName num="masato"]
Please don't look at me like that...
[cpg cn=true]


More importantly, why the hell are you doing this?
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0535"]
[OnName num="sayo"]
'Come to your room as soon as you've finished sweeping the floor. I'm dressed like that.
[cpg cn=true]


[OnName num="masato"]
''Yes, I'm awed...''
[cpg cn=true]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_01_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

[window target=true]

[SE f=se005]
;//【ＳＥ】『歩く』

[VOICE f="Sayo0536"]
[OnName num="sayo"]
「田中さん」
[cpg cn=true]


[OnName num="butler"]
Yes, sir.
[cpg cn=true]


[VOICE f="Sayo0537"]
[OnName num="sayo"]
Let someone else do the laundry, please.
[cpg cn=true]


[OnName num="butler"]
I'm sorry.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0538"]
[OnName num="sayo"]
I'm sorry. Please.
[cpg cn=true]


[SE f=se005]
;//【ＳＥ】『歩く』

[move from="2/3" to="5/3" ease="easeInOutSine" time=2000]

[WAIT time=1500]


[OnName num="butler"]
(Masato is having a hard time too, isn't he?) Well, this time it's rust from the body...)
[cpg cn=true]




[FO pos="5/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2500]
;//ＢＫ

[SE f=se034]
;//【ＳＥ】『ノック』

[WAIT time=2000]


[VOICE f="Sayo0539"]
[OnName num="sayo"]
「どうぞ」
[cpg cn=true]


[OnName num="masato"]
Excuse me.
[cpg cn=true]


[window target=false]

[BG f="b_04_2.ui" time=1500]

;//【ＢＧ】『小夜の部屋』（昼）******************************************************

[SE f=se016]
;//【ＳＥ】『扉を開ける』

[WAIT time=2000]

[window target=true]

[OnName num="masato"]
Thank you for waiting.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0540"]
[OnName num="sayo"]
Hmm.
[cpg cn=true]


As I finished cleaning up, I visited the room with my master's pants, which were exactly the same as before...covered in dirt and cum.
[cpg]

The servants passing by also said, "What's going on now? He was looking at me like, "Oh, my God. It's a good thing they don't despise you.
[cpg]

I'm sure this is part of the punishment.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0541"]
[OnName num="sayo"]
Now...well...then explain to me why you did what you did...
[cpg cn=true]


[OnName num="masato"]
Yes..."
[cpg cn=true]


Rather than being extra angry, it seems that the master called me in to make me explain exactly how I got into that situation.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0542"]
[OnName num="sayo"]
You're going to tell me everything... truthfully and honestly.
[cpg cn=true]


[OnName num="masato"]
''Ugh...yes...''
[cpg cn=true]


It can't be helped. In front of her command, shame and such petty things must be discarded.
[cpg]

[STOPBGM]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ


As you said, I was honest with you about everything. And honestly... all of it.
[cpg]

What's more, she also gave an impassioned speech about how wonderful her master's pants were. I'm an idiot...
[cpg]

[window target=false]

[BG f="b_04_2.ui" time=1500]

[WAIT time=2500]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************

[BGM f="h1"]
[window target=true]
[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]

[VOICE f="Sayo0543"]
[OnName num="sayo"]
「………」
[cpg cn=true]


When Master listened to me, his gaze occasionally swam and his expression became tense.
[cpg]

She seems to be withdrawing a little too. Yeah, I guess so.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0544"]
[OnName num="sayo"]
Hmmm...hmmm...hmmm...hmmm...hmmm...hmmm...hmmm...hmmm...wait a minute...
[cpg cn=true]


[VOICE f="Sayo0545"]
[OnName num="sayo"]
''Ugh...I'm a little dizzy...''
[cpg cn=true]


[OnName num="masato"]
Are you okay?
[cpg cn=true]


I'm not in a position to say that. Then Master put his hand forward and made me restrain him with actions rather than words.
[cpg]


[VOICE f="Sayo0546"]
[OnName num="sayo"]
"Well, I understand the situation. Just in case... just in case. Just in case...
[cpg cn=true]


[OnName num="masato"]
「……はい」
[cpg cn=true]


He doesn't seem to have the energy to be angry.
[cpg]

[FG f="CHA01_p4_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0547"]
[OnName num="sayo"]
(Hmmm...I knew he was a pervert, and I adopted him for that reason, but...how should I put it, he's a pervert that's hard to take.
[cpg cn=true]


[VOICE f="Sayo0548"]
[OnName num="sayo"]
''(I somehow don't understand how this is going to end... I have to discipline him as a master...)''
[cpg cn=true]


[OnName num="masato"]
......"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
As I waited intently for his next words, I noticed that Master's expression had changed.
[cpg]

It's as if I've come up with something.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0549"]
[OnName num="sayo"]
Come to think of it, I had something interesting to say...
[cpg cn=true]


[OnName num="masato"]
「？」
[cpg cn=true]

[VOICE f="Sayo0550"]
[OnName num="sayo"]
'Do you have ten cups of rice in my underwear? I don't know if it was. You can eat it, right?
[cpg cn=true]


[OnName num="masato"]
''Um, um...''
[cpg cn=true]

[STOPBGM]

[FACE method="change_2" pos="2/3"]
The master cocked his head with a grin when he saw my dismay.
[cpg]


[VOICE f="Sayo0551"]
[OnName num="sayo"]
It can be eaten, can't it?
[cpg cn=true]


[OnName num="masato"]
''Aww...''
[cpg cn=true]


[SE f="se035"]
;//【ＳＥ】『指パッチン』パチン

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0552"]
[OnName num="sayo"]
''Then actually, you should try it. Ten bowls of rice...
[cpg cn=true]


[BGM f="co"]


[SE f="se016"]
;//【ＳＥ】『扉が開く』ガチャ


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0553"]
[OnName num="sayo"]
"A bowl of rice, please.
[cpg cn=true]

[SE f="se036"]
;//【ＳＥ】『カート』ガラガラガラ、ガタガタガタ
[WAIT time=1500]


When Master gave the signal, the maids and butlers, who had been waiting for how long, brought the rice cooker on a cart.
[cpg]

[OnName num="masato"]
「……」
[cpg cn=true]


I've been asked to do something outrageous. But I can't and won't go against it.
[cpg]

As I was told, I had to go into the task of putting white rice in my stomach with a side dish of Master's pants (No. 2), which were once again undressed in front of me...
[cpg]


[STOPBGM]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_04_3.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『小夜の部屋』（夕方）******************************************************


[SE f=se037]
;//【ＳＥ】『食器の音』

[WAIT time=1500]


[SE f=se037]
;//【ＳＥ】『食器の音』

[WAIT time=1500]

[SE f=se038]
;//【ＳＥ】『食器を置く音』カチャーン

[WAIT time=1500]


[window target=true]


[OnName num="masato"]
Ugh................................................................
[cpg cn=true]


[SE f="se038"]
;//【ＳＥ】『食器を置く音』カチャーン




[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0554"]
[OnName num="sayo"]
「……………」
[cpg cn=true]

[SE f="se002"]
;//【ＳＥ】『時計の音』カッチコッチ


[OnName num="masato"]
"..............."
[cpg cn=true]




;//ここは後で名前の順番を入れ替えて下さい

[BGM f="co"]

[VOICE f="ExSayo0001"]
[OnName num="masato&sayo"]
(Oh, I ate it...)
[cpg cn=true]


[SE f=se011]
;//【ＳＥ】『どどーん』

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0555"]
[OnName num="sayo"]
''(You're kidding, I said it with the intention of disciplining you...)
[cpg cn=true]


[OnName num="masato"]
(It was more like a half-joke, a rant from a sexual rage...)
[cpg cn=true]


However, ten bowls of white rice fell into my stomach. It's surprisingly possible.
[cpg]

However, the master was also surprised that it was different from the plan. Or rather, I feel like I'm pulling back a bit again.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]

[VOICE f="Sayo0556"]
[OnName num="sayo"]
 I don't get it! I don't know what to do!
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

[VOICE f="Sayo0557"]
[OnName num="sayo"]
Eat it! I usually eat all of it! It's crazy, right? Because of the pants! The food... it's my pants! It's funny, it's funny! It's crazy, isn't it?
[cpg cn=true]


Master... you're a little out of character. This is Bremble.
[cpg]


[OnName num="masato"]
''Master, please calm down...''
[cpg cn=true]


[FG f="CHA01_p4_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0558"]
[OnName num="sayo"]
"Calm down!
[cpg cn=true]


No. I'm distraught.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0559"]
[OnName num="sayo"]
''Huh, huh..........................
[cpg cn=true]


[OnName num="masato"]
Wha...excuse me. I'm really...but I'm sorry.
[cpg cn=true]


[VOICE f="Sayo0560"]
[OnName num="sayo"]
「………」
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

[VOICE f="Sayo0561"]
[OnName num="sayo"]
"No, no...you just did what I told you to do...yeah, yeah...I'm...I'm...it's my fault. I was just wrong in my perception. Um...
[cpg cn=true]


Oh, the Master is a little down on his feet because of me.
[cpg]

How incompetent I am.
[cpg]

[FACE method="change_6" pos="2/3"]

[VOICE f="Sayo0562"]
[OnName num="sayo"]
''Whew...''
[cpg cn=true]


Ah, the mental unity in that pose where the master seems to be climbing to some heights!
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0563"]
[OnName num="sayo"]
I see, I understand.
[cpg cn=true]


[OnName num="masato"]
What can I do for you, sir?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0564"]
[OnName num="sayo"]
"For perverts like you, it's not a joke... your underwear is a meal.
[cpg cn=true]


[OnName num="masato"]
「……」
[cpg cn=true]


[VOICE f="Sayo0565"]
[OnName num="sayo"]
There was a scene like that in an anime I watched a long time ago, where you eat white rice with the aroma of cooking. Surely it's something like that, isn't it?
[cpg cn=true]


[VOICE f="Sayo0566"]
[OnName num="sayo"]
Then... at least once a month, I'll make a special meal menu for you with 'underwear and white rice'.
[cpg cn=true]


[OnName num="masato"]
''Eh, that... master! I didn't do that...
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0567"]
[OnName num="sayo"]
Come on, don't be shy. I'm trying to understand your tastes. So it's good to be meek.
[cpg cn=true]


[OnName num="masato"]
"Master!
[cpg cn=true]


Even if you say that with such a merciful expression like the Virgin, I'm confused!
[cpg]

No, it's not... no, it's not that, but it's still not right! Listen to me!
[cpg]


[FG f="CHA01_p4_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0568"]
[OnName num="sayo"]
It's also the master's duty. It's to keep my servant from making another mistake... and to discipline you. You know that, don't you?
[cpg cn=true]


[OnName num="masato"]
''That, of course...I understand. But...
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0569"]
[OnName num="sayo"]
I'm sorry. You don't like pants!
[cpg cn=true]


[OnName num="masato"]
No, I love it!
[cpg cn=true]


[VOICE f="Sayo0570"]
[OnName num="sayo"]
What would you do if a week's worth of pants were to be shoved into your mouth with or without warning!
[cpg cn=true]


[OnName num="masato"]
Munchy Munchy Munchy Munchy!!!!!
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0571"]
[OnName num="sayo"]
I love those pants! I'm telling you, I'm offering it to you once a month! How do you like it?
[cpg cn=true]


[OnName num="masato"]
I'm so happy that I can make my cock squirt milk!
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0572"]
[OnName num="sayo"]
 I'm not complaining. Then it's decided.
[cpg cn=true]


[OnName num="masato"]
''Ha, ha.......yes, of course.
[cpg cn=true]


It was an unexpected turn of events, and it turned out to be a terrible thing.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0573"]
[OnName num="sayo"]
By the way... do you have a preference for underwear?
[cpg cn=true]


[OnName num="masato"]
Yes?"
[cpg cn=true]


[VOICE f="Sayo0574"]
[OnName num="sayo"]
The design, the fabric... and who is wearing it is also important. I have women in my house who are in their twenties and fifties or so, so if you have a preference for age, there's a certain amount...
[cpg cn=true]


[OnName num="masato"]
'Whoa!' And no, not particularly! I'm that pants omnivore, so... anything is fine!
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo0575"]
[OnName num="sayo"]
 So there's such a division...
[cpg cn=true]


[OnName num="masato"]
''Besides, I want Master's! I'd rather not have anything but a master!
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0576"]
[OnName num="sayo"]
 Okay, I get it. You don't have to shout with all your strength, I can hear you...
[cpg cn=true]


[OnName num="masato"]
Ha! S, excuse me!
[cpg cn=true]


I felt incredibly sorry, but I also felt like I had to ask you to give me a break.
[cpg]

[FG f="CHA01_p4_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0577"]
[OnName num="sayo"]
Well, then...I'll give you mine...sometimes. But I'll take the money for the underwear out of your paycheck.
[cpg cn=true]


[OnName num="masato"]
What?"
[cpg cn=true]


[VOICE f="Sayo0578"]
[OnName num="sayo"]
I'm not lending you anything, I'm really giving you my underwear.
[cpg cn=true]


[OnName num="masato"]
''Soooooooo...is it okay if I take Master's pants?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0579"]
[OnName num="sayo"]
I don't want them to put me back.
[cpg cn=true]


You're right.
[cpg]


[VOICE f="Sayo0580"]
[OnName num="sayo"]
I'm sure you're going to use it for nasty things... but do what you want with what I give you.
[cpg cn=true]


[OnName num="masato"]
''Ha, yes! Thank you so much!
[cpg cn=true]


[VOICE f="Sayo0581"]
[OnName num="sayo"]
So don't ever do anything like what you did today in your other underwear again.
[cpg cn=true]


[OnName num="masato"]
Of course! Of course!
[cpg cn=true]


Thus, the case had been settled somehow.
[cpg]


[STOPBGM]

;//ＢＫ
[window target=false]

[FO pos="2/3" time=1000]

[BG f="black.ui" time=1000]
[WAIT time=2000]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="d1"]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[BG f="b_01_2_up.ui" time=1500]
;//レターボックスin
[FACE method="feadin_up" pos="4/7"]

[WAIT time=1500]

[window target=true]

The servants are servants, and they have a place to eat. I'm mostly here too.
[cpg]

[OnName num="masato"]
''Hey...um...my side dishes...''
[cpg cn=true]


[OnName num="maid_B"]
That's why the young lady says she doesn't need it today... just white rice.
[cpg cn=true]


I don't think this is...
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』コツコツ
[WAIT time=1500]


I felt a sign of a person behind me, and there was the Master.
[cpg]

[OnName num="masato"]
''Sir, Master...!''
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0582"]
[OnName num="sayo"]
It's getting late.
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

Shhhhhhhhhhhhhhhh...............................................
[cpg]

Master has his underwear stripped in front of him and placed on his head.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0583"]
[OnName num="sayo"]
「はい」
[cpg cn=true]


[OnName num="masato"]
''Wha...?''
[cpg cn=true]


[OnName num="maid_C"]
''Hey, young lady! How outrageous!
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo0584"]
[OnName num="sayo"]
You promised me. It's for this month... and use it with care.
[cpg cn=true]


[FO pos="2/3" time=1000]
[SE f=se005]
;//【ＳＥ】『歩く』コツコツ

With that said, the no-pants master leaves.
[cpg]

[OnName num="masato"]
(Master.........yes, thank you very much.)
[cpg cn=true]


As promised, the master volunteered his underwear.
[cpg]

Once a month, I have to eat rice with my master's underwear by my side while people around me look at me strangely.
[cpg]



[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

[jump storage="ep006.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
