*start



;#################################################
*Ep003|Big M and Little S
;#################################################

[SCENE id=3]


[stflag jump_scene=0]
[window target=false]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep002で発生	ジャンプしてきた場合奉仕ルートで固定
[stflag gohome_flag=1]
[stflag pets_flag=0]
[endif]

[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1500]
;//ＢＫ
[SE f=se018]
;//【ＳＥ】『鳥の鳴き声』朝チュン
[WAIT time=1000]

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


;//【ＢＧ】『使用人の部屋（雅人の部屋）』（朝）******************************************************


;//※日本家屋じゃないからお屋敷とは言わない気がする。洋館の場合は何て言うんだろう？


[WAIT time=1000]

[BGM f="sl"]


[window target=true]

[OnName num="masato"]
"Wow...morning. We need to get ready early...
[cpg cn=true]



It was just the third morning of my visit to this mansion. Today, the real work and live-in life begins.
[cpg]

The two days are over with moving, greeting other butlers and maids, and explaining the mansion.
[cpg]

[SE f=se016]
;//【ＳＥ】『扉を開ける』ガチャ

[BG f="b_01_1.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『豪邸、廊下』（朝）******************************************************


;//ここから小夜の喋り方が本来のものに。丁寧語は殆ど無い？


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0105"]
[OnName num="sayo"]
"Brunark~, Brunark~!
[cpg cn=true]


You...Master is calling out some kind of special attack-ish words in succession.
[cpg]

I don't know if it's okay. I wonder if I have suddenly developed middle-age disease.
[cpg]

[OnName num="masato"]
Master...good morning.
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0106"]
[OnName num="sayo"]
Good morning.
[cpg cn=true]


[OnName num="masato"]
How can I help you?
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[VOICE f="Sayo0107"]
[OnName num="sayo"]
''Yeah...I couldn't see any Brunark...''
[cpg cn=true]


I wonder if it's a name for something that appears to be real.
[cpg]

[OnName num="dog"]
Woof!
[cpg cn=true]


[OnName num="masato"]
"A dog?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0108"]
[OnName num="sayo"]
Brunark. Where the hell have you been? All right, all right.
[cpg cn=true]


I never thought it was a pet name.
[cpg]

[OnName num="masato"]
It's adorable."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0109"]
[OnName num="sayo"]
I'm sure it is. We've been together since we were little.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0110"]
[OnName num="sayo"]
Yes. You've come to just the right place.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0111"]
[OnName num="sayo"]
Come here for a minute.
[cpg cn=true]


[OnName num="masato"]
Yes?
[cpg cn=true]


I wondered what they were going to do to me, but it turned out to be a big deal.
[cpg]


[FO pos="2/3" time=1000]
[window target=false]

[SE f=se005]
;//【ＳＥ】『歩く』
[STOPBGM]


[BG f="black.ui" time=1000]
[WAIT time=1500]

[transition target={true} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_1.ui" time=1]

[SE f=se017]
;//【ＳＥ】『扉を閉める』
[WAIT time=1]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『小夜の部屋』（朝）******************************************************

[BGM f="h1"]
[window target=true]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0112"]
[OnName num="sayo"]
"Speaking of which... since you're both a servant and a pet, let's get a room for that...
[cpg cn=true]


The kennel in the corner of the master's room is given to him.
[cpg]

[OnName num="masato"]
It's terrible.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0113"]
[OnName num="sayo"]
I guess that's as good as it gets.
[cpg cn=true]


The kennel itself was gorgeous.
Incidentally, the name of the dog, Corgi, is Brunark. Why do you look so good?
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0114"]
[OnName num="sayo"]
Well, it's a dog's house... so you can't.
[cpg cn=true]


[OnName num="masato"]
''What, you were joking...''
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0115"]
[OnName num="sayo"]
I was pretty serious, though.
[cpg cn=true]


[OnName num="masato"]
''Huh...''
[cpg cn=true]


Let's not offend the master.
[cpg]

;//※下僕の場合///////////////////////////////

[if exp={getFlagValue("gohome_flag") == 1 }]

[OnName num="masato"]
It's adorable."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo109"]
[OnName num="sayo"]
We've been together since we were little.
[cpg cn=true]


[OnName num="masato"]
You're serving the master. You're one of them.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo110"]
[OnName num="sayo"]
Don't be an idiot.
[cpg cn=true]


What, are you saying that I'm more important than...?
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo111"]
[OnName num="sayo"]
"She's my family. You're a servant. This child is the superior one, so be respectful.
[cpg cn=true]


[OnName num="masato"]
'...........yes.
[cpg cn=true]

[endif]
;//※下僕の場合ーここまで//////////////////////////////




;//[FO pos="2/3" time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1500]
;//;//ＢＫ
;//
;//
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[BG f="black.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_04_1.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[STOPBGM]
;//
;//[WAIT time=100]
;//
;//[WAIT time=100]
;//;//【ＢＧ】『小夜の部屋』（朝）******************************************************



[FG f="CHA01_p4_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0119"]
[OnName num="sayo"]
Well, let's get started, shall we?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0120"]
[OnName num="sayo"]
I didn't call you here to make small talk.
[cpg cn=true]


[OnName num="masato"]
What do you mean...?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0121"]
[OnName num="sayo"]
''Humph. Since you're going to serve me here, you'll have to make it to my liking first.
[cpg cn=true]


[OnName num="masato"]
'............what?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0122"]
[OnName num="sayo"]
Â"
[cpg cn=true]


;//●ＣＧエロ（雅人＆小夜・ちんぐり返し状態でキレイキレイプレイ：小夜の部屋）ev_03（※ex01同一CG）
;//※後に別のシチュエーションでも使用
;//※軽く言葉責め入れる。下準備としてちん毛や玉毛をむしられる

[STOPBGM]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="h1"]

;**【ＣＧ】ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sayo0123"]
[OnName num="sayo"]
This is the second time I've seen Seriously, but...
[cpg cn=true]


[VOICE f="Sayo0124"]
[OnName num="sayo"]
I guess I'm just not good enough.
[cpg cn=true]


As for the pubic story, I have no words to return it because it's true.
[cpg]

[VOICE f="Sayo0125"]
[OnName num="sayo"]
It's a child's penis, How do you satisfy a woman with this?
[cpg cn=true]


[OnName num="masato"]
"I don't know...
[cpg cn=true]


[VOICE f="Sayo0126"]
[OnName num="sayo"]
'Oh, I'm sorry. Come to think of it, you were a virgin.
[cpg cn=true]


My body trembles at the words, like they're tingling with needles.
[cpg]


[VOICE f="Sayo0127"]
[OnName num="sayo"]
I like it a lot, don't I? This cock...
[cpg cn=true]


[OnName num="masato"]
Are you sure...?
[cpg cn=true]


[VOICE f="Sayo0128"]
[OnName num="sayo"]
Yeah... Pretty things...
[cpg cn=true]


[SE f="se019"]
;//【ＳＥ】『毛を抜く』ブチブチ

;**【ＣＧ】ev_03_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="masato"]
Ouch! Ouch!
[cpg cn=true]


[VOICE f="Sayo0129"]
[OnName num="sayo"]
Humph! Now it's to my liking.
[cpg cn=true]


[OnName num="masato"]
''Ugh... you don't have to do anything up here...''
[cpg cn=true]


[VOICE f="Sayo0130"]
[OnName num="sayo"]
"I don't want to be pale. I don't feel good when I touch or lick them.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


No way... could such a situation be possible?
[cpg]


[VOICE f="Sayo0131"]
[OnName num="sayo"]
Oh, unexpected?
[cpg cn=true]


[OnName num="masato"]
Yes..."
[cpg cn=true]


[VOICE f="Sayo0132"]
[OnName num="sayo"]
Yeah, If you're being a good boy, you might be able to do that.
[cpg cn=true]


Okay, I'll be a good boy!
[cpg]


[VOICE f="Sayo0133"]
[OnName num="sayo"]
Then the next one...
[cpg cn=true]


[OnName num="masato"]
It's not over yet!
[cpg cn=true]

[window target=false]
[transition target={true} rule="moya.webp" color={0xffffffff} time=500]
[WAIT time=1100]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0xffffffff} time=1]
[WAIT time=1]
[window target=true]


[BG f="b_04_1.ui" time=1000]
[WAIT time=1000]

[BGM f="sl"]
[WAIT time=100]
;//【ＢＧ】『小夜の部屋』（朝）******************************************************


[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0134"]
[OnName num="sayo"]
Okay, that's perfect.
[cpg cn=true]


[OnName num="masato"]
''Huh, huh...''
[cpg cn=true]


My lower half of my body was cleaned by Master.
[cpg]

[OnName num="butler"]
It's about time, my lady.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0135"]
[OnName num="sayo"]
I understand, Let's go.
[cpg cn=true]


[OnName num="masato"]
Where are you going?
[cpg cn=true]


[VOICE f="Sayo0136"]
[OnName num="sayo"]
Academy.
[cpg cn=true]


I see, it's something you would naturally notice if you saw this outfit... Master was still a student.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0137"]
[OnName num="sayo"]
It's a fun place, but it's also a hassle to go to every day...
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0138"]
[OnName num="sayo"]
Plus, I just got a new toy.
[cpg cn=true]


Is that about me?
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0139"]
[OnName num="sayo"]
Maybe I should take the day off from school today.
[cpg cn=true]


[OnName num="butler"]
No, ma'am.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0140"]
[OnName num="sayo"]
.......yes, yes! I know what I'm doing!
[cpg cn=true]


The Master's slightly childish reaction was unexpected. However, considering its appearance, this might be the normal one.
[cpg]

[OnName num="butler"]
The young lady is a bit of a... recluse.
[cpg cn=true]


[OnName num="masato"]
Is that so...?
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0141"]
[OnName num="sayo"]
I can hear you.
[cpg cn=true]



The master drove to the school in a car driven by Mr. Tanaka.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1500]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=2500]
;//ＢＫ

;//夕方

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0142"]
[OnName num="sayo"]
I'm home.
[cpg cn=true]


[OnName num="masato"]
Welcome back.
[cpg cn=true]


Somehow, she was giddy.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0143"]
[OnName num="sayo"]
Come here.
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0144"]
[OnName num="sayo"]
Come on! We're going to continue our morning!
[cpg cn=true]


[OnName num="masato"]
''Eh...wait...''
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0145"]
[OnName num="sayo"]
Well, then... let's start with the opening, shall we?
[cpg cn=true]


[OnName num="masato"]
Yes? Or, is it open?
[cpg cn=true]


When you think of the opening of the tunnel, the first thing that comes to mind is the tunnel. Do you think they're going to do a tunnel? I'm not sure if I can handle heavy equipment...
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo0146"]
[OnName num="sayo"]
I don't know if it's already done. If that's the case, I'm going to review it...
[cpg cn=true]


[OnName num="masato"]
"What?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0147"]
[OnName num="sayo"]
Well, that can't be right. I still feel a lot of unconsciousness right now.
[cpg cn=true]


[OnName num="masato"]
Um, Sayo-chan... What are you talking about earlier?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0148"]
[OnName num="sayo"]
The way you talk.
[cpg cn=true]


[SE f="se020"]
;//【ＳＥ】『強デコピン』ベチンッ
[WAIT time=1000]


[OnName num="masato"]
I'm sorry!
[cpg cn=true]


I've been deco-pinned. It's surprisingly painful when it's done at full force.
[cpg]

[OnName num="masato"]
''Master... what do you mean by what you've been saying earlier?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0149"]
[OnName num="sayo"]
"You're an inexperienced boy. I'm sure your asshole will be open.
[cpg cn=true]


[SE f="se015"]
;//【ＳＥ】『動き』ババッ


[OnName num="masato"]
"..............."
[cpg cn=true]


I covered my butt with my hands on the spur of the moment.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo0150"]
[OnName num="sayo"]
Why are you running away?
[cpg cn=true]


[OnName num="masato"]
''No, I mean...''
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0151"]
[OnName num="sayo"]
Why are you backing off?
[cpg cn=true]


[OnName num="masato"]
I'm afraid it's too early for me.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0152"]
[OnName num="sayo"]
...Tanaka-san.
[cpg cn=true]


[OnName num="butler"]
Awe.
[cpg cn=true]


[OnName num="masato"]
Waaaaaah! Oh, my ass! They're going to open my tunnel!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0153"]
[OnName num="sayo"]
Resign yourself to it.
[cpg cn=true]


[OnName num="masato"]
Oui.
[cpg cn=true]


I resigned myself to it.
I have no choice but to resign myself to my master's orders.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[SE f="se021"]
;//【ＳＥ】『ゴム手袋』ギュッギュッ


Master wore gloves on his hands as if he were preparing for surgery. Rubber gloves, though.
[cpg]


[VOICE f="Sayo0154"]
[OnName num="sayo"]
Let's clean it up first. Tanaka-san.
[cpg cn=true]


[OnName num="butler"]
Yes. It's already set up here, sir.
[cpg cn=true]


[OnName num="masato"]
"Tanaka-san!
[cpg cn=true]


[VOICE f="Sayo0155"]
[OnName num="sayo"]
You're very good at what you do.
[cpg cn=true]


[OnName num="butler"]
I'm honored by your compliments.
[cpg cn=true]


You could have just given me time to prepare more slowly and mentally prepare myself instead of showing such competence!
[cpg]


[VOICE f="Sayo0156"]
[OnName num="sayo"]
He wants to clean up his ass...
[cpg cn=true]


[VOICE f="Sayo0157"]
[OnName num="sayo"]
"Relax. It hurts when you're so tight, doesn't it?
[cpg cn=true]

;//●ＣＧエロ（雅人＆小夜・ご主人様に尻穴開通、拡張作業：小夜の部屋）ev_18（※ex02同一CG）

*Scene02|Big M and Little S

;//尻穴を拡張される

[BGM f="h1"]

;**【ＣＧ】ev_18_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]

Gneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee!
[cpg]

[OnName num="masato"]
''Ugh...ugh...ugh.
[cpg cn=true]


[VOICE f="Sayo0158"]
[OnName num="sayo"]
I'll let you in. Oh, I'm coming in...I'm coming in...here.
[cpg cn=true]


Gneeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee!
[cpg]

[OnName num="masato"]
Ughhhh.
[cpg cn=true]


[VOICE f="Sayo0159"]
[OnName num="sayo"]
It's hard to experience this because you're the one who gets in. How does it feel to have a foreign object in your ass?
[cpg cn=true]


[OnName num="masato"]
It's disgusting.
[cpg cn=true]


[VOICE f="Sayo0160"]
[OnName num="sayo"]
Shush. You'll soon get used to it and get better.
[cpg cn=true]


[VOICE f="Sayo0161"]
[OnName num="sayo"]
"Here, here, I'm going in... It's going to go in deeper and deeper.
[cpg cn=true]


[VOICE f="Sayo0162"]
[OnName num="sayo"]
Do you understand? Can you feel your asshole being spread and your rectum being violated?
[cpg cn=true]


A foreign object takes over my belly.
[cpg]


[VOICE f="Sayo0163"]
[OnName num="sayo"]
"Couscous...your manners are getting bigger. Are you feeling it?
[cpg cn=true]


[VOICE f="Sayo0164"]
[OnName num="sayo"]
He shakes every time you move him and even drips his juices... you have the makings.
[cpg cn=true]


[VOICE f="Sayo0165"]
[OnName num="sayo"]
I'm going to dilate you and train you.
[cpg cn=true]


[VOICE f="Sayo0166"]
[OnName num="sayo"]
"I'm going to cum with just my ass... until I'm a slutty hole that can't be beaten by a bitch hole...
[cpg cn=true]


;//☆数日〜数ヶ月かけて尻穴に突っ込む物を徐々に大きくしていって調教される

[SCENE id=1]
[ENDPARTIAL]

[window target=false]
[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=1]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="sl"]
[WAIT time=100]
;//【ＢＧ】『小夜の部屋』（夜）******************************************************

[window target=true]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0167"]
[OnName num="sayo"]
"Oh, it's late already. Let's call it a day, shall we?
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[OnName num="masato"]
"Thank you, thank you very much.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0168"]
[OnName num="sayo"]
Well, let's see...
[cpg cn=true]


[OnName num="masato"]
Hi! It's over, isn't it? You're still going to do something!
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0169"]
[OnName num="sayo"]
What are you scared of?
[cpg cn=true]


Well, after what she did to me, I was jumpy at every move the master made.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0170"]
[OnName num="sayo"]
I'm going to take a bath. It's the night, of course.
[cpg cn=true]


I take a bath in the evening. I see... it was overtime, wasn't it? Yeah, that's good. I'm not disappointed.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0171"]
[OnName num="sayo"]
"..............."
[cpg cn=true]


[OnName num="masato"]
? Master?
[cpg cn=true]


He said he was going to take a bath, but when he put his hand on the doorknob, he froze like a stone statue.
That look makes me feel a little uneasy.
[cpg]

[OnName num="masato"]
Uh, um...
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0172"]
[OnName num="sayo"]
Come on.
[cpg cn=true]


[OnName num="masato"]
Huh?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0173"]
[OnName num="sayo"]
Come to the baths with me.
[cpg cn=true]

Standing still, she said as she turned slightly this way.
[cpg]

[OnName num="masato"]
What... why me?
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0174"]
[OnName num="sayo"]
I can't hear what you have to say.
[cpg cn=true]


[OnName num="masato"]
''That's not true, I'm a man, and my master is a woman, and I'm not in the same bathhouse ahhhhh...''
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0175"]
[OnName num="sayo"]
Come on.
[cpg cn=true]


[OnName num="masato"]
Yes, sir.
[cpg cn=true]


I wonder if they'll do something there again.
[cpg]

No...it's ridiculous to only think about the negative. A bath with the master is a reward, isn't it?
[cpg]

Maybe I'll get a bigger reward than I ever imagined...
[cpg]


;//ＢＫ
;//エロティックな音楽

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=2100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="yuge.ui" method="in"  pos="3/5" time=1]

[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="h1"]
;//【ＢＧ】『豪華な風呂』（夜）******************************************************


;//ここでは画面一杯に湯気


;//小夜の喋り方は徐々にエロティックに

[window target=true]


[FG f="CHA01_p3_00_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0176"]
[OnName num="sayo"]
See, what are you afraid of?
[cpg cn=true]


[OnName num="masato"]
"But, Master... we've never done anything like this before.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0177"]
[OnName num="sayo"]
It's your first time, isn't it? It's okay... just take it slow and gentle and you'll be fine.
[cpg cn=true]


[OnName num="masato"]
"Master, you're very... sweet.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0178"]
[OnName num="sayo"]
''It's an important part of my life, too, so I don't want it to be handled too roughly. It's only natural to teach them to be polite.
[cpg cn=true]


[OnName num="masato"]
Like this?
[cpg cn=true]

[SE f=se086]
;//【ＳＥ】『体をこする』
[WAIT time=1000]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo0179"]
[OnName num="sayo"]
Ouch.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0180"]
[OnName num="sayo"]
Come on, no clawing.
[cpg cn=true]


[OnName num="masato"]
Excuse me!
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0181"]
[OnName num="sayo"]
It's a delicate area for a girl, so be more polite.
[cpg cn=true]


[OnName num="masato"]
Yes!
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0182"]
[OnName num="sayo"]
You have to press the belly part of your finger against it.
[cpg cn=true]


[OnName num="masato"]
Like this?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0183"]
[OnName num="sayo"]
Yes. Yeah, that's not very good... try going deeper and deeper.
[cpg cn=true]


[OnName num="masato"]
No more of this...
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0184"]
[OnName num="sayo"]
''If you don't go all the way to the back, you won't be able to get the dirt off. Here, don't be afraid...
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]

[SE f=se086]
;//【ＳＥ】『体をこする』
[WAIT time=1000]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo0185"]
[OnName num="sayo"]
It feels good.
[cpg cn=true]


[VOICE f="Sayo0186"]
[OnName num="sayo"]
Next time, be a little more...strong. Hmmm...hmmm...hmmm...
[cpg cn=true]


[OnName num="masato"]
Master.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo0187"]
[OnName num="sayo"]
You're good at it. Yes, more...hard...ahhhhhhhhh.
[cpg cn=true]



;//ホワイトアウト
;//ここでは画面一杯の湯気が晴れる
;//ここから小夜のトーンやしゃべり方も戻り、お風呂でリラックスしてる子供らしさも。
;//髪を洗っているだけ

[window target=false]

[FO pos="3/5" time=3000]
[WAIT time=4000]

[window target=true]

;//ここから小夜のトーンやしゃべり方も戻り、お風呂でリラックスしてる子供らしさも

;//髪を洗っているだけ

[FACE method="change_2" pos="2/3"]

[VOICE f="Sayo0188"]
[OnName num="sayo"]
Hahaha, it feels so good to have your hair washed by someone.
[cpg]


[OnName num="masato"]
......
[cpg cn=true]


That's right. Yeah, I knew it. I knew it. Yeah, yeah.
[cpg]

[FACE method="change_3" pos="2/3"]

[VOICE f="Sayo0189"]
[OnName num="sayo"]
My right itches.
[cpg cn=true]


[OnName num="masato"]
This is it?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]

[VOICE f="Sayo0190"]
[OnName num="sayo"]
"More down. No, you've gone too far! More... yes, yes. Around there. Oh, it feels good.
[cpg cn=true]


Well, whatever... the master is happy with it, and there wasn't any additional Oshioki to go around.
[cpg]



;//【ＢＧ】『豪華な風呂』（夜）

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0191"]
[OnName num="sayo"]
Hey, your hand has stopped.
[cpg cn=true]


[OnName num="masato"]
Excuse me!
[cpg cn=true]


[SE f=se086]
;//【ＳＥ】『体をこする』
[WAIT time=1000]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0192"]
[OnName num="sayo"]
It's time to move on, and then conditioner.
[cpg cn=true]


[OnName num="masato"]
Yes! I'm home!
[cpg cn=true]


[FG f="CHA01_p4_00_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0193"]
[OnName num="sayo"]
You have to wash your body properly and thoroughly.
[cpg cn=true]


[OnName num="masato"]
Every inch of it, huh?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0194"]
[OnName num="sayo"]
What's the problem?
[cpg cn=true]


[OnName num="masato"]
No, I mean, I can't be the one washing every inch of Master's body...
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo0195"]
[OnName num="sayo"]
You don't want to?
[cpg cn=true]


[OnName num="masato"]
I don't want to!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0196"]
[OnName num="sayo"]
Then what?
[cpg cn=true]


[OnName num="masato"]
''Ha, aren't you ashamed of it...?
[cpg cn=true]




;//※選択の内容により下記のセリフが変化

[if exp={getFlagValue("pets_flag") == 1 }]
;//※選択の内容により下記のセリフが変化
;//------------------------------
;//飼われる（ペット状態）になっている場合


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0197"]
[OnName num="sayo"]
Nothing. I wouldn't do anything for my pet to see me naked.
[cpg cn=true]

[endif]

;//------------------------------
[if exp={getFlagValue("gohome_flag") == 1 }]
;//仕える（下僕状態）になっている場合

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0198"]
[OnName num="sayo"]
Nothing. There's nothing like having a servant see you naked.
[cpg cn=true]


[endif]
;//------------------------------


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0199"]
[OnName num="sayo"]
Yeah, but... is that too much stimulation for you as a virgin and a pedophile?
[cpg cn=true]


[OnName num="masato"]
"!!!??????"
[cpg cn=true]


I became like a goldfish with my mouth popping and puckering, and I couldn't even reply properly.
[cpg]

[FG f="CHA01_p3_00_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0200"]
[OnName num="sayo"]
Did you think I hadn't noticed?
[cpg cn=true]


[OnName num="masato"]
Ah........
[cpg cn=true]


They saw right through me.
No, maybe it's a given. But I wish I hadn't said that as a wall of calmness.
[cpg]

[OnName num="masato"]
Doh... doh...
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

[VOICE f="Sayo0201"]
[OnName num="sayo"]
What?
[cpg cn=true]


[OnName num="masato"]
I don't..........
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo0202"]
[OnName num="sayo"]
......
[cpg]


[OnName num="masato"]
........
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0203"]
[OnName num="sayo"]
"Pup!"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0204"]
[OnName num="sayo"]
Ahahahahahaha! You'd rather have that excuse than me?! Ahahahaha, that's funny!
[cpg cn=true]


She was laughing out loud!
[cpg]

[FG f="CHA01_p4_00_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0205"]
[OnName num="sayo"]
I'm hungry. Besides, you even told such a blatant lie...
[cpg cn=true]


[OnName num="masato"]
......
[cpg cn=true]


It's a lie, I know it's a lie, but I want to insist that it's not a lie in this forum. If I don't, my heart is going to break with embarrassment.
[cpg]


[VOICE f="Sayo0206"]
[OnName num="sayo"]
But...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0207"]
[OnName num="sayo"]
Now it's worth being bullied all the more.
[cpg cn=true]


Master said with a grin and a smile.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0208"]
[OnName num="sayo"]
Now that you're done with your hair... you can wash your body next.
[cpg cn=true]


[OnName num="masato"]
Ahhhhhh...
[cpg cn=true]


[FG f="CHA01_p3_00_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0209"]
[OnName num="sayo"]
I'm a lolicon, but if you're not a virgin, you can put up with it a little. Here, wash up quickly.
[cpg cn=true]


[OnName num="masato"]
Awwwwwwwwww...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0210"]
[OnName num="sayo"]
My breasts, my ass... be gentle and respectful! Wash your sides as well, and my vagina!...
[cpg cn=true]


[OnName num="masato"]
Awwwwwwwwwwwwww!!
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0211"]
[OnName num="sayo"]
You touch me for a second and I'll kill you.
[cpg cn=true]


[OnName num="masato"]
Nuh-uh-uh-uh-uh-uh-uh-uh-uh!
[cpg cn=true]


A live killer, this is a live killer. If you touch it, it's going to kill you! It's a living hell...
[cpg]

Can someone please help me?
[cpg]

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]



[SE f=se080]
;//【ＳＥ】『風呂入る』
[BGM f="h1"]
;**【ＣＧ】ev_04_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1500]


;//●ＣＧ微エロ（雅人＆小夜・ご主人様と一緒にお風呂に入る：豪華なお風呂）ev_04


[VOICE f="Sayo0212"]
[OnName num="sayo"]
Fuhahaha, My tiredness will melt away in the hot water!
[cpg cn=true]


[OnName num="masato"]
That's good to hear. But in this position...
[cpg cn=true]


[VOICE f="Sayo0213"]
[OnName num="sayo"]
It sinks when you go in normally, That's a lot of inconvenience when your body is so small.
[cpg cn=true]


Surely, at Master's size, her face might sink into the hot water if her buttocks hit the bottom of the tub.
[cpg]

[OnName num="masato"]
So, how about this? Then, why don't you make a new bathtub for your master? You're rich, after all.
[cpg cn=true]


[VOICE f="Sayo0214"]
[OnName num="sayo"]
I hate that because it makes me feel like I'm losing.
[cpg cn=true]


He's a selfish person.
[cpg]


[VOICE f="Sayo0215"]
[OnName num="sayo"]
Plus, now that we've got just the right chair, we don't need it anymore.
[cpg cn=true]


[OnName num="masato"]
Hmm..........
[cpg cn=true]


Seriously, it would make you happy to be told that up close and personal with a smile like that.
[cpg]


[OnName num="masato"]
Well, that's good, she said. Well... it's a cheap chair.
[cpg cn=true]


[VOICE f="Sayo0216"]
[OnName num="sayo"]
Shush. Things aren't all about price. There are some things that are called cheap, but can't compete with the first-class.
[cpg cn=true]


Master, is this about me?
I was tempted to confirm it when I heard it, but I kept my mouth shut.
It seemed like something that shouldn't be asked...no, it seemed like something that shouldn't be asked.
[cpg]


[VOICE f="Sayo0217"]
[OnName num="sayo"]
It's just that it's cheap and has a stick that gets in the way...
[cpg cn=true]

;**【ＣＧ】ev_04_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1500]


Squeak!
[cpg]

[OnName num="masato"]
Nuh-uh!
[cpg cn=true]


So it's about me after all? It's like I'm happy, it hurts... it hurts, it hurts!
[cpg]


[VOICE f="Sayo0218"]
[OnName num="sayo"]
You'll be uncomfortable in your seat, so pull back.
[cpg cn=true]


[OnName num="masato"]
You can't just...
[cpg]


[VOICE f="Sayo0219"]
[OnName num="sayo"]
A useless servant!
[cpg cn=true]


It's my fault that I'm in this state, but it's a terrible thing to say.
However, the master rested his back on my chest again and relaxed.
[cpg]

;**【ＣＧ】ev_04_b ***********************
[CG id=3 index=2 time=1000]
;***************************************


The reason why I can entrust my body like this is, tentatively, because they are allowing me to have a little bit of a heart... I feel selfish about it.
[cpg]


[VOICE f="Sayo0220"]
[OnName num="sayo"]
Even so, you have a difficult constitution. It looks like it's going to be harder than me.
[cpg cn=true]


I replied to the topic of the shake, even though I was giggling.
[cpg]


[OnName num="masato"]
I don't know what you're talking about.
[cpg cn=true]


[VOICE f="Sayo0221"]
[OnName num="sayo"]
Lolicon.
[cpg cn=true]


[OnName num="masato"]
Ugh...
[cpg cn=true]


[VOICE f="Sayo0222"]
[OnName num="sayo"]
A virgin.
[cpg cn=true]


[OnName num="masato"]
Unh!
[cpg cn=true]


Master grinned and told me about my weaknesses.
[cpg]


[VOICE f="Sayo0223"]
[OnName num="sayo"]
Now that they know, you'll just have to confess.
[cpg cn=true]


If they already knew, they wouldn't have bothered to do this. However, she does it for fun.
I think they want me to say it from my mouth.
[cpg]

[OnName num="masato"]
Ha, ha, ha, ha, ha... nanoko de shoka.
[cpg cn=true]


My petty pride made me reply like that.
[cpg]


[VOICE f="Sayo0224"]
[OnName num="sayo"]
.........
[cpg cn=true]


Shoo, her eyes narrowed slightly!
[cpg]

;**【ＣＧ】ev_04_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1500]



[VOICE f="Sayo0225"]
[OnName num="sayo"]
I wonder if she's happy to lean in like this.
[cpg cn=true]


[OnName num="masato"]
"!!!"
[cpg cn=true]


As she said this, Master not only her own body but also her cheeks slid into her chest plate.
I'm so excited about this.
[cpg]


[OnName num="masato"]
No, no! I can't do that, master...
[cpg]


[VOICE f="Sayo0226"]
[OnName num="sayo"]
You won't have to run away. There you go.
[cpg cn=true]


rub... rub... rub...
[cpg]

While the line is emphasized like a child, the body with a moderately fleshed out body rubs against it.
[cpg]

On the one hand, I am happy when they do this to me, but on the other hand, it's hard because I can't give my hand to them.
[cpg]



;//ＢＫ


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

;//レターボックスin
[FACE method="in" pos="4/7"]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_08_4_up.ui" time=1000]


;//【ＢＧ】『豪華な風呂』（夜）******************************************************

[SE f=se082]
;//【ＳＥ】『風呂遊ぶ』

[window target=true]

[OnName num="masato"]
It's a bit of a trifle! I can't believe a girl would do something like this!
[cpg cn=true]


[FG f="CHA01_p3_00_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0227"]
[OnName num="sayo"]
"Which one of you is the awkward one? Make this place inflate like this, yikes!
[cpg cn=true]


[OnName num="masato"]
Aaaaahhhh, don't be jerking! No, no, no, no, no! And it's out! I'm getting out!
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0228"]
[OnName num="sayo"]
If you defile the bathtub, you'll be made to drink every drop of it.
[cpg cn=true]


[OnName num="masato"]
It's terrible!
[cpg cn=true]


[FG f="CHA01_p4_00_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0229"]
[OnName num="sayo"]
"Ahaha, this is fun.
[cpg cn=true]


[OnName num="masato"]
"Oh, no, no, no, no, I'm going to shoot! Poor wasted bullets are coming out!
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0230"]
[OnName num="sayo"]
It won't serve any purpose, so it won't change much.
[cpg cn=true]


[OnName num="masato"]
It's even worse! Even those kids are desperately trying to live!
[cpg cn=true]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=2100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=1]
[WAIT time=200]
;//レターボックスout
[FACE method="out" pos="4/7"]

[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=100]


[transition target={true} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『豪邸、廊下』（夜）******************************************************


[SE f=se082]
;//【ＳＥ】『お湯が跳ねる音』バシャバシャ


;//＠ep003
;//[SE f=se000]
;//【ＳＥ】『楽しそうな様子』


[OnName num="butler_A"]
"......"
[cpg cn=true]


[OnName num="maid_A"]
"......"
[cpg cn=true]


;//下記のセリフは同時に表示して下さい

[OnName num="butlerA&maidA"]
Lady, you look like you're enjoying yourself.
Lady, you look like you're enjoying yourself.
[cpg cn=true]


[window target=false]

[STOPBGM]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1500]
[WAIT time=2000]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_07_3.ui" time=1000]

[WAIT time=1500]

[SE f=se083]
;//【ＳＥ】『フクロウ』

[BG f="b_07_4.ui" time=1000]

[WAIT time=3000]


;//【ＢＧ】『空』（夜）******************************************************

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[window target=true]

[WAIT time=100]

[BGM f="sl"]
[WAIT time=100]
;//【ＢＧ】『豪邸、廊下』（夜）******************************************************


[SE f="se016"]
;//【ＳＥ】『扉を開ける』ガチャ


[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0231"]
[OnName num="sayo"]
Whew, that was a good hot water!
[cpg cn=true]


[OnName num="butler"]
Young lady, how about a drink?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0232"]
[OnName num="sayo"]
Thank you! I'll take it.
[cpg cn=true]


[OnName num="butler"]
Still, you seemed to be having a lot of fun.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0233"]
[OnName num="sayo"]
Shush. I've lost my mind, too, and I've become a child for all my years.
[cpg cn=true]


[OnName num="butler"]
''(The young lady is not even old enough to look like a child...)''
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0234"]
[OnName num="sayo"]
Tanaka, what's up?
[cpg cn=true]


[OnName num="butler"]
No, no. Please be careful not to get hot water.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0235"]
[OnName num="sayo"]
'Yeah. Let's be careful.
[cpg cn=true]

[move from="2/3" to="5/3" ease="easeInOutSine" time=2000]

[WAIT time=2000]

[OnName num="butler"]
''(Lady, you really seemed to be enjoying yourself more than usual. I'm glad he's here.)
[cpg cn=true]


[BG f="b_08_4" time=1000]


;//様子を見に浴場へ移動する田中

[SE f=se016]
;//【ＳＥ】『扉を開ける』
[BG f="b_08_4.ui" time=1000]

[OnName num="butler"]
Masato, thank you very much for your hard work. Well, I'm glad the young lady is pleased too.....
[cpg cn=true]


[BG f="b_08_4_up.ui" time=1000]

[WAIT time=1000]

;//レターボックスin
[FACE method="feadin" pos="4/7"]

[WAIT time=1500]

[SE f=se084]
;//【ＳＥ】『チーン』

[WAIT time=2000]


;//※もし可能ならカットインが欲しいです。ぷかーっと湯船に浮かんでいる雅人

[STOPBGM]
[BGM f="co"]


[OnName num="butler"]
''Nantzuo, nantzuo, nantzuo, nantzuo! Your periscope is broken, Masato's periscope is broken!
[cpg cn=true]


[OnName num="masato"]
''Ugh...it's this long...from the original...it's...right...''
[cpg cn=true]


The squeezed out twit was a red dot.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]

[window target=true]

;//【ＢＧ】『小夜の部屋』（夜）******************************************************


[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0236"]
[OnName num="sayo"]
Fluffy~... I think I'll sleep well today... Good night!
[cpg cn=true]


[OnName num="brionac"]
Wham.
[cpg cn=true]



[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=2000]
[WAIT time=3000]
[free time=1]
;//レターボックスout
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="ep004.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
