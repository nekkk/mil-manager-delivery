*start


;#################################################
*Ep004|Ah, wonderful M days!
;#################################################

[SCENE id=4]


[stflag jump_scene=0]
[window target=false]

[STOPBGM]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]



[BG f="black.ui" time=1]
[WAIT time=1]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[WAIT time=100]

[BGM f="d1"]
[WAIT time=100]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（朝）******************************************************

Today, we start working in earnest.
[cpg]

[OnName num="masato"]
All right, let's give it our best shot.
[cpg cn=true]

[SE f=se005]
;//【ＳＥ】『歩く』

[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ＢＫ

[STOPBGM]
[SE f=se007]
;//【ＳＥ】『転ぶ』ドタッ

[WAIT time=1000]

[SE f=se052]
;//【ＳＥ】『瓶とか倒す音』

[OnName num="masato"]
"Ah..."
[cpg cn=true]


I don't know what I'm doing...
[cpg]

;//レターボックスin
[FACE method="in" pos="4/7"]

[window target=false]
[transition target={true} rule="amamori3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1_up.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]

[BGM f="h1"]
[WAIT time=100]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（朝）******************************************************
[window target=true]


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0250"]
[OnName num="sayo"]
It's a very expensive acupuncture point.
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0251"]
[OnName num="sayo"]
How dare you suddenly crack it open... distracted?
[cpg cn=true]


[OnName num="masato"]
I don't have any words to say back.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0252"]
[OnName num="sayo"]
Well...I hear it's about my motivation running out of steam, so I'm not that angry about it...''
[cpg cn=true]


Who in the world was following me? I thought so and glanced to the side.
[cpg]


[OnName num="butler"]
.........................
[cpg cn=true]


Mr. Tanaka! Thank you so much!
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0253"]
[OnName num="sayo"]
But since you have failed...I will give you the punishment you deserve. Is that good?
[cpg cn=true]


[OnName num="masato"]
Yes
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0254"]
[OnName num="sayo"]
Then get in here.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo206"]
[OnName num="sayo"]
Humph... I'll humiliate you a lot.
[cpg cn=true]

[STOPBGM]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//レターボックスin
[FACE method="out" pos="4/7"]

;//●ＣＧ（雅人＆小夜・ツボを割ったオシオキ。四つん這いでお尻たたき：ダイニング）ev_05

[BGM f="h1"]


;**【ＣＧ】 ev_05_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1500]

[SE f=se025]
;//【ＳＥ】『スパンキング』

[BG f="white.ui" time=100]
[WAIT time=100]

[CG id=4 index=0 time=100]
[WAIT time=100]


[VOICE f="Sayo0256"]
[OnName num="sayo"]
"Yes! Yes! Damn it! That!
[cpg cn=true]


[OnName num="masato"]
Ahhhhhhhh!
[cpg cn=true]

[SE f=se025]
;//【ＳＥ】『スパンキング』

[BG f="white.ui" time=100]
[WAIT time=100]

[CG id=4 index=0 time=100]
[WAIT time=100]

I'm being put on the table and spanked by my master as punishment.
[cpg]

It's almost like a freak showroom.
[cpg]

Incidentally, it's a different table than the one where the master takes her meal.
[cpg]

[OnName num="masato"]
Um, why are you dressed like this...?
[cpg cn=true]


[VOICE f="Sayo0257"]
[OnName num="sayo"]
Parents discipline their children, The master disciplines his servant... Right?
[cpg cn=true]


[OnName num="masato"]
I'm sure you're right about what you're saying, but this outfit...?
[cpg cn=true]


[VOICE f="Sayo0258"]
[OnName num="sayo"]
It's butt-pen-pen.
[cpg cn=true]


[OnName num="masato"]
I don't know why I'm penciling in...
[cpg cn=true]


[VOICE f="Sayo0259"]
[OnName num="sayo"]
You mean, why do people spank you?
[cpg cn=true]


[OnName num="masato"]
I'm not talking about that kind of philosophy...
[cpg cn=true]


[VOICE f="Sayo0260"]
[OnName num="sayo"]
A spanking is not really a reasonable thing to do.
[cpg cn=true]


[OnName num="masato"]
?
[cpg cn=true]


[VOICE f="Sayo0261"]
[OnName num="sayo"]
The shame of being made to dress up in this way in public with my ass out. On top of that, the act of continuing to beat them until they admit their fault. 
[cpg]

Shame on the mind, pain on the body... that's how one can admit one's stupidity. That's great, ass pen pen!
[cpg cn=true]


[OnName num="masato"]
I don't think there's such a noble meaning to this act...
[cpg cn=true]


[VOICE f="Sayo0262"]
[OnName num="sayo"]
Shut up!
[cpg cn=true]


Petite.
[cpg]


[VOICE f="Sayo0263"]
[OnName num="sayo"]
I'm not going to verbally abuse you, Those who don't understand what I say should be taught a lesson by the pain they deserve."
[cpg cn=true]


[SE f="se025"]
;//【ＳＥ】『スパンキング』


[VOICE f="Sayo0264"]
[OnName num="sayo"]
Well? Are you remorseful?
[cpg cn=true]


[OnName num="masato"]
"Yes, yes... I'm sorry...
[cpg cn=true]


;**【ＣＧ】ev_05_a ***********************
[CG id=4 index=1 time=1000]
;***************************************


[VOICE f="Sayo0265"]
[OnName num="sayo"]
You're lying to me!
[cpg cn=true]


[SE f="se025"]
;//【ＳＥ】『スパンキング』


[OnName num="masato"]
"Gah!
[cpg cn=true]


[VOICE f="Sayo0266"]
[OnName num="sayo"]
If you're feeling remorseful, why is this thing... so bloated?
[cpg cn=true]


Well, that's because... I got so excited by being spanked that I felt good....
[cpg]


[VOICE f="Sayo0267"]
[OnName num="sayo"]
We need to get some more Oshioki. Let me out.
[cpg cn=true]


She was even more embarrassed by what she was told.
[cpg]

;**【ＣＧ】ev_05_b ***********************
[CG id=4 index=2 time=1000]
;***************************************


[VOICE f="Sayo0268"]
[OnName num="sayo"]
I won't forgive you if you make out on your own.
[cpg cn=true]


A masturbator is attached to my manhood and handled.
[cpg]


[OnName num="masato"]
Ah, ah, ah.
[cpg cn=true]


[VOICE f="Sayo0269"]
[OnName num="sayo"]
Be patient. If you make a mess on the table, we'll get another Osoki.
[cpg cn=true]


[OnName num="masato"]
''Oooh!''
[cpg cn=true]


[VOICE f="Sayo0270"]
[OnName num="sayo"]
Oh. You're oozing with a lot of nasty juices... and you have no patience for anything so crude.
[cpg cn=true]


However, I ejaculated easily.
[cpg]


[SE f="se026"]
;//【ＳＥ】『射精音』


-- thump thump thump thump thump thump thump thump thump thump thump thump thump thump thump thump!
[cpg]

;**【ＣＧ】ev_05_c ***********************
[CG id=4 index=3 time=1000]
;***************************************
[WAIT time=2000]


[VOICE f="Sayo0271"]
[OnName num="sayo"]
I told you not to let it out... and you can't hear what I have to say?
[cpg cn=true]


[VOICE f="Sayo0272"]
[OnName num="sayo"]
Every time you take it out, your butt-penpen 50 times. And if you cum again, 50 times. I'm going to keep going until I can bear it without ejaculating.
[cpg cn=true]


[OnName num="masato"]
Hiiiiiiiiiiiie!
[cpg cn=true]


[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=2100]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;//ＢＫ


On that day, I cussed eight times...and the number of times I used my butt pen pen exceeded 500 times in total.
[cpg cn=true]

[SCENE id=2]
[ENDPARTIAL]

[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=2000]

[BGM f="sl"]
;//【ＢＧ】『空』（夕方）******************************************************


[SE f=se005]
;//【ＳＥ】『歩く』

[WAIT time=1500]

[window target=true]

[VOICE f="Sayo0273"]
[OnName num="sayo"]
Oh.
[cpg cn=true]


[VOICE f="Sayo0274"]
[OnName num="sayo"]
It's quite an auspicious gesture to be greeted so properly.
[cpg cn=true]


[OnName num="masato"]
I was worried about you... because you arrived late.
[cpg cn=true]


[VOICE f="Sayo0275"]
[OnName num="sayo"]
You're not going to get anything out of it by saying that.
[cpg cn=true]


[OnName num="masato"]
I know.
[cpg cn=true]


[VOICE f="Sayo0276"]
[OnName num="sayo"]
Yes. Let me stop by your room for a minute.
[cpg cn=true]


[OnName num="masato"]
'Yes, I don't mind, but...'
[cpg cn=true]


[VOICE f="Sayo0277"]
[OnName num="sayo"]
I'll have to check to make sure I'm doing it right.
[cpg cn=true]


I guess they check the room to see if I'm doing well in my life here.
[cpg cn=true]


[SE f=se005]
;//【ＳＥ】『歩く』

[BG f="black.ui" time=1000]
[WAIT time=2000]

[stopse g=2]
;//通常se

;//☆ＣＧエロ（雅人＆小夜・具合を見てあげると言われケツ穴を掘られる：雅人の部屋）ev_18（※ex02同一CG）

*Scene04|嗚呼、素晴らしきMな日々

[STOPBGM]
[WAIT time=1000]

[BGM f="h1"]

;**【ＣＧ】ev_18_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=2000]


[OnName num="masato"]
Ahhhhhhhhhh!
[cpg cn=true]


I was wondering, but it was different. 
[cpg]


[VOICE f="Sayo0278"]
[OnName num="sayo"]
No boy would ever make such a pathetic sound.
[cpg cn=true]


Even if you're being told to pick people's asses... Apparently it was my ass that was checking.
[cpg]


[VOICE f="Sayo0279"]
[OnName num="sayo"]
"Did you do what you were told... to do? You haven't changed much.
[cpg cn=true]


[OnName num="masato"]
Geekly.
[cpg cn=true]


[VOICE f="Sayo0280"]
[OnName num="sayo"]
"Spread it out tightly. Will you be the one to see me cry when I put my fist in it later?
[cpg cn=true]


[OnName num="masato"]
"Hiiiiiiiiy! Please don't do that!
[cpg cn=true]


[VOICE f="Sayo0281"]
[OnName num="sayo"]
'Just kidding, just kidding. Couscous.
[cpg cn=true]


[VOICE f="Sayo0282"]
[OnName num="sayo"]
This time, I'm going to break it in specially for you.
[cpg cn=true]


With that, the Master's intense expansion began, to the point that I honestly would have rather kept the cork on.
[cpg]


[VOICE f="Sayo0283"]
[OnName num="sayo"]
''Hmmm. I'd still be able to fit about two fingers in.
[cpg cn=true]


[VOICE f="Sayo0284"]
[OnName num="sayo"]
Well? Doesn't it feel good to have the walls of your rectum rubbed against you like this?
[cpg cn=true]


[OnName num="masato"]
''Ha, yes...''
[cpg cn=true]

;**【ＣＧ】ev_18_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sayo0285"]
[OnName num="sayo"]
''Haha, great! My cock is so jumpy...
[cpg cn=true]


[VOICE f="Sayo0286"]
[OnName num="sayo"]
I'll do the same for you.
[cpg cn=true]


Saying that, Master played with my balls as well.
[cpg]

[OnName num="masato"]
Ahh... no more.
[cpg cn=true]


[VOICE f="Sayo0287"]
[OnName num="sayo"]
Do you happen to be dealing with an ass and come? Does it feel good and make you squeal?
[cpg cn=true]


[VOICE f="Sayo0288"]
[OnName num="sayo"]
''You're so happy to have a girl smaller than yourself do this to you and ejaculate...you're a pervert!
[cpg cn=true]


I couldn't stand the pleasure and ejaculated.
[cpg]


[VOICE f="Sayo0289"]
[OnName num="sayo"]
The more you feel, the better you'll feel.
[cpg cn=true]


[VOICE f="Sayo0290"]
[OnName num="sayo"]
Just do as you're told.
[cpg cn=true]


[OnName num="masato"]
Ha-ha-hee...
[cpg cn=true]


I'll do as I'm told from now on...
[cpg]

[SCENE id=3]
[ENDPARTIAL]


;//ＢＫ


[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse
;//ＢＫ

[jump storage="ep005.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
