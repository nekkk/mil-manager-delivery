*start


;#################################################
*Ep002|M Dreams
;#################################################


[stflag jump_scene=0]
[stflag gohome_flag=0]
[stflag service_flag=0]
[stflag hiyokurenri_flag=0]
[stflag existence_flag=0]
[stflag pets_flag=0]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]



[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_0.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[STOPBGM]

[WAIT time=100]

[BGM f="co"]
[WAIT time=100]
;//【ＢＧ】『空』******************************************************
;//夢の中。空の背景にモヤモヤを掛けたもので代用。

[window target=true]


When I woke up, I was in a fluffy, glittery place I'd never seen before.
[cpg]

Where the hell am I? What was I doing here again?
[OnName num="masato"]
I'm pretty sure I'm...
[cpg cn=true]


I'm trying to pull up a memory and remember...
[cpg]

[OnName num="unknown"]
''Brother!''
[cpg cn=true]




[SE f="se008"]
;//【ＳＥ】『走ってくる音』タタタタタ


[OnName num="masato"]
''Wow. It's full of herbs!
[cpg cn=true]


Out of nowhere, a lot of loli sisters appeared who called me "brother".
[cpg]


[OnName num="younger_sister_4"]
Brother Ani! I've got it!
[cpg cn=true]


[OnName num="younger_sister_1"]
"Mmmm... big brother! It's not fair that you have to leave us!
[cpg cn=true]


[OnName num="younger_sister_2"]
"What a terrible way to break a promise to your pretty sister.
[cpg cn=true]


[OnName num="younger_sister_3"]
Ni... Play, play, play.
[cpg cn=true]


[OnName num="younger_sister_5"]
''Brother, let me put my pants on! Pants Pants!
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]




This is heaven. Yeah, I'm sure.
[cpg]

There's a Loli sister with multiple attributes that I've dreamed of: caring, pampering, and tsundere. What's the point if this isn't heaven?
[cpg]


[OnName num="masato"]
Yes. I have a lot of cute loli sisters and I spend my days hanging out with everyone...
[cpg cn=true]


[OnName num="younger_sister_2"]
''What's the matter with you all of a sudden! Why are you crying big brother!
[cpg cn=true]


[OnName num="younger_sister_5"]
"What's wrong with your brother? Are you sad you can't find your pants?
[cpg cn=true]


[OnName num="younger_sister_1"]
Big brother? Was there something sad about it...?
[cpg cn=true]


[OnName num="masato"]
''No...I've been going through a lot of hard times lately...I suddenly had tears...''
[cpg cn=true]


[OnName num="younger_sister_4"]
''Brother, you must have had a bad dream. I'm fine! We'll always be by your brother's side!
[cpg cn=true]


[OnName num="younger_sister_3"]
Ni... Good boy, good boy...
[cpg cn=true]




Surely, as my sisters would say, I've been having bad dreams.
[cpg]

This is the real reality.
[cpg]

I felt like I'd been fired from my job, but it was all my fault.
[cpg]


Hurrah! Hail Loli!
[cpg]

Long live my sister!
[cpg]

Hail to her!
[cpg]


[OnName num="masato"]
''Ah ha ha ha ha ha, ah ha ha ha ha, ah ha ha ha...''
[cpg cn=true]


[WAIT time=600]

;//キャッキャする雅人と妹達


[STOPBGM]


[VOICE f="Sayo0058"]
[OnName num="sayo"]
''Totally... really, big brother, you're not a very nice person.
[cpg cn=true]

[SE f="se005"]
;//【ＳＥ】『歩いてくる』

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

;//小夜の立ち絵登場

[WAIT time=1000]

;//無音

[stopse g=2]
;//通常se

[OnName num="masato"]
 "…………………………eh?" 
[cpg cn=true]




[SE f="se014"]
;//【ＳＥ】『衝撃』ダダーン


It was a shock like being hit with a blunt instrument.
[cpg]

I've felt something similar when I've felt like I've been fired from my job.
[cpg]

No...maybe even more than that.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0059"]
[OnName num="sayo"]
''Big brother. Is there a problem?
[cpg cn=true]


[OnName num="masato"]
''Um, but...that...thing...? You don't...you don't...
[cpg cn=true]




She's a familiar face. No, my sister...
[cpg]

No, no, no, that's not possible. My sister doesn't have this girl.
[cpg]

The moment I caught it in my sight, I got chills and chills... There's no way this girl is my sister.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo0060"]
[OnName num="sayo"]
''Don't tell me you've forgotten your sister's face, big brother?
[cpg cn=true]


Oh, no. This isn't good.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0061"]
[OnName num="sayo"]
I'm sorry. How long are you going to be out of sleep? Please wake up quickly, big brother.
[cpg cn=true]


[OnName num="younger_sister_1"]
"Big brother.
[cpg cn=true]


[OnName num="younger_sister_2"]
"My brother.
[cpg cn=true]


[OnName num="younger_sister_3"]
"Ni Ni.
[cpg cn=true]


[OnName num="younger_sister_4"]
Brother!
[cpg cn=true]


[OnName num="younger_sister_5"]
"My brother.
[cpg cn=true]




---The 'sisters' smiled and shook their right leg....
[cpg]

Aaahhhh no no no............................................................................................................
[cpg]

[SE f=se030]
;//【ＳＥ】『風切音』ビュンッ

;//ＢＫ
[STOPBGM]

[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=500]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=1]
[WAIT time=2000]
;//【ＢＧ】『使用人の部屋（執事、田中の部屋）』（昼）******************************************************
;//ここで働く事になるので雅人の部屋にもなります。最初は物が無くて殺風景な感じの方が良いです
;//それか全く一緒でも全然問題無いです



[SE f="se015"]
;//【ＳＥ】『ベッドから起きる』がバッ

[transition target={true} rule="bakuhatu2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]

[WAIT time=200]
[transition target={false} rule="bakuhatu2.webp" color={0x000000ff} time=500]
[WAIT time=1000]

[window target=true]



[OnName num="masato"]
Waaaaaaaah!
[cpg cn=true]


[OnName num="butler"]
"Nuouo!
[cpg cn=true]


[OnName num="masato"]
''Hah, hah...ahhh...ahhh...''
[cpg cn=true]




Before I knew it, I was in a room I'd never seen before. The color is clearly different from the fluffy place where I should have been just a moment ago.
[cpg]

[OnName num="butler"]
 "... Did you notice?" 
[cpg cn=true]


[OnName num="masato"]
Heh...uh...yes.
[cpg cn=true]




Thanks to a familiar person standing right next to me who called out to me, I was somehow able to grasp the situation.
[cpg]

A familiar person standing right beside me called out to me, and I somehow got a sense of the situation.
[cpg]

I was sleeping in a strange room, and I had just woken up.
[cpg]


[OnName num="butler"]
I'm even more aware that what I was seeing until just a moment ago was a dream.
[cpg cn=true]


[OnName num="masato"]
How do you feel about that?
[cpg cn=true]


[OnName num="butler"]
''Well, nothing in particular...'' He looks fine.
[cpg cn=true]


[OnName num="masato"]
'That's good to hear. He didn't seem to be doing anything particularly unusual when he was examined at the hospital.
[cpg cn=true]


[OnName num="butler"]
A hospital?
[cpg cn=true]


[OnName num="masato"]
'Oh, you won't remember. Yes, after what happened. I can't rest easy until I've been tested... for you or for us.
[cpg cn=true]



Well, I'm... she's...
[cpg]

I remember it well. In fact, I can't forget such an event so easily.
[cpg]

It's just that I had a dream that was so deceptively real, and that I was up in bed and couldn't sort things out.
[cpg]

I finally remembered why I was here.
[cpg]


[OnName num="butler"]
I don't know what I don't remember, but I heard that he was taken to the hospital and taken care of like this afterwards.
[cpg cn=true]


[OnName num="masato"]
I'm sorry I'm late. I'm Tanaka, the butler who serves this family.
[cpg cn=true]


[OnName num="butler"]
Ha! Thank you very much for your kind words. It's Sakigawa.
[cpg cn=true]


[OnName num="masato"]
By the way, do you have a brother and sister?
[cpg cn=true]


[OnName num="butler"]
"He said something in his sleep.
[cpg cn=true]


[OnName num="masato"]
''Ah, ah, ah, ah, ah...''
[cpg cn=true]




I didn't know what to say and returned a bitter smile. If they knew what kind of dream I was having, they'd be furious.
[cpg]

[OnName num="butler"]
This way, sir.
[cpg cn=true]


[OnName num="masato"]
?
[cpg cn=true]


As we talked, Tanaka-san offered me a change of clothes.
[cpg]

[OnName num="butler"]
The young lady is waiting for you over there.
[cpg cn=true]


[OnName num="masato"]
"Eh.
[cpg cn=true]

[STOPBGM]
[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=2500]
;//ＢＫ

[SE f=se016]
;//【ＳＥ】『扉を開ける』ガチャ

[WAIT time=2000]

[SE f=se017]
;//【ＳＥ】『扉を閉める』バタン

;//優雅な音楽
[BG f="b_04_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************

[window target=true]

[BGM f="sl"]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]


[VOICE f="Sayo0062"]
[OnName num="sayo"]
Â
[cpg cn=true]



After changing, "That Girl" was enjoying an elegant afternoon tea time in the room where Tanaka-san showed us.
[cpg]

[OnName num="butler"]
''Miss, I've brought Master Sakigawa with me.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0063"]
[OnName num="sayo"]
Thank you.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]




It's as if you've wandered into a manga or anime world with a room full of rich people.
[cpg]

These are obviously people who live in a different world from their own.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0064"]
[OnName num="sayo"]
How are you feeling?
[cpg cn=true]


[OnName num="masato"]
''Eh, uh...yes. Thanks to you, I'm fine.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0065"]
[OnName num="sayo"]
Yes. That's good to hear.
[cpg cn=true]




As Tanaka-san also calls her daughter, this girl in front of her seems to be quite a great person.
[cpg]

Isn't it great to be a rich girl?
[cpg]

But it's not just that, it has an atmosphere of...unconsciously degrading, I think.
[cpg]

No matter how you look at it, I'm in awe...I use honorifics.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0066"]
[OnName num="sayo"]
Mr. Tanaka, I need those papers.
[cpg cn=true]


[OnName num="butler"]
Yes, this way.
[cpg cn=true]




It's too soon to tell, but Tanaka-san quickly gave her what she was asking for.
[cpg]

The quickness of this response and the feeling of knowing what the other party is looking for is probably a true butler. I was a little impressed to see it live.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0067"]
[OnName num="sayo"]
Sakigawa Masato?
[cpg cn=true]


[OnName num="masato"]
Yes, sir!
[cpg cn=true]


I get nervous when my name is suddenly called.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0068"]
[OnName num="sayo"]
I'd like to introduce myself again. I am Misanagi Sayo.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0069"]
[OnName num="sayo"]
I'm your... master.
[cpg cn=true]


[OnName num="masato"]
Ew!
[cpg cn=true]


That means.....
[cpg]

[FG f="CHA01_p4_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0070"]
[OnName num="sayo"]
Here are the results of your interview...
[cpg cn=true]


I had completely forgotten about it due to various reasons, but I had come here for an interview for a job...
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0071"]
[OnName num="sayo"]
I passed with no complaints. Kusu, congratulations on your book adoption.
[cpg cn=true]


[OnName num="masato"]
''Heh, ha...hi.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0072"]
[OnName num="sayo"]
I wish I could be more pleased.
[cpg cn=true]


[OnName num="masato"]
Excuse me. I'm still confused...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0073"]
[OnName num="sayo"]
Well, a good night's rest will calm you down.
[cpg cn=true]


Even as I say this, the talk of hiring goes on and on.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0074"]
[OnName num="sayo"]
Work starts tomorrow. You'll be live-in and work, so go get ready.
[cpg cn=true]


I'm not very enthusiastic about it, and I'm left wondering what to do.
[cpg]

It's not that I can start working tomorrow...it's that I'm going to have to work at this rate.
[cpg]

[OnName num="masato"]
Wait a minute, please. You can't just go ahead and talk like that...
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo0075"]
[OnName num="sayo"]
''As you wish...? What does that mean?
[cpg cn=true]


I can't give a clear answer to her question, either.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0076"]
[OnName num="sayo"]
Have you changed your mind, by any chance? Or are you worried about a sudden change in circumstances?
[cpg cn=true]


Honestly, I think it's either way. But more than that, the part that makes my heart churn is what kind of work I'm going to do...
[cpg]

[OnName num="masato"]
''Well, the job description seems to be different from what I had first imagined...I don't know...I don't know...I don't know...I don't know.
[cpg cn=true]


I let out a feeling that even I couldn't clearly understand, but I let it out.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0077"]
[OnName num="sayo"]
I wish I could be honest.
[cpg cn=true]


[OnName num="masato"]
"Huh?
[cpg cn=true]


I could faintly hear her words as she let loose with a whimper.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0078"]
[OnName num="sayo"]
Do you not want to serve me?
[cpg cn=true]


[VOICE f="Sayo0079"]
[OnName num="sayo"]
Are you unhappy with serving me, a woman, a child in appearance, who should be more powerless than you...because of the difference in status, as your master?
[cpg cn=true]


She pieced together the words, one by one, to make sure of something.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0080"]
[OnName num="sayo"]
What are you waiting for now? I'm sure you'll be happy to have a steady job.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
Tanaka! She let out a slightly louder voice as she accepted some papers.
[cpg]

[WAIT time=500]



[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0081"]
[OnName num="sayo"]
Looking at the resume you brought with you, it looks like you've had a lot of trouble.
[cpg cn=true]


[OnName num="masato"]
''Ugh...!''
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0082"]
[OnName num="sayo"]
It's a strange preference to prefer a day job to a regular job...but that's up to each person. If you don't want to, I don't care.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0083"]
[OnName num="sayo"]
You're guaranteed food, clothing, shelter, a job, stability, and a decent income... if you have any complaints.
[cpg cn=true]


[OnName num="masato"]
''Huh, it's more of a complaint...''
[cpg cn=true]


I can't say anything back because the other person is right and we are just talking about our feelings.
But I found one thing to refute.
[cpg]

[OnName num="masato"]
What exactly is the job description? If you don't know that, it's hard to say...
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0084"]
[OnName num="sayo"]
"......"
[cpg cn=true]


[OnName num="masato"]
'(Ooh, I wonder if I'll be offended...)
[cpg cn=true]


I waited anxiously for an answer.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0085"]
[OnName num="sayo"]
I thought you already knew that...
[cpg cn=true]


;//【ＳＥ】ページめくる
[SE f=se076]
;//【ＳＥ】紙の音

[FACE method="change_1" pos="2/3"]
Suddenly, another document is shown to me.
[cpg]

[OnName num="masato"]
What's this?
[cpg cn=true]


[VOICE f="Sayo0086"]
[OnName num="sayo"]
It's a job description. Please choose one of them.
[cpg cn=true]


[OnName num="masato"]
..............."
[cpg cn=true]




1. He takes Sayo Misanagi as his master and serves her (he's like a butler, I guess).
[cpg]

2, to be kept as a pet for Misanagi Sayo (I don't know what that means)
[cpg]

To summarize what was written on the paper I was handed, it goes like this.
[cpg]

No matter how you look at it, the second one is a decent document, which made it even more confusing.
[cpg]


[OnName num="masato"]
Are you kidding me?
[cpg cn=true]


[FG f="CHA01_p4_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0087"]
[OnName num="sayo"]
No, I'm very serious. I'm serious.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


If this isn't an advanced gag, then it's as serious as she says it is.
[cpg]

If I were to do this job, I would have to choose between "serving" her, who looks like a child, as a "master" and "being kept".
[cpg]

I've been at a crossroads in my life.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0088"]
[OnName num="sayo"]
I won't say it's unreasonable, so you can decline if you don't want to. There are other candidates out there.
[cpg cn=true]


[OnName num="masato"]
''What else...?''
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0089"]
[OnName num="sayo"]
These are the people who were with you. Don't you remember that?
[cpg cn=true]


I think it was the other three people who made it to the end of the interview.
[cpg]


[VOICE f="Sayo0090"]
[OnName num="sayo"]
Two of them are a long shot, but I'm sure the other one will come back to take the test.
[cpg cn=true]


I could tell right away that it was the man with the glasses.
He was the first one to take that test. I felt a strong will that even I could understand.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0091"]
[OnName num="sayo"]
I think they're more motivated than you.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


I don't know, she's right about what she's saying... and since she's showing her own reluctance, it's no wonder she's saying that others...
And yet, for some reason, it makes me feel bad about it.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0092"]
[OnName num="sayo"]
"Above all...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0093"]
[OnName num="sayo"]
They were honest with themselves.
[cpg cn=true]


[OnName num="masato"]
'............!
[cpg cn=true]



She has the same eyes as she did then.
[cpg]

An exam... or rather, an ordeal would have been more accurate, just like that time.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0094"]
[OnName num="sayo"]
What do you want to do? It would be very helpful if you could decide now...



[OnName num="masato"]
Let's see... I'm...
[cpg cn=true]

I don't know what to do. What am I supposed to do?


To take it or not to take it...or 1 or 2 if you do. Which one should I choose...?
[cpg]


;//■選択肢１
[switch]
[case "serve"]
	[swap]
	[jump target="*IseSel01_1"]
[case "be domesticated"]
	[swap]
	[jump target="*IseSel01_2"]
[case "say no"]
	[swap]
	[jump target="*IseSel01_3"]
[endswitch]


;//■選択肢
1. Serve.
2. to be kept.
No. 3.


;//==============================
;//１、お仕えするの場合
;//ご主人様である小夜にお仕えする展開。執事育成の様な感じで色々教育されながら、遊び相手としても調教されていく
;//Hシーンは少なめ。ご主人様と主従としての関係を深めていく

*IseSel01_1|M Dreams

;//[stflag f.first_select = 1]

[OnName num="masato"]
...to serve you.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0095"]
[OnName num="sayo"]
Yes," he said. Good boy."
[cpg cn=true]


She smiled happily.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0096"]
[OnName num="sayo"]
''Oh, and...''
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0097"]
[OnName num="sayo"]
Serving isn't as good as being a steward, so that's what you're supposed to do.
[cpg cn=true]


[OnName num="masato"]
''Then what is it...?''
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0098"]
[OnName num="sayo"]
"Hmmm... servant, I guess.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0099"]
[OnName num="sayo"]
You might as well be a servant and a pet...
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0100"]
[OnName num="sayo"]
It's good to see you. You're a cute little servant.
[cpg cn=true]


This is how I became the master's butler, or rather, his servant.
[cpg]


;//【ただいまEND】へのフラグ
;//※合流１へ
;//[jump target="*s14"]

[stflag gohome_flag=1]


[jump target="*IseSel01_4"]


;//==============================
;//２、飼われる
;//ご主人様である小夜にペットの様に飼われる展開。性的な相手をするだけ、に近い存在となってしまう
;//Hシーンは多め。プレイ内容もM男のライト層からマニア層に向けての広い内容。軽いものから徐々に重いものへ

*IseSel01_2|M Dreams

;//[stflag f.first_select = 2]

[OnName num="masato"]
...or keep it.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0095"]
[OnName num="sayo"]
Yes," he said. Good boy."
[cpg cn=true]


She smiled happily.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0101"]
[OnName num="sayo"]
"Well, you're my pet now. Make sure you do what I say.
[cpg cn=true]


[OnName num="masato"]
''Yes...''
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0102"]
[OnName num="sayo"]
Well, I'll treat him as a pet... but for the time being, he's nominally a servant.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0103"]
[OnName num="sayo"]
It's good to see you. You're a cute pet!
[cpg cn=true]


;//[jump target="*s14"]

[stflag pets_flag=1]
;//ペットフラグ

[jump target="*IseSel01_4"]

;//※合流１へ
;//==============================
;//３、断る

*IseSel01_3|M's Dream

[OnName num="masato"]
'............................................... sorry.
[cpg cn=true]


I couldn't shake my head, so I squeezed out just one word.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0104"]
[OnName num="sayo"]
'.......I see. I'm sorry, but it can't be helped.
[cpg cn=true]



[OnName num="masato"]
"......"
[cpg cn=true]



[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ



In this way, my connection with her disappeared, and I went back to my life as before...
[cpg]

;//少し間を置いて
[STOPBGM]


[SE f=se003]
;//【ＳＥ】『荷出しの音』ガタガタ


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=2100]
[BG f="b_03_2.ui" time=1]

[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[window target=true]

[BGM f="se"]


[OnName num="man_1"]
Hey, don't give me that shit!
[cpg cn=true]


[OnName num="masato"]
I'm sorry, I'm sorry...
[cpg cn=true]

;//【ＢＧ】『分岐路のある道』（昼）


[OnName num="man_1"]
''Oh, forget it. Take those to the warehouse. All of it, all of it.
[cpg cn=true]


[OnName num="masato"]
''Ha, yes!''
[cpg cn=true]


[WAIT time=2000]

;//レターボックスin
[FACE method="feadin" pos="4/7"]
[WAIT time=2000]


[OnName num="man_2"]
"Senior, can't you do something about that person? I don't want to work with you.
[cpg cn=true]


[OnName num="man_1"]
I don't like it either, but I can't do anything about it.
[cpg cn=true]


[OnName num="man_2"]
She's almost 40 years old now, isn't she?
[cpg cn=true]


[OnName num="man_1"]
Yeah... she's working part-time to make ends meet.
[cpg cn=true]


[OnName num="man_2"]
Ugh. That's not good at that age...I don't want to be like that.
[cpg cn=true]


[OnName num="man_1"]
Stop talking to me like that. You're on your own tomorrow.
[cpg cn=true]

[BG f="black.ui" time=1000]
[WAIT time=2000]

[FACE method="out" pos="4/7"]


[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
;//【ＢＧ】『空』（昼）******************************************************


[OnName num="masato"]
"......"
[cpg cn=true]


Whenever I disappear, there's always someone talking about me. He says a lot of things, thinking he's not around.
[cpg]

I've gotten used to being told so many things by now.
[cpg]

To my dad, to my mom, to my friends.
[cpg]

What the hell are you doing at your age... it's pathetic... it's pretentious... it's all right and there's nothing you can say back.
[cpg]

After all, nothing has changed for me since those days. It's the same life over and over again.
[cpg]

[OnName num="masato"]
''(What to do, I want to go get the rest of my stuff...)''
[cpg cn=true]


I'm turning 40 and I'm miserable about everything. There is no turning point in life.
[cpg]

--no, I was visiting.
[cpg]

That time... that was my first and last chance.
[cpg]

However, I was determined to protect my little pride, and the result is the life I live now.
[cpg]

I'm miserable now.
[cpg]

[OnName num="masato"]
''(Ah...I want to go home early. (I've got a new loli book...I want to clean up with that thing).
[cpg cn=true]


I spend my days looking at books about being bullied by small children, fantasizing and ejaculating...sometimes dreaming and dreaming.
[cpg]

The child in my fantasy is her.
[cpg]

If I had responded differently back then...like a delusion, the little girl who would have been the master.
[cpg]

I'm sure she's an amazing beauty now.
[cpg]

Oh my God... it makes me want to die just thinking about it.
[cpg]

I want to die, I want to forget, I want to pull out a Lolita... I remember it all over again.
[cpg]

I'm sure I'll keep thinking about her and regretting it until the day I die.
[cpg]

In hindsight, it has become a one-time, exciting event in a dull, mundane day, only waiting to fade and fade away.
[cpg]

Time passes, and it goes from being a vivid memory to being part of a delusion that you can't tell if it's true or false.
[cpg]

[SE f=se003]
;//【ＳＥ】『荷出しの音』
[WAIT time=1500]

[OnName num="man_1"]
Oh! Whoa! What are you slacking off on!
[cpg cn=true]


[OnName num="masato"]
''Ah...''
[cpg cn=true]


[OnName num="man_1"]
You'll miss it! Hey, help me out here! The three of us are going to end this!
[cpg cn=true]


[OnName num="man_2"]
What the hell...they're increasing the burden again...
[cpg cn=true]


[OnName num="masato"]
''I'm sorry...I'm sorry...I'm really...sorry.
[cpg cn=true]


[OnName num="man_1"]
Stop mumbling and move your hands! Let's hurry up!
[cpg cn=true]



[SE f=se003]
;//【ＳＥ】『荷出しの音』
[WAIT time=1500]


...I should have been more honest about my feelings sooner.
[cpg]

I will continue to regret it until the moment I die.
[cpg]


[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=3100]

[BG f="black.ui" time=1]


[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ＢＫ

Please, please, please. Please, my little angels.
[cpg]

It could be anyone. So please.
[cpg]

--Someone please bully my manhood.
[cpg]



;//フェードアウト

[jump storage="epend.ks" target="*back_title"]

;//ＢＡＤＥＮＤ
;//==============================

*IseSel01_4


[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[FO pos="2/3" time=2000]
[BG f="black.ui" time=2000]
[WAIT time=2500]

[jump storage="ep003.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////
;//※合流１
;//※下僕、ペットのどちらを選んでもストーリーは基本共通で進みます。
