*start

;#################################################
*Ep009|Loli Golden Water - Sparkling Holy Water Flavor
;#################################################

[SCENE id=9]


[stflag jump_scene=0]
[window target=false]


;//レターボックス初期召喚
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]

[WAIT time=1000]
[STOPBGM]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]

[WAIT time=1500]

[BGM f="sl"]
;//【ＢＧ】『小夜の部屋』（夕方）******************************************************


[window target=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0585"]
[OnName num="sayo"]
Do I really have to do this?
[cpg cn=true]


[OnName num="masato"]
「……」
[cpg cn=true]


From the young lady's sorrowful expression and sorrowful words, the atmosphere in the room in the evening was even more sunken.
[cpg]

[OnName num="butler"]
''Miss, I understand how you feel. It's really hard for me too.
[cpg cn=true]


[VOICE f="Sayo0586"]
[OnName num="sayo"]
'Well, then...'
[cpg cn=true]


[OnName num="butler"]
I'm sorry. It's what the Master says.
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0587"]
[OnName num="sayo"]
''Shun...''
[cpg cn=true]


It's cute that the master makes a depressing onomatopoeic sound.
[cpg]

No, no, no!
[cpg]

What am I supposed to say to her as a servant?
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0588"]
[OnName num="sayo"]
Hahahahaha................................................................
[cpg cn=true]


[OnName num="butler"]
Well, let's get right to it.
[cpg cn=true]




[SE f="se036"]
;//【ＳＥ】『』ガラガラガラ
;//※レストランとかホテルで料理持ってくるやつ。名前が分からない



[OnName num="masato"]
...wine?
[cpg cn=true]


Wine bottles are brought into the room one after another.
[cpg]

No, it's not just wine... they have all sorts of bottles of brandy, whiskey, sake, etc.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0589"]
[OnName num="sayo"]
Huh..... I came home from school, practiced, practiced, practiced...and now I've got this today?
[cpg cn=true]


[OnName num="butler"]
''I understand your daughter's feelings so much that it hurts. But the Master's...
[cpg cn=true]


[VOICE f="Sayo0590"]
[OnName num="sayo"]
It's your father's idea, isn't it? I know.
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0591"]
[OnName num="sayo"]
I know, but...
[cpg cn=true]


The other maids and butlers are getting ready quickly, even in front of her with an unhappy face.
[cpg]

It was so fast that it was arranged while Tanaka-san was appeasing it.
[cpg]

[OnName num="masato"]
Um, Mr. Tanaka...what the hell is your master doing?
[cpg cn=true]


[OnName num="butler"]
It's a tasting. Simply put, it's a way to train your tongue to be able to tell the difference between what's good and what's not.
[cpg cn=true]


[OnName num="masato"]
''Hahaha...you do that, don't you? The rich are.
[cpg cn=true]


[OnName num="butler"]
''As a daughter of the family of Osanagi, there are many things that are required of you.
[cpg cn=true]


[OnName num="masato"]
But she doesn't like it very much. Why is that?
[cpg cn=true]


[OnName num="butler"]
 "... My lady likes cocoa with plenty of sugar and milk." 
[cpg cn=true]


[OnName num="masato"]
I see! Does that mean you don't like alcohol because you're a kid with a taste for it!
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0592"]
[OnName num="sayo"]
"Kick.
[cpg cn=true]


[OnName num="masato"]
Hi!
[cpg cn=true]


[VOICE f="Sayo0593"]
[OnName num="sayo"]
''I felt like I just heard some...extra irritating words, but I wonder if it's just my imagination...?
[cpg cn=true]


[OnName num="masato"]
"No, I didn't say anything! Yes, sir! Of course it's your imagination!
[cpg cn=true]


[VOICE f="Sayo0594"]
[OnName num="sayo"]
"Choose what you like. One bottle is enough to pay you for a month, so I'd say it's a worthy death.
[cpg cn=true]


[OnName num="masato"]
"Don't beat me to death with that expensive thing! I'm a guy who's only worth about as much as the cheap drinks at the supermarket!
[cpg cn=true]


[OnName num="butler"]
"Lady"
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0595"]
[OnName num="sayo"]
'..........hmmm.
[cpg cn=true]


Putting down the bottle he had already swung up, Master thumped and misbehaved and sat back down in his chair.
[cpg]

It made me realize how much I disliked the behavior that a normal girlfriend would never do.
[cpg]

[OnName num="butler"]
You don't have to drink it, just moisten it as you always do, and that's fine.
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0596"]
[OnName num="sayo"]
I know.
[cpg cn=true]


As if he had made up his mind, the master caught his breath and picked up the glass that had been poured the right amount.
[cpg]

He takes a small amount in his mouth and rolls it on his tongue for a tasting. Maybe.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0597"]
[OnName num="sayo"]
It's a chateau. Château Mouton Rothschild.
[cpg cn=true]


[OnName num="butler"]
Yes, that's right.
[cpg cn=true]




[SE f="se041"]
;//【ＳＥ】『グラスの音』カチャカチャ


Then, the master guessed the brand of alcohol one after another.
[cpg]

She doesn't seem to swallow because she doesn't like alcohol. It's like you're judging by the taste and smell on your tongue without swallowing... great.
[cpg]

[OnName num="masato"]
(I don't know what's what.)
[cpg cn=true]


I'm sure that even if they make you drink it, you can only say "it's good" and "it's not good".
[cpg]

I'm not sure if this is what the upper class needs to be able to do, but...
[cpg]

The master's figure is beautiful to watch and looks good.
[cpg]


I guess this is what it means to be gazing at it unconsciously.
[cpg]

Suddenly, I felt that I was happy to be working for such a person.
[cpg]


[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ





--A few hours later--



[BGM f="co" time=1000]
[BG f="b_04_4.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（夜）******************************************************


[SE f="se050"]
;//【ＳＥ】『瓶とか倒す音』ガタガタガチャンガタガタガチャン


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo0598"]
[OnName num="sayo"]
I can't drink anymore...hiccup...
[cpg cn=true]


[OnName num="butler"]
「……」
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


A few hours after I started the tasting, I'm in big trouble.
[cpg]

[OnName num="masato"]
Excuse me, Mr. Tanaka.
[cpg cn=true]


[OnName num="butler"]
「はい」
[cpg cn=true]


[OnName num="masato"]
"You look like your master is drunk...
[cpg cn=true]


[OnName num="butler"]
You're definitely drunk.
[cpg cn=true]


[OnName num="masato"]
I guess I'm not very good at drinking.
[cpg cn=true]


[OnName num="butler"]
He's a man who gets lightly intoxicated just by the smell.
[cpg cn=true]


I don't feel like I should let someone like that do this to me.
[cpg]

Watching this, I can see that the master was completely drunk.
[cpg]

I haven't drunk it in my mouth many times, but I'm sure I'll get drunk if I repeat it that many times.
[cpg]

[FG f="CHA01_p2_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0599"]
[OnName num="sayo"]
Sigh... I can't do it anymore... I can't do it anymore...
[cpg cn=true]


[OnName num="masato"]
'(This is the type of thing that gets you sick.)''
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0600"]
[OnName num="sayo"]
Tanaka!
[cpg cn=true]


A large voice and a call out made my shoulders tremble with excitement.
[cpg]

[OnName num="butler"]
'Yes, sir, what is it?'
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo0601"]
[OnName num="sayo"]
...is it a cat?
[cpg cn=true]


[OnName num="butler"]
"Ha.
[cpg cn=true]


[VOICE f="Sayo0602"]
[OnName num="sayo"]
Is it a cat? Cat? Hey, you there?
[cpg cn=true]


[OnName num="butler"]
"... ...I'm a dog, if you like...
[cpg cn=true]


And there it is! A drunken nonsensical tangle!
[cpg]

Tanaka-san is desperately trying to be a butler in response! I can't help but feel unhappy that something is clearly in trouble!
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0603"]
[OnName num="sayo"]
Is it a dog? A dog.....................................
[cpg cn=true]


[OnName num="butler"]
I'm sorry I didn't meet your expectations.
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo0604"]
[OnName num="sayo"]
What about the cat? Is there a cat in the house?
[cpg cn=true]


[OnName num="masato"]
Tanaka-san...why a cat?
[cpg cn=true]


[OnName num="butler"]
''Speaking of which, the lady said that she would like to have a cat soon. Could it be because of that?
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo0605"]
[OnName num="sayo"]
"Cat! I don't have a cat! Cat, cat, cat! Cat cat cat cat cat cat kitten cat!
[cpg cn=true]




[SE f="se051"]
;//【ＳＥ】『テーブルを叩く』バンバン




Oh, it's rampaging... the master is rampaging while yelling at the cat. It's an unbelievable sight, unimaginable from what she usually looks like.
[cpg]

[SE f="se050"]
;//【ＳＥ】『物が落ちる』ガッチャンガッチャン


[OnName num="masato"]
''Mr. Tanaka...what is this house pet...''
[cpg cn=true]


[OnName num="butler"]
'Yes, it's only Brunark. Oh, and one more thing... the other.
[cpg cn=true]


[OnName num="masato"]
Don't look at me! You don't have to be blurry at a time like this!
[cpg cn=true]


[SE f="se050"]
;//【ＳＥ】『物が落ちる』ガッチャンガッチャン



[FG f="CHA01_p2_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0606"]
[OnName num="sayo"]
"Hey, you know what?
[cpg cn=true]



[SE f="se052"]
;//【ＳＥ】『物を投げる』ビュンビュンパリーン



[OnName num="butler"]
Dear Masato, do something about it.
[cpg cn=true]


[SE f="se053"]
;//【ＳＥ】『暴れる』


[OnName num="masato"]
You're a useless butler when it comes down to it, aren't you!
[cpg cn=true]



[STOPBGM]
;//急に無音になる


[FG f="CHA01_p2_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0607"]
[OnName num="sayo"]
.............................................
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0608"]
[OnName num="sayo"]
Where's the cat? Cat, no cat... no cat, no cat, no cat...
[cpg cn=true]


Oooh, now I'm crying!
[OnName num="butler"]
Oooh, now I'm crying!
[cpg cn=true]


[OnName num="masato"]
Mr. Masato, please do something urgently!
[cpg cn=true]


[OnName num="butler"]
''Hey, you can't even say that to me! You can arrange for one of the cats right away with your financial resources!
[cpg cn=true]


[OnName num="masato"]
Like a cartoon like that.
[cpg cn=true]


[VOICE f="Sayo0609"]
[OnName num="sayo"]
This development is cartoonish enough!
[cpg cn=true]


[OnName num="butler"]
"Whew...whew...whew, whew, whew...
[cpg cn=true]


[OnName num="butlerA&maidA"]
"Oh, come on, come on! Letting the young lady shed tears is outrageous!!!
[cpg cn=true]


[OnName num="masato"]
That's right, that's right.
[cpg cn=true]


"C'mon, c'mon, c'mon...
[cpg]


[VOICE f="Sayo0610"]
[OnName num="sayo"]
However, even though it's because of the alcohol... I can't let the master cry like this.
[cpg cn=true]


[OnName num="butler"]
Ewwww, eww, hiccup... hiccup...
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0611"]
[OnName num="sayo"]
''Mistress, there is a cat. Please stop crying.
[cpg cn=true]


[OnName num="masato"]
Phew... are you there? Do you have a cat?
[cpg cn=true]


Where the hell is the cat...?
[OnName num="butler"]
and then
[cpg cn=true]


'........................................................................................................................
[cpg]

[OnName num="masato"]
Tanaka-san winked at me with a bang.
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0612"]
[OnName num="sayo"]
(Me, aaaaahhhhhhhhhh!)
[cpg cn=true]


...are you a cat?
[cpg]

[OnName num="masato"]
I had a choice to make, and I decided to do it.
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo0613"]
[OnName num="sayo"]
 “………………… Meow ~” 
[cpg cn=true]




[SE f="se015"]
;//【ＳＥ】『飛びついてくる』ガバッ


[OnName num="masato"]
"Cat!
[cpg cn=true]


[VOICE f="Sayo0614"]
[OnName num="sayo"]
Whoa!
[cpg cn=true]


"Oooh, fluffy, fluffy, fluffy.
[cpg]

He seemed to think I was a serious cat, so he suddenly hugged me and started stroking my head.
[cpg]

It's kind of nice that we're in this situation, but... what do we do from here on out?
[cpg]

[OnName num="butler"]
She moved her gaze toward Tanaka-san as if to ask for help.
[cpg cn=true]


[OnName num="masato"]
Good luck.
[cpg cn=true]


"Oh, you heartless bastard!
[cpg]

*Scene10

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ


[BGM f="h1" time=1000]

;//●ＣＧエロ（雅人＆小夜・泥酔した小夜が甘えさせてくれる。赤ちゃんプレイ：小夜の部屋）ev_07
;※泥酔した小夜は普段より優しくなり甘えさせてくれる。ここぞとばかりに赤ちゃんプレイ。
[cpg]


;**【ＣＧ】ev_07_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[VOICE f="Sayo0615"]
[OnName num="sayo"]
The butlers and maids, including Tanaka-san, had left the room.
[cpg cn=true]

''Hmmm~. Let's go, let's go!
[cpg]

[OnName num="masato"]
The master without a tongue in cheek is cute.
[cpg cn=true]


"I don't know what to do about this situation.
[cpg]

I'm pretending to be a cat and she's holding me and stroking my head.
[cpg]

[VOICE f="Sayo0616"]
[OnName num="sayo"]
I don't know what the hell to do from here, and I'm slumped over.
[cpg cn=true]


[OnName num="masato"]
''Fluffy, fluffy...fluffy..........fluffy?
[cpg cn=true]


[VOICE f="Sayo0617"]
[OnName num="sayo"]
''(Oh, no!) Even when I'm drunk, I'm still questioning the difference in feel!")
[cpg cn=true]


[OnName num="masato"]
"Cat, isn't it fluffy?
[cpg cn=true]


'(What should I do!)'' (Fluffy, fluffy...what to do!)
[cpg]


;//ズボンを下ろして玉を触らせる

;**【ＣＧ】ev_07_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[VOICE f="Sayo0618"]
[OnName num="sayo"]
The only place on my body that's fluffy and fluffy is...
[cpg cn=true]


Oh. It's fluffy...
[cpg]

[OnName num="masato"]
I pulled her hand away and let her grab my testicles.
[cpg cn=true]


Nyah, Nyah~ (Master, I'm really sorry, I'm really sorry, I'm really sorry)
[cpg]

It's an outrageous thing to let your master stroke your golden balls.
[cpg]


[VOICE f="Sayo0619"]
[OnName num="sayo"]
But when I was told I was fluffy, I couldn't think of anywhere else.
[cpg cn=true]


[OnName num="masato"]
Neko-san's fluffy, it feels good.
[cpg cn=true]


Meow! (I feel good too!)
Fuunu, Fuunu, Fuunu.
[cpg]

[OnName num="masato"]
'Ha, ha...ha, ha...ha...'
[cpg cn=true]


Her small hands wrapped around the golden ball and squeezed it.
[cpg]

The sexual pleasure of the gentle and occasional strong squeezing made my dick harden.
[cpg]


[VOICE f="Sayo0620"]
[OnName num="sayo"]
"You're squishy.
[cpg cn=true]


[OnName num="masato"]
''Ha-ha-ha... ah-ha-ha... ah-ha-ha... meow-ha-ha...''
[cpg cn=true]


Honestly, it's hard to even continue acting as a cat who sucks.
[cpg]

[OnName num="masato"]
"(Aaahhhh...it feels good...smooth little hands, my balls are squeezing!)
[cpg cn=true]


Sneeze. Sneeze. Sneeze.
[cpg]


[VOICE f="Sayo0621"]
[OnName num="sayo"]
? Do you feel good, cat?
[cpg cn=true]


[OnName num="masato"]
Nya-Nya-Nya!
[cpg cn=true]


It feels so good that my head is already light-headed.
[cpg]


[VOICE f="Sayo0622"]
[OnName num="sayo"]
''Hmmm~~? Cat...is it a boy or a girl?
[cpg cn=true]


Master says as he notices the genitals pointing upwards as he can show them.
[cpg]

[OnName num="masato"]
Nyah. (Yes.)
[cpg cn=true]


[VOICE f="Sayo0623"]
[OnName num="sayo"]
It's so cute. It's a kitten, isn't it?
[cpg cn=true]


It's a little sad to be judged as a kitten there, but even more gratifying is what happened.
[cpg]


[VOICE f="Sayo0624"]
[OnName num="sayo"]
"Tick-tock.
[cpg cn=true]


[OnName num="masato"]
"Meow!
[cpg cn=true]



[VOICE f="Sayo0625"]
[OnName num="sayo"]
"Hiccup.
[cpg cn=true]


Master's fingers pecked at the rod part.
[cpg]

It makes me want more, and my hips move on their own and I rub the tip of my dick against her hand.
[cpg]


[VOICE f="Sayo0626"]
[OnName num="sayo"]
"Good-for-nothing.
[cpg cn=true]


[OnName num="masato"]
"Ha-ha-ha-ha.
[cpg cn=true]


Because the master tightly embraces the breast more strongly, I also get close to it just by chance.
[cpg]

He pressed his face against her abdomen and chest area, sniffing and sniffing, then leaned his lower body toward her hand.
[cpg]


[VOICE f="Sayo0627"]
[OnName num="sayo"]
''Alright, alright, good boy. Good, good, good.
[cpg cn=true]


[OnName num="masato"]
''(Master smells sweet and good.)''
[cpg cn=true]


A feeling that not only fills my lungs, but also my head and classles.
[cpg]

It's like a drug for me.
[cpg]

;**【ＣＧ】ev_07_b ***********************
[CG id=6 index=2 time=1000]
;***************************************
[VOICE f="Sayo0628"]
[OnName num="sayo"]
Hiccup.
[cpg cn=true]


[OnName num="masato"]
Meow, meow, meow!
[cpg cn=true]


[VOICE f="Sayo0629"]
[OnName num="sayo"]
'Ahahahaha, that tickles me.
[cpg cn=true]


[OnName num="masato"]
''(Master, I'm sorry!)''
[cpg cn=true]


The collapse of reason, the runaway sexual desire. It's not so much that I'm on a roll, it's that I can't stand it.
[cpg]

I sucked on her breasts from the top of my clothes.
[cpg]

He explored her small breasts, hidden by her clothing, with his face and mouth, wriggling and sucking on them.
[cpg]


[VOICE f="Sayo0630"]
[OnName num="sayo"]
Neko-san, it's a baby. tottering.
[cpg cn=true]


It must have been set up as a kitten in the master's mind.
[cpg]

I took advantage of this and sucked on her chest as if it was the right time to do so.
[cpg]

[OnName num="masato"]
"(Master's cherries!) (Cherry nipples!)
[cpg cn=true]


[VOICE f="Sayo0631"]
[OnName num="sayo"]
"Cats, I'm gonna roll over!
[cpg cn=true]


It's small, but well-shaped, crunchy and delicious.
[cpg]

[OnName num="masato"]
I don't know what to say.
[cpg cn=true]


[VOICE f="Sayo0632"]
[OnName num="sayo"]
"Even if you suck on it, your tits won't show.
[cpg cn=true]


[OnName num="masato"]
"Jingle, jingle, jingle...jingle...jingle...jingle...jingle.
[cpg cn=true]


[VOICE f="Sayo0633"]
[OnName num="sayo"]
Huh...huh...huh...feline...huh...huh...huh...huh...huh...huh.
[cpg cn=true]


Reason had collapsed long ago. I can't go back, and I'm desperately sucking on my nipples.
[cpg]

She sucked on her breasts and nipples at different angles and positions, making a number of kiss marks.
[cpg]

[OnName num="masato"]
''Haha, haha...haha...haha...haha...haha!
[cpg cn=true]


It's a fully fledged animal.
[cpg]


[VOICE f="Sayo0634"]
[OnName num="sayo"]
Cat, do you want my tits?
[cpg cn=true]




[SE f="se013"]
;//【ＳＥ】『服をはだけさせる』

;**【ＣＧ】ev_07_c ***********************
[CG id=6 index=3 time=1000]
;***************************************
I couldn't believe what was being served up to me and looked at my eyes.
[cpg]


[VOICE f="Sayo0635"]
[OnName num="sayo"]
Here you go.
[cpg cn=true]


[OnName num="masato"]
(My master's tits... in front of me...)
[cpg cn=true]


[VOICE f="Sayo0636"]
[OnName num="sayo"]
My tits... Don't you want it? Didn't you want boobs?
[cpg cn=true]


[OnName num="masato"]
Hup!
[cpg cn=true]


[VOICE f="Sayo0637"]
[OnName num="sayo"]
''Huh?''
[cpg cn=true]


I'd like to thank you for this.
[cpg]


[VOICE f="Sayo0638"]
[OnName num="sayo"]
I'm sorry my tits are so small.
[cpg cn=true]


[VOICE f="Sayo0639"]
[OnName num="sayo"]
I can't even give you milk, but you have to be patient, cat.
[cpg cn=true]


Master's tits are so delicious that I don't care about such details, though it would be even better if they came out with milk.
[cpg]

Maybe it's because I usually eat high quality food, but the elasticity around my chest is great even though it's small, it's soft and pimply and feels good.
[cpg]

It's almost like I want to keep it in my mouth. Plus, the sweat is just a little soggy and the smell is floral.
[cpg]

The girl's unique body odor makes me more excited.
[cpg]

[OnName num="masato"]
(Delicious, delicious.) (It even feels sweet... and the sweat is delicious).
[cpg cn=true]


[VOICE f="Sayo0640"]
[OnName num="sayo"]
Cat, that's intense. Oh, it's a little...painful...
[cpg cn=true]


[OnName num="masato"]
Hmph. Hmph."
[cpg cn=true]


[VOICE f="Sayo0641"]
[OnName num="sayo"]
''Ahhhhhhhh...hahhhh....''
[cpg cn=true]


Master also seems to be feeling a little bit of the sucking on his chest.
[cpg]

[OnName num="masato"]
Hmmm. Sniffle.
[cpg cn=true]


[VOICE f="Sayo0642"]
[OnName num="sayo"]
"Cat's tongue is kind of...wet...ahhhhh, ahhh, ahhh!
[cpg cn=true]


[OnName num="masato"]
(I'm sorry!)
[cpg cn=true]


Surely cats and human babies who want boobies don't lick like this.
[cpg]


[VOICE f="Sayo0643"]
[OnName num="sayo"]
''Huh, huh...huh, huh. I'm sure you'll find that you're in a lot of pain.
[cpg cn=true]


[OnName num="masato"]
!
[cpg cn=true]


Sawa, sawa, sawa.
[cpg]


[VOICE f="Sayo0644"]
[OnName num="sayo"]
It's so swollen, so painful... I'll pet you.
[cpg cn=true]


When he said that, Master started stroking his pubic area more carefully than before.
[cpg]

The movement of his hands and fingers is different from the way he used to work on his balls.
[cpg]

Gentle, gentle...yet a move that seems like a sexual gesture.
[cpg]

[OnName num="masato"]
''(Aaahhhh, when they do that to you...)''
[cpg cn=true]


Excitement that drove me crazy. A spurting, ending fluid crept up from her testicles.
[cpg]

[OnName num="masato"]
Ching ching ching ching ching ching ching!
[cpg cn=true]


[VOICE f="Sayo0645"]
[OnName num="sayo"]
What? It hurts, it hurts, it hurts...if you suck so hard, it will hurt!
[cpg cn=true]


[OnName num="masato"]
''(Don't stop, don't stop!)''
[cpg cn=true]


No matter how angry I was, there was nothing I could do to suppress the libido that had gotten me this far.
[cpg]

All I could think of was "I want to cum while sucking on Master's tits".
[cpg]

[OnName num="masato"]
''Haha, haha. Ahhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh!
[cpg cn=true]


[VOICE f="Sayo0646"]
[OnName num="sayo"]
''Ugh, ahhh...ahhh...ahhh...ahhh...''
[cpg cn=true]


[VOICE f="Sayo0647"]
[OnName num="sayo"]
''Huh, ah... that's no good! Ahhhh, ahhhh!
[cpg cn=true]


[OnName num="masato"]
"Squirt, squirt...squirt, squirt, squirt, squirt.
[cpg cn=true]


Her chest area was smeared with saliva, and a kiss mark had formed from sucking so hard here and there.
[cpg]

I'm literally in a state where her breasts are being fucked with my mouth.
[cpg]


[VOICE f="Sayo0648"]
[OnName num="sayo"]
''Ahhhh...ahhh...ahhh...darn! I feel something...weird...ahhh!
[cpg cn=true]


[OnName num="masato"]
"Oh, no, I'm getting out.
[cpg cn=true]


I was about to finish, making whimpering noises and sucking on my chest as I was being touched in the pubic area.
[cpg]

[OnName num="masato"]
"Juju juju, juju juju, juju juju.
[cpg cn=true]


[VOICE f="Sayo0649"]
[OnName num="sayo"]
"Huh...hmmm...hmmm...hmmm. No, no, no, no, no, no, no, no, no, no, no, no, no, no!
[cpg cn=true]


[VOICE f="Sayo0650"]
[OnName num="sayo"]
My body is hot... ahhhhhhh... something's coming...!!
[cpg cn=true]


The young lady started acting strange, and then...


;//フラッシュ


;//小夜絶頂

;**【ＣＧ】ev_07_d ***********************
[CG id=6 index=4 time=1000]
;***************************************
[VOICE f="Sayo0651"]
[OnName num="sayo"]
 "Funny! 
[cpg cn=true]


[VOICE f="Sayo0652"]
[OnName num="sayo"]
''Ahhhh...ahhh...ahhh...ahhh...ahhh...ahhh...ahhh...ahhh...ahhh...ahhh...ahhh...ahhh.
[cpg cn=true]




;//フラッシュ


[SE f="se026"]
;//【ＳＥ】『射精音』

;**【ＣＧ】ev_07_e ***********************
[CG id=6 index=5 time=1000]
;***************************************
--thump, thump, thump, thump, thump!
[OnName num="masato"]
'(Hahahaha...it's out. I had my master touch me and I let it out...)
[cpg cn=true]


[VOICE f="Sayo0653"]
[OnName num="sayo"]
''Ha, ha...ha...ha...ha...ha...ha...ha.
[cpg cn=true]


Apparently, the master also came out of it because he was relentlessly sucking and playing with her breasts.
[cpg]


[VOICE f="Sayo0654"]
[OnName num="sayo"]
Cat, san...
[cpg cn=true]


And then I collapsed on my back on the bed, exhausted or not, because I came.
[cpg]

[OnName num="masato"]
Ha, ha..."
[cpg cn=true]


Like my master, I can't move my body because I got a strong feeling of pleasure from the ejaculation from the great excitement.
[cpg]

I was similarly groggy and limp for a while.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BG f="b_04_4.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（夜）******************************************************


A few minutes later...when the aftermath of my ejaculation had subsided and my mood had calmed down, I finally sat up.
[cpg]

[OnName num="masato"]
''Sir, Master...''
[cpg cn=true]


[VOICE f="Sayo0655"]
[OnName num="sayo"]
''Hmmm...''
[cpg cn=true]


When I chill out and look at the current situation, it's a lot worse. It's my own fault, too.
[cpg]

The master lying on his back is covered in my dirty cum. The situation is so bad that I can't complain about being killed.
[cpg]

[OnName num="masato"]
I've done it.
[cpg cn=true]


It's too late to be self-loathing now. Our great forebears said it was foolish to give in to a temporary sexual desire.
[cpg]

[OnName num="masato"]
''Master...I'm really, really sorry.
[cpg cn=true]


[VOICE f="Sayo0656"]
[OnName num="sayo"]
Ughhhhhhhh........................................................................................
[cpg cn=true]


[OnName num="masato"]
I'm sleeping...
[cpg cn=true]


There's no point in apologizing. Besides, the current master didn't hear me.
[cpg]

I think he's fallen asleep, so I'll apologize to him tomorrow. No matter what happens, it's your fault.
[cpg]

[OnName num="masato"]
''And, anyway, even if it's just cleaning...!''
[cpg cn=true]


It doesn't make any amends, but out of self-satisfaction of conscience, I start cleaning.
[cpg]

The face and the breast that was exposed also became covered with semen.
[cpg]

You can't let your master sleep in this state.
[cpg]

[OnName num="masato"]
"Master, I'll wipe you down...
[cpg cn=true]

[BG f="black.ui" time=1000]
;//ＢＫ



[BGM f="h1"]

;//●ＣＧエロ（雅人＆小夜・泥酔してお漏らしをする小夜の便器になる：小夜の部屋）ev_08
;//※ここではまだ寝ているだけ

;**【ＣＧ】ev_08_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************


[VOICE f="Sayo0657"]
[OnName num="sayo"]
"Soooooooooo. mumbling.
[cpg cn=true]


[OnName num="masato"]
'(Sleeping face, how cute.)''
[cpg cn=true]


I still can't believe that such a pretty person is my master.
[cpg]

I may be the happy one.
[cpg]

But what have I done to my master when he's drunk and unconscious? Self-hatred again.
[cpg]

[OnName num="masato"]
''Oh...even in my clothes...''
[cpg cn=true]


I don't know how much momentum I put into it. It looks like it's gone all the way down to her breasts and her belly.
[cpg]

But if I leave it like this, my clothes will get dirty and shiny and smell...
[cpg]

[OnName num="masato"]
I'm sorry...I'll take it off. We'll just wipe it down.
[cpg cn=true]


In a way, there's nothing to be afraid of because they've already been outrageously disrespectful.
[cpg]


[SE f="se013"]
;//【ＳＥ】『服を脱がせる』

;**【ＣＧ】ev_08_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[VOICE f="Sayo0658"]
[OnName num="sayo"]
 "Uh ... soooooooooooooo ..." 
[cpg cn=true]


[OnName num="masato"]
''Huh...!''
[cpg cn=true]


She had removed her clothes, so naturally she would be in her underwear. My bra is so displaced it's almost meaningless.
[cpg]

The master is almost naked.
[cpg]

I've even taken a bath with them, so I've seen them at times...but now that I see them like this, it's different.
[cpg]

[OnName num="masato"]
No! No, no, no! What the hell are you thinking!
[cpg cn=true]


What more are you going to do? He lightly tapped his swollen crotch in self-control.
[cpg]

I have to use my rational mind and clean up Master's body...or put him in his pajamas.
[cpg]

I'll ask Tanaka-san to bring me a change of clothes.
But in that moment.....
[cpg]

[BG f="black.ui" time=1000]
;//ＢＫ


[STOPBGM]
[BG f="b_04_4.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（夜）******************************************************


[SE f="se015"]
;//【ＳＥ】『起き上がる』ガバッ


[VOICE f="Sayo0659"]
[OnName num="sayo"]
"..............."
[cpg cn=true]


[OnName num="masato"]
"Hi!
[cpg cn=true]


Master only raised his upper body as if it were a Kyonsi.
[cpg]

[OnName num="masato"]
''Ah, ah... master, you're awake...?''
[cpg cn=true]


Even if nothing had to happen at this time, I would be teary-eyed.
[cpg]

[VOICE f="Sayo0660"]
[OnName num="sayo"]
.............................................
[cpg cn=true]


[OnName num="masato"]
「？」
[cpg cn=true]


[VOICE f="Sayo0661"]
[OnName num="sayo"]
".........................................
[cpg cn=true]


[OnName num="masato"]
What?"
[cpg cn=true]


[VOICE f="Sayo0662"]
[OnName num="sayo"]
...pee.
[cpg cn=true]


[OnName num="masato"]
.................................................................................................
[cpg cn=true]


Apparently, Master is not even fully awake, he's still sleeping.
[cpg]

If you look closely, you're still sleepy-eyed.
[cpg]


[VOICE f="Sayo0663"]
[OnName num="sayo"]
"Pee.
[cpg cn=true]


[OnName num="masato"]
''Ha, yes...well...let's see...this way...''
[cpg cn=true]


I'm sure he can't walk alone, so I give him my shoulder and try to lead the way.


[SE f="se015"]
;//【ＳＥ】『倒れる』バタッ、ボフンッ


[OnName num="masato"]
Huh! Hey, master!
[cpg cn=true]


[VOICE f="Sayo0664"]
[OnName num="sayo"]
Sneeze...sneeze...sneeze...sneeze...sneeze...
[cpg cn=true]


[OnName num="masato"]
He's asleep! I mean, where's the pee? What are you going to do about it!
[cpg cn=true]


With a bang, I fell asleep again. Oh, no. This is a big deal.
[cpg]

[OnName num="masato"]
Master! Wake up, please! You want to go pee!
[cpg cn=true]


[VOICE f="Sayo0665"]
[OnName num="sayo"]
''Ugh...Ugh...Ugh...Ugh...Ugh...Ugh.
[cpg cn=true]


It's not good, it's not good... you need to go to the bathroom, but you're sleeping on it, that's a big problem.
[cpg]

I'm sure everyone has experienced this when they were a kid, but this pattern is like having a water-related dream and having a map of the world in the morning.
[cpg]

[OnName num="masato"]
Master! Master! Wake up, please! Let's go to the bathroom! Just the toilet! Then go back to sleep!
[cpg cn=true]




;//☆ＣＧエロ（雅人＆小夜・泥酔してお漏らしをする小夜の便器になる：小夜の部屋）ev_08
;//CGを再び表示

;**【ＣＧ】ev_08_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[VOICE f="Sayo0666"]
[OnName num="sayo"]
"Oooh, oooh... oooh, oooh... oooh, oooh.
[cpg cn=true]


[OnName num="masato"]
No, this!
[cpg cn=true]


She was already on the verge of a deep sleep. Or rather, I don't think I'm going to get up because I'm drunk.
[cpg]

[OnName num="masato"]
What do I do? !
[cpg cn=true]


A urinal? I wonder if this house has any urinals, because they're rich... and they don't have any? I'll ask Mr. Tanaka about it first...
[cpg]


[VOICE f="Sayo0667"]
[OnName num="sayo"]
''Hmmm...hmmm...hmmm...hmmm...''
[cpg cn=true]


[OnName num="masato"]
Wow! It's starting to creep up on me!
[cpg cn=true]


Without a moment's delay, she began to cower, rubbing her inner thighs together.
[cpg]

Does this mean that I can't stand the toilet anymore, I'm going to get out! In other words, we don't have a moment to lose.
[cpg]

[OnName num="masato"]
Please forgive my repeated rudeness!
[cpg cn=true]


[BG f="black.ui" time=1000]
;//ＢＫ

[SE f="se015"]
;//【ＳＥ】『下着を下ろす』ガバッ

;**【ＣＧ】ev_08_b ***********************
[CG id=7 index=2 time=1000]
;***************************************

In a panic of what the hell am I supposed to do now...I do what comes to mind.
[cpg]

Now the only thing that serves the function of hiding your bare skin is to pull down your underwear and stuff it with...tesh!
[cpg]

[SE f="se054"]
;//【ＳＥ】『ティッシュを大量に取り出す』シャッシャッシャッシャッシャッ

;**【ＣＧ】ev_08_c ***********************
[CG id=7 index=3 time=1000]
;***************************************

With the momentum to use up the entire box, he takes out a tissue, rolls it up a bit, and stuffs it between his legs.
[cpg]

[OnName num="masato"]
"(Master's slippery face... no, don't be distracted! Patience, patience, patience! Ignore, ignore, ignore! (That's not a bun, it's a cracked peach or something!)
[cpg cn=true]


I shake off my ruminations and single-mindedly pack a tissue. Pack it. Pack it. I'll pack it in.
[cpg]

[VOICE f="Sayo0668"]
[OnName num="sayo"]
''Hmmm...........................................................
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


In the meantime, it finally started...
[cpg]


[SE f="se032"]
;//【ＳＥ】『放尿』ちょろ…ちょろちょろ…


;**【ＣＧ】ev_08_d ***********************
[CG id=7 index=4 time=1000]
;***************************************
[OnName num="masato"]
''Ahhhhhh...''
[cpg cn=true]


Choro...choro...choro...choro...choro.
[cpg]

 The husband wasn't bedridden .... Instead, he began to be laid and laid down. 
[cpg]

The fact that he finally started to pee made me stop moving and watch him.
[cpg]


[SE f="se032"]
;//【ＳＥ】『放尿』じょろろろろろ〜〜っ


[OnName num="masato"]
''Oh, you're gaining momentum...!''
[cpg cn=true]


From the beginning of the urination, it turned into a serious urination..............................................................................
[cpg]


[SE f="se032"]
;//【ＳＥ】『放尿』ぢょぼぼぼぼぼぼぼぼ

;**【ＣＧ】ev_08_e ***********************
[CG id=7 index=5 time=1000]
;***************************************

[VOICE f="Sayo0669"]
[OnName num="sayo"]
''Ugh...Ugh...Ugh...Ugh...Ugh...Ugh...Ugh.
[cpg cn=true]


[OnName num="masato"]
Whoa, whoa! This isn't good!
[cpg cn=true]


I thought it was about time to finish, but the urine still didn't get any weaker...it just kept coming out.
[cpg]

Where in the world has this body been storing up so much urine?
[cpg]

A large number of tissues, most of which had been stuffed between his legs, were also yellowing from the moisture, and were fulfilling their mission.
[cpg]


[SE f="se032"]
;//【ＳＥ】『放尿』じょろろろろろ〜〜っ


[OnName num="masato"]
Oh, no! Oh, my God! What am I going to do!
[cpg cn=true]


The sound of urine echoing around me made me panic even more.
[cpg]

The tissues are on the verge of being wiped out... there's no way I'm taking Master to the bathroom now! And no urine bottles!
[cpg]

So, what do I do...what do I do...what do I do...what do I do...what do I do?
[cpg]

I didn't even have time to turn my normal thoughts around anymore.
[cpg]

So I just...
[cpg]

;**【ＣＧ】ev_08_f ***********************
[CG id=7 index=6 time=1000]
;***************************************

[OnName num="masato"]
''Master, I beg your pardon!
[cpg cn=true]


He had chosen to catch her urine.
[cpg]

[OnName num="masato"]
Hmmm.
[cpg cn=true]


[VOICE f="Sayo0670"]
[OnName num="sayo"]
Hmmm.
[cpg cn=true]


[OnName num="masato"]
"Ugh! 
[cpg cn=true]


Urine is released without stopping.
[cpg]

As soon as he touched his tongue, the smell spread into his nasal cavity.
[cpg]

I swallowed the urine of my master who couldn't keep it in his mouth while breathing desperately through his nose, and put it in his stomach.
[cpg]

The taste touches my tongue, the smell fills every time I breathe, and it's like I'm being violated to the brain.
[cpg]

[OnName num="masato"]
 "Foooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo ... 
[cpg cn=true]


You're right. Urine.
[cpg]

He's a great peeer.
[cpg]

No matter how bright, how beautiful, how pretty, or how many limbs you have to seduce a man...
[cpg]

But the pee stinks.
[cpg]

The smell. It stinks because it's pee.
[cpg]

The ammonia smell is stinky. What stinks is what stinks.
[cpg]

It's the stuff that comes out of the master's body and there's nothing dirty about it. You could say that, but the general sense is that stinky things stink.
[cpg]

The taste that spreads in your mouth is vomitous and sucks.
[cpg]

The other day, I tasted Master's urine for the first time... the same taste as that time. It's not good.
[cpg]

[OnName num="masato"]
''Whew, whew...gok, gok...gok, gok...oooh, goooh...''
[cpg cn=true]


I still drink up all the urine that is released into my mouth one after another like a wanko wanko wanko wanko wanko wanko wanko wanko wanko wanko wanko wanko wanko.
[cpg]

--I shed a few tears.
[cpg]

I'm sure his eyes are bleeding too. The snort must be ragged. I can even tell my body is rattling and twitching.
[cpg]

It makes my eyes tingle. It's like my brain is being violated by a foreign object and my mind is going blank.
[cpg]

Looking back later on, I would not be able to accurately describe the feelings I had at this time.
[cpg]

I couldn't do it the other day... I guess I was happy to drink Master's urine.
[cpg]

Or is it the frustration of having your hopes of "Lolita's golden water (holy water) being the most delicious drink in the world" dashed twice?
[cpg]

To be honest, I'm not sure either.
[cpg]


[SE f="se032"]
;//【ＳＥ】『放尿』じょろろろろろ〜〜っ


Jolo Jolo Jolo.
[cpg]

[OnName num="masato"]
 "Jump, jerky ... huhh, huhhh ..." 
[cpg cn=true]


But...the only thing that was unshakeable was the fact that he was drinking pee. Still, it's long, and it doesn't end at all. Long pee.
[cpg]

No, maybe 10 seconds, maybe 20...I think if you just put up with that much you'll actually be done.
[cpg]

It seems like an eternity for such a long time.
[cpg]

I'm not done yet.
[cpg]

Oh, I'm sure...maybe I shed tears at my own inadequacies.
[cpg]

[SCENE id=9]
[ENDPARTIAL]

[BG f="black.ui" time=1000]
;//ＢＫ


[STOPBGM]
[BG f="b_04_4.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（夜）******************************************************


[OnName num="masato"]
''Hah, hah...''
[cpg cn=true]


Finally, it's over...
[cpg]

It was a long pee, more than 30 seconds in an hour, but I managed to get through it.
[cpg]

My stomach is lumpy. When it shakes, you can feel the water rippling inside.
[cpg]

Right now, the only thing in my stomach is probably Master's pee.
[cpg]

[OnName num="masato"]
''Ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh.
[cpg cn=true]


I almost put it back in from the relief of knowing it was over. It would be a waste of time if I vomited here, so I held my mouth with my hand and struggled to endure.
[cpg]

Besides, if you throw up now, your master's body will be in a lot of trouble.
[cpg]

I'm tired...I feel like crap. However, it was done.
[cpg]

But that's no surprise either. Once the term droops naturally and my own lower body is in sight, I am convinced.
[cpg]

[OnName num="masato"]
(I'm a pervert after all.)
[cpg cn=true]


Drinking urine, that's what I did... my crotch is all swollen up.
[cpg]

[OnName num="masato"]
''(Well...if you don't go on like this, you'll catch a cold, so I'll wipe Master's body and put some clothes on...)''
[cpg cn=true]


[VOICE f="Sayo0671"]
[OnName num="sayo"]
Shoo...shoo...shoo...shoo
[cpg cn=true]


He looks happy in his sleep.
[cpg]

He is sleeping very calmly, perhaps because he felt refreshed after giving out something.
[cpg]

Somehow...just looking at this sleeping face already, I felt a sense of accomplishment and even satisfaction at what I had done.
[cpg]

[OnName num="masato"]
''I'll wipe my body. And I'll have a change of clothes for you soon.....
[cpg cn=true]


[BG f="black" time=1000]
[BGM f="h1"]
;//ＢＫ


;//CGを再び表示
;//☆ＣＧエロ（雅人＆小夜・泥酔してお漏らしをする小夜の便器になる：小夜の部屋）ev_08
;//おしっこを吸ったティッシュが大量に散乱している。小夜の下半身もべちょべちょ


;**【ＣＧ】ev_08_g ***********************
[CG id=7 index=7 time=1000]
;***************************************

If you look at her to wipe her body, you can see her exposed crotch.
[cpg]

Earlier, I didn't care because I was in a hurry, but now that I've calmed down...my eyes are glued to it.
[cpg]

Because it is an emergency, it is a secret part that is made to take off and is exposed.
[cpg]

Her defenseless vagina is stained with urine and my saliva.
[cpg]

Yes, this place needs to be cleaned up....
[cpg]

[OnName num="masato"]
Master...I'll clean up...right?
[cpg cn=true]


That's just an excuse.
[cpg]



;**【ＣＧ】ev_08_h ***********************
[CG id=7 index=8 time=1000]
;***************************************
[OnName num="masato"]
Prickle... prickle, prickle...
[cpg cn=true]


[VOICE f="Sayo0672"]
[OnName num="sayo"]
Hmmm.
[cpg cn=true]


Instead of wiping it off with a tissue, I put my mouth on it in a natural motion.
[cpg]

[OnName num="masato"]
"Jingle, jingle...
[cpg cn=true]


[VOICE f="Sayo0673"]
[OnName num="sayo"]
Hmmm...hmmm...hmmm...hmmm...
[cpg cn=true]


[OnName num="masato"]
''Hmmm, hmmm. Aww...jingle...jingle...jingle...jingle.
[cpg cn=true]


[OnName num="masato"]
''Squeak, squeak...squeak...squeak.''
[cpg cn=true]


;**【ＣＧ】ev_08_i ***********************
[CG id=7 index=9 time=1000]
;***************************************


While licking my master's private parts, I took out a tissue with a groping motion and put it on my own dick.
[cpg]

[OnName num="masato"]
Picha. Ch-chu, n-chu, chu-puh."
[cpg cn=true]


He licks it carefully from the outside to the center, taking too much time to be careful.
[cpg]

She squirts out the remaining urine with her mouth, sucking it in.
[cpg]

[OnName num="masato"]
「ぴちゃ。ちゅ、んちゅ、ちゅぷっ」
[cpg cn=true]


Master's private parts become clean enough by only licking them a few times.
[cpg]

The tongue does not stop.
[cpg]

More and more, I told myself, it's not going to get any prettier yet.
[cpg]

[OnName num="masato"]
 "Jup ... hmmm ... mmmm" 
[cpg cn=true]


[VOICE f="Sayo0674"]
[OnName num="sayo"]
Hmmm................................................................
[cpg cn=true]


The color in her sleep.
[cpg]

The movement of his tongue was unstoppable. It has become unstoppable.
[cpg]

[OnName num="masato"]
"Prickly, prickly, prickly... prickly, prickly... prickly, prickly...
[cpg cn=true]


[VOICE f="Sayo0675"]
[OnName num="sayo"]
''Phew, phew...phew, phew...''
[cpg cn=true]


[OnName num="masato"]
Hmmm, hmmm, hmmm...
[cpg cn=true]


The right hand, which moves with the tongue, also increases in speed. The difference is noticeable, even with the sound of scraping on the tissue.
[cpg]

[OnName num="masato"]
''Jingle, jingle...jingle, jingle, jingle...''
[cpg cn=true]


[OnName num="masato"]
"Chirp... chirp, chirp, chirp... chirp... chirp...
[cpg cn=true]


[OnName num="masato"]
"Lero, hmmm, hmmm... hmmm, hmmm, hmmm... hmmm, hmmm, hmmm...
[cpg cn=true]


;//フラッシュ


[SE f="se026"]
;//【ＳＥ】『射精音』


;**【ＣＧ】ev_08_i ***********************
[CG id=7 index=9 time=1000]
;***************************************
[OnName num="masato"]
!
[cpg cn=true]


Half an hour later. The white liquid was released in the tissue that was wrapped, and I finally released my mouth from the master's secret part.
[cpg]

[OnName num="masato"]
'Ha, ha...ha, ha...ha, ha...ha, ha...ha, ha...ha, ha.
[cpg cn=true]


The perfect cleaning that didn't leave even the slightest stain was finally over.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ


[STOPBGM]
[BG f="b_04_4.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（夜）******************************************************


[OnName num="masato"]
Yo...hmm. Phew, it's over.
[cpg cn=true]


After cleaning her body and changing into the pajamas Tanaka-san had brought her, Master was in bed, making a cute little sound of sleep.
[cpg]

A lot has happened, but that's it for now.
[cpg]

[OnName num="masato"]
...good night, master.
[cpg cn=true]


That was the last thing I said, and I turned off the light and left the room.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ


[BGM f="se"]
[BG f="b_01_4.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（夜）******************************************************


When I stepped out into the hallway, Tanaka-san, the other butlers, and the maids who had brought me pajamas and a change of underwear were waiting for me.
[cpg]

[OnName num="butler"]
Are you done?
[cpg cn=true]


[OnName num="masato"]
Yes."
[cpg cn=true]


When I say that, everyone looks relieved. Tonight was hard in so many ways.
[cpg]

[OnName num="butler"]
Thank you for all your hard work, Lord Masato.
[cpg cn=true]


[OnName num="masato"]
No...nothing. Thank you all for your hard work.
[cpg cn=true]


For a while, I wondered what was going to happen, but everyone seemed to be worried and stayed here all the time, so it was a good, good atmosphere.
[cpg]

[OnName num="masato"]
But I won't forget that you all ran away without me.
[cpg cn=true]


I'm not sure what to do about it.
[cpg]

I was even angry then, but I'm not angry anymore. But I won't forget it.
[cpg]

[OnName num="butler"]
Now, now, Mr. Masato... please don't say that.
[cpg cn=true]


While saying this, Tanaka-san suddenly approaches me and says in a small voice...in a slightly lower tone.
[cpg]

[OnName num="butler"]
"We, too, will keep what we saw tonight... to ourselves.
[cpg cn=true]


[BGM f="co"]
[OnName num="masato"]
!!!???
[cpg cn=true]


I knew immediately what the hell he was talking about, because I knew what he was talking about.
[cpg]


[OnName num="masato"]
''What, uh...what? What? No way...look....
[cpg cn=true]


[OnName num="butler"]
We're all very impressed with your dedication to your work, Mr. Masato.
[cpg cn=true]


[OnName num="masato"]
''Eh, eh, eh...''
[cpg cn=true]


[OnName num="butler_A"]
"I'd like to inform the young lady that it is our duty and honor as servants to support our master behind our backs. I would not do such a daring thing.
[cpg cn=true]


[OnName num="maid_B"]
'Yeah, yeah. Of course I won't.
[cpg cn=true]


[OnName num="masato"]
''Ahhhh...ahhh...ahhh...''
[cpg cn=true]


There is no doubt about it. It was all being watched. It's like, "I'm going to do this, I'm going to do that, I'm going to do that, I'm going to do that, I'm going to do that.
[cpg]

I'm about to get fire from my face, or from the pores of my entire body.
[cpg]

[OnName num="maid_A"]
He's been a wonderful servant. I would like to follow Masato's example.
[cpg cn=true]


She swims her gaze in bewilderment, and even the young maid whose eyes met hers smiles and says such things.
[cpg]

[OnName num="masato"]
Ugh...!"
[cpg cn=true]


[OnName num="maid_A"]
Can I bring you a change of Masato's underwear, too? And if you leave it like that, it might get dirty.
[cpg cn=true]


[OnName num="maid_B"]
''No, no, you need to clean up first, don't you? If it's okay with me, I'll clean you up like I did with your daughter!
[cpg cn=true]


[OnName num="maid_C"]
''It would be better to deodorize the butler's clothes as well. Let me take care of it.
[cpg cn=true]


[OnName num="masato"]
''Ah...uh...uh...uh...uh...uh...uh...uh...uh...uh.
[cpg cn=true]


Please give me a break from the feeling that you're slowly squeezing me with that cotton wool!
[cpg]

There was only one course of action I could take.
[cpg]

[OnName num="masato"]
''Ahahaha...ahahahahahahaha! Yes, that's right! Today, we saved the day with the help of everyone here! It's an emergency, so there's been a lot going on, but...
[cpg cn=true]


[OnName num="masato"]
You're a small vessel to be worrying about such things all the time! Yeah! That's right! Such a person isn't fit to serve the Master, after all!
[cpg cn=true]




[SE f="se055"]
;//【ＳＥ】『拍手』

[OnName num="all_members"]
''Whoa!''
[cpg cn=true]


Crackle. For some reason, there was a round of applause along with cheers. Was I making a speech, too?
[cpg]

[OnName num="masato"]
'............................................................................................................. Well, let's put today behind us and make a good memory of it. Yes, to urine only! Just kidding...
[cpg cn=true]


[STOPBGM]
[OnName num="butler"]
「……」
[cpg cn=true]


[OnName num="butler_A"]
「……」
[cpg cn=true]


[OnName num="maid_A"]
「……」
[cpg cn=true]


[OnName num="maid_B"]
"......"
[cpg cn=true]


[OnName num="maid_C"]
「……」
[cpg cn=true]


[OnName num="masato"]
'Oh, that?'
[cpg cn=true]




[SE f="se056"]
;//【ＳＥ】『手を叩く』パンパン

[OnName num="butler"]
''Well, let's take care of the rest of our business and get some rest, too.
[cpg cn=true]


[OnName num="maid_A"]
Yes, sir.
[cpg cn=true]


[OnName num="maid_B"]
I guess.
[cpg cn=true]




[SE f="se057"]
;//【ＳＥ】『皆で歩いていく』ゾロゾロ


[OnName num="masato"]
「……」
[cpg cn=true]


[OnName num="butler"]
"Masato-san, please take a rest today. I'll take care of the rest.
[cpg cn=true]


[OnName num="masato"]
''Ha, yes... thank you...''
[cpg cn=true]


[OnName num="butler"]
Well then, good night.
[cpg cn=true]


[OnName num="masato"]
"Have a good night...
[cpg cn=true]


[BG f="black.ui" time=1000]
;//ＢＫ


[SE f="se005"]
;//【ＳＥ】『歩く』コツコツ


I don't know what it is, but it's an inconsolable feeling.
[cpg]

I went back to my room and immediately wrapped myself in the covers and went to bed.
[cpg]

When I woke up in the morning, my pants were a little squishy.
[cpg]


[STOPBGM]
[BGM f="sl" time=1000]
[BG f="b_02_1.ui" time=1000]
;//【ＢＧ】『豪邸、ダイニング』（朝）******************************************************


[SE f="se037"]
;//【ＳＥ】『食器の音』カチャカチャ


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0676"]
[OnName num="sayo"]
“♪”
[cpg cn=true]


[OnName num="masato"]
''Master, you're in a... very good mood this morning.
[cpg cn=true]


[VOICE f="Sayo0677"]
[OnName num="sayo"]
Yeah. I had a good dream last night.
[cpg cn=true]


Giggle.
[cpg]

[OnName num="butler"]
It's a dream. What kind of dream is this?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0678"]
[OnName num="sayo"]
''Humph. It's a dream of playing with a cute cat. It was a lot of fun!
[cpg cn=true]


The master talks happily, but I'm not in the mood for it.
[cpg]

[OnName num="the_master"]
Sayo is still a kid when it comes to dreams of playing with cats.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0679"]
[OnName num="sayo"]
''Oh, you're being cruel, Father. You treat me like a child.
[cpg cn=true]


[OnName num="the_master"]
I'm sorry, I'm sorry.
[cpg cn=true]


[OnName num="butler"]
But, surprisingly, such dreams can turn out to be positive dreams.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0680"]
[OnName num="sayo"]
?
[cpg cn=true]


[OnName num="the_master"]
I'm not sure if they're around. Tanaka.
[cpg cn=true]


[OnName num="butler"]
Yes. Master.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0681"]
[OnName num="sayo"]
"Father, what are you talking about...
[cpg cn=true]




[SE f="se058"]
;//【ＳＥ】『鈴の音』チリン


Meow.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0682"]
[OnName num="sayo"]
Aaaaahhhh!
[cpg cn=true]


[OnName num="the_master"]
Come on, Sayo, it's not like we're eating.
[cpg cn=true]

[SE f="se059"]
;//【ＳＥ】『椅子から立ち上がる』ガタッ


[SE f="se042"]
;//【ＳＥ】『走る』タッタッタ




Master got up from his seat with vigor and ran towards the door.
[cpg]

The steward behind him took the chair that was about to fall to the ground in a clap and put it back together.
[cpg]

[VOICE f="Sayo0683"]
[OnName num="sayo"]
Father! Father! The cat! The cat! My kitty!
[cpg cn=true]


[OnName num="the_master"]
''Hahaha, I can see it even if I can't get that close. That's good, isn't it?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0684"]
[OnName num="sayo"]
"But I never thought it would be a dream.
[cpg cn=true]


[VOICE f="Sayo0685"]
[OnName num="sayo"]
It's so cute!
[cpg cn=true]


[OnName num="butler"]
Well, well, well, well, it's a lost cat, isn't it?
[cpg cn=true]


[OnName num="the_master"]
Tanaka, you'll have to keep the gates closed properly.
[cpg cn=true]


[OnName num="butler"]
I'm sorry, sir.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0686"]
[OnName num="sayo"]
"You're so white, Father. And Tanaka-san, too.
[cpg cn=true]


[OnName num="the_master"]
"What..."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0687"]
[OnName num="sayo"]
Shush. There are no houses around, and it's not unusual for a cat with a pedigree to wander into a place like this...
[cpg cn=true]


[OnName num="butler"]
Ha-ha-ha, you've been found out.
[cpg cn=true]


[OnName num="the_master"]
No, no, no, no, no, no.
[cpg cn=true]


[VOICE f="Sayo0688"]
[OnName num="sayo"]
Thank you, Father!
[cpg cn=true]


[OnName num="the_master"]
I'm glad Sayo is happy. Besides, it wasn't me who said it, but... all the servants.
[cpg cn=true]


[VOICE f="Sayo0689"]
[OnName num="sayo"]
I didn't realize that. Thank you all, too.
[cpg cn=true]


[OnName num="butler_A"]
No, no, no, we haven't done anything about it.
[cpg cn=true]


[OnName num="maid_A"]
I'm glad you're pleased with your daughter.
[cpg cn=true]



[OnName num="all_members"]
"""Ahahahahahahahahahahahahahahahahahahahahaha.""
[cpg cn=true]




The morning mealtime was a very peaceful atmosphere.
[cpg]

In this way, a new family was added to the family by the sophisticated arrangement of the master and Mr. Tanaka...
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0690"]
[OnName num="sayo"]
Oh, it's a female.
[cpg cn=true]


[VOICE f="Sayo0691"]
[OnName num="sayo"]
I thought I was a male in my dream, so I thought...
[cpg cn=true]


[OnName num="masato"]
Giggles.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0692"]
[OnName num="sayo"]
''Humph, but it's cute.
[cpg cn=true]


Well, they managed to get it all under control.
[cpg]


[window target=false]

[STOPBGM]

[BG f="black.ui" time=1000]
[WAIT time=1500]

[window target=true]

[jump storage="ep010.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////
