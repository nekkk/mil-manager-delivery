*start

;//ここでルート分岐します。【奉公ルート】【比翼連理ルート】は下記のシナリオに進んで途中で分岐。

;//【遠き存在ルート】の場合は【合流B】へ

;#################################################
*Ep015|Me
;#################################################

[SCENE id=15]


[window target=false]


[stflag jump_scene=0]
;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]


[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep002で発生	ジャンプしてきた場合奉仕ルートで固定
[stflag gohome_flag=1]
[stflag pets_flag=0]
;//ep014で発生	ジャンプしてきた場合【遠き存在END】へのフラグで固定
[stflag service_flag=1]
[stflag hiyokurenri_flag=0]
[stflag existence_flag=0]
[endif]


;//【遠き存在ルート】の場合は【合流B】へ
[if exp={getFlagValue("existence_flag") == 1 }]
[jump target="*root_existence"]
[endif]


[STOPBGM]

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BGM f="se"]
;//【ＢＧ】『豪邸、ダイニング』（昼）******************************************************

[window target=true]


It was about a week before we got married.
[cpg]

In the dining room at lunchtime, there was a single father concerned about his daughter.
[cpg]


[SE f="se037"]
;//【ＳＥ】『食事音』カチャカチャ


[OnName num="the_master"]
How's your daughter doing lately?
[cpg cn=true]


[OnName num="butler"]
''Yes, you are very calm, thanks to Lord Masato.
[cpg cn=true]


[OnName num="the_master"]
".......................................... To be honest, even the gossip I hear from the servants... I don't have a very good impression of them...?
[cpg cn=true]


[OnName num="butler"]
''Indeed, generally speaking...yes, that's true. However, Master...you promised to let the young lady do as she pleases...
[cpg cn=true]


[OnName num="the_master"]
''Yeah, I know, I know. I'm not trying to do anything about it.
[cpg cn=true]


[OnName num="the_master"]
Besides, it's my fault. He has no right to thank me, but I have no right to be angry with him...
[cpg cn=true]


[OnName num="the_master"]
I created this situation, I'm... it's all my fault.
[cpg cn=true]


[OnName num="butler"]
''Master...''
[cpg cn=true]


[OnName num="the_master"]
 I let my unmarried daughter perform perversions on me... I would have tied up the bridal car and dragged it around like a bridal car!!!!!!
[cpg cn=true]


[OnName num="butler"]
''Master, you're leaking, sir. Dada leak.
[cpg cn=true]


[OnName num="the_master"]
''Huh, huh... no, I'm sorry. I'm a little distraught.
[cpg cn=true]


[OnName num="the_master"]
Huh..............
[cpg cn=true]


[OnName num="the_master"]
Tanaka.
[cpg cn=true]


[OnName num="butler"]
Yes.
[cpg cn=true]


[OnName num="the_master"]
I don't know what to do.
[cpg cn=true]


[OnName num="butler"]
This is your first time. It's a question like that for the Master to be asked.
[cpg cn=true]


[OnName num="the_master"]
'Oh...I don't know what to do anymore.
[cpg cn=true]




[STOPBGM]
[BGM f="d1" time=1000]
[BG f="b_00_2.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************


[OnName num="masato"]
「………」
[cpg cn=true]


Wow, that's a very difficult atmosphere to get out of.
In fact, sir, didn't you say you were going to drag me around?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo1080"]
[OnName num="sayo"]
Come on. Get a grip on your stomach.
[cpg cn=true]


[OnName num="masato"]
'Oh, yes! I'm fine!
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1081"]
[OnName num="sayo"]
It's good.
[cpg cn=true]


[OnName num="masato"]
'...Yes, of course.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1082"]
[OnName num="sayo"]
 I won't say anything more.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1083"]
[OnName num="sayo"]
"Let's just pray that we succeed.
[cpg cn=true]


[OnName num="masato"]
Yes, sir.
[cpg cn=true]




[SE f="se016"]
;//【ＳＥ】『ドアを開ける』ガチャ


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo1084"]
[OnName num="sayo"]
Father! I need to talk to you!
[cpg cn=true]




[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ





--The fateful day came soon enough.
[cpg]


[STOPBGM]
[BGM f="d1" time=1000]
[BG f="b_03_2.ui" time=1000]
;//【ＢＧ】『分岐路のある道』（昼）******************************************************


[SE f="se004"]
;//【ＳＥ】『喧騒』ガヤガヤ


[OnName num="fatty_man"]
I'm not sure what to say. It was adorable when I was a kid though. How long has it been since we've seen each other?
[cpg cn=true]


[OnName num="the_master"]
''It's been quite a while, I believe...''
[cpg cn=true]


[OnName num="fatty_man"]
That's right. It's been about ten years, I think! No, I'm getting older too, Sayo-chan, do you remember your uncle?
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo1085"]
[OnName num="sayo"]
'Yes, of course. Mr. Takayama is my benefactor, so I've never forgotten him for a moment.
[cpg cn=true]


[OnName num="fatty_man"]
Haha, that's a nice thing to say.
[cpg cn=true]


Face to face before marriage.
[cpg]

Sayo's father and Sayo, who is also her daughter-in-law, have come to work for the president of a large company, who is indebted to Sayo for his help when the company was in distress.
[cpg]

[OnName num="fatty_man"]
''You're a terrible person too, you won't let me see Sayo at all. From what I've heard, he was overprotective enough to keep them in the house.
[cpg cn=true]


[OnName num="the_master"]
''Hahaha...well, that's right. I'm embarrassed to say so.
[cpg cn=true]


[OnName num="fatty_man"]
You can't do that. No matter how important your daughter is, how can you be so pitiful?
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1086"]
[OnName num="sayo"]
''Mr. Takayama, that's not true. My father has been thinking of me for so long.
[cpg cn=true]


[OnName num="fatty_man"]
''Hah~, you're a really well-made young lady. No, no, I'm not accusing you of anything else. Well, thanks to this, I'm able to marry Sayo with a clean body. Ha-ha-ha-ha.
[cpg cn=true]


The other guy was in a good mood without knowing anything. It's true that I've put up with some of the things I've put up with in my life for this guy. Cramped life...that's over now.
[cpg]

Cramped life...it's over now.
[cpg]

[OnName num="the_master"]
Mr. Takayama, I'd like to talk to you about... a few things.
[cpg cn=true]


[OnName num="fatty_man"]
「？」
[cpg cn=true]


[OnName num="the_master"]
Will you reconsider marrying my daughter, please?
[cpg cn=true]

That being said, the man was enraged. It's shameless how much I owe them, and they hurl abuse at me for promising to do so.
[cpg]


[OnName num="the_master"]
There's a reason for that.
[cpg cn=true]


[OnName num="fatty_man"]
"Why? Ha, then say it. I won't let you get away with it if it's for a lousy reason.
[cpg cn=true]


[OnName num="the_master"]
Sayo...
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo1087"]
[OnName num="sayo"]
Yes, Father.
[cpg cn=true]

Sayo stood up and gingerly pulled up her skirt.
[cpg]


[OnName num="fatty_man"]
"What?
[cpg cn=true]

The man's eyes opened like plates and his mouth puckered like a goldfish.
[cpg]

To the man looking at Sayo's face as if asking for an explanation...Sayo smiled back.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BGM f="d1" time=1000]
[BG f="b_00_2.ui" time=1000]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************


[SE f="se016"]
;//【ＳＥ】『扉を開ける』ガチャ


[OnName num="butler_B"]
Welcome back, sir.
[cpg cn=true]


[OnName num="maid_B"]
「お帰りなさいませ」
[cpg cn=true]

When they return to the mansion, their servants greet them.
However, there was a remarkable person there.
[cpg]


[SE f="se072"]
;//【ＳＥ】『階段を駆け下りる』タッタッタ


[FG f="CHA01_p1_02_a.ui" method="change_5"  pos="4/4" time=800]
[VOICE f="Sayo1088"]
[OnName num="sayo"]
Father!
[cpg cn=true]


[OnName num="the_master"]
''Sayo, why are you here! I told you to get out of sight immediately.
[cpg cn=true]


[FO pos="4/4"]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Sayo1089"]
[OnName num="sayo"]
I'm sorry, but...
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Sayo1090"]
[OnName num="sayo"]
「………」
[cpg cn=true]

Another person, Sayo, appeared. She then turned her worried eyes to Sayo, who was next to her father.
[cpg]

Next to her father, Sayo turned her anxious eyes to the two of them.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Sayo1091"]
[OnName num="sayo"]
So, how... did it go?
[cpg cn=true]

The question was not answered by his father. Instead, the other Sayo answered.
[cpg]


[FG f="CHA01_p2_02_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Sayo1092"]
[OnName num="sayo"]
I'm...
[cpg cn=true]


[FO pos="2/2"]
[FO pos="1/2"]

[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BGM f="se" time=1000]
[BG f="b_02_2.ui" time=1000]
;//【ＢＧ】『豪邸、ダイニング』（昼）******************************************************


[SE f="se038"]
;//【ＳＥ】『テーブルを叩く』ガチャン


[OnName num="the_master"]
Nonsense! That's a no-brainer!
[cpg cn=true]


[OnName num="masato"]
'No, it's possible. Of course, it's also difficult and usually impossible...but with the master's help, we can do it.
[cpg cn=true]


[OnName num="butler"]
Masato-dono...
[cpg cn=true]


[OnName num="the_master"]
"But what about you? Even if the story we're talking about now could come true, it would be at your expense.
[cpg cn=true]


[OnName num="the_master"]
'Certainly my daughter is important. But I can't do that at the expense of others either.
[cpg cn=true]


[OnName num="masato"]
Sacrifice? No, sir. Even the master, who has many servants, does not understand, does he?
[cpg cn=true]


[OnName num="the_master"]
「？」
[cpg cn=true]


[OnName num="masato"]
"Every drop of blood, every piece of flesh...I'll give it all. It always scorches my heart to the point where I want it all to melt away."
[cpg]

"I want to show my service and loyalty to those I care about... to those I care about... to the best of my ability... to the greatest of self-satisfaction."
[cpg cn=true]


[OnName num="the_master"]
"......"
[cpg cn=true]


[OnName num="masato"]
It's not a sacrifice. This is something I'm selfishly hoping to do. At the same time, it's not a bad story for the masters... so I want you to get on board.
[cpg cn=true]


[OnName num="the_master"]
"...are you sure you want to do this?"
[cpg cn=true]


[OnName num="masato"]
Yeah. I'm a true dirtbag, and I'm just being complacent.
[cpg cn=true]




[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BGM f="se" time=1000]
[BG f="b_03_2.ui" time=1000]
;//【ＢＧ】『分岐路のある道』（昼）******************************************************


[SE f="se048"]
;//【ＳＥ】『椅子から転げる』ガタンッ


[OnName num="fatty_man"]
Wha...Wha...Wha...Wha...Wha...Wha...Wha.
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo1093"]
[OnName num="sayo"]
"Shush. There's no need to be so surprised by anything."
[cpg cn=true]

The secret part that was hidden by the skirt.
There was something there that wasn't supposed to be about the woman. The other person who saw it was also astonished and couldn't keep his mouth shut.
[cpg]


[OnName num="the_master"]
"It's no wonder you're surprised. My daughter...she was, in fact, a man."
[cpg cn=true]


[OnName num="fatty_man"]
"What the fuck?!"
[cpg cn=true]

So far, from here on out... everything will go as planned.
[cpg]

It's a fabricated lie, but you have to explain it in such a way that the other person will believe it... you have to make the lie real.
[cpg]


[OnName num="the_master"]
I was definitely raised as a woman in terms of looks, character and behavior, but...
[cpg cn=true]

The doctor had also told her that she was a woman, and she was aware of it. However, it later turned out to be a man...and
[cpg]

It's an unbelievable setup, but we're going to have to... push through it.
[cpg]


[OnName num="fatty_man"]
"Well, that's ridiculous! I've seen it all when I was little! Naked! Two, you weren't supposed to be lucky!"
[cpg cn=true]


[OnName num="the_master"]
(This fucking fatty...did you take secret shots of me? Ahhhh!)
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo1094"]
[OnName num="sayo"]
"Master, please calm down! (I'll ask Tanaka-san to look into it later, and depending on the results, we'll make a move)"
[cpg cn=true]


[OnName num="the_master"]
That's because they were small, yes.
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1095"]
[OnName num="sayo"]
"That's right. When I was a kid, I didn't even notice that they were this...not even the size of my pinky finger..."
[cpg cn=true]

It's normal to not believe such things when they are said out of the blue. But it's right in front of you.
[cpg]

Masato is there as Sayo, but there is no way he could have known that.
[cpg]

For the sake of his master and for himself... Masato volunteered to be a double, and with Misanagi's help, he underwent a surgery to become an exact duplicate of Sayo.
[cpg]

There were differences in height and bone structure, but Masato was also neutral to begin with, and the other guy hadn't seen Sayo in years, so he could be fooled...that's what he came to.
[cpg]

The woman she was supposed to marry was a man. Of course, the other party will be angry, and if the engagement is broken, they may make a lot of demands in return.
[cpg]

Even so, the master's true intention was to prevent her from marrying off to this man.
[cpg]

The husband was also troubled by the survival of the company and the employees all the time, but it was decided as a father who thinks about his daughter.
[cpg]


[OnName num="the_master"]
"Mr. Takayama, would you please reconsider this marriage thing...?"
[cpg cn=true]


[OnName num="fatty_man"]
Well, that's..."
[cpg cn=true]

The other man was sweating like a waterfall. And.........
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ



;//ここで展開が変化



;//【奉公END】フラグを得ている場合は下記の流れ、【比翼連理END】フラグを得ている場合は【合流C】へ
[if exp={getFlagValue("service_flg") == 1 }]
[jump target="*root_service"]
[endif]

[if exp={getFlagValue("hiyokurenri_flag") == 1 }]
[jump target="*root_hiyokurenri"]
[endif]


*root_service|apprenticeship



[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="se"]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[OnName num="masato"]
"...I'm going to be married to Master Takayama."
[cpg cn=true]

I spoke to him as softly as I could.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1096"]
[OnName num="sayo"]
"………so" 
[cpg cn=true]


[OnName num="masato"]
"I'm sorry. I thought I got to a good point, but...ah-ha-ha."
[cpg cn=true]

In the end, the answer didn't change when I confronted him about the fact that Sayo is a man who is the only one with an amorous marriage partner...
[cpg]

In response to Masato's words, Sayo looked down. I don't know what kind of expression he has on his face.
[cpg]


[OnName num="the_master"]
"Come on, Sayo, let's get ready and get out of here quickly. Tanaka, you're up!"
[cpg cn=true]


[OnName num="butler"]
Yes, sir.
[cpg cn=true]

There should never be two people who are the same. If they find out about this, the operation is a dead end.
[cpg]

So she too has to hide and live in seclusion.
[cpg]

[FG f="CHA01_p2_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1097"]
[OnName num="sayo"]
"........."
[cpg cn=true]

Prompted by Master and Mr. Tanaka, the will-less doll is made to move...with the butler, Master heads upstairs.
[cpg]


[OnName num="masato"]
"Master."
[cpg cn=true]


[VOICE f="Sayo1098"]
[OnName num="sayo"]
「……」
[cpg cn=true]


[OnName num="masato"]
"Please, take care of yourself."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1099"]
[OnName num="sayo"]
"...you too..."
[cpg cn=true]

We said our goodbyes.
[cpg]


[OnName num="the_master"]
"I'm really, really sorry..."
[cpg cn=true]


[OnName num="masato"]
"Master. Don't mind me... it's my own doing."
[cpg cn=true]

In the end, Sayo (Masato) ended up getting married to her partner as planned.
Takayama, who was an amorous man, did not break off the engagement even when he found out the gender of his partner was a man.
[cpg]


[OnName num="fatty_man"]
"A man but a woman... this mystical charm is unbearable."
[cpg cn=true]

He said something like that.
[cpg]

Since she is a man, it won't be a marriage, but she may eventually be forced to change her gender and enter the registry.
[cpg]

In terms of the objectives of the operation, it was a success. Originally, this strategy would not have failed if it hadn't been discovered at the time of the double.
[cpg]

The real Sayo is safe when it comes to getting married, and she's in the best shape when it comes to her company.
[cpg]

If the other guy would just give up, he might make a lot of demands in exchange for breaking off the engagement, but Masato can come back too.
[cpg]

It was a story of either of those things.
[cpg]

Whichever way it turns out, it will be better for the master than marrying it off as it is, so the master also went along with this proposal.
[cpg]

For Masato, it was all about risk, but it didn't matter.
[cpg]

It's all for the master...
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BGM f="d1" time=1000]
[BG f="b_00_2.ui" time=1000]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************


Time passes, and the day Sayo (Masato) leaves the house.
[cpg]


[OnName num="butler"]
I'll send it to you.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1100"]
[OnName num="sayo"]
"Tanaka-san. Thank you....."
[cpg cn=true]

You're going to live with him today.
[cpg]


[STOPBGM]
[BGM f="d1" time=1000]
[FO pos="2/3" time=1000]
[BG f="b_07_2.ui" time=1000]
;//【ＢＧ】『空』（昼）******************************************************


I put on my gleaming clothes and get into the car prepared for me. Suddenly, I looked up at the mansion with regret and glanced around.
[cpg]

Spontaneously, I searched for the master's figure. It's not like that. It's not supposed to be.
[cpg]

She's never going to be here. I've already said goodbye. All that's left to do is serve the master as best I can.
[cpg]

The car with me in it quietly departed...
[cpg]


[SE f="se073"]
;//【ＳＥ】『車が走る』ブルルルルンッ


[BG f="black.ui" time=1000]
;//ＢＫ


[STOPBGM]
[BGM f="h1" time=1000]


[OnName num="fatty_man"]
"Hah, hah, hah..."
[cpg cn=true]


[FG f="CHA01_p3_00_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo1101"]
[OnName num="sayo"]
"Hmmm...uhhhhhh...ugh...ugh!"
[cpg cn=true]


[OnName num="fatty_man"]
"Ahh~ that's okay, Sayo-chan. It's so good, I don't think it's a boy."
[cpg cn=true]


[FG f="CHA01_p4_00_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1102"]
[OnName num="sayo"]
"Hmm, thank you...thank you. Ahhhhhh!"
[cpg cn=true]

Having your ass dug night after night, night after night, and crying out. That's the responsibility of being married to this man.
[cpg]

But to me, she's the only master... only Sayo-sama. This is a service for her.
[cpg]

It is not overturned. It shouldn't be overturned.
[cpg]


[OnName num="fatty_man"]
"Humph, Sayo-chan looks great too."
[cpg cn=true]


[FG f="CHA01_p3_00_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1103"]
[OnName num="sayo"]
"Huh...uh...eh...?"
[cpg cn=true]


[OnName num="fatty_man"]
Here, take a look in the mirror.
[cpg cn=true]

[FO pos="2/3" time=1000]

;**【ＣＧ】ev_13_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************

;//●ＣＧエンディング（雅人＆キモデブおやじ・小夜そっくりの姿になった雅人。恋人繋ぎで犯される：豪華な寝室）ev_13


[VOICE f="Sayo1104"]
[OnName num="sayo"]
"........."
[cpg cn=true]


[OnName num="fatty_man"]
I'm sure she'll make a very horny face when her cock is in it. He's got a full meth face now.
[cpg cn=true]

It's not like that.
That can't be true.
[cpg]

But from the look on her face...it looked as if she was simply feeling the joy of being a female.
[cpg]


[OnName num="fatty_man"]
Here, how are you doing? Does your dick feel good?
[cpg cn=true]


[VOICE f="Sayo1105"]
[OnName num="sayo"]
"Hmm, ohhhh..., my husband's dick, it feels good! ♪" 
[cpg cn=true]

I'm sure only he can figure out the truth...
[cpg]


;//【奉仕ルート】END


;//レターボックスout
[FACE method="feadout" pos="4/7"]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="epend.ks" target="*start"]

;//【奉仕ルート】END



;/////////////////////////////////////////////////////////////////////////////////
;//奉仕ルートが終わりスタッフロールが流れた後、条件達成時に追加のエンディング
;//２箇所ある【ただいまEND】へのフラグを得ている場合ストーリーが進行します

*go_home|...I'm home.


;//【…ただいま。ルート】

[STOPBGM]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]

[window target=false]

;//【…ただいま。ルート】

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ



[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="se"]

;//【ＢＧ】『空』（昼）******************************************************
;//※ここ小夜家の豪邸玄関を改造してなんとかならないかな？

;//レターボックスin
[FACE method="feadin_up" pos="4/7"]
[wait time=2000]


[window target=true]

This is the luxurious house of the Takayama family where Masato got married.
[cpg]

In the long hallway leading from the doorway, Masato put three fingers on the floor and bowed his head deeply.
[cpg]


[VOICE f="Sayo1106"]
[OnName num="sayo"]
Thank you very much for the six years you've been with us.
[cpg cn=true]

[BGM f="se" time=1000]

In response, the man gives me a blank glance and climbs the stairs. The man is the one whom Masato has been serving for the last six years.
[cpg]

Even though it was half compulsory, and even though the purpose was for personal gain, they had been together for six years.
[cpg]

There should be a word. But the man didn't say anything and looked down on Masato as if he was looking at something nasty. Masato has no value to him any more.
[cpg]

Maybe it's better to just come and see him off, after all.
[cpg]

It was only the other day that the man started saying he was going to break off the engagement. He didn't give a clear reason, but surely he was simply bored with it.
[cpg]

There was no reason for him to refuse the decision, but things went smoothly and he was kicked out of his house in no time.
[cpg]

The man is apparently remarrying some (real) daughter. The girl would be the next to be sacrificed...my heart ached to think about it.
[cpg]


[VOICE f="Sayo1107"]
[OnName num="sayo"]
"....then I'll leave you alone."
[cpg cn=true]

When the greeting was over, Masato picked up the wand he had placed on the floor and stood up. Then, with unsteady steps, he heads for the exit.
[cpg]

Attendants stood at either end of the long corridor as if decorating it, staring at the figure of the one who had been their wife.
[cpg]

Some have spent many years together, while others are still in their infancy. But they all have a tense expression on their faces.
[cpg]

The girls have never heard the details of why Masato came to marry her, nor have they ever heard the details. However, after six years together, I knew the general picture.
[cpg]

The fact that Masato was a man, and why he came here...
[cpg]

That's why they all have such an expression on their faces. Thanks for the work... that's what it sounds like.
[cpg]


[OnName num="メイド"]
Hey, Sayo-sama! I'll take your luggage, sir!
[cpg cn=true]

As the master's figure disappeared into the depths of the second floor, a young attendant jumped out of the line.
[cpg]


[VOICE f="Sayo1108"]
[OnName num="sayo"]
Thank you. But I don't have to worry about it. I'll be fine.
[cpg cn=true]


[OnName num="メイド"]
No, no! Let me help you with that! Let me do it!
[cpg cn=true]

Desperately appealing with a tearful expression on her face, she came here to serve about three years ago. I'm sure she had her reasons, too.
[cpg]

Masato was kind to her as she felt uneasy in her new life.
[cpg]

Masato was kind to her. She is not the only one.
[cpg]

The people who were indebted to him, the people who were close to him... they all looked up to him as a good wife.
[cpg]


[VOICE f="Sayo1109"]
[OnName num="sayo"]
"...Thank you. Now, please make your way to the gate."
[cpg cn=true]


[OnName num="メイド"]
Yes!
[cpg cn=true]


[OnName num="maid_head"]
"Mistress. I've made arrangements for a taxi. Why don't you stay away and have some tea until we get there?"
[cpg cn=true]


[VOICE f="Sayo1110"]
[OnName num="sayo"]
"Kirie-san...I'm sorry, I'm glad, but...I'm going to wait at the gate.
[cpg cn=true]


[OnName num="maid_head"]
I see. Then, ma'am, I'll join you.
[cpg cn=true]


[VOICE f="Sayo1111"]
[OnName num="sayo"]
"I'm sorry to let you, Chief Maid, do such a thing. Besides, I don't belong to this family anymore..."
[cpg cn=true]


[OnName num="maid_head"]
"Until we leave this house, you will be our wife."
[cpg cn=true]


[VOICE f="Sayo1112"]
[OnName num="sayo"]
'........thank you.
[cpg cn=true]



[BG f="b_03_2.ui" time=1000]
;//【ＢＧ】『空』（昼）******************************************************


Masato, supported by the two, goes out of the entrance and goes to the gate. It has been six years since I came here through this big gate. I feel nostalgic when I think of the past.
[cpg]

When I looked back, I saw that all the attendants had seen me off. Masato bowed his head in a deep, deep way and thanked him as well.
[cpg]

A few moments while waiting for a taxi. It wasn't a conversation, and everyone didn't speak much.
[cpg]


[SE f="se074"]
;//【ＳＥ】『クラクション』パッパー


[OnName num="メイド"]
Oh, it looks like he's here!
[cpg cn=true]

A car is coming towards us, honking its horn. Seeing this, the young attendant thought that a taxi had arrived.
[cpg]

But the car wasn't a taxi, even from the exterior.
[cpg]

[OnName num="メイド"]
"Oh, that...?"
[cpg cn=true]

Next to the bewildered young chambermaid...a smile appears on Masato's lips.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1113"]
[OnName num="sayo"]
"...Kirie-san."
[cpg cn=true]


[OnName num="maid_head"]
"Yes, what is it, ma'am?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo1114"]
[OnName num="sayo"]
Is it possible to cancel the taxi you arranged for us?
[cpg cn=true]


[OnName num="maid_head"]
"Well, let's see...they're already here... Don't you feel sorry for the driver if he's told to come all the way here and leave?"
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo1115"]
[OnName num="sayo"]
Shush. Hmph...yes, that's true.
[cpg cn=true]



[SE f="se075"]
;//【ＳＥ】『ブレーキ』キキッ


Masato turned to face Kirie and the young handmaiden and thanked them again as the brakes sounded and the car came to a stop.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo1116"]
[OnName num="sayo"]
Thank you so much for everything.
[cpg cn=true]


[OnName num="maid_head"]
"It's an honor to serve you, Mistress."
[cpg cn=true]


[OnName num="メイド"]
"Sayo-sama...please, please take care of yourself...!"
[cpg cn=true]

Reluctant to say goodbye, Masato got into the car at the urging of the driver. The accelerator was depressed, the tires spun...and the car started running toward its destination.
[cpg]



[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ

;//【ＢＧ】『空』（昼）******************************************************
;//※カットインでも良いので車内の風景が欲しいかも



The car was running at a reasonable speed, but perhaps because it was a luxury car, the interior of the car was calm and quiet enough to talk.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo1117"]
[OnName num="sayo"]
"...Tanaka-san. Where are you going?"
[cpg cn=true]


[OnName num="butler"]
"What do you mean, Where?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1118"]
[OnName num="sayo"]
It's about the destination.
[cpg cn=true]


[OnName num="butler"]
"Oh, I'm sorry about this. Wherever you say it is, there's only one place for you to go."
[cpg cn=true]

[FO pos="2/3" time=1000]
[BG f="b_07_2.ui" time=1000]


With that being said, Masato laughed again.
[cpg]

The car slowed down and came to a halt. Masato gets out of the car with the help of Tanaka, the butler, and is standing in a familiar place.
[cpg]

The first time I walked through this gate more than six years ago... it's a place that is so important to me that I can easily remember it.
[cpg]

The mansion is still the same as it was at that time, and Masato almost burst into tears.
[cpg]

[OnName num="butler"]
"Go ahead."
[cpg cn=true]


[VOICE f="Sayo1119"]
[OnName num="sayo"]
"Thank you"
[cpg cn=true]



[SE f="se012"]
;//【ＳＥ】『扉を開ける』ギギギ



[free time=1000]
[BG f="b_00_2.ui" time=1000]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************


Tanaka lends a hand to open the door, which has become difficult to open by himself.
[cpg]

It doesn't feel more lived-in than it did back then, and it doesn't smell like a person. However, the smell was so nostalgic that it tickled my tear glands.
[cpg]


;//下記のセリフは？？？でお願いします
;//ここから雅人も名前が小夜から元に戻ります。設定として屋敷にいる時や戻ってきた時、自分になる…みたいな感じです



[VOICE f="Sayo1120"]
[OnName num="unknown"]
"This place will not change. It's almost exactly the way it was."
[cpg cn=true]

A voice sounded like it was pouring down from upstairs. It was an appearance that was terribly nostalgic and reminiscent of our first meeting.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
His... her... master.
She was also just as good as she was back then.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1121"]
[OnName num="sayo"]
"Every nook and cranny is well-cleaned... not that there are any. It can't be helped, I've been out of here since then too..."
[cpg cn=true]

Six years ago, when Masato himself became the master's double and got married to him. She couldn't live as she had before, and had moved to a deserted place.
[cpg]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1122"]
[OnName num="sayo"]
"It's been a long time... six years... a long time?"
[cpg cn=true]


[OnName num="masato"]
No. After all, it seems to have happened so fast.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1123"]
[OnName num="sayo"]
"Well... you've grown a little taller, haven't you?"
[cpg cn=true]


[OnName num="masato"]
"I don't know"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1124"]
[OnName num="sayo"]
"What about me?"
[cpg cn=true]


[OnName num="masato"]
"...hasn't changed much" 
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo1125"]
[OnName num="sayo"]
"Rude, I'm still five millimeters taller than I was."
[cpg cn=true]


[OnName num="masato"]
"I'm sorry, but if it's 5 millimeters, I'd be able to tell with a microscope, but unfortunately we can't."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1126"]
[OnName num="sayo"]
"Then I guess you should keep it on hand from now on."
[cpg cn=true]


[OnName num="masato"]
"Understood"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo1127"]
[OnName num="sayo"]
"...I can't see any better from this position either."
[cpg cn=true]


[OnName num="masato"]
?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1128"]
[OnName num="sayo"]
"Hey. Make a better face."
[cpg cn=true]


[OnName num="masato"]
"Yes"
[cpg cn=true]

[FO pos="2/3" time=1000]

;**【ＣＧ】ev_14_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************

;//●ＣＧエンディング（雅人＆小夜・額をコツンと当てる感じで顔を近づける二人：背景はイメージ的なやつ）ev_14
;//小夜は片手→両手で雅人の頬に優しく触れている。後に少しポーズが変わってもっと寄り添う感じに



Masato bends down slightly and brings his face closer to Master's. She touched Masato's face with both hands.
[cpg]

It was as if he was confirming that it was not a ghost, as if he was confirming its shape.
[cpg]

She stroked her ears and cheeks lovingly, touched her lips, her hair, and gazed into her eyes.
[cpg]

Touching him, looking at his wanded feet and the lightless left eye hidden by his bangs, she brought her cheek up to hug Masato.
[cpg]


[VOICE f="Sayo1129"]
[OnName num="sayo"]
"I'm sorry...I'm sorry...I'm sorry...I'm sorry...!"
[cpg cn=true]

Master shed large tears as he repeated the words filled with apologies and penance.
[cpg]


[OnName num="masato"]
"Why are you apologizing?"
[cpg cn=true]


[VOICE f="Sayo1130"]
[OnName num="sayo"]
"I know it must have been hard, it must have been painful... I'm sorry, I'm sorry it was my fault... I'm so sorry!"
[cpg cn=true]


[OnName num="masato"]
"That's not true. I did what I wanted to do... not because of the master, as I told you six years ago."
[cpg cn=true]


[VOICE f="Sayo1131"]
[OnName num="sayo"]
"Yeah, yeah, I know. I know, but..."
[cpg cn=true]

Although I understand Masato's way of thinking, I am still the one who caused this situation. Master was so heartbroken.
[cpg]


[OnName num="masato"]
"You really don't have to worry about it. If the master is worried about me, I will think that what I did was a mistake."
[cpg cn=true]

She knows this firmly too. But it's not the same as being convinced because you understand it.
[cpg]


[VOICE f="Sayo1132"]
[OnName num="sayo"]
"But then..."
[cpg cn=true]

[BG f="black.ui" time=1000]
;//ＢＫ

[OnName num="butler"]
"My lady"
[cpg cn=true]



[BG f="b_00_2.ui" time=1000]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]


Tanaka, the butler who was standing by the door watching over the two of them, made a suggestion.
[cpg]

[OnName num="butler"]
"I thought it was normal for labor to be given just compensation."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Sayo1133"]
[OnName num="sayo"]
"You're right..."
[cpg cn=true]

Sayo looked as if she had something on her mind.
[cpg]


[OnName num="masato"]
"Master. I didn't mean to do that..."
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="1/2" time=800]

[VOICE f="Sayo1134"]
[OnName num="sayo"]
"I know, I know, I know. So it's a reward, a reward for the seven years you've served me."
[cpg cn=true]

It was that man who had practically served for six years. But it was out of service to her that it happened.
Masato felt that his actions had finally been rewarded.
[cpg]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Sayo1135"]
[OnName num="sayo"]
"Well, normally I'd give you what you want, but..."
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/2" time=800]

[OnName num="masato"]
"If I can serve my master, there is no greater reward than that."
[cpg cn=true]


[FO pos="2/2"]
[FO pos="1/2"]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo1136"]
[OnName num="sayo"]
"Shush. I thought you'd say that. But I dismiss that."
[cpg cn=true]


[OnName num="masato"]
？
[cpg cn=true]


[FG f="CHA01_p4_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1137"]
[OnName num="sayo"]
"There's something I want to give you."
[cpg cn=true]

The master supported Masato and pulled his hand and went upstairs.
Behind him, in his intact position, was Butler Tanaka with his head bowed.
[cpg]



[FO pos="2/3" time=1000]
[BG f="b_04_2.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1138"]
[OnName num="sayo"]
"See, this place is the same as it was before."
[cpg cn=true]


[OnName num="masato"]
"Wow. It's true, I miss it"
[cpg cn=true]

This is the bedroom that the master used when he lived here. Come to think of it, there's been a lot going on here. A place filled with memories.
[cpg]

[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1139"]
[OnName num="sayo"]
"...I'm just the way I was then, really."
[cpg cn=true]


[OnName num="masato"]
"What?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo1140"]
[OnName num="sayo"]
"So I want to reward you for it."
[cpg cn=true]

Masato, the servant, knew immediately what the master was trying to say.
[cpg]

However, there is a reason why Masato is unable to accept the offer honestly.
[cpg]


[OnName num="masato"]
"..........I'm sorry. I just don't have the ability to function as a man anymore, so..."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1141"]
[OnName num="sayo"]
I don't care.
[cpg cn=true]

[FO pos="2/3" time=1000]

;**【ＣＧ】ev_14_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************


;//☆ＣＧエンディング（雅人＆小夜・額をコツンと当てる感じで顔を近づける二人：背景はイメージ的なやつ）ev_14
;//CGを再び表示


[VOICE f="Sayo1142"]
[OnName num="sayo"]
"With my toes, for example, with this finger, for example, with these lips...with my tongue...you name it."
[cpg]

"If you're going to take it, if you're going to leave a mark on it, I'd be... very happy."
[cpg cn=true]


[OnName num="masato"]
".............yes. It's too good to pass up, I'm honored. Respectfully, I will reward you."
[cpg cn=true]

Masato and Sayo don't transcend the boundaries of a sovereign, but are united by a stronger bond.
[cpg]

He became the one and only, a real master and servant.
[cpg]

;//【…ただいま。ルート】エンド
[jump storage="epend.ks" target="*back_title"]

;/////////////////////////////////////////////////////////////////////////////////

;//【合流C】
;//【比翼連理ルート】（※途中までの展開はEND１と同じ）

*root_hiyokurenri|marital vows

[window target=false]

[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

;//【ＢＧ】『豪邸、ホール』（昼）******************************************************


[OnName num="masato"]
"...Apparently, my ass is... protected"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo1143"]
[OnName num="sayo"]
"...................................................."
[cpg cn=true]

The man she was marrying was horrified that the girl he was after was a man, and he agreed to break off the engagement, saying that he had no intention of doing so.
[cpg]


[SE f=se078]
;//【ＳＥ】『衣擦れ』
[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=1000]
[WAIT time=1500]


At that moment, Master jumped into my chest with a big flap of his wings.
[cpg]

[window target=false]

;//ＢＫ

[STOPBGM]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『小夜の部屋』（夜）******************************************************


[BGM f="se"]

[window target=true]


After that one incident, life went back to normal.
[cpg]

My "man's daughter" strategy seems to have worked so well with my ex-married man that I have kept a certain distance from him at home for work, and our relationship has thinned out.
[cpg]

I don't think I'll be involved with him much in the future because he's avoiding me.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1144"]
[OnName num="sayo"]
Huh...I've calmed down, but it doesn't look like I'll be able to get out of this house as usual.
[cpg cn=true]


[OnName num="masato"]
I can't help it, but... you're a recluse again.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo1145"]
[OnName num="sayo"]
Don't be a shut-in.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo1146"]
[OnName num="sayo"]
It's a strange feeling to have another one of your own.
[cpg cn=true]


[OnName num="masato"]
''Haha, that's right. I'm sorry.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo1147"]
[OnName num="sayo"]
I don't think you have anything to apologize for.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo1148"]
[OnName num="sayo"]
"But now you're... just like me. You're going to be forced to live in a cramped cage, aren't you?
[cpg cn=true]


[OnName num="masato"]
It's fine. You've decided to serve your master for the rest of your life.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo1149"]
[OnName num="sayo"]
'Yes, you're a good boy. By the way, since you're going to have some free time from now on... I'd like to play something a little different.
[cpg cn=true]


[OnName num="masato"]
What do you mean?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo1150"]
[OnName num="sayo"]
There will be things you haven't done yet.
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』
[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

;//レターボックスin
[FACE method="feadin_up" pos="4/7"]

[WAIT time=1500]

Saying this, Sayo began to undress. With that alone, Masato knows what he is going to do.
[cpg]

[OnName num="masato"]
''I'm glad, but I don't wish it on myself. However, if you command it...
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo1151"]
[OnName num="sayo"]
"Shush. Yeah, that's an order. I won't accept your refusal."
[cpg cn=true]


[OnName num="masato"]
"Yes, madam"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo1152"]
[OnName num="sayo"]
You're a difficult character.
[cpg cn=true]


[OnName num="masato"]
"You too, master"
[cpg cn=true]

The two of them laughed at each other. I layered my body in a way that I hadn't done before.
[cpg]

A master and a servant, a woman and a man, a sister... They became the same entity and were sublimated into a special relationship that could not be found anywhere else.
[cpg]


[STOPBGM]

;//レターボックスout
[FACE method="feadout_up" pos="4/7"]

[FO pos="2/3" time=1000]


;//●ＣＧエンディング（雅人＆小夜・小夜が上で覆いかぶさる様にして騎乗位で挿入。破瓜あり：小夜の部屋）ev_15

;//[if exp="f.first_select == 1"]
;**【ＣＧ】ev_15_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
;//[endif]


;//[if exp="f.first_select == 2"]
;**【ＣＧ】ev_15_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
;//[endif]

[BGM f="h1"]


Death will separate them and keep them together.
[cpg]

[WAIT time=1000]

[BG f="black.ui" time=2500]
[WAIT time=2500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

;//暫くCGを表示してゆっくりとフェードアウト。その後スタッフロール。



;//【比翼連理ルート】エンド
[jump storage="epend.ks" target="*start"]



;/////////////////////////////////////////////////////////////////////////////////


;//【合流B】
;//【遠き存在ルート】
*root_existence|Distant Presence

[stflag gohome_flag=0]
[stflag service_flag=0]

[window target=true]



In the end, I can't do anything about it. I couldn't think of anything.
[cpg]

[BG f="b_00_2.ui" time=1000]
[WAIT time=2000]

[BGM f="se"]

[FACE method="feadin" pos="4/7"]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_00_2_up.ui" time=1000]

[WAIT time=2000]

[OnName num="masato"]
Master, please take me with you.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo1153"]
[OnName num="sayo"]
I can't do that.
[cpg cn=true]


[OnName num="masato"]
Well, then, at least I'm not leaving you for a moment.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[WAIT time=1000]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo1154"]
[OnName num="sayo"]
"Pretty girl.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo1155"]
[OnName num="sayo"]
"I love you more than a dog, more than a cat...
[cpg cn=true]


[OnName num="masato"]
"Master..."
[cpg cn=true]

Licking your wounds, excellent. If it will save the master, even a little...
[cpg]


[window target=false]

[SE f=se005]
;//【ＳＥ】『歩く』

[transition target={true} rule="morble1.webp" color={0x000000ff} time=2000]
[WAIT time=3100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=500]

[BG f="b_07_1.ui" time=2000]
[WAIT time=2000]
;//ＢＫ
[window target=true]


The master got married, the master was gone, and I was unemployed again.
[cpg]

I couldn't do anything...nothing...nothing.
[cpg]


;//【遠き存在ルート】エンド
[jump storage="epend.ks" target="*start"]


