*start

;#################################################
*Ep012|Dark Cloud M Castle
;#################################################

[SCENE id=12]


[stflag jump_scene=0]
[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep002で発生	ジャンプしてきた場合奉仕ルートで固定
[stflag gohome_flag=0]
[stflag pets_flag=1]
[endif]


[BG f="black.ui" time=1000]
[WAIT time=1000]

[window target=true]


It's been a long time since I've been able to live my life without any major problems, but suddenly there was a glimmer of hope.
[cpg]


[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BGM f="se"]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夜）******************************************************

[window target=true]


[OnName num="masato"]
"......what?"
[cpg cn=true]


[OnName num="butler"]
"Oops, I almost dropped you. Get a grip.
[cpg cn=true]


I dropped the glass I was polishing and almost broke it.
[cpg]

It's not the usual failure. He had abandoned himself.
[cpg]

[OnName num="masato"]
Um, Mr. Tanaka... what did you say?
[cpg cn=true]


[OnName num="butler"]
「………」
[cpg cn=true]


[OnName num="masato"]
Master is getting married...?
[cpg cn=true]

[STOPBGM]
[BGM f="se"]

It was something I was suddenly informed of.
[cpg]

The master's house had once fallen into a business crisis. It became difficult for the company and the house to survive... It seems that at such a time, a person helped him out of his predicament.
[cpg]

That was... the master's mate.
[cpg]

Because of that, the master is supposed to marry a fat man who is amorous and has no good reputation.
[cpg]

Marriage is imminent.
[cpg]

It would be a life more like a doll to be served than a marriage.
[cpg]

I've been trying to postpone it by deceiving myself until now, but such deceit is no longer possible.
[cpg]

A full-fledged enlistment is nearing. That's when I finally found out about it.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

;//【ＢＧ】『豪邸、廊下』（夜）******************************************************

[window target=true]


[OnName num="masato"]
Master, may I... may I have a word?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0843"]
[OnName num="sayo"]
Something.
[cpg cn=true]


[OnName num="masato"]
''Well...I heard from Tanaka-san that you're getting married...or something...''
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0844"]
[OnName num="sayo"]
「………」
[cpg cn=true]


[OnName num="masato"]
You're kidding, right?
[cpg cn=true]


[FG f="CHA01_p4_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0845"]
[OnName num="sayo"]
'...no, really.
[cpg cn=true]


[VOICE f="Sayo0846"]
[OnName num="sayo"]
In a few months, I'm supposed to be...getting married.
[cpg cn=true]


[VOICE f="Sayo0847"]
[OnName num="sayo"]
"I'm going to marry off to someone your father knew...
[cpg cn=true]


[OnName num="masato"]
''So...it's not like...''
[cpg cn=true]


It was true. The strength seems to drain from his body.
[cpg]

[OnName num="masato"]
Are you sure about this?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0848"]
[OnName num="sayo"]
It's what's supposed to happen. I'm convinced, too.
[cpg cn=true]


[OnName num="masato"]
No, I mean, is he really... is he someone you want to marry?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0849"]
[OnName num="sayo"]
"What have you been...? What's your point?
[cpg cn=true]


[OnName num="masato"]
It's just that...
[cpg cn=true]


I don't know what to say. However, I don't want her to be gone.
[cpg]

[OnName num="masato"]
What will happen to me? When the master is gone...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0850"]
[OnName num="sayo"]
"I'll make sure you're ready to work here as you've always been. Well, the job description will change a bit, but...
[cpg cn=true]


[OnName num="masato"]
''It's not, it's not... master!
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo0851"]
[OnName num="sayo"]
Pssst!
[cpg cn=true]


[OnName num="masato"]
Don't... don't... don't leave me.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0852"]
[OnName num="sayo"]
"........."
[cpg cn=true]


[OnName num="masato"]
"Please don't go, master... when you're gone, I'll be back...
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0853"]
[OnName num="sayo"]
"...shut up."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0854"]
[OnName num="sayo"]
It's none of your business.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo0855"]
[OnName num="sayo"]
I'm done talking about this. Don't ever do that again...
[cpg cn=true]


[OnName num="masato"]
"..........................."
[cpg cn=true]


The master built the wall.
[cpg]


I've never called him names before, but I've never called him "you".
[cpg]


I don't know what to do...I don't know what to do...I don't know what to do.
[cpg]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[STOPBGM]

[if exp={getFlagValue("pets_flag") == 0 }]
;//[jump storage="ep013.ks" target="*start"]
[jump target="*ep012_jump"]
[endif]
;///////////////////////////////////////////////////////////
;//最初の選択肢で『ペット』を選んでいた場合にのみ表示されるイベント

*Scene12

*event_pet|暗雲Ｍ城

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ



I'm still being Oshioki today. This time, however, it was different than usual.
[cpg]


[SE f=se078]
;//【ＳＥ】『衣擦れ』

[BGM f="h1"]


;//●ＣＧエロ（雅人＆小夜・椅子に縛られて騎乗位挿入。ロリの腕に抱かれたり、顔をスリスリされる：小夜の部屋）ev_20

;**【ＣＧ】ev_20_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1500]

[OnName num="masato"]
"Master... why are you doing this...
[cpg cn=true]


[VOICE f="Sayo0856"]
[OnName num="sayo"]
Come on... feel good. Nothing but that.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


That said, her appearance was different than usual.
[cpg]


[OnName num="masato"]
No, please don't.
[cpg cn=true]


[VOICE f="Sayo0857"]
[OnName num="sayo"]
"Stop...? Why?
[cpg cn=true]


[OnName num="masato"]
It's...
[cpg cn=true]


[VOICE f="Sayo0858"]
[OnName num="sayo"]
"I'm telling you that I'm going to give you a brush-off of the trash cock that won't leave your virginity for the rest of your life..."
[cpg cn=true]


[OnName num="masato"]
But you can't do that...
[cpg cn=true]


[VOICE f="Sayo0859"]
[OnName num="sayo"]
Shut up.
[cpg cn=true]


[VOICE f="Sayo0860"]
[OnName num="sayo"]
All you have to do is shut up and buck your shabby ass out there.
[cpg cn=true]


Inside her, my things go into her.
[cpg cn=true]

;**【ＣＧ】ev_20_a ***********************
[CG id=19 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo0861"]
[OnName num="sayo"]
"...ugh...ughhhh...ughhhh!"
[cpg cn=true]


[VOICE f="Sayo0862"]
[OnName num="sayo"]
"Huh, huh... it's small, but it hurts, doesn't it?"
[cpg cn=true]


It was the first time she had done that too.
[cpg]


[VOICE f="Sayo0863"]
[OnName num="sayo"]
Shut up and don't move.
[cpg cn=true]


[VOICE f="Sayo0864"]
[OnName num="sayo"]
"Hmmm...hmmm...hmmm...hmmm...hmmm..."
[cpg cn=true]


[VOICE f="Sayo0865"]
[OnName num="sayo"]
Yes, stay focused. Enjoy the feeling inside of me.
[cpg cn=true]


[VOICE f="Sayo0866"]
[OnName num="sayo"]
We might never have that again, right? Sssh...first and last sex, enjoy it.
[cpg cn=true]


Master remains on top and begins to move slowly.
[cpg]


[VOICE f="Sayo0867"]
[OnName num="sayo"]
I don't know if it's in there or not, but it's moving desperately inside...
[cpg cn=true]


[VOICE f="Sayo0868"]
[OnName num="sayo"]
Oh, no. Hmmm...hmmm...hmmm...hmmm...
[cpg cn=true]


[VOICE f="Sayo0869"]
[OnName num="sayo"]
"Huh...ugh, ugh! It's amazing... even though it's a garbage cock, I can feel it.
[cpg cn=true]


[VOICE f="Sayo0870"]
[OnName num="sayo"]
"Aww, aww...good. I'm sure you'll be happy to hear that."
[cpg cn=true]


[VOICE f="Sayo0871"]
[OnName num="sayo"]
"Aaahhhh...ahhh...ahhh...ahhh...ahhh...ahhh!"
[cpg cn=true]


[VOICE f="Sayo0872"]
[OnName num="sayo"]
"Aaaaah! At the entrance, gurgling...ahhhhh, that feels good...!"
[cpg cn=true]


[VOICE f="Sayo0873"]
[OnName num="sayo"]
"Humph... my body is also small, so maybe it's the right size."
[cpg cn=true]


The Master shook his hips in a single-minded manner.
[cpg]


[VOICE f="Sayo0874"]
[OnName num="sayo"]
"Oooh! Ahhhh...ahhh...ahhh...ahhh!"
[cpg cn=true]


[VOICE f="Sayo0875"]
[OnName num="sayo"]
"No...I'm coming. Oh, I'm going to cum...I'm going to cum with my garbage cock!
[cpg cn=true]


[OnName num="masato"]
I don't know...
[cpg cn=true]


[VOICE f="Sayo0876"]
[OnName num="sayo"]
"Come, ah...with me, ah...ahhhhhhhhhhhhhhhhhhh!!!!"
[cpg cn=true]

;**【ＣＧ】ev_20_b ***********************
[CG id=19 index=2 time=1000]
;***************************************
[WAIT time=1500]

Doby-doby-doby-doby-doby-doby-doby.
[cpg]


[VOICE f="Sayo0877"]
[OnName num="sayo"]
"Huh...huh...huh...huh..."
[cpg cn=true]


[VOICE f="Sayo0878"]
[OnName num="sayo"]
"Hmmm...ah, my stomach is...hot. It's so full... it's cumming."
[cpg cn=true]


[VOICE f="Sayo0879"]
[OnName num="sayo"]
"Ahhhhhh...even though you're short, your ejaculation volume is amazing."
[cpg cn=true]


[VOICE f="Sayo0880"]
[OnName num="sayo"]
"I love this cock. I love it!"
[cpg cn=true]


[BG f="black.ui" time=1000]
;//ＢＫ


Since then, I've had a total of more than a dozen ejaculations.
[cpg]


[OnName num="masato"]
"I can't do it anymore! I don't want to... no, no, no, no, I don't want to let you out! I don't want to get it out! I'm sorry, master! I don't have any money... I don't have any money!"
[cpg cn=true]


[OnName num="masato"]
"I'm empty already...why won't you stop? aaahhhhhh...I know I'm empty already ...aaahhhh, no, no, no, no, no, no, no, no!"
[cpg cn=true]

There is no ejaculation sound when you are in good spirits, It's just silence.
[cpg]

His body spasmed, his meat rod pulsed several times... the inside of his penis moved along with the ejaculation mechanism, trying to get the liquid out.
[cpg]

However, there is no semen. It's already empty. Instead, it barely bleeds.
[cpg]

The act of ejaculation that makes you feel good has become a torture in excess of a degree.
[cpg]

;**【ＣＧ】ev_20_c ***********************
[CG id=19 index=3 time=1000]
;***************************************

[VOICE f="Sayo0881"]
[OnName num="sayo"]
Just one more time, and you'll do well.
[cpg cn=true]


[OnName num="masato"]
"Ugh, gosh...I can't do it, I can't do it!
[cpg cn=true]


[VOICE f="Sayo0882"]
[OnName num="sayo"]
"Here, hang in there, hang in there. It feels good, feels good, feels good, Your cock feels good!"
[cpg cn=true]


The master tries to soothe her and make her do her best until the end.
[cpg]

;**【ＣＧ】ev_20_d***********************
[CG id=19 index=4 time=1000]
;***************************************
[WAIT time=1500]

——どびゅっどびゅっどびゅっ。
[cpg cn=true]

[BG f="black" time=1000]
;//ＢＫ

[WAIT time=1500]


[BG f="b_04_4_up.ui" time=1000]


[FG f="CHA01_p3_00_a.ui" method="change_1"  pos="2/3" time=1000]
[VOICE f="Sayo0883"]
[OnName num="sayo"]
"You did a good job. Great, great, great!"
[cpg cn=true]


[OnName num="masato"]
"Ugh..."
[cpg cn=true]

[FO pos="2/3" time=1000]

After I did my best, he would lap me up and pat me on the head while praising me for being a good boy and a good boy.
[cpg]

How could she have done this....
[cpg]


[SCENE id=11]
[ENDPARTIAL]

[STOPBGM]

[BG f="black.ui" time=1000]
[WAIT time=1500]


[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse



*ep012_jump

[jump storage="ep013.ks" target="*start"]



;///////////////////////////////////////////////////////////
