*start

;#################################################
*Ep007|Milk Tea
;#################################################

[SCENE id=7]


[stflag jump_scene=0]
[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]

[SE f=se018]
;//【ＳＥ】『鳥の鳴き声』


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1500]


[BGM f="d1"]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（朝）******************************************************

[window target=true]

[OnName num="masato"]
''Mm-hmm, mm-hmm.''
[cpg cn=true]



It's already been a few months since I came to this house.
When I first came here, there were a lot of things I didn't understand, and I was being taught a lot of things... but I think that's a little less of a problem now.
[cpg]


[OnName num="masato"]
Alright, let's go for it today.
[cpg cn=true]




[STOPBGM]
[BGM f="d1"]
[BG f="b_01_1.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（朝）******************************************************


[OnName num="maid_A"]
Good morning, Mr. Masato.
[cpg cn=true]


[OnName num="butler"]
Good morning.
[cpg cn=true]


[OnName num="masato"]
「おはようございます」
[cpg cn=true]


As we walked out into the hallway, we met the maid and Tanaka-san and exchanged greetings. I'll be able to get to work in the morning without delay today.
[cpg]


[OnName num="butler"]
''Come on, the young lady is waiting for you. Let's go.
[cpg cn=true]


[OnName num="maid_A"]
Yes!
[cpg cn=true]


[OnName num="masato"]
Yes!
[cpg cn=true]


Now that I feel like I've finally become a member of this company, I can't let my guard down.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ


[STOPBGM]
[BGM f="sl" time=1000]
[BG f="b_04_1.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（朝）******************************************************
;//※小夜の部屋にはベランダというかテラスがある。そこでお茶を楽しむ



[OnName num="masato"]
Good morning, Master.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0291"]
[OnName num="sayo"]
Good morning.
[cpg cn=true]




When they entered the room, the master stepped out onto the terrace and sat down on a chair made of white.
[cpg]

Here, she enjoys her morning tea time before going to school.
[cpg]

Of course, there's plenty of time to make sure you're not late.
[cpg]

The master is getting up by himself even if we don't wake him up. But I want to wake you up once in a while...
[cpg]


[OnName num="maid_A"]
"My Lady, what would you like for your tea this morning?
[cpg cn=true]


[VOICE f="Sayo0292"]
[OnName num="sayo"]
''Well...I'd like some milk tea, which I've been loving lately.
[cpg cn=true]


[OnName num="maid_A"]
Yes, sir.
[cpg cn=true]




There are many things that Tanaka-san and especially me only refrain from doing because most maids do it about serving.
[cpg]

But Mr. Tanaka...
[cpg]


[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0293"]
[OnName num="sayo"]
"World affairs are a bitching matter...
[cpg cn=true]


[OnName num="butler"]
Well, now even in the Middle East...blah, blah, blah, blah...
[cpg cn=true]




He is firmly talking to his master. The two of them always have something intelligent to say.
[cpg]

I'm not an educated person, so it sounds like a spell or something...
[cpg]

It's a bit of an alienation.
[cpg]

I need to learn a little more about myself so I can be more useful to my master...!
[cpg]


[OnName num="maid_A"]
Thank you for waiting
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0294"]
[OnName num="sayo"]
Thank you.
[cpg cn=true]




[SE f="se041"]
;//【ＳＥ】『カップの音』カチャカチャ


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0295"]
[OnName num="sayo"]
Today's tea is good too.
[cpg cn=true]


[OnName num="maid_A"]
Thank you, Miss.
[cpg cn=true]


[OnName num="masato"]
I want to be praised too...
[cpg cn=true]




It's only at this time in the morning that I don't get any action.
[cpg]

No, it may not be a limited thing. I've always been a bit overshadowed...like I'm not much of a help.
[cpg]


[OnName num="maid_A"]
Miss, would you like a refill?
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0296"]
[OnName num="sayo"]
 I'll take it.
[cpg cn=true]


[OnName num="maid_A"]
''Yes, sir, I'm awed.''
[cpg cn=true]




The maid is in a good mood.
[cpg]

A compliment on a good cup of tea, and another... it's a pleasure. Goddamn it.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0297"]
[OnName num="sayo"]
'...........?
[cpg cn=true]


[OnName num="masato"]
''Ha...!''
[cpg cn=true]




She noticed that she was giving Master a hot look and peeped away.
[cpg]

After all this time, I realized that I was jealous of the maid, and I felt embarrassed.
[cpg]


[OnName num="masato"]
(What the hell am I thinking? Let's keep it quiet...)
[cpg cn=true]




We've been in this house for a few months now. I've been through the same amount at this time of the morning.
[cpg]

You'll be able to get the best of both worlds.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0298"]
[OnName num="sayo"]
"Hey, servant. Come on over here.
[cpg cn=true]


[OnName num="masato"]
''Ha...yes!''
[cpg cn=true]




[SE f="se042"]
;//【ＳＥ】『早足』タタタ


He is called out and reflexively moves to his master. It's already dog behavior.
[cpg]

And being a dog, I don't know why they called me...my heart rumbles with anticipation and anxiety.
[cpg]

[OnName num="masato"]
''(Ugh...I guess I was offended because I was staring at it zealously a while ago.)''
[cpg cn=true]




If that happens, it's not good.
[cpg]

Not only that, but it means I've interfered with Master's leisure time.
[cpg]

Isn't it an epic failure as a servant?
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0299"]
[OnName num="sayo"]
...there's milk tea.
[cpg cn=true]


[OnName num="masato"]
Ha, yes? That's right.
[cpg cn=true]


The master suddenly began to talk about tea. Right now, she is also getting a mouthful of milk tea.
[cpg]

I can't keep up with you if you talk about tea leaves....
[cpg]


[VOICE f="Sayo0300"]
[OnName num="sayo"]
'I wonder if the milk in this is something else... or if it tastes good. What do you think?
[cpg cn=true]


[OnName num="masato"]
"Huh...well, for example, goat's milk? There will be a bit of a stink to it, but I thought it would be a different way to enjoy it than usual...
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0301"]
[OnName num="sayo"]
You're right. It's a good quality product, so of course it's delicious... but sometimes you want to enjoy a different flavor...
[cpg cn=true]




It was a question I hadn't expected, so I replied without thinking too deeply about it.
[cpg]

It seems the master wants to drink a different flavor of milk tea.
[cpg]

However, I hadn't prepared anything for it... I was at a loss as to what to do, so I turned to look at Mr. Tanaka.
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0302"]
[OnName num="sayo"]
Can you pour me some milk?
[cpg cn=true]


[OnName num="masato"]
Ha, yes, I'm home!
[cpg cn=true]




Not knowing what to do, she grabs the vial of milk on the table.
[cpg]


[FG f="CHA01_p4_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0303"]
[OnName num="sayo"]
"No, it's not. It's not that...
[cpg cn=true]


[OnName num="masato"]
''Also, I'm sorry. Let's see... then I'll go find another milk!
[cpg cn=true]


[VOICE f="Sayo0304"]
[OnName num="sayo"]
No. You're in there, there's another milk...
[cpg cn=true]


[OnName num="masato"]
?
[cpg cn=true]


She stopped moving as she was about to make a dash for the kitchen.
[cpg]

I had no idea what Master's intentions were, and a number of question marks were lined up on my head.
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo0305"]
[OnName num="sayo"]
You're talking about how the milk in milk tea... is it good with semen in it?
[cpg cn=true]


[OnName num="masato"]
'....................I don't know.
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0306"]
[OnName num="sayo"]
I'm sure.
[cpg cn=true]


Milk tea with semen is one of the few things you've ever had.
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0307"]
[OnName num="sayo"]
They call semen "milk," too, so I'm not sure if it fits...
[cpg cn=true]


''Master, how could you suddenly come up with such an active act? It's great to be a challenger though.
[cpg]

Where are all the intellectual stories that grace our elegant teatime?
[cpg]

[OnName num="masato"]
I don't know...Tanaka-san?
[cpg cn=true]


[OnName num="butler"]
! Well, now...I'm a man too, so unfortunately I've had such an experience...how about you, Ochiai-san?
[cpg cn=true]


[OnName num="maid_A"]
Tanaka-san, this is sexual harassment.
[cpg cn=true]


[OnName num="butler"]
"What the hell?
[cpg cn=true]


As a result of the easy shaking of the story, the question jumped to the surface. Tanaka-san, I'm sorry.
[cpg]


[FG f="CHA01_p4_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0308"]
[OnName num="sayo"]
It can't be helped to ponder, so let's try it out right away.
[cpg cn=true]


[OnName num="masato"]
Huh! Are you serious!
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0309"]
[OnName num="sayo"]
They say, "You have to try things. Here, let me out.
[cpg cn=true]


[OnName num="masato"]
''No, eh...hey...''
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0310"]
[OnName num="sayo"]
Let me out.
[cpg cn=true]


[OnName num="masato"]
 "………Yes" 
[cpg cn=true]


I'm the master's servant. You can't go against the master.
[cpg]

I think it's time to think about it more, to change it... and I don't have time for that.
[cpg]

I don't know if it was a sudden thought of hers or if it was just for fun... but I ended up pulling down my pants in front of everyone.
[cpg]

*Scene07

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ


[SE f="se029"]
;//【ＳＥ】『ベルト＆ファスナー』カチャカチャ、ジィーッ


;//●ＣＧエロ（小夜・ティータイムのご主人様にミルクを提供：小夜の部屋）ev_16


[BGM f="h1" time=1000]
;**【ＣＧ】ev_16_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************

[VOICE f="Sayo0311"]
[OnName num="sayo"]
Pour it out quickly. The tea is getting cold.
[cpg cn=true]


[OnName num="masato"]
I know...I know. But...
[cpg cn=true]


[OnName num="butler&maidA"]
Zeeee..................
[cpg cn=true]


[OnName num="masato"]
Don't look at me like that! It's embarrassing!
[cpg cn=true]


[OnName num="butler"]
"No, no, we have nothing to say, sir.
[cpg cn=true]


[OnName num="maid_A"]
''Yeah, I'm just looking at it. Don't worry about it.
[cpg cn=true]


[OnName num="masato"]
''No, she's too embarrassed to be seen!''
[cpg cn=true]


;**【ＣＧ】ev_16_a ***********************
[CG id=15 index=1 time=1000]
;***************************************
[VOICE f="Sayo0312"]
[OnName num="sayo"]
Shut up! Don't make a mess, just do it!
[cpg cn=true]


[OnName num="masato"]
''Yes, yes...''
[cpg cn=true]




Shuko, shuko, shuko...
[cpg]

I can't help it if it's an order, I'm grasping and handling my shabby things in front of my master's eyes.
[cpg]

[OnName num="masato"]
Huh...huh...huh...
[cpg cn=true]


[VOICE f="Sayo0313"]
[OnName num="sayo"]
「………」
[cpg cn=true]


It's the first time I've ever been able to stare so intently at a place I'm handling myself.
[cpg]

When I think that my master is watching me, my body reacts...I get excited on its own.
[cpg]


[VOICE f="Sayo0314"]
[OnName num="sayo"]
Mr. Mikuni.
[cpg cn=true]


[OnName num="maid_A"]
'Yes, sir, what can I do for you?
[cpg cn=true]


[BG f="black.ui" time=1000]
;//ＢＫ

;//ここから内緒話


[VOICE f="Sayo0315"]
[OnName num="sayo"]
I wonder if they're getting it right.
[cpg cn=true]


[OnName num="maid_A"]
I mean...?
[cpg cn=true]


[VOICE f="Sayo0316"]
[OnName num="sayo"]
It seems a little different from the groping I know...
[cpg cn=true]


[OnName num="maid_A"]
''Oh...it's okay. Don't worry.
[cpg cn=true]


[VOICE f="Sayo0317"]
[OnName num="sayo"]
So, is that right?
[cpg cn=true]


[OnName num="maid_A"]
''Young lady, this is called leather masturbation.
[cpg cn=true]


[VOICE f="Sayo0318"]
[OnName num="sayo"]
"Kaw...?
[cpg cn=true]


Oh, the master is so cute that he wiggles without understanding the meaning!
[cpg]

[OnName num="maid_A"]
''Like Mr. Masato, the one with a phallus, apart from handling the rod directly... he uses this excess skin for nothing and uses it to get sexual pleasure from handling it.
[cpg cn=true]


It's an explanation that sticks in my mind.
[cpg]

[VOICE f="Sayo0319"]
[OnName num="sayo"]
''I see, there's such a thing, isn't there? I've learned a lot.
[cpg cn=true]


[OnName num="maid_A"]
I'm glad I could be of some help.
[cpg cn=true]


Ah, the master is getting erudite again...! I feel like I'm wasting my knowledge on you!
[cpg]

[VOICE f="Sayo0320"]
[OnName num="sayo"]
It's not going to come up...
[cpg cn=true]


She muttered to herself as if she'd waited too long.
[cpg]


[OnName num="masato"]
''But, I'm sorry...hah, hah...I'll be out soon, I'll be out soon!
[cpg cn=true]


[VOICE f="Sayo0321"]
[OnName num="sayo"]
We're running out of time. Besides, if we don't hurry, it'll be time to go to school...
[cpg cn=true]


[OnName num="masato"]
''Excuse me...ha, ha, ha...''
[cpg cn=true]

[VOICE f="Sayo0322"]
[OnName num="sayo"]
I can't help it, I'll help you.
[cpg cn=true]


[OnName num="masato"]
Huh!
[cpg cn=true]

As he was single-mindedly handling things, Master picked up the teaspoon that he had placed with the teacup.
[cpg]

[VOICE f="Sayo0323"]
[OnName num="sayo"]
It's not going to work like that.
[cpg cn=true]


[OnName num="masato"]
''Ha...ha...ha...master, what are you doing...''
[cpg cn=true]

;**【ＣＧ】ev_16_b ***********************
[CG id=15 index=2 time=1000]
;***************************************

--Gulp gulp gulp gulp gulp.
[cpg]

[OnName num="masato"]
Whoo-hoo!
[cpg cn=true]


[VOICE f="Sayo0324"]
[OnName num="sayo"]
"Selling.
[cpg cn=true]


[OnName num="masato"]
''Ugh!'' Ha-ha-ha! (Oh, there's a spoon in the skin...in the spoon...in the skin!
[cpg cn=true]


The master pushed the teaspoon in his hand into the skin with a grind.
[cpg]

It's totally different from being stripped and treated... it gives you a new feeling and pleasure.
[cpg]


[OnName num="masato"]
''Oooh, master...that's...not good, ugh! No, no...!
[cpg cn=true]


[VOICE f="Sayo0325"]
[OnName num="sayo"]
What's wrong with that?
[cpg cn=true]


She giggles and asks the question while stirring the spoon inside.
[cpg]

[OnName num="masato"]
It's coming out!
[cpg cn=true]


I've never had a sexual feeling like this before. The metal moves like a living thing inside the skin, rubbing up the rod and inside the skin.
[cpg]


[VOICE f="Sayo0326"]
[OnName num="sayo"]
You can get it out. It's not a problem for me to get out.
[cpg cn=true]


With that said, the blame continues.
[cpg]

I want to put my body somewhere, but unfortunately I can't do that either... I hold my pants while standing upright.
[cpg]


[OnName num="masato"]
''Ugh...phew...phew...phew...''
[cpg cn=true]


[VOICE f="Sayo0327"]
[OnName num="sayo"]
You seem to like the spoon.
[cpg cn=true]


[OnName num="masato"]
''Ha-ha-hee...this is amazing. It feels too good...ahhhhhhh!
[cpg cn=true]


It's nothing compared to masturbation with your skin on, rather than with your skin on. More than that, it feels really, really good.
[cpg]

This is going to make me fall for the spoon rather than the leather masturbation.
[cpg]


Munch, munch...munch, munch, munch.
[cpg]

[VOICE f="Sayo0328"]
[OnName num="sayo"]
That sound is so cheap... it's quite a tone a pervert can produce.
[cpg cn=true]


[OnName num="masato"]
Thank you very much.
[cpg cn=true]


[VOICE f="Sayo0329"]
[OnName num="sayo"]
"Just kidding. Don't take it seriously.
[cpg cn=true]


;**【ＣＧ】ev_16_c ***********************
[CG id=15 index=3 time=1000]
;***************************************

Giiiiiiiiiiiiy.
[cpg]

[OnName num="masato"]
Aah!
[cpg cn=true]


Like a bit of an Oshioki, the Master tugged at the skin of the butt.
[cpg]

Even though it's leftover skin, it hurts when it's stretched to this extent.
[cpg]


[VOICE f="Sayo0330"]
[OnName num="sayo"]
''Ahahaha. Great, it's going to grow like this!
[cpg cn=true]


[VOICE f="Sayo0331"]
[OnName num="sayo"]
''With this much skin, I can't see the rod at all. Or is it just too small to see... I wonder how minuscule it is? Couscous♪
[cpg cn=true]


[OnName num="masato"]
I'm sorry.
[cpg cn=true]


I rejoice in the pleasure given by master's hand even though I apologize and expose molestation.
[cpg]

As it was, her hand was playing with me and all I could think about was ejaculating.
[cpg]


[OnName num="masato"]
''Hah, hah... hah, hah... hah, hah...''
[cpg cn=true]


[VOICE f="Sayo0332"]
[OnName num="sayo"]
What's the matter? You make a face like that... is this so good?
[cpg cn=true]


[OnName num="masato"]
Yes, yes... it's very good.
[cpg cn=true]



[VOICE f="Sayo0333"]
[OnName num="sayo"]
More so than the leather masturbation thing?
[cpg cn=true]


[OnName num="masato"]
Yes, sir.
[cpg cn=true]


I was too scared to put a foreign object inside myself.
[cpg]

This is a play that I might not have done in my life if it wasn't for Master.
[cpg]

The sense of ejaculation intensifies in the sensation that the internal organs are gouged out.
[cpg]

By the way, I was supposed to be handling it by myself, but before I knew it, I was getting Master to do it for me... He's a bad servant.
[cpg]


Grrrrrrrrrrrr.
[cpg]

chug chug chug!
[cpg]

[OnName num="masato"]
Ughhhhhh!
[cpg cn=true]


Master spun the spoon at high speed as he pulled the skin further.
[cpg]


[VOICE f="Sayo0334"]
[OnName num="sayo"]
"Come on, let's get this over with. You're going to be really late.
[cpg cn=true]


[OnName num="masato"]
"Ha, yes...it's coming out, it's coming out, it's coming out...it's coming out!
[cpg cn=true]


;**【ＣＧ】ev_16_d ***********************
[CG id=15 index=4 time=1000]
;***************************************

;//フラッシュ


[SE f="se026"]
;//【ＳＥ】『射精音』


——どびゅっどびゅっどびゅっ！！
[cpg]

[OnName num="masato"]
''Ah, ah... ah!''
[cpg cn=true]


Finally, the limit is exceeded and ejaculation begins. A large amount of vigorous sperm shot out in response to the heightened excitement.
[cpg]


[VOICE f="Sayo0335"]
[OnName num="sayo"]
It's finally out. Oh, my God... it's full of squeaks and whistles.
[cpg cn=true]



[VOICE f="Sayo0336"]
[OnName num="sayo"]
Hey... you're splattered. I'm not going to put you in a cup.
[cpg cn=true]


[OnName num="masato"]
''Huh, huh... sorry, I'm sorry...''
[cpg cn=true]


I couldn't aim firmly and ended up sperm-soaked not only in my cup, but also on the table.
[cpg]

[SCENE id=6]
[ENDPARTIAL]


[BG f="black.ui" time=1000]
;//ＢＫ


[STOPBGM]
[BG f="b_04_1.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（朝）******************************************************


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0337"]
[OnName num="sayo"]
Well, I'll have a quick bite.
[cpg cn=true]


She takes a sip of the steamy, hot tea with milk (sperm).
[cpg]

[FG f="CHA01_p4_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0338"]
[OnName num="sayo"]
Nn......kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk..."
[cpg cn=true]


[OnName num="masato"]
......"
[cpg cn=true]


I wonder how it actually is, is it really that delicious...I wait for Master's reaction for a few seconds while basking in the aftermath of the ejaculation....
[cpg]

[FG f="CHA01_p4_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0339"]
[OnName num="sayo"]
''-----It's tasteless!!!!!
[cpg cn=true]


[SE f="se043"]
;//【ＳＥ】『紅茶をかける』パッシャーン


[OnName num="masato"]
Azzuuuuhhh!" I'm sorry!
[cpg cn=true]


The master threw the cup he was holding at me, as it was still tasteless.
[cpg]

[BGM f="d1" time=1000]
[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0340"]
[OnName num="sayo"]
It's worse than I expected. That's disappointing...
[cpg cn=true]


It's probably because my sperm is bad. No, I think sperm is a bad thing, but it's not about that.
[cpg]

It's my fault that I couldn't produce a sperm that tastes good to the Master.
[cpg]

[OnName num="masato"]
''Ugh...I'm sorry. Master, do whatever you want to punish me!
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0341"]
[OnName num="sayo"]
? Why?
[cpg cn=true]


[OnName num="masato"]
Um, because now...
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0342"]
[OnName num="sayo"]
I said it wasn't good, but you didn't say it wasn't.
[cpg cn=true]


Hmm, so that means... he won't be offended.
[cpg]

[FG f="CHA01_p4_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0343"]
[OnName num="sayo"]
Besides, it wouldn't be a punishment because it would make me feel better if I masturbated...
[cpg cn=true]


[OnName num="masato"]
''Ah, ah, ah, ah...''
[cpg cn=true]


It's true that I'm a reprimanding and rewarding person, so if I had to put it this way, the meaning of Oshioki has faded.
[cpg]

Oh, to let the master baffle Oshioki...I hate this constitution sometimes.
[cpg]


[OnName num="butler"]
Lady, I think it's time...
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0344"]
[OnName num="sayo"]
It's time. Well then, let's go.
[cpg cn=true]


[VOICE f="Sayo0345"]
[OnName num="sayo"]
Thanks for the food.
[cpg cn=true]


The master leaves his seat and leaves the room. But only once did he stop in his tracks.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0346"]
[OnName num="sayo"]
I'll see you soon, please. Good luck trying to make more delicious milk this time.
[cpg cn=true]


That's what he told me.
[cpg]

[OnName num="masato"]
''Ha, yes! I'll do my best!
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0347"]
[OnName num="sayo"]
I'm counting on you.
[cpg cn=true]


[SE f="se016"]
;//【ＳＥ】出て行く


[FO pos="2/3" time=1000]
My motivation, which had been waning at her words, swelled up.
[cpg]

All right! Let's do our best to provide Master with some delicious milk (sperm)!
[cpg]


[STOPBGM]
[BG f="black.ui" time=1000]
;//ＢＫ


[WAIT time=600]

[BG f="b_01_1.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（朝）******************************************************


[SE f="se005"]
;//【ＳＥ】『歩く』


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="maid_A"]
Excuse me, miss.
[cpg cn=true]


[VOICE f="Sayo0348"]
[OnName num="sayo"]
"What?
[cpg cn=true]


[OnName num="maid_A"]
It's just my opinion... that semen is better when it's male.
[cpg cn=true]


[VOICE f="Sayo0349"]
[OnName num="sayo"]
Yes, you're right.
[cpg cn=true]


[VOICE f="Sayo0350"]
[OnName num="sayo"]
''It's sludgy and sticky, and when it touches the water, it makes you squirm... There's nothing more tasteless and delicious than man-smelling semen.
[cpg cn=true]


[OnName num="maid_A"]
So the one from earlier...
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0351"]
[OnName num="sayo"]
"Well, I don't know. I don't know if she really understands what "delicious" means.
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0352"]
[OnName num="sayo"]
I'm not looking forward to that.
[cpg cn=true]


[OnName num="maid_A"]
''(Miss, you're being mean.)''
[cpg cn=true]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ

[STOPBGM]
[BGM f="d1"]
[BG f="b_06_2.ui" time=1000]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（昼）******************************************************


After this morning's incident, I've been trying to figure out how to make my sperm taste better...even as I work.
[cpg]

[OnName num="masato"]
''Ummm... what should I do?
[cpg cn=true]


Since then, I've done a lot of research in my own way, but I can't find any answers.
[cpg]

I don't think that's possible in the first place...
[cpg]

[OnName num="masato"]
''Delicious sperm...? I guess I can't do it after all?
[cpg cn=true]


The first thing sperm can't do is smell like this. The smell. I'm sure there's some individual differences, but the premise stinks.
[cpg]

Also, I think the texture is bad. Mouthfeel is important.
[cpg]

Taste must be tackled as a matter of course. A bitter taste would not be good.
[cpg]

Apparently, it can be a little sweet or salty for some people, so it shouldn't be impossible.
[cpg]

[OnName num="masato"]
Protein, cholesterol...hmmm...what do I do with it?
[cpg cn=true]


While investigating the main components of semen, he tries to find a way to change the taste... but soon he hits a dead end.
[cpg]

This is quite a challenge.
[cpg]


[OnName num="masato"]
''Hmmm... maybe we should think of a way to make it taste good instead of the semen one?
[cpg cn=true]


For example, first thing in the morning, I prepare a cup... and pour it when I'm told.
[cpg]

I don't know when I'm going to get the call, so it's going to be hard to do it every day, but... I can do it.
[cpg]

But freshness is also important.
[cpg]

Then... how about mixing the sperm from the first thing in the morning with plenty of condensed milk?
[cpg]

It's much sweeter, and it's not so much less fresh.
[cpg]

[OnName num="masato"]
This... is it! This is the only way to do it!
[cpg cn=true]


I was convinced that I had a great idea, and my tone went haywire.
[cpg]

Once that's the case, we need to find the golden ratio right away...!
[cpg]

[OnName num="masato"]
All right, let's...
[cpg cn=true]


Swooshing.
[cpg]

I'm about to start a science experiment.
[cpg]


[STOPBGM]
[SE f="se034"]
;//【ＳＥ】『ノック』


[OnName num="maid_A"]
Mr. Masato, it's me.
[cpg cn=true]


[OnName num="masato"]
Huh? Mr. Ochiai? W-what is it, sir?
[cpg cn=true]


[OnName num="maid_A"]
May I come in for a moment to talk to you about your daughter? Or rather, it's coming in.
[cpg cn=true]


The door is mercilessly opened before you can say, "Wait a moment.
[cpg]


[SE f="se016"]
;//【ＳＥ】『扉を開ける』


[BGM f="co" time=1000]
[OnName num="maid_A"]
"Excuse me........................................................ Wha, what are you doing!
[cpg cn=true]


[OnName num="masato"]
''No, no... this is an experiment in trying to get semen out of a cup...''
[cpg cn=true]


[OnName num="maid_A"]
In the cup! That kind of hobby... or rather, even if you don't pretend, it's just normal masturbation!
[cpg cn=true]


[OnName num="masato"]
No, it's not. I'm not masturbating.
[cpg cn=true]


[OnName num="maid_A"]
What are you doing in the cup? You're going to drink it later! Perverts have noble taste too!
[cpg cn=true]


[OnName num="masato"]
''Ha, listen to me...''
[cpg cn=true]



[STOPBGM]
[BG f="black.ui" time=1000]

I'm explaining...............................
[cpg]

[WAIT time=600]

[BG f="b_06_2.ui" time=1000]


[BGM f="d1" time=1000]
[OnName num="maid_A"]
"Nah, Nalhod. I've been doing research for your daughter. I believed it.
[cpg cn=true]


[OnName num="masato"]
(It's an absolute lie.)
[cpg cn=true]


[OnName num="maid_A"]
So... what exactly is the method?
[cpg cn=true]


[OnName num="masato"]
"I was thinking of doing this like this...
[cpg cn=true]


[OnName num="maid_A"]
"..............."
[cpg cn=true]


[OnName num="masato"]
Uh, um...Mr. Ochiai?
[cpg cn=true]


[OnName num="maid_A"]
You were right to come and check on me after all.
[cpg cn=true]


She sighed, though she didn't know why.
[cpg]

[OnName num="maid_A"]
As a matter of fact, Mr. Masato. The lady is... gonyo gonyo gonyo gonyo.
[cpg cn=true]


[OnName num="masato"]
''What...eh...eh...eh...eh?
[cpg cn=true]


They gave me some serious information about milk (semen) tea. This is something you need to rethink.
[cpg]

...Also, her ear licks felt good.
[cpg]


[STOPBGM]
[BG f="black.ui" time=1000]
;//ＢＫ


--A week later...
[cpg]

*Scene08|Milk Tea

[BGM f="sl" time=1000]
[BG f="b_04_1.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（朝）******************************************************


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0353"]
[OnName num="sayo"]
''Today's tea is good too.''
[cpg cn=true]


[OnName num="maid_A"]
「ありがとうございます」
[cpg cn=true]


[OnName num="masato"]
(thumping...)
[cpg cn=true]


It's been a week since then. I'm waiting for the master to call on me again, whether it's now or not.
[cpg]

[FG f="CHA01_p2_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0354"]
[OnName num="sayo"]
.........
[cpg cn=true]


[VOICE f="Sayo0355"]
[OnName num="sayo"]
''(You're strangely restless and restless...)''
[cpg cn=true]


[VOICE f="Sayo0356"]
[OnName num="sayo"]
(...I'm sure they're preparing something for you. (And the expectant look).
[cpg cn=true]


[OnName num="maid_A"]
''Miss, if you'd like a refill...''
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0357"]
[OnName num="sayo"]
I'll take it.
[cpg cn=true]


Every time Master refills his tea, my heart rises. I was so nervous that the tips of my limbs were trembling in small increments.
[cpg]

It's no wonder when you're called upon. It's been a week since I thought so. Maybe...maybe...maybe...maybe.
[cpg]

[OnName num="maid_A"]
Lady, it's milk.
[cpg cn=true]


[VOICE f="Sayo0358"]
[OnName num="sayo"]
 "... Oh, I wonder if I'm going to do something different today." 
[cpg cn=true]


The master glances in my direction.
[cpg]

[FG f="CHA01_p2_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0359"]
[OnName num="sayo"]
"Servant.
[cpg cn=true]


[OnName num="masato"]
! Ha, ha!
[cpg cn=true]


[VOICE f="Sayo0360"]
[OnName num="sayo"]
Get ready for the milk.
[cpg cn=true]


[OnName num="masato"]
"Yes, sir! I'm awed!
[cpg cn=true]


--And finally, you've been called away.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ



;//☆ＣＧエロ（小夜・ティータイムのご主人様にミルクを提供：小夜の部屋）ev_16


;//CGを再び表示


[SE f="se029"]
;//【ＳＥ】『ベルト＆ファスナー』カチャカチャ、ジィーッ

[STOPBGM]
[BG f="black.ui" time=1000]

[WAIT time=1000]

[BGM f="h1"]

;**【ＣＧ】ev_16_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************

[OnName num="masato"]
excuse me
[cpg cn=true]

She unleashed the meat stick in her pants with a bang.
[cpg]


It's a lie. My things are not so big that they need to be onomatopoeic.
[cpg]

She takes out her own things, which are as small as ever, and handles them herself first to get the milk out.
[cpg]

[VOICE f="Sayo0361"]
[OnName num="sayo"]
Am I supposed to expect that?
[cpg cn=true]


[OnName num="masato"]
Yes, of course.
[cpg cn=true]


[VOICE f="Sayo0362"]
[OnName num="sayo"]
''Hmmm. But nothing seems to have changed since then...
[cpg cn=true]


Well, it's not like my dick is going to look any different after a week's time...
[cpg]

[OnName num="masato"]
''Master, I'm sorry...spoon...''
[cpg cn=true]


[VOICE f="Sayo0363"]
[OnName num="sayo"]
A spoon? Smell. Do you want me to do this again?
[cpg cn=true]


[OnName num="masato"]
''Ha, yes... please.
[cpg cn=true]


Not really, but as an act, it's the same... and I affirm it to keep things running smoothly.
[cpg]


[VOICE f="Sayo0364"]
[OnName num="sayo"]
You're a lousy servant, bothering your master's hand.
[cpg cn=true]


;**【ＣＧ】ev_16_b ***********************
[CG id=15 index=2 time=1000]
;***************************************
While saying so, Master inserted the teaspoon into the skin of the meat stick.
[cpg]


--Oh, phew.
[cpg]

[OnName num="masato"]
Kuh-uh!"
[cpg cn=true]


[VOICE f="Sayo0365"]
[OnName num="sayo"]
"Muzzles.
[cpg cn=true]


This is the second time I've been spoon fed by my master.
[cpg]


It's been a long time since I've felt this pleasure and my body is so hot that I almost forget my original duty.
[cpg]


Squishy...squishy...squishy...squishy...squishy.
[cpg]

Relentlessly, the skin is overrun.
[cpg]

[VOICE f="Sayo0366"]
[OnName num="sayo"]
'(You're sounding fast today...)''
[cpg cn=true]


[OnName num="masato"]
Ha, ha..."
[cpg cn=true]


When the time is right, I make a proposal to the master.
[cpg]

[OnName num="masato"]
Master, please try the one inside the skin as well.
[cpg cn=true]

[VOICE f="Sayo0367"]
[OnName num="sayo"]
"In the skin?
[cpg cn=true]


As I wondered, I pulled out the spoon...it was threaded like a sticky natto...and the tincture came out.
[cpg]

They are kept as clean as possible, but matured carefully in the skin.
[cpg]


[VOICE f="Sayo0368"]
[OnName num="sayo"]
What?
[cpg cn=true]


The master frowned. That's how strong the odor is.
[cpg]

[OnName num="masato"]
The flavor...hah...it gets better.
[cpg cn=true]


[VOICE f="Sayo0369"]
[OnName num="sayo"]
''Hmmm. There's no flavor...
[cpg cn=true]


Normally, it would be an outrageous act to let someone eat something that smells like this.
[cpg]

However, the master accepted the suggestion and brought the spooned sore to his mouth as a test.
[cpg]


[VOICE f="Sayo0370"]
[OnName num="sayo"]
Hmmm...hmmm...hmmm...hmmm...hmmm...
[cpg cn=true]


[VOICE f="Sayo0371"]
[OnName num="sayo"]
It tastes like the worst. It's too tasty.
[cpg cn=true]


[OnName num="masato"]
I'm sorry, sir.
[cpg cn=true]


Grumbling, Master plunged the spoon into the skin again.
[cpg]

Grrrrrr.....
[cpg]

Mix, scoop...the next tincture I took out, this time in the tea and stirred.
[cpg]

[VOICE f="Sayo0372"]
[OnName num="sayo"]
Well, now that you're here... let's put it in, shall we?
[cpg cn=true]


[OnName num="masato"]
「ありがとうございます」
[cpg cn=true]


After all, it's not a very bad reaction.
[cpg]

It's thanks to the advice I was surreptitiously given about what kind of things would please her.
[cpg]

[OnName num="masato"]
Uh-oh... soon we'll be leaving.
[cpg cn=true]


[VOICE f="Sayo0373"]
[OnName num="sayo"]
You're going to put it out in the cup, aren't you? Now, let's see what kind of milk we get today...
[cpg cn=true]


The master is looking forward to it. The milk that will live up to your expectations...
[cpg]

Today, I'm offering Master the 'Chinkas Milk (Semen) Tea'!
[cpg]


;//フラッシュ

;**【ＣＧ】ev_16_d ***********************
[CG id=15 index=4 time=1000]
;***************************************

[SE f="se026"]
;//【ＳＥ】『射精音』


--Doby-doby-doby-doby-doby!
[OnName num="masato"]
''Ugh, ugh...''
[cpg cn=true]


This time, all the semen is contained in the cup to avoid spilling.
[cpg]

[VOICE f="Sayo0374"]
[OnName num="sayo"]
Whoa... this is...?
[cpg cn=true]


The semen is spit out with a squeal and floats in the cup.
[cpg]

Once again, Master frowned. That's how strong the smell of semen is.
[cpg]

And not only that.
[cpg]


[VOICE f="Sayo0375"]
[OnName num="sayo"]
It's a very thick and tender cum... Even the color is yellow...
[cpg cn=true]


A week of hoarding had turned it into something yellow and blotchy instead of a white, slippery semen.
[cpg]

It was different from anything I had ever put out, and the master was surprised.
[cpg]


[OnName num="masato"]
Here you go.
[cpg cn=true]


[VOICE f="Sayo0376"]
[OnName num="sayo"]
Here...
[cpg cn=true]


[VOICE f="Sayo0377"]
[OnName num="sayo"]
I'll take it anyway...
[cpg cn=true]




[BG f="black.ui" time=1000]
;//ＢＫ


[SCENE id=7]
[ENDPARTIAL]


Master took a mouthful into his cup with a little bewilderment.
[cpg]


[STOPBGM]
[BG f="b_04_1.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（朝）******************************************************


[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0338"]
[OnName num="sayo"]
「んっ……こくっ、ゴクン…」
[cpg cn=true]


With a gurgle, it went down her throat...and the milk tea went into her stomach.
[cpg]

[BGM f="co"]
[FG f="CHA01_p4_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0378"]
[OnName num="sayo"]
------Fucking disgusting!!!!!
[cpg cn=true]


[SE f="se043"]
;//【ＳＥ】『紅茶をかける』パッシャーン


[OnName num="masato"]
"Ah-uh-uh! Sooooooooooooooooooooooooooo!
[cpg cn=true]


I guess it wasn't a good idea.
[cpg]

I thought I'd thought of her and offered her the best of both worlds, but...
[cpg]

[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0379"]
[OnName num="sayo"]
''Hah, hah...ugh.
[cpg cn=true]


[OnName num="maid_A"]
''Are you all right, missy!
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0380"]
[OnName num="sayo"]
Yeah... it's fine. Whew...
[cpg cn=true]


[STOPBGM]
[VOICE f="Sayo0381"]
[OnName num="sayo"]
"It's inexplicably bad... but maybe addictive...
[cpg cn=true]


[VOICE f="Sayo0382"]
[OnName num="sayo"]
I was wondering if it was a good time to...
[cpg cn=true]


[OnName num="masato"]
Master...!
[cpg cn=true]


The master seemed to like it a little, even though he said it was unpleasant.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ

--In the event that you are not able to do so, you will be able to get a better understanding of what you are doing.
[cpg]

[VOICE f="Sayo0383"]
[OnName num="sayo"]
'Tincus Milk Tea...TMT for short...do you think you can sell it?'
[cpg cn=true]


[OnName num="maid_A"]
I'm afraid you're only going to get complaints...
[cpg cn=true]


It's release is not going to come forever.
[cpg]


;//少し時間を置く演出
[BG f="b_07_1.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]
[BG f="black.ui" time=1000]
[WAIT time=1500]

;//少し時間を置く演出

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="ep008.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
