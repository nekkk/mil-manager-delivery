
*start



;#################################################
*Ep001|Turning Point
;#################################################

[SCENE id=1]


[stflag jump_scene=0]
;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


--a few days later
[cpg]


[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[STOPBGM]

[WAIT time=100]

[BGM f="d1"]
[WAIT time=100]
;//【ＢＧ】『分岐路のある道』（昼）******************************************************

;//※街の中心や住宅街（小夜宅がある方面。小夜宅は小高い丘の上にある）への分岐路がある道

[SE f=se006]
;//【ＳＥ】『走る』

[OnName num="masato"]
Huh, huh... this hill is surprisingly steep.
[cpg cn=true]


With my resume in hand and my heart pounding, I'm on my way to the designated interview location.
[cpg]

Dada dada dada. I run, out of breath.
[cpg]

I chose to walk to save money, but the place was farther away than I had expected... I was five minutes past the designated time.
[cpg]

My resume, which I had been clutching so as not to lose it, was crumpled and stained from sweat.
[cpg]

This is how I felt before the interview... I'm sure I'll fail again.
[cpg]

But the interview place was just a stone's throw away. I stood in front of the building in a gloomy mood, thinking that I should just take the test first.
[cpg]

[BG f="b_03_2_up.ui" time=1000]

;//レターボックスin
[FACE method="feadin" pos="4/7"]
[WAIT time=2000]


[SE f=se094]
;//【ＳＥ】『どどーん』

[OnName num="masato"]
I stood in front of the building in a gloomy mood, thinking, "What the hell is this house?
[cpg cn=true]


The interview place was a little further down the street in a residential area... on top of a small hill.
[cpg]

Towering in front of me was an extremely large mansion. Could this really be the place designated for the interview?
[cpg]


[SE f=se012]
;//【ＳＥ】『門が開く』ギギギ

[WAIT time=1000]


[OnName num="masato"]
Whoa!"
[cpg cn=true]


I wondered as I checked the documents in my hand over and over again, and the gate opened by itself.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』

[WAIT time=1500]

[OnName num="butler"]
"Welcome. My name is Tanaka, and I am the butler of this family.
[cpg cn=true]


Butler...? There really is a butler.
[cpg]

Indeed, the elderly man who came out from inside had the perfect appearance to be called a "butler".
[cpg]

He was neatly dressed and his gestures were clean. He was perfectly respectful and I felt that he was from a different world than mine.
[cpg]

[OnName num="masato"]
My name is Sakigawa. I'm here for an interview..."
[cpg cn=true]


[OnName num="butler"]
"Yes. This way, please.
[cpg cn=true]


It looks like I'm in the right place. Suddenly...I'm getting anxious.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』

;//ＢＫ
[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


;//レターボックスout
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_00_2.ui" time=1000]

[window target=true]

[WAIT time=1000]

[BGM f="sl"]
[WAIT time=1000]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[OnName num="masato"]
"Wow...this is amazing! It's a rich man's house...
[cpg cn=true]


The butler, Mr. Tanaka, showed me around the mansion and my mouth dropped open halfway.
[cpg]

It was a mansion that I could guess from the outside, but naturally the inside was also... extremely spacious and luxurious.
[cpg]

If I got the interview, I'd be working here... I was getting anxious again.
[cpg]

[OnName num="butler"]
"Please wait here."
[cpg cn=true]


[OnName num="masato"]
"Ha, yes!"
[cpg cn=true]



I wasn't even let through to any room, I was told to wait in the entrance hall.
[cpg]

[OnName num="masato"]
''(Are these all the people who came for the interview?)''
[cpg cn=true]


It's not just me, but a lot of people who probably came for an interview as well.
Nearly 20 men are lined up in a row in the hall... It's a strange sight...
[cpg]

[OnName num="butler"]
Miss, they're all here.
[cpg cn=true]


[VOICE f="Sayo0007"]
[OnName num="sayo"]
Yes.
[cpg cn=true]




[SE f="se005"]
;//【ＳＥ】『歩く』コツコツコツ


You'll be able to get the most out of it.
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

[stopse g=2]
;//通常se

;//●ＣＧ非エロ（小夜・ご主人様登場！：豪邸の広間）ev_01

;**【ＣＧ】ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo0008"]
[OnName num="sayo"]
There are so many of them this time.
[cpg cn=true]


[OnName num="masato"]
'...........................
[cpg cn=true]


We were greeted by a girl who looked like a young child.
[cpg]

It's beautiful, lovely, and graceful....
[cpg]

I forgot to say a word and gazed at her...maybe it was because she was so close to my "ideal".
[cpg]


[VOICE f="Sayo0009"]
[OnName num="sayo"]
"Are you guys the ones who want me to keep you?"
[cpg cn=true]


[OnName num="all_members"]
''H...?''
[cpg cn=true]


Great, the response was unanimous.
[cpg]

[OnName num="butler"]
"Miss.
[cpg cn=true]


[VOICE f="Sayo0010"]
[OnName num="sayo"]
I'm sorry. Now that was a joke. Couscous.
[cpg cn=true]


--She was the 'master' who was also mentioned in the recruitment letter....
[cpg]


[stopse g=2]
;//通常se

[stopse g=3]
;//通常se

[window target=false]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ


;//レターボックスin
[FACE method="in" pos="4/7"]
[WAIT time=1]

[BG f="b_00_2_up.ui" time=1000]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1000]

[WAIT time=1000]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[window target=true]



[OnName num="butler"]
Ladies and gentlemen, thank you very much for coming here today.
[cpg cn=true]


After the résumés were collected, we stood in single file in front of the stairs in the center of the hall as we were briefed.
[cpg]

Mr. Tanaka was explaining it to me, but I couldn't get the content of it into my head. It seems that others do too.
[cpg]

[OnName num="masato"]
''(Could it be that this person is the master?)''
[cpg cn=true]


I don't think it's possible...but from what I see in the words and actions and the way the butler handles it, I'm sure it is.
[cpg]

The job description said, "A job in service to the master. If I'm adopted, I'm sure I'll worship her as a master and serve her as a steward or something...
[cpg]

I was dumbfounded by an unlikely situation in my life.
[cpg]

[OnName num="man"]
Hey, what's going on!
[cpg cn=true]


Suddenly, a loud voice rang out, pulling me back to reality in a huff.
[cpg]

I couldn't grasp the situation because I hadn't heard any explanation because I had been watching her standing in the middle all this time.
[cpg]

[OnName num="butler"]
That's what I just said.
[cpg cn=true]


[OnName num="man"]
''What, because... a job to serve your husband...''
[cpg cn=true]


[OnName num="butler"]
Yes, I'm sure of it.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0011"]
[OnName num="sayo"]
I'm sorry, but it's a given.
[cpg cn=true]


The girl explains herself.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0012"]
[OnName num="sayo"]
We don't have enough employees. In the first place, you can't just hire a person with no experience or skill as a butler. You guys are just going to get in trouble for doing nothing either.
[cpg cn=true]


[OnName num="man"]
I mean, that's just...
[cpg cn=true]


I'm sure the people who came here, like me, were aware that a job in service is a butler or something like that.
[cpg]

When it comes to the fact that they have enough employees to talk to, and they're not hiring them as butlers... I'm more puzzled than angry.
[cpg]

[OnName num="glasses_man"]
Does this mean that you will hire me as a servant?
[cpg cn=true]


[OnName num="butler"]
That's not enough either.
[cpg cn=true]


This time they were all puzzled. If it's not even a job to be a servant and do cleaning and other chores, then what the hell was it called to be?
[cpg]

[OnName num="butler"]
''What we want is a playmate for the Lady. No, to put it more bluntly...
[cpg cn=true]


The butler was about to continue his words further, but she interrupted him.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0013"]
[OnName num="sayo"]
There's no point in taking too much time. I think it's about time we started interviewing.
[cpg cn=true]


And so, the explanation ended and the interview began.
[cpg]



[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ



;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=1]

[BG f="b_00_2.ui" time=1000]

[WAIT time=1000]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************


[OnName num="masato"]
What's a playmate?
[cpg cn=true]


With a feeling of trepidation, the interview began.
[cpg]

However, instead of being let into a separate room, Masato and the others stood in a line and were being stared at by the girls. It's like a scavenger hunt.
[cpg]

[OnName num="glasses_man"]
''Oh, um... isn't it better to do it one at a time or a few at a time...''
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0014"]
[OnName num="sayo"]
You're wasting your time doing that.
[cpg cn=true]


[OnName num="glasses_man"]
''But...but...''
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0015"]
[OnName num="sayo"]
Shut up.
[cpg cn=true]


One of the brave ones uttered a question, but nowhere was the gentle feeling that had been there before. In the end, he was silenced with intimidation.
[cpg]

What surprised me was that such a kid, and nearly 20 guys, were told to shut up by a girl and really shut up.
[cpg]

There may be an instinctive power that makes us feel that we should not go against the grain.
[cpg]

But it was even worse from there. When I say interview, it was already different from the norm, and it was outrageously demanding.
[cpg]

[STOPBGM]
[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0016"]
[OnName num="sayo"]
''Well, everyone take off your pants. And your underwear.
[cpg cn=true]


[OnName num="masato"]
Huh?
[cpg cn=true]

[SE f=se077]
;//【ＳＥ】『喧騒』

[BGM f="co"]
[OnName num="man"]
What the heck... why do I have to do that?
[cpg cn=true]


Of course, even if he was ordered to expose his privates in front of a woman without understanding the meaning, he would not act meekly. A few were puzzled and the rest protested.
[cpg]

[STOPBGM]
[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0017"]
[OnName num="sayo"]
It's annoying. Take it off.
[cpg cn=true]


But even that defiance was quelled with a single word. For some reason, they couldn't get away, and everyone there did as they were told.
[cpg]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

[BG f="b_00_2.ui" time=1000]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="5/5" time=1000]
[WAIT time=1500]


[BGM f="h1"]
[VOICE f="Sayo0018"]
[OnName num="sayo"]
Hmmm-hmm...heh. Hmmm...
[cpg cn=true]


They take their time to look at them from one end to the other, as if they were sifting through them.
[cpg]

I'm sure most of the men here never imagined that they would be molested by such a child.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』

[move from="5/5" to="4/5" ease="easeInOutSine" time=1500]
[WAIT time=1500]

[stopse g=2]
;//通常se

[FACE method="change_2" pos="4/5"]
[WAIT time=1500]


[VOICE f="Sayo0019"]
[OnName num="sayo"]
"You're so big. This one is smaller. Normal... normal. Kusu, the leather cover is cute.
[cpg cn=true]


It was already an act of being evaluated as a man itself.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』
[move from="4/5" to="3/5" ease="easeInOutSine" time=1500]
[WAIT time=1500]

[stopse g=2]
;//通常se

[FACE method="change_1" pos="3/5"]
[WAIT time=1500]


[VOICE f="Sayo0020"]
[OnName num="sayo"]
Well, well, well. What's wrong with you? They're getting bigger, though.
[cpg cn=true]


A few people have gotten so excited about this situation that they have erections.
[cpg]

;//レターボックスin
[FACE method="slidein" pos="4/7"]

[FO pos="3/5" time=1500]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1500]

[SE f=se005]
;//【ＳＥ】『歩く』

[WAIT time=2000]

She was actually enjoying herself as she scanned the lined up men. And finally, it was Masato's turn.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo0021"]
[OnName num="sayo"]
...who said it was okay to hide it?
[cpg cn=true]


[OnName num="masato"]
''Ugh...''
[cpg cn=true]


I covered my pubic area with my hands. The frog was glared at by a snake.
He had to do what he said, but he still stubbornly kept his hand out of his mouth.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0022"]
[OnName num="sayo"]
Didn't you hear me?
[cpg cn=true]


[OnName num="masato"]
''Ughhhhhh...''
[cpg cn=true]


But he couldn't resist forever... and finally let go.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo0023"]
[OnName num="sayo"]
'...! Oh, my God! Well, well...
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
She grinned at that, and now she knew why Masato had been hiding it all along.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0024"]
[OnName num="sayo"]
It's very pretty. Are you short...? And the skin covering. But I'm frantically squirming.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0025"]
[OnName num="sayo"]
''It's good that you're in good spirits. Is it possible that you are a pedophile?
[cpg cn=true]


[OnName num="masato"]
Wha...Wha...Wha...Wha...Wha.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0026"]
[OnName num="sayo"]
It's only some people like that who can get it up in this situation.
[cpg cn=true]


I can't believe she's able to see through the proclivities she's been desperately trying to hide in a single moment.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0027"]
[OnName num="sayo"]
And you're a virgin, aren't you?
[cpg cn=true]


This situation alone is so embarrassing that the fire comes out of the face, and it becomes even hotter when it is said so.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0028"]
[OnName num="sayo"]
"You're right. What, you're short... skinny... and a virgin at the same time? It's perfect in a way.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0029"]
[OnName num="sayo"]
Besides, even though it's big, it's small. I can't help it.
[cpg cn=true]


I know I've been told a lot, but even when I'm told harsh words, my product doesn't wilt, it just gets harder and harder.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0030"]
[OnName num="sayo"]
"And remember. I like meek girls better...
[cpg cn=true]


I don't want to go, I want to die, I want to go home. I rolled over and just thought about it.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]

;//レターボックスout
[FACE method="out" pos="4/7"]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=2000]


[BG f="b_00_2.ui" time=1000]

[WAIT time=1000]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[window target=true]


Finally, the first interview? seems to be over. And so, now.....
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0031"]
[OnName num="sayo"]
''You'll be missed, but it's a shame. Please leave.
[cpg cn=true]


[OnName num="man"]
Huh, wha... why...?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0032"]
[OnName num="sayo"]
I don't think you're up to the task.
[cpg cn=true]


And so came forth the one who was to be sent back. I guess it simply means that they were unsuccessful.
[cpg]

Everyone was unconvinced to be exposed to such molestation...but when they received a thick envelope, they left without complaining.
[cpg]

Incredibly, this was also the way it was first described.
[cpg]

(*The contract is signed first. Even if you don't make the cut, you get a decent amount of money to go home. (Instead, don't tell anyone about today.)
[cpg]

One by one, one by one, they walked out of the door they entered. In the end, there were only four of us left. I'm one of them.
[cpg]

Honestly, he didn't know what this kid was doing...but Masato also wondered that he hadn't been sent home.
[cpg]

If I had seen the reaction earlier, it would have been a failing grade and normal.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0033"]
[OnName num="sayo"]
You passed. I'm hiring you guys.
[cpg cn=true]


Turning to the four people who remained there, she said. Everyone was surprised at how unexpected it was.
[cpg]

However, all four of us have one thing in common. That is...all of them are men who, under the circumstances, have gotten a boner.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0034"]
[OnName num="sayo"]
We're all hired as of right now. But there's one condition for them to actually work for us.
[cpg cn=true]


[OnName num="glasses_man"]
Huh? Conditions?
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=800]

[WAIT time=1500]

[VOICE f="Sayo0035"]
[OnName num="sayo"]
It's like an exam. You are welcome to quit at any time if you don't want to. Regardless of the outcome, we'll have some level of reciprocity.
[cpg cn=true]


There were various oddities in what was collected, the reasons for it, and the content of the interview, but this is also something that cannot be considered normal. It's a bargain, I'd say.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0036"]
[OnName num="sayo"]
Now, who better to play with me than...?
[cpg cn=true]

[STOPBGM]
[VOICE f="Sayo0037"]
[OnName num="sayo"]
My... servant.
[cpg cn=true]


The words made everyone gasp. Servant...? It certainly sounded like it. Before we get into the current remarks, things are moving along in a flurry.
[cpg]

[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[SE f=se013]
;//【ＳＥ】『服を脱ぐ』シュルシュル
[WAIT time=1100]

;//レターボックスin
[FACE method="in" pos="4/7"]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_2_up.ui" time=1]

[window target=true]
[BGM f="h1"]

She's going to make them undress, just in case you can see them or not... all four of them gasped.
[cpg]

She pulls up her long skirt and shows her perky paws. He took off his shoes and went barefoot.
[cpg]

The exquisite state in which a woman is felt even at a young age, the appearance ... The foot exposed to their eyes is beautiful, the skin is slimy, and the care is well taken.
[cpg]

What in the world do you want them to do and what do you want them to do? What to do. There is no explanation.
[cpg]

However, with his invincible smile and his manners...Masato and the others who remained on the spot understood.
[cpg]

Give him a kiss on the foot.
[cpg]

That's not what I'm saying.
[cpg]

She prepared for the exercise by moving the toes of her right foot and turning her ankle like an athlete before the start.
[cpg]

Her feet are beautiful. But at the same time, it's tightening up.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0038"]
[OnName num="sayo"]
Well. Who is it from?
[cpg cn=true]


At her words, the first person to come forward was the spectacled figure on the other side of Masato.
[cpg]

[OnName num="glasses_man"]
I'll... please.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0039"]
[OnName num="sayo"]
"You're very motivated. I don't hate them, that's who they are.
[cpg cn=true]


A small, "Excuse me," he said, and with a natural movement of his glasses, he crawled on all fours.
[cpg]

Why in the world would I dress like that? Why are they doing that without hesitation, the three of them thought.
[cpg]

But I finally understood it too. Why did we leave ourselves here? Surely, the guy with the glasses in front of him is smart.
[cpg]

He realized it earlier than anyone else, and he was more...honest with himself than anyone else.
[cpg]

Because of his actions, the three who remained also understood who they were...and why they had been chosen.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0040"]
[OnName num="sayo"]
It's easier to do a little higher up.
[cpg cn=true]


[OnName num="glasses_man"]
''Ha, ha.''
[cpg cn=true]

The spectacled man squeaks his butt up in response to a request.
[cpg]


[FACE method="change_1" pos="2/3"]

And after a few beats, her right foot moved as if by surprise without any words such as "let's go" or "put some energy into it".
[cpg]


[SE f=se040]
;//【ＳＥ】『蹴り』

[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=500]
[WAIT time=800]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=500]
[WAIT time=1000]

！！！！！
[cpg]

It's a great way to get to know each other.
[cpg]

If you're a man, it's a horrible act that hurts just by looking at it.
[cpg]

[SE f=se062]
;//【ＳＥ】『倒れる』

[WAIT time=1000]

He, too, in his glasses, twitched and convulsed with the screams, his body trembled in small increments, and he fell unconscious.
[cpg]

It's a great way to get to know each other. They are probably going to take him to the hospital.
[cpg]

[OnName num="butler"]
You're welcome, sir.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0041"]
[OnName num="sayo"]
Of course, you'll pass... and when you wake up, give him a good workout. Again, if he wants to.
[cpg cn=true]


[OnName num="butler"]
I'm awed.
[cpg cn=true]


That exchange brought his final interview to an end. Next, it's the three of us. The Master looks at this.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0042"]
[OnName num="sayo"]
Now, who's next?
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="b_00_2.ui" time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]


;//レターボックスout
[FACE method="out" pos="4/7"]

[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1]
[window target=true]

[WAIT time=2000]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************


[VOICE f="Sayo0043"]
[OnName num="sayo"]
What about you?
[cpg cn=true]


[OnName num="masato"]
Uh, uh, I...
[cpg cn=true]


She asks Masato, now that she is the last one.
[cpg]

The other two saw the scene ahead and refused to take the exam and left. They seem to have adopted it as a form, and they've been given a reprieve.
[cpg]

I wonder if it's like a training or trial period. Masato, who became one of the rest, also had to be chosen.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0044"]
[OnName num="sayo"]
''If you don't want to, you should stop. I'm not sure I'm going to be able to use it anymore.
[cpg cn=true]


As she said that, she got ready.
[cpg]

Masato was also hesitant, as if he was convinced that Masato would not refuse.
[cpg]

That's no joke, I can't stand it when they do that to me... I know that. But he doesn't even try to run out the door.
[cpg]

Unlike the other two, Masato's little phallus was harder and towered higher, even though he was presented with a hideous sight.
[cpg]

I have an erection as if I'm going to come off my waist like this and fly away like a rocket.
[cpg]

My body is reacting like this, I already know. Masato was conflicted, but he couldn't admit it honestly.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0045"]
[OnName num="sayo"]
Now, what do we do?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0046"]
[OnName num="sayo"]
 Let's call it a day. Come back later, if you feel up to it.
[cpg cn=true]

[SE f=se005]
;//【ＳＥ】『歩く』
[FO pos="2/3" time=1000]
With that said, she turned on her heel. When he turned his back on me, I felt like he was telling me that he didn't want you anymore...
[cpg]

[OnName num="masato"]
Wait, wait, wait! Please...
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]


I spoke up on the spur of the moment.
[cpg]

[OnName num="masato"]
I'll take it... please.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0047"]
[OnName num="sayo"]
Shush, I understand.
[cpg cn=true]


I decided to take the exam.
[cpg]


[SE f=se078]
;//【ＳＥ】『衣擦れ』

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]

;//レターボックスin
[FACE method="in" pos="4/7"]

[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[WAIT time=1000]

[STOPBGM]
;//●ＣＧエロ（雅人＆小夜・金玉を蹴られる雅人。反撃の射精：豪邸の広間）ev_02
;//※立った状態で足を開いて腰を前に出して蹴りやすい体勢


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_2_up.ui" time=1]
[BGM f="h1"]

[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3000]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[window target=true]

[FACE method="change_7" pos="2/3"]

[VOICE f="Sayo0048"]
[OnName num="sayo"]
Are you sure you're okay with that?
[cpg cn=true]


[OnName num="masato"]
Ha, yes... before, please.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[VOICE f="Sayo0049"]
[OnName num="sayo"]
"Huh...you're changing. That's fine, that kind of thing.
[cpg cn=true]


Masato was on his back, not on all fours, with his arms and legs on his back and his hips floating. This body position is certainly easier to kick, too.
[cpg]

[SE f=se033 loop=true]
;//【ＳＥ】『心音』

[OnName num="masato"]
''Ha, ha...''
[cpg cn=true]


From extreme tension and fear, my breathing becomes labored.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo0050"]
[OnName num="sayo"]
You don't have to be so nervous.
[cpg cn=true]


[OnName num="masato"]
Huh?
[cpg cn=true]


[VOICE f="Sayo0051"]
[OnName num="sayo"]
''You love it, this kind of thing. You want this, don't you?
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_1"  pos="2/3" time=800]
Sayo smiles and tells the other person what to expect.
[cpg]

Masato clenched his teeth as his face flushed and he didn't answer. In my head, I desperately deny it.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0052"]
[OnName num="sayo"]
"...stubborn. I told you I liked meek girls...
[cpg cn=true]


The strength in her eyes and feet.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0053"]
[OnName num="sayo"]
Well... it's nice to have to deal with guys like you.
[cpg cn=true]

[stopse g=6]
;//通常se

[STOPBGM]

[SE f=se030]
;//【ＳＥ】『風切音』
[FO pos="2/3" time=800]
[BG f="black.ui" time=800]
[WAIT time=800]

His right foot swings out at the same time as his words. Fastest and strongest of the day. The testicles would be crushed by this.
[cpg]

At that moment, Masato thought in fear and unusual excitement.
[cpg]

No, no, no, no, I'm not the kind of person who would take pleasure in something like this, it's not, it can't be. Absolutely not.
[cpg]

I just didn't want to run away. Besides, I didn't want to end up being made a fool of.
[cpg]

Yes, this is my little counterattack.
[cpg]

[SE f=se001]
;//【ＳＥ】『轟音』ドゴンッ


[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=500]


;//レターボックスout
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]
[WAIT time=1500]

[WAIT time=1100]
[BG f="white.ui" time=1]

[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]
[WAIT time=1000]

[SE f=se097]
;//【ＳＥ】『射精』

;**【ＣＧ】ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]

[window target=true]


！！！！！
[cpg]


[VOICE f="Sayo0054"]
[OnName num="sayo"]
"Ack!
[cpg cn=true]


After receiving a strong golden kick...or rather, a golden ball crushing, Masato, like the previous person, screamed, his body convulsed, his eyes blurred and he lost consciousness.
[cpg]

But one thing was different...despite being kicked in the nuts, Masato was ejaculating in a big way.
[cpg]

She was kicked in the balls, and at the same time, a burbling, sticky mass of semen hit her.
[cpg]

The momentum was so strong that it flew not only to her feet, but also to her body and face. Sayo lets out a small scream at the unexpected situation of her body being defiled.
[cpg]

[SE f=se062]
;//【ＳＥ】『倒れる』

[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

[BG f="b_00_2.ui" time=1000]

[WAIT time=1000]


[BGM f="h1"]
[WAIT time=100]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************


[OnName num="butler"]
''Hey, young lady! Are you all right!
[cpg cn=true]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="Sayo0055"]
[OnName num="sayo"]
Yeah, I'm fine. Tanaka-san.
[cpg cn=true]


I answered as I took the handkerchief offered to me and wiped the cum off my face.
[cpg]

Sayo and the butler look at Masato, who looks like a frog that was hit by a car.
[cpg]

[OnName num="butler"]
He's... you're welcome.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[VOICE f="Sayo0056"]
[OnName num="sayo"]
''Of course, you passed... this is my employment. When he wakes up, teach him a lot of things. Don't let them get away with it when they say no.
[cpg cn=true]


[OnName num="butler"]
Ha. I was in awe.
[cpg cn=true]

[SE f=se005]
;//【ＳＥ】『歩く』
[move from="2/3" to="5/3" ease="easeInOutSine" time=2000]

Sayo says that much and heads upstairs. Looks like he's going to take a shower or something.
[cpg]

He stops in the middle of the stairs and looks in Masato's direction again.
[cpg]

[FG f="CHA01_p2_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0057"]
[OnName num="sayo"]
I guess I won't be bored.
[cpg cn=true]


The master was somehow amused.
[cpg]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[FO pos="2/3" time=2000]
[BG f="black.ui" time=2000]
[WAIT time=2500]
;//ＢＫ

[jump storage="ep002.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
