*start


;//ドM向けロリものシナリオ『絶対君主！小夜様！』

;//[stflag f.first_select = 0]
;//[stflag f.second_select = 0]

;//【プロローグ】


;#################################################
*Ep000|There's no such thing as bad men, Even if they are pedophiles.
;#################################################

[stflag jump_scene=0]
[stflag gohome_flag=0]
[stflag service_flag=0]
[stflag hiyokurenri_flag=0]
[stflag existence_flag=0]
[stflag pets_flag=0]


;//※※※お願い※※※ト書き文章でブロック毎に分けてあるものは、一回のメッセージ表示で全て表示して欲しいものです
;//出来れば改行もそのままでお願いします

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


[BG f="black.ui" time=1000]
[BGM f="h1"]
[WAIT time=1000]
;//ＢＫ


;//ここではまだ小夜の名前は『？？？』でお願いします


;//クスクスの後、次の言葉の間にウェイトを入れて下さい
;//少しキャラからズレても良いので『臭っさぁい♪』の部分は思いっきり蔑みながら、でも楽しんでいる感じでお願いします可愛さも


[BGM f="h1"]
[VOICE f="Sayo0001"]
[OnName num="unknown"]
"....................................................
[cpg cn=true]

[WAIT time=600]

Looking down at the steaming, stinking penis she'd removed from her sweaty underwear... she laughed in amusement.
[cpg]


A smelly penis like this might be a demerit.
I worry about that kind of thing even though it's an abomination.
[cpg]

*Scene01|There are no bad M-men. Even if they are pedophiles.

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="h1"]

;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[BG f="b_00_2_up.ui" time=1000]

;//レターボックスin
[FACE method="slidein" pos="4/7"]
[WAIT time=1500]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]


It was a few dozen minutes ago. Not wanting to be late, I aimed for this mansion and broke out in sweat from running uphill.
[cpg]

There was no way I could take a shower before the interview, and the thing became sweaty in my underwear as it was.
[cpg]

She laughs at my penis like that.
[cpg]


[VOICE f="Sayo0002"]
[OnName num="sayo"]
''It's a delicate area, so you have to pay attention to it. Always clean..... Please be careful after that.
[cpg cn=true]


[OnName num="masato"]
H...ha, yes. I'm sorry...
[cpg cn=true]




A little girl is in front of me.
[cpg]

Low stature, large eyes, soft cheeks that seem to be slightly reddish, straight hair that is smooth... All are lovely, girl.
[cpg]

Her simple clothes, combined with the right amount of skin exposure, make her even more attractive.
[cpg]


;//『ルビ：娘（こ）』
The girl I may end up calling 'Master' and serving.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0003"]
[OnName num="sayo"]
''Totally... what kind of recruiting statement did you put out? Tanaka-san.
[cpg cn=true]


[OnName num="butler"]
"I've written with a sense of timing, my lady.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo0004"]
[OnName num="sayo"]
You should have been straighter. There are a lot of people out there who will come to you with a misunderstanding...
[cpg cn=true]



;//[FO pos="2/3" time=1000]
;//[BG f="black" time=1000]
;//ＢＫ




;//☆ＣＧエロ（雅人＆小夜・金玉を蹴られる雅人反撃の射精：豪邸の広間）ev_02
;//※立った状態で足を開いて腰を前に出して蹴りやすい体勢
;//このCGは後でまた出てきますまだ蹴られる前


[OnName num="masato"]
Huh...huh...huh...huh! Ha, ha...!
[cpg cn=true]




In front of her, I expose my molestation, and I'm afraid of the sure pain that will come.
[cpg]

The big man was shaking miserably...on the verge of tears.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』

[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/3" time=1000]
[VOICE f="Sayo0005"]
[OnName num="sayo"]
Are you ready for this?
[cpg cn=true]

[SE f=se033 loop=true]
;//【ＳＥ】『心音』

[OnName num="masato"]
 Ha, ha...!
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo0006"]
[OnName num="sayo"]
Chuckle. Well, it doesn't matter either way...
[cpg cn=true]



Either he took no answer as a yes, or he sensed that he didn't even have time to answer.
[cpg]

She braced herself before hearing the answer here.
[cpg]

And then the slippery legs move like a bow.
[cpg]


[OnName num="masato"]
'.................................................!
[cpg cn=true]


[stopse g=2]
;//通常se

[stopse g=6]
;//通常se

No hesitation, not even the slightest hint.
[cpg]

She threw up her right leg and...
[cpg]



[SE f=se030]
;//【ＳＥ】『風切音』
[FO pos="2/3" time=800]
[BG f="black.ui" time=800]
[WAIT time=800]

[WAIT time=1000]


;//画面揺れる演出

[SE f="se001"]
;//【ＳＥ】『轟音』ドゴンッ
;//※金玉を蹴っているので、石を砕いたりとか、あまり物理的な音は合わないので止めて下さい


[STOPBGM]


[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=500]


;//レターボックスout
[FACE method="slideout" pos="4/7"]
[WAIT time=500]

[WAIT time=1100]
[BG f="white.ui" time=1]

[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]
[WAIT time=1]


[window target=true]
[WAIT time=500]

;**【ＣＧ】ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************

[WAIT time=2000]


[BG f="black.ui" time=1000]
[WAIT time=2000]


I was in so much pain that my consciousness was cut off at that moment.
[cpg]

How in the world did this happen?
[cpg]

In my fading consciousness, such a question came to me like a running lantern.....
[cpg]

[SCENE id=0]
[ENDPARTIAL]

;//少し時間を置いて

;//ＢＫ

[SE f="se002"]
;//【ＳＥ】『時計の音』カチコチカチコチ


--A few days ago--
[cpg]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[STOPBGM]

[WAIT time=100]

[stopse g=2]
;//通常se

[BGM f="d1"]
[WAIT time=100]
;//【ＢＧ】『分岐路のある道』（昼）******************************************************



[SE f=se003]
;//【ＳＥ】『品出し音』

[WAIT time=1500]


[OnName num="masato"]
'........what? Manager, what did you just say...
[cpg cn=true]


[OnName num="manager"]
''Yeah...I'm really sorry, but... Can you get the contract done by the end of this month?
[cpg cn=true]

[SE f=se014]
;//【ＳＥ】『衝撃』

The manager, who had been so kind to me both at work and in private, released words that made me want to cover my ears.
[cpg]

I hope I'm wrong. I can't help but hope so.
[cpg]

[OnName num="masato"]
''What, why are you...? Oh, please! I'll do my best! So...
[cpg cn=true]


[OnName num="manager"]
I know you're a serious and good person, too.
[cpg cn=true]


[OnName num="masato"]
Then...
[cpg cn=true]


[OnName num="manager"]
''But even after six months, the failures have hardly diminished. We've been spending a lot of money on things, like breaking things... and we're in trouble.
[cpg cn=true]


[OnName num="manager"]
It's not like I'm making that much money to begin with. So, I'm really sorry...
[cpg cn=true]


[OnName num="masato"]
 I understand...
[cpg cn=true]


How many times have I heard these words or said these words?
[cpg]

[OnName num="masato"]
Thank you very much for your help.
[cpg cn=true]


[OnName num="manager"]
''Yeah...thanks for the work.''
[cpg cn=true]




[STOPBGM]
[window target=false]


[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ


[BG f="b_03_3.ui" time=1000]
[WAIT time=1000]
[window target=true]

[WAIT time=100]

[BGM f="se"]
[WAIT time=100]
;//【ＢＧ】『分岐路のある道』（夕方）******************************************************


[SE f=se005]
;//【ＳＥ】『歩く』


[OnName num="masato"]
Sigh... what about the next job?
[cpg cn=true]




It's not that I don't want to work... You have to work in order to live in society, I know that.
[cpg]

We think we're trying our hardest, but we keep failing. And it's not uncommon to get fired for it.
[cpg]

If you keep doing that...you will feel that no workplace is the right fit for you.
[cpg]

Maybe it's just an excuse....
[cpg]


[OnName num="masato"]
''Hahhhhhhhhhh........
[cpg cn=true]


I don't want to go home dragging my depressed mood with me.
[cpg]

Perhaps because of this strong feeling, my feet naturally turned to the center of the city instead of going home.
[cpg]


[SE f="se005"]
;//【ＳＥ】『歩く』

[WAIT time=2000]


[SE f="se004"]
;//【ＳＥ】『喧騒』ガヤガヤ


I didn't go to university for family reasons, but got a job.
[cpg]

It's been more than a year since I started working this way...and I still can't fit into the life of working as a working adult.
[cpg]

Since it was an employment ice age, he couldn't find a fixed job and worked part-time to earn his living expenses.
[cpg]

I do have a desire to get a job in some kind of regular employment. But you have to make it last longer than that... even if it's a part-time job.
[cpg]


You look in information magazines, write a resume, get an interview...and you fall.
[cpg]

I'm tired of living a life of being fired after a few months to six months of being accepted.
[cpg]

It would be different if I could just find the right job for me. It's a so-called vocation, but I wonder if there really is such a thing.
[cpg]

What is a vocation?
[cpg]


[SE f="se004"]
;//【ＳＥ】『喧騒』ガヤガヤ


;//☆ここ必要か？

[BG f="b_03_3_up.ui" time=1000]

;//レターボックスin
[FACE method="slidein" pos="4/7"]
[WAIT time=1500]

[OnName num="girls_mother"]
What do you want for dinner today?
[cpg cn=true]


[OnName num="little_girl"]
''Err...umm...hamburger!
[cpg cn=true]


[OnName num="girls_mother"]
"Again? You really like hamburgers.
[cpg cn=true]


[OnName num="little_girl"]
Yeah! Next to my dad and mom, I like hamburgers.
[cpg cn=true]


[OnName num="girls_mother"]
I don't know what to do now. Then let's have a hamburger.
[cpg cn=true]


[OnName num="little_girl"]
Yay! Hamburger! Hamburger WAY!
[cpg cn=true]




[SE f="se006"]
;//【ＳＥ】『走る』


[OnName num="girls_mother"]
Come on, don't get carried away...
[cpg cn=true]




[SE f="se007"]
;//【ＳＥ】『転ぶ』ドタッ


[OnName num="little_girl"]
Aww.
[cpg cn=true]


A little girl falls down in front of you! No, we've got to help her!
[cpg]

[SE f=se006]
;//【ＳＥ】『駆け寄る』


[OnName num="masato"]
Are you okay?
[cpg cn=true]


I immediately ran over and helped the kid up after she fell down.
[cpg]

[OnName num="little_girl"]
''Ugh...my knees hurt.
[cpg cn=true]


[OnName num="girls_mother"]
''Oh, I'm sorry about our girl!''
[cpg cn=true]


[OnName num="masato"]
No, nothing. I didn't do anything... oh, yes, I have a bandage, if you like.
[cpg cn=true]


[OnName num="girls_mother"]
Thank you very much. Come on, say thank you to the man.
[cpg cn=true]


[OnName num="little_girl"]
Oh, thank you.
[cpg cn=true]


[OnName num="masato"]
"Well, I'll just have to...
[cpg cn=true]


[OnName num="little_girl"]
"Bye, bye.
[cpg cn=true]


[SE f=se005]
;//【ＳＥ】『歩く』

[BG f="black.ui" time=1000]
[WAIT time=1000]

;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=1]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]

Hah, kids are good...soothing. I get excited when I see a cute girl.
[cpg]

Personally, I prefer it when they're more mature... but that doesn't matter. Dangerous remarks get the finger pointed at you for being a reserve criminal.
[cpg]


I wish I had a daughter, too.
[cpg]

If it was for a pretty girl like her, I'd be able to work hard...
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

;//＠
[BG f="b_03_3.ui" time=1000]
[WAIT time=1000]


;//背景切り替え演出をして、また街を表示。場所を移動した感じの演出



[SE f="se009"]
;//【ＳＥ】『入店音』ピンポローン

[BG f="b_03_3_up.ui" time=1000]

;//レターボックスin
[FACE method="feadin" pos="4/7"]
[WAIT time=1500]

;//書店


[OnName num="staff"]
There you go.
[cpg cn=true]




[SE f="se005"]
;//【ＳＥ】『歩く』


Huh, cool. It's tempting to just stay here, but I shake it off. I didn't come here to cool off.
[cpg]

[OnName num="masato"]
(I'd like a part-time job, a little more stable...!)
[cpg cn=true]


With this in mind, I looked at a part-time job information magazine as usual.
[cpg]

[SE f=se076]
;//【ＳＥ】ページめくる

[WAIT time=2000]

[SE f=se076]
;//【ＳＥ】ページめくる

[WAIT time=2000]

[OnName num="masato"]
Hmm? I don't know, this...
[cpg cn=true]


Then, there was a job offer that I had never seen before.
[cpg]


"We are here to serve our masters.
[cpg]


[OnName num="masato"]
Ha...?
[cpg cn=true]


What the hell does this mean? I don't know if that means he's a butler or something.
[cpg]

Obviously, the context is unexplained.
[cpg]

There's no "beginner's welcome" or "we're a homely workplace" that would make you feel at ease or motivated.
[cpg]

It's like, "What the hell? I've never seen such a recruitment letter, even though I'm an albiter.
[cpg]

[OnName num="masato"]
Oh, that's weird. It's too fishy...
[cpg cn=true]


It's suspicious no matter how you look at it. A lot of people are wondering, and I'm sure they won't be recruiting. It's 100% suspicious.
[cpg]

[OnName num="masato"]
'..............
[cpg cn=true]


But...I was curious about that recruitment letter.
[cpg]

I think 'serving' the 'master' is such an attractive word that I can't move my eyes to other items.
[cpg]

There was something about it that appealed to me, I even felt like it.
[cpg]

[OnName num="masato"]
All right.
[cpg cn=true]




[SE f="se010"]
;//【ＳＥ】『電話を掛ける』ピポパポ、プルルルル


I was attracted by the letters that did not require any academic or work experience... I was tempted to make a phone call.
[cpg]


;//レターボックスout
[FACE method="out" pos="4/7"]

[WAIT time=1000]
[STOPBGM]

[transition target={true} rule="moya.webp" color={0x000000ff} time=2000]
[WAIT time=2000]
[BG f="black.ui" time=1]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]



[window target=true]


[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="ep001.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
