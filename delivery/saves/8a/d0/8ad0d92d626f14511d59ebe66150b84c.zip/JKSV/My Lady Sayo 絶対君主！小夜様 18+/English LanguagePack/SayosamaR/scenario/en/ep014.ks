*start

;#################################################
*Ep014|Blood, Urine, Semen & M
;#################################################

[SCENE id=14]


[stflag jump_scene=0]
[window target=false]

[STOPBGM]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep002で発生	ジャンプしてきた場合奉仕ルートで固定
[stflag gohome_flag=1]
[stflag pets_flag=0]
[endif]



[BG f="black.ui" time=1000]
[WAIT time=1000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]

[SE f=se005]
;//【ＳＥ】『歩く』

[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

[BGM f="se"]
;//【ＢＧ】『豪邸、廊下』（夜）******************************************************


[window target=true]

[stopse g=2]
;//通常se

[OnName num="masato"]
Hmm... the light...
[cpg cn=true]


On my way back to my room after my walk, I noticed a faint light leaking out of the master's room I was passing by...
[cpg]

The clock pointed to the hour of midnight. Normally, he would have gone to bed long ago.
[cpg]

[OnName num="masato"]
No way...
[cpg cn=true]


I stood in front of the door, thinking about knocking... I kept my hand on the doorknob.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ





[SE f="se016"]
;//【ＳＥ】『扉を静かに開ける』カチャ、キィー…

[WAIT time=600]


[STOPBGM]
[BGM f="se" time=1000]
[BG f="b_04_4.ui" time=1000]
;//【ＢＧ】『豪邸、廊下』（夜）******************************************************


When he entered the room, a small light that had been placed on the side of the window was on.
[cpg]

[OnName num="masato"]
........."
[cpg cn=true]


And the chair beside it swayed slowly and slightly.
[cpg]

I opened my mouth to speak, but even faster than that.

[VOICE f="Sayo0884"]
[OnName num="sayo"]
Who is it?
[cpg cn=true]


The master spoke up.
[cpg]

[OnName num="masato"]
I'm sorry it's so late. It's me, master.
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0885"]
[OnName num="sayo"]
...at least knock.
[cpg cn=true]


[OnName num="masato"]
I'm sorry."
[cpg cn=true]


She didn't stand up, didn't look at me, but stayed in the same position and scolded me.
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0886"]
[OnName num="sayo"]
How dare you enter my master's room this late at night... what do you want?
[cpg cn=true]


[OnName num="masato"]
The... lights, as I saw them.
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0887"]
[OnName num="sayo"]
Oh, I see. I thought you were here to crawl at night.
[cpg cn=true]


[OnName num="masato"]
「……」
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0888"]
[OnName num="sayo"]
Say something.
[cpg cn=true]


[OnName num="masato"]
"Master, it's late at night and you need to get some rest..."
[cpg cn=true]


[VOICE f="Sayo0889"]
[OnName num="sayo"]
"Ha. I can't even bring myself to get mad at you for your continued rudeness..."
[cpg cn=true]


[OnName num="masato"]
Excuse me.
[cpg cn=true]

The master is sitting on a chair and refuses to go to sleep even though it is late at night.
[cpg]


[OnName num="masato"]
If I don't get some sleep, I'm going to be sick.
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0890"]
[OnName num="sayo"]
...I can't sleep.
[cpg cn=true]


[OnName num="masato"]
Can I get you something to help you fall asleep? How about some hot milk?
[cpg cn=true]


[VOICE f="Sayo0891"]
[OnName num="sayo"]
I don't want to go to sleep.
[cpg cn=true]


[OnName num="masato"]
However, I have school tomorrow as well, and thinking about my health...
[cpg cn=true]


[SE f="se059"]
;//【ＳＥ】『立ち上がる』ガタン


[FG f="CHA01_p3_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0892"]
[OnName num="sayo"]
I told you I don't want to go to sleep!
[cpg cn=true]



[SE f="se052"]
;//【ＳＥ】『物を投げる』ガチャン


[OnName num="masato"]
"......"
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0893"]
[OnName num="sayo"]
"What are you... what is that? You're acting like a servant. That's not why I'm leaving you!"
[cpg cn=true]


[VOICE f="Sayo0894"]
[OnName num="sayo"]
"It was still better to say you came to crawl at night! Stop this pointless meddling!"
[cpg cn=true]


[OnName num="masato"]
"Meddling...?"
[cpg cn=true]

The master was there, bare of his emotions, which he had never shown before.
[cpg]


[OnName num="masato"]
"What Mr. Tanaka and the others are doing... is meaningless meddling?"
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0895"]
[OnName num="sayo"]
"Hmmm..."
[cpg cn=true]

When she said that, she pushed off and sat back in her chair.
[cpg]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0896"]
[OnName num="sayo"]
"...I'm sorry, I'm a little... distraught."
[cpg cn=true]


[OnName num="masato"]
No, I'm sorry that I'm a... poor servant.
[cpg cn=true]

They pushed each other for a moment, then she opened her mouth.
[cpg]


[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0897"]
[OnName num="sayo"]
"I don't want to... I don't want to sleep. I'm scared...
[cpg cn=true]

It was a frank expression of feeling.
[cpg]


[VOICE f="Sayo0898"]
[OnName num="sayo"]
When you fall asleep, time flies by. While you're sleeping...more and more and more...a few sleeps and the week goes by in a blink of an eye.
[cpg cn=true]

After all, it's the marriage that's irritating her.
[cpg]

Marriage is a matter of the near future, and as it gets closer and closer... the master is in a state of blue.
[cpg]


[FG f="CHA01_p1_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0899"]
[OnName num="sayo"]
"I don't want to go to that guy... I'm not going to let him tame me, I'm not going to let him tame me.
[cpg cn=true]


[OnName num="masato"]
Why don't you come and talk to the master?
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0900"]
[OnName num="sayo"]
"You can't say that...
[cpg cn=true]

The voice he squeezed out had no trace of his usual bravado or strength.
[cpg]


[VOICE f="Sayo0901"]
[OnName num="sayo"]
"That guy... he's a pervert by the looks of it. I haven't heard any good things about him and I'm sure if I married him, he'd beat me to a pulp.
[cpg cn=true]


[OnName num="masato"]
"……"
[cpg cn=true]

If I were in the same position... it would be unbearable to think about it.
[cpg]

I don't want you to send the master to such a place.
[cpg]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0902"]
[OnName num="sayo"]
"Humph. I've been following you as a servant and keeping you as a pet all this time, so that's not something I can say..."
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0903"]
[OnName num="sayo"]
What I've done is unforgivable. You're going to get the same thing... I guess I deserved it...
[cpg cn=true]

I don't know how hard it is. However, I'm a bit against the current thing.
[cpg]


[OnName num="masato"]
Well, who's not allowed to...?
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0904"]
[OnName num="sayo"]
"That's up to me."
[cpg cn=true]


[OnName num="masato"]
"That's ridiculous. I wanted to, and I became the master's servant. Yes, it's a perverted thing... and I'm happy to be bullied."
[cpg]

"What's wrong with that? What's wrong with something that's consensual and aligned with our interests before we allow it and don't allow it...?"
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo0905"]
[OnName num="sayo"]
"Well, that's..."
[cpg cn=true]


[OnName num="masato"]
"That's just what I thought from the master's conscience. However, this is an answer that shows contempt for the person you care about most. As far as I'm concerned, it's very disturbing."
[cpg cn=true]


[VOICE f="Sayo0906"]
[OnName num="sayo"]
"You're out of your mind..."
[cpg cn=true]


[OnName num="masato"]
"S and M are exactly the same as masters and servants. It doesn't work on either one alone. And it's also a mistake for one or the other to feel guilty."
[cpg]

"In that case, both are bad. Both good and bad... it's mutual, S and M, master and servant."
[cpg cn=true]


[OnName num="masato"]
Then neither of them is good. Both are good, both are bad... that is mutuality, that is one and the same, S and M, master and servant."
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0907"]
[OnName num="sayo"]
"It's my fault..."
[cpg cn=true]


[OnName num="masato"]
Do I make myself clear?
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0908"]
[OnName num="sayo"]
Yeah, I hate it. Seriously, perverts are hard to deal with.
[cpg cn=true]


[OnName num="masato"]
Well, he's a pervert...
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0909"]
[OnName num="sayo"]
Somehow I feel like a fool for worrying about it now.
[cpg cn=true]


[OnName num="masato"]
I think it's good to worry and think.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0910"]
[OnName num="sayo"]
"Listening to you talk about it all the time is driving me crazy!
[cpg cn=true]




[SE f="se040"]
;//【ＳＥ】『蹴る』バキッ


[OnName num="masato"]
It's clear!
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0911"]
[OnName num="sayo"]
"Not at all..."
[cpg cn=true]

His expression brightened just a little, even though he was angry.
Yes, I (the pervert) will cheer up and support the master in my own way (the pervert).
Once that's decided, there's only one thing to do...
[cpg]


[OnName num="masato"]
"Um, Master?"
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0912"]
[OnName num="sayo"]
"What?"
[cpg cn=true]


[OnName num="masato"]
"If you're having trouble sleeping... you might want to get some exercise, if you don't mind."
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0913"]
[OnName num="sayo"]
"Exercise? At this hour of the day?"
[cpg cn=true]


[OnName num="masato"]
"Yes! It's a great stress reliever, and I think if you exercise and your body gets tired... you'll have a good night's rest."
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0914"]
[OnName num="sayo"]
"Well, that's true, but..."
[cpg cn=true]


[OnName num="masato"]
"It's an exercise that you can do indoors, and I don't know."
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0915"]
[OnName num="sayo"]
"...okay. You can't sleep anyway, so I'll keep you company."
[cpg cn=true]


[OnName num="masato"]
Thank you.
[cpg cn=true]


[VOICE f="Sayo0916"]
[OnName num="sayo"]
"So, what do you do?"
[cpg cn=true]


[OnName num="masato"]
"Yes, it is..."
[cpg cn=true]

I stripped down to my pants with a flourish and became a full-blown man.
[cpg]


[FG f="CHA01_p1_03_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0917"]
[OnName num="sayo"]
"What?"
[cpg cn=true]


[OnName num="masato"]
"Master..."
[cpg cn=true]


[VOICE f="Sayo0918"]
[OnName num="sayo"]
"Wha... Wha... Wha...? Idiot! Why are you taking it off all of a sudden?! The heat has gotten to you!"
[cpg cn=true]


[OnName num="masato"]
"Why are you so embarrassed? I'm sure you've seen a lot of my cock..."
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0919"]
[OnName num="sayo"]
"Know your TPOs! I don't think I have the slightest idea what it's like to have a dick in the current climate, you idiot! Put it away now, eh!"
[cpg cn=true]

The master's reaction is very cute, which has never been seen before. I never thought you would blush at the sight of my manhood.
[cpg]

Usually it's, "This short little paraplegic virgin cock of yours! I'm looking down at you like, "Oh, my God.
[cpg]


[FG f="CHA01_p1_03_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0920"]
[OnName num="sayo"]
Aww! Hey, get back here! Don't come here!
[cpg cn=true]


[OnName num="masato"]
"Um, master. It's different."
[cpg cn=true]


[VOICE f="Sayo0921"]
[OnName num="sayo"]
"What is it? What's the difference between what and what? Don't tell me it's really a night crawl..."
[cpg cn=true]


[OnName num="masato"]
"No... no, it's not that... it's that they use my cock... for exercise."
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0922"]
[OnName num="sayo"]
"I knew it!"
[cpg cn=true]


[OnName num="masato"]
Yes. I'll do cock boxing for you.
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0923"]
[OnName num="sayo"]
"Huh?"
[cpg cn=true]

The master who was an embarrassed maiden pose until just a moment ago has become an eye that looks like a pussy.
[cpg]

Well, that's funny.
[cpg]

This place is called "What is penis boxing? It's a scene that makes me say "beep".
[cpg]


[VOICE f="Sayo0924"]
[OnName num="sayo"]
"...three lines, please."
[cpg cn=true]


[OnName num="masato"]
"Let's see..."
[cpg cn=true]


[OnName num="masato"]
"Master."
[cpg cn=true]


[OnName num="masato"]
"tinkle"
[cpg cn=true]


[OnName num="masato"]
"Punch! Punch!"
[cpg cn=true]


[OnName num="masato"]
"That's right!"
[cpg cn=true]


[FO pos="2/3" time=1000]

[SE f="se071"]
;//【ＳＥ】『超ビンタ』ずっぱぁあぁぁん！


[OnName num="masato"]
"Heh!"
[cpg cn=true]




[SE f="se007"]
;//【ＳＥ】『倒れる』ドタン


[FG f="CHA01_p3_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0925"]
[OnName num="sayo"]
"Fuuuuuuuuuuuuuuuuuuuu........"
[cpg cn=true]

He acted as if he were a martial artist and released an intense bite. Come to think of it, Master used to learn self-defense as well.
[cpg]


[OnName num="masato"]
"Ouch! My neck... what are you doing?"
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0926"]
[OnName num="sayo"]
"That's what I'm talking about. Somehow, it destroyed all the flow and flags and everything that had been going on so far, and this ultra-hyped idiot pervert...!"
[cpg cn=true]

I don't know why I'm so angry!
[cpg]


[OnName num="masato"]
I'm sorry, I'm sorry, I'm sorry, I'm sorry! I just wanted to play with my master!
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0927"]
[OnName num="sayo"]
"I'm sure there are other things to play with."
[cpg cn=true]


[OnName num="masato"]
"Well, that's true...but...if master and I are going to play, this is the one... Ahahahaha!"
[cpg cn=true]


[OnName num="masato"]
"Master, please hit my cock! Oh, you can also do kicking and strangling techniques in the setting of a mixed martial arts fight!"
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0928"]
[OnName num="sayo"]
(.......what, that innocent smile. You're like a child... even though what you're saying is perverted).
[cpg cn=true]


[OnName num="masato"]
"Well then, Master. I'll keep you company until you can sleep, or even in the morning."
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0929"]
[OnName num="sayo"]
"I didn't know you well enough to know that."
[cpg cn=true]

Phew, she sighed.
[cpg]


[FG f="CHA01_p3_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0930"]
[OnName num="sayo"]
"You're... really, really, really a true, genuine pervert... right!"
[cpg cn=true]



[SE f="se040"]
;//【ＳＥ】『蹴り』ドカッ


[OnName num="masato"]
"Ugh!"
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0931"]
[OnName num="sayo"]
"Mm-hmm, you caught me off guard."
[cpg cn=true]


He leans forward at the sudden attack. I'm terrified of your eyes, Master.
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0932"]
[OnName num="sayo"]
The perverts don't need to be shy or merciful. That's kind of rude...Sayo, I remember.
[cpg cn=true]


I didn't go that far, though...
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0933"]
[OnName num="sayo"]
So... let's get on with it, shall we?
[cpg cn=true]


[OnName num="masato"]
''Oh, wait...wait. There's one more thing we need to talk about.
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0934"]
[OnName num="sayo"]
What?
[cpg cn=true]


[OnName num="masato"]
"Master, would you like to make a bet?"
[cpg cn=true]


[VOICE f="Sayo0935"]
[OnName num="sayo"]
'Betting...?'
[cpg cn=true]


[OnName num="masato"]
''I'm going to put in a lot of effort too, so...I'd like a little reward. After that, I'm sure the master will be more motivated if I bet on it!
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0936"]
[OnName num="sayo"]
Well, okay. If you can make it through without giving up... I'll do you one favor. So what do you think?
[cpg cn=true]


[OnName num="masato"]
「はい！」
[cpg cn=true]


Thus, Master and I are about to start 'chinkin boxing' (a different kind of martial arts).
[cpg]

[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0937"]
[OnName num="sayo"]
''Humph. I can't believe that all the martial arts I've been learning will come in handy in a place like this... I feel kind of sorry for the teachers who taught me...
[cpg cn=true]


[OnName num="masato"]
''Master, cheer up! FIGHT!
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0938"]
[OnName num="sayo"]
This is your fault! Totally... all right, get on with it and be a sandbag.
[cpg cn=true]


[OnName num="masato"]
Yes! Oh, and by the way, Master, you mentioned martial arts, what are you doing?
[cpg cn=true]


I asked him about it while getting ready for it.
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0939"]
[OnName num="sayo"]
Judo San-dan, Karate San-dan and Kendo Nidan. Other than that, Muay Thai, Shaolin Temple, Sambo, Bone Law, Brazilian Jiu-Jitsu... and a little Capoeira.
[cpg cn=true]


Oh, my God, there are so many! Isn't it too much to say that there are different martial arts?
[cpg]

[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0940"]
[OnName num="sayo"]
You can't stop now, can you? Couscous.
[cpg cn=true]


[OnName num="masato"]
''B, I'm a man too... a man doesn't have two words!''
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0941"]
[OnName num="sayo"]
It's nice. Well, let's see...
[cpg cn=true]


[OnName num="masato"]
I'm sorry.
[cpg cn=true]


I don't know where Master took it from, but he made me suck a gag ball into his mouth.
[cpg]

[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0942"]
[OnName num="sayo"]
It's a neighborhood nuisance if you raise your voice.
[cpg cn=true]


[OnName num="masato"]
"The mothballs.
[cpg cn=true]


It's true that it's late at night, and people at home get up too.
[cpg]

But, Master, you even had these things. I guess he was going to use it on me someday...I'm glad he did.
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0943"]
[OnName num="sayo"]
 "Soooo ... I'm going." 
[cpg cn=true]


Then, the master attacks with an unnoticeable movement.
[cpg]

What's that move... no, no, no, no!
[cpg]

[SE f="se040"]
;//【ＳＥ】『蹴り』ズドンッ！
;//画面超揺れる


[OnName num="masato"]
Ugh...oooooooooooooooooooooooooooooooooooooooooooooo!
[cpg cn=true]


Suddenly a strong one came. That was a close one. It was almost as if the current blow had reaped his consciousness.
[cpg]

His cock jerked and jerked as he received a strong shock.
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0944"]
[OnName num="sayo"]
Didn't I tell you I'd use Capoeira too?
[cpg cn=true]


[OnName num="masato"]
''Ughhhhhhhhhh...Ughhhhhhhhhh...''
[cpg cn=true]


I mean it. It's different now... the master really, really means it.
[cpg]

Without a care in the world, he strikes a full force blow into my pubic area.
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0945"]
[OnName num="sayo"]
I'll tell you while you're still conscious. Tonight... you may stain this room and me with this sack of perverted, filthy male juices and the like... and I will forgive you.
[cpg cn=true]


[OnName num="masato"]
''Whew, whew...whew...whew...whew...''
[cpg cn=true]

[FO pos="2/3" time=1000]

That's what I'm hoping for. I'm super serious this time, too. I have no intention of losing at all.
[cpg]

I'm going to win, I'm going to win, I'm going to win for my master, I'm going to win.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ





[SE f="se040"]
;//【ＳＥ】『蹴り』ズドンッ！
;//画面超揺れる


--And so the late-night sparring began.
[cpg]


;//少し時間を置いて


;//一定間隔で、何度かSEを再生



[SE f="se071"]
;//【ＳＥ】『ビンタ系』バチィン
[WAIT time=600]


[SE f="se071"]
;//【ＳＥ】『ビンタ系』バチィン
[WAIT time=600]


[SE f="se071"]
;//【ＳＥ】『ビンタ系』バチィン

[WAIT time=600]

;//※ここから小夜も雅人も疲弊しています。セリフ中も常に疲れているが、その中でもしっかり会話はしている、という感じです




[BG f="b_04_1.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（朝）******************************************************


[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0946"]
[OnName num="sayo"]
haha....haha...haha...haha...yikes...yikes...yikes...yikes...yikes.
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0947"]
[OnName num="sayo"]
''Ummm.............................''
[cpg cn=true]




[SE f="se068"]
;//【ＳＥ】『弱々しいビンタ系』ぺちん


[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0948"]
[OnName num="sayo"]
'Ha, ha...ha...ha...ha...ha...ha.
[cpg cn=true]

[FO pos="2/3" time=1000]


[SE f="se015"]
;//【ＳＥ】『ベッドに倒れこむ』ボフッ


I was tied to the bed so that I wouldn't move, and the master fell down next to me as it was.
[cpg]

[OnName num="masato"]
''Ughhhhhh.............................''
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0949"]
[OnName num="sayo"]
''Huh, huh...''
[cpg cn=true]


We're both breathing hard.
[cpg]

That's because they've been punching and kicking all night... no wonder.
[cpg]


[SE f="se018"]
;//【ＳＥ】『鳥の鳴き声』チュンチュン

[WAIT time=500]


Before you know it, it's already morning.
[cpg]

[FG f="CHA01_p3_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0950"]
[OnName num="sayo"]
 "Hmm ... this, shit, chinpo ... ehhhhhhhhh ..." 
[cpg cn=true]


Master misses my gag ball in a prone position.
[cpg]

[OnName num="masato"]
Phew! Ha, ha...I'll take that as a compliment.
[cpg cn=true]


We were drenched in sweat, drenched in urine, and drenched in sperm.
[cpg]

The same was true of the bed and the room around it. There's also blood all over the place. It came out of one of my things.
[cpg]

His balls were now empty, but he still had an ejaculatory motion, and it probably took the place of the one that didn't come out.
[cpg]

[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0951"]
[OnName num="sayo"]
''Huh...huh...huh...''
[cpg cn=true]


[OnName num="masato"]
「はぁ、はぁ…」
[cpg cn=true]


What happened here last night is indescribable...content that we don't want to give too much away, except to us.
[cpg]

What took place was not an act like what had been done before, but a serious clash with each other. Yeah, I just kept getting them....
[cpg]

Master had come to crush my privates in earnest. I'm not joking, I'm serious.
[cpg]

That's why... this room is such a wreck.
[cpg]

As if to be bathed in blood, Master shook his fist at my pubic area without a break while receiving semen and urine.
[cpg]

Sometimes it's a kick, sometimes it's an elbow, sometimes it's a knee kick, sometimes it's a shimematsu, sometimes it's a drop technique with all the weight on it... Honestly, I'm amazed at how long I've been alive.
[cpg]

Master had a look I had never seen before and acted in a way I had never seen before.
[cpg]

It was like being hit with a mass of negative emotions that I've been storing up until now...
[cpg]

That scene... is something we should keep in our own memories.
[cpg]

You can't even try to tell people about it.
[cpg]

[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0952"]
[OnName num="sayo"]
''Hahahaha...just to ask you a question, are you okay...right?
[cpg cn=true]


[OnName num="masato"]
''Yes, somehow...I honestly thought it was broken...but it seems to be okay.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0953"]
[OnName num="sayo"]
Shush. I wonder if the pervert's penis has a steel plate in it...
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0954"]
[OnName num="sayo"]
 “Ohhhhh ... I ’m losing” 
[cpg cn=true]


The game was won by me.
[cpg]

For one night...I endured Master's earnest torment. I think it's a tenacious win.
[cpg]

[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0955"]
[OnName num="sayo"]
I can't move anymore...
[cpg cn=true]


[OnName num="masato"]
Me too.
[cpg cn=true]


We're not going to be able to move with each other for a while.
[cpg]

[OnName num="masato"]
How are you... feeling?
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0956"]
[OnName num="sayo"]
It sucks.
[cpg cn=true]


[VOICE f="Sayo0957"]
[OnName num="sayo"]
''I'm all sweaty and covered in the liquid from your body and I'm so tired...I'm defeated. It's so bad now.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0958"]
[OnName num="sayo"]
 "... It's the worst, but it's the best" 
[cpg cn=true]


Seemingly refreshed, Master said.
[cpg]

[OnName num="masato"]
Master. Promise, don't forget that.
[cpg cn=true]


[VOICE f="Sayo0959"]
[OnName num="sayo"]
Yeah. Aaaaahhhh...the pervert's request is so scary.
[cpg cn=true]


[OnName num="masato"]
''I wouldn't ask you to do anything weird like that...''
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0960"]
[OnName num="sayo"]
But to keep slapping a man's penis all night long... I guess I'm one of the perverts.
[cpg cn=true]


[OnName num="masato"]
Ahahaha. You're a pervert.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0961"]
[OnName num="sayo"]
Shut up."
[cpg cn=true]




[SE f="se068"]
;//【ＳＥ】『弱々しいビンタ系』ぺちん


[VOICE f="Sayo0962"]
[OnName num="sayo"]
It's okay to say it yourself, but it's annoying when people say it to you.
[cpg cn=true]


[OnName num="masato"]
Um, we shouldn't get up yet...
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0963"]
[OnName num="sayo"]
"It's okay, it's okay...
[cpg cn=true]


When he said that, he managed to stand up with his body shaking, and the master sat down with a thud on the chair by the window.
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0964"]
[OnName num="sayo"]
My whole body hurts.
[cpg cn=true]


[OnName num="masato"]
"I've got a dick...
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0965"]
[OnName num="sayo"]
Well, I didn't go easy on him. You can go to the hospital later and get checked out.
[cpg cn=true]


That's certainly true, let's do that.
[cpg]

It hasn't stopped functioning due to being crushed, but I'm sorry to the master even if it's left as it is and a problem appears somewhere.
[cpg]

At first glance, it looks twice as swollen as it is.
[cpg]

[OnName num="masato"]
''Master, what are we going to do after this...?
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0966"]
[OnName num="sayo"]
Come on, Prep.
[cpg cn=true]


[OnName num="masato"]
You're going? That's great.
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0967"]
[OnName num="sayo"]
"Of course. A student's duty is to study.
[cpg cn=true]


[OnName num="masato"]
I'll definitely be resting. Ahahaha.
[cpg cn=true]


[VOICE f="Sayo0968"]
[OnName num="sayo"]
If I rested, you wouldn't be able to show me...as a master.
[cpg cn=true]


[OnName num="masato"]
"Well...then I'll do my job...too...well...
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0969"]
[OnName num="sayo"]
You need to get well today.
[cpg cn=true]


[OnName num="masato"]
But...
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0970"]
[OnName num="sayo"]
Order.
[cpg cn=true]


[OnName num="masato"]
Yes. "
[cpg cn=true]

[FO pos="2/3" time=1000]

As we talked like that, we were in a daze for a while... almost motionless and in a daze.
[cpg]

Even if you can move a little, you have to recover your strength.
[cpg]


[SE f="se002"]
;//【ＳＥ】『時計音』カッチコッチ


[OnName num="masato"]
"Master, aren't you hungry?
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0971"]
[OnName num="sayo"]
''Aaah~...that's right. It's empty. Or rather, pecking...
[cpg cn=true]


[OnName num="masato"]
If it's easy, I can make you something.
[cpg cn=true]


My energy is empty because I hustled all night.
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0972"]
[OnName num="sayo"]
'...that's fine too.
[cpg cn=true]


[OnName num="masato"]
「？」
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0973"]
[OnName num="sayo"]
Do you know? When people have unfulfilled desires, they try to substitute them elsewhere.
[cpg cn=true]


[OnName num="masato"]
''Huh...I've heard something about this. If you stay up all night, you're going to have an appetite in the middle of the night.
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0974"]
[OnName num="sayo"]
Yes. So, we all lacked sleep. No wonder I'm not getting enough sleep.
[cpg cn=true]


[OnName num="masato"]
'Yes, I understand. But it's...?
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0975"]
[OnName num="sayo"]
There are only two substitutions. It could be the appetite... or the sex drive...
[cpg cn=true]


[OnName num="masato"]
「……」
[cpg cn=true]


[VOICE f="Sayo0976"]
[OnName num="sayo"]
Right? Let's take a chance... and substitute it with sex appeal.
[cpg cn=true]


[OnName num="masato"]
 "... your husband likes it too ..." 
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0977"]
[OnName num="sayo"]
"Shut up. I don't have the power to get angry, so get over here and don't talk about it.
[cpg cn=true]


[OnName num="masato"]
I'm going, right? It's a servant's fault.
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0978"]
[OnName num="sayo"]
I'm sorry, I'm stuck.
[cpg cn=true]


I went to the master with all my strength and wobbled around.
[cpg]

[OnName num="masato"]
Servant, I'm here.
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0979"]
[OnName num="sayo"]
''Hmm. Thank you for your time.
[cpg cn=true]


It becomes wet, and it sticks to the body tightly...and the clothes that are disordered on top of that are very naughty.
[cpg]

Master opens both legs wide as it is and makes it easy for me to kneel.
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0980"]
[OnName num="sayo"]
I also need to take a bath, so... it'll be about another forty minutes before I start getting ready.
[cpg cn=true]


[OnName num="masato"]
"Forty minutes? We don't have much time...
[cpg cn=true]


[FG f="CHA01_p1_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0981"]
[OnName num="sayo"]
It won't hold you for long.
[cpg cn=true]


[OnName num="masato"]
''Haha, that's certainly true.
[cpg cn=true]


As we talked, I put my hands in the back of my pajamas and pull down my underwear around my waist.
[cpg]

She takes off her pants while being caught with the sound of slipping. My underwear is also covered in my liquid, but it seems to include Master's as well.
[cpg]

[OnName num="masato"]
"Master, you're wet.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo0982"]
[OnName num="sayo"]
What? Is it bad if it's wet?
[cpg cn=true]


[OnName num="masato"]
''No, no, no...the master was excited by the feeling too, wasn't he?
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0983"]
[OnName num="sayo"]
'...idiot. It's the lack of sleep.
[cpg cn=true]


[OnName num="masato"]
Chuckle. Yes, sir.
[cpg cn=true]


I've seen it many times and even put my mouth on it. It's the same thing I'm about to do now.
[cpg]

But it seemed to me to be the most beautiful bun I've ever seen...
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0984"]
[OnName num="sayo"]
I feel like I need to cum a lot. Please...
[cpg cn=true]


[OnName num="masato"]
I'll take care of it. I'll have a drink with you.
[cpg cn=true]


Then I put my mouth on Master's private parts.
[cpg]

[OnName num="masato"]
Squirt, squirt, squirt, squirt.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0985"]
[OnName num="sayo"]
Oh! Hmmm...hmmm...hmmm...hmmm!
[cpg cn=true]


[VOICE f="Sayo0986"]
[OnName num="sayo"]
Huh...huh, huh? I love it, I love it, you're so good at licking it.
[cpg cn=true]


[OnName num="masato"]
"Juppu, juppu, juppu...it's possible, it's a good day. Hmmm, hmmm, hmmm...
[cpg cn=true]


[VOICE f="Sayo0987"]
[OnName num="sayo"]
''Ahhhhhhhhhhhhhhhh...ahhhhhhhhh...ahhhhhhhhhhh!
[cpg cn=true]


[OnName num="masato"]
(Master...you feel great.)
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0988"]
[OnName num="sayo"]
"...ah...hmmm... I'm... now... because there's nothing I can do to resist...
[cpg cn=true]


[OnName num="masato"]
"Huh?
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0989"]
[OnName num="sayo"]
I don't mind if you put it in. Hmmm...ahhhhhhh...
[cpg cn=true]


[OnName num="masato"]
"...........no thanks. Besides, I can't use this one right now.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0990"]
[OnName num="sayo"]
''So...it's a shame. Oh, God...hhhh, oh, God...come...come...come! Ahhhh...come...come...come...come!
[cpg cn=true]


[OnName num="masato"]
"I'll be happy to help you...jiggle, jiggle, jiggle. Squishy, squishy.
[cpg cn=true]


[FG f="CHA01_p3_03_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0991"]
[OnName num="sayo"]
''Oooh! Mmm, mmm, mmm! Aaaaahhhhhh!!!!!
[cpg cn=true]


[VOICE f="Sayo0992"]
[OnName num="sayo"]
''Hahhhh, hahhhh...hahhhh...''
[cpg cn=true]


[OnName num="masato"]
I'll be right behind you.
[cpg cn=true]


[VOICE f="Sayo0993"]
[OnName num="sayo"]
Yeah... 40 minutes, I'll give you that. Do what you want with it...
[cpg cn=true]



[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ





In the forty minutes I was told I could be free, I made my master cum seven times.
[cpg]

They became more mushy with bodily fluids than each other.
[cpg]

The maids who came to wake up their masters found us...they tore us apart, and our night was finally over.
[cpg]


;//少し時間を置く感じで


[STOPBGM]
[BGM f="d1" time=1000]
[BG f="b_04_2.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************


[OnName num="masato"]
Oh, welcome back, master.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0994"]
[OnName num="sayo"]
I'm back...what are you doing?
[cpg cn=true]


[OnName num="masato"]
Bed making, sir.
[cpg cn=true]


Master's room was in a bad state after last night, so I cleaned it up to clean it up.
[cpg]

It was so hard that it took me a whole day.
[cpg]

[FG f="CHA01_p2_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo0995"]
[OnName num="sayo"]
I told you to get some rest...
[cpg cn=true]


[OnName num="masato"]
I've examined her properly, so she should be fine.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0996"]
[OnName num="sayo"]
'.............yeah. Well, I hope so...
[cpg cn=true]


[OnName num="masato"]
''Then look at it, here it is. It's cleaned up nicely.
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0997"]
[OnName num="sayo"]
Yeah. That's great.
[cpg cn=true]


Master directed a gentle smile at me.
[cpg]

[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0998"]
[OnName num="sayo"]
You didn't have to force me to fix it today...
[cpg cn=true]


Those are words from knowing the devastation in this room this morning.
[cpg]

[OnName num="masato"]
''I want to keep the master's room clean. Besides, I've got an appointment to make...
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo0999"]
[OnName num="sayo"]
"Ugh..."
[cpg cn=true]


[OnName num="masato"]
I remember, don't I?
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo1000"]
[OnName num="sayo"]
Of course. Of course you do.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1001"]
[OnName num="sayo"]
'....I guess that's not what you were waiting for.
[cpg cn=true]


[OnName num="masato"]
Ehehehe.
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1002"]
[OnName num="sayo"]
''Huh...''
[cpg cn=true]


Master let out a sigh.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1003"]
[OnName num="sayo"]
So what? What in the world is this request?
[cpg cn=true]


[OnName num="masato"]
Huh? Is it now?
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1004"]
[OnName num="sayo"]
''It won't be much different now or later. Let's hear it.
[cpg cn=true]


[OnName num="masato"]
''Ha, yes...kohon. Let's see...
[cpg cn=true]


As a reward, I'm going to ask you to do me a favor.


Well...
[cpg]



;//■選択肢２
[switch]
[case "kiss"]
	[swap]
	[jump target="*IseSel02_1"]
[case "have one's fingers licked"]
	[swap]
	[jump target="*IseSel02_2"]
[case "anal sex"]
	[swap]
	[jump target="*IseSel02_3"]
[endswitch]

;//■選択肢

One, kiss.
Two, I need a lick.
Three, anal sex.
;////////////////////////////////////////////////////////////////////
;//１、キス
*IseSel02_1|Blood, Sweat and M

;//[stflag f.second_select = 1]

[OnName num="masato"]
I...want to...kiss...my master.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1005"]
[OnName num="sayo"]
''Kissing...? Kissing, you mean?
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1006"]
[OnName num="sayo"]
So...it's better.
[cpg cn=true]


[OnName num="masato"]
Yes!
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1007"]
[OnName num="sayo"]
I understand.
[cpg cn=true]


This is how I ended up kissing my master. It's the first time I've ever been able to do something like this.
[cpg]


;//●ＣＧエロ（雅人＆小夜・ご主人様とご褒美にディープキス：小夜の部屋）ev_10


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1008"]
[OnName num="sayo"]
「……」
[cpg cn=true]


[OnName num="masato"]
Well, then...
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1009"]
[OnName num="sayo"]
Oh. Wait, wait.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1010"]
[OnName num="sayo"]
Maybe it's better if you rinse your mouth first.
[cpg cn=true]


[OnName num="masato"]
Why is that?
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1011"]
[OnName num="sayo"]
''Why, because, you know... it's just... etiquette... if it's dirty, wouldn't we both hate it?''
[cpg cn=true]


[OnName num="masato"]
Not at all. I'd rather clean Master's mouth too. I'd rather have food scraps or something.
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo1012"]
[OnName num="sayo"]
"...Heh, pervert. Even perverts will hate you if you go too far!
[cpg cn=true]


[OnName num="masato"]
No one but the master will accept you.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1013"]
[OnName num="sayo"]
That's true too.
[cpg cn=true]


I was easily convinced.
[cpg]

[OnName num="masato"]
(thump).
[cpg cn=true]

[FO pos="2/3" time=1000]


[STOPBGM]
[BGM f="h1" time=1000]
;**【ＣＧ】ev_10_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************

[VOICE f="Sayo1014"]
[OnName num="sayo"]
''Hmm...''
[cpg cn=true]


[OnName num="masato"]
"Squish.
[cpg cn=true]


My lips touch Master's soft, springy lips.
[cpg]

[VOICE f="Sayo1015"]
[OnName num="sayo"]
''Tsk, tsk...tsk...tsk. Squishy, squishy.
[cpg cn=true]


[OnName num="masato"]
Chub chub chub.
[cpg cn=true]


[VOICE f="Sayo1016"]
[OnName num="sayo"]
"Ha...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh...ugh.
[cpg cn=true]


[OnName num="masato"]
"Chuppa, chuppa.
[cpg cn=true]


[VOICE f="Sayo1017"]
[OnName num="sayo"]
''Hmmm...hmmm...hmmm. Tsk, tsk...tsk...tsk...tsk...tsk.
[cpg cn=true]


[VOICE f="Sayo1018"]
[OnName num="sayo"]
"Pee-pee, pee-pee...hhhh, hhhh...hmmm. Mm-hmm.
[cpg cn=true]


[OnName num="masato"]
''Hmm, I want to drink...................................................................................................................................... I want more of my master's saliva.
[cpg cn=true]


[VOICE f="Sayo1019"]
[OnName num="sayo"]
'...idiot. Here, have all the... drinks you want.
[cpg cn=true]


[VOICE f="Sayo1020"]
[OnName num="sayo"]
"Chupu, ugh...don't be shy. This is my reward for you.
[cpg cn=true]


[OnName num="masato"]
"Hi.
[cpg cn=true]


[VOICE f="Sayo1021"]
[OnName num="sayo"]
"Whew...chug, chug, chug...chug, chug, chug...chug, chug...
[cpg cn=true]


They kissed at a delicate distance, but gradually their bodies became closer to each other.
[cpg]


A few minutes later, they were embracing without either of them.
[cpg]


[VOICE f="Sayo1022"]
[OnName num="sayo"]
 "Hmm ... I'm tired when I'm standing." 
[cpg cn=true]


[OnName num="masato"]
Come on, then.
[cpg cn=true]


I sit down and invite my master to sit on my lap.
[cpg]

;**【ＣＧ】ev_10_a ***********************
[CG id=9 index=1 time=1000]
;***************************************



[VOICE f="Sayo1023"]
[OnName num="sayo"]
''Pee, pee...I'm not usually allowed to let my master sit on my lap...''
[cpg cn=true]


[OnName num="masato"]
But it's a reward, isn't it?
[cpg cn=true]


[VOICE f="Sayo1024"]
[OnName num="sayo"]
''Yes, hmmm, hmmm... so special. Jyuru, ugh...
[cpg cn=true]


[VOICE f="Sayo1025"]
[OnName num="sayo"]
Hmmm... Tsk...tsk...tsk...tsk...tsk...tsk...tsk...tsk.
[cpg cn=true]


[OnName num="masato"]
Excuse me, my teeth...?
[cpg cn=true]


[VOICE f="Sayo1026"]
[OnName num="sayo"]
"No, it's not. My male parts are squishy...
[cpg cn=true]


[OnName num="masato"]
It's a menstrual phenomenon.
[cpg cn=true]


[VOICE f="Sayo1027"]
[OnName num="sayo"]
I'm relieved to see that it's true that he's still available.
[cpg cn=true]


[VOICE f="Sayo1028"]
[OnName num="sayo"]
''Prickle, prickle, prickle... prickle, prickle, prickle.''
[cpg cn=true]


[VOICE f="Sayo1029"]
[OnName num="sayo"]
 Puh-hah!
[cpg cn=true]


[VOICE f="Sayo1030"]
[OnName num="sayo"]
Huh, huh... is this good enough for you?
[cpg cn=true]


[OnName num="masato"]
Yes. That's enough.
[cpg cn=true]


I tasted my master's lips for an hour or so.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ

[STOPBGM]
[BGM f="d1" time=1000]
[BG f="b_04_2.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1031"]
[OnName num="sayo"]
...is this a favor, okay?
[cpg cn=true]


[OnName num="masato"]
Yes, of course. This could not be a better reward.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo1032"]
[OnName num="sayo"]
''Well... then I'm glad you did.
[cpg cn=true]


The master laughed softly.
I have another request (story) to tell.
[cpg]

[OnName num="masato"]
Master. Just one more thing...
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1033"]
[OnName num="sayo"]
?"
[cpg cn=true]


[OnName num="masato"]
Master. Let me...
[cpg cn=true]




;//【奉公END】【ただいまEND】へのフラグ
[stflag service_flag=1]


;//【合流A】へ
[jump target="*IseSel02_4"]


;////////////////////////////////////////////////////////////////////
;//２、舐めて貰う

*IseSel02_2|Blood, Sweat and M
;//[stflag f.second_select = 2]

[OnName num="masato"]
I want you to...lick me.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1034"]
[OnName num="sayo"]
I see. Do you really want your master to serve you with a shabby prick?
[cpg cn=true]


[OnName num="masato"]
'Well, no...'
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1035"]
[OnName num="sayo"]
"...okay, fine. It's a reward in the first place, so there's no reason to say no.
[cpg cn=true]


[OnName num="masato"]
「ありがとうございます」
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1036"]
[OnName num="sayo"]
Really, this time it's special.
[cpg cn=true]


*Scene13

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ
[BGM f="h1" time=1000]

;//＝＝※※CGリストと一致しない※※＝＝
;//☆ＣＧエロ（雅人＆小夜・ちんぐり返し状態でアナル舐め＋竿扱き：小夜の部屋）ev_03（※ex01同一CG）
;//アナルだけじゃなく竿も舐めたり、アナルに指いれたりもします


;**【ＣＧ】ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************

[OnName num="masato"]
Go ahead, please.
[cpg cn=true]


[VOICE f="Sayo1037"]
[OnName num="sayo"]
"You dressed yourself up like this... I'm not a very good beggar.
[cpg cn=true]


I don't care if the words are a little sarcastic and appalling.
[cpg]

[VOICE f="Sayo1038"]
[OnName num="sayo"]
I'm sure you've cleaned it up properly.
[cpg cn=true]


[OnName num="masato"]
Yes, of course.
[cpg cn=true]


[VOICE f="Sayo1039"]
[OnName num="sayo"]
Hmm, fine.
[cpg cn=true]


And so the first Master's service began.
[cpg]


;**【ＣＧ】ev_03_b ***********************
[CG id=2 index=2 time=1000]
;***************************************

[VOICE f="Sayo1040"]
[OnName num="sayo"]
Pero. I don't know what to do....
[cpg cn=true]


[OnName num="masato"]
Aah! Master's tongue is on my dick and on my ass!
[cpg cn=true]



[VOICE f="Sayo1041"]
[OnName num="sayo"]
"Pour, pour, pour, pour...chug, chug, chug...chug, chug...chug, chug, chug, chug.
[cpg cn=true]


[OnName num="masato"]
"Huh, huh... great, Master's tongue.
[cpg cn=true]


It feels so good that my head is in a daze.
[cpg]


[VOICE f="Sayo1042"]
[OnName num="sayo"]
''Jyuru...hmmm. Hey, did you really clean it up? It's really stinky. Squeak, squeak...
[cpg cn=true]


[OnName num="masato"]
Well, is that so?
[cpg cn=true]


[VOICE f="Sayo1043"]
[OnName num="sayo"]
''Pichan, hmmm~...you know, around here and so on. Lero, ugh...
[cpg cn=true]


Even while saying so, Master licks me.
[cpg]


[VOICE f="Sayo1044"]
[OnName num="sayo"]
I knew it. Because you don't skin and clean it every time...you know, all this coccus...
[cpg cn=true]


[OnName num="masato"]
Oh, I'm sorry.
[cpg cn=true]


[VOICE f="Sayo1045"]
[OnName num="sayo"]
"Juppy...Juppy...Juppy...Juppy...Juppy...Juppy...Juppy...Juppy...Juppy...Juppy...Juppy...Juppy.
[cpg cn=true]


[OnName num="masato"]
"Master!
[cpg cn=true]


[VOICE f="Sayo1046"]
[OnName num="sayo"]
"Lero, I'm going to make a special effort to clean this too. I'll show you an example, so watch and learn.
[cpg cn=true]


[VOICE f="Sayo1047"]
[OnName num="sayo"]
"Chill out, chill out...chill out, chill out...chill out, chill out...chill out, chill out.
[cpg cn=true]


It's great to have them do this to you. I end up begging for more.
[cpg]

[OnName num="masato"]
"Master, I want you to do more... to touch my ass, too.
[cpg cn=true]



[VOICE f="Sayo1048"]
[OnName num="sayo"]
'Yes and yes. You're a servant with a lot of orders.
[cpg cn=true]



[VOICE f="Sayo1049"]
[OnName num="sayo"]
''Ooh~, chug. 
[cpg cn=true]


[OnName num="masato"]
Oh, I'm out.
[cpg cn=true]


;**【ＣＧ】ev_03_c ***********************
[CG id=2 index=3 time=1000]
;***************************************


[SE f="se026"]
;//【ＳＥ】『射精音』


--Doby-doby-doby-doby-doby-doby!

[VOICE f="Sayo1050"]
[OnName num="sayo"]
''Hmmm, hmmm, hmmm, hmmm, hmmm, hmmm, hmmm!!!
[cpg cn=true]



[VOICE f="Sayo1051"]
[OnName num="sayo"]
''Ugh...hmmm...hmmm...hmmm...hmmm. Very much. Gokun...
[cpg cn=true]



;//※下僕の場合
;//------------------------------
;//[if exp="f.first_select == 1"]
[if exp={getFlagValue("gohome_flag") == 1 }]


[VOICE f="Sayo1052"]
[OnName num="sayo"]
"There you go. I drank it all.
[cpg cn=true]

[endif]
;//------------------------------
;//※ペットの場合
[if exp={getFlagValue("pets_flag") == 1 }]


[VOICE f="Sayo1053"]
[OnName num="sayo"]
"There you go. I drank the whole thing.
[cpg cn=true]
[endif]

;//------------------------------
;//分岐１行のみ

[OnName num="masato"]
'Oh, I'm so happy... master.
[cpg cn=true]

[SCENE id=12]
[ENDPARTIAL]


;//【比翼連理END】へのフラグ
[stflag hiyokurenri_flag=1]

;//【合流A】へ
[jump target="*IseSel02_4"]

;////////////////////////////////////////////////////////////////////
;//３、アナルセックス
*IseSel02_3|血と汗とＭ
*s23
;//[stflag f.second_select = 3]

[OnName num="masato"]
I want... your... master's... butt virginity.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo1054"]
[OnName num="sayo"]
'Oh, ass virgin...?'
[cpg cn=true]


[OnName num="masato"]
I want to have anal sex with you!
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1055"]
[OnName num="sayo"]
"Huh...that's how I see it. Uggh...
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo1056"]
[OnName num="sayo"]
''Alright, alright. I will, with my butt...
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo1057"]
[OnName num="sayo"]
In return, be nice to them. Or I'm going to kill you.
[cpg cn=true]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]

*Scene14|Blood, urine, semen and M


[STOPBGM]
[BGM f="h1" time=1000]

;//●ＣＧエロ（雅人＆小夜・ご主人様とご褒美にアナルセックス：お風呂場）ev_11
;**【ＣＧ】ev_11_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************

[OnName num="masato"]
Master, the first thing we need to do is clean up.
[cpg cn=true]


[VOICE f="Sayo1058"]
[OnName num="sayo"]
I mean, what do you mean, "Washing...
[cpg cn=true]


[OnName num="masato"]
It's done with your butt. Yes, relax your strength.
[cpg cn=true]


[VOICE f="Sayo1059"]
[OnName num="sayo"]
'Well, yes, but...'
[cpg cn=true]

;**【ＣＧ】ev_11_a ***********************
[CG id=10 index=1 time=1000]
;***************************************

[VOICE f="Sayo1060"]
[OnName num="sayo"]
Oh! Just a little...wait aaaaahhhh!
[cpg cn=true]


And so the cleaning begins.
[cpg]

[OnName num="masato"]
Yes, it's all in.
[cpg cn=true]

;**【ＣＧ】ev_11_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************

[VOICE f="Sayo1061"]
[OnName num="sayo"]
Ugh...my stomach...what did you put in there?
[cpg cn=true]


[OnName num="masato"]
It's an enema.
[cpg cn=true]


[VOICE f="Sayo1062"]
[OnName num="sayo"]
Huh! Well, that's...
[cpg cn=true]


[OnName num="masato"]
It's a wash.
[cpg cn=true]


[VOICE f="Sayo1063"]
[OnName num="sayo"]
Go to the toilet... go to the toilet!
[cpg cn=true]




[BG f="black.ui" time=1000]
;//ＢＫ





;//またCGを表示


[OnName num="masato"]
Well, I'll let you in then.
[cpg cn=true]

;**【ＣＧ】ev_11_b ***********************
[CG id=10 index=2 time=1000]
;***************************************

[VOICE f="Sayo1064"]
[OnName num="sayo"]
Ahhhhhhhh!
[cpg cn=true]


[OnName num="masato"]
"Ahhh...Master's anus is the best.
[cpg cn=true]


[VOICE f="Sayo1065"]
[OnName num="sayo"]
''Hmmm! I'm not sure what to do about it.
[cpg cn=true]


[VOICE f="Sayo1066"]
[OnName num="sayo"]
Ahhhh, ahhh...slow down more, slow down...ahhh, ahhh...ahhh...
[cpg cn=true]


[OnName num="masato"]
I'm sorry, I can't.
[cpg cn=true]


Joo-hoo! Joo-hoo! Joo-hoo!
[cpg]


[VOICE f="Sayo1067"]
[OnName num="sayo"]
'Hey, don't put it in your ass, no! That's not a place where you can cum...
[cpg cn=true]




[SE f="se026"]
;//【ＳＥ】『射精音』

;**【ＣＧ】ev_11_c ***********************
[CG id=10 index=3 time=1000]
;***************************************

——どびゅっどびゅっどびゅっ！！

[VOICE f="Sayo1068"]
[OnName num="sayo"]
''Ahhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh!!!!!
[cpg cn=true]


[VOICE f="Sayo1069"]
[OnName num="sayo"]
Huh...huh...it's coming out, it's hot...I'm full of it in my belly...
[cpg cn=true]


[OnName num="masato"]
"Ha, ha..."
[cpg cn=true]


I ejaculated into my master's anus in full force.
[cpg]

[BG f="black.ui" time=1000]
;//ＢＫ

[STOPBGM]
[BGM f="co" time=1000]
[BG f="b_08_4.ui" time=1000]


[FG f="CHA01_p1_00_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo1070"]
[OnName num="sayo"]
I told you to be nice, didn't I?
[cpg cn=true]


[FG f="CHA01_p2_00_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo1071"]
[OnName num="sayo"]
"Let's go, let's go.
[cpg cn=true]



[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ




[BGM f="h1"]

;//●ＣＧエロ（雅人＆小夜・ベッドに４方から仰向けで縛られ動きを封じられ騎乗位：小夜の部屋）ev_12

;**【ＣＧ】ev_12_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************



[OnName num="masato"]
I thought you said it was a reward...
[cpg cn=true]


[VOICE f="Sayo1072"]
[OnName num="sayo"]
There's a difference between that and this. I said I'd give you a reward, but I didn't say I wouldn't get a good one as a result.
[cpg cn=true]


It certainly is. You got one.
[cpg]

[OnName num="masato"]
''Um, but...is this going to be an Oshioki?''
[cpg cn=true]


[VOICE f="Sayo1073"]
[OnName num="sayo"]
You will.
[cpg cn=true]



[VOICE f="Sayo1074"]
[OnName num="sayo"]
Something that would make you cum over and over again... with your balls unfilled yesterday and today.
[cpg cn=true]


[OnName num="masato"]
That's not good! Seriously!
[cpg cn=true]



[VOICE f="Sayo1075"]
[OnName num="sayo"]
''Fufu, but... it's good to be treated inside me, isn't it?
[cpg cn=true]


[OnName num="masato"]
Yes!
[cpg cn=true]


[VOICE f="Sayo1076"]
[OnName num="sayo"]
Then it's decided. Let's get going.
[cpg cn=true]


[OnName num="masato"]
''Ahhhhhhhhhhhh!''
[cpg cn=true]


;**【ＣＧ】ev_12_a ***********************
[CG id=11 index=1 time=1000]
;***************************************

[VOICE f="Sayo1077"]
[OnName num="sayo"]
'...ohhh...ohhh...ohhh...ohhh...ohhh...ohhh...ohhh...ohhh...ohhh...ohhh!
[cpg cn=true]


[VOICE f="Sayo1078"]
[OnName num="sayo"]
It hurts like hell...
[cpg cn=true]


[OnName num="masato"]
「ご主人様」
[cpg cn=true]


[VOICE f="Sayo1079"]
[OnName num="sayo"]
''Here, let's go...hmmm, hmmm, hmmm...hmmm...hmmm!
[cpg cn=true]


Thus began the exploitation of the Master. I had to go along with it for a long time, and they made me feel bad.
[cpg]

[SCENE id=13]
[ENDPARTIAL]


[STOPBGM]
[BG f="black.ui" time=1000]
;//ＢＫ


;//【遠き存在END】へのフラグ
[stflag existence_flag=1]

;//【合流A】へ

;////////////////////////////////////////////////////////////////////



;//【合流A】
*IseSel02_4

[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="ep015.ks" target="*start"]


;////////////////////////////////////////////////////////////////////
;//【合流A】
