*start

;//[jump target="*root_existence"]


;#################################################
*Ep008|Serious S vs Serious M
;#################################################

[SCENE id=8]


[stflag jump_scene=0]
[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


[BG f="black.ui" time=1000]

[SE f=se018]
;//【ＳＥ】『鳥の鳴き声』

[WAIT time=2000]

[window target=true]


It happened while I was hanging my laundry outside...
[cpg]


[BGM f="d1"]
[BG f="b_07_2.ui" time=1000]
;//【ＢＧ】『空』（昼）******************************************************


[OnName num="masato"]
Huh... it's a nice day too!
[cpg cn=true]


It's a perfect day to hang the laundry out to dry, Let's get right to work!
[cpg]


[SE f="se044"]
;//【ＳＥ】『洗濯物を干す』パンパンッ


[OnName num="dog"]
Sigh.
[cpg cn=true]


[OnName num="masato"]
"Whoa, what's up, senior?
[cpg cn=true]


I call him senior because he is serving the master before me. Occasionally, though.
[cpg]

[OnName num="dog"]
Woof woof!
[cpg cn=true]


[OnName num="masato"]
Do you want me to play with you?
[cpg cn=true]


It's weirdly jarring, but I can't do it now that I'm hanging the laundry out to dry.
[cpg]

[OnName num="masato"]
I'll see you later.
[cpg cn=true]


[OnName num="dog"]
 "Woohhhhhhhhhh!" 
[cpg cn=true]


[OnName num="masato"]
Oh! Hey!
[cpg cn=true]


I'm not sure if being treated harshly is annoying, or if it's annoying to be treated harshly, but I'm jumping on the laundry.
[cpg]

And what's more, it's... the master's favorite clothes! Oh, shit!
[cpg]

[OnName num="masato"]
No... don't...
[cpg cn=true]




[SE f="se045"]
;//【ＳＥ】『破れる音』ビリビリ、ビリッ


[OnName num="masato"]
"Hey!
[cpg cn=true]


[OnName num="dog"]
Woooooooooooooo!
[cpg cn=true]




[SE f="se046"]
;//【ＳＥ】『噛み付く』ガブッ


[OnName num="masato"]
Aaahhhh...aaahhhh!!!!!
[cpg cn=true]

[BG f="black.ui" time=1000]
;//ＢＫ

[STOPBGM]
[BG f="b_04_3.ui" time=1000]
;//【ＢＧ】『小夜の部屋』（夕方）******************************************************

[SE f="se002"]
;//【ＳＥ】時計

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0384"]
[OnName num="sayo"]
「………」
[cpg cn=true]


I'm sitting on my feet in front of the master who has returned from school.
[cpg]

It wasn't a flattering atmosphere, and she was angry.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0385"]
[OnName num="sayo"]
This...it's my favorite outfit. Do you know?
[cpg cn=true]


[OnName num="masato"]
Yes..."
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0386"]
[OnName num="sayo"]
And then...this...this...this much...
[cpg cn=true]


There were slight tears in her eyes.
[cpg]

His clothes were ripped to shreds. It can be hard to fix, too.
[cpg]

It's such an important thing, but to do it like this...it makes the master sad.
[cpg]

[OnName num="maid_A"]
That was a gift from your husband, a memento of his life.
[cpg cn=true]


[OnName num="masato"]
''So, I see...I'm sorry. Really, I'm sorry!
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0387"]
[OnName num="sayo"]
''That's right...I got it when I was in elementary school, and I still wore it with great care...!!
[cpg cn=true]


[OnName num="masato"]
''Master... you've grown up since that time...''
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0388"]
[OnName num="sayo"]
Hmph!
[cpg cn=true]




[SE f="se047"]
;//【ＳＥ】『殴る』バキッ


I got hit with a rare goo.
[cpg]

[OnName num="butler&maidA"]
''(I'm going to go off on a tangent...)
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0389"]
[OnName num="sayo"]
''For once... for once... I'm seriously pissed off, too.
[cpg cn=true]


[OnName num="masato"]
I'm sorry, I'm sorry...
[cpg cn=true]


[VOICE f="Sayo0390"]
[OnName num="sayo"]
I will not forgive you. Be prepared.
[cpg cn=true]


And so, the hellish Oshioki began.
[cpg]

[OnName num="dog"]
.............................
[cpg cn=true]




[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
;//ＢＫ



*Scene09

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="b_06_3.ui" time=1000]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夕方）******************************************************


[OnName num="masato"]
''Uh, um...be as gentle as possible...''
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0391"]
[OnName num="sayo"]
「………」
[cpg cn=true]


She didn't answer, and proceeded to prepare blandly. What I'm preparing for... of course, I'm preparing for my Oshioki.
[cpg]


;//●ＣＧエロ（雅人＆小夜・殴り、ペンチ、本を使って金玉潰し：雅人の部屋）ev_17
;//雅人はベッドに縛られてます
;//言葉責めされる


[VOICE f="Sayo0392"]
[OnName num="sayo"]
I don't think you're going to feel any better today, so brace yourself.
[cpg cn=true]


[OnName num="masato"]
''Ugh...''
[cpg cn=true]


[SE f="se"]
;//【ＳＥ】縛る

I'm lying on my back on my bed, my hips floating up and restrained. He's in a chin-up position.
[cpg]

I've worn this embarrassing outfit many times, but the look of the master between my legs...today, my cock is also shrinking.
[cpg]

Swoosh... and her fist was squeezed.
[cpg]



[SE f="se030"]
;//【ＳＥ】『風切音』ブオンッ

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=600]



[SE f="se047"]
;//【ＳＥ】『殴る』バキッ


[STOPBGM]
[BGM f="h1" time=1000]
[FO pos="2/3" time=1000]

;**【ＣＧ】ev_17_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************

[SE f="se000"]
;//【ＳＥ】画面揺れる


[OnName num="masato"]
"Ngugi!
[cpg cn=true]


He was swung down mercilessly without a word being said.
[cpg]


[SE f="se047"]
;//【ＳＥ】『殴る』バキッ


[SE f="se047"]
;//【ＳＥ】『殴る』バキッ


[OnName num="masato"]
"Oooh, oooh!
[cpg cn=true]


[VOICE f="Sayo0393"]
[OnName num="sayo"]
You... no, you servant!
[cpg cn=true]


A fist devoid of tenderness. It is directed at the testicles repeatedly with great momentum.
[cpg]

There was a gurgling, dull sound, and it dug in deep enough to change the shape of the ball. I feel like I'm going to pop out of the bag...
[cpg]

[OnName num="masato"]
 "Uguiiiii !?" 
[cpg cn=true]




[SE f="se047"]
;//【ＳＥ】『殴る』バキッ


[OnName num="masato"]
"Aah, aah, aah! No, no, no, no, no!
[cpg cn=true]


[VOICE f="Sayo0394"]
[OnName num="sayo"]
What's wrong? I'm going to be cursed, I'm going to be slapped in the balls... you horny pervert!
[cpg cn=true]




[SE f="se047"]
;//【ＳＥ】『殴る』バキッ


Obviously, punching him is not the end of Oshioki.
[cpg]

Master took out his pliers.
[cpg]

[OnName num="masato"]
Shit, what do you do with that...?
[cpg cn=true]


[VOICE f="Sayo0395"]
[OnName num="sayo"]
This is how it's done.
[cpg cn=true]

;**【ＣＧ】ev_17_a ***********************
[CG id=16 index=1 time=1000]
;***************************************

Grrrrrrrrrrrrrrrrrr!
[cpg]

I grabbed my right ball with pliers, and even that caused me pain... I pulled as hard as I could.
[cpg]

[OnName num="masato"]
"Ughhhh, ahhh, ahhh, ahhh!
[cpg cn=true]


[VOICE f="Sayo0396"]
[OnName num="sayo"]
Well? Does it hurt? Don't make it feel good, don't make it hurt.
[cpg cn=true]


[OnName num="masato"]
Whoop-doh-doh-doh-doh-doh-dah-dah-dah-dah-dah-dah-dah-dah!
[cpg cn=true]


The visual effect makes it extra painful.
[cpg]

Up until now, most things have turned into sexual pleasure, but this time it's not so easy.
[cpg]

[OnName num="masato"]
A thousand cuts! It'll cut a thousand! It'll cut a thousand! Aaaaaaahhhh, I'm going to break a thousand!
[cpg cn=true]


[VOICE f="Sayo0397"]
[OnName num="sayo"]
We might as well just rip it off.
[cpg cn=true]


[OnName num="masato"]
'No! Aaah! Ughhhhhhhh I'm sorry, I'm sorry! No, please, don't, don't, don't, don't! No, no, no, no, no, no!
[cpg cn=true]


;**【ＣＧ】ev_17_b ***********************
[CG id=16 index=2 time=1000]
;***************************************
[VOICE f="Sayo0398"]
[OnName num="sayo"]
''Well, I wouldn't want it to break...''
[cpg cn=true]


After saying that, Master loosened the strength of his hand and released the gold ball he was pinching.
[cpg]

The testicles inside seem to have been deformed as well.
[cpg]

Her pubic area was bright red and swollen from the blows and pulling.
[cpg]

[OnName num="masato"]
"Hiyyyyy...hiy...hiy...fuhiy...
[cpg cn=true]


I thought I had finally been released, but this didn't end the reprimand.
[cpg]


[VOICE f="Sayo0399"]
[OnName num="sayo"]
Hey, it hurts, doesn't it?
[cpg cn=true]


[OnName num="masato"]
''Yes...yes, yes, yes...it hurts like hell.
[cpg cn=true]



[VOICE f="Sayo0400"]
[OnName num="sayo"]
It hurts so much that it makes me cry, but how come... it's swelling up here as usual.
[cpg cn=true]


[SE f="se047"]
;//【ＳＥ】『殴る』バキッ

;**【ＣＧ】ev_17_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************

[OnName num="masato"]
''Huh-uh-uh!''
[cpg cn=true]


[VOICE f="Sayo0401"]
[OnName num="sayo"]
You really have no sense of moderation, no sense of place, and you're a bad cock!
[cpg cn=true]




[SE f="se047"]
;//【ＳＥ】『殴る』バキッ


[OnName num="masato"]
I'm sorry!
[cpg cn=true]


The pain that can be inflicted is real. I'm not screaming or hurting like this for acting either.
[cpg]

However, because of my constitution...no matter how much it hurts, there is a part of me that turns into a slight sexual feeling from there.
[cpg]

Inevitably, because of this, my lower body reacts...and my meat rod gets bigger.
[cpg]

;**【ＣＧ】ev_17_b ***********************
[CG id=16 index=2 time=1000]
;***************************************

[VOICE f="Sayo0402"]
[OnName num="sayo"]
How about this...?
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


Master picked up a thick book that was sitting on a bookshelf in his room.
[cpg]

The book is a hardcover, so the weight is heavy.
[cpg]

[OnName num="masato"]
You can't...do that...can you?
[cpg cn=true]


[VOICE f="Sayo0403"]
[OnName num="sayo"]
......"
[cpg cn=true]


I guessed he meant to replace the place where he had been punching with his fists.
[cpg]

Wait a minute... if you hit me with a heavy object like that...
[cpg]


[SE f="se048"]
;//【ＳＥ】『叩きつける』ドスンッ

;**【ＣＧ】ev_17_c ***********************
[CG id=16 index=3 time=1000]
;***************************************

--Butch.
[cpg]

[OnName num="masato"]
Oohhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh!
[cpg cn=true]


[VOICE f="Sayo0404"]
[OnName num="sayo"]
It sounds good.
[cpg cn=true]


[SE f="se048"]
;//【ＳＥ】『叩きつける』ドスンッ


[OnName num="masato"]
"Gaaaaaaaahhhh! Break! Break! Break! It's going to break!
[cpg cn=true]

[VOICE f="Sayo0405"]
[OnName num="sayo"]
It's okay, here. It's not sturdy. It's not crushed yet.
[cpg cn=true]


I was surprised even by myself.
[cpg]

Sure, it made my ears hurt, but it certainly wasn't...crushed yet.
[cpg]

But if you keep doing this... one more shot or two. It's going to go under for sure.
[cpg]


[VOICE f="Sayo0406"]
[OnName num="sayo"]
Would you like this one then?
[cpg cn=true]


[SE f="se049"]
;//【ＳＥ】『金属音』ゴトンッ

;**【ＣＧ】ev_17_d ***********************
[CG id=16 index=4 time=1000]
;***************************************

Surely he was prepared with pliers, and a hammer came out.
[cpg]

I can't help but shudder at the thought of being beaten for it.
[cpg]

 My testicles will be crushed for sure.
[cpg]

[OnName num="masato"]
''Hi...huuuuuuuuuuuuuuuuuuu...please don't do that...I'm sorry...''
[cpg cn=true]


[VOICE f="Sayo0407"]
[OnName num="sayo"]
"........."
[cpg cn=true]




[SE f="se048"]
;//【ＳＥ】『叩きつける』ドスンッ

;**【ＣＧ】ev_17_e ***********************
[CG id=16 index=5 time=1000]
;***************************************

[OnName num="masato"]
"Guhhhhhhhhhhh, aaaaahhhh!!!!
[cpg cn=true]


The master wordlessly swung the hammer down.
[cpg]

Right, left, right, left. They alternately balance and slam into the ball.
[cpg]

[OnName num="masato"]
 "Fuuii, uhhh ... fuuu, uuuu ..." 
[cpg cn=true]


[VOICE f="Sayo0408"]
[OnName num="sayo"]
I think it's time... to crush it.
[cpg cn=true]


[OnName num="masato"]
''Hi...no...don't...don't...don't...don't...don't...don't.
[cpg cn=true]




[SE f="se048"]
;//【ＳＥ】『叩きつける』ドスンッ


It made a loud noise and was swung down with intense pain.
[cpg]

[OnName num="masato"]
Ahhhhhhhhhhhh!!!!!
[cpg cn=true]


[SE f="se026"]
;//【ＳＥ】『射精音』

;**【ＣＧ】ev_17_f ***********************
[CG id=16 index=6 time=1000]
;***************************************

--thump, thump, thump, thump, thump!
And then... they ejaculated at the same time.
[cpg]


[VOICE f="Sayo0409"]
[OnName num="sayo"]
Well? Didn't it go under? Did it go out of business?
[cpg cn=true]


[VOICE f="Sayo0410"]
[OnName num="sayo"]
'He crushed your balls and you ejaculated? You're a pervert. You've been sucking my balls and making me squeal, haven't you?
[cpg cn=true]


[VOICE f="Sayo0411"]
[OnName num="sayo"]
Shall I completely grind you until you can no longer produce your filthy cum?
[cpg cn=true]


[OnName num="masato"]
''Hi, hi... ah, come up... ah, ha, ha...''
[cpg cn=true]


I fainted as I felt the intense pain and pleasure in my body.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ

[SCENE id=8]
[ENDPARTIAL]

[WAIT time=600]


[STOPBGM]
[BG f="b_06_4.ui" time=1000]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夜）******************************************************

[OnName num="masato"]
''Um...um...that...''
[cpg cn=true]


By the time I woke up, it was already night.
[cpg]

The strings that bound his hands and feet were gone, and he was lying on the bed properly.
[cpg]

It's as if I've just passed out and ended up at this hour.
[cpg]

[OnName num="masato"]
''Ah...?''
[cpg cn=true]


[SE f="se015"]
;//【ＳＥ】『布団をめくる』ガバッ


Huh, I remembered, and flipped the covers to check my crotch.
[cpg]

I took off my underwear and looked at it with my eyes...touched it, and I stroked my chest in relief.
[cpg]

[OnName num="masato"]
'(Good. Somehow it doesn't seem to be crushed...)
[cpg cn=true]


Although it's bright red and puffy and swollen, it's not the worst of it.
[cpg]

The master is right, it's incredibly sturdy.
[cpg]

[OnName num="masato"]
Th... thud.
[cpg cn=true]


Even the slightest movement or abrasion causes pain. That's to be expected, after all the things I've done.
[cpg]

Besides, it wasn't just Master Osioki... it was because of another thing that caused the pain.
[cpg]

Let's just sleep like this for the rest of the day.
[cpg]


[SE f="se016"]
;//【ＳＥ】入室

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0412"]
[OnName num="sayo"]
"It's me. Are you awake?
[cpg cn=true]


[OnName num="masato"]
''Ha, yes. Go ahead.
[cpg cn=true]


[OnName num="masato"]
At least knock, please.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0413"]
[OnName num="sayo"]
Huh? Why? You're in your servant's room and I have to knock on your door?
[cpg cn=true]


He's more pissed off than I've ever seen him.
[cpg]


[VOICE f="Sayo0414"]
[OnName num="sayo"]
I'm sorry about this time of day.
[cpg cn=true]


[OnName num="masato"]
No...
[cpg cn=true]


I was about to get up to get a chair or something, but he restrained me from doing so with his hand.
[cpg]

She stands and speaks.
[cpg]

[BGM f="se" time=1000]
[FG f="CHA01_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0415"]
[OnName num="sayo"]
Why didn't you tell me...?
[cpg cn=true]


I immediately knew that what she was referring to was a dog bite.
[cpg]

That's right...that time I tried to stop Brunark and got bitten by a golden ball.
[cpg]

That's why today's torment was so much more painful.
[cpg]

[OnName num="masato"]
It was... an accident. Besides, it's my own fault.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0416"]
[OnName num="sayo"]
...take it off.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo0417"]
[OnName num="sayo"]
Just do it!
[cpg cn=true]


I was forcibly made to look embarrassing again.
[cpg]

I take off my clothes as I'm told, and Master applies the drug that he brought to me...to my pubic area.
[cpg]

[OnName num="masato"]
Um...I'm really embarrassed.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0418"]
[OnName num="sayo"]
You're always dressed like this. Why are you embarrassed?
[cpg cn=true]


[OnName num="masato"]
''No, I was embarrassed to think that I was exposing my lower body, even though I was being gently drugged, unlike usual...''
[cpg cn=true]


[FG f="CHA01_p4_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0419"]
[OnName num="sayo"]
What do you mean I'm not nice?
[cpg cn=true]


[OnName num="masato"]
It's in vain!
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0420"]
[OnName num="sayo"]
Hmph. You're such a pervert that you're more happy to be rough than to be nice.
[cpg cn=true]


I'm sorry.
[cpg]

[OnName num="masato"]
It hurts.
[cpg cn=true]


He was slapped lightly.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo0421"]
[OnName num="sayo"]
I'm sorry... I'm sorry I lost my temper too...
[cpg cn=true]


[OnName num="masato"]
"Oh, no, Master. Please don't apologize.
[cpg cn=true]


[VOICE f="Sayo0422"]
[OnName num="sayo"]
I've punished her well. I'll have to discipline him again.
[cpg cn=true]


The punishment is a cheap meal for a week, but I don't think it's much of a punishment...
[cpg]

[FG f="CHA01_p4_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0423"]
[OnName num="sayo"]
Yes, I'm done.
[cpg cn=true]


[OnName num="masato"]
Thank you very much
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0424"]
[OnName num="sayo"]
Have a good rest. If the swelling hasn't gone down yet, I'll apply it again. And the hospital.
[cpg cn=true]


[OnName num="masato"]
''No, it's okay. I'm sure you'll be fine tomorrow.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0425"]
[OnName num="sayo"]
I'll see you tomorrow.
[cpg cn=true]


[OnName num="masato"]
Yes. Good night, sir.
[cpg cn=true]

[SE f="se017"]
;//【ＳＥ】退室

[FO pos="2/3" time=1000]
With that said, Master walked out of the room.
[cpg]

It's a strange feeling. I'm somehow happy to see a slightly different master than usual.
[cpg]


[BG f="black.ui" time=1000]
;//ＢＫ


[STOPBGM]
[BGM f="d1"]
[BG f="b_02_1.ui" time=1000]
;//【ＢＧ】『豪邸、ダイニング』（朝）******************************************************


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo0426"]
[OnName num="sayo"]
Good morning. How's it going?
[cpg cn=true]


[OnName num="masato"]
Yes, I'm totally fine now.
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo0427"]
[OnName num="sayo"]
That's good to hear.
[cpg cn=true]


I felt like I'd closed the distance between me and the master one more step.
Whether as a servant or a pet is unclear...
[cpg]

[STOPBGM]

[window target=false]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ


[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]



[jump storage="ep009.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////
