*start

;#################################################
*Ep013|M-man style
;#################################################

[SCENE id=13]


[stflag jump_scene=0]
[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

[BGM f="se"]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夜）******************************************************

[window target=true]


The master has been in a bad mood lately.
[cpg]

That's when her marriage to the man became a concrete, near-future event.
[cpg]

Every day... the Master is not as strong as he once was.
[cpg]

[OnName num="masato"]
"But... what can I do?"
[cpg cn=true]


The reality is that no matter how much you think about her or worry about her, you can't be helpful.
[cpg]


I'm just a servant. No, a servant... or a pet... what can a man do?
[cpg]


[SE f="se016"]
;//【ＳＥ】『窓を開ける』ガチャギギギ



[BG f="b_07_4.ui" time=1000]
;//【ＢＧ】『空』（夜）******************************************************


[OnName num="masato"]
Sigh...the wind feels good. Hmm...?
[cpg cn=true]





[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BGM f="sl" time=1000]
[BG f="b_03_4.ui" time=1000]
;//【ＢＧ】『分岐路のある道』（夜）******************************************************
;//※街の中心や住宅街（小夜宅がある方面。小夜宅は小高い丘の上にある）への分岐路がある道


[SE f="se042"]
;//【ＳＥ】『走る』タタタ


[OnName num="masato"]
Mr. Tanaka.
[cpg cn=true]


[OnName num="butler"]
"Oh, Mr. Masato. What can I do for you this late at night?
[cpg cn=true]


[OnName num="masato"]
No...I saw Tanaka-san...so...
[cpg cn=true]


[OnName num="butler"]
I see. It's a nice breeze today, so I thought I'd take a little walk.
[cpg cn=true]


[OnName num="masato"]
May I join you?
[cpg cn=true]


[OnName num="butler"]
Of course. I'd be less bored if I had someone to talk to.
[cpg cn=true]


[OnName num="masato"]
Yes, sir.
[cpg cn=true]


We go for a walk while chatting.
[cpg]

[OnName num="masato"]
Um, Mr. Tanaka...
[cpg cn=true]


[OnName num="butler"]
What is it?
[cpg cn=true]


[OnName num="masato"]
"It's about your master...
[cpg cn=true]


[OnName num="butler"]
「……」
[cpg cn=true]




[BG f="black.ui" time=1000]
;//ＢＫ






[BG f="b_03_4.ui" time=1000]
;//【ＢＧ】『分岐路のある道』（夜）******************************************************


[OnName num="butler"]
Would you like some coffee?
[cpg cn=true]


[OnName num="masato"]
Yeah.
[cpg cn=true]




[SE f="se069"]
;//【ＳＥ】『缶コーヒーを買う』ピッ、ガタンッ


[OnName num="masato"]
Thanks.
[cpg cn=true]




[SE f="se070"]
;//【ＳＥ】『缶コーヒーを開ける』プシュッ


[OnName num="butler"]
''Hmmm. When you drink like this, even a canned coffee is pretty good.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


[OnName num="butler"]
''I've been thinking about you, Miss. And, of course, the Master.
[cpg cn=true]


With a cup of coffee in his hand, Tanaka-san began to talk.
[cpg]

[OnName num="butler"]
I wish there was some good way to do this, but I can't think of anything... at all.
[cpg cn=true]


[OnName num="masato"]
Me too...
[cpg cn=true]


Even I, a dull person, somehow understood.
[cpg]

Mr. Tanaka had been thinking about it, too. I'm feeling the wind today, taking a walk...about that house.
[cpg]

[OnName num="masato"]
But...isn't this the right thing to do? Tanaka-san feels the same way, doesn't he!
[cpg cn=true]


[OnName num="butler"]
I don't...I don't think you're wrong, sir.
[cpg cn=true]


[OnName num="masato"]
What?"
[cpg cn=true]


[OnName num="butler"]
The master didn't make his decision so easily. Thinking, suffering...and then making a decision. As a steward, I can't...deny that.
[cpg cn=true]


[OnName num="masato"]
"Ugh..."
[cpg cn=true]


Indeed, it is. I only think about the poor master or something like that.
[cpg]

I'm sure the answer to this question was based on the house's position, the company's, and many other considerations.
[cpg]

[OnName num="masato"]
''But... but... but... then the master...''
[cpg cn=true]


[OnName num="butler"]
''The young lady has been prepared for this for a long time. And the Master.
[cpg cn=true]


[OnName num="butler"]
That's why I've given the young lady so much of what she wants and so much love.
[cpg cn=true]


[OnName num="butler"]
''The young lady honed herself and her husband for the sake of the house. One day it will come, for this time...
[cpg cn=true]


[OnName num="masato"]
「……」
[cpg cn=true]


[OnName num="butler"]
Well, because of that...I did a lot of reckless things. Especially welcoming you to the mansion and all that...ho ho.
[cpg cn=true]


[OnName num="butler"]
''I don't want the master or the young lady in my heart. But both of you are convinced.
[cpg cn=true]


[OnName num="masato"]
I don't know what that is.
[cpg cn=true]


[OnName num="butler"]
'Yeah...I don't really know either.
[cpg cn=true]


[OnName num="masato"]
"I don't want you and your husband to do something you really don't want to do...
[cpg cn=true]


[OnName num="butler"]
But we don't have a plan to counteract that...nor do we.
[cpg cn=true]


[OnName num="butler"]
Otherwise, I wouldn't have the right to tell you what to do.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


Tanaka's tone of voice intensified. Yes, if I could do something about it, at any cost, I would have done it long ago.
[cpg]

If it's the master, if it's the daughter, if it's Mr. Tanaka...if it's the servants of that house...
[cpg]

It's a roundabout circle with no answers.
[cpg]

[OnName num="masato"]
"............................................................"
[cpg cn=true]


[OnName num="butler"]
"?"
[cpg cn=true]


[OnName num="masato"]
"If only there were no more men to choose from...
[cpg cn=true]


[OnName num="butler"]
Mr. Masato. You can't do that.
[cpg cn=true]


[OnName num="masato"]
Because...I can't think of anything else! Isn't Tanaka-san the same!
[cpg cn=true]


[OnName num="butler"]
"Nevertheless, I don't think it would be prudent to jump into that choice so easily."
[cpg cn=true]


[OnName num="butler"]
"More than anything else... you'll be sad, miss."
[cpg cn=true]


[OnName num="masato"]
"Hmmm..."
[cpg cn=true]

At the end of the day, I'm not going to be much help.
[cpg]


[OnName num="butler"]
It's getting cold, isn't it? It's time to go back.
[cpg cn=true]





[BG f="black.ui" time=1000]
;//ＢＫ





[STOPBGM]
[BGM f="se" time=1000]

[BG f="b_03_4.ui" time=1000]
;//【ＢＧ】『分岐路のある道』（夜）******************************************************


[SE f="se005"]
;//【ＳＥ】『歩く』コツコツ


[OnName num="masato"]
「……」
[cpg cn=true]


[OnName num="butler"]
Can I say one thing to myself?
[cpg cn=true]


[OnName num="masato"]
「？」
[cpg cn=true]


[OnName num="butler"]
"The young lady didn't go out much since she was a child. They'll hardly ever leave the house except when they go to school."
[cpg cn=true]

That's right. The Master was always at home.
[cpg]


[OnName num="butler"]
"That would have been a desire to distract from the future, which was already set."
[cpg cn=true]


[OnName num="butler"]
"To your daughter, the man she is marrying is an object of fear. When you're at home, there's infinitely less chance of your own being touched by those eyes."
[cpg cn=true]


[OnName num="butler"]
I think that's why you don't leave the house, sir.
[cpg cn=true]


[OnName num="butler"]
"Well, you're a recluse, aren't you? Ho-ho-ho."
[cpg cn=true]

Mr. Tanaka sometimes says harsh things in a straightforward manner.
[cpg]


[OnName num="butler"]
"I was worried about such a young lady too. But...at some point, I realized that it wasn't a bad thing."
[cpg cn=true]


[OnName num="masato"]
"Not bad...?"
[cpg cn=true]


[OnName num="butler"]
"Yes, Not since you came to this mansion."
[cpg cn=true]


[OnName num="butler"]
"In all honesty, I have no idea where the horse's bones are, and I've been thinking that there's an extreme pervert, a social outcast, and a sexual ape in the mansion."
[cpg cn=true]


[OnName num="masato"]
"I've been told I'm going to be fucked up! Or rather, I didn't feel so good about it, did I?!"
[cpg cn=true]


[OnName num="butler"]
Yeah. We were wondering how we were going to get them out of the house.
[cpg cn=true]


[OnName num="masato"]
"K, she hated me...then that smile at that time...that gentle response...ahhhhh...I'm going to be distrustful of people..."
[cpg cn=true]


[OnName num="butler"]
Ho ho ho. It was a long time ago, wasn't it? In the beginning, I mean.
[cpg cn=true]


[OnName num="masato"]
"Ugh... something doesn't make sense."
[cpg cn=true]


[OnName num="butler"]
"...but unlike what we thought... the young lady seemed to be having fun every day. I feel like I'm smiling a lot more... that's how I feel."
[cpg cn=true]


[OnName num="butler"]
"Well, I've pissed him off just as much."
[cpg cn=true]

It's painful to hear these little tidbits coming in from time to time.
[cpg]


[OnName num="butler"]
"Yes, really...the Lady is enjoying herself every day. It's thanks to Masato-dono."
[cpg cn=true]


[OnName num="butler"]
"I'm glad you're here. I think so now.
[cpg cn=true]


[OnName num="masato"]
Mr. Tanaka...
[cpg cn=true]


[OnName num="butler"]
"We, the servants, can't just listen to orders. While following the Lord's will, we help them when they are in trouble and admonish them when they go astray."
[cpg cn=true]

Together we rejoice, suffer, and trust each other. Because otherwise, it's all just a matter of the machines doing it.
[cpg]


[OnName num="butler"]
"We will do the Lord's will, but we will also help people when they are in trouble and admonish them when they are going the wrong way. Together we rejoice, we suffer, and we trust each other."
[cpg cn=true]


[OnName num="butler"]
Otherwise, it's just a matter of having the machine do everything."
[cpg cn=true]


[OnName num="butler"]
"However, as I said earlier... we cannot easily disagree with the Lord's decision."
[cpg cn=true]


[OnName num="butler"]
"Dear Masato..."
[cpg cn=true]


[OnName num="masato"]
"Yes"
[cpg cn=true]


[OnName num="butler"]
"You're a butler, aren't you? Could it be a maid? Or... is it just a pet?"
[cpg cn=true]


[OnName num="masato"]
"………"
[cpg cn=true]


[OnName num="butler"]
"You have to be there for her."
[cpg cn=true]

Finally, I understood what Mr. Tanaka was trying to say.
[cpg]

I don't know if I can say it myself, but I'm just a pervert. They don't get a regular job, but they are excluded from society.
[cpg]

It is a pervert who is pleased to be bullied by the girl who looks childish like a master. He's a bastard, if you ask me.
[cpg]


[OnName num="masato"]
"Thank you, Mr. Tanaka."
[cpg cn=true]

But I'm not like that in that house. They are out of the ordinary, There are no strings attached.
[cpg]

That's why there are things we can think about... things we can do...
[cpg]

I thought that the look he gave me was filled with such expectation.
[cpg]


[OnName num="masato"]
"I... will do my best."
[cpg cn=true]

He smiles back.
[cpg]


[OnName num="butler"]
"Ho ho. Well, that's... that's a very reliable word."
[cpg cn=true]

He smiled back at me.
[cpg]


[OnName num="butler"]
Please take good care of your daughter.
[cpg cn=true]

He bowed to me deeply, and I thanked him wordlessly.
[cpg]


[OnName num="masato"]
I'll go back first!
[cpg cn=true]


[OnName num="butler"]
Yes."
[cpg cn=true]

As I was about to start running, I noticed one thing that bothered me.
[cpg]


[OnName num="masato"]
"Speaking of which, Tanaka-san and the others...you've trusted me well. Even if Master says it's because he's having fun..."
[cpg cn=true]


[OnName num="butler"]
"I could see that you are a good person at heart. He's just a dopey pervert...right?"
[cpg cn=true]


[OnName num="masato"]
"Ah-ha-ha..."
[cpg cn=true]

I was so happy to hear you say that.
[cpg]


[OnName num="butler"]
"But after all, the place where you think too much about things with your lower body... is troubling, isn't it?
[cpg]

Especially if you're playing too kinky! And it's hard to clean the room! The cost of new sheets won't be a fool's errand!"
[cpg cn=true]


[OnName num="masato"]
"Don't go any further, I'm going to die of shame...!"
[cpg cn=true]


[OnName num="butler"]
"I'd like you to take firm responsibility for being the cause of leading the young lady to an abnormality, but..."
[cpg cn=true]


[OnName num="masato"]
I'm sorry, I'm sorry!
[cpg cn=true]

In many ways, I have to make up my own mind about this.
[cpg]


[OnName num="masato"]
"Well, it's... well, I don't want you to expect too much, but it would be nice if... well, you'd be there like you're on a medium-sized ship."
[cpg cn=true]


[OnName num="butler"]
Ho ho. Even a medium-sized one will not be beaten by a large one, depending on how you steer it.
[cpg cn=true]


[OnName num="masato"]
Yes, I'll try to do something about it!
[cpg cn=true]



[SE f="se042"]
;//【ＳＥ】『走りだす』ダダッ


With that said, I started to run.
[cpg]


[OnName num="masato"]
"And? We're just a bunch of perverts like you and me... but there's no such thing as a bad man! That's what I'm talking about!"
[cpg cn=true]


[OnName num="butler"]
"Ho ho ho."
[cpg cn=true]




[SE f="se042"]
;//【ＳＥ】『走る』ダッダッダッ



[BG f="b_07_4.ui" time=1000]
;//【ＢＧ】『空』（夜）******************************************************



[BG f="black.ui" time=1000]
;//ＢＫ





[BG f="b_03_4.ui" time=1000]
;//【ＢＧ】『分岐路のある道』（夜）******************************************************


[OnName num="butler"]
"........."
[cpg cn=true]


[OnName num="butler"]
"Hoho, hoho, hoho."
[cpg cn=true]



[SE f=se084]
;//【ＳＥ】『チーン』
[BG f="black.ui" time=3000]
[WAIT time=3000]


[STOPBGM]

;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=1]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse



[jump storage="ep014.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////
