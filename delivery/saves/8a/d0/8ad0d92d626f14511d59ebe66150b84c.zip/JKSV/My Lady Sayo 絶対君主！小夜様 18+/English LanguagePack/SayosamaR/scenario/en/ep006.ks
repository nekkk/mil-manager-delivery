*start


;#################################################
*Ep006|M is easily misunderstood.
;#################################################

[SCENE id=6]


[stflag jump_scene=0]
;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


Even though it was a mistake, I peeked into my master's underwear.
[cpg]


;//●ＣＧエロ（主人公＆小夜・仰向けで壁に背を預けてる感じ。言葉責めをされながら足コキ。蹴り、ちん踏みで射精：屋敷廊下）ev_19
;//ご主人様は下着姿のまま


[SE f="se039"]
;//【ＳＥ】『突き飛ばされる』ドンッ

[BGM f="h1"]
;**【ＣＧ】ev_19_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[VOICE f="Sayo0237"]
[OnName num="sayo"]
You infidel, peeking into my change of clothes.
[cpg cn=true]


[OnName num="masato"]
Ugh!
[cpg cn=true]


The master's masterful kick burst out into the hallway.
And then, he stomps his crotch as it is.
Gurrii.
[cpg]

[OnName num="masato"]
Ugh.
[cpg cn=true]


[VOICE f="Sayo0238"]
[OnName num="sayo"]
This lower body animal!
[cpg cn=true]


[OnName num="masato"]
Excuse me! But it's a misunderstanding!
[cpg cn=true]


I won't deny the lower body animal part though.
[cpg]


[VOICE f="Sayo0239"]
[OnName num="sayo"]
What's the misunderstanding? See... it's getting bigger here.
[cpg cn=true]


[OnName num="masato"]
"Well, that's..."
[cpg cn=true]


[VOICE f="Sayo0240"]
[OnName num="sayo"]
Well, I don't know if it's getting bigger at all because the original is too small.
[cpg cn=true]


[OnName num="masato"]
It's terrible!
[cpg cn=true]


[VOICE f="Sayo0241"]
[OnName num="sayo"]
"No, no, no... That's how you get stepped on, and you're a happy pervert!
[cpg cn=true]


The weight is put on it and the meat rod is stepped on.
[cpg]

;**【ＣＧ】ev_19_a ***********************
[CG id=18 index=1 time=1000]
;***************************************

[VOICE f="Sayo0242"]
[OnName num="sayo"]
No!
[cpg cn=true]


[SE f="se040"]
;//【ＳＥ】『蹴り』ベシンッ


[VOICE f="Sayo0243"]
[OnName num="sayo"]
It feels good, doesn't it? I'm going to kick you a lot!
[cpg cn=true]


[VOICE f="Sayo0244"]
[OnName num="sayo"]
Here we go, here we go, here we go, here we go, here we go.
[cpg cn=true]


Master moved his legs as he verbally tormented her to defuse her pent.
Because this is a corridor, it is embarrassing that the maids are looking at us for some reason.
[cpg]


[SE f="se040"]
;//【ＳＥ】『蹴り』ベシンッ


[VOICE f="Sayo0245"]
[OnName num="sayo"]
I see, I see, I see!
[cpg cn=true]




[SE f="se040"]
;//【ＳＥ】『蹴り』ベシンッ


[OnName num="masato"]
''Ugh, Ugh...''
[cpg cn=true]

[SE f="se040"]
;//【ＳＥ】『蹴り』ベシンッ


Despite the fact that I was being kicked in the pubic area with all my might, I was delighted with the sexual pleasure I was getting.
[cpg]


[VOICE f="Sayo0246"]
[OnName num="sayo"]
I'm not ashamed to be a man with such a little thing hanging around.
[cpg cn=true]


[VOICE f="Sayo0247"]
[OnName num="sayo"]
Stomp on it with all your might and I'll make your no-good dick a little better!
[cpg cn=true]


Grrrrrrrrrr.
[cpg]

[OnName num="masato"]
Ughhhhhhhhhh!
[cpg cn=true]


[VOICE f="Sayo0248"]
[OnName num="sayo"]
"I'll give you a good look at the dirty cum coming out of your garbage cock.
[cpg cn=true]




[SE f="se026"]
;//【ＳＥ】『射精音』


;**【ＣＧ】ev_19_b ***********************
[CG id=18 index=2 time=1000]
;***************************************

-- swoosh, swoosh, swoosh.
[cpg]

[VOICE f="Sayo0249"]
[OnName num="sayo"]
''Huh, it stinks. It's not a dick, it's just a dirty dick.
[cpg cn=true]


Let's make sure she's getting dressed from now on and go into the room...
[cpg]


;//ＢＫ


[SCENE id=5]
[ENDPARTIAL]

[window target=false]


[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[WAIT time=500]

[window target=true]


[jump storage="ep007.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
