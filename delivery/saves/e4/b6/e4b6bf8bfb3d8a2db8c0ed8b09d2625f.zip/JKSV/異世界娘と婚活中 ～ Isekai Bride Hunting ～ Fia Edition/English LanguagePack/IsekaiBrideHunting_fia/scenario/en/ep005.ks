
;//==============================
;//１、フィア

*start

*ep003
*IseSel09_1|Demon Lord・Fia

[SCENE id=3]


Fia. I want to make her my queen.
[cpg]


With that in mind, I decide to go to Fia’s room.
[cpg]



[window target=false]

;//ブラックアウト
[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=2000]

[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（夜）******************************************************


[window target=true]



[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia318"]
[OnName num="fia"]
“...... What is it? At this time of night?”
[cpg cn=true]


[OnName num="kousuke"]
"I have a few things to discuss."
[cpg cn=true]


I explained to her that I was determined to conquer this world.
[cpg]


The expression on Fia's face becomes clouded. I'm sure the pacifist in her won't agree with that.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia319"]
[OnName num="fia"]
“I think there are ways to live in peace without ...... world domination.”
[cpg cn=true]


[OnName num="kousuke"]
“Are you defying me? The Demon Lord?”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia320"]
[OnName num="fia"]
“......I can't do it. I want peace.”
[cpg cn=true]


I might not be able to keep Fia around me for any longer.
[cpg]


Even though I think that, I still want Fia to be my queen.
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト


[BG f="b_11_4.ui" time=1000]
[WAIT time=1500]



[OnName num="kousuke"]
"Not a ...... mate, but a queen."
[cpg cn=true]

I thought about it in my head, and it felt right.
[cpg]

We are attracted to each other because of our conflicting thoughts.
[cpg]

;//Ｈシーンカット


;//ブラックアウト


[WAIT time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************






The next day. I gather the four of us together and decided to talk about what we were going to do.
[cpg]


[OnName num="kousuke"]
“I've already told Fia, but my plan is to take over the world so that we can live in peace.”
[cpg cn=true]


The four of us are silent for a moment, but then Chartier speaks up.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Schartye333"]
[OnName num="schartye"]
“That's what the Demon Lord is all about.”
[cpg cn=true]


And then she clapped. Kullulu also clapped.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Clolowlude260"]
[OnName num="clolowlude"]
“My arms are ringing. I'm sure you can handle any kind of magic, so ...... I'll teach you.”
[cpg cn=true]





[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="sMeile046"]
[OnName num="meile"]
"Yeah, why not? I'll go along with whatever Kosuke wants to do."
[cpg cn=true]


Meir seems to respect my opinion.
[cpg]




On the other hand, Fia is confused. Only one person seems to have a different opinion.
[cpg]

[free time=1000]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=1000]
[VOICE f="Fia343"]
[OnName num="fia"]
“I'm against it. As I said yesterday, Kosuke ..."
[cpg cn=true]


[OnName num="kousuke"]
“I'm going to do it even if you disagree. I just wanted to let you know. I’m not asking for your opinion.”
[cpg cn=true]


Fia couldn't say anything and her shoulders slumped.
[cpg]



[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





I then worked with Chartier and Kullulu to develop magic for the military.
[cpg]


Even though Fia had knowledge of magic and could have helped, she did not.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Schartye334"]
[OnName num="schartye"]
“This might be how the power can increase.”
[cpg cn=true]


[FACE method="change_2" pos="2/2"]
[VOICE f="Clolowlude261"]
[OnName num="clolowlude"]
“Chartier, there's no need to go overboard with the power here, a half-kill would be fine.”
[cpg cn=true]


Chartier and Kullulu respond to my suggestion with some crazy replies, but ......
[cpg]


What I had asked for was out of the ordinary in the first place. Finally, I was about to become a real Demon Lord.
[cpg]



;//ブラックアウト

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_3.ui" time=1000]

[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夕方）******************************************************





[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia344"]
[OnName num="fia"]
“…… I'm not convinced."
[cpg cn=true]


I'm sure she isn’t. She might have thought that being loved by me was something she had to ignore.
[cpg]

[OnName num="kousuke"]
“I'll keep saying I love you until you feel the same way Fia.”
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="sFia030"]
[OnName num="fia"]
“Why would I feel the same way? No matter how many times you tell me.”
[cpg cn=true]

[OnName num="kousuke"]
“I don't know. I just like you.”
[cpg cn=true]

She didn't reply. But that was in her way an answer.
[cpg cn=true]

Fia doesn’t know what to do. She doesn’t want to get rid of me.
[cpg cn=true]


;//ブラックアウト


;//Ｈシーンカット

;//Ｈシーンカット


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]


[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************



[OnName num="kousuke"]
“I'm thinking of invading the land of the elves soon ……."
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia394"]
[OnName num="fia"]
“The time has come.”
[cpg cn=true]


Fia has an unhappy expression on her face. It makes sense.
[cpg]


We were going to invade her home country.
[cpg]


It's not like I'm trying to destroy everything and kill everyone.
[cpg]


I'm also trying to create magic that can even diminish our abilities to fight.
[cpg]


I still thought it would be better to have as few deaths as possible.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia395"]
[OnName num="fia"]
“Kosuke, I have a favor to ask of you.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia396"]
[OnName num="fia"]
“The land of the elves is my home. So…"
[cpg cn=true]


[OnName num="kousuke"]
" Fia . It doesn't matter if you stop me.”
[cpg cn=true]


[OnName num="kousuke"]
“I just thought I'd tell you before anyone else does.”
[cpg cn=true]


Fia said nothing and looked down.
[cpg]



;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="162.jpg" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="162.jpg" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]


[WAIT time=100]
;//【ＢＧ】『城内＿廊下』（昼）******************************************************


[window target=true]



The next day. I had gather the four of us together.
[cpg]


They all seemed to sense that I had decided.
[cpg]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[STOPBGM]
[WAIT time=500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[OnName num="kousuke"]
“I've perfected a new spell. It’s tentatively named Sleep Magic."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye335"]
[OnName num="schartye"]
"Oh, come on. You couldn’t have perfected it without my help.”
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Clolowlude262"]
[OnName num="clolowlude"]
“Oh let it be. He just wants to say that out loud.”
[cpg cn=true]


Chartier interjects. But that's not the main point.
[cpg]


[OnName num="kousuke"]
“It will have a tremendous effect on the battlefield. It's the kind of magic that will reduce ones energy enough so that they cannot move.”
[cpg cn=true]


[OnName num="kousuke"]
“It's also very far-reaching. If I go in alone, and then call in the soldiers ……"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile353"]
[OnName num="meile"]
"It might be able to neutralize any country. Not that I fully understand."
[cpg cn=true]


[OnName num="kousuke"]
“I think the first place I'm going to use this magic is in the land of the elves.”
[cpg cn=true]


Fia bites her lips. I can understand how she might feel.
[cpg]


[OnName num="kousuke"]
"I'm sorry Fia , but ...... It is the country that is most hostile to me. I want to take it down first."
[cpg cn=true]

;//;[FO layer="2/2"]



[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sFia031"]
[OnName num="fia"]
"You mean ...... war, right?"
[cpg cn=true]


[OnName num="kousuke"]
“I don't want to kill them. It's more efficient to capture them and turn them into soldiers.”
[cpg cn=true]


Fia disagrees. Everyone senses it.
[cpg]


[OnName num="kousuke"]
" Fia . You still don't like it?”
[cpg cn=true]


[FACE method="change_7" pos="2/2"]
[VOICE f="Fia397"]
[OnName num="fia"]
"......, of course not.”
[cpg cn=true]


It was a natural response. Even if you don't go around killing people, it's still a conquest.
[cpg]


My relationship with Fia may one day prevent me from conquering the world.
[cpg]


I wonder what I'll do then. I just want to live in peace with Fia .
[cpg]


But if Fia disappears, that goal itself will be lost.
[cpg]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile354"]
[OnName num="meile"]
"Well, well, there's no use to think about it. If we don't do something, we might be invaded, right?"
[cpg cn=true]


[OnName num="kousuke"]
"Yeah. You're right. We're not going to do nothing.”
[cpg cn=true]



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Schartye336"]
[OnName num="schartye"]
“That's reassuring. You're begining to look like a Demon Lord.”
[cpg cn=true]


Chartier smiled at that. Kullulu was smiling too.
[cpg]


Fia still seems upset.
[cpg]

[free time=800]

[OnName num="kousuke"]
“Fia . Let's go outside for a bit.”
[cpg cn=true]


[FACE method="change_5" pos="2/2"]
[VOICE f="Fia398"]
[OnName num="fia"]
“Sure ……."
[cpg cn=true]



;//ブラックアウト

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************

;//＠
[SE f="se011"]
;//【ＳＥ】『人混み』

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

I take Fia out into the city.
[cpg]


This city is full of activity. It may be a result of the ambition of the lower-ranking subordinates to reverse their position.
[cpg]


Or maybe they're simply expecting me to do the same.
[cpg]


Either way, these are the people who will be my supporters.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia399"]
[OnName num="fia"]
"...... I'm still not sure. Do we really need to invade the land of the elves?"
[cpg cn=true]


[OnName num="kousuke"]
“If we don't, we will be attacked. Wouldn't you be sad if I died?”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia400"]
[OnName num="fia"]
“I don't think they'd kill you.”
[cpg cn=true]


[OnName num="kousuke"]
“They might seal me. Either way, it's like dying."
[cpg cn=true]


Fia falls silent. I was supposed to convince her, but it turned into an argument.
[cpg]


I don't want to do this either.
[cpg]


[OnName num="kousuke"]
“This is a complicated situation. This is about more than just a racial barrier right?”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia401"]
[OnName num="fia"]
“Yes. It’s because you’re a Demon Lord.”
[cpg cn=true]


We may have to curse our fate. But,
[cpg]


[OnName num="kousuke"]
“But if I wasn't the Demon Lord, I wouldn't have been able to get together with you Fia ."
[cpg cn=true]


Fia looks a little sad. She seemed to be pessimistic about this fate.
[cpg]


[OnName num="kousuke"]
"Let's walk the streets. I'm sure you can tell what the demi-humans want."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_3.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『城下町＿魔王の国』（夕方）******************************************************



[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]


As we walk through the city, the demi-humans are talking amongst each other.
[cpg]


“It's not like they're going to invade Elf country yet, or even Japan if the king is from Japan.”
[cpg]


They seemed to be ready at any time. If anything, even the non-soldiers were bloodthirsty.
[cpg]


I guess that's how dissatisfied they were until now.
[cpg]


It was true that the country of the beastmen, unlike the country of the elves, could not be called a developed country.
[cpg]


It was impossible not to complain about being left behind by the rest of the world.
[cpg]


[OnName num="therianthropy_A"]
"You're developing a new magic, aren't you, Demon Lord?”
[cpg cn=true]


[OnName num="therianthropy_B"]
“Let's invade the land of the elves! If we can get the elves to follow us, we can really take over the world.”
[cpg cn=true]


[OnName num="kousuke"]
"You hear that, Fia ? This is what people are saying.”
[cpg cn=true]


[VOICE f="Fia402"]
[OnName num="fia"]
"I know, I know, but ……"
[cpg cn=true]


[OnName num="kousuke"]
“I'm not talking about destroying the land of elves. The land of the Demon Lord will only be their leader.”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia403"]
[OnName num="fia"]
“But you can't promise that you won't do terrible things to the ...... elves.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia404"]
[OnName num="fia"]
“Even if I did promise, I couldn’t say that it won’t happen.”
[cpg cn=true]


[OnName num="kousuke"]
“That’s a strong statement.”
[cpg cn=true]


I might be a strong statement, but I can sympathize. If I were in the same position, I might have argued that way.
[cpg]



;//ブラックアウト

[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





I was alone with Fia in my room.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia405"]
[OnName num="fia"]
"...... Kosuke . I don't understand anymore."
[cpg cn=true]


[OnName num="kousuke"]
“What don’t you understand? Why don't you just do as I say?”
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia406"]
[OnName num="fia"]
“My mind is a mess. ...... What can I do to help you, Kosuke ?”
[cpg cn=true]


[OnName num="kousuke"]
“It's obvious. I need your help.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia407"]
[OnName num="fia"]
“I can't ...... do that.”
[cpg cn=true]


[OnName num="kousuke"]
“You're a stubborn girl.”
[cpg cn=true]


She needed to be reminded, even in a rough way, that she was mine.
[cpg]

[OnName num="kousuke"]
“I love you, Fia. I think I know what you need.”
[cpg cn=true]

[OnName num="kousuke"]
"Don't hesitate. I'll give you whatever you want.”
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia408"]
[OnName num="fia"]
“...... I may be stubborn and strong-willed, but Kosuke you are pushy.”
[cpg cn=true]


[OnName num="kousuke"]
“Yeah, I know that.”
[cpg cn=true]

;//Ｈシーンカット

I had slowly come to understand that Fia was stubborn.
[cpg]

No matter how many times I tried to seduce her, tell her I loved her, or convince her that this was the only way, she would stay the same.
[cpg]


Which also made sense. Her mind would not change that easily.
[cpg]


[OnName num="kousuke"]
"...... Fia "
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia432"]
[OnName num="fia"]
"What is it......? I don't care how many times you say it, my opinion is the same.”
[cpg cn=true]


[OnName num="kousuke"]
"I know. I'm not asking you to accept it. But please forgive me.”
[cpg cn=true]


[OnName num="kousuke"]
“It's so that I can live without being hunted. That's why I have to ......."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia433"]
[OnName num="fia"]
“...... I can't respond to something like that.”
[cpg cn=true]


Fia has a troubled look on her face.
[cpg]


I also have an unsettling feeling. I don't know how many more times I can tell her.
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************





At night. I am alone in my room.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドアノック』





[OnName num="kousuke"]
"Who is it?"
[cpg cn=true]



[VOICE f="Schartye337"]
[OnName num="schartye"]
"It's me. Can I come in?
[cpg cn=true]


[OnName num="kousuke"]
“Yes. Come on in.”
[cpg cn=true]



[SE f="se002"]
;//【ＳＥ】『ドア開く』





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Schartye338"]
[OnName num="schartye"]
“You don't look so good, My Lord.”
[cpg cn=true]


Chartier didn't seem to be worried about me.
[cpg]


Rather, she looked as if she wanted to tell me not to hesitate now.
[cpg]


[OnName num="kousuke"]
“What is it that you want? ”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Schartye339"]
[OnName num="schartye"]
“My men are ready. And so are the men of Kullulu Urud.”
[cpg cn=true]


[OnName num="kousuke"]
“...... I see. It's time.”
[cpg cn=true]


I have to make up my mind. I'm going to invade the land where Fia used to live.
[cpg]



;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_02_2.ui" time=1000]

[WAIT time=1500]
[BGM f="bg_tc"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************

[window target=true]




I had come to the land of the elves earlier.
[cpg]


The magic of sleep. In the end, the provisional name became the name.
[cpg]


This magic works indiscriminately. The only way to make the mission work was for me to go in alone.
[cpg]


If they find out that I'm a Demon Lord and surround me, that would be the end of it.
[cpg]


I really need to leave Chartier and Kullulu in the Demon Lord's country.
[cpg]


If they were to fall asleep everything would be over.
[cpg]


[OnName num="kousuke"]
“Let's go ……."
[cpg cn=true]


It was a very one-sided development from there.
[cpg]


[SE f="se016"]
;//【ＳＥ】状態異常魔法

;//画面薄く赤色に
[BG f="red.ui" time=1000]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_de"]




Very few of them were resistant to magic. Some of the wizards noticed something was wrong and put up wards, but ......
[cpg]


They were outnumbered. We had soldiers on our side as well.
[cpg]


And on top of that, I have my magic. It was no longer a contest.
[cpg]


Not a single scream occurred, it was just a one-sided domination. The elven kingdom was neutralized in a matter of hours.
[cpg]

[window target=false]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト


;//色調元に戻る


[BG f="b_02_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（夜）******************************************************



[window target=true]


By the time night fell, the news had swept the world.
[cpg]


The land of the Demon Lord had invaded the land of the elves. They are steadily trying to take over the world. ......
[cpg]


I don't know if it's my reputation, or if it's my danger in the eyes of the world .......
[cpg]


In any case, I've become someone who can't be left alone, but I've also become someone who's difficult to deal with.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia434"]
[OnName num="fia"]
“...... Are you sure you want to do this?”
[cpg cn=true]


[OnName num="kousuke"]
“It's okay. We've captured all the soldiers and the people in the center of the country.”
[cpg cn=true]


[OnName num="kousuke"]
“We'll be able to control this country as we see fit. Maybe more demi-humans will come.”
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia435"]
[OnName num="fia"]
“I have mixed feelings about this....... It's my home.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia436"]
[OnName num="fia"]
“I can’t believe you’re doing this without negotiation."
[cpg cn=true]


[OnName num="kousuke"]
“You have to understand. There is no other way."
[cpg cn=true]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（昼）******************************************************





The next day, I return to the land of the Demon Lord.
[cpg]


After all, I feel more at home here. I left the control of the elven kingdom to my minions.
[cpg]


The minions are not Chartier or Kullulu , but those who were her subordinates.
[cpg]


There were plenty of people who were better than me at politics.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[OnName num="kousuke"]
" Fia . Don't look at me like that."
[cpg cn=true]


I walk with Fia who stays silent.
[cpg]


In the midst of this, one of the citizens stood in front of me.
[cpg]


It looked like a beast, but on closer inspection it was an elf.
[cpg]



[OnName num="elf_man"]
"How dare you do this to me, ......!"
[cpg cn=true]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

He had a blade in his hand. I immediately shielded Fia .
[cpg]


[SE f="se006"]
;//【ＳＥ】『魔法発動する』
[WAIT time=1000]

[OnName num="elf_man"]
"......! Phew!"
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『倒れる』
[WAIT time=1000]


[BG f="b_05_2.ui" time=1000]


The elf man collapsed on the spot. He was attacked from behind by someone.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clolowlude263"]
[OnName num="clolowlude"]
“It's not a good time to go out my Lord. You should not be walking around right now.”
[cpg cn=true]


[OnName num="kousuke"]
"...... I’m sorry.”
[cpg cn=true]


[free time=800]

[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
I look back at Fia with her eyes wide open.
[cpg]


[OnName num="kousuke"]
“Are you okay? You're not hurt, are you?”
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Fia437"]
[OnName num="fia"]
“...... I just remembered.”
[cpg cn=true]

[free time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="1/2" time=800]

[VOICE f="Clolowlude264"]
[OnName num="clolowlude"]
"Remembered? Remembered what?”
[cpg cn=true]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia438"]
[OnName num="fia"]
“We elves have a long life. I have met you in a previous life.”
[cpg cn=true]


[OnName num="kousuke"]
“What?”
[cpg cn=true]


She had remembered meeting the demon lord before he was reincarnated.
[cpg]


They say that the Demon Lord of those days, though abhorrent, had a gentle nature.
[cpg]



[FACE method="change_6" pos="1/2"]
[VOICE f="sFia032"]
[OnName num="fia"]
“I was about to get attacked by evil magic when you helped me out of the blue.”
[cpg cn=true]


Fia tells me that I had saved her before I was reincarnated.
[cpg]


[FACE method="change_1" pos="1/2"]
[VOICE f="Fia440"]
[OnName num="fia"]
“ Back then I told you that I wanted to thank you for saving me.”
[cpg cn=true]


[FACE method="change_1" pos="2/2"]
[VOICE f="Clolowlude265"]
[OnName num="clolowlude"]
"Hmm. What did the Demon Lord say then?”
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Fia441"]
[OnName num="fia"]
“He said he didn’t need anything ...... Instead, he said that if we meet again somewhere, I should help him ……"
[cpg cn=true]


[OnName num="kousuke"]
“……Oh, I see."
[cpg cn=true]


Fia had met me before I was reincarnated. I have no memory of it.
[cpg]


[OnName num="kousuke"]
“Forget about it. I'm not asking for your help.”
[cpg cn=true]


[FACE method="change_3" pos="1/2"]
[VOICE f="Fia442"]
[OnName num="fia"]
"No. I'm going to get you out. I'm going to help you Kosuke ."
[cpg cn=true]


Fia looked at me as if she had made a decision.
[cpg]


[OnName num="kousuke"]
“I said I don't want it.”
[cpg cn=true]



;//ブラックアウト
[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************



[FG f="CHA01_p5_01_a.ui" method="change_3"  pos="2/3" time=800]

Fia followed me to my room. She had said that she was going to help me.
[cpg]


[OnName num="kousuke"]
“If you're not going to do anything, don't force yourself to stay here.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia443"]
[OnName num="fia"]
“I'm ...... thinking about it right now. What's really going to help you?"
[cpg cn=true]


It's not like Fia to follow my lead without thinking. That's the part of her that I fell in love with.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト



Either way, my opinion will not change.
[cpg]

If I am the Demon Lord, I should act like a Demon Lord.
[cpg]


;//Ｈシーンカット



[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





[OnName num="kousuke"]
“Next, I'm going to declare war on humans.”
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia465"]
[OnName num="fia"]
“...... I see.”
[cpg cn=true]


[OnName num="kousuke"]
“My family is human, too. I want the whole world to be mine."
[cpg cn=true]


Fia 's expression only grew cloudier.
[cpg]


[OnName num="kousuke"]
“You're not convinced yet? I'd like to conquer as much of the world as possible in its original form.”
[cpg cn=true]


[OnName num="kousuke"]
“We'll try to minimize the number of deaths. That's why we're using magic to neutralize them. ……"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia466"]
[OnName num="fia"]
“...... Why can’t we just stop?”
[cpg cn=true]


[OnName num="kousuke"]
“Stop what? We can't go back now.”
[cpg cn=true]


I was a little annoyed by Fia and tried to do something different.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_06_2_l.ui" time=1000]
[WAIT time=1000]


[OnName num="kousuke"]
“Fia . Sit here, please.”
[cpg cn=true]

[VOICE f="sFia033"]
[OnName num="fia"]
"Yeah, ...... what?"
[cpg cn=true]

I sat her down right in front of me and pinned her down from behind. Then ......
[cpg]

I cast a summoning spell.
[cpg]


;//========================================
;//●ＣＧ（ヒロインが主人公のすぐ前に居る。さらにその前から触手が伸びている）ev_51
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//人ex２：触手　　　　服ex２：無し
;//場所　：城内＿主人公の部屋
;//時間　：昼
;//========================================

*Scene041

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』

[WAIT time=1000]

[SE f="se013"]
;//【ＳＥ】『触手絡みつく』

[BGM f="bg_h2"]
;**【ＣＧ】 ev_51_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sFia034"]
[OnName num="fia"]
“What the hell are you doing?”
[cpg cn=true]

[OnName num="kousuke"]
“Since you're not listening to me very well.”
[cpg cn=true]

[VOICE f="sFia035"]
[OnName num="fia"]
“Are you going to threaten me with this?”
[cpg cn=true]

She is still stubborn, or at least she is trying to be.
[cpg]

But her body seems to be trembling.
[cpg]

[OnName num="kousuke"]
“It's not that I'm trying to do anything. It's just that ……"
[cpg cn=true]

[OnName num="kousuke"]
“Tentacles are disgusting, aren't they? You don't want to just be touched.”
[cpg cn=true]

I tried to scare her but she wouldn’t move.
[cpg]

;**【ＣＧ】 ev_51_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia036"]
[OnName num="fia"]
“...... It’s fine. I don't care what you do to me.”
[cpg cn=true]

[VOICE f="sFia037"]
[OnName num="fia"]
"I'll accept anything, as long as I can change your mind."
[cpg cn=true]

[OnName num="kousuke"]
"......"
[cpg cn=true]

How stubborn can you be? It's not easy for me to do this.
[cpg]

I can't get what I want this way.
[cpg]

;//Ｈシーンカット


;//ブラックアウト


[STOPBGM]

[window target=false]
[transition target={true} rule="dark.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="dark.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************

[window target=true]




I decided to let the tentacles go.
[cpg]

Then Fia fell silent and said nothing.
[cpg]


[OnName num="kousuke"]
“Fia . You like me, don't you?"
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia485"]
[OnName num="fia"]
"...... Yes."
[cpg cn=true]


[OnName num="kousuke"]
“Why are you not following me? Isn't what I want what you want?”
[cpg cn=true]


She is silent again for a while. Then Fia says,
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia486"]
[OnName num="fia"]
“I've ...... figured out why I fell in love with you at first sight.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia487"]
[OnName num="fia"]
“Actually it wasn't really love at first sight. It’s because elves live long.”
[cpg cn=true]


She's talking about the me before I was reincarnated. She wants to say that the love began there.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia488"]
[OnName num="fia"]
“I know that you are really a kind person. I want you to be the real you again."
[cpg cn=true]


[OnName num="kousuke"]
“What do you mean the real me? I am the real me.”
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia489"]
[OnName num="fia"]
“No, you're not. Maybe you’re doing things that you don’t want out of the fear for your own life."
[cpg cn=true]


[OnName num="kousuke"]
“……"
[cpg cn=true]


I could not retaliate. I couldn't even deny it out of my own mind. ......
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BG f="b_06_3.ui" time=1000]
[WAIT time=1500]


[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





I then gathered the Meir and the other girls.
[cpg]


[OnName num="kousuke"]
“I'm declaring war on humans. If we could do it in Elfland, we can do it.”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Schartye340"]
[OnName num="schartye"]
"That's brave and good. I agree.”
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude266"]
[OnName num="clolowlude"]
“I agree. Though it may be a bit early.”
[cpg cn=true]


I knew these two would agree with me. The problem is, Fia…..
[cpg]

;//;[FO layer="2/2"]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sMeile047"]
[OnName num="meile"]
"Let's see, ...... Fia ."
[cpg cn=true]

Meir glanced around awkwardly. Fia did not say anything.
[cpg]

[FACE method="change_7" pos="1/2"]
[VOICE f="sMeile048"]
[OnName num="meile"]
“I think I agree....... Don't be reckless though. Everyone here loves you.”
[cpg cn=true]

It's not just the four of us. You can say that all the people in the country of the Demon Lord have placed their hopes in me.
[cpg]


I think I understand that.
[cpg]


;//ブラックアウト
[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_05_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城下町＿魔王の国』（夜）******************************************************



[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]


The final battle is near. With this in mind, Fia and I go outside.
[cpg]

[OnName num="kousuke"]
"Hey, Fia . "Do you still like me after all this?”
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

When I asked Fia that, her cheeks flushed without saying a word.
[cpg]

[OnName num="kousuke"]
“In the next battle, I might die. I don't plan on it, though."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]

[VOICE f="sFia038"]
[OnName num="fia"]
“I won't let that happen, ....... I will make sure that the fight itself does not happen.”
[cpg cn=true]

Fia is as stubborn as ever. We head to the woods.
[cpg]


[SE f="se008"]
;//【ＳＥ】『歩く』

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=100]
;//ブラックアウト





;//========================================
;//●ＣＧ（樹のそばに立っているヒロイン）ev_52
;//人物１：ヒロイン１　服装１：着衣
;//場所　：森の茂み
;//時間　：夜
;//========================================

*Scene042

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_52_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=100]


[VOICE f="sFia039"]
[OnName num="fia"]
“Uh, ...... Kosuke ?”
[cpg cn=true]

[OnName num="kousuke"]
“Stay there."
[cpg cn=true]

I close in on her. There's a tree behind her and she can't escape.
[cpg]

At least she doesn’t try to escape.
[cpg]

;**【ＣＧ】 ev_52_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia040"]
[OnName num="fia"]
"......"
[cpg cn=true]

And Fia closes her eyes. She understands me.
[cpg]

I'm sure she already knows what it means to be taken to a secluded place like this.
[cpg]

;//＠
[SE f="se001"]
;//【ＳＥ】衣擦れ

[WAIT time=1000]

Then I kissed her on the mouth.
[cpg]

Of course, it was a calculated move, thinking that she might listen to me.
[cpg]


;**【ＣＧ】 ev_52_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia041"]
[OnName num="fia"]
"I'm glad you're here, ....... Kosuke "
[cpg cn=true]

[OnName num="kousuke"]
"That's good. Fia , please stay by my side forever."
[cpg cn=true]

[VOICE f="sFia042"]
[OnName num="fia"]
“Yes. Yes, of course."
[cpg cn=true]


She said this, but lowered her eyes a little. I didn't know what that meant at the time.
[cpg]

;//Ｈシーンカット

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[BG f="b_11_4.ui" time=1000]
[WAIT time=1000]



Thinking about it, Fia must have been thinking about it a lot. I've destroyed Fia’s home country.
[cpg]


I guess they thought that if they left me alone, I might actually take over the world.
[cpg]


That’s exactly why all of this is happening.
[cpg]



[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]



[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（朝）******************************************************

[window target=true]




[OnName num="kousuke"]
“……"
[cpg cn=true]


I wake up alone. I thought I slept with Fia , but she was gone.
[cpg]


[STOPBGM]
[BGM f="bg_tc"]

[SE f="se009"]
;//【ＳＥ】『走る』

[WAIT time=1000]

[FG f="CHA02_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Meile356"]
[OnName num="meile"]
"Oh my god, Kosuke! Fia is gone!"
[cpg cn=true]


[OnName num="kousuke"]
"...... what?"
[cpg cn=true]



;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
[BG f="b_07_2.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『城内＿廊下』（昼）******************************************************





I wandered around looking for Fia . Of course, I wasn't the only one looking for her.
[cpg]


The whole castle is looking for Fia, but she's nowhere to be found.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMeile049"]
[OnName num="meile"]
“Maybe she has left the country……”
[cpg cn=true]


[OnName num="kousuke"]
“What do you mean? She can't do that by herself.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMeile050"]
[OnName num="meile"]
“It's possible, because some of the Harpy people want peace, not invasion.”
[cpg cn=true]


So those people helped her. Did Chartier and the others know about it and just let it happen?
[cpg]


No, now is not the time to blame them. Where did Fia go?
[cpg]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





Later that day, the harpy that had apparently carried Fia had returned.
[cpg]


[OnName num="kousuke"]
"...... you took Fia with you?"
[cpg cn=true]


[OnName num="harpy_woman"]
“ Yes, it was all Fia 's idea, and it was for the good of the country.”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye341"]
[OnName num="schartye"]
"I'm missing the point. Where is she.”
[cpg cn=true]


[OnName num="harpy_woman"]
“Fia is now in Japan to tell them that the Demon Lord and his country are going to invade.”
[cpg cn=true]


[OnName num="kousuke"]
“...... I see.”
[cpg cn=true]


I knew it would be something like that. She is trying to keep them from invading Japan.
[cpg]


But even if they did, I could still invade other countries.
[cpg]


This is only a temporary solution,……, I thought, but.
[cpg]


[free time=800]


[OnName num="harpy_woman"]
“Now, she is being held hostage in Japan.”
[cpg cn=true]


[OnName num="kousuke"]
“What?”
[cpg cn=true]


[OnName num="harpy_woman"]
“I'm also here to carry the Japanese demands.”
[cpg cn=true]


The main demand was the liberation of the Elven lands.
[cpg]


Another one was that there would be no further invasions.
[cpg]


If we break the promise, Fia will be dead.
[cpg]


But it’s also a promise that can be broken at any time if Fia only came back. ......
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Clolowlude267"]
[OnName num="clolowlude"]
"It's funny, ...... the story is going on under the assumption that the Demon Lord likes Fia ."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Meile357"]
[OnName num="meile"]
“I think Fia said it herself. That Kosuke likes her.”
[cpg cn=true]


[OnName num="kousuke"]
"What does that mean……..?”
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Meile358"]
[OnName num="meile"]
"It means she deliberately went to Japan to be a hostage."
[cpg cn=true]


The harpy woman nodded. I couldn't say anything.
[cpg]



[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Schartye342"]
[OnName num="schartye"]
What do we do now? What should I do, Demon Lord? If I give in here, I'll have to give up the land of the elves.
[cpg cn=true]


[OnName num="kousuke"]
“I've already decided on my answer. There is no substitute for Fia ."
[cpg cn=true]


[FACE method="change_5" pos="2/2"]
[VOICE f="Clolowlude268"]
[OnName num="clolowlude"]
“Hey! I've gone to a lot of trouble to rule the land of the elves.”
[cpg cn=true]


[OnName num="kousuke"]
“I don't care about that...... anymore. I knew that this would happen one day.”
[cpg cn=true]



;//ブラックアウト

[STOPBGM]

[window target=false]
[transition target={true} rule="cube.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_02_2.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『街＿エルフの国』（昼）******************************************************


[window target=true]



I decided to let go of the land of the elves.
[cpg]


It didn't take me long to make my decision.
[cpg]


I can say that it all started when I fell in love with Fia . ......
[cpg]


I felt that if the people I loved wanted peace, this was the way it had to be.
[cpg]

[STOPBGM]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





No more invasions. I also liberated the land of the elves.
[cpg]


I think the situation is worse than when this Demon Lord's country was established.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia515"]
[OnName num="fia"]
“I'm sorry for the trouble I caused Kosuke ……”
[cpg cn=true]


I was relieved when I saw that Fia had returned.
[cpg]


[OnName num="kousuke"]
“Do you know what's going to happen next Fia?”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Fia516"]
[OnName num="fia"]
"Yes, I do. I'll take any punishment I can get.”
[cpg cn=true]


My wish for world domination did not come true, but I was able to protect the people I cared about.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[SE f="se008"]
;//【ＳＥ】『歩く』

[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]



[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
I take Fia to the basement.
[cpg]


[OnName num="kousuke"]
“I'm going to, as you said, punish you.”
[cpg cn=true]


[OnName num="kousuke"]
“I'm not going to threaten you like I have in the past. You know that, right?”
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia517"]
[OnName num="fia"]
"...... Yes."
[cpg cn=true]


Then I thought about what Fia hates the most. It was time to try a new summoning spell.
[cpg]

;//Ｈシーンカット


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//＠地下室
[BG f="b_12_4.ui" time=1000]
[WAIT time=1000]

[OnName num="kousuke"]
“You don't seem to like bugs much, do you?”
[cpg cn=true]



[VOICE f="sFia043"]
[OnName num="fia"]
“Not many people would dare to ...... say they like them.”
[cpg cn=true]


[OnName num="kousuke"]
“You're honest. You know you're pushing yourself.”
[cpg cn=true]



[VOICE f="Fia540"]
[OnName num="fia"]
“Perhaps ……"
[cpg cn=true]


[OnName num="kousuke"]
“But I'm glad if you don't like it."
[cpg cn=true]


I said, and cast a summoning spell.
[cpg]


It's a magic I've never used before, and I don't know what it will do.
[cpg]


[OnName num="kousuke"]
"Here we go, Fia. If you stay sane, I will praise you."
[cpg cn=true]



;//========================================
;//●ＣＧ（大量のワーム状の虫が体中を這っている。膣に何匹も入り込まれるヒロイン）ev_54
;//人物１：ヒロイン１　服装１：着衣
;//人物ex：ワーム　　　服装ex：なし
;//場所　：城内＿地下室
;//時間　：夜
;//========================================

*Scene012

[BG f="black.ui" time=1000]
[free time=1000]
[STOPBGM]

[SE f="se005"]
;//【ＳＥ】『召喚魔法の音』

[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_54_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia044"]
[OnName num="fia"]
“Oh, my God. ...... Oh, my God.”
[cpg cn=true]

[OnName num="kousuke"]
“It's not just a bug. It's more like a slime.”
[cpg cn=true]

[OnName num="kousuke"]
“It's an individual that can grow on its own. If you wait long enough, it will multiply.”
[cpg cn=true]

[VOICE f="sFia045"]
[OnName num="fia"]
“No, no, no, ...... delete it, please.”
[cpg cn=true]

[OnName num="kousuke"]
“You said you'd accept to be punished. Now you're whining."
[cpg cn=true]

I said, and turned away.
[cpg]

[OnName num="kousuke"]
“I'll see you later. I'll let you out later so the least you can do is to take care of it for me.”
[cpg cn=true]

;**【ＣＧ】 ev_54_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=100]

[VOICE f="sFia046"]
[OnName num="fia"]
“Wait, Kosuke……!"
[cpg cn=true]

This is not a big deal.
[cpg]

When I said it would increase, I only meant it as a scare tactic. In fact, there is no way such a phenomenon will happen.
[cpg]

Maybe Fia knows what's going on.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[STOPBGM]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]



[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]
[BGM f="bg_d2"]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************

[window target=true]


Then, a few hours later, I let Fia out of the room.
[cpg]


She looked tired, but she hadn't lost the light in her eyes……..
[cpg]


[OnName num="kousuke"]
“Are you sorry, Fia? "
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Fia562"]
[OnName num="fia"]
"...... Yes."
[cpg cn=true]


But no matter how much Fia regrets it, it doesn't change the fact that I'm now limited in what I can do.
[cpg]


The land of the elves is back to normal. It is no longer the territory of the Demon Lord.
[cpg]


From Fia 's point of view, it means that I have protected my homeland.
[cpg]


Maybe Fia is a very cunning girl.
[cpg]


And maybe it is me who is being conquered, maybe it is me who is being seduced. ......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia563"]
[OnName num="fia"]
“...... Are you okay Kosuke ?”
[cpg cn=true]


[OnName num="kousuke"]
“Yea, nothings wrong.”
[cpg cn=true]



;//ブラックアウト

[free time=800]
[BG f="black.ui" time=1000]
[WAIT time=100]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[BGM f="bg_si"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（昼）******************************************************





And then the country of the Demon Lord and myself were in a tight spot.
[cpg]


We lost our land as well as the power to control the elves.
[cpg]


The fact that we are being targeted for our lives hasn't change. In fact, it's worse than before.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Clolowlude269"]
[OnName num="clolowlude"]
“It seems that no other country is going to invade, but the number of assassins are increasing again.”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Meile359"]
[OnName num="meile"]
“I wonder if people are thinking that now is the time to contain you...... Kosuke.”
[cpg cn=true]


[OnName num="kousuke"]
“...... I see.”
[cpg cn=true]


It's Fia 's fault, but if I'm left alone with my world domination ambitions, ......
[cpg]


I might have died somewhere along the line.
[cpg]


I'm not sure if we're in a position to debate which was better.
[cpg]


[FACE method="change_2" pos="2/2"]
[VOICE f="Meile360"]
[OnName num="meile"]
“But I think it's good. Kosuke was so dangerous a while ago that it was difficult to watch.”
[cpg cn=true]


[OnName num="kousuke"]
“Was that so?”
[cpg cn=true]


[FACE method="change_7" pos="1/2"]
[VOICE f="Clolowlude270"]
[OnName num="clolowlude"]
“That's true. You really wanted to collide with the world, didn't you?”
[cpg cn=true]


...... maybe Fia did a good job of stopping me.
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[BG f="b_06_3.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夕方）******************************************************





After that, I was alone with Fia .
[cpg]


[OnName num="kousuke"]
" Fia . I can't read you.”
[cpg cn=true]


[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Fia564"]
[OnName num="fia"]
“...... I'm a simple minded person. I just keep believing that you are a kind person."
[cpg cn=true]


Maybe she was right. But in the end, ......
[cpg]


[OnName num="kousuke"]
“I'm in a life-threatening situation. Are you happy with this?"
[cpg cn=true]


Fia did not nod. But.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia565"]
[OnName num="fia"]
“I like you now, you’re just like the person who saved me. ......"
[cpg cn=true]


She must be talking about before the reincarnation. I have no memory of that time.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia566"]
[OnName num="fia"]
“Do you hate me now, ...... Kosuke ?”
[cpg cn=true]


[OnName num="kousuke"]
"No. I don't. No, not at all.”
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Fia567"]
[OnName num="fia"]
“In that case…….”
[cpg cn=true]


Fia is about to say something. I think she's still attracted to my pheromones.
[cpg]


[OnName num="kousuke"]
"Yeah. I'll kiss you. I still like you, you should thank me.”
[cpg cn=true]

It was like I was a real Demon Lord.
[cpg]



;//ブラックアウト

[STOPBGM]


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_06_4.ui" time=1000]
[WAIT time=1500]

[BGM f="bg_d3"]
[WAIT time=100]
;//【ＢＧ】『城内＿主人公の部屋』（夜）******************************************************


[window target=true]



Time passed, and it was night.
[cpg]


Me and Fia were cuddling and sleeping. I was with Fia , who was supposed to have betrayed me.
[cpg]


[OnName num="kousuke"]
"......, you're probably smarter than me."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Fia589"]
[OnName num="fia"]
"No, I'm not.”
[cpg cn=true]


[OnName num="kousuke"]
“I'm not buying it. It's like you know exactly what I'm thinking."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Fia590"]
[OnName num="fia"]
“...... is a coincidence.”
[cpg cn=true]


Fia is humble. She might be the right person to be with as the Demon Lord.
[cpg]


I wasn’t able to conquer the world, but I gained something more important than that.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia591"]
[OnName num="fia"]
“Kosuke when I’m with you…….I feel a sense of nostalgia.”
[cpg cn=true]


[OnName num="kousuke"]
“Yea. You did meet me before I was reincarnated.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Fia592"]
[OnName num="fia"]
“Yes. Looking back, I've been in love with you since then.”
[cpg cn=true]


She was saying that even though I died once, our love was fulfilled. It seemed romantic.
[cpg]


But for me, I'm just happy to be with Fia .
[cpg]


It's not the process that matters to me, it's what I'm doing now that matters.
[cpg]


Of course, there is an attempt on my life. I'm far from safe.
[cpg]


Even so, I was happy to be spending time with Fia .
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Fia593"]
[OnName num="fia"]
“...... My species is quite long-lived. Maybe you might die…… before I do…….”
[cpg cn=true]


[OnName num="kousuke"]
"Then, next time when I’m reborn, let's be together again."
[cpg cn=true]


I said this without hesitation. Fia smiled and replied.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Fia594"]
[OnName num="fia"]
“You're right. I was about to say the same thing.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//ＥＮＤ　ヒロイン１征服ルート



[WAIT time=100]
[jump storage="epend.ks" target="*start"]
[WAIT time=100]
;[s]
[WAIT time=100]
[WAIT time=100]


;//==============================

