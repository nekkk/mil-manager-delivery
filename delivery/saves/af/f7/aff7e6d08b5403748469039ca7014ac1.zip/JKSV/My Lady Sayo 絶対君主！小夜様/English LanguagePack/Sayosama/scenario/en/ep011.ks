*start

;#################################################
*Ep011|Sing it, dance it, M ondo.
;#################################################

[SCENE id=11]


[stflag jump_scene=0]
[window target=false]

[STOPBGM]



;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]

[FG f="line.ui" method="out"  pos="3/5"]


[SE f=se018]
;//【ＳＥ】『鳥の鳴き声』

[BG f="black.ui" time=1000]
[WAIT time=1000]



[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]
[BGM f="d1"]
[WAIT time=100]

;//【ＢＧ】『豪邸、廊下』（朝）******************************************************

[SE f=se000]
;//【ＳＥ】『ドアを開ける』ガチャ


[window target=true]

[OnName num="masato"]
Whoa!
[cpg cn=true]


[OnName num="butler"]
Good morning. Masato-dono.
[cpg cn=true]


It was my usual wake-up time.
[cpg]

I opened the door and greeted Mr. Tanaka, rubbing my still-awake eyes.
[cpg]

[OnName num="masato"]
"Ah, Mr. Tanaka. Good morning...
[cpg cn=true]


[OnName num="butler"]
"You look sleepy."
[cpg cn=true]


[OnName num="masato"]
"Excuse me. I was up late reading a book...
[cpg cn=true]



[SE f=se000]
;//【ＳＥ】『ドアを開ける』ガチャ

[OnName num="maid_A"]
Wow. Good morning.
[cpg cn=true]


[OnName num="butler"]
Good morning to you, too.
[cpg cn=true]


[OnName num="maid_B"]
You two need to lighten up.
[cpg cn=true]


[OnName num="masato&maidA"]
Excuse me.
[cpg cn=true]


[OnName num="butler"]
Okay, let's go.
[cpg cn=true]


[OnName num="maid_B"]
You'll have to keep the young lady waiting.
[cpg cn=true]


[OnName num="masato"]
Yes!
[cpg cn=true]


[OnName num="maid_A"]
Yes!
[cpg cn=true]



[SE f=se005]
;//【ＳＥ】『小走り』タタタ

I've become so used to living here that I feel as if I've been here for years.
[cpg]

After greeting my colleagues like this, I headed for my master's place. I was happy to be able to spend an ordinary morning.
[cpg]


[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ＢＫ

[BG f="b_04_1.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『小夜の部屋』（朝）******************************************************


[window target=true]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]


[OnName num="butler"]
"Good morning, Miss."
[cpg cn=true]


[OnName num="maid_A"]
"Good morning. It's another beautiful day.
[cpg cn=true]


[OnName num="masato"]
"Good morning, Master."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]


She smiled at me with a gentle smile. Just being able to see this smile makes me happy.
[cpg]

My life is so smooth sailing that I can't even compare it to my old life.
[cpg]

I work for my master, I do my best, and sometimes (big lie) I get touched... I'm happy every day.
[cpg]

[OnName num="masato"]
(Alright, I'll work hard for my master again today!)"
[cpg cn=true]



(Okay, I'll work hard for my master today!) -- but that's only if there are no problems.
[cpg]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=500]

[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[SE f=se092]
;//【ＳＥ】『掃き掃除』

[WAIT time=2500]


[SE f=se093]
;//【ＳＥ】『磨く』

[WAIT time=2500]


[window target=true]


[OnName num="maid_A"]
"Ah, Masato-san. Just in the right place.
[cpg cn=true]

[OnName num="masato"]
"Yes?"
[cpg cn=true]


As I was cleaning the corridor, which was my assigned work area, Ochiai-san called out to me.
[cpg]


[OnName num="maid_A"]
Can you help me over here?
[cpg cn=true]

[OnName num="masato"]
Sure, sure.
[cpg cn=true]


[OnName num="maid_A"]
Thanks!
[cpg cn=true]

[OnName num="masato"]
It's no problem.
[cpg cn=true]


[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

[SE f=se078]
;//【ＳＥ】『衣擦れ』

Squeezing.
[cpg]


[OnName num="masato"]
Ugh...!
[cpg cn=true]


This is what it sounds like when you step on someone.
[cpg]

I thought about this as I listened to the sound coming from my own back.
[cpg]


[BG f="b_02_2.ui" time=1000]
[WAIT time=1500]


;//【ＢＧ】『豪邸、ダイニング』（昼）******************************************************

[OnName num="maid_A"]
"Are you okay? Isn't it heavy?
[cpg cn=true]

[OnName num="masato"]
"No, it's totally fine. Please continue.
[cpg cn=true]


[OnName num="maid_A"]
"Yes. Okay, okay...
[cpg cn=true]

Her full weight is on my back.
[cpg]

Of course, I'm on all fours and I'm the platform for her to ride on.
[cpg]


[SE f=se064]
;//【ＳＥ】『電球交換』カチャカチャ

[OnName num="maid_A"]
I'm sorry, the light bulb here is too high for me to reach..."
[cpg cn=true]

[OnName num="masato"]
"Haha... of course.
[cpg cn=true]


This mansion is big and spacious. The lights that illuminate the room are all set high up.
[cpg]

Even to change the light bulbs on the walls, a man would have to climb up on a platform to reach them.
[cpg]

So he was asked to help, and this is how he became a stepping stone....
[cpg]


[SE f=se064]
;//【ＳＥ】『電球交換』カチャカチャ
[WAIT time=1000]

[OnName num="maid_A"]
I'll get it done soon.
[cpg cn=true]

[OnName num="masato"]
"Don't rush, just take your time."
[cpg cn=true]


Perhaps because she was using me as a platform, I stopped her from hastily trying to change the light bulb.
[cpg]

Even if it's just changing a light bulb, you have to do the job carefully. You never know what might happen later.
[cpg]

[OnName num="maid_A"]
"But Masato-san..."
[cpg cn=true]

[OnName num="masato"]
"Don't worry. I'm used to this kind of thing.
[cpg cn=true]


[OnName num="maid_A"]
"Crap. Is that so? Well then...
[cpg cn=true]

[SE f=se064]
;//【ＳＥ】『電球交換』カチャカチャ
[WAIT time=1000]

[OnName num="masato"]
"(Thank God...)"
[cpg cn=true]


The sound of the work in my ears stabilized, and I patted my chest in relief.
[cpg]

;//集中線in
[FACE method="white_in" pos="3/5"]

[SE f=se094]
;//【ＳＥ】『どどーん２』

[BGM f="co"]


[OnName num="masato"]
I could stay like this for a while longer.
[cpg cn=true]

;//集中線out
[FACE method="white_out" pos="3/5"]
[WAIT time=1000]

[OnName num="maid_A"]
"Mmm..."
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

The sound of work stabilized and I patted my chest.
[cpg]

The comfortable feeling of her legs and the exquisite weight of her feet spread all over my back.
[cpg]

[OnName num="masato"]
I'm not sure what to say. (There... hahaha!)"
[cpg cn=true]


I'm being stepped on by a girl right now.
[cpg]

In other words, I'm happy.
[cpg]


[OnName num="masato"]
I'm happy.
[cpg cn=true]


It's normal to want to feel happy for as long as possible.
[cpg]

Of course, I didn't want to make her feel uncomfortable, but I wanted her to do her job carefully.
[cpg]

I'm just trying to make her feel better, but she's more focused on her work.
[cpg]


[OnName num="masato"]
"Hahahahahahaha."
[cpg cn=true]


To be honest, I can handle being stepped on like this for about an hour. I can do it.
[cpg]

It's a good day to be able to do my job and still feel good. You're lucky.
[cpg]


[OnName num="maid_A"]
"Um... Masato-san? Are you sure you're okay? I feel like you're breathing heavily..."
[cpg cn=true]

[OnName num="masato"]
"I'm fine, I'm fine! I'm all green!
[cpg cn=true]


[OnName num="maid_A"]
I'm all green!" "I see... that's fine, but..."
[cpg cn=true]

It's such a happy thing to be used as a stepping stone by a girl.
[cpg]

I'm not sure what to do.
[cpg]


[OnName num="masato"]
(It's heavier than Master's, but this weight is also moderate...)"
[cpg cn=true]


By the way, this is not a change of sides or cheating.
[cpg]

It's just like panting.
[cpg]

It's a natural byproduct of the job of changing light bulbs. It just happened to be a happy event.
[cpg]

It was a reward for me, that's all.
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

[STOPBGM]

;//レターボックスin
[FACE method="out" pos="4/7"]


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]



[BG f="b_02_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『豪邸、ダイニング』（昼）******************************************************


[BGM f="sl"]


[window target=true]


[OnName num="maid_A"]
"Okay, I'm done. Thank you for your hard work.
[cpg cn=true]


[OnName num="masato"]
"Hmm..."
[cpg cn=true]


[OnName num="maid_A"]
"Thank you, Masato-san. Thank you so much for your help.
[cpg cn=true]

After about half an hour, we finished changing all the light bulbs in the dining room.
[cpg]

Well, I didn't do anything but stand there for a long time.
[cpg]

[OnName num="maid_A"]
"Is your back okay? Does it hurt?"
[cpg cn=true]


[OnName num="masato"]
"I'm fine like this. Mr. Ochiai was so light.
[cpg cn=true]


You could have extended it for another half hour.
[cpg]


[OnName num="maid_A"]
Couscous. Masato-san, you're so dependable.
[cpg cn=true]


[OnName num="masato"]
"Oh, no... If it's okay with me, I'll help you anytime.
[cpg cn=true]


[OnName num="maid_A"]
Really? Then I'll ask you again if I need help.
[cpg cn=true]


[OnName num="masato"]
You can count on me!
[cpg cn=true]


She and I are good friends, probably because we are close in age among the people who work here. By the way, she's older than me.
[cpg]

And I'm also a guy. I can't say no when a girl asks me to do something.
[cpg]

I want to show her how good I am, so I often help out like this.
[cpg]


--Yes. I may have had some ulterior motives, but I was just helping out as a favor.
[cpg]

But when things started to get a little weird, things started to look suspicious.
[cpg]


;//ＢＫ

[STOPBGM]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1500]
[WAIT time=1600]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]


;//【ＢＧ】『使用人の部屋（雅人の部屋）』（昼）******************************************************


[BGM f="sl"]

[window target=true]


[OnName num="butler"]
"You've been hanging out with Mr. Ochiai a lot lately.
[cpg cn=true]


Mr. Tanaka, who was drinking tea with us on a break, said something like that to me.
[cpg]


[OnName num="masato"]
Mr. Tanaka, who was drinking tea with us on a break, said, "......? Is that so?
[cpg cn=true]


[OnName num="butler"]
"Yes. Whenever I see him, he usually seems to be on good terms with me, so that may be why I feel that way.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


[OnName num="butler"]
Excuse me. It's just what I thought, so I hope you don't mind.
[cpg cn=true]


[OnName num="masato"]
Well, Mr. Ochiai often asks me for help, so I guess that's why.
[cpg cn=true]


[OnName num="butler"]
I see. He trusts me, doesn't he?
[cpg cn=true]


[OnName num="masato"]
Haha, is that so?
[cpg cn=true]


[OnName num="butler"]
"Relying on me is a sign that you trust me.
[cpg cn=true]


I'm trusted. When Mr. Tanaka clearly said that, I felt even more happy.
[cpg]

She's relying on me, and I'm helping her... I feel more fulfilled by the recognition of others, not just myself.
[cpg]


[OnName num="butler"]
"It's just..."
[cpg cn=true]


[OnName num="masato"]
?"
[cpg cn=true]


[OnName num="butler"]
No, ...... nothing."
[cpg cn=true]


He put down his empty teacup, stood up and straightened his collar.
[cpg]

[OnName num="masato"]
"Tanaka-san?"
[cpg cn=true]


[OnName num="butler"]
I'm sure you've heard of it. Please don't forget that..."
[cpg cn=true]


[OnName num="masato"]
"What?　Yes. Of course...
[cpg cn=true]


[OnName num="butler"]
"Then there is no problem. Now, let's get back to work.
[cpg cn=true]


What Mr. Tanaka was saying was too obvious for me to understand, so I tilted my head.
[cpg]

[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ＢＫ

[BG f="b_01_3.ui" time=1000]
[WAIT time=500]
;//【ＢＧ】『豪邸、廊下』（夕方）******************************************************

[SE f=se005]
;//【ＳＥ】『歩く』

[WAIT time=1500]


[window target=true]

[OnName num="masato"]
I don't know what he was trying to say..."
[cpg cn=true]


As I resumed my work and walked alone down the corridor, I thought back to Mr. Tanaka's words.
[cpg]

I felt as if I had been nailed down, but there was nothing strange about it.
[cpg]

I'm just helping Ms. Ochiai, and she's relying on me.
[cpg]

I'm sure there's no mistake there.
[cpg]


[SE f=se028]
;//【ＳＥ】『小走り』タッタッタ

[OnName num="maid_A"]
"Oh, Masato-san.
[cpg cn=true]


[OnName num="masato"]
"Ochiai-san..."
[cpg cn=true]


But...why did Tanaka-san look so worried?
[cpg]


[OnName num="maid_A"]
"Thank God you found it."
[cpg cn=true]


[OnName num="masato"]
"What?"
[cpg cn=true]


[OnName num="maid_A"]
Can I ask you again?
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[OnName num="maid_A"]
Can't I just go to ......?
[cpg cn=true]


[OnName num="masato"]
No, I'm good.
[cpg cn=true]


For a moment, the thought of refusing came to mind, but then I said yes with two words.
[cpg]

I couldn't say no when she smiled at me with happiness.
[cpg]

;//ＢＫ


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]

[window target=true]


;//【ＢＧ】『豪邸、ホール』（夜）******************************************************

[window target=true]


[OnName num="maid_A"]
Thank you so much for everything. You've been a great help.
[cpg cn=true]

[OnName num="masato"]
It's okay. It's a man's job to carry heavy things.
[cpg cn=true]


[OnName num="maid_A"]
I'm sorry. Masato-san is so dependable that I couldn't help but ask him to do many things.
[cpg cn=true]

[OnName num="masato"]
"Oh, no. That's fine.
[cpg cn=true]


Helping others. Helping others, being useful to someone.
[cpg]

I'm just doing it because it makes me happy... that's all.
[cpg]


[OnName num="maid_A"]
Masato-san, there is something I would like to ask you.
[cpg cn=true]

[OnName num="masato"]
"Yes? What is it?"
[cpg cn=true]


But then it occurred to me.
[cpg]

But then it occurred to me that it didn't make any difference whether I was there or not for the things Ochiai-san had asked for help with.
[cpg]

[STOPBGM]

[OnName num="maid_A"]
"Um, ......, isn't it sometimes... hard to serve your daughter?"
[cpg cn=true]

[BGM f="h1"]

[OnName num="masato"]
"......What?"
[cpg cn=true]


Yes, even at that time... I could have used a chair to change the light bulb.
[cpg]

The luggage was not too heavy. The luggage was not too heavy. One woman could have carried it.
[cpg]


[OnName num="maid_A"]
"I think I can do more for Masato-san..."
[cpg cn=true]

[OnName num="masato"]
"What do you mean by that?
[cpg cn=true]


If that was the case, why did she ask me to help her every time?
[cpg]

Why is she saying this to me?
[cpg]


[OnName num="maid_A"]
"How about I be your new master?"
[cpg cn=true]

[OnName num="masato"]
"What?"
[cpg cn=true]




What's that proposal...there's no way I can listen to that.
[cpg]

Because I have only one master, Saya.
[cpg]


[OnName num="maid_A"]
It's a good idea. I don't think it's a bad idea.
[cpg cn=true]

[OnName num="masato"]
"Hey, Ochiai-san... please calm down. What's wrong with you?
[cpg cn=true]


[OnName num="maid_A"]
"C'mon. I'm not doing anything wrong... it's just that I'm feeling... uncontrollable.
[cpg cn=true]

[BG f="b_00_4_up.ui" time=1000]

;//レターボックスin
[FACE method="feadin" pos="4/7"]
[WAIT time=1500]

[SE f=se033 loop=true]
;//【ＳＥ】『心音』

Like a frog stared at by a snake, I couldn't move my body.
[cpg]

Her body, her lips... they come closer and closer.
[cpg]

[OnName num="masato"]
(Wait, wait, wait...)
[cpg cn=true]

[STOPBGM]

[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1500]
[WAIT time=2000]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[stopse g=6]
;//ループse
[WAIT time=1]

[SE f=se065]
;//【ＳＥ】『靴音』

[WAIT time=800]

[stopse g=2]
;//通常se

[window target=true]


[VOICE f="Sayo472"]
[OnName num="sayo"]
"......"
[cpg cn=true]


[OnName num="maid_A"]
"Ah!"
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]

[window target=false]

;//レターボックスout
[FACE method="out" pos="4/7"]

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=2000]
[BG f="b_00_4.ui" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]

[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

[window target=true]

[BGM f="se"]

The sound of shoes echoed from behind me, and there was my master.
[cpg]

Both Ms. Ochiai and I hurriedly moved our bodies away, unsure of how long we had been there or if we had just arrived.
[cpg]


[OnName num="masato"]
"Gee, Master..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo473"]
[OnName num="sayo"]
"What are you doing?"
[cpg cn=true]


[OnName num="masato"]
"Well, this is..."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo474"]
[OnName num="sayo"]
"If you have time to chat, get to work."
[cpg cn=true]


[OnName num="maid_A"]
Yes, sir! I... haven't cleaned up over there yet...
[cpg cn=true]

[SE f=se006]
;//【ＳＥ】『走る』
[WAIT time=1000]


I'm still cleaning up over there..." Unable to help herself, she left quickly.
[cpg]

I wanted to leave the place with her, but I lost my chance and was left alone with Master.
[cpg]

[OnName num="masato"]
"Oh, um..."
[cpg cn=true]


[FG f="CHA01_p4_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo475"]
[OnName num="sayo"]
"You too. It's nice to be able to make out with a coworker at work.
[cpg cn=true]

[SE f=se047]
;//【ＳＥ】『殴る』

[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=300]
[WAIT time=800]


[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=300]
[WAIT time=200]


[OnName num="masato"]
"Ow!"
[cpg cn=true]


He hit me. Master was in a foul mood for some reason.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[VOICE f="Sayo476"]
[OnName num="sayo"]
Go back to work, now. Come on, come on!
[cpg cn=true]


[OnName num="masato"]
"Yes, yes, yes!
[cpg cn=true]


[SE f=se006]
;//【ＳＥ】『走る』

;//ＢＫ
[STOPBGM]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1500]


[BGM f="se"]
;//【ＢＧ】『小夜の部屋』（夜）******************************************************

[window target=true]

[BG f="b_04_4_up.ui" time=1000]
[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=1000]

;//レターボックスin
[FACE method="slidein" pos="4/7"]

[WAIT time=2000]


[VOICE f="Sayo477"]
[OnName num="sayo"]
(What a pain in the ass that servant/pet is. I wonder if it's okay to be a servant.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo478"]
[OnName num="sayo"]
That servant... seems to be on a roll lately.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo479"]
[OnName num="sayo"]
"And..."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo480"]
[OnName num="sayo"]
".......... I think I'm going to have to do something about that.
[cpg cn=true]


;//ＢＫ
[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//レターボックスout
[FACE method="out" pos="4/7"]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BGM f="sl"]
;//【ＢＧ】『小夜の部屋』（夕方）******************************************************

[window target=true]


A few days later, in the evening.
[cpg]

A few days later in the evening, the master called his servant into his room after he had finished his work as usual.
[cpg]

[OnName num="masato"]
He said, "(Um, Mr. Tanaka. What exactly is this gathering today?
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="5/3" time=1]

[OnName num="butler"]
(Oh, no...) (Well, that is...)"
[cpg cn=true]

[SE f=se005]
;//【ＳＥ】『歩く』コツコツ

[move from="5/3" to="2/3" ease="easeInOutSine" time=2000]
[WAIT time=1500]


[OnName num="masato"]
(Hey, that guy...I think I've seen him before.)
[cpg cn=true]


The master stands in front of everyone. And next to him was a man.
[cpg]

[VOICE f="Sayo481"]
[OnName num="sayo"]
"Let me introduce you, he is..."
[cpg cn=true]


[OnName num="glasses_man"]
"This is Ryuhei. It's nice to meet you.
[cpg cn=true]


I hadn't been told what the purpose of my visit was, but I soon found out.
[cpg]

He had a big announcement to make....
[cpg]

[STOPBGM]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo482"]
[OnName num="sayo"]
He was going to start working here today. He's going to start working here today, and you're going to have to teach him a lot.
[cpg cn=true]


[OnName num="all_members"]
""Yes!
[cpg cn=true]

[BGM f="h1"]

[OnName num="masato"]
What...?
[cpg cn=true]


I was surprised because it was so sudden. I didn't think it was an introduction from a colleague...
[cpg]


[OnName num="glasses_man"]
"I'm looking forward to working with you.
[cpg cn=true]


[OnName num="masato"]
"........."
[cpg cn=true]


And the guy who showed up was... the guy from that time. The man with glasses that I had interviewed with.
[cpg]

If he's here, then it looks like he passed the test.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo483"]
[OnName num="sayo"]
Masato."
[cpg cn=true]


[OnName num="masato"]
"Yes?
[cpg cn=true]


[FG f="CHA01_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=800]
[VOICE f="Sayo484"]
[OnName num="sayo"]
Since you're my senior, you should teach me well.
[cpg cn=true]


[OnName num="masato"]
I understand, but... senior means...
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo485"]
[OnName num="sayo"]
"Xu Xu. It's obvious. I mean senior as a servant.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


My heart was squeezed tightly.
[cpg]

It's been a while since I've heard my name called, but I don't have time to be happy about it.
[cpg]

This is because it is... ......, after all.
[cpg]


[OnName num="glasses_man"]
My name is Ryuhei. What is your senior's name..."
[cpg cn=true]


[OnName num="masato"]
"Ah ......, yes... my name is Masato..."
[cpg cn=true]


A new servant other than me. That is to say, a new servant to serve the new master.
[cpg]

It's the first time I've had a peer, a colleague close to my age, and a rival.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo486"]
[OnName num="sayo"]
"I've been bored lately, so I wanted a new girl, you know..."
[cpg cn=true]

[SE f=se014]
;//【ＳＥ】『衝撃』


[OnName num="masato"]
"What?
[cpg cn=true]


I was shocked as if I had been hit in the back of the head with a hammer.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

No, no, no, no, no, no, no, no... I'm bored with the idea of having a new servant...?
[cpg]


[OnName num="glasses_man"]
"You must be Masato-senpai! I look forward to your guidance and encouragement!"
[cpg cn=true]


[OnName num="masato"]
"Uh, yeah... nice to meet you .........."
[cpg cn=true]


So... this person is not servant number two, but my replacement?
[cpg]

A new servant? Maybe you don't need me anymore?
[cpg]

That's... that's ridiculous.
[cpg]

;//レターボックスin
[FACE method="slidein" pos="4/7"]
[WAIT time=2000]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo487"]
[OnName num="sayo"]
It's working. It's working, it's working... it's going to be fun for a while."
[cpg cn=true]


[OnName num="butler"]
(Miss ...... is a demon.)"
[cpg cn=true]

[STOPBGM]

[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1500]
[WAIT time=2000]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//レターボックスout
[FACE method="out" pos="4/7"]

;//ＢＫ

[window target=treu]


--That was the beginning of hell.
[cpg]

[window target=false]


[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1500]
[WAIT time=2000]

[BGM f="se"]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************

[window target=true]

The next day.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo488"]
[OnName num="sayo"]
The next day: "It's coming along quite nicely."
[cpg cn=true]


[OnName num="glasses_man"]
Oh, thank you... thank you!
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo489"]
[OnName num="sayo"]
You wanted me to do this to you, didn't you?
[cpg cn=true]


[OnName num="glasses_man"]
"Yes..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo490"]
[OnName num="sayo"]
"Yes... Yeah...
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]



A man's voice that wasn't mine echoed in Master's room.
[cpg]

[OnName num="glasses_man"]
I've been wanting to do something like this for a long time. I've been longing for something like this for a long time. I've always wanted a master like you, Master."
[cpg cn=true]


He was on his knees being kicked by Master, and yet he was happy.
[cpg]

It was a painful scene to watch. I couldn't help but say something.
[cpg]

[OnName num="masato"]
I couldn't help but say, "Oh, um... Master..."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo491"]
[OnName num="sayo"]
"What?　Are you trying to interrupt me?
[cpg cn=true]


[OnName num="masato"]
No...
[cpg cn=true]

[window target=false]

;//ＢＫ

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

[BGM f="se"]
;//【ＢＧ】『豪邸、廊下』（夜）******************************************************

[window target=true]


[OnName num="glasses_man"]
Good night, sir. Have a good night.
[cpg cn=true]


[OnName num="masato"]
Good night. Good night.
[cpg cn=true]


[window target=false]

[SE f=se005]
;//【ＳＥ】『歩く』

[BG f="black.ui" time=1500]
[WAIT time=2000]


[BG f="b_06_4.ui" time=1500]
[WAIT time=2000]


;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夜）******************************************************

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[window target=true]


[OnName num="masato"]
I don't know what I'm doing...
[cpg cn=true]


I'm jealous when I see other men being treated well by their masters... and then I get angry.
[cpg]

Sometimes I don't even do my daily work properly.
[cpg]

I'm really screwed like this. It's no wonder Master has run out of patience with me....
[cpg]

[OnName num="masato"]
"What should I do......... Master..."
[cpg cn=true]


I was almost overwhelmed with anxiety.
[cpg]

[STOPBGM]
;//ＢＫ

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1500]


[BG f="b_06_2.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『使用人の部屋（雅人の部屋）』（昼）******************************************************

[BGM f="sl"]


[window target=true]


;//自分のテリトリーが犯されていく恐怖に、ちょっと意地悪をする主人公。
;//彼女がふだん着ないパジャマを持たせる。

[OnName num="masato"]
I was about to be overwhelmed with anxiety. "Master is going to take a bath, so please follow me as I bring you a change of clothes."
[cpg cn=true]


[OnName num="glasses_man"]
"Yes, I understand."
[cpg cn=true]


One of my jobs is to deliver a change of clothes to my master before he takes a bath.
[cpg]

It's easy, though, because all I have to do is deliver it.
[cpg]

No mistakes are made.
[cpg]

[window target=false]


[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ＢＫ


[BG f="b_01_2.ui" time=1000]
[WAIT time=500]


;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[SE f=se005]
;//【ＳＥ】『歩く』

[WAIT time=1000]


[window target=true]


[OnName num="masato"]
"......"
[cpg cn=true]


[OnName num="glasses_man"]
Um, senpai...
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[OnName num="glasses_man"]
"Are you sure that the change of clothes that you have for your master... is this really enough?"
[cpg cn=true]

My heart skipped a beat at his unexpected question.
[cpg]

[SE f=se033]
;//【ＳＥ】『心音』

[OnName num="masato"]
My heart skipped a beat at his unexpected question: "Why?"
[cpg cn=true]


[OnName num="glasses_man"]
No, it's just... I didn't think it suited Master's taste very well.
[cpg cn=true]


[OnName num="masato"]
"........."
[cpg cn=true]


[OnName num="glasses_man"]
Senior?
[cpg cn=true]


[OnName num="masato"]
It's okay, don't worry about it. It's just a spare...
[cpg cn=true]


[OnName num="glasses_man"]
"Huh..."
[cpg cn=true]


My hands were trembling slightly.
[cpg]

[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ＢＫ
[BG f="b_01_2.ui" time=1000]
[WAIT time=500]


;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[SE f=se005]
;//【ＳＥ】『歩く』

[WAIT time=1000]

[window target=true]


[OnName num="masato"]
Master, I've brought you a change of clothes.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo492"]
[OnName num="sayo"]
Thank you.
[cpg cn=true]


[OnName num="glasses_man"]
......
[cpg cn=true]


I walked over to Master just as he was entering the bathroom and offered him the change of clothes I had.
[cpg]

;//小夜「……」
;//小夜「……」

However, the master did not accept the change of clothes.
[cpg]


[OnName num="masato"]
...... Oh, you know what?
[cpg cn=true]

[STOPBGM]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo493"]
[OnName num="sayo"]
"I think I'll wear yours today."
[cpg cn=true]

[BGM f="se"]

As I was about to ask him if there was a problem, he pointed not to my change of clothes but to the one Ryuhei was holding.
[cpg]


[OnName num="glasses_man"]
"What? Is it this way? Here you go!
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[WAIT time=1000]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo494"]
[OnName num="sayo"]
"Thank you."
[cpg cn=true]


[OnName num="glasses_man"]
"No problem."
[cpg cn=true]


[OnName num="masato"]
.........
[cpg cn=true]


Why...I usually wear this side of my pajamas.
[cpg]

I'm sure I made the right choice of clothes.
[cpg]

Why are you picking up what he brought you, master?
[cpg]


;//ＢＫ


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_01_4.ui" time=1500]
[WAIT time=2000]

;//【ＢＧ】『豪邸、廊下』（夜）******************************************************

[window target=true]

[SE f=se025]
;//【ＳＥ】『スパンキング』
[WAIT time=2000]

[OnName num="glasses_man"]
"Ah, ah, ah...master!"
[cpg cn=true]


[VOICE f="Sayo495"]
[OnName num="sayo"]
Come on, make a better noise!
[cpg cn=true]

[SE f=se025]
;//【ＳＥ】『スパンキング』
[WAIT time=2000]

[OnName num="glasses_man"]
"Aahiiiii!"
[cpg cn=true]



His loud voice reached all the way to the hallway... and even though I covered my ears with my hands, I could still hear it.
[cpg]

[SE f=se025]
;//【ＳＥ】『スパンキング』

It was hard to see them, so I asked him to stay in the hallway, but it didn't make much difference.
[cpg]

The fact that I couldn't see them made me even more curious.
[cpg]


[OnName num="masato"]
"Damn..."
[cpg cn=true]


I wondered what they were doing in there.
[cpg]

I wonder if they are doing things that I have never had done to me before.
[cpg]

I haven't been touched recently, and I haven't been rewarded.
[cpg]

No... rewards are not something you get very often, and with the way I'm working, they're just a distant dream.
[cpg]

[SE f=se025]
;//【ＳＥ】『スパンキング』

I know that. But .......
[cpg]


[BG f="b_01_4_up.ui" time=1500]


[OnName num="masato"]
I'm sure you'll be happy to hear that.
[cpg cn=true]


The master only cares about that man with glasses, and they are becoming friends...
[cpg]

It's a good idea to take a look at the website and see if you can find anything you like.
[cpg]

...... Honestly, I feel like crying.
[cpg]


[SE f=se005]
;//【ＳＥ】『足音』コツン

[WAIT time=1000]

[stopse g=2]
;//通常se

[OnName num="maid_A"]
"Masato? Are you okay?"
[cpg cn=true]

[BG f="b_01_4.ui" time=800]
[WAIT time=1000]

[STOPBGM]

[OnName num="masato"]
"Oh, Ochiai-san..."
[cpg cn=true]


As I was cowering in the hallway, Ochiai-san called out to me.
[cpg]

I felt like it had been a long time since we had talked face to face since that day.
[cpg]


[OnName num="maid_A"]
It's hard, isn't it, ......? I know exactly how you feel.
[cpg cn=true]


[OnName num="masato"]
"What?"
[cpg cn=true]

[BGM f="h1"]


[OnName num="maid_A"]
"...... I'll help you heal."
[cpg cn=true]


[OnName num="masato"]
No, no, no, no, no, no, no.
[cpg cn=true]


[OnName num="maid_A"]
Don't worry, don't worry. I won't tell anyone.
[cpg cn=true]


[OnName num="maid_A"]
And I'm actually really good at tormenting people.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]



;//ＢＫ

[STOPBGM]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BGM f="h1"]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夜）******************************************************

[window target=true]


[OnName num="masato"]
"Oh, my God, Mr. Ochiai..."
[cpg cn=true]


[OnName num="maid_A"]
Yeah. I'm sorry it's been so hard for you.
[cpg cn=true]

I've been under a spell.
[cpg]

That's not even an excuse.
[cpg]

It's also a good idea to have a good idea of what you're doing.
[cpg]

She needed me, and I took her up on her offer.
[cpg]

[STOPBGM]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『豪邸、廊下』（夜）******************************************************

[OnName num="glasses_man"]
........................... ..."
[cpg cn=true]


[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

--They continued like that for a while after that.
[cpg]

While Master was training Ryuhei, I escaped and went to Ochiai-san's place to be comforted.
[cpg]

She gently wraps me in her arms.
[cpg]


;//ＢＫ

[window target=false]

[transition target={true} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BGM f="h1"]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夜）******************************************************

[window target=true]


[OnName num="masato"]
Ochiai-san is so kind. To me like this."
[cpg cn=true]


[OnName num="maid_A"]
"I'm not nice. Besides, I think you're doing a great job.
[cpg cn=true]


[OnName num="masato"]
"Haha, I see..."
[cpg cn=true]


I lay back on the bed, feeling satisfied and happy.
[cpg]


[OnName num="maid_A"]
What are you going to do tomorrow?
[cpg cn=true]


[OnName num="masato"]
Hmmm... what should I do?
[cpg cn=true]


I should be happy, I should feel good... I should be more than happy.
[cpg]

But I still feel like there's a hole in my heart. It's not going to be filled, no matter what.
[cpg]


[SE f=se016]
;//【ＳＥ】『扉を開ける』

[WAIT time=1000]

[OnName num="glasses_man"]
"........."
[cpg cn=true]


[OnName num="masato"]
"Eh...? Ryuhei-kun...?"
[cpg cn=true]


Suddenly, the door was opened and a person came in. And it was him who came to the room.
[cpg]

[OnName num="maid_A"]
"Ryu-chan..."
[cpg cn=true]


[OnName num="glasses_man"]
"Senior, the master wants to see you. He wants you to come at once.
[cpg cn=true]


[OnName num="masato"]
"...... Okay."
[cpg cn=true]


With his mood and the timing of the summons, I had an idea of what to expect.
[cpg]

It didn't take long for this affair to be discovered by the wise master.
[cpg]

[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ＢＫ


[BG f="b_04_2.ui" time=1000]
[WAIT time=1500]



[BGM f="se"]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************

[window target=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo496"]
[OnName num="sayo"]
"Do you know why you were called to ......?"
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]


I was called into a room and there was Master in front of me.
[cpg]

He seemed to be the same as usual, but I could sense that he was angry.
[cpg]


[FG f="CHA01_p4_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo497"]
[OnName num="sayo"]
"Let's hear your excuse, shall we?"
[cpg cn=true]


[OnName num="masato"]
"...No, sir.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo498"]
[OnName num="sayo"]
No? No? Did you just say no?
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]


There is no excuse for what happened. No matter what the reason was, it was my fault.
[cpg]

I was convinced of that, and that's why I did what I did.
[cpg]

And I also feel that I don't really care about excuses anymore.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo499"]
[OnName num="sayo"]
So... you have no excuse for your master.
[cpg cn=true]


[OnName num="masato"]
Master... doesn't need me anymore.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo500"]
[OnName num="sayo"]
Huh?
[cpg cn=true]


[OnName num="masato"]
......
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo501"]
[OnName num="sayo"]
......... Yeah. You seem to be trying to piss me off.
[cpg cn=true]


;//ＢＫ

[STOPBGM]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************

[window target=true]

[SE f=se034]
;//【ＳＥ】『ノック』

[WAIT time=2000]

[SE f=se016]
;//【ＳＥ】『扉を開ける』


[OnName num="maid_A"]
Excuse me miss, can I help you with ......?
[cpg cn=true]

[BGM f="h1"]

[SE f=se095]
;//【ＳＥ】『縛る』

[OnName num="masato"]
"Ughhhh... hmmm... hmmm..."
[cpg cn=true]


A few dozen minutes later.
[cpg]

Ms. Ochiai, who had been summoned at the same time as me, let out a scream as soon as he entered the room.
[cpg]


[OnName num="maid_A"]
"What are you doing?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo502"]
[OnName num="sayo"]
As you can see, I'm giving my servant a hard time.
[cpg cn=true]

[SE f=se095]
;//【ＳＥ】『縛る』

I was tied up with ropes, suspended in the air, and I was shaking my body like I was being rocked in a cradle.
[cpg]

Anyone would scream if they were suddenly presented with such a scene.
[cpg]


[OnName num="masato"]
"Hmmm... hmmm..."
[cpg cn=true]


[OnName num="maid_A"]
"Oh, no, that's... that's... that's pitiful!
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo503"]
[OnName num="sayo"]
Hard? It's only the beginning. Besides, the servant is so happy.
[cpg cn=true]


Even though I had been subjected to a complete and unrestrained masturbation, my body was still trembling with pleasure.
[cpg]

It was the first time in months that I was being tortured by my master. No matter how hard it was... no matter how much it hurt... it was a reward.
[cpg]


[FG f="CHA01_p4_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo504"]
[OnName num="sayo"]
"You can't do this to him, can you?"
[cpg cn=true]


[OnName num="maid_A"]
"Ssshhh... ......"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo505"]
[OnName num="sayo"]
Don't mess with my toys too much. ......
[cpg cn=true]

[STOPBGM]

[OnName num="maid_A"]
It's amazing!
[cpg cn=true]

[BGM f="co"]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo506"]
[OnName num="sayo"]
"What...?"
[cpg cn=true]


Interrupting her master's words, Ochiai-san said with a twinkle in her eye.
[cpg]

[OnName num="maid_A"]
"I'm sorry, Miss. My selfishness... made you feel uncomfortable."
[cpg cn=true]


Acknowledging her fault and apologizing, she bowed her head deeply.
[cpg]


[SE f=se095]
;//【ＳＥ】『縛る』

[OnName num="masato"]
"Hmph... hmph... (What... how are you doing?)"
[cpg cn=true]

[STOPBGM]

[window target=false]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ＢＫ

[BG f="b_04_2.ui" time=1000]
[WAIT time=1500]


[BGM f="se"]
[WAIT time=100]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************

[window target=true]


[OnName num="butler"]
"Ho!"
[cpg cn=true]


[OnName num="masato"]
"Ow... ow... ow...
[cpg cn=true]


[OnName num="butler"]
Masato-dono, take this.
[cpg cn=true]


[OnName num="masato"]
Thank you, Mr. Tanaka.
[cpg cn=true]


Thank you, Mr. Tanaka." Apparently, there was some kind of situation, and I had to listen to what he had to say, so I was released from the suspension for the time being.
[cpg]


[OnName num="maid_A"]
I'm really... sorry."
[cpg cn=true]


She bowed her head again.
[cpg]

[OnName num="masato"]
"Ochiai-san... what exactly..."
[cpg cn=true]


[OnName num="maid_A"]
"Actually, Masato-san... well, ...... I have a pet."
[cpg cn=true]


[OnName num="butler"]
"A pet...?"
[cpg cn=true]


[OnName num="maid_A"]
Yes. Well..."
[cpg cn=true]


She paused for a moment, then glanced at me.
[cpg]

[STOPBGM]

[OnName num="maid_A"]
I have a pet like Masato-san, who looks a little like my brother's pet.
[cpg cn=true]

[BGM f="co"]

[SE f=se014]
;//【ＳＥ】『衝撃』

[OnName num="masato"]
"What?
[cpg cn=true]


[OnName num="maid_A"]
When I see Masato-san, I can't help but want to ...... torment him.
[cpg cn=true]


Ochiai-san said something outrageous.
[cpg]

I couldn't hide my surprise at the existence of her pet (my brother).
[cpg]

By pets, she didn't mean dogs or cats, but people like me...people like you.
[cpg]


[OnName num="maid_A"]
"I try to let him off the hook with the weekends off, but I just can't..."
[cpg cn=true]


[OnName num="maid_A"]
I think it's good that I can leave him alone for a while, but..."
[cpg cn=true]


Your brother may be more advanced than me.
[cpg]

I'm sure you can understand how hard it is. I'm in the same position, so I understand.
[cpg]

I'm talking from the point of view of the pet (your brother), but it's hard to be left alone for a long time.
[cpg]

[OnName num="maid_A"]
"I knew it was wrong, but I couldn't resist my desire... I'm really sorry!
[cpg cn=true]


[OnName num="masato"]
I'm so sorry!" "Oh, so that's what you meant..."
[cpg cn=true]



In other words, she had a servant (a pet, a brother) who was like a master to me.
[cpg]

But...my job at the mansion is live-in, so I can't go home every day to train my pet.
[cpg]

That's why they asked me to take his place.
[cpg]

I was surprised by such an intricate and special situation, but was that the reason why he was bullying me?
[cpg]

It's not a problem, though, because supply and demand were in place.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo507"]
[OnName num="sayo"]
I see, your feelings are... painfully clear.
[cpg cn=true]


[OnName num="maid_A"]
"My Lady...
[cpg cn=true]


[OnName num="maid_A"]
I'm so, so sorry.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo508"]
[OnName num="sayo"]
It's okay. There's nothing to be sorry for.
[cpg cn=true]


[OnName num="maid_A"]
"My Lady... oh, my God!"
[cpg cn=true]



[SE f=se066]
;//【ＳＥ】『』キラキラキラ〜

With tears streaming down her face, she apologized, and Master accepted it with the generosity of a Bodhisattva.
[cpg]

Ochiai-san apologized again and again as he stroked her head.
[cpg]

I want to be nudged on the head too.
[cpg]

[stopse g=2]
;//通常se

[OnName num="butler"]
"Mm-hmm. I guess... the matter is settled.
[cpg cn=true]


[OnName num="masato"]
"Is it okay, this atmosphere... we're getting along somehow...?
[cpg cn=true]


It seems that sadists had their own thoughts about each other.
[cpg]

If this case can be resolved without Ms. Ochiai being punished, so be it.
[cpg]


[OnName num="maid_A"]
And, well, there was a part of me that was jealous of Miss...
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo509"]
[OnName num="sayo"]
"Jealousy? Jealous of me?
[cpg cn=true]


[OnName num="maid_A"]
Yes. Actually, the new servant, the one with the glasses, is my...
[cpg cn=true]


[SE f=se067]
;//【ＳＥ】『扉を開ける』バンッ！

[WAIT time=1500]


[OnName num="glasses_man"]
Sister!
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo510"]
[OnName num="sayo"]
Sister?
[cpg cn=true]


[OnName num="maid_A"]
Ryu-chan!
[cpg cn=true]


[OnName num="masato"]
"Ryu-chan!"
[cpg cn=true]



I thought that the story was entering the summary stage, but at this point, an intruder appeared.
[cpg]

It was... the new servant, Ryuhei.
[cpg]

[OnName num="masato"]
"Ryu-chan... you can't possibly be..."
[cpg cn=true]


[OnName num="glasses_man"]
"Yes... my name is Ryuhei Ochiai. I'm the pet of the ...... sister that we just talked about!
[cpg cn=true]

[FACE method="white_in" pos="3/5"]


[SE f=se094]
;//【ＳＥ】『どどーん２』

[WAIT time=1000]

Yes, he was the one who had declared himself as a pet... he was the pet of Ms. Ochiai, the one who was being talked about right now... he was her brother.
[cpg]

I knew that was the case since he came in at this time, but...
[cpg]

[FACE method="white_out" pos="3/5"]


[OnName num="maid_A"]
"Ryu-chan... why..."
[cpg cn=true]


[OnName num="glasses_man"]
"It's your fault!"
[cpg cn=true]


[OnName num="maid_A"]
What?
[cpg cn=true]


[OnName num="glasses_man"]
Before I got this job, my sister... she used to abuse me more. But she's been doing it less and less...
[cpg cn=true]


[OnName num="maid_A"]
That's just the way it is.
[cpg cn=true]


[OnName num="glasses_man"]
I know. I know it's selfish of me, but I just couldn't bear the thought of my sister bullying another man.
[cpg cn=true]



He was having a hard time because since his sister got her current job, he had less time to be bullied than before.
[cpg]

He had been having a hard time since his sister got a new job and he was getting bullied less than before.
[cpg]

I knew that feeling too.
[cpg]


[OnName num="glasses_man"]
I'm sorry for deciding to work here on my own, and for not telling you. I'm sorry I decided to work here on my own, and I'm sorry I didn't tell you about it, but I couldn't stay, so I came to check on you!
[cpg cn=true]


[OnName num="glasses_man"]
And then you were... hanging out with this guy and I was so frustrated that I went to .......
[cpg cn=true]


[OnName num="masato"]
What, me?
[cpg cn=true]


[OnName num="butler"]
There's no one else.
[cpg cn=true]


[OnName num="glasses_man"]
So I thought I'd be a little mean to him so he'd like me.
[cpg cn=true]


[OnName num="maid_A"]
That's a misunderstanding, Ryu-chan! You're wrong, Ryu-chan! Masato-san and I are good friends, but to be honest, he's just a comfort to me!
[cpg cn=true]

[SE f=se014]
;//【ＳＥ】『衝撃』

[OnName num="masato"]
"Yeah, yeah, yeah! That's really terrible!
[cpg cn=true]


[OnName num="glasses_man"]
Are you sure?
[cpg cn=true]


[OnName num="maid_A"]
Yes. Masato-san is nothing but a piece of trash to me.
[cpg cn=true]

[SE f=se014]
;//【ＳＥ】『衝撃』

[OnName num="masato"]
That's even worse!
[cpg cn=true]


[OnName num="glasses_man"]
I want to spend more time with you. I want you to tease me more!
[cpg cn=true]


[OnName num="maid_A"]
Ryu-chan...
[cpg cn=true]


[OnName num="glasses_man"]
"Sister..."
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

The two of them exchanged a passionate embrace.
[cpg]

[OnName num="maid_A"]
"I'm sorry, I'm sorry... I'm sorry, Ryuu-chan."
[cpg cn=true]


[OnName num="glasses_man"]
"I'm sorry too. But I can't live without you...
[cpg cn=true]


[OnName num="maid_A"]
I'm sorry too. I can't live without you.
[cpg cn=true]


[SE f=se066]
;//【ＳＥ】『』キラキラキラ〜

[OnName num="masato"]
What the hell...
[cpg cn=true]


Ahhh... something is forming a second beautiful space. It's hard to look directly at it because of the glare.
[cpg]

I'm worried that the rant against me has already gone through.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo511"]
[OnName num="sayo"]
"Ruru~"
[cpg cn=true]


[OnName num="butler"]
"Ruru~"
[cpg cn=true]


[OnName num="maid_B"]
"Rururu~"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo512"]
[OnName num="sayo"]
"Nice talk..."
[cpg cn=true]


[OnName num="masato"]
"What? Why are you crying?
[cpg cn=true]


[OnName num="butler"]
It's beautiful sisterly love.
[cpg cn=true]

[stopse g=2]
;//通常se

[OnName num="masato"]
Sisterly love? It's a beautiful sisterly love. Did you see that, Tanaka-san? What's wrong with your eyes? Shall I refer you to an ophthalmologist?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo513"]
[OnName num="sayo"]
"Shut up!"
[cpg cn=true]



[SE f=se068]
;//【ＳＥ】『叩く』ペチンッ

[WAIT time=1000]

[OnName num="masato"]
It hurts!
[cpg cn=true]


[FG f="CHA01_p4_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo514"]
[OnName num="sayo"]
It's a nice place. Keep it down.
[cpg cn=true]


[OnName num="glasses_man"]
Sis, you're picking on me.
[cpg cn=true]


[OnName num="maid_A"]
Yeah. Yeah, I'll do it.
[cpg cn=true]


[OnName num="masato"]
Hey, hey, hey! You in public! No! Do it over there!
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo515"]
[OnName num="sayo"]
I'm excited.
[cpg cn=true]


[OnName num="butler"]
Excited...
[cpg cn=true]


[OnName num="masato"]
Hey! Don't get your hopes up! No, no, no, no!
[cpg cn=true]

[STOPBGM]

[window target=false]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ＢＫ


[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]


[BGM f="se"]
;//【ＢＧ】『小夜の部屋』（夜）******************************************************

[SE f=se017]
;//【ＳＥ】『扉を閉める』バタン

[window target=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo516"]
[OnName num="sayo"]
"Hmm. I guess that's all over, huh? Well, good for you.
[cpg cn=true]


[OnName num="masato"]
......
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo517"]
[OnName num="sayo"]
What's wrong?
[cpg cn=true]


[OnName num="masato"]
"Ugh, ......, ugh..."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo518"]
[OnName num="sayo"]
What? What? Why are you crying?
[cpg cn=true]


[OnName num="masato"]
I was so scared... so scared... so scared.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo519"]
[OnName num="sayo"]
"......... What?
[cpg cn=true]


[OnName num="masato"]
I was afraid that Master... hated me... that he was going to throw me away. ...... I was so scared... so sad...
[cpg cn=true]


The emotions that had been bottled up until now began to flow with relief.
[cpg]

[FACE method="change_7" pos="2/3"]
[WAIT time=1500]

[FACE method="change_6" pos="2/3"]
[WAIT time=1000]

[VOICE f="Sayo520"]
[OnName num="sayo"]
...... Come here."
[cpg cn=true]


[OnName num="masato"]
"Ugh, ugh..."
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

;//レターボックスin
[FACE method="feadin" pos="4/7"]
[BG f="b_04_4_up.ui" time=1000]
[WAIT time=1500]


The master hugged me gently, not as if I were a child.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo521"]
[OnName num="sayo"]
I'm sorry. I've gone too far.
[cpg cn=true]


[OnName num="masato"]
"Ughhhh..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo522"]
[OnName num="sayo"]
You've been getting carried away lately, so I thought I'd give you a little moxa...
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo523"]
[OnName num="sayo"]
I'm sorry. I'm sorry. ...... I'm sorry.
[cpg cn=true]


[OnName num="masato"]
No, no, no, no, no, no, no, I...
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo524"]
[OnName num="sayo"]
Don't worry. Don't worry, one or two mistakes won't cause me to abandon my lovely servant.
[cpg cn=true]


[OnName num="masato"]
"Oh, Master..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo525"]
[OnName num="sayo"]
When I'm really tired of you, I'll throw you away without saying a word.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo526"]
[OnName num="sayo"]
As long as you are devoted to me, there will be no such future.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo527"]
[OnName num="sayo"]
Don't worry... you'll still be there for me tomorrow, won't you?
[cpg cn=true]


[OnName num="masato"]
"Yes, yes... my body and soul are yours, Master."
[cpg cn=true]


I continued to cry for a while after that.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

;//レターボックスout
[FACE method="out" pos="4/7"]


This is how the incident ended, with all four of us having our feelings intricately intertwined.
[cpg]

Ryuhei-kun will no longer be a servant of the master, but will continue to live and work as a servant.
[cpg]

I think the matter is settled... for the time being.
[cpg]

[STOPBGM]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1500]


[BGM f="sl"]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[SE f=se005]
;//【ＳＥ】『歩く』

[WAIT time=1000]

[window target=true]


[OnName num="glasses_man"]
"Oh, hi."
[cpg cn=true]


[OnName num="maid_A"]
"Hi."
[cpg cn=true]


[OnName num="masato"]
"Hi..."
[cpg cn=true]


Since then, the two of them have been together wherever they go (even inside the house).
[cpg]

It's a little hard to watch them loving each other morning, noon and night. I envy them.
[cpg]

But they seem to be doing their job, so there's no problem.
[cpg]

[OnName num="masato"]
"Well, clean, clean."
[cpg cn=true]



[SE f=se016]
;//【ＳＥ】『扉を開ける』ガチャ


[BG f="b_06_1.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『使用人の部屋（執事、田中の部屋）』（昼）******************************************************
;//ここは空き部屋の設定。

I walked into the empty room where they had come out to clean...
[cpg]

[OnName num="masato"]
"What's this?
[cpg cn=true]


I don't know what it's for, but I'm sure it's going to be used for violence.
[cpg]

I wondered why they had come out of this room, but... well, those people.
[cpg]

No, I might not be doing my job properly.
[cpg]

[OnName num="masato"]
Huh... this place is full of weirdos.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo528"]
[OnName num="sayo"]
"You say that?"
[cpg cn=true]


[OnName num="masato"]
Huh! Master... how long have you been there...?
[cpg cn=true]


Can you please stop sneaking up behind me like a ninja? I thought my heart was going to jump out of my chest.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo529"]
[OnName num="sayo"]
"How are those two?"
[cpg cn=true]


[OnName num="masato"]
They seem to be getting along well, you know?
[cpg cn=true]


[FG f="CHA01_p4_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo530"]
[OnName num="sayo"]
Well... they seem to be...
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo531"]
[OnName num="sayo"]
Well, I'm glad it all worked out.
[cpg cn=true]


[OnName num="masato"]
Both you and your husband have such deep pockets.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo532"]
[OnName num="sayo"]
Of course they are. They let people like you live here.
[cpg cn=true]


[OnName num="masato"]
Ugh... it hurts when you say it to my face.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo533"]
[OnName num="sayo"]
But ......
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo534"]
[OnName num="sayo"]
It's a good thing the bugs aren't here.
[cpg cn=true]


[OnName num="masato"]
......
[cpg cn=true]


Master said with a smile.
[cpg]

[STOPBGM]

[OnName num="masato"]
"Oh, um... master..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo535"]
[OnName num="sayo"]
What is it?
[cpg cn=true]

[BGM f="h1"]

[OnName num="masato"]
I was in the middle of the last one, and I haven't had any recently, so..."
[cpg cn=true]


I'm sure you're not the only one who has a problem with this.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo536"]
[OnName num="sayo"]
So? Say it more clearly.
[cpg cn=true]


[OnName num="masato"]
I'd like to be bullied by ...... too. Tease me, please..."
[cpg cn=true]


Then the corners of her mouth lifted.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo537"]
[OnName num="sayo"]
You've become quite a big man, ordering me around when I say I'll do it whenever I want.
[cpg cn=true]


But Master is not angry, he seems to be enjoying it.
[cpg]

[OnName num="masato"]
I'm sorry, sir. I'm sorry, but I really...want..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo538"]
[OnName num="sayo"]
"I ordered you to clean this room just a moment ago. Finish it first. After that, I'll do it when I feel like it.
[cpg cn=true]


[OnName num="masato"]
"But... there's no point in cleaning it, or it would be a double effort..."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo539"]
[OnName num="sayo"]
"............... Pfft! Couscous. Haha, haha, haha, haha, haha..."
[cpg cn=true]


Master laughed loudly.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo540"]
[OnName num="sayo"]
Huh, my stomach hurts. You really can't stand it when you beg so much...
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


I nodded silently.
[cpg]

[OnName num="masato"]
"Master..."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo541"]
[OnName num="sayo"]
I nodded silently. Well, today is special.
[cpg cn=true]


Master was teasing me at a different time, in a different place, and in a different way.
[cpg]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f=se025]
;//【ＳＥ】『スパンキング』

[WAIT time=1000]

[OnName num="masato"]
"Ow!"
[cpg cn=true]

[WAIT time=1000]


[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

;//ＢＫ


[jump storage="ep012.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////
