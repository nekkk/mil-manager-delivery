
*start



;#################################################
*Ep001|M turning point
;#################################################

[SCENE id=1]


[stflag jump_scene=0]
;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


--a few days later
[cpg]


[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[STOPBGM]

[WAIT time=100]

[BGM f="d1"]
[WAIT time=100]
;//【ＢＧ】『分岐路のある道』（昼）******************************************************

;//※街の中心や住宅街（小夜宅がある方面。小夜宅は小高い丘の上にある）への分岐路がある道

[SE f=se006]
;//【ＳＥ】『走る』

[OnName num="masato"]
Huh, huh... this hill is surprisingly steep.
[cpg cn=true]


With my resume in hand and my heart pounding, I'm on my way to the designated interview location.
[cpg]

Dada dada dada. I run, out of breath.
[cpg]

I chose to walk to save money, but the place was farther away than I had expected... I was five minutes past the designated time.
[cpg]

My resume, which I had been clutching so as not to lose it, was crumpled and stained from sweat.
[cpg]

This is how I felt before the interview... I'm sure I'll fail again.
[cpg]

But the interview place was just a stone's throw away. I stood in front of the building in a gloomy mood, thinking that I should just take the test first.
[cpg]

[BG f="b_03_2_up.ui" time=1000]

;//レターボックスin
[FACE method="feadin" pos="4/7"]
[WAIT time=2000]


[SE f=se094]
;//【ＳＥ】『どどーん』

[OnName num="masato"]
I stood in front of the building in a gloomy mood, thinking, "What the hell is this house?
[cpg cn=true]


The interview place was a little further down the street in a residential area... on top of a small hill.
[cpg]

Towering in front of me was an extremely large mansion. Could this really be the place designated for the interview?
[cpg]


[SE f=se012]
;//【ＳＥ】『門が開く』ギギギ

[WAIT time=1000]


[OnName num="masato"]
Whoa!"
[cpg cn=true]


I wondered as I checked the documents in my hand over and over again, and the gate opened by itself.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』

[WAIT time=1500]

[OnName num="butler"]
"Welcome. My name is Tanaka, and I am the butler of this family.
[cpg cn=true]


Butler...? There really is a butler.
[cpg]

Indeed, the elderly man who came out from inside had the perfect appearance to be called a "butler".
[cpg]

He was neatly dressed and his gestures were clean. He was perfectly respectful and I felt that he was from a different world than mine.
[cpg]

[OnName num="masato"]
My name is Sakigawa. I'm here for an interview..."
[cpg cn=true]


[OnName num="butler"]
"Yes. This way, please.
[cpg cn=true]


It looks like I'm in the right place. Suddenly...I'm getting anxious.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』

;//ＢＫ
[STOPBGM]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


;//レターボックスout
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_00_2.ui" time=1000]

[window target=true]

[WAIT time=1000]

[BGM f="sl"]
[WAIT time=1000]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[OnName num="masato"]
"Wow...this is amazing. It's a rich man's house.
[cpg cn=true]


The butler, Mr. Tanaka, showed me around the mansion and my mouth dropped open halfway.
[cpg]

It was a mansion that I could guess from the outside, but naturally the inside was also... extremely spacious and luxurious.
[cpg]

If I got the interview, I'd be working here... I was getting anxious again.
[cpg]

[OnName num="butler"]
"Please wait here."
[cpg cn=true]


[OnName num="masato"]
"Yes, sir!
[cpg cn=true]



I was not taken to any room, but told to wait in the entrance hall.
[cpg]

[OnName num="masato"]
(Are all these people here for the interview?)"
[cpg cn=true]


I was not the only one, but there were many others who had probably come for the interview as well.
[cpg]

Nearly 20 men were lined up in a row in the hall... what a strange sight...
[cpg]

[OnName num="butler"]
"Miss, we're all here."
[cpg cn=true]


[VOICE f="Sayo006"]
[OnName num="sayo"]
"Yes."
[cpg cn=true]



[SE f=se005]
;//【ＳＥ】『歩く』コツコツコツ

--The person came with a beautiful voice like the sound of a bell and the sound of shoes.
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

[stopse g=2]
;//通常se

;//●ＣＧ（小夜・ご主人様登場！：豪邸の広間）ev_01
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1500]


[VOICE f="Sayo007"]
[OnName num="sayo"]
"One two three... that's quite a lot this time."
[cpg cn=true]


[OnName num="masato"]
"........."
[cpg cn=true]


The person who greeted us was a young girl who looked like a child.
[cpg]

She was beautiful, cute, and graceful.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[STOPBGM]

[VOICE f="Sayo008"]
[OnName num="sayo"]
"Are you the ones who want to be 'kept' by me?"
[cpg cn=true]


[OnName num="all_members"]
"Yes...?
[cpg cn=true]

[SE f=se077]
;//【ＳＥ】『喧騒』

[BGM f="h1"]


The response was unanimous.
[cpg]

[OnName num="butler"]
"My Lady.
[cpg cn=true]


[VOICE f="Sayo009"]
[OnName num="sayo"]
"I'm sorry. That was just a joke. Couscous."
[cpg cn=true]


--She was the 'Master' mentioned in the recruitment letter....
[cpg]

[stopse g=2]
;//通常se

[stopse g=3]
;//通常se

[window target=false]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ


;//レターボックスin
[FACE method="in" pos="4/7"]
[WAIT time=1]

[BG f="b_00_2_up.ui" time=1000]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1000]

[WAIT time=1000]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[window target=true]



[OnName num="butler"]
Thank you very much for coming today, everyone.
[cpg cn=true]


After our resumes were collected, we were lined up in front of the stairs in the center of the hall and were being briefed.
[cpg]

Mr. Tanaka was giving us an explanation, but I couldn't really get it into my head. The others seemed to be doing the same.
[cpg]

[OnName num="masato"]
(Could it be that this person is the master?)"
[cpg cn=true]


I don't think so, but judging from his behavior and the way the butler handled him, I'm sure he is.
[cpg]

The job description said that it was a job to serve the master. If I'm hired, I'll probably worship this girl as my master and serve her as a butler or something...
[cpg]

My heart skipped a beat at the thought of such a rare situation in my life.
[cpg]

[OnName num="man"]
"Wait, what do you mean?
[cpg cn=true]


Suddenly a loud voice rang out and I was jolted back to reality.
[cpg]

I had been watching her standing in the middle of the room and hadn't heard her explanation, so I couldn't grasp the situation.
[cpg]

[OnName num="butler"]
"It's just as I said."
[cpg cn=true]


[OnName num="man"]
"Yes, because... a job to serve your master..."
[cpg cn=true]


[OnName num="butler"]
Yes, I'm sure of it.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo010"]
[OnName num="sayo"]
I'm sorry, but it's only natural.
[cpg cn=true]


The girl explained herself.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo011"]
[OnName num="sayo"]
We have enough employees. In the first place, you can't just hire someone without any experience or skills as a butler. You'll just be stuck with nothing to do.
[cpg cn=true]


[OnName num="man"]
It's true, but..."
[cpg cn=true]


I'm sure the people who came here had the same perception as I did, that a job serving others meant being a butler or something.
[cpg]

It's not that I'm angry, it's that I'm confused.
[cpg]

[OnName num="glasses_man"]
"So you're saying you'll hire me as a servant?"
[cpg cn=true]

[OnName num="butler"]
'We have enough of that too.
[cpg cn=true]


This time they were all puzzled. If it's not even a job to be a servant and do cleaning and miscellaneous work, then what the hell is it that we've been called in to do?
[cpg]

[OnName num="butler"]
What we are looking for is a playmate for the young lady. No, to put it more simply..."
[cpg cn=true]


The butler was about to continue, but she interrupted him.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo012"]
[OnName num="sayo"]
The butler tried to continue, but she interrupted him, "There's no point in taking too long. Let's get on with the interview, shall we?
[cpg cn=true]


So the explanation was over and the interview began.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ



;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=1]

[BG f="b_00_2.ui" time=1000]

[WAIT time=1000]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[OnName num="masato"]
What is a playmate?
[cpg cn=true]


The interview began with me feeling uneasy.
[cpg]

However, we weren't taken to a separate room, and Masato and the others stood in a line while the girls stared at us intently. It was as if we were being judged.
[cpg]

[OnName num="glasses_man"]
I thought they would do it one by one or in groups.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo013"]
[OnName num="sayo"]
It's a waste of time to do that.
[cpg cn=true]


[OnName num="glasses_man"]
But, but...
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo014"]
[OnName num="sayo"]
Shut up.
[cpg cn=true]


One of the braver ones voiced his doubts, but the gentle feeling he had had before was nowhere to be seen. In the end, he was intimidated into silence.
[cpg]

What surprised me was that nearly 20 men really shut up when told to shut up by such a child and a girl.
[cpg]

Perhaps it's an instinctive power that makes us feel that we should not go against them.
[cpg]

However, what was even worse was what happened next. The interview was already different from a normal one, and they made some ridiculous demands.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo015"]
[OnName num="sayo"]
"Then, one by one, kneel down and kiss my feet."
[cpg cn=true]


[OnName num="masato"]
"What?
[cpg cn=true]

[SE f=se077]
;//【ＳＥ】『喧騒』

[OnName num="man"]
"What the hell... why are you doing that?"
[cpg cn=true]


The rest of us were confused. A few were confused and the rest protested.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo016"]
[OnName num="sayo"]
Bother."
[cpg cn=true]

[stopse g=3]
;//通常se

But their defiance was quelled with a single word. For some reason, everyone in the room did as they were ordered.
[cpg]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

[BG f="b_00_2.ui" time=1000]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="5/5" time=1000]
[WAIT time=1500]


[VOICE f="Sayo017"]
[OnName num="sayo"]
"Hmmm...hmmm... Hmmm..."
[cpg cn=true]


The moment he kissed her, I watched him as if I were inspecting him.
[cpg]

Most of the men here would have never imagined doing this to a child.
[cpg]


[SE f=se005]
;//【ＳＥ】『歩く』

[move from="5/5" to="4/5" ease="easeInOutSine" time=1500]
[WAIT time=1500]

[stopse g=2]
;//通常se

[FACE method="change_7" pos="4/5"]
[WAIT time=1500]

[VOICE f="Sayo018"]
[OnName num="sayo"]
You're nervous. In a normal interview, you'd get points deducted.
[cpg cn=true]

[SE f=se005]
;//【ＳＥ】『歩く』
[move from="4/5" to="3/5" ease="easeInOutSine" time=1500]
[WAIT time=1500]

[stopse g=2]
;//通常se

[FACE method="change_3" pos="3/5"]
[WAIT time=1500]

[VOICE f="Sayo019"]
[OnName num="sayo"]
"Hey. If you're going to kiss my feet, you're going to kiss my toes, right?
[cpg cn=true]

[FACE method="change_1" pos="3/5"]


It was as if I was being judged as a man rather than a servant.
[cpg]


;//レターボックスin
[FACE method="slidein" pos="4/7"]

[FO pos="3/5" time=1500]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1500]

[SE f=se005]
;//【ＳＥ】『歩く』

[WAIT time=2000]

Finally, it was my turn.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo020"]
[OnName num="sayo"]
...... You look particularly nervous.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo021"]
[OnName num="sayo"]
"Do you ...... like little girls?"
[cpg cn=true]


[OnName num="masato"]
"No, no, no, no, no, no, no, no, no, no.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo022"]
[OnName num="sayo"]
You got it right. Only a few people can respond like that.
[cpg cn=true]


I can't believe you can see through my desperate attempts to hide my sexuality in an instant.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo023"]
[OnName num="sayo"]
"And you've never had a girlfriend, have you?"
[cpg cn=true]


This situation alone is embarrassing enough to make my face burn, but being told that makes me even hotter.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo024"]
[OnName num="sayo"]
It's perfect in a way. I like the fact that you have no redeeming qualities.
[cpg cn=true]


I was thrilled by the harshness of his words.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo025"]
[OnName num="sayo"]
And remember. I like you better when you're honest.
[cpg cn=true]


I want to die, I want to go home. I wanted to die, I wanted to go home. I turned my head and thought of nothing else.
[cpg]


;//ＢＫ



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]

;//レターボックスout
[FACE method="out" pos="4/7"]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=2000]


[BG f="b_00_2.ui" time=1000]

[WAIT time=1000]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[window target=true]


Finally, the first interview? The first interview seemed to be over. And now....
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo026"]
[OnName num="sayo"]
"You're too bad, but I'm sorry. Please leave."
[cpg cn=true]


[OnName num="man"]
"What? Why?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo027"]
[OnName num="sayo"]
"Because you're not good enough."
[cpg cn=true]


And so some of them were sent home. I guess it simply means that they were not accepted.
[cpg]

They all seemed unconvinced that they had been exposed to such lasciviousness, but after receiving some thick envelopes, they left without complaining.
[cpg]

I couldn't believe it, but it was just as I had been told.
[cpg]

I wondered what kind of rich people they were, instead of saying nothing about today's events on .......
[cpg]

One by one, more and more people walked out the door. In the end, there were only four of us left. I was one of them.
[cpg]

To be honest, I don't know what this girl is doing here, but I also wondered why I hadn't been sent home.
[cpg]

If I had seen her reaction earlier, it would have been normal for me to fail.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo028"]
[OnName num="sayo"]
You have passed. You're hired."
[cpg cn=true]


She said to the four people who remained there. Everyone was surprised at the unexpected.
[cpg]

But there was one thing that all four of them had in common. That is... the person she said she was nervous about.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo029"]
[OnName num="sayo"]
We're all hired as of now. However, there is one condition for them to actually work for us."
[cpg cn=true]


[OnName num="glasses_man"]
"What? A condition?
[cpg cn=true]


[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=800]

[WAIT time=1500]


[VOICE f="Sayo030"]
[OnName num="sayo"]
It's like a test. If you don't like it, you can quit at any time. If you don't like it, you can quit at any time. Regardless of the outcome, we will provide you with a certain amount of reward.
[cpg cn=true]


There were many strange things about being gathered in this way, the reasons for it, and the content of the interview, but this was also something out of the ordinary. The treatment was unbelievable.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo031"]
[OnName num="sayo"]
"Now, who do you think would be a good playmate for me?
[cpg cn=true]



[VOICE f="Sayo032"]
[OnName num="sayo"]
"My... servant," he said.
[cpg cn=true]


Everyone gasped at the words. Servant...? That's what it sounded like. Before I could even mention what I had just said, things proceeded in a hurry.
[cpg]

[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[SE f=se013]
;//【ＳＥ】『服を脱ぐ』シュルシュル
[WAIT time=1100]

;//レターボックスin
[FACE method="in" pos="4/7"]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_2_up.ui" time=1]

[window target=true]


The four of us gasped as she peeled off her clothes, just barely visible or invisible.
[cpg]

[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=2000]

She pulls up her long skirt, revealing her tight, age-appropriate legs. She took off her shoes and went barefoot.
[cpg]

Her feet, exposed to their eyes, were beautiful, smooth-skinned, and well-groomed.
[cpg]

What do they want me to do, what do they want me to do? What should I do? There was no explanation.
[cpg]

But by her fearless smile and her manner, Masato and the others who were still there understood.
[cpg]

She moved the tips of her toes on her right foot and turned her ankle like a track athlete before the start of the race to prepare for the exercise.
[cpg]

Her legs were beautiful. But they were also toned.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo033"]
[OnName num="sayo"]
"Hey. From whom?"
[cpg cn=true]


At her words, the first person to come forward was the person with glasses on the other side of Masato.
[cpg]

[OnName num="glasses_man"]
I'll go first, please.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo034"]
[OnName num="sayo"]
"You're very ambitious. I don't mind people like that.
[cpg cn=true]


The man with the glasses crawled on all fours in a natural motion, saying in a small voice, "Excuse me.
[cpg]

Why in the world would he dress like that? The three of us wondered why he was doing it without hesitation.
[cpg]

But finally, they understood. Why were they left here? Surely the man in the glasses in front of them was smart.
[cpg]

He had realized it before anyone else, and he had been more honest with himself than anyone else.
[cpg]

His actions made the remaining three understand who they were and why they had been chosen.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo035"]
[OnName num="sayo"]
It would be easier if you were a little higher up.
[cpg cn=true]


[OnName num="glasses_man"]
"Yes, sir."
[cpg cn=true]


The man with glasses raised his buttocks quickly to meet the request.
[cpg]



[FACE method="change_1" pos="2/3"]


Then, a few beats later, without a word of "let's go" or "get into it"... her right leg moved as if by surprise.
[cpg]

[SE f=se040]
;//【ＳＥ】『蹴り』

[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=500]
[WAIT time=800]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=500]
[WAIT time=1000]


ーー！！！！！
[cpg]

With a sound of cutting wind, she was kicked by the leg that was swung out with all her might, probably with all her might. It was a horrible act that hurt just by looking at it.
[cpg]

[SE f=se062]
;//【ＳＥ】『倒れる』

[WAIT time=1000]

It's a great way to make sure you're getting the most out of your vacation.
[cpg]

At the command of the master, who seemed somewhat satisfied with the sight of him, the butlers and maids-in-waiting immediately took care of him and took him out of the house. They will probably take him to the hospital.
[cpg]

[OnName num="butler"]
"You are welcome, sir.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo036"]
[OnName num="sayo"]
"Of course, he's passed the test... treat him when he wakes up. Try again if he asks.
[cpg cn=true]


[OnName num="butler"]
"Yes, sir."
[cpg cn=true]


With that exchange, his final interview was over. Next it was the turn of the three of us. The master looked at me.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo037"]
[OnName num="sayo"]
"Now, who's next?"
[cpg cn=true]


;//ＢＫ


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="b_00_2.ui" time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]


;//レターボックスout
[FACE method="out" pos="4/7"]

[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1]
[window target=true]

[WAIT time=2000]

;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[VOICE f="Sayo038"]
[OnName num="sayo"]
"What about you?"
[cpg cn=true]


[OnName num="masato"]
"Well, I..."
[cpg cn=true]


She asks me, as I am the last one.
[cpg]

The other two had refused to take the test after seeing the scene before and had already left. It seems that they're hiring, and they're giving them a reprieve.
[cpg]

I wondered if it was some kind of training or trial period. Now that I was the only one left, I had to choose Masato.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo039"]
[OnName num="sayo"]
If you don't like it, you shouldn't do it. You might become useless.
[cpg cn=true]


As she said this, she was preparing.
[cpg]

It was as if she was sure Masato would not refuse. Masato was also confused.
[cpg]

I'm not kidding, I can't stand it when they do that to me.... But he didn't even try to run out the door.
[cpg]

I already know what I am. But I can't admit it honestly. I'm conflicted.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo040"]
[OnName num="sayo"]
"Well, what do you want to do?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo041"]
[OnName num="sayo"]
...... I'm sorry, but I don't have time for this either. Let's call it a day. Please come back later when you're ready."
[cpg cn=true]

[SE f=se005]
;//【ＳＥ】『歩く』
[FO pos="2/3" time=1000]

With that, she turned on her heel. When she turned her back, I felt like she was telling me that she didn't need me anymore...
[cpg]

[OnName num="masato"]
"Wait, wait! Please..."
[cpg cn=true]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

I called out as quickly as I could.
[cpg]


[OnName num="masato"]
I'll take it... please.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo042"]
[OnName num="sayo"]
"C'mon, I get it."
[cpg cn=true]


[SE f=se078]
;//【ＳＥ】『衣擦れ』

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3100]
[FO pos="2/3" time=1]
[BG f="b_00_2_up.ui" time=1]

;//レターボックスin
[FACE method="in" pos="4/7"]

[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]




[WAIT time=1000]

[window target=true]

I decided to take the test. I changed my posture.
[cpg]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2_up.ui" time=1]

[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=2000]
[WAIT time=3000]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo043"]
[OnName num="sayo"]
"Are you sure you want to do that?"
[cpg cn=true]


[OnName num="masato"]
Yes, from the front, please.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo044"]
[OnName num="sayo"]
"Hmm... that's unusual. I like that.
[cpg cn=true]


I was on my back, not on all fours, with my hands and feet on the floor, my hips in the air. It's definitely easier to kick in this position.
[cpg]


[SE f=se033 loop=true]
;//【ＳＥ】『心音』

[OnName num="masato"]
"Ha, ha..."
[cpg cn=true]

My breathing became erratic due to extreme tension and fear.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo045"]
[OnName num="sayo"]
There's no need to be so nervous.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo046"]
[OnName num="sayo"]
You like this, don't you?
[cpg cn=true]


Saya grinned at me and pointed out the truth about my partner.
[cpg]

I clenched my teeth as my face turned red and I didn't answer anything. In my head, I desperately try to deny it.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo047"]
[OnName num="sayo"]
"...... You're so stubborn. I told you I like girls who are honest..."
[cpg cn=true]


The strength in her eyes and legs tightened.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo048"]
[OnName num="sayo"]
I'm sure you'll be happy to hear that.
[cpg cn=true]


[stopse g=6]
;//通常se

[STOPBGM]

[SE f=se030]
;//【ＳＥ】『風切音』
[FO pos="2/3" time=800]
[BG f="black.ui" time=800]
[WAIT time=800]



Her right foot swung out at the same time as her words. It was the fastest and strongest of the day.
[cpg]

In that moment, I thought in fear and unusual excitement.
[cpg]

No, no, no, no, no, no, no, no, no, no, no, no, no, no. No, no, no. Absolutely not.
[cpg]


;//画面揺れる演出

[SE f=se001]
;//【ＳＥ】『轟音』ドゴンッ


[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=500]


;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=1500]

[WAIT time=1100]
[BG f="white.ui" time=1]

[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]
[WAIT time=1000]

[SE f=se062]
;//【ＳＥ】『倒れる』

[WAIT time=1000]

[window target=true]


[OnName num="masato"]
"Ugh ......!
[cpg cn=true]


And no matter what I thought, the pain remained the same.
[cpg]

Like the others, I screamed, my body convulsed, and I lost consciousness with the whites of my eyes.
[cpg]

[window target=false]


[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

[BG f="b_00_2.ui" time=1000]

[WAIT time=1000]


[BGM f="h1"]
[WAIT time=100]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]

[window target=true]


[VOICE f="Sayo049"]
[OnName num="sayo"]
"You're laughing while passing out."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo050"]
[OnName num="sayo"]
This is going to keep me ...... occupied.
[cpg cn=true]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[FO pos="2/3" time=2000]
[BG f="black.ui" time=2000]
[WAIT time=2500]
;//ＢＫ

[jump storage="ep002.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
