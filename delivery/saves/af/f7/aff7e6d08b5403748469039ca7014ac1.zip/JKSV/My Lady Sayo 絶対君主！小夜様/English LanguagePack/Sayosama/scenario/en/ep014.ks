*start

;#################################################
*Ep014|Blood, Sweat, and M
;#################################################

[SCENE id=14]


[stflag jump_scene=0]
[window target=false]

[STOPBGM]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep002で発生	ジャンプしてきた場合奉仕ルートで固定
[stflag gohome_flag=1]
[stflag pets_flag=0]
[endif]



[BG f="black.ui" time=1000]
[WAIT time=1000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]

[SE f=se005]
;//【ＳＥ】『歩く』

[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

[BGM f="se"]
;//【ＢＧ】『豪邸、廊下』（夜）******************************************************


[window target=true]

[stopse g=2]
;//通常se

[OnName num="masato"]
Hmm...the light..."
[cpg cn=true]


On my way back to my room after returning from a walk, I saw a faint light... leaking from my master's room as I passed by.
[cpg]

The clock was pointing to midnight. Normally, he should have gone to bed by now.
[cpg]

[OnName num="masato"]
"You don't mean..."
[cpg cn=true]


I stood in front of the door and thought about knocking... I just put my hand on the doorknob.
[cpg]

[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

[SE f=se016]
;//【ＳＥ】『扉を静かに開ける』カチャ、キィー…


[transition target={true} rule="tobira2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tobira2.webp" color={0x000000ff} time=2000]
[WAIT time=2100]
[window target=true]
;//【ＢＧ】『豪邸、廊下』（夜）******************************************************

When I entered the room, I saw that a small light near the window had been turned on.
[cpg]

[OnName num="masato"]
"........."
[cpg cn=true]


The chair next to it was slowly and slightly swaying.
[cpg]

I opened my mouth to speak, but it was too late.
[cpg]

[FG f="CHA01_p3_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo558"]
[OnName num="sayo"]
Who?"
[cpg cn=true]


Master called out to me.
[cpg]

[OnName num="masato"]
It's me, Master. It's me, master.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo559"]
[OnName num="sayo"]
You should at least knock on .......
[cpg cn=true]


[OnName num="masato"]
I'm sorry.
[cpg cn=true]


She did not get up or look at me, but scolded me with her posture.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo560"]
[OnName num="sayo"]
What is it that brings you to the master's room so late at night?
[cpg cn=true]


[OnName num="masato"]
"Well, I saw a light..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo561"]
[OnName num="sayo"]
Oh, really? I thought you might have come to crawl in the night.
[cpg cn=true]


[OnName num="masato"]
......
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo562"]
[OnName num="sayo"]
Say something.
[cpg cn=true]


[OnName num="masato"]
Master, it's getting late. You should be resting...
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo563"]
[OnName num="sayo"]
...... Now you're telling me what to do? Huh. I can't even be mad at you for being so rude...
[cpg cn=true]


[OnName num="masato"]
Excuse me.
[cpg cn=true]


Master sat in the chair and refused to go to sleep, even though it was late at night.
[cpg]

[OnName num="masato"]
If you don't get some sleep, it will be bad for you.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo564"]
[OnName num="sayo"]
...... Can't sleep?
[cpg cn=true]


[OnName num="masato"]
Can I get you something to help you fall asleep? Would you like some hot milk?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo565"]
[OnName num="sayo"]
......... I don't want to sleep.
[cpg cn=true]


[OnName num="masato"]
I don't want to sleep, but I've got school tomorrow and I'm feeling a little under the weather.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo566"]
[OnName num="sayo"]
I'm the one who said I don't want to sleep!
[cpg cn=true]



[SE f=se059]
;//【ＳＥ】『立ち上がる』ガタン

[WAIT time=1500]



[OnName num="masato"]
"......"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo567"]
[OnName num="sayo"]
What are you... what are you doing? You're acting like a servant. I didn't put you here to be bullied!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo568"]
[OnName num="sayo"]
It would have been better if you'd said you were here to be bullied! Stop your pointless meddling!
[cpg cn=true]


[OnName num="masato"]
"Meddling?"
[cpg cn=true]


I'm sure you'll be able to understand what I mean.
[cpg]

[OnName num="masato"]
"I wonder if what Mr. Tanaka and the others are doing is pointless or meddlesome."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo569"]
[OnName num="sayo"]
"What...?"
[cpg cn=true]


Then she shushed him and sat back in her chair.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo570"]
[OnName num="sayo"]
...... I'm sorry, I'm a little... upset.
[cpg cn=true]


[OnName num="masato"]
No, I'm sorry for being such a bad servant.
[cpg cn=true]


After a few moments of mutual silence, she opened her mouth.
[cpg]

[VOICE f="Sayo571"]
[OnName num="sayo"]
I don't want to sleep... I don't want to sleep. I'm scared..."
[cpg cn=true]


It was an honest admission of her feelings.
[cpg]

[VOICE f="Sayo572"]
[OnName num="sayo"]
I don't want to sleep. When I sleep... it goes on and on and on... after a few sleeps, a week will fly by."
[cpg cn=true]


After all, it was the thought of marriage that was bothering her.
[cpg]

Now that marriage was in the near future and getting closer, Master was feeling blue.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo573"]
[OnName num="sayo"]
"I don't want to go to that man. I don't want to be tamed by him, I don't want that.
[cpg cn=true]


[OnName num="masato"]
Why don't you talk to your husband about it?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo574"]
[OnName num="sayo"]
"How could I?"
[cpg cn=true]


There was no trace of her usual bravado or strength in her voice.
[cpg]

[VOICE f="Sayo575"]
[OnName num="sayo"]
That man is scary to look at. I've heard nothing but good things about him, and if I marry him, I'm sure he'll do whatever he wants to me and mess me up.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


If I were in the same position, I don't think I could stand it.
[cpg]

I'm not going to let my master go to such a place.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo576"]
[OnName num="sayo"]
I don't want my master to go there. It's not something I can say as I've kept you as a pet and obeyed you as a servant until now..."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo577"]
[OnName num="sayo"]
"What I have done is unforgivable. What I have done is unforgivable, and you will suffer the same fate. You'll get what's coming to you...
[cpg cn=true]


I don't know how to explain it. I don't know how difficult it is to understand, but I do have some objections to what you just said.
[cpg]

[OnName num="masato"]
"Well, when you say unforgivable, you mean... who?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo578"]
[OnName num="sayo"]
What? It's me, of course.
[cpg cn=true]


[OnName num="masato"]
That's ridiculous. I became Master's servant because I wanted to. I'm happy to be bullied. What's wrong with that? What's wrong with something that is consensual and in agreement with your interests before you even forgive it?
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo579"]
[OnName num="sayo"]
"Well, that's..."
[cpg cn=true]


[OnName num="masato"]
I'm sure you'll agree with me. However, that would be an answer that disparages the most important person, the other person. As for me, I am very disappointed.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo580"]
[OnName num="sayo"]
What do you mean by "very disappointing"?
[cpg cn=true]


[OnName num="masato"]
A master and a servant cannot exist without one another. And it is wrong for either of them to feel guilty. Then they are both wrong."
[cpg cn=true]

[OnName num="masato"]
"Both are good, both are bad... that's mutuality, that's one and the same, master and servant."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo581"]
[OnName num="sayo"]
......... Oh, okay, okay, okay. I'm sorry.
[cpg cn=true]


[OnName num="masato"]
Do you understand?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo582"]
[OnName num="sayo"]
Yes, I do. I hate it. It's really hard to deal with you.
[cpg cn=true]


[OnName num="masato"]
Yeah, I guess that's...
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo583"]
[OnName num="sayo"]
I feel like a fool for worrying about it now.
[cpg cn=true]


[OnName num="masato"]
I think it's good to think about your problems.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo584"]
[OnName num="sayo"]
I think it's good to worry and think.
[cpg cn=true]


[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=100]
[WAIT time=200]

[SE f=se040]
;//【ＳＥ】『蹴る』バキッ

[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=100]
[WAIT time=500]

[OnName num="masato"]
That's right!
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo585"]
[OnName num="sayo"]
"What the..."
[cpg cn=true]


My expression brightened up a little, despite my anger.
[cpg]

Yes, in my own way, I will cheer up and support my master.
[cpg]

If I decide to do so, there is only one thing to do.
[cpg]

[OnName num="masato"]
"Um, Master."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo586"]
[OnName num="sayo"]
What?
[cpg cn=true]


[OnName num="masato"]
If you can't sleep... why don't you do some exercise, if you don't mind?
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo587"]
[OnName num="sayo"]
Exercise? At this hour?
[cpg cn=true]


[OnName num="masato"]
Yes. It will help relieve your stress, and I think that if your body is tired from exercising you will be able to sleep better.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo588"]
[OnName num="sayo"]
Well, that's true, but...
[cpg cn=true]


[OnName num="masato"]
How about some indoor exercise?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo589"]
[OnName num="sayo"]
I don't mind. Since you can't sleep anyway, I'll go with you.
[cpg cn=true]


[OnName num="masato"]
Thank you very much.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo590"]
[OnName num="sayo"]
So, what do you do?
[cpg cn=true]


[OnName num="masato"]
Well, you know..."
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[STOPBGM]

I quickly took off my clothes in an elegant manner.
[cpg]

[BGM f="co"]

[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo591"]
[OnName num="sayo"]
What?
[cpg cn=true]


[OnName num="masato"]
Master.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo592"]
[OnName num="sayo"]
What the...? You idiot! Why are you suddenly taking off your clothes? Is the heat getting to you?
[cpg cn=true]


[OnName num="masato"]
Why are you so shy?
[cpg cn=true]


[VOICE f="Sayo593"]
[OnName num="sayo"]
Why are you so shy? - Know your place! I don't think I'm going to take off my clothes in this situation, you idiot!
[cpg cn=true]


Something about Master's reaction that I've never seen before is so cute. I never thought she would blush at the sight of me naked.
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo594"]
[OnName num="sayo"]
I'm sure you'll agree. Get away from me! Don't come over here!
[cpg cn=true]


[OnName num="masato"]
"Oh, Master. That's not what I meant.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo595"]
[OnName num="sayo"]
What's wrong? What's different? No way. ......
[cpg cn=true]


[OnName num="masato"]
No, no, you're going to use me for exercise.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo596"]
[OnName num="sayo"]
I knew it!
[cpg cn=true]


[OnName num="masato"]
Yes. I'll be your sandbag. We'll be boxing.
[cpg cn=true]


[VOICE f="Sayo597"]
[OnName num="sayo"]
-----?
[cpg cn=true]


[OnName num="masato"]
But it's not boxing if it's one-sided, is it?
[cpg cn=true]


As I added the explanation, the master, who had been in a shy maiden pose, looked at me like she was looking at something she shouldn't.
[cpg]

It's funny.
[cpg]

What's boxing without clothes? It's a scene that will make you bite your tongue.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo598"]
[OnName num="sayo"]
"......... in three lines, please."
[cpg cn=true]


[OnName num="masato"]
"Well...
[cpg cn=true]


The master.
The servant.
Punch! Punch!
[cpg]

Right!
[cpg]

[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=100]
[WAIT time=200]

[FG f="CHA01_p3_03_a.ui" method="change_3"  pos="2/3" time=1]


[SE f=se025]
;//【ＳＥ】『超ビンタ』



[OnName num="masato"]
Huh?
[cpg cn=true]



[SE f=se062]
;//【ＳＥ】『倒れる』ドタン

[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=100]
[WAIT time=500]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo599"]
[OnName num="sayo"]
"Fuuuuuck~~~......"
[cpg cn=true]


A strong slap was unleashed with a movement like a martial artist. I remembered that the master had learned self-defense and so on.
[cpg]

[OnName num="masato"]
"Ow, that hurt. My neck... what are you doing?"
[cpg cn=true]


[VOICE f="Sayo600"]
[OnName num="sayo"]
"That's my line.You've destroyed everything that's happened so far, all the flags, and you're a super, super, super idiot...!"
[cpg cn=true]


"I'm sorry, I'm sorry, I'm sorry!
[cpg]

[OnName num="masato"]
I'm sorry, I'm sorry, I'm sorry! I just wanted to play with my master!
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo601"]
[OnName num="sayo"]
I just wanted to play with you!" "You have other things to play with."
[cpg cn=true]


[OnName num="masato"]
I'm sorry, I'm sorry! Hahaha.
[cpg cn=true]


[OnName num="masato"]
"Master, please hit me! You can also use kicking and strangling techniques in a different kind of martial arts fight!
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo602"]
[OnName num="sayo"]
(......) What's with that innocent smile? ( What's with that innocent smile, you're like a child... though what you're saying is dangerous)
[cpg cn=true]


[OnName num="masato"]
Then, master. I will stay with you until you fall asleep, or even until morning.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo603"]
[OnName num="sayo"]
"I guess I didn't know you yet."
[cpg cn=true]


She sighed.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo604"]
[OnName num="sayo"]
You're... really, really, really genuine.
[cpg cn=true]



[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=100]
[WAIT time=200]

[SE f=se040]
;//【ＳＥ】『蹴る』バキッ

[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=100]
[WAIT time=500]

[OnName num="masato"]
"Ugh!
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo605"]
[OnName num="sayo"]
Ugh, you caught me off guard.
[cpg cn=true]


I leaned forward at the sudden attack. I'm afraid of your eyes, Master.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo606"]
[OnName num="sayo"]
There is no need for discretion or mercy. I've learned that, Saya.
[cpg cn=true]


I didn't say that much, but....
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo607"]
[OnName num="sayo"]
"Then... let's get on with it, shall we?"
[cpg cn=true]


[OnName num="masato"]
"Oh, wait, please wait. I still have one more thing to tell you.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo608"]
[OnName num="sayo"]
What?
[cpg cn=true]


[OnName num="masato"]
"Master, would you like to make a bet?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo609"]
[OnName num="sayo"]
"A bet?"
[cpg cn=true]


[OnName num="masato"]
I'm going to put in a lot of effort, and I'd like to be rewarded for it. I'll do my best, but I'd like a little reward.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo610"]
[OnName num="sayo"]
"Well, okay. Well, okay, if you can endure without giving up halfway through I'll do you one favor. How about that?"
[cpg cn=true]


[OnName num="masato"]
"Yes!"
[cpg cn=true]



And so, the one-sided boxing match between Master and me was about to begin.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo611"]
[OnName num="sayo"]
"Huh. I can't believe that the martial arts I've learned so far are coming in handy in a place like this. ......... Somehow, I feel bad for the teachers who taught me..."
[cpg cn=true]


[OnName num="masato"]
Master, please cheer up! Fight!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo612"]
[OnName num="sayo"]
It's your fault! Come on, sandbag.
[cpg cn=true]


[OnName num="masato"]
Yes, sir! Oh, by the way, Master... you mentioned martial arts, what are you doing?
[cpg cn=true]


As I hurriedly got ready, I asked him somehow.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo613"]
[OnName num="sayo"]
"Judo 3rd dan, Karate 3rd dan, Kendo 2nd dan. I also do Muay Thai, Shorinji, Sambo, Kempo, Brazilian Jiu-Jitsu... and a little Capoeira.
[cpg cn=true]


Wow, that's a lot! I don't care how many different martial arts you call them, isn't that too many!
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo614"]
[OnName num="sayo"]
You can't stop me now. Couscous.
[cpg cn=true]


[OnName num="masato"]
I'm a man too... and a man never says never!
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo615"]
[OnName num="sayo"]
That's nice. Here, take this...
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』


[OnName num="masato"]
Moxie.
[cpg cn=true]


The master took the shackles out of his mouth and put them in my mouth.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo616"]
[OnName num="sayo"]
I don't want to disturb the neighbors if you scream.
[cpg cn=true]


[OnName num="masato"]
"Moxie."
[cpg cn=true]


You're right, it's late at night and the people in the house will be awake.
[cpg]

But Master, you even have this thing. I wonder if he was planning to use it on me someday...I'm glad.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo617"]
[OnName num="sayo"]
Swoosh. .........
[cpg cn=true]


And then, the master attacked with uncanny movements.
[cpg]

What the hell is this move?
[cpg]


[SE f=se040]
;//【ＳＥ】『蹴り』ズドンッ！
;//画面超揺れる

[OnName num="masato"]
"Gahhhh........................................."
[cpg cn=true]


A powerful blow came out of nowhere. It was a close call. I'm sure you've heard of it, but I've never heard of it.
[cpg]

I was shocked and I started to flail around.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo618"]
[OnName num="sayo"]
I said I would use Capoeira as well, didn't I?
[cpg cn=true]


[OnName num="masato"]
"Uhh, uhh... uhh, uhh..."
[cpg cn=true]


I'm serious. It's not the same as before... Master is really, really serious.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo619"]
[OnName num="sayo"]
"I'll tell you something while you're still conscious. Tonight I will forgive you no matter how much you cry out. I may not be able to do that with my mouth full."
[cpg cn=true]


[OnName num="masato"]
"Whew, whew, whew... ......"
[cpg cn=true]


I'm very serious this time, too. I'm not going to lose at all.
[cpg]

I'm going to win, I'm going to win, I'm going to win for my master, I'm going to win .......
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

[SE f=se040]
;//【ＳＥ】『蹴り』ズドンッ！
;//画面超揺れる

--And so the late night one-sided sparring began.
[cpg]

[STOPBGM]

[window target=false]


[SE f=se083]
;//【ＳＥ】『フクロウ』


[BG f="b_04_4.ui" time=1000]
[WAIT time=2500]

;//少し時間を置いて

;//一定間隔で、何度かSEを再生。

[SE f=se096]
;//【ＳＥ】『確殺コンボ』

[WAIT time=6000]

;//[SE f=se000]
;//;//【ＳＥ】『ビンタ系』
;//[SE f=se000]
;//;//【ＳＥ】『ビンタ系』
;//[SE f=se000]
;//;//【ＳＥ】『ビンタ系』

[WAIT time=1000]

[BG f="b_04_1.ui" time=1000]

[WAIT time=1000]


;//※ここから小夜も雅人も疲弊しています。セリフ中も常に疲れているが、その中でもしっかり会話はしている、という感じです。


[BG f="black.ui" time=2000]
[WAIT time=2500]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


;//【ＢＧ】『小夜の部屋』（朝）******************************************************

[BGM f="sl"]

[WAIT time=1000]

[window target=true]


[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo620"]
[OnName num="sayo"]
It's a good idea to have a good idea of what you're looking for.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo621"]
[OnName num="sayo"]
"Damn, ......aaaah!"
[cpg cn=true]


[SE f=se068]
;//【ＳＥ】『弱々しいビンタ系』ぺちん

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo622"]
[OnName num="sayo"]
"Huh, huh... huh... huh..."
[cpg cn=true]



[SE f=se015]
;//【ＳＥ】『厚みのある布束』

[FO pos="2/3" time=1000]

I was tied to the bed so that I could not move, and Master fell down next to me.
[cpg]

[OnName num="masato"]
"Uh-uh...Ugh. ......"
[cpg cn=true]


[VOICE f="Sayo623"]
[OnName num="sayo"]
"Huh, huh..."
[cpg cn=true]


We are both breathing hard.
[cpg]

We were both breathing hard, which was only natural after being punched and kicked all night.
[cpg]

[SE f=se018]
;//【ＳＥ】『鳥の鳴き声』朝チュン


The next thing you know, it's morning.
[cpg]

[VOICE f="Sayo624"]
[OnName num="sayo"]
"You... how tough ...... are you, haha..."
[cpg cn=true]


The Master removes my shackles from my fallen body.
[cpg]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[WAIT time=1000]

[OnName num="masato"]
"Haha, haha ...... I'll take that as a compliment!"
[cpg cn=true]


We're both drenched in sweat. I'll take that as a compliment. The bed and the room around it were sweaty as well.
[cpg]

[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo625"]
[OnName num="sayo"]
"Huh...huh..."
[cpg cn=true]


[OnName num="masato"]
"Huh, huh..."
[cpg cn=true]


There's no way to describe what happened here last night... and I don't want to share it with anyone but us.
[cpg]

What happened last night was not an act like the previous ones, but a real clash between us. No, I just kept taking it....
[cpg]

That's why this room is such a mess.
[cpg]

Master never took a break from bullying me.
[cpg]

Sometimes he kicked me, sometimes he elbowed me, sometimes he kicked me in the knee, sometimes he clamped me down, sometimes he dropped me with all his weight... Honestly, I don't know how he could survive.
[cpg]

Master had a look on his face that I had never seen before, and he acted in a way that I had never seen before.
[cpg]

It was as if the mass of negative emotions that he had accumulated up until now had been thrown at him....
[cpg]

The scene was something that should be kept in our private memories.
[cpg]

It's impossible to tell anyone about it.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo626"]
[OnName num="sayo"]
"Hahaha... just so you know, are you okay?
[cpg cn=true]


[OnName num="masato"]
Yes, I'm fine... and to be honest, I can't even feel this body, but ...... seems to be fine.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo627"]
[OnName num="sayo"]
I'll be fine. I wonder if you have a steel plate in your body...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo628"]
[OnName num="sayo"]
Ohhhhh ........., I'm losing.
[cpg cn=true]


The game was won by me.
[cpg]

I had to endure a night of serious torture from my master. I'm sure you'll agree.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo629"]
[OnName num="sayo"]
"I'm so tired... I can't move anymore."
[cpg cn=true]


[OnName num="masato"]
"Me too."
[cpg cn=true]


"Me too." Neither of us seemed to be able to move for a while.
[cpg]

[OnName num="masato"]
How do you... feel?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo630"]
[OnName num="sayo"]
Terrible.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo631"]
[OnName num="sayo"]
I'm a sweaty mess and I'm so tired and I lost. It sucks."
[cpg cn=true]

[WAIT time=1000]


[FG f="CHA01_p3_03_a.ui" method="change_6"  pos="2/3" time=1000]

[WAIT time=1000]

[VOICE f="Sayo632"]
[OnName num="sayo"]
"......... sucks, but it's the most refreshing feeling."
[cpg cn=true]


Master said, looking refreshed.
[cpg]

[OnName num="masato"]
"Master. Don't forget your promise.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo633"]
[OnName num="sayo"]
"Yes. I'm so scared of what you're asking me to do.
[cpg cn=true]


[OnName num="masato"]
I'm not going to ask you to do anything crazy...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo634"]
[OnName num="sayo"]
But if I'm going to spend all night beating on a man's body, I'm going to be a pervert.
[cpg cn=true]


[OnName num="masato"]
Haha. Yes, you are.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo635"]
[OnName num="sayo"]
Shut up.
[cpg cn=true]



[SE f=se068]
;//【ＳＥ】『弱々しいビンタ系』ぺちん

[WAIT time=1000]


[VOICE f="Sayo636"]
[OnName num="sayo"]
It's one thing to say it to yourself, but it's annoying when people say it to you.
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[WAIT time=1000]


[OnName num="masato"]
You know, I don't think you should...
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo637"]
[OnName num="sayo"]
It's okay.
[cpg cn=true]

[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

Then, with a shudder, he managed to get up and sat down on the chair by the window.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo638"]
[OnName num="sayo"]
I'm aching all over.
[cpg cn=true]


[OnName num="masato"]
'I mean, that's me too, but...'
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo639"]
[OnName num="sayo"]
'Well, I didn't go easy on you, you know. You should go to the hospital later and get checked out."
[cpg cn=true]


That's for sure, let's do that. If you leave it like this and some problem comes out, you will feel sorry for your master.
[cpg]

[OnName num="masato"]
Master, what should we do after this?
[cpg cn=true]


[VOICE f="Sayo640"]
[OnName num="sayo"]
We're going to the school.
[cpg cn=true]


[OnName num="masato"]
You're going? That's great.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo641"]
[OnName num="sayo"]
Of course. A student's main duty is to study.
[cpg cn=true]


[OnName num="masato"]
I'm definitely going to miss it. Ha-ha-ha.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo642"]
[OnName num="sayo"]
If you take a day off, you'll be a bad influence on your master.
[cpg cn=true]


[OnName num="masato"]
In that case, I'll just do my job...
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo643"]
[OnName num="sayo"]
You need to recuperate today.
[cpg cn=true]


[OnName num="masato"]
But...
[cpg cn=true]


[VOICE f="Sayo644"]
[OnName num="sayo"]
Orders.
[cpg cn=true]


[OnName num="masato"]
"Yes."
[cpg cn=true]


While having such a conversation, we languished for a while... barely moving.
[cpg]

Even if I could move a little, I had to recover my strength.
[cpg]


[SE f=se002]
;//【ＳＥ】『時計音』カッチコッチ

[WAIT time=1000]


[OnName num="masato"]
"Master, are you hungry?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo645"]
[OnName num="sayo"]
"Ah...yes. I'm hungry. I'm starving, I mean...
[cpg cn=true]


[OnName num="masato"]
I can make something simple for you.
[cpg cn=true]


I've been hustling all night, and my energy is empty.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo646"]
[OnName num="sayo"]
...... would be nice, too.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo647"]
[OnName num="sayo"]
You know what? When people have unfulfilled desires, they try to substitute something else.
[cpg cn=true]


[OnName num="masato"]
Huh... I've heard something about that. When you're up all night, you get an appetite in the middle of the night.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo648"]
[OnName num="sayo"]
Yes. And we're both sleep deprived. So we don't get enough sleep.
[cpg cn=true]


[OnName num="masato"]
Yes, I understand. But is that...?
[cpg cn=true]


[VOICE f="Sayo649"]
[OnName num="sayo"]
The only thing that can replace it is appetite.
[cpg cn=true]


[OnName num="masato"]
......
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo650"]
[OnName num="sayo"]
Yeah. You understand, don't you?　We don't need food when we have the warmth of a human being.
[cpg cn=true]


[OnName num="masato"]
...... Master likes it a lot, doesn't he?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo651"]
[OnName num="sayo"]
Shut up. You don't even have the strength to be angry, so stop talking and come here.
[cpg cn=true]


[OnName num="masato"]
I'm going, aren't I? You're not a very good servant, are you?
[cpg cn=true]


[VOICE f="Sayo652"]
[OnName num="sayo"]
I'm sorry, but I can't move.
[cpg cn=true]


I'm sorry, I can't move." I put all my strength into the Toyota and wobbled to my master.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』

;//レターボックスin
[FACE method="feadin" pos="4/7"]
[BG f="b_04_1_up.ui" time=1000]
[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=1000]
[WAIT time=1500]

[stopse g=2]
;//通常se

[OnName num="masato"]
"I'm back, servant."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo653"]
[OnName num="sayo"]
"Hmm. Thank you.
[cpg cn=true]


I'm soaking wet, tightly clinging to my body, and my clothes are in disarray, which is very erotic.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo654"]
[OnName num="sayo"]
I have to take a bath, so I have about forty minutes before I have to start getting ready.
[cpg cn=true]


[OnName num="masato"]
"Forty minutes? That's not much time...
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo655"]
[OnName num="sayo"]
What are you going to do for the rest of the time?
[cpg cn=true]


[OnName num="masato"]
Oh, you're right.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo656"]
[OnName num="sayo"]
Please. Please stay close to me and don't let me go.
[cpg cn=true]



[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

Then we were both snuggled up together.
[cpg]

The maids who came to wake up Master found us and pulled us apart, and our night was finally over.
[cpg]

[window target=false]

[WAIT time=1000]

[STOPBGM]

;//少し時間を置く感じで



[WAIT time=1000]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//レターボックスout
[FACE method="out" pos="4/7"]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

[BGM f="sl"]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************

[window target=true]

[OnName num="masato"]
"Oh, welcome home, master."
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo657"]
[OnName num="sayo"]
I'm home. ...... What are you doing?
[cpg cn=true]


[OnName num="masato"]
"Making the bed, sir."
[cpg cn=true]


Master's room was in a terrible state after last night, so I had to clean it up.
[cpg]

It was a lot of work and it took all day.
[cpg]

[VOICE f="Sayo658"]
[OnName num="sayo"]
I told you to rest...
[cpg cn=true]


[OnName num="masato"]
I told you to rest.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo659"]
[OnName num="sayo"]
I'm fine." "....... That's good, but...
[cpg cn=true]


[OnName num="masato"]
"Look at that, look at that. It's all clean now.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo660"]
[OnName num="sayo"]
Yeah. That's great."
[cpg cn=true]


Master gave me a gentle smile.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo661"]
[OnName num="sayo"]
"You didn't have to fix it today..."
[cpg cn=true]


"You didn't have to fix it today..." This was coming from someone who knew about the disastrous state of this room this morning.
[cpg]

[STOPBGM]

[OnName num="masato"]
I want to keep Master's room clean. Besides, I have an appointment..."
[cpg cn=true]

[BGM f="h1"]

[FG f="CHA01_p4_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo662"]
[OnName num="sayo"]
"Ugh..."
[cpg cn=true]


[OnName num="masato"]
You remember, don't you?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo663"]
[OnName num="sayo"]
Of course I do. Of course you do.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo664"]
[OnName num="sayo"]
...... That's not why you're waiting for me, is it?
[cpg cn=true]


[OnName num="masato"]
Heh.
[cpg cn=true]


[VOICE f="Sayo665"]
[OnName num="sayo"]
"Huh..."
[cpg cn=true]


The master let out a sigh.
[cpg]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo666"]
[OnName num="sayo"]
So? What kind of request is it?
[cpg cn=true]


[OnName num="masato"]
What? Is it now?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo667"]
[OnName num="sayo"]
Now or later, it won't make much difference. Tell me.
[cpg cn=true]


[OnName num="masato"]
Yes, yes... Well...
[cpg cn=true]


I'm going to ask you to grant me one favor as a reward.
[cpg]

It's--
[cpg]


;//■選択肢２
[switch]
[case "I don't want anything."]
	[swap]
	[jump target="*IseSel02_1"]
[case "I want you to kiss me."]
	[swap]
	[jump target="*IseSel02_2"]
[case "I want a kiss."]
	[swap]
	[jump target="*IseSel02_3"]
[endswitch]

One, I don't want anything.
Two, I want you to kiss me.
Three, I want to kiss you.


;//原作と同様、上にある選択肢ほど何も望まない選択になっています
;//ただし、キスは二番目以降にずれています

;////////////////////////////////////////////////////////////////////
;//１、何も要らない

*IseSel02_1|Blood, sweat and M.

[OnName num="masato"]
...... I don't need anything. Please grant me my wish of not needing anything."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo668"]
[OnName num="sayo"]
"What?
[cpg cn=true]


[OnName num="masato"]
I want you to grant me the wish that I don't want anything, that you won't give me anything.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo669"]
[OnName num="sayo"]
That would be the same as no promise at all.
[cpg cn=true]


[OnName num="masato"]
It's not the same. I want Master to know that I am fulfilled.
[cpg cn=true]


[VOICE f="Sayo670"]
[OnName num="sayo"]
That's not what you want. I really don't want anything.
[cpg cn=true]


I don't really need anything. What I need now, if I may say so.
[cpg]

I have one more request (story) to make.
[cpg]

[OnName num="masato"]
"Then, Master. Just one more thing..."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo671"]
[OnName num="sayo"]
What?
[cpg cn=true]


[OnName num="masato"]
"Master. Let me...
[cpg cn=true]



;//【奉公END】【ただいまEND】へのフラグ
[stflag service_flag=1]


;//【合流A】へ
[jump target="*IseSel02_4"]


;////////////////////////////////////////////////////////////////////
;//２、キスしてほしい

*IseSel02_2|Blood, sweat and M.

[OnName num="masato"]
I want you to ...... kiss me, master.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo672"]
[OnName num="sayo"]
Kiss? You mean kiss, don't you?
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo673"]
[OnName num="sayo"]
Is that what you want?
[cpg cn=true]


[OnName num="masato"]
Yes!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo674"]
[OnName num="sayo"]
Okay.
[cpg cn=true]


That's how I ended up kissing my master. It was the first time I could do it like this.
[cpg]

[STOPBGM]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//●ＣＧ（雅人＆小夜・ご主人様とご褒美にディープキス：小夜の部屋）ev_10

[BGM f="h1"]

;**【ＣＧ】 ev_10_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo675"]
[OnName num="sayo"]
"......"
[cpg cn=true]


[OnName num="masato"]
"Well, then..."
[cpg cn=true]


[VOICE f="Sayo676"]
[OnName num="sayo"]
"Oh. Wait.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[VOICE f="Sayo677"]
[OnName num="sayo"]
You might want to rinse your mouth first.
[cpg cn=true]


[OnName num="masato"]
Why?
[cpg cn=true]


[VOICE f="Sayo678"]
[OnName num="sayo"]
Because, you know, as a matter of etiquette, you don't want to get dirty, do you?
[cpg cn=true]


[OnName num="masato"]
Not at all.
[cpg cn=true]


[VOICE f="Sayo679"]
[OnName num="sayo"]
You're not going to like it when I do that.
[cpg cn=true]


[OnName num="masato"]
No one but your master would accept you like that.
[cpg cn=true]


[VOICE f="Sayo680"]
[OnName num="sayo"]
"That's true."
[cpg cn=true]


I was easily convinced.
[cpg]

[OnName num="masato"]
"I'm so excited."
[cpg cn=true]

;**【ＣＧ】 ev_10_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1500]



[VOICE f="Sayo681"]
[OnName num="sayo"]
"Mmm...
[cpg cn=true]


[OnName num="masato"]
"Ssshhh."
[cpg cn=true]


My lips touch Master's soft, pouty lips.
[cpg]

[VOICE f="Sayo682"]
[OnName num="sayo"]
My lips touch Master's soft, pouty lips, "Chuu...mmm...mmm. Chuu, chuu."
[cpg cn=true]


We were kissing at a delicate distance, but gradually our bodies came closer and closer to each other.
[cpg]

After a few minutes, they embraced each other without either of them knowing it.
[cpg]

[VOICE f="Sayo683"]
[OnName num="sayo"]
I'm tired of standing .......
[cpg cn=true]


[OnName num="masato"]
Come here, then."
[cpg cn=true]


I sat down and invited my master to sit on my lap.
[cpg]

[VOICE f="Sayo684"]
[OnName num="sayo"]
I invited my master to sit on my lap, which is not normally allowed.
[cpg cn=true]


[OnName num="masato"]
'But it's a reward, right?
[cpg cn=true]


[VOICE f="Sayo685"]
[OnName num="sayo"]
Yes, it's a special treat. Churp, churp...
[cpg cn=true]


[VOICE f="Sayo686"]
[OnName num="sayo"]
Churp. Chug, chug, chug, chug, chug, chug, chug, chug.
[cpg cn=true]


[OnName num="masato"]
I'm sorry, are your teeth...?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo687"]
[OnName num="sayo"]
Oh, yeah. There's nothing else.
[cpg cn=true]




[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

;//【ＢＧ】『小夜の部屋』（昼）******************************************************


[window target=true]


[FG f="CHA01_p5_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo688"]
[OnName num="sayo"]
"...... mmm...mmm...mmm...mmm...mmm...mmm...mmm. Pfft!
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=41500]


[VOICE f="Sayo689"]
[OnName num="sayo"]
Ha, ha, ha... is that enough?
[cpg cn=true]


[OnName num="masato"]
"Yes. That's enough.
[cpg cn=true]


I tasted my master's lips for about an hour.
[cpg]

[FG f="CHA01_p4_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo690"]
[OnName num="sayo"]
...... Is this what you want?
[cpg cn=true]


[OnName num="masato"]
Yes, of course. It's the best reward I can give you.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo691"]
[OnName num="sayo"]
"Well, I'm glad to hear it."
[cpg cn=true]


Master smiled serenely.
[cpg]


;//【比翼連理END】へのフラグ
[stflag hiyokurenri_flag=1]

;//【合流A】へ
[jump target="*IseSel02_4"]

;////////////////////////////////////////////////////////////////////
;//３、キスしたい

*IseSel02_3|Blood, Sweat and M

[OnName num="masato"]
I'd like to kiss you, Master.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo692"]
[OnName num="sayo"]
"Yes. Okay... do what you want, if you want."
[cpg cn=true]


She smiled gently, but it wasn't exactly what I was expecting... somehow.
[cpg]

[FO pos="2/3" time=1000]


;//ev_10を表示
[BG f="black.ui" time=1000]
[WAIT time=1500]

;**【ＣＧ】 ev_10_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1500]


I took the initiative and kissed her, instead of her master doing it to me.
[cpg]

Her lips were soft. I will never forget this feeling.
[cpg]

No matter what happens from now on... maybe forever.
[cpg]


;//【遠き存在END】へのフラグ
[stflag existence_flag=1]

;//【合流A】へ

;////////////////////////////////////////////////////////////////////


;//【合流A】
*IseSel02_4

[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="ep015.ks" target="*start"]


;////////////////////////////////////////////////////////////////////

;//【合流A】
