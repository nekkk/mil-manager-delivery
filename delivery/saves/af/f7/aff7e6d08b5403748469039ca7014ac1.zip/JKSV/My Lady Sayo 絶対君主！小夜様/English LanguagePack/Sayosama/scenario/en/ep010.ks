*start

;#################################################
*Ep010|M-medium sickness
;#################################################

[SCENE id=10]


[stflag jump_scene=0]
[window target=false]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]

[SE f=se060 loop=true]
;//【ＳＥ】『強い日差し』
;//※SEかもしくは演出で

[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

;//【ＢＧ】『空』（昼）******************************************************



[BGM f="d1"]

[window target=true]


The sun is shining brightly. It's even hotter today.
[cpg]

I'm sweating like a waterfall as I weed in the garden of my house.
[cpg]

[OnName num="masato"]
"It's so hot..."
[cpg cn=true]


Working outside under the blazing sun is really tough.
[cpg]

[OnName num="masato"]
"Water, water.
[cpg cn=true]


The water that moistened my throat tasted so good.
[cpg]

I knew I had to hydrate often, or I might get heat stroke.
[cpg]

[OnName num="butler"]
It's not easy to work outside in today's weather.
[cpg cn=true]


[OnName num="masato"]
Mr. Tanaka.
[cpg cn=true]


[OnName num="butler"]
Drinking water is good, but it's better to have some salt in it.
[cpg cn=true]


[OnName num="masato"]
Oh... that's right.
[cpg cn=true]


If that's the case, will it be a sports drink or something?
[cpg]

[OnName num="butler"]
I'll leave you to it then. Don't strain yourself too much.
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]

All right, I'll do my best one more time.
[cpg]

After that, I continued to work while rehydrating.
[cpg]

[SE f=se044]
;//【ＳＥ】『洗濯物を干す』

[WAIT time=1500]

[OnName num="masato"]
It's so hot... no matter how much I drink, I'm still thirsty. Water, water..."
[cpg cn=true]


There was no more water left in the plastic bottle I had brought with me.
[cpg]

I had no choice but to go back to the mansion and get some water.
[cpg]

Oh, but... Tanaka-san said it would be better to have salt. I don't know what to do...
[cpg]

What can I drink that also has salt?
[cpg]

[OnName num="masato"]
Huh~ ...... If only I had Master's handkerchief...
[cpg cn=true]


It's perfect for the current situation. A handkerchief is a drink. I'm sure it will give you a lot of motivation.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[WAIT time=1000]


[OnName num="masato"]
It's hot, hot..."
[cpg cn=true]


Anyway, back to the mansion.
[cpg]

;//レターボックスin
[FACE method="feadin" pos="4/7"]
[WAIT time=1000]

[STOPBGM]
[stopse g=3]
;//通常se

;//暗転と共に画面が揺れ、傾き倒れる演出

[OnName num="masato"]
"...... Huh?"
[cpg cn=true]

[window target=false]


[transition target={true} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[SE f=se062]
;//【ＳＥ】『倒れる』バタッ

;//ＢＫ


[BG f="black.ui" time=1]
[WAIT time=2000]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1000]




[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=1]

[BG f="b_06_2_up.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=2000]
[WAIT time=2500]


[WAIT time=100]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（昼）******************************************************


[window target=true]


[OnName num="masato"]
"Uh-uh..."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo444"]
[OnName num="sayo"]
Are you awake?
[cpg cn=true]


;//レターボックスout
[FACE method="feadout" pos="4/7"]
[BG f="b_06_2.ui" time=1000]
[WAIT time=1000]

[BGM f="sl"]

[OnName num="masato"]
Master? Oh, this is...
[cpg cn=true]


I feel like I'm in my room, but why am I here? I thought you were working outside.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo445"]
[OnName num="sayo"]
You idiot... You've collapsed from heat stroke.
[cpg cn=true]


[OnName num="masato"]
"Oh, no, you didn't?"
[cpg cn=true]


I've made another mistake.
[cpg]

[OnName num="masato"]
I'm sorry to have caused you so much trouble.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo446"]
[OnName num="sayo"]
Oh, well. It seems that nothing serious happened.
[cpg cn=true]


Could it be that they were worried about me and came to check on me? If so, I'm very happy.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo447"]
[OnName num="sayo"]
Is there anything you want?
[cpg cn=true]


[OnName num="masato"]
No, I'm fine. I'm already feeling better.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo448"]
[OnName num="sayo"]
"Well..."
[cpg cn=true]


Instantly, Master's eyes narrowed.
[cpg]

[STOPBGM]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo449"]
[OnName num="sayo"]
"You kept saying 'handkerchief' in your sleep, but you don't need it, do you?
[cpg cn=true]


[OnName num="masato"]
"What?"
[cpg cn=true]

[BGM f="co"]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo450"]
[OnName num="sayo"]
I'm afraid of authenticity, that you're still a pervert even when you're sleeping.
[cpg cn=true]


Wait, I was talking in my sleep with such lustful thoughts?
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo451"]
[OnName num="sayo"]
Do you want it?
[cpg cn=true]


[OnName num="masato"]
Well, it was hot outside, so I wanted something that would keep me hydrated and salty at the same time.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo452"]
[OnName num="sayo"]
You want it?
[cpg cn=true]


[OnName num="masato"]
I want .......
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo453"]
[OnName num="sayo"]
Mmm-hmm.
[cpg cn=true]

[STOPBGM]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ＢＫ

;//●ＣＧ（雅人＆小夜・ハンカチを主人公の前でひらひらさせる。アングルは元ＣＧのまま：雅人の部屋）ev_09

[BGM f="h1"]


;**【ＣＧ】 ev_09_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo454"]
[OnName num="sayo"]
It was hot again today. I sweat a lot.
[cpg cn=true]


[OnName num="masato"]
Well, uh, master...
[cpg cn=true]


[VOICE f="Sayo455"]
[OnName num="sayo"]
Go back to sleep.
[cpg cn=true]



He began to wipe himself with a handkerchief.
[cpg]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[WAIT time=1500]

[VOICE f="Sayo456"]
[OnName num="sayo"]
I wondered if a towel would be better. Or is there a point to the handkerchief?
[cpg cn=true]


[OnName num="masato"]
"Yes, yes. It's better to use a handkerchief.
[cpg cn=true]


[VOICE f="Sayo457"]
[OnName num="sayo"]
I don't understand... but if you want it so badly, I'll give it to you.
[cpg cn=true]


With that, she tosses the handkerchief to me in my sleep... just in time, and doesn't take her hand away.
[cpg]

[VOICE f="Sayo458"]
[OnName num="sayo"]
"Hmmm. You look good."
[cpg cn=true]


I wonder if what I'm thinking is so easy to show on my face...
[cpg]

[window target=false]


[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ
;//レターボックスin
[FACE method="in" pos="4/7"]
[WAIT time=1]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1000]

[BG f="b_06_2_up.ui" time=1000]
[WAIT time=1500]


;//【ＢＧ】『使用人の部屋（雅人の部屋）』（昼）******************************************************


[window target=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo459"]
[OnName num="sayo"]
"Do you want this so badly?"
[cpg cn=true]


[OnName num="masato"]
"Oh, my God..."
[cpg cn=true]


Master is looking down at me in sorrow as I'm being held back at the last minute.
[cpg]

[FG f="CHA01_p2_02_a.ui" method="change_2"  pos="2/3" time=1000]
[VOICE f="Sayo460"]
[OnName num="sayo"]
"Hahahaha. You're looking absolutely ridiculous right now."
[cpg cn=true]


[OnName num="masato"]
"Ugh, ugh..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo461"]
[OnName num="sayo"]
"Oh my God, are you going to cry? What kind of man cries over a handkerchief...
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


Damn, this is too much, Master.
[cpg]


[SE f=se061]
;//【ＳＥ】『踏みつけられる』ガッ

[FO pos="2/3" time=800]
[BG f="black.ui" time=800]
[WAIT time=800]

[OnName num="masato"]
What?
[cpg cn=true]

;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=1]

;//再度ＣＧ表示

;**【ＣＧ】 ev_09_a ***********************
[CG id=11 index=1 time=800]
;***************************************
[WAIT time=1000]


[VOICE f="Sayo462"]
[OnName num="sayo"]
I only did it to see that kind of reaction. Don't be disappointed.
[cpg cn=true]


And then she pulls the handkerchief closer to my nose.
[cpg]

[OnName num="masato"]
"Oh, my God!"
[cpg cn=true]


[VOICE f="Sayo463"]
[OnName num="sayo"]
Come on, it's time to eat.
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]


[BG f="b_06_2.ui" time=1000]

[WAIT time=1500]

[BGM f="sl"]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（昼）******************************************************

[window target=true]

[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo464"]
[OnName num="sayo"]
You really can't live without my handkerchief, can you?
[cpg cn=true]


[OnName num="masato"]
Ugh, I'm so embarrassed, but yes, you're right.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo465"]
[OnName num="sayo"]
If you want it, you'll have to work harder.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo466"]
[OnName num="sayo"]
"Work harder, do more for me, live for me. Work harder, do more for me, live for me, and I will give you exactly what you want as a reward.
[cpg cn=true]


[OnName num="masato"]
Yes, yes! I'll do my best! More, more! With all my heart and soul, I will do everything I can for you, Master!"
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo467"]
[OnName num="sayo"]
"Couscous. For the sake of my handkerchief, right? Couscous.
[cpg cn=true]


[OnName num="masato"]
"No, no, no. It's for that too, but it's also purely for master's sake.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo468"]
[OnName num="sayo"]
I know. I'm counting on you, so do your best.
[cpg cn=true]


[OnName num="masato"]
Yes, yes, yes, yes!
[cpg cn=true]


I vowed to devote myself even more to my master, not my handkerchief.
[cpg]

[OnName num="masato"]
I'm not a handkerchief, but I vowed to be even more diligent for Master.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo469"]
[OnName num="sayo"]
"I'll be careful about that. And there's no point in dressing up in front of you, is there?
[cpg cn=true]


[OnName num="masato"]
Oh! Yes, of course. Reveal more of yourself, Master.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo470"]
[OnName num="sayo"]
Don't ride the choo-choo.
[cpg cn=true]



[SE f=se068]
;//【ＳＥ】『軽いデコピン』ぺちっ

[WAIT time=1000]


[OnName num="masato"]
Aah! Ha-ha-ha.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo471"]
[OnName num="sayo"]
Ha-ha-ha.
[cpg cn=true]


I really think I'm going to... work harder and harder for him.
[cpg]

[STOPBGM]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="ep011.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////
