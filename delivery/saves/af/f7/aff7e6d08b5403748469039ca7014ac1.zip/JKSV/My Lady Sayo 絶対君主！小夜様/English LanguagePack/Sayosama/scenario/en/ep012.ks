*start

;#################################################
*Ep012|Dark Cloud M Castle
;#################################################

[SCENE id=12]


[stflag jump_scene=0]
[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep002で発生	ジャンプしてきた場合奉仕ルートで固定
[stflag gohome_flag=0]
[stflag pets_flag=1]
[endif]


[BG f="black.ui" time=1000]
[WAIT time=1000]

[window target=true]


--Suddenly, a shadow appeared over the life I had been able to lead without any major problems.
[cpg]


[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BGM f="se"]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夜）******************************************************

[window target=true]


[OnName num="masato"]
"...... What?"
[cpg cn=true]


[OnName num="butler"]
"Oh, I almost dropped you. Stay with me, please."
[cpg cn=true]


I dropped the cup I was polishing and almost broke it.
[cpg]

It was not my usual mistake. I let my mind wander.
[cpg]

[OnName num="masato"]
"What did you say, Mr. Tanaka?
[cpg cn=true]


[OnName num="butler"]
"........."
[cpg cn=true]


[OnName num="masato"]
"Master is getting married ......?"
[cpg cn=true]



It was a sudden revelation.
[cpg]

The master's family had gone through a financial crisis a long time ago. The company and the house had become difficult to survive... At that time, someone had helped him out of his predicament.
[cpg]

That person was... her master's marriage partner.
[cpg]

Because of this, the master is supposed to marry a fat man who is very sexy and has no good reputation.
[cpg]

The marriage is coming soon.
[cpg]

It's not a marriage, but rather a life as a servant doll.
[cpg]

Until now, she had managed to delay the date of her marriage, but now that deception was no longer an option.
[cpg]

It was time for me to join the family in earnest. That's when I finally found out about it.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]


;//【ＢＧ】『豪邸、廊下』（夜）******************************************************

[window target=true]


[OnName num="masato"]
"Master, may I have a word?"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo542"]
[OnName num="sayo"]
"Yes?"
[cpg cn=true]


[OnName num="masato"]
I heard from Mr. Tanaka that you're getting married...
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo543"]
[OnName num="sayo"]
"........."
[cpg cn=true]


[OnName num="masato"]
You're kidding, right?
[cpg cn=true]


[FG f="CHA01_p4_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo544"]
[OnName num="sayo"]
...... No, it's true.
[cpg cn=true]


;//[VOICE f="Sayo545"][OnName num="sayo"]「数ヶ月後に、私は…結婚する事になっているわ」[cpg cn=true]


[VOICE f="Sayo546"]
[OnName num="sayo"]
I'm going to marry someone your father knows...
[cpg cn=true]


[OnName num="masato"]
Oh, no...
[cpg cn=true]


It was the truth. I felt as if my strength would be drained from my body.
[cpg]

[OnName num="masato"]
Are you serious?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo547"]
[OnName num="sayo"]
It's what I've decided. I'm convinced of it.
[cpg cn=true]


[OnName num="masato"]
Are you sure... that's who you want to marry?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo548"]
[OnName num="sayo"]
What are you...? What are you trying to say?
[cpg cn=true]


[OnName num="masato"]
Well, it's just...
[cpg cn=true]


I don't know what to say. I don't know what to say, but I don't want her to go away.
[cpg]

[OnName num="masato"]
What will happen to me? When Master is gone...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo549"]
[OnName num="sayo"]
I'll make sure you can work here as before. Well, the work will be a little different, but..."
[cpg cn=true]


[OnName num="masato"]
That's not it, that's not...
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo550"]
[OnName num="sayo"]
No!
[cpg cn=true]


[OnName num="masato"]
Please don't leave me, please don't leave me.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo551"]
[OnName num="sayo"]
"........."
[cpg cn=true]


[OnName num="masato"]
Don't leave me, master... because if you don't, I'll...
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo552"]
[OnName num="sayo"]
"...... Shut up."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo553"]
[OnName num="sayo"]
It's none of your business.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo554"]
[OnName num="sayo"]
I'm done talking about it. Don't ever do that again.
[cpg cn=true]


[OnName num="masato"]
......... Oh, yes, .........
[cpg cn=true]


The master built a wall.
[cpg]

I've never read your name before, but I've never called you "you" before.
[cpg]

I don't know what to do...I don't know what to do...I don't know what to do.
[cpg]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[STOPBGM]

[if exp={getFlagValue("pets_flag") == 0 }]
;//[jump storage="ep013.ks" target="*start"]
[jump target="*ep012_jump"]
[endif]

;///////////////////////////////////////////////////////////
;//最初の選択肢で『飼われる』を選んでいた場合にのみ表示されるイベント

*event_pet|Dark Cloud M Castle

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

Today, too, I'm being touched. But this time, it was different.
[cpg]


;//●ＣＧ（雅人＆小夜・腕に抱かれたり、顔をスリスリされる：小夜の部屋）ev_20

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[BGM f="h1"]

;**【ＣＧ】 ev_20_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1500]

[OnName num="masato"]
"Master... why are you doing this..."
[cpg cn=true]


[VOICE f="Sayo555"]
[OnName num="sayo"]
"Well... it's my mood. Nothing else."
[cpg cn=true]


She didn't tease me. She didn't tease me; rather, she flirted with me like a normal lover would.
[cpg]

She hugged me and rubbed her cheek against mine.
[cpg]

This was a good thing, but... it made me feel even worse.
[cpg]

[VOICE f="Sayo556"]
[OnName num="sayo"]
......"
[cpg cn=true]


She doesn't say anything, but continues to hug me and bring her face close to mine.
[cpg]

My heart is tightening. I've never felt this way before, and I'm confused.
[cpg]

[OnName num="masato"]
"Master..."
[cpg cn=true]


;**【ＣＧ】 ev_20_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1500]


[VOICE f="Sayo557"]
[OnName num="sayo"]
Don't say a word. I just want to do this for a while.
[cpg cn=true]


...Maybe she was thinking something of me, too.
[cpg]


[STOPBGM]

[BG f="black.ui" time=1000]
[WAIT time=1500]


[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse



*ep012_jump

[jump storage="ep013.ks" target="*start"]



;///////////////////////////////////////////////////////////
