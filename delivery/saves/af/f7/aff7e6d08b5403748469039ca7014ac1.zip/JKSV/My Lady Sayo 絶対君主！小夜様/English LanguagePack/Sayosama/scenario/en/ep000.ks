*start

;//ドM向けロリものシナリオ『絶対君主！小夜様！』

;//移植用に加筆修正しています
;//01 03 04 05 06
;//07 08 09 10 14
;//15 16 17 18 19
;//20
;//以上のCGが引き継がれ残っています

;//【プロローグ】

;//[jump target="*Ep007"]




;#################################################
*Ep000|There is no such thing as a bad M-man. Even if they are pedophiles.
;#################################################

[SCENE id=0]


[stflag jump_scene=0]
[stflag gohome_flag=0]
[stflag service_flag=0]
[stflag hiyokurenri_flag=0]
[stflag existence_flag=0]
[stflag pets_flag=0]




;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


;//※※※お願い※※※　ト書き文章でブロック毎に分けてあるものは、一回のメッセージ表示で全て表示して欲しいものです。
;//出来れば改行もそのままでお願いします。



[BG f="black.ui" time=1000]
[BGM f="h1"]
[WAIT time=1000]
;//ＢＫ



;//ここではまだ小夜の名前は『？？？』でお願いします。

;//クスクスの後、次の言葉の間にウェイトを入れて下さい

[VOICE f="Sayo001"]
[OnName num="sayo"]
"Hmmm, couscous ......... nice outfit..."
[cpg cn=true]



Lying on the floor on her back, ...... she laughed happily as she watched me in horror.
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************



[BG f="b_00_2_up.ui" time=1000]

;//レターボックスin
[FACE method="slidein" pos="4/7"]
[WAIT time=1500]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]


In front of me is a small girl.
[cpg]

Her short stature, her large eyes, her soft cheeks with a slight blush, her hair straight down to her waist... everything about her is cute.
[cpg]

The glamorous clothes combined with the moderate exposure of her skin makes her even more attractive.
[cpg]


;//『ルビ：娘（こ）』
She is a girl that I might call 'Master' and serve.
[cpg]

[FACE method="change_7" pos="2/3"]

[VOICE f="Sayo002"]
[OnName num="sayo"]
What kind of recruitment letter did you send out? Tanaka-san.
[cpg cn=true]


[OnName num="butler"]
"It was written in an appropriate manner, Miss."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo003"]
[OnName num="sayo"]
You should have been more straightforward. You should have been more straightforward. There are a lot of people who will come to you with the wrong idea...
[cpg cn=true]



[OnName num="masato"]
"Huh, huh, huh, ......! Huh, huh...!"
[cpg cn=true]



In front of her, I am terrified of the pain that is sure to come.
[cpg]

A large man was shaking his body in a disgusting manner... and was on the verge of crying.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=1000]
[VOICE f="Sayo004"]
[OnName num="sayo"]
"Are you ready for this?"
[cpg cn=true]

[SE f=se033 loop=true]
;//【ＳＥ】『心音』

[OnName num="masato"]
"Haha. ...... Haha! Hahahaha...!
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo005"]
[OnName num="sayo"]
"Huh, huh...! Well, it doesn't matter either way..."
[cpg cn=true]



Did she take the fact that he didn't answer as a yes, or did she sense that he didn't even have time to answer?
[cpg]

Before she heard our answer, she took a stance.
[cpg]

Then her slippery legs moved like a bow.
[cpg]


[OnName num="masato"]
".........!!!"
[cpg cn=true]

[stopse g=2]
;//通常se

[stopse g=6]
;//通常se

Without a shred of hesitation, without a care in the world.
[cpg]

She swung her right leg up and -----
[cpg]

[SE f=se030]
;//【ＳＥ】『風切音』
[FO pos="2/3" time=800]
[BG f="black.ui" time=800]
[WAIT time=800]
;//ＢＫ



[WAIT time=1000]


;//画面揺れる演出

[SE f=se001]
;//【ＳＥ】『轟音』ドゴンッ
;//※金玉を蹴っているので、石を砕いたりとか、あまり物理的な音は合わないので止めて下さい
;//直接的にそうとは描写されません

[STOPBGM]


[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=500]


;//レターボックスout
[FACE method="slideout" pos="4/7"]
[WAIT time=500]

[WAIT time=1100]
[BG f="white.ui" time=1]

[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]
[WAIT time=1]


[window target=true]
[WAIT time=100]

[SE f=se062]
;//【ＳＥ】『倒れる』

[WAIT time=1000]


The pain was so intense that my consciousness was cut off at that point.
[cpg]

I don't know why this happened to me.
[cpg]

In my fading consciousness, only such a question came to my mind like a running lantern. ......
[cpg]


;//少し時間を置いて


--A few days ago...
[cpg]


[SE f=se002]
;//【ＳＥ】『時計の音』カチコチカチコチ



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[STOPBGM]

[WAIT time=100]

[stopse g=2]
;//通常se

[BGM f="d1"]
[WAIT time=100]
;//【ＢＧ】『分岐路のある道』（昼）******************************************************

[SE f=se003]
;//【ＳＥ】『品出し音』

[WAIT time=1500]


[OnName num="masato"]
"......What? Manager, what did you say...?
[cpg cn=true]


[OnName num="manager"]
I'm really sorry, but.... I'm really sorry, but my contract is up at the end of the month.
[cpg cn=true]

[SE f=se014]
;//【ＳＥ】『衝撃』


The manager, who had been kind to me both at work and in my private life, said something that made me want to cover my ears.
[cpg]

I hoped that I had misheard him. I can't help but hope so.
[cpg]

[OnName num="masato"]
Why, why...? Please, please! I'll do my best! So...
[cpg cn=true]


[OnName num="manager"]
I know that you are a good and serious person.
[cpg cn=true]


[OnName num="masato"]
"Then..."
[cpg cn=true]


[OnName num="manager"]
But even after half a year, my failures have hardly decreased. I've been breaking things and we've been spending a lot of money, so... we're in trouble.
[cpg cn=true]


[OnName num="manager"]
It's not like we're making much money to begin with. So I'm really sorry, but..."
[cpg cn=true]


[OnName num="masato"]
"........., yes. I understand..."
[cpg cn=true]


I don't know how many times I've heard these words or said these words.
[cpg]

[OnName num="masato"]
"Thank you for your help."
[cpg cn=true]


[OnName num="manager"]
"Yes... good work."
[cpg cn=true]


[STOPBGM]
[window target=false]


[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ


[BG f="b_03_3.ui" time=1000]
[WAIT time=1000]
[window target=true]

[WAIT time=100]

[BGM f="se"]
[WAIT time=100]
;//【ＢＧ】『分岐路のある道』（夕方）******************************************************

[SE f=se005]
;//【ＳＥ】『歩く』

[OnName num="masato"]
What should I do next?
[cpg cn=true]



It's not that I don't want to work ....... It's not that I don't want to work. It's that I know I have to work in order to survive in society.
[cpg]

It's not that I don't want to work. It's not uncommon to get fired for it.
[cpg]

When I keep doing that, I feel that every workplace is not the right environment for me.
[cpg]

It may just be an excuse, but....
[cpg]


[OnName num="masato"]
"Haaaaaaaaaaaaaaaa ......"
[cpg cn=true]


I don't want to go home with my depressed mood dragging me down.
[cpg]


Perhaps it was because of these strong feelings that I naturally turned my feet not towards home, but towards the center of the city.
[cpg]

[SE f=se004]
;//【ＳＥ】『喧騒』

Due to family reasons, I didn't go to university, but got a job.
[cpg]

It's been more than a year since I started working, but I still haven't been able to blend into the life of a working adult.
[cpg]

Due to the fact that it was the ice age of employment, I couldn't get a regular job and had to work part-time to make ends meet.
[cpg]

I have a desire to get a regular job. But I need to make it last longer than that... even if it's just a part-time job.
[cpg]


I look at information magazines, write resumes, go to interviews... and fail.
[cpg]

I'm tired of living a life where I get fired within a few months to six months even if I get the job.
[cpg]

It would be different if I could just find a job that suits me. It's called a vocation, but I wonder if there really is such a thing.
[cpg]

I wonder what my vocation is.
[cpg]

[SE f=se004]
;//【ＳＥ】『喧騒』ガヤガヤ


[BG f="b_03_3_up.ui" time=1000]

;//レターボックスin
[FACE method="slidein" pos="4/7"]
[WAIT time=1500]

[OnName num="girls_mother"]
"What would you like for dinner tonight?"
[cpg cn=true]


[OnName num="little_girl"]
"Let's see, um... hamburger steak!"
[cpg cn=true]


[OnName num="girls_mother"]
Again? You really like hamburgers, don't you?
[cpg cn=true]


[OnName num="little_girl"]
Yes! I like hamburgers as much as my mom and dad.
[cpg cn=true]


[OnName num="girls_mother"]
I can't help it. Let's make it a hamburger.
[cpg cn=true]


[OnName num="little_girl"]
Yes! A hamburger! A hamburger!
[cpg cn=true]



[SE f=se006]
;//【ＳＥ】『走る』

[OnName num="girls_mother"]
Don't get so excited...
[cpg cn=true]


[SE f=se007]
;//【ＳＥ】『転ぶ』ドタッ

[OnName num="little_girl"]
Aah!
[cpg cn=true]


A little girl fell down in front of me! I've got to help her!
[cpg]


[SE f=se006]
;//【ＳＥ】『駆け寄る』

[OnName num="masato"]
Are you okay?
[cpg cn=true]


I quickly ran over and helped the fallen child up.
[cpg]

[OnName num="little_girl"]
"My knee hurts.
[cpg cn=true]


[OnName num="girls_mother"]
Oh, I'm so sorry about my baby!
[cpg cn=true]


[OnName num="masato"]
I didn't do anything. I didn't do anything... Oh, yes, I have some bandages if you want.
[cpg cn=true]


[OnName num="girls_mother"]
Thank you very much. Say thank you to your brother.
[cpg cn=true]


[OnName num="little_girl"]
Oh, thank you.
[cpg cn=true]


[OnName num="masato"]
Okay, I'll just...
[cpg cn=true]


[OnName num="little_girl"]
Bye.
[cpg cn=true]

[SE f=se005]
;//【ＳＥ】『歩く』

[BG f="black.ui" time=1000]
[WAIT time=1000]

;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=1]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]

Kids are good... they heal me. I get excited when they are cute.
[cpg]

Personally, I prefer when they are more mature. ...... But that's not important. If you say something dangerous, you will be pointed at as a potential criminal.
[cpg]


I wish I had a daughter of my own.
[cpg]

I wish I had a daughter, so I could work harder for that cute girl.
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

;//＠
[BG f="b_03_3.ui" time=1000]
[WAIT time=1000]

;//背景切り替え演出をして、また街を表示。場所を移動した感じの演出。

[SE f=se009]
;//【ＳＥ】『入店音』ピンポローン

[BG f="b_03_3_up.ui" time=1000]

;//レターボックスin
[FACE method="feadin" pos="4/7"]
[WAIT time=1500]

;//書店

[OnName num="staff"]
"Come in."
[cpg cn=true]



[SE f=se005]
;//【ＳＥ】『歩く』

It's so cool. I felt like I wanted to stay here, but I shook it off. I didn't come here to cool off.
[cpg]

[OnName num="masato"]
I'd like to get a more stable job, even if it's only part-time.
[cpg cn=true]


With that in mind, I looked at the part-time job information magazine as usual.
[cpg]

[SE f=se076]
;//【ＳＥ】ページめくる

[WAIT time=2000]

[SE f=se076]
;//【ＳＥ】ページめくる

[WAIT time=2000]

[OnName num="masato"]
"Hmm? I wonder what this is..."
[cpg cn=true]



Then I saw a job opening that I've never seen before.
[cpg]


"This is a job where you serve your master.

[OnName num="masato"]
What?
[cpg cn=true]


What the hell does that mean? What does it mean? Does it mean I'm a butler or something?
[cpg]

It's clearly an insufficient explanation.
[cpg]

There are no phrases like "beginners are welcome" or "it's a homey place to work" that would make you feel at ease or make you want to join.
[cpg]

It was like, "What the hell is this? I'm a part-timer, but I've never seen such a recruitment letter.
[cpg]

[OnName num="masato"]
It's too suspicious. It's too suspicious..."
[cpg cn=true]


No matter how you look at it, it's suspicious. I'm sure many people would be suspicious and would not apply. It's 100% suspicious.
[cpg]

[OnName num="masato"]
"......"
[cpg cn=true]


But...I was curious about that recruitment letter.
[cpg]

The words "to serve" the "master" sounded so appealing that I couldn't move my eyes to the other items.
[cpg]

I even felt that there was something that attracted me to it.
[cpg]

[OnName num="masato"]
There was something about it that attracted me.
[cpg cn=true]



[SE f=se010]
;//【ＳＥ】『電話を掛ける』ピポパポ、プルルルル

I was also attracted by the words "no academic or professional background required"... I couldn't help but make a phone call.
[cpg]



;//ＢＫ


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=2100]
[BG f="black.ui" time=1]


;//レターボックスout
[FACE method="out" pos="4/7"]

[WAIT time=1000]
[STOPBGM]


[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]



[window target=true]


[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="ep001.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
