*start

;#################################################
*Ep013|M-man style
;#################################################

[SCENE id=13]


[stflag jump_scene=0]
[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

[BGM f="se"]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夜）******************************************************

[window target=true]


Master has not been in good spirits lately.
[cpg]

It's because her marriage to that man has become a concrete event in the near future.
[cpg]

Day by day... Master is losing his strength like before.
[cpg]

[OnName num="masato"]
"But... what can I do?"
[cpg cn=true]


No matter how much I think about her, no matter how much I worry about her, the reality is that I can't do anything useful.
[cpg]

I'm just a servant. No, I'm just a servant...or a pet...what can a man like that do?
[cpg]


[SE f=se016]
;//【ＳＥ】『窓を開ける』


[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『空』（夜）******************************************************

[OnName num="masato"]
The wind feels good. Hmm...?
[cpg cn=true]


;//ＢＫ


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


;//【ＢＧ】『分岐路のある道』（夜）******************************************************
;//※街の中心や住宅街（小夜宅がある方面。小夜宅は小高い丘の上にある）への分岐路がある道

[SE f=se006]
;//【ＳＥ】『走る』

[WAIT time=1100]


[window target=true]


[OnName num="masato"]
Tanaka-san.
[cpg cn=true]


[OnName num="butler"]
"Oh, Masato-dono. What are you doing here so late at night?
[cpg cn=true]


[OnName num="masato"]
"No, I saw Mr. Tanaka, so..."
[cpg cn=true]


[OnName num="butler"]
"I see. It's a nice breeze today, so I thought I'd take a walk.
[cpg cn=true]


[OnName num="masato"]
Do you mind if I join you?
[cpg cn=true]


[OnName num="butler"]
Of course. It's better to have someone to talk to to keep me occupied.
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]


We went for a walk, chatting.
[cpg]

[OnName num="masato"]
"Mr. Tanaka..."
[cpg cn=true]


[OnName num="butler"]
What is it?
[cpg cn=true]


[OnName num="masato"]
It's about Master...
[cpg cn=true]


[OnName num="butler"]
"......"
[cpg cn=true]



[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]



;//【ＢＧ】『分岐路のある道』（夜）******************************************************

;//レターボックスin
[FACE method="feadein_up" pos="4/7"]
[WAIT time=1000]

[OnName num="butler"]
Would you like a cup of coffee?
[cpg cn=true]

[OnName num="masato"]
Yeah.
[cpg cn=true]

[SE f=se069]
;//【ＳＥ】『缶コーヒーを買う』ピッ、ガタンッ

[OnName num="masato"]
Thanks.
[cpg cn=true]

[SE f=se070]
;//【ＳＥ】『缶コーヒーを開ける』プシュッ

[OnName num="butler"]
Hmm. Even a can of coffee is good when you drink it like this.
[cpg cn=true]


[OnName num="masato"]
......
[cpg cn=true]


[OnName num="butler"]
I've been thinking about your daughter, too. Of course, I was thinking about your husband, too.
[cpg cn=true]


With a cup of coffee in his hand, Mr. Tanaka began to talk.
[cpg]

[OnName num="butler"]
I wish there was a better way, but I can't seem to come up with anything.
[cpg cn=true]


[OnName num="masato"]
"Me neither...
[cpg cn=true]


Even I, a slow learner, could somehow understand.
[cpg]

Mr. Tanaka had been thinking about it for a long time, too. I've been thinking about that house.
[cpg]

[OnName num="masato"]
But... this is wrong, isn't it? Don't you think so too, Tanaka-san!"
[cpg cn=true]


[OnName num="butler"]
"I... don't think your husband's idea is wrong."
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[OnName num="butler"]
I don't think your idea is wrong. He was troubled, he suffered... and then he made his decision. As a steward, I cannot deny him his decision.
[cpg cn=true]


[OnName num="masato"]
"Ugh..."
[cpg cn=true]


You are right, that is true. It's a good idea to take a look at your own personal life.
[cpg]

I'm sure you'll find a lot of things to consider when answering this question.
[cpg]

[OnName num="masato"]
"But... but... then Master..."
[cpg cn=true]


[OnName num="butler"]
"You have been prepared for this for a long time, young lady. Master, too."
[cpg cn=true]


[OnName num="butler"]
That's why he did everything she wanted and gave her so much love.
[cpg cn=true]


[OnName num="butler"]
"The young lady improved herself for the sake of her husband and her home. She has honed herself for the sake of her husband and her home, for the time that will come.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


[OnName num="butler"]
"Well, for that reason, I have been reckless in many ways. Especially welcoming you into my home..."
[cpg cn=true]


[OnName num="butler"]
"Neither you nor your daughter, deep down, want to. But they are both convinced of it.
[cpg cn=true]


[OnName num="masato"]
That's what I don't understand.
[cpg cn=true]


[OnName num="butler"]
Well, I don't really know either.
[cpg cn=true]


[OnName num="masato"]
I don't know what it's like for you and for your husband to have to do something you don't want to do.
[cpg cn=true]


[OnName num="butler"]
But we don't have a solution to that either.
[cpg cn=true]


[OnName num="butler"]
Otherwise, we wouldn't even have the right to interfere.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


Mr. Tanaka's tone intensified. Yes, if I could do something about it, I would have done it by now, no matter what the cost.
[cpg]

It's a great way to make sure you're getting the most out of your money.
[cpg]

It's a roundabout, unanswerable question.
[cpg]

[OnName num="masato"]
"...............'s opponent."
[cpg cn=true]


[OnName num="butler"]
"What?"
[cpg cn=true]


[OnName num="masato"]
If only the other man would go away .......
[cpg cn=true]


[OnName num="butler"]
Masato-dono. You can't do that.
[cpg cn=true]


[OnName num="masato"]
Because I can't think of anything else! I can't think of anything else!
[cpg cn=true]


[OnName num="butler"]
But if you jump to that option too easily, you won't have a shred of forethought.
[cpg cn=true]


[OnName num="butler"]
Most of all your daughter will be saddened.
[cpg cn=true]


[OnName num="masato"]
What...
[cpg cn=true]


In the end, I can't be of any use whatsoever.
[cpg]

[OnName num="butler"]
...... It's getting cold, isn't it? It's time to go back.
[cpg cn=true]

[window target=false]


[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=1000]


[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]

;//【ＢＧ】『分岐路のある道』（夜）******************************************************

[SE f=se005]
;//【ＳＥ】『歩く』

[WAIT time=1000]

[window target=true]

[OnName num="masato"]
"......"
[cpg cn=true]


[OnName num="butler"]
Can I have a word with you?
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[OnName num="butler"]
Ever since she was a child, the young lady did not go out much. She rarely leaves the house except to go to school.
[cpg cn=true]


Yes, that's right. Master was always at home.
[cpg]

[OnName num="butler"]
I suppose it was partly because he wanted to distract himself from a certain future.
[cpg cn=true]


[OnName num="butler"]
The man you are married to is an object of fear for you, young lady. Once you're in the house, it's unlikely that you'll be exposed to his eyes.
[cpg cn=true]


[OnName num="butler"]
I think that's why she doesn't leave the house.
[cpg cn=true]


[OnName num="butler"]
"Well, that's why you don't leave your house. Well, he's a hermit.
[cpg cn=true]


Mr. Tanaka sometimes says the hardest things straightforwardly.
[cpg]

[OnName num="butler"]
I was also worried about the young lady. I was worried about her too, but... at some point, I realized that it wasn't such a bad thing.
[cpg cn=true]


[OnName num="masato"]
"Not so bad...?"
[cpg cn=true]


[OnName num="butler"]
Yes. Ever since you came to this house.
[cpg cn=true]


[OnName num="butler"]
To tell you the truth, I didn't know who you were and I didn't think it was right to have a social outcast in my house.
[cpg cn=true]

[SE f=se014]
;//【ＳＥ】『衝撃』


[OnName num="masato"]
"That's a terrible thing to say! I mean, was I that bad of an impression?
[cpg cn=true]


[OnName num="butler"]
"Yes. We were all planning how to get him out of the house.
[cpg cn=true]


[OnName num="masato"]
"So he didn't like me... then, that smile... that kindness... oh my god, I'm going to lose faith in people..."
[cpg cn=true]


[OnName num="butler"]
"Hohohoho. It was a long time ago, wasn't it? In the beginning, I mean.
[cpg cn=true]


[OnName num="masato"]
"Ugh...something doesn't add up."
[cpg cn=true]


[OnName num="butler"]
"...... However, unlike what we had expected... the young lady seemed to be happy every day. She was smiling more and more... that's how I felt."
[cpg cn=true]


[OnName num="butler"]
"Well, I was just as angry as she was.
[cpg cn=true]


It's hard to keep up with all these little comments.
[cpg]

[OnName num="butler"]
Yes, really... the young lady seems to be enjoying herself every day. It's thanks to Masato-dono.
[cpg cn=true]


[OnName num="butler"]
"I'm glad you came here. I'm glad you came here, I think so now.
[cpg cn=true]


[OnName num="masato"]
"Mr. Tanaka..."
[cpg cn=true]


[OnName num="butler"]
It is not enough for us servants to just listen to orders. We must follow the Lord's will, help when he is troubled, and admonish when he goes wrong.
[cpg cn=true]

[OnName num="butler"]
We must rejoice and suffer together, and trust in each other. Otherwise, the machines will just do it all for us.
[cpg cn=true]


[OnName num="butler"]
But as I said before, we cannot simply disagree with the Lord's decisions.
[cpg cn=true]


[OnName num="butler"]
Masato-dono...
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]

;//レターボックスin
[FACE method="feadin_up" pos="4/7"]
[WAIT time=2000]


[OnName num="butler"]
Are you a butler or a maid? Are you a butler or a maid? Are you a butler, a maid, or... just a pet?
[cpg cn=true]


[OnName num="masato"]
"........."
[cpg cn=true]


[OnName num="butler"]
"Please support your daughter."
[cpg cn=true]


Finally, I understood what Mr. Tanaka was trying to say.
[cpg]

I can't believe I'm saying this, but I'm just a useless person. I can't get a normal job, and I'm on the fringe of society.
[cpg]

I'm just a scumbag who enjoys being tortured by girls who are like masters.
[cpg]

;//レターボックスout
[FACE method="feadout_up" pos="4/7"]
[WAIT time=2000]

[OnName num="masato"]
"Thank you, Mr. Tanaka."
[cpg cn=true]


But I am... different in that house. I'm different from the norm, out of the ordinary. I have no ties.
[cpg]

That's why I think there are things I can think about... things I can do...
[cpg]

I thought that the look he was giving me was filled with such expectations.
[cpg]

[OnName num="masato"]
I...I'll try my best.
[cpg cn=true]


I smiled back at him.
[cpg]

[OnName num="butler"]
I smiled back, "Ho-ho. That's... that's very kind of you to say.
[cpg cn=true]


He smiled back at me.
[cpg]

[OnName num="butler"]
"Please take good care of my daughter.
[cpg cn=true]


He bowed deeply, and I silently returned the bow.
[cpg]

[OnName num="masato"]
I'll go back first!
[cpg cn=true]


[OnName num="butler"]
"Yes."
[cpg cn=true]


As I was about to run off, one thing struck me.
[cpg]

[OnName num="masato"]
I was about to run when one thing struck me: "By the way, Tanaka-san and the others... how could they trust me? Even if it's just because Master seems to be enjoying himself..."
[cpg cn=true]


[OnName num="butler"]
I could see that you are a good person at heart. You're just a pervert..."
[cpg cn=true]


[OnName num="masato"]
"Hahaha..."
[cpg cn=true]


I was very happy to hear you say that.
[cpg]

[OnName num="butler"]
I'm glad to hear you say that, but I still think you're a little too impulsive in your decisions.
[cpg cn=true]


[OnName num="masato"]
"Oh, I'm sorry, I'm sorry, I'm sorry! Don't go any further, I'll die of embarrassment...!
[cpg cn=true]


[OnName num="butler"]
I want you to take full responsibility for leading your daughter to the abnormal...
[cpg cn=true]


[OnName num="masato"]
I'm sorry, I'm sorry!
[cpg cn=true]


In many ways, this is something I have to settle for.
[cpg]

[OnName num="masato"]
"Well, I mean, I don't want you to get your hopes up too high, but if you could just stay with me as if you were on a medium-sized ship..."
[cpg cn=true]


[OnName num="butler"]
"Hohoho. Even a medium-sized ship can lose to a large one, depending on how you steer.
[cpg cn=true]


[OnName num="masato"]
Yes, I'll see what I can do!
[cpg cn=true]



[SE f=se006]
;//【ＳＥ】『走りだす』ダダッ

With that, I started running.
[cpg]

[OnName num="masato"]
And! People like us are all helpless, but... still, there are no bad people! That's my theory!
[cpg cn=true]


[OnName num="butler"]
Hohohoho.
[cpg cn=true]



[SE f=se006]
;//【ＳＥ】『走る』ダッダッダッ

[STOPBGM]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]



[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;//【ＢＧ】『空』（夜）

;//レターボックスin
[FACE method="in" pos="4/7"]
[WAIT time=1]


[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]


;//【ＢＧ】『分岐路のある道』（夜）******************************************************

[window target=true]


[OnName num="butler"]
"........."
[cpg cn=true]




[OnName num="butler"]
......... I guess I should have turned him in to the police, huh? Ho, ho, ho, ho, ho.
[cpg cn=true]


[SE f=se084]
;//【ＳＥ】『チーン』
[BG f="black.ui" time=3000]
[WAIT time=3000]


[STOPBGM]

;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=1]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse



[jump storage="ep014.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////
