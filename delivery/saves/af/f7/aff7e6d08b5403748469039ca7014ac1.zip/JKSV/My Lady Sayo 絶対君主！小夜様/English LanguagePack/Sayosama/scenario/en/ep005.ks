*start



;#################################################
*Ep005|M's special water
;#################################################

[SCENE id=5]


[stflag jump_scene=0]
[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


[BG f="black.ui" time=1000]
[WAIT time=1500]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]

[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

[BGM f="d1"]

;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[BG f="b_01_2_up.ui" time=1000]

;//レターボックスin
[FACE method="feadin" pos="4/7"]

[SE f=se087 loop=true]
;//【ＳＥ】『洗濯機の音』

[WAIT time=1000]


[window target=true]


A box rattling up and down and shaking from side to side in front of me.
[cpg]

[OnName num="masato"]
..............."
[cpg cn=true]


I've been thinking about this all day. This is where the master's clothes...
[cpg]

[OnName num="maid_A"]
"......... What are you doing?
[cpg]

[OnName num="masato"]
What?
[cpg cn=true]

[SE f=se033 loop=true]
;//【ＳＥ】『心音』

I noticed a maid looking at me with narrowed eyes from the entrance, and I came to my senses.
[cpg]

This is the laundry room of the Misanagi family.
[cpg]

I was instructed to do my laundry here today.
[cpg]


[OnName num="masato"]
It's nothing! What can I do for you?
[cpg cn=true]


I felt like it was too late to mend my ways, but the maid didn't mention what she had seen and started talking about her requirements.
[cpg]

[stopse g=6]
;//ループse



[OnName num="maid_A"]
"Masato, I'm sorry, but... please take this with you."
[cpg]

[OnName num="masato"]
"Oh, yes! I understand!
[cpg cn=true]


[SE f=se078]
;//【ＳＥ】『衣擦れ』

[WAIT time=1000]


[OnName num="masato"]
I understand! That's quite a lot, isn't it?
[cpg cn=true]


[OnName num="maid_A"]
Yes, it's always a lot of work.
[cpg]

The clothes I received were quite thick. Do I have to wash them too?
[cpg]

I'm still waiting for my turn to do the laundry, but...
[cpg]

[OnName num="maid_A"]
"Then, please do it."
[cpg]

[OnName num="masato"]
"Yes. I'll leave it to you.
[cpg cn=true]


[OnName num="maid_A"]
"Couscous. Please make sure you don't slack off.
[cpg]

[OnName num="masato"]
Ugh, forget it.
[cpg cn=true]


[OnName num="maid_A"]
Oh... looks like your laundry is done.
[cpg]

[OnName num="masato"]
Oh, yes. Thank you."
[cpg cn=true]

[SE f=se005]
;//【ＳＥ】『歩く』

The young maid leaves with a smile and a fluttering wave. She's always caught me making embarrassing mistakes.
[cpg]

I need to be better at this.
[cpg]

Naturally, I do the laundry for this house first. But since there are half a dozen servants, there's a lot of laundry to be done there, too.
[cpg]

I'll have to hurry up and get it done in time.
[cpg]

[OnName num="masato"]
"Okay, I'll do my best!"
[cpg cn=true]



[SE f=se005]
;//【ＳＥ】『歩く』

[WAIT time=1500]


[OnName num="butler"]
"Oh, Masato-dono. "Oh, Masato-dono, I thought I heard some kind of spirited voice.
[cpg cn=true]


[OnName num="masato"]
Tanaka-san.
[cpg cn=true]


[OnName num="butler"]
Please keep up the good work. For your daughter's sake.
[cpg cn=true]


[OnName num="masato"]
"Yes, sir. I'll do my best.
[cpg cn=true]


I put my energy into doing the laundry, but I think Mr. Tanaka meant it in a broader sense.
[cpg]

Either way, she was expecting me to do my best, so I felt motivated to do my best.
[cpg]

[OnName num="masato"]
All right!
[cpg cn=true]



[SE f=se087 loop=true]
;//【ＳＥ】『洗濯機の音』

[OnName num="masato"]
.........."
[cpg cn=true]


[OnName num="masato"]
......, go for it, civilized!"
[cpg cn=true]


My motivation was not demonstrated and I was spinning. My motivation was in vain, and I was left with a washing machine that was running at full capacity.
[cpg]

[stopse g=6]
;//ループse

[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]



[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[SE f=se005]
;//【ＳＥ】『歩く』

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1000]

[WAIT time=1000]

[stopse g=2]
;//通常se

[window target=true]


[VOICE f="Sayo224"]
[OnName num="sayo"]
"Looks like you're doing a good job."
[cpg cn=true]


[OnName num="masato"]
Oh, master! Welcome home, sir.
[cpg cn=true]


As I was washing the laundry I was ordered to do, my master appeared.
[cpg]

It seems that he had returned from the school. Is it that time already?
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo225"]
[OnName num="sayo"]
I thought he was selling oil somewhere since he didn't come to pick me up, but... hmm.
[cpg cn=true]


[OnName num="masato"]
I'm sorry.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo226"]
[OnName num="sayo"]
I'm not mad at you.
[cpg cn=true]


I'm not mad at you." It was nice of you to say that, but I still wanted to welcome her.
[cpg]

[OnName num="masato"]
Oh! Master, you're sweating..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo227"]
[OnName num="sayo"]
"Ah... The sun was strong today, and it was hot.
[cpg cn=true]


I looked at him and saw that he was sweating a lot.
[cpg]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[OnName num="masato"]
Here."
[cpg cn=true]


I took out a handkerchief from my pocket and handed it to him. I'm not in the habit of carrying one around, but Mr. Tanaka told me to have one.
[cpg]

It will come in handy at times like this....
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo228"]
[OnName num="sayo"]
"Oh, thank you. But it's okay, I have my own.
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[WAIT time=1000]


Master wiped the sweat off with his own handkerchief and handed it to me.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo229"]
[OnName num="sayo"]
Here.
[cpg cn=true]


[VOICE f="Sayo230"]
[OnName num="sayo"]
It's all wet from sweat, so you can wash it while you're at it.
[cpg cn=true]


[OnName num="masato"]
.........
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo231"]
[OnName num="sayo"]
Are you listening to me?
[cpg cn=true]


[OnName num="masato"]
Ha, yes! Yes, sir! I'll wash it for you...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo232"]
[OnName num="sayo"]
You're on.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo233"]
[OnName num="sayo"]
Oh, and... come to my room as soon as you finish your laundry.
[cpg cn=true]


[OnName num="masato"]
Yes, sir. Thank you, sir.
[cpg cn=true]

[STOPBGM]

[SE f=se005]
;//【ＳＥ】『歩く』コツコツ
[FO pos="2/3" time=1500]
[WAIT time=1500]


[OnName num="masato"]
"......"
[cpg cn=true]


I was left alone with a sweat-soaked handkerchief in my hand.
[cpg]

[BG f="b_01_2_up.ui" time=1000]
[WAIT time=1500]


Nothing strange was happening.
[cpg]

But somehow, I felt like I was being tested.
[cpg]

[BGM f="h1"]


[SE f=se033 loop=true]
;//【ＳＥ】『心音』

[WAIT time=1500]


[OnName num="masato"]
"No...no, no, no! No, no, no! Laundry, laundry, laundry!
[cpg cn=true]


I had to quickly throw this magical object into the washing machine.
[cpg]

But .......
[cpg]

[OnName num="masato"]
But ........., ............
[cpg cn=true]


I'm not going to be able to do that if I let the scent of it come from my hand and take it into my nostrils along with the air.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="masato"]
(Here, Master's sweat is on .......)
[cpg cn=true]


This handkerchief is actually a bit heavy. This handkerchief is actually a little bit heavy, because it absorbs a lot of Master's sweat.
[cpg]

This handkerchief is actually a bit heavy because it absorbs a lot of Master's sweat. If you squeeze it, the sweat will drip out. It's worth more than a hundred million tons of natural water from Alus.
[cpg]

And then there's this scent that tickles my nostrils even from 30 centimeters away from my face.
[cpg]

The floral and exciting scent of the master. This is amazing.
[cpg]

It's quite a stimulating scent. In other words, it's a steaming smell that sticks to your nose.
[cpg]

The master goes to a young lady's school where rich people gather. I'm sure that just spending a normal day at school wouldn't sublimate into a scent like this.
[cpg]

He must have had physical education today.
[cpg]

The sweat that was shed in a healthy manner through physical exercise. The rising humidity in the clothes. A scent that matures.
[cpg]

The miraculous process that took a whole day to complete. Right now, the handkerchief in my hand is emitting this fragrance. It's impressive.
[cpg]

I can't put a price on this handkerchief. I can eat ten bowls of rice with it.
[cpg]

[OnName num="masato"]
"Haa, haa..."
[cpg cn=true]


Master's handkerchief. Sweat absorbing. Steamy. It had too many elements to blow away my reason.
[cpg]

[OnName num="masato"]
(I can't take this any longer!)"
[cpg cn=true]

[SE f=se015]
;//【ＳＥ】『厚みのある布束』


Instantly, I pressed my master's handkerchief to my face with my own hand, like a pie crust being thrown at my face.
[cpg]

[OnName num="masato"]
"Swoosh, swoosh, swoosh... ah, ah... ah..."
[cpg cn=true]


Great. It smelled so good. I can feel my tongue and head going numb.
[cpg]

[OnName num="masato"]
"Mmm... mmmm, mmmm... master, master...!"
[cpg cn=true]


I know that if I'm caught doing this without doing my job, I'll get angry.
[cpg]

It's not that I think it's inevitable that I was given this thing.
[cpg]

I just let my desire get the better of me.
[cpg]

[OnName num="masato"]
Swoosh...haha...swoosh...haha..."
[cpg cn=true]


I sniffed as hard as I could, filling my lungs and all the oxygen going to my brain with Master's scent.
[cpg]

[OnName num="masato"]
I smelled so hard that it filled my lungs and all the oxygen to my brain. I've never smelled anything like this before..."
[cpg cn=true]


I want to take my time and enjoy it. The handkerchief has a number of points that can be enjoyed.
[cpg]

But I don't have time. My master has called me, and I have to wash this handkerchief right away. What a pity.
[cpg]

[OnName num="masato"]
"Master's sweat..."
[cpg cn=true]


Bliss. That's the perfect word.
[cpg]

[OnName num="masato"]
Master, I'm so sorry..."
[cpg cn=true]


At such a time when all reason is blown away, ......
[cpg]

[stopse g=6]
;//ループse

[STOPBGM]

[SE f=se016]
;//【ＳＥ】『扉を開ける』

[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=1000]

[WAIT time=500]

[VOICE f="Sayo234"]
[OnName num="sayo"]
"You're late! How long do I have to wait? ......"
[cpg cn=true]


[OnName num="masato"]
"What the...?"
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo235"]
[OnName num="sayo"]
"...... what?"
[cpg cn=true]

[SE f=se014]
;//【ＳＥ】『衝撃』

If I had finished my work immediately as I was told, my master would not have come.
[cpg]

But I'm here. It was late, so the master who came to check on me found me.
[cpg]

And he saw me doing something dangerous.
[cpg]

[BGM f="h1"]

[OnName num="masato"]
"Oh, Master... oh, this is..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo236"]
[OnName num="sayo"]
"........."
[cpg cn=true]


I just barely managed to stop myself. This is the first time I've been able to do this.
[cpg]

[VOICE f="Sayo237"]
[OnName num="sayo"]
It's late, so why don't you go to the trouble of visiting..."
[cpg cn=true]


[OnName num="masato"]
"Oh...I mean...I'm sorry!"
[cpg cn=true]


I heard her bite her lip.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo238"]
[OnName num="sayo"]
"What are you doing, ignoring my orders?"
[cpg cn=true]


[window target=false]


[SE f=se030]
;//【ＳＥ】『風切音』
[FO pos="2/3" time=800]
[BG f="black.ui" time=800]
[WAIT time=800]
;//ＢＫ

[WAIT time=1000]

;//画面揺れる演出

[SE f=se001]
;//【ＳＥ】『金的』ゴキンッ


[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=500]
[WAIT time=1100]
[BG f="white.ui" time=1]
;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]
[WAIT time=1000]

[BG f="b_01_2_up.ui" time=1000]

;//レターボックスin
[FACE method="feadin" pos="4/7"]

[window target=true]


--A moment later, the master unleashed a swift kick.
[cpg]

[OnName num="masato"]
A moment later, the master unleashed a swift kick.
[cpg cn=true]


You can find a lot more information on the web.
[cpg]

A powerful kick, without a shred of mercy, pierces my body.
[cpg]

[OnName num="masato"]
This is a great way to make sure you are getting the most out of your investment.
[cpg cn=true]

[SE f=se062]
;//【ＳＥ】『倒れる』

;//フラッシュ

It's a good idea to have a good idea of what you're doing.
[cpg]

Even so, my body did not stop trembling in pain. ......
[cpg]

;//ＢＫ

[window target=false]

[STOPBGM]




[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2_up.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


;//【ＢＧ】『豪邸、廊下』（昼）******************************************************


[BGM f="h1"]

[window target=true]


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo239"]
[OnName num="sayo"]
Stand up.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo240"]
[OnName num="sayo"]
"Answer me. What were you doing here?
[cpg cn=true]


[OnName num="masato"]
What were you...
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo241"]
[OnName num="sayo"]
Answer me.
[cpg cn=true]


The master was unusually scary.
[cpg]

[OnName num="masato"]
I was sniffing my ...... handkerchief.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo242"]
[OnName num="sayo"]
I'll know it when I see it. Why were you doing that?
[cpg cn=true]


[OnName num="masato"]
"Well, when I saw Master's ...... handkerchief he gave me, I couldn't take it anymore. ..."
[cpg cn=true]


When I put it into words myself, I reaffirm what I did and feel even more ashamed.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo243"]
[OnName num="sayo"]
It's disgusting."
[cpg cn=true]


Master spat, then continued, "I'm angry.
[cpg]

[VOICE f="Sayo244"]
[OnName num="sayo"]
I'm angry. Do you understand?"
[cpg cn=true]


[OnName num="masato"]
...... Yes.
[cpg cn=true]


[VOICE f="Sayo245"]
[OnName num="sayo"]
"Do you know why?"
[cpg cn=true]


[OnName num="masato"]
"Because I did this to Master's... handkerchief."
[cpg cn=true]


I don't know if that's the right answer. She didn't say anything about it.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo246"]
[OnName num="sayo"]
...... I'm going to give you a bit of a hard spanking."
[cpg cn=true]


[OnName num="masato"]
What?"
[cpg cn=true]


After a short pause, the master ordered more.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo247"]
[OnName num="sayo"]
"Lie down on your back there.
[cpg cn=true]


[OnName num="masato"]
"Yes, yes..."
[cpg cn=true]


Not wanting to disobey, I did as I was told.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ
;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=1]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

;//●ＣＧ（雅人＆小夜・主人公の上に座るヒロイン：洗濯場）ev_06

;**【ＣＧ】 ev_06_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo248"]
[OnName num="sayo"]
The chair is as uncomfortable as ever.
[cpg cn=true]


[OnName num="masato"]
...... Sorry.
[cpg cn=true]


[VOICE f="Sayo249"]
[OnName num="sayo"]
It's not that I'm upset about it. I just thought I should apologize.
[cpg cn=true]

[SE f=se020]
;//【ＳＥ】『ビンタ系』

My skin is slapped.
[cpg]

[VOICE f="Sayo250"]
[OnName num="sayo"]
Don't move.
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』


The master seemed to be preparing for something. It sounded like he was going through his bag.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo251"]
[OnName num="sayo"]
I'm going to scribble on your body so you can reflect on what you've done.
[cpg cn=true]

;**【ＣＧ】 ev_06_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1500]

She had a magic pen in her hand.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo252"]
[OnName num="sayo"]
What should I write on you?　I'll let you choose.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo253"]
[OnName num="sayo"]
Come on, come on. I said I'll let you choose your own punishment.
[cpg cn=true]


I knew that if I said anything half-heartedly, it would make her even angrier. I realized that, so I opened my mouth.
[cpg]

[OnName num="masato"]
"...I'm a useless person who is unfit to be a servant."
[cpg cn=true]



[SE f=se089]
;//【ＳＥ】『マジックペンの音２』

;**【ＣＧ】 ev_06_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=2500]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo254"]
[OnName num="sayo"]
"That came out easily. What else?
[cpg cn=true]


[OnName num="masato"]
I'm a bum who can't even wash his master's handkerchief. ......
[cpg cn=true]


[VOICE f="Sayo255"]
[OnName num="sayo"]
"Scum" is a bit weak, isn't it? I already said I'm not a good person.
[cpg cn=true]


[VOICE f="Sayo256"]
[OnName num="sayo"]
Yes. How about "livestock"?
[cpg cn=true]


[OnName num="masato"]
"Ugh..."
[cpg cn=true]



[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

This back-and-forth and torment continued for quite some time...
[cpg]

[STOPBGM]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=2100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]


[BG f="b_01_2.ui" time=1000]


[WAIT time=1500]


;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[window target=true]
[BGM f="h1"]

[OnName num="masato"]
"Ow, ow, ow, ow, ow, ow, ow, ow, ow, ow, ow, ow, ow..."
[cpg cn=true]


I cried miserably.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo257"]
[OnName num="sayo"]
"Oh my god, you're crying all of a sudden, you're like a baby.
[cpg cn=true]


Master was really angry like never before. That scared me.
[cpg]

I was afraid that I wouldn't be able to breathe and that I would really die.
[cpg]

I was afraid that Master might hate me.
[cpg]

But most of all... it was me who brought this situation on myself. I felt ashamed of myself for being so stupid and weak, and tears flowed down my face.
[cpg]

[OnName num="masato"]
"Hiccup, ugh... ugh, ugh... ugh, ugh..."
[cpg cn=true]


[SE f=se078]
;//【ＳＥ】『衣擦れ』

[BG f="b_01_2_up.ui" time=1500]

[FG f="CHA01_p5_02_a.ui" method="change_1"  pos="2/3" time=1500]

;//レターボックスin
[FACE method="feadin_up" pos="4/7"]

[WAIT time=1500]


[VOICE f="Sayo258"]
[OnName num="sayo"]
"Come on, don't cry. I'm sorry, too. So don't cry.
[cpg cn=true]


[OnName num="masato"]
"Ugh... sorry, master... sorry, sorry..."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo259"]
[OnName num="sayo"]
"Good, good. Good boy, good boy.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo260"]
[OnName num="sayo"]
Silly girl, thinking only of herself and not of me.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo261"]
[OnName num="sayo"]
But I don't hate him. I don't like idiots but I do like stupid people.
[cpg cn=true]


[OnName num="masato"]
"I'm sorry, Master..." "I'm sorry, Master..." "I'm sorry..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo262"]
[OnName num="sayo"]
I was too rough with you. I'm sorry. So stop shedding tears."
[cpg cn=true]


Master sat down on the ground with his knees folded, put my head on his lap as I cried in my sleep, and stroked my head.
[cpg]

I was the one who was at fault. Tears flowed again at her kindness.
[cpg]

She put me on her lap, stroked my head, and waited for me to calm down.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo263"]
[OnName num="sayo"]
"You're calm now, aren't you?"
[cpg cn=true]


[OnName num="masato"]
Yes...I'm sorry...gosh...
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[BG f="b_01_2.ui" time=1500]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1500]

;//レターボックスout
[FACE method="feadout_up" pos="4/7"]

[WAIT time=1500]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo264"]
[OnName num="sayo"]
I'm angry because you put yourself before my orders... and I'm angry at you for that.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo265"]
[OnName num="sayo"]
You know that, don't you?
[cpg cn=true]


[OnName num="masato"]
"Ugh... yes..."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo266"]
[OnName num="sayo"]
But your body will understand. So I'm going to keep going.
[cpg cn=true]


[OnName num="masato"]
Ugh... Please, please, please scold me.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo267"]
[OnName num="sayo"]
"Good. That's why you're my servant.
[cpg cn=true]


;//ＢＫ

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se025]
;//【ＳＥ】『超ビンタ』

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1500]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="sl"]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[SE f=se013]
;//【ＳＥ】『服を着る音』シュルッ

[window target=true]


After the masturbation was over, Master adjusted the disorder of his clothes.
[cpg]

[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo268"]
[OnName num="sayo"]
"Stand there for a moment."
[cpg cn=true]


[OnName num="masato"]
"Yes, sir."
[cpg cn=true]


Master said as he prepared himself.
[cpg]

I felt my heart pounding, wondering if I was still going to be touched.
[cpg]

[VOICE f="Sayo269"]
[OnName num="sayo"]
Don't move.
[cpg cn=true]


[OnName num="masato"]
Master, what are you...?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo270"]
[OnName num="sayo"]
You've got the letters backwards.
[cpg cn=true]


Master gazes at my scribbled body as if licking it carefully.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo271"]
[OnName num="sayo"]
"Hmmm. You look even more disgusting than I imagined..."
[cpg cn=true]


[OnName num="masato"]
Please don't look so hard...
[cpg cn=true]




;//ＢＫ

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_01_2.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

[window target=true]

[SE f=se005]
;//【ＳＥ】『歩く』


[VOICE f="Sayo272"]
[OnName num="sayo"]
"Tanaka-san."
[cpg cn=true]


[OnName num="butler"]
Yes?
[cpg cn=true]


[VOICE f="Sayo273"]
[OnName num="sayo"]
Let someone else do the laundry.
[cpg cn=true]


[OnName num="butler"]
I'm sorry.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo274"]
[OnName num="sayo"]
I'm sorry. Please.
[cpg cn=true]



[SE f=se005]
;//【ＳＥ】『歩く』

[move from="2/3" to="5/3" ease="easeInOutSine" time=2000]

[WAIT time=1500]


[OnName num="butler"]
Masato-dono is in trouble. (Masato-dono is going through a lot, isn't he?)
[cpg cn=true]



[FO pos="5/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2500]
;//ＢＫ

[SE f=se034]
;//【ＳＥ】『ノック』

[WAIT time=2000]


[VOICE f="Sayo275"]
[OnName num="sayo"]
Come in.
[cpg cn=true]


[OnName num="masato"]
Excuse me.
[cpg cn=true]


[window target=false]

[BG f="b_04_2.ui" time=1500]

;//【ＢＧ】『小夜の部屋』（昼）******************************************************

[SE f=se016]
;//【ＳＥ】『扉を開ける』

[WAIT time=2000]

[window target=true]

[OnName num="masato"]
Thank you for waiting.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo276"]
[OnName num="sayo"]
Hmm...
[cpg cn=true]


I came to the room with my body covered in magic marker scribbles.
[cpg]

My face was also scribbled on, so I couldn't cover everything with my clothes.
[cpg]

The servants I passed were looking at me like, "What's going on now? What's going on? I was lucky that I wasn't scorned.
[cpg]

I guess this is part of my punishment.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo277"]
[OnName num="sayo"]
"Well... then explain to me why you did what you did."
[cpg cn=true]


[OnName num="masato"]
"Yes, yes..."
[cpg cn=true]


It seems that master called me to make me explain why I was in that situation rather than to make me additionally angry.
[cpg]

[FACE method="change31" pos="2/3"]
[VOICE f="Sayo278"]
[OnName num="sayo"]
"No lies, no honesty... just the whole story."
[cpg cn=true]


[OnName num="masato"]
"Ugh... yes..."
[cpg cn=true]


I can't help it if she says this. In front of her order, I have to throw away such small things as shame.
[cpg]

[STOPBGM]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

As she said, I told her everything honestly. I told her everything honestly, and I mean everything.
[cpg]

Moreover, I made a passionate speech about how wonderful Master's handkerchief was. I'm an idiot...
[cpg]


[window target=false]

[BG f="b_04_2.ui" time=1500]

[WAIT time=2500]

;//【ＢＧ】『小夜の部屋』（昼）******************************************************


[BGM f="h1"]


[window target=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo279"]
[OnName num="sayo"]
"........."
[cpg cn=true]


When the master heard my story, his gaze swam from time to time, and his expression became tense.
[cpg]

She seems to be a little taken aback by the quirk. That's true, isn't it?
[cpg]

[VOICE f="Sayo280"]
[OnName num="sayo"]
"Ummm...umm...let's see......... let's see......... wait a minute..."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo281"]
[OnName num="sayo"]
Ugh, I'm a little dizzy...
[cpg cn=true]


[OnName num="masato"]
Are you okay?
[cpg cn=true]


It's not my place to say. Then the master put his hand out in front of him and stopped him not with words but with actions.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo282"]
[OnName num="sayo"]
I'm not in a position to say. Just in case...just in case. Just in case, you know..."
[cpg cn=true]


[OnName num="masato"]
"...... Yes."
[cpg cn=true]


He doesn't seem to have the energy to get angry.
[cpg]

[VOICE f="Sayo283"]
[OnName num="sayo"]
"(I don't know if it's a good idea to just let it end like this, but as a master, I have to discipline him...)"
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

I waited patiently for the next words, but then I noticed that Master's expression had changed.
[cpg]

It was as if he had come up with something.
[cpg]

[VOICE f="Sayo284"]
[OnName num="sayo"]
I was waiting for him to say something else.
[cpg cn=true]


[OnName num="masato"]
"?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo285"]
[OnName num="sayo"]
"Ten cups of rice in my handkerchief? You can eat it, right? You can eat that, right?
[cpg cn=true]


[OnName num="masato"]
"Well, um..."
[cpg cn=true]


When Master saw my dismay, he grinned and lifted the corners of his mouth.
[cpg]

[VOICE f="Sayo286"]
[OnName num="sayo"]
You can eat it, right?
[cpg cn=true]


[OnName num="masato"]
"Yes..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo287"]
[OnName num="sayo"]
If so, you should actually try it. Ten bowls of rice...
[cpg cn=true]



[SE f=se035]
;//【ＳＥ】『指パッチン』パチン

[WAIT time=1500]

[SE f=se016]
;//【ＳＥ】『扉が開く』ガチャ

[WAIT time=1500]

[SE f=se036]
;//【ＳＥ】『カート』ガラガラガラ、ガタガタガタ

[WAIT time=1500]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo288"]
[OnName num="sayo"]
"Ten bowls of rice."
[cpg cn=true]


When Master gave the signal, the maids and butlers, who had been waiting for some time, brought the rice cooker on a cart.
[cpg]

[OnName num="masato"]
......"
[cpg cn=true]


It was a ridiculously reckless thing to do. But I couldn't resist, nor did I want to.
[cpg]

I had to do as I was told and start putting white rice into my stomach, with my master's handkerchief (No. 2) wiping my sweat in front of me as a side dish...
[cpg]

;//ＢＫ
[STOPBGM]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_04_3.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『小夜の部屋』（夕方）******************************************************


[BGM f="h1"]


[SE f=se037]
;//【ＳＥ】『食器の音』

[WAIT time=1500]


[SE f=se037]
;//【ＳＥ】『食器の音』

[WAIT time=1500]

[SE f=se038]
;//【ＳＥ】『食器を置く音』カチャーン

[WAIT time=1500]


[window target=true]


[OnName num="masato"]
"Ugh ...... geppuu ......"
[cpg cn=true]

[STOPBGM]

[SE f=se002]
;//【ＳＥ】『時計の音』カッチコッチ

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]

[VOICE f="Sayo289"]
[OnName num="sayo"]

"..............."

[cpg cn=true]

;//qwe1

[OnName num="masato"]
"..............."
[cpg cn=true]



;//ここは後で名前の順番を入れ替えて下さい。

[BGM f="h1"]

[VOICE f="Sayo290"]
[OnName num="masato&sayo"]
(I ate it...)
[cpg cn=true]

[SE f=se011]
;//【ＳＥ】『どどーん』

[WAIT time=1000]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo291"]
[OnName num="sayo"]
"(I thought you were joking, so I said it as a form of discipline...)"
[cpg cn=true]


[OnName num="masato"]
(I was only half joking, or maybe I was out of control...)
[cpg cn=true]


But ten bowls of white rice ended up in my stomach. It's surprisingly possible.
[cpg]

But the master was also surprised that it was different from his plan. In fact, I think he's a bit taken aback again.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]


[VOICE f="Sayo292"]
[OnName num="sayo"]
"What? I don't know what that means! I just don't get it!"
[cpg cn=true]

;//qwe2

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo293"]
[OnName num="sayo"]
"You're going to eat it? I don't understand! That's crazy, right? It's a handkerchief! It's a handkerchief! It's crazy, isn't it? Isn't it strange?
[cpg cn=true]


Gee, Master... your character is blurred. My character is blurred.
[cpg]

[OnName num="masato"]
"Master, please calm down..."
[cpg cn=true]


[FG f="CHA01_p4_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo294"]
[OnName num="sayo"]
"I'm calm!"
[cpg cn=true]


It's no good. He's distraught.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo295"]
[OnName num="sayo"]
"Huh, huh. ........."
[cpg cn=true]


[OnName num="masato"]
I'm sorry, I'm sorry. I'm really... really sorry.
[cpg cn=true]


[VOICE f="Sayo296"]
[OnName num="sayo"]
"........."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo297"]
[OnName num="sayo"]
No, no... you were just doing what I told you to do... yeah, yeah... it was me... it was my fault. It's just that my perception was wrong. Yeah...
[cpg cn=true]


Oh, master is a little depressed because of me.
[cpg]

What an incompetent person I am.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo298"]
[OnName num="sayo"]
"Hmph..."
[cpg cn=true]


Oh, the master is in a pose of mental unification, as if he is about to ascend to some higher level!
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo299"]
[OnName num="sayo"]
"I see, I understand."
[cpg cn=true]


[OnName num="masato"]
"What can I do for you?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo300"]
[OnName num="sayo"]
For people like you, the handkerchief is not a joke, it's a side dish.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo301"]
[OnName num="sayo"]
It's not a joke, but for people like you, a handkerchief is a side dish. I'm sure it's something similar to that.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo302"]
[OnName num="sayo"]
If that's the case, then... once a month or so, I'll make a special meal menu for you, 'handkerchief and white rice'.
[cpg cn=true]


[OnName num="masato"]
"What, sir? I don't want to...
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo303"]
[OnName num="sayo"]
"Don't be shy. I'm trying to understand your tastes. So you can be honest.
[cpg cn=true]


[OnName num="masato"]
"Master?
[cpg cn=true]


I'm in trouble if you say that with such a merciful expression like a holy mother!
[cpg]

I'm not... no, not at all, but still... no! Please listen to me!
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo304"]
[OnName num="sayo"]
"This is also the duty of a master. This is also the duty of the master, to control the servant so that he will not make mistakes again, and also to discipline you. Do you understand?"
[cpg cn=true]


[OnName num="masato"]
"Of course I understand that. But...
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo305"]
[OnName num="sayo"]
You're annoying. Do you not like my handkerchief?
[cpg cn=true]


[OnName num="masato"]
No, I love them!
[cpg cn=true]


[FG f="CHA01_p4_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo306"]
[OnName num="sayo"]
What would you do if someone shoved a handkerchief in your mouth that hadn't been washed in a week, right or wrong?
[cpg cn=true]


[OnName num="masato"]
Munch, munch, munch!
[cpg cn=true]


[VOICE f="Sayo307"]
[OnName num="sayo"]
Your favorite handkerchief! I'm offering it to you once a month! What do you say?
[cpg cn=true]


[OnName num="masato"]
I'm so happy!
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo308"]
[OnName num="sayo"]
...... Okay. I have no complaints. Then it's decided.
[cpg cn=true]


[OnName num="masato"]
Ha, ha. ...... Yes, of course.
[cpg cn=true]


It was an unbelievable turn of events, and it was an unbelievable thing.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo309"]
[OnName num="sayo"]
By the way... do you have a preference for handkerchiefs?
[cpg cn=true]


[OnName num="masato"]
"Yes?
[cpg cn=true]


[VOICE f="Sayo310"]
[OnName num="sayo"]
The design, the fabric... and even who made it is important, isn't it? We have women from their twenties to their fifties, so if they have a preference in age, then to some extent..."
[cpg cn=true]


[OnName num="masato"]
"Oh my God! And not particularly! I'm a handkerchief omnivore, so anything will do!
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo311"]
[OnName num="sayo"]
...... So, yes. So there is such a category...
[cpg cn=true]


[OnName num="masato"]
And I prefer Master's! I don't like anything that isn't master's!
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo312"]
[OnName num="sayo"]
....... I understand. You don't have to shout so hard, I can hear you...
[cpg cn=true]


[OnName num="masato"]
Ha! I'm so sorry!
[cpg cn=true]


It's not that I don't like it.
[cpg]

[FG f="CHA01_p4_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo313"]
[OnName num="sayo"]
I'll give you mine once in a while. But I'll deduct the cost of the handkerchief from your salary.
[cpg cn=true]


[OnName num="masato"]
"What?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo314"]
[OnName num="sayo"]
I'm not lending you my handkerchief, I'm really giving it to you.
[cpg cn=true]


[OnName num="masato"]
I'm not lending you my handkerchief, I'm really giving you my handkerchief. - Oh, no... you don't mind if I take your handkerchief?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo315"]
[OnName num="sayo"]
I don't want you to take it back.
[cpg cn=true]


That's true, isn't it?
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo316"]
[OnName num="sayo"]
I'm sure you'll use it for something dirty anyway but if I gave it to you, do with it as you please.
[cpg cn=true]


[OnName num="masato"]
Yes, sir! Thank you very much.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo317"]
[OnName num="sayo"]
And don't ever use another handkerchief for anything like this again.
[cpg cn=true]


[OnName num="masato"]
Of course! Of course I will!
[cpg cn=true]


And so the matter was somehow settled.
[cpg]

[STOPBGM]

;//ＢＫ
[window target=false]

[FO pos="2/3" time=1000]

[BG f="black.ui" time=1000]
[WAIT time=2000]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="d1"]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************


[BG f="b_01_2_up.ui" time=1500]
;//レターボックスin
[FACE method="feadin_up" pos="4/7"]

[WAIT time=1500]

[window target=true]


The servants had their own place to eat. This is where I usually eat too.
[cpg]

[OnName num="masato"]
"Hey, where's my side dish..."
[cpg cn=true]


[OnName num="maid_B"]
The lady said that she didn't need it today and that I should just have white rice.
[cpg cn=true]


I can't believe this...
[cpg]


[SE f=se005]
;//【ＳＥ】『歩く』コツコツ
[WAIT time=1500]


I felt the presence of someone behind me, and there was Master.
[cpg]

[OnName num="masato"]
"Gosh, Master...!"
[cpg cn=true]

[stopse g=2]
;//通常se

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo318"]
[OnName num="sayo"]
It's getting late.
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

I'm sorry I'm late." ......
[cpg]

Master looked somewhat sluggish as he pulled a handkerchief out of his pocket.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo319"]
[OnName num="sayo"]
Here.
[cpg cn=true]


[OnName num="masato"]
"Oh...!
[cpg cn=true]


[OnName num="maid_C"]
Oh, Miss!
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo320"]
[OnName num="sayo"]
You promised me. It's for this month... use it carefully.
[cpg cn=true]

[FO pos="2/3" time=1000]
[SE f=se005]
;//【ＳＥ】『歩く』コツコツ

That's all he said, and then he left.
[cpg]

[OnName num="masato"]
(Master ......, yes, thank you very much.)"
[cpg cn=true]


As promised, Master began to provide me with handkerchiefs himself.
[cpg]

Once a month, I would eat my meal with Master's handkerchief by my side, while the people around me looked at me strangely.
[cpg]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

[jump storage="ep006.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
