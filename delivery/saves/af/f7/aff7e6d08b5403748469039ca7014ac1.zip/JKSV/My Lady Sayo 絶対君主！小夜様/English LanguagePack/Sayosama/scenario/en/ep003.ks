*start



;#################################################
*Ep003|The Big M and the Little S
;#################################################

[SCENE id=3]


[stflag jump_scene=0]
[window target=false]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep002で発生	ジャンプしてきた場合奉仕ルートで固定
[stflag gohome_flag=1]
[stflag pets_flag=0]
[endif]

[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1500]
;//ＢＫ
[SE f=se018]
;//【ＳＥ】『鳥の鳴き声』朝チュン
[WAIT time=1000]

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


;//【ＢＧ】『使用人の部屋（雅人の部屋）』（朝）******************************************************


;//※日本家屋じゃないからお屋敷とは言わない気がする。洋館の場合は何て言うんだろう？


[WAIT time=1000]

[BGM f="sl"]


[window target=true]

[OnName num="masato"]
"Huh...it's morning. I have to get ready quickly..."
[cpg cn=true]


It was the morning of the third day since we arrived at the mansion. Today was the start of the real work and live-in life.
[cpg]

The first two days were spent moving in, greeting the other butlers and maids, and explaining the house to them.
[cpg]

[SE f=se016]
;//【ＳＥ】『扉を開ける』ガチャ

[BG f="b_01_1.ui" time=1000]
[WAIT time=1500]
;//【ＢＧ】『豪邸、廊下』（朝）******************************************************

;//ここから小夜の喋り方が本来のものに。丁寧語は殆ど無い？

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo098"]
[OnName num="sayo"]
"Brunark~, Brunark~!"
[cpg cn=true]


The master is calling out some kind of special move.
[cpg]

I wonder if he's okay. Has she suddenly become childish?
[cpg]

[OnName num="masato"]
"Master... good morning."
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo099"]
[OnName num="sayo"]
"Good morning."
[cpg cn=true]


[OnName num="masato"]
Can I help you?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo100"]
[OnName num="sayo"]
Well, I couldn't see Brunark...
[cpg cn=true]


Well, is that the name of something you can see in reality?
[cpg]

[OnName num="dog"]
"Woof woof!"
[cpg cn=true]


[OnName num="masato"]
A dog?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo101"]
[OnName num="sayo"]
Brunark. Where have you been already? All right. ♪
[cpg cn=true]


I didn't know that was a pet name.
[cpg]

[OnName num="masato"]
He's cute.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo102"]
[OnName num="sayo"]
I bet it is. They've been together since they were little.
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo103"]
[OnName num="sayo"]
That's right. Well, you've come to the right place.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo104"]
[OnName num="sayo"]
Come here.
[cpg cn=true]


[OnName num="masato"]
Yes?
[cpg cn=true]


They took me in, and I was wondering what they were going to do to me, but then I found out the hard way.
[cpg]


[FO pos="2/3" time=1000]

[window target=false]



[SE f=se005]
;//【ＳＥ】『歩く』
[STOPBGM]


[BG f="black.ui" time=1000]
[WAIT time=1500]

[transition target={true} rule="tobira.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_1.ui" time=1]

[SE f=se017]
;//【ＳＥ】『扉を閉める』
[WAIT time=1]
[transition target={false} rule="tobira.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『小夜の部屋』（朝）******************************************************

[BGM f="h1"]
[window target=true]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo105"]
[OnName num="sayo"]
He took me in and I wondered what he was going to do to me.
[cpg cn=true]


He pointed to the doghouse in the corner of the master's room.
[cpg]

[OnName num="masato"]
It's terrible.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo106"]
[OnName num="sayo"]
"It's still good."
[cpg cn=true]


The kennel itself was gorgeous.
[cpg]

By the way, the dog, a corgi, is named Brunark. Why is he so good-looking?
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo107"]
[OnName num="sayo"]
Well, it's my dog's house... not yours.
[cpg cn=true]


[OnName num="masato"]
"Oh, you're kidding..."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo108"]
[OnName num="sayo"]
I was quite serious.
[cpg cn=true]


[OnName num="masato"]
"What?"
[cpg cn=true]


Let's not upset the master.
[cpg]


;//※下僕の場合///////////////////////////////

[if exp={getFlagValue("gohome_flag") == 1 }]

[OnName num="masato"]
He's so cute.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo109"]
[OnName num="sayo"]
We've been together since we were little.
[cpg cn=true]


[OnName num="masato"]
You're in Master's service. He's one of us.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo110"]
[OnName num="sayo"]
Don't be silly.
[cpg cn=true]


Do you think I'm more important than...?
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo111"]
[OnName num="sayo"]
She's my family. You are my servant. You're a servant. She's more important than you, so show her some respect.
[cpg cn=true]


[OnName num="masato"]
"...... Yes."
[cpg cn=true]

[endif]
;//※下僕の場合ーここまで//////////////////////////////




;//[FO pos="2/3" time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1500]
;//;//ＢＫ
;//
;//
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[BG f="black.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_04_1.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[STOPBGM]
;//
;//[WAIT time=100]
;//
;//[WAIT time=100]
;//;//【ＢＧ】『小夜の部屋』（朝）******************************************************



[FG f="CHA01_p4_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo112"]
[OnName num="sayo"]
All right, let's get started.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo113"]
[OnName num="sayo"]
I didn't invite you here to make small talk.
[cpg cn=true]


[OnName num="masato"]
I mean...?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo114"]
[OnName num="sayo"]
"Well... Since you're here to serve me, you'll have to make yourself my favorite.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo115"]
[OnName num="sayo"]
Now, get down on all fours.
[cpg cn=true]


[OnName num="masato"]
...... What?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo116"]
[OnName num="sayo"]
Don't make any stupid noises. Come on.
[cpg cn=true]


[SE f=se078]
;//【ＳＥ】『衣擦れ』

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]


;//●ＣＧ（雅人＆小夜・主人公四つん這いで椅子プレイ：小夜の部屋）ev_03（※ex01同一CG）


[BGM f="h1"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="masato"]
What are you going to do?
[cpg cn=true]


[VOICE f="Sayo117"]
[OnName num="sayo"]
What? Why are you asking me that?　Are you going to say no, depending on what it is?
[cpg cn=true]


[OnName num="masato"]
"No, no. I don't intend to.
[cpg cn=true]


[VOICE f="Sayo118"]
[OnName num="sayo"]
Then shut up and obey.
[cpg cn=true]


I did as I was told and got down on all fours.
[cpg]

This position reminded me of the interview.
[cpg]

I knew it wouldn't be the same, but I was still a little scared.
[cpg]

[SE f=se078]
;//【ＳＥ】『衣擦れ』


[VOICE f="Sayo119"]
[OnName num="sayo"]
It kind of reminds me of gymnastics, doesn't it?
[cpg cn=true]


Then Master sat down on top of me!
[cpg]

Suddenly, I was unprepared and collapsed.
[cpg]

[VOICE f="Sayo120"]
[OnName num="sayo"]
"What?
[cpg cn=true]

[SE f=se062]
;//【ＳＥ】『倒れる』
[STOPBGM]


;//ＢＫ

[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=500]
[WAIT time=1100]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]
[WAIT time=1]
[window target=true]


[BG f="b_04_1.ui" time=1000]
[WAIT time=1000]

[BGM f="sl"]
[WAIT time=100]
;//【ＢＧ】『小夜の部屋』（朝）******************************************************

[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo121"]
[OnName num="sayo"]
"Hey. It's a good thing I was just sitting there.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo122"]
[OnName num="sayo"]
If I'd had a teacup, I'd have been in trouble.
[cpg cn=true]


[OnName num="masato"]
I'm sorry, but I didn't know you were going to do this.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo123"]
[OnName num="sayo"]
I know you're not very perceptive so should I tell you in advance what I'm going to do?
[cpg cn=true]


I felt like I was letting him down. I couldn't say anything at all.
[cpg]

[SE f=se034]
;//【ＳＥ】『ノック』
[WAIT time=2000]
[OnName num="butler"]
"Miss, it's time to go."
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo124"]
[OnName num="sayo"]
"Okay. Let's go.
[cpg cn=true]


[OnName num="masato"]
Where to?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo125"]
[OnName num="sayo"]
To school.
[cpg cn=true]


Well, it was obvious from the way he was dressed that he was still a student.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo126"]
[OnName num="sayo"]
It's a fun place, but it's a hassle to go there every day...
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo127"]
[OnName num="sayo"]
Besides, I just got a new toy.
[cpg cn=true]


Are you talking about me?
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo128"]
[OnName num="sayo"]
I think I'll take a break from school today.
[cpg cn=true]


[OnName num="butler"]
No.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo129"]
[OnName num="sayo"]
...... Yes, yes. I know, I know.
[cpg cn=true]


The master's slightly childish reaction was unexpected. It's a good idea to have a good idea of what you're looking for.
[cpg]

[OnName num="butler"]
The young lady is a bit of a recluse.
[cpg cn=true]


[OnName num="masato"]
"I see..."
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo130"]
[OnName num="sayo"]
"I can hear you."
[cpg cn=true]


The master left for the school in the car driven by Mr. Tanaka.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1500]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=2500]
;//ＢＫ


;//夕方

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]



[window target=true]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo131"]
[OnName num="sayo"]
I'm home.
[cpg cn=true]


[OnName num="masato"]
Welcome home.
[cpg cn=true]


She seemed to be in a good mood.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo132"]
[OnName num="sayo"]
Come here.
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo133"]
[OnName num="sayo"]
Come on! Let's pick up where we left off this morning!
[cpg cn=true]


[OnName num="masato"]
Wait, wait, wait...
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

;//●ＣＧ（雅人＆小夜・四つん這いでテーブルになる主人公。読書をするヒロイン）ev_18（※ex02同一CG）
;//元の要素を残すのが難しいため、ＣＧ内容が大きく変わっています

[BGM f="h1"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Sayo134"]
[OnName num="sayo"]
If we use the table instead of the chair, it won't fall over.
[cpg cn=true]


[OnName num="masato"]
Well, yeah, I suppose so.
[cpg cn=true]


[VOICE f="Sayo135"]
[OnName num="sayo"]
Well, I'm going to read, so you're going to stay there for a while.
[cpg cn=true]


If you're going to read, you won't be carrying anything other than a book on your back.
[cpg]

I was a little relieved to hear that. ......
[cpg]

[SE f=se038]
;//【ＳＥ】『食器を置く音』

[WAIT time=1000]

;**【ＣＧ】 ev_18_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=1500]

[OnName num="masato"]
"It's hot!　It's hot!
[cpg cn=true]


I was a little relieved to think that, but then I felt a hot sensation on my back, wondering what she had put there.
[cpg]

[OnName num="masato"]
Is it a teacup?
[cpg cn=true]


[VOICE f="Sayo136"]
[OnName num="sayo"]
No, it's a teapot. No, a teapot.
[cpg cn=true]


What was I thinking? It must be hot.
[cpg]

It's got to be hot. I'll get burned if I don't, but if it collapses, it'll be even worse...
[cpg]

So I waited for her to read gracefully and held on.
[cpg]

[OnName num="masato"]
I can't do it anymore.
[cpg cn=true]


[VOICE f="Sayo137"]
[OnName num="sayo"]
"Are you going to make me carry you?"
[cpg cn=true]


Between the pushing and pulling, my back felt like it was going to burn.
[cpg]

[window target=false]
[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=1]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BGM f="sl"]
[WAIT time=100]
;//【ＢＧ】『小夜の部屋』（夜）******************************************************

[window target=true]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo138"]
[OnName num="sayo"]
"Oh, my God, it's already late. Let's call it a day for now.
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

[OnName num="masato"]
"Thank you, thank you.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo139"]
[OnName num="sayo"]
"Well, now then..."
[cpg cn=true]


[OnName num="masato"]
Hee! It's over, isn't it? Are you going to do something?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo140"]
[OnName num="sayo"]
What are you scared of?
[cpg cn=true]


After what he did to me, I'm scared of my master's every move.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo141"]
[OnName num="sayo"]
I'm going to take a bath. It's night time, of course.
[cpg cn=true]


In my life, I take a bath at night. I see... it was an extension. Yeah, I'm glad. I'm not disappointed.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo142"]
[OnName num="sayo"]
"..............."
[cpg cn=true]


[OnName num="masato"]
"Master? Master?"
[cpg cn=true]


He said he was going to take a bath, but froze like a stone statue when he put his hand on the doorknob.
[cpg]

His appearance made me feel a little uneasy.
[cpg]

[OnName num="masato"]
"Oh, um..."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo143"]
[OnName num="sayo"]
"Come here."
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo144"]
[OnName num="sayo"]
Come with me to the bathhouse.
[cpg cn=true]


She was still standing there, but she turned her head and said, "What?
[cpg]

[OnName num="masato"]
"Why me?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo145"]
[OnName num="sayo"]
You can't listen to me.
[cpg cn=true]


[OnName num="masato"]
It's not that, I'm a man and my master is a woman and we can't be in the same bathroom.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo146"]
[OnName num="sayo"]
Come.
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]


I don't think so. Will he do something there again?
[cpg]

No...it's not right to think only negatively. Bathing with Master is a treat, isn't it?
[cpg]

Maybe the reward will be even greater than I imagined...
[cpg]



;//ＢＫ

;//エロティックな音楽

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=2100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="yuge.ui" method="in"  pos="3/5" time=1]

[BG f="b_08_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="h1"]
;//【ＢＧ】『豪華な風呂』（夜）******************************************************


;//ここでは画面一杯に湯気

;//小夜の喋り方は徐々にエロティックに。

[window target=true]


[FG f="CHA01_p3_04_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo147"]
[OnName num="sayo"]
Look, what are you afraid of?
[cpg cn=true]


[OnName num="masato"]
"Because, Master, I've never done anything like this before.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo148"]
[OnName num="sayo"]
It's your first time. It's all right... just take it slow and gentle and you'll be fine.
[cpg cn=true]


[OnName num="masato"]
Master, you're so... gentle.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo149"]
[OnName num="sayo"]
It's a very important part of my body and I don't want you to be too rough with it. I don't want you to be too rough with it. You have to teach me carefully.
[cpg cn=true]


[OnName num="masato"]
"Here, like this?"
[cpg cn=true]

[SE f=se086]
;//【ＳＥ】『体をこする』
[WAIT time=1000]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo150"]
[OnName num="sayo"]
Ow!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo151"]
[OnName num="sayo"]
Hey, no fingernails.
[cpg cn=true]


[OnName num="masato"]
I'm sorry!
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo152"]
[OnName num="sayo"]
It's a sensitive area for a girl. You have to be more careful.
[cpg cn=true]


[OnName num="masato"]
Yes!
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo153"]
[OnName num="sayo"]
Press your fingers against her belly.
[cpg cn=true]


[OnName num="masato"]
Like this?
[cpg cn=true]

[SE f=se086]
;//【ＳＥ】『体をこする』
[WAIT time=1000]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo154"]
[OnName num="sayo"]
Like that. Yeah, you're good... try to go deeper.
[cpg cn=true]


[OnName num="masato"]
I can't go any deeper.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo155"]
[OnName num="sayo"]
You'll have to go deeper to get all the dirt off. Now, don't be afraid...
[cpg cn=true]


[OnName num="masato"]
Okay.
[cpg cn=true]

[SE f=se086]
;//【ＳＥ】『体をこする』
[WAIT time=1000]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo156"]
[OnName num="sayo"]
...... Yeah, that's good.
[cpg cn=true]

;//ホワイトアウト
;//ここでは画面一杯の湯気が晴れる
;//ここから小夜のトーンやしゃべり方も戻り、お風呂でリラックスしてる子供らしさも。
;//髪を洗っているだけ


[window target=false]


[FO pos="3/5" time=3000]
[WAIT time=4000]


[window target=true]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo157"]
[OnName num="sayo"]
Ahhhhhh, there you go. It's so nice to have someone wash my hair.
[cpg cn=true]


[OnName num="masato"]
......
[cpg cn=true]


That's right. Yes, I knew that. Yeah, yeah.
[cpg]

She's not even naked... but she looks great in this kind of swimsuit.
[cpg]

I'm wearing a bathing suit myself, so it's kind of like a heated pool.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo158"]
[OnName num="sayo"]
"My right side itches."
[cpg cn=true]


[OnName num="masato"]
"Here?"
[cpg cn=true]

[SE f=se086]
;//【ＳＥ】『体をこする』
[WAIT time=1000]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo159"]
[OnName num="sayo"]
Lower. No, you're going too far! More... yeah, yeah. Right there. Oh, it's so good!
[cpg cn=true]


Well, whatever, it's good that Master is happy and it wasn't an additional masturbation.
[cpg]

;//＠
;//【ＢＧ】『豪華な風呂』（夜）



[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo160"]
[OnName num="sayo"]
"Hey, you're holding up."
[cpg cn=true]


[OnName num="masato"]
Excuse me!
[cpg cn=true]

[SE f=se086]
;//【ＳＥ】『体をこする』
[WAIT time=1000]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo161"]
[OnName num="sayo"]
You need to flush, then condition.
[cpg cn=true]


[OnName num="masato"]
Yes! I'm home!
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo162"]
[OnName num="sayo"]
Make sure you wash every inch of him.
[cpg cn=true]


[OnName num="masato"]
Every inch?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo163"]
[OnName num="sayo"]
Is there a problem?
[cpg cn=true]


[OnName num="masato"]
No, no, no. I don't like the idea of me washing every inch of my master's...
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo164"]
[OnName num="sayo"]
You don't like it?
[cpg cn=true]


[OnName num="masato"]
I don't mind!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo165"]
[OnName num="sayo"]
Then what?
[cpg cn=true]


[OnName num="masato"]
Aren't you ashamed of what you're doing?
[cpg cn=true]


[if exp={getFlagValue("pets_flag") == 1 }]
;//※選択の内容により下記のセリフが変化
;//------------------------------
;//飼われる（ペット状態）になっている場合

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo166"]
[OnName num="sayo"]
No. I don't care if my pet sees me in a bathing suit.
[cpg cn=true]

[endif]
;//------------------------------

[if exp={getFlagValue("gohome_flag") == 1 }]
;//仕える（下僕状態）になっている場合

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo167"]
[OnName num="sayo"]
No. It's nothing to be seen in a bathing suit by a servant.
[cpg cn=true]

[endif]


;//------------------------------



[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo168"]
[OnName num="sayo"]
But... you've never had a girlfriend before, so I guess it's too much for you.
[cpg cn=true]


[OnName num="masato"]
"！！！！！？？？？？"
[cpg cn=true]


I couldn't even reply properly as my mouth became like a chomping fish when I was suddenly hit with the right answer.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo169"]
[OnName num="sayo"]
"Did you think I didn't notice?"
[cpg cn=true]


[OnName num="masato"]
"Ah ...... ah ...... ah..."
[cpg cn=true]


He saw right through me.
[cpg]

No, it may be natural. But I wanted to avoid saying that as a mental barrier to maintain my composure.
[cpg]

[OnName num="masato"]
"Kaka...ka...ka........."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo170"]
[OnName num="sayo"]
"You?"
[cpg cn=true]


[OnName num="masato"]
I've at least had a girlfriend. ......
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo171"]
[OnName num="sayo"]
"......"
[cpg cn=true]


[OnName num="masato"]
"........."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo172"]
[OnName num="sayo"]
"............... Pfft."
[cpg cn=true]


[VOICE f="Sayo173"]
[OnName num="sayo"]
Ha-ha-ha. Are you going to make excuses here? Hahaha, that's funny. Couscous."
[cpg cn=true]


He laughed loudly.
[cpg]

[VOICE f="Sayo174"]
[OnName num="sayo"]
My stomach hurt. I'm so sick to my stomach, and you're lying to me like that.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


It's a lie, and they know it, but I want to insist that it's not a lie in this situation. If I don't, I'm going to break down from embarrassment.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo175"]
[OnName num="sayo"]
But..."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo176"]
[OnName num="sayo"]
'You're making it even more worthwhile to tease me.
[cpg cn=true]


The master grinned and said so.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo177"]
[OnName num="sayo"]
Now that you've done your hair you can wash your body.
[cpg cn=true]


[OnName num="masato"]
"Oh, no..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo178"]
[OnName num="sayo"]
If you've ever had a girlfriend, you've got a little patience. Come on, wash up.
[cpg cn=true]


[OnName num="masato"]
"Aaaaahhh..."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo179"]
[OnName num="sayo"]
"Gently and carefully."
[cpg cn=true]


[OnName num="masato"]
"Aaahhhhh!
[cpg cn=true]


[VOICE f="Sayo180"]
[OnName num="sayo"]
Wash it with a sponge. If your hand touches it even a little bit, ...... you know what will happen.
[cpg cn=true]


[OnName num="masato"]
No, no, no, no, no!
[cpg cn=true]


It's alive, it's alive. If I touch it, it's going to kill me. It's a living hell.
[cpg]

Please help me, someone.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

;//●ＣＧ（雅人＆小夜・ご主人様と一緒にお風呂に入る。互いに水着：豪華なお風呂）ev_04

[SE f=se080]
;//【ＳＥ】『風呂入る』

;**【ＣＧ】 ev_04_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo181"]
[OnName num="sayo"]
"Huh huh. My fatigue is melting away in the hot water.
[cpg cn=true]


[OnName num="masato"]
"That's good to hear. But this position...
[cpg cn=true]


[VOICE f="Sayo182"]
[OnName num="sayo"]
"If I go in normally, I'll sink. It's inconvenient when you're small.
[cpg cn=true]


It's true that with a body the size of Master's, if his buttocks touch the bottom of the bathtub, his face might sink into the water.
[cpg]

[OnName num="masato"]
"Oh, I see. Then why don't you build a new bathtub for your master? You're a rich man."
[cpg cn=true]

;**【ＣＧ】 ev_04_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo183"]
[OnName num="sayo"]
I don't want to do that because I feel like I'm losing.
[cpg cn=true]


You're a selfish person.
[cpg]

;**【ＣＧ】 ev_04_b ***********************
[CG id=3 index=2 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo184"]
[OnName num="sayo"]
And now that you've got the right chair, you won't need it.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


You know, it makes me happy when you smile at me like that.
[cpg]

[OnName num="masato"]
It's a good thing. Well, it's a cheap chair.
[cpg cn=true]

;**【ＣＧ】 ev_04_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo185"]
[OnName num="sayo"]
"Xu. Price is not the only thing. There are some things that are called cheap that are just as good as the best.
[cpg cn=true]


Master, are you talking about me?
[cpg]

I was tempted to ask him to confirm this, but I just about managed to keep my mouth shut.
[cpg]

It sounded like something I shouldn't ask...or better yet, something I shouldn't ask.
[cpg]

The master laid his back against my chest again and relaxed.
[cpg]

The fact that he can lean against me like this makes me wonder if it's because he's forgiven me a little.
[cpg]

;**【ＣＧ】 ev_04_b ***********************
[CG id=3 index=2 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo186"]
[OnName num="sayo"]
You have a difficult constitution, by the way. You seem to have more trouble than I do.
[cpg cn=true]


I replied with a wince at the topic he brought up.
[cpg]

[OnName num="masato"]
What are you talking about?
[cpg cn=true]


[VOICE f="Sayo187"]
[OnName num="sayo"]
You like little girls, don't you?
[cpg cn=true]


[OnName num="masato"]
"Nuh-uh."
[cpg cn=true]


Master grinned and pointed out my weak point.
[cpg]

;**【ＣＧ】 ev_04_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo188"]
[OnName num="sayo"]
You've already been found out, so just tell us.
[cpg cn=true]


If you already know, you don't have to go through the trouble of doing this. But she's doing it for fun.
[cpg]

I guess she wants me to say it.
[cpg]

[OnName num="masato"]
"Ha, ha, ha... what's the matter with you?
[cpg cn=true]


My petty pride made me reply like that.
[cpg]

[VOICE f="Sayo189"]
[OnName num="sayo"]
"........."
[cpg cn=true]


Her eyes narrowed slightly.
[cpg]

[SE f=se081]
;//【ＳＥ】『風呂の中移動』

;**【ＣＧ】 ev_04_b ***********************
[CG id=3 index=2 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo190"]
[OnName num="sayo"]
I'm sure you'll be happy to hear that.
[cpg cn=true]


[OnName num="masato"]
"Yes!
[cpg cn=true]


I'm sure you'll be able to understand why I'm so happy. This is not good.
[cpg]

[OnName num="masato"]
No, no, no! No, you can't, master!
[cpg cn=true]


[VOICE f="Sayo191"]
[OnName num="sayo"]
There's no need to run away. Here, here.
[cpg cn=true]


Slither...slither...slither...
[cpg]

A moderately fleshy body rubs up against me, emphasizing my lines like a child.
[cpg]

I'm happy when she does this, but on the other hand, I can never touch her, so it's hard to keep her alive.
[cpg]



;//ＢＫ


[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

;//レターボックスin
[FACE method="in" pos="4/7"]

[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_08_4_up.ui" time=1000]


;//【ＢＧ】『豪華な風呂』（夜）******************************************************

[SE f=se082]
;//【ＳＥ】『風呂遊ぶ』

[window target=true]

[OnName num="masato"]
It's such a pity! I can't believe a girl would do this to me!
[cpg cn=true]



[FG f="CHA01_p3_04_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo192"]
[OnName num="sayo"]
It's okay, you're happy too, aren't you?
[cpg cn=true]


[OnName num="masato"]
It's... it is, but...
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo193"]
[OnName num="sayo"]
"You don't deny it. Ha-ha-ha.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo194"]
[OnName num="sayo"]
I'll give you plenty to do, and don't think you'll get away with it.
[cpg cn=true]




;//ＢＫ


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=2100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=1]
[WAIT time=200]
;//レターボックスout
[FACE method="out" pos="4/7"]

[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=100]


[transition target={true} rule="hidari.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hidari.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


;//【ＢＧ】『豪邸、廊下』（夜）******************************************************


[SE f=se082]
;//【ＳＥ】『お湯が跳ねる音』バシャバシャ

;//＠ep003
;//[SE f=se000]
;//【ＳＥ】『楽しそうな様子』

[OnName num="butler_A"]
......
[cpg cn=true]


[OnName num="maid_A"]
......
[cpg]


;//下記のセリフは同時に表示して下さい

[OnName num="butlerA&maidA"]

You look like you're having fun, young lady.
You look like you're having fun, young lady.
[cpg cn=true]


;//ＢＫ

;//少し時間を置く演出


[window target=false]

[STOPBGM]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1500]
[WAIT time=2000]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]


[BG f="b_07_3.ui" time=1000]

[WAIT time=1500]

[SE f=se083]
;//【ＳＥ】『フクロウ』

[BG f="b_07_4.ui" time=1000]

[WAIT time=3000]


;//【ＢＧ】『空』（夜）******************************************************



[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[window target=true]

[WAIT time=100]

[BGM f="sl"]
[WAIT time=100]
;//【ＢＧ】『豪邸、廊下』（夜）******************************************************

[SE f=se016]
;//【ＳＥ】『扉を開ける』

[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo195"]
[OnName num="sayo"]
Mmm. That was a nice bath.
[cpg cn=true]


[OnName num="butler"]
Miss, would you like a drink?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo196"]
[OnName num="sayo"]
Thank you. I'll have one.
[cpg cn=true]


[OnName num="butler"]
You look like you're having a great time.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo197"]
[OnName num="sayo"]
Cousin. I forgot myself, and I felt like a child all over again.
[cpg cn=true]


[OnName num="butler"]
You're not old enough to be a child...
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo198"]
[OnName num="sayo"]
Tanaka, what is it?
[cpg cn=true]


[OnName num="butler"]
No, no, no. Just be careful not to get too hot.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo199"]
[OnName num="sayo"]
Yes. Let's be careful.
[cpg cn=true]

[SE f=se005]
;//【ＳＥ】『歩く』

[move from="2/3" to="5/3" ease="easeInOutSine" time=2000]

[WAIT time=2000]


[OnName num="butler"]
I'm glad he came. I'm glad he's here.
[cpg cn=true]


;//様子を見に浴場へ移動する田中

[SE f=se016]
;//【ＳＥ】『扉を開ける』
[BG f="b_08_4.ui" time=1000]



[OnName num="butler"]
Masato-dono, thank you for your hard work. Thank you for your hard work, Masato-dono. I'm glad to see that your daughter is happy. ......
[cpg cn=true]


[BG f="b_08_4_up.ui" time=1000]

[WAIT time=1000]

;//レターボックスin
[FACE method="feadin" pos="4/7"]

[WAIT time=1500]

[SE f=se084]
;//【ＳＥ】『チーン』

[WAIT time=2000]

;//※もし可能ならカットインが欲しいです。ぷかーっと湯船に浮かんでいる雅人。

[OnName num="butler"]
Masato-dono!　You will catch a cold if you sleep in the bath.
[cpg cn=true]


At this depth, it's not a cold, it's probably death. ......
[cpg]



;//ＢＫ


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]

[window target=true]

;//【ＢＧ】『小夜の部屋』（夜）******************************************************

[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo200"]
[OnName num="sayo"]
I think I'm going to sleep well today. Have a good night."
[cpg cn=true]


[OnName num="brionac"]
"Woof."
[cpg cn=true]



[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=2000]
[WAIT time=3000]
[free time=1]
;//レターボックスout
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="ep004.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
