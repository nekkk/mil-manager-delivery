*start

;#################################################
*Ep009|M saw it.
;#################################################

[SCENE id=9]


[stflag jump_scene=0]
[window target=false]


;//レターボックス初期召喚
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]

[WAIT time=1000]
[STOPBGM]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]

[WAIT time=1500]

[BGM f="sl"]
;//【ＢＧ】『小夜の部屋』（夕方）******************************************************


[window target=true]


[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sayo380"]
[OnName num="sayo"]
"Do I really have to do this?"
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


The young lady's sorrowful expression and sad tone made it seem as if the sun had gone down even more in the evening.
[cpg]

[OnName num="butler"]
I know how you feel, young lady. It's really hard for me too.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo381"]
[OnName num="sayo"]
"Then..."
[cpg cn=true]


[OnName num="butler"]
I'm sorry. I'm sorry, but the Master has given me orders.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo382"]
[OnName num="sayo"]
"Shun..."
[cpg cn=true]


Master is so cute when he says onomatopoeic sounds of depression.
[cpg]

It's not!
[cpg]

What should I say to her as her servant?
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo383"]
[OnName num="sayo"]
"Huh... ...... I understand..."
[cpg cn=true]


[OnName num="butler"]
"Well then, let's start with this."
[cpg cn=true]



[SE f=se036]
;//【ＳＥ】『』ガラガラガラ
;//※レストランとかホテルで料理持ってくるやつ。名前が分からない。

[WAIT time=1000]


[OnName num="masato"]
"...... wine?"
[cpg cn=true]


Wine bottles were being brought into the room one after another.
[cpg]

It's not just wine, but brandy, whiskey, sake, and many other bottles.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo384"]
[OnName num="sayo"]
"Huh.... I came back from the school and practiced, practiced, practiced... and to top it all off, I got this today?
[cpg cn=true]


[OnName num="butler"]
"I understand how you feel, young lady. But your husband's...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo385"]
[OnName num="sayo"]
"Your father's orders, right? I understand.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo386"]
[OnName num="sayo"]
I know, but..."
[cpg cn=true]


Even with her unhappy face, the other maids and butlers made their preparations quickly.
[cpg]

It was so fast that it was ready while Mr. Tanaka was appeasing her.
[cpg]

[OnName num="masato"]
"Um, Tanaka-san... what exactly is your master doing?"
[cpg cn=true]


[OnName num="butler"]
"Tasting. To put it simply, it's a way to train your palate to be able to distinguish between the best and the worst.
[cpg cn=true]


[OnName num="masato"]
Oh, so you do that. Rich people do that.
[cpg cn=true]


[OnName num="butler"]
As the daughter of the Goshanagi family, there are many things that are required of me.
[cpg cn=true]


[OnName num="masato"]
But you are very reluctant to do so. Why is that?
[cpg cn=true]


[OnName num="butler"]
...... The young lady prefers cocoa with lots of sugar and milk.
[cpg cn=true]


[OnName num="masato"]
"I see! So she doesn't like alcohol because her taste buds are childish!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo387"]
[OnName num="sayo"]
Squeak.
[cpg cn=true]


[OnName num="masato"]
Ow!
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo388"]
[OnName num="sayo"]
I thought I just heard something that made me even more irritated, was it my imagination?
[cpg cn=true]


[OnName num="masato"]
I didn't say anything! Yes! Yes, it was my imagination!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo389"]
[OnName num="sayo"]
"Take your pick. A bottle of any of these things is worth a month's salary to you, so I'd say you deserve to die.
[cpg cn=true]


[OnName num="masato"]
Please don't bludgeon me to death with such expensive stuff! I'm a man whose only value is cheap liquor from the supermarket!
[cpg cn=true]


[OnName num="butler"]
"My Lady."
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo390"]
[OnName num="sayo"]
"......"
[cpg cn=true]


Putting down the bottle she had already swung up, the master sat back down in his chair with a thud.
[cpg]

It was the first time I'd ever seen her do that, and I could tell she hated it that much.
[cpg]

[OnName num="butler"]
'You don't have to drink it, you can just moisten it as usual.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo391"]
[OnName num="sayo"]
I know."
[cpg cn=true]


As if he had made up his mind, Master took a moment to catch his breath and then picked up the glass from which the proper amount had been poured.
[cpg]

He put a small amount in his mouth and rolled it around on his tongue, tasting it. Maybe.
[cpg]

[FG f="CHA01_p4_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo392"]
[OnName num="sayo"]
...... Chateau. Chateau Mouton Rothschild."
[cpg cn=true]


[OnName num="butler"]
Yes, that's right."
[cpg cn=true]



[SE f=se049]
;//【ＳＥ】『グラスの音』カチャカチャ

And so, one after another, the master guessed the brand of alcohol.
[cpg]

She doesn't like alcohol, so she doesn't seem to swallow. She doesn't swallow and seems to be judging it by the taste and aroma on her tongue...amazing.
[cpg]

[OnName num="masato"]
(I don't know what's going on.)"
[cpg cn=true]


I'm sure he can only say 'good' and 'bad' when he's given a drink.
[cpg]

I don't know if upper class people need this kind of ability or not, but it's beautiful and cool to see a master who can do it without a hitch.
[cpg]

This is what I mean when I say that I can't help but admire him.
[cpg]

I suddenly felt happy that I was serving such a person.
[cpg]
[window target=false]

[STOPBGM]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

[window target=true]


--A few hours later...
[cpg]

[window target=false]

[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]

[BGM f="sl"]
;//【ＢＧ】『小夜の部屋』（夜）******************************************************

[SE f=se052]
;//【ＳＥ】『瓶とか倒す音』ガタガタガチャンガタガタガチャン

[window target=true]


[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sayo393"]
[OnName num="sayo"]
I can't drink anymore...hiccup..."
[cpg cn=true]


[OnName num="butler"]
"......"
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


A few hours after we started tasting, we found ourselves in a serious situation.
[cpg]

[OnName num="masato"]
"Um, Mr. Tanaka."
[cpg cn=true]


[OnName num="butler"]
Yes.
[cpg cn=true]


[OnName num="masato"]
Your husband looks drunk to me.
[cpg cn=true]


[OnName num="butler"]
He's definitely drunk.
[cpg cn=true]


[OnName num="masato"]
You're not much of a drinker, are you?
[cpg cn=true]


[OnName num="butler"]
He can get drunk just by smelling it.
[cpg cn=true]


I don't think I should let such a person do this.
[cpg]

You can tell by looking at this that Master is completely drunk.
[cpg]

I've had it in my mouth many times before, but I haven't drunk it, but if I keep repeating it like that, I'm sure he'll get drunk.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo394"]
[OnName num="sayo"]
I can't do it... I can't do it anymore...
[cpg cn=true]


[OnName num="masato"]
"I can't do it!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo395"]
[OnName num="sayo"]
"Tanaka!"
[cpg cn=true]


(This is the type of drunkenness.) "Tanaka!" My shoulders trembled at the loud voice and the name.
[cpg]

[OnName num="butler"]
Yes, what is it?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo396"]
[OnName num="sayo"]
"Are you a ...... cat?"
[cpg cn=true]


[OnName num="butler"]
Yes.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo397"]
[OnName num="sayo"]
Are you a cat? Are you a cat? Are you a cat?
[cpg cn=true]


[OnName num="butler"]
"......... I'm a dog, I guess..."
[cpg cn=true]


And there it is! The drunk's unintelligible tangent!
[cpg]

Tanaka-san is desperately trying to answer the question as if he were a butler! I can't help but pity him, he's clearly in some kind of trouble!
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo398"]
[OnName num="sayo"]
I can't believe it. A dog? ......
[cpg cn=true]


[OnName num="butler"]
"I apologize for not meeting your expectations."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo399"]
[OnName num="sayo"]
"Where's the cat? Do you have a cat?
[cpg cn=true]


[OnName num="masato"]
Mr. Tanaka... why the cat?
[cpg cn=true]


[OnName num="butler"]
By the way, your daughter said she wants to get a cat soon. Is that why?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo400"]
[OnName num="sayo"]
Where's the cat? Don't you have a cat? Cat cat cat cat! Cat, cat, cat, cat, kitty, kitty, kitty!
[cpg cn=true]



[SE f=se051]
;//【ＳＥ】『テーブルを叩く』バンバン

[WAIT time=2000]

[SE f=se053]
;//【ＳＥ】『暴れる』

Oh, she's raging...her master is raging while calling her cat. It's an unbelievable sight that you can't imagine from her usual appearance.
[cpg]

[OnName num="masato"]
"Tanaka-san... what are the pets in this house..."
[cpg cn=true]


[OnName num="butler"]
"Yes, only Brunark. And the other one... the other one.
[cpg cn=true]


[OnName num="masato"]
"Don't look at me! You don't have to be blurry at a time like this!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo401"]
[OnName num="sayo"]
Don't look at me!
[cpg cn=true]


[SE f=se053]
;//【ＳＥ】『暴れる』

[WAIT time=2500]

[SE f=se052]
;//【ＳＥ】『物を投げる』


[OnName num="butler"]
Masato-dono, please do something.
[cpg cn=true]


[OnName num="masato"]
You're a useless butler at a critical moment!
[cpg cn=true]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

;//急に無音になる

[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo402"]
[OnName num="sayo"]
......... Huh?
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[VOICE f="Sayo403"]
[OnName num="sayo"]
Cat... is not here? No cat, no cat... no cat, no cat, no cat...
[cpg cn=true]


Now he's crying!
[cpg]

[OnName num="butler"]
"Masato-dono, please do something immediately, immediately!
[cpg cn=true]


[OnName num="masato"]
"No, I can't do it! Please use your financial resources to get me a cat!
[cpg cn=true]


[OnName num="butler"]
It's like a cartoon.
[cpg cn=true]


[OnName num="masato"]
This development is cartoonish enough!
[cpg cn=true]


[VOICE f="Sayo404"]
[OnName num="sayo"]
"Wha... wha... wha... wha..."
[cpg cn=true]


[OnName num="butler"]
Oh, come on, come on! Don't make me shed a tear for you, young lady!
[cpg cn=true]


[OnName num="butlerA&maidA"]
Yes, yes.
[cpg cn=true]


[OnName num="masato"]
That's it.
[cpg cn=true]


But even though it's because of the alcohol, I can't just let my master cry like this.
[cpg]

[VOICE f="Sayo405"]
[OnName num="sayo"]
"Yeah, yeah, yeah, hiccup, hiccup..."
[cpg cn=true]


[OnName num="butler"]
"Miss, I have a cat. Please stop crying.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo406"]
[OnName num="sayo"]
"Huh... is there a cat? Is there a cat?
[cpg cn=true]


[OnName num="masato"]
"Where the hell is the cat?"
[cpg cn=true]


And then.
[cpg]

[OnName num="butler"]
"...... glanced at me."
[cpg cn=true]


Mr. Tanaka winked at me with a bang.
[cpg]

[OnName num="masato"]
(Is that me? !)
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo407"]
[OnName num="sayo"]
"...... are you a cat?"
[cpg cn=true]


I was forced to make a decision on what to do.
[cpg]

[OnName num="masato"]
"....................."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo408"]
[OnName num="sayo"]
"It's a cat!"
[cpg cn=true]


[FG f="CHA01_p5_02_a.ui" method="change_2"  pos="2/3" time=800]

[SE f=se015]
;//【ＳＥ】『飛びついてくる』ガバッ

[BG f="b_04_4_up.ui" time=800]

;//レターボックスin
[FACE method="slidein" pos="4/7"]

[WAIT time=1500]


[OnName num="masato"]
Whoa!
[cpg cn=true]


[VOICE f="Sayo409"]
[OnName num="sayo"]
"Fluffy, fluffy, fluffy..."
[cpg cn=true]


She seemed to think I was a cat and suddenly started hugging me and petting my head.
[cpg]

I'm glad I'm in this situation, but...what should I do from here?
[cpg]

I moved my gaze toward Mr. Tanaka as if asking for help.
[cpg]

[OnName num="butler"]
"Good luck."
[cpg cn=true]

[SE f=se042]
;//【ＳＥ】『早足』

[OnName num="masato"]
"You heartless bastard!"
[cpg cn=true]



The butlers and maids, including Mr. Tanaka, quickly left the room.
[cpg]

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[FACE method="out" pos="4/7"]

;//ＢＫ

;//●ＣＧ（雅人＆小夜・泥酔した小夜が甘えさせてくれる：小夜の部屋）ev_07

[SE f=se078]
;//【ＳＥ】『衣擦れ』
[BGM f="h1"]

;**【ＣＧ】 ev_07_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo410"]
[OnName num="sayo"]
It's so warm and fluffy..."
[cpg cn=true]


As long as they think I'm a cat, I have to act like one.
[cpg]

I can't make my body smaller, so I at least try to lie down.
[cpg]

I can't make my body smaller, so I'll at least try to lie down. I'll aim to be at a height where I'm purring like a cat from the master's point of view, or something like that...
[cpg]

;**【ＣＧ】 ev_07_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo411"]
[OnName num="sayo"]
"This cat doesn't purr... does it hate me?"
[cpg cn=true]


And then he said something quite annoying.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo412"]
[OnName num="sayo"]
Then he said something quite annoying: "Cat, purr, meow... ...... meow, meow ah~!"
[cpg cn=true]


The situation has become quite difficult. Even though no one is watching...
[cpg]

[OnName num="masato"]
"...... meow."
[cpg cn=true]

;**【ＣＧ】 ev_07_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo413"]
[OnName num="sayo"]
"Hmmm?　What does he want?　I wonder if she wants me to pet her..."
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

Master is so happy. I wanted to disappear, but at the same time I felt like I was getting some kind of benefit.
[cpg]

[VOICE f="Sayo414"]
[OnName num="sayo"]
"Cat, purr some more!
[cpg cn=true]


[OnName num="masato"]
"Meow, meow."
[cpg cn=true]


It's disgusting... but I guess it's okay if it's for my master.
[cpg]

I thought about it and decided to pamper her a little.
[cpg]

[VOICE f="Sayo415"]
[OnName num="sayo"]
I thought to myself, "Hmmm... what?　This cat's a little heavy...?"
[cpg cn=true]


Oh no, no, no. I imitated a cat to hide it.
[cpg]

[OnName num="masato"]
"Meow!"
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

Every time I do this, she pets me, which makes me want to spoil her even more.
[cpg]


;//ＢＫ

[STOPBGM]

[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1500]


[BGM f="sl"]
;//【ＢＧ】『小夜の部屋』（夜）******************************************************

[window target=true]


A few minutes later... when I was about to sober up, I finally woke up.
[cpg]

[SE f=se078]
;//【ＳＥ】『衣擦れ』


[OnName num="masato"]
"Gee, Master..."
[cpg cn=true]


[VOICE f="Sayo416"]
[OnName num="sayo"]
"Hmmm..."
[cpg cn=true]


When I calmly looked at the current situation, I did something that I couldn't look back on.
[cpg]

[OnName num="masato"]
I've done it.
[cpg cn=true]


It's too late to feel self-loathing now.
[cpg]

[OnName num="masato"]
"Master... I'm really, really sorry."
[cpg cn=true]


[VOICE f="Sayo417"]
[OnName num="sayo"]
"Uu~n~n~...neko hin~ ......~...mmmm..."
[cpg cn=true]


[OnName num="masato"]
He's sleeping...
[cpg cn=true]


It's no use apologizing. Besides, the Master can't hear me now.
[cpg]

I think she's asleep, so I'll apologize to her tomorrow. Whatever happens, it's my fault.
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

Anyway, I can't sleep here, I'll catch a cold. I have to move him...
[cpg]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

;//●ＣＧ（雅人＆小夜・泥酔してお漏らしをする小夜の便器になる：小夜の部屋）ev_08
;//※ここではまだ寝ているだけ

[WAIT time=2000]

[SE f=se015]
;//【ＳＥ】『ベッドに倒れこむ』


[BGM f="h1"]

;**【ＣＧ】 ev_08_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo418"]
[OnName num="sayo"]
"Soooooooooo... Munchy."
[cpg cn=true]


[OnName num="masato"]
"Your sleeping face is so cute."
[cpg cn=true]


I still can't believe that such a cute person is my master.
[cpg]

Maybe I'm a lucky guy.
[cpg]

[OnName num="masato"]
"Excuse me...I'll take off your clothes. I'll just let you change."
[cpg cn=true]


In a way, there was nothing to be afraid of, since I had already been rude.
[cpg]


[SE f=se013]
;//【ＳＥ】『服を脱がせる』

;**【ＣＧ】 ev_07_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo419"]
[OnName num="sayo"]
"Mmmm...soooooo..."
[cpg cn=true]


[OnName num="masato"]
"...!"
[cpg cn=true]


I was in the middle of taking off my clothes. I've even taken a bath with her before, so I've seen her before, but seeing her like this, it's different...
[cpg]

[OnName num="masato"]
"No! No! No, no, no! What are you thinking?
[cpg cn=true]


What more are you going to do?
[cpg]

What more is she going to do? I have to reason with her and change her into her pajamas.
[cpg]

I'll ask Mr. Tanaka to bring me a change of clothes.
[cpg]

But at that moment ......
[cpg]

[STOPBGM]

[BG f="b_04_4_up.ui" time=500]

;//レターボックスin
[FACE method="feadin" pos="4/7"]

;//【ＢＧ】『小夜の部屋』（夜）******************************************************

[SE f=se015]
;//【ＳＥ】『起き上がる』ガバッ

[WAIT time=500]

[VOICE f="Sayo420"]
[OnName num="sayo"]
"..............."
[cpg cn=true]


[OnName num="masato"]
"What?
[cpg cn=true]

As if he were a zombie, Master raised only his upper body.
[cpg]

[BGM f="h1"]

[OnName num="masato"]
Ah, ah... master, are you awake?
[cpg cn=true]


I get teary-eyed, thinking that nothing has to happen at this time.
[cpg]

[VOICE f="Sayo421"]
[OnName num="sayo"]
"......... Le..."
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[VOICE f="Sayo422"]
[OnName num="sayo"]
"......re..."
[cpg cn=true]


[OnName num="masato"]
"Yes?"
[cpg cn=true]


[VOICE f="Sayo423"]
[OnName num="sayo"]
"...... toilet."
[cpg cn=true]


[OnName num="masato"]
......... Oh, yeah?
[cpg cn=true]


It seems that the master is not completely awake, but is still asleep.
[cpg]

If you look closely, you can see that he's still sleepy-eyed.
[cpg]

[VOICE f="Sayo424"]
[OnName num="sayo"]
"Toilet."
[cpg cn=true]


[OnName num="masato"]
"Yes, yes... then, um... this way..."
[cpg cn=true]


I tried to lend him my shoulder to lead the way, as I was sure he couldn't walk on his own.
[cpg]


[SE f=se078]
;//【ＳＥ】『衣擦れ』
[STOPBGM]

[OnName num="masato"]
I'm sure he can't walk alone, so I lent him my shoulder to lead the way. "Hey, Master!
[cpg cn=true]


[VOICE f="Sayo425"]
[OnName num="sayo"]
"Mnya...mnya......, mnya, mnya..."
[cpg cn=true]

[SE f=se014]
;//【ＳＥ】『衝撃』

[BGM f="co"]

[OnName num="masato"]
"He's asleep! What about the bathroom? What are you going to do?
[cpg cn=true]


He collapsed and fell asleep again. Oh no, this is a big deal.
[cpg]

[OnName num="masato"]
"Master! Please wake up! You want to go to the bathroom, don't you?
[cpg cn=true]


[VOICE f="Sayo426"]
[OnName num="sayo"]
"Ggh...ggh........."
[cpg cn=true]


It's not good, it's not good... I want to go to the bathroom, but I'm asleep, that's a big problem.
[cpg]

I'm sure everyone has experienced this as a child, but the pattern is one where you dream about water and in the morning you have a map of the world.
[cpg]

[OnName num="masato"]
"Master! Master! Master! Wake up, please! Let's go to the bathroom! Just the toilet! Then go to sleep!"
[cpg cn=true]

[STOPBGM]
;//ＢＫ

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

;//【ＢＧ】『小夜の部屋』（夜）******************************************************

[BGM f="se"]

[window target=true]

[OnName num="masato"]
"Okay... I'm done.
[cpg cn=true]


The master, who had neatly changed into the pajamas that Tanaka-san had brought for him, was breathing a lovely sleep in his bed.
[cpg]

A lot has happened, but this is the end for now.
[cpg]

[OnName num="masato"]
"...... Good night, Master."
[cpg cn=true]


That was the last thing I said, and I turned off the lights and left the room.
[cpg]

[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ＢＫ

;//レターボックスout
[FACE method="out" pos="4/7"]


[SE f=se017]
;//【ＳＥ】『扉を閉める』

[BG f="b_01_4.ui" time=1000]
[WAIT time=1000]


;//【ＢＧ】『豪邸、廊下』（夜）******************************************************

[window target=true]


When I went out into the hallway, Tanaka-san, the other butlers, and the maids who had brought me pajamas were also waiting.
[cpg]

[OnName num="butler"]
Are you finished?
[cpg cn=true]


[OnName num="masato"]
"Yes."
[cpg cn=true]


When I said that, they all looked relieved. Tonight was a tough night in many ways.
[cpg]

[OnName num="butler"]
Masato-dono, thank you for your hard work.
[cpg cn=true]


[OnName num="masato"]
"No, not really. Thank you all for your hard work.
[cpg cn=true]


For a moment, I wondered what was going to happen, but then I realized that everyone had been here for a long time because they were worried about me, and I was glad.
[cpg]

[OnName num="masato"]
But I'll never forget that you all ran away without me.
[cpg cn=true]


They all looked unhappy.
[cpg]

I was angry at the time, but I'm not angry anymore. But I won't forget.
[cpg]

[OnName num="butler"]
"Well, well, Masato-dono... don't say that."
[cpg cn=true]

[STOPBGM]

;//レターボックスin
[FACE method="feadin" pos="4/7"]
[BG f="b_01_4_up.ui" time=1000]
[WAIT time=1500]

As he said this, Mr. Tanaka approached me and whispered... in a slightly low tone.
[cpg]

[OnName num="butler"]
"We'll keep what we saw tonight to ourselves.
[cpg cn=true]

[BGM f="co"]

[SE f=se014]
;//【ＳＥ】『衝撃』


[OnName num="masato"]
What are you talking about?
[cpg cn=true]


I knew immediately what he was talking about, as I knew what he was talking about.
[cpg]

[OnName num="masato"]
"What? What? You can't be serious...look at ......."
[cpg cn=true]


[OnName num="butler"]
"We are all impressed with your work ethic, Masato-dono."
[cpg cn=true]


[OnName num="masato"]
What, what, what...?
[cpg cn=true]


[OnName num="butler_A"]
I would like to report this to you, Miss, but it is the duty and honor of our servants to support our masters in the shadows. We do not do such tactless things.
[cpg cn=true]


[OnName num="maid_B"]
"Yes, yes. Of course not.
[cpg cn=true]


[OnName num="masato"]
"Ah, ah... ah... ah..."
[cpg cn=true]


I'm sure of it. The whole thing was being watched. Especially the part where she pretended to be a cat and was being sweet...
[cpg]

It's not just fire coming out of my face, it's fire coming out of every pore in my body.
[cpg]

[OnName num="maid_A"]
He was a wonderful servant. I want to learn from you, Masato-san."
[cpg cn=true]

Even the young maid who swept her gaze in bewilderment and met my eyes said such a thing with a smiling face.
[cpg]

[OnName num="masato"]
"Ugh...!"
[cpg cn=true]


That cottony, tightening feeling, give me a break!
[cpg]

There was only one course of action I could take.
[cpg]

[OnName num="masato"]
I can't believe it. That's right, isn't it! Today, we got out of a tight spot with the help of everyone here! It was an emergency situation, so there were a lot of things that happened, but..."
[cpg cn=true]

[OnName num="masato"]
It was an emergency, so there were a lot of things that happened, but..." "You're too small to be worrying about such things forever! Yes! That's right! That kind of person is not worthy of serving the master!
[cpg cn=true]



[SE f=se055]
;//【ＳＥ】『拍手』


""Wow!""
[cpg]

Crackle, crackle. For some reason, there was a round of applause along with cheers. Was I making a speech or something?
[cpg]


[OnName num="masato"]
Was I making a speech? "........." I thought. Well, let's let bygones be bygones and make today a good memory!　Or rather, let it go down the drain with alcohol..."
[cpg cn=true]

[STOPBGM]

[SE f=se084]
;//【ＳＥ】『チーン』

[OnName num="butler"]
"......"
[cpg cn=true]


[OnName num="butler_A"]
"......"
[cpg cn=true]


[OnName num="maid_A"]
......
[cpg cn=true]


[OnName num="maid_B"]
"......"
[cpg cn=true]


[OnName num="maid_C"]
"......"
[cpg cn=true]


[OnName num="masato"]
"Oh, what?"
[cpg cn=true]



[SE f=se056]
;//【ＳＥ】『手を叩く』パンパン

;//レターボックスout
[FACE method="feadout" pos="4/7"]
[BG f="b_01_4.ui" time=1000]
[WAIT time=1500]

[BGM f="sl"]


[OnName num="butler"]
Well, let's get the rest of our work done and get some rest.
[cpg cn=true]


[OnName num="maid_A"]
Okay.
[cpg cn=true]


[OnName num="maid_B"]
Right.
[cpg cn=true]


[SE f=se005]
;//【ＳＥ】『皆で歩いていく』

[WAIT time=1500]

[OnName num="masato"]
......
[cpg cn=true]


[OnName num="butler"]
Masato-dono, please take the rest of the day off. I'll take care of the rest.
[cpg cn=true]


[OnName num="masato"]
Yes, thank you.
[cpg cn=true]


[OnName num="butler"]
"Then, have a good night."
[cpg cn=true]


[OnName num="masato"]
"Good night.
[cpg cn=true]


[SE f=se005]
;//【ＳＥ】『歩く』コツコツ

I don't know what to do with this feeling.
[cpg]

I went back to my room and immediately wrapped myself in my futon and went to sleep.
[cpg]


;//ＢＫ

[STOPBGM]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;//レターボックスout
[FACE method="out" pos="4/7"]

[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="d1"]
;//【ＢＧ】『豪邸、ダイニング』（朝）******************************************************

[SE f=se037]
;//【ＳＥ】『食器の音』カチャカチャ

[window target=true]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo427"]
[OnName num="sayo"]
"Good night."
[cpg cn=true]


[OnName num="masato"]
"Master, you seem to be in a very good mood this morning."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo428"]
[OnName num="sayo"]
Yes, I am. I had a good dream last night.
[cpg cn=true]


Cringe.
[cpg]

[OnName num="butler"]
"A dream? What kind of dream?
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo429"]
[OnName num="sayo"]
"Hmm. I dreamed that I was playing with a cute cat. It was fun!
[cpg cn=true]


Master was talking happily, but I was not in the mood.
[cpg]

[OnName num="the_master"]
It's a dream about playing with cats, Saya is still a child.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo430"]
[OnName num="sayo"]
"Oh, that's terrible, father. You treat me like a child.
[cpg cn=true]


[OnName num="the_master"]
Sorry, sorry.
[cpg cn=true]


[OnName num="butler"]
However, such dreams may turn out to be true.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo431"]
[OnName num="sayo"]
What?
[cpg cn=true]


[OnName num="the_master"]
I think he might be around. Tanaka.
[cpg cn=true]


[OnName num="butler"]
Yes, sir. Sir.
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo432"]
[OnName num="sayo"]
Father, what are you talking...
[cpg cn=true]



[SE f=se091]
;//【ＳＥ】『猫の首輪の鈴の音』

[WAIT time=1000]


Oh!
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo433"]
[OnName num="sayo"]
Aaah!
[cpg cn=true]


[OnName num="the_master"]
Hey, Saya. Don't be rude during dinner.
[cpg cn=true]



[SE f=se059]
;//【ＳＥ】『椅子から立ち上がる』ガタッ

[WAIT time=1000]

[move from="2/3" to="5/3" ease="easeInOutSine" time=2000]

[SE f=se006]
;//【ＳＥ】『走る』タッタッタ

[WAIT time=1500]


Master got up from his seat and ran towards the door.
[cpg]

The butler behind her quickly caught the chair that was about to fall over and put it back.
[cpg]

[FG f="CHA01_p3_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo434"]
[OnName num="sayo"]
'Father! Father! The cat! The cat! My cat!"
[cpg cn=true]


[OnName num="the_master"]
Haha, you don't have to get so close to see it. That's good, isn't it?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo435"]
[OnName num="sayo"]
I never thought it would turn out to be true.
[cpg cn=true]


[VOICE f="Sayo436"]
[OnName num="sayo"]
So cute.
[cpg cn=true]


[OnName num="butler"]
Well, well, well. Could it be a stray cat?
[cpg cn=true]


[OnName num="the_master"]
Tanaka, you have to close the gate properly.
[cpg cn=true]


[OnName num="butler"]
I'm sorry.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo437"]
[OnName num="sayo"]
That's a bit obvious, Father. And you too, Mr. Tanaka.
[cpg cn=true]


[OnName num="the_master"]
What the...?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo438"]
[OnName num="sayo"]
What? It's not normal for a pedigreed cat to wander into a place like this with no houses around.
[cpg cn=true]


[OnName num="butler"]
Well, you've been found out, haven't you?
[cpg cn=true]


[OnName num="the_master"]
Well, well, well.
[cpg cn=true]


[FG f="CHA01_p4_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo439"]
[OnName num="sayo"]
Thank you, Father!
[cpg cn=true]


[OnName num="the_master"]
I'm glad you're happy, Saya. I'm glad Saya is happy. Besides, it wasn't me who suggested it, it was all the servants.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo440"]
[OnName num="sayo"]
I didn't know that. Thank you, everyone.
[cpg cn=true]


[OnName num="butler_A"]
No, no, we didn't do anything.
[cpg cn=true]


[OnName num="maid_A"]
I'm glad you're happy, young lady.
[cpg cn=true]



「「「「「 hahahahahahahahaha 」」」」」
[cpg]


The morning meal time was filled with a very friendly atmosphere.
[cpg]

In this way, thanks to the master's and Mr. Tanaka's smart plan... a new family member would be added.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


;//【ＢＧ】『空』（朝）******************************************************
;//【ＢＧ】『豪邸、ダイニング』（朝）******************************************************

[window target=true]


[VOICE f="Sayo441"]
[OnName num="sayo"]
"Oh, she's a female, isn't she?
[cpg cn=true]


[VOICE f="Sayo442"]
[OnName num="sayo"]
"I thought it was a male in my dream, so I thought..."
[cpg cn=true]


[OnName num="masato"]
"Ouch."
[cpg cn=true]


[VOICE f="Sayo443"]
[OnName num="sayo"]
"Hmm, but she's cute."
[cpg cn=true]


Well, somehow... it seems to have settled down safely.
[cpg]

[window target=false]

[STOPBGM]

[BG f="black.ui" time=1000]
[WAIT time=1500]

[window target=true]

[jump storage="ep010.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////
