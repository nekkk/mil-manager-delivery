*start

;//[jump target="*root_existence"]


;#################################################
*Ep008|Serious S vs Serious M
;#################################################

[SCENE id=8]


[stflag jump_scene=0]
[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


[BG f="black.ui" time=1000]

[SE f=se018]
;//【ＳＥ】『鳥の鳴き声』

[WAIT time=2000]

[window target=true]


It happened when I was hanging my laundry outside.
[cpg]


[window target=false]
[BG f="b_07_2.ui" time=1000]

[WAIT time=1500]

[BGM f="d1"]
;//【ＢＧ】『空』（昼）******************************************************

[window target=true]


[OnName num="masato"]
It's another beautiful day.
[cpg cn=true]


It's a perfect day to dry the laundry. It's a perfect day for drying laundry, so let's get to work.
[cpg]


[SE f=se044]
;//【ＳＥ】『洗濯物を干す』

[OnName num="brionac"]
"Hmmm..."
[cpg cn=true]


[OnName num="masato"]
"Oh, what's wrong, senpai?"
[cpg cn=true]


I call him "senpai" because he serves his master before me. Sometimes, though.
[cpg]

[OnName num="brionac"]
"Woof!
[cpg cn=true]


[OnName num="masato"]
Does he want me to play with him?
[cpg cn=true]


He jerks me around strangely, but I can't because I'm hanging the laundry.
[cpg]

[OnName num="masato"]
See you later.
[cpg cn=true]


[OnName num="brionac"]
"Woof! ...... woof!"
[cpg cn=true]


[OnName num="masato"]
Oh! Hey!
[cpg cn=true]


He was annoyed that I treated him so badly, and jumped on the laundry.
[cpg]

And it's... master's favorite clothes! That's not good!
[cpg]

[OnName num="masato"]
"Don't...don't..."
[cpg cn=true]



[SE f=se045]
;//【ＳＥ】『破れる音』ビリビリ、ビリッ

[OnName num="masato"]
"Hey!
[cpg cn=true]


[OnName num="brionac"]
"Woooooooooo!"
[cpg cn=true]



[SE f=se046]
;//【ＳＥ】『噛み付く』ガブッ

[OnName num="masato"]
No... no... no... no!
[cpg cn=true]


;//ＢＫ

[STOPBGM]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1500]


[BGM f="se"]
;//【ＢＧ】『小夜の部屋』（夕方）******************************************************

[window target=true]


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo347"]
[OnName num="sayo"]
"........."
[cpg cn=true]


I'm sitting on the floor in front of my master who has returned from the academy.
[cpg]

She was so angry that it was not a flattering atmosphere.
[cpg]

[VOICE f="Sayo348"]
[OnName num="sayo"]
This is my favorite dress. Do you know it?"
[cpg cn=true]


[OnName num="masato"]
"Yes, I do..."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo349"]
[OnName num="sayo"]
"And you... you did this ...... to it..."
[cpg cn=true]


A few tears appear in her eyes.
[cpg]

The clothes have been ripped to shreds. It may be difficult to fix it.
[cpg]

It's a very important thing, but to do it like this...it'll make Master sad.
[cpg]

[OnName num="maid_A"]
It was a gift from the master, a memento.
[cpg cn=true]


[OnName num="masato"]
I'm so sorry. I'm really, really sorry!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo350"]
[OnName num="sayo"]
Yes, ...... I got it when I was in elementary school, and I still cherish wearing it!
[cpg cn=true]


[OnName num="masato"]
Master... you've grown since then...
[cpg cn=true]


[VOICE f="Sayo351"]
[OnName num="sayo"]
Hmph!
[cpg cn=true]


[SE f=se047]
;//【ＳＥ】『殴る』バキッ

[transition target={true} rule="bakuhatu1.webp" color={0xffffffff} time=200]
[WAIT time=310]


[transition target={false} rule="bakuhatu1.webp" color={0xffffffff} time=200]
[WAIT time=310]

He hit me with a rare goo.
[cpg]

[OnName num="butler&maidA"]
(For saying unnecessary things...)
[cpg]

[FG f="CHA01_p4_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo352"]
[OnName num="sayo"]
"This time...this time, ...... I'm really angry, too."
[cpg cn=true]


[OnName num="masato"]
I'm sorry...
[cpg cn=true]


[VOICE f="Sayo353"]
[OnName num="sayo"]
I won't forgive you. Prepare yourself."
[cpg cn=true]


And so the hellish ordeal began.
[cpg]

[OnName num="brionac"]
"......?"
[cpg cn=true]



;//ＢＫ

[STOPBGM]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=2000]



[BG f="b_06_3.ui" time=1000]

[WAIT time=1500]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夕方）******************************************************


[BGM f="h1"]

[window target=true]


[OnName num="masato"]
I'll try to be gentle with you...
[cpg cn=true]


[FG f="CHA01_p3_21_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo354"]
[OnName num="sayo"]
"........."
[cpg cn=true]


She didn't answer, and proceeded with her preparations without hesitation. I've been thinking about this for a while.
[cpg]


;//●ＣＧ（雅人＆小夜・本を使って主人公をサンドバッグにするヒロイン：雅人の部屋）ev_17
;//雅人はベッドに縛られてます。

[FO pos="2/3" time=1000]

;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo355"]
[OnName num="sayo"]
I've been thinking about it for a while."
[cpg cn=true]


Her voice was colder than usual. She had a thick dictionary in her hand.
[cpg]

[VOICE f="Sayo356"]
[OnName num="sayo"]
I was thinking that if I kicked you directly, you would get dirty.
[cpg cn=true]


[OnName num="masato"]
Oh, that ...... book...
[cpg cn=true]


[VOICE f="Sayo357"]
[OnName num="sayo"]
It's the Six Laws. I thought what you lacked was discipline.
[cpg cn=true]


The Six Laws. I wonder where he got it from.
[cpg]

[VOICE f="Sayo358"]
[OnName num="sayo"]
What do you think I'm going to do with it?
[cpg cn=true]


[OnName num="masato"]
You could hit me with it...
[cpg cn=true]

;**【ＣＧ】 ev_17_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo359"]
[OnName num="sayo"]
That's a good one.
[cpg cn=true]


I'm sorry, that was unnecessary!
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo360"]
[OnName num="sayo"]
I was going to see at what height you would pass out if I dropped this on your head from above.
[cpg cn=true]


I was going to see if I could drop this on your head from above to see at what height you'd pass out. No, no, no. Would you rather be hit by ......?
[cpg]


;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1500]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo361"]
[OnName num="sayo"]
Or do you want me to memorize the contents of this book?
[cpg cn=true]


It seems to be the most difficult, but in a way it's also the easiest because it's impossible.
[cpg]

[OnName num="masato"]
"Well, since we're at the end..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo362"]
[OnName num="sayo"]
All right. I'll make him eat the pages he can't remember.
[cpg cn=true]


[OnName num="masato"]
I'll take the first one!
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo363"]
[OnName num="sayo"]
"Which one is it?"
[cpg cn=true]


Then she shook the book.
[cpg]

[SE f=se030]
;//【ＳＥ】『風切音』ビュンッ

[STOPBGM]
;//ＢＫ

[window target=false]
[transition target={true} rule="bakuhatu1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu1.webp" color={0xffffffff} time=1]
[WAIT time=2000]


[BG f="b_06_4.ui" time=2000]
[WAIT time=3000]


;//【ＢＧ】『使用人の部屋（雅人の部屋）』（夜）******************************************************

[window target=true]


[BGM f="se"]

[OnName num="masato"]
She shook the book and said, "Uh-uh... that..."
[cpg cn=true]


When I woke up, it was already night.
[cpg]

When I woke up, it was already nighttime, and the straps that had bound my hands and feet were gone, and I was lying neatly on my bed.
[cpg]

It seems that I had just passed out and it was this time of night.
[cpg]


[SE f=se078]
;//【ＳＥ】『衣擦れ』


My body is incredibly strong. I might be a good sandbag.
[cpg]

[OnName num="masato"]
"Ow...that hurt!"
[cpg cn=true]


Even the slightest movement or rubbing is enough to cause pain. It's only natural after all the things you've done.
[cpg]

And it's not only because of Master's penis but also because of other things that caused the pain.
[cpg]

I think I'll just sleep quietly for the rest of the day.
[cpg]


[SE f=se034]
;//【ＳＥ】『ノック』

[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="5/3" time=1]

[VOICE f="Sayo364"]
[OnName num="sayo"]
"It's me. Are you awake?"
[cpg cn=true]


[OnName num="masato"]
Yes, it's me. Come in.
[cpg cn=true]


;//＠消し忘れ？
;//;//-------------------------------
;//[OnName num="masato"]
;//「ノックくらいして下さい」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_3" pos="2/3"]
;//[VOICE f="Sayo365"]
[OnName num="sayo"]
;//「は？何故？下僕の部屋にはいるのに私がノックしなくちゃいけないの？」
;//[cpg cn=true]
;//
;//
;//普段みないくらいキレている。
;//[cpg]
;//;//-------------------------------

[SE f=se016]
;//【ＳＥ】『扉を開ける』

[move from="5/3" to="2/3" ease="easeInOutSine" time=2000]

[WAIT time=2500]

[VOICE f="Sayo366"]
[OnName num="sayo"]
I'm sorry to bother you at this hour.
[cpg cn=true]


[OnName num="masato"]
No, it's..."
[cpg cn=true]


I tried to stand up to get a chair, but she stopped me with her hand.
[cpg]

She stood and talked.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo367"]
[OnName num="sayo"]
"Why didn't you tell me..."
[cpg cn=true]


I knew immediately that what she was talking about was the dog bite.
[cpg]

Yes...I was bitten when I tried to stop Brunark that time.
[cpg]

So today's blame was even more painful.
[cpg]

[OnName num="masato"]
"It was an accident. And it was my fault."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo368"]
[OnName num="sayo"]
"......, take it off."
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo369"]
[OnName num="sayo"]
Take it off!
[cpg cn=true]


[SE f=se013]
;//【ＳＥ】『服を脱ぐ』シュルシュル

[WAIT time=1500]


I was forced to wear the embarrassing outfit again.
[cpg]

[FG f="CHA01_p5_03_a.ui" method="change_7"  pos="2/3" time=800]


I did as I was told and took off my clothes. Master brought me some drugs and applied them to the area where I had been beaten.
[cpg]

[OnName num="masato"]
I'm so embarrassed.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo370"]
[OnName num="sayo"]
"You always dress like this, don't you? Why are you embarrassed?
[cpg cn=true]


[OnName num="masato"]
No, it's just that you're not always so gentle with me.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo371"]
[OnName num="sayo"]
I'm not gentle?
[cpg cn=true]


[OnName num="masato"]
Not at all!
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo372"]
[OnName num="sayo"]
Hmm. You'd rather be rough than gentle.
[cpg cn=true]

[SE f=se068]
;//【ＳＥ】『弱々しいビンタ系』

Pish.
[cpg]

[OnName num="masato"]
Ouch.
[cpg cn=true]


He slapped me lightly.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo373"]
[OnName num="sayo"]
I'm sorry...I lost my temper too.
[cpg cn=true]


[OnName num="masato"]
"Oh, no, Master. Please don't apologize.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo374"]
[OnName num="sayo"]
I have punished him properly. He needs to be disciplined again.
[cpg cn=true]


The punishment seems to be a week of cheap food, but I don't think that's much of a punishment.
[cpg]

[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo375"]
[OnName num="sayo"]
"Okay, that's it.
[cpg cn=true]


[OnName num="masato"]
Thank you, sir.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo376"]
[OnName num="sayo"]
Get some rest. If the swelling doesn't go down, I'll give you another coat. And go to the hospital.
[cpg cn=true]


[OnName num="masato"]
It's all right. I'm sure you'll be fine by tomorrow.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo377"]
[OnName num="sayo"]
See you tomorrow.
[cpg cn=true]


[OnName num="masato"]
Okay. Have a good night.
[cpg cn=true]

[move from="2/3" to="5/3" ease="easeInOutSine" time=2000]
[WAIT time=1000]

[SE f=se017]
;//【ＳＥ】『扉を閉める』


With that, the master left the room.
[cpg]

I felt a strange feeling. I was somewhat happy to see a slightly different master than usual.
[cpg]

[STOPBGM]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="5/3" time=1]
[BG f="black.ui" time=1]

[SE f=se018]
;//【ＳＥ】『鳥の鳴き声』朝チュン

[WAIT time=2000]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=2000]

[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]




[BGM f="d1"]
;//【ＢＧ】『豪邸、ダイニング』（朝）******************************************************

[window target=true]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo378"]
[OnName num="sayo"]
"Good morning. How are you doing?
[cpg cn=true]


[OnName num="masato"]
Yes, I'm totally fine.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo379"]
[OnName num="sayo"]
That's good.
[cpg cn=true]


I felt as if the distance between me and Master had shortened... one more step.
[cpg]

I don't know if it was as a servant or as a pet, but...
[cpg]

[STOPBGM]

[window target=false]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ


[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]



[jump storage="ep009.ks" target="*start"]

;//////////////////////////////////////////////////////////////////////
