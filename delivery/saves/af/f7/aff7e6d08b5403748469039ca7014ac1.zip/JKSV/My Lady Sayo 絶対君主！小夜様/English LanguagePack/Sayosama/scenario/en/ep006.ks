*start


;#################################################
*Ep006|M is easily misunderstood.
;#################################################

[SCENE id=6]


[stflag jump_scene=0]
;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]


And then it happened again on a different day.
[cpg]

Although it was a mistake, I peeked at Master 's changing clothes.
[cpg]


;//●ＣＧ（主人公＆小夜・ヒロインに足蹴にされる主人公：屋敷廊下）ev_19

[BGM f="h1"]

[SE f=se040]
;//【ＳＥ】『突き飛ばされる』

[window target=false]
[transition target={true} rule="bakuhatu1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu1.webp" color={0xffffffff} time=1]
[WAIT time=1]


[transition target={true} rule="sita.webp" color={0xffffffff} time=1]
[WAIT time=1]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=6 index=0 time=1]
;***************************************
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0xffffffff} time=1000]
[WAIT time=1500]

[window target=true]

[VOICE f="Sayo321"]
[OnName num="sayo"]
"You're such an asshole for peeping at my clothes."
[cpg cn=true]


[OnName num="masato"]
"Yes, I have nothing to say in return.
[cpg cn=true]


[VOICE f="Sayo322"]
[OnName num="sayo"]
You're getting used to apologizing all the time, aren't you?
[cpg cn=true]


[OnName num="masato"]
I'm sorry. I'm sorry.
[cpg cn=true]


[VOICE f="Sayo323"]
[OnName num="sayo"]
You've been doing it all your life, haven't you?
[cpg cn=true]


There was a different nuance to what she was saying today.
[cpg]

[VOICE f="Sayo324"]
[OnName num="sayo"]
"Being good at apologizing won't make you good at your job."
[cpg cn=true]


[OnName num="masato"]
"Oh, um... did you read something on Master ?"
[cpg cn=true]

;**【ＣＧ】 ev_19_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo325"]
[OnName num="sayo"]
"What?　What?
[cpg cn=true]


It might have been an unnecessary comment for me to say here.
[cpg]

[VOICE f="Sayo326"]
[OnName num="sayo"]
"I haven't read... anything about empiricism..."
[cpg cn=true]


Teioigaku, huh? I wonder if there was something in there about how to scold subordinates.
[cpg]

[VOICE f="Sayo327"]
[OnName num="sayo"]
Anyway!　You should just apologize and stop guessing!
[cpg cn=true]


You're saying the opposite of what I just said!
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

In the future, I'll make sure that she's changed her clothes before entering the room...
[cpg]

[window target=false]


[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[WAIT time=500]

[window target=true]


[jump storage="ep007.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
