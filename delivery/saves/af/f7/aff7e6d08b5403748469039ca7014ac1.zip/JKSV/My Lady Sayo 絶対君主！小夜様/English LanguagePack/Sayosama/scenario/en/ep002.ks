
*start



;#################################################
*Ep002|M's dream
;#################################################

[SCENE id=2]


[stflag jump_scene=0]
[stflag gohome_flag=0]
[stflag service_flag=0]
[stflag hiyokurenri_flag=0]
[stflag existence_flag=0]
[stflag pets_flag=0]

[stflag jump_scene=1]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]



[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_0.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[STOPBGM]

[WAIT time=100]

[BGM f="co"]
[WAIT time=100]
;//【ＢＧ】『空』******************************************************
;//夢の中。空の背景にモヤモヤを掛けたもので代用。

[window target=true]


When I woke up, I found myself in a fluffy, shiny place I had never seen before.
[cpg]

Where the hell am I? What was I doing here?
[cpg]

[OnName num="masato"]
I'm sure I was..."
[cpg cn=true]


As I pulled out my memory and tried to remember...
[cpg]

"'Big brother'..."
[cpg]


[SE f=se008]
;//【ＳＥ】『走ってくる音』

[OnName num="masato"]
"Oh, wow. There are so many girls here!
[cpg cn=true]


Out of nowhere, many sisters who called me "brother" appeared.
[cpg]


[OnName num="younger_sister_4"]
"Brother! I've got him!
[cpg cn=true]


[OnName num="younger_sister_1"]
"Oh my god, big brother! You can't just leave us here!
[cpg cn=true]


[OnName num="younger_sister_2"]
You're a terrible brother for breaking a promise to your lovely sister.
[cpg cn=true]


[OnName num="younger_sister_3"]
"Come on. Play, play, play.
[cpg cn=true]


[OnName num="younger_sister_5"]
Big brother, let me put my pants on. Pants pants pants.
[cpg cn=true]


[OnName num="masato"]
......
[cpg cn=true]



This is heaven. I'm sure of it.
[cpg]

I have a caring, spoiled, tsundere ...... sister with many attributes that I have dreamed of. If this is not heaven, then what is it?
[cpg]


[OnName num="masato"]
"That's right. I have a lot of little sisters, and I spend my days playing with them and..."
[cpg cn=true]


[OnName num="younger_sister_2"]
"What's wrong with you? Why are you crying, brother?
[cpg cn=true]


[OnName num="younger_sister_5"]
What's wrong with your brother? Are you sad because you can't find your pants?
[cpg cn=true]


[OnName num="younger_sister_1"]
Big brother? Are you sad about something?
[cpg cn=true]


[OnName num="masato"]
No, it's just that I've been through a lot lately and I'm suddenly crying.
[cpg cn=true]


[OnName num="younger_sister_4"]
"Brother, you must have had a bad dream. It's okay! We'll always be by your side!
[cpg cn=true]


[OnName num="younger_sister_3"]
"Niini. Good boy, good boy...
[cpg cn=true]



As my sisters say, I must have been having a bad dream until now.
[cpg]

This is the real reality.
[cpg]

I felt like I'd been fired from my job or something, but it was all in my head.
[cpg]


Hooray! Long live my sister!
[cpg]


[OnName num="masato"]
"Hahahahaha, hahahahaha!"
[cpg cn=true]



;//キャッキャする雅人と妹達

[SE f=se005]
;//【ＳＥ】『歩いてくる』

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo051"]
[OnName num="sayo"]
"You really are a helpless person, aren't you?"
[cpg cn=true]



;//小夜の立ち絵登場

;//無音

[STOPBGM]

[stopse g=2]
;//通常se

[OnName num="masato"]
"........................... ...Huh?
[cpg cn=true]



[SE f=se014]
;//【ＳＥ】『衝撃』ダダーン

It was a shock, like being hit with a blunt object.
[cpg]

[BGM f="h1"]


I've felt something similar when I felt like I was fired from my job.
[cpg]

No... it might be more than that.
[cpg]



[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo052"]
[OnName num="sayo"]
"Brother. What's wrong?"
[cpg cn=true]


[OnName num="masato"]
'Um, because... that...? You're not... that..."
[cpg cn=true]



She was a familiar face. No, my sister...?
[cpg]

No, no, no, that's ridiculous. My sister does not include this girl.
[cpg]

It's a good idea to take a look at the website to see if there is anything you need to know.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo053"]
[OnName num="sayo"]
Did you forget your sister's face, brother?
[cpg cn=true]


Oh, no. This is not good.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo054"]
[OnName num="sayo"]
"Oh, no. How long have you been asleep? Hurry up and wake up, big brother.
[cpg cn=true]


[OnName num="younger_sister_1"]
"Big brother."
[cpg cn=true]


[OnName num="younger_sister_2"]
Big brother.
[cpg cn=true]


[OnName num="younger_sister_3"]
Big brother.
[cpg cn=true]


[OnName num="younger_sister_4"]
Brother!
[cpg cn=true]


[OnName num="younger_sister_5"]
Brother."
[cpg cn=true]



---And with that, the sisters swung their right foot with a smile...
[cpg]

Aaaaah ...... no ............... wake up.
[cpg]

[SE f=se030]
;//【ＳＥ】『風切音』ビュンッ

;//ＢＫ
[STOPBGM]

[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=500]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=1]
[WAIT time=2000]



;//【ＢＧ】『使用人の部屋（執事、田中の部屋）』（昼）******************************************************
;//ここで働く事になるので雅人の部屋にもなります。最初は物が無くて殺風景な感じの方が良いです。
;//それか全く一緒でも全然問題無いです。


[SE f=se015]
;//【ＳＥ】『ベッドから起きる』がバッ

[transition target={true} rule="bakuhatu2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]

[WAIT time=200]
[transition target={false} rule="bakuhatu2.webp" color={0x000000ff} time=500]
[WAIT time=1000]

[window target=true]


[OnName num="masato"]
Aaaaah!
[cpg cn=true]


[OnName num="butler"]
"Noooo?
[cpg cn=true]


[OnName num="masato"]
"Huh, huh, huh, huh, huh..."
[cpg cn=true]



I found myself in a room I had never seen before. The color was clearly different from the fluffy place I must have been just a moment ago.
[cpg]

[BGM f="sl"]

[OnName num="butler"]
"......, did you notice that?"
[cpg cn=true]


[OnName num="masato"]
"Heh, ah, ...... yes."
[cpg cn=true]



I'm in a strange room and I'm sleeping.
[cpg]

I was asleep in an unknown room and had just woken up.
[cpg]

I became more aware of the fact that what I had just seen was a dream.
[cpg]


[OnName num="butler"]
How are you feeling?
[cpg cn=true]


[OnName num="masato"]
"Well, not really. I feel fine.
[cpg cn=true]


[OnName num="butler"]
That's good. The hospital didn't seem to find anything wrong with me.
[cpg cn=true]


[OnName num="masato"]
The hospital?
[cpg cn=true]


[OnName num="butler"]
Oh, you don't remember that, do you? No, not after what happened. You need to get checked out to feel safe... you and us.
[cpg cn=true]


[OnName num="masato"]
I see. I'm going to give her .......
[cpg cn=true]



I remember it well. I remember it well. I mean, I can't forget something like that so easily.
[cpg]

It's just that I had a dream that was so real that I thought it was real, and I woke up and didn't know what to do.
[cpg]

I finally remembered why I was here.
[cpg]

I don't know what I don't remember, but it seems that I was taken to the hospital and then taken care of like this.
[cpg]

[OnName num="butler"]
I'm sorry for the delay. I'm Tanaka, the butler in charge of the family.
[cpg cn=true]


[OnName num="masato"]
Ha! Thank you for your kindness. I'm Sakigawa.
[cpg cn=true]


[OnName num="butler"]
By the way, do you have a brother or sister?
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[OnName num="butler"]
I heard them talking in their sleep.
[cpg cn=true]


[OnName num="masato"]
"Oh, ha-ha-ha..."
[cpg cn=true]

I didn't know what to say, so I gave a wry smile. I didn't know what to say, so I smiled wryly. If anyone knew what kind of dream I was having, they would be shocked.
[cpg]

[OnName num="butler"]
This way.
[cpg cn=true]


[OnName num="masato"]
What?"
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』

Mr. Tanaka offered me a change of clothes as he spoke.
[cpg]

[OnName num="butler"]
The young lady is waiting for you over there.
[cpg cn=true]


[OnName num="masato"]
"Yes?"
[cpg cn=true]

[STOPBGM]
[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=2500]
;//ＢＫ

[SE f=se016]
;//【ＳＥ】『扉を開ける』ガチャ

[WAIT time=2000]


[SE f=se017]
;//【ＳＥ】『扉を閉める』バタン

;//優雅な音楽


[BG f="b_04_2.ui" time=1000]

[WAIT time=1500]

;//【ＢＧ】『小夜の部屋』（昼）******************************************************

[window target=true]

[BGM f="sl"]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo055"]
[OnName num="sayo"]
What?
[cpg cn=true]


After changing, Mr. Tanaka led me to a room where "the girl" was elegantly enjoying her afternoon tea time.
[cpg]

[OnName num="butler"]
"Miss, I've brought Miss Sakigawa."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo056"]
[OnName num="sayo"]
Thank you.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]



It was as if I had wandered into the world of a manga or anime, and there was a rich man's room.
[cpg]

They are obviously from a different world than mine.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo057"]
[OnName num="sayo"]
"How are you feeling?"
[cpg cn=true]


[OnName num="masato"]
"Uh, yes. I'm fine, thanks to you.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo058"]
[OnName num="sayo"]
Yeah. That's good to hear.
[cpg cn=true]



As Mr. Tanaka also calls her daughter, this girl in front of him seems to be a very important person.
[cpg]

It's a good idea to have a good idea of what you're looking for.
[cpg]

But it's not just that, it's also the fact that she seems to have an air of unconscious humility about her.
[cpg]

Even though the person I'm talking to looks like a child, I'm in awe and use honorifics.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo059"]
[OnName num="sayo"]
"Mr. Tanaka, can you hand me that document?
[cpg cn=true]


[OnName num="butler"]
"Yes, this way."
[cpg cn=true]

[SE f=se076]
;//【ＳＥ】紙の音

Mr. Tanaka immediately handed over what she was looking for.
[cpg]

The quickness of his response and the fact that he knew what the other person was looking for made him the perfect butler. I was a little moved to see him in person.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo060"]
[OnName num="sayo"]
"Masato Sakigawa-san?"
[cpg cn=true]


[OnName num="masato"]
Yes, sir!
[cpg cn=true]


I felt nervous when my name was suddenly called.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo061"]
[OnName num="sayo"]
I'll introduce myself again. I am Misanagi Sayo.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo062"]
[OnName num="sayo"]
I am your... master.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


That means...
[cpg]

[FG f="CHA01_p4_01_a.ui" method="change_3"  pos="2/3" time=800]
[WAIT time=800]
[VOICE f="Sayo063"]
[OnName num="sayo"]
"About the results of the interview..."
[cpg cn=true]


I had completely forgotten about it due to various reasons, but I had come for an interview in search of a job.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo064"]
[OnName num="sayo"]
I passed without question. Congratulations on getting the job.
[cpg cn=true]


[OnName num="masato"]
"Yes, yes, yes... thank you.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo065"]
[OnName num="sayo"]
You should be more excited.
[cpg cn=true]


[OnName num="masato"]
I'm sorry. I'm still confused...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo066"]
[OnName num="sayo"]
"Well, I'm sure you'll calm down after a good night's rest."
[cpg cn=true]


"Well, I'm sure you'll calm down after a good night's rest.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo067"]
[OnName num="sayo"]
"The job starts tomorrow. The job starts tomorrow, and you'll be living and working here, so please come prepared.
[cpg cn=true]


I wasn't too keen on the idea and pondered over what to do.
[cpg]

It wasn't that I could start working tomorrow, but that I would have to work if I didn't.
[cpg]

[OnName num="masato"]
Wait a minute, please. Please don't proceed without permission..."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=800]
[VOICE f="Sayo068"]
[OnName num="sayo"]
"Selfishly? What do you mean?"
[cpg cn=true]


I couldn't give a clear answer to her question.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo069"]
[OnName num="sayo"]
What do you mean? Or are you worried about the sudden change of environment?
[cpg cn=true]


To be honest, I think it's both. But what made me more nervous was the part about what kind of work I would be doing.
[cpg]

[OnName num="masato"]
I don't like it, or I'm worried about it, or... well..."
[cpg cn=true]


I was expressing my feelings that I didn't know for sure.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo070"]
[OnName num="sayo"]
"...... You should be honest."
[cpg cn=true]


[OnName num="masato"]
"What?"
[cpg cn=true]


I heard her words faintly as she blurted them out.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo071"]
[OnName num="sayo"]
"You don't want to serve me?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo072"]
[OnName num="sayo"]
'Are you unhappy to serve me as your master because of my status as a woman, who looks like a child, and who is supposed to be less powerful than you?
[cpg cn=true]


She pieced the words together one by one to confirm something.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo073"]
[OnName num="sayo"]
"What are you confused about now? I'm sure you'll be happy to have a regular job."
[cpg cn=true]


Tanaka! Tanaka!" she shouted a little louder and took some documents from him.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo074"]
[OnName num="sayo"]
I'm sure you'll be happy to know that I'm not the only one who's been struggling with this.
[cpg cn=true]


[OnName num="masato"]
"Ugh...!
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo075"]
[OnName num="sayo"]
It's an odd preference, preferring a day job to a regular job, but to each his own. If you don't like it, that's fine.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo076"]
[OnName num="sayo"]
Food, clothing, shelter, a job and a steady income... what's wrong with that?
[cpg cn=true]


[OnName num="masato"]
"Well, I'm not complaining..."
[cpg cn=true]


I can't say anything back because the other person is right and I'm just talking about my feelings.
[cpg]

But I found one thing to argue about.
[cpg]

[OnName num="masato"]
But I found one thing to argue about. Without knowing that, I can't really say..."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo077"]
[OnName num="sayo"]
"......"
[cpg cn=true]


[OnName num="masato"]
(Oh, he's going to be mad... I'm nervous...)"
[cpg cn=true]


As I anxiously awaited his reply.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo078"]
[OnName num="sayo"]
"I thought you already knew that..."
[cpg cn=true]

;//【ＳＥ】ページめくる
[SE f=se076]
;//【ＳＥ】紙の音

"I thought you already knew..." He showed me another document.
[cpg]

[OnName num="masato"]
"What's this?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo079"]
[OnName num="sayo"]
"This is a document stating the job description. Please choose one.
[cpg cn=true]


[OnName num="masato"]
"..............."
[cpg cn=true]



One, to serve Saya Misanagi as your master (like a butler, I guess).
[cpg]

2. Be kept as Saya Misanagi's pet (I don't know what that means)
[cpg]

This is the summary of what was written on the paper that was handed to me.
[cpg]

The second document was not proper in any way, which made me even more confused.
[cpg]


[OnName num="masato"]
"........., you're kidding, right?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo080"]
[OnName num="sayo"]
No, I'm very serious. I'm serious.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


If this is not a sophisticated gag, then she is serious, as she says.
[cpg]

If you want to do this job, you have to choose between serving her as a "master" or being kept by her, as she looks like a child.
[cpg]

I was at a fork in the road of life.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo081"]
[OnName num="sayo"]
I don't want to force you, so you can decline if you don't want to. There are other candidates."
[cpg cn=true]


[OnName num="masato"]
"What, other...?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo082"]
[OnName num="sayo"]
"The ones you were with. Don't you remember them?
[cpg cn=true]


I guess you're talking about the other three people who stayed until the end of that interview.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo083"]
[OnName num="sayo"]
Two of them are unlikely, but one of them will be there... and the other one will probably come back to take the test.
[cpg cn=true]


I knew immediately that it was the man with the glasses who was talking.
[cpg]

He was the first to take the test. He was the first one to take the test. I could feel his determination, even I could tell.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo084"]
[OnName num="sayo"]
They seem to be more motivated than you.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


I don't know, but she's right... and since I've expressed my reluctance, I can't blame her for wanting someone else.
[cpg]

And yet, for some reason, it makes me feel bad.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo085"]
[OnName num="sayo"]
"Above all..."
[cpg cn=true]


[FG f="CHA01_p4_01_a.ui" method="change_2"  pos="2/3" time=800]
[WAIT time=800]
[VOICE f="Sayo086"]
[OnName num="sayo"]
"They were honest with themselves."
[cpg cn=true]


[OnName num="masato"]
......!!!"
[cpg cn=true]



She has the same look in her eyes as she did then.
[cpg]

She has the same look in her eyes as she did then, when the test was more like a trial.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo087"]
[OnName num="sayo"]
What do you want to do? If you could decide now, that would be great..."
[cpg cn=true]


[OnName num="masato"]
"Well...I..."
[cpg cn=true]


What should I do? What should I do?
[cpg]

Should I take it or not? If I take it, should I choose 1 or 2? Which one should I choose...?
[cpg]

;//■選択肢１
[switch]
[case "I'll serve you."]
	[swap]
	[jump target="*IseSel01_1"]
[case "to be kept"]
	[swap]
	[jump target="*IseSel01_2"]
[case "Refuse"]
	[swap]
	[jump target="*IseSel01_3"]
[endswitch]


;//■選択肢
1, to serve you
2, to be kept
3, refuse


;//==============================
;//１、お仕えするの場合
;//ご主人様である小夜にお仕えする展開。執事育成の様な感じで色々教育されながら、遊び相手としても調教されていく

*IseSel01_1|M's dream

[OnName num="masato"]
"...... will serve you."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo088"]
[OnName num="sayo"]
"Yes. Good girl."
[cpg cn=true]


She smiled happily.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo089"]
[OnName num="sayo"]
"Oh, and..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo090"]
[OnName num="sayo"]
Serving isn't as noble as being a butler, so be prepared for that.
[cpg cn=true]


[OnName num="masato"]
"Then what is it...?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo091"]
[OnName num="sayo"]
"Well, ...... servant, I suppose.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo092"]
[OnName num="sayo"]
"Servant and pet, I suppose..."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo093"]
[OnName num="sayo"]
"I'm looking forward to working with you. Cute servant.
[cpg cn=true]


In this way, I became a butler, or servant, to my master.
[cpg]


;//【ただいまEND】へのフラグ

[stflag gohome_flag=1]


[jump target="*IseSel01_4"]


;//※合流１へ
;//==============================
;//２、飼われる
;//ご主人様である小夜にペットの様に飼われる展開

*IseSel01_2|M's dream

[OnName num="masato"]
Please keep me at ......."
[cpg cn=true]


;//小夜「そう。良い子ね」
;//小夜「そう。良い子ね」
;//[cpg]
[FACE method="change_2" pos="2/3"]

She smiled happily.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo094"]
[OnName num="sayo"]
She smiled happily and said, "Well, you're my pet now. Now you are my pet, and you will listen to me.
[cpg cn=true]


[OnName num="masato"]
"Yes..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo095"]
[OnName num="sayo"]
"Well, I'll treat you as a pet, but for the time being, you'll be my nominal servant.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo096"]
[OnName num="sayo"]
I'll treat you as a pet, but for the time being, I'll call you a servant. Cute pet.
[cpg cn=true]

[stflag pets_flag=1]
;//ペットフラグ

[jump target="*IseSel01_4"]

;//※合流１へ
;//==============================
;//３、断る

*IseSel01_3|M's dream

[OnName num="masato"]
............... Sorry.
[cpg cn=true]


It's just that I can't seem to shake my head, so I just squeezed out a few words.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo097"]
[OnName num="sayo"]
"...... I see. I'm sorry, but it can't be helped.
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]



[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ＢＫ

Thus, the connection with her disappeared without a trace, and I went back to my life as usual...
[cpg]


;//少し間を置いて
[STOPBGM]


[SE f=se003]
;//【ＳＥ】『荷出しの音』ガタガタ


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=2100]
[BG f="b_03_2.ui" time=1]



[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=2000]
[window target=true]

[BGM f="se"]

[OnName num="man_1"]
"Hey, don't be a dick!
[cpg cn=true]


[OnName num="masato"]
I'm sorry...
[cpg cn=true]


;//【ＢＧ】『分岐路のある道』（昼）******************************************************

[OnName num="man_1"]
"Oh, forget it. Just take it to the warehouse. All of it, all of it.
[cpg cn=true]


[OnName num="masato"]
Yes, sir!
[cpg cn=true]


[SE f=se003]
;//【ＳＥ】『荷出しの音』ガタガタ

[WAIT time=2000]

;//レターボックスin
[FACE method="feadin" pos="4/7"]
[WAIT time=2000]

[OnName num="man_2"]
Senior, can't you do something about that guy? I don't want to work with him.
[cpg cn=true]


[OnName num="man_1"]
I don't like it either, but there's nothing I can do about it.
[cpg cn=true]


[OnName num="man_2"]
How old is that guy?　He looks young.
[cpg cn=true]


[OnName num="man_1"]
Oh... he's old enough to be working part-time to make ends meet.
[cpg cn=true]


[OnName num="man_2"]
Wow. That's not good... I don't want to be like that.
[cpg cn=true]


[OnName num="man_1"]
Don't talk to me like that. Tomorrow is my day.
[cpg cn=true]


[BG f="black.ui" time=1000]
[WAIT time=2000]

[FACE method="out" pos="4/7"]


[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
;//【ＢＧ】『空』（昼）******************************************************

[OnName num="masato"]
......
[cpg cn=true]


Whenever I disappear, there's always someone talking about me. Whenever I disappear, someone is always talking about me.
[cpg]

I've been told so many things that I've gotten used to it.
[cpg]

My dad, my mom, my friends.
[cpg]

I don't know what I'm doing at my age... I'm so pathetic... I'm so ashamed.
[cpg]

In the end, nothing has changed for me since then. I've been living the same life over and over again.
[cpg]

[OnName num="masato"]
"(What should I do? I want to go get the rest of my stuff...)"
[cpg cn=true]


Everything is miserable for me. The turning point in my life never came.
[cpg]

--No, it was coming.
[cpg]

That time... that was my first and last chance.
[cpg]

But I became stubborn to protect my small pride, and the result is my current life.
[cpg]

I'm miserable now.
[cpg]

[OnName num="masato"]
I can't wait to go home. I've got a new book... I can't wait to read it.
[cpg cn=true]


Every day, I look at books about appreciating small children, or read them and fantasize about them.
[cpg]

The child in my fantasy is her.
[cpg]

If I had responded differently at that time... like in my fantasy, the little girl would have become my master.
[cpg]

I'm sure she would have become a very beautiful woman now.
[cpg]

Just thinking about it makes me want to die.
[cpg]

I want to die, I want to forget... and then I remember again.
[cpg]

I'm sure I'll keep thinking about her and regretting it until the day I die.
[cpg]

Now, it's just a one-time exciting event that happened in my boring and mundane life, waiting to fade away and disappear.
[cpg]

Time passes, and it goes from being a vivid memory to being part of an untruthful fantasy.
[cpg]


[SE f=se003]
;//【ＳＥ】『荷出しの音』
[WAIT time=1500]

[OnName num="man_1"]
"Oh! Hey! What are you slacking off for?"
[cpg cn=true]


[OnName num="masato"]
"Oh...
[cpg cn=true]


[OnName num="man_1"]
You'll never make it! Come on, help me! The three of us can finish this!
[cpg cn=true]


[OnName num="man_2"]
What the hell, you're adding to my workload...
[cpg cn=true]


[OnName num="masato"]
I'm sorry... really ...... sorry.
[cpg cn=true]


[OnName num="man_1"]
Don't just stand there. Let's go!
[cpg cn=true]



[SE f=se003]
;//【ＳＥ】『荷出しの音』ガタガタ

...... I should have been more honest with myself earlier.
[cpg]

I'm going to regret this until the moment I die.
[cpg]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=3100]

[BG f="black.ui" time=1]


[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ＢＫ

Please, please, please, please. Please, my little angels.
[cpg]

I don't care who you are. So please.
[cpg]

--Somebody, please torment me.
[cpg]


;//フェードアウト

[jump storage="epend.ks" target="*back_title"]

;//ＢＡＤＥＮＤ
;//==============================

*IseSel01_4


[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[jump storage="ep003.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////
;//※合流１
;//※下僕、ペットのどちらを選んでもストーリーは基本共通で進みます。
