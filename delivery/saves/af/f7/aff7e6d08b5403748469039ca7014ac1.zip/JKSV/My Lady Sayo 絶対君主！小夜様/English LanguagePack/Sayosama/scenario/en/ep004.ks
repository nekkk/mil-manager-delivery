*start


;#################################################
*Ep004|Ah, the wonderful M days!
;#################################################

[SCENE id=4]


[stflag jump_scene=0]
[window target=false]

[STOPBGM]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]



[BG f="black.ui" time=1]
[WAIT time=1]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[WAIT time=100]

[BGM f="d1"]
[WAIT time=100]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（朝）******************************************************

Today is the first day of real work.
[cpg]

[OnName num="masato"]
All right, I'm going to work very hard.
[cpg cn=true]

[SE f=se005]
;//【ＳＥ】『歩く』

[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ＢＫ

[STOPBGM]
[SE f=se007]
;//【ＳＥ】『転ぶ』ドタッ

[WAIT time=1000]

[SE f=se052]
;//【ＳＥ】『瓶とか倒す音』

[OnName num="masato"]
"Oh..."
[cpg cn=true]


I've done it.
[cpg]

;//レターボックスin
[FACE method="in" pos="4/7"]

[window target=false]
[transition target={true} rule="amamori3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1_up.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]

[BGM f="h1"]
[WAIT time=100]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（朝）******************************************************

[window target=true]


[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo201"]
[OnName num="sayo"]
That's a very expensive pressure point.
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo202"]
[OnName num="sayo"]
To break it so suddenly... you must have been distracted.
[cpg cn=true]


[OnName num="masato"]
I don't know what to say.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo203"]
[OnName num="sayo"]
Well, I'm not that mad at him because he said he was just spinning his wheels, but...
[cpg cn=true]


I wondered who was following me. I glanced to the side, thinking so.
[cpg]

[FO pos="2/3" time=1000]
[WAIT time=2000]


[OnName num="butler"]
I glanced to the side and saw, "...... (wink bachin*)"
[cpg cn=true]


Tanaka-san! Thank you very much!
[cpg]

[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo204"]
[OnName num="sayo"]
But since you failed...I will punish you accordingly. Is that okay?"
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo205"]
[OnName num="sayo"]
Then get in here.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo206"]
[OnName num="sayo"]
I'm going to humiliate you a lot.
[cpg cn=true]

[STOPBGM]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//レターボックスin
[FACE method="out" pos="4/7"]

;//●ＣＧ（雅人＆小夜・ツボを割ったオシオキ。四つん這いでお尻たたき：ダイニング）ev_05

[BGM f="h1"]


;**【ＣＧ】 ev_05_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1500]

[SE f=se025]
;//【ＳＥ】『スパンキング』

[BG f="white.ui" time=100]
[WAIT time=100]

[CG id=4 index=0 time=100]
[WAIT time=100]


[VOICE f="Sayo207"]
[OnName num="sayo"]
Yes! No! No! That's it!
[cpg cn=true]


[OnName num="masato"]
Oh, my God.
[cpg cn=true]

[SE f=se025]
;//【ＳＥ】『スパンキング』

[BG f="white.ui" time=100]
[WAIT time=100]

[CG id=4 index=0 time=100]
[WAIT time=100]

I'm being spanked by my master on the table as punishment.
[cpg]

It's like a freak show.
[cpg]

It's a different table from the one where Master and Master eat.
[cpg]

[OnName num="masato"]
"Um, why are you dressed like this?
[cpg cn=true]


[VOICE f="Sayo208"]
[OnName num="sayo"]
"Parents discipline their children. "Parents discipline their children, masters discipline their servants. See?
[cpg cn=true]


[OnName num="masato"]
I think what you're saying is true, but why are you dressed like this?
[cpg cn=true]

;**【ＣＧ】 ev_05_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="Sayo209"]
[OnName num="sayo"]
Pencil your bottom.
[cpg cn=true]


[OnName num="masato"]
Why are they spanking me?
[cpg cn=true]


[VOICE f="Sayo210"]
[OnName num="sayo"]
Why do people spank their asses?
[cpg cn=true]


[OnName num="masato"]
I'm not talking about philosophy.
[cpg cn=true]


[VOICE f="Sayo211"]
[OnName num="sayo"]
Spanking is not really a rational thing to do.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo212"]
[OnName num="sayo"]
The humiliation of having to dress like this with your ass exposed in public. The humiliation of being forced to wear this outfit in front of people, plus the act of continuing to spank until you admit you're wrong. The humiliation to the mind, the pain to the body, so that one can admit one's folly. Isn't that great, ass-whipping!
[cpg cn=true]


[OnName num="masato"]
I don't think this act has such a noble meaning...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo213"]
[OnName num="sayo"]
"Shut up."
[cpg cn=true]

[SE f=se025]
;//【ＳＥ】『スパンキング』

[BG f="white.ui" time=100]
[WAIT time=100]

;**【ＣＧ】 ev_05_b ***********************
[CG id=4 index=2 time=100]
;***************************************
[WAIT time=100]

Petching.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo214"]
[OnName num="sayo"]
I'm not going to verbally abuse you. If you don't know what you're talking about, you might as well learn a lesson.
[cpg cn=true]


[SE f=se025]
;//【ＳＥ】『スパンキング』

[BG f="white.ui" time=100]
[WAIT time=100]

[CG id=4 index=2 time=100]
[WAIT time=100]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo215"]
[OnName num="sayo"]
How's that? Are you feeling sorry for yourself?
[cpg cn=true]


[OnName num="masato"]
Yes, I'm sorry...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo216"]
[OnName num="sayo"]
You're lying!
[cpg cn=true]


[SE f=se025]
;//【ＳＥ】『スパンキング』

[BG f="white.ui" time=100]
[WAIT time=100]

[CG id=4 index=2 time=100]
[WAIT time=100]

[OnName num="masato"]
Yikes!
[cpg cn=true]


And so the punishment continued...
[cpg]


;//ＢＫ

[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=2100]
[STOPBGM]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]




[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=2000]

[BGM f="sl"]
;//【ＢＧ】『空』（夕方）******************************************************

[SE f=se005]
;//【ＳＥ】『歩く』

[WAIT time=1500]

[window target=true]

[VOICE f="Sayo217"]
[OnName num="sayo"]
Oh.
[cpg cn=true]


[VOICE f="Sayo218"]
[OnName num="sayo"]
What an auspicious way to greet me.
[cpg cn=true]


[OnName num="masato"]
Your late return had us worried.
[cpg cn=true]


[VOICE f="Sayo219"]
[OnName num="sayo"]
You're not going to get anything by saying that.
[cpg cn=true]


[OnName num="masato"]
I know.
[cpg cn=true]


[VOICE f="Sayo220"]
[OnName num="sayo"]
I know. Can I come by your room for a minute?
[cpg cn=true]


[OnName num="masato"]
Yes, of course, but...
[cpg cn=true]


[VOICE f="Sayo221"]
[OnName num="sayo"]
I just have to make sure everything's in order.
[cpg cn=true]


I wonder if they're going to check my room to see if I'm doing well here.
[cpg]


;//ev_18をもう一度表示

[SE f=se005]
;//【ＳＥ】『歩く』

[BG f="black.ui" time=1000]
[WAIT time=2000]

[stopse g=2]
;//通常se

;**【ＣＧ】 ev_18_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=2000]

[OnName num="masato"]
Oh, um... master.
[cpg cn=true]


[VOICE f="Sayo222"]
[OnName num="sayo"]
It's the same as the other day. Let's try a pot instead of a teapot this time, shall we?
[cpg cn=true]


[OnName num="masato"]
You're kidding, right?
[cpg cn=true]


[VOICE f="Sayo223"]
[OnName num="sayo"]
What?　You're thinking of something else.
[cpg cn=true]


Master's eyes were serious. I'm glad I wore a thicker inner layer than last time...
[cpg]


[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse
;//ＢＫ

[jump storage="ep005.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
