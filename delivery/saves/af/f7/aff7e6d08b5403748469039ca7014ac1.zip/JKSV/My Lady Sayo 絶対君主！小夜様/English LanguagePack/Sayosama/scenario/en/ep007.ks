*start

;#################################################
*Ep007|Milk Tea
;#################################################

[SCENE id=7]


[stflag jump_scene=0]
[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]

[SE f=se018]
;//【ＳＥ】『鳥の鳴き声』


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1500]


[BGM f="d1"]
;//【ＢＧ】『使用人の部屋（雅人の部屋）』（朝）******************************************************

[window target=true]

[OnName num="masato"]
"Mmmmmmmmmm..."
[cpg cn=true]



It's already been a few months since I came to this house.
[cpg]

When I first came here, there were many things I didn't understand, and I had to learn a lot of things from them.
[cpg]


[OnName num="masato"]
All right, let's work hard today.
[cpg cn=true]



[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=2000]

[BG f="b_01_1.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『豪邸、廊下』（朝）******************************************************


[window target=true]


[OnName num="maid_A"]
Masato, good morning.
[cpg cn=true]


[OnName num="butler"]
"Good morning."
[cpg cn=true]


[OnName num="masato"]
Good morning.
[cpg cn=true]


As I walked out into the hallway, I met the maid and Mr. Tanaka and exchanged greetings with them. It looks like I'll be able to start my morning work without delay today.
[cpg]


[OnName num="butler"]
Now, the lady is waiting for us. Let's go.
[cpg cn=true]


[OnName num="maid_A"]
Yes?
[cpg cn=true]


[OnName num="masato"]
Yes!
[cpg cn=true]



Now that I feel like I'm finally a part of this community, I can't let my guard down.
[cpg]

[window target=false]

[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ＢＫ



[BG f="b_04_1.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『小夜の部屋』（朝）******************************************************
;//※小夜の部屋にはベランダというかテラスがある。そこでお茶を楽しむ。

[window target=true]


[OnName num="masato"]
Good morning, Master.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo328"]
[OnName num="sayo"]
"Good morning."
[cpg cn=true]



When I entered the room, Master was sitting on the terrace in a chair made of white.
[cpg]

It is her daily routine to enjoy her morning tea time here before going to the school.
[cpg]

Of course, she has plenty of time to spare so as not to be late.
[cpg]

Master wakes up well on his own without us waking him up. But sometimes I want to wake him up...
[cpg]


[OnName num="maid_A"]
"Miss, what would you like for tea this morning?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo329"]
[OnName num="sayo"]
Well, I'd like some milk tea, my new favorite.
[cpg cn=true]


[OnName num="maid_A"]
Yes, ma'am.
[cpg cn=true]



Most of the serving is done by the maids, so Tanaka-san and I often just stand back.
[cpg]

But Tanaka-san...
[cpg]


[FG f="CHA01_p2_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo330"]
[OnName num="sayo"]
"What about the world situation..."
[cpg cn=true]


[OnName num="butler"]
"Well, now the Middle East is also... well, well, well..."
[cpg cn=true]

He was talking to his master firmly. The two of them are always talking about something intellectual.
[cpg]

I don't know what it is, so it sounds like a spell or something...
[cpg]

I feel a little alienated.
[cpg]

I need to learn a little more so that I can be of more use to my master...!
[cpg]

[SE f=se090]
;//【ＳＥ】『紅茶を混ぜる』

[WAIT time=2000]


[OnName num="maid_A"]
Thank you for waiting.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo331"]
[OnName num="sayo"]
Thank you.
[cpg cn=true]



[SE f=se041]
;//【ＳＥ】『カップの音』カチャカチャ

[WAIT time=1500]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo332"]
[OnName num="sayo"]
Today's tea is delicious.
[cpg cn=true]


[OnName num="maid_A"]
Thank you, my lady.
[cpg cn=true]


[OnName num="masato"]
I want to be praised too...
[cpg cn=true]

At this time of the morning, I have no role to play.
[cpg]

No, maybe not only at this time of the day. I'm always in the shadows... and I don't seem to be of much use...
[cpg]


[OnName num="maid_A"]
"Miss, would you like a refill?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo333"]
[OnName num="sayo"]
...... There's still time... yes. I'll take it.
[cpg cn=true]


[OnName num="maid_A"]
Yes, thank you.
[cpg cn=true]


The maid was in a good mood.
[cpg]


The maid is in a good mood, complimented on the quality of her tea, and another cup of tea... that's a good thing. Damn it.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo334"]
[OnName num="sayo"]
"......?"
[cpg cn=true]


[OnName num="masato"]
"Ha...!"
[cpg cn=true]


He noticed that I was giving him a hot look, and he turned his face away.
[cpg]

I was embarrassed to realize that I was still jealous of the maids after all these years.
[cpg]


[OnName num="masato"]
(What am I thinking? (What am I thinking? I'll just stay quiet...)"
[cpg cn=true]


It's been a few months since I came to this house. I've been in this mansion for a few months now, and I've experienced as much as I can at this time of the morning.
[cpg]

I know that I'm not going to be there, so the best thing for me to do is to be quiet and watch my master enjoy his tea time.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo335"]
[OnName num="sayo"]
"Hey, servant. Come here."
[cpg cn=true]


[OnName num="masato"]
"Huh...yes?
[cpg cn=true]


[SE f=se042]
;//【ＳＥ】『早足』

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1500]

;//レターボックスin
[FACE method="slidein" pos="4/7"]

[BG f="b_04_1_up.ui" time=1000]

[WAIT time=2000]


When he was called, he reflexively moved to his master's side. That's exactly what a dog would do.
[cpg]

And I, being a dog, wondered why I was called... My heart throbbed with anticipation and anxiety.
[cpg]

[OnName num="masato"]
(Ugh...did I offend him by staring at him earlier?)"
[cpg cn=true]



If that happens, it's not good.
[cpg]

If so, it's not good. As well as being angry, I've disturbed my master's moment of relaxation.
[cpg]

It's a huge failure as a servant.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo336"]
[OnName num="sayo"]
There's ...... milk tea, you know."
[cpg cn=true]


[OnName num="masato"]
"Yes? That's right.
[cpg cn=true]



The master suddenly started talking about tea. The one she is drinking right now is also milk tea.
[cpg]

I can't keep up with you when you talk about tea leaves....
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo337"]
[OnName num="sayo"]
"I wonder if the milk in this could be something else... tasty? What do you think?"
[cpg cn=true]


[OnName num="masato"]
"Well, maybe goat's milk, for example? It's a little stinky, but it's a different experience...
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo338"]
[OnName num="sayo"]
"That's right. It's a good quality product, so of course it's delicious, but sometimes you want to enjoy a different taste..."
[cpg cn=true]



It was a question I hadn't expected, so I answered it without thinking too much.
[cpg]

The master seemed to be saying that he wanted to drink a different flavor of milk tea.
[cpg]

However, even if it was a different flavor, I hadn't prepared anything... When I tried to look at Mr. Tanaka, I was troubled by what to do.
[cpg]


[FG f="CHA01_p4_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo339"]
[OnName num="sayo"]
"Can you pour me some milk?"
[cpg cn=true]


[OnName num="masato"]
"Yes, I'm home!"
[cpg cn=true]



Not knowing what to do, I picked up the small bottle of milk on the table.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo340"]
[OnName num="sayo"]
No, I don't. You said you wanted to enjoy a different taste.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo341"]
[OnName num="sayo"]
Is there only one thing that comes to your mind when you think of milk?
[cpg cn=true]


[OnName num="masato"]
"......"
[cpg cn=true]


I don't think so, but... no, definitely not the first thing that comes to mind.
[cpg]

However, I am being tested. I was being tested to see how interesting I could be as a servant.
[cpg]

[SE f=se006]
;//【ＳＥ】『走る』

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ＢＫ

;//レターボックスout
[FACE method="out" pos="4/7"]
[WAIT time=1]


;//●ＣＧ（小夜・ティータイムのご主人様：小夜の部屋）ev_16

;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1500]

Then I came back from the kitchen.
[cpg]

[VOICE f="Sayo342"]
[OnName num="sayo"]
"What's this?"
[cpg cn=true]


[OnName num="masato"]
"Avocados!　It's called the milk of the forest.
[cpg cn=true]



It sounds like a monk's quip, but I hope it satisfies him.
[cpg]

;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo343"]
[OnName num="sayo"]
Butter from the forest is the correct answer. Butter from the forest is correct. Oysters are called the milk of the sea, so it's mixed in with that.
[cpg cn=true]

[SE f=se014]
;//【ＳＥ】『衝撃』


[OnName num="masato"]
Oh, no.
[cpg cn=true]

;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo344"]
[OnName num="sayo"]
Oh, no. You thought avocado and tea went well together, so have some.
[cpg cn=true]


[OnName num="masato"]
Well, that's .......
[cpg cn=true]


[VOICE f="Sayo345"]
[OnName num="sayo"]
Or would you like some sea milk?
[cpg cn=true]


[OnName num="masato"]
No!　I want forest milk!
[cpg cn=true]


[VOICE f="Sayo346"]
[OnName num="sayo"]
Butter from the forest. Whatever you like.
[cpg cn=true]


[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=2000]
[WAIT time=3000]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=500]

;//ＢＫ

As it turns out, avocado does not go well with tea.
[cpg]

I'm pretty proud of myself for not throwing up. From now on, I'll try not to make unnecessary accusations. ......
[cpg]


;//少し時間を置く演出

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="ep008.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////
