*start

;//ここでルート分岐します。【奉公ルート】【比翼連理ルート】は下記のシナリオに進んで途中で分岐。

;//【遠き存在ルート】の場合は【合流B】へ

;#################################################
*Ep015|Me
;#################################################

[SCENE id=15]


[window target=false]


[stflag jump_scene=0]
;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]


[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep002で発生	ジャンプしてきた場合奉仕ルートで固定
[stflag gohome_flag=1]
[stflag pets_flag=0]
;//ep014で発生	ジャンプしてきた場合【遠き存在END】へのフラグで固定
[stflag service_flag=0]
[stflag hiyokurenri_flag=0]
[stflag existence_flag=1]
[endif]


;//【遠き存在ルート】の場合は【合流B】へ
[if exp={getFlagValue("existence_flag") == 1 }]
[jump target="*root_existence"]
[endif]


[STOPBGM]

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BGM f="se"]
;//【ＢＧ】『豪邸、ダイニング』（昼）******************************************************

[window target=true]


It was a week before her wedding.
[cpg]

In the dining room at lunch time, there was a father who was worried about his daughter.
[cpg]


[SE f=se037]
;//【ＳＥ】『食事音』
[WAIT time=1500]

[OnName num="the_master"]
"How is she these days?
[cpg cn=true]


[OnName num="butler"]
Yes, she's very calm. Thanks to Masato-dono.
[cpg cn=true]


[OnName num="the_master"]
"...... Him. To be honest, the rumors I hear from the servants don't give me a very good impression of him...?
[cpg cn=true]


[OnName num="butler"]
It is true that, generally speaking, yes. But, sir, you promised to let the young lady do as she pleases..."
[cpg cn=true]


[OnName num="the_master"]
"Yes, I know. I'm not trying to do anything about it.
[cpg cn=true]


[OnName num="the_master"]
And it's my fault. You can thank him, but you have no right to be angry with me.
[cpg cn=true]


[OnName num="the_master"]
It's all my fault... that I'm in this situation.
[cpg cn=true]


[OnName num="butler"]
"Sir..."
[cpg cn=true]

[STOPBGM]

[FACE method="white_in" pos="3/5"]


[OnName num="the_master"]
"..............., yeah, yeah, yeah, yeah, that fucking GACAAHHHHHHHHHH! What did you do to my daughter before she was married? How dare you drag her around like a pridercar? ！！！！！"
[cpg cn=true]

[SE f=se084]
;//【ＳＥ】『チーン』


[OnName num="butler"]
"Sir, it's leaking, sir. It's leaking.
[cpg cn=true]

[BGM f="se"]

[FACE method="white_out" pos="3/5"]


[OnName num="the_master"]
Huh, huh. ...... No, I'm sorry. I'm a little distracted.
[cpg cn=true]


[OnName num="the_master"]
Huh. ......
[cpg cn=true]


[OnName num="the_master"]
Tanaka.
[cpg cn=true]


[OnName num="butler"]
Okay.
[cpg cn=true]


[OnName num="the_master"]
What am I supposed to do?
[cpg cn=true]


[OnName num="butler"]
That's a first. I've never had a husband ask me a question like that.
[cpg cn=true]


[OnName num="the_master"]
Well, I don't know what I'm supposed to do.
[cpg cn=true]




[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


;//[BGM f="sl"]
;//【ＢＧ】『豪邸、廊下』（昼）******************************************************

[window target=true]


[OnName num="masato"]
"........."
[cpg cn=true]


Wow, this is a very difficult atmosphere to leave.
[cpg]

I mean, didn't you say you were going to drag me around with you?
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sayo693"]
[OnName num="sayo"]
I'm coming. Make up your mind."
[cpg cn=true]


[OnName num="masato"]
"Oh, yes! I'll be fine!
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo694"]
[OnName num="sayo"]
Are you sure?
[cpg cn=true]


[OnName num="masato"]
...... Yeah, of course.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo695"]
[OnName num="sayo"]
...... Okay. I won't say anything else.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo696"]
[OnName num="sayo"]
Let's just hope it works.
[cpg cn=true]


[OnName num="masato"]
Okay.
[cpg cn=true]



[SE f=se016]
;//【ＳＥ】『ドアを開ける』ガチャ

[STOPBGM]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[VOICE f="Sayo697"]
[OnName num="sayo"]
Father! I need to talk to you!
[cpg cn=true]



;//ＢＫ

--The day of reckoning came quickly.
[cpg]



[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]

[BGM f="sl"]
[WAIT time=100]
;//【ＢＧ】『分岐路のある道』（昼）******************************************************

[SE f=se004]
;//【ＳＥ】『喧騒』ガヤガヤ

[window target=true]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="fatty_man"]
The day of reckoning came quickly. "Well, Saya-chan has become a very pretty girl, hasn't she? You were so cute when you were a child, though. How long has it been since we've seen each other?
[cpg cn=true]


[OnName num="the_master"]
"Well, it's been quite a while, I believe..."
[cpg cn=true]


[OnName num="fatty_man"]
That's right. I think it's been about ten years! Well, I'm getting old, too. Saya-chan, do you remember your uncle?
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

[VOICE f="Sayo698"]
[OnName num="sayo"]
Yes, of course I do. Yes, of course. Mr. Takayama is my benefactor and I have never forgotten him.
[cpg cn=true]


[OnName num="fatty_man"]
Haha, that's nice of you to say.
[cpg cn=true]


The meeting before the wedding.
[cpg]

Saya's father and Saya were married to the president of a large company, who had helped them when the company was in trouble and could not resist.
[cpg]

[OnName num="fatty_man"]
He is also a terrible person, he won't let me see Saya at all. I heard that you were so overprotective of her that you locked her up in your house.
[cpg cn=true]


[OnName num="the_master"]
"Hahaha... well, yes. I'm so embarrassed.
[cpg cn=true]


[OnName num="fatty_man"]
You can't do that. You can't do that, no matter how important your daughter is, it would be a pity.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo699"]
[OnName num="sayo"]
Takayama-san, that's not true. My father was thinking of me when he did that.
[cpg cn=true]


[OnName num="fatty_man"]
"Huh, you're a really good young lady. No, no, it's not that I'm taking refuge in you. Well, thanks to you, I'll be able to marry Sayo-chan with a pure body! Hahahahaha."
[cpg cn=true]


Without knowing anything about it, the other man was in a good mood. It is true that there are things I have had to endure in my life for the sake of this man. My cramped life... that's over now.
[cpg]

[STOPBGM]

[OnName num="the_master"]
"Mr. Takayama, I'd like to talk to you about that..."
[cpg cn=true]


[OnName num="fatty_man"]
"What?"
[cpg cn=true]


[OnName num="the_master"]
"Would you please reconsider marrying my daughter?"
[cpg cn=true]


[BGM f="se"]

The man was furious. The man was furious. He called me out on how much I owed him, how shameless I was, and how I had promised him that.
[cpg]

[OnName num="the_master"]
"No, I have my reasons.
[cpg cn=true]


[OnName num="fatty_man"]
"Reasons? Ha, then tell me. I won't forgive you if it's a trivial reason.
[cpg cn=true]


[OnName num="the_master"]
Saya...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo700"]
[OnName num="sayo"]
Yes, Father.
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]


Saya stood up and let the man put his hand on her chest.
[cpg]

[STOPBGM]

[OnName num="fatty_man"]
"What about -----?"
[cpg cn=true]


The man's eyes widened like saucers and his mouth puckered up like a goldfish.
[cpg]

The man's eyes widened like saucers and his mouth puckered up like a goldfish's. The man looked at Saya's face as if asking for an explanation.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]

[BGM f="sl"]
[WAIT time=100]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[SE f=se016]
;//【ＳＥ】『扉を開ける』ガチャ

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="5/3"time=800]


[window target=true]


[OnName num="butler_B"]
"Welcome back.
[cpg cn=true]


[OnName num="maid_B"]
"Welcome back."
[cpg cn=true]


The servants greeted the two as they returned to the villa.
[cpg]

However, there was a surprising person there.
[cpg]


[SE f=se006]
;//【ＳＥ】『階段を駆け下りる』タッタッタ

[move from="5/3" to="4/5" ease="easeInOutSine" time=2000]

[move from="2/3" to="2/5" ease="easeInOutSine" time=2000]


[VOICE f="Sayo701"]
[OnName num="sayo"]
Father!
[cpg cn=true]


[OnName num="the_master"]
Saya, why are you here? I told you to hide yourself at once.
[cpg cn=true]


[FACE method="change_4" pos="4/5"]
[VOICE f="Sayo702"]
[OnName num="sayo"]
I'm sorry, but...
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Sayo703"]
[OnName num="sayo"]
"........."
[cpg cn=true]


Another Saya appeared. He then turned his worried eyes to Saya, who was standing next to his father.
[cpg]

Then to her father. Saya turned her anxious eyes to them.
[cpg]

[FACE method="change_3" pos="4/5"]
[VOICE f="Sayo704"]
[OnName num="sayo"]
"So, how...did it go?"
[cpg cn=true]


The father could not answer the question. Instead, the other Saya answered.
[cpg]

[FACE method="change_1" pos="2/5"]
[VOICE f="Sayo705"]
[OnName num="sayo"]
"I was..."
[cpg cn=true]


;//ＢＫ


[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/5" time=1]
[FO pos="4/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


[BGM f="se"]
;//【ＢＧ】『豪邸、ダイニング』（昼）******************************************************

[SE f=se048]
;//【ＳＥ】『テーブルを叩く』
[WAIT time=1100]


[OnName num="the_master"]
"Nonsense! Of course you can't do that!
[cpg cn=true]


[OnName num="masato"]
No, it is possible. Of course it is difficult and impossible to do it normally... but with the Master's help, it can be done.
[cpg cn=true]


[OnName num="butler"]
"Masato-dono..."
[cpg cn=true]


[OnName num="the_master"]
But what are you going to do? Even if we can make this happen, it will be at your expense.
[cpg cn=true]


[OnName num="the_master"]
It is true that my daughter is important to me. But I can't sacrifice others because of it.
[cpg cn=true]


[OnName num="masato"]
Sacrifice? No, sir. Even a master with so many servants doesn't understand that, does he?
[cpg cn=true]


[OnName num="the_master"]
What?
[cpg cn=true]


[OnName num="masato"]
"Every drop of blood, every piece of flesh I give, I give it all. It always scorches my heart to the point where I want it all to melt and disappear.
[cpg cn=true]

[OnName num="masato"]
For the sake of those I love... for the sake of those I love... for the sake of those I love... for the sake of those I love... for the sake of those I love... for the sake of those I love...
[cpg cn=true]


[OnName num="the_master"]
"......"
[cpg cn=true]


[OnName num="masato"]
It's not a sacrifice. This is what I would like to do on my own. At the same time, it's not a bad deal for the husbands either... so I want you on board.
[cpg cn=true]


[OnName num="the_master"]
...... Are you sure you want to do this?
[cpg cn=true]


[OnName num="masato"]
Yes. It's just for my own satisfaction, sir.
[cpg cn=true]


;//ＢＫ

[STOPBGM]

[window target=false]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]

[BGM f="h1"]
;//【ＢＧ】『分岐路のある道』（昼）******************************************************

[SE f=se048]
;//【ＳＥ】『椅子から転げる』ガタンッ
[WAIT time=500]

[window target=true]

[OnName num="fatty_man"]
What the...?
[cpg cn=true]


[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sayo706"]
[OnName num="sayo"]
Cousin. You don't have to be so surprised, do you?
[cpg cn=true]


[OnName num="the_master"]
It is understandable that you are surprised. My daughter... was actually a man.
[cpg cn=true]


[OnName num="fatty_man"]
What the hell?
[cpg cn=true]


Everything up to this point, and even from here on, was going according to the plan I had devised.
[cpg]

You have to make up a lie, but you have to explain it in a way that the other person will believe it, and make the lie true.
[cpg]

[OnName num="the_master"]
"I was definitely raised as a woman in terms of appearance, personality and behavior..."
[cpg cn=true]


The doctor had said she was a woman, and she was aware of it. The doctor said she was a woman, and she was aware of it, but it turned out that she was a man later on.
[cpg]

It's hard to believe, but I have no choice but to push it through.
[cpg]

[OnName num="fatty_man"]
"No, that's ridiculous! I've seen you naked before when I was little! Naked!"
[cpg cn=true]


[OnName num="the_master"]
I've seen you naked when you were little! Oh, no!
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Sayo707"]
[OnName num="sayo"]
(Sir, please calm down. (Sir, please calm down. I'll have Mr. Tanaka check it out later and depending on the results, we'll have to do something about it.)
[cpg cn=true]


[OnName num="the_master"]
That's because it was small, yeah.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo708"]
[OnName num="sayo"]
That's true. You probably didn't notice it when you were a child.
[cpg cn=true]


It's normal to not believe something like that when it's said out of the blue. But he is right in front of me.
[cpg]

It was Masato who was there as Saya, but there was no way he could know that.
[cpg]

For his master's sake and his own... Masato offered himself to be a double, and using Misanagi's power, he underwent plastic surgery to become exactly like Saya.
[cpg]

Although there were differences in height and structure, Masato was originally neutral and the man he was marrying hadn't seen Saya for years, so it was possible to deceive him.
[cpg]

The woman he was supposed to marry was a man. Of course, the other party would be angry, and if the engagement was broken, he might make many demands in return.
[cpg]

Even so, the Master... he really wanted to prevent her from marrying this man.
[cpg]

The husband was also worried about the survival of his company and his employees, but he made a decision as a father thinking of his daughter.
[cpg]

[OnName num="the_master"]
"Mr. Takayama, would you please reconsider your marriage proposal?
[cpg cn=true]


[OnName num="fatty_man"]
"Well, that's..."
[cpg cn=true]


The other man broke out in a waterfall of sweat. And .......
[cpg]

[STOPBGM]

[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

;//ここで展開が変化。

;//【奉公END】フラグを得ている場合は下記の流れ、【比翼連理END】フラグを得ている場合は【合流C】へ
[if exp={getFlagValue("service_flg") == 1 }]
[jump target="*root_service"]
[endif]

[if exp={getFlagValue("hiyokurenri_flag") == 1 }]
[jump target="*root_hiyokurenri"]
[endif]


*root_service|service

[SCENE id=16]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

[BGM f="se"]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[OnName num="masato"]
I'm going to marry into Takayama-sama's family.
[cpg cn=true]


I called out as gently as I could.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo709"]
[OnName num="sayo"]
"............... Yes."
[cpg cn=true]


[OnName num="masato"]
"I'm sorry. I thought I had gotten to a pretty good place, but... haha.
[cpg cn=true]


In the end, the sexy marriage partner did not change his answer even when confronted with the fact that Saya was a man.
[cpg]

In response to Masato's words, Saya turned her head. I don't know what kind of expression she has on her face.
[cpg]

[OnName num="the_master"]
"Come on, Sayo. Now, Saya, get ready and get out of here. Tanaka, I'm counting on you."
[cpg cn=true]


[OnName num="butler"]
"Yes, sir."
[cpg cn=true]


There can't be two of the same person. If they find out about this, the whole operation will be ruined.
[cpg]

That's why she has to go into hiding and live in seclusion.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo710"]
[OnName num="sayo"]
"........."
[cpg cn=true]


At the urging of the Master and Mr. Tanaka, the Master and the butler went upstairs to make the will-less doll move.
[cpg]

[OnName num="masato"]
"Master."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Sayo711"]
[OnName num="sayo"]
"......"
[cpg cn=true]


[OnName num="masato"]
"Please, take care."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo712"]
[OnName num="sayo"]
"......, you too..."
[cpg cn=true]


We exchanged parting words.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』


[move from="2/3" to="5/3" ease="easeInOutSine" time=2000]
[wait time=2000]

[OnName num="the_master"]
"I'm so sorry..."
[cpg cn=true]


[OnName num="masato"]
"Sir. Don't worry about it I did it on my own.
[cpg cn=true]


In the end, Saya (Masato) ended up marrying the other man as planned.
[cpg]

Takayama, who was a lover, did not break off the engagement even when he found out that the other man was a man.
[cpg]

[OnName num="fatty_man"]
He said, "He's a man, but he looks like a woman... I can't stand this mysterious charm.
[cpg cn=true]


That's what she said.
[cpg]

Since he is a man, he won't get married, but eventually he might get her to change her gender and register.
[cpg]

In terms of the purpose of the operation, it was a success. It was a success in terms of the purpose of the operation.
[cpg]

Even if they end up getting married, the real Saya will be safe and sound, and considering the company, she is in the best position.
[cpg]

If the other man would give up, Masato could come back, although he might make various demands in exchange for breaking off the engagement.
[cpg]

It was one of those things.
[cpg]

Either way, it would be better for him than marrying her off, which is why he agreed to the proposal.
[cpg]

For Masato, it was all risk, but that didn't matter.
[cpg]

It was all for the sake of the master....
[cpg]

[STOPBGM]

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

[FO pos="5/3" time=1000]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]


[BGM f="se"]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

[window target=true]


Time passed, and on the day Saya (Masato) was leaving the mansion.
[cpg]

[OnName num="butler"]
"I'll send you home.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo713"]
[OnName num="sayo"]
"Tanaka-san. Thank you. ......
[cpg cn=true]


From now on, I will live in that man's house.
[cpg]


[FO pos="2/3" time=1000]

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]

;//【ＢＧ】『空』（昼）******************************************************

[window target=true]


I put on my fancy clothes and got into the car that was prepared for me. It's a good idea to have a good idea of what you're looking for.
[cpg]

I naturally looked for my master. That's not true. That shouldn't happen.
[cpg]

She would not be coming here. I've already said goodbye to her. Now all I have to do is serve my master to the best of my ability.
[cpg]

The car carrying me left quietly...
[cpg]


[SE f=se073]
;//【ＳＥ】『車が走る』ブルルルルンッ

;//ＢＫ
;//レターボックスin
[FACE method="feadin" pos="4/7"]

[wait time=2500]


I don't really like men. But I have to act.
[cpg]

That's my responsibility for being married to this man.
[cpg]

But for me, there is only one master... her. Only Saya-sama. This is my service for her.
[cpg]

That can't be overturned. There's no way I can change that.
[cpg]

[OnName num="fatty_man"]
"Saya-chan, from now on, you'll always be mine and mine alone..."
[cpg cn=true]


[VOICE f="Sayo714"]
[OnName num="sayo"]
"Yes."
[cpg cn=true]


But the truth is, only you know the truth...
[cpg]

;//レターボックスout
[FACE method="feadout" pos="4/7"]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ

[jump storage="epend.ks" target="*start"]

;//【奉仕ルート】END



;/////////////////////////////////////////////////////////////////////////////////
;//奉仕ルートが終わりスタッフロールが流れた後、条件達成時に追加のエンディング。
;//２箇所ある【ただいまEND】へのフラグを得ている場合ストーリーが進行します。

*go_home|...I'm back.

[SCENE id=19]


[STOPBGM]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]

[window target=false]

;//【…ただいま。ルート】

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ



[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="se"]
;//【ＢＧ】『空』（昼）******************************************************
;//※ここ小夜家の豪邸玄関を改造してなんとかならないかな？

;//レターボックスin
[FACE method="feadin_up" pos="4/7"]
[wait time=2000]


[window target=true]

The mansion of the Takayama family, where Masato got married.
[cpg]

In the long corridor leading from the entrance, Masato put three fingers on the floor and bowed his head deeply.
[cpg]

;//[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo715"]
[OnName num="sayo"]
Thank you very much for your support over the past six years.
[cpg cn=true]

[SE f=se005]
;//【ＳＥ】『歩く』

The man said nothing, but gave him a glance and walked up the stairs. The man was the person Masato had been serving for the past six years.
[cpg]

Even though he had been forced to do so, even though his purpose was personal gain, he had been her companion for six years.
[cpg]

He should have said something. But the man didn't say anything and looked down at Masato as if he were something dirty. To him, Masato had no value at all.
[cpg]

It was probably better that he had come to see her off.
[cpg]

It was just the other day that the man said he was going to break off the engagement. He didn't give a clear reason, but I'm sure he was simply bored.
[cpg]

Masato had no reason to refuse the decision, but things proceeded without hesitation, and in no time at all, he was kicked out of the house.
[cpg]

The man was going to remarry some (real) girl. It was heartbreaking to think that his daughter would be the next victim.
[cpg]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo716"]
[OnName num="sayo"]
Please excuse me at ......."
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』


After the greeting, Masato picked up the cane he had left on the floor and stood up. He walked unsteadily to the exit.
[cpg]

The maids of honor standing at either end of the long corridor gazed at the figure of their former mistress.
[cpg]

Some of them had spent many years together, while others were still young. But all of them had a tense expression on their faces.
[cpg]

None of them had ever heard the details of why Masato had married her. However, after six years of being together, they knew most of the details.
[cpg]

I knew that Masato was a man, and I knew why he came here....
[cpg]

That's why they all have that look on their faces. Oroshiya...that's what I hear.
[cpg]

[OnName num="maid_1"]
"...... Oh, um! Sayo-sama! I'll carry your luggage for you!"
[cpg cn=true]


As the master disappeared into the back of the second floor, a young maid came running out of the line.
[cpg]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo717"]
[OnName num="sayo"]
Thank you. But you don't have to worry about it. I'm fine.
[cpg cn=true]


[OnName num="maid_1"]
'No, no! I'll help you! Please let me!"
[cpg cn=true]


With a tearful expression on her face, she desperately appealed to me. I'm sure she had her reasons.
[cpg]

She must have had her own reasons, but it was a new life of uncertainty, not knowing what was right or wrong. Masato had been kind to her. She was not the only one.
[cpg]

Everyone who was indebted to him, everyone who was close to him... everyone loved him as a good wife.
[cpg]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo718"]
[OnName num="sayo"]
Thank you. Now, please walk me to the gate."
[cpg cn=true]


[OnName num="maid_1"]
Yes!
[cpg cn=true]




[OnName num="maid_head"]
Mistress. I've arranged a cab for you. Would you like to have a cup of tea away from here until we arrive?
[cpg cn=true]


;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo719"]
[OnName num="sayo"]
I'm sorry, Kirie-san but I'm happy to wait for you at the gate.
[cpg cn=true]


[OnName num="maid_head"]
"I see. Well then, Mistress, I'll join you.
[cpg cn=true]


;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo720"]
[OnName num="sayo"]
"I'm sorry to make you, the head maid, do such a thing. Besides, I don't belong to this family anymore..."
[cpg cn=true]


[OnName num="maid_head"]
"You will be our wife until we leave this house."
[cpg cn=true]


;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo721"]
[OnName num="sayo"]
Thank you, ......."
[cpg cn=true]

[SE f=se005]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//レターボックスout
[FACE method="out" pos="4/7"]
[wait time=2000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se012]
;//【ＳＥ】『門が開く』ギギギ

[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

;//【ＢＧ】『空』（昼）******************************************************

[window target=true]


Masato walked out the front door, supported by the two men, and headed for the gate. It had been six years since he had passed through this large gate and arrived here. When I think of the past, I get nostalgic.
[cpg]

I looked back and saw all the maids seeing me off. I bowed deeply. Masato returned the bow as well.
[cpg]

We spent some time waiting for the cab. They didn't talk much, but they didn't say much either.
[cpg]


[SE f=se074]
;//【ＳＥ】『クラクション』パッパー

[OnName num="maid_1"]
"Oh, it looks like he's here!
[cpg cn=true]


One of the cars honked its horn and came towards us. The young maid thought it was a cab.
[cpg]

But the car was not a cab, even from the exterior.
[cpg]

[OnName num="maid_1"]
"Oh, that...?"
[cpg cn=true]


The young maid was confused, and next to her a smile appeared on Masato's face.
[cpg]

;//[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo722"]
[OnName num="sayo"]
"...... Kirie-san."
[cpg cn=true]


[OnName num="maid_head"]
"Yes, what is it, ma'am?"
[cpg cn=true]


;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo723"]
[OnName num="sayo"]
Can you cancel the cab you arranged for me?
[cpg cn=true]


[OnName num="maid_head"]
'Well, I don't know... it's already here... I don't know... we're already here... Wouldn't it be a pity for the driver if he had to come all the way here and ask us to leave?
[cpg cn=true]


;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo724"]
[OnName num="sayo"]
"Xu Xu. You're right, that's true.
[cpg cn=true]



[SE f=se075]
;//【ＳＥ】『ブレーキ』キキッ

The car came to a stop with the sound of brakes, and the driver emerged from inside and bowed deeply. Masato turned to Kirie and the young maidservant and thanked them again.
[cpg]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo725"]
[OnName num="sayo"]
Thank you for everything.
[cpg cn=true]


[OnName num="maid_head"]
It has been an honor to serve you, Mistress.
[cpg cn=true]


[OnName num="maid_1"]
Saya-sama... please, please take care of yourself!
[cpg cn=true]


Saying goodbye, Masato got into the car with the driver's urging. The gas pedal was depressed, the tires rotated, and the car started driving towards its destination.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//レターボックスin
[FACE method="in" pos="4/7"]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『空』（昼）******************************************************
;//※カットインでも良いので車内の風景が欲しいかも。



The car was driving at a reasonable speed, but perhaps because it was a luxury car, the interior was quiet enough for them to talk calmly.
[cpg]

;//[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo726"]
[OnName num="sayo"]
"...... Tanaka-san. Where to?"
[cpg cn=true]


[OnName num="butler"]
What do you mean, "where?"
[cpg cn=true]


;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo727"]
[OnName num="sayo"]
I'm talking about your destination.
[cpg cn=true]


[OnName num="butler"]
Oh, I'm sorry about that. I'm sorry about that. No matter where you say you're going, there's only one place you should go.
[cpg cn=true]


Masato chuckled again.
[cpg]

The car slowed down and came to a stop. Masato got out of the car with the help of Tanaka, the butler, and found himself standing in a familiar place.
[cpg]

It was a place so important to him that he could easily remember the first time he had passed through this gate more than six years ago.
[cpg]

A mansion that has remained unchanged since that time. Masato was about to burst into tears.
[cpg]

[OnName num="butler"]
Please come in.
[cpg cn=true]


;//[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo728"]
[OnName num="sayo"]
"Thank you."
[cpg cn=true]



[SE f=se012]
;//【ＳＥ】『扉を開ける』ギギギ

[STOPBGM]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//レターボックスout
[FACE method="out" pos="4/7"]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『豪邸、ホール』（昼）******************************************************

Tanaka helped him open the door, which had become difficult for him to open by himself.
[cpg]

There was no sense of life, no human scent. But the scent was so nostalgic that it shook my tear glands.
[cpg]


;//下記のセリフは？？？でお願いします
;//ここから雅人も名前が小夜から元に戻ります。設定として屋敷にいる時や戻ってきた時、自分になる…みたいな感じです。

[VOICE f="Sayo729"]
[OnName num="unknown"]
This place hasn't changed, has it? It's almost exactly the same as it was back then.
[cpg cn=true]




I heard a voice pouring down from the second floor. It was a terribly nostalgic appearance, reminding him of their first encounter.
[cpg]

His...her, master.
[cpg]

She was the same as she had been back then.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1500]

[VOICE f="Sayo730"]
[OnName num="sayo"]
It's not as if every inch of the house has been cleaned. It can't be helped, I've been out of here since then too..."
[cpg cn=true]


Six years ago, when Masato himself became the master's double and married her off. Six years ago, when Masato became his master's double and married her off, she couldn't live as she had before, so she moved to a place where no one lived.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo731"]
[OnName num="sayo"]
"Long time no see, six years... long time?"
[cpg cn=true]


[OnName num="masato"]
"No. No, it seems to have flown by, after all.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo732"]
[OnName num="sayo"]
I wonder if you've gotten any taller.
[cpg cn=true]


[OnName num="masato"]
I don't know.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo733"]
[OnName num="sayo"]
What about me?
[cpg cn=true]


[OnName num="masato"]
...... You haven't changed much, have you?
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo734"]
[OnName num="sayo"]
I'm sorry, but you're still five millimeters taller than I am.
[cpg cn=true]


[OnName num="masato"]
"I'm sorry, sir, but five millimeters is more than I can see with a microscope, which I don't have.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo735"]
[OnName num="sayo"]
Then you'll have to keep it handy from now on.
[cpg cn=true]


[OnName num="masato"]
Thank you, sir.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo736"]
[OnName num="sayo"]
...... I can't see very well from this position either.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo737"]
[OnName num="sayo"]
Hey. Can you get a better look at me?
[cpg cn=true]


[OnName num="masato"]
Yes.
[cpg cn=true]

[FO pos="2/3" time=1000]

[SE f=se078]
;//【ＳＥ】『衣擦れ』


;//●ＣＧエンディング（雅人＆小夜・額をコツンと当てる感じで顔を近づける二人：背景はイメージ的なやつ）ev_14
;//小夜は片手→両手で雅人の頬に優しく触れている。後に少しポーズが変わってもっと寄り添う感じに。

;**【ＣＧ】 ev_14_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1500]


Masato bent down a little and brought his face closer to Master's. She touched Masato's face with both hands.
[cpg]

She touched Masato's face with both hands, as if she was checking the shape of it, to make sure it was not a ghost.
[cpg]

She stroked his ears and cheeks lovingly, touched his lips, his hair, and gazed into his eyes.
[cpg]

She touched him, looked at his cane leg and the lightless left eye hidden by his bangs, and hugged Masato close to her cheek.
[cpg]

;**【ＣＧ】 ev_14_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1500]


[VOICE f="Sayo738"]
[OnName num="sayo"]
'I'm sorry...I'm sorry...'
[cpg cn=true]


The master shed large tears as he repeated the words filled with apology and repentance.
[cpg]

[OnName num="masato"]
Why are you apologizing?
[cpg cn=true]


[VOICE f="Sayo739"]
[OnName num="sayo"]
I'm sorry, I'm sorry, I'm sorry, I'm sorry, I'm sorry.
[cpg cn=true]


[OnName num="masato"]
That's not true. I did what I wanted to do... it's not your fault, I told you that six years ago.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo740"]
[OnName num="sayo"]
Yes, yes, I know. I know, but..."
[cpg cn=true]


I understand Masato's way of thinking, but still, it is I who brought about this situation. The master was heartbroken about it.
[cpg]

;**【ＣＧ】 ev_14_b ***********************
[CG id=14 index=2 time=1000]
;***************************************
[WAIT time=1500]


[OnName num="masato"]
Please don't worry about it. If you are worried about it, I will feel that what I did was wrong.
[cpg cn=true]


She knew exactly what she was doing. But understanding is not the same as being convinced.
[cpg]

[VOICE f="Sayo741"]
[OnName num="sayo"]
"But then..."
[cpg cn=true]


[OnName num="butler"]
"My Lady."
[cpg cn=true]


Tanaka, the butler who had been standing by the door watching over the two of them, made a suggestion.
[cpg]

[OnName num="butler"]
I think it's normal for labor to be fairly compensated.
[cpg cn=true]


[VOICE f="Sayo742"]
[OnName num="sayo"]
"...... You're right. You're right.
[cpg cn=true]


I'm sure you're right." Saya looked as if she had come up with something.
[cpg]

[OnName num="masato"]
Master. I didn't mean to do that..."
[cpg cn=true]


[VOICE f="Sayo743"]
[OnName num="sayo"]
I know, I know, I know. So this is my reward, your reward for serving me for seven years."
[cpg cn=true]


For six years, it was the man who had actually served her. However, it happened because of his service to her.
[cpg]

The master understood that feeling, and he understood it properly. Masato felt as if his actions had finally been rewarded here.
[cpg]

[VOICE f="Sayo744"]
[OnName num="sayo"]
"Well, it's normal to give what you want, but..."
[cpg cn=true]


[OnName num="masato"]
'I would like nothing more than to be able to serve my master.
[cpg cn=true]

;**【ＣＧ】 ev_14_c ***********************
[CG id=14 index=3 time=1000]
;***************************************
[WAIT time=1500]


[VOICE f="Sayo745"]
[OnName num="sayo"]
"Xu Xu. I knew you would say that. But I reject that.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[VOICE f="Sayo746"]
[OnName num="sayo"]
I have something to give you.
[cpg cn=true]


The master then took Masato by the hand, supporting him, and headed upstairs.
[cpg]

In the back of the room, Tanaka, the butler, was still in the same position, bowing his head.
[cpg]

[SE f=se005]
;//【ＳＥ】『歩く』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1500]
[WAIT time=2000]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f=se016]
;//【ＳＥ】『扉を開ける』


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『小夜の部屋』（昼）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sayo747"]
[OnName num="sayo"]
"Look, this place is still the same as before.
[cpg cn=true]


[OnName num="masato"]
"Wow. It's true, I miss it.
[cpg cn=true]


This is the bedroom that the master used when he lived here. Thinking back, a lot of things happened here. A place filled with memories.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo748"]
[OnName num="sayo"]
...I'm still the same as I was back then, really.
[cpg cn=true]


[OnName num="masato"]
What?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo749"]
[OnName num="sayo"]
That's why I want to give you this as a reward.
[cpg cn=true]


Masato, the servant, immediately understood what Master was trying to say.
[cpg]

However, Masato has his reasons for not accepting the offer.
[cpg]

[OnName num="masato"]
He said, "I'm sorry, .......... I'm sorry, but I can't function as a man anymore..."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo750"]
[OnName num="sayo"]
I don't mind.
[cpg cn=true]

[FO pos="2/3" time=1000]

[SE f=se078]
;//【ＳＥ】『衣擦れ』


;//☆ＣＧエンディング（雅人＆小夜・額をコツンと当てる感じで顔を近づける二人：背景はイメージ的なやつ）ev_14
;//CGを再び表示

;**【ＣＧ】 ev_14_c ***********************
[CG id=14 index=3 time=1000]
;***************************************
[WAIT time=1500]


[VOICE f="Sayo751"]
[OnName num="sayo"]
For example, with my toes, with my fingers, with my lips... with my tongue. ...... Anything. If you'll take it, if you'll keep the proof, I'll be ...... very happy."
[cpg cn=true]


[OnName num="masato"]
"...... Yes. It is an honor that is too good to be true. I will respectfully accept the reward.
[cpg cn=true]


Masato and Sayo. The two do not go beyond the framework of master and servant, but are bound together by a deeper and stronger bond.
[cpg]

They became the one and only, real master and servant.
[cpg]


;//【…ただいま。ルート】エンド
[jump storage="epend.ks" target="*back_title"]


;/////////////////////////////////////////////////////////////////////////////////

;//【合流C】
;//【比翼連理ルート】（※途中までの展開はEND１と同じ）

*root_hiyokurenri|Hiyou Renri

[SCENE id=17]


[window target=false]

[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1500]

;//【ＢＧ】『豪邸、ホール』（昼）******************************************************



[window target=true]
[OnName num="masato"]
It seems that I will not be married off.
[cpg cn=true]

[BGM f="sl"]

[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Sayo752"]
[OnName num="sayo"]
".........!!!"
[cpg cn=true]


The man who was to marry her was astonished to find that the girl he was aiming for was a man, and that he had no intention of marrying her... so he agreed to break off the engagement.
[cpg]


[SE f=se078]
;//【ＳＥ】『衣擦れ』
[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=1000]
[WAIT time=1500]


At that moment, the master flapped his wings and jumped into my chest.
[cpg]

[window target=false]

;//ＢＫ

[STOPBGM]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[BG f="b_04_4.ui" time=1000]
[WAIT time=1500]

;//【ＢＧ】『小夜の部屋』（夜）******************************************************


[BGM f="se"]

[window target=true]


After that incident, my life returned to normal.
[cpg]

The "man's daughter" strategy seemed to have worked so well with the man I was married to that I kept a certain distance from him at home, even at work, and our relationship faded.
[cpg]

I'm not going to have much to do with him in the future because he's avoiding me.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sayo753"]
[OnName num="sayo"]
"Well, I've calmed down, but I still don't think I'll be able to get out of this house.
[cpg cn=true]


[OnName num="masato"]
"It can't be helped, but... will I have to live as a recluse again?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo754"]
[OnName num="sayo"]
Don't call me a hermit.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Sayo755"]
[OnName num="sayo"]
It's strange to feel like there's another me.
[cpg cn=true]


[OnName num="masato"]
Ha, yes. I'm sorry.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo756"]
[OnName num="sayo"]
You have nothing to apologize for.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo757"]
[OnName num="sayo"]
But now you're just like me. You'll be forced to live in a cage, just like me.
[cpg cn=true]


[OnName num="masato"]
I don't care. I'm determined to serve my master for the rest of my life.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo758"]
[OnName num="sayo"]
Yes, good girl. By the way, since you're going to have a lot of time on your hands I'd like to play something a little different.
[cpg cn=true]


[OnName num="masato"]
What do you mean?"
[cpg cn=true]

[SE f=se078]
;//【ＳＥ】『衣擦れ』
[FG f="CHA01_p5_01_a.ui" method="change_2"  pos="2/3" time=800]

;//レターボックスin
[FACE method="feadin_up" pos="4/7"]

[WAIT time=1500]


I'm going to huddle up. I'm going to have some free time, so I'd like to play something different.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="Sayo759"]
[OnName num="sayo"]
Hug me, that's an order. I will not accept your refusal.
[cpg cn=true]


[OnName num="masato"]
"Yes, sir, whatever you command."
[cpg cn=true]

[VOICE f="Sayo760"]
[OnName num="sayo"]
You have a difficult personality.
[cpg cn=true]


[OnName num="masato"]
Master.
[cpg cn=true]



;//●ＣＧエンディング（雅人＆小夜・小夜が上で覆いかぶさる様にして騎乗位で挿入。破瓜あり：小夜の部屋）ev_15

;//レターボックスout
[FACE method="feadout_up" pos="4/7"]

[FO pos="2/3" time=1000]

;**【ＣＧ】 ev_14_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Sayo761"]
[OnName num="sayo"]
Well... Are you sure you want to be just a servant?
[cpg cn=true]


She pressed me. But there was only one answer.
[cpg]

[OnName num="masato"]
"Of course."
[cpg cn=true]


They laughed and kissed each other once again.
[cpg]

Husband and wife, woman and man, sisters... they became one and the same, sublimated into a unique relationship.
[cpg]

Death will separate them, but they will remain together.
[cpg]

[WAIT time=1000]

[BG f="black.ui" time=2500]
[WAIT time=2500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

;//暫くCGを表示してゆっくりとフェードアウト。その後スタッフロール。




;//【比翼連理ルート】エンド
[jump storage="epend.ks" target="*start"]


;/////////////////////////////////////////////////////////////////////////////////

;//【合流B】
;//【遠き存在ルート】

*root_existence|Distant existence

[SCENE id=18]


[stflag gohome_flag=0]
[stflag service_flag=0]


[window target=true]


In the end, there was nothing I could do. I couldn't think of anything.
[cpg]


[BG f="b_00_2.ui" time=1000]
[WAIT time=2000]

[BGM f="se"]

[FACE method="feadin" pos="4/7"]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_00_2_up.ui" time=1000]

[WAIT time=2000]

[OnName num="masato"]
Master, please take me with you.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Sayo762"]
[OnName num="sayo"]
"I can't do that.
[cpg cn=true]


[OnName num="masato"]
Then at least I won't leave you for even a moment until I do.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[WAIT time=1000]

[FACE method="change_1" pos="2/3"]
[VOICE f="Sayo763"]
[OnName num="sayo"]
Sweetie.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sayo764"]
[OnName num="sayo"]
I love you more than dogs, more than cats I love you.
[cpg cn=true]


[OnName num="masato"]
"Master..."
[cpg cn=true]


We can lick each other's wounds all we want. If it can save master even a little...
[cpg]

[window target=false]

[SE f=se005]
;//【ＳＥ】『歩く』

[transition target={true} rule="morble1.webp" color={0x000000ff} time=2000]
[WAIT time=3100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=500]

[BG f="b_07_1.ui" time=2000]
[WAIT time=2000]
;//ＢＫ
[window target=true]

Master got married, and without him, I became unemployed again.
[cpg]

I couldn't do anything...nothing...
[cpg]


;//【遠き存在ルート】エンド
[jump storage="epend.ks" target="*start"]
