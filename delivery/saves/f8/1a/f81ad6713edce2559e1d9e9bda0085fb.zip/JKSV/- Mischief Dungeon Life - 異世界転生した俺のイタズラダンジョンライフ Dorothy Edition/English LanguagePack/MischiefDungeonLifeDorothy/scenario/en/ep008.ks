

*start

;###################################################################
*Ep008|Being pissed off doesn't stop a makeover.
;###################################################################


[SCENE id=8]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
[BG f="black.ui"  time=1000]
[WAIT time=100]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





[OnName num="goblins"]
Hey, that shapeshifter ......
[cpg cn=true]


[OnName num="kobold"]
“Oh. I thought he would be the key to change the war situation..."
[cpg cn=true]


You are more discouraged than rushed.
[cpg]

;//＠
For me, it's the same thing, but my conscience is a little sore from the quicksand.
[cpg]


I'm just sitting here, resting on my laurels, with only a meal and a room to myself.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha128"]
[OnName num="asha"]
You're worried about the rumors?　Renji.
[cpg cn=true]


[OnName num="renzi"]
“Yeah, well..., I guess."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha129"]
[OnName num="asha"]
“There's not much I can say about that, but it seems that the Demon King is thinking about how you're being treated.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha130"]
[OnName num="asha"]
If I wanted my own private bedroom, I might at least go scouting."
[cpg cn=true]


Even Asha pushed back against my foolishness.
[cpg]


If this keeps up, apparently, I may end up sleeping in the big room again.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



;//ここからしばらく、ドロシーのセリフ名前欄を「ドロシー（蓮司）」と置き換えてください

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[WAIT time=1000]
[FG f="CHA02_p4_01_a.ui" method="change_1"  pos="2/3" time=1]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

[VOICE f="Dorothy082"]
[OnName num="renzi_to_dorothy"]
“As always, a perfect transformation...”
[cpg cn=true]


But I had one thing on my mind.
[cpg]


I think it's so refreshing to me. I guess that means this place is my nature after all.
[cpg]


Today I was transformed into Dorothy. Compared to Janice, she is much shorter.
[cpg]


I think about something similar to the other day. If the transformation is this perfect, I can impersonate and live my life.
[cpg]


I should really pretend to be Dorothy and live for a day.
[cpg]


It might not be a bad feeling to be praised as a princess by everyone...
[cpg]

;//移植前シーンカット


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


[SE f=se019]
;//【ＳＥ】『ノック』

[WAIT time=1000]


Then I heard a knock at the door. I rush to answer it.
[cpg]


[FG f="CHA02_p4_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Dorothy103"]
[OnName num="renzi_to_dorothy"]
What...? Oh, wait a minute.
[cpg cn=true]



[VOICE f="Janice109"]
[OnName num="janice"]
......?"　It sounded like the voice of the Princess."
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_12_0 ***********************
;//カットイン
[CUTIN f="ci_12_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

I quickly transform. I took the form of a canine beastman and opened the door.
[cpg]



;//ここからドロシーのセリフ、名前欄を元に戻してください


[CUTIN f="ci_12_0.ui" show={false} method="slideout"]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Janice110"]
[OnName num="janice"]
You were disguised as the princess?
[cpg cn=true]


[OnName num="renzi"]
“No..., I think you heard wrong.”
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Janice111"]
[OnName num="janice"]
In moderation."
[cpg cn=true]


Janice said this, seeming quite angry.
[cpg]


[OnName num="renzi"]
So, you have something for me.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Janice112"]
[OnName num="janice"]
Oh," he said. The princess wants to see you.
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]

I am escorted to the King's chamber, where Dorothy is sitting on the throne.
[cpg]


[OnName num="renzi"]
“Where is His Majesty, the Demon King?”
[cpg cn=true]


I could have asked casually, but since Janice and Dorothy were there, I added a "His Majesty".
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy104"]
[OnName num="dorothy"]
He was busy adjusting the magic flowing through the dungeon."
[cpg cn=true]


[OnName num="renzi"]
Can I sit on the throne ......?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy105"]
[OnName num="dorothy"]
I don't mind. If things go in order, I'm the next Demon King."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Dorothy106"]
[OnName num="dorothy"]
But more importantly, I need you to do me a favor.
[cpg cn=true]


[OnName num="renzi"]
Oh. I'll listen if I can.
[cpg cn=true]


[FO pos="2/3" time=1000]
[FO pos="1/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト

[FACE method="feadin" pos="4/7"]

[BG f="b_04_5.ui" time=1000]

[WAIT time=1000]


According to him, there is a bit of a problem in the dungeon where the demons live.
[cpg]


It is said that adventurers have been showing up in the dungeon from time to time and returning ......
[cpg]



Money and belongings were stripped from such adventurers. If they did not, they would attack again.
[cpg]


but they had no use for it in the dungeon.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FACE method="out" pos="4/7"]


[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]


[OnName num="renzi"]
It's true, it's not good to just have money.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy107"]
[OnName num="dorothy"]
Yes," he said. It's supposed to be that adventurers are coming in for the adventurers' money.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy108"]
[OnName num="dorothy"]
So ...... why don't you go to the human city and buy some magic equipment?　You can turn into a human, can't you?
[cpg cn=true]


[OnName num="renzi"]
“Maybe I can turn into one... What's a magic tool?”
[cpg cn=true]


[FACE method="change_1" pos="1/3"]

[VOICE f="Janice113"]
[OnName num="janice"]
Literally, it's a magical tool. The one I need you to go buy this time is something that promotes the growth of vegetables."
[cpg cn=true]


I see. That reminds me, there was a story about that.
[cpg]


I had wondered how vegetables could grow in the depths of such a cave-like place.
[cpg]


[OnName num="renzi"]
I guess so. I'll give it a try."
[cpg cn=true]


It's a lighter mission than reconnaissance. And I wanted to play tricks on humans.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Dorothy109"]
[OnName num="dorothy"]
Really?　I'm glad I have a job I can assign you.
[cpg cn=true]


[OnName num="renzi"]
What kind of ...... is that?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy110"]
[OnName num="dorothy"]
I was worried when your father said he was going to take the room away from Renji.
[cpg cn=true]


[OnName num="renzi"]
......"
[cpg cn=true]


I see. I'm sorry I put you through that.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FO pos="1/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





But I can't do nothing after all this arrangement.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha131"]
[OnName num="asha"]
How's it going?　Do you think you can turn him?
[cpg cn=true]


An adventurer who had come to defeat the Demon King and had been returned, knocked unconscious. I approach him and sniff him.
[cpg]


It's not a very pleasant experience to smell a human being, let alone a man...
[cpg]


[OnName num="renzi"]
I can do it. As long as I can smell it."
[cpg cn=true]



;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_13_0 ***********************
;//カットイン
[CUTIN f="ci_13_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

I could easily be human. I felt like a young man who looked like a swordsman.
[cpg]


And the real one, or rather, a copy of the original, was to be held captive in a dungeon for a while.
[cpg]


This way, two people with the same appearance would not happen.
[cpg]

[CUTIN f="ci_13_0.ui" show={false} method="feadout"]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep009.ks" target="*start"]
