

*start

;###################################################################
*Ep004|How to Makeover Without Being Discovered
;###################################################################


[SCENE id=4]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out" pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
[BG f="black.ui"  time=1000]
[WAIT time=100]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





[OnName num="renzi"]
Hello," he said. You don't look so good, Janice."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice041"]
[OnName num="janice"]
I'm going to go to ...... and see if I can find anything. That's you."
[cpg cn=true]


In the mess hall, I see Janice so I call her name.
[cpg]


She is now in slime form. Conveniently, I could still speak in this guise.
[cpg]


Of course, I also have sight, hearing, and smell. I still remember the smell of the fruit and mint combined when I approached Janice.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Janice042"]
[OnName num="janice"]
I was in a bad way. Leave me alone."
[cpg cn=true]


That ghost said he didn't remember himself and ......, Janice muttered.
[cpg]


I guess I questioned the ghost that was the source of my copy. It's my fault, though it's a good thing I got caught in the middle of it.
[cpg]


[move from="2/3" to="2/5" ease="easeInOutSine" time=2000]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=2000]

[VOICE f="Dorothy011"]
[OnName num="dorothy"]
Oh, Janice. Is that Renji over there?"
[cpg cn=true]


[OnName num="renzi"]
Yes, it's me. Sorry for the confusion.
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Dorothy012"]
[OnName num="dorothy"]
No, it's fine. What's wrong with your face, Janice?
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[VOICE f="Janice043"]
[OnName num="janice"]
No, it's not something for the princess to talk about.
[cpg cn=true]


Dorothy and I responded very differently to the same question.
[cpg]


What is Dorothy's position and feelings from Janice's point of view?
[cpg]


Nervousness or admiration?　Or is there something like affection?
[cpg]


[FACE method="change_4" pos="2/5"]
[VOICE f="Janice044"]
[OnName num="janice"]
Instead of worrying about me, you should worry about this dungeon."
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Dorothy013"]
[OnName num="dorothy"]
“I guess so. I wonder how Clara will behave.”
[cpg cn=true]


[OnName num="renzi"]
“Clara?"
[cpg cn=true]


[FACE method="change_7" pos="4/5"]
[VOICE f="Dorothy014"]
[OnName num="dorothy"]
Don't you know?　No, Renji doesn't know?"
[cpg cn=true]


When I was puzzled, Janice told me.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="4/5" time=1]
[FO pos="2/5" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FACE method="in" pos="4/7"]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="03"]
;//【ＢＧ】『街』（昼）******************************************************



;//ヒロイン１の立ち絵を黒いシルエットで表示してください



[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]



[VOICE f="Janice045"]
[OnName num="janice"]
“Clara Easton. Our natural enemy, the champion.”
[cpg cn=true]


I had never heard the name before. But if it's a natural enemy, maybe all the demons know it.
[cpg]


[VOICE f="Janice046"]
[OnName num="janice"]
How many times have I been made to lick her bitter ......
[cpg cn=true]


[OnName num="renzi"]
Are you talking about the ...... demons that have been killed?"
[cpg cn=true]


[VOICE f="Dorothy015"]
[OnName num="dorothy"]
“Yes..., so they are sworn enemies. If we could only defeat her, things would change a lot."
[cpg cn=true]


Would I be able to do it? Even if I couldn't beat him, I could at least capture him.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FACE method="out" pos="4/7"]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="3/3" time=800]


[VOICE f="Arsha058"]
[OnName num="asha"]
What are you three talking about?
[cpg cn=true]


Then Asha came along.
[cpg]


[OnName num="renzi"]
'You're a cook, right?　Can I step away from my work?"
[cpg cn=true]


[FACE method="change_7" pos="3/3"]
[VOICE f="Arsha059"]
[OnName num="asha"]
'Yeah, I'm done with work for the day. I mean, you're a hoarder to me."
[cpg cn=true]


[OnName num="renzi"]
“I guess I just feel friendly towards you...”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy016"]
[OnName num="dorothy"]
“You can talk to me casually too... We’re friends right?”
[cpg cn=true]


Friend. What is it suddenly, I know Dorothy is interested in me.
[cpg]


She looks at me and her eyes light up. I guess she's not interested, she's expecting me to work for her.
[cpg]


[OnName num="renzi"]
“Well..., I guess.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Dorothy017"]
[OnName num="dorothy"]
Ehehe."
[cpg cn=true]


[FACE method="change_7" pos="1/3"]

Dorothy looks happy. Janice looked indescribable.
[cpg]


She is happy with her, too, or is it ...... jealousy or something?
[cpg]


[OnName num="renzi"]
'And yet, how can you tell she's done for the day?
[cpg cn=true]


[FACE method="change_1" pos="3/3"]
[VOICE f="Arsha060"]
[OnName num="asha"]
That's because there is no day or night, but there is a clock."
[cpg cn=true]


[OnName num="renzi"]
Is it working by magic or something?"
[cpg cn=true]


[FACE method="change_5" pos="3/3"]
[VOICE f="Arsha061"]
[OnName num="asha"]
What?　Clocks don't work by magic, do they?"
[cpg cn=true]


[OnName num="renzi"]
“No..., that's right."
[cpg cn=true]


We are civilized enough to have clocks that run on machines.
[cpg]


Or maybe it's something we looted from the humans.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="1/3" time=1]
[FO pos="2/3" time=1]
[FO pos="3/3" time=1]


[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//＠シナリオカット用場所移動１
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





Back in my room, I was trying out various transformations on my own.
[cpg]


One thing became clear. It turns out that I can now transform into Janice.
[cpg]


My repertoire is growing, and I'm starting to understand the rules somewhat.
[cpg]


Inorganic or someone who has some knowledge of the person ...... or something like that?
[cpg]


But don't we know why Asha was the first to be transformed?
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[BGM f="05"]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



Thinking about this and that, I decided to approach Asha. Of course, to play a trick on her.
[cpg]


For example, in this world, goblins and orcs have intelligence.
[cpg]


But even so, there are various kinds of demons, some of whom are without intelligence.
[cpg]


For example, slimes and insects are considered to be very primitive demons.
[cpg]


In other words, by transforming into such demons, it is possible to attack while hiding my true identity...
[cpg]

;**【ＣＧ】ci_06_0 ***********************
;//カットイン
[CUTIN f="ci_06_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

With that in mind, I disguised myself as a slime and made my way to Asha's room.
[cpg]

[CUTIN f="ci_06_0.ui" show={false} method="feadout"]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Arsha062"]
[OnName num="asha"]
'Hmmm, you've worked hard today ...... that?'
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


I entered Asha's room through the open door.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha063"]
[OnName num="asha"]
'Slime in a place like this?　Lost?"
[cpg cn=true]


Asha didn't seem to realize that the slime was me.
[cpg]


I silently approach her body.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha064"]
[OnName num="asha"]
She's a very friendly slime," she says. It tickles me.
[cpg cn=true]


I crawl straight onto Asha's body. As I try to stick to her body...
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Arsha065"]
[OnName num="asha"]
"Yes... That’s just the way I like it."
[cpg cn=true]


She said something strange. I wondered what she meant by just right, and she closed the door.
[cpg]




;//;//========================================
;//;//●ＣＧ（スライムとなった主人公を、寝ているヒロインが撫でる）ev_04
;//;//人物１：ヒロイン４　服装１：着衣
;//;//人物ex：主人公　　　服装ex：無し
;//;//場所　：ダンジョン内部
;//;//時間　：夜
;//;//備考　：主人公はスライムに変身しています
;//;//========================================
;//
;//[STOPBGM]
;//[FO pos="2/3" time=1000]
;//[BG f="black.ui"  time=1000]
;//[WAIT time=1000]
;//[BGM f="10"]
;//
;//;**【ＣＧ】 ev_04_0 ***********************
;//[CG id=2 index=0 time=1000]
;//;***************************************
;//
;//[wait time=1500]
;//
;//[VOICE f="sArsha003"]
;//[OnName num="asha"]
;//「私も人肌恋しかったんだ。まあ、スライムだから人じゃないけど」
;//[cpg cn=true]
;//
;//
;//[VOICE f="sArsha004"]
;//[OnName num="asha"]
;//「だけど……一人で寝るのもさみしいよね」
;//[cpg cn=true]
;//
;//
;//……よく考えれば、彼女は兎族の獣人だ。
;//[cpg]
;//
;//
;//だから恋しやすいとか、そんなことをふっと思ってしまった。
;//[cpg]
;//
;//
;//;**【ＣＧ】 ev_04_a ***********************
;//[CG id=2 index=1 time=1000]
;//;***************************************
;//
;//[wait time=1500]
;//
;//[VOICE f="sArsha005"]
;//[OnName num="asha"]
;//「私のところに来たってことは、貴方もさみしいのかな？」
;//[cpg cn=true]
;//
;//
;//俺は返事をすることも、仕草で返すこともできない。
;//[cpg]
;//
;//
;//というかスライムには仕草というものがない。できることがあるとしたら……
;//[cpg]
;//
;//;**【ＣＧ】 ev_04_b ***********************
;//[CG id=2 index=2 time=1000]
;//;***************************************
;//
;//[wait time=1500]
;//
;//[VOICE f="sArsha006"]
;//[OnName num="asha"]
;//「やっ。くすぐったいよ」
;//[cpg cn=true]
;//
;//
;//俺を撫でてくれる彼女に、こちらからも触れるぐらいのことだった。
;//[cpg]
;//
;//
;//結局、することとしてはただ一緒に居るだけ。
;//[cpg]
;//
;//
;//スライムの姿で、アーシャの寂しさを癒やせたかどうかなんて分からない。
;//[cpg]
;//
;//;**【ＣＧ】 ev_04_a ***********************
;//[CG id=2 index=1 time=1000]
;//;***************************************
;//
;//[wait time=1500]
;//
;//[VOICE f="sArsha007"]
;//[OnName num="asha"]
;//「……このまま寝ちゃってもいいけど、どうしようかな」
;//[cpg cn=true]
;//
;//
;//彼女はまだ、何か孤独を抱えているような顔をしていた。
;//[cpg]
;//
;//
;//
;//;//移植前シーンカット
;//
;//

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


After all, all we did was just stay together.
[cpg]

I don't know if I was able to soothe Asha's loneliness in my slime form.
[cpg]

She still looked like she was carrying some kind of loneliness.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Arsha090"]
[OnName num="asha"]
'So long,' she said. Bye."
[cpg cn=true]


[OnName num="renzi"]
......"
[cpg cn=true]


I can't untransform on the way. I left, wondering what to do with this feeling.
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]



[jump storage="ep005.ks" target="*start"]
