
*start

;//==============================
;//ヒロイン１がギャルである場合
*end1_citch|美智佳は遊んでる



Michika. She seemed like the type of girl to play around.
[cpg]

I didn't dislike her type.
[cpg]


There was something raw and human about her that I found attractive.
[cpg]


She was easy to interact with. It was easy to see how she became a central figure in our class.
[cpg]


On top of it all, she was cute.
[cpg]


;#################################################
*Ep008|Michika is a player
;#################################################

[SCENE id=8]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************



[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko096"]
[OnName num="nathuko"]
"...... and you want to talk to me about it? Don't you have anybody else to talk to?"
[cpg cn=true]


I'd gone to Natsuko's class and asked for advice on how I could confess to Michika.
[cpg]


[OnName num="shoma"]
"Should I just go up to her and say it? Or maybe I should gauge her reaction by talking to her friends first..."
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="sNathuko011"]
[OnName num="nathuko"]
"Hold your horse. Do you even know if you have a chance with her?"
[cpg cn=true]


......You miss every shot you don't shoot.
[cpg]


If Natsuko didn't think I had a chance, then there wasn't any point in asking her for advice.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


We finish morning classes. Then, it is lunch break.
[cpg]


I called Michika over to an empty classroom.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[OnName num="shoma"]
"I like you ……. Please go out with me."
[cpg cn=true]


It was clichéd, but sometimes the best choice is also the simplest.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sMithika021"]
[OnName num="mithika"]
"You want to go out with me? But we're already friends. We even kissed."
[cpg cn=true]


Maybe I should have chosen my words better. It didn't seem like she was taking me seriously.
[cpg]


[OnName num="shoma"]
"Sure, but I want more. I want to be your lover. I want a real relationship."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika310"]
[OnName num="mithika"]
"Haha, what's a real relationship? That's funny."
[cpg cn=true]


Michika is laughing. Maybe what Natsuko said was true.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Michika311"]
[OnName num="mithika"]
"Well, you probably know already, but I'm not the type to date anybody seriously."
[cpg cn=true]


[OnName num="shoma"]
"But......is that enough for you?"
[cpg cn=true]


"I'm satisfied", Michika replies without any hesitation at all.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="sMithika022"]
[OnName num="mithika"]
"On the contrary, what's the difference between a lover and a friend?"
[cpg cn=true]


[OnName num="shoma"]
"Well......I don't know, maybe building a strong, lasting romantic relationship?"
[cpg cn=true]


[OnName num="shoma"]
"......Loving the person you're with...stuff like that……"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Michika313"]
[OnName num="mithika"]
"Yeah, no. I don't really get that sorta stuff."
[cpg cn=true]


...... I see. I guess that's how it is. But I still want to be close to her. Closer than anybody else.
[cpg]


I don't want to be just another one of her 'friends'. What could I do to become special in her eyes?
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sMithika023"]
[OnName num="mithika"]
"So like, can I go over to your house today?"
[cpg cn=true]


[OnName num="shoma"]
"Huh......?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sMithika024"]
[OnName num="mithika"]
"We're friends, right?"
[cpg cn=true]


I'd only just worked up the courage to tell her how I felt with her...
[cpg]


And yet she acts as if it never happened. She even wants to come to my house?
[cpg]


It's not normal. Was it okay to fall in love with this girl?
[cpg]


......No, it was too late to think about that. I'd already fallen in love with her.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************


Then after school. On the way home with Michika.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="4/5" time=800]

[VOICE f="Mei087"]
[OnName num="mei"]
"You two are going home together? I think I'll join you."
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Michika316"]
[OnName num="mithika"]
"Not today, we've got plans."
[cpg cn=true]


Mei looked us knowingly.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Mei088"]
[OnName num="mei"]
"Alright, have fun you two."
[cpg cn=true]


I wonder how much she knew as Michika and I left the school grounds.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[SE f="se010"]
;//【ＳＥ】『歩く』



Michika walks with me, smiling. How was I going to explain her presence to my parents?
[cpg]


[OnName num="shoma"]
"Michika, do you like...go to other guys' houses often?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sMithika025"]
[OnName num="mithika"]
"Not always. Sometimes I'll bring them to my house."
[cpg cn=true]


I wasn't sure if I wanted her to go into detail...
[cpg]


[OnName num="shoma"]
"So, we're friends right?"
[cpg cn=true]


[FACE method="shak_7" pos="2/3"]
[VOICE f="Michika318"]
[OnName num="mithika"]
"What's this all of a sudden? I keep telling you we are."
[cpg cn=true]


Friends. Was that all we were? I wanted Michika to be my girlfriend.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


We get to my room.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sMithika026"]
[OnName num="mithika"]
"Shōma, look at me."
[cpg cn=true]

She leans in for a kiss.
[cpg]

[OnName num="shoma"]
"So much for the mood......"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Michika321"]
[OnName num="mithika"]
"Do boys care about that kind of thing?"
[cpg cn=true]


[OnName num="shoma"]
"Not really. I thought girls did though?"
[cpg cn=true]


I guess Michika wasn't the type to care about stuff like that.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Michika322"]
[OnName num="mithika"]
"I guess it depends. Right now, it's the last thing on my mind."
[cpg cn=true]


;//移植のためシーンをカットしています

The line between friends and lovers must be pretty blurry to her.
[cpg]

Yet, she said that she didn't want a boyfriend.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Dinner that night was slightly awkward. I couldn't answer the question of whether she was my girlfriend.
[cpg]

But I guess there wasn't much to say. The reality of our relationship couldn't be summarized so easily.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』


I have to seriously think about what I was going to do.
[cpg]


With this in mind, I head to school in the morning.
[cpg]


I see Natsuko ahead of me and call out to her.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nathuko098"]
[OnName num="nathuko"]
"Shōma? Whaddya want?"
[cpg cn=true]


[OnName num="shoma"]
"It's..about Michika."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko099"]
[OnName num="nathuko"]
"I dunno her that well, you should ask someone else for advice."
[cpg cn=true]


That said, I didn't really know anybody else.
[cpg]


Natsuko was in a different class, but I didn't really have any other options.
[cpg]


[OnName num="shoma"]
"I don't think she's ever had a boyfriend or anything."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sNathuko012"]
[OnName num="nathuko"]
"At least, from what I've heard, she's never been in a proper relationship."
[cpg cn=true]


I knew it. How could I possibly get her to fall in love with me?
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Natsuko and I finished talking and parted ways in the hallway.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nathuko102"]
[OnName num="nathuko"]
"See you later. Don't sweat it too much, alright?"
[cpg cn=true]


[OnName num="shoma"]
"......Yeah."
[cpg cn=true]



[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************



Soon after, Mei approached me.
[cpg]


I didn't see Michika in the classroom. I wondered if she was with another guy.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mei089"]
[OnName num="mei"]
"Hey Shōma. I hear you and Michika have been getting along well lately?"
[cpg cn=true]


[OnName num="shoma"]
"Maybe...I'm not sure anymore."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sMei014"]
[OnName num="mei"]
"I think you are. You guys talk a lot, right?."
[cpg cn=true]


From an outsider's point of view, I guess we were……but I'm not positive enough to believe that.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************


Michika finally showed up after missing half of her morning classes.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michika341"]
[OnName num="mithika"]
"What's wrong? You don't look so good."
[cpg cn=true]


[OnName num="shoma"]
"I'm fine, where were you all morning...?"
[cpg cn=true]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[FACE method="shake_1" pos="2/3"]
;//[VOICE f="sMithika027"]
;//[OnName num="mithika"]
;//「何って、普通に別の男子と一緒に居たけど」
;//[cpg cn=true]

Apparently she'd been with another guy.
[cpg]

;//[OnName num="shoma"]
;//「……そっか」
;//[cpg cn=true]
;//

She doesn't even feel bad about it. I guess we had different values.
[cpg]

;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
;//[WAIT time=1000]
;//ＢＫ

[FACE method="bow_2" pos="2/3"]

Later, she started to paw at me, wanted to flirt with me too.
[cpg]

I don't understand......No, that's wrong. I understood, but I couldn't relate.
[cpg]

[SE f="se010"]
;//【ＳＥ】『歩く』


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


We came to another classroom. One that wouldn't have any unexpected visitors.
[cpg]


[OnName num="shoma"]
"......How many ‘friends' do you have right now?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Michika345"]
[OnName num="mithika"]
"Hmm, you can count them on two hands, I guess."
[cpg cn=true]


She hadn't hit double digits at least......
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sMithika027"]
[OnName num="mithika"]
"It might be nice to be...friends with all the boys at school."
[cpg cn=true]


[OnName num="shoma"]
"Seriously......? That's......wow."
[cpg cn=true]


She says she was serious. Somehow, I didn't doubt her.
[cpg]


[FACE method="change_1" pos="2/3"]
;//移植のためシーンをカットしています

I felt that the time I could spend with her was invaluable.
[cpg]

[OnName num="shoma"]
"You know......I'm fine with you being the way you are."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="sMithika028"]
[OnName num="mithika"]
"What are you talking about?"
[cpg cn=true]


[OnName num="shoma"]
"I uh...I guess I like you, even when you're...playing around."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
Michika scratches her head.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMithika029"]
[OnName num="mithika"]
"Well whatever, I'm fine with what we have right now. Don't make it weird."
[cpg cn=true]


I'd worked up a lot of courage to say it. I thought my words would have more of an effect......
[cpg]


She didn't seem to care, but I loved her anyways. Maybe even more than before.
[cpg]


I think I've already accepted it. Michika will never have a boyfriend, and that ......
[cpg]

I had fallen hopelessly in love with her.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



I walk home with Michika. We don't hold hands or anything.
[cpg]


We're not lovers. She and I are just friends.
[cpg]



[FACE method="bow_2" pos="2/3"]
[VOICE f="sMithika030"]
[OnName num="mithika"]
"It's not like I don't appreciate it when people tell me they like me. I think it takes a lot of courage."
[cpg cn=true]


Michika suddenly brings up our earlier conversation.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika366"]
[OnName num="mithika"]
"Were you serious? Won't you get jealous or possessive or something?"
[cpg cn=true]


[OnName num="shoma"]
"No. I made up my mind."
[cpg cn=true]


I tried to assure her, but I still felt lost. A part of me held on to hope that she'd become my girlfriend someday.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="sMithika031"]
[OnName num="mithika"]
"Hmm. Every now and again I get guys who tell me to quit playing with other guys."
[cpg cn=true]


Michika looked at me, defiantly. I took it as a challenge.
[cpg]


[OnName num="shoma"]
"Don't worry, I won't say anything like that."
[cpg cn=true]


Seemingly satisfied, she pulls away.
[cpg]


We walk together, but she stayed just out of reach.
[cpg]


It was as if she was illustrating our relationship. This was the closest I could get to her.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Another awkward dinner. But I didn't care anymore.
[cpg]


To see Michika, I had to see myself.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



What was it about her that I was attracted to? Was it just how she played around so much?
[cpg]

Then isn't it crazy to try to monopolize her? it would change her...she wouldn't be the same girl I'd fallen for, right?
[cpg]

She was free-spirited. You couldn't hold her down. And maybe that's what I loved about her.
[cpg]


If anything, I should be supporting her...Yeah, I think I'd finally found a way forward.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



I lay in bed trying to come up with a concrete plan. Before long it was morning.
[cpg]


I smiled wryly to myself. It was like we were like a new couple. I'd spent the whole night thinking about her.
[cpg]


My mind was made up, I had to tell Michika about my idea.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************



It seems Michika wasn't in the classroom again.
[cpg]


;//別の男子とさかっているのだろう。それにしたって、サボりすぎだ。
She was probably with another guy. Again. She was missing too many classes.
[cpg]


Morning classes are about to end but there's still no sign of Michika.
[cpg]


Miss this many classes and the faculty are going to start keeping an eye on you......
[cpg]


Wait, maybe some of the teachers were her friends too.
[cpg]


I couldn't put it past her. She wasn't the type to be held back by common sense.
[cpg]


That said, I had to start moving past the boundaries of common sense if I wanted to be with Michika.
[cpg]


Just friends wasn't enough, but I couldn't be her lover.
[cpg]


Even still, I needed to be close to her. That's why I had do whatever it took to make a new space. Somewhere in between.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


;//ＢＫ

It was getting late to be at the school, so we talked some more on the way home.
[cpg]

[SE f="se010"]
;//【ＳＥ】『歩く』


[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="shoma"]
"So what I'm trying to say is that there's a lot of boys that would love to talk to you, Michika."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Michika389"]
[OnName num="mithika"]
"Yeah, cool. So?"
[cpg cn=true]


[OnName num="shoma"]
"Well, it's difficult for a girl to ask around about that sort of thing, right? That's where I come in."
[cpg cn=true]


[OnName num="shoma"]
"I'll ask around. Get a feel for who's interested, you know?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

Michika doesn't seem to understand what I was suggesting.
[cpg]


Sure, it was probably faster if she approached guys herself.
[cpg]


But I wanted to help. I thought I could make Michika's dream a reality.
[cpg]


I was on the precipice. One more step and I wouldn't be able to return. Not that I had any plans to.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="sMithika032"]
[OnName num="mithika"]
"So you want to introduce me to new boys?"
[cpg cn=true]


[OnName num="shoma"]
"An oversimplification, but yes. What do you think?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika391"]
[OnName num="mithika"]
"Well, it seems like a great deal for me. I just don't see what you get out of it. You sound a little desperate."
[cpg cn=true]


......I froze for a moment.
[cpg]


I managed to work out a reply.
[cpg]


[OnName num="shoma"]
"It's not desparation, it's love. I love you, Michika."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika392"]
[OnName num="mithika"]
"Well, if you're sure about it."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


From now on, I was going to be her shadow.
[cpg]


Well, maybe not her shadow. She wouldn't let me that close. But, I could go around and see which boys were interested in her.
[cpg]


[OnName num="male_student_A"]
"What? Ms. Arishiro? Nah, she seems kinda scary."
[cpg cn=true]


[OnName num="male_student_B"]
"Yeah, I guess I kinda have a thing for her. Haha."
[cpg cn=true]


[OnName num="shoma"]
"Yeah? A thing, huh?"
[cpg cn=true]


[OnName num="male_student_B"]
"Yeah...so what? What?"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（朝）******************************************************



I decided to tell him a little bit more about her over the break period.
[cpg]


[OnName num="shoma"]
"So that about sums it up. Michika was looking for somebody like you."
[cpg cn=true]


[OnName num="male_student"]
"......Dude. What?"
[cpg cn=true]


[OnName num="shoma"]
"What do you mean, what? You said you had a thing for her, right?"
[cpg cn=true]


[OnName num="male_student"]
"Yeah sure, but it's not like I thought I'd ever get the chance to talk to her or anything. What would we even talk about, anyways?"
[cpg cn=true]


Yeah, you and me both man.
[cpg]


Whatever, he was only my first candidate. I had to keep looking. For her.
[cpg]


[OnName num="shoma"]
"Anyways, hit me up later if you're still interested."
[cpg cn=true]


[OnName num="male_student"]
"......Why are you doing this?"
[cpg cn=true]


[OnName num="shoma"]
"Does it really matter? You know where to find me."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



After school. He showed up.
[cpg]



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michika393"]
[OnName num="mithika"]
"You're laaaaate. What took you so long?"
[cpg cn=true]


[OnName num="shoma"]
"Sorry, I was a little busy explaining the situation."
[cpg cn=true]


It sounded weird in my head. Even weirder when the words came out of my mouth.
[cpg]


[OnName num="male_student"]
"Uh, thanks for inviting me......Ms. Arishiro."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika394"]
[OnName num="mithika"]
"Just call me Michika. Didn't you confess to me last year?"
[cpg cn=true]


[OnName num="male_student"]
"Please don't bring that up!"
[cpg cn=true]


They knew each other?
[cpg]


[OnName num="shoma"]
"Do you know each other?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sMithika033"]
[OnName num="mithika"]
"Well, you know. He confessed his feelings to me, so I suggested we could be friends."
[cpg cn=true]


If they already knew each other, what was the point of everything I did today...
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Michika396"]
[OnName num="mithika"]
"Well, when I thought I'd treat him like a friend, he ran away. I guess he's over it now."
[cpg cn=true]


[OnName num="male_student"]
"Don't tell him……"
[cpg cn=true]


I see. Well, I guess that's a normal reaction. Maybe it was before Michiko started acting like a gal.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="sMithika034"]
[OnName num="mithika"]
"So like, what do you want? I'm not gonna force you or anything."
[cpg cn=true]


[OnName num="shoma"]
"Maybe not."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sMithika035"]
[OnName num="mithika"]
"You confessed your feelings for me, that means you wanted something from me, right?"
[cpg cn=true]


Hearing such words, the boys seemed to have lost his patience.
[cpg]



;//========================================
;//●ＣＧエロ（モブ男に抱きつかれるヒロイン）ev_25
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：モブ男
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_25_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="male_student"]
" ......."
[cpg cn=true]


She looks excited as he grabs her.
[cpg]

[VOICE f="sMithika036"]
[OnName num="mithika"]
"Well......"
[cpg cn=true]


[VOICE f="sMithika037"]
[OnName num="mithika"]
"It's kind of exciting to make out with another boy in front of you, Shōma."
[cpg cn=true]


There was no going back. I felt a strange sense of fulfillment.
[cpg]


We both knew it was a bizarre situation.
[cpg]

I no longer felt lost. This was what I wanted.
[cpg]


;//移植のためシーンをカットしています



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika415"]
[OnName num="mithika"]
"......Are you sure you want to do this? Isn't it hard on you?"
[cpg cn=true]


[OnName num="shoma"]
"Don't worry about it. Your happiness is my happiness."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
She smiles. I knew what I had to do.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************



After this, we worked out a little routine.
[cpg]


I'd find another boy and introduce him to Michika.
[cpg]


I was always there for her between flings. It was a strange relationship, to be sure.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika416"]
[OnName num="mithika"]
"I think I like our little situation. It's a lot of fun and it's all thanks to you."
[cpg cn=true]


[OnName num="shoma"]
"That's good to hear. I'll have to work harder."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sMithika038"]
[OnName num="mithika"]
"......Don't you want me?"
[cpg cn=true]


[OnName num="shoma"]
"Of course I do."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sMithika039"]
[OnName num="mithika"]
"Then let's go to your house today."
[cpg cn=true]


Nodding, I saw a smile flash across her face. It was different from her usual smile. It was mine.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（昼）******************************************************



Walking around the campus, I heard all sorts of rumors about Michika.
[cpg]


[OnName num="female_student"]
"Have you heard the rumors about Ms. Arishiro ......?"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nathuko103"]
[OnName num="nathuko"]
"I have. She's even messing with guys who already have girlfriends, right?"
[cpg cn=true]


[OnName num="female_student"]
"Isn't it crazy? What is she thinking?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nathuko104"]
[OnName num="nathuko"]
"I don't know, she's not normal."
[cpg cn=true]


You'd have to talk to her to find out. But then again, there's a good chance you wouldn't understand.
[cpg]


It didn't matter much to me.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se010"]
;//【ＳＥ】『歩く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[FACE method="bow_1" pos="2/3"]
[VOICE f="Michika418"]
[OnName num="mithika"]
"You've changed a lot. You were so dark and moody at first."
[cpg cn=true]


[OnName num="shoma"]
"Have I? So am I bright and sociable now?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika419"]
[OnName num="mithika"]
"......It's hard to tell. Sometimes you seem like a hermit."
[cpg cn=true]


[OnName num="shoma"]
"What's that supposed to mean......?"
[cpg cn=true]


Did I seem like I'd given up on something? It wasn't far from the truth.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************




I flirted with Michika, but something didn't feel right.
[cpg]

Oh. I guess I no longer felt the need to touch her anymore.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="sMithika040"]
[OnName num="mithika"]
"......I think it's time for me to go home. It was fun, Shōma."
[cpg cn=true]


[OnName num="shoma"]
"You don't have to force yourself to say anything."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika421"]
[OnName num="mithika"]
"What's that supposed to mean? Are you okay?"
[cpg cn=true]


Probably not. But I wanted to see something else. I wanted to see Michika as she really was.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]


The next day. I was out looking for boys who might be interested in Michika.
[cpg]


[OnName num="male_student_A"]
"Are you serious? I guess..."
[cpg cn=true]


[OnName num="male_student_B"]
"Hold on, I've been thinking about her for a while now."
[cpg cn=true]


[OnName num="shoma"]
"Don't worry. Michika isn't picky."
[cpg cn=true]




[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************


And after school in the classroom. I had brought two boys today.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMithika041"]
[OnName num="mithika"]
"There's two this time..…"
[cpg cn=true]


[OnName num="male_student_A"]
"......"
[cpg cn=true]


It was kind of awkward for the boys.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sMithika042"]
[OnName num="mithika"]
"It kinda feels like a harem."
[cpg cn=true]


That was one way to describe it......
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Michika continues to increase her friends.
[cpg]

There was more to it than that, of course.
[cpg]

[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


Another day, Michika and I are together. It's just the two of us.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sMithika043"]
[OnName num="mithika"]
;//「……あんがとね。翔馬」
"Thanks ......."
[cpg cn=true]


[OnName num="shoma"]
"I just did what I wanted to do."
[cpg cn=true]


I gave up trying to monopolize her long ago. I didn't expect to win her affections.
[cpg]


She started to say something I never thought I'd hear.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Michika441"]
[OnName num="mithika"]
"You're the first guy who's ever done so much for me. It feels weird."
[cpg cn=true]


[OnName num="shoma"]
"......What's this all of a sudden?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika442"]
[OnName num="mithika"]
"I like you, Shōma. Hey, will you go out with me?"
[cpg cn=true]


......I was shaken. I'd gone so far, I thought I could never return. Then she'd reached out to me.
[cpg]


After all this time, she was trying to pull me back.
[cpg]


I couldn't answer right away.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Michika443"]
[OnName num="mithika"]
"Hey......don't you want me to be your girlfriend? What do you think?"
[cpg cn=true]


I had to come up with an answer. Now.
[cpg]



[free time=1000]
[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[WAIT time=1000]
;//ＢＫ



I was torn. Michika had shattered me and put me back together.
[cpg]

She was so cute......I adored her. But my heart held no other emotion.
[cpg]

[SCENE id=17]

[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン１ギャルルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
