
*start

;#################################################
*Ep003|How do I want to end up with these girls?
;#################################################

[SCENE id=3]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



Morning comes. As usual, breakfast is prepared by my parents.
[cpg]


They are busy people, but they seem to take good care of me.
[cpg]


I wonder if they are concerned about my twisted personality after moving from one place to another so many times.
[cpg]


Today is my day off. What should I do? ......
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



[OnName num="shoma's_mother"]
"Well then, have a good day."
[cpg cn=true]


[OnName num="shoma"]
"I'll see you later. I'm off."
[cpg cn=true]



[SE f="se011"]
;//【ＳＥ】『ドア開閉』


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』


It's not like I don't have friends. I get along with a few of the guys in my class and I even have Michika and Mei's phone numbers.
[cpg]


Natsuko doesn't really seem like the type to meet up with on the weekends, not that I have her number anyways.
[cpg]


Should I meet up with Michika? Or perhaps Mei? Either way, I figured I'd have some fun over the weekend.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************



After much deliberation, I decided to head into the city alone and explore a bit.
[cpg]


It's not that I chickened out or anything. I'll say this much for my own honor.
[cpg]


I was just a little scared to call up a gal.
[cpg]


I mean what would I do if they turned me down?
[cpg]


I wasn't a chicken. Probably.
[cpg]


Besides, I'd only just moved here, I should take the time to learn where everything was.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



Time passed quickly, it was already evening.
[cpg]


Just as I was about to head home, I ran into a familiar face.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michika050"]
[OnName num="mithika"]
"Hey Shōma, you headed to the arcade?"
[cpg cn=true]


I bumped into Michika in front of the arcade.
[cpg]


Michika was not alone, she was with three other gals.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika051"]
[OnName num="mithika"]
"It's kinda late but why don't you hang with us for a bit?"
[cpg cn=true]


[OnName num="shoma"]
"I'll pass, I don't want to intrude."
[cpg cn=true]


[OnName num="female_student_A"]
"That's right, it's no fun to tease him like this. Michika."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Michika052"]
[OnName num="mithika"]
"I don't know, I think it would be fun, he's my type."
[cpg cn=true]


That's good to know, but I didn't want to get my hopes up.
[cpg]


[OnName num="shoma"]
"Anyways, I'll see you at school....."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]

Don't think anything. With that thought, I waved and started walking.
[cpg]


Did I just blow a golden opportunity? Thinking about that, I returned to my house.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I went to my room and thought to myself.
[cpg]


How do I want to end up with these girls? As friends? As girlfriends?
[cpg]


Somehow it felt wrong to just approach them without a clear goal in mind.
[cpg]


If, by some chance, I was able to make one of them my girlfriend, I need to think about who I like ...... once again.
[cpg]


With that thought, I go to sleep.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



The weekend continues. I thought I'd walk around town again, but ......
[cpg]


This time I chose to head to school.
[cpg]


Maybe there were students participating in club activities. I was curious to see what was happening at school on the weekend.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（朝）******************************************************



[OnName num="shoma"]
"......It's so quiet."
[cpg cn=true]


I guess that wasn't surprising since it was a weekend.
[cpg]


What am I doing here? I feel like an alumni or something, even though I haven't graduated yet.
[cpg]


As I was thinking that, I heard a voice, so I walked in that direction.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



[OnName num="male_student"]
"Oh, I don't have any money ......"
[cpg cn=true]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Nathuko046"]
[OnName num="nathuko"]
"You sure about that? Jump and let's see what we hear."
[cpg cn=true]


A classic as far as muggings go...the instigator looked awful familiar.
[cpg]


How often do you see a girl mugging a boy? It was a rare occasion, but I decided to step in.
[cpg]


[OnName num="shoma"]
"Cut it out, Natsuko! This is bad."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nathuko047"]
[OnName num="nathuko"]
"Shōma? Get outta here, this ain't none of your business."
[cpg cn=true]


[OnName num="shoma"]
"I can't. What if someone finds out or tells on you?"
[cpg cn=true]


Natsuko had grabbed the frail-looking boy by the chest, but then let him go.
[cpg]

[free time=1000]
Then, without saying a word, she left the place ......
[cpg]


[OnName num="male_student"]
"Thanks..."
[cpg cn=true]


What good was his thanks to me? If only I'd saved a girl instead...
[cpg]


[OnName num="shoma"]
"......Sucks, man. You do something to offend her?"
[cpg cn=true]


[OnName num="male_student"]
"No, not really.....I just confessed to the first year Miyako-san."
[cpg cn=true]


Miyako? It was an unusual last name. Natsuko and I were 2nd year students, meaning he'd tried to get close to her sister?
[cpg]


I couldn't be sure, but it made sense. Natsuko being protective of her younger sister really fit her image.
[cpg]


But still, I never thought I'd run into her on the weekend.
[cpg]


Maybe he confessed his feelings to the younger sister on Saturday and Natsuko made him come to school today?
[cpg]


[OnName num="shoma"]
"......So, did your confession go well?"
[cpg cn=true]


[OnName num="male_student"]
"No, I was rejected..."
[cpg cn=true]


This poor guy......oh well, I had other things to worry about.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



I looked around the grounds and gymnasium. As expected, there were people doing club activities......
[cpg]


Satisfied, I decided to go home.
[cpg]


My little excursion had proven fruitful. I'd learned that Natsuko likely had a younger sister.
[cpg]


And I'd learned that she was quite protective of said sister. It was a precious opportunity to see what Natsuko was really like.
[cpg]


......Still, it's a little early to be going home.
[cpg]


[OnName num="shoma"]
"I think I'll stop by the arcade ......."
[cpg cn=true]


The other day, Michika and her friends prevented me from entering.
[cpg]


I don't have any hobbies, so it's not like I was particularly interested in games.
[cpg]


I wasn't fond of the atmosphere peculiar to the arcade either. But in my life, entertainment could be hard to come by.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I decided to head back home shortly. I'd reaffirmed that gaming wasn't really for me.
[cpg]


It hadn't been a total waste of time. At least I'd been able to confirm once again that I had no real hobbies.
[cpg]




[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I guess I've become a boring person with a boring personality.
[cpg]


Was there anything about me that was remotely attractive?
[cpg]


Michika and Mei had proactively reached out and talked to me. Were they just really nice?
[cpg]


I guess gals tend to be easy-going. Maybe they were surprisingly kind to social outcasts.
[cpg]


That said, I'd also heard stories about them bullying loners.
[cpg]


Maybe those stories were just stories. Maybe I was just lucky. It was hard to tell......
[cpg]


[jump storage="ep004.ks" target="*start"]


;////////////////////////////////////////////////////////////////////////
