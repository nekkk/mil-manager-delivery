
*start


;//==============================
;//ヒロイン２がギャルである場合

*end2_citch|浮気性の夏子



Natsuko. I want to be her boyfriend.
[cpg]


I knew she was a delinquent, and the type to play around, but……
[cpg]


Even still, I couldn't get her out of my mind.
[cpg]

I want to be her number one. With that in mind, I headed to school.
[cpg]


;#################################################
*Ep011|Flirtatious Natsuko
;#################################################

[SCENE id=11]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika454"]
[OnName num="mithika"]
"Natsuko? You want to confess to her? I'd...reconsider, if I were you…"
[cpg cn=true]


[OnName num="shoma"]
"Why? Tell me."
[cpg cn=true]


Michika seemed hesitant when I told her of my intention to confess my feelings to Natsuko.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Michika455"]
[OnName num="mithika"]
"She's...not really the monogamous type......If you go out with her, you'll see what I mean."
[cpg cn=true]


[OnName num="shoma"]
"I don't care, I can change her. I'm gonna make her say I'm the only guy for her."
[cpg cn=true]


Slightly exasperated, Michika waves me off.
[cpg]


Was I really that out of my league?
[cpg]

[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="4/5" time=800]

[VOICE f="Mei099"]
[OnName num="mei"]
"Huhhh? You're planning on confessing to Natsuko?"
[cpg cn=true]


[OnName num="shoma"]
"Don't spread it around too much......"
[cpg cn=true]


That said, I was planning on telling her how I felt today, so there wouldn't be much risk of Natsuko finding out beforehand.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Michika456"]
[OnName num="mithika"]
"I tried to warn him, but he doesn't want to hear it."
[cpg cn=true]


They talk in hushed tones, I couldn't pick up much of their conversation.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Mei100"]
[OnName num="mei"]
"Hmmm, I guess Shōma's the stubborn type."
[cpg cn=true]


It sounded like they were talking about me……what did they know?
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



In the evening I called Natsuko to a quiet spot. I was ready to confess my feelings.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nathuko308"]
[OnName num="nathuko"]
"What do you want from me?"
[cpg cn=true]


[OnName num="shoma"]
"......I'm only going to say this once. Listen carefully."
[cpg cn=true]


Or rather, I only had the guts to say it once.
[cpg]


[OnName num="shoma"]
"I've always loved you. Please go out with me."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Nathuko309"]
[OnName num="nathuko"]
"......What? Say it again."
[cpg cn=true]


I said I would only say it once. But fine, I'll say it again if that's what she wants.
[cpg]


[OnName num="shoma"]
"I said I love you. I want you to go out with me."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nathuko310"]
[OnName num="nathuko"]
"Well that's new. I've never had a guy try to make a pass at me before."
[cpg cn=true]


Natsuko scratches her head. I couldn't tell if she was enthusiastic or not.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nathuko311"]
[OnName num="nathuko"]
"Okay, fine. Let's go out then."
[cpg cn=true]


[OnName num="shoma"]
"Really ……? That was easier than I thought."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nathuko312"]
[OnName num="nathuko"]
"What, did you want me to string you along for a bit first?"
[cpg cn=true]


[OnName num="shoma"]
"No, of course not. I'm really glad you said yes."
[cpg cn=true]


I was so happy I doubted my ears for a moment.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』


Things proceeded quickly.
[cpg]


;//移植のためシーンをカットしています

We walk the streets, late in the evening. It was getting late and my parents were probably wondering where I was.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sNathuko025"]
[OnName num="nathuko"]
"Why're you acting so squirrely all of a sudden?"
[cpg cn=true]


[OnName num="shoma"]
"Oh......I thought we should be getting back soon. I mean, it's late and our parents are probably getting worried."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="sNathuko026"]
[OnName num="nathuko"]
"So? I thought you wanted to go out with me."
[cpg cn=true]


Even so, it's not like I could stay out all night.
[cpg]


[SE f="se011"]
;//【ＳＥ】『ドア開く』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]

[OnName num="shoma"]
"I'm back......"
[cpg cn=true]


I was a little late for dinner. My parents questioned me, but seemed satisfied after I told them I'd gotten a girlfriend.
[cpg]


I guess they were happy to see that I was making connections.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I was feeling awfully tired today. It was a day of ups and downs.
[cpg]


I certainly wasn't prepared for her to bring me around so much on our first day as a couple.
[cpg]


It couldn't be helped, I tell myself.
[cpg]


We can change it as we went along. After all, we had plenty of time ahead of us. With that in mind, the next morning.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』



[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika457"]
[OnName num="mithika"]
"So, how was your first day as a couple?"
[cpg cn=true]


[OnName num="shoma"]
"Well, it's a little early to say anything. I didn't really see anything that suggested she was a serial cheater."
[cpg cn=true]


I was rather surprised that she knew we were dating.
[cpg]


It was hard to imagine Natsuko telling anybody, so Michika must have known that my confession was going to go well.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Michika458"]
[OnName num="mithika"]
"Yeah, she's not the type to turn anybody down. If anything, she's more likely to approach guys as long as she thinks they're fun."
[cpg cn=true]


I got a little worried. Was she right?
[cpg]


[OnName num="shoma"]
"But…...no wait, that rings a bell."
[cpg cn=true]


I'd seen her with a boy in an alleyway before.
[cpg]


So what...was she finding guys to play with all over the place?
[cpg]


[OnName num="shoma"]
"But she said she'd go out with me? She wouldn't cheat on me, right?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Michika459"]
[OnName num="mithika"]
"Yeah, uhh.....it's kind of hard to tell with her."
[cpg cn=true]


I guess Michika didn't know much about it either.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



Lunchtime at the school. I go to Natsuko's class.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nathuko334"]
[OnName num="nathuko"]
"Cheating? Me?"
[cpg cn=true]


[OnName num="shoma"]
"I'm not saying you did, but Michika keeps telling me things and..."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Nathuko335"]
[OnName num="nathuko"]
"I'm not going to cheat on you. We like each other, right?"
[cpg cn=true]


I felt relieved. Michika must have been mistaken.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Nathuko336"]
[OnName num="nathuko"]
"Anyway, can I come over to your house today?"
[cpg cn=true]


[OnName num="shoma"]
"Today? Uhh sure, why not?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="sNathuko027"]
[OnName num="nathuko"]
"I thought you'd be a little happier."
[cpg cn=true]


She is a straightforward girl. But there was something comfortable about how she closed the distance between us.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************


And after school. Natsuko and I left school together.
[cpg]


[OnName num="shoma"]
"Shall we hold hands? ......"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Nathuko337"]
[OnName num="nathuko"]
"Yeah, we are dating after all."
[cpg cn=true]


It's really like she accepts everything that comes to her. She does whatever I want.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


We reach my room. Conveniently, both of my parents are out today.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nathuko338"]
[OnName num="nathuko"]
"I thought there would be more idol posters or something."
[cpg cn=true]


[OnName num="shoma"]
"Really? Did you think I was a nerd or something?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko339"]
[OnName num="nathuko"]
"Nah, it's just most guys have posters of girls on their walls."
[cpg cn=true]


Really? Wait, how would she know?
[cpg]


…….I guess she probably had an ex-boyfriend or two.
[cpg]


I decided not to think about it, I was her number one right now.
[cpg]

;//移植のためシーンをカットしています



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
;//ＢＫ

We flirt and chat for a bit.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



As it was getting late, I decided to send Natsuko back home before my parents returned.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Nathuko356"]
[OnName num="nathuko"]
"Hey, Shōma. You're going to love me no matter what, right?"
[cpg cn=true]


[OnName num="shoma"]
"Huh? What's this about?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko357"]
[OnName num="nathuko"]
"Be a man and give me a clear answer."
[cpg cn=true]


I guess she had a point. I took a moment to gather my words.
[cpg]


[OnName num="shoma"]
"Of course, I'm going to love you no matter what......."
[cpg cn=true]


I thought it was a good, manly answer. Hopefully it was enough for Natsuko.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Nathuko358"]
[OnName num="nathuko"]
"Well that's good. See you later then."
[cpg cn=true]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



The next morning on the way to school. I joined Mei on the way.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mei101"]
[OnName num="mei"]
"Good morning. Shōma."
[cpg cn=true]


[OnName num="shoma"]
"Good morning, Mei. Umm..."
[cpg cn=true]


I'd spent most of the night thinking. Why would Natsuko ask me something like that?"
[cpg]


[OnName num="shoma"]
"Do you think......Natsuko is cheating on me?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mei102"]
[OnName num="mei"]
"Hmmm. I don't know, have you asked her?"
[cpg cn=true]


[OnName num="shoma"]
"She said she wouldn't."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Mei103"]
[OnName num="mei"]
"Then she probably won't. Oh, but then again...it is Natsuko we're talking about."
[cpg cn=true]


It didn't seem like I was going to get any assurances from Mei.
[cpg]


There probably wasn't any point in pressing her further.
[cpg]


[OnName num="shoma"]
"Sorry, I know it's not your problem."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei104"]
[OnName num="mei"]
"Don't worry about it. I'm always here for you if you need me."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



The classroom during recess. I went to Natsuko's class to find Natsuko and Michika giggling about something together.
[cpg]


It seemed inappropriate to barge into their conversation, so I hung back and tried to listen in for a bit.
[cpg]


......I couldn't hear a thing over all the noise.
[cpg]


I gave up and entered the classroom.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Nathuko359"]
[OnName num="nathuko"]
"Hey Shōma."
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Michika460"]
[OnName num="mithika"]
"Oh, hey. Did you need Natsuko for something? Oh wait, you two are going out now, huh."
[cpg cn=true]


[OnName num="shoma"]
"Yeah......umm. Did you...? You know..."
[cpg cn=true]


I wanted to ask her out again. I was afraid she might cheat on me.
[cpg]


If she spent all her time with me, she wouldn't have time to look at other guys.
[cpg]


But with Michika here, I felt a little awkward.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="sNathuko028"]
[OnName num="nathuko"]
"What, you want to spend some time alone? I don't mind, but what are we even gonna do?"
[cpg cn=true]


Natsuko knew exactly what I wanted and wasn't afraid to say it.
[cpg]


It was probably a good thing. I certainly appreciated that part of her.
[cpg]


[FACE method="shake_6" pos="2/5"]
[VOICE f="Michika461"]
[OnName num="mithika"]
"Wow, get a room. I wish I had a boyfriend too."
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Nathuko361"]
[OnName num="nathuko"]
"You could probably have your pick of the lot if you wanted."
[cpg cn=true]


They go back to chatting. I felt a little out of place.
[cpg]


But I didn't want to come off as overbearing or needy. I had to be patient.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』



I decided to wait for Natsuko at the gates.
[cpg]


I waited and waited, but she didn't show up.
[cpg]


Right when I was thinking about going home, I saw her walking up to me……
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nathuko362"]
[OnName num="nathuko"]
"Is that you, Shōma? What are you still doing here?"
[cpg cn=true]


[OnName num="shoma"]
"That's my line. Why are you going home so late?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sNathuko029"]
[OnName num="nathuko"]
"Oh you know. I had a little business to take care of."
[cpg cn=true]



;//ＢＫ


[OnName num="shoma"]
"The sun's already set......you wanna go somewhere or something?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sNathuko030"]
[OnName num="nathuko"]
"......Well, not like I'm gonna force you or anything."
[cpg cn=true]


Natsuko comes up with an idea.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夜）******************************************************


We'd sneak back into the school at night. It sounded crazy, but it was definitely something she'd do.
[cpg]

Unsurprisingly, she knew just how to get in.
[cpg]


Night had already fallen and we were wandering around the campus.
[cpg]


[OnName num="shoma"]
"......This is probably illegal, right?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko364"]
[OnName num="nathuko"]
"Who cares?"
[cpg cn=true]


To Natsuko the school itself might just seem like some kind of quiet place for her to bring boys.
[cpg]


We ended up in the infirmary in the middle of the night......
[cpg]



;//========================================
;//●ＣＧエロ（ベッドに横たわっているヒロイン。迫る主人公）ev_36
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園保健室
;//時間　：夜
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


The infirmary at night.
[cpg]

[VOICE f="sNathuko031"]
[OnName num="nathuko"]
"......Well, we're here. Don't keep me waiting."
[cpg cn=true]


She had a point, I'd followed her all the way here.
[cpg]

But I didn't feel ready to cross that line yet.
[cpg]

[VOICE f="sNathuko032"]
[OnName num="nathuko"]
"Wuss."
[cpg cn=true]


I kissed her but I don't think it was enough for her.
[cpg]


;//移植のためシーンをカットしています
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


It was late. We had to get back.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夜）******************************************************


We walk through the school at night in silence. This time, we were sneaking out.
[cpg]


It was surprisingly quiet.
[cpg]


Unable to bear the silence, I tried to reconcile what had happened earlier.
[cpg]


[OnName num="shoma"]
"I love you, Natsuko. More than anyone else in this world."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sNathuko033"]
[OnName num="nathuko"]
"Yeah, well prove it. Don't wimp out on me again."
[cpg cn=true]


[OnName num="shoma"]
"......"
[cpg cn=true]


It didn't look like my words had much effect. Natsuko seemed strangely used to men.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


[FACE method="bow_1" pos="2/3"]
[VOICE f="sNathuko034"]
[OnName num="nathuko"]
"I guess I'll see you later. Call me when you want me."
[cpg cn=true]


[OnName num="shoma"]
"I'm not going to treat you like an object..."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Nathuko383"]
[OnName num="nathuko"]
"Even if I'm the one telling you to? Stop overthinking things."
[cpg cn=true]

[free time=1000]


Even still, it wasn't something I could change so quickly. We parted and I headed home.
[cpg]


I don't have to tell my parents why I get home so late anymore.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]


Days pass. It's the weekend.
[cpg]


We'd scheduled a date for today. I got up early to prepare.
[cpg]


[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』



[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nathuko384"]
[OnName num="nathuko"]
"Hey. So is this like our first date?"
[cpg cn=true]


[OnName num="shoma"]
"......Well, yeah."
[cpg cn=true]


I guess she's been on dates before. With other guys.
[cpg]


It's all I can think about anymore.
[cpg]


I have to stop suspecting her like this. She told me she wasn't going to cheat on me.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



Even when we went to karaoke, we just kind of flirted with each other and didn't sing much.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[OnName num="shoma"]
"You know......I think these karaoke boxes have a lot of surveillance cameras."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sNathuko035"]
[OnName num="nathuko"]
"So?"
[cpg cn=true]


[OnName num="shoma"]
"So we can't...you know, do anything in here."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
;//[VOICE f="Nathuko388"]
[VOICE f="sNathuko036"]
[OnName num="nathuko"]
"......Fine."
[cpg cn=true]


Natsuko seems frustrated and starts to pout.
[cpg]


I didn't really want to get in trouble.
[cpg]



;//ＢＫ



.......We should have ended our relationship here.
[cpg]


What I did after was something I'd come to regret.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


Natsuko left in a huff. Curious, I decided to follow her.
[cpg]


She talked to someone on the phone and then wandered about the area for a bit.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

She met up with another guy. I didn't recognize him.
[cpg]


From the looks of his face, he was close to my age...maybe younger.
[cpg]


[OnName num="male_student"]
"Not again. What about your boyfriend?"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Nathuko389"]
[OnName num="nathuko"]
"It's fine, my heart's his."
[cpg cn=true]


[OnName num="male_student"]
"Well, I'm not going to complain."
[cpg cn=true]


They head into an alleyway.
[cpg]


I had to follow them.
[cpg]



;//========================================
;//●ＣＧエロ（男に迫るヒロイン）ev_37
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：モブ男
;//服装２：私服
;//場所　：路地裏
;//時間　：夜
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_37_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]



;//移植のためシーンをカットしています

Natsuko drapes herself over him. She moves in for a kiss.
[cpg]

[VOICE f="sNathuko037"]
[OnName num="nathuko"]
"You're more of man than he is."
[cpg cn=true]


[OnName num="male_student"]
"Wow, I thought you said your heart was his."
[cpg cn=true]


[VOICE f="sNathuko038"]
[OnName num="nathuko"]
"He won't mind. Besides, I think you're cool too."
[cpg cn=true]


I couldn't watch any more of this.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[OnName num="shoma"]
"Natsuko? What are you doing...?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko406"]
[OnName num="nathuko"]
"Huh? Oh, hi Shōma."
[cpg cn=true]


[OnName num="male_student"]
"Shōma? Do you know him?"
[cpg cn=true]


He didn't know my name. I guess that was a given.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nathuko407"]
[OnName num="nathuko"]
"That's my boyfriend. You want to join us?"
[cpg cn=true]


[OnName num="shoma"]
"What are you thinking...? You said you wouldn't cheat on me."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sNathuko039"]
[OnName num="nathuko"]
"This isn't cheating. You're my lover and he's just my friend."
[cpg cn=true]


What was she saying? That's not the kind of thing you'd do with a friend.
[cpg]


[OnName num="shoma"]
"......Are you okay with this?"
[cpg cn=true]


[OnName num="male_student"]
"Yeah, I mean I got a girlfriend, so no skin off my back."
[cpg cn=true]


I felt like I was losing my mind. Was I the only one who felt this void?
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Nathuko409"]
[OnName num="nathuko"]
"Don't worry, I'm always thinking about you……"
[cpg cn=true]


;//移植のためシーンをカットしています

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Back at home, I felt like crying, but I couldn't.
[cpg]


Is this the best relationship for us?
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]


[OnName num="shoma"]
"......Good morning, Natsuko."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nathuko427"]
[OnName num="nathuko"]
"Oh, hey. What's up, you want to break up already?"
[cpg cn=true]


I couldn't see any trace of remorse on her face. She seemed perfectly normal.
[cpg]


[OnName num="shoma"]
"No. I'm fine with whoever you're dating. I'm fine with it."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sNathuko040"]
[OnName num="nathuko"]
"I'm not dating him, we're just friend. Don't blow things out of proportion."
[cpg cn=true]


......I hadn't intended to, but it seems that to Natsuko, what she'd done wasn't even worth getting angry about.
[cpg]



[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************



Our relationship continues. Sometimes we go out on dates.
[cpg]


I think I'm happy. I can't separate myself from Natsuko anymore.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michika462"]
[OnName num="mithika"]
"You don't look so good…… Are you okay?"
[cpg cn=true]


[OnName num="shoma"]
"I'm fine......I'm happy."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika463"]
[OnName num="mithika"]
"Happy? What are you talking about?"
[cpg cn=true]


It wasn't just Michika. Most of the people around me seemed worried about me.
[cpg]


Even my male friends were worried about how Natsuko treated me.
[cpg]


If only they knew how right they were......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[WAIT time=1100]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nathuko429"]
[OnName num="nathuko"]
"Hey, wanna go home together?"
[cpg cn=true]


[OnName num="shoma"]
"Yeah......."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sNathuko041"]
[OnName num="nathuko"]
"You're so bitter. If me having guy friends bothers you so much, it's going to be hard to tell you the big news."
[cpg cn=true]


Big news? What did she mean?
[cpg]


Was there a new guy? No, that wouldn't surprise me anymore.
[cpg]


I was okay. I was confident that we could get through whatever it was.
[cpg]


At this point, I didn't fully understand what she'd done.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



No matter how much time I spent with her, some part of me panicked.
[cpg]


What I saw that day keeps coming back, fresher and clearer each time.
[cpg]


Natsuko wouldn't say something like that, yet her words echo in my head.
[cpg]


......It was happening again. I kept spiralling into a dark place.
[cpg]


I knew what I had to do. I had to go to sleep. I'd wake up and everything would be fine again.
[cpg]


Nothing worse than this could possibly happen. That was some small relief.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Or so I thought. Natsuko always manages to surprise me.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************

It was noon at school. My bag falls to the floor with a dull thunk.
[cpg]

[OnName num="shoma"]
"Pregnant……? How? No, whose......is it?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nathuko431"]
[OnName num="nathuko"]
"It doesn't matter. If you're my lover, you'll accept and love the both of us, right?"
[cpg cn=true]


It didn't...matter? Was she serious?
[cpg]


She seemed almost alien to me. Her thought process was incompatible with mine.
[cpg]


[OnName num="shoma"]
"I don't know what to say, it's too sudden."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko432"]
[OnName num="nathuko"]
"Yeah, I guess. I'll give you some time to think about it. We can either get married or just break up."
[cpg cn=true]


[OnName num="shoma"]
"I don't want to leave you Natsuko! I want to stay with you!"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

The words came from the heart. Natsuko looked a little surprised……
[cpg]


It was actually refreshing. At least I knew that she as capable of feeling surprise.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Nathuko433"]
[OnName num="nathuko"]
"Do you really like me that much?"
[cpg cn=true]


[OnName num="shoma"]
"Yes. I love you."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Nathuko434"]
[OnName num="nathuko"]
"All right. Then let's get married after we graduate."
[cpg cn=true]


Normally I'd be the one asking, but what use was normal to us anyways?
[cpg]


The child she is carrying might not be mine. It wouldn't be hard to find out, but I don't think I had it in me.
[cpg]


......I'm too scared to know the answer.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Time seems to fly by in an instant.
[cpg]


I found a job right after graduating.
[cpg]


I had a child to take care of, what choice did I have?
[cpg]

[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=3000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]

;//【ＢＧ】『街』（朝）******************************************************


I became a working adult. Natsuko became a mother. But that doesn't mean I've become a father yet.
[cpg]


[OnName num="shoma"]
"Okay, I'm off to work……"
[cpg cn=true]


[VOICE f="Nathuko435"]
[OnName num="nathuko"]
"Okay. I'm going out for a bit tonight."
[cpg cn=true]


Sometimes she'll go out. She won't tell me where.
[cpg]


She might come back pregnant again.
[cpg]


That doesn't stop me. Our relationship hasn't changed since we were student.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



I work. I have to keep working, no matter how hard it is.
[cpg]


I still don't know whose child it is. It wasn't important. I had to make Natsuko happy.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



......This was the story of a man driven mad by a woman.
[cpg]


Most people will probably laugh at me. But when it happens to them, they'll understand.
[cpg]


I still remember that scene in the alleyway......
[cpg]



[SCENE id=20]

[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン２ギャルルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

