
*start

;//==============================
;//全てのヒロインが純情である場合

*end2_alvar|夏子の素顔



Natsuko. I'm in love with her.
[cpg]


She acted violent and, at times, even crude. But I feel like there was a reason for it.
[cpg]


I remember hearing that she had a younger sister. Did that have something to do with it?
[cpg]


Whatever the reason, I wanted to see what she was really like.
[cpg]


Could it be that she was actually quite naïve?
[cpg]


;#################################################
*Ep010|Natsuko's true face
;#################################################

[SCENE id=10]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************



[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko157"]
[OnName num="nathuko"]
"What are you staring at?"
[cpg cn=true]


Now that I've made up my mind, she seems somehow even more attractive.
[cpg]


If it meant I could have a relationship with her, I'd confess my feelings to her on the spot.
[cpg]


But I didn't think I had a chance, yet. Maybe I was just getting cold feet.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



An opportunity appeared when I least expected it.
[cpg]


I'd forgotten something in the classroom and had returned to get it. I was walking down the hallway to the classroom.....
[cpg]


I came across Natsuko, she had a bruise on her face.
[cpg]


[OnName num="shoma"]
"What happened!?"
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Nathuko158"]
[OnName num="nathuko"]
"It's nothing……I had to protect Yōka."
[cpg cn=true]


Had she gotten into a fight? Who was Yōka?
[cpg]


[OnName num="shoma"]
"Who is this Yōka? Is she your sister by any chance?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nathuko159"]
[OnName num="nathuko"]
"Yeah, how'd you know? Some guy tried to hit on her so I thought I'd teach him a lesson, but.....agh."
[cpg cn=true]


Natsuko was in such a state that she could hardly walk. I was afraid she would collapse.
[cpg]


[OnName num="shoma"]
"Let me lend you a hand."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nathuko160"]
[OnName num="nathuko"]
"Thanks......oof."
[cpg cn=true]


She's wobbly on her feet. I felt like she'd put most of her weight against me but she was still light.
[cpg]


She almost trips.
[cpg]


[OnName num="shoma"]
"I've got you!"
[cpg cn=true]


I put my arm around her to keep her upright. Her face is close to mine.
[cpg]

[FADEOUTBGM]

Her breath was ragged. I could see all sorts of scrapes and bruises.....She was irresistible.
[cpg]


[OnName num="shoma"]
"I've always loved you……."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Nathuko161"]
[OnName num="nathuko"]
"What th-......?"
[cpg cn=true]

[BGM f="bg_h1"]
[WAIT time=100]


[OnName num="shoma"]
"Go out with me, Natsuko. I want to protect you."
[cpg cn=true]


It was an opportunity and I took it. Even if the opportunity was a crisis.
[cpg]


Natsuko was the kind of girl who'd get into a fistfight with a boy. If I wanted to protect her, I might end up having to take beatings in her place.
[cpg]


Still, I had to say it.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Nathuko162"]
[OnName num="nathuko"]
"......Why're you telling me this now? Come on, put me down, I need to sit for a bit."
[cpg cn=true]


[OnName num="shoma"]
"Oh, yeah. Sure."
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



Natsuko sits down on the spot, her back against the wall.
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Nathuko163"]
[OnName num="nathuko"]
"......So you like me? As a girl?"
[cpg cn=true]


[OnName num="shoma"]
"I do. I really, really do."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko164"]
[OnName num="nathuko"]
"So why tell me now? I'd rather you told me when things were calmer."
[cpg cn=true]


I felt I had to say it now. I didn't have a choice.
[cpg]


[OnName num="shoma"]
"Seeing you like this is hard for me to bear. I want to protect you, Natsuko."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Nathuko165"]
[OnName num="nathuko"]
"You got a long way to go......but it's a nice thought."
[cpg cn=true]


She laughs a little.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Nathuko166"]
[OnName num="nathuko"]
"Alright, fine. I've been thinking about you too. Let's see where this goes."
[cpg cn=true]


I couldn't just let it all go and be happy. Someone had hurt her.
[cpg]


I had to do something to ensure this never happened again.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



We were a couple now......
[cpg]


But I didn't think we were a couple in the truest sense of the word.
[cpg]


She might have been interested in me, but I wasn't sure that she really liked me yet.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



The next day, I head to Natsuko's classroom.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nathuko167"]
[OnName num="nathuko"]
"What happened yesterday was, well......kind of my fault."
[cpg cn=true]


[OnName num="shoma"]
"What do you mean?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Nathuko168"]
[OnName num="nathuko"]
"There was this guy who confessed to my sister Yōka. It looked like he was coming on to her a little too strongly......"
[cpg cn=true]


Pieces of the story fell into place. Something like this had already happened before.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Nathuko169"]
[OnName num="nathuko"]
"I tried to get rid of him, but he fought back and I ended up getting whupped."
[cpg cn=true]


According to her, the boy who injured Natsuko ended up promising to stay away from Yōka.
[cpg]


Or maybe her injuries were the price she had to pay to keep him away.
[cpg]


[OnName num="shoma"]
"I see you really care for her......."
[cpg cn=true]


Natsuko nods. Maybe this was the reason for Natsuko's aggressiveness.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Nathuko170"]
[OnName num="nathuko"]
"More importantly, we......you know. We're like......a couple now, right?"
[cpg cn=true]


Natsuko voice trails off as she blushes.
[cpg]


[OnName num="shoma"]
"I sure hope so, I mean I confessed to you and everything."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Nathuko171"]
[OnName num="nathuko"]
"Well, then……can I go to your house?"
[cpg cn=true]


[OnName num="shoma"]
"......Yeah."
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se010"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko172"]
[OnName num="nathuko"]
"This doesn't seem right."
[cpg cn=true]


[OnName num="shoma"]
"What do you mean?"
[cpg cn=true]


We walking through the city, holding hands. The setting sun makes for a nice backdrop.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Nathuko173"]
[OnName num="nathuko"]
"I've never done anything like this before. I even left Yōka alone......"
[cpg cn=true]


She's talking about her sister even now.
[cpg]


[OnName num="shoma"]
"Do you like me?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nathuko174"]
[OnName num="nathuko"]
"I guess. I mean I told you I was interested."
[cpg cn=true]


She did, but what was it about me that she was interested in?
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko175"]
[OnName num="nathuko"]
"I mean, it's not every day I meet someone who didn't seem...you know, scared of me."
[cpg cn=true]


I thought I was pretty freaked out, but I guess I hid it well. I'm just glad she took it that way.
[cpg]


[OnName num="shoma"]
"I'm surprised you decided to go out with me."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Nathuko176"]
[OnName num="nathuko"]
"......Yeah, I got a feeling about you. It's like......I knew my feelings for you were gonna grow as time passes."
[cpg cn=true]


Was that a roundabout way of calling it fate? Or maybe this was women's intuition.
[cpg]


Either way, she chose me. I had to become a man worthy of her.
[cpg]


As I ponder my options, a voice calls out to us from behind.
[cpg]

[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]

[VOICE f="Michika444"]
[OnName num="mithika"]
"Whoa, are you two holding hands? Does that mean you two are…?"
[cpg cn=true]


And here I thought there weren't many rumors about us...
[cpg]


It was because we hadn't been acting like a couple at school...…
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Michika445"]
[OnName num="mithika"]
"Wow, this is big news..."
[cpg cn=true]


Of all people, it had to be Michika who saw us. I had a feeling she wasn't the type to keep secrets.
[cpg]

[free time=1000]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[OnName num="shoma"]
"......It looks like there's going to be a lot of gossip about us tomorrow."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Nathuko177"]
[OnName num="nathuko"]
"Let 'em talk."
[cpg cn=true]


It looks like we'd passed the point of no return.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


We ended up in my room. Natsuko put up a brave face, but I could tell she was nervous..
[cpg]




It's not like we'd planned on doing anything in particular, but I felt nervous too.
[cpg]


;//移植のためシーンをカットしています

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


I think we had fun talking, but I don't really remember the content.
[cpg]

Looking back, I realized I was nervous too.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


After she left, I had time to think.
[cpg]


Even if Natsuko had initiated it, I couldn't stand the fact that someone had hit her.
[cpg]


And now that she is my girlfriend, it's even more unforgivable......
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[FACE method="change_2" pos="2/3"]
[VOICE f="Michika446"]
[OnName num="mithika"]
"Good morning? Hey, you seem glum."
[cpg cn=true]


[OnName num="shoma"]
"Yeah? Well, maybe so. I have a lot to think about."
[cpg cn=true]


Michika is always full of energy. She is a different type of gal from Natsuko.
[cpg]


If only Natsuko could be as easygoing as Michika was......but I guess her little sister was a big part of her life.
[cpg]


I got the feeling that nothing I said would change her mind.
[cpg]


I'd have to prove my love for her with my actions, not my words.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika447"]
[OnName num="mithika"]
"What's on your mind? I'll lend an ear as long as you're not talking about how lovey dovey you are."
[cpg cn=true]


......My worries revolved around Natsuko, so I decided not to take her up on her offer.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************


Then we get to the academy.
[cpg]


I decided to look for the boy who hurt Natsuko. I found him sooner than I expected.
[cpg]

[free time=1000]
[WAIT time=1000]

[OnName num="male_student"]
"What do you want? I'm busy."
[cpg cn=true]


[OnName num="shoma"]
"......Are you the one who hit Natsuko?"
[cpg cn=true]


He looks like a delinquent. If it turned into a fight, I'd definitely lose.
[cpg]


[OnName num="male_student"]
"Yeah yeah, that's me. If I knew she had her sister was like that, I wouldn't have confessed to Yōka."
[cpg cn=true]


[OnName num="shoma"]
"You hit a girl man, what were you thinking?"
[cpg cn=true]


[OnName num="male_student"]
"Bro, she hit me first. All I did was protect myself."
[cpg cn=true]


[OnName num="male_student"]
"I haven't even gone near Yōka since then. I'm keeping my end of the bargain, what more do you want from me?"
[cpg cn=true]


......I wasn't sure.
[cpg]


I wanted to get back at him, but this wasn't the time.
[cpg]


But I couldn't help myself. I threw a punch.
[cpg]



[SE f="se019"]
;//【ＳＥ】『殴る』

[WAIT time=1100]

I guess he was ready for it because as soon as I pulled my arm back...
[cpg]


I took a heavy blow to my gut.
[cpg]


[OnName num="shoma"]
"Ughhh ...... ugh."
[cpg cn=true]


[OnName num="male_student"]
"It's settled, man. Quit trying to pick a fight."
[cpg cn=true]


I'm so weak......Winded, my consciousness fades.
[cpg]


;//＠
;//ＢＫ
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『保健室』（昼）******************************************************


I awoke to see Mei nearby. I must be in the infirmary.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Mei094"]
[OnName num="mei"]
"Are you okay? I found you lying in the hallway."
[cpg cn=true]


[OnName num="shoma"]
"......I'm good...ouch."
[cpg cn=true]


But Natsuko got hit, multiple times. It must have hurt a lot, but she didn't pass out.
[cpg]


She was a better fighter than I was, she could take more hits. But that meant she would have been in a lot more pain.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Mei095"]
[OnName num="mei"]
"You should stay in bed for a bit. I know you like her, but you're not a fighter."
[cpg cn=true]


I guess Mei knew all about us already……
[cpg]


Was my relationship with Natsuko already public knowledge?
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夕方）******************************************************



Then after school. Natsuko brings me to a park and sits me down on a bench. She stands in front of me, looking down at me.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko198"]
[OnName num="nathuko"]
"Did you seriously try to fight that guy?"
[cpg cn=true]


How did she find out? Mei must have told her......
[cpg]


[OnName num="shoma"]
"Yeah, it was the first time I've ever tried to hit someone."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Nathuko199"]
[OnName num="nathuko"]
"I can't believe it. How many times did he get you?"
[cpg cn=true]


......On the contrary, I fainted after a single hit. Not that I'd ever tell her that.
[cpg]


[OnName num="shoma"]
"It was a slugfest. I wish you could have seen it, I almost had him."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Nathuko200"]
[OnName num="nathuko"]
"If that were true, you'd be turning purple from all of the bruises. You're not a fighter, don't push yourself like that."
[cpg cn=true]


She saw right through me. I guess it was pointless to pretend.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Nathuko201"]
[OnName num="nathuko"]
"But, well......I guess I finally know what I like about you."
[cpg cn=true]


[OnName num="shoma"]
"What do you mean......?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Nathuko202"]
[OnName num="nathuko"]
"Shōma, you're pretty manly. I mean, not as you are right now. It's like you're on the right track or something......"
[cpg cn=true]


Awkward as it was, I felt like she'd given me a great compliment. It was a little embarrassing.
[cpg]


[OnName num="shoma"]
"......It's getting late. I've gotta get home."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="sNathuko021"]
[OnName num="nathuko"]
"Hold on a sec."
[cpg cn=true]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
;//ＢＫ



[SE f="se010"]
;//【ＳＥ】『歩く』



We walked together for a bit. This time, we headed deeper into the city.
[cpg]



;//========================================
;//●ＣＧエロ（抱きしめ合う二人）ev_30
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：路地裏
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNathuko022"]
[OnName num="nathuko"]
"Sorry about everything......"
[cpg cn=true]


She hugs me.
[cpg]

There was nothing to be apologetic about.
[cpg]

[OnName num="shoma"]
"There's nothing to be sorry about."
[cpg cn=true]


She shakes her head.
[cpg]


;**【ＣＧ】 ev_30_a ***********************
[CG id=13 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="sNathuko023"]
[OnName num="nathuko"]
"It was my fault, wasn't it?"
[cpg cn=true]


It was a little embarrassing. I didn't start that fight because I wanted her attention.
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//ＢＫ


I make it back to my room and relax a bit.
[cpg]


I had to get stronger. I needed to fight that guy again and win.
[cpg]


On another note, I really wanted to know what drove Natsuko to go to such lengths for her sister.
[cpg]



[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』


[FACE method="change_1" pos="2/3"]
[VOICE f="Michika448"]
[OnName num="mithika"]
"Natsuko? Oh, you want to know why she's a delinquent?"
[cpg cn=true]


[OnName num="shoma"]
"Yeah. Can you tell me a little bit more about her? I overheard you talking about it the other day."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika449"]
[OnName num="mithika"]
"Ummm, I only really know how she acts."
[cpg cn=true]


That was a start. I'd take what I could get.
[cpg]


[OnName num="shoma"]
"Tell me more."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Michika450"]
[OnName num="mithika"]
"She skips a lot of classes, but her grades are really good."
[cpg cn=true]


I see, Natsuko is smart after all. She definitely seemed like it.
[cpg]


It felt more like she had a good reason for acting like a delinquent.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



[FACE method="change_1" pos="2/3"]
[VOICE f="Nathuko222"]
[OnName num="nathuko"]
"You want to know why I'm a delinquent……? You calling me a delinquent? And to my face?"
[cpg cn=true]


It was lunch break. Natsuko was sitting on a chair, looking a little grumpy.
[cpg]


[OnName num="shoma"]
"I'm sorry. It's just that I heard you've been skipping classes......."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Nathuko223"]
[OnName num="nathuko"]
"......I told you before, I have a younger sister named Yōka."
[cpg cn=true]


Yeah, I hadn't met her yet.
[cpg]


[OnName num="shoma"]
"Are you going around beating up any boy that tries to get close to her?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Nathuko224"]
[OnName num="nathuko"]
"That ain't all, she gets bullied a lot."
[cpg cn=true]


...... I see. I'm starting to see the story.
[cpg]


It's not that she was being overprotective. There was a reason she had to intervene.
[cpg]


[OnName num="shoma"]
"Do you think I could meet her?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nathuko225"]
[OnName num="nathuko"]
"......Yeah, sure. You got time?"
[cpg cn=true]


Natsuko stands up. Wait, did that mean......
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Nathuko226"]
[OnName num="nathuko"]
"Yōka's a student here, too. She's one year below us."
[cpg cn=true]


[OnName num="shoma"]
"I see……."
[cpg cn=true]


No wonder. If they'd gone to different schools, it would be a lot harder to protect her.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（昼）******************************************************



[OnName num="hiroka"]
"Hi......it's nice to meet you. Umm...it's Shōma, right?"
[cpg cn=true]


[OnName num="shoma"]
"Nice to meet you. I'm dating your sister."
[cpg cn=true]


[OnName num="hiroka"]
"Oh...yes, I've heard......"
[cpg cn=true]


She seemed polite. Natsuko stands next to me, awkwardly blushing all the while.
[cpg]


The two of us are standing in front of Yōka.
[cpg]


[OnName num="shoma"]
"I'm going to ask you straight out. Yōka, do you feel like your sister is protecting you from being bullied?"
[cpg cn=true]


Yōka stares at me, blankly. I guess I should have tried to work it into the conversation instead.
[cpg]


After a short pause, she responds.
[cpg]


[OnName num="hiroka"]
"I do......I mean, she does."
[cpg cn=true]


I see. They're in no condition to be separated.
[cpg]


In that case, I had to protect them both. That was the only way I could see this ending.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Nathuko227"]
[OnName num="nathuko"]
"Are we done? Come on, you've got to get back to class."
[cpg cn=true]


[OnName num="shoma"]
"Yeah. See you later."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



In the classroom after school. I don't feel like going home yet.
[cpg]


I wanted her to attend classes. Thinking about her future, it was important.
[cpg]


Of course, if Natsuko had something else she wanted to do that didn't require her studies then that was fine.
[cpg]


But right now, I felt like she was only going to school to keep her sister safe.
[cpg]


I wanted her to feel like it was okay to pursue her own goals. To that end, I had to create a situation that meant she didn't have to constantly protect her sister.
[cpg]


It was simple, I'd protect Yōka in her place.
[cpg]


Unfortunately, it wasn't something I could achieve overnight. I wasn't exactly very manly.
[cpg]


But I thought I could do it. I had motivation.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nathuko228"]
[OnName num="nathuko"]
"What are you still doing here? Everybody's gone home already."
[cpg cn=true]


[OnName num="shoma"]
"Natsuko? I could say the same thing to you."
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Nathuko229"]
[OnName num="nathuko"]
"It's nothin'......."
[cpg cn=true]


I think I knew why. She wanted to go home together but I hadn't left the classroom yet.
[cpg]


Or maybe she was waiting for me at the gates. Either way, it's cute.
[cpg]


;//========================================
;//●ＣＧエロ（机に押し倒されているヒロイン。キスをする）ev_31
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_31_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNathuko024"]
[OnName num="nathuko"]
"Whaat?"
[cpg cn=true]


[OnName num="shoma"]
"Sorry, I couldn't resist."
[cpg cn=true]

;**【ＣＧ】 ev_31_a ***********************
[CG id=14 index=1 time=1]
;***************************************
[WAIT time=1]

Of course, at this stage in our relationship, there was a limit to what I could do.
[cpg]

That said, I had to do something, so I put my lips to hers.
[cpg]

Natsuko didn't mind, but she did seem surprised.
[cpg]

Just like I thought. She's plenty girly.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


On our way home, Natsuko brings up her sister.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko249"]
[OnName num="nathuko"]
"……Yōka is my problem, stay out of it."
[cpg cn=true]


[OnName num="shoma"]
"What do you mean......?"
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Nathuko250"]
[OnName num="nathuko"]
"I'm the only one who can protect Yōka. I have to be the one to protect her."
[cpg cn=true]


But that's not the solution. Natsuko was smart, she needed to focus on her studies.
[cpg]


[OnName num="shoma"]
"Did you become a delinquent because you wanted to be a delinquent?"
[cpg cn=true]


She didn't respond. I was missing something.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se010"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


Natsuko and I part ways and I walk down a street near the school.
[cpg]


[OnName num="male_student_A"]
"Please, I don't have anything....."
[cpg cn=true]


[OnName num="male_student_B"]
"Nothing? I bet you've got a wallet, right?"
[cpg cn=true]


I didn't know if it was a mugging or bullying, but whatever it was, I couldn't pretend I hadn't seen anything.
[cpg]


There were two boys. A bully and his victim, I guess.
[cpg]


In the past I would have ignored it. I didn't want to get involved.
[cpg]


But I needed experience. I had to learn how to fight if I wanted to stand a chance against him.
[cpg]


The guy who hit Natsuko……
[cpg]


[OnName num="shoma"]
"Pick on someone your own size."
[cpg cn=true]


[OnName num="male_student_B"]
"The hell're you......?"
[cpg cn=true]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



Fists flew, but it seems my opponent wasn't much of a fighter either.
[cpg]


Thankfully he gave up right around the point my stamina was about to run out.
[cpg]


Surprisingly, he didn't seem particularly vengeful.
[cpg]


[OnName num="male_student_B"]
"The hell, man!? I'm out, why you gotta stick your nose into this?"
[cpg cn=true]


I guess modern delinquents knew when to cut and run.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



Taking a bath hurt that night. Not that I soaked my body, I decided that washing up in the shower was painful enough.
[cpg]


Thinking I'd grown a little stronger, I fell asleep satisfied.
[cpg]



[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_01_1.ui" time=1000]
[WAIT time=3000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mei096"]
[OnName num="mei"]
"What's wrong? You're covered in bruises."
[cpg cn=true]


Mei points out the obvious. We'd run into each other on our way to school.
[cpg]


[OnName num="shoma"]
"I got into a fight."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Mei097"]
[OnName num="mei"]
"With Natsuko…..!?"
[cpg cn=true]


Of course not! Wait, to outsiders that might be their first thought…
[cpg]


If Natsuko and I got into a fight, she'd probably wipe the floor with me.
[cpg]


She was more used to fighting than I was.
[cpg]


[OnName num="shoma"]
"It wasn't her, trust me. Please don't spread any weird rumors about us."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mei098"]
[OnName num="mei"]
"Okaaaay fine. Don't do anything too crazy, okay?"
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

I had a similar conversation with Natsuko, after we met up later.
[cpg]


;//【ＢＧ】『学園教室』（昼）******************************************************


[FACE method="shock_5" pos="2/3"]
[VOICE f="Nathuko251"]
[OnName num="nathuko"]
"......What happened to you?"
[cpg cn=true]


[OnName num="shoma"]
"I thought I'd get some experience in."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nathuko252"]
[OnName num="nathuko"]
"A wimp like you doesn't need to learn how to fight."
[cpg cn=true]


[OnName num="shoma"]
"Come on, think of it as my first step in becoming top dog around here."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
Natsuko paused for a moment, her mouth agape.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko253"]
[OnName num="nathuko"]
"I'm in awe at how you can say something so farfetched without blushing."
[cpg cn=true]


[OnName num="shoma"]
"I'm serious. Think about it, the timid transfer student starts a zero and ends up the hero."
[cpg cn=true]


"You are unfathomably stupid." she says, exasperated. Maybe she was right.
[cpg]


My love for Natsuko was taking me down a most unusual path.
[cpg]


I probably wasn't thinking rationally.
[cpg]


[OnName num="shoma"]
"I want you to be able to do what you want to do. If you're playing the delinquent because you don't have a choice, then I'll take your place."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Nathuko254"]
[OnName num="nathuko"]
"......Are you serious?"
[cpg cn=true]



[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************


Unfortunately, it wasn't enough to convince Natsuko to stop skipping class.
[cpg]


She was still acting like a delinquent. I had to try something else.
[cpg]


But in the long run, I think this was the right course of action to take. It might take a while, but I would become manlier. More dependable.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]


The following weekend.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


[SE f="se010"]
;//【ＳＥ】『歩く』



Part of my plan to become a manlier and more dependable involved protecting the weak from the jaws of evil.
[cpg]


Of course, I wasn't going to just walk up to a delinquent and attack them or anything.
[cpg]


That said, it wasn't every day you ran into a scene like before.
[cpg]


I was wondering what to do.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nathuko255"]
[OnName num="nathuko"]
"You free right now?"
[cpg cn=true]


I ran into Natsuko by accident. It seems she had been looking for me.
[cpg]


We were close to my house so it's possible she'd checked if I was home first.
[cpg]


[OnName num="shoma"]
"I've got a goal but I'm not sure how to achieve it right now. I guess you could say I'm free."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nathuko256"]
[OnName num="nathuko"]
"Good......do you wanna come over to my place?"
[cpg cn=true]


Natsuko looked quite serious, it wasn't a situation where I could turn her down.
[cpg]


[OnName num="shoma"]
"Alright, let's go."
[cpg cn=true]

[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]

We walk together for a bit, holding hands.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Nathuko257"]
[OnName num="nathuko"]
"I get it...you're serious about protecting Yōka."
[cpg cn=true]


[OnName num="shoma"]
"Yeah."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko258"]
[OnName num="nathuko"]
"If you're a man of your word, then……I guess I could change too."
[cpg cn=true]


[OnName num="shoma"]
"I don't want you to feel like I'm forcing you to do anything."
[cpg cn=true]


If she likes the delinquent lifestyle, then it was my job to support her.
[cpg]


But when I mentioned that it didn't suit her, Natsuko went quiet.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



She brings me to her room. It was a rather normal, girly room.
[cpg]


[OnName num="shoma"]
"You know, I was half-convinced you'd have a punching bag or something set up in here."
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]

Natsuko gives me a swift poke. I felt like we were getting closer and I loved every second of it.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]


We talk for a while.
[cpg]


I decide to leave before her parents get home.
[cpg]


;//【ＢＧ】『街』（夕方）******************************************************


[free time=800]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nathuko277"]
[OnName num="nathuko"]
"......Hey, Shōma."
[cpg cn=true]


[OnName num="shoma"]
"What's up, you want me to stay the night?"
[cpg cn=true]


It was a lighthearted joke, but Natsuko looked serious.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Nathuko278"]
[OnName num="nathuko"]
"I don't want you getting hurt for my sake. I can hardly stand the thought."
[cpg cn=true]


It was hard to hear her say that. I felt like this was the best option...how was I supposed to respond?
[cpg]


[OnName num="shoma"]
"I feel the same way about you, you know."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nathuko279"]
[OnName num="nathuko"]
"…… I'm used to fighting. I'm better at it than you are, so I'll get hurt a lot less."
[cpg cn=true]


[OnName num="shoma"]
"And here I thought it was weaker fighters that were less likely to get hurt."
[cpg cn=true]


Natsuko shushes me. We weren't trying to start an argument.
[cpg]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Nathuko280"]
[OnName num="nathuko"]
"Don't do anything rash."
[cpg cn=true]


[OnName num="shoma"]
"You too."
[cpg cn=true]


We were just rehashing the same conversation over and over.
[cpg]


[OnName num="shoma"]
"I'll see you later."
[cpg cn=true]


I said my goodbyes and left Natsuko.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]


A few days pass.
[cpg]


I started by breaking up scuffles here and there. A few developed into fights, but I was getting used to them.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』



One morning, I thought I'd learned enough. It was time to take revenge.
[cpg]


I owed the guy who'd hit Natsuko a punch.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michika451"]
[OnName num="mithika"]
"......You sure look different these days. I almost can't believe you're the same guy who transferred in."
[cpg cn=true]


[OnName num="shoma"]
"You really think so?"
[cpg cn=true]


As I was walking to school, Michika approached me.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika452"]
[OnName num="mithika"]
"You seemed like a really sweet guy when we first met. But I think I like you better better as you are now."
[cpg cn=true]


[OnName num="shoma"]
"Thanks, but I'd be happier if it were Natsuko saying it."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika453"]
[OnName num="mithika"]
"Hah, so you don't feel anything if I say it?"
[cpg cn=true]


She giggles.
[cpg]


I was getting so close. If I beat him, something would change. It had to.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************



That evening, after school......
[cpg]


I'd sent my opponent a letter of challenge.
[cpg]


[OnName num="male_student"]
"......Bro, what are you trying to do here? There's no reason for us to fight."
[cpg cn=true]


[OnName num="shoma"]
"Maybe you don't, but I sure do. You hit the girl I love and I'm not letting that stand."
[cpg cn=true]


[OnName num="male_student"]
"For c......ugh, okay. We'll meet up here later."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



True to his word, he showed up on time.
[cpg]


[OnName num="male_student"]
"Look man, I don't want you bothering me any more. If that means I have to teach you a lesson, then that's what I'm gonna do."
[cpg cn=true]


[OnName num="shoma"]
"I wouldn't have it any other way."
[cpg cn=true]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



From there, it was a normal fistfight. He really wasn't holding anything back.
[cpg]


But I was able to hold my own. It seems he wasn't as good of a fighter as I'd thought.
[cpg]


I'd finally caught up to him.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************


[OnName num="male_student"]
"......You're pretty good at this."
[cpg cn=true]


[OnName num="shoma"]
"You too......"
[cpg cn=true]


Too exhausted to continue, we sat on the floor to catch our breath.
[cpg]


If only we were outdoors, you'd think we'd come straight out of a comic book. Oh well.
[cpg]


[OnName num="male_student"]
"You get it out of your system......?"
[cpg cn=true]


[OnName num="shoma"]
"More or less. From now on, Natsuko's fights are mine."
[cpg cn=true]


[OnName num="shoma"]
"I'll protect them. Both Yōka and Natsuko."
[cpg cn=true]


[OnName num="male_student"]
"Oof. You're so weird......I must have hit you too hard last time."
[cpg cn=true]


Maybe he was right. I had said some pretty cheesy lines.
[cpg]


But so what? It felt right at the time.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



Bloodied but victorious, I made my way to the school gates to find Natsuko waiting for me.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Nathuko281"]
[OnName num="nathuko"]
"......You look terrible."
[cpg cn=true]


[OnName num="shoma"]
"Yeah...but I won."
[cpg cn=true]


In truth, it was closer to a draw, but I felt like I was allowed to fudge the story a bit.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Nathuko282"]
[OnName num="nathuko"]
"You're so reckless......but I'll admit you're pretty cool sometimes."
[cpg cn=true]


She looks away a bit, embarrassed.
[cpg]


Finally. I felt like we'd become a real couple.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


;//移植のためシーンをカットしています


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko298"]
[OnName num="nathuko"]
"Shōma, can I really go back to being a girl?"
[cpg cn=true]


[OnName num="shoma"]
"I've said it before and I'll say it again. I want you to live the way you want to live."
[cpg cn=true]


[OnName num="shoma"]
"It's the whole reason I learned how to fight, so don't waste it, okay?"
[cpg cn=true]


If she really wants to continue to be a delinquent, I wasn't going to stop her.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



Some time in the near future.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Nathuko299"]
[OnName num="nathuko"]
"Good morning Shōma."
[cpg cn=true]


[OnName num="shoma"]
"Good morning. You feeling clingy today?"
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Nathuko300"]
[OnName num="nathuko"]
"Does it matter? I'm a girl, I get to do stuff like this."
[cpg cn=true]


She grabs my arm and pulls me towards her.
[cpg]


I could feel people staring at us. It wasn't a bad feeling, really.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************



Natsuko is no longer late or absent. She no longer skipped out on her classes.
[cpg]


It meant she was done being a delinquent.
[cpg]


She had stopped intimidating people.
[cpg]


I hadn't heard of her getting into any fights, either. I think I'd finally done it.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nathuko301"]
[OnName num="nathuko"]
"......Hey, Shōma."
[cpg cn=true]


After school, when it was just the two of us. Natsuko approached me.
[cpg]


[OnName num="shoma"]
"What?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko302"]
[OnName num="nathuko"]
"I still don't know what I want to do."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Nathuko303"]
[OnName num="nathuko"]
"All I could think about was getting stronger. Strong enough to protect Yōka."
[cpg cn=true]


[OnName num="shoma"]
"Yeah, I get it. Take all the time you need. I didn't expect you find what you want to do right away."
[cpg cn=true]


"You're right." she says.
[cpg]


[OnName num="shoma"]
"It's not like I really know what I'm going to do with my life yet either."
[cpg cn=true]


[FACE method="shake_5" pos="2/3"]
[VOICE f="Nathuko304"]
[OnName num="nathuko"]
"What? I can't believe you had the nerve to tell me to do something you hadn't done either......"
[cpg cn=true]


[OnName num="shoma"]
"Sure. I mean, I might still be on the fence, but you sure weren't."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

Natsuko nods.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nathuko305"]
[OnName num="nathuko"]
"......I saw changed. I thought I could, too. I wanted to become more girly."
[cpg cn=true]


[OnName num="shoma"]
"Yeah, and you're doing a great job too. But I'm happy as long as you are."
[cpg cn=true]


It was the outcome I'd worked so hard to achieve. I wasn't sure what would come next.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Nathuko306"]
[OnName num="nathuko"]
"I think I know what I want to be in the future...but if you laugh, I'm going to punch you."
[cpg cn=true]


[OnName num="shoma"]
"I won't."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Nathuko307"]
[OnName num="nathuko"]
"I want to be your......bride."
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
I couldn't help but laugh. I didn't think it was going to be such a childlike dream.
[cpg]


True to her word, Natsuko threw a punch, but I was able to dodge her fist as I was now.
[cpg]

[FACE method="change_2" pos="2/3"]

;//ＢＫ

[SCENE id=19]

[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン２純情ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

