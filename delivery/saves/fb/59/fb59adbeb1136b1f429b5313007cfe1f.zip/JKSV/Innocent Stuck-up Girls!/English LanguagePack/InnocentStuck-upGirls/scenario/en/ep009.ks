
*start


;//==============================

;//==============================
;//２、夏子
*select04_2|The person I have feelings for in my heart


;//それぞれ純情であるかギャルであるかによって３種類に分岐


;//ヒロイン2が非処女である場合
[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*end2_citch"]
[endif]

[if exp={getFlagValue("Cha1flg") == 0 }]
[if exp={getFlagValue("Cha2flg") == 0 }]
[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*end2_alvar"]
[endif]
[endif]
[endif]
;//全てのヒロインが処女である場合



;//==============================
;//ヒロイン２が純情であり、残り二人のうち片方あるいは両方がギャルである場合

*end2_badend|Love within one's means

It's ...... Natsuko. It had to be her.
[cpg]


She was gruff, but I'd fallen for her anyways.
[cpg]


Of course, there were other girls who'd shown interest in me and I'd honestly considered them too……
[cpg]


But now I knew what I wanted. It was Natsuko.
[cpg]


;#################################################
*Ep009|Love within one's means
;#################################################

[SCENE id=9]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[FACE method="bow_1" pos="2/3"]
[VOICE f="Mei092"]
[OnName num="mei"]
"Good morning. You look different."
[cpg cn=true]


[OnName num="shoma"]
"......Yeah?"
[cpg cn=true]


Did I have the look of a man with determination on his face?
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Mei093"]
[OnName num="mei"]
"Yeah, you look kinda nervous."
[cpg cn=true]


Oh......well, she wasn't wrong.
[cpg]


I'd already gotten close to another girl.
[cpg]


If I confessed my feeling to Natsuko and we started going out......and if she found out, I don't know what she'd do to me.
[cpg]


Maybe it was too early to worry about that. I mean, I haven't even told her how I felt about her yet. There wasn't even a guarantee she'd reciprocate.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（朝）******************************************************



[FG f="CHA02_p2_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nathuko105"]
[OnName num="nathuko"]
"Keep staring and I'm gonna start charging."
[cpg cn=true]


She glares at me. I'd love to stare into her eyes, but I guess I'd have to convince her to go out with me first.
[cpg]


This wasn't the right place to confess. There were too many people around.
[cpg]


I had to get the timing right, but how?
[cpg]


When in doubt, do what everybody else does……
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



I decided to call her to an empty classroom after school.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nathuko106"]
[OnName num="nathuko"]
"Whaddya want? There someone needing a beatin'?"
[cpg cn=true]


She sounded like a guy. One of poor character, to boot. I doubted she'd fare well against a guy of similar stature.
[cpg]


[OnName num="shoma"]
"Are you...offering to beat up a guy for me?"
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Nathuko107"]
[OnName num="nathuko"]
"Nah man. You call me when you need another girl put in her place."
[cpg cn=true]


Oh. I guess there was some semblance of logic behind her actions.
[cpg]


[OnName num="shoma"]
"Okay, I'm not sure how to word this, but just hear me out."
[cpg cn=true]


With her, I should probably just cut to the chase. It was nerve-wracking.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko108"]
[OnName num="nathuko"]
"What is it...? It's weird when you go all serious like that."
[cpg cn=true]


[OnName num="shoma"]
"I like you. I want to go out with you. Are you interested?"
[cpg cn=true]


Natsuko's face flushed beet-red. It was almost comical.
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Nathuko109"]
[OnName num="nathuko"]
"You making fun of me!? Why me? I ain't girly or nothin'!"
[cpg cn=true]


[OnName num="shoma"]
"I disagree. I think you're cool and I know there's a cute side to you too."
[cpg cn=true]


I was able to convey my feelings, but it was hard to tell if she was listening. She fidgets, clearly embarrassed.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Nathuko110"]
[OnName num="nathuko"]
"You're......you're dumb. What're you even thinking, seriously......"
[cpg cn=true]


She half-mumbles to herself. It was cute to see her so flustered.
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Nathuko111"]
[OnName num="nathuko"]
"Are you sure you want me? Are you really sure?"
[cpg cn=true]


[OnName num="shoma"]
"I meant every word. Why?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nathuko112"]
[OnName num="nathuko"]
"Because it might be a prank or something."
[cpg cn=true]


[OnName num="shoma"]
"I don't think there's anybody at school who'd have the guts to prank you, Natsuko......"
[cpg cn=true]


Seemingly convinced, she looks down and takes my hand.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Nathuko113"]
[OnName num="nathuko"]
"Please go out with me……."
[cpg cn=true]


Her eyes welled over as I leaned in to kiss her.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]


Our relationship began that day.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[OnName num="shoma"]
「……」
[cpg cn=true]


The first change I noticed was that the boys in class no longer interacted with me.
[cpg]


They were already terrified of Natsuko. I wouldn't be surprised if they were equally as scared of me, her boyfriend……
[cpg]


They probably couldn't see how I could fall in love with Natsuko.
[cpg]


Objectively speaking, Natsuko is cute. Why didn't anybody else see that?
[cpg]


[OnName num="male_student"]
"Dude......are you nuts?"
[cpg cn=true]


It had been a while since anybody had talked to me.
[cpg]


[OnName num="shoma"]
"What are you talking about?"
[cpg cn=true]


I knew what he meant, but I was a little irritated that he was questioning my sanity.
[cpg]


[OnName num="male_student"]
"You girlfriend, dude. Why did you ever think about dating someone that terrifying?"
[cpg cn=true]


[OnName num="shoma"]
"She's a lovely person. I understand that she probably seems scary to people who don't know her."
[cpg cn=true]


[OnName num="male_student"]
"That's...wow. I knew you were different, but to think you'd tame the beast..."
[cpg cn=true]


[OnName num="shoma"]
"Can you stop ragging on Natsuko like that? Even if she wasn't my girlfriend, it's really rude."
[cpg cn=true]


I snapped at him. I'd probably lost another friend.
[cpg]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************



But I was so in love with Natsuko that it didn't seem to matter.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nathuko114"]
[OnName num="nathuko"]
"Soooo......Shōma."
[cpg cn=true]


[OnName num="shoma"]
"What's up?"
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Nathuko115"]
[OnName num="nathuko"]
"Can I......you know......go to your house today?"
[cpg cn=true]


There was no reason to refuse. I nodded in reply.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se010"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[FACE method="bow_2" pos="2/3"]
[VOICE f="Nathuko116"]
[OnName num="nathuko"]
".......It all feels like a dream. I can't believe I got a boyfriend..."
[cpg cn=true]


[OnName num="shoma"]
"I don't see any reason for you to be so surprised."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko117"]
[OnName num="nathuko"]
"But I'm not really.....girly or anything, right......?"
[cpg cn=true]


[OnName num="shoma"]
"You seem plenty girly to me."
[cpg cn=true]


Every time I try to reassure her, I feel guilty.
[cpg]


I've already kissed and done stuff with another girl.
[cpg]


If Natsuko found out……No, I could never let her know.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se011"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


Then we come to my room.
[cpg]


;//========================================
;//●ＣＧエロ（ヒロインの背後に座る主人公。ヒロインを抱きしめる）ev_27
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sNathuko013"]
[OnName num="nathuko"]
"......This is embarrassing."
[cpg cn=true]


[OnName num="shoma"]
"I don't mind. If anything, you're even cuter than usual."
[cpg cn=true]


I stopped thinking about it. I had to focus on loving Natsuko.
[cpg]

[VOICE f="sNathuko014"]
[OnName num="nathuko"]
"I've never had someone......hold me like this before."
[cpg cn=true]


[VOICE f="sNathuko015"]
[OnName num="nathuko"]
"It really is like a dream."
[cpg cn=true]


My heart aches. She seemed to happy.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


We stayed together for a while after that.
[cpg]

Natsuko didn't seem to want to leave.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="sNathuko016"]
[OnName num="nathuko"]
"So......there's a lot of comic books in your room."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sNathuko017"]
[OnName num="nathuko"]
"Oh, I've read this one too."
[cpg cn=true]



;//========================================
;//●ＣＧエロ（背中を向けるヒロイン）ev_28
;//人物１：ヒロイン２
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]



She reaches for books at the bottom of the shelf.
[cpg]

Sensing my gaze, she keeps glancing back at me.
[cpg]

[VOICE f="sNathuko018"]
[OnName num="nathuko"]
"......Are you ogling me?"
[cpg cn=true]


[OnName num="shoma"]
"Just a little."
[cpg cn=true]


[VOICE f="sNathuko019"]
[OnName num="nathuko"]
"I don't......mind. As long as it's you."
[cpg cn=true]


I felt relieved......
[cpg]

But deep down, I was scared. She could never know about my relationship with the other girls.
[cpg]


;//移植のためシーンをカットしています



[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I sent Natsuko home before my parents returned.
[cpg]


I was satisfied. Happy, even.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************



But the past has a way of catching up to you.
[cpg]


It was the natural conclusion to the choices I'd made, but it still took me by surprise.
[cpg]


We'd started the day as lovers......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nathuko154"]
[OnName num="nathuko"]
"Can I go to your house today, too?"
[cpg cn=true]


[OnName num="shoma"]
"I don't mind, but I'd rather go to your house."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Nathuko155"]
[OnName num="nathuko"]
"N...no way, I don't want to you to see my room."
[cpg cn=true]


That evening.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************



Seething with silent rage, Natsuko entered the classroom.
[cpg]


She didn't make a scene, she simply walked up to me.
[cpg]


[FACE method="shock_3" pos="2/3"]
[VOICE f="sNathuko020"]
[OnName num="nathuko"]
"I hear you've been kissing other girls?"
[cpg cn=true]


[OnName num="shoma"]
"......"
[cpg cn=true]


The time had finally come. I desperately tried to think of an excuse.
[cpg]


[OnName num="shoma"]
"It's not what you think, they were practically forcing themselves on me......"
[cpg cn=true]


[SE f="se019"]
;//【ＳＥ】『殴る』
[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Before I finished my sentence, I saw a blur, then stars.
[cpg]


I stumbled backwards, my brain slow to process what had just happened.
[cpg]



[SE f="se019"]
;//【ＳＥ】『殴る』
[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


After the second punch, I found myself on the ground. Natsuko mounts me, tears in her eyes.
[cpg]


Her expression left a powerful impression on me. There wasn't anything I could say to her anymore......
[cpg]



;//ＢＫ


[SE f="se019"]
;//【ＳＥ】『殴る』


She continued to beat me until I passed out.
[cpg]


As my consciousness faded, I realized that I didn't have what it took to date gals......
[cpg]

[SE f="se019"]
;//【ＳＥ】『殴る』

They were too much for me to handle. I decided that I should stick to girls who were better-suited to someone like me.
[cpg]


[SCENE id=18]

[jump storage="epend.ks" target="*badend"]

;//ＥＮＤ：ヒロイン２バッドエンド



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

*end2_alvar|Natsuko's true face
[jump storage="ep010.ks" target="*end2_alvar"]

*end2_citch|Flirtatious Natsuko
[jump storage="ep011.ks" target="*end2_citch"]


