

*start|バタフライ効果

;#################################################
*Ep001|バタフライ効果
;#################################################

[SCENE id=1]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[SE f="se002"]
;//【ＳＥ】『喧噪』


And again in the morning. I did not meet Michika at the previous rendezvous point.
[cpg]


I headed to the school without thinking anything about it.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（朝）******************************************************

[SE f="se017" loop=true]
;//【ＳＥ】『学園の喧噪』

And it wasn't until I got to my class that I met that person.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Nathuko003"]
[OnName num="nathuko"]
「……」
[cpg cn=true]


Mr. Miyako, right? I've seen this guy many times and he's still very powerful.
[cpg]


He was probably just looking at me, but I felt like he was staring at me, so I looked away.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
And in the classroom before class started. The gals are coming up to Michika, who is sitting next to me.
[cpg]


I don't know how I didn't notice it before, but Michika really seems to be the center of the class.
[cpg]


It seems impossible that she doesn't have a boyfriend.
[cpg]

Maybe not having a boyfriend is something to be ashamed of among the gals.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Michika011"]
[OnName num="mithika"]
"Seriously?　I'm pulling away, break up with that guy, break up with him!"
[cpg cn=true]


I thought to myself as I listened to the conversation of the fussing gals next to me.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



[OnName num="shoma"]
"...... gal, huh?"
[cpg cn=true]


[OnName num="male_student"]
"What's wrong? You sound like it's a life issue."
[cpg cn=true]


[OnName num="shoma"]
"I didn't."
[cpg cn=true]


[OnName num="male_student"]
"I did. You said it like, "I'm taking an exam, huh?"
[cpg cn=true]


[OnName num="shoma"]
"Is taking exams a life mission for you, ......?"
[cpg cn=true]


[OnName num="male_student"]
"...... it's a little subtle when you put it like that."
[cpg cn=true]


What's that? It's a very sterile exchange.
[cpg]


[OnName num="male_student"]
"What's up with that?　What about the gals?"
[cpg cn=true]


[OnName num="shoma"]
"No, I'm just wondering if those girls are playing around."
[cpg cn=true]


[OnName num="male_student"]
"I don't know. They may be surprisingly innocent."
[cpg cn=true]


While we were having this conversation, I realized that I was not a little interested in gal.
[cpg]


I am interested in gal in no small way.
[cpg]


Not only Michika, but also Mei and Miyako.
[cpg]


I became very curious about whether they were playing or not.
[cpg]

It is fitting that Michika has a boyfriend. If it's the other way around, there's a huge gap.
[cpg]

Miyako could be either ....... I'm not sure about Mei, either.
[cpg]

I have no idea about Mei either.
[cpg]

[OnName num="male_student"]
"What's wrong? Now you're acting like a 'thinker.' "
[cpg cn=true]


[OnName num="shoma"]
"Well, I was thinking right now, and I am a person ......"
[cpg cn=true]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_da"]
[WAIT time=100]

The sun was setting, and it was after school.
[cpg]


I was strolling around at random, thinking that I didn't know the full extent of the academy yet.
[cpg]


As I put my ear to the ground, I hear voices, male and female, though I don't know who they are.
[cpg]

Rather than just talking, they sound like they are flirting......
[cpg]



;//■選択肢
[switch]
[case "I'm going to go see."]
	[swap]
	[jump target="*select01_1"]
[case "I'm not going to see it."]
	[swap]
	[jump target="*select01_2"]
[endswitch]


1, I'm going to see it.
2, not going to see



;//==============================
;//１、見に行く

*select01_1|バタフライ効果


;//美智佳がギャル設定になる
[stflag Cha1flg = 1]

It is said that there is a butterfly effect in the world.
[cpg]

個人が取った些細な行動の差がのちに大きな差に変わるとかなんとか。
[cpg]

However, I don't think it will change to the past. ......
[cpg]



......I had a hunch, somewhat, that I was going to be there.
[cpg]


I have a feeling that it might be Michika.
[cpg]


And it was right. I'm not sure how much I'm going to be able to do with it.
[cpg]



;//========================================
;//●ＣＧエロ（モブ男に迫られるヒロイン。お互い立っている）ev_01
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：モブ男
;//服装２：制服
;//場所　：学園裏
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMithika001"]
[OnName num="mithika"]
"Hey, it's not good to be in the school,"
[cpg cn=true]


[OnName num="male_student"]
"Why not?　You're the one who asked me out."
[cpg cn=true]


;**【ＣＧ】 ev_01_a ***********************
[CG id=0 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sMithika002"]
[OnName num="mithika"]
"You're too pushy. Girls don't like you."
[cpg cn=true]


[OnName num="male_student"]
"You don't hate me."
[cpg cn=true]


I can hear the conversation between them.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト


Michika then kissed a male student whom she did not know.
[cpg]

I stopped peeking at that moment for the last time.
[cpg]

After all, it seems that Michika's impression of me as a playful person was true.
[cpg]


;//移植のためシーンをカットしています


[jump target="*select01_3"]

;//==============================
;//２、見に行かない
*select01_2|バタフライ効果


;//美智佳が純情設定になる
[stflag Cha1flg = 0]



......I'd better stop.
[cpg]


世の中にはバタフライ効果というのがあるらしい。
[cpg]

The difference between an individual's smallest action can later turn into a big difference.
[cpg]

However, I don't think it will change to the past.
[cpg]

Even if this does not determine whether Michika is a pure-hearted child or not ......
[cpg]

I knew that peeping was not a good idea. With that in mind, I left the place.
[cpg]



;//==============================
*select01_3|バタフライ効果




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I felt strangely tired today.
[cpg]


I ate dinner and took a bath. I decided to go to bed and fall asleep ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』



The morning comes in a rush.
[cpg]


The first thing to do is to make sure that you have a good time.
[cpg]


It's true, just because they walk to school in the same direction doesn't mean they will see each other.
[cpg]


Even though there is a fixed time when you have to be at the school, it's up to each person to decide whether to go at the very last minute or to leave enough time to get there.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（朝）******************************************************

[SE f="se017" loop=true]
;//【ＳＥ】『学園の喧噪』


[OnName num="male_student_A"]
"So there's ...... Mr. Takaha, right? She's dating a guy because she wants a present ......"
[cpg cn=true]


[OnName num="male_student_B"]
"Ah. I'm not sure if that's true or not."
[cpg cn=true]


In the hallway of the school, I see a couple of people chatting at a time when they should be in the classroom by now.
[cpg]


[OnName num="male_student_A"]
"I don't think many people know the truth about that. I do."
[cpg cn=true]


If you keep listening to ......, you might find out something about Mei.
[cpg]


But it's like indirectly peeking into privacy. It's not a good thing.
[cpg]


[OnName num="male_student_A"]
"I liked Takahane. That's why I confessed to her ......"
[cpg cn=true]



;//■選択肢
[switch]
[case "Listening"]
	[swap]
	[jump target="*select02_1"]
[case "Ignore"]
	[swap]
	[jump target="*select02_2"]
[endswitch]


1, listen
2. ignore



;//==============================
;//１、聞き耳を立てる
*select02_1|バタフライ効果


;//芽衣が純情設定になる
[stflag Cha3flg = 0]



[OnName num="male_student_A"]
"She's so guarded. I was surprised too."
[cpg cn=true]


[OnName num="male_student_B"]
"Stiff-guarded ......?　She doesn't look like that to me."
[cpg cn=true]


[OnName num="male_student_A"]
"Maybe natural is just pretending to be natural."
[cpg cn=true]


...... Ahhhh, I heard the end of it. Mei is apparently a novice girl.
[cpg]


But I can't help it if I've already heard it.
[cpg]


Anyway, I decided to enter the classroom before these two noticed me.
[cpg]

[jump target="*select02_3"]

;//==============================
;//２、無視する
*select02_2|バタフライ効果


;//芽衣がギャル設定になる
[stflag Cha3flg = 1]



Oh, no. I knew I shouldn't ask.
[cpg]


It's not like Mei is a neat and tidy girl anyway.
[cpg]


I don't need to hear anyone's voice. With that in mind, I headed for the classroom.
[cpg]



;//==============================
*select02_3|The Butterfly Effect


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************



Attending morning class. Bored.
[cpg]


I look over at Michika, who is doing some cute doodles.
[cpg]


It seems she doesn't intend to take the class too seriously.
[cpg]



;//ＢＫ

;//==============================
;//ここから暫く、美智佳が純情の場合のみ発生するイベント

[if exp={getFlagValue("Cha1flg") == 1 }]
[jump target="*cha01_gal01"]
[endif]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



Then it was lunch break. After having lunch at the cafeteria, I saw Michika and her gal friends talking.
[cpg]


I didn't have the courage to get involved in the conversation, but I decided to ask her from a distance.
[cpg]



;//========================================
;//●ＣＧ非エロ（楽しく会話するヒロインとモブ女子。ヒロイン明るい表情。途中から焦りだす）ev_02
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：モブ女子
;//服装２：制服
;//人物３：モブ女子
;//服装３：制服
;//場所　：学園教室
;//時間　：昼
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="female_student_A"]
"Nowadays, it's impossible for a girl this age to have never had a boyfriend."
[cpg cn=true]


[OnName num="female_student_B"]
"Yes, of course you think so. Of course you think so too, don't you Michika?"
[cpg cn=true]



[VOICE f="Michika027"]
[OnName num="mithika"]
"What?　Well, of course, of course it's ......."
[cpg cn=true]


It's a somewhat clumsy answer. Is it possible that she doesn't have a girlfriend?
[cpg]


I can only speculate, but I get the impression that Michika doesn't like the topic, based on her facial expressions, etc.
[cpg]


[OnName num="female_student_A"]
"I can't help but think of my first boyfriend as a memory."
[cpg cn=true]

[OnName num="female_student_B"]
"My first boyfriend was my current boyfriend ...... . What was Michika's first boyfriend like?"
[cpg cn=true]


[VOICE f="Michika028"]
[OnName num="mithika"]
"Well......, was he a normal guy?"
[cpg cn=true]


[OnName num="female_student_B"]
"What?　What's normal?"
[cpg cn=true]


I still feel like it's a lie. I can see that you are in some kind of a hurry.
[cpg]

If you've never really been in love before, it's hard not to get burned. As I was thinking that.
[cpg]


[SE f="se014"]
;//【ＳＥ】『学園のチャイム』


Lunch break was about to end. I take my seat.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************



After school, Michika spoke to me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michika029"]
[OnName num="mithika"]
"Hi, I'm so glad to see you. You look so happy."
[cpg cn=true]


[OnName num="shoma"]
"Well ......, something happened to me that made me a little paranoid."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]

"What's that?" she says and cackles. I don't think he thinks I'm talking about him.
[cpg]



;//ＢＫ


[jump target="*cha01_gal01_end"]


;//ここまで、美智佳が純情の場合のみ発生するイベント
;//==============================

*cha01_gal01|バタフライ効果

;//==============================
;//ここから暫く、美智佳がギャルの場合のみ発生するイベント



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



They finish their morning classes and also finish their afternoon classes.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



I realized that it was already late in the evening. I had just left the classroom. ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michika030"]
[OnName num="mithika"]
"Wait a minute. Are you free after school?"
[cpg cn=true]


[OnName num="shoma"]
"......I'm free, what's going on?"
[cpg cn=true]


Michika caught me. After seeing her like that, it was kind of hard to treat her.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Michika031"]
[OnName num="mithika"]
"There's an empty classroom at the end of the school. Let's go there for a minute."
[cpg cn=true]


[OnName num="shoma"]
"Why?　Tell me why, I don't understand."
[cpg cn=true]


But I also understood a little. I had been peeking in there for such a long time.
[cpg]


She must have known I was there.
[cpg]


[SE f="se010"]
;//【ＳＥ】『歩く』



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMithika003"]
[OnName num="mithika"]
"You saw it, didn't you? You saw us flirting."
[cpg cn=true]


[OnName num="shoma"]
"......"
[cpg cn=true]


It was hard to answer clearly. But I couldn't not answer.
[cpg]


[OnName num="shoma"]
"I saw it. But it was an act of God. I'm sorry."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
I thought, "You're apologizing for a force majeure?　I thought, "Well, it doesn't matter.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Michika033"]
[OnName num="mithika"]
"Well, whatever. This is just to keep my mouth shut."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
Michika came close to me saying that. Her face was so close to mine that my breath hit hers.
[cpg]


;//========================================
;//●ＣＧエロ（主人公に迫るヒロイン。お互いに立っている）ev_03
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

I couldn't even pretend to refuse.
[cpg]

[VOICE f="sMithika004"]
[OnName num="mithika"]
"You have a funny face, you know."
[cpg cn=true]


[OnName num="shoma"]
「……」
[cpg cn=true]


I couldn't say anything. I'm not sure what to say.
[cpg]

This is crazy. I can't believe how close we are all of a sudden.
[cpg]

I know that if I don't, I'll end up kissing someone who isn't my lover. ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ


[VOICE f="sMithika005"]
[OnName num="mithika"]
"Chu"
[cpg cn=true]


He took my lips. It was a first for me. ......
[cpg]


;//ここまで、美智佳がギャルの場合のみ発生するイベント
;//==============================

*cha01_gal01_end|バタフライ効果


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



Right after I left the school, I met Miyako-san at what looked like a gate.
[cpg]


They came to pick up something they had forgotten, or they really did run into each other.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Nathuko004"]
[OnName num="nathuko"]
「……」
[cpg cn=true]


I was about to walk through the gate, but she didn't seem to remember me.
[cpg]


[OnName num="shoma"]
"Oh, wait a minute!　I'm sorry about the other day."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nathuko005"]
[OnName num="nathuko"]
"Oh?　The other day?　What are you talking about?"
[cpg cn=true]


That's not the language of a girl, it's too scary.
[cpg]


I was tempted to leave right then and there, but I decided to apologize properly.
[cpg]


Upon closer inspection, she's quite pretty too. There's nothing better than having some kind of connection.
[cpg]


[OnName num="shoma"]
"You see ......, you bumped into me in the hallway."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nathuko006"]
[OnName num="nathuko"]
"Ah, that's the one from back then, right? That's enough."
[cpg cn=true]

[free time=1000]

Permission was given and Mr. Miyako went straight to the school.
[cpg]


I don't get to talk to this girl much.
[cpg]


No, he's the kind of guy who would be crazy if he bounced. ......
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



Then I go back to my house. I say, "I'm home," and then go to my room.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[OnName num="shoma"]
"Huh. ......."
[cpg cn=true]


I'm kind of in touch with a lot of gals, aren't I? Is it any wonder that there are so many Gyaru in the school?
[cpg]


But Miyako ...... she doesn't really have any connection unlike Michika and Mei.
[cpg]


And yet I'm strangely curious about them. I don't see that type of girl very often.
[cpg]


The girl always seemed angry. It didn't bother me.
[cpg]



[jump storage="ep002.ks" target="*start"]


;////////////////////////////////////////////////////////////////////////


