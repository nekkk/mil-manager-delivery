
*start

;#################################################
*Ep005|心に秘めた想い人
;#################################################

[SCENE id=5]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]


I went to sleep thinking about such a trivial thing. On the next day,
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[OnName num="shoma"]
"Oh ......."
[cpg cn=true]


This time I saw Natsuko on my way to school.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Nathuko048"]
[OnName num="nathuko"]
"What? Quit bugging me unless you got something to say."
[cpg cn=true]


[OnName num="shoma"]
"Sure. I was just going to see if we could chat a bit about karaoke. I didn't know you were the type to sing solo."
[cpg cn=true]


I mentioned it, thinking I might close the distance between us a little bit.
[cpg]


Natsuko's face turns bright red. I match her pace to stop as she does.
[cpg]


Then she said in a whisper.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Nathuko049"]
[OnName num="nathuko"]
"......What did you see and where?"
[cpg cn=true]


[OnName num="shoma"]
"Huh? Uhhh, I'm not sure……."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Nathuko050"]
[OnName num="nathuko"]
"If you say a word about this to anyone, you're dead."
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
That wasn't the reaction I was hoping for. I step back, reflexively.
[cpg]


[OnName num="shoma"]
"Wow, sorry. Your secret is safe with me..."
[cpg cn=true]


It seems like she really wanted to keep it quiet.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko051"]
[OnName num="nathuko"]
"I was only there to meet up with someone."
[cpg cn=true]


What was the problem with that? I didn't understand why she felt like she had to keep something so mundane a secret.
[cpg]


She's probably just making stuff up. I know.
[cpg]


[OnName num="shoma"]
"It's okay ...... I get it. Really, I do."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Nathuko052"]
[OnName num="nathuko"]
"What exactly is it that you think you 'get?'"
[cpg cn=true]


[OnName num="shoma"]
"In short, I should just forget it ever happened, right?"
[cpg cn=true]


I flinched. Natsuko glares at me as if she could throw a punch at any moment. My voice is hoarse.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Nathuko053"]
[OnName num="nathuko"]
"All right. If you got it, that's good."
[cpg cn=true]

[free time=1000]
With that, I headed back to the academy.
[cpg]


That was scary. I really could have been killed.
[cpg]



[if exp={getFlagValue("Cha1flg") == 1 }]
[jump target="*allvir"]
[endif]

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*allvir"]
[endif]

[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*allvir"]
[endif]

;//==============================
;//ここから暫く、ヒロイン全員が純情の場合のみ発生するイベント




;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



Then the morning classes are over and it's lunch break.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Nathuko054"]
[OnName num="nathuko"]
"So, you know, I'm a gal, right?"
[cpg cn=true]


[FACE method="bow_2" pos="3/3"]
[VOICE f="Mei049"]
[OnName num="mei"]
"I guess so. Although a different type compared to me."
[cpg cn=true]


[FACE method="bow_2" pos="1/3"]
[VOICE f="Michika056"]
[OnName num="mithika"]
"But we can be allies, right? We're like all on the same side."
[cpg cn=true]


It's rare to see these three together.
[cpg]


I thought so, and after wondering for a while whether or not to talk to them, I did.
[cpg]


[OnName num="shoma"]
"What's up? I don't think I've ever seen the three of you together."
[cpg cn=true]


All three of them have a connection with me, but that wouldn't be a reason for them to get together.
[cpg]


[FACE method="shake_1" pos="1/3"]
[VOICE f="Michika057"]
[OnName num="mithika"]
"Oh, Shōma. Well......"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Nathuko055"]
[OnName num="nathuko"]
"Wait, don't say it. You never know who might hear you."
[cpg cn=true]


Now I was even more curious. What do these three have in common?
[cpg]


[FACE method="shake_1" pos="3/3"]
[VOICE f="sMei006"]
[OnName num="mei"]
"It's embarrassing, but none of us have boyfriends."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Nathuko056"]
[OnName num="nathuko"]
"Why'd you tell him......!"
[cpg cn=true]


So that's what this was all about. That explains the unusual combination.
[cpg]


[OnName num="shoma"]
"I get it, boyfriends are kind of like a status thing for gals, right?"
[cpg cn=true]


I say knowingly, but they nod in agreement with me.
[cpg]

[FACE method="change_1" pos="2/3"]
[FACE method="bow_7" pos="1/3"]
[VOICE f="Michika058"]
[OnName num="mithika"]
"Seriously. I've had to hide it for so long, it's such a drain sometimes."
[cpg cn=true]


[OnName num="shoma"]
"I don't think you have to go that far to hide it..."
[cpg cn=true]


[FACE method="shake_1" pos="1/3"]
[VOICE f="Michika059"]
[OnName num="mithika"]
"You don't get it, I'm on the top of this gal pyramid. There are certain standards that I have to adhere to."
[cpg cn=true]


It was a rare glimpse into the woman's world. I didn't pretend to understand it.
[cpg]


[FACE method="bow_2" pos="3/3"]
[VOICE f="Mei051"]
[OnName num="mei"]
"It's the worst when people start talking about...you know...boy and girl stuff."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Nathuko057"]
[OnName num="nathuko"]
"Yeah, I get that sometimes......not that I have many friends to talk about that sorta thing."
[cpg cn=true]


The three confide such concerns to each other.
[cpg]


They were all off to a corner of the room, talking in hushed tones. I think the other people in the classroom were silently wondering what was going on. It was an unusual sight to see them together.
[cpg]


;//ここまで、ヒロイン全員が純情の場合のみ発生するイベント
;//==============================


*allvir|心に秘めた想い人

[if exp={getFlagValue("Cha1flg") == 0 }]
[jump target="*allbich"]
[endif]

[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*allbich"]
[endif]

[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*allbich"]
[endif]



;//==============================
;//ここから暫く、ヒロイン全員がギャルの場合のみ発生するイベント



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



After classes were out, I found myself in a bit of a situation. A happy one.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michika060"]
[OnName num="mithika"]
"Hey, Shōma, come here."
[cpg cn=true]


As I was getting ready to leave, Michika approached me.
[cpg]


Wondering what it was all about, I did as I was told and walked out of the classroom.
[cpg]




[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



We continued down the hallway.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Michika061"]
[OnName num="mithika"]
"The others are already waiting. I knew you had it in you, Shōma."
[cpg cn=true]


What did she mean by that?
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Michika062"]
[OnName num="mithika"]
"I was talking to Natsuko and Mei and they both mentioned you by name."
[cpg cn=true]


I have a bad feeling about this.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************
;//ＢＫ


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="Nathuko058"]
[OnName num="nathuko"]
"Finally, I was getting tired of waiting."
[cpg cn=true]


[FACE method="shake_2" pos="3/3"]
[VOICE f="sMei007"]
[OnName num="mei"]
"Wow, Shōma. I didn't know you were so close with them too."
[cpg cn=true]


[OnName num="shoma"]
"I don't know if I'd put it like that..."
[cpg cn=true]


Not that I was trying to be modest or anything.
[cpg]


When you have these three in front of you, you might respond in such a way.
[cpg]


[FACE method="bow_2" pos="1/3"]
[VOICE f="sMithika006"]
[OnName num="mithika"]
"You don't act all intimidated by us or anything. When we chat you really listen."
[cpg cn=true]


[FACE method="shake_1" pos="1/3"]
[VOICE f="sMithika007"]
[OnName num="mithika"]
"So, we started talking and we were thinking that maybe the four of us could go on a date together."
[cpg cn=true]


What. How did they come to that conclusion?
[cpg]


I was having a hard time understanding what was happening.
[cpg]


[FACE method="change_2" pos="1/3"]
[FACE method="change_2" pos="2/3"]
[FACE method="change_2" pos="3/3"]

[OnName num="shoma"]
"Let's not. If anybody sees us, it'll look bad."
[cpg cn=true]


[FACE method="shake_1" pos="3/3"]
[VOICE f="sMei008"]
[OnName num="mei"]
"I don't know, I think you'd just look really popular."
[cpg cn=true]


Yeah, that was the problem. I try to find a way out.
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="sNathuko005"]
[OnName num="nathuko"]
"Hey, wait!"
[cpg cn=true]



;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]
;//ＢＫ

I rush out, barely managing to escape them and headed straight home.
[cpg]


;//ここまで、ヒロイン全員がギャルの場合のみ発生するイベント
;//==============================

*allbich|心に秘めた想い人

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



It was time to go home. Today I decided to go home quickly.
[cpg]


Straight back without any detours. Students have a lot of time to spend as they please.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



However, all of that time is wasted when you have no hobbies or anything to do.
[cpg]


In that case, it's only natural to consider getting a girlfriend.
[cpg]


Of course, that alone would be a terrible motive for starting a relationship.
[cpg]


Falling in love with love is not something I should be doing.
[cpg]


But I was developing feelings for somebody.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



The days pass.
[cpg]



;//==============================
;//ここから暫く、芽衣がギャルの場合のみ発生するイベント

[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*eve_11"]
[endif]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



On my way to the school as usual. I see Mei ahead of me.
[cpg]


She's mingling and conversing with some gals. They seem to be having a lot of fun......
[cpg]


She didn't really seem like the type to play around.
[cpg]


If anything, she looked pretty tame compared to the gals she was with.
[cpg]


But the reality was different. She was every bit a player as she looked, possibly even moreso.
[cpg]


Maybe girls like her were the real carnivore types you'd have to watch out for. Honestly, I didn't know, the only other gals I'd talked to were Michika and Natsuko.
[cpg]


She doesn't notice me even though we're so close. I can see her smiling face.
[cpg]


……She's almost always smiling. I wonder if that's part of the act.
[cpg]


I found it strange that she'd smile like that to other girls as well. Did she have that kind of relationship with girls too?
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



Between classes, Mei approaches me.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMei009"]
[OnName num="mei"]
"Hey, can we talk? I figured you might be feeling a little lonely by now."
[cpg cn=true]


[OnName num="shoma"]
"......I'm not sure I follow."
[cpg cn=true]


But I did. It was clearly an invitation.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sMei010"]
[OnName num="mei"]
"If you buy me dinner, I'll go on a date with you."
[cpg cn=true]


[OnName num="shoma"]
"......Are you always so direct?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sMei011"]
[OnName num="mei"]
"Aww, you make me nervous when you say things like that."
[cpg cn=true]


It didn't seem like the kind of reaction someone with a lot of gal friends would have.
[cpg]

I guess she really enjoyed playing with men. No peer pressure or anything.
[cpg]


[OnName num="shoma"]
"All right, I'll meet you after school."
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then, after school.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************


[FACE method="shock_4" pos="2/3"]
[VOICE f="sMei012"]
[OnName num="mei"]
"Sorry! About today ...... Umm ..."
[cpg cn=true]


[OnName num="shoma"]
"What, did someone with a fatter wallet ask you out?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="sMei013"]
[OnName num="mei"]
"Not really, I had plans with someone else......but I forgot until a moment ago. Hehehe."
[cpg cn=true]


I was impressed she'd managed to accidentally double book. I was even more impressed by how she admitted it.
[cpg]

All I could say was that it was very...her.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]

;//ＢＫ



;//ここまで、芽衣がギャルの場合のみ発生するイベント
;//==============================

*eve_11|心に秘めた想い人


;//==============================
;//ここから暫く、美智佳がギャルの場合のみ発生するイベント


[if exp={getFlagValue("Cha1flg") == 0 }]
[jump target="*eve_12"]
[endif]


On the weekend, Michika invited me out.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[VOICE f="Michika070"]
[OnName num="mithika"]
"Hi. Did you wait?"
[cpg cn=true]


[OnName num="shoma"]
"Yeah, I got here early and you're 25 minutes late."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika071"]
[OnName num="mithika"]
"Only 20 minutes? Oh good, no biggie then."
[cpg cn=true]


Normally you're supposed to round up, not down...
[cpg]


As irritating as it was, I felt it might have been part of her charm.
[cpg]


Thinking that was somehow unfair, I asked Michika what she wanted.
[cpg]


[OnName num="shoma"]
"So? Why did you call me up today?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="sMithika008"]
[OnName num="mithika"]
"Nothing, I just wanted to see your face."
[cpg cn=true]


She wasn't afraid to say stuff like that. I admired that part of her.
[cpg]


[free time=1000]

;//ＢＫ



[SE f="se010"]
;//【ＳＥ】『歩く』


I ended up going on a date with Michika.
[cpg]

Unused to this sort of thing I was clumsy......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（昼）******************************************************



But at the end of it all, we ended up here.
[cpg]

The park. It was filled with flirting couples.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michika074"]
[OnName num="mithika"]
"......I didn't call you just for a date."
[cpg cn=true]


Unsure of what she meant, I suggested we hurry along and made our through the park.
[cpg]



;//ＢＫ



[FACE method="shake_3" pos="2/3"]
[VOICE f="Michika093"]
[OnName num="mithika"]
"You wimp. You were cooler before."
[cpg cn=true]


She was probably referring to how I acted before we got to know each other.
[cpg]

I was acting unsociable then, what part of that was cool?
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Exhausted after the date, I went back to my house and collapsed onto my bed.
[cpg]


And a little more time passes.
[cpg]



;//ここまで、美智佳がギャルの場合のみ発生するイベント
;//==============================

*eve_12|The person I have feelings for in my heart

;//==============================
;//ここから暫く、夏子がギャルの場合のみ発生するイベント

[if exp={getFlagValue("Cha2flg") == 0 }]
[jump target="*eve_13"]
[endif]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『公園』（夕方）******************************************************



The weekend. I had a few errands to run during the day, but once they were over, I was bored. I opted to sit idly in the park.
[cpg]


What a profound waste of the golden years of my youth. My eyes glazed over as I stare at nothing in particular.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nathuko064"]
[OnName num="nathuko"]
"It's ...... Shōma, right?"
[cpg cn=true]


[OnName num="shoma"]
"Whoa."
[cpg cn=true]


Natsuko suddenly approached me from behind.
[cpg]


A mixture of fear and surprise shocked me back into reality. It wasn't just her sudden appearance, it was also her background as a delinquent.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nathuko065"]
[OnName num="nathuko"]
"What are you doing here? Are you really that bored?"
[cpg cn=true]


[OnName num="shoma"]
"Is that bad? I don't think you'd enjoy hanging out with me."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Nathuko066"]
[OnName num="nathuko"]
"Who said anything about that? Anyways, if you're free then come with me for a bit."
[cpg cn=true]


I was tempted to pretend that I was waiting for someone, but on second thought, I was really bored.
[cpg]


I was so bored that I'd chosen to sit on a bench and space out......
[cpg]


This is not what a normal student would do. That's why I decided to follow Natsuko for a bit.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

[OnName num="shoma"]
"......So, how'd you end up a gal anyways?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sNathuko006"]
[OnName num="nathuko"]
"What do you mean?"
[cpg cn=true]


She is as blunt as ever. I'd have to rephrase my question to get any real answers out of her.
[cpg]

[OnName num="shoma"]
"I mean, you seem even tougher that most guys I know. I was just wondering why you chose to join the gal clique."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sNathuko007"]
[OnName num="nathuko"]
"I dunno, it just happened I guess."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sNathuko008"]
[OnName num="nathuko"]
"Although, I've always had a lot of guy friends."
[cpg cn=true]


I guess she never grew out of her tomboy phase or something.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************


We return to the park. I decided to ask what happened the other day.
[cpg]

[OnName num="shoma"]
"So......who was the guy you were with the other day? You seemed close."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="sNathuko009"]
[OnName num="nathuko"]
"What, you want me do the same to you?"
[cpg cn=true]


[OnName num="shoma"]
"That's not what I meant..."
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
Natsuko approaches me.
[cpg]

We were in public, but she was so close that I could feel her breath on my face.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="sNathuko010"]
[OnName num="nathuko"]
"What're you so nervous about? Even little kids kiss."
[cpg cn=true]


Saying that, she kisses me.
[cpg]

I wasn't her boyfriend or anything...... I just wanted to know if she was flirting with another boy.
[cpg]

Did she have feelings for me? If she didn't, why would she kiss me?
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

Was keeping me guessing just another way to seduce me?
[cpg]

My mind racing, I spent a little more time with Natsuko.
[cpg]



And a little more time passes.
[cpg]



;//ここまで、夏子がギャルの場合のみ発生するイベント
;//==============================

*eve_13|心に秘めた想い人


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



I wake up in my room in the morning. Everything is the usual.
[cpg]


I was already planning to go out today.
[cpg]


I'd started getting used to the gals.
[cpg]


There are three gals, some of whom I know and some of whom I can call friends. I was going to confess my feelings to one of them.
[cpg]


I wasn't in love with love, I'd thought about it and come to a decision.
[cpg]


I knew how I felt and I wanted to make these feelings clear.
[cpg]


That's why I decided to do it. I was going to tell her.
[cpg]


The person I have feelings for in my heart. Her name is ......
[cpg]



;//■選択肢
[switch]
[case "Michika"]
	[swap]
	[jump target="*select04_1"]
[case "Natsuko"]
	[swap]
	[jump target="*select04_2"]
[case "Mei"]
	[swap]
	[jump target="*select04_3"]
[endswitch]


1. Michika
2. Natsuko
3. Mei



*select04_1|心に秘めた想い人
[jump storage="ep006.ks" target="*select04_1"]

*select04_2|心に秘めた想い人
[jump storage="ep009.ks" target="*select04_2"]

*select04_3|心に秘めた想い人
[jump storage="ep012.ks" target="*select04_3"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
