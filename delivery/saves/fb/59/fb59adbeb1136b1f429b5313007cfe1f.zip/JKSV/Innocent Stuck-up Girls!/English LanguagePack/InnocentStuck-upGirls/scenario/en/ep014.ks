
*start


;//==============================
;//ヒロイン３がギャルである場合

*end3_citch|Mei for gift purposes



Mei. I like Mei ......
[cpg]


I want to be the best for her. That's how I felt.
[cpg]


;#################################################
*Ep014|Mei for gift purposes
;#################################################

[SCENE id=14]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************



Morning school. Mei was indeed in this class.
[cpg]


They also take classes. But when it comes to lunch, ......
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



He disappeared without a trace. Where did they go?
[cpg]


As someone who had planned to confess my feelings to her today, I felt a bit empty.
[cpg]


But I am also afraid to look for her.
[cpg]


What if I am with someone else? I have such a fear.
[cpg]


No matter, the fact remains that you don't see it or not. ......
[cpg]


I thought I would stand still again when I witnessed it.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



I still look for it, but I think I'm halfway there, or I'm not in control of myself.
[cpg]


And that's where I heard Mei's voice, as I thought I would: ......
[cpg]



;//========================================
;//●ＣＧエロ（背後から抱きつかれるヒロイン。背景が変わっています）ev_46
;//人物１：ヒロイン３
;//服装１：制服
;//人物２：モブ男
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_da"]
;**【ＣＧ】 ev_46_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

[OnName num="male_student"]
"Hey, Mei ......."
[cpg cn=true]


[VOICE f="sMei024"]
[OnName num="mei"]
"What is it?　You made a sweet voice."
[cpg cn=true]


[OnName num="male_student"]
"Mei's the one with the spoiled voice."
[cpg cn=true]


[VOICE f="sMei025"]
[OnName num="mei"]
"Don't be mean."
[cpg cn=true]


Mei and an unknown boy were about to kiss.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（昼）******************************************************



[SE f="se018"]
;//【ＳＥ】『走る』



I rush back to the hallway. However, it's at the end of the school, so I have to run or they will see me.
[cpg]


It's pathetic. Why should I run away?
[cpg]


I'm running away from the people I love. I think it's something I really need to pay attention to.
[cpg]


The word "herbivore" doesn't do away with it. This doesn't fulfill any hope. ......
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夕方）******************************************************


[VOICE f="Mei308"]
[OnName num="mei"]
"Hey, that's Shoma, right?"
[cpg cn=true]


That's what I thought, after school that day.
[cpg]


Mei approached me.
[cpg]


[OnName num="shoma"]
"Hey, what are you talking about ......?"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Mei309"]
[OnName num="mei"]
"I saw you run away."
[cpg cn=true]


What the hell. You were seen. It was a loss just to run away.
[cpg]


[OnName num="shoma"]
"Leave me alone. ......"
[cpg cn=true]


I found myself a little teary-eyed. I tried not to look at Mei because I didn't want her to see my face.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mei310"]
[OnName num="mei"]
"I've never met a man who was so jealous of me. I've never met a man like that before."
[cpg cn=true]


[OnName num="shoma"]
"What if it is? Don't make me think."
[cpg cn=true]


Do you like me that much?　Mei asks.
[cpg]


[OnName num="shoma"]
"I like it. Of course I like you."
[cpg cn=true]


I said this in a half-burned-out state of mind.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Mei311"]
[OnName num="mei"]
"Hey, why don't we go out ......?"
[cpg cn=true]


I couldn't believe my ears. But she apparently meant it.
[cpg]


I looked at Mei with tears in my eyes and she was looking at me with her eyes upward.
[cpg]



[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


From that day on, we started dating.
[cpg]


It's a ridiculous story. She was originally approaching the guy for a gift.
[cpg]


I probe, wondering if there's more to it than that.
[cpg]


[OnName num="shoma"]
"Hey, you're going to keep seeing other boys, aren't you?"
[cpg cn=true]


Mei shakes her head. If you ask her, she says she's going to cut ties with the other boys.
[cpg]


How could that be possible? I don't think he liked me that much in an instant.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei312"]
[OnName num="mei"]
"I'll go to my house. Wouldn't you like to, Shoma?"
[cpg cn=true]


I couldn't refuse. I just went along.
[cpg]


[SE f="se011"]
;//【ＳＥ】『ドア開く』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



[OnName num="shoma"]
"T, Thank you for inviting me."
[cpg cn=true]


He went into Mei's room. There, Mei said something unexpected.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sMei026"]
[OnName num="mei"]
"Then it's a gift I'd like to get ......"
[cpg cn=true]


[OnName num="shoma"]
"What's ......?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

I made a crazy noise, but she nodded her head.
[cpg]


[OnName num="shoma"]
"I, I don't have any money on me right now. ......"
[cpg cn=true]


Mei looked blatantly disappointed. So that's how it is after all.
[cpg]


Going out with me is based on the assumption that we're going to connect with things.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mei314"]
[OnName num="mei"]
"What?...... okay, oh well, I can't help it."
[cpg cn=true]



;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


And then, as we were leaving.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Mei328"]
[OnName num="mei"]
"I'll see you later. Bring me the money this time."
[cpg cn=true]


[OnName num="shoma"]
"...... yeah."
[cpg cn=true]


I said yes, but does this count as being in a relationship?
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
;//ＢＫ



After that, I spent most of my time working part-time.
[cpg]


For the first time in my life. I learned that a part-time job can be quite demanding.
[cpg]


It was a part-time job at a convenience store, but there was quite a lot to learn, and the odd customer would come in from time to time.
[cpg]


It was just hard to have to be flexible.
[cpg]


I guess I'm not good at that kind of thing. At the same time, I thought that if I had not had this experience, it would have been difficult when I entered the workforce.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************



Even if you start a part-time job, you don't have any money until payday.
[cpg]


Today is another day off and I have a date with Mei, but I can't get to the thing because I don't have the money. ......
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mei329"]
[OnName num="mei"]
"I'll go to Shoma's room then. It might be a bit of fun."
[cpg cn=true]


[OnName num="shoma"]
"Umm, yeah ...... good, but I don't have any money, okay?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mei330"]
[OnName num="mei"]
"I see. Then I can't do anything for you."
[cpg cn=true]

What do you mean, "nothing"? We're lovers.
[cpg]

Damn, I should have saved up. Or I should have asked my parents for more allowance on a regular basis.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************




Mei shows a normal reaction to my room, like there's nothing there.
[cpg]


She did not kiss me or even hug me, as she declared.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[OnName num="shoma"]
"...... Mei, is your curfew ok?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]

Mei replies, "Yes, that's right. She really doesn't do anything to me and tries to go home.
[cpg]


[OnName num="shoma"]
"Because I know when payday comes I'll be able to buy ...... something for you."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Mei345"]
[OnName num="mei"]
"I agree. Cut back on wasting money on other things, Shoma."
[cpg cn=true]


I would do so without being told. I wouldn't be able to buy a game or a comic book by mistake. ......
[cpg]


I even had to hold back when I was hungry. That's how much I was willing to contribute to her.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



On the way to school. I met Michika.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michika469"]
[OnName num="mithika"]
"Are you still seeing Mei?"
[cpg cn=true]


I wonder where the rumor got started. Well, but are they acting like lovers?
[cpg]


[OnName num="shoma"]
"I'm dating. Do you have a problem with that?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika470"]
[OnName num="mithika"]
"I don't have one, but ...... are you okay?　I thought you were working part-time or something."
[cpg cn=true]


You get the idea. That's how famous Mei's obsession with money must be.
[cpg]


;//移植のためシーンをカットしています
;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************


Then, after school. I talked to Mei.
[cpg]


[OnName num="shoma"]
"...... then we'll go home together."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei359"]
[OnName num="mei"]
"That's good. You're my lover."
[cpg cn=true]


This is about the only thing they don't want in return. By the way, no kissing.
[cpg]


She seems to have a pretty clear line of demarcation in that area.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



That's how much I liked Mei.
[cpg]


She chooses men for their money. That's great.
[cpg]


Then I'll make more money than anyone else so that she'll choose me. That's what I thought.
[cpg]


[OnName num="shoma"]
"Hey, Mei."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sMei027"]
[OnName num="mei"]
"What's up?　I'll give you a service if you just hold my hand."
[cpg cn=true]


[OnName num="shoma"]
"I love you. I love you."
[cpg cn=true]


Mei smiled softly, unashamedly.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



And so the days passed. I had a part-time job outside of the convenience store.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]


Youth passed like a rush.
[cpg]

[BG f="b_04_2.ui" time=1000]

In the end, the whole time we were dating, they wanted something in return.
[cpg]

[BG f="b_04_3.ui" time=1000]

All the way up until I got a job and got married ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



We did not have a wedding. We agreed that it was a waste of money.
[cpg]


I think it's just like us. Or perhaps I was inspired by Mei's way of thinking.
[cpg]


[OnName num="shoma"]
"......Where, after all, did those gifts from my school days disappear?"
[cpg cn=true]


We are both adults now. We are not the same as when we were students.
[cpg]


That's why I ask these things. Then Mei answered me like this.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMei028"]
[OnName num="mei"]
"Let's see, ......, you gave me everything I wanted."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sMei029"]
[OnName num="mei"]
"So I saved the rest of the money for after we were married."
[cpg cn=true]

[OnName num="shoma"]
"......You're so stubborn ......"
[cpg cn=true]


We're married and they still deduct our allowance.
[cpg]


[OnName num="shoma"]
"Then the allowance that is being deducted now is ......."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei376"]
[OnName num="mei"]
"Saving for when you have a baby. There's no reason not to have a lot of it, right?"
[cpg cn=true]


She really is a woman to the core. I can see why I was attracted to her when I was a student.
[cpg]


[OnName num="shoma"]
"That's great. You could have used it however you wanted, couldn't you?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Mei377"]
[OnName num="mei"]
"I'm doing all the saving because I love you. I want to be happy with Shoma."
[cpg cn=true]


I don't think money leads directly to happiness.
[cpg]


But I know it is a form of love for her. That's enough.
[cpg]



;//ＢＫ

[SCENE id=23]

[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン３非処女ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


