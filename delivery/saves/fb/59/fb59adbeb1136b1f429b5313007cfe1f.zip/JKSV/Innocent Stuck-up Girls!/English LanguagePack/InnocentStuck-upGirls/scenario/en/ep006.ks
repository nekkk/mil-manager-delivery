

*start|


;//==============================
;//１、美智佳

*select04_1|The person I have feelings for in my heart

;//それぞれ純情であるかギャルであるかによって３種類に分岐


;//ヒロイン１が非処女である場合
[if exp={getFlagValue("Cha1flg") == 1 }]
[jump target="*end1_citch"]
[endif]

[if exp={getFlagValue("Cha1flg") == 0 }]
[if exp={getFlagValue("Cha2flg") == 0 }]
[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*end1_alvar"]
[endif]
[endif]
[endif]
;//全てのヒロインが処女である場合



;//==============================
;//ヒロイン１が純情であり、残り二人のうち片方あるいは両方がギャルである場合

*end1_badend|Guilty Conscience

It's Michika. She was the first person to really get me to open up.
[cpg]


Sure, I've had other gals approach me, but could you really call it cheating?
[cpg]


Although nervous about my prospects, I decided to confess my feelings to Michika.
[cpg]


;#################################################
*Ep006|後ろめたい気持ち
;#################################################

[SCENE id=6]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika095"]
[OnName num="mithika"]
"Hey. What's up?"
[cpg cn=true]


[OnName num="shoma"]
"Well …… Nothing much."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika096"]
[OnName num="mithika"]
"You know, you're not fooling anybody. It's clear as day that something's bothering you."
[cpg cn=true]


She was right. I couldn't hold back these feelings of guilt.
[cpg]


I'd kissed another girl.
[cpg]


Was it really okay for me to tell her how I felt? It didn't feel like it...
[cpg]


[OnName num="shoma"]
"Really, it's nothing. Don't worry about it ......"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Michika097"]
[OnName num="mithika"]
"When you put it like that, it only makes me worry more. C'mon, spill the beans already."
[cpg cn=true]


If only I could......
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I decided that this wasn't the time, nor the place.
[cpg]


Today's classes felt like they dragged on forever. Once they were finally over, we met up again.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michika098"]
[OnName num="mithika"]
"What's up? Do you owe someone money or something?"
[cpg cn=true]


Michika's face is a little red. She's probably guessed why we're here.
[cpg]


But she doesn't seem panicked. She must think I don't have the courage to go through with it yet.
[cpg]


[OnName num="shoma"]
"Listen, Michika.......I like you. A lot."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Michika099"]
[OnName num="mithika"]
"Wha-......"
[cpg cn=true]


Her expression changes to one of surprise. I guess she didn't expect me to find the courage to tell her so soon.
[cpg]


She tries, but fails to hide her panic.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="sMithika009"]
[OnName num="mithika"]
;//「あ、あはは。私？　嘘でしょ？　こんなギャルもどきが好きって、冗談きついよ」
"Oh, haha. Me? You're kidding, right? I mean, I'm a gal and all. If it's a joke, you're going a little too far."
[cpg cn=true]


[OnName num="shoma"]
"Gal or not, that's got nothing to do with it. I like you for you, Michika."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
Even as the words leave my lips, I'm forced to remember that I'd touched another girl.
[cpg]


My heart aches with guilt. But Michika accepts my confession.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Michika101"]
[OnName num="mithika"]
"......I don't...have a lot of experience with stuff like this......"
[cpg cn=true]


[OnName num="shoma"]
"I figured, but I didn't expect you to admit it."
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Michika102"]
[OnName num="mithika"]
"Don't make fun of me. You really surprised me, I've never had someone confess to me before."
[cpg cn=true]


[OnName num="shoma"]
"Now who's joking? I bet the boys don't leave you alone."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Michika103"]
[OnName num="mithika"]
"I'm not popular! The only kind of guys lining up to date someone like me are fanatics like you."
[cpg cn=true]


I guess I was a fanatic. It's not like I'd fallen for her because she was a gal.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



We walk home, holding hands. I felt extremely self-conscious.
[cpg]


Michika must have felt the same way. She keeps looking around nervously. Probably worried that someone would see us.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika104"]
[OnName num="mithika"]
"This...I can't......"
[cpg cn=true]


[OnName num="shoma"]
"What? Having second thoughts?"
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Michika105"]
[OnName num="mithika"]
"'No! I like you too......it's just..."
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


As time passes, our budding relationship develops. But I was being seduced by another gal.
[cpg]


Unable to resist her advances, I'd even gone so far as to kiss her.
[cpg]

I had Michika, but I couldn't resist......I felt terrible about it.
[cpg]


;//
;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_01_3.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//
;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//;//【ＢＧ】『主人公の部屋』（夕方）******************************************************
;//
;//
;//
;//そしてある日。俺と美智佳は一線を超えようとしていた。
;//[cpg]
;//
;//
;//互いに裸になって正座。ギャルの美智佳がこういうことをしているのはかなりギャップがある。
;//[cpg]
;//
;//
;//[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
;//[VOICE f="Michika106"]
;//[OnName num="mithika"]
;//「そ、それじゃ……しよっか？　ううん、したい」
;//[cpg cn=true]
;//
;//
;//[OnName num="shoma"]
;//「俺もしたいよ。美智佳……」
;//[cpg cn=true]
;//
;//
;//だけど、美智佳の他にも女の子を抱いている。
;//[cpg]
;//
;//
;//俺はとんでもない裏切りものだと思いながら、美智佳を抱くことにする。
;//[cpg]
;//
;//
;//夕日が赤かったのがやけに印象深かった。美智佳の肌も、ほんのり赤い。
;//[cpg]
;//
;//
;//
;//;//移植のためシーンをカットしています
;//
;//
;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_01_3.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//
;//[BGM f="bg_sa"]
;//[WAIT time=100]
;//;//【ＢＧ】『主人公の部屋』（夕方）******************************************************
;//
;//
;//
;//それから、美智佳がイケるまで色々試した。最後には美智佳も満足してくれたようなので、これで良いと思う。
;//[cpg]
;//
;//
;//問題はこれからだ。他の子と、どうやって手を切るか、今の内に考えておかないと。
;//[cpg]
;//
;//
;//[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
;//[VOICE f="Michika122"]
;//[OnName num="mithika"]
;//「幸せ……こんなに幸せでいいのかな、私」
;//[cpg cn=true]
;//
;//
;//[OnName num="shoma"]
;//「……幸せでいいんだと思うよ」
;//[cpg cn=true]
;//
;//
;//俺の言葉には裏がある。断言できない理由がある。
;//[cpg]
;//
;//
;//後ろめたさがある。そしてそれは、思ったよりすぐ表ざたになった。
;//[cpg]
;//

;//移植のためシーンをカットしています


;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


One day at school. A classroom where there are still people left ......
[cpg]



;//【ＢＧ】『学園教室』（夕方）******************************************************



[SE f="se009"]
;//【ＳＥ】『ビンタ』

[FACE method="shock_3" pos="2/3"]

Michika slaps me with all her might.
[cpg]


I put my hand to my stinging face and look up at Michika. She was crying.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Michika123"]
[OnName num="mithika"]
"If you like a girl other than me, why don't you just say so? Why did you have to go behind my back?"
[cpg cn=true]


[OnName num="shoma"]
"It's not like that, Michika! I like you, it's just......"
[cpg cn=true]


What more could I say? I can vaguely hear people murmuring around us. There's a hostility in the air and it's aimed at me.
[cpg]


I guess that was a given. I was in the wrong.
[cpg]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Michika124"]
[OnName num="mithika"]
"I'll never trust men again……! Especially not you!"
[cpg cn=true]

[free time=1000]
[SE f="se018"]
;//【ＳＥ】『走る』

Michika leaves the room crying. I couldn't chase after her. What right did I have?
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



......At least I still had my relationship with the other gal.
[cpg]


What a lousy person I must be.
[cpg]


[SCENE id=15]

[jump storage="epend.ks" target="*badend"]

;//ＥＮＤ：ヒロイン１バッドエンド



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


*end1_alvar|The Pure Michika
[jump storage="ep007.ks" target="*end1_alvar"]

*end1_citch|Michika is a player
[jump storage="ep008.ks" target="*end1_citch"]

