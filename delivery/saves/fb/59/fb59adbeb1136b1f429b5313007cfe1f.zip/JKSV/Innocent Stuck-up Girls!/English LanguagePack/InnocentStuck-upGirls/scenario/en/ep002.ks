
*start


;#################################################
*Ep002|What do I think about Natsuko?
;#################################################

[SCENE id=2]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』


Then the next day, on the way to the school.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mei006"]
[OnName num="mei"]
"Ah, good morning, Shōma."
[cpg cn=true]


[OnName num="shoma"]
"Oh, good morning, Mei. Do you live around here too?"
[cpg cn=true]


It was almost pointless to ask, we were almost at the academy. You could meet anyone at this point.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Mei007"]
[OnName num="mei"]
"So, we're friends now, but we haven't really done anything yet......"
[cpg cn=true]


[OnName num="shoma"]
"What do you mean? Was there something we were supposed to do?"
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
She pouts a little while saying "Well, yeah...".
[cpg]


[OnName num="shoma"]
"Then...should we exchange phone numbers?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
She smiles and nods, I guess that was the right answer.
[cpg]


Usually I wouldn't bother getting this close to anybody, but there's something comforting about Mei that makes me act like this.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



So we exchanged phone numbers.
[cpg]

[FACE method="bow_2" pos="2/3"]

It was a trivial thing, but she seemed really happy about it.
[cpg]


I didn't mind either. Now I had something to keep me occupied over the weekends.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[SE f="se017" loop=true]
;//【ＳＥ】『喧噪』

We got to school. After that, we finished our morning classes and began lunch break.
[cpg]


I joined a conversation with some of the male students about Miyako.
[cpg]


We were having a conversation in the corner of the classroom.
[cpg]


[OnName num="male_student_A"]
"Hey ...... what do you think about Natsuko Miyako?"
[cpg cn=true]


Glancing at each other, we speak in whispers.
[cpg]


[OnName num="shoma"]
"Why the full name? I mean sure, it's distinctive......"
[cpg cn=true]


[OnName num="male_student_A"]
"I dunno, it just feels like you gotta respect her or she'll come after you. I don't think I've ever heard of a guy getting close to her."
[cpg cn=true]


[OnName num="male_student_B"]
"Me neither. What about you, Miyagishi?"
[cpg cn=true]


[OnName num="shoma"]
"I couldn't say......"
[cpg cn=true]



;//■選択肢
[switch]
[case "I think she is surprisingly inexperienced."]
	[swap]
	[jump target="*select03_1"]
[case "I think she's a player."]
	[swap]
	[jump target="*select03_2"]
[endswitch]


1. I think she is surprisingly inexperienced.
2. I think she's a player.

;//==============================
;//１、意外と初心だと思う

*select03_1|夏子についてどう思う？

;//夏子が純情設定になる
[stflag Cha2flg = 0]



[OnName num="shoma"]
"I think she is rather inexperienced. I don't know if she even has a boyfriend ......"
[cpg cn=true]


[OnName num="male_student_A"]
"For real!? Yeah...Maybe you're right......"
[cpg cn=true]


Miyako and the others were looking at us. Maybe we were being too loud.
[cpg]


[OnName num="male_student_B"]
"If we're talking about guys, punks aren't immune to girls."
[cpg cn=true]


[OnName num="shoma"]
"I don't that theory applies when it's the other way around. Maybe she's not what she looks like."
[cpg cn=true]


Rather, I want her to be inexperienced. That desire was expressed in my answer.
[cpg]


[jump target="*select03_3"]

;//==============================
;//２、遊んでると思う

*select03_2|夏子についてどう思う？

;//夏子がギャル設定になる
[stflag Cha2flg = 1]


[OnName num="shoma"]
"I think she's probably a player. I mean, just look at her."
[cpg cn=true]


I started to regret saying something so degrading, but the others agreed.
[cpg]


[OnName num="male_student_A"]
"Makes sense, man. Well, I might have heard rumors about that ......"
[cpg cn=true]


[OnName num="male_student_B"]
"No kidding? Well, she certainly doesn't look like the prim and proper type."
[cpg cn=true]


In my mind, it would have been scarier if a girl like that didn't have a lot of experience.
[cpg]

If anything, I thought girls were even more attractive if they were experienced to some extent.
[cpg]



;//==============================

*select03_3|夏子についてどう思う？

;//==============================
;//ここから暫く、夏子が純情の場合のみ発生するイベント

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*cha02_gal01"]
[endif]



[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』


Then afternoon classes end and it's after school.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



It took me a little while to get ready to leave. By the time I'd finished, the hallways were empty.
[cpg]


I see Miyako headed towards the same direction as me.
[cpg]


I should take the plunge and talk to her. I would like to get to know this type of gal as well.
[cpg]


[OnName num="shoma"]
"Hey, Ms. Miyako ......"
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（廊下で話す二人。ヒロイン不機嫌、途中から主人公をにらむ）ev_04
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園廊下
;//時間　：昼
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_04_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="Nathuko007"]
[OnName num="nathuko"]
"Whaddya want?"
[cpg cn=true]


That's...aggressive. Was she really a girl?
[cpg]


[OnName num="shoma"]
"Oh, it's just I saw you were a bit late going home too."
[cpg cn=true]



[VOICE f="Nathuko008"]
[OnName num="nathuko"]
"It's just a coincidence. Also, don't call me Ms. Miyako."
[cpg cn=true]


Did I say something to offend her?
[cpg]


She looks extremely grumpy. Was calling her ‘Ms. Miyako' really that bad?
[cpg]


[OnName num="shoma"]
"Then what should I call you ......?"
[cpg cn=true]



[VOICE f="Nathuko009"]
[OnName num="nathuko"]
"I hate it when people call me by my surname or add ‘Ms'."
[cpg cn=true]


Does that mean I should call her Natsuko?
[cpg]


It was easy in my head, but surprisingly difficult to put into practice in reality.
[cpg]


[OnName num="shoma"]
"So, Natsuko ......"
[cpg cn=true]


I called her Natsuko, but she remains grumpy.
[cpg]


I guess she wasn't grumpy because of the way I'd referred to her. I don't know why she's grumpy anymore.
[cpg]


She forgave me for what happened the other day. I think about it that much and realize.
[cpg]



[VOICE f="Nathuko010"]
[OnName num="nathuko"]
"If you don't have anything to say, talk to me later. I'm busy."
[cpg cn=true]


She didn't look very busy. I figured she must be grumpy all year round.
[cpg]

[jump target="*cha02_gal01_end"]

;//ここまで、夏子が純情の場合のみ発生するイベント
;//==============================



;//==============================
;//ここから暫く、夏子がギャルの場合のみ発生するイベント
*cha02_gal01|夏子についてどう思う？



[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=false]


;//[SE f="se014"]
;//【ＳＥ】『学園のチャイム』


After school. I go straight home.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//【ＢＧ】『街』（夕方）******************************************************



But along the way, I got lost again.
[cpg]


I walk around wondering where I went wrong......
[cpg]




[SE f="se010"]
;//【ＳＥ】『歩く』

[WAIT time=2000]
;//ＢＫ



As I kept walking, I realized that I seemed to be going in circles.
[cpg]


There wasn't much in the way of landmarks in the area, and the roads are intricate.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



Evening was about to turn into night. It's really bad if I don't go home soon.
[cpg]


I was wondering what to do .......
[cpg]


[VOICE f="sNathuko001"]
[OnName num="unknown"]
"What are you waiting for? You started this."
[cpg cn=true]


[OnName num="male_student"]
"I'm not hesitating. Don't underestimate me."
[cpg cn=true]


I heard voices from the back alley. It was the voices of a male and a female.
[cpg]


And the voice sounded somewhat familiar. I headed in that direction.
[cpg]


I should have left it alone, but I tried to explore the scene.
[cpg]


;//移植のためシーンをカットしています
[FADEOUTBGM]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;//ＢＫ

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

There, as expected ...... Miyako was with a boy I didn't know.
[cpg]

Obviously, I feel like I'm intruding. But I guess they can't see me.
[cpg]



;//ＢＫ


[FACE method="change_7" pos="2/3"]
[VOICE f="Nathuko027"]
[OnName num="nathuko"]
"...... Is someone there?"
[cpg cn=true]


I guess I was wrong. Miyako had found me hiding behind something.
[cpg]


[OnName num="shoma"]
"No, I just happened to pass by. Sorry to have disturbed you."
[cpg cn=true]


Normally I'd be in a stronger position, but I wanted to extract myself from this situation as easily as possible.
[cpg]


However, Miyako had other plans.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sNathuko002"]
[OnName num="nathuko"]
"What did you say your name was again?"
[cpg cn=true]


[OnName num="shoma"]
"I'm Shōma Miyagishi ......."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="sNathuko003"]
[OnName num="nathuko"]
"Sorry, but you'll have to wait your turn."
[cpg cn=true]


Wait for my turn. For a moment I didn't know what that meant.
[cpg]

[OnName num="shoma"]
"Ms. Miyako ......?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sNathuko004"]
[OnName num="nathuko"]
"I'm fine with Natsuko. I hate being called by my last name."
[cpg cn=true]



;//移植のためシーンをカットしています


;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I wonder if waiting for my turn means that I'm next in line to that guy who was just here.
[cpg]

I guess she can see that I have some feelings for her ……
[cpg]


;//ここまで、夏子がギャルの場合のみ発生するイベント
;//==============================

*cha02_gal01_end|夏子についてどう思う？


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



I get back home and take a breather.
[cpg]


Natsuko. She's a mysterious person. I guess you could call her a delinquent.
[cpg]


Someone as punk as her is rare nowadays. I think we used to call people like her a Sukeban......
[cpg]


But she had that anachronistic, delinquent look.
[cpg]


Of course I'd never say it to her face, but that's what I thought. Was there some reason why she was acting like a delinquent?
[cpg]



[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I ate dinner, took a bath, and called it a night.
[cpg]


I've had a surprising amount of contact with gals at this school, but they were all quite different.
[cpg]


And if you look up gal on the internet, the are a bunch of results .......
[cpg]


A mountain of detailed definitions. They're even broken down by age in history.
[cpg]


But the most fragmented generation was apparently the previous one......
[cpg]


I got the impression that the word "gal" itself was a bit old-fashioned.
[cpg]


What should we call these girls then?
[cpg]


[jump storage="ep003.ks" target="*start"]


;////////////////////////////////////////////////////////////////////////

