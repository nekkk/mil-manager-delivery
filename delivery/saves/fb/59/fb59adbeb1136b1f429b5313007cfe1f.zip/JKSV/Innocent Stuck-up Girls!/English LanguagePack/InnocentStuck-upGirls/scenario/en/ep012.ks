
*start


;//==============================


;//それぞれ純情であるかギャルであるかによって３種類に分岐
;//==============================
;//３、芽衣
*select04_3|The person I have feelings for in my heart


;//ヒロイン３が純情であり、残り二人のうち片方あるいは両方がギャルである場合


;//ヒロイン3が非処女である場合
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*end3_citch"]
[endif]

[if exp={getFlagValue("Cha1flg") == 0 }]
[if exp={getFlagValue("Cha2flg") == 0 }]
[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*end3_alvar"]
[endif]
[endif]
[endif]
;//全てのヒロインが処女である場合



;//==============================
;//ヒロイン３が処女であり、残り二人のうち片方あるいは両方が非処女である場合

*end3_badend|A love that slowly faded away

[OnName num="shoma"]
"......Mei."
[cpg cn=true]


It had to be her.
[cpg]


I felt like I'd made a breakthrough. I knew I loved her.
[cpg]


However, I'd begun relationships with other girls......
[cpg]


Will she forgive me? I couldn't be sure, I had to keep it a secret.
[cpg]

;#################################################
*Ep012|徐々に立ち消えた恋
;#################################################

[SCENE id=12]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************




I met Mei in the morning. Of course, since we are in the same class.
[cpg]


However, it wasn't like I could confess to her immediately.
[cpg]


[OnName num="shoma"]
"Hey......do you have time after school today?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei105"]
[OnName num="mei"]
"Sure, what's up?"
[cpg cn=true]



[FADEOUTBGM]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



I could hardly wait for classes to end.
[cpg]


Classes were always dull, but it felt like they dragged on forever.
[cpg]


It was finally time.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



I'd already called her out, there was no going back.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

The two of us are alone in a classroom after school. I'm sure she had an inkling of what we were here for.
[cpg]


[OnName num="shoma"]
"Mei......do you have a boyfriend?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Mei106"]
[OnName num="mei"]
"Nope, I don't think I've ever had one."
[cpg cn=true]


Get a hold of yourself, this wasn't what you were here for......
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Mei107"]
[OnName num="mei"]
"Sooo, are you going to, you know......confess?"
[cpg cn=true]


She says so with a blush and puppy dog eyes.
[cpg]


[OnName num="shoma"]
"......yes."
[cpg cn=true]


My voice trails off. We're quiet for a little while.
[cpg]


This wasn't how I imagined it going. I couldn't let her say it for me.
[cpg]


I gathered my resolve.
[cpg]


[OnName num="shoma"]
"Um, please go out with me……Mei."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei108"]
[OnName num="mei"]
"What a surprise, I thought my heart would stop."
[cpg cn=true]


Mei, finally says something. It wasn't a reply.
[cpg]


[OnName num="shoma"]
"So, what do you think? Will you go out with me......?"
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Mei109"]
[OnName num="mei"]
"Sure! I'm happy, but are you sure you want to go out with me?"
[cpg cn=true]


......Wow. That went a lot better than I'd expected.
[cpg]


It's different from how I thought it would be. I didn't expect it to be so casual.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Mei110"]
[OnName num="mei"]
"So......what happens now? What do couples do, anyways? Kiss or something?"
[cpg cn=true]


[OnName num="shoma"]
"I guess that depends on what you want to do."
[cpg cn=true]


I left the answer to her. That was not manly.
[cpg]


Mei fidgets shyly for a while.
[cpg]

;//========================================
;//●ＣＧエロ（ヒロインに迫る主人公。キスをする）ev_39
;//人物１：ヒロイン３
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_39_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]

She made a gesture like she was waiting for me to do something.
[cpg]

I had to take the initiative.
[cpg]


[VOICE f="Mei111"]
;//[VOICE f="sMei015"]
[OnName num="mei"]
We kissed.
[cpg cn=true]


I couldn't resist ...... given the situation.
[cpg]


I reaffirmed that I really love her.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[SE f="se010"]
;//【ＳＥ】『歩く』



We head home together, flirting all the while.
[cpg]


We talked about mundane things like holding hands or how we should hold each other's hands and how long.
[cpg]


In the end, we naturally laced our fingers together. It was kind of embarrassing.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei130"]
[OnName num="mei"]
"I always wanted to hold hands like this."
[cpg cn=true]


Mei seems happy. That's all the more reason for me to be a little anxious.
[cpg]


What if she finds out that I'd been kissing other girls? That would be cheating, right?
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』


And that hunch was correct. One day, Mei appeared extremely grumpy.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mei131"]
[OnName num="mei"]
"You're such a pig, Shōma. I bet you made a bunch of other girls cry too."
[cpg cn=true]


[OnName num="shoma"]
"W...what are you talking about......?"
[cpg cn=true]


I shouldn't play dumb. She already knew.
[cpg]


[FACE method="shock_3" pos="2/3"]
[VOICE f="sMei016"]
[OnName num="mei"]
"From now on, when we go out, you have to give me something in return."
[cpg cn=true]


I had to buy her something to show my love for her. My actions were no longer enough.
[cpg]


I seem to have made Mei quite angry.
[cpg]


It took a while for me to realize that she'd chosen a very roundabout way of breaking up with me.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************





[FACE method="shake_2" pos="2/3"]
[VOICE f="sMei017"]
[OnName num="mei"]
"What? You can't even afford that? Then let's break up."
[cpg cn=true]


[OnName num="shoma"]
"But...I can't afford it……."
[cpg cn=true]


Over time, the presents she wanted became more and more lavish. There was no way I could afford them anymore.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mei134"]
[OnName num="mei"]
"Well that's too bad. I guess we should break up."
[cpg cn=true]


[OnName num="shoma"]
"Wait! Please, just give me a week!"
[cpg cn=true]


I had to buy time. But even if I went around borrowing money from people, it wouldn't be anywhere near enough.
[cpg]


I knew it wouldn't last. We'd break up eventually. Still, I clung to her desperately.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



It's beyond pathetic....... I think our love had probably ended a little while ago.
[cpg]


What was the point of dragging it out so long? There wasn't any, and I knew it.
[cpg]


But I wasn't ready to give up yet, even if it was clear that she was sick of me.
[cpg]


......Thus, our love slowly faded away.
[cpg]


[SCENE id=21]


[jump storage="epend.ks" target="*badend"]
;//ＥＮＤ：ヒロイン３バッドエンド



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

*end3_alvar|Mei in a daze
[jump storage="ep013.ks" target="*end3_alvar"]

*end3_citch|Mei dating me for returns
[jump storage="ep014.ks" target="*end3_citch"]

