
*start


;//==============================
;//全てのヒロインが純情である場合

*end1_alvar|純情な美智佳



Michika. She's the one who got me interested in gals......
[cpg]


But in the end, I found her the most attractive.
[cpg]


I guess I'm in love with her.
[cpg]


I'd still choose Michika even if another attractive girl approached me.
[cpg]

;#################################################
*Ep007|The Pure Michika
;#################################################

[SCENE id=7]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika125"]
[OnName num="mithika"]
"......What's up? Keep staring at me like that and I might start blushing."
[cpg cn=true]


[OnName num="shoma"]
"Can we talk after school? I need to tell you something."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

Michika seemed nervous for a second. She looks around as if to make sure that nobody was listening in.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Michika126"]
[OnName num="mithika"]
"......okay."
[cpg cn=true]


Sometimes it seemed like she was trying too hard to act like a gal. Maybe that's what it was. An act.
[cpg]


She is such an earnest, pure-hearted girl. Maybe she didn't really want to be a gal.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



Once classes were over it's just the two of us, alone in the classroom.
[cpg]


We sit at our usual seats. Usually we're faced towards the front of the room......
[cpg]


Now we're facing each other. It's an important conversation. I want to face it straight on.
[cpg]


[OnName num="shoma"]
"Michika, I like you."
[cpg cn=true]


Michika gulps.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Michika127"]
[OnName num="mithika"]
"......You really cut to the chase, huh. Normally you lead with something else."
[cpg cn=true]


I didn't think it was necessary. I wanted to tell her how I felt, so that's what I did.
[cpg]


I was more nervous about how Michika would respond.
[cpg]


Even if she eventually agreed, I fully expected to have to wait a week or so to get an answer.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Michika128"]
[OnName num="mithika"]
"......Give me a day. I'll have an answer for you tomorrow."
[cpg cn=true]


[OnName num="shoma"]
"I can't wait that long. I need to know how you feel about me."
[cpg cn=true]


I really didn't think I could wait that long for her answer.
[cpg]


Even now my heart was racing. I doubt I'd be able to sleep tonight if I didn't hear her answer now..
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Michika129"]
[OnName num="mithika"]
"It doesn't seem fair...I mean, I didn't get any chance to prepare for this......"
[cpg cn=true]


Michika takes a deep breath as if to calm herself.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika130"]
[OnName num="mithika"]
"I liked you too. I actually had that sort of a feeling about you from the first time I approached you."
[cpg cn=true]


[OnName num="shoma"]
"Really......? I couldn't tell."
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Michika131"]
[OnName num="mithika"]
"That's because I'm a gal! I wasn't gonna just up and say it....."
[cpg cn=true]


She smiles shyly.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



From that moment on, we were a couple.
[cpg]


We didn't tell anybody about us, but it didn't take long for the entire class to figure it out.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[SE f="se017" loop=true]
;//【ＳＥ】『学園の喧噪』

[OnName num="male_student_A"]
"How did you do it? How did you make her fall for you?"
[cpg cn=true]


[OnName num="shoma"]
"Huh? What......"
[cpg cn=true]


[OnName num="male_student_B"]
"Man, I was gunning for her too. I can't believe you lucked out like that."
[cpg cn=true]


[OnName num="shoma"]
"That's kinda mean……"
[cpg cn=true]


I had to endure endless ribbing from my classmates. Thankfully, it was all good-natured.
[cpg]


I defended myself, saying that all I had to do was confess.
[cpg]


[OnName num="female_student_A"]
"What's up, girl? Are you feeling okay?"
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
I can hear some of the other girls questioning Michika.
[cpg]


[OnName num="female_student_B"]
"Michika, you could have any guy you wanted. Why'd you pick him?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika132"]
[OnName num="mithika"]
"His face, I guess...?"
[cpg cn=true]


[OnName num="female_student_A"]
"Come on, he's not bad, but you can't really call him good-looking."
[cpg cn=true]


Ouch. Well, let them say what they want, Michika and I were together.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


After class, the two of us leave the school together.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』

[WAIT time=1000]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Michika133"]
[OnName num="mithika"]
"I didn't think it would be such a big deal."
[cpg cn=true]


[OnName num="shoma"]
"I think you had a lot of secret admirers. Both boys and girls."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Michika134"]
[OnName num="mithika"]
"What do you mean?"
[cpg cn=true]


She definitely seemed to be the central figure among the gals.
[cpg]


But I had other things I wanted to talk to her about right now.
[cpg]


[OnName num="shoma"]
"So...what part of me did you fall for?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Michika135"]
[OnName num="mithika"]
"That's a hard one. I guess for me, it's all the time we spent together."
[cpg cn=true]


Come to think of it, she did say she felt a spark when we first met.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Michika136"]
[OnName num="mithika"]
"I mean, I liked how you looked. And when I got to know you, it was clear you weren't a player. I guess the biggest thing was that you were kind."
[cpg cn=true]


[OnName num="shoma"]
"Kind...huh?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika137"]
[OnName num="mithika"]
"Trust me, I've been paying attention. You're very kind."
[cpg cn=true]


I guess it's not something you'd normally notice on your own.
[cpg]


I'd always conflated the word with effeminate. If that's what got me together with Michika, I guess I didn't mind.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



Then the next morning. A pretty important event happened in my life.
[cpg]


Our first date. I liked how it sounded in my head. It's almost embarrassing.
[cpg]


I leave the house, taking more care than usual about my appearance as well as pretending to be natural.
[cpg]


My parents asked me if I was going on a date, but I didn't answer them.
[cpg]


How did they know......?
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michika138"]
[OnName num="mithika"]
"Good morning. Did you wait for me?"
[cpg cn=true]


[OnName num="shoma"]
"Not at all. Let's go then."
[cpg cn=true]


It's a normal conversation, but I'm a little nervous and don't feel like I'm actually speaking.
[cpg]


[OnName num="shoma"]
"Where do you want to go? I didn't make any plans, so don't count on me."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Michika139"]
[OnName num="mithika"]
"Aww, and I thought you were going to sweep me off my feet."
[cpg cn=true]


Her words sounded slightly forced. She was probably as nervous as I was.
[cpg]


We were both behaving awkwardly, but it wasn't like either of us could mention it.
[cpg]


[FADEOUTBGM]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=3000]
;//ＢＫ

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_sa"]
[WAIT time=100]

With these thoughts in mind, we went to the shopping mall and looked around.
[cpg]


Michika's taste in clothes is, as expected, girly.……
[cpg]


Still, she shows interest in things that make her a girl after all.
[cpg]


I mean, I'd normally never set foot in a variety store.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夕方）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michika140"]
[OnName num="mithika"]
"I had a great time. This might be the best day of my life."
[cpg cn=true]


[OnName num="shoma"]
"Oh come on, you're exaggerating. Besides, we're going to have even better times ahead of us."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Michika141"]
[OnName num="mithika"]
"I'm not exaggerating, seriously. When I'm with you, I even forget that I'm a gal."
[cpg cn=true]


Should I take that mean that she feels at ease with me? Maybe she wasn't always a gal.
[cpg]


A Michika that wasn't a gal...it might be interesting. I wonder if I'd ever get to see her like that.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



We start going on more dates. We're getting more comfortable with each other.
[cpg]


And it's not that either of us suggested it but ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



We found ourselves in my room. I'd thought we'd go to her room, but Michika wanted to see mine.
[cpg]



;//ＢＫ

;//========================================
;//●ＣＧエロ（主人公に迫るヒロイン）ev_15
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_15_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sMithika010"]
[OnName num="mithika"]
"What are lovers supposed to do?"
[cpg cn=true]


[OnName num="shoma"]
"......I'm down for whatever you want, Michika."
[cpg cn=true]


[VOICE f="sMithika011"]
[OnName num="mithika"]
"I know. I'm sorry, I guess I'm being overcautious."
[cpg cn=true]


She put up a calm front, but I could feel her heart racing.
[cpg]

She presses herself against me and we collapse onto the bed……
[cpg]

;//ＢＫ

Our lips touched.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[OnName num="shoma"]
"......We kissed."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Michika159"]
[OnName num="mithika"]
"Yeah......that's what lovers do, don't you think?"
[cpg cn=true]


Michika's face is flushed. She seems more embarrassed now.
[cpg]


[OnName num="shoma"]
"We should probably go before my parents get back……"
[cpg cn=true]


Well, it's not like they'd know what we were doing or anything but it was still kind of awkward.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sMithika012"]
[OnName num="mithika"]
"You must be disappointed…….I'm a gal, but a terrible kisser."
[cpg cn=true]


What was there to be disappointed with? I got to kiss her...
[cpg]


[OnName num="shoma"]
"Not a chance. What kind of guy do you think I am?"
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Michika161"]
[OnName num="mithika"]
"Right.......right, sorry. I guess it was a weird thing to say..."
[cpg cn=true]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]

And after my first experience, I saw her out and returned to my room.
[cpg]


;//【ＢＧ】『主人公の部屋』（夜）******************************************************


......Michika. Now she could say that she had a boyfriend too.
[cpg]

Thinking back, both Natsuko and Mei said that they didn't have boyfriends.
[cpg]

I guess I shouldn't think that all gals were the same.
[cpg]

Of course, there were probably a number of gals who acted the part, but maybe they weren't the majority.
[cpg]


[OnName num="shoma"]
"Man, I don't think I'm going to be able to sleep tonight......"
[cpg cn=true]


It was all because Michika's smell still lingered in my room.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika162"]
[OnName num="mithika"]
"Good morning. Did you sleep last night......?"
[cpg cn=true]


I turn to see Michika, who has dark circles under her eyes.
[cpg]


[OnName num="shoma"]
"Not much......it doesn't look like you got much sleep either."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sMithika013"]
[OnName num="mithika"]
"Well, you know......I was just having trouble processing it all."
[cpg cn=true]


We head to the school holding hands. I hear a lot of whispering.
[cpg]


[OnName num="male_student_A"]
"Hey, how long do you think those two will last?"
[cpg cn=true]


[OnName num="male_student_B"]
"Maybe two weeks. They don't fit together."
[cpg cn=true]


A guy I know and his friend mutter to each other.
[cpg]


What's it matter to them, anyways?
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Michika164"]
[OnName num="mithika"]
"How long do you think we're going to last? Have you...thought about it?"
[cpg cn=true]


[OnName num="shoma"]
"Do you want to break up......?"
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Michika165"]
[OnName num="mithika"]
"That's not what I mean. I just think you should be able to say 'forever' without hesitating."
[cpg cn=true]


[OnName num="shoma"]
"In that case, forever."
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
Michika looks away.
[cpg]


I didn't understand what she wanted me to say.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（朝）******************************************************




[VOICE f="Nathuko089"]
[OnName num="nathuko"]
"So, you two are together now, huh?"
[cpg cn=true]


In the hallway. As we were walking together, we ran into Natsuko.
[cpg]


We are in different classes, but we see each other often.
[cpg]


[FACE method="shake_3" pos="4/5"]
[VOICE f="Nathuko090"]
[OnName num="nathuko"]
"You jumped the gun a bit, Michika......just remember that."
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Michika166"]
[OnName num="mithika"]
"I guess you're right. Sorry."
[cpg cn=true]


Their exchange didn't seem angry. Natsuko was probably joking...
[cpg]


[FACE method="shake_4" pos="4/5"]
[VOICE f="Nathuko091"]
[OnName num="nathuko"]
"Don't apologize, that's just rubbing salt in the wound."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



And so our relationship continues.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Mei082"]
[OnName num="mei"]
"Congratulations to both of you. I'm rooting for you."
[cpg cn=true]


This time, it was Mei who approached us. We were in the same class, so it wasn't unexpected.
[cpg]


Michika seems at a loss for words and looks to me.
[cpg]


[OnName num="shoma"]
"Thanks, we'll do our best."
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Mei083"]
[OnName num="mei"]
"Wow, you two really are so cute. I'm a little jealous."
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


We head home. We'd normally part ways around here, but Michika tags along a little further.
[cpg]


;//【ＢＧ】『公園』（夜）******************************************************



We end up in the park insteady of my house.
[cpg]

Before I knew it, it was getting dark. We should probably head home......
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="sMithika014"]
[OnName num="mithika"]
"Oh no! It's already this late? Yikes..."
[cpg cn=true]


She jumps up in a hurry...
[cpg]

[FACE method="shock_4" pos="2/3"]
[VOICE f="sMithika015"]
[OnName num="mithika"]
"Ow!"
[cpg cn=true]


She winces and crouches, holding her leg.
[cpg]


[free time=1000]

[WAIT time=1000]
;//ＢＫ


[OnName num="shoma"]
"Did you twist your ankle? I think you stood up a little too suddenly."
[cpg cn=true]


;//[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMithika016"]
[OnName num="mithika"]
"I'm not...sure..."
[cpg cn=true]


[OnName num="shoma"]
"Let me take a look."
[cpg cn=true]



;//========================================
;//●ＣＧエロ（足をくじいたヒロインの足を見る主人公。主人公の姿勢が違うので元の絵から消してください）ev_16
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：公園の茂み
;//時間　：夜
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


I decided to do something a little more boyfriend-like and looked for any obvious injuries.
[cpg]

[OnName num="shoma"]
"......Well, I can't see anything wrong with your leg."
[cpg cn=true]


[VOICE f="sMithika017"]
[OnName num="mithika"]
"It's kind of embarrassing."
[cpg cn=true]


[OnName num="shoma"]
"Why?"
[cpg cn=true]


She goes quiet, blushing.
[cpg]

I decided to wrap her ankle with a bandage.
[cpg]

[VOICE f="sMithika018"]
[OnName num="mithika"]
"Why do you have that anyways?"
[cpg cn=true]


I kept it on hand just in case, but I didn't expect to ever use it.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************



[OnName num="shoma"]
"......Do you have your keys? Are you going to be able to get home all right?"
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Michika188"]
[OnName num="mithika"]
"I'll be fine, just......I mean, thanks for today ......"
[cpg cn=true]


Michika seems slightly dazed. Her face remains flushed.
[cpg]


It would be nice if we could make memories one by one like this, just the two of us ......
[cpg]


I wonder what will happen in the future. I feel like we shouldn't try to keep things secret.
[cpg]


I hope we'll be able to tell our parents someday.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



I snuck back home. I tried to make it to my room as quietly as possible, but my dad found me. I had to make up a reason why I was out so late.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="shoma"]
"...... I'm sleepy ......"
[cpg cn=true]


It was later than I'd thought. I had to get to sleep or I might not be able to get up on time.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]

I had a dream that night of Michika and I in the park.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



I awoke, slightly disappointed. What I'd give to spend more time with her, even if it was in my dreams.
[cpg]


But I guess the real thing is even better. I rushed out of the house in the hopes of meeting Michika even a moment sooner.
[cpg]


No hobbies, no special skills. My ordinary, boring life was now filled with happy, unexpected events.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』



I saw Michika on my way to school. She'd brought more stuff than usual.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika189"]
[OnName num="mithika"]
"So, I made you lunch. I know, I know. It's not very gal-like of me."
[cpg cn=true]


[OnName num="shoma"]
"Uhh, but I get the school lunch......"
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Michika190"]
[OnName num="mithika"]
"Oh don't say stuff like that, I'm already self conscious about this enough as it is."
[cpg cn=true]


Shouldn't have said that. Michika starts to pout..
[cpg]


[OnName num="shoma"]
"I mean, of course I'm happy about it. It's a little tropey, but it's still a dream come true."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika191"]
[OnName num="mithika"]
"Trope or not......Well, at least you're happy about it."
[cpg cn=true]


Michika looks away, bashfully. Seeing her like that gave me butterflies.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



Lunch was...something. It was really something.
[cpg]


It wasn't inedible, but I couldn't call it delicious, no matter how much I liked her.
[cpg]

Of course, you can't really rate something your girlfriend makes for you......
[cpg]


But it was barely straddling the line of things I'd voluntarily put in my mouth.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika192"]
[OnName num="mithika"]
".......This doesn't taste anywhere as good as it did when I tried it at home......"
[cpg cn=true]


I let out a slow sigh of relief. Michika's taste buds were normal.
[cpg]


[OnName num="shoma"]
"Well, these meatballs are pretty good."
[cpg cn=true]


I came to the sudden realization that she probably hadn't made them. Fearfully, I look over to gauge her reaction......
[cpg]

[FACE method="bow_2" pos="2/3"]
She was laughing. Relieved, I somehow managed to finish eating.
[cpg]


[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="4/5" time=800]

[VOICE f="Nathuko092"]
[OnName num="nathuko"]
"......She made you lunch? Seriously? Are we talking about the same Michika?"
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
Natsuko pops in for a moment. Why was she here? Did she drop by just to see us?
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Nathuko093"]
[OnName num="nathuko"]
"How was it? I mean, was it actually food?"
[cpg cn=true]


She came up to us just to say this? Of course it was food.
[cpg]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Michika193"]
[OnName num="mithika"]
"Oh come on, I'm not that bad. I mean, it was the first time I've ever cooked, but still."
[cpg cn=true]


[FACE method="change_2" pos="2/5"]
[FACE method="change_2" pos="4/5"]
The two start laughing.
[cpg]


It's kind of nice, this feeling. I want to spend every second I could with Michika.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



The rumors about us eventually died down. Our relationship had became common knowledge.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Michika194"]
[OnName num="mithika"]
"......It's weird, I'm only just starting to feel like we're dating."
[cpg cn=true]


[OnName num="shoma"]
"Yeah.....it's nice that people finally got used to us together."
[cpg cn=true]


I don't couldn't tell if people had just accepted us or we were acting like more a couple.
[cpg]


Either way, it reinforced the feeling that Michika and I were lovers.
[cpg]


My feelings for her weren't fleeting. If anything, they only grew stronger with each passing day.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sMithika019"]
[OnName num="mithika"]
"It's not just because they were gals, but it was like everybody I knew had a boyfriend for a long time....."
[cpg cn=true]


[OnName num="shoma"]
"Yeah, it's not that surprising to me. Gals do have that kind of image."
[cpg cn=true]


If anything, it would be weirder if they didn't.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Michika196"]
[OnName num="mithika"]
"Well, so like they all know you're my first boyfriend now..."
[cpg cn=true]


Oh, I can see why she was worried now......
[cpg]


[OnName num="shoma"]
"Is it that big of a deal? I mean, it's the truth."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Michika197"]
[OnName num="mithika"]
"Well, they sorta made fun of me for it and now there's kind of a power shift."
[cpg cn=true]


I could imagine. She'd been their top dog for some reason, but she wasn't exactly living the gal life. It might be a point of friction for some of the other gals.
[cpg]


[OnName num="shoma"]
"I can't claim to know all the intricacies of gal culture, but if it doesn't fit you anymore, you can stop whenever you want."
[cpg cn=true]


Michika stops and looks at me for a moment, then mutters "I see".
[cpg]




;//ＢＫ

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

The next morning. Michika was walking with a few gals on her way to school.
[cpg]

[FACE method="change_6" pos="2/3"]

Though she was laughing along with them, I saw them poking her a few times.
[cpg]


I thought I saw something forced about the way she was smiling.
[cpg]


[OnName num="shoma"]
"Good morning, Michika."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Michika242"]
[OnName num="mithika"]
"Oh, Shōma. Hi."
[cpg cn=true]


[OnName num="female_student_A"]
"Oh look, it's prince charming on his white steed."
[cpg cn=true]


[OnName num="female_student_B"]
"I dunno, he looks a little dull for a prince."
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]

The gals snicker. Michika laughs along with them.
[cpg]


I couldn't help but wonder if Michika was forcing herself to fit in.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



Lunch break. We choose to go to an empty classroom and talk.
[cpg]


[OnName num="shoma"]
"Michika, are you really comfortable like this? Lately you don't seem like you enjoy hanging with your gal friends as much."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika243"]
[OnName num="mithika"]
"......I'm not really sure anymore. I don't like how they're poking fun at me all of the time."
[cpg cn=true]


After a moment, she continues.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Michika244"]
[OnName num="mithika"]
"I really don't like it when they make fun of you. You're my boyfriend."
[cpg cn=true]


[OnName num="shoma"]
"......I see."
[cpg cn=true]


Maybe she never really wanted to become a gal. I wasn't sure if I was allowed to ask her...
[cpg]


No, I had to take a stand. She was important to me and I needed to know how she really felt.
[cpg]


[OnName num="shoma"]
"Michika, were you always a gal?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika245"]
[OnName num="mithika"]
"......I guess you can tell, huh? I used to be a very plain person."
[cpg cn=true]


I knew it. Somehow, I had a feeling.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Michika246"]
[OnName num="mithika"]
"At some point......I don't even remember when or why, I thought I had to change. I wanted to be popular, I wanted to be pretty."
[cpg cn=true]


[OnName num="shoma"]
"Yeah? I'm interested to see what you looked like."
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]

Michika laughs, but her expression looked somehow bitter.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika247"]
[OnName num="mithika"]
"I can't. I wore glasses and had my hair up in braid and stuff..."
[cpg cn=true]


I didn't see any problem with braids, but it was surprising to hear that she used to wear glasses.
[cpg]


[OnName num="shoma"]
"I didn't know you had bad eyesight."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Michika248"]
[OnName num="mithika"]
"I still do, I'm just wearing contacts."
[cpg cn=true]


[OnName num="shoma"]
"......No kidding?"
[cpg cn=true]


What could I say to make her feel better? There are topics that even lovers hesitate to broach. I felt this might be one of them.
[cpg]


But if I wanted to show how I really cared for her, wouldn't this be the place to step in?
[cpg]


I didn't know what to do.......It was a lot to take in.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se010"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


We head home and part halfway.
[cpg]

[OnName num="shoma"]
"......I guess I'll head home."
[cpg cn=true]


Saying goodbye to Michika never gets any easier.
[cpg]


I treasure every moment I get to spend with her, yet I still find myself wanting more.
[cpg]



;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_01_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[SE f="se011"]
;//【ＳＥ】『ドア閉まる』


[OnName num="shoma"]
"......Phew."
[cpg cn=true]


Michika. I was surprised to find out she'd never had a boyfriend, but now I understand why.
[cpg]


If we assume that she was forcing herself to fit in as a gal, it all makes sense.
[cpg]


She'd had trouble dealing with conversations about boyfriends.
[cpg]


It was easier for her to blend in before, but now that we're together, it's changed the power dynamic in her group.
[cpg]


I don't want to see her fighting a losing battle. It's hard enough watching them rib her about me all the time.
[cpg]


It's even worse when I think that she's forcing herself to act like a gal.
[cpg]


I felt like I had to do something, but all I could do was try to reassure her with my words.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



The next morning. I had trouble sleeping, worrying about Michika.
[cpg]


I didn't have the right to tell Michika to stop acting like a gal, but I didn't want her to get keep it up when it was hurting her.
[cpg]


I want her to be comfortable as she is, but how could I convey these feelings?
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』


A familiar scene...I see Michika ahead of me. She's being made fun of by other gals.
[cpg]


It wasn't a situation where I could cut in.
[cpg]


To an outsider, they looked like friends playing with each other and having a good time.
[cpg]


That's what was so insidious about it. I had a strong suspicion that Michika wanted no part of it.
[cpg]


[OnName num="female_student_A"]
"Hey Michika, does that boyfriend of yours love you properly?"
[cpg cn=true]


[OnName num="female_student_B"]
"You'll just get frustrated with a meek guy like that."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Michika274"]
[OnName num="mithika"]
"He's not that bad......"
[cpg cn=true]


[OnName num="female_student_A"]
"I can give you some tips if you like. Tell your big sister what's bothering you."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Michika275"]
[OnName num="mithika"]
"We're the same age."
[cpg cn=true]


[OnName num="female_student_B"]
"Maybe, but like, there's a big difference in mental age, right? Ahahaha!"
[cpg cn=true]


Maybe they hadn't yet crossed the line to bullying yet.
[cpg]


I don't know what to do ......
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Michika276"]
[OnName num="mithika"]
"......What's wrong? You look serious."
[cpg cn=true]


[OnName num="shoma"]
"Really? Huh......"
[cpg cn=true]


I guess I was worrying too much. Even if I wasn't, I didn't want to add to her pile of things to worry about.
[cpg]


[OnName num="shoma"]
"Hey, Michika? Do you enjoy hanging out with the gals?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika277"]
[OnName num="mithika"]
"It's fun. They're easy-going and silly. I guess that makes me a good fit."
[cpg cn=true]


[OnName num="shoma"]
"Are you pushing yourself at all?"
[cpg cn=true]


Hearing my words, Michika flashed a tired smile.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Michika278"]
[OnName num="mithika"]
"I don't even know anymore. I can't remember what I used to be like or what I wanted to do."
[cpg cn=true]


[OnName num="shoma"]
"......That must be hard."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]

It's not hard, she says and smiles weakly.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（昼）******************************************************



The hallway at lunchtime. Even though there are a lot of gals, there are also a few plain kids in our class.
[cpg]


I happened to overhear them talking as I was passing by.
[cpg]


[OnName num="female_student_A"]
"Ms. Arishiro doesn't seem like much of a gal anymore......"
[cpg cn=true]


[OnName num="female_student_B"]
"Yeah, maybe she's more like us than we thought."
[cpg cn=true]


I guess it has to do with the fact that she started to go out with me.
[cpg]


The girls were so engrossed in their conversation that they didn't seem to notice me.
[cpg]


It wasn't like they were trying to make sure I could hear them.
[cpg]


I looked down and walk around thinking. Then, I ran into another person.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mei084"]
[OnName num="mei"]
"What's wrong? You look so gloomy."
[cpg cn=true]


[OnName num="shoma"]
"Nothing, I'm fine......."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Mei085"]
[OnName num="mei"]
"Chin up man, it's your job to make Michika-chan happy. You're her boyfriend, aren't you?"
[cpg cn=true]


You don't have to tell me, I know.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]


And after school.
[cpg]

;//【ＢＧ】『学園教室』（夕方）******************************************************


In the middle of a conversation with her about something else.
[cpg]


[OnName num="shoma"]
"That sounds good, let's do that."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sMithika020"]
[OnName num="mithika"]
"......Have you got something else on your mind?"
[cpg cn=true]


Of course I do. I can't stop worrying that Michika is forcing herself to act like a gal.
[cpg]


But I'm not sure if I should tell her. I can't put it into words because I'm not sure.
[cpg]


[OnName num="shoma"]
"Not really. I'm only thinking about you, Michika."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Michika282"]
[OnName num="mithika"]
"Then are you thinking about something else about me?"
[cpg cn=true]


She was sharp. I couldn't beat around the bush any longer.
[cpg]


[OnName num="shoma"]
"You know, Michika, I didn't fall in love with you because you're a gal."
[cpg cn=true]


[OnName num="shoma"]
"So if you get tired of being a gal, you can always stop."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika283"]
[OnName num="mithika"]
"......Is that what you were thinking about? I get it, but it's harder than you think."
[cpg cn=true]


So she wants to quit, but can't.
[cpg]


[OnName num="shoma"]
"I just don't like seeing you having such a hard time. It's easier to pretend to be normal than it is to stand out."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

Michika's usual, light hearted expression turns serious. I knew what I said had hit home.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Michika284"]
[OnName num="mithika"]
"......I'll think about it."
[cpg cn=true]


She only answered me after thinking about it for a bit.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se010"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



We didn't talk much on our way home. Michika seemed deep in thought.
[cpg]


[OnName num="shoma"]
"You look like you're planning something."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika303"]
[OnName num="mithika"]
"Kinda. You'll see."
[cpg cn=true]


Judging from her expression, she was planning something big.
[cpg]


That said, I don't know everything about Michika either …… In fact, most of the time I don't.
[cpg]


[OnName num="shoma"]
"Well this is me. See you tomorrow?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Michika304"]
[OnName num="mithika"]
"Yeah, see you tomorrow. Be prepared."
[cpg cn=true]


It's hard to prepare yourself when you don't know what's coming. If it wasn't a big deal, she should just tell me.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[SE f="se004"]
;//【ＳＥ】『ベッドに倒れこむ』



I fall back on the bed and start thinking.
[cpg]


What was she up to? I knew it wasn't like she'd gotten me a present or anything.
[cpg]


But if she did, it was kind of cute how determined she looked.
[cpg]


I guess there wasn't any point in thinking about it.
[cpg]


[OnName num="shoma's_mother"]
"Shōma, dinner!"
[cpg cn=true]


[OnName num="shoma"]
"Okay, I'll be right there."
[cpg cn=true]


Let's just eat dinner. My head was full with thoughts about Michika.
[cpg]


[SE f="se023"]
;//【ＳＥ】『家の廊下歩く』

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


A little past dinner time, it was time to relax as a family.
[cpg]


The TV program that was on at the time was a kind of program that documented the reality of today's youth.
[cpg]


The close-ups were all about yankees and gals.
[cpg]


There were plenty of kids in other, less flashy cliques. I guess the further away you stayed from the mainstream, the harder it was to make friends.
[cpg]


Those kind of people needed support. From friends, family, whatever they could get. I wonder if I could be Michika's support.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


The next morning. I walk along my usual route to school, but Michika is nowhere to be found.
[cpg]


It wasn't that unusual. We usually left home at different times.
[cpg]


There wasn't any need for us to meet up somewhere along the way. If anything, that might be going too far.
[cpg]


It seems that Michika had arrived at school today early.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/5" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（朝）******************************************************


[FACE method="shock_3" pos="2/5"]
[VOICE f="Nathuko094"]
[OnName num="nathuko"]
"Shōma! What did you do to Michika?"
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Mei086"]
[OnName num="mei"]
"Wow, so that's the power of love."
[cpg cn=true]


They practically ran up to me. I had no idea what they were talking about.
[cpg]


[OnName num="shoma"]
"Sorry, what are you guys talking about?"
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Nathuko095"]
[OnName num="nathuko"]
"I don't have the words to explain it. Just get in there and see for yourself."
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I peeked into the classroom…..
[cpg]


She was right, there weren't any words to explain what was going on.
[cpg]



;//========================================
;//●ＣＧ非エロ（髪を黒髪に戻して、地味な三つ編みと眼鏡で通学してくるヒロイン。微笑んでいる）ev_21
;//人物１：ヒロイン１
;//服装１：制服
;//場所　：学園教室
;//時間　：朝
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_se"]
;**【ＣＧ】 ev_21_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="Michika305"]
[OnName num="mithika"]
"Good morning, Shōma. Oh, I knew you'd make that kind of face."
[cpg cn=true]


[OnName num="shoma"]
"......Michika? New look?"
[cpg cn=true]



[VOICE f="Michika306"]
[OnName num="mithika"]
"Technically, no. Well, just give me some time, I can't change how I talk so suddenly."
[cpg cn=true]


Right. There wasn't anything wrong. She'd just gone back to normal.
[cpg]


To how she was before. All this time, she was trying to be something she wasn't.
[cpg]



[VOICE f="Michika307"]
[OnName num="mithika"]
"I like you. I like you and I like myself now."
[cpg cn=true]


......I guess I had become her support without even realizing it.
[cpg]




;//ＢＫ

[SCENE id=16]

[jump storage="epend.ks" target="*start"]


;//ＥＮＤ：ヒロイン１純情ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

