
*start


;#################################################
*Ep004|Rumors about Mei
;#################################################

[SCENE id=4]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



The morning comes. I get dressed and ready to head to school.
[cpg]


The number of gals at school has made me somehow more concerned about my appearance than usual.
[cpg]


Bed hair alone is enough to make me a topic of conversation for the gals.
[cpg]


Even the girls who are not gal may not say it out loud, but they may be thinking something about it.
[cpg]




[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』



I walk through the city on the way to the school. I've gotten used to it.
[cpg]


I've gotten used to adapting to new environments.
[cpg]


It's sad to say, but I didn't have much of a choice. I don't know when I'll have to say goodbye to Michika and Mei.
[cpg]


I think that if you settle down in one place, you will naturally acquire hobbies and special skills.
[cpg]


If you know you're going to see your classmates for years, you might even join a club.
[cpg]


Then it could become a skill, or even a hobby.
[cpg]


I wonder if I would have become sporty by now if I hadn't kept transferring schools.
[cpg]


Maybe I'd have learned Shōgi or Go? Perhaps even art?
[cpg]


......Thinking about it now, I've either wasted or lost a lot of time already.
[cpg]


Even still I don't want to join any club activities knowing that I'll probably have to move again.
[cpg]


Sure, I get to meet all sorts of people from all over.
[cpg]


Maybe it's fate that I ended up here in this school overrun with gals.
[cpg]


That put me into a positive mood.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（朝）******************************************************

[SE f="se017" loop=true]
;//【ＳＥ】『学園の喧噪』

Then in the hallway, a male friend approaches me.
[cpg]


[OnName num="male_student"]
"Is it true that you've been hanging out with the gals?"
[cpg cn=true]


[OnName num="shoma"]
"Where'd you hear that?"
[cpg cn=true]


[OnName num="male_student"]
"The walls have ears. So? Spill."
[cpg cn=true]


[OnName num="shoma"]
"I wouldn't call it hanging out, I'm just getting to know them ......."
[cpg cn=true]


[OnName num="male_student"]
"Well, whatever you do, don't go for Ms. Takahane. She'll suck you dry. In a financial sense."
[cpg cn=true]


Well that's...rude. He went out of his way to tell me this?
[cpg]


[OnName num="shoma"]
"Hey man, don't say that kind of stuff about her. I don't think she's a bad girl."
[cpg cn=true]


[OnName num="male_student"]
"Damn, did she get her claws into you already......?"
[cpg cn=true]


[OnName num="shoma"]
"I didn't say that."
[cpg cn=true]



;//==============================
;//ここから暫く、芽衣が純情の場合のみ発生するイベント

[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*cha03_gal01"]
[endif]



;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]



After the conversation my focus naturally went to Mei.
[cpg]


Lunch break. After having lunch at the school cafeteria.
[cpg]



;//========================================
;//●ＣＧ非エロ（椅子に座っているヒロインに話しかける主人公。見上げてきょとんとした後、笑うヒロイン）ev_07
;//人物１：ヒロイン３
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="Mei008"]
[OnName num="mei"]
"What's wrong? You seem intense today."
[cpg cn=true]


[OnName num="shoma"]
"Really? Well, it's not intentional..."
[cpg cn=true]


I decided to talk to Mei.
[cpg]


She certainly looked like a gal. Maybe some of the rumors were true.
[cpg]


[OnName num="shoma"]
"Hey...look, I heard some weird rumors about you."
[cpg cn=true]



[VOICE f="Mei009"]
[OnName num="mei"]
"Rumors about me? Do tell."
[cpg cn=true]


It didn't seem like she was aware of the rumors or their contents.
[cpg]


Sure, people talk, but I felt bad for her all the same.
[cpg]


[OnName num="shoma"]
"I'm going to be straightforward. There are some bad rumors about you."
[cpg cn=true]


[OnName num="shoma"]
"I don't want to go into too much detail, but they say you flirt with men to get them to buy you things."
[cpg cn=true]


She seemed puzzled. Then she clapped her hands and laughed.
[cpg]


[VOICE f="Mei011"]
[OnName num="mei"]
"What's that? That's interesting."
[cpg cn=true]


I knew it. Somehow I had a feeling it wasn't true from her reaction.
[cpg]


But if that was the case, it would mean that there were rumors about things that had no basis.
[cpg]


[OnName num="shoma"]
"Did you know about the rumors?"
[cpg cn=true]


Mei shook her head. She had an easy-going look on her face.
[cpg]


[OnName num="shoma"]
"You don't care about it ......?"
[cpg cn=true]



[VOICE f="Mei012"]
[OnName num="mei"]
"I don't care. I'm a little weird, so I get a lot of comments."
[cpg cn=true]


It's much weirder that she calls herself weird.
[cpg]


I guess her being a spacecase gives her some modicum of insulation against the malice from others.
[cpg]


I found it honestly impressive how casual she seemed about it. Either that or she didn't understand what I'd said.
[cpg]


No, that was unlikely. I felt like her having a strong mentality was closer to the truth.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』



Then, after school. I was walking around, deep in thought.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michika053"]
[OnName num="mithika"]
"...... What happened to you?"
[cpg cn=true]


[OnName num="shoma"]
"Oh, no ...... I was just thinking."
[cpg cn=true]


I thought about how much I should say, and then decided to tell her everything.
[cpg]


Michika would be familiar with the rumors among the gals.
[cpg]


So I told her about Mei.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Michika054"]
[OnName num="mithika"]
"Oh, that. I feel bad for her."
[cpg cn=true]


[OnName num="shoma"]
"Well …… Can't you stop the rumors?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Michika055"]
[OnName num="mithika"]
"I think it's the boys who are spreading the rumors. We don't really tease or bully each other."
[cpg cn=true]


I didn't know that. So, what gives the boys the right to spread such rumors?
[cpg]


Did someone have some kind of grudge against her?
[cpg]


I couldn't understand the whole situation and decided to go home ......
[cpg]

[jump target="*cha03_gal01_end"]

;//ここまで、芽衣が純情の場合のみ発生するイベント
;//==============================



;//==============================
;//ここから暫く、芽衣がギャルの場合のみ発生するイベント

*cha03_gal01|芽衣の噂



[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Perhaps that conversation changed fate somehow.
[cpg]


After school. I ended up seeing something I didn't really want to see.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』



[OnName num="shoma"]
"......?"
[cpg cn=true]


I was lost. I had reached the edge of the school campus in my confusion.
[cpg]


From somewhere, I hear a conversation between a man and a woman. One of them sounded like school faculty.
[cpg]


[OnName num="male_teacher"]
"Oh Mei, you drive a hard bargain……When you ask like that, I can't help but want to buy it for you."
[cpg cn=true]


[VOICE f="Mei013"]
[OnName num="unknown"]
"Really? I love you so much."
[cpg cn=true]


I headed towards the direction of the voice when I stumbled upon a scene that could land a lot of people in a lot of trouble.
[cpg]



;//========================================
;//●ＣＧエロ（前屈みでモブ男に迫るヒロイン。元の絵にある背後の男は消してください）ev_08
;//人物１：ヒロイン３
;//服装１：制服
;//人物２：モブ男
;//服装２：着衣
;//場所　：学園教室
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]
;//移植のためシーンをカットしています

[VOICE f="sMei001"]
[OnName num="mei"]
"I have to pay you back then, don't I?"
[cpg cn=true]


[OnName num="male_teacher"]
"Oh come on, just you being her with me like this is reward enough."
[cpg cn=true]


[VOICE f="sMei002"]
[OnName num="mei"]
"Well someone's feeling generous today ……huh?"
[cpg cn=true]


[OnName num="shoma"]
" ! "
[cpg cn=true]


She must have spotted me.
[cpg]

But I pretend that I don't see them……
[cpg]



[window target=false]
[free time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



I tried to look casual as I walked away.
[cpg]

I walk slowly down the hallway, trying to figure out what I'd do with this information......when a voice calls out to me from behind.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mei028"]
[OnName num="mei"]
"It's not polite to peep, Shōma."
[cpg cn=true]


[OnName num="shoma"]
"......I guess you saw me."
[cpg cn=true]



;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_sa"]
;//[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



It would be bad if someone heard us. We enter the classroom.
[cpg]


And I was going to have her do something that I didn't want anyone to see.
[cpg]


[OnName num="shoma"]
"......A teacher of all things? It would be problematic if anybody found out."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mei029"]
[OnName num="mei"]
"You're right......I might even have to leave school. So, what will it take to keep your silence?"
[cpg cn=true]


Mei asks me as if it were not her problem.
[cpg]


[OnName num="shoma"]
"I wonder."
[cpg cn=true]


I pretended to think about it. Then Mei said,
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMei003"]
[OnName num="mei"]
"Sure, I'll kiss you."
[cpg cn=true]


She was quick on the uptake. Too quick.
[cpg]

;//========================================
;//●ＣＧエロ（主人公からのキスを待つヒロイン）ev_09
;//人物１：ヒロイン３
;//服装１：裸
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sMei004"]
[OnName num="mei"]
"Come on."
[cpg cn=true]


Mei closes her eyes.
[cpg]

Something about her captivated me. She looked like she'd had a lot of experience.
[cpg]

She was different from Michika and Natsuko. Right now, she seemed like the most gal-like of them all.
[cpg]

If the devil existed, it would have a smile as pretty as hers.
[cpg]

;//移植のためシーンをカットしています


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


[VOICE f="sMei005"]
[OnName num="mei"]
"Mmh ......"
[cpg cn=true]


The moment our lips touched, I immediately felt like she'd turned the tables on me.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se010"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



Mei Takaha. She was an amazing girl.
[cpg]


I can't believe she hid her true nature like that. They say people are not what they seem like, but then again......
[cpg]


;//ここまで、芽衣がギャルの場合のみ発生するイベント
;//==============================
*cha03_gal01_end|芽衣の噂




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



After all that, it was evening.
[cpg]


I ran into Natsuko on my way home.
[cpg]


But she didn't notice me.
[cpg]


I thought I saw her figure from behind and decided to follow her a bit......
[cpg]


She checks her surroundings before entering a karaoke box alone.
[cpg]


She doesn't want anyone to find out. I know the feeling.
[cpg]


So Natsuko likes to go to Karaoke alone. I imagined what her favorite songs were as I headed home.
[cpg]



[SE f="se011"]
;//【ＳＥ】【ドア閉まる】


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



But still, karaoke alone? I guess it's hard to invite people when you have a reputation like hers.
[cpg]


[OnName num="shoma"]
"...... Hmmm."
[cpg cn=true]


I guess gals were harder to understand than I thought. At least, the ones I knew didn't seem to fit into any single stereotype.
[cpg]


I had contact with Mei today, but I don't think I truly understand her.
[cpg]


It's the same with Michika. There is no way to know what her true feelings are.
[cpg]


I thought gals were easier to understand than regular girls, but so far, it's the other way around.
[cpg]


I feel like they have two sides. Although this may be just my personal image of them ......
[cpg]


[jump storage="ep005.ks" target="*start"]

;////////////////////////////////////////////////////////////////////////

