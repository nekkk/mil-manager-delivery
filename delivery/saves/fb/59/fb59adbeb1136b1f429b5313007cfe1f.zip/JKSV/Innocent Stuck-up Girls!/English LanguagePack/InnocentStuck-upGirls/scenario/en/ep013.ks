
*start


;//==============================
;//全てのヒロインが純情である場合

*end3_alvar|ぼんやりしている芽衣



Mei. I love her even though I don't know what she's thinking......
[cpg]


For example, where did the rumors about her come from?
[cpg]

But whatever kind of person she is, I love her.
[cpg]


So I decided to take the first step.
[cpg]

;#################################################
*Ep013|Mei in a daze
;#################################################

[SCENE id=13]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************



[FACE method="bow_7" pos="2/3"]
[VOICE f="Mei135"]
[OnName num="mei"]
"What's up? You wanted to see me?"
[cpg cn=true]


[OnName num="shoma"]
"Yeah, it's......umm. …."
[cpg cn=true]


This wasn't the right time to confess. There's no romantic mood or vibe.
[cpg]


I decided to set a time and place.
[cpg]


[OnName num="shoma"]
"Can we be alone in this classroom after school?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei136"]
[OnName num="mei"]
"......Sure. I wonder what you have planned."
[cpg cn=true]


Mei must have noticed me. She seemed surprisingly calm
[cpg]


But if I actually confessed, would she be surprised? I could only hope......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


After school, Mei and I were alone in the classroom. We stood next to each other as we looked out the window.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei137"]
[OnName num="mei"]
"It's strange to be in a classroom after school's out. It's usually full of people, but now there's nobody here."
[cpg cn=true]


[OnName num="shoma"]
"We're here......together.."
[cpg cn=true]


I'd hoped I'd manage to say something romantic, but I was so anxious that I started to panic.
[cpg]


[OnName num="shoma"]
"Mei......there's someone I like."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Mei138"]
[OnName num="mei"]
"Are you talking about me?"
[cpg cn=true]


[OnName num="shoma"]
"Um? Uhh......?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Mei139"]
[OnName num="mei"]
"It was so obvious, but it made me happy."
[cpg cn=true]


I guess I'd spent more time staring at her than I'd thought.
[cpg]


[OnName num="shoma"]
"I guess...there's nothing more for me to say......"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Mei140"]
[OnName num="mei"]
"Oh come on. If you're going to confess, do it properly!"
[cpg cn=true]


......Right, of course. I was more nervous than I'd thought.
[cpg]


It's like she sees right through me and it makes me nervous.
[cpg]


[OnName num="shoma"]
"I like you. Go out with me, Mei."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei141"]
[OnName num="mei"]
"Sure."
[cpg cn=true]


That was easy. Maybe Mei liked me too?
[cpg]


[OnName num="shoma"]
"Are you sure you wanna be with...... me? What do you like about me?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Mei142"]
[OnName num="mei"]
"Hmm. Like you pretend to be cold but you're actually really kind."
[cpg cn=true]


It was embarrassing to hear her say it, but that was my fault wasn't it?
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="sMei018"]
[OnName num="mei"]
"…...What do you think lovers do?"
[cpg cn=true]



;//移植のためシーンをカットしています

;//========================================
;//●ＣＧエロ（ヒロインが主人公に迫る）ev_41
;//人物１：ヒロイン３
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_40_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]


She steps closer.
[cpg]

My pulse quickens as I wait to see what she'll do to me.
[cpg]

[VOICE f="sMei019"]
[OnName num="mei"]
"When you act that nervous, I get a little nervous too."
[cpg cn=true]


My heart pounds in my chest.
[cpg]

She gets even closer.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************

After a brief exchange of words of love ......
[cpg]

I'd finally come back to my sense. We were still at school.
[cpg]

I choke on my words, and nothing happens for a while.
[cpg]


[OnName num="shoma"]
"We should probably head home......."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei182"]
[OnName num="mei"]
"Let's go home together. We can walk together part of the way."
[cpg cn=true]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
Mei clings onto my arm. I feel the warmth of her body ......
[cpg]


[OnName num="shoma"]
"It's kind of hard to walk like this..."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mei183"]
[OnName num="mei"]
"You'll be fine, come on."
[cpg cn=true]


Sure, maybe I was exaggerating a bit, but walking like this was practically advertising that we were dating.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



We were seen by several students before we left the school grounds.
[cpg]


There were whispers about us, but I guess I shouldn't let it bother me. We're in a relationship now.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



[FACE method="bow_6" pos="2/3"]
[VOICE f="Mei184"]
[OnName num="mei"]
"Ehehe. Finally, a real boyfriend."
[cpg cn=true]


The way she said "real" stuck with me, but I didn't say anything. Mei walked together until our paths home diverged.
[cpg]


She lets go of me at the corner.
[cpg]


[OnName num="shoma"]
"I'm this way, see you tomorrow?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei185"]
[OnName num="mei"]
"Yeah, see you tomorrow."
[cpg cn=true]


Her warmth gradually fades from my arm. I felt a little lonely.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



A girlfriend. I didn't expect it to happen so quickly.
[cpg]


But there was something that bothered me a little. It seems like she is used to being close to guys.
[cpg]


And she also said I was her "real boyfriend". I wonder if this has anything to do with the rumors that she is seeing other men in exchange for things.
[cpg]

I'm not quite sure what's going on.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[free time=1000]

[SE f="se005"]
;//【ＳＥ】『鳥の鳴き声』

[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]



Then morning comes, but I've yet to find an answer and lost a lot of sleep.
[cpg]


Lethargic, I trudged out of the house.
[cpg]


I must have looked awful, because my parents seemed worried about me in the morning.
[cpg]


If they knew the truth, they might make a fuss.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[OnName num="shoma"]
"......?"
[cpg cn=true]


On the way to school I saw Michika and Natsuko talking. It was a rare sight to see them together.
[cpg]


That's when I remembered that they'd formed a little group because they didn't have boyfriends.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Michika464"]
[OnName num="mithika"]
"I feel really bad, but……what can we do?"
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Nathuko436"]
[OnName num="nathuko"]
"There's nothing we can do, right? I mean, we can't just hand over some cash."
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Michika465"]
[OnName num="mithika"]
"I know, right? Maybe we can buy something? But that's about it."
[cpg cn=true]


I don't know who they're talking about, but they seem to be taking pity on someone.
[cpg]


I didn't really give it much thought and kept my distance as I headed to school.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



Lunch break, after the morning classes.
[cpg]


[OnName num="shoma"]
"Mei, let's go home together today."
[cpg cn=true]


There were probably better ways to invite her, but nothing came to mind.
[cpg]


I was too tired to come up with something suave.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mei186"]
[OnName num="mei"]
"I'm sorry. I have to hurry home today, I have a part-time job."
[cpg cn=true]


There was something odd about the way she said it. It was unusual for a laid-back girl like Mei to leave in such a hurry......
[cpg]


Honestly, I couldn't imagine her working. I wonder what kind of part-time job she has?
[cpg]


[OnName num="shoma"]
"Oh, alright…..."
[cpg cn=true]


I wanted to know more, but I didn't have the courage to ask.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Mei187"]
[OnName num="mei"]
"I bet you're thinking that I'm too slow to have a job."
[cpg cn=true]


[OnName num="shoma"]
"N-no way, I'd never think such a thing."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]

I did want to know why she was working a part-time job in the first place?
[cpg]


I guess gals nowadays have a lot of stuff they want but......
[cpg]


I wonder if her allowance wasn't enough.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



Mei had left right when the bell rang. Since I no longer had any plans for the evening, I took my time.
[cpg]


By coincidence, I met Natsuko on my way home.
[cpg]


[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Nathuko437"]
[OnName num="nathuko"]
"Yo, you heading home?"
[cpg cn=true]


[OnName num="shoma"]
"Yeah……Hey, can I ask you something?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Nathuko438"]
[OnName num="nathuko"]
"What's up?"
[cpg cn=true]


[OnName num="shoma"]
"Did you know that Mei was working part-time? I was wondering if you knew anything about it."
[cpg cn=true]


Natsuko went silent for a moment, clearly thinking about something.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Nathuko439"]
[OnName num="nathuko"]
"I think it would be better if you asked her yourself."
[cpg cn=true]


Natsuko was right, it wasn't her place to tell me.
[cpg]


But it seemed that Natsuko knew the reason. Was I the only one who didn't?
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



The next morning, at school. I decided to ask Mei what was going on.
[cpg]


If we were going to be in a relationship, I wanted to know what was happening in her life.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************



[OnName num="shoma"]
"Good morning, Mei."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mei188"]
[OnName num="mei"]
"Morning, heehee."
[cpg cn=true]


Mei looks happy. I felt a little better.
[cpg]


Now wasn't the time to ask. I had to get her somewhere alone.
[cpg]


If it was a sensitive topic, we should go somewhere that people couldn't overhear us.
[cpg]


[OnName num="shoma"]
"Hey, do you want to come over to my place this weekend?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Mei189"]
[OnName num="mei"]
"Hmm, okay. It makes me a little nervous though."
[cpg cn=true]


She quickly accepted. And we've made a promise......
[cpg]


[OnName num="shoma"]
"I'll see you later."
[cpg cn=true]


What kind of part-time job does Mei have?
[cpg]


I'm a little afraid to ask, given the rumors about her.
[cpg]


;//ＢＫ


But what choice did I have? Not knowing was worse.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]

The weekend comes and we meet up, then head to my house.
[cpg]

[SE f="se010"]
;//【ＳＥ】『歩く』

[window target=false]
[FO pos="4/7" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************




[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei190"]
[OnName num="mei"]
"What's your house like, Shōma?"
[cpg cn=true]


[OnName num="shoma"]
"It's not really that impressive. It's pretty normal, I think."
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Mei191"]
[OnName num="mei"]
"Aww don't ruin the surprise."
[cpg cn=true]


She was right, I was being negative again.
[cpg]


As we walked, I decided to ask about her work.
[cpg]


[OnName num="shoma"]
"So, what kind of part-time job do you have?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Mei192"]
[OnName num="mei"]
"Hmmm….I don't think I should tell you......."
[cpg cn=true]


Now I'm even more curious. Is it a job that she can't tell me about?
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Mei193"]
[OnName num="mei"]
"If I told you the truth, you might not like me anymore. No matter how kind you are."
[cpg cn=true]


[OnName num="shoma"]
"I promise I won't. I won't be surprised by anything you say."
[cpg cn=true]


Mei ponders for a moment, then begins to explain.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMei020"]
[OnName num="mei"]
"Do you know what a concept café is?"
[cpg cn=true]


[OnName num="shoma"]
"Yeah, I've heard of them……."
[cpg cn=true]


Now it made sense.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sMei021"]
[OnName num="mei"]
"I'm too absent minded to continue a regular part-time job."
[cpg cn=true]


I felt my stomach drop. Was this what Mei was doing?
[cpg]


[OnName num="shoma"]
"Don't you hate that job?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="sMei022"]
[OnName num="mei"]
"I don't like it, but I have to do it. I don't know any other way to make money."
[cpg cn=true]


If I told her I didn't want her to do it, would she stop? She probably won't.
[cpg]


There must be a reason why she has to work…at a place like that.
[cpg]


In the end, I wasn't able to ask why she was working in the first place.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se011"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『街』（夕方）******************************************************


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei222"]
[OnName num="mei"]
"I'll see you at school."
[cpg cn=true]


[OnName num="shoma"]
"Yeah. See you……"
[cpg cn=true]


Mei and I said our goodbyes. I wish I had the courage to ask her.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』



On Monday, I ran into Mei on our way to school.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mei223"]
[OnName num="mei"]
"Good morning, Shōma."
[cpg cn=true]


She jogged slowly to catch up to me from behind.
[cpg]


[OnName num="shoma"]
"Good morning. I had fun the other day."
[cpg cn=true]


[FACE method="shock_7" pos="2/3"]
[VOICE f="Mei224"]
[OnName num="mei"]
"Nooo, don't remind me! I was trying to forget."
[cpg cn=true]


She is cute when she is embarrassed.
[cpg]


Was someone else touching her when I wasn't around?
[cpg]


......I couldn't stand the thought. I wasn't courageous by any means, but this feeling of resentment kept growing and growing inside of me.
[cpg]


[OnName num="shoma"]
"Mei, why do you have a part-time job? Is there something you want?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mei225"]
[OnName num="mei"]
"Umm……If I tell you, you'll probably feel really bad."
[cpg cn=true]


[OnName num="shoma"]
"Don't worry about me. I promise, no matter what you say, it won't change how I feel about you."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mei226"]
[OnName num="mei"]
"If you're sure……"
[cpg cn=true]


It wasn't what I was expecting.
[cpg]


Apparently her father hardly worked and it was putting a serious strain on her family's finances.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Mei227"]
[OnName num="mei"]
"You know, my dad always says he's going to be a writer."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Mei228"]
[OnName num="mei"]
"That's why my mom and I have work instead."
[cpg cn=true]


[OnName num="shoma"]
"…… Is that why you chose that job?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Mei229"]
[OnName num="mei"]
"I'm too slow to work at a normal part-time job."
[cpg cn=true]


[OnName num="shoma"]
"Isn't there anything else you could do……?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Mei230"]
[OnName num="mei"]
"……Well, the pay is a lot better than the other options."
[cpg cn=true]


I could hardly believe it. Her father was the cause of all her suffering? Was she suffering?
[cpg]


Either way, I felt anger welling up inside of me. I couldn't forgive her father.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



During lunch break. I questioned Mei.
[cpg]


[OnName num="shoma"]
"Is there a way to quit your job......?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="sMei023"]
[OnName num="mei"]
"You don't have to worry that much."
[cpg cn=true]


It was true, this was her problem, not mine. It wasn't my place to say anything.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


;//移植のためシーンをカットしています


In the classroom after school.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


[OnName num="shoma"]
"I'm going to start a part-time job too.......Maybe I can help you with your expenses."
[cpg cn=true]



[FACE method="shock_5" pos="2/3"]
[VOICE f="Mei249"]
[OnName num="mei"]
"I didn't ask you to do that! Why are you saying this all of a sudden..."
[cpg cn=true]


[OnName num="shoma"]
"A first, I thought about confronting your father. But I don't have the right to criticize him because I'm not family."
[cpg cn=true]


[OnName num="shoma"]
"Honestly I don't even have the courage to start working either, but I've made up my mind."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mei250"]
[OnName num="mei"]
"I don't want to drag you into this......"
[cpg cn=true]


She doesn't seem to understand. She wasn't dragging me into anything.
[cpg]


[OnName num="shoma"]
"It's normal to want to help someone you love. It's not about getting dragged in or anything like that."
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Mei251"]
[OnName num="mei"]
"......Shōma......"
[cpg cn=true]


Looking closely, I can see that Mei's clothes showed signs of being repaired multiple times.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



From that day on, I spent most of my free time working part-time at a convenience store.
[cpg]


Balancing my academics and work was harder than I thought it would be.
[cpg]


I wasn't working for myself. What I earned ended up going to Mei's family…or her worthless father.
[cpg]


Even still, I was determined to support Mei even if it meant losing sleep.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



I wasn't very sociable to begin with and the part-time job itself was hard.
[cpg]


But the moment I received my first paycheck, I knew I finally had a way to help Mei......
[cpg]


It was like a fog was lifted and I could finally see clearly.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[VOICE f="Michika466"]
[OnName num="mithika"]
"You seriously working part-time for someone else? I would never do that."
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Nathuko440"]
[OnName num="nathuko"]
"Well, to each their own. It's probably got to do with his pride."
[cpg cn=true]


I was talking with Michika and Natsuko. It was a rare combination.
[cpg]


Mei was with us, but had stepped out to use the restroom.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Michika467"]
[OnName num="mithika"]
"But you've become so manly. No wonder Mei fell in love with you."
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Nathuko441"]
[OnName num="nathuko"]
"Well, they were technically dating before all of that, so...."
[cpg cn=true]


Let them talk. I was satisfied with my situation.
[cpg]

[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p2_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[VOICE f="Mei252"]
[OnName num="mei"]
"I'm back. What were you talking about?"
[cpg cn=true]


[FACE method="bow_2" pos="1/3"]
[VOICE f="Michika468"]
[OnName num="mithika"]
"We were talking about how we're jealous you found such a great boyfriend."
[cpg cn=true]

[FACE method="bow_2" pos="3/3"]

Mei puffed out her chest in pride. I felt validated.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************



[FACE method="bow_1" pos="2/3"]
[VOICE f="Mei253"]
[OnName num="mei"]
"Want to come over today......?"
[cpg cn=true]


After school, on our way back, Mei invited me to her house.
[cpg]


[OnName num="shoma"]
"Hm. Am I going to run into your father?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei254"]
[OnName num="mei"]
"Don't worry. He's out today."
[cpg cn=true]


That was a relief......If I met him, I wasn't sure I'd be able to hold myself back.
[cpg]


Mei quit her part-time job at the concept café.
[cpg]


She switched to a more normal part-time job. Hopefully one day she won't need to work part-time anymore.
[cpg]


I had decided to get a job as soon as I graduated.
[cpg]

;//移植のためシーンをカットしています



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


We flirt with each other for a bit......
[cpg]


;//移植のためシーンをカットしています


[SE f="se011"]
;//【ＳＥ】『ドア開く』


[FACE method="change_5" pos="2/3"]


I heard the front door open.
[cpg]


[OnName num="mei's_father"]
"I'm home......Is someone here?"
[cpg cn=true]


Uh oh. Looks like I was going to get my chance to 'convince' her father to start working again.
[cpg]


Maybe we could settle this with words. At the very least, I had to tell him that I was going to marry Mei.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Mei293"]
[OnName num="mei"]
"......What should we do? My dad's home."
[cpg cn=true]


[OnName num="shoma"]
"It'll be fine. I think I can take him."
[cpg cn=true]


I wasn't confident, but Mei seemed happy I'd said it.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Mei294"]
[OnName num="mei"]
"I think I'm falling in love with you all over again......"
[cpg cn=true]



[SCENE id=22]

[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン３純情ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

