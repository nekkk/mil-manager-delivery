
*start|A school with many gals

;//ギャル処女ビッチもの　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//美智佳　私服　制服 ev18前に裸有り(画像無)
;//夏子　　私服　制服 ev27前に裸有り(画像無)
;//芽衣　　私服　制服

;//今まで立ち絵に「裸」が含まれていましたが
;//使用頻度がやや少ないのでヒロインが裸の部分は立ち絵無しで進めてください
;//以下音声なし
;//翔馬 男性教師 女子学生Ａ 女子学生Ｂ 男子学生Ａ
;//男子学生Ｂ 男子学生 翔馬の母 女子学生 陽香 芽衣の父

;//一旦台本用で完成させるため、Ｈシーンをやや短く書いております
;//通常5KB程度であるのを、ev_06から4KB程度にしています
;//ev_35からさらに短く3KB程度にしています


;//仮時追加文章	に注意
;//仮時修正文章



;////////////////////////////////////////////////////////////////////////


;#################################################
*Ep000|ギャルの多い学園
;#################################################

[SCENE id=0]


[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]

The first day after transferring to a new school.
[cpg]


It seems most of my classmates had already formed groups so I stood out.
[cpg]


But that didn't bother me anymore.
[cpg]


So I stood out, so what? I was used to it.
[cpg]


My parents moved often, each time saying that this would be the last time, but that was unlikely.
[cpg]


[window target=false]
[free time=1000]
[WAIT time=2000]
[window target=true]

;//【ＢＧ】『学園教室』（朝）******************************************************

[SE f="se017" loop=true]
;//【ＳＥ】『学園の喧噪』



[OnName num="shoma"]
"My name is Shōma Miyagishi. I have no hobbies or special skills. Nice to meet you all."
[cpg cn=true]


By mentioning that I have no hobbies or special skills, I intentionally make it harder to start up a conversation with me. I had no interest in making connections.
[cpg]


I don't want to make any friends because that just makes it harder to say goodbye.
[cpg]


[OnName num="female_student_A"]
"Hey, isn't he handsome ......?"
[cpg cn=true]


[OnName num="female_student_B"]
"He's average. Is he your type?"
[cpg cn=true]


While thinking about it, they'd already started gossiping about me.
[cpg]


They are not ordinary schoolgirls, but gals. Looking around, there seems to be a lot of them in the class.
[cpg]


It was surprising, I hadn't heard of any problems at the school. At least the boys seem to be normal......
[cpg]


But for some reason, there were a lot of gal-looking girls in my class. Maybe it was a local fashion?
[cpg]


[OnName num="male_teacher"]
"Umm... the seat next to Arishiro is open."
[cpg cn=true]


Someone perked up, that must be Arishiro. We locked eyes for a moment.
[cpg]


She sure looked like a gal. We hadn't spoken yet, but her appearance made it pretty clear.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



Then the class started.
[cpg]


Arishiro and I didn't talk during class.
[cpg]


Yet I could tell that she was very interested in me. I guess transfer students are unusual.
[cpg]


The lessons were fairly difficult, but in line with my academic level.
[cpg]


Not to brag, but I tended to perform well in school. That's why it came as a surprise to see so many gals at a school of this caliber.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f=se014]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



I wasn't shy, either. When you change schools as often as I do, you quickly learn how to adapt to your environment.
[cpg]


But this time might be different......or so I was thinking, when I heard a voice call out to me.
[cpg]



;//ここからしばらく美智佳の名前を？？？と隠してください



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michika001"]
[OnName num="unknown"]
"What's wrong, new guy? You look tired."
[cpg cn=true]


Did I? Perhaps she was right.
[cpg]


I was used to it, but I guess there's a certain amount of unavoidable stress that comes with moving a lot......
[cpg]


[OnName num="shoma"]
"Well, I'm just a little nervous about coming to a new place."
[cpg cn=true]


I lied. I never get nervous in these situations.
[cpg]


But I unconsciously say things in a way that puts others at a distance.
[cpg]


I pretend to be nervous and keep people away from me. Then I don't have to make friends.
[cpg]


I've been through the process many times of saying goodbye to former school friends in tears. We would keep in touch, but then calls would turn into emails, and then we stop.......
[cpg]


That's why I don't make friends.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Michika002"]
[OnName num="unknown"]
"You are nervous? Let me help you relax."
[cpg cn=true]


[OnName num="shoma"]
"Hey, cut it out!"
[cpg cn=true]


She tickles me......what was her name? Arishiro?
[cpg]


[OnName num="shoma"]
"Haha, hahaha ...... stop it, hahaha."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Michika003"]
[OnName num="unknown"]
"There that's a little better."
[cpg cn=true]


What was that for......?
[cpg]


I'm not the biggest fan of gals. They seemed overly familiar.
[cpg]


I don't like to imagine that they might be saying something behind my back.
[cpg]


I had to be careful about how I interacted with her.
[cpg]


[OnName num="shoma"]
"Okay, okay, just don't tickle me......."
[cpg cn=true]



;//ここから美智佳の名前を表示してください



[FACE method="change_2" pos="2/3"]
[VOICE f="Michika004"]
[OnName num="mithika"]
"I'm Michika Arishiro. You can call me Michika."
[cpg cn=true]


[OnName num="shoma"]
"Okay ...... Michika-san."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Michika005"]
[OnName num="mithika"]
"You don't really need to add honorifics...... But it's fine, you can call me however you like."
[cpg cn=true]


Again, I'm not the biggest fan of gals.
[cpg]


But for some reason, Michika was strangely attractive to me.
[cpg]


[OnName num="shoma"]
"You really don't care how people call you?……."
[cpg cn=true]


When I asked Michika this, she scratched her head and replied,
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Michika006"]
[OnName num="mithika"]
"If people are comfortable with it, I don't care what they call me."
[cpg cn=true]


Just as I unconsciously reject everything, she unconsciously accepts everything.
[cpg]


Was it intentional? She might be a good talker.
[cpg]


Maybe she was manipulating me. I get defensive.
[cpg]


[OnName num="shoma"]
"Well, look. I'm a boring guy, so you don't really have to bother with me."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Michika007"]
[OnName num="mithika"]
"I don't know, sometimes it's fun to talk to a boring guy."
[cpg cn=true]


I don't know what she's talking about, and Maybe she's just being random, but she makes me feel strangely cheerful.
[cpg]


She was a girl who suited the casual tone of her voice. She left a strong impression on me.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



As we talked, Michika kept coming closer and closer to me.
[cpg]


Eventually, she forced me to exchange phone numbers with her.
[cpg]


I guess "forced" is not quite the right word ......I wanted hers too.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se010"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************


After school, I bumped into a girl.
[cpg]


;//ここから暫く夏子の名前を？？？と隠してください


[SE f="se004"]
;//【ＳＥ】『歩いていてぶつかる』
[WAIT time=1000]

[FG f="CHA02_p2_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Nathuko001"]
[OnName num="unknown"]
"......Ouch, watch where you're going!"
[cpg cn=true]


The girl was also a gal. But she looked more ferocious than Michika.
[cpg]


Michika had an aura that made me want to talk to her again, but this girl was the complete opposite.
[cpg]


I knew in an instant that it was better not to get involved with her.
[cpg]


[OnName num="shoma"]
"I'm sorry."
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Nathuko002"]
[OnName num="unknown"]
"Be more careful, damnit."
[cpg cn=true]


The way she said it sounded more like a delinquent than a gal.
[cpg]


Yikes......I quickly walked back home.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



The streets were unfamiliar to me, but I managed to make it home.
[cpg]


I'm not good with directions, no matter how many times I move to a new place, I never seemed to be able to remember the way home.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



I get lost a few times, but I finally reach the apartment.
[cpg]




[window target=false]
[free time=1000]
[BG f="b_01_3.ui" time=1000]
[WAIT time=2100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[OnName num="shoma"]
"...... phew."
[cpg cn=true]


I let out a sigh. I wasn't feeling nervous or depressed or anything.
[cpg]


I no longer worry about fitting in or making friends.
[cpg]


I felt the same as usual, the sigh was just from fatigue.
[cpg]


The days when I felt excited every time I moved to a new school are long gone.
[cpg]


I'm sure nothing special will happen at the new school. I'll probably just have a couple of friends and go to another school ...... again.
[cpg]


My parents said something about finally being able to settle down, but I don't know.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



I'm not excited about the prospect of another day.
[cpg]


I don't think you can blame it all on my upbringing. It's also my fault.
[cpg]


If I had kept in touch with my friends from my old school, I might have had a few people I could call my best friends.
[cpg]


But Maybe I'm just lazy or they simply disliked me?
[cpg]


I'm not sure, but I've come to think that making relationships is a hassle.
[cpg]



;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



[SE f="se002" loop=true]
;//【ＳＥ】『喧噪』



I ate breakfast and headed to school. I feel somewhat dazed and unmotivated.
[cpg]


It's a feeling I shouldn't have at my age. Youth should be a brighter period in one's life.
[cpg]


I am sure that I will come to regret my vague and unmotivated youth.
[cpg]


However, if making friends is meaningless, what exactly could I do......
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[SE f="se017" loop=true]
;//【ＳＥ】『学園の喧噪』

But by spending my days in the classroom, there are some guys who talked to me.
[cpg]


[OnName num="male_student_A"]
"So? Have you gotten used to this school?"
[cpg cn=true]


[OnName num="shoma"]
"I don't know. I'm used to moving schools."
[cpg cn=true]


[OnName num="male_student_B"]
"Yeah? ......Well this school is great, isn't it?"
[cpg cn=true]


[OnName num="shoma"]
"What do you mean?"
[cpg cn=true]


[OnName num="male_student_B"]
"The number of gals. Although this is a prep school."
[cpg cn=true]


[OnName num="male_student_A"]
"I guess gal's are gonna gal. That's just the way it is."
[cpg cn=true]


It is true that there are a lot of gals in this school.
[cpg]


The same goes for Michika and the girl I bumped into the other day.
[cpg]


[OnName num="shoma"]
"Oh, you know I accidentally bumped into one the other day. She sure was scary."
[cpg cn=true]


[OnName num="male_student_A"]
"Scary? Hmm. Maybe it was Miyako?"
[cpg cn=true]


[OnName num="male_student_B"]
"Oh, Natsuko Miyako? Yeah, she can be pretty scary......"
[cpg cn=true]



;//ここから夏子の名前を表示してください



[OnName num="shoma"]
"Maybe? It seems like there are a few girls who could fit that description, honestly."
[cpg cn=true]


[OnName num="male_student_A"]
"Nah, she's on another level. She's somewhere in between a gal and a delinquent, and I hear she skips classes and stuff."
[cpg cn=true]


I'm not sure what the difference is between a gal and a delinquent, but I nodded anyway.
[cpg]


[OnName num="male_student_A"]
"Another girl you should watch out for is Mei Takahane. That's her over there......."
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

He says so as he glances behind him. Was that Takahane?
[cpg]


She doesn't seem harmful from her looks.
[cpg]

[free time=1000]

[OnName num="shoma"]
"What should I watch out for?"
[cpg cn=true]


[OnName num="male_student_B"]
"I hear a lot about how she'll flirt with guys for gifts and stuff."
[cpg cn=true]


......That's certainly something to watch out for.
[cpg]

Guys have a universal weakness to girls asking for favors.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************


After such an exchange, it was already evening and class was over.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

Takahane was looking for something around her desk.
[cpg]


[OnName num="shoma"]
"...... What are you doing?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Mei001"]
[OnName num="mei"]
"Oh, um, I lost my eraser."
[cpg cn=true]


Eraser. Why can't she just buy another one?
[cpg]


Is the eraser a memento, or is this a scheme?
[cpg]


[OnName num="shoma"]
"Do you need help?"
[cpg cn=true]

[free time=1000]

Either way, I couldn't leave her alone somehow, so I decided to help look for it.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Mei002"]
[OnName num="mei"]
"Ah! There it is, there it is."
[cpg cn=true]


I decided to help, but before I could, she'd found it. It was a tattered, nearly used-up eraser.
[cpg]

[FACE method="change_2" pos="2/3"]

She should really just buy a new one...... but I resisted the urge to tell her that.
[cpg]


Maybe there is a reason. Maybe there's something she wants to buy so badly that she doesn't want to spare the money for a new eraser.
[cpg]


[OnName num="shoma"]
"I see. I'm glad you found it."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Mei003"]
[OnName num="mei"]
"Thanks for your help."
[cpg cn=true]


[OnName num="shoma"]
"I didn't do anything."
[cpg cn=true]


This is not me being modest. Literally, the only thing I did was offer her help.
[cpg]


It felt weird when she thanked me.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Mei004"]
[OnName num="mei"]
"My name is Mei. Since you helped me out......"
[cpg cn=true]


What will she say? I wonder if she will want something in return.
[cpg]


In fact, Maybe it was all an act...
[cpg]


Would that even make sense......?
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Mei005"]
[OnName num="mei"]
"Let's be friends, what's your name?"
[cpg cn=true]


[OnName num="shoma"]
"...... Shōma Miyagishi ...... I think I introduced myself on the first day."
[cpg cn=true]


She puts her hand to her head looking like she didn't remember.
[cpg]


Somehow I couldn't call Michika by just her first name, but I'm somewhat comfortable calling this girl just Mei.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』



In the end, I became friends with Mei.
[cpg]


She seemed like a genuine goofball. Maybe tomorrow she'll have forgotten about everything.
[cpg]


But I didn't feel annoyed when she asked me to be her friend.
[cpg]


When someone says they'll be your friend in return for something, normally you'd think they were a narcissist or something ……
[cpg]


But not her. She was a strange girl.
[cpg]



[VOICE f="Michika008"]
[OnName num="mithika"]
"Oh, hey Shōma."
[cpg cn=true]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

A tap on the back. I knew it was Michika, so I turn around.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[WAIT time=800]

[OnName num="shoma"]
"Michika, is your home this way too?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
"Yeah", she says and gets all touchy.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Michika009"]
[OnName num="mithika"]
"I see you're pretty fit. Do you like sports?"
[cpg cn=true]


[OnName num="shoma"]
"I told you, I have no skills or hobbies."
[cpg cn=true]


This is not an exaggeration at all. I consider myself to be a characterless person to a great extent.
[cpg]


But in truth, I might have become something of a contrarian as a result of constantly moving......
[cpg]


I don't mention it in my introduction because I thought of it as more a part of my nature than a trait.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Michika010"]
[OnName num="mithika"]
"Yeah? Well, you're not bad looking. At our school, I bet you'll have girls lining up for a chance to play with you."
[cpg cn=true]


There was something strange about the way she said it. 'Our' school?
[cpg]


[OnName num="shoma"]
"Well ......it's not exactly your school, is it?"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
"Who knows." she said, smirking.
[cpg]


Maybe she does something that unites the gals in the class?
[cpg]


I think Michika could do it. In fact, she is a good talker.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



We part ways on the way and we each head back to our own home.
[cpg]


The way she waved at me left an impression on me ...... however.
[cpg]


Girls lining up...? Did she count herself as one of them?
[cpg]


Maybe she didn't have a boyfriend......it was odd, since she seemed like the type to play around.
[cpg]

[SE f="se010"]
;//【ＳＥ】『歩く』



[jump storage="ep001.ks" target="*start"]

;////////////////////////////////////////////////////////////////////////


