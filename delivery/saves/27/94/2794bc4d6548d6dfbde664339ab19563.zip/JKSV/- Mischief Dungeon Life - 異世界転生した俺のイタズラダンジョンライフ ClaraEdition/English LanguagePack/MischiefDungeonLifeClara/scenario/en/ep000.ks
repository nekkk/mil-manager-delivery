
*start


;//異世界変態生活　シナリオ
;//セリフを喋るキャラクターについて音声のあるものを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//クラーラ　　　　裸　下着　私服　軽装の鎧
;//ドロシー　　　　裸　下着　着衣
;//ジャニス　　　　裸　下着　私服　鎧
;//アーシャ　　　　裸　下着　着衣
;//サツキ　　　　　裸　下着　着衣

;//上記以外のキャラクターには音声がありません

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//クラーラ　　　　一人称「私（わたし）」　ドロシー呼び「ドロシー」　ジャニス呼び「ジャニス」
;//　　　　　　　　アーシャ呼び「アーシャ」　サツキ呼び「サツキ」　蓮司呼び「蓮司」
;//ドロシー　　　　一人称「あたし」　クラーラ呼び「クラーラ」　ジャニス呼び「ジャニス」
;//　　　　　　　　アーシャ呼び「アーシャ」　サツキ呼び「サツキ」　蓮司呼び「蓮司」
;//ジャニス　　　　一人称「私（わたし）」　クラーラ呼び「クラーラ」　ドロシー呼び「姫様」
;//　　　　　　　　アーシャ呼び「アーシャ」　サツキ呼び「サツキ」　蓮司呼び「蓮司」
;//アーシャ　　　　一人称「私（わたし）」　クラーラ呼び「クラーラ」　ドロシー呼び「ドロシー」
;//　　　　　　　　ジャニス呼び「ジャニス」　サツキ呼び「サツキ」　蓮司呼び「蓮司」
;//サツキ　　　　　一人称「私（わたし）」　クラーラ呼び「クラーラさん」　ドロシー呼び「ドロシーさん」
;//　　　　　　　　ジャニス呼び「ジャニスさん」　アーシャ呼び「アーシャさん」　蓮司呼び「蓮司」

;//蓮司　　　　　　一人称「俺」　クラーラ呼び「クラーラ」　ドロシー呼び「ドロシー」
;//　　　　　　　　ジャニス呼び「ジャニス」　アーシャ呼び「アーシャ」　サツキ呼び「サツキ」
;//　　　　　　　　ただし、物語序盤ではさん付けあるいはちゃん付けで呼ぶ

;//クラーラルートの一部では、蓮司は「ハリー」と偽名を使う
;//その間蓮司はクラーラを「クラーラさん」と呼び　クラーラは蓮司を「ハリーさん」と呼ぶ


;//////////////////////////////////////
;///////////////以下本編///////////////
;//////////////////////////////////////

;###################################################################
*Ep000|Metamorphosis."
;###################################################################


[SCENE id=0]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
[STOPBGM]


[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 1]
[stflag Cha4flg = 1]
[stflag Cha5flg = 1]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]


[BG f="black.ui"  time=1000]
[WAIT time=100]
[WAIT time=100]
;//ブラックアウト




I think someone somewhere compared a story in which the protagonist is reincarnated in another world to Kafka's "metamorphosis.
[cpg]


I kind of know the feeling. I know what you mean: ......
[cpg]


I didn't expect to be reincarnated and then transformed again.
[cpg]



[window target=false]

[WAIT time=1000]

[BGM f="04"]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="04"]
[window target=true]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





A student living in the present day. A student who is too ordinary to have anything to say.
[cpg]


I don't have a girlfriend, but I have a few friends. No inconvenience, but not too much freedom either.
[cpg]


Generally, neither happy nor unhappy...that's the kind of life ......
[cpg]


What a view!
[cpg]


[OnName num="renzi"]
「……」
[cpg cn=true]


Renji Haramura. I don't remember exactly what happened or how it happened.
[cpg]


It looks like some kind of underground, dungeon-like place.
[cpg]


I should have been hit by a car protecting a cat, but the cat I should have been protecting was not there either.
[cpg]


And most importantly, even if I tried to get up, I couldn't do it.
[cpg]


I don't know where is my leg and where is my hand. Still, I had the sensation of being able to move.
[cpg]


I see myself. I had a vague idea of what I looked like. ......
[cpg]

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

;//レターボックスin
[FACE method="feadin" pos="4/7"]

[BG f="b_04_5_up.ui" time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_01_1 ***********************
;//カットイン
[CUTIN f="ci_01_1.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

To put it simply, I was a snake. It was no ordinary snake.
[cpg]


A student living in the modern age. I don't know if there is such a thing as being hit by a car and reincarnated.
[cpg]


It is quite possible that this is a dream I am having.
[cpg]



The real me might be in a coma in a hospital.
[cpg]


But what was strange about it was my appearance.
[cpg]


Snakes, snakes are not that much of an obsession for ...... me.
[cpg]


[CUTIN f="ci_01_1.ui" show={false} method="feadout"]
;//[WAIT time=1000]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』
[WAIT time=1000]

[window target=true]

Everything felt awfully real to confirm that it wasn't a dream.
[cpg]


No legs. No hands. Yet I knew how to move my body to move forward.
[cpg]


There was no sense of discomfort. The sense of touch is there, too.
[cpg]


[OnName num="renzi"]
「……」
[cpg cn=true]


I want to talk to myself, but I can't because I have no vocal cords.
[cpg]


The most important thing to remember is that you can't just go to the store and ask for a discount.
[cpg]


I couldn't go on. At least, not in my current state.
[cpg]

;//レターボックスout
[FACE method="feadout" pos="4/7"]


[SE f="se007"]
;//【ＳＥ】『ゴーレム足音』

[WAIT time=2000]

;**【ＣＧ】ci_02_0 ***********************
;//カットイン
[CUTIN f="ci_02_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


As I was thinking this, a large stone doll, about two meters in height, like a golem, passed by me.
[cpg]


It was like a "Oh, it's a demon.
[cpg]


I wasn't really surprised because I looked like this. And they weren't surprised either.
[cpg]


The golem didn't care if it saw me.
[cpg]

[CUTIN f="ci_02_0.ui" show={false} method="slideout"]
[WAIT time=1000]



I wonder if a demon looking at a demon is like a person looking at a person, but even so ......
[cpg]


I can't go on like this. As I stared at the golem moving away from me, I wondered if I could do something about it.
[cpg]

[SE f=se001]
;//【ＳＥ】『変身音　リバースシンバル』

[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_02_0 ***********************
;//カットイン
[CUTIN f="ci_02_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


I thought. When I thought, I felt the structure of my ...... body change.
[cpg]


The only thing that triggered it was that I wanted to climb the stairs.
[cpg]


That was all it took, and I was no longer in the form of a snake.
[cpg]


Transformation. It is possible to be reincarnated in another world and take on a different form, but ......
[cpg]


Is there such a thing as becoming another form from there?
[cpg]


No, what had happened could not be helped now. I had my legs now, so I went ahead to the end of the stairs.
[cpg]


[SE f="se007"]
;//【ＳＥ】『ゴーレム足音』


[CUTIN f="ci_02_0.ui" show={false} method="slideout"]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



My body was heavy. I walked slowly, but I couldn't go fast.
[cpg]


Step by step, the number of demons increased. Goblins, orcs, and the other golems were the same ones that didn't pay attention when they saw me.
[cpg]


As I went deeper into the dungeon, I found a slightly open area.
[cpg]


[window target=false]

[STOPBGM]
[transition target={true} rule="tobira2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=1]
[WAIT time=100]
[transition target={false} rule="tobira2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[BGM f="02"]


[SE f="se008"]
;//【ＳＥ】『喧噪』

[window target=true]

There was a place that could be called a headquarters, or something like that.
[cpg]


A large desk and many chairs. And when I looked at the food on the table, it looked more like a dining room than a base.
[cpg]


There, demons of various races gathered, and the same demons were cooking and serving the meals.
[cpg]


It was a strange sight, but it is true that the demons cannot afford not to eat anything.
[cpg]


[OnName num="renzi"]
"(Come to think of it, I'm hungry. ......)"
[cpg cn=true]


If I asked, something might be served, but since I was a golem, I couldn't speak.
[cpg]


But since I was so hungry, I decided to join them.
[cpg]


I'm not sure if it's okay for me to be there right now, but I can't help myself.
[cpg]


;//ここから暫くアーシャの名前をunknownと隠してください


[FG f="CHA04_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha001"]
[OnName num="unknown"]
It's rare to see a golem in a diner. What can I get you?
[cpg cn=true]


A rabbit-like beastman looks at me.
[cpg]


[OnName num="renzi"]
「……」
[cpg cn=true]


I can't reply to anything. After all, I have no mouth.
[cpg]


No mouth means no food, right? I heard you say that it is rare for a golem to come to the cafeteria.
[cpg]


I nodded silently. I thought this would be enough to get the message across.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha002"]
[OnName num="unknown"]
I thought this would be enough to get the point across, but then he said, "I guess I'll leave it up to you. I mean, do golems eat food?"
[cpg cn=true]


The beastman said this and then pointed to his seat.
[cpg]


I wondered if he was a natural to cook for someone who doesn't know if he eats rice or not. ......
[cpg]

Now I can't even make a tsk tsk.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha003"]
[OnName num="unknown"]
I said, "Wait in your seat. I'll bring it right away."
[cpg cn=true]


[SE f="se007"]
;//【ＳＥ】『ゴーレム足音』


[FO pos="2/3" time=2000]

;//レターボックスin
[FACE method="feadin_up" pos="4/7"]

So said, I went to my seat.
[cpg]


I thought the chair was going to break, that I would be heavier now than I was. ......
[cpg]


It was a sturdy chair, as if it was designed for that kind of thing.
[cpg]


;//ブラックアウト

But a dining room in a dungeon?
[cpg]


I wonder how they use fire. It has to let air through, doesn't it?
[cpg]


I mean, what are they doing with the ingredients?
[cpg]


Would they grow vegetables with magic or something, but raise livestock? ......
[cpg]


The questions were endless, but I had my hands full with my own hunger right now anyway.
[cpg]

[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


[FG f="CHA04_p1_01_a.ui" method="change_2"  pos="2/3" time=1000]
[VOICE f="Arsha004"]
[OnName num="unknown"]
'Here you go. Somehow I figured you wouldn't eat meat, so I made you a salad set."
[cpg cn=true]



[SE f=se011]
;//【ＳＥ】『食器の音』


I can't imagine a golem eating meat.
[cpg]


But I can't say for sure if it would eat vegetables.
[cpg]


I think the original Golem probably doesn't eat rice, but I wanted to eat it.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha005"]
[OnName num="unknown"]
I was like, "...... what's the matter, you don't want to eat it?　You came here, that means you want to eat something."
[cpg cn=true]

Bread and salad are placed in a bowl in front of me.
[cpg]

I think so too. I want to eat. But I don't have a mouth.
[cpg]


I have the senses of sight, hearing, smell, and touch, even though I am a golem.
[cpg]


The only thing it doesn't have is the sense of taste. After all, it has no mouth.
[cpg]


Without a mouth, it cannot eat. How does the golem get its nutrition?
[cpg]


Or does the original golem not need to eat? ......
[cpg]


If this is the case, then I must not be able to imitate the mechanism of the golem itself, even though I am now transformed into a golem.
[cpg]

[FO pos="2/3" time=1000]


I look next to me. The goblin is eating something, a meat dish, roughly.
[cpg]


I am thinking to myself, "Even though he is a demon, he uses eating utensils," but that is not what I should be looking at right now.
[cpg]


I think, "Why don't you turn into a goblin? At least he has a mouth, right?
[cpg]


I think, and I try to remind myself the same as before, but ......
[cpg]


[OnName num="renzi"]
"......"
[cpg cn=true]


I can't transform. I don't know what the difference is.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha006"]
[OnName num="unknown"]
If you don't eat it, I'll lower it, okay?"
[cpg cn=true]



The rabbit beastman approached me. It was so close that I could smell it.
[cpg]


I've never had a girl come this close to me before. I guess she doesn't care because I'm a golem. ......
[cpg]


I recognized the smell. It smelled like a combination of vanilla and soap.
[cpg]


Somehow, it was a scent I wanted to remember.
[cpg]


But still, even though it is a golem, it has a sense of smell. It has sight and hearing from the start, right?
[cpg]



It suddenly occurred to me that I should try to transform myself into the beastman.
[cpg]


I don't know why I thought so. But I somehow thought I could transform better than the goblin next to me.
[cpg]

[STOPBGM]

[SE f=se001]
;//【ＳＥ】『変身音　リバースシンバルのような音』
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

;//レターボックスout
[FACE method="out" pos="4/7"]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/5" time=1]
[FG f="CHA04_p4_01_a.ui" method="change_7"  pos="4/5" time=1]

[WAIT time=100]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


And then the structure of his body changed again. It was neither a snake nor a golem, but a beastman.
[cpg]

[BGM f="02"]
[SE f="se008"]
;//【ＳＥ】『喧噪』

[OnName num="goblins"]
Whoa!　What the hell are you?
[cpg cn=true]


The surroundings were buzzing. It was just a transformation, but it seemed to be unusual.
[cpg]



[FACE method="change_1" pos="2/5"]
[VOICE f="Arsha007"]
[OnName num="unknown"]
I was surprised to see you ...... are a shapeshifter.
[cpg cn=true]


[OnName num="goblins"]
I didn't know there were still survivors. Where did you come from?
[cpg cn=true]


I could reply now. But I'm more interested in ......
[cpg]

[FO pos="2/5" time=1000]
[FO pos="4/5" time=1000]

[SE f=se011]
;//【ＳＥ】『食器の音』

;//レターボックスin
[FACE method="feadin" pos="4/7"]

I decided to start on the meal in front of me.
[cpg]


The demons were looking at me and talking about this and that, but I didn't care.
[cpg]


[OnName num="goblins"]
I was really hungry,......, but I didn't know there were shapeshifters in this dungeon.
[cpg cn=true]


The voices talking in a buzz were generally what you would expect from me.
[cpg]


In fact, there was even a demon that came up to me and tried to talk directly to me.
[cpg]


[OnName num="orc_A"]
I heard you're a shapeshifter.　You really look just like Asha.
[cpg cn=true]



;//ここからアーシャの名前を隠さないでください



[OnName num="orc_B"]
'Really,......, if I can shape-shift so much like you, I'll be able to plan a lot of different strategies.
[cpg cn=true]

[stopse g=3]
;//通常se

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト


;//レターボックスout
[FACE method="out" pos="4/7"]


The shapeshifters are a race that once made a great contribution to the demon tribe, according to what I've heard.
[cpg]


I was not sure how I should take it, but I didn't feel bad about being pampered.
[cpg]


[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[WAIT time=100]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************




[window target=true]

On the other hand, it would be conspicuous if I kept dressing up like her.
[cpg]


I changed back into my golem form again and left the cafeteria.
[cpg]


As usual, I could not disguise myself as a goblin. I don't know why I was able to turn into that girl who was called Asha.
[cpg]


It's a strange thing, but there must be some condition.
[cpg]


[OnName num="renzi"]
I'm a little sleepy.
[cpg cn=true]


I'm sleepy. I am sleepy, but I don't know where to sleep.
[cpg]


Is it okay to sleep in the middle of a dungeon?
[cpg]


If this is a safe place, it's fine. But there is a possibility that it is not.
[cpg]


Demons seem to leave demons alone, but there is a possibility that they are hostile to humans.
[cpg]


There was some talk that the shapeshifters could be useful in some kind of operation.
[cpg]


If there is an operation, it means there is something hostile.
[cpg]


[OnName num="renzi"]
"(No, I don't want to think about anything else right now ......)"
[cpg cn=true]


After much thought, I decided to go to sleep.
[cpg]



[BG f="black.ui"  time=1000]
[WAIT time=100]
[STOPBGM]
;//ブラックアウト





I lay down in a suitable place in the corridor. Even if some insects appeared, they would not sting me as a golem.
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[window target=true]

And after a good night's sleep. I didn't wake up on my own, I was woken up.
[cpg]


The one who woke me up was a lizardman, an upright, reptilian-looking creature.
[cpg]


[OnName num="lizardman"]
What are you doing? What are you doing, sleeping in a place like this?
[cpg cn=true]


[OnName num="renzi"]
「……」
[cpg cn=true]


[OnName num="lizardman"]
You never know when that brave woman might attack. Aren't you afraid?
[cpg cn=true]


I had no mouth to speak, so I couldn't say anything back to him.
[cpg]


[OnName num="lizardman"]
Anyway, you should be on guard rather than sleeping here.
[cpg cn=true]



I was reluctant to say anything. Reluctantly, I headed for the place he had indicated.
[cpg]

[SE f=se007]
;//【ＳＥ】『ゴーレム足音』


;//レターボックスin
[FACE method="feadin_up" pos="4/7"]


I guess he was assigning me a job as a member of the dungeon community.
[cpg]


It wasn't much of a job, even though it was called "guarding. I was really just there to keep an eye on things.
[cpg]


I was never alone there, so I was never bored.
[cpg]


[OnName num="goblins_A"]
'Golem is kind of boring to hang out with because he can't talk.
[cpg cn=true]


[OnName num="goblins_B"]
'Well, don't say that. I heard a shapeshifter came to our house.
[cpg cn=true]


[OnName num="goblins_A"]
"Shapeshifters ......?　If that's true, it's a big deal.
[cpg cn=true]


We spent some time in the dungeon, taking turns keeping watch.
[cpg]


Fortunately, no humans appeared while I was on watch. Perhaps they are hostile.
[cpg]


If they appeared, I wondered if I would have to fight them.
[cpg]


I tried to look as strong as possible, so I kept disguising myself as a golem instead of my original serpent-like form.
[cpg]


It was slow-moving. It doesn't look like it could fight very well, but that's true even in its original form.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//レターボックスout
[FACE method="out" pos="4/7"]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************

[window target=true]


Still, I just can't stay in golem form when I'm eating.
[cpg]


My transformation repertoire was either a golem or the beastman ...... Asha, for example.
[cpg]


[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="4/5" time=800]

[FG f="CHA04_p3_01_a.ui" method="change_5"  pos="2/5" time=800]
[VOICE f="Arsha008"]
[OnName num="asha"]
'Whoa!　What a surprise, I thought I was there."
[cpg cn=true]


I'm not sure if it's a good idea to be at the dinner table in her form, but it could lead to some unwanted misunderstandings.
[cpg]


[OnName num="orc"]
"Two Asha's ......?　Did you learn some kind of magic?
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Arsha009"]
[OnName num="asha"]
No, no, no, he's a shapeshifter,...... or maybe it's more of a she than a he."
[cpg cn=true]

[FO pos="2/5" time=1000]
[FO pos="4/5" time=1000]


[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト





And when we went to bed, we headed to a large room that was separate from the dining room.
[cpg]


It was quite large, and was apparently meant to be a communal bedroom.
[cpg]


There were several rooms similar to this one, and the higher ranking demons had private rooms.
[cpg]



[window target=false]

[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************

[window target=true]


As I continued to keep watch, I would occasionally see a human being.
[cpg]

;**【ＣＧ】ci_02_0 ***********************
;//カットイン
[CUTIN f="ci_02_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

But if they were disguised as strong-looking golems, they would run away just as soon as they encountered them.
[cpg]


Whether or not they can actually fight, it's useful to be able to change their appearance.
[cpg]

[CUTIN f="ci_02_0.ui" show={false} method="slideout"]
[WAIT time=1000]


[OnName num="goblins"]
'No, it helps. You just look so strong.'
[cpg cn=true]


People around me are beginning to realize that I am a shapeshifter.
[cpg]


They know I'm not strong enough to fight myself, and they've been supportive.
[cpg]


But being a golem who can't speak forever is a problem. ......
[cpg]


That said, the only way to speak is to borrow Asha's form.
[cpg]


It's also a hassle to explain every time someone sees you do that and misunderstands you.
[cpg]


[OnName num="goblins"]
"You really don't talk much,......, or rather, you can't speak."
[cpg cn=true]


[OnName num="renzi"]
I'm a golem.
[cpg cn=true]


[OnName num="goblins"]
Try to be me, and then you'll be able to talk. Then maybe you can talk.
[cpg cn=true]


I tried desperately to become the golem, but I couldn't. What was the difference?
[cpg]


What was the difference? I tried desperately to disguise myself, but I couldn't. I couldn't remember anything at all.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="ep001.ks" target="*start"]


