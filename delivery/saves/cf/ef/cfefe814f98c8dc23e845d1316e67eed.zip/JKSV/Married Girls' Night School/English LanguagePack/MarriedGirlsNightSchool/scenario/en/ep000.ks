
*start

;//人妻ざかりの性指導　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//夏希　裸　スーツ　私服
;//翠　　裸　制服　私服
;//咲良　裸　私服
;//以下音声なし
;//雄基
;//雄基の母
;//雄基の父
;//中年男性
;//女子学生
;//翠の夫
;//咲良の夫

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//夏希　一人称「私」　翠呼び「滝津さん」　咲良呼び「新実さん」　雄基呼び「雄基くん」
;//翠　　一人称「あたし」　夏希呼び「賀原先生or先生」　咲良呼び「咲良さん」　雄基呼び「雄基くん」
;//咲良　一人称「私」　夏希呼び「賀原先生or先生」　翠呼び「翠さん」　雄基呼び「雄基くん」
;//雄基　一人称「俺」　夏希呼び「夏希さん→先生→夏希さん」　翠呼び「翠さん」　咲良呼び「咲良さん」


;#################################################
*Ep000|Everyday life where darkness prevails
;#################################################

[SCENE id=0]

[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]

;///////////////////////////ここから本編です///////////////////////////



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2500]
[BG f="b_03_5.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_da"]
;//ブラックアウト



There was a darkness spreading.
[cpg]


It wasn't so much that people were being extremely cruel .......
[cpg]


It was just a general and probably mild bullying.
[cpg]


But it was still darkness to me. When I went to school in the morning, there was a vase of flowers on my desk.
[cpg]


My notebooks and textbooks were torn up, and there were scribbles that were unpleasing to read.
[cpg]


I was really afraid of the end of summer vacation. I wonder if the number of students who don't come to the school will increase.
[cpg]


If so, I am one of them.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



I haven't seen this town during the daytime for a long time.
[cpg]


The reason for this is that I have become what some would call a “shut-in".
[cpg]


It was worse right after the summer vacation, but recently I've finally been able to go outside.
[cpg]


But I can only go out at night.
[cpg]


Being out during the day is taxing, I can feel people staring at me.
[cpg]


Naturally, there are fewer people at night, so it stands to reason I'd make eye contact more often during the day.
[cpg]


Even so, I felt as if I was being stared at even if our eyes did not meet.
[cpg]


It was as if the image of myself was expanding on its own.
[cpg]


I was paranoid that everyone was gossiping about me. I couldn't stop thinking about it.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『商店街』（夜）******************************************************



Staying at home all the time was also difficult for me because I had always been outside.
[cpg]


If I could stay home all the time, I would. But that wasn't going to happen.
[cpg]


My parents didn't worry about me being a shut-in and not going to school anymore.
[cpg]


They decided to accept me as I was ......
[cpg]


I guess that was their way of showing me love, but it was hard to tell if they were actually worried about me.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『公園』（夜）******************************************************



Yuki Asado. I am an only child.
[cpg]


I was stuck. I was at a standstill.
[cpg]


It's already autumn, the new semester had started some time ago.
[cpg]


Of course, I have no intention of going back to that school. Still, time is passing.
[cpg]


[OnName num="yuuki"]
"......"
[cpg cn=true]


When you take a walk like this in the middle of the night, it's not easy to pass by people.
[cpg]


Even though it's better than during the day, I wish they would walk as far away from me as possible.
[cpg]


Why can't I get that wish, I even begin to think that this situation is unreasonable.
[cpg]


I was sick in the head and I knew it.
[cpg]


;//ブラックアウト
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[SE f="se003"]
;//【ＳＥ】『ドア閉まる』
[WAIT time=1000]

[OnName num="yuuki"]
"I'm home. ......"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I go back to my room. There was nothing to do but play games.
[cpg]


The night is long. I couldn't stay awake during the day, and it was common for me to be active in the middle of the night.
[cpg]


I had to really think about what I wanted to do.
[cpg]


It was 2 AM, my parents were long asleep.
[cpg]


I just had too much time to spend in solitude.
[cpg]


I used to suffer through every day, so this was still an improvement.
[cpg]


But even so, it's too much. Why do I have to suffer like this?
[cpg]


It's hard to return to a normal school now. The days and nights are completely switched.
[cpg]


On top of that, I'm worried that I'll be bullied again at a normal school.
[cpg]


I still don't know why I was bullied. Maybe that's why I was bullied in the first place.
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



Morning comes, and I am still unable to think of a solution to my situation.
[cpg]


I spend more time sleeping these days...12 hours at least.
[cpg]


Maybe my body’s out of it because I'm up in the middle of the night.
[cpg]


In the morning, I finally feel sleepy. I don't have to do or feel anything when I'm asleep.
[cpg]


I drift off to sleep, painfully aware that tomorrow awaits when I awake...
[cpg]




;//ブラックアウト

Then evening came again.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



Around five o'clock in the evening, I wake up as usual.
[cpg]


I go to sleep at five in the morning. Sometimes a little earlier and sometimes a little later.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
;//ブラックアウト


[OnName num="yuuki"]
"Good morning, Mom."
[cpg cn=true]


[OnName num="yuuki's_mother"]
"Oh, good morning. I'm thinking of making curry rice today.”
[cpg cn=true]


Mom is always like this. I'm her only son, but it feels like she doesn't take my situation seriously.
[cpg]


[OnName num="yuuki"]
"Thank you… that sounds good.”
[cpg cn=true]


Lately she's cooking more dishes that will last the whole night.
[cpg]


I'm not surprised. She's sleeping while I'm eating.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



Today seems to be a holiday. I realized this when I met a certain person in the middle of the night.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
Her name is Natsuki Kahara. She’s a teacher apparently.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Natuki001"]
[OnName num="natuki"]
"Ah, Yuki. Good evening.”
[cpg cn=true]


[OnName num="yuuki"]
“Good evening ......  Do you have the day off today?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Natuki002"]
[OnName num="natuki"]
"I suppose I do, since today is Saturday."
[cpg cn=true]


Right? Although she could be out walking around at this hour, even on a weekday.
[cpg]


She and my mom are good friends and neighbors. I used to admire her, but ......
[cpg]


She's married. I can't bring myself to touch a married woman, also she's too old for me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Natuki003"]
[OnName num="natuki"]
"Are you all right? You look pale, Yuki."
[cpg cn=true]


[OnName num="yuuki"]
"Well ...... I'm fine. I always look pale."
[cpg cn=true]


But in fact, I may not be getting enough exercise.
[cpg]


If I stopped taking walks at night, that might very well be the end of me.
[cpg]


I might have it already, but ...... I’ll try not think about that anymore.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Natuki004"]
[OnName num="natuki"]
“Are you sure you're okay? I'm really worried about you, Yuki."
[cpg cn=true]


[OnName num="yuuki"]
“You don't have to worry so much ..... I’m just someone who lives nearby.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Natuki005"]
[OnName num="natuki"]
“I don't think of you that way. I knew you when you were a child.”
[cpg cn=true]


[OnName num="yuuki"]
“...Well, you don't have to worry about me.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Natuki006"]
[OnName num="natuki"]
"I see. ...... Well then, I have some shopping to do."
[cpg cn=true]

[free time=1000]
[SE f="se014"]
;//【ＳＥ】『歩く』

When I walk around this time of day, I sometimes see Mrs. Natsuki.
[cpg]


I've been looking forward to talking to Natsuki for a while now.
[cpg]


I only talk to my parents. Therefore, it was a real pleasure to be able to talk with a beautiful woman like Natsuki.
[cpg]


[OnName num="yuuki"]
"This can't go on forever..."
[cpg cn=true]


I have to do something. I already knew that long ago.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『商店街』（夜）******************************************************



But still, I couldn't do anything about it. And so the days passed.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



The following Monday. I was still walking aimlessly through the city.
[cpg]


[OnName num="yuuki"]
“Where am I?"
[cpg cn=true]


It seems that I had wandered quite far from home.
[cpg]


I came to a place I had never seen before. There, I saw a strange sight, something that I'd never seen before.
[cpg]


It was a school. It's a school, but the lights are on at midnight.
[cpg]


All the classrooms were lit up. This wasn't some sort of late-night faculty meeting.
[cpg]


I saw people who looked like students in their everyday clothing coming out of the gates. It was a curious sight to see.
[cpg]


Is the school open at night? Is there such a school?
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se003"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



After I returned home, I did some research on my smartphone.
[cpg]


Then I found one. It was a night school.
[cpg]


It is a form of school where classes are held in the middle of the night instead of during the day ……
[cpg]


In exchange, it seemed to be a place where graduation was a little later than in a normal school.
[cpg]


Surprised by this, I decided to asked my parents about it as they were getting ready for sleep.
[cpg]


[OnName num="yuuki's_father"]
"Oh, the night school? Yes, I've heard of it."
[cpg cn=true]


[OnName num="yuuki's_mother"]
“If you want to go there, we'll pay for your tuition. Right?”
[cpg cn=true]


[OnName num="yuuki's_father"]
“Of course. What you want to do is the most important thing."
[cpg cn=true]


What, they knew about this?
[cpg]


[OnName num="yuuki"]
“Why didn't you tell me?”
[cpg cn=true]


[OnName num="yuuki's_mother"]
“Because ...... you didn't look like you could manage it."
[cpg cn=true]


......I guess I looked that depressed.
[cpg]


Still, they could have told me about the night school earlier,......
[cpg]


But my parents were worried about me. They are being supportive.
[cpg]


I made up my mind. I'm going to regain my youth once again, which sounds a bit exaggerated .......
[cpg]


I wanted to graduate from school. That was what I desired.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



It was late at night. Mrs. Natsuki was on her way home.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Natuki007"]
[OnName num="natuki"]
Ah, Yuki. Good evening.
[cpg cn=true]


[OnName num="yuuki"]
“Good evening. Mrs. Natsuki ……"
[cpg cn=true]


I had been thinking that it was a little strange. She always comes back in a suit. It is at this time of the day.
[cpg]


I thought that it was strange for a teacher to come back at this time of the day, no matter how demanding the work place is.
[cpg]


Could it be ......
[cpg]


[OnName num="yuuki"]
“Mrs. Natsuki, are you are a teacher at a night school?”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Natuki008"]
[OnName num="natuki"]
“How do you know? I guess it’s rather obvious isn’t it?”
[cpg cn=true]


[OnName num="yuuki"]
“I knew it …… “
[cpg cn=true]


As I talked to her, she said that she was a teacher at the night school where I was trying to go to.
[cpg]


I wonder if she will become my teacher.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Natuki009"]
[OnName num="natuki"]
“Would you like to try it, Yuki? It might change your life.”
[cpg cn=true]


When she said that, I began to look forward to it. I was getting excited about my new life.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



Days and nights passed.
[cpg]


Even though it was a night school, there were entrance exams.
[cpg]


I was nervous and rubbed my sleepy eyes as I went there, but it was so easy that I was surprised.
[cpg]


But maybe that's just how it is. I guess the main purpose of the school is to accommodate a variety of students.
[cpg]

[jump storage="ep001.ks" target="*start"]

;////////////////////////////////////////////////////////////////////////


