
*start


;#################################################
*Ep004|I only have one youth.
;#################################################

[SCENE id=4]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



I fall asleep and wake up in the evening.
[cpg]


On my way to school. I bumped into Akira.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akira077"]
[OnName num="akira"]
"Good morning ......? You look awful sleepy."
[cpg cn=true]


[OnName num="yuuki"]
“Well …… I just woke up."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Akira078"]
[OnName num="akira"]
“Good morning then. Shall we go?”
[cpg cn=true]


[OnName num="yuuki"]
“What do you do during the day, Akira?”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Akira079"]
[OnName num="akira"]
“Oh you know...I work part-time.”
[cpg cn=true]


Part time. Somehow, the words don't really suit her.
[cpg]


[OnName num="yuuki"]
“Then, why don't you go to school during the day and work part time at night?”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Akira080"]
[OnName num="akira"]
“It's not as easy as you think, it's hard for people of my generation to blend in with you young folks.”
[cpg cn=true]


I think that Akira could blend in ……
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************


We keep on talking, we go to class and it was already after school.
[cpg]


After school. At least in our own way ……
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuki076"]
[OnName num="natuki"]
"Yuki, do you have a few minutes after this?”
[cpg cn=true]


[OnName num="yuuki"]
"Sure, but ...... what is it?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Natuki077"]
[OnName num="natuki"]
“You seem a little dark again lately. What's wrong?”
[cpg cn=true]


There wasn't anything, really. Gloomy was just part of my appearance.
[cpg]


[OnName num="yuuki"]
"...... Nothing in particular."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Natuki078"]
[OnName num="natuki"]
“Really? Well, either way, please stay here for a while.”
[cpg cn=true]


I don't think there's any reason to follow her instructions.
[cpg]


But I decided to wait with a little anticipation. ......
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

And then, in the classroom after school.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sNatuki008"]
[OnName num="natuki"]
“I want you to cheer up. Is there anything I can do?”
[cpg cn=true]


There was a certain weight to her words that implied something else.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="sNatuki009"]
[OnName num="natuki"]
"You can rely on me ...... more."
[cpg cn=true]


I'm sure that's not all. She has such an expression on her face.
[cpg]

That kind of look as if she was waiting for something.
[cpg]

;//========================================
;//●ＣＧ（ヒロインに主人公が背後から迫る）ev_09
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：私服
;//場所　：学園教室
;//時間　：夜
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]

When I got closer to her, she didn't pull away.
[cpg]

I am tempted to grab her and pull her close.
[cpg]

[VOICE f="sNatuki010"]
[OnName num="natuki"]
“……"
[cpg cn=true]


But if I do that, I can't go back.
[cpg]

She just keeps quiet, which I guess means she's not rejecting me, but ......
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akira081"]
[OnName num="akira"]
“...There are better places to do that, you know."
[cpg cn=true]

[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="shock_5"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Natuki097"]
[OnName num="natuki"]
“!? Mrs. Takizu……!?"
[cpg cn=true]


I hadn't noticed until she'd spoken up, but Akira had seen us.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Akira082"]
[OnName num="akira"]
“Well ...... it's not like I'm in any position to criticize you.”
[cpg cn=true]


[FACE method="change_4" pos="2/5"]
[VOICE f="Natuki098"]
[OnName num="natuki"]
“Were you there the whole time?”
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Akira083"]
[OnName num="akira"]
“I sure was. I think I'll be taking Yuki tonight in exchange for my silence.”
[cpg cn=true]


Akira said. The teacher looked frustrated.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Natuki099"]
[OnName num="natuki"]
“...I suppose I don't have much of a choice.”
[cpg cn=true]


Yay, says Akira. I questioned that reaction, too ......
[cpg]






[SE f="se014"]
;//【ＳＥ】『歩く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************



She took me to the park. Then we went into the bushes.
[cpg]



[SE f="se024"]
;//【ＳＥ】『茂みに入る』
[WAIT time=1100]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akira084"]
[OnName num="akira"]
“Mrs. Natsuki can be a little pushy. Although, I can't speak for others.”
[cpg cn=true]


[OnName num="yuuki"]
"No kidding...”
[cpg cn=true]

;//ブラックアウト
;//========================================
;//●ＣＧ（公園で隣り合わせに座っている二人）ev_10
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：私服
;//場所　：公園
;//時間　：夜
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sAkira003"]
[OnName num="akira"]
“You sure are popular, aren't you, Yuki?”
[cpg cn=true]


[OnName num="yuuki"]
“I suppose ……"
[cpg cn=true]


I guess you could say that.
[cpg]

I can't deny it strongly, but should I?
[cpg]

She was smiling the whole time, as if she could see through the hesitation in my heart.
[cpg]


;**【ＣＧ】 ev_10_a ***********************
[CG id=6 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="sAkira004"]
[OnName num="akira"]
“Have you ever kissed anyone?”
[cpg cn=true]


When she finally said something like that, I thought about it again.
[cpg]


She has a husband. She might have her own reasons for coming on to me.
[cpg]


But I still couldn't do it.
[cpg]

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************



[OnName num="yuuki"]
“Mrs. Akira, I can’t ……”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Akira107"]
[OnName num="akira"]
"Are you holding back just because I'm a married woman?"
[cpg cn=true]


[OnName num="yuuki"]
“Well, umm...yes."
[cpg cn=true]


I foolishly and honestly answer like that. Akira laughs again.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Akira108"]
[OnName num="akira"]
“Yeah, I guess that's the normal reaction in a situation like this.”
[cpg cn=true]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
;//ブラックアウト



That day, Akira withdrew more quickly than I expected.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



The next day at school. I was thinking again.
[cpg]


Why are these girls coming on to me?
[cpg]


Why would they do this to me without any reason? They are all married women.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Akira109"]
[OnName num="akira"]
“I see. It must be tough being a teacher.”
[cpg cn=true]


[FACE method="bow_7" pos="1/3"]
[VOICE f="Natuki100"]
[OnName num="natuki"]
"Yes, it is. ...... How are things with you, Mrs. Niimi?”
[cpg cn=true]


[FACE method="shake_7" pos="3/3"]
[VOICE f="Sakura043"]
[OnName num="sakura"]
“Well …… lately …..”
[cpg cn=true]


With these thoughts in mind, I interrupted the three of them as they were talking.
[cpg]


[OnName num="yuuki"]
“Hey, uhhh...I have a question for you."
[cpg cn=true]


[FACE method="bow_1" pos="1/3"]
[FACE method="change_1" pos="2/3"]
[FACE method="change_1" pos="3/3"]

[VOICE f="Natuki101"]
[OnName num="natuki"]
"Oh, Yuki, what's wrong ......?"
[cpg cn=true]


How should I ask? It would be bad if I asked them why they were coming on to me.
[cpg]


[OnName num="yuuki"]
“Are the three of you having marital difficulties......?"
[cpg cn=true]


Is this too direct? As I was thinking,
[cpg]


[FACE method="bow_7" pos="1/3"]
[VOICE f="Natuki102"]
[OnName num="natuki"]
“In my case, yes...... I guess you could say we don't get along. We are on the verge of divorce."
[cpg cn=true]


Mrs. Natsuki responded quite frankly. This would not have happened in the previous relationship that we had.
[cpg]


She's telling me this because she's been close to me and has a certain amount of trust in me.
[cpg]


[FACE method="shake_7" pos="3/3"]
[VOICE f="sSakura002"]
[OnName num="sakura"]
“In our case, it's like he's not really interested in me ...... I don't blame him."
[cpg cn=true]


[OnName num="yuuki"]
"...... What about you Mrs. Akira ……"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Akira110"]
[OnName num="akira"]
“Me? I'm ...... well, it's hard to talk about it.”
[cpg cn=true]


After all, everyone has their own circumstances.
[cpg]


If there was nothing going on, they wouldn't have approached me.
[cpg]


[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



Classes were over. I think their attention had led me to become a little more confident in myself.
[cpg]


I was able to go to places I couldn't go before.
[cpg]


I used to hate buying clothes, now I could chat with the employees a little bit.
[cpg]


I can even go to game centers and other noisy places usually filled with people.
[cpg]


I think I am gradually getting used to people.
[cpg]


Everything was starting to turn out a little better. Then I thought.
[cpg]


The three people who did this for me, who helped me get back on my feet, each have their own problems.
[cpg]


I thought I might be able to return the favor.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


The holidays are coming. Since I had nothing to do, I began to think about various things.
[cpg]


Not just brooding about it, but actively thinking about doing something.
[cpg]


I began to think about which of the women I wanted to spend my youth with.
[cpg]


You're only young once, or so they say.
[cpg]


With this thought in mind, I made a decision.
[cpg]


[if exp={getFlagValue("Cha1flg") == 1 }]
[if exp={getFlagValue("Cha2flg") == 0 }]
[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target=*select04_1]
[endif]
[endif]
[endif]

[if exp={getFlagValue("Cha1flg") == 0 }]
[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target=*select04_2]
[endif]
[endif]
[endif]

[if exp={getFlagValue("Cha1flg") == 0 }]
[if exp={getFlagValue("Cha2flg") == 0 }]
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target=*select04_3]
[endif]
[endif]
[endif]

[if exp={getFlagValue("Cha1flg") == 1 }]
[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target=*select04_5]
[endif]
[endif]
[endif]

[if exp={getFlagValue("Cha1flg") == 0 }]
[if exp={getFlagValue("Cha2flg") == 0 }]
[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target=*select04_4]
[endif]
[endif]
[endif]


[if exp={getFlagValue("Cha1flg") == 1 }]
[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target=*Sel12]
[endif]
[endif]

[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target=*Sel23]
[endif]
[endif]


[switch]
[case "Mrs. Natsuki"]
	[swap]
	[jump target="*select04_1"]
[case "Mrs. Sakura"]
	[swap]
	[jump target="*select04_3"]
[endswitch]


*Sel12|I only have one youth.
[switch]
[case "Mrs. Natsuki"]
	[swap]
	[jump target="*select04_1"]
[case "Mrs. Akira"]
	[swap]
	[jump target="*select04_2"]
[endswitch]

*Sel23|I only have one youth.
[switch]
[case "Mrs. Akira"]
	[swap]
	[jump target="*select04_2"]
[case "Mrs. Sakura"]
	[swap]
	[jump target="*select04_3"]
[endswitch]


;//■選択肢
[switch]
[case "Mrs. Natsuki"]
	[swap]
	[jump target="*select04_1"]
[case "Mrs. Akira"]
	[swap]
	[jump target="*select04_2"]
[case "Mrs. Sakura"]
	[swap]
	[jump target="*select04_3"]
[endswitch]


1. Mrs. Natsuki
2. Mrs. Akira
3. Mrs. Sakura


*select04_1|I only have one youth.
[jump storage="ep005.ks" target="*select04_1"]
*select04_2|I only have one youth.
[jump storage="ep006.ks" target="*select04_2"]
*select04_3|I only have one youth.
[jump storage="ep007.ks" target="*select04_3"]
*select04_5|I only have one youth.
[jump storage="ep008.ks" target="*select04_5"]
*select04_4|I only have one youth.
[jump storage="ep009.ks" target="*select04_4"]


;//※候補となっているヒロインから選択
;//※ルート分岐。選んだヒロインのルートへと進む
;//※全員が候補になっている場合、下から二番目の【全員が候補になっている場合】ルートへ
;//※誰も候補になっていない場合、最下の【候補が居ない場合】ルートへ


;////////////////////////////////////////////////////////////////////////

