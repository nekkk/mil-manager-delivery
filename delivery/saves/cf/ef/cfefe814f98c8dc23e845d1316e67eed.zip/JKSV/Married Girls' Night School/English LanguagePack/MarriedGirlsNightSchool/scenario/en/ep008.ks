
*start

;//==============================
;//【全員が候補になっている場合】

;#################################################
*Ep008|A Crazy Harem
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

*select04_5|A Crazy Harem

[SCENE id=8]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]

I couldn't choose just one person that I liked.
[cpg]


I wonder if the days will continue to pass like this: ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



Then we take classes at the academy.
[cpg]


Mrs. Natsuki’s classes are easy to understand. I think my grades are pretty good there too .......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuki332"]
[OnName num="natuki"]
“Yuki. You've been distracted lately."
[cpg cn=true]


[OnName num="yuuki"]
“Really?"
[cpg cn=true]


I shrugged, unable to recall anything in particular.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Natuki333"]
[OnName num="natuki"]
“And Mrs. Takizu too. You need supplementary lessons."
[cpg cn=true]


[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="4/5" time=800]

[VOICE f="Akira328"]
[OnName num="akira"]
"Oh, me too?"
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Natuki334"]
[OnName num="natuki"]
“That's why you'll have to wait until I'm done."
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************





I didn't understand what her reasons were.
[cpg]


Akira and I were waiting for her to finish work.
[cpg]

[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Natuki335"]
[OnName num="natuki"]
“I'm sorry to keep you waiting. Let's start by reviewing today's lesson."
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Akira329"]
[OnName num="akira"]
“......Ooh, I think I see what's going on here."
[cpg cn=true]


Akira grins mischievously. I still have no idea.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************



For some reason, I was taken to a park at night.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="sNatuki015"]
[OnName num="natuki"]
“I think you're getting distracted because you two keep flirting with each other."
[cpg cn=true]

[OnName num="yuuki"]
“What do you mean ......"
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]
[VOICE f="sAkira028"]
[OnName num="akira"]
“Well, she's not wrong...”
[cpg cn=true]


Well, I certainly haven't picked one person I like.
[cpg]

This is why there continues to be a slight distance between them and me.
[cpg]


;//========================================
;//●ＣＧ（ヒロイン２に後ろから抱きつくヒロイン１。背景が変わっています）ev_39
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：制服
;//場所　：公園
;//時間　：夜
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_38_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sNatuki016"]
[OnName num="natuki"]
“Mrs. Takizu, I think you could afford to be a little more aggressive."
[cpg cn=true]


[VOICE f="sAkira029"]
[OnName num="akira"]
“Whoa, hold on-”
[cpg cn=true]


The teacher hugs Akira from behind. It is a rare sight.
[cpg]

[VOICE f="sAkira030"]
[OnName num="akira"]
“And here I thought you were giving us space.”
[cpg cn=true]


[VOICE f="sNatuki017"]
[OnName num="natuki"]
“When did I ever say that?”
[cpg cn=true]



;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************



I never expected to see women fighting over me.
[cpg]

I'm happy, I guess. But.
[cpg]


[OnName num="yuuki"]
"...... Is this really okay?”
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Natuki358"]
[OnName num="natuki"]
“What do you mean?"
[cpg cn=true]


[OnName num="yuuki"]
“No, it's nothing.”
[cpg cn=true]



A harem situation where love was out of the question. It was strangely uncomfortable.
[cpg]

Neither of them asked me to choose them.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se003"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



When I returned home afterwards, it was almost morning.
[cpg]


I was headed off to bed while most people were just getting up.
[cpg]


I couldn't help but get lost in the turmoil of things.
[cpg]


This isn't love. It's adultery. It's two-timing, or even three-timing if you include Sakura.
[cpg]


It was lunacy, how long could I keep this up?
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



I fall asleep with these thoughts in my mind, and it is evening again.
[cpg]


I wake up as usual and get ready to go to the academy.
[cpg]


This can't possibly last, can it?
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



After eating at the school, we attend classes.
[cpg]


I'm most clear-headed at this time of the day, but I wonder about other people.
[cpg]


I'm sure a lot of people would be getting sleepy at this hour …..
[cpg]


Akira and Sakura don't seem to be like that. What did they have planned for me?
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

After a few days of such days. Mrs. Natsuki approaches me again.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

It’s highly unusual for a teacher and their student to walk the streets together.
[cpg]

Yet, for some reason, I couldn't refuse her.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『公園』（夜）******************************************************

Then we arrived at a park. It was nighttime, so we would be harder to spot.
[cpg]


[VOICE f="sNatuki018"]
[OnName num="natuki"]
“I think you could stand to be a little more decisive.”
[cpg cn=true]


[OnName num="yuuki"]
“What are you talking about ......?"
[cpg cn=true]


I knew what she meant. I hadn't chosen anyone and was dragging this strange situation along.
[cpg]

;//========================================
;//●ＣＧ（背後からヒロインに抱きつく主人公。背景が変わっています）ev_41
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：公園
;//時間　：夜
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_40_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


She invites me to hold her, how could I resist?
[cpg]

But ...... It’s uncomfortable, or rather ......
[cpg]

I still think this is wrong.
[cpg]

Is it the situation I've gotten myself into or the people that allow it in the first place?
[cpg]

[VOICE f="sNatuki019"]
[OnName num="natuki"]
“You look like you've lost your way.”
[cpg cn=true]


;//移植のためシーンをカットしています

;//ブラックアウト

We talk, but I can hardly remember what was said.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

I leave and head home.
[cpg]


But ...... I really don't know if this was the right thing to do.
[cpg]


There's affection, possibly even romance. But am I even allowed to truly love these women?
[cpg]


It seems clear that they don't love me. At least, not in any meaningful way.
[cpg]


I didn't know if I could continue this three-way situation any longer.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************




[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira351"]
[OnName num="akira"]
“So, what's the big deal? You said you had some concerns."
[cpg cn=true]


[FACE method="bow_7" pos="1/3"]
[VOICE f="Natuki382"]
[OnName num="natuki"]
“I'm curious, too. Maybe it's about our relationship."
[cpg cn=true]


I decided to stop the three of them at the end of class to talk.
[cpg]


The stares from those around me hurt, but I still had to talk about it now.
[cpg]


[OnName num="yuuki"]
“……I don't think I can go on like this."
[cpg cn=true]


[OnName num="yuuki"]
“It’s not like you’re in a relationship with anyone.”
[cpg cn=true]


[FACE method="shake_2" pos="3/3"]
[VOICE f="Sakura253"]
[OnName num="sakura"]
"Do you really care about that? I really like you, Yuki.”
[cpg cn=true]


[OnName num="yuuki"]
“What?......."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Akira352"]
[OnName num="akira"]
“I don't think that being in a relationship is the only form of love.”
[cpg cn=true]


Is that how it is ……? It got me a little bit flabbergasted.
[cpg]


[FACE method="shake_7" pos="1/3"]
[VOICE f="Natuki383"]
[OnName num="natuki"]
“Besides, having a husband doesn't necessarily mean you truly love him."
[cpg cn=true]


[OnName num="yuuki"]
“I thought things were...simpler than this."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira353"]
[OnName num="akira"]
“Well, you look cute when you're confused, Yuki.”
[cpg cn=true]


Akira laughs as she says so. Then,
[cpg]


[FACE method="bow_1" pos="1/3"]
[VOICE f="Natuki384"]
[OnName num="natuki"]
“Well then, I still have some work to do."
[cpg cn=true]


[OnName num="yuuki"]
“Oh, okay......."
[cpg cn=true]


;//移植のためシーンをカットしています
;//ブラックアウト
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_03_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************


[FACE method="shake_1" pos="2/3"]
[VOICE f="sAkira031"]
[OnName num="akira"]
“…… Do you feel any better, Yuki?"
[cpg cn=true]


I wasn't over it, but I didn't have it in me to fight it any longer.
[cpg]

;//[free time=1000]

Love comes in different forms for each person. It's not all about being in a relationship.
[cpg]


I was sure they each loved me in their own way...
[cpg]


Maybe that was okay. I started to think it was.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


With all that going on, I headed home.
[cpg]


Maybe things didn't have to stay this way, but did I have to go out of my way to change them?
[cpg]


I had come to accept that I was somewhat happy now.
[cpg]


Yes, how could I not be happy to be surrounded by such beautiful women?
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se003"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




What would I do now? I considered going to university.
[cpg]


If I did, our relationship would probably end...
[cpg]


But it wasn't something I had to think about right now. I was anxiously awaiting the next evening.
[cpg]


If I wanted to go to university, I'd have to fix my sleeping schedule.
[cpg]


For now, I thought about getting up a little earlier tomorrow.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



[OnName num="yuuki"]
“…… I’m sleepy."
[cpg cn=true]


I wake up in the late afternoon, still quite sleepy. I must have slept for nine hours.
[cpg]


Is this what they call hypersomnia?
[cpg]


I'd probably have to consult with a special doctor. What a pain...
[cpg]


As I thought about it, I went out to the city in the daytime for the first time in a long time.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『公園』（昼）******************************************************



...... Everything is dazzling. This was the view I used to see.
[cpg]


Perhaps the women in my life were gradually bringing me back into the light.
[cpg]


Back to who I was before I was bullied.
[cpg]


Maybe I was trying to move on, getting back on my feet after being bullied.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
;//ブラックアウト



And after a little while, I headed back to the academy.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuki385"]
[OnName num="natuki"]
“You look sleepy. ...... Were you up late?"
[cpg cn=true]


[OnName num="yuuki"]
“Umm. No, it's the other way around."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Natuki386"]
[OnName num="natuki"]
“The opposite? Oh, you're up early. That's good."
[cpg cn=true]


The teacher smiles softly. How many times had I been saved by this smile.
[cpg]


[OnName num="yuuki"]
“...... Do you have time after work today?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Natuki387"]
[OnName num="natuki"]
“Yes, I do. Shall we go on a date?"
[cpg cn=true]


She said. I felt a warmth feeling spreading in my chest.
[cpg]



;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


Time passes quickly and I head back to my place.
[cpg]


I always come home late. My family doesn't ask me where I've been.
[cpg]


[OnName num="yuuki"]
“......Phew."
[cpg cn=true]


I am quite sleepy, partly because I got up so early in the morning. Shall I go to sleep now?
[cpg]


...... I'll have to get up early tomorrow. I've decided to go on to university.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************



And more days pass. I'd advanced a grade and started to see new faces around.
[cpg]


Quite a few of them were older than me. A fair number of people stopped attending as well.
[cpg]


I knew that would be different from a normal school ......
[cpg]

[window target=false]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2500]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2500]

;//ブラックアウト
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



I realized that I was about to graduate.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Sakura272"]
[OnName num="sakura"]
“I guess we won't be able to see each other so often soon."
[cpg cn=true]


[FACE method="shake_2" pos="2/5"]
[VOICE f="Akira374"]
[OnName num="akira"]
“Oh, I think we can make it work. Every day might be difficult, though."
[cpg cn=true]


I don't know where Akira's optimism is coming from, but ......
[cpg]


I had a feeling that as long as she felt that way, we wouldn't be so easily separated.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]

Some more time passes. I graduated and went on to university.
[cpg]


I am separated from Natsuki, Akira, and Sakura for a while.
[cpg]


It was only about an hour by train, but my parents wanted me to live on my own, so I did.
[cpg]


The school I was going to was not a night school. My rhythm of life had returned to normal.
[cpg]


My parents seemed pleased with my reentry into society and were happy to help me move.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



Then, guests arrive at my flat.
[cpg]


They'd all decided on today as it fit everyone's schedule.
[cpg]


;//ブラックアウト

[SE f=se003]
;//【ＳＥ】『ドア開く』

;//========================================
;//●ＣＧ（主人公の部屋に居る三人のヒロイン）ev_44
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//人物３：ヒロイン３
;//服装３：私服
;//場所　：主人公の部屋
;//時間　：夜
;//備考　：主人公は引っ越してマンションの一室に住んでいます
;//備考２：本編から三年が経過しています
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="yuuki"]
“Hi ......."
[cpg cn=true]


;//[VOICE f="sNatuki000"]
;//[OnName num="natuki"]
;//「遊びに来ましたよ。雄基くん」
;//[cpg cn=true]

They come to visit me.
[cpg]


A strange situation for students and a teacher to be in.
[cpg]


[VOICE f="sNatuki020"]
;//[VOICE f="Natuki396"]
[OnName num="natuki"]
“It's been a while, Yuki.…”
[cpg cn=true]


;//[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akira375"]
[OnName num="akira"]
“What are you talking about? It's only been about a month.”
[cpg cn=true]


;//[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Sakura273"]
[OnName num="sakura"]
"Yeah, but the last time we were apart for so long, it was summer vacation."
[cpg cn=true]


;//移植のためシーンをカットしています


;//ブラックアウト


I think I'm a lucky guy. Even if I didn't end up with someone, I was definitely happy.
[cpg]

[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]
;//========================================
;//●ＣＧ非エロ（ヒロイン三人、それぞれ裸のまま主人公に寄り添っている。ベッドに横たわっている主人公）ev_45
;//人物１：ヒロイン１
;//服装１：裸
;//人物２：ヒロイン２
;//服装２：裸
;//人物３：ヒロイン３
;//服装３：裸
;//人物４：主人公
;//服装４：裸
;//場所　：主人公の部屋
;//時間　：夜
;//備考　：主人公は引っ越してマンションの一室に住んでいます
;//備考２：本編から三年が経過しています
;//========================================

;**【ＣＧ】 ev_45_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="Sakura280"]
[OnName num="sakura"]
“I'll keep coming to visit you from time to time. Yuki."
[cpg cn=true]



[VOICE f="Natuki406"]
[OnName num="natuki"]
“Well hold on, you'd better not hog him.”
[cpg cn=true]


So what did I do in this crazy harem?
[cpg]


[OnName num="yuuki"]
"...... Haha”
[cpg cn=true]


I laughed a little. It's crazy, but I think this is for the best.
[cpg]


At this rate, I'll probably never be able to get a girlfriend.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



Either way, this harem is mine.
[cpg]


Even if everyone is someone's wife, there is no one but me who can enjoy this situation right now.
[cpg]



;//ＥＮＤ：ハーレムルート
[SCENE id=13]


[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
