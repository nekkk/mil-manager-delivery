
*start

;#################################################
*Ep003|The wife's age.
;#################################################

[SCENE id=3]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Two days passed and it was Monday again.
[cpg]


[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



I finished my school lunch and classes started again.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Natuki026"]
[OnName num="natuki"]
“Well then, fill in the blanks here: ...... Mrs. Niimi.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Sakura008"]
[OnName num="sakura"]
“Yes!”
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************


The night school, by its very nature, does not have a lunch break.
[cpg]


The most common time for everyone to chat is after all the classes are over.
[cpg]


[FACE method="bow_7" pos="1/3"]
[VOICE f="Natuki027"]
[OnName num="natuki"]
"Oh ...... Yuki did that......?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira072"]
[OnName num="akira"]
“I know. Isn't that just so cute?”
[cpg cn=true]


[FACE method="shake_2" pos="3/3"]
[VOICE f="Sakura009"]
[OnName num="sakura"]
“Oh my, I must hear this..."
[cpg cn=true]


I didn’t know Sakura was like that ...... but I hard to hear this conversation too.
[cpg]


[OnName num="yuuki"]
“What are you three talking about?”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Akira073"]
[OnName num="akira"]
“What? I want to tell everyone how cute you are, Yuki.”
[cpg cn=true]


[OnName num="yuuki"]
"That's...no, people will figure out what's going on."
[cpg cn=true]


[FACE method="change_1" pos="3/3"]
[VOICE f="Sakura010"]
[OnName num="sakura"]
“You're digging your own grave, Yuki.”
[cpg cn=true]


......That's true. I had inadvertently admitted that something had happened.
[cpg]




;//ブラックアウト



I thought to myself, "Oh, no." But soon after that, the teacher came to me.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Natuki028"]
[OnName num="natuki"]
“Yuki, can I talk to you for a minute?"
[cpg cn=true]


[OnName num="yuuki"]
“Yes. What is it?”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Natuki029"]
[OnName num="natuki"]
“About what we were talking about the other day. I'd like to continue.”
[cpg cn=true]


What were we talking about the other day......? I was taken to a small classroom by the teacher's hand.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[VOICE f="Natuki030"]
[OnName num="natuki"]
;//「翠さんが、雄基くんは良い反応をすると言っていましたよね」
“Mrs. Takizu said something about how 'cute' you were.”
[cpg cn=true]


[OnName num="yuuki"]
“Is that what this is about……!"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sNatuki002"]
[OnName num="natuki"]
“It is. Besides …..  you still have a little bit of a dark side to you. I wanted to help you recover.”
[cpg cn=true]


This is absurd. It's beyond the scope of what a teacher should do.
[cpg]

[OnName num="yuuki"]
“Please don't make fun of me.”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sNatuki003"]
[OnName num="natuki"]
"No, no. This is my role as a teacher.”
[cpg cn=true]


I think it's beyond the role of a teacher.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



[FACE method="bow_1" pos="1/3"]
[VOICE f="Natuki050"]
[OnName num="natuki"]
“He is cute, isn't he?”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira074"]
[OnName num="akira"]
"Oh, you think so too, Ms. Kahara? Does that mean something happened between you two?”
[cpg cn=true]


[FACE method="shake_7" pos="3/3"]
[VOICE f="Sakura011"]
[OnName num="sakura"]
“Oh …… you keep talking like that. Now I’m interested.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Akira075"]
[OnName num="akira"]
“I see that you are too, Mrs. Sakura. He’s very liked.”
[cpg cn=true]


[FACE method="change_2" pos="3/3"]
[VOICE f="Sakura012"]
[OnName num="sakura"]
“He's not only cute, but he's also very kind. He told me I would be a good mother.”
[cpg cn=true]


I knew well enough to avoid this conversation.
[cpg]


So, this was my life now.
[cpg]


When the three of them are talking, they don't look like a gossipy group of women.
[cpg]


They really look like teachers and students. Especially Sakura, who looks like a child.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************


After class, the teacher called me in again.
[cpg]

A classroom where only me and the teacher are present. Or rather, she told me to stay.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Natuki051"]
[OnName num="natuki"]
"Well,  ...... Mr. Yuki.”
[cpg cn=true]


[OnName num="yuuki"]
“What is it?”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sNatuki004"]
[OnName num="natuki"]
"Let's practice communicating together, shall we?"
[cpg cn=true]


But this distance is not just about communication.
[cpg]


Is she not getting along with her husband? My mind races through a thousand possible reasons.
[cpg]

;///ブラックアウト

;//========================================
;//●ＣＧ（主人公に密着するヒロイン）ev_07
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：私服
;//場所　：学園教室
;//時間　：夜
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

[VOICE f="sNatuki005"]
[OnName num="natuki"]
“You seem to be nervous. I can tell by your expression.”
[cpg cn=true]

I don't think married women usually do this. I told her how I felt.
[cpg]


[OnName num="yuuki"]
“Are you not getting along with your husband?"
[cpg cn=true]


[VOICE f="sNatuki006"]
[OnName num="natuki"]
"Do you think so ……? I guess that's normal.”
[cpg cn=true]


[OnName num="yuuki"]
“I'm sorry, I know I shouldn't pry, but I was curious.”
[cpg cn=true]


She shakes her head. Then she said this.
[cpg]


[VOICE f="sNatuki007"]
[OnName num="natuki"]
“Sorry….. I'll tell you about it someday. For now, let's just enjoy ourselves, okay?”
[cpg cn=true]


What was there to be sorry about...? I didn't mean to sound accusatory.
[cpg]


[OnName num="yuuki"]
“No, I mean...it's not a problem or anything...If anything, I'm pretty happy, but..."
[cpg cn=true]


I said so. Then she laughed.
[cpg]


I'd said too much again.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
;//【ＢＧ】『街』（夜）******************************************************



I walked back home. Surrounded by married women, a lot of impossible things happened.
[cpg]


It's not like they were simply unfaithful to their families, there had to be a reason for all of this.
[cpg]


Was I happy? Was this what I really wanted?
[cpg]


At least it's better than when I was a shut-in ......
[cpg]



;//■選択肢
[switch]
[case "Maybe this kind of youth is not that bad."]
	[swap]
	[jump target="*select02_1"]
[case "I still want to spend my youth with people of my own generation"]
	[swap]
	[jump target="*select02_2"]
[endswitch]


1. Maybe this kind of youth is not that bad.
2. I still want to spend my youth with people of my own generation



;//==============================
;//１、こういう青春もありかもしれない
*select02_1|The wife's age.

[stflag Cha1flg = 1]
;//ヒロイン１が候補になる


After all, this is one form of youth, isn't it?
[cpg]


I was interacting with an older, married woman, but it was an interaction with the opposite sex nonetheless.
[cpg]


I feel like I had crossed a line somewhere along the way, but what could I do……
[cpg]

[jump target="*select02_3"]

;//==============================
;//２、やはり同世代と青春を過ごしたい
*select02_2|The wife's age.


Was there really no way I could interact with people my own age?
[cpg]


Perhaps there wasn't, but it didn't stop me from desiring it.
[cpg]


How does one return to any sense of normalcy after being treated like that?
[cpg]

;//==============================
*select02_3|The wife's age.


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Anyway, I was getting ready for my class tomorrow.
[cpg]


The classes weren't difficult enough to require much review.
[cpg]


I don't have anything in particular to prepare for ...... but still, I had nothing to do at night.
[cpg]


If I'm not doing something like this, I'm either taking a walk or playing video games.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



And the next day. I went to the school and had classes.
[cpg]


I seemed to be a rather good student in this school.
[cpg]


I was never like that before.
[cpg]


I wonder if it is because they want older people to keep up as well.
[cpg]


I don't know if it's rude of me to think so, but ......
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Natuki075"]
[OnName num="natuki"]
“Yes, that's correct. Now, the grammar here is a bit complicated ……"
[cpg cn=true]


[free time=1000]

On our way back to our seats, Akira said to me
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akira076"]
[OnName num="akira"]
"Good job, you must be good at studying.”
[cpg cn=true]


I wasn't sure if there was anything really worth being proud of.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『学園チャイム』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************



Then, on my way home. I was approached by a rather unusual person.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura013"]
[OnName num="sakura"]
“Yuki? May I have a word?
[cpg cn=true]


[OnName num="yuuki"]
"Oh, sure. ...... What is it?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sakura014"]
[OnName num="sakura"]
"I need to get some shopping done, could you come with me?"
[cpg cn=true]


[OnName num="yuuki"]
"You want me to go shopping with you?”
[cpg cn=true]


What does that mean? I asked for the details ……
[cpg]


Sakura's younger brother's son. In short, she wanted to buy a birthday present for her nephew.
[cpg]


We ended up talking about what she should buy for his birthday.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『商店街』（夜）******************************************************


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sakura015"]
[OnName num="sakura"]
“I'm sorry, I wanted someone young to give help out an old lady like me.”
[cpg cn=true]


But, you look younger than me, I thought.
[cpg]


[OnName num="yuuki"]
“How old is the child?”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Sakura016"]
[OnName num="sakura"]
“Well, I think he's two years old.”
[cpg cn=true]


Sakura's younger brother's son is two years old …… I could glean a lot of information from that statement, however.
[cpg]


[OnName num="yuuki"]
“Then maybe a toy would be good. Or a picture book ......"
[cpg cn=true]


We talked and decided on what to buy. Finally, we settled on a picture book.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sakura017"]
[OnName num="sakura"]
“I'm sorry you had to stay with me today. I want to thank you a little.”
[cpg cn=true]


She says, pulling my arm.
[cpg]


[OnName num="yuuki"]
“I have to go home.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sakura018"]
[OnName num="sakura"]
“Why? Is it because I'm a married woman?”
[cpg cn=true]


There's that, and then there's the fact that with our appearances, people would assume our ages were reversed...
[cpg]


I thought about what to do. As a result, I decided to……
[cpg]



;//■選択肢
[switch]
[case "Run away"]
	[swap]
	[jump target="*select03_1"]
[case "Tag along."]
	[swap]
	[jump target="*select03_2"]
[endswitch]


1. Run away
2. Tag along.

;//==============================
;//１、逃げ出す
*select03_1|The wife's age.


[OnName num="yuuki"]
“…….”
[cpg cn=true]


I tried to run away, but she pulled my arm with quite a bit of force.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sakura019"]
[OnName num="sakura"]
“Don't be like that, I just want to thank you. There's nothing wrong with that, right?”
[cpg cn=true]


[OnName num="yuuki"]
“But ..…”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sakura020"]
[OnName num="sakura"]
“It's okay. Let's go.”
[cpg cn=true]

[jump target="*select03_3"]

;//==============================
;//２、ついていく

*select03_2|The wife's age.

;//ヒロイン３が候補になる
[stflag Cha3flg = 1]




I'm not going to run and hide. I'm a man, too.
[cpg]


[OnName num="yuuki"]
“I understand. ……"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sakura021"]
[OnName num="sakura"]
“How cute, don't be nervous. Shall we go then?”
[cpg cn=true]



;//==============================

*select03_3|The wife's age.


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト


I was taken to a private room in a karaoke bar.
[cpg]

I was wondering what she would do to me in a place like this, no ......
[cpg]

I already know that myself.
[cpg]

;//========================================
;//●ＣＧ（主人公を誘うヒロイン。背景が変わっています）ev_08
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：カラオケ店
;//時間　：夜
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

[VOICE f="sSakura001"]
[OnName num="sakura"]
“Ha ha. You're so cute when you’re nervous.”
[cpg cn=true]


I couldn't respond to her flirtations.
[cpg]

If I kissed her, for example, there would be no turning back.
[cpg]

I tried my best to hold back. Seeing me like that, Sakura laughed.
[cpg]


[OnName num="yuuki"]
“….. Mrs. Sakura, are you...having problems with your husband or...something?”
[cpg cn=true]


;**【ＣＧ】 ev_08_a ***********************
[CG id=4 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Sakura042"]
[OnName num="sakura"]
“I guess so. When you've been married for a long time, you can't help it.”
[cpg cn=true]


I kept wondering how old she was .......
[cpg]


;//ブラックアウト

We eventually parted ways that day without anything happening.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『公園』（朝）******************************************************


Somehow I couldn't sleep that night and was still walking around the park as the sun rose.
[cpg]


[OnName num="yuuki"]
"......"
[cpg cn=true]


Are all three of them frustrated with their marriages? Or is there something about me that makes them want to tease me?
[cpg]


I don't know. But ......
[cpg]


I have some kind of connection with all three of them.
[cpg]


Can things really go on like this? Somehow, I doubt it.
[cpg]

[jump storage="ep004.ks" target="*start"]


;////////////////////////////////////////////////////////////////////////
