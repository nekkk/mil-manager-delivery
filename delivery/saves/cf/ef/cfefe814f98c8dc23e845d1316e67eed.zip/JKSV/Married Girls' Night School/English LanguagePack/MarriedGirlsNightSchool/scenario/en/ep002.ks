
*start

;#################################################
*Ep002|Practicing how to be in a relationship
;#################################################

[SCENE id=2]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

The next day, still slightly shocked by what I'd heard.
[cpg]


I thought I'd try to learn about Sakura's situation.
[cpg]


[window target=false]
[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************


[FACE method="change_1" pos="2/3"]
[VOICE f="Natuki016"]
[OnName num="natuki"]
“So ......in this situation, you'd say this instead.”
[cpg cn=true]


Mrs. Natsuki seemed to be an English teacher.
[cpg]


I had never heard about that, so I was a little surprised about that as well.
[cpg]



[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]
;//========================================
;//●ＣＧ非エロ（ヒロイン２がヒロイン３を紹介する。二人とも立っていて、身長差が分かる感じ）ev_03
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：ヒロイン３
;//服装２：私服
;//場所　：学園教室
;//時間　：夜
;//========================================

;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]

In between classes, Akira introduced me to Sakura.
[cpg]



[VOICE f="sAkira001"]
[OnName num="akira"]
“Yes, let's see ...... This is Sakura Niimi. She looks like this, but she has two daughters. Isn't that amazing?”
[cpg cn=true]



[VOICE f="Sakura002"]
[OnName num="sakura"]
“Don’t introduce me like that. It’s so embarrassing.”
[cpg cn=true]


I almost fell over. I was sitting down, so I didn't fall over.
[cpg]


[OnName num="yuuki"]
“I find that extremely hard to believe. You're kidding, right?”
[cpg cn=true]



[VOICE f="Sakura003"]
[OnName num="sakura"]
“Oh, but it's true you know? People sometimes mistake me and my husband for siblings.”
[cpg cn=true]


I can't believe the word "husband" came out of her mouth.
[cpg]


It's not like she's trying to look young. She is young. She is almost too young.
[cpg]



[VOICE f="Akira022"]
[OnName num="akira"]
“I told you my situation wasn't anything to be surprised about.”
[cpg cn=true]


[OnName num="yuuki"]
“Maybe, but I still think you're pretty young to be married too, Akira.”
[cpg cn=true]


I don't know how much older she is than me after all.
[cpg]


But the fact that she's hiding it implied that she's a good bit older than I am.
[cpg]


It was difficult to imagine.
[cpg]



[VOICE f="Akira023"]
[OnName num="akira"]
"By the way, I never did hear why you decided to attend night school.”
[cpg cn=true]



[VOICE f="Sakura004"]
[OnName num="sakura"]
“Well. I used to have money problems that prevented me from getting into the academy ……"
[cpg cn=true]



[VOICE f="Sakura005"]
[OnName num="sakura"]
"I hope to be able to be able teach my daughter someday after I graduate.”
[cpg cn=true]


It was too hard to imagine that I was at a loss for words. She wanted to teach her daughter to study ......?
[cpg]


If it was true, it was still very strange to be told that with her appearance.
[cpg]


[OnName num="yuuki"]
“..... Sakura, I'm convinced that you'll make a great mother.”
[cpg cn=true]



[VOICE f="Sakura006"]
[OnName num="sakura"]
“You don’t have to say that. I know I look young.”
[cpg cn=true]



[VOICE f="Sakura007"]
[OnName num="sakura"]
“But thank you. I'm flattered.”
[cpg cn=true]



;//ブラックアウト


We kept talking so on and so forth.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************



[FACE method="change_1" pos="2/3"]
[VOICE f="Natuki017"]
[OnName num="natuki"]
"How are you doing, Yuki? Have you gotten used to school life?”
[cpg cn=true]


[OnName num="yuuki"]
"It's full of surprises ……”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Natuki018"]
[OnName num="natuki"]
“I know, right? I'm not used to having school lunches before classes.”
[cpg cn=true]


That's not the point. But it doesn't matter what I say.
[cpg]

[FACE method="change_1" pos="2/3"]
There are a lot of people who keep their age a secret, but a mother of two ......?
[cpg]


If she has two daughters …… when did she give birth?
[cpg]


Considering all that, Sakura must be in her 30s...? With that appearance? How is that possible?
[cpg]


While I was thinking about the many questions, I was also relieved that the teacher was, in a sense, as old as she appeared to be.
[cpg]


[OnName num="yuuki"]
“Mrs. Natsuki, you won't betray me, will you?”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Natuki019"]
[OnName num="natuki"]
“Betray you? What are you talking about ……?"
[cpg cn=true]


I might be able to ask her, but should I?
[cpg]


As our teacher, she probably knows each student's situation, or at least their age.
[cpg]


That's a ...... cowardly way to go about it. I need to stop trying to take the easy way.
[cpg]


[OnName num="yuuki"]
“It's nothing. ……"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Natuki020"]
[OnName num="natuki"]
“Really? Please let me know if there's something wrong."
[cpg cn=true]


I mean, there was something going on, but it wasn't something I could talk to her about.
[cpg]



;//ブラックアウト


My inner turmoil had turned an otherwise normal class into an exercise in self control.
[cpg]


;//[BG g="black"][WAIT time=100][BG g="b_05_4" rule="sita"][WAIT time=100]
;//[stbgm][plbgm bg="bg_da"][WAIT time=100][OnMes]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************
;//家に帰って、一人でご飯を食べる。[cpg]
;//おかずは作り置いてくれているし、ご飯もある。[cpg]
;//流石に多少寂しいという気持ちになるけど、この気持ちがあるだけましなんだろうな。[cpg]
;//かつては寂しいと思うこともなかったから。[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『商店街』（夜）******************************************************



I knew how to pass the time in the middle of the night. I could take a walk, play games, or do all sorts of other things.
[cpg]


But once you get to know life at the school, all that extra time spent outside of it becomes difficult to bear.
[cpg]


At least, to me, it was almost unbearable.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


As usual, I commute to school in the evening, while the sun sets in the distance.
[cpg]


However, I feel a little sad that there are no girls my age.
[cpg]


Not to say that they don't exist, but they're so dark that it's hard to approach them.
[cpg]


[OnName num="yuuki"]
"Um,...... may I have a word?"
[cpg cn=true]


[OnName num="female_student"]
"Er...I......, um, what ......?"
[cpg cn=true]


The girl was strangely frightened by me. I was acting suspiciously myself.
[cpg]


[OnName num="yuuki"]
“Ah, er...it's nothing. See you."
[cpg cn=true]


I found it difficult to make friends with people my own age.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************

The class went on and homeroom was over.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Natuki021"]
[OnName num="natuki"]
“Well, I guess that's it for today.”
[cpg cn=true]

[free time=1000]
The students file out of the classroom. When I was alone with Akira, I told her about my problems.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=1000]
[VOICE f="Akira024"]
[OnName num="akira"]
“Okay. So you want to talk to someone your own age?"
[cpg cn=true]


[OnName num="yuuki"]
“Well yes ….. I mean ……”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Akira025"]
[OnName num="akira"]
“Do you want a girlfriend or something?"
[cpg cn=true]


She crossed some boudaries, but I couldn't deny it.
[cpg]


When I nodded, Akira told me this.
[cpg]

[FADEOUTBGM]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Akira026"]
[OnName num="akira"]
"Well, how about me?"
[cpg cn=true]


[OnName num="yuuki"]
“What, ……."
[cpg cn=true]

[BGM f="bg_h2"]

Did I just mishear her? Did she really say, "How about me” ......?
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="sAkira002"]
[OnName num="akira"]
“I may not be able to be your girlfriend, but maybe I can at least give you some practice at it."
[cpg cn=true]


[OnName num="yuuki"]
“Are you serious ……?"
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Akira028"]
[OnName num="akira"]
“I'm a married woman. I think I can coach you better than most people your age.”
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[OnName num="yuuki"]
“But ...... But …..”
[cpg cn=true]


“What are you hesitating about?”, Akira says.
[cpg]


Normally one hesitate. Because she has a husband.
[cpg]


This is adultery. If she really do it, it will be a terrible thing.
[cpg]



;//■選択肢
[switch]
[case "I refuse."]
	[swap]
	[jump target="*select01_1"]
[case "I don’t refuse"]
	[swap]
	[jump target="*select01_2"]
[endswitch]


1. I refuse.
2. I don’t refuse
;//==============================
;//１、拒む
*select01_1|Practicing how to be in a relationship


[OnName num="yuuki"]
“You can't do that.”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Akira029"]
[OnName num="akira"]
"There's no one here now. I love cute guys like you, Yuki.”
[cpg cn=true]


Akira looks about the same age as me when she says that.
[cpg]

[jump target="*select01_3"]

;//==============================
;//２、拒まない
*select01_2|Practicing how to be in a relationship

[stflag Cha2flg = 1]
;//ヒロイン２が候補になる



[OnName num="yuuki"]
“I understand ..… Please be nice to me.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira030"]
[OnName num="akira"]
“Haha, I think that's normally my line.”
[cpg cn=true]


;//==============================
*select01_3|Practicing how to be in a relationship


;//ブラックアウト
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


[OnName num="yuuki"]
“...... What a fine mess this is."
[cpg cn=true]


Akira is married. I don't know if she has children, but still.
[cpg]


I am sure she is married. Is it okay to practice dating with her ……?
[cpg]

I don't know if it's okay to do that, no, I don't think it's right.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se003"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I decided to stay home alone and play games.
[cpg]


Tomorrow is my day off. I will definitely be bored.
[cpg]


The existence of the school helped me a lot, but what would happen to me on my day off?
[cpg]


I couldn't imagine what would happen to me.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se007"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



Morning comes. I get sleepy and crawl under the covers.
[cpg]


I need an eye mask. I always sleep in the daytime.
[cpg]


And while I sleep soundly, ......
[cpg]



[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



Holiday comes. I wake up again in the evening.
[cpg]


It’s a holiday, which means that the I don’t have to go to school inn the evening.
[cpg]


It's strange …… I think, and I head for the living room.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



[OnName num="yuuki's_mother"]
“Good morning. Oh, you look a little better.”
[cpg cn=true]


[OnName num="yuuki"]
"I guess so …….”
[cpg cn=true]


[OnName num="yuuki's_father"]
"It's good that you're doing well. Well, just try not to overexert yourself."
[cpg cn=true]


My parents are like this. They don't force me to go to the school.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
When I left home, I ran into Mrs. Natsuki. It was her day off, she was wasn't wearing her suit.
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuki022"]
[OnName num="natuki"]
“Good evening, Yuki. What a coincidence.”
[cpg cn=true]


[OnName num="yuuki"]
“Good evening…… Where are you headed Mrs. Natsuki?”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Natuki023"]
[OnName num="natuki"]
"Well, you are always so formal ..…”
[cpg cn=true]


She was a little taken aback, but to me, she was my teacher.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Natuki024"]
[OnName num="natuki"]
“I am going shopping now. Usually my husband does it for me.”
[cpg cn=true]


I wonder if her husband is at home full-time. I don't know.
[cpg]


[OnName num="yuuki"]
“...... Have a good day."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Natuki025"]
[OnName num="natuki"]
“Yes. See you at the academy then."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『公園』（夕方）******************************************************



In the end, I took my usual a walk through the park in the evening.
[cpg]


It's not a very fulfilling way to kill time ……
[cpg]


I recognized that I was killing time. I had nothing else to do.
[cpg]


That's how much I was looking forward to going to school on Monday.
[cpg]

[jump storage="ep003.ks" target="*start"]


;////////////////////////////////////////////////////////////////////////

