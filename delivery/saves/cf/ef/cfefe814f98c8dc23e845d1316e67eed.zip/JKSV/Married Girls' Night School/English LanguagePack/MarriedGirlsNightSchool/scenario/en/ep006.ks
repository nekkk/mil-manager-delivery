
*start

;//==============================
;//２、翠さん

;#################################################
*Ep006|Akira, who appears to be in my generation
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

*select04_2|Akira, who appears to be in my generation

[SCENE id=6]


I like Akira.
[cpg]


Despite looking like she's my age, she's a married woman. Still, I can't help falling in love with her.
[cpg]


I felt like my inner feelings were becoming clearer.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se014"]
;//【ＳＥ】『歩く』



The holidays ended. I was on my way to school when I bumped into Akira.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akira116"]
[OnName num="akira"]
"Oh, Yuki. Good evening.”
[cpg cn=true]


[OnName num="yuuki"]
“Good evening. ...... Well, it's a beautiful day today, isn't it?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira117"]
[OnName num="akira"]
"Well, it's already late in the evening.”
[cpg cn=true]


[OnName num="yuuki"]
“Oh...yeah, I guess so.”
[cpg cn=true]


I may have said something a little strange.
[cpg]


I became strangely conscious of Akira.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



And the evening turns into night. The classes continue on.
[cpg]


I couldn't help but say something to Akira.
[cpg]


But I wondered when would be the best time to say something.
[cpg]


I'm sure Akira doesn't intend to leave her husband.
[cpg]


I can't make her mine…… I understand that, but I couldn't hold it back.
[cpg]



[SE f="se001"]
;//【ＳＥ】『学園のチャイム』
[WAIT time=1100]


In the meantime, all the classes were over.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akira118"]
[OnName num="akira"]
“Mmmm ...... I'm so tired today!”
[cpg cn=true]


From these words, I can tell that she is older than she looks.
[cpg]


In fact, she is a married woman. Is it right for me to confess to her?
[cpg]


[OnName num="yuuki"]
 “Mrs. Akira…… I would like to talk to you for a moment if that’s okay.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Akira119"]
[OnName num="akira"]
“What? What is it? I don't mind.”
[cpg cn=true]




;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_ne"]
;//[WAIT time=100]
;//【ＢＧ】『公園』（夜）******************************************************





So there we are, Akira and I, alone in the park in the middle of the night.
[cpg]


[OnName num="yuuki"]
"...... Akira, you are beautiful.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira120"]
[OnName num="akira"]
"Thank you, but did you stop me today to compliment me?"
[cpg cn=true]


Certainly not. I have to say it right. My mouth is going dry.
[cpg]


[OnName num="yuuki"]
“I've been ...... well, you know, ......"
[cpg cn=true]


I had a hard time telling her. After all, I was dealing with a married woman.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Akira121"]
[OnName num="akira"]
"Ahah, it's like you're trying to confess your feelings for me.”
[cpg cn=true]


She says directly. No, this is ......
[cpg]


Does this mean that I got her permission to confess? I think it might be.
[cpg]


[OnName num="yuuki"]
"I like you ....... Akira.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Akira122"]
[OnName num="akira"]
“Thank you, I like you too.”
[cpg cn=true]


[OnName num="yuuki"]
“I know you have a husband ...... but I ……”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Akira123"]
[OnName num="akira"]
“I understand what you’re trying to say. I'll go out with you.”
[cpg cn=true]


[OnName num="yuuki"]
“Huh .......?"
[cpg cn=true]


Akira accepted it more swiftly than I had imagined.
[cpg]


[OnName num="yuuki"]
"Are you sure? You are married."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="sAkira005"]
[OnName num="akira"]
“Yes. So, if that's okay with you I’ll go out with you.”
[cpg cn=true]


She was not going to leave her husband after all.
[cpg]


But I was fine with that.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています
;//========================================
;//●ＣＧ（主人公に迫るヒロイン。背景が変わっています）ev_22
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：私服
;//場所　：公園
;//時間　：夜
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_21_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sAkira006"]
[OnName num="akira"]
“Don't you want to kiss me?”
[cpg cn=true]


Unable to resist, I moved closer to her.
[cpg]

It was a moment of a wish fulfilled. But ......
[cpg]

[VOICE f="sAkira007"]
[OnName num="akira"]
“Can you record us making out ...... for a bit? I don't have my phone."
[cpg cn=true]


[OnName num="yuuki"]
“What? Why would you do that?”
[cpg cn=true]


;**【ＣＧ】 ev_21_a ***********************
[CG id=9 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sAkira008"]
[OnName num="akira"]
"It'll be a memory. Send it to me later.”
[cpg cn=true]


……It was a strange request, I felt some strange twinge.
[cpg]

I did not have the courage to say no.
[cpg]



;//移植のためシーンをカットしています

[SE f="se003"]
;//【ＳＥ】『ドア閉まる』


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[OnName num="yuuki"]
"Phew……"
[cpg cn=true]


I sigh involuntarily. I was remembering what happened with Akira.
[cpg]

Why doesn't she just push me away?
[cpg]

The more I think about it, the more confused I get. It's strange, no matter how much things were not going well with her husband.
[cpg]


The order is the other way around. Isn't it normal to at least divorce before you go out with someone else?
[cpg]


I don't know what women are thinking. I don't know ......
[cpg]


I decided to send Akira the video I took with my phone.
[cpg]


She says she has a computer. Another place where I feel the generational gap between us ......
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



I fall asleep again and the evening comes. The birds that wake me up are crows.
[cpg]


I'll have to fix this lifestyle someday. Or so I thought to myself as I headed to school.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura052"]
[OnName num="sakura"]
"Good evening, Yuki.”
[cpg cn=true]


[OnName num="yuuki"]
“Ah, Mrs. Sakura ...... Good evening.”
[cpg cn=true]


I bumped into Sakura near the school. She then asked me a question.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sakura053"]
[OnName num="sakura"]
“You look more like an adult now. Did something happen?”
[cpg cn=true]


[OnName num="yuuki"]
“Is that so ......?"
[cpg cn=true]


;//確かに童貞ではなくなったけど、そんな一朝一夕で変わるものなのだろうか。
I did kiss Akira, but I wonder if one can change overnight like that.
[cpg]


[OnName num="yuuki"]
“I guess you could say that, yeah."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Sakura054"]
[OnName num="sakura"]
“I knew it. Is it Mrs. Akira? I'm jealous. If only I were a little younger...”
[cpg cn=true]


I still can't get used to Sakura mentioning her age, even in passing.
[cpg]


She looks younger than Akira, yet she's married with two children......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



Then, after taking classes at the school, I was on my way home.
[cpg]



[FACE method="change_1" pos="2/3"]
[VOICE f="Akira168"]
[OnName num="akira"]
“Well, I won't see you for a while because tomorrow is Saturday.”
[cpg cn=true]


[OnName num="yuuki"]
"...... I don’t mind. I'm usually free on holidays.”
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Akira169"]
[OnName num="akira"]
“Does that mean you want to come see me?”
[cpg cn=true]


I couldn't immediately affirm it, but I thought it would be strange to remain silent.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Akira170"]
[OnName num="akira"]
“My husband won't be home until late, so you can come over if you'd like.”
[cpg cn=true]


[OnName num="yuuki"]
“That's...I mean, what if he comes home early?”
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Akira171"]
[OnName num="akira"]
“Don't worry. Because, umm......... I don't know if I should tell you.”
[cpg cn=true]


Akira seems to be considering something. But I didn’t know what it was.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



It wasn't until we'd left the building that she explained their situation.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="sAkira009"]
[OnName num="akira"]
"My husband has a...unique fetish... He likes it when I cheat on him.”
[cpg cn=true]


[OnName num="yuuki"]
“What …..”
[cpg cn=true]


I'd heard about it, but I never thought people like that really existed.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira173"]
[OnName num="akira"]
“So, it's not a big deal if he...sees anything. I already told him about you.”
[cpg cn=true]


[OnName num="yuuki"]
“Is that why you wanted the video?”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Akira174"]
[OnName num="akira"]
“That's right. I took it to show him.”
[cpg cn=true]


Apparently, that was also the reason why she first came on to me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="sAkira010"]
[OnName num="akira"]
"......That's the real reason.”
[cpg cn=true]


[OnName num="yuuki"]
"Everything...it was all for this......"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sAkira011"]
[OnName num="akira"]
"Well, it's true that I like you, Yuki. I want you to get to know me better.”
[cpg cn=true]


[OnName num="yuuki"]
"......"
[cpg cn=true]


I have mixed feelings. I understand what she is saying.
[cpg]


I'm sure it's true that she has her husband's blessing. But ......
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Akira177"]
[OnName num="akira"]
"Anyways, you'll drop by tomorrow, right?"
[cpg cn=true]


[OnName num="yuuki"]
"Uh, well, ...... sure."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Akira178"]
[OnName num="akira"]
“You don't know where I live, right? Let's meet around the shopping street.”
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『商店街』（夕方）******************************************************



That Saturday, the shopping street.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
I walked to our meeting point to find Akira already there.
[cpg]


It was my first time seeing Akira in casual wear. A strange situation, considering our night school has no uniform policy......
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Akira179"]
[OnName num="akira"]
“You’re late. You’re really not a morning person, huh. It's pretty much evening, though."
[cpg cn=true]


[OnName num="yuuki"]
“I’m so sorry......."
[cpg cn=true]


We headed to Akira's house while Akira was scolding me.
[cpg]




;//ブラックアウト
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]

[SE f="se003"]
;//【ＳＥ】『ドア開く』


She leads me to her...their room.
[cpg]

I shouldn't be here, but I couldn't bring myself to leave.
[cpg]


;//移植のためシーンをカットしています

[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sAkira012"]
[OnName num="akira"]
“Now, let's ...... kiss.”
[cpg cn=true]


I had reservations despite the circumstances that had led me here.
[cpg]



;//========================================
;//●ＣＧ（主人公にキスを迫った後のヒロイン。笑顔でピースする）ev_24
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_23_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]


But my desires shoved aside such concerns.
[cpg]

[VOICE f="sAkira013"]
[OnName num="akira"]
"You're getting good at kissing. It's not like you had much experience, right?"
[cpg cn=true]


[OnName num="yuuki"]
"...... yes."
[cpg cn=true]


I felt ashamed and embarrassed.
[cpg]

And that's not all, I had mixed feelings.
[cpg]


;//移植のためシーンをカットしています



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira219"]
[OnName num="akira"]
"I'll see you again on Monday then.”
[cpg cn=true]


[OnName num="yuuki"]
“Yes …… See you then."
[cpg cn=true]


I left Akira's house and was about to return to my own house.
[cpg]


The weekends are boring. Everything interesting in my life happens on weekdays.
[cpg]


But today was a good day for me.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se003"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



I went home but had nothing to do.
[cpg]


So I played games until the morning.
[cpg]


This lifestyle means that I don't get to go out with my friends anymore.
[cpg]


I don't have many friends from the start, or rather, I don't have any now ……
[cpg]


But I still have Akira. That's what I thought.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



The next evening. I wake up at the usual time and go to the evening school.
[cpg]


I recalled how hard it used to be for me to even go outside. Having a goal really changes a person.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
With this thought in mind, I was on my way to school. I saw Akira and Sakura talking.
[cpg]


It’s not an unusual combination. Those two had always been good friends.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="sSakura003"]
[OnName num="sakura"]
“Really? Wow, I guess that's one way to spice up a marriage ……."
[cpg cn=true]


An awkward conversation to listen in on. I wondered if Sakura's husband had a unique...personality as well.
[cpg]


I didn't want to get involved, but that didn't stop me from straining my ears trying to pick up what they were talking about.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************



And in class. I sat at my desk and took the class seriously.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuki322"]
[OnName num="natuki"]
“So, with that in mind, we can take this passage to mean this...”
[cpg cn=true]


Mrs. Natsuki was acting like our teacher today. And Akira was acting like a student.
[cpg]


But the two of them are almost the same age.
[cpg]


No matter how many times I think about it, it's still hard to imagine.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


In the meantime, the class was over and it was time to go home.
[cpg]

;//【ＢＧ】『学園教室』（夜）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuki323"]
[OnName num="natuki"]
“Yuki, you're really taking your studies seriously lately.”
[cpg cn=true]


[OnName num="yuuki"]
“Really? I don't feel like I'm doing anything differently……"
[cpg cn=true]


All I did at home was play games, but apparently it seemed different from the teacher's point of view.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Natuki324"]
[OnName num="natuki"]
“Something might have turned into a desire to study. Did you fall in love or something?”
[cpg cn=true]


She was right, but I kept my mouth shut.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[SE f="se014"]
;//【ＳＥ】『歩く』


Then, Akira and I walked together for a while.
[cpg]


[VOICE f="Akira220"]
[OnName num="akira"]
“...... Hey, Yuki. My husband is home now.”
[cpg cn=true]


[OnName num="yuuki"]
“So ......?”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira221"]
[OnName num="akira"]
"Won't you come to my house? My husband wants to meet you.”
[cpg cn=true]


I had trouble understanding what she meant.
[cpg]


What would he do when he saw me?
[cpg]


[OnName num="yuuki"]
“Wait, do you mean ……?”
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="sAkira014"]
[OnName num="akira"]
“He wants to see us making out right in front of him. Are you up for it?”
[cpg cn=true]


I had trouble turning her down. I wanted to be with Akira. But ......
[cpg]


Was this the right thing to do? Apparently her husband approved, but...
[cpg]


I felt like I'd come to a line I shouldn't cross.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira223"]
[OnName num="akira"]
“You don’t mind do you? Let’s show him.”
[cpg cn=true]


Let's show him. I couldn't tell if she was thinking of me or her husband.
[cpg]


I couldn't tell. But eventually ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se003"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



I found myself standing in front of her husband.
[cpg]


[OnName num="husband_of_akira"]
"It's nice to meet you. Please, come in.”
[cpg cn=true]


[OnName num="yuuki"]
“Hi, uh...thanks......."
[cpg cn=true]


I didn't know what to say.
[cpg]


He didn't match Akira at all. It wasn't about his looks.
[cpg]


It's about age. He looked like he was well over 30, but how old is Akira?
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sAkira015"]
[OnName num="akira"]
“How long are you going to stand there, come on in.”
[cpg cn=true]


[OnName num="yuuki"]
“Are you sure……?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="sAkira016"]
[OnName num="akira"]
“Don't worry about it.”
[cpg cn=true]


She practically drags me into their home.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



There wasn't much for the three of us to talk about.
[cpg]


I recall being impressed by the way her husband explained his fetish in such a frank manner.
[cpg]


He seemed almost excited at the prospect of his wife and I forming a romantic relationship.
[cpg]


Despite all of this, I still had my doubts. Was this really happening?
[cpg]

;//移植のためシーンをカットしています

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sAkira017"]
[OnName num="akira"]
“You seem nervous. There's no need to be so reserved.”
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="sAkira018"]
[OnName num="akira"]
“Hold me…..  I'm kind of in the mood for it.”
[cpg cn=true]


;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


I know this is crazy, but I can't stop.
[cpg]

I think. I wonder who Akira belongs to.
[cpg]


If she falls in love with me then, could I be with her ......?
[cpg]


I can't help but have such expectations. Even though I know it's impossible.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira265"]
[OnName num="akira"]
“Thanks for today. See you at the academy."
[cpg cn=true]


[OnName num="yuuki"]
“Yes ……  see you later.”
[cpg cn=true]


I said goodbye to Akira and went back to my house.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Then a few days pass. Akira started to say strange things.
[cpg]

[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sAkira019"]
[OnName num="akira"]
“I wonder if it is okay to say this …… but I have to.”
[cpg cn=true]


Akira was stammering.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sAkira020"]
[OnName num="akira"]
“Look. I'm pregnant.”
[cpg cn=true]


[OnName num="yuuki"]
“……."
[cpg cn=true]


I was flustered. Whose baby is it?
[cpg]


[OnName num="yuuki"]
"Whose baby is it, ......?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sAkira021"]
[OnName num="akira"]
“I'm not sure.”
[cpg cn=true]


She says lightly, but it's a big deal.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



On the way home. I was walking with Sakura.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Sakura056"]
[OnName num="sakura"]
“Oh wow ...... Akira is pregnant."
[cpg cn=true]


[OnName num="yuuki"]
“......I guess that means she was just playing around using me after all."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Sakura057"]
[OnName num="sakura"]
“It's not really my place to guess, but......"
[cpg cn=true]


After a pause, she continues on.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sakura058"]
[OnName num="sakura"]
“I don’t think she intends to neglect you.”
[cpg cn=true]


I'd like to think so. But I ….
[cpg]


On the contrary, I felt heartbroken.
[cpg]


It was just a return to our original relationship. Still, that's how I felt ……
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]

More days pass. Spring was about to turn into summer.
[cpg]


Akira's stomach was getting bigger.
[cpg]


[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]

;//【ＢＧ】『学園教室』（夕方）******************************************************



Our classmates didn't say anything about her pregnancy.
[cpg]


That was normal in this type of school.
[cpg]


If someone got pregnant in a normal school, it would be a big deal. But ......
[cpg]


It's not that unusual here.
[cpg]


Even if it is unusual, people don't mention it.
[cpg]


That was also hard. I felt like everyone was ignoring it, even though it was a big deal to me.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************



Then, after school in the classroom. No one was there but me and Akira.
[cpg]


I asked Akira again,
[cpg]


[OnName num="yuuki"]
“Akira...... are we over?”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Akira270"]
[OnName num="akira"]
“I never said anything like that. You can still love me.”
[cpg cn=true]


I could hardly believe my ears...
[cpg]

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



More time passes. It was early summer and then summer was in full swing.
[cpg]


Even at our school, there is a summer vacation.
[cpg]


I was about to run out of things to do, but Akira and I had exchanged contact information.
[cpg]


After all, her husband had given his blessing. I guess he is still her first priority though.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuki325"]
[OnName num="natuki"]
“Oh, …… Yuki.”
[cpg cn=true]


[OnName num="yuuki"]
“Mrs. Natsuki, are you on your way back home ......?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Natuki326"]
[OnName num="natuki"]
“Yes, I am. With this job, I get home late."
[cpg cn=true]


[OnName num="yuuki"]
“Do you...... Do ...... You ..…”
[cpg cn=true]


I wanted to ask hersomething.
[cpg]


She is also married. I might be able to get some important information out of her.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Natuki327"]
[OnName num="natuki"]
"You don't look well ...... are you all right?"
[cpg cn=true]


[OnName num="yuuki"]
“I'm fine. Don't worry.”
[cpg cn=true]


But I couldn't ask her anything.
[cpg]


I was afraid to that she would say that her husband is the most important thing in her life ......
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



Later that day, I called Akira.
[cpg]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]

[OnName num="yuuki"]
"Oh, um, this is Yuki ......."
[cpg cn=true]


;//[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sAkira022"]
[OnName num="akira"]
“Oh, Yuki. What's wrong? Did you miss me?”
[cpg cn=true]


Akira can see through everything. I told her I missed her.
[cpg]


[OnName num="yuuki"]
"...... Yes, um, is there a convenient day for you or something ……"
[cpg cn=true]


;//[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akira290"]
[OnName num="akira"]
“How about tomorrow? It's summer vacation, we both have free time, right?”
[cpg cn=true]


The distance between us is so close, yet so far ......
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『商店街』（夜）******************************************************



I met up with her in the shopping district. Akira was wearing her casual clothes.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira291"]
[OnName num="akira"]
“Sorry for making you wait. Let's go then."
[cpg cn=true]


[OnName num="yuuki"]
"Um, ...... Akira."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Akira292"]
[OnName num="akira"]
“What? Are you that curious about whose kid it is?”
[cpg cn=true]


[OnName num="yuuki"]
"...... Yes."
[cpg cn=true]


Akira didn't even laugh. She just looked straight ahead.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Akira293"]
[OnName num="akira"]
"Whether it's yours or not, it's me and my husband who will raise it.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Akira294"]
[OnName num="akira"]
“You're probably not ready to step in between us, are you?"
[cpg cn=true]


…… I didn’t. That was for sure ……
[cpg]


I don't want to take away Akira from her husband.
[cpg]


So this was the best possible outcome for me.
[cpg]


[SE f="se014"]
;//【ＳＥ】『歩く』

;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************


[OnName num="yuuki"]
"...... Akira, you just won’t leave your husband for me would you?”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Akira315"]
[OnName num="akira"]
“I don't know. I'm trying to be yours in my own way, Yuki.”
[cpg cn=true]


[OnName num="yuuki"]
“But you love your ...... husband more, don't you?”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sAkira023"]
[OnName num="akira"]
“Well yeah. I love him.”
[cpg cn=true]


Then she continued.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="sAkira024"]
[OnName num="akira"]
“Of course, I love you, too, Yuki. I trust you.”
[cpg cn=true]


[OnName num="yuuki"]
"......"
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


In the end, the matter was never settled
[cpg]


There may be no winners and losers. There might not even be a draw .......
[cpg]

;//========================================
;//●ＣＧ非エロ（画面の中に映るかつて録画したヒロインの姿。それを見ている主人公）ev_29
;//人物１：ヒロイン２
;//服装１：制服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]


I don't think I'll ever know who the child's father is.
[cpg]


But whether it's my child or her husband's child, nothing would change.
[cpg]


I understand that. I can't break into their relationship.
[cpg]


Right now, I'm just feeling alone, with that feeling dawning on me ......
[cpg]

I was thinking about her.
[cpg]



;//ＥＮＤ：ヒロイン２ルート
[SCENE id=11]

[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
