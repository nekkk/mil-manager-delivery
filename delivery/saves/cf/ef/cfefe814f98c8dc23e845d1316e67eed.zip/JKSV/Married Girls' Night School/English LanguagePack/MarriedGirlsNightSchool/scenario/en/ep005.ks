
*start

;//==============================
;//１、先生

;#################################################
*Ep005|I want to become close with Mrs. Natsuki.
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

*select04_1|I want to become close with Mrs. Natsuki.

[SCENE id=5]


After everything's said and done, I want to become close with my teacher.
[cpg]


Of course, she is married and even has a child.
[cpg]


I didn't have any intention of destroying her relationship, but I could no longer ignore my feelings.
[cpg]




;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se014"]
;//【ＳＥ】『歩く』



On the way to the school after a holiday. I meet Sakura.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura045"]
[OnName num="sakura"]
"......You look different. You look like you're over it.”
[cpg cn=true]


[OnName num="yuuki"]
“Really ......?"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sakura046"]
[OnName num="sakura"]
“I think you look better now, though you can't rely on what an old woman says.”
[cpg cn=true]


[OnName num="yuuki"]
"......"
[cpg cn=true]


Have I changed that much? Maybe I have.
[cpg]


After all, I've made up my mind to confess to Mrs. Natsuki.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



I reach the school and take my classes seriously.
[cpg]


I needed to be alone with her. So, I stayed at the school for a while after class.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuki103"]
[OnName num="natuki"]
“Is there something wrong? You can go home now.”
[cpg cn=true]


[OnName num="yuuki"]
“Umm, it's ……"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Natuki104"]
[OnName num="natuki"]
“Or are you expecting something?”, she chuckles.
[cpg cn=true]


I was. But what I needed to say had nothing to do with that.
[cpg]


The other students leave and eventually it's just the two of us.
[cpg]


[OnName num="yuuki"]
"...... Mrs. Natsuki. I like you."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Natuki105"]
[OnName num="natuki"]
“Thank you for that. As a teacher, I'm very happy to hear that.”
[cpg cn=true]


I guess this doesn't get the message across. Then, I’ll say something else.
[cpg]


[OnName num="yuuki"]
"No, it's not that. I love ....... I'm in love with you.”
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

[OnName num="yuuki"]
"Think of it as a confession. I don't intend to leave without hearing your answer.”
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

She seemed a little surprised. But then she laughed.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Natuki106"]
[OnName num="natuki"]
"When you're a ...... teacher, sometimes you don't know what your students are thinking."
[cpg cn=true]


[OnName num="yuuki"]
“What I'm thinking is exactly what I told you.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Natuki107"]
[OnName num="natuki"]
“Even so, I have a husband. But ......"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]

Your courage deserves a straight answer, she said.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



She then told me to wait until she'd finished work.
[cpg]


I obeyed and waited for the teacher to come out.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuki108"]
[OnName num="natuki"]
"I'm sorry for making you wait. Shall we go then?"
[cpg cn=true]


[OnName num="yuuki"]
“Yes ….”
[cpg cn=true]



;//ブラックアウト

[SE f="se014"]
;//【ＳＥ】『歩く』


After a short walk, I was taken to a certain place.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************

In the park, between the bushes, where people wouldn't find us.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Natuki109"]
[OnName num="natuki"]
“I don't do this with just anyone.”
[cpg cn=true]


[OnName num="yuuki"]
“...... okay.”
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Natuki110"]
[OnName num="natuki"]
“I have known you for a long time ...... and above all, you told me that you like me.”
[cpg cn=true]


[OnName num="yuuki"]
“I know. Well, you know, ……."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]

She moves closer to me. I can feel her breath on my face.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
;//ブラックアウト


And we kissed.
[cpg]

The situation was beyond the taboo of teacher and student. Beyond the taboo of being with a married woman .......
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

After that, we talked a little.
[cpg]

I was kind of flustered, and I don't even remember what I said.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[FACE method="bow_1" pos="2/3"]
[VOICE f="Natuki151"]
[OnName num="natuki"]
“Well, I'll see you later. You know we can't go back to what our relationship used to be right?”
[cpg cn=true]


[OnName num="yuuki"]
“I know ...... But I really like you.”
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]

Then that's good, she said, laughing.
[cpg]


…… My mind is filled with thoughts about her. How I could make her happy. How we could be together.
[cpg]


But I have no idea what to do to achieve that.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



Night turns into morning again, and while I'm sleeping, evening comes.
[cpg]


And when night falls, school begins. I see her just as before.
[cpg]


During class, she pretends that nothing happened with me.
[cpg]


It makes me feel that what happened was just a dream or an illusion.
[cpg]


Then, at the end of class: ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura047"]
[OnName num="sakura"]
"I wonder what happened to Mrs. Natsuki.”
[cpg cn=true]


Sakura spoke to me.
[cpg]


[OnName num="yuuki"]
“What ...... I didn't do anything.”
[cpg cn=true]


I answered as quickly as I could, but apparently it was a different story.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Sakura048"]
[OnName num="sakura"]
“What? I saying that, Mrs. Natsuki looks kind of depressed.”
[cpg cn=true]


[OnName num="yuuki"]
“..... Oh ......"
[cpg cn=true]


Maybe so. Even I could tell that she looked troubled.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se014"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『商店街』（夜）******************************************************



The truth is, I didn't know what was really going on that day.
[cpg]


I was walking along my usual walking course.
[cpg]


[OnName num="yuuki"]
"...... hmm..."
[cpg cn=true]


Mrs. Natsuki was unhappy. Maybe it was about her husband.
[cpg]


But I'm not the type of person who can ask such a thing so openly.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I went to my room to think alone.
[cpg]


Suppose she is on the verge of divorce.
[cpg]


What would I do if she divorced?
[cpg]


Would I be able to say without hesitation that I want to be with her?
[cpg]


If I couldn’t make up my mind, then there was no point in confessing.
[cpg]


With that thought in mind, I drifted off to sleep, as it was about to be morning.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



I wake up the next evening. The usual days begin.
[cpg]


But I also knew that my relationship with my teacher could not continue.
[cpg]


An affair with a married woman. I know that I can't stay in such a  relationship forever.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



I arrived at the school and went to class.
[cpg]


Mrs. Natsuki seemed to be a little down. Homeroom was over.
[cpg]



[SE f="se001"]
;//【ＳＥ】『学園のチャイム』
[WAIT time=1000]


After all the students had left. I asked her,
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=1000]

[OnName num="yuuki"]
"...... Are you doing alright? You look depressed.”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Natuki152"]
[OnName num="natuki"]
“What? Do I?”
[cpg cn=true]


She sighs a little as she says so. She’s not even trying to hide it.
[cpg]


[OnName num="yuuki"]
“If there's anything I can do, I'll do it. Just tell me."
[cpg cn=true]

Even though I said that, she just kept her eyes down.
[cpg]
;//ブラックアウト

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


Little by little, the days pass by.
[cpg]


I don't really go out during day, but I guess it's getting warmer.
[cpg]


The temperature at night is also changing little by little. The temperature becomes lukewarm.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[OnName num="yuuki"]
“I think it's time to go home and go to bed ……"
[cpg cn=true]


I was tired of walking and tired of playing games.
[cpg]


All I could think about was Mrs. Natsuki.
[cpg]


How could I support her?
[cpg]


I wanted to help her more than I wanted a relationship with her.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



At the end of the evening, I head to the school. As soon as we finish lunch, we go to class.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Akira111"]
[OnName num="akira"]
“Yuki, you look like a girl in love.”
[cpg cn=true]


[OnName num="yuuki"]
“I can understand ‘in love’ but I’m not a girl.”
[cpg cn=true]


[FACE method="shake_2" pos="2/5"]
[VOICE f="Akira112"]
[OnName num="akira"]
"Maybe, but you have feminine features.”
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Sakura049"]
[OnName num="sakura"]
“He does, doesn't he?”
[cpg cn=true]


It's the first time I've been told that. I wonder if the difference in age compensates for it.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************


While I was thinking about that, all the classes ended.
[cpg]


I started to stay in the classroom later and later each night.
[cpg]


And the same goes for the teacher. I think everyone around us might have noticed that there's something between us.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuki172"]
[OnName num="natuki"]
"...... You're always the last one to leave, aren't you?”
[cpg cn=true]


[OnName num="yuuki"]
“I feel like you want me to.”
[cpg cn=true]


I say something a little self-obsessed like that.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Natuki173"]
[OnName num="natuki"]
"You understand me well, don't you? You really like me ……"
[cpg cn=true]


She took it that way. It made me happy, too.
[cpg]



;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************


I think this whole thing started out with her helping me get back on my feet. But our relationship has gone beyond that.
[cpg]

Then something disturbing caught my eye.
[cpg]

I saw what looked like bruises on her body.
[cpg]



[OnName num="yuuki"]
“Hey …… what happened there?”
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

I felt like I shouldn't ask, but I had to know.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Natuki192"]
[OnName num="natuki"]
“It's nothing. I'm fine.”
[cpg cn=true]


[OnName num="yuuki"]
“I wouldn't call that nothing...”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Natuki193"]
[OnName num="natuki"]
"...... don't worry about it."
[cpg cn=true]


She was shutting me out. I asked her more probing questions.
[cpg]


[OnName num="yuuki"]
“If someone I care about is hurt, I'm going to worry.”
[cpg cn=true]


She looked troubled. But ......
[cpg]


She was silent for a while and then told me the truth.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Natuki194"]
[OnName num="natuki"]
“My husband...hits me.”
[cpg cn=true]


[OnName num="yuuki"]
“You mean domestic violence? Why do you stay with such a person?”
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Natuki195"]
[OnName num="natuki"]
“I have a young child. If we get divorced, I can't raise it by myself.”
[cpg cn=true]


[OnName num="yuuki"]
“Oh, no ……"
[cpg cn=true]


I wasn't in a position to help her...
[cpg]


Frustrated and powerless to do anything, my mind spiralled.
[cpg]


I felt totally helpless...
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


I had to think.
[cpg]


How far could I afford to go? I couldn't just leave her like this.
[cpg]


[OnName num="yuuki"]
“......"
[cpg cn=true]


And I had decided. If I couldn't leave her be, then I had to do something.
[cpg]


I'd confessed my feelings for her, I could tell her anything.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



Night turns into morning. It's time for me to sleep.
[cpg]


I had already decided what to say to her.
[cpg]


But I had to think about what words to use.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



Eventually I was able to say it the next holiday. When I bumped into her.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuki196"]
[OnName num="natuki"]
“Oh …… Yuki.”
[cpg cn=true]


[OnName num="yuuki"]
"......It's a coincidence, isn't it? Are you going out somewhere?”
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Natuki197"]
[OnName num="natuki"]
“No. I just came back.”
[cpg cn=true]


We are neighbors. This kind of thing happens.
[cpg]


And I thought now was the time to say it. I had a feeling we were going to keep it more casual at school.
[cpg]


[OnName num="yuuki"]
“I'm thinking of getting a job right after I graduate ……."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Natuki198"]
[OnName num="natuki"]
“That's sudden, what made you decide that...?”
[cpg cn=true]


[OnName num="yuuki"]
“I want to do what I can to help you. If you can't raise you child by yourself, I'll step in."
[cpg cn=true]


This is like saying, in a roundabout way, that she should get a divorce.
[cpg]


But I didn't know what else to tell her.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Natuki199"]
[OnName num="natuki"]
“Oh. When you say things like this,...... I don't even know how to respond."
[cpg cn=true]


She sounded a little tearful.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Natuki200"]
[OnName num="natuki"]
“Come with me. My husband won't be home for a while.”
[cpg cn=true]


[OnName num="yuuki"]
"Oh, ...... why?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Natuki201"]
[OnName num="natuki"]
“He's working on his day off. He is busy as well.”
[cpg cn=true]


She grabs my hand and leads me down the street.
[cpg]


We reach her house.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



When I came home, I saw her child for the first time.
[cpg]


If she gets a divorce and marries me ...... this child will be my child.
[cpg]


It would take a lot...perhaps more than I had to give.
[cpg]


Even still, I was determined to take on this huge responsibility.
[cpg]

;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se003"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



And I left her house.
[cpg]


If I ran into her husband, we might come to blows.
[cpg]


I didn't want that either. I was willing to do anything to keep her from suffering a moment longer.
[cpg]


It's a struggle. It's not about who's right or wrong.
[cpg]


If it comes down to right and wrong, I'm probably better off doing nothing.
[cpg]


Just wait for Mrs. Natsuki to act on her own. That's probably the best thing to do.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


The holiday passed. It's going by quickly ...... And soon Monday will come again.
[cpg]


[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

Akira is staring at a female student on her phone.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Akira113"]
[OnName num="akira"]
"Hmmm, young girls these days play with these things ……."
[cpg cn=true]


[OnName num="female_student"]
“Yes …… but you look young too, Mrs. Akira.”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Akira114"]
[OnName num="akira"]
“Me? Not at all. But I'm flattered.”
[cpg cn=true]


It was hard to think of her as old.
[cpg]

[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Sakura050"]
[OnName num="sakura"]
"What is it? Can I join in on the conversation?"
[cpg cn=true]


Sakura and Akira are the same as ever. The only person with a shadow is on their face is...
[cpg]

[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuki220"]
[OnName num="natuki"]
“……”
[cpg cn=true]


Only Mrs. Natsuki. After school, she sighs without doing anything.
[cpg]


I think she's seriously wondering if she should get a divorce or not.
[cpg]


[OnName num="yuuki"]
“Hey ......are things alright at home?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Natuki221"]
[OnName num="natuki"]
“Oh, Yuki. Well, you already know, don't you?”
[cpg cn=true]


She was right. I guess it was not the right way to approach her.
[cpg]


[OnName num="yuuki"]
“I'm ...... always on your side.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Natuki222"]
[OnName num="natuki"]
"Thank you, ......."
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Natuki223"]
[OnName num="natuki"]
“I'm still on the fence about this ……. Divorce is a big deal.”
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Natuki224"]
[OnName num="natuki"]
"It's not like can just end a marriage because you aren't compatible.”
[cpg cn=true]


[OnName num="yuuki"]
“But, in your case, it's escalated to domestic violence...”
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Natuki225"]
[OnName num="natuki"]
“…..Yes, that's true, but .…”
[cpg cn=true]


;//ブラックアウト
;//移植のためシーンをカットしています

[OnName num="yuuki"]
“Is he still hurting you?”
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Natuki243"]
[OnName num="natuki"]
"...... Yes, nothing's really changed.”
[cpg cn=true]


This was becoming normal for her. I had to do something to help her.
[cpg]


But what, exactly, could I even do?
[cpg]


It's not like I could support her financially.
[cpg]


I'm planning to get a job right after I finish school ......
[cpg]


But how could I ask her to put her faith in me when I had no way to back up my words.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************


As we were walking together, we came to a park.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Natuki268"]
[OnName num="natuki"]
"I've made up my mind. After all, I can't go on like this, can I?”
[cpg cn=true]


[OnName num="yuuki"]
"What have you decided ......?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sNatuki011"]
[OnName num="natuki"]
“If can't continue on like this, something's got to give. My relationship with you isn't exactly healthy, either.”
[cpg cn=true]


Her mind seemed to be stressed out.
[cpg]


Not only is she not getting along with her husband, but she is getting abused.
[cpg]


She told me that it was wrong of her to keep me as company to relieve her stress.
[cpg]


[OnName num="yuuki"]
“It's not wrong…..”
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="sNatuki012"]
[OnName num="natuki"]
“It's wrong."
[cpg cn=true]


I considered the worst case scenario, which was that the relationship would end.
[cpg]


However, I later learned that she had the opposite in mind.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



She had divorced shortly after.
[cpg]


She was going to continue teaching while raising her child on her own.
[cpg]


She said she was going to use her savings to hire a babysitter for a while ......
[cpg]


In the end, I never once met her husband.
[cpg]


If we had met, I had something to say.
[cpg]


But if I met him, I might not have been able to say anything.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『商店街』（夕方）******************************************************



Today is a holiday. While walking around town at random, I met her in her daily clothing.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuki271"]
[OnName num="natuki"]
"Ah, Yuki ……."
[cpg cn=true]


[OnName num="yuuki"]
“Hi ......."
[cpg cn=true]


She’s come this far. She is divorced.
[cpg]


I don't think she’ll be alone forever.
[cpg]


Or rather, I can’t be alone forever. That's why I'm going to marry her.
[cpg]


The question was if she'd let me.
[cpg]


[OnName num="yuuki"]
"......I have something I want to talk to you about.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Natuki272"]
[OnName num="natuki"]
“Me too. Shall we go to the park?”
[cpg cn=true]




[SE f="se014"]
;//【ＳＥ】『歩く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夕方）******************************************************



We came to the park and we both shared an indescribable look.
[cpg]


She wasn't smiling, but she looked happier than when she was married.
[cpg]


We were both nervous. It was like we couldn't look at each other.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Natuki273"]
[OnName num="natuki"]
“You know. Umm ......"
[cpg cn=true]


She looked nervous to the extent where my heart filled with anticipation.
[cpg]


[OnName num="yuuki"]
“Yes.”
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Natuki274"]
[OnName num="natuki"]
“I'm seriously relying on you, Yuki.”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Natuki275"]
[OnName num="natuki"]
“It's impossible for me to raise a child while working on my own.”
[cpg cn=true]


I wonder if she thinks that I might not marry her.
[cpg]


There is an age difference between us. It's natural to feel a little uneasy.
[cpg]


[OnName num="yuuki"]
“Please wait just a little longer. I'll do whatever I can to support you.”
[cpg cn=true]


[OnName num="yuuki"]
“Just let me get a job first, then I can finally propose."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Natuki276"]
[OnName num="natuki"]
"......Yes, you're right."
[cpg cn=true]


;//ブラックアウト
;//========================================
;//●ＣＧ（主人公に抱きしめられるヒロイン）ev_18
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：公園
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


It's not like the silence became unbearable or anything. I held her tight.
[cpg]

[VOICE f="sNatuki013"]
[OnName num="natuki"]
“Yuki, you have become reliable, haven't you?”
[cpg cn=true]


[OnName num="yuuki"]
“I don't think so. Even now, I wonder what I should do.”
[cpg cn=true]


[VOICE f="sNatuki014"]
[OnName num="natuki"]
“I'm happy though.”
[cpg cn=true]


Her words seemed to save me.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



The first thing I had to do was to fix my lifestyle.
[cpg]


Of course, I had already decided to graduate from this school.
[cpg]


There was no point in changing schools now. With that in mind, I managed to return to a normal lifestyle.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



It wasn't easy, and there were times when I had to see a doctor ......
[cpg]


But I gradually got better. I managed to get my body to move during the day.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



I took my classes at the school seriously.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Akira115"]
[OnName num="akira"]
“Hey, Yuki. I heard you're going to marry the teacher after graduation?"
[cpg cn=true]


[OnName num="yuuki"]
"Who told you that?”
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Sakura051"]
[OnName num="sakura"]
"It doesn't matter who told me, does it? I wish you all the best.”
[cpg cn=true]


Everyone around me congratulated me. I am a lucky man ......
[cpg]



[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************



Time flew by. Time flew by as I took classes while looking for a place to work.
[cpg]


Ms. Natsuki was single during that time. Her child is growing up, of course.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



And ...... After a long time, I was about to graduate from the school.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuki297"]
[OnName num="natuki"]
“..... Are you sure you want to do this?”
[cpg cn=true]


[OnName num="yuuki"]
“You are questioning me now? I don't want to be with anyone but you.”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Natuki298"]
[OnName num="natuki"]
"Hmmm. You'll have to change the way you call me when you graduate.”
[cpg cn=true]


[OnName num="yuuki"]
“I guess so. I want to be able to feel more closer to you.”
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Natuki299"]
[OnName num="natuki"]
“I'm sure you're right. Then, why don't you call me by my name?”
[cpg cn=true]


That was so out of the blue that it took me a moment to get used to.
[cpg]


[OnName num="yuuki"]
"...... Ms. Natsuki ..…”
[cpg cn=true]


I added  “Ms.” out of habit and she laughed.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Natuki300"]
[OnName num="natuki"]
“That's fine for now. Someday, I want you to call me Natsuki.”
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



After graduating from the school, I married Natsuki ...... 
[cpg]


I became the father of a child, albeit a stepfather.
[cpg]


My parents were free-spirited people, so they accepted the situation.
[cpg]


They were happy to have their first grandchild ...... That's a good thing, I guess.
[cpg]


I thought it was strange, but I decided to enjoy my new life with Natsuki.
[cpg]




[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



Natsuki moved in with me.
[cpg]


She gets along well with my Mom and my Dad.
[cpg]


We were a little short on the number of rooms, though. ......
[cpg]


We got by, using the room my grandparent once used, before they passed away.
[cpg]


Now we are in a strange situation where I finished with work and Natsuki's job was about to start.
[cpg]


Our free time rarely overlapped. But it couldn't be helped.
[cpg]


Mrs. Natsuki still wanted to continue teaching at the evening school.
[cpg]

;//移植のためシーンをカットしています

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



Sometimes it was a good thing that our free time did not overlap.
[cpg]


We split our time between childcare and work in half. Either one of us would always have time for the child.
[cpg]


It wasn't the right time to explain the situation.
[cpg]


But the day will come.
[cpg]



;//========================================
;//●ＣＧ非エロ（玄関から出ながら、半分振り返って主人公に手を振るヒロイン）ev_20
;//人物１：ヒロイン１
;//服装１：スーツ
;//場所　：主人公の家玄関
;//時間　：夕方
;//備考　：本編から三年経過しています
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]




It was a day when I finished work a little early. It was right when Natsuki was about to leave for work.
[cpg]



[VOICE f="Natuki319"]
[OnName num="natuki"]
“I'm off then, my dear”
[cpg cn=true]


When she said “my dear”, I got nervous.
[cpg]


[OnName num="yuuki"]
“See you, Natsuki.”
[cpg cn=true]



[VOICE f="Natuki320"]
[OnName num="natuki"]
"Hmmm... You could at least say ‘my love’.”
[cpg cn=true]


[OnName num="yuuki"]
“I can't do that. ...... I'm not fully an adult yet."
[cpg cn=true]



[VOICE f="Natuki321"]
[OnName num="natuki"]
“I guess it’s time to grow up then. You are already a father.”
[cpg cn=true]


She was right. I have to grow up.
[cpg]


It's different from when I was a “shut-in”, thinking that I'd always be a kid.
[cpg]


I need to grow up. I'm past the point of just letting someone else take care of me and support me.
[cpg]


From now on, I hope I can be the kind of person who can support Natsuki.
[cpg]



;//ＥＮＤ：ヒロイン１ルート
[SCENE id=10]


[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
