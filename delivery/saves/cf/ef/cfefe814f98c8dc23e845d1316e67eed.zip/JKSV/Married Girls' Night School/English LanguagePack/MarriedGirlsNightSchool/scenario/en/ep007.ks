
*start

;//==============================
;//３、咲良さん

;#################################################
*Ep007|Sakura, a mother of two
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


*select04_3|Sakura, a mother of two

[SCENE id=7]


Sakura. I couldn't help but wonder about her.
[cpg]


She looks so young that it's hard to believe that she's a mother of two...
[cpg]


If anything, she looks almost childish.
[cpg]


Akira didn't look her age, but Sakura took that to the extreme.
[cpg]


I was becoming attracted to her ......
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se014"]
;//【ＳＥ】『歩く』


After the holiday, I headed to school. On the way, I bumped into Akira.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sAkira025"]
[OnName num="akira"]
”Good evening. What's up with you?"
[cpg cn=true]


[OnName num="yuuki"]
"...What do you mean?"　
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="sAkira026"]
[OnName num="akira"]
“Hmm, you just seem less...nervous than usual?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sAkira027"]
[OnName num="akira"]
“Did you fall in love with someone else or something?"
[cpg cn=true]


[OnName num="yuuki"]
“How...how did you know?”
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
Akira laughs. And then...
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira321"]
[OnName num="akira"]
“Oh really? I was just trying to trick you."
[cpg cn=true]


I walked into that one, but at least I didn't say who it was.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



End of class. Even the teacher, who must have heard it from Akira, came up to me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Natuki328"]
[OnName num="natuki"]
"I heard. I heard you are in love, Yuki."
[cpg cn=true]


[OnName num="yuuki"]
“...... Really Mrs. Natsuki?”
[cpg cn=true]

[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]

[VOICE f="Sakura059"]
[OnName num="sakura"]
“I'm curious too. I wonder who it is.”
[cpg cn=true]


Akira and Sakura were also there.
[cpg]


The men in my class, both from my generation and older looked at me in envy……Or so I imagined.
[cpg]


They were all married women. Screw it, I'm going to just be open and say it.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Akira322"]
[OnName num="akira"]
"Come on, tell me, if it isn't me, who is it? Mrs. Natsuki?”
[cpg cn=true]


[OnName num="yuuki"]
“……I...like Mrs. Sakura."
[cpg cn=true]

[FACE method="shock_5" pos="1/3"]
[FACE method="shock_5" pos="2/3"]
[FACE method="change_6" pos="3/3"]

There was silence for a moment. Then Mrs. Sakura, the person in question, opened her mouth.
[cpg]


[FACE method="shake_6" pos="3/3"]
[VOICE f="Sakura060"]
[OnName num="sakura"]
“Oh, my. Oh, dear."
[cpg cn=true]


Her cheeks are red. She really doesn't look like a mother of two right now.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Akira323"]
[OnName num="akira"]
“I see …… I guess it can't be helped if it’s Mrs. Sakura.”
[cpg cn=true]


I wonder what she means by that. I thought it might be rude, but I kept on speaking.
[cpg]


[OnName num="yuuki"]
"...... Mrs. Sakura. Don’t leave me hanging."
[cpg cn=true]


;//[free time=1000]

;//[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FACE method="shake_7" pos="3/3"]
[VOICE f="Sakura061"]
[OnName num="sakura"]
“Ummm ...... sorry, but I can't be your girlfriend or anything like that …”
[cpg cn=true]


She was right. I'm coming on to her knowing that.
[cpg]


[FACE method="bow_2" pos="3/3"]
[VOICE f="Sakura062"]
[OnName num="sakura"]
“Shall we talk about it later, when we're alone?"
[cpg cn=true]


[OnName num="yuuki"]
"...... Got it."
[cpg cn=true]




[SE f="se014"]
;//【ＳＥ】『歩く』



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



So, we go out to the city. Mrs. Sakura and I were walking together.
[cpg]


I don't know where I'm going, but I kind of follow Sakura.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura063"]
[OnName num="sakura"]
“I have two daughters. I've known my husband for a long time, too. ......"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sSakura004"]
[OnName num="sakura"]
“But I can at least give you some practice in romance.”
[cpg cn=true]


[OnName num="yuuki"]
"...... I know. I'm not talking about getting between you and your husband."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
Sakura nodded as she said, “Right.”
[cpg]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]

Then later on.
[cpg]



[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[window target=false]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


It was at the school again. It was not just the two of us ……
[cpg]


;//【ＢＧ】『学園教室』（夜）******************************************************



Mrs. Natsuki was there. At the end of class, the three of us talk.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Natuki329"]
[OnName num="natuki"]
“Yuki, you like Mrs. Niimi, don't you?"
[cpg cn=true]


[OnName num="yuuki"]
"Yeah, well, why are you asking me that in front of her?”
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Sakura109"]
[OnName num="sakura"]
“Hehe. How embarrassing."
[cpg cn=true]


Mrs. Natsuki seemed to look a little disappointed.
[cpg]


Could it be that she has feelings for me too …… perhaps.
[cpg]


;//確かめようがないな。俺にどの程度好意があったからしていたのか、なんて分からない。
There's no way to be sure.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Natuki330"]
[OnName num="natuki"]
“I hope you will be happy. Don't ever regret it.”
[cpg cn=true]


[OnName num="yuuki"]
“I won't, but ......I just think it's a little much to say that in front of her.”
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************



Then a little more time passed, and it was just me and Sakura.
[cpg]


I was getting ready to go home and sorting through some of my stuff.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura110"]
[OnName num="sakura"]
"It's a smartphone, isn't it? It's so small.”
[cpg cn=true]


[OnName num="yuuki"]
“No ...... this is a walkman."
[cpg cn=true]


Could someone mistake a walkman for a smartphone? It may be unusual in that I use them separately.
[cpg]


There was an obvious generational gap between us.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Sakura111"]
[OnName num="sakura"]
“Smartphones seem so convenient, but ...... I just can't figure out that flick typing thing.”
[cpg cn=true]


She must have grown up with flip phones.
[cpg]


Come to think of it, Akira didn't have a smartphone.
[cpg]


I wonder if this kind of love will ever come to fruition …… She's still a woman from a different generation than I am.
[cpg]


I think it is doubtful whether it will bear fruit.
[cpg]


It's not like I wanted to marry her.
[cpg]


She already has two daughters and a husband, how could I compete?
[cpg]


So what was the goal of our relationship ......?
[cpg]


I asked Sakura.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sSakura005"]
[OnName num="sakura"]
“I don't know either.”
[cpg cn=true]


I know. I may have asked something strange.
[cpg]

;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
;//ブラックアウト

[SE f="se014"]
;//【ＳＥ】『歩く』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



We walked together for a little while.
[cpg]


We were headed in different directions but she had decided to follow me part of the way.
[cpg]





[OnName num="yuuki"]
“Thank you for always coming with me.”
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Sakura154"]
[OnName num="sakura"]
“It's okay. I want to get closer to you, Yuki."
[cpg cn=true]


…… I can't make her my girlfriend even though she thinks this much of me.
[cpg]


I can't even marry her. Still, I kept thinking about her.
[cpg]





[SE f="se003"]
;//【ＳＥ】『ドア閉まる』
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]
;//ブラックアウト

Then I parted with Sakura and went back to my room.
[cpg]


It was almost morning. I was in a state of indescribable, uncontrollable rage.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



Still, after a while I get sleepy. In the morning I naturally want to sleep.
[cpg]


I would see Sakura again the next evening. I went to sleep ...... looking forward to it.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



And again in the evening. My parents are in a good mood these days.
[cpg]


I think it's because I'm getting back into society.
[cpg]


They'd mostly left me to my own devices, but seeing them visibly happier made me feel a little better.
[cpg]


Now if only Sakura were here ....... What a thought.
[cpg]




;//ブラックアウト
[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



Of course, this is just a fantasy.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akira324"]
[OnName num="akira"]
“Did something happen to you? You look a little dejected."
[cpg cn=true]


[OnName num="yuuki"]
“Does it matter?”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Akira325"]
[OnName num="akira"]
"Did Sakura dump you or something? I can't imagine that."
[cpg cn=true]


Akira knows that Sakura won't let go of me.
[cpg]


But I'm sure it's out of compassion, and I'm not the object of her affection.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『商店街』（夜）******************************************************



Then class ended. I parted with Sakura and went out for my usual walk.
[cpg]


Mundane days. If I want to continue this distance, I can probably stay with Sakura forever.
[cpg]


But that's not enough. I want to be the only one for Sakura.
[cpg]


But Sakura's husband probably doesn't even know I exist.
[cpg]


I can't even imagine what he's like, but I doubt he'd be the type to come after me if he'd found out about my relationship with his wife.
[cpg]


In any case, I wanted to meet her husband once.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Then the next day off. I was wandering around the city in the evening.
[cpg]

;//【ＢＧ】『街』（夕方）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura176"]
[OnName num="sakura"]
"Oh, Yuki."
[cpg cn=true]


[OnName num="yuuki"]
“Hey ...... what a coincidence."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Sakura177"]
[OnName num="sakura"]
“No kidding. But then again, we're going to the same school so we probably live closer than we think.”
[cpg cn=true]


Sakura was holding a bag in each hand.
[cpg]


[OnName num="yuuki"]
“Are you on your way home from the grocery store or something?"
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Sakura178"]
[OnName num="sakura"]
“Oh yes, we're a big family so there's plenty of mouths to feed.”
[cpg cn=true]


Right. Sakura already has a family.
[cpg]


I knew about it but ...... I asked,
[cpg]


[OnName num="yuuki"]
“Are you free tonight or something?"
[cpg cn=true]


[FACE method="shake_5" pos="2/3"]
[VOICE f="Sakura179"]
[OnName num="sakura"]
“What? I don’t have any errands, but …….”
[cpg cn=true]


[OnName num="yuuki"]
"If you want, do you want to go out with me. I have something I want to talk to you about."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

Sakura seemed like she had a lot to think about.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura180"]
[OnName num="sakura"]
"Ummm, why not now?"
[cpg cn=true]


[OnName num="yuuki"]
“Not now. I want to be alone with you for a long time."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I think she got my point.
[cpg]


We parted ways with the idea of meeting up in the park afterwards.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Then some time passes and it is completely night.
[cpg]

[window target=false]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura181"]
[OnName num="sakura"]
“Here I am. So, why did you want to meet me?”
[cpg cn=true]


[OnName num="yuuki"]
“I think you know why Mrs. Sakura.”
[cpg cn=true]


I said something like that and Sakura smiled.
[cpg]



;//ブラックアウト
;//========================================
;//●ＣＧ（公園に二人。何か期待しているような表情のヒロイン）ev_35
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：公園
;//時間　：夜
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]

I'm alone with her. I want to be with her more, so I approach her.
[cpg]

[VOICE f="sSakura006"]
[OnName num="sakura"]
“I'm so lucky to be so well-liked.”
[cpg cn=true]


She says that, seeing through my bravado. I could hardly bear to wait any longer.
[cpg]

Would forcing myself on her accomplish anything?
[cpg]

......No, it would have the opposite effect.
[cpg]


;//移植のためシーンをカットしています
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_02_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



;//[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[OnName num="yuuki"]
“...But your husband loves you more?"
[cpg cn=true]


;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura202"]
[OnName num="sakura"]
“Well, …… Of course. I am his wife after all.”
[cpg cn=true]


......Of course.
[cpg]



;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_da"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


;//ブラックアウト

...... Tomorrow is Sunday. I wouldn't be able to see Sakura unless it were by chance.
[cpg]


Still, my feelings for Sakura grew within me.
[cpg]


In the midst of all this, my thoughts take a dark turn. Why couldn't she be mine?
[cpg]


Her husband is not even sleeping with Sakura that often.
[cpg]


And yet ...... Sakura won't be mine.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



I walk around the city aimlessly in the evening, my heart writhing with jealousy.
[cpg]


What happened from here on was really a coincidence.
[cpg]


I hadn't even expected to see her that day.
[cpg]


;//ブラックアウト
;//========================================
;//●ＣＧ非エロ（ヒロイン３とその夫が笑顔で歩いている。住宅街のような場所）ev_36
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：ヒロイン３の夫
;//服装２：私服
;//場所　：街
;//時間　：夕方
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]




[OnName num="yuuki"]
“Oh, Mrs. Sakura ……"
[cpg cn=true]


I saw Sakura in a residential area. But there was also ......
[cpg]


It was Sakura and her husband.
[cpg]


She looked really happy.
[cpg]


I had never seen her like that when she was with me. Oh, why ......
[cpg]


How can you look at him like that, Sakura?
[cpg]



[VOICE f="Sakura203"]
[OnName num="sakura"]
“Oh, Yuki, ...... good evening.”
[cpg cn=true]


[OnName num="yuuki"]
"Are you her husband?”
[cpg cn=true]


[OnName num="husband_of_sakura"]
“Yes, that's me. Er, can I help you?"
[cpg cn=true]


He was a well-kempt man in his late thirties.
[cpg]


He was probably the only one who could make Sakura truly happy. It wasn't hard to imagine.
[cpg]


Still, I couldn't help but say it.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[OnName num="yuuki"]
“…… Why are you so uninterested in Sakura?"
[cpg cn=true]


[OnName num="husband_of_sakura"]
“What are you talking about?"
[cpg cn=true]


[OnName num="yuuki"]
“I won't let you say you don't know. If you were even remotely interested, you'd know what's going on with her and me."
[cpg cn=true]


[OnName num="husband_of_sakura"]
“Are you a classmate at the academy or something?"
[cpg cn=true]


[OnName num="yuuki"]
“Please don't change the subject!”
[cpg cn=true]


I raise my voice as Sakura panics. But Sakura's husband remains calm.
[cpg]


[OnName num="husband_of_sakura"]
“I don't care what Sakura decides to do.”
[cpg cn=true]


[OnName num="yuuki"]
“What ……?"
[cpg cn=true]


[OnName num="husband_of_sakura"]
“I don't know what kind of a relationship you have with Sakura, but I see no reason to feel jealous."
[cpg cn=true]


[OnName num="husband_of_sakura"]
“Sakura and I have built a strong relationship by trusting in each other completely."
[cpg cn=true]


......How could that be? I couldn't believe it.
[cpg]


[SE f="se000"]
;//【ＳＥ】『走る』



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト

I couldn't stand to be there any longer, so I ran away.
[cpg]


I could see Sakura chasing after me. Still, I run.
[cpg]

[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



Sakura follows me for a fair distance. I stop.
[cpg]


[OnName num="yuuki"]
“Please, don't follow me..."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura204"]
[OnName num="sakura"]
“Yuki...you're important to me too."
[cpg cn=true]


[OnName num="yuuki"]
“I get it now. I'll never be special, Mrs. Sakura.”
[cpg cn=true]


[OnName num="yuuki"]
“I'll never be the only one for you. That much is clear.”
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Sakura205"]
[OnName num="sakura"]
“Yuki ......"
[cpg cn=true]


Silence. Nothing I said or did would change anything.
[cpg]


Perhaps there wasn't any room for change from the very beginning.
[cpg]


In the end, it was just me, struggling alone with my emotions.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I went home that day.
[cpg]


I found it awkward to return to school the next day.
[cpg]


But what choice did I have? If I ran away here, I knew I'd never be able to come back.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



At the academy. I didn't dare to talk to Sakura.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akira326"]
[OnName num="akira"]
"Did you have a fight with Mrs. Sakura? You're so easy to read, Yuki.”
[cpg cn=true]


[OnName num="yuuki"]
“Please leave me alone ......."
[cpg cn=true]


After school. Akira teased me.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Akira327"]
[OnName num="akira"]
“You should make up with her. You like Mrs. Sakura, don't you?"
[cpg cn=true]


......Yes. I like Sakura.
[cpg]


Even if I can't be her number one. That's okay.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I chased after Sakura, who had already left.
[cpg]


[OnName num="yuuki"]
“Mr. Sakura ...... Can I have a minute?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sakura206"]
[OnName num="sakura"]
“…… What is it?”
[cpg cn=true]


[OnName num="yuuki"]
“I have a few things to say. Can you please come back to the classroom?"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************



By the time I got back to the classroom, no one was there.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="yuuki"]
“I don't care if I don't become your number one.”
[cpg cn=true]


[OnName num="yuuki"]
"I don't care if ...... everything ends up being a memory. But I still don't want it to end up as a bad memory."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Sakura207"]
[OnName num="sakura"]
“You're so honest. I wish I could have spent my youth like that too.”
[cpg cn=true]


I felt like she was willing to answer, but I didn't ask a question that is looking for some kind of definitive answer either.
[cpg]

;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]

Then a couple of days pass. Quite a few days pass.
[cpg]


Sakura and I never became more than friends.
[cpg]


She told me that she hoped the woman of my dreams would appear for me.
[cpg]


I'm sure that's what it's all about. Sakura was not my destiny.
[cpg]


By giving up on her, everything became clearer.
[cpg]


Specifically, I was slowly getting my day/night routine back on track.
[cpg]


I could even go to a normal school.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=2100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[OnName num="yuuki"]
"Phew......"
[cpg cn=true]


I unfolded my diploma and confirmed that I had graduated from that academy.
[cpg]


Starting this April, I'm going to college.
[cpg]


It's not that far away from home, so I didn't have to look for a room......
[cpg]


I'm starting a new chapter in my life.
[cpg]


I wondered if I would ever find someone I could trust and love.
[cpg]


What happened with Sakura became a good memory.
[cpg]


But the past is the past and I need to live in the present.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



The city was dazzling in the daylight as the sun was shining bright.
[cpg]




;//ブラックアウト



;//ＥＮＤ：ヒロイン３ルート
[SCENE id=12]

[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
