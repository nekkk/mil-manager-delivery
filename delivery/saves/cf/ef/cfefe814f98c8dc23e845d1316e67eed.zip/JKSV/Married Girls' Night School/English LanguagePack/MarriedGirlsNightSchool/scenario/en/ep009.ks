
*start

;//==============================
;//【候補が居ない場合】

;#################################################
*Ep009|Ordinary Youth
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

*select04_4|Ordinary Youth


[SCENE id=9]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]

After all, I can't love anyone wholeheartedly.
[cpg]


I finally understood. They were all married women.
[cpg]


If that's the case, then what I'm doing is still nothing more than adultery ......
[cpg]




;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se014"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



I shouldn’t be doing anything with Mrs. Natsuki, Akira, or Sakura anymore.
[cpg]


It was monday, I headed to school with this in mind.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura281"]
[OnName num="sakura"]
“Good morning, Yuki."
[cpg cn=true]


[OnName num="yuuki"]
“Hey ......."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Sakura282"]
[OnName num="sakura"]
“What's wrong? You seem in low spirits.”
[cpg cn=true]


[OnName num="yuuki"]
Nothing's going on. I'm always like this.”
[cpg cn=true]


I guess I subconsciously tried to keep Sakura away, which came out in my reply.
[cpg]


But I can't help it. I actually think it's a good thing I stayed away.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************



Taking classes. I was even beginning to think that it might not be a good idea for me to stay at this school for too long.
[cpg]


Mrs. Natsuki would probably try to come on to me.
[cpg]


I was beginning to think that I wanted to have a normal youth.
[cpg]



[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[WAIT time=1500]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

And at the end of class. Just as I had thought, Mrs. Natsuki took me by the hand.
[cpg]


[OnName num="yuuki"]
“…… Uh what is it ......?"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Natuki408"]
[OnName num="natuki"]
“It's just practice. You know what I mean.”, she chuckles.
[cpg cn=true]


She mistakenly thinks I'm on board too.
[cpg]


But I was not in the mood ......
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

;//========================================
;//●ＣＧ（主人公を誘うヒロイン）ev_47
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：私服
;//場所　：学園教室
;//時間　：夜
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_ne"]
;**【ＣＧ】 ev_47_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sNatuki021"]
[OnName num="natuki"]
What's wrong ......?
[cpg cn=true]


It's not like I had a good answer.
[cpg]

I can't erase what had happened until now.
[cpg]

Despite that, I respond. What choice did I have?
[cpg]

But something unexpected happened.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************



[FACE method="shake_2" pos="4/5"]
[VOICE f="sAkira032"]
[OnName num="akira"]
Oh wow, Mrs. Natsuki. I thought we'd agreed to wait until he chose someone.”
[cpg cn=true]


[FACE method="shock_5" pos="2/5"]
[VOICE f="Natuki446"]
[OnName num="natuki"]
"What ...... Mrs. Takizu? It's...not what it looks like.”
[cpg cn=true]


Apparently Akira was watching. To Natsuki, this was a...dangerous situation.
[cpg]


[FACE method="shake_1" pos="4/5"]
[VOICE f="sAkira033"]
[OnName num="akira"]
“I think it's exactly what it looks like. You're his teacher, you could get into a lot of trouble."
[cpg cn=true]


[FACE method="shake_4" pos="2/5"]
[VOICE f="Natuki447"]
[OnName num="natuki"]
“Oh, please ...... don't tell anybody."
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Akira386"]
[OnName num="akira"]
“Sure ......but in return, I think I'll take Yuki too."
[cpg cn=true]


[OnName num="yuuki"]
“Huh?"
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


And so, this time Akira took me away.
[cpg]

In the past, I might have been happy about this.
[cpg]


;//========================================
;//●ＣＧ（主人公を誘うヒロイン）ev_48
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：私服
;//場所　：路地裏
;//時間　：夜
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_48_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

[VOICE f="sAkira034"]
[OnName num="akira"]
“What's wrong?"
[cpg cn=true]


She asks me as well. I don't know if I'm that easy to read.
[cpg]

[OnName num="yuuki"]
“It's nothing."
[cpg cn=true]


It wasn't right, but fair is fair...I'd been with Natsuki just moments before.
[cpg]

Why was it so hard to stick with my decision?
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]


A few days pass from there.
[cpg]


I was a little lost. Being approached by married women like Natsuki, Akira, or Sakura was fine, in its own way.
[cpg]


But I figured if I was so popular, I'd rather spend time with my peers.
[cpg]


Or is it that they are fond of me because they were older than me?
[cpg]




[window target=false]
[free time=1000]
[BG f="b_02_4.ui" time=1000]
[WAIT time=2100]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuki448"]
[OnName num="natuki"]
"You want to go back to a normal academy ……? It's not impossible.”
[cpg cn=true]


[OnName num="yuuki"]
“What grade will I end up in?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Natuki449"]
[OnName num="natuki"]
“Some schools allow you to transfer credits, but you know your school offers daytime classes as well.”
[cpg cn=true]


I don't know that there was such a thing. I wonder how it works ......
[cpg]


All in all, I still wanted to regain my normal youth, even if it meant I could be bullied again.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



Then class ended. This time, Sakura took me out.
[cpg]


[window target=false]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_ne"]
[WAIT time=100]
;//【ＢＧ】『公園』（夜）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sakura283"]
[OnName num="sakura"]
“Oh dear, I'm sorry you had to go on a date with this old lady."
[cpg cn=true]


[OnName num="yuuki"]
“I honestly don't think of you as old.”
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Sakura284"]
[OnName num="sakura"]
“Well, well, aren't you just the cutest.”
[cpg cn=true]


We talked as we were sitting on the bench.
[cpg]

;//移植のためシーンをカットしています

In truth, I enjoyed the time I spent with these women.
[cpg]


But I didn't change my mind.
[cpg]


I needed to have a normal youth.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************



In the classroom at the end of the day. I was alone with Mrs. Natsuki.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Natuki450"]
[OnName num="natuki"]
“I see ......If that's your decision, I won't stop you."
[cpg cn=true]


[OnName num="yuuki"]
“Yes ...... it's hasn't been long, but I've learned so much. It's all thanks to you."
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Natuki451"]
[OnName num="natuki"]
“But are you okay? Can you stay awake during the day?"
[cpg cn=true]


[OnName num="yuuki"]
“I've been adjusting my sleeping schedule. I'll be fine.”
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Natuki452"]
[OnName num="natuki"]
“I see ……."
[cpg cn=true]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



...... I started going to school during the day.
[cpg]


It's a different school. I will not see Mrs. Natsuki, nor Akira or Sakura.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


I got a year older. That makes me older than the other students.
[cpg]


Because of this, I was never bullied at all.
[cpg]


I felt like I was being kept at distance by some people, but that was fine by me.
[cpg]


I am making friends. Not just boys, but girls too.
[cpg]


I was comfortable talking to girls my own age. I knew I didn't fit in with older people.
[cpg]


Sometimes I find myself wondering if Mrs. Natsuki, Akira and Sakura are still having marital problems.
[cpg]


But I guess it's no longer my place to worry about them.
[cpg]



;//ブラックアウト
;//ＥＮＤ：ノーマルルート


[SCENE id=14]

[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


