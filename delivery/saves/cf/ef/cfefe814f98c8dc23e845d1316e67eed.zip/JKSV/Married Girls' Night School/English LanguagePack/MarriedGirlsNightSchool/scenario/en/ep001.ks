
*start


;#################################################
*Ep001|New Life
;#################################################

[SCENE id=1]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


The seasons change. Autumn turns into winter, and then comes spring.
[cpg]


What if I get bullied at my new school? I couldn't help but think about it...
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



At the entrance ceremony, there were all kinds of people.
[cpg]


There were very depressed looking boys and girls of about the same age as me.
[cpg]


I guess they were the same type of people as me.
[cpg]


The rest of the people were much older than me. I guess they just wanted to graduate because they couldn't before.
[cpg]


There were also a lot of old men and women. And then there were the punk looking people.
[cpg]


I wonder if these people work during the day or something like that ......?
[cpg]


Anyway, they all seemed to have various reasons for being there. I don't think I'd be bullied here.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************



With that in mind, the first day starts.
[cpg]


To my surprise, the homeroom teacher of the class was Ms.Natsuki. She’s going to be my teacher from now on.
[cpg]


At the end of homeroom, I stayed back to talk to Mrs. Natsuki.
[cpg]



;//========================================
;//●ＣＧ非エロ（ノート類を持ちながら主人公の方を振り返るヒロイン）ev_01
;//人物１：ヒロイン１
;//服装１：スーツ
;//場所　：学園教室
;//時間　：夜
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]




[OnName num="yuuki"]
“Umm…. Mrs. Natsuki…..”
[cpg cn=true]



[VOICE f="Natuki010"]
[OnName num="natuki"]
“What's wrong? Yuki.”
[cpg cn=true]


“She still calls me “Yuki". Normally, teachers would call me by my last name.
[cpg]


Knowing someone from the beginning, has its challenges.
[cpg]


[OnName num="yuuki"]
“I'm looking forward to the next year.”
[cpg cn=true]



[VOICE f="Natuki011"]
[OnName num="natuki"]
“It’s not just a year.”
[cpg cn=true]


[OnName num="yuuki"]
“What do you mean ……?"
[cpg cn=true]



[VOICE f="Natuki012"]
[OnName num="natuki"]
“You don't move up a class after a year at this school, you just continue into the next curriculum..”
[cpg cn=true]



[VOICE f="Natuki013"]
[OnName num="natuki"]
“So I'll be in charge for a longer period of time.”
[cpg cn=true]


[OnName num="yuuki"]
"Is that so?”
[cpg cn=true]


I was having trouble wrapping my head around it. I guess it means there wouldn't be distinctions between grades.
[cpg]



[VOICE f="Natuki014"]
[OnName num="natuki"]
“I'll be looking forward to teaching you either way. Yuki.”
[cpg cn=true]


Mrs. Natsuki smiled as she said so ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


A few more days pass.
[cpg]


[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]


[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[OnName num="yuuki"]
“I'm off to school.”
[cpg cn=true]


[OnName num="yuuki's_mother"]
“Yes, have a good day.”
[cpg cn=true]



[SE f="se014"]
;//【ＳＥ】『歩く』


I had become somewhat accustomed to commuting to school in the evening, and had begun to pay attention to my surroundings.
[cpg]



;//========================================
;//●ＣＧ非エロ（自分の席に座っている状態で、主人公の方を見上げる）ev_02
;//人物１：ヒロイン２
;//服装１：制服
;//場所　：学園教室
;//時間　：夜
;//========================================
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


Her, for example. I knew her name was Akira Takizu from her self-introduction.
[cpg]


[OnName num="yuuki"]
"Oh, um, Akira?”
[cpg cn=true]



[VOICE f="Akira001"]
[OnName num="akira"]
“Um, yeah ......, it was Yuichi or something like that, right? What can I do for you?"
[cpg cn=true]


[OnName num="yuuki"]
“It’s Yuki ......"
[cpg cn=true]



[VOICE f="Akira002"]
[OnName num="akira"]
“I'm sorry. I guess I'm getting old, huh?"
[cpg cn=true]


Although she said that, she looks about the same age as me.
[cpg]


[OnName num="yuuki"]
“Why are you in a uniform? There's no designated uniform here, right?”
[cpg cn=true]



[VOICE f="Akira003"]
[OnName num="akira"]
“Oh, this is the uniform I used to wear at the school before ....... I couldn't graduate because of some stuff that happened.”
[cpg cn=true]



[VOICE f="Akira004"]
[OnName num="akira"]
“I was going through a lot at the time. I want to graduate in this uniform to overcome the pain I felt at that time.”
[cpg cn=true]


There was a quiet strength about her. But even she had been driven to quit school...
[cpg]


Does that mean she's the same type as me ……? It's hard to judge.
[cpg]



[VOICE f="Akira005"]
[OnName num="akira"]
“By the way, you don’t have to be so formal when you talk to me. I’m pretty casual.”
[cpg cn=true]


[OnName num="yuuki"]
But what if I'm younger than you.”
[cpg cn=true]



[VOICE f="Akira006"]
[OnName num="akira"]
“He he. You’re right."
[cpg cn=true]


What was with that laugh? And why won’t she tell me her age?
[cpg]



[VOICE f="Akira007"]
[OnName num="akira"]
“Anyways you’re cute. I think I might fall in love.”
[cpg cn=true]


[OnName num="yuuki"]
"Oh, please don’t joke like that ......"
[cpg cn=true]


I'm also a bit confused by the term “cute". Is she older than me?
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夜）******************************************************



Some of my classmates are girls my age or maybe even younger.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
For example, Sakura Niimi.
[cpg]


She's younger than me, it was obvious me ……
[cpg]

I wonder if you can skip grades in this school.
[cpg]


No, that wouldn't make sense...there was an entrance exam for a reason.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sakura001"]
[OnName num="sakura"]
“What's wrong, do you want something from me?”
[cpg cn=true]


She had a particular slow drawl to her speech.
[cpg]


[OnName num="yuuki"]
“No, no. Nothing."
[cpg cn=true]


There was a big gap between her appearance and her words.
[cpg]


Her manner of speaking contrasted greatly with her young appearance.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************


[OnName num="yuuki"]
"Phew……"
[cpg cn=true]


After school, there's still time before I go to bed.
[cpg]


Still, I felt more fulfilled than I did before.
[cpg]


I felt that humans had a primal drive to always be doing something.
[cpg]


I guess it's because human beings are animals by nature.
[cpg]


There are not many animals that can just stay in their nests and get food.
[cpg]


I began to think that maybe that was what was distorting me.
[cpg]


I was becoming less afraid of the park at night. I think that's a good thing.
[cpg]


Every once in a while I see a rough-looking crowd, but I keep my distance...
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夜）******************************************************


The next day. Classes were going normally, and for the most park, everyone was taking them rather seriously.
[cpg]


I was worried that someone who looked punk might ruin the class, but ......
[cpg]


A delinquent is only a delinquent because the people around them conform to a certain standard.
[cpg]


It would be difficult to continue to be a delinquent among such a unique group of people, with even older people around.
[cpg]


It's a good thing, isn't it? I wish this kind of school was more popular ......
[cpg]


There are more of these places than I thought. I had no idea.
[cpg]



[SE f="se001"]
;//【ＳＥ】『学園のチャイム』
[WAIT time=2100]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Natuki015"]
[OnName num="natuki"]
"Well, that's it for today's class.”
[cpg cn=true]


It was interesting to see the old men and women act along when the bell rang.
[cpg]

[free time=1000]
[SE f="se014"]
;//【ＳＥ】『歩く』
[WAIT time=2100]

[OnName num="middle_aged_man"]
“Whew ...... My shoulders are tense.”
[cpg cn=true]


[OnName num="yuuki"]
“What ...... are you talking to me?”
[cpg cn=true]


[OnName num="middle_aged_man"]
“What? You're my classmate, can't I talk to you?”
[cpg cn=true]


Some were a little more friendly than others, and of course there were those who kept their distance and came only to take classes.
[cpg]


But I'm glad to see that those who are keeping their distance also blend into this friendly atmosphere.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akira008"]
[OnName num="akira"]
“Good evening, Yuki.”
[cpg cn=true]


[OnName num="yuuki"]
"Oh, Akira …… You seem pretty jolly.”
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Akira009"]
[OnName num="akira"]
“Well yeah. Are you going home soon, Yuki?”
[cpg cn=true]


Hmm. We don’t have any club activities or anything like that.
[cpg]


That's the hard part of being in school at night.
[cpg]


Even school lunch was served before classes started. I was surprised at that too.
[cpg]


[OnName num="yuuki"]
“I think I'll stay a little longer ...... I have quite a bit of time before I go to bed.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Akira010"]
[OnName num="akira"]
“I see. Then, go out on a date with me for a bit.”
[cpg cn=true]


[OnName num="yuuki"]
"What ......?"
[cpg cn=true]




[SE f="se014"]
;//【ＳＥ】『歩く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]

[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************



So, Akira and I were alone in a park in the middle of the night.
[cpg]


It was a peculiar experience to walk through a park in the middle of the night.
[cpg]


[OnName num="yuuki"]
“What in the world do you mean by...... date?”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Akira011"]
[OnName num="akira"]
"Heh heh. I like talking with cute boys like you, Yuki. …."
[cpg cn=true]


She says this with a smile. I wonder if there is a chance between us.
[cpg]


[OnName num="yuuki"]
"Are you teasing me ......?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Akira012"]
[OnName num="akira"]
“I don't know. I really wanted to talk to you properly, Yuki.”
[cpg cn=true]


[OnName num="yuuki"]
“You say that but ...... I don’t have any interesting experiences talk about.”
[cpg cn=true]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ブラックアウト



Akira asked me digging down to the root of the question. I had no choice but to answer.
[cpg]


I told her that I was bullied at my previous school. And the story of how I withdrew from society and became nocturnal.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『公園』（夜）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Akira013"]
[OnName num="akira"]
“I see …… that must have been tough.”
[cpg cn=true]


[OnName num="yuuki"]
“Well, I would say it was tough. But now I can go to school like this.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira014"]
[OnName num="akira"]
“That's true. Plus, we got to meet each other so it can't be all that bad.”
[cpg cn=true]


Akira smiles carefree saying so.
[cpg]


Wondering if I should be a little more aggressive, I tried to make a move.
[cpg]


[OnName num="yuuki"]
"Well, do you have an account for this app ……? If you do, I'll send you a friend request ......."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Akira015"]
[OnName num="akira"]
"Oh, no, no. I don't have a smartphone.”
[cpg cn=true]


[OnName num="yuuki"]
“What?"
[cpg cn=true]


At her age? No phone?
[cpg]


[OnName num="yuuki"]
“Well, ….. Are your parents very strict?”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Akira016"]
[OnName num="akira"]
“No, I'm not very good with modern technology.”
[cpg cn=true]


Modern technology? I was a little curious, so I asked her.
[cpg]


[OnName num="yuuki"]
“Akira, how old are you?”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Akira017"]
[OnName num="akira"]
“I'm not telling you how old I am, but I'm married.”
[cpg cn=true]


Wow. I was not expecting a married woman.
[cpg]


I could understand Natsuki, but not Akira.
[cpg]


She seemed about the same age as me. Maybe she is the same age, only married.
[cpg]


[OnName num="yuuki"]
“Really….? If that's the case, I don't understand why you would go to a night school now.”
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Akira018"]
[OnName num="akira"]
"Well, I couldn't go to school properly in my youth because of my parents' circumstances.”
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akira019"]
[OnName num="akira"]
“I'm trying to be a young girl again. But at my age, I can't even attend a normal school.”
[cpg cn=true]


[OnName num="yuuki"]
“Seriously ……?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Akira020"]
[OnName num="akira"]
“You seem very surprised. If you’re surprised at this, you would be even more surprised when you hear Sakura’s story.”
[cpg cn=true]


[OnName num="yuuki"]
"......"
[cpg cn=true]



[jump storage="ep002.ks" target="*start"]


;////////////////////////////////////////////////////////////////////////


