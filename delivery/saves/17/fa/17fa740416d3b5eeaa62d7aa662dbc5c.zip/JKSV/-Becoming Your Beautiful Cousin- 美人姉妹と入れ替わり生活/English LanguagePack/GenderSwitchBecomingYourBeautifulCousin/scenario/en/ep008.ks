
*start


;//==============================
;//２、雫

*start|Bright Shizuku


*select30_2|Bright Shizuku


[SCENE id=8]


;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（雫）　雫（由宇）
;//と変更してください
;//----------------------------------------


I decided. If I discussed this with my sister, who is serious at heart, it would be very dark.
[cpg]


I thought that Shizuku would be cheerful. So I headed to my sister's room.
[cpg]

;#################################################
*Ep008|Bright Shizuku
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



[FACE method="bow_2" pos="2/5"]
[VOICE f="sMarina357"]
[OnName num="marina(shizuku)"]
I thought to myself, "Well, you're right. I understand how you feel.
[cpg cn=true]


She seemed to laugh off my seriousness.
[cpg]


I was glad that I talked to her after all.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku202"]
[OnName num="shizuku(yu)"]
"I don't know what to do about ....... I can't come up with any good ideas myself."
[cpg cn=true]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



I talked with Shizuku for a while.
[cpg]


I was honestly not sure what to say to her, but she just said, "I'll figure something out.
[cpg]


I guess she really thought so.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



[FACE method="bow_7" pos="2/5"]
[VOICE f="Marina358"]
[OnName num="marina(shizuku)"]
It's getting pretty late, isn't it? Shall we go to bed?
[cpg cn=true]


I realized what he had said. Time flies when I'm with Shizuku.
[cpg]


I thought that might be a sign that she was relaxed.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Shizuku203"]
[OnName num="shizuku(yu)"]
Oh. Well, good night."
[cpg cn=true]


I decided to go back to Shizuku's room.
[cpg]



;//ＢＫ

[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈　雫
;//と変更してください
;//----------------------------------------

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



When I woke up, I was in my own body.
[cpg]


I was relieved to feel something I hadn't felt in a while, and I got ready to go to school.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Marina359"]
[OnName num="marina"]
Good morning, Yu.
[cpg cn=true]


My sister is calm. That means she is my sister.
[cpg]


I can tell that everyone is back to normal today.
[cpg]


Shizuku's non-acting is a good indicator of who's who.
[cpg]


Does that mean that from Shizuku's point of view, she can't see us who are acting?
[cpg]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Shizuku204"]
[OnName num="shizuku"]
What's wrong?　What's wrong?
[cpg cn=true]


[OnName num="yu"]
"Oh, nothing. Nothing.
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

After finishing breakfast, I left the house.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア閉まる』


[window target=false]
[BG f="b_03_1.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



I met Koyi on the way. It was still a little awkward,
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kokoro088"]
[OnName num="kokoro"]
She said, "Good morning. It's Yoo-kun today, right?
[cpg cn=true]


[OnName num="yu"]
She said, "Yes, that's right. You know me well.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
Koyi's expression was soft. At this rate, there seems to be nothing for me to worry about.
[cpg]


It's not like I can just go to ....... Both Koyi and my sister like me.
[cpg]


Shizuku is not a different ...... being in that sense. He's going to tell me he likes me straight up.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の通う学園＿教室』（昼）******************************************************



I'm taking classes at the school. My memory is so jumpy that I can't keep up.
[cpg]


I think I'm going to fail the next test. ......
[cpg]


I strongly felt again that we all have to go back to the way we were before.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kokoro089"]
[OnName num="kokoro"]
I thought to myself, "That's tough, Yu-kun. ...... class, you can't keep up with it, can you?"
[cpg cn=true]


[OnName num="yu"]
"Well, yeah. You're the only one who knows what's going on."
[cpg cn=true]


But the hardest part is probably Shizuku. Whether she switched with me or with her sister, she would not be able to understand the class.
[cpg]


I'll have to think of a way to help her. So, what should we do? ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

On the way home. Walking with Koyi on the way home from school.
[cpg]


[OnName num="yu"]
I asked her, "...... Koyi, do you still want me to be me after all?"
[cpg cn=true]


How outlandishly I asked.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kokoro090"]
[OnName num="kokoro"]
Why do you ask me that?"
[cpg cn=true]


[OnName num="yu"]
'No, it's nothing.
[cpg cn=true]


Even though I can't go out with Koyi. I heard something strange ......
[cpg]


...... wait. Why can't I go out with Koyi?
[cpg]


I can't see my sister as an object of romantic interest. On the other hand, I can't go out with Koyi either.
[cpg]


Who am I doing this for?
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



Then, I naturally became aware of my feelings.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuku205"]
[OnName num="shizuku"]
'Welcome back, big brother ......, big brother?
[cpg cn=true]



[OnName num="yu"]
Ah, ah. I'm home.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[WAIT time=1000]

I see. I like Shizuku.
[cpg]


I think it probably goes beyond liking her as a family member.
[cpg]


Because otherwise, there would be no reason not to respond to Koyi's feelings.
[cpg]


[OnName num="yu"]
Hey, Shizuku, ......, I need to talk to you.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Shizuku206"]
[OnName num="shizuku"]
I've got to talk to you, too. The most important thing to remember is that you can't just go to the store and ask for a discount.
[cpg cn=true]


I wonder what ...... is talking about. Oh well.
[cpg]



[SE f="se019"]
;//【ＳＥ】『ドア開く』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[OnName num="yu"]
I've been thinking about something recently,......, and I don't know how to start it.
[cpg cn=true]


I can't think of a good way to start this. Would it be better to prepare a killing sentence and then come back to it later?
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Shizuku207"]
[OnName num="shizuku"]
"No?　Then let me talk to him.
[cpg cn=true]

[free time=500]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

I was sitting down and she came very close to me.
[cpg]


She was quite close. I thought she was going to kiss me.
[cpg]


;//ＢＫ

[FACE method="bow_6" pos="2/3"]
[VOICE f="sShizuku008"]
[OnName num="shizuku"]
I've always thought it was unfair that you were always with your sister.
[cpg cn=true]

She blushed when she said that, but she didn't seem embarrassed.
[cpg]

Maybe ...... I need to be honest about my feelings.
[cpg]

;//========================================
;//●ＣＧ（ヒロインを背後から抱きしめる主人公）ev_26
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_26_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sShizuku009"]
[OnName num="shizuku"]
I feel kind of at home."
[cpg cn=true]


[OnName num="yu"]
'...... I see.'
[cpg cn=true]


She said she felt calm in my arms.
[cpg]

It was almost like a confession.
[cpg]

But I couldn't respond properly.
[cpg]

[VOICE f="sShizuku010"]
[OnName num="shizuku"]
I like you. I like you.
[cpg cn=true]


And then she said it first.
[cpg]

After I did so, I was finally able to respond. ......
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



Then night came and we had dinner. Dad had come home, too.
[cpg]


[OnName num="father"]
What's wrong?　Shizuku, you seem to be in a good mood.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Shizuku226"]
[OnName num="shizuku"]
"Do I look like I am?　"Heh heh heh.
[cpg cn=true]


Shizuku was in such a good mood that she could have blown the whole thing out of proportion.
[cpg]


The most important thing to remember is that you should never be afraid to ask for help.
[cpg]


I should at least try to maintain my composure. I thought so.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



And then, my room. I was about to go to bed.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈　雫（由宇）
;//と変更してください
;//----------------------------------------


;//ＢＫ
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿雫の部屋』（夜）******************************************************


[FACE method="shake_4" pos="2/3"]
[VOICE f="Shizuku227"]
[OnName num="shizuku(yu)"]
I was in Shizuku's body.
[cpg cn=true]


I was in Shizuku's body. I was sure the room was Shizuku's room.
[cpg]


But I was sleepy, so I fell asleep without any consultation.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=800]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="yu(shizuku)"]
Good morning, sis.
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Marina360"]
[OnName num="marina"]
Good morning, ......."
[cpg cn=true]


I was so tired that I didn't know what to do. I'm sure you're right.
[cpg]


[OnName num="mother"]
Yoo is in a good mood today. It's as if a drop of water has taken over.
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]
Mom guessed exactly what I was thinking. Oh no, oh no, oh no.
[cpg]


I was so flustered that I decided to follow her up.
[cpg]


[FACE method="shake_4" pos="4/5"]
[VOICE f="Shizuku228"]
[OnName num="shizuku(yu)"]
I said, "Wow, I'm here, aren't I?　That's funny, because that means there are two of us.
[cpg cn=true]


[OnName num="mother"]
I said, "......, that's true."
[cpg cn=true]


I think he was convinced, but I don't think he was convinced.
[cpg]


It's a delicate point, but I'll take it as a sign that he was convinced. I'm sure he's convinced, but I'm going to assume he's convinced.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



[FACE method="shake_7" pos="4/5"]
[VOICE f="Kokoro091"]
[OnName num="kokoro"]
"Uh, ......, you're Shizuku, right?
[cpg cn=true]


[OnName num="yu(shizuku)"]
Yes, I'm Shizuku. I'm Shizuku.
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]

Shizuku speaks frankly with Koyi. There is no need to hide anything.
[cpg]


[OnName num="yu(shizuku)"]
The actuality that you can't get a good deal more than a few of these, it's not really a good idea to get a lot more than a few of these. I'm looking forward to it.
[cpg cn=true]


I was thinking, "You say you're looking forward to it, but I don't think you'll be able to keep up with the class.
[cpg]


I went to the school Shizuku went to.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（昼）******************************************************



Shizuku's school. After lunch, I was sitting in the hallway looking outside.
[cpg]


[OnName num="female_student"]
I was thinking, "Tokiwa-san, did you watch that drama I told you about the other day?"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

I was in an early pinch.
[cpg]


I was in a pinch right away. I had to get her on the same page somehow.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Shizuku229"]
[OnName num="shizuku(yu)"]
I said, "No, I haven't seen it. Sorry, I didn't have time.
[cpg cn=true]


[OnName num="female_student"]
"So ......?　That's too bad.
[cpg cn=true]


My words stutter. And they suspect it.
[cpg]


[OnName num="female_student"]
But then again, Tokiwa-san's mood has changed recently, hasn't it?
[cpg cn=true]


[OnName num="female_student"]
She's become a little cooler, or something. It's like she's not as cheerful as she used to be.
[cpg cn=true]


[FACE method="shock_2" pos="2/3"]
[VOICE f="Shizuku230"]
[OnName num="shizuku(yu)"]
It's just my imagination. You're full of energy today, too.
[cpg cn=true]


I tried to say what Shizuku might have said,
[cpg]


[OnName num="female_student"]
I don't think Tokiwa-san would say something like that herself. ......
[cpg cn=true]


It was counterproductive. They continue to deceive from there.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=1100]
[window target=true]

I continued to deceive, and when I was tired of it all, the class finally ended.
[cpg]

[window target=false]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=800]

[VOICE f="Marina361"]
[OnName num="marina"]
Welcome back, you two. Are you still switching?"
[cpg cn=true]


I was the only one in the house. Shizuku said without hiding.
[cpg]


[OnName num="yu(shizuku)"]
I'm going to go stand up for a while now. Well, I'm going to be busy right now, so don't open the door.
[cpg cn=true]

[FACE method="shake_7" pos="2/5"]

What's that?" says my sister. It's a weird thing to worry about, isn't it?
[cpg]


I should have told her that I liked her too, right? I should have said no to her, but I didn't. ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[OnName num="yu(shizuku)"]
I'm alone with you, aren't I?
[cpg cn=true]


And then Shizuku came closer to me.
[cpg]

I mean,......
[cpg]



;//========================================
;//●ＣＧ（ベッドに押し倒されるヒロインの姿の主人公）ev_27
;//人物１：主人公（ヒロイン２の外見）
;//服装１：制服
;//人物２：ヒロイン２（主人公の外見）
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

[VOICE f="sShizuku011"]
[OnName num="shizuku(yu)"]
'Hey ......, that's not good.'
[cpg cn=true]


She pushed me down on the bed. What are you going to do?
[cpg]

[OnName num="yu(shizuku)"]
I'm not going to do anything sinister. It's just skinship.
[cpg cn=true]


[VOICE f="sShizuku012"]
[OnName num="shizuku(yu)"]
"Stop it, it's your body.
[cpg cn=true]


[OnName num="yu"]
"Can't we just have skinship?　Massage, then.
[cpg cn=true]


;//ＢＫ

After such a contrived conversation.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


A little while later, we had dinner. Me, Shizuku, my sister, grandpa and mom.
[cpg]


Dad can't seem to get home today. He's very busy.
[cpg]


But it's good that he's not home. It reduces the chance of him finding out about us.
[cpg]


[OnName num="yu(shizuku)"]
"It's delicious!　Mom's curry is the best!
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku248"]
[OnName num="shizuku(yu)"]
This is hashed rice, big brother. ......
[cpg cn=true]


[OnName num="yu(shizuku)"]
It doesn't matter which one it is, it's delicious.
[cpg cn=true]


[OnName num="mother"]
"Heh. Thank you."
[cpg cn=true]


The problem is mom. She's obviously looking at me suspiciously.
[cpg]


She's probably already talking to my dad. I had to make a plan to get back to normal as soon as possible.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



So the three of us gathered in my room.
[cpg]



[OnName num="yu(shizuku)"]
What's the matter?　Why did you suddenly get together?
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Marina362"]
[OnName num="marina"]
Of course. We're trying to figure out how we're going to make money.
[cpg cn=true]


[OnName num="yu(shizuku)"]
Oh, that.
[cpg cn=true]


He called me such a thing. He is always going at his own pace, or whatever you call it. ......
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina363"]
[OnName num="marina"]
"Do you have any idea what such a thing is ......?"
[cpg cn=true]


[OnName num="yu(shizuku)"]
I do. But, umm, I need a little strategy, or preparation.
[cpg cn=true]


What are you talking about? I have no idea.
[cpg]


I don't know, but if you have a plan, please tell me.
[cpg]


[OnName num="yu(shizuku)"]
"What's wrong, you two, looking at me like that?"
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku249"]
[OnName num="shizuku(yu)"]
No, you're looking at me like that. Do you have any idea how to get back on track?"
[cpg cn=true]


I scratch my head and say, "Hmmm.
[cpg]


[OnName num="yu(shizuku)"]
I have an idea, but I'm not sure if I can make it happen yet. I have an idea, but I'm not sure if I can make it happen yet.
[cpg cn=true]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



My sister and I were fascinated by this story. But Shizuku didn't say anything more.
[cpg]


She was being very presumptuous, and she even started to get cocky because she was being depended on.
[cpg]


[OnName num="yu(shizuku)"]
Hmmm...well, look forward to it. You'll get your life back."
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



After that, she went back to her room and left me alone.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuku250"]
[OnName num="shizuku(yu)"]
What do you mean ......?
[cpg cn=true]


[OnName num="yu(shizuku)"]
Nothing happened. Come to bed with me, big brother.
[cpg cn=true]


Another one of those stories. I wouldn't wish it on me, but ......
[cpg]


If Mom finds out, it will be a big problem.
[cpg]


I explained to Mom that if she found out, it would be a family affair, but...
[cpg]


[OnName num="yu(shizuku)"]
But then she said, "Again. You're dressed as me now, you know?　I've snuck into your bedroom before, haven't I?"
[cpg cn=true]


Indeed. It certainly has happened before, quite a few times.
[cpg]


[OnName num="yu(shizuku)"]
So, you should sleep on my futon today. I'm sure you've done it before.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Shizuku251"]
[OnName num="shizuku(yu)"]
I understand ......, but it's like sleeping with your own body, isn't it?　Is that okay with you, Shizuku?
[cpg cn=true]


[OnName num="yu(shizuku)"]
It's not the body that's the problem. It's the mind, isn't it?"
[cpg cn=true]


...... Sometimes it feels like our ages are reversed, me and Shizuku.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

The next day off. The next day, I and Shizuku switched again.
[cpg]



;//========================================
;//●ＣＧ（ヒロインと主人公、二人で街を歩く）ev_28
;//人物１：主人公（ヒロイン２の外見）
;//服装１：私服
;//人物２：ヒロイン２（主人公の外見）
;//服装２：私服
;//場所　：住宅街
;//時間　：昼
;//========================================


[BGM f="bg_d2"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sShizuku013"]
[OnName num="shizuku(yu)"]
......"
[cpg cn=true]


When we walked around town together, it was somehow different from before.
[cpg]

It's not just because we've switched bodies.
[cpg]

[OnName num="yu(shizuku)"]
What's wrong?　You're fidgeting.
[cpg cn=true]


[VOICE f="sShizuku014"]
[OnName num="shizuku(yu)"]
"......, it's nothing."
[cpg cn=true]


I'm sure that now that we're lovers, I'm more concerned about the way you look at me.
[cpg]


;//移植のためシーンをカットしています



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



So we went back to the house.
[cpg]


[OnName num="yu(shizuku)"]
'Now that we've gone on a date, what shall we do next, big brother?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Shizuku269"]
[OnName num="shizuku(yu)"]
I was so excited, I thought, "We don't have to do so many things so quickly, you know. We have plenty of time.
[cpg cn=true]


[OnName num="yu(shizuku)"]
There's never enough time. It's only a matter of time before we can enjoy switching places.
[cpg cn=true]


...... I see. You said you had a plan for the drops.
[cpg]


I'm about to ask him, and I'm about to ask him.
[cpg]


[OnName num="yu(shizuku)"]
'Well, I guess so. It's about time we all talked about my plan."
[cpg cn=true]


;//ＢＫ
[window target=false]
[free time=800]
[BG f="b_07_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

So even my sister, who had not been replaced, was summoned.
[cpg]



[window target=false]
[free time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


The three of us gathered in my room. Then Shizuku started to explain her theory.
[cpg]


[OnName num="yu(shizuku)"]
Grandpa, you still have a lot of machines that you use for research, don't you?
[cpg cn=true]


[OnName num="yu(shizuku)"]
If he sold them all, he would have a lot of money, and I'm sure he has some saved up.
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Marina364"]
[OnName num="marina"]
I wonder if Grandpa thinks that even though he admits it was his fault, it's not enough for him to throw his fortune away. I wonder if Grandpa thinks he's admitting it's his fault, but not enough to throw his fortune away.
[cpg cn=true]


If so, that's a terrible story. We're in serious trouble.
[cpg]


[OnName num="yu(shizuku)"]
"So I think we should just let him tell us," I said, "that he has money. "He's got money, too.
[cpg cn=true]


If I could do that, I would have no trouble. But judging from the way Shizuku talks, she must have thought of a way to make him say it.
[cpg]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Shizuku270"]
[OnName num="shizuku(yu)"]
How would you get him to say that?
[cpg cn=true]


[OnName num="yu(shizuku)"]
I haven't thought that far ahead. What am I going to do?
[cpg cn=true]


What, you haven't thought of ...... that?
[cpg]


I was disappointed, but still felt that I could see some light.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



It is difficult to kill time in the room of the drop. There was nothing I was interested in.
[cpg]


I was wandering around the city in Shizuku's body.
[cpg]


As I wandered around the city, I noticed that everyone was looking at my breasts.
[cpg]


I've seen this before. I knew that people were looking at my body shape like that.
[cpg]


As I was walking along thinking, "It's not easy being a girl. ......
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------


;//ＢＫ
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]

Suddenly, my vision switched.
[cpg]

[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************

[FACE method="shock_5" pos="2/3"]

I was in front of her. So, was it Shizuku who was in front of me?
[cpg]


That's strange, because it was Shizuku's body.
[cpg]


No, is it possible?　I mean, how is it possible?
[cpg]


[OnName num="yu(marina)"]
"What, ......, uh, Shizuku?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina365"]
[OnName num="marina(yu)"]
No, no. It's me."
[cpg cn=true]


It seems that my sister is inside of me.
[cpg]


This moment really scares me. Every time I wonder what I would do if I were on a bicycle.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



Then night falls and Shizuku comes back.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuku271"]
[OnName num="shizuku"]
I'm home. You're terrible, big brother, where have you been?"
[cpg cn=true]


[OnName num="yu(marina)"]
"Where? What are you talking about?"
[cpg cn=true]


She would talk like this even in front of Mom.
[cpg]


I wonder if they know we're having trouble replying.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Shizuku272"]
[OnName num="shizuku"]
I'm sorry. I know. ...... Well, which one is it?"
[cpg cn=true]


[OnName num="yu(marina)"]
So, which is what?
[cpg cn=true]


[OnName num="mother"]
What?　What are you talking about?"
[cpg cn=true]


Mom is suspicious. We try to mend things.
[cpg]


[OnName num="yu(marina)"]
"It's nothing. It's just that Shizuku is saying something strange."
[cpg cn=true]


And so our perilous dinner passes.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



We take a bath and sleep in my sister's bed, and the next morning we're still in the same place.
[cpg]


The next morning, we still seem to be doing the same thing. My sister is acting like me.
[cpg]


[OnName num="yu(marina)"]
I've got to get going or I'm going to be late. Shizuku.
[cpg cn=true]


[OnName num="mother"]
"Have a good day, you three."
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Marina366"]
[OnName num="marina(yu)"]
"Yeah, I'm off. I'm off.
[cpg cn=true]



[SE f="se019"]
;//【ＳＥ】『ドア閉まる』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

[SE f="se001"]
;//【ＳＥ】『歩く』



I'm heading to my sister's college. I'm used to it by now.
[cpg]


I still can't communicate with my sister's friends, but I can't help it anymore.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の通う学園＿教室』（朝）******************************************************



While I was in a lecture room at ...... university, I suddenly thought to myself.
[cpg]


If I went home now, would Shizuku want me?
[cpg]


I thought to myself, "That would be a bad idea, but I don't think she would press me.
[cpg]


I was thinking about it in a daze because I couldn't get the lecture out of my head at all.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の通う学園＿教室』（夕方）******************************************************


It was now late in the evening. I was about to go home.
[cpg]


[OnName num="female_student"]
"Hey, hey, Tokiwa-san, let's go for a short detour, shall we?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marina367"]
[OnName num="marina(yu)"]
"Sorry. I'll pass for today.
[cpg cn=true]


If I were me, I wouldn't say "I'll pass today.
[cpg]


I'm getting used to acting like a big sister.
[cpg]


On the other hand, Shizuku doesn't want to be anyone else at all.
[cpg]


[OnName num="female_student"]
I'm not interested in being someone else, but I don't want to be someone else at all. You've been so boring lately.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Marina368"]
[OnName num="marina(yu)"]
"Oh, wait a minute!"
[cpg cn=true]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



I was forcibly pulled by the arm and taken to what looked like a general store.
[cpg]


There were many uninteresting knick-knacks lined up in a narrow space. I had never been to a place like this before.
[cpg]


I went along with someone whose name I did not know, thinking, "Hmmm.
[cpg]


[OnName num="female_student"]
Hey, don't you think this is cute?　They are cute, aren't they?
[cpg cn=true]


I didn't know college students did this kind of thing.
[cpg]


It's a world I can't even imagine. Is it good or bad that I can enjoy it? ......
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


I finally ended the conversation and went back home.
[cpg]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Shizuku273"]
[OnName num="shizuku"]
I said to myself, "Welcome home. Alright, let's go to your sister's room."
[cpg cn=true]


I was caught in a drop like something was waiting for me.
[cpg]


;//========================================
;//●ＣＧ（ヒロイン２に迫られる主人公。ヒロイン１の外見）ev_29
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公（ヒロイン１の外見）
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

It was my sister's room. The room smelled like my sister's. I could smell her scent on my body.
[cpg]


And I could smell her scent on my body.
[cpg]


I was getting dizzy. I am not sure what's real anymore.
[cpg]


I am sure that Shizuku is Shizuku. But who the hell am I?
[cpg]


What do I want to become?　I wonder if I even want to remain a woman.
[cpg]




;//========================================
;//●ＣＧ（キスをする二人）ev_30
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公（ヒロイン１の外見）
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================

;**【ＣＧ】 ev_30_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

[VOICE f="sShizuku015"]
[OnName num="shizuku"]
I'm sure you're not confused. We are lovers, aren't we?
[cpg cn=true]


That's what Shizuku says, but I'm her sister now.
[cpg]

Is she okay with that?
[cpg]

While I'm still wondering, her lips come closer to mine.
[cpg]

I closed my eyes.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



[OnName num="yu(marina)"]
What are you guys doing?
[cpg cn=true]


My sister found me and scolded me severely.
[cpg]


[OnName num="yu(marina)"]
You're out of your mind!
[cpg cn=true]


Yes, I have nothing to say in return. ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈　雫（由宇）
;//と変更してください
;//----------------------------------------

[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



The next morning. I woke up with me and Shizuku switched.
[cpg]


I had been thinking that we often switch at night while I'm sleeping, but when I think about it, it's not surprising.
[cpg]


Considering that I sleep for a third of the day, the probability would be high.
[cpg]


Or maybe there is some kind of law that they tend to switch during the night to begin with.
[cpg]


Whatever the case, only Grandpa would know.
[cpg]


[OnName num="grandfather"]
"What's wrong with ......?　What's on my face?"
[cpg cn=true]


I had to get it out of Grandpa, didn't I?
[cpg]


He told me that there was money to be made by selling off the machines and stuff. ......
[cpg]


How do I get him to tell me?　How do I get him to drop his guard?
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


I think about it even as I walk around town.
[cpg]


If I sell off the machines from my grandfather's lab, I can get this much money: ......
[cpg]


I can't find out what he's talking about. I think it would be better to let him come up with it himself.
[cpg]


I don't think we can find out what he wants. I reject this plan.
[cpg]


If that's the case, we have to get grandpa to tell us in some way.
[cpg]


Maybe to get his sympathy, or something like that.
[cpg]


But even now, the situation should be enough to make him sympathetic. Grandpa knows he's in trouble.
[cpg]


If you go any further, are we talking about attempted suicide or something like that?　I don't even want to scar my body by doing that. ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（朝）******************************************************



I think the same thing at the school Shizuku goes to.
[cpg]


I think it's tough because I can't talk to anyone about it, but I think about this and that alone because I have no choice.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（夕方）******************************************************



As a result of ......, I didn't come up with any good ideas.
[cpg]


I can't help what I couldn't come up with. I try to leave the school.
[cpg]


[OnName num="female_student"]
I was going to leave the school. Let's go home together.
[cpg cn=true]


I was about to get caught by my girl friend again. This time it was going to be trouble, so I ran away.
[cpg]


I knew I would look suspicious if I did this, but I didn't want to go out with girls anymore. It's too hard.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="4/5" time=800]

[VOICE f="Kokoro093"]
[OnName num="kokoro"]
......That's tough."
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]

Do you sympathize with me, Koyi? I'm tired of it.
[cpg]


If we keep switching, I'm going to start thinking about what I'm going to do .......
[cpg]


Koyi accepted my talk sincerely.
[cpg]


She is a valuable source of support. But I can't keep bothering her, can I?
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************




[VOICE f="Shizuku292"]
[OnName num="shizuku(yu)"]
"...... Grandpa. Do you really don't have enough money to fix it?
[cpg cn=true]


[OnName num="grandfather"]
Are you doubting me?　I'd like to put my lovely grandchildren back together again.
[cpg cn=true]


You're cutting off your tongue, aren't you? But if that's the way he's going to treat me, I don't have a choice.
[cpg]


We have to come up with a plan. We need to get Grandpa to tell us that he has money.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[OnName num="yu(shizuku)"]
"A plan?　I've already thought of one.
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

That's a lie. When did you come up with it?
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Shizuku293"]
[OnName num="shizuku(yu)"]
Really?　How are you going to get me to say it ......?"
[cpg cn=true]


[OnName num="yu(shizuku)"]
Why don't you just pretend you're back?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

I didn't get it right away. I didn't understand it right away, but gradually I did.
[cpg]


I could make them think that I was back to normal by accident.
[cpg]


Then, there would be no need to fix the machine, and I might just blurt it out at that time.
[cpg]


Then I could lead him on.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Shizuku294"]
[OnName num="shizuku(yu)"]
I'm sure that would be a good idea. That would be a good idea. I'll let her know right away.
[cpg cn=true]


;//移植のためシーンをカットしています


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


[FACE method="bow_7" pos="4/5"]

I looked at my sister. I looked at her with the intention of discussing it with her and Shizuku afterwards.
[cpg]

[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina384"]
[OnName num="marina"]
I looked at her and said, "......, what's going on?　Shizuku, you're staring at me so intently.
[cpg cn=true]


Sometimes your sister is so dull, isn't she? No, are you aware of it and hiding it?
[cpg]


If so, he is a very clever man. I can't be sure, though.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[OnName num="yu(shizuku)"]
So ...... the three of us will show up and pretend we're back together. What do you think?
[cpg cn=true]


She nodded her head and said, "I see.
[cpg]


I'm sure she must have felt something similar to the response I felt. But," she shook her head at the end.
[cpg]


She shook her head at the end. Why?
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina385"]
[OnName num="marina"]
She shook her head. You can't even pretend to be me.
[cpg cn=true]


[OnName num="yu(shizuku)"]
I think you're persuasive there, too. If I really looked like you, you'd think I was back, wouldn't you?
[cpg cn=true]


You're right again. Is Shizuku really that sharp?
[cpg]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Marina386"]
[OnName num="marina"]
"Then try pretending to be Yu for ten minutes.
[cpg cn=true]


[OnName num="yu(shizuku)"]
"Okay. Okay.
[cpg cn=true]


You already don't look like me. Is it okay?
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se000"]
;//【ＳＥ】『時計の音　カチコチ』

Ten minutes passed.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[OnName num="yu(shizuku)"]
"I wonder about ......."
[cpg cn=true]


I don't know, I don't know. I don't see any desire to imitate me.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina387"]
[OnName num="marina"]
First of all, you should at least say "I" in the first person.
[cpg cn=true]


[OnName num="yu(shizuku)"]
"Oh, I said I, didn't I?"
[cpg cn=true]


Indeed. I said it a few times as if I remembered.
[cpg]


I'm sure that if you and I work on it together, you'll be able to act it out in time.
[cpg]


Or so I would like to think: ......
[cpg]



;//ＢＫ
[window target=false]
[free time=800]
[BG f="b_05_1.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]


From there, we continued to practice acting for a long time.
[cpg]


I had to practice for when I became the older sister, since she and Shizuku switched places in the middle of the performance.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



When I woke up in the morning, it was just me and Shizuku again.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuku311"]
[OnName num="shizuku(yu)"]
"Good morning, big brother."
[cpg cn=true]


I tried to act like Shizuku. I wondered if my practice had paid off.
[cpg]


[OnName num="yu(shizuku)"]
Good morning, Shizuku. Sleeping in again today?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

...... was a little bit like that. I'm not sure if it's a good idea or not.
[cpg]


[OnName num="yu(shizuku)"]
The first thing to do is to make sure you have a good time. Come on, let's eat up.
[cpg cn=true]


You see, something is a little different. Well, I can just barely fake the grandfather's eyes. ......?
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[OnName num="yu(shizuku)"]
Hey, Koyo. Koyo, it's a nice morning again, isn't it?
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Kokoro094"]
[OnName num="kokoro"]
"Eh,...... yeah. Who is it?
[cpg cn=true]


[OnName num="yu(shizuku)"]
I'm Shizuku. I've been told to act like myself lately.
[cpg cn=true]


Oh ...... says Koyi. I wonder if she was convinced.
[cpg]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Shizuku312"]
[OnName num="shizuku(yu)"]
I'm going to go now, Shizuku. See you later.
[cpg cn=true]


[OnName num="yu(shizuku)"]
I'll see you later. See you later.
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『歩く』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（昼）******************************************************



I headed back to the school with a little apprehension.
[cpg]


At the school, I had to act the part of Shizuku again. I'm used to it, but it's hard.
[cpg]


[OnName num="female_student"]
"Shizuku, do you want to have dinner with me?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Shizuku313"]
[OnName num="shizuku(yu)"]
"Yeah, sure. Let's eat together.
[cpg cn=true]


It was better to say no at this point. It's a good idea to say no. You don't have to have a conversation, and you don't have to reveal anything.
[cpg]


But I knew the relationship Shizuku had built with him. I can't afford to ruin it.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The conversation is casual and goes on without mentioning the other person's name.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（昼）******************************************************




[VOICE f="Shizuku314"]
[OnName num="shizuku(yu)"]
I think, "Haaaa...... no, it's just a matter of patience for a while longer."
[cpg cn=true]


I rouse myself. Then, during my lunch break, I received an unexpected visitor.
[cpg]


[OnName num="yu(shizuku)"]
Hello. Hello, big brother."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
I was speechless. I didn't know what to say.
[cpg]


What's wrong with me, what's wrong with my school?　Did you just slip out?
[cpg]


[OnName num="yu(shizuku)"]
I told them I was Shizuku's family and they let me right through. I'm supposed to be here to deliver something I forgot, you know."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
I was supposed to be here to deliver a lost and found.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（昼）******************************************************

In the end, the drop that looked like me left. ......
[cpg]


Still, I think the behavior was a little too conspicuous. The uniform was different, too.
[cpg]


Did he come to deliver a forgotten item or something under that guise?
[cpg]


But I think she might have been trying to cover it up.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（夕方）******************************************************


[SE f=se000]
;//【ＳＥ】『学園のチャイム』

Then, in the evening, after school.
[cpg]




[SE f="se001"]
;//【ＳＥ】『歩く』


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


On the way back home, I saw Shizuku and Koyi talking.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kokoro095"]
[OnName num="kokoro"]
She said, "I see,......, so are you acting to look like Yu-kun?"
[cpg cn=true]


[OnName num="yu(shizuku)"]
I'm acting to look more or less like that now. I'm looking a little like that now, aren't I?
[cpg cn=true]


[OnName num="yu(shizuku)"]
I've been thinking a lot about it since then. I've been thinking about a lot of things since then.
[cpg cn=true]


I've been thinking about a lot of things since then.
[cpg]


I think I'm becoming a lot more like me. I'm sure this won't be a problem for you ......?
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="4/5" time=800]

[OnName num="yu(shizuku)"]
"So, you're drop ......, you're here?"
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Shizuku330"]
[OnName num="shizuku(yu)"]
...... yeah, bro."
[cpg cn=true]


I was called "Shizuku" and I answered "big brother" as quickly as I could.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina388"]
[OnName num="marina"]
'Are you sure there's a drop in there?　It looks like Yoo herself. ......
[cpg cn=true]


[OnName num="yu(shizuku)"]
I said, "That's a bit harsh, sis. I can't quite catch the inflection in your voice, though.
[cpg cn=true]


[OnName num="yu(shizuku)"]
I've lived with her for a long time. You've lived with me for a long time, so you can imitate me a little.
[cpg cn=true]


Then what was the point of not being able to imitate her well at first?
[cpg]


I guess I was out of practice after all.　Acting like me at my school all day today must have worked, I'm sure.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Shizuku331"]
[OnName num="shizuku(yu)"]
......That's why, sis.
[cpg cn=true]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[FACE method="shock_5" pos="2/5"]
[FACE method="shock_5" pos="4/5"]


I was about to say, "Let's get to work on the plan,......," when we switched places again.
[cpg]


[OnName num="yu(marina)"]
I was about to say, "...... am I Yoo this time?"
[cpg cn=true]

[FACE method="bow_7" pos="2/5"]
[FACE method="change_7" pos="4/5"]
[VOICE f="Marina389"]
[OnName num="marina(yu)"]
It looks like it."
[cpg cn=true]


Shizuku plopped down on the sofa and said, "I'm so tired. I'm tired," she said.
[cpg]


[OnName num="yu(marina)"]
I can't be tired," she said. If we're going to do this, it's going to take some time.
[cpg cn=true]


[OnName num="yu(marina)"]
We'd have to pretend that we weren't replacing each other to the extent that it would look like we weren't replacing each other anymore."
[cpg cn=true]


It gets confusing, but the point is: ......
[cpg]


I guess what I'm trying to say is that the replacement hasn't happened for a day or two before.
[cpg]


I guess it means that Grandpa won't be satisfied unless we each pretend to be the same person for at least a week.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿麻莉奈の部屋』（夕方）******************************************************

Then we moved to my sister's room.
[cpg]


I decided to ask her what I had wanted to ask her for a long time.
[cpg]


I asked her how long she had been in love with me.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku333"]
[OnName num="shizuku"]
She said, "Well, I like your kindness. I guess you could call it receptiveness.
[cpg cn=true]


She says, "Even in this case, you care about everyone more than anyone else, don't you?　I wonder if that was the case.
[cpg]


I wonder if she did. I don't feel that way.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Shizuku334"]
[OnName num="shizuku"]
I don't feel that way about him, but he said, "You know I don't like you because of your face. I like you even if we switch.
[cpg cn=true]


...... That's a killer phrase, indeed.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ

[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈（由宇）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------


[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



Then our plan began.
[cpg]


We each acted like it for a week.
[cpg]


Mom didn't seem to notice. Grandpa probably didn't notice either.
[cpg]


The moment of switching was a little awkward. ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



Time passed without being discovered. A week passed.
[cpg]


Mom and Dad were gone, and it was just Grandpa and the three of us.
[cpg]



[OnName num="yu(shizuku)"]
Grandpa said, "Hey, Grandpa, ...... I have to tell you something.
[cpg cn=true]


[OnName num="grandfather"]
What is it?　What is it?
[cpg cn=true]


[OnName num="yu(shizuku)"]
He said, "It seems we've been switching places for the past week. We haven't switched in a week.
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Shizuku343"]
[OnName num="shizuku(marina)"]
"......You're right, you're right. We used to switch every day.
[cpg cn=true]


[OnName num="grandfather"]
"Is that right, ......?　So we don't need a machine to fix it?
[cpg cn=true]


[OnName num="yu(shizuku)"]
"Probably. Maybe. You don't have the money anyway, do you?
[cpg cn=true]


[OnName num="grandfather"]
Oh, yeah. Yeah, you're right, I don't have any money.
[cpg cn=true]


That's good. We're almost there.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina398"]
[OnName num="marina(yu)"]
"Did you really have no money?　Saving up or selling the machines you have?"
[cpg cn=true]


[OnName num="grandfather"]
That's ......, or I can tell you already.
[cpg cn=true]


[OnName num="grandfather"]
I had money, that's all I had.
[cpg cn=true]


[FACE method="change_5" pos="2/5"]
[FACE method="change_5" pos="4/5"]

I said it. I said it now. And Grandpa dug his grave even deeper.
[cpg]


[OnName num="grandfather"]
But a replacement is a rare case, isn't it?　I wanted to see how it went.
[cpg cn=true]


[OnName num="grandfather"]
So that's why I didn't tell you about it until now, but now you're back. ......
[cpg cn=true]

[FACE method="change_3" pos="2/5"]
[FACE method="change_3" pos="4/5"]
[OnName num="yu(shizuku)"]
Is it true what you just said?　I told you, I have money, didn't I?
[cpg cn=true]


I, who had been playing the role of a drop, revealed my true nature and crowded Grandpa.
[cpg]


[OnName num="grandfather"]
What?　What happened all of a sudden?
[cpg cn=true]


[FACE method="shock_3" pos="2/5"]
[VOICE f="Marina399"]
[OnName num="marina(yu)"]
Grandpa, you lied to me, didn't you?　That's not fair.
[cpg cn=true]


[OnName num="grandfather"]
You lied to me?
[cpg cn=true]


[FACE method="shake_3" pos="4/5"]
[VOICE f="Shizuku344"]
[OnName num="shizuku(marina)"]
How can you say that, Grandpa?
[cpg cn=true]


We three heard it. The three of us pursued him.
[cpg]


We all three of us asked him.
[cpg]


[OnName num="grandfather"]
He said, "I can't help it, ....... It's known now. ......
[cpg cn=true]


He grumbled and complained, but promised to bring us back to normal.
[cpg]


[OnName num="mother"]
I'm back ......, what's going on?　The four of us gathered.
[cpg cn=true]


[OnName num="yu(shizuku)"]
Oh, nothing, Mom. It's nothing, Mom.
[cpg cn=true]


The actor has really gotten into the swing of things. The first thing to do is to get a good idea of what you're looking for.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


A few more days passed. Grandpa had built a machine to help her get back to normal, so we gathered in the lab.
[cpg]


[OnName num="grandfather"]
He told us, "Imagine your body. Or should I say, "Imagine you are living in your own body.
[cpg cn=true]


[OnName num="grandfather"]
We still don't know where the spirit is. It's a small thing that can go wrong.
[cpg cn=true]


[OnName num="yu(shizuku)"]
I understand. I'll be careful.
[cpg cn=true]


The moment had finally arrived. We can go back to the way we were.
[cpg]



;//ルート分岐。ここまでの女性化ポイントによって決まる


[if exp={getFlagValue("pi_fi") == 1 }]
[jump target=*tag_02]
[endif]

[if exp={getFlagValue("pi_fi") == 2 }]
[jump target=*tag_02]
[endif]



[jump storage="ep009.ks" target="*root02_1"]


*tag_02|I thought the body of the Shizuku was good.
[jump storage="ep010.ks" target="*tag_02"]
