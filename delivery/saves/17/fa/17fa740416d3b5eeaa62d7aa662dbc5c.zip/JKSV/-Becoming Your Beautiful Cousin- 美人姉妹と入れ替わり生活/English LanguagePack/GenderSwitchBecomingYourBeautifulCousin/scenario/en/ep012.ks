
*start


;//==============================
;//女性化ポイントが２以上の場合
*tag_03|If the heart becomes a woman, too
*root_bad|If the heart becomes a woman, too


[SCENE id=12]


It occurred to me. I thought to myself, "Why don't I just be okay without it, instead of looking for a way to go back to the way it was?
[cpg]


I should become a woman in body and soul. That's what I thought.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------

;#################################################
*Ep012|If the heart becomes a woman, too
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



The next time I woke up, I was an older sister.
[cpg]


Acting as an older sister. I felt like my heart would become hers, too.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Marina443"]
[OnName num="marina(yu)"]
Good morning, Yu.
[cpg cn=true]


[OnName num="yu(marina)"]
Good morning, sis.
[cpg cn=true]


Now, a drop is a drop, and she is in my body.
[cpg]


When this happens, it's really like I've become my sister.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


How to turn your mind into a woman. I don't need to think about it, I think I just need to fuck someone.
[cpg]


But I can't do it with just anyone.
[cpg]


I feel like I can't do it with anyone. ......
[cpg]


And if push came to shove, I could be the big sister in my body. That's what I was thinking.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の通う学園＿教室』（昼）******************************************************


And the university my sister attends. Lecture ended at noon and a male student spoke to her.
[cpg]


[OnName num="male_student"]
He said, "Um, Mr. Tokiwa. Can I talk to you for a minute?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina444"]
[OnName num="marina(yu)"]
"...... what is it? You wanted to see me?
[cpg cn=true]


I act like a big sister. Partly because I don't want to be discovered, but also to get used to being a woman.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************




The boy took me to a park in the city.
[cpg]


I wondered what he was doing here, and waited for him to say something.
[cpg]


[OnName num="male_student"]
'I've always loved you. Please go out with me. ......"
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]

I was at a loss for what to say. I was at a loss for what to do.
[cpg]


He didn't seem intimidated. I think he's a good-looking guy.
[cpg]


That said, I don't want to go out with him without asking my sister to judge .......
[cpg]


Shall we consider this as part of making our own hearts into women?
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina445"]
[OnName num="marina(yu)"]
I'm ...... happy for you, but I'm not ready either."
[cpg cn=true]


What a thoughtful thing to say.
[cpg]


[OnName num="male_student"]
'What do you mean ...... by that?　I mean, I'm not sure if it's a good idea or not.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Marina446"]
[OnName num="marina(yu)"]
I mean I need to think about it. You know what I mean."
[cpg cn=true]



;//ＢＫ
;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



Before it was too late, I left him.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



I went home. Family conversation.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]

[OnName num="grandfather"]
'...... are all three of you okay?'
[cpg cn=true]


Grandpa whispered to me while Mom and Dad were out of the room.
[cpg]


[OnName num="yu(marina)"]
I'm not doing so well. I'm afraid I'm going to turn into a man.
[cpg cn=true]


My sister feels the same way.
[cpg]


I guess I don't have a choice then, even if I'm turning into a woman.
[cpg]


[OnName num="grandfather"]
I'm sorry, I'd like to change it back right away. ......
[cpg cn=true]

[FACE method="change_7" pos="2/5"]
[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku463"]
[OnName num="shizuku"]
It's not your fault, Grandpa. No, it's your fault.
[cpg cn=true]


The drops spit a bit of venom. Grandpa got a somber look on his face.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



And the next morning. It seemed that our switched situations were still the same.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************


I acted as if I were my sister. She lives her life as if she were me.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


We headed for her college. I'm used to it by now, I don't make any mistakes.
[cpg]


If I went to the lecture again today, I wondered if the boy would approach me. I had such expectations.
[cpg]


I was hoping that I would be able to talk to the boy again.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の通う学園＿教室』（昼）******************************************************



Then, I was in the middle of a lecture.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（雫）　雫（由宇）
;//と変更してください
;//----------------------------------------


[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（昼）******************************************************


[FACE method="shock_5" pos="2/3"]


The scenery changed again. Where am I ......?　I mean, what kind of situation is this?
[cpg]


[OnName num="male_student"]
'Hey, I'm just asking you to go out with me for a minute.'
[cpg cn=true]



Now Shizuku seemed to be entangled with a boy. She was cornered in the hallway during class, right up to the wall.
[cpg]


[FADEOUTBGM]

[FACE method="shake_7" pos="2/3"]

I know what to do in a situation like this. I'm not sure what I'm supposed to do.
[cpg]

[BGM f="bg_da"]
[WAIT time=100]

But I wanted to just let it go.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（夕方）******************************************************



I was being led by the hand down the hallway. Normally, I would have refused at any cost.
[cpg]


But I didn't. I wanted to be swept away.
[cpg]


The guy was also very careless, moving to a different place just because the class was over.
[cpg]


What if he had run away during that time? It would ruin the mood.
[cpg]


I followed his lead, never saying a word about my feelings.
[cpg]



;//ＢＫ
;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



My mind was already completely insane. The pleasure was driving me crazy.
[cpg]


How would I explain this to Shizuku and my sister? How could I explain it to them?
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



[OnName num="grandfather"]
"Welcome back. You're back late, Shizuku.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Shizuku494"]
[OnName num="shizuku(yu)"]
Well, I had some business to attend to.
[cpg cn=true]


[OnName num="yu(marina)"]
What is it?　I don't know. ......
[cpg cn=true]


My sister, who pretends to be me, has a hunch.
[cpg]


The actuality that you're in a different person's body and you've got something to do is certainly odd.
[cpg]


I can't fool her. And the premonition was becoming more and more real.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



In my room, we had a strategy meeting to get back to normal.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Marina462"]
[OnName num="marina(shizuku)"]
I said, "...... there was someone who made a pass at my sister. Who was that?"
[cpg cn=true]


[OnName num="yu(marina)"]
She said, "Oh, it's okay. Leave that kind of thing alone.
[cpg cn=true]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈（由宇）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------

[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

;//[SE f="se001"]
;//【ＳＥ】『歩く』



Next morning. About the time I was going to school, I switched with my sister's body.
[cpg]


I almost fell. Watch out, watch out ......
[cpg]


There was someone wooing me ......, huh? I don't know what to do.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の通う学園＿教室』（朝）******************************************************



After the morning lecture. I was approached by that guy.
[cpg]


[OnName num="male_student"]
He said, "Mr. Tokiwa, what happened to you yesterday?　You didn't seem to recognize me."
[cpg cn=true]


I told him not to worry about it. I know it's not something you don't mind telling people not to mind, but there's no other way to put it.
[cpg]

;//移植のためシーンをカットしています

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（雫）　雫（由宇）
;//と変更してください
;//----------------------------------------

[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=2100]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


;//[SE f="se000"]
;//【ＳＥ】『歩く』

And the next day.
[cpg]


[OnName num="yu(marina)"]
Then, the next day, he said, "Well, that's all for now. Bye, Yoo."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Shizuku495"]
[OnName num="shizuku(yu)"]
"Yeah, see you later, sis. See you later, sis.
[cpg cn=true]


I waved to her as she entered my body.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（朝）******************************************************



[OnName num="male_student"]
I'm not sure if this is a good idea or not. You know what you have to do after school today, don't you ......?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Shizuku496"]
[OnName num="shizuku(yu)"]
I know .......
[cpg cn=true]


I'm not sure if it's a good idea or not, but I'm sure it's a good idea.
[cpg]

But it was more convenient for me.
[cpg]


;//移植のためシーンをカットしています



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



I was going home before it got too late.
[cpg]


I can be with those boys anytime I want. Then I wouldn't be in such a hurry.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[OnName num="yu(marina)"]
"Oh, welcome back ...... haha."
[cpg cn=true]


She seemed to be tired of being constantly replaced.
[cpg]


;//まだ処女を失ったことに気づいてはいない。
She still doesn't realize that I'm doing whatever I want.
[cpg]


That means I can still behave freely.
[cpg]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Marina480"]
[OnName num="marina(shizuku)"]
I'm home. What's wrong, you look so serious.
[cpg cn=true]


[OnName num="yu(marina)"]
"How can you not be serious, Shizuku?"
[cpg cn=true]

[FACE method="shake_2" pos="2/5"]

No, no, no. I don't think it's a compliment.
[cpg]


The first thing you need to do is to make sure that you have a good understanding of what is going on in your life.
[cpg]


Would I then not be able to act freely?
[cpg]


No, that's not true. Since we switch bodies, there is no way for us to stop each other's activities.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈（由宇）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------

[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



In the time it took us to get to dinner, we switched again. I switched with my sister, she switched with Shizuku. We went in opposite directions.
[cpg]


No problem. I can act like it.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I went to sleep in her room.
[cpg]


[window target=false]
[BG f="b_07_1.ui" time=1000]
[WAIT time=2000]
;//[BG f="b_05_1.ui" time=1000]
;//[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



I woke up and got ready for bed. I woke up and got ready for bed.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="4/5" time=800]
[VOICE f="Shizuku510"]
[OnName num="shizuku(marina)"]
She said, "Hey, Shizuku ......, I've noticed something.
[cpg cn=true]


[OnName num="yu(shizuku)"]
What is it?　Is it serious?
[cpg cn=true]


I was wondering if she had noticed it. I'm not sure if she noticed or not.
[cpg]


If so, it's the same thing I'm going to do.
[cpg]


;//移植のためシーンをカットしています

I don't know if I can keep this up for very long, even if it is .......
[cpg]

There is no way that my being with another man would remain undetected.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈　雫
;//と変更してください
;//----------------------------------------

[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


The next holiday morning. We each woke up in our own body.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="4/5" time=800]
[VOICE f="Shizuku511"]
[OnName num="shizuku"]
I woke up in my own body and asked, "Oh, brother, what's the meaning of this?
[cpg cn=true]


Shizuku turned bloodthirsty and came up to me.
[cpg]


She was a little further away from me with a serious expression on her face.
[cpg]


The other day she said she wanted to talk to me about the case.
[cpg]


How am I going to excuse myself? I thought with a somewhat broken head.
[cpg]


[OnName num="yu"]
I was threatened by .......
[cpg cn=true]


[OnName num="yu"]
I couldn't resist with my woman's body.
[cpg cn=true]


[FACE method="bow_3" pos="2/5"]
[VOICE f="sMarina015"]
[OnName num="marina"]
Then, what about me?
[cpg cn=true]


[OnName num="yu"]
You're just like her, .......
[cpg cn=true]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Marina500"]
[OnName num="marina"]
That's a lie. There was a man who came on to me, and he told me everything.
[cpg cn=true]


Oh, really? They already know everything about you. ......
[cpg]


Of course Shizuku would never do such a thing.
[cpg]


Of course I would be pursued. Of course.
[cpg]


[FACE method="bow_3" pos="4/5"]
[VOICE f="sShizuku017"]
[OnName num="shizuku"]
What do you think, big brother?
[cpg cn=true]


[OnName num="yu"]
"...... that's ......"
[cpg cn=true]


I was at a loss for words. I was pursued by the two of them, and I couldn't say anything else.
[cpg]


;//とんでもないことをしたとは思ってる。その自覚は行為の最中もあった。
I know I did a terrible thing. I was aware of that even while the man was pressing me.
[cpg]


That's why I was excited. But I couldn't say anything about it.
[cpg]


[FACE method="shake_4" pos="2/5"]
[VOICE f="Marina501"]
[OnName num="marina"]
What I don't understand is the motive. He didn't seem to be asking for money in return.
[cpg cn=true]


[OnName num="yu"]
I'm sorry.
[cpg cn=true]


My sister got angry at me for not apologizing without a proper explanation.
[cpg]


[FACE method="bow_7" pos="2/5"]
[VOICE f="sMarina016"]
[OnName num="marina"]
I was so angry that I didn't explain myself properly. "Maybe you ...... just wanted to be with a guy?"
[cpg cn=true]


I fell silent. That was an affirmative.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************


We had lunch with the family face to face.
[cpg]


[OnName num="grandfather"]
"What's the matter, you three look ...... pale.
[cpg cn=true]


Of course, we all look pale. The reason is different for each of us.
[cpg]


I was pale because I was thinking about how to cover it up.
[cpg]


And then the drops started to cry. She must be in shock.
[cpg]

Either way, I realized once again that I had done something terrible.
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------

[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


After that, we continued to switch places.
[cpg]


[OnName num="male_student"]
Why?　Did you start to dislike me, Tokiwa-san?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina503"]
[OnName num="marina(yu)"]
"I'm sorry, ....... I can't do it with you anymore.
[cpg cn=true]


This is fine with me. This will solve everything.
[cpg]


[OnName num="male_student"]
"I see...I get it. You've been acting strange lately, haven't you?
[cpg cn=true]


[OnName num="male_student"]
Thank you for letting me dream for a while. Bye.
[cpg cn=true]


The problem is the drops. This one is not so simple.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈　雫
;//と変更してください
;//----------------------------------------
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



The problem is that Shizuku has started to self-mutilate.
[cpg]


No matter whose body it was in. There were times when I had wounds on my body without my knowledge.
[cpg]


I guess something similar is happening to my sister.
[cpg]


She seemed to be at her wits' end and spending her days in a stupor.
[cpg]


I can no longer use my sister's or Shizuku's body on my own because of my guilt.
[cpg]


[FACE method="shake_4" pos="4/5"]
[VOICE f="Shizuku516"]
[OnName num="shizuku"]
I wonder what will happen to us now."
[cpg cn=true]


[FACE method="shake_4" pos="2/5"]
[VOICE f="Marina504"]
[OnName num="marina"]
I don't ...... know."
[cpg cn=true]


We will continue to swap. I am sure that we will continue to swap.
[cpg]


My sins cannot be atoned for in any way. Still, the punishment continues: ......
[cpg]

[SCENE id=18]

[jump storage="epend.ks" target="*back_title"]

;//BADEND
;//ＥＮＤ：バッドエンドルート

;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


