
*start

;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈（由宇）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------

;//==============================
;//女性化ポイントが１以上の場合
*start|I thought I liked your body.
*tag_02|I thought I liked your body.
*root02_2|I thought I liked your body.

[SCENE id=10]


But then I thought to myself.
[cpg]


I wondered if I would have to give up all the pleasure I had felt as a woman.
[cpg]


If that was the case, I wanted to be fixed as a woman.
[cpg]


If possible, I would prefer to be in Shizuku's body. ......
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈　雫（由宇）
;//と変更してください
;//----------------------------------------

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


This evil thought affected the machine.
[cpg]


My body and Shizuku's body were swapped and I was fixed in place.
[cpg]

;#################################################
*Ep010|I thought I liked your body.
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



It was a big deal for a while.
[cpg]


According to Grandpa, the switching was a coincidence, and it would be difficult to reproduce.
[cpg]


Since that warp experiment was a failure to begin with, even I can imagine how difficult it would be to fail in the same way.
[cpg]


It was late that night, so I decided to go to sleep. ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


[OnName num="yu(shizuku)"]
'Brother, why ......?　Why did you even want to be me?"
[cpg cn=true]


Grandpa also explained why he was fixed with being replaced.
[cpg]


I assumed that the current situation was happening because someone was strongly reminded that they wanted to be replaced.
[cpg]


And I couldn't deny it. ...... That's like affirming it already.
[cpg]


[OnName num="yu(shizuku)"]
'Am I going to be a boy forever?　I don't want to do that,......!"
[cpg cn=true]


That way of speaking is Shizuku. The angry gesture is also a drop, but it looks like me.
[cpg]

[FACE method="change_4" pos="2/3"]

I realized once again that I had wished for something terrible.
[cpg]


But there is nothing I can do about it now. We can never go back to the way we were.
[cpg]


I saw Shizuku clinging to my body, crying. I couldn't do anything for her.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（昼）******************************************************



Time passed. I had to live as Shizuku and she had to live as me.
[cpg]


However, Shizuku stayed at home as me.
[cpg]


I think it's understandable. I have accepted my female body, but she has not.
[cpg]


I don't think I've ever felt such pain. I asked to be replaced in exchange for her future.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（夕）******************************************************



More time passed and I graduated from the school.
[cpg]


After graduation, I started dating a completely different guy.
[cpg]


I felt bad for Shizuku, but I knew I had to at least have my own happiness.
[cpg]


In the meantime, we had a baby and ......
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



We got married as it were. I have now left the Tokiwa family and changed my last name.
[cpg]


[OnName num="shizuku(yu)_husband"]
What's wrong?　You look so gloomy.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuku379"]
[OnName num="shizuku(yu)"]
'No, it's nothing. Don't worry about me.
[cpg cn=true]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

The first person, "I," is becoming a part of her vocabulary.
[cpg]


I am me. It has become natural for him to say, "It's me, not me.
[cpg]


Still, I try to visit Shizuku once in a while, even though she is confined to the house.
[cpg]


She still refers to herself as "I". She still retains the face of the woman she was when she was a woman.
[cpg]


She has not become a man. It is I who am making her taste the pain.
[cpg]


;//移植のためシーンをカットしています



[window target=false]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



The months go by. I have a baby and my stomach is completely flat.
[cpg]


In the meantime, Shizuku has remained in her room. I don't know how many times I visited Shizuku's room, but I've lost count.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************


[FACE method="bow_7" pos="2/5"]
[VOICE f="Marina412"]
[OnName num="marina"]
'Oh, Shizuku ......, you came again today.'
[cpg cn=true]


My sister is also married, but she lives in this house.
[cpg]


I guess she has a thing for Shizuku. She still called me "Shizuku," but ......
[cpg]


My sister also calls that person who is now locked up in her room "Shizuku". I'm still dragging it out.
[cpg]


...... I myself feel that I have betrayed her.
[cpg]


So this is at least an atonement.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



[OnName num="yu(shizuku)"]
I'm here again. Big brother.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Shizuku394"]
[OnName num="shizuku(yu)"]
"......Yes. After all, I'm worried about you.
[cpg cn=true]


[OnName num="yu(shizuku)"]
"......, stop talking like that. It's as if you're not my brother anymore.
[cpg cn=true]


A sighing drop. He has a dark look on his face.
[cpg]


[OnName num="yu(shizuku)"]
I really feel as if my brother has become Shizuku.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Shizuku395"]
[OnName num="shizuku(yu)"]
Is there anything I can do for you?　Or something you'd like me to do? ......"
[cpg cn=true]


I say it every time. Nothing, I can usually answer.
[cpg]


[OnName num="yu(shizuku)"]
I can usually answer, "Nothing. ......
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



The relationship is twisted and twisted. I can usually answer, "Nothing," but this is a twisted relationship.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina413"]
[OnName num="marina"]
You don't have to go overboard about the ...... drop. I think you should live your own life.
[cpg cn=true]


I was puzzled when my sister said that to me one day, but I knew ...... what the answer would be.
[cpg]


Even if she tried to stop me, I would let her do what she wanted to do.
[cpg]


I had made a mess of Shizuku's life.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


I couldn't tell my husband everything. I have a cousin who broke her heart because of me.
[cpg]


I could tell him that much, but I couldn't explain that the original body I switched with was that cousin's .......
[cpg]


Even if I did, they wouldn't believe me.
[cpg]


I wasn't sure what to say to him, but he forgave me for everything.
[cpg]


No, I was telling him, knowing he would forgive me.
[cpg]


It makes me feel like a shallow person, working for my own convenience to no end.
[cpg]


And I also thought it was almost the right thing to do.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina414"]
[OnName num="marina"]
;//「……また来たのね。もう来なくていいのに」
He said, "...... here you are again. You don't have to worry anymore."
[cpg cn=true]


She said something like that. Well, from her point of view, I guess so.
[cpg]


She must want me to be happy.
[cpg]


She probably thinks that neither of us will be happy if things continue as they are.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



......This room used to be my room. I can still see the face of it.
[cpg]


It looks as if time has stopped since then.
[cpg]


No, I am sure that time has stopped. At least, time has not progressed for Shizuku since then.
[cpg]


Maybe there is no salvation for her.
[cpg]


Maybe there is nothing I can do.
[cpg]


But I will continue to atone for my sins. I will do whatever it takes to satisfy her.
[cpg]


I wonder if someday our relationship will be repaired and Shizuku will accept being a man.
[cpg]

[SCENE id=16]

[jump storage="epend.ks" target="*start"]
;//ＥＮＤ：ヒロイン２ルート２



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

