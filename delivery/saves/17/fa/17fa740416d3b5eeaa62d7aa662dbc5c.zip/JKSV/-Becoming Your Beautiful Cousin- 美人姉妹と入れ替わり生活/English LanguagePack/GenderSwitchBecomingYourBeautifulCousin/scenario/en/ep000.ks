
*start

;//性換姉妹　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//麻莉奈　裸　私服(大学生なので制服は無し)
;//雫　　　裸　私服　制服
;//小衣　　裸　私服　制服
;//以下音声なし
;//由宇 祖父 母 父 女子学生Ａ 女子学生Ｂ 男子学生
;//女子学生 男の声 男 雫（由宇）の夫 男子学生Ａ 男子学生Ｂ
;//途中、名前欄が変更されることがありますがその際は
;//（）内に入っているのがキャラクターの精神です
;//ＣＧ内容につきましての文章は（）内が外見です


;#################################################
*Ep000|Grandpa was an inventor.
;#################################################

[SCENE id=0]

[stflag pi_fi = 0]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


In any age, geniuses never know what they will do.
[cpg]


Our peaceful routine was disrupted by that genius.
[cpg]


It's not that this genius is our enemy. He's not our ally, he's one of us.
[cpg]


My grandpa is an inventor.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



Yu Tokiwa. He is a little bit far from ordinary male students everywhere .......
[cpg]


My parents are always busy with work, and they are the kind of people who are overseas right now.
[cpg]


So I'm allowed to live at my uncle's house.
[cpg]


I'm already comfortable with that family, and calling them mom and dad is normal. ......
[cpg]


Even to his cousins, he calls them "sister" or something like that.
[cpg]


And my unusual episode doesn't end here.
[cpg]


It's a bit of a special family, with an uncle who is a doctor and a grandfather who is an inventor.
[cpg]


I don't think this is very common. Especially having a grandfather who is an inventor.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Marina001"]
[OnName num="marina"]
I'm home. ...... Where's Grandpa?"
[cpg cn=true]

[window target=false]
[free time=500]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]
[window target=true]

It is early afternoon on a holiday. Marina, my older cousin, comes home when I finish lunch.
[cpg]


She is a college girl. Today she was going out with a friend or something.
[cpg]


A cool beauty with a great style, but someone you can't look at in that way because they are family.
[cpg]

[window target=false]
[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]
[window target=true]

[OnName num="yu"]
Still in the lab. They're turning boiled eggs back into raw eggs."
[cpg cn=true]


[free time=500]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=1000]

[VOICE f="Shizuku001"]
[OnName num="shizuku"]
I'm like, "Oh my God, you're doing that. You're inventing it like the Kid."
[cpg cn=true]


[window target=false]
[free time=500]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]
[window target=true]

Lying on the couch is Shizuku. She is my younger cousin. She is well styled like her older sister, but short.
[cpg]


Maybe it's called loli big tits, but I can't see her as a woman for the same reason as my sister.
[cpg]

[window target=false]
[free time=500]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=1000]
[window target=true]

[OnName num="yu"]
"Kid?　What the hell is that?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Shizuku002"]
[OnName num="shizuku"]
'That's the kind of thing you see in old RPGs.'
[cpg cn=true]

[free time=1000]

[OnName num="yu"]
'Well, okay, but it's time for you to go check on your ...... sister, too.
[cpg cn=true]


My grandfather must have been quite old, but when it comes to inventions, he is the kind of person who immerses himself in them without eating or drinking.
[cpg]


I'm starting to worry about my health. I don't want to have a bad breakdown in the lab or something.
[cpg]


[OnName num="yu"]
"Please, sis. ...... sis?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Marina002"]
[OnName num="marina"]
But if you could really turn an egg back into a raw egg, it could be used in medicine, it would win a Nobel Prize.
[cpg cn=true]


[OnName num="yu"]
Yeah, is that right?　Whatever. ......"
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


So I asked my sister to call my grandfather.
[cpg]


Grandpa, you're a little cold towards me. Maybe because I'm a man.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



[OnName num="grandfather"]
No, no, no, no, no. ......, that's useless.
[cpg cn=true]



[FACE method="bow_7" pos="2/5"]
[VOICE f="Marina003"]
[OnName num="marina"]
Yes, it's a shame. Too bad. ...... would really be the invention of the century if it were possible."
[cpg cn=true]


I wonder if it is such a valuable invention. I can't even imagine.
[cpg]


[OnName num="grandfather"]
You have no idea how great this invention is!　It could even be used to cure cancer."
[cpg cn=true]


[OnName num="yu"]
...... grandpa, why don't you stop talking like that?"
[cpg cn=true]


[OnName num="grandfather"]
"Nah ...... you got a problem with the way I talk!"
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Shizuku003"]
[OnName num="shizuku"]
I thought it was your grandfather's way of being an inventor.　Leave him alone.
[cpg cn=true]


Shizuku pointed out more frankly. Grandpa flinched.
[cpg]


[OnName num="grandfather"]
I am a man who is serious about changing the world. I will not change my tone of voice now.
[cpg cn=true]


[OnName num="yu"]
He said he couldn't make the connection back and forth. ......
[cpg cn=true]


[OnName num="grandfather"]
It is said that if you try to change the world, you can't change what's closest to you."
[cpg cn=true]


[OnName num="grandfather"]
I'd rather concentrate on inventing than spending my energy on such things.
[cpg cn=true]


It's kind of a cool and bad thing to say.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku004"]
[OnName num="shizuku"]
I don't understand. What do you mean after all?"
[cpg cn=true]


And Shizuku would say so. She's not being tongue-in-cheek or anything, she's being forthright.
[cpg]


[OnName num="grandfather"]
Anyway!　I'm tired of facing the eggs."
[cpg cn=true]


[OnName num="grandfather"]
Look forward to the next invention. This one is a genuine breakthrough.
[cpg cn=true]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



Mom returned a short time later.
[cpg]


[OnName num="mother"]
I'm home. Oh, you're not in the lab today?"
[cpg cn=true]


[OnName num="grandfather"]
"Well, yes," he said, "it's all right. No problem, the invention is going well."
[cpg cn=true]


Shizuku and her sister went back to their room. I kind of had nothing to do, so I stayed behind in the living room.
[cpg]


[OnName num="mother"]
Yu Yu, you seem to be free. Can you help me make dinner?"
[cpg cn=true]


[OnName num="yu"]
Yeah, yeah. All right."
[cpg cn=true]


We are basically a family of six.
[cpg]


There were six of us: me, my sister, Shizuku, my dad, my mom, and my grandpa.
[cpg]


But two of them, my dad and grandpa, are often away from home.
[cpg]


Grandpa says he's a research enthusiast, but Dad is simply too busy with his hard work.
[cpg]


It's another day off and he doesn't seem to be coming home. You're a busy man. ......
[cpg]



;//========================================
;//●ＣＧ非エロ（家族で食卓を囲む。ヒロインたちが見えるアングル）ev_01
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//人物３：主人公
;//服装３：私服
;//場所　：主人公の家＿ダイニングキッチン
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]



And dinner. We sit around the table.
[cpg]



[VOICE f="Shizuku005"]
[OnName num="shizuku"]
...... this boiled egg could have been made into a raw egg too."
[cpg cn=true]


The drops are rehashing the topic. Even though Grandpa is there too.
[cpg]


[OnName num="grandfather"]
"You'll see. I'm going to make the world go wild."
[cpg cn=true]


[OnName num="yu"]
Well, it would be nice if we could. I'm rooting for you, too."
[cpg cn=true]


Basically, our family likes Grandpa.
[cpg]


He is a selfish person in some ways, but I can't hate him.
[cpg]



[VOICE f="Marina004"]
[OnName num="marina"]
May I ask you to elaborate on the idea that this could be used in the treatment of cancer?
[cpg cn=true]


And my sister is very studious. She is trying to get a story out of Grandpa.
[cpg]


[OnName num="grandfather"]
Marina wouldn't understand even if I explained it to her."
[cpg cn=true]


[OnName num="mother"]
"...... what are you talking about?"
[cpg cn=true]


[OnName num="yu"]
No, it's a long story to explain ......"
[cpg cn=true]



[VOICE f="Shizuku006"]
[OnName num="shizuku"]
Hey, hey, what's your next invention?　Grandpa."
[cpg cn=true]


[OnName num="grandfather"]
I'm thinking of building a warp device."
[cpg cn=true]


You say that so casually. Can you really do it?
[cpg]


I guess you can't ....... It's a grandpa thing.
[cpg]



[VOICE f="Shizuku007"]
[OnName num="shizuku"]
Really?　That's amazing! It's more than a Nobel Prize!
[cpg cn=true]


[OnName num="grandfather"]
"Well, you'll see. Space travel will become much more accessible."
[cpg cn=true]


Shizuku is genuinely excited. She also looks up to her grandfather.
[cpg]


I'm not a person with no accomplishments at all. There was a time when he was really in a research position. ......
[cpg]


In my family lineage, I should have inherited the brain of a genius, but it seems it was passed on to my sister.
[cpg]


Shizuku would probably be angry if I told her that compared to her brainy sister, me and Shizuku are not very good at .......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="yu"]
"Teleportation or ......"
[cpg cn=true]


I blurted out in bed, remembering today.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuku008"]
[OnName num="shizuku"]
Not teleportation. It's a warp device."
[cpg cn=true]


Shizuku picked up on the murmur. She's a good old girl, but she hasn't gotten out of the habit of sneaking under my covers.
[cpg]


[OnName num="yu"]
Go to your sister at ......."
[cpg cn=true]


Shaking his head, Shizuku shakes his head. I'm not old enough for skinship anymore.
[cpg]


[OnName num="yu"]
Your sister is cold to me, but you're always so goofy."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Shizuku009"]
[OnName num="shizuku"]
Eh?　I wonder if your sister thinks the same thing."
[cpg cn=true]


[OnName num="yu"]
The same thing?　What do you mean?
[cpg cn=true]

[SE f=se029]
;//【ＳＥ】『衣擦れ』

[free time=500]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

Shizuku rolled over and got out of bed. He is a dexterous guy.
[cpg]


Then he turned on the light in his room and started reading a comic book.
[cpg]


[OnName num="yu"]
Dazzling, drop ...... I just want to go to bed."
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Shizuku010"]
[OnName num="shizuku"]
She loves you, too, big brother. We're family, isn't that normal?"
[cpg cn=true]


It's not normal. Especially in the case of the drops.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



When I woke up in the morning, something was heavy in my body.
[cpg]



;//[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
;//[WAIT time=1100]


[OnName num="yu"]
"...... drops or."
[cpg cn=true]



[VOICE f="Shizuku011"]
[OnName num="shizuku"]
"Goo, goo."
[cpg cn=true]


He's sleeping on top of me. What kind of sleeping position is that?
[cpg]


I'm pretty sure we slept side by side. ...... Well, okay.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina005"]
[OnName num="marina"]
"Yu Yu. You've been sleeping in too much, haven't you been slack lately?"
[cpg cn=true]


[OnName num="yu"]
"Don't sound like a teacher,...... mostly if that's the case, Shizuku would have slept in more."
[cpg cn=true]


My sister is tough on me, or rather cold.
[cpg]


You're right, Shizuku, my sister in my childhood memories was much brighter or ......
[cpg]


I have a memory of my sister being goofy with me.
[cpg]


Why am I like this now?　Did I do something that will be disliked one day?
[cpg]


[OnName num="yu"]
Well, I'm off then."
[cpg cn=true]



[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[SE f="se027"]
;//【ＳＥ】『雑踏』


On the way to the school. Walking through the hustle and bustle.
[cpg]


From here to the school you have to go through the station.
[cpg]


So I really should get up a little earlier ...... but I can't say that now.
[cpg]



[SE f="se009"]
;//【ＳＥ】『電車揺れる音』

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の通う学園＿教室』（朝）******************************************************



I arrive at the school. It seems that I was just in time to avoid being late.
[cpg]


[OnName num="yu"]
Yoh. Kokoro."
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kokoro001"]
[OnName num="kokoro"]
Oh, good morning. Yoo-kun."
[cpg cn=true]

[window target=false]
[free time=500]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=800]
[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]
[window target=true]


Koyi Kurusu. My childhood friend and classmate.
[cpg]

[window target=false]
[free time=500]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]
[window target=true]


[OnName num="yu"]
This morning was a disaster. ...... I was a little sleep-deprived."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Kokoro002"]
[OnName num="kokoro"]
"What's wrong?　Did you have some bad dream?"
[cpg cn=true]


I may have had some bad dreams. I don't remember.
[cpg]


But it wasn't surprising that I was watching.
[cpg]


[OnName num="yu"]
I had a drop sleeping on me," he said. I thought my body was strangely heavy, but that's because of this."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Kokoro003"]
[OnName num="kokoro"]
Haha ...... you guys really all get along."
[cpg cn=true]


[OnName num="yu"]
Me and Shizuku. But not so much your sister.
[cpg cn=true]


As soon as we talked about this, the class started.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se028"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の通う学園＿教室』（昼）******************************************************


Then it is lunchtime. Koyi approaches me as I spread out my lunch box.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Kokoro004"]
[OnName num="kokoro"]
"Oh ...... are you eating your lunch already ......?"
[cpg cn=true]


[OnName num="yu"]
Oh. Is that your lunch box?　You eat a lot."
[cpg cn=true]


He is holding a package that looks like it could hold two lunches. Two? You mean two for two people?　No way.
[cpg]


[OnName num="yu"]
Eat too much and you'll get fat."
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Kokoro005"]
[OnName num="kokoro"]
"Yeah ...... I think I'll have one of them for dinner when I get home ......"
[cpg cn=true]


Koyi stumbles away with a somber look on her face.
[cpg]


I don't know what it is about this guy. I remember being good friends with her too.
[cpg]


When he decided where to go to school, he studied hard as if he was copying me.
[cpg]


After all, we're at the same academy, so there must be a reason.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の通う学園＿教室』（夕方）******************************************************



After lunch and a few classes, it's completely evening. It's after school.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kokoro006"]
[OnName num="kokoro"]
Shall we go home together? Yoo-kun."
[cpg cn=true]


[OnName num="yu"]
Yeah, we almost always go home together. We almost always go home together."
[cpg cn=true]


Almost, I would say, not at all.
[cpg]


The Tokiwa and Kurusu families are neighbors. The relationship started there as childhood friends.
[cpg]


[OnName num="yu"]
I don't want to make a detour or anything. I don't want to stop off or anything, but do you want to stop somewhere?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Kokoro007"]
[OnName num="kokoro"]
I might want to stop by the bookstore then. Will you accompany me?"
[cpg cn=true]

[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[OnName num="yu"]
Yeah, let's go. Let's go."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[WAIT time=1500]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



;//[SE f="se027"]
;//【ＳＥ】『雑踏』



So we stopped at a bookstore. Koyi doesn't know what he was buying and won't tell me.
[cpg]


The cover I glimpsed was a picture of a dish, so I assume it's a cookbook or something: ......
[cpg]


[OnName num="yu"]
Are you into cooking these days?"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Kokoro008"]
[OnName num="kokoro"]
I don't think so. It's normal. It's normal.
[cpg cn=true]


[OnName num="yu"]
I see. Don't eat too much."
[cpg cn=true]


Koyi looks mortified. Did I say too much?
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Kokoro009"]
[OnName num="kokoro"]
"I'm not going to get ...... fat by saying that all the time, okay?"
[cpg cn=true]


He added that he might lose weight due to stress. What does that mean?
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



Then we came back to the neighborhood of our house. A neighbor is really a neighbor.
[cpg]


It is very close by, so we can visit them if we need anything.
[cpg]


[free time=500]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Shizuku012"]
[OnName num="shizuku"]
Oh, it's Koyi-chan. Good evening."
[cpg cn=true]


Shizuku comes out of the house. She greets Koyi while hugging my arm.
[cpg]


My breasts are touching, but it doesn't bother me. I think it's a bit immodest, but I don't mind.
[cpg]


And Koyi looked complicated. I don't know why she looked that way.
[cpg]


[OnName num="yu"]
What's wrong, Koyi? What's wrong with you lately?"
[cpg cn=true]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Kokoro010"]
[OnName num="kokoro"]
It's not weird. It's normal."
[cpg cn=true]


I heard something similar earlier. I hope so.
[cpg]


[OnName num="yu"]
See you later. Koromo."
[cpg cn=true]

[free time=1000]
I said yes and waved. Then he went home.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuku013"]
[OnName num="shizuku"]
My brother seems to make a lot of girls cry.
[cpg cn=true]


[OnName num="yu"]
What's up with that? What makes you think that?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
Nothing," he says, whistling. It's a cartoonish reaction.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



[OnName num="yu"]
I'm home."
[cpg cn=true]



[SE f="se019"]
;//【ＳＥ】『ドア開く』




[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[OnName num="yu"]
...... where's grandpa?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuku014"]
[OnName num="shizuku"]
I don't know. Isn't this some kind of teleportation experiment?"
[cpg cn=true]


[OnName num="yu"]
You're Warp." You pointed it out."
[cpg cn=true]


While we were having a silly conversation, my sister came back.
[cpg]

[free time=500]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Marina006"]
[OnName num="marina"]
I'm home. Yoo, put your shoes on and take them off.
[cpg cn=true]


[OnName num="yu"]
Yes, yes, ......, I'll fix it right now."
[cpg cn=true]



[free time=500]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



When I went to fix them, the drops were worse than my shoes.
[cpg]


I don't know how they take it off, but the front and back are reversed on the right and left.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[OnName num="yu"]
I also fixed the ...... drop.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Marina007"]
[OnName num="marina"]
Yes, that's right. Of course.
[cpg cn=true]


That's cold. Since Shizuku told me, I've been wondering for sure.
[cpg]


[OnName num="yu"]
So ...... grandpa is still building warp devices, that's what I'm talking about."
[cpg cn=true]

[free time=1000]
She says, "Hmmm," and goes back to her room.
[cpg]


They don't seem interested. I wonder if they're not interested because of what I tell them.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="yu"]
I wonder what's wrong with you, ...... sis."
[cpg cn=true]


After dinner and a bath, it was completely nighttime.
[cpg]


I play on a portable game console, but I'm not very enthusiastic about it.
[cpg]


I can't stop thinking about when and why my sister became cold.
[cpg]


It's something I can't help but think about, and I don't want to be intimate with my sister.
[cpg]


But we're a family, and we want to get along. ......
[cpg]


[OnName num="yu"]
"It's a waste of time to think about it, yeah."
[cpg cn=true]


I conclude and get under the covers. I don't think Shizuku will disturb my sleep today.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]


[FACE method="change_1" pos="2/3"]
[VOICE f="Shizuku015"]
[OnName num="shizuku"]
Now, it is I, Shizuku Tokiwa, who will surprise Yu Tokiwa with a surprise in her sleep. ......
[cpg cn=true]


I hear you, I hear you. I'm the kind of guy who wakes up a little before I'm fully awake.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Shizuku016"]
[OnName num="shizuku"]
He's sleeping soundly. ...... Then I'll sleep with him today as usual.
[cpg cn=true]


And that's not really a surprise. Oh well. ......
[cpg]


No, it's time to stop this guy's spoiling habit. With that in mind, I suddenly got up and tried to scare him.
[cpg]



[SE f="se029"]
;//【ＳＥ】『布団から起き上がる』



[OnName num="yu"]
Whoa!"
[cpg cn=true]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_4"  pos="4/5" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina008"]
[OnName num="marina"]
......Why are you both holding your heads down?"
[cpg cn=true]


[OnName num="yu"]
"No, it's just a little ...... hit me the moment I woke up and ......
[cpg cn=true]


My sister is looking at me curiously. Naturally, Shizuku is also holding her head.
[cpg]


But this is more Shizuku's fault than mine. I'm not responsible for this.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku017"]
[OnName num="shizuku"]
...... I thought I cracked your head open, bro."
[cpg cn=true]


[OnName num="yu"]
My bad. ......"
[cpg cn=true]


I think so, but when Shizuku says this to me, I apologize.
[cpg]


[OnName num="yu"]
So, where's Grandpa?　Haven't seen him since yesterday or so."
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Marina009"]
[OnName num="marina"]
I think he's into his research. But I heard he went back to dinner around midnight.
[cpg cn=true]


He's a powerful old man. It's just like him, though.
[cpg]


[OnName num="mother"]
But you're going to be late if you don't eat soon."
[cpg cn=true]


[OnName num="yu"]
Oh, yeah. I know."
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[FACE method="change_1" pos="4/5"]

Breakfast for the three of us. The timing of getting up in the morning is usually the same, so this view is not unusual.
[cpg]


Shizuku eats quite a bit, but her sister eats little. There is a difference between the two sisters in these areas as well.
[cpg]


What about me, am I somewhat of a small eater?　I do indeed eat more than my sister, but ......
[cpg]


Speaking of which, is Koyi going to bring two lunch boxes again?　If so, I'd prefer not to have her make me a bento.
[cpg]


[OnName num="yu"]
Thanks for the food. Mom, I don't want my lunch today."
[cpg cn=true]


[OnName num="mother"]
What?　Tell me quickly, I've already made it."
[cpg cn=true]


[FACE method="bow_3" pos="4/5"]
[VOICE f="Shizuku018"]
[OnName num="shizuku"]
Yes, I'll eat for two!　I'll eat for two!
[cpg cn=true]


You're very energetic, even in one reply. Maybe it means that you are burning more calories.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[SE f="se027"]
;//【ＳＥ】『雑踏』


Today I was with Koyi from the time I left.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kokoro011"]
[OnName num="kokoro"]
Oh, Yu-kun. Are you on your way out?"
[cpg cn=true]


[OnName num="yu"]
"Oh, you made two lunches today, too? Did you make two lunches today?"
[cpg cn=true]


Koyi is puzzled, saying, "What? It looks like I've made two of these.
[cpg]


I don't know what the reason is, but if no one else is going to eat it, I can eat it.
[cpg]


[OnName num="yu"]
Can I have half?　I didn't bring my lunch today."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Kokoro012"]
[OnName num="kokoro"]
Oh, really?　Yeah, but, um... ......
[cpg cn=true]


Koyi seems to be hesitant about something. I wonder why.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Kokoro013"]
[OnName num="kokoro"]
I've been making this for Yu-kun from the beginning, and now this is an ant ......?"
[cpg cn=true]


[OnName num="yu"]
Did you just say something?"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

It's nothing!　Koyi goes ahead and says.
[cpg]


She seems to be having some trouble of her own. I have no idea.
[cpg]



[SE f="se009"]
;//【ＳＥ】『電車揺れる音』

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の通う学園＿教室』（昼）******************************************************



[OnName num="yu"]
Bon appétit.
[cpg cn=true]


Me and Koyi, facing each other at one desk, eating our lunch boxes.
[cpg]


It sounds like we are lovers, but we are not.
[cpg]


In my mind, they're not just friends, they're more like family.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Kokoro014"]
[OnName num="kokoro"]
How's ...... tasty?"
[cpg cn=true]


[OnName num="yu"]
......Overall, not very tasty."
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Kokoro015"]
[OnName num="kokoro"]
I see. Honest."
[cpg cn=true]


[OnName num="yu"]
Would you have preferred I had given you a compliment, even if it was a lie?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]

Koyi shakes her head, "No," she says. Koyi eats her own lunch as well.
[cpg]


He has a difficult look on his face. It seems that even he is not satisfied with the result.
[cpg]


[OnName num="yu"]
"Yeah?　It doesn't taste very good, does it?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Kokoro016"]
[OnName num="kokoro"]
You have no delicacy,...... Yu-kun."
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[OnName num="yu"]
Well, I'll see you tomorrow, then."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Kokoro017"]
[OnName num="kokoro"]
I'm glad you ate lunch today. Thanks for eating my lunch today."
[cpg cn=true]


[OnName num="yu"]
"Oh, nothing. I don't need to be thanked, but you can always use me as a lab rat."
[cpg cn=true]


Koyi giggles. I'm not sure if that was a good idea or not.
[cpg]

[jump storage="ep001.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
