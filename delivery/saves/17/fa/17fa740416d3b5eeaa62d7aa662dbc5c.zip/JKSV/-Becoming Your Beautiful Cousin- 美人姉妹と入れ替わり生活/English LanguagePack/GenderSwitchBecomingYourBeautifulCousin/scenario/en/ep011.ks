

;//==============================
;//３、どちらでもない
*start


*select30_3|Consult with Koyi


;//※ルート分岐。ここまでの女性化ポイントによって決まる



;//==============================
;//女性化ポイントが１以下の場合

[if exp={getFlagValue("pi_fi") == 2 }]
;//[jump target=*tag_03]
[jump storage="ep012.ks" target="*tag_03"]
[endif]


*start|Consult with Koyi

*root03_1|Consult with Koyi


[SCENE id=11]


It is different to consult with ...... sister and to consult with Shizuku.
[cpg]


They are parties. Instead, I want an objective opinion.
[cpg]


When I thought of that, one girl came to mind.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈（雫）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------


;#################################################
*Ep011|Consult with Koyi
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



The next morning, I woke up in my room. I wonder if the replacement hasn't happened today.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="grandfather"]
'You're up, Yu......, everyone is already here.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marina417"]
[OnName num="marina(shizuku)"]
I'm late, Yoo-kun. You're late, Yu.
[cpg cn=true]


It looks like my sister and Shizuku have been replaced. I've never been called Yu-kun.
[cpg]


I whispered to Grandpa.
[cpg]


[OnName num="yu"]
You know, Grandpa," he said, "I don't have any money. You really don't have any money, do you?"
[cpg cn=true]


[OnName num="grandfather"]
You doubt me?　I told you I don't have any money.
[cpg cn=true]


[OnName num="yu"]
I said, "I don't have any money. We'll have to earn it ourselves.
[cpg cn=true]


[OnName num="grandfather"]
Don't do anything rash. Don't even think about ...... using a woman's body.
[cpg cn=true]


He nailed me. Actually, I was thinking about it.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


Now, the academy. I don't know if I'll be able to keep up with the classes since I'll be skipping them.
[cpg]


But I can't not go. Besides, there is someone at the school I want to talk to.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の通う学園＿教室』（昼）******************************************************



[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kokoro096"]
[OnName num="kokoro"]
"You want to talk to me about ......?　Okay, but what do you want to talk about?
[cpg cn=true]


[OnName num="yu"]
You get the general idea. We're still swapping places.
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]

Koyi turns over and says, "Yes, that's right. Why do you turn over?
[cpg]


I asked Koyi to help me out.
[cpg]


[OnName num="yu"]
"Hey, do you have any good ideas on how we can get back together?"
[cpg cn=true]


Koyi put her hand on her chin and thought. The way she was looking at me, I couldn't help but think ......
[cpg]


It didn't look like she was thinking about how to get back to normal.
[cpg]


She was glancing at me. It was as if she was wondering whether to say something or not.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Kokoro097"]
[OnName num="kokoro"]
I said, "There is a way. There's a way we might be able to get back together.
[cpg cn=true]


[OnName num="yu"]
"What? ......!　Really, Koyi?
[cpg cn=true]


I was so surprised that I got up from my chair.
[cpg]


Koyi was a little surprised. She coughed and continued, "I can tell you how to do that.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Kokoro098"]
[OnName num="kokoro"]
I can tell you. But in return, I'll tell you ...... that, umm..."
[cpg cn=true]


Koyi was puzzled. What is there to be hesitant about now?
[cpg]


[OnName num="yu"]
Is it an exchange?　I'll do whatever you want. So tell me.
[cpg cn=true]

[FADEOUTBGM]

[FACE method="bow_1" pos="2/3"]

Koyi nodded in response to my words. Then she said, "In exchange, I want you to like me.
[cpg]

[free time=500]
[FG f="CHA03_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[WAIT time=1000]

[VOICE f="sKokoro008"]
[OnName num="kokoro"]
In exchange, I want you to like me.
[cpg cn=true]


[OnName num="yu"]
'What about ......?'
[cpg cn=true]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈（由宇）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------

[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の通う学園＿教室』（昼）******************************************************



And at that moment, the view switched.
[cpg]


I seemed to be the older sister. There was a familiar lecture hall.
[cpg]


Oh no, that means my sister or Shizuku is on my side now, right?
[cpg]


Would Koyi understand ......?　I hope I don't get in trouble.
[cpg]



[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



On the way home, I saw Koyi walking with my sister or Shizuku, who looked like me.
[cpg]


[OnName num="yu(shizuku)"]
Koyi, you are very bold.
[cpg cn=true]


From the way she talks, I'm guessing this is Shizuku.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kokoro100"]
[OnName num="kokoro"]
I said, "Forget about it ......."
[cpg cn=true]


I guess they were talking for a while, not realizing that me and Shizuku had switched.
[cpg]


I could hear her saying that, so I decided to intervene.
[cpg]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="4/5" time=800]

[VOICE f="sMarina013"]
[OnName num="marina(yu)"]
I was like, "Hey, what are you talking about? What are you talking about?"
[cpg cn=true]


[OnName num="yu(shizuku)"]
"Oh, wow!　What, you were listening?
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************





[OnName num="grandfather"]
"Oh, welcome back ......, I see you have a friend with you."
[cpg cn=true]


[OnName num="yu(shizuku)"]
Yeah. Yes, I have some business to attend to.
[cpg cn=true]


And it seemed that Koyi still had some requests to be liked by Koyi.
[cpg]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Kokoro101"]
[OnName num="kokoro"]
'Ojamasu ......'
[cpg cn=true]


Are you sure you're okay with me now?　Because I'm your sister now.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿麻莉奈の部屋』（夕方）******************************************************

We talked about that in her room.
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Kokoro102"]
[OnName num="kokoro"]
She said, "Okay. If it's Yoo-kun on the inside, I don't care what body you have.
[cpg cn=true]


Is it really like that? Something about Koyi seems out of the ordinary too.
[cpg]


I don't care how much of a man she is inside, it's not like she's a woman with a man. ......
[cpg]


If it were a man, it would be unthinkable, but if it were a woman, could it be like that?
[cpg]


Of course, from my point of view, the other person is Koyi, so I don't have a problem with it.
[cpg]


;//========================================
;//●ＣＧ（主人公（ヒロイン１の外見）がサブヒロインへ一方的にキスをする）ev_39
;//人物１：主人公（ヒロイン１の外見）
;//服装１：私服
;//人物２：サブヒロイン
;//服装２：制服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_00_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMarina014"]
[OnName num="marina(yu)"]
Are you sure?"
[cpg cn=true]


Koyi nodded. There seems to be no more hesitation.
[cpg]


I sit on the chair and Koyi sits on the bed.
[cpg]


Koyi blushes and closes her eyes, as if seeking a kiss.
[cpg]


Is it good that I haven't even formally responded to her confession yet?
[cpg]


You know how to get back on track at ......, don't you?　If that's the case, I should.
[cpg]


[VOICE f="sKokoro009"]
[OnName num="kokoro"]
Nn......."
[cpg cn=true]



;//移植のためシーンをカットしています




;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


And so we spent some time alone together.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


I got Koyi home before dark.
[cpg]


It was right next door. I was sorry to see her go, but it was only for a moment.
[cpg]


[OnName num="yu(shizuku)"]
I was so glad you had fun, big brother.
[cpg cn=true]


Shizuku overheard me. I'm not sorry you had fun. ......
[cpg]


But I don't want my sister to tell on me. Should I tell her?
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina425"]
[OnName num="marina(yu)"]
I'm not going to tell your sister, I'm begging you. I beg you.
[cpg cn=true]


[OnName num="yu(shizuku)"]
What should I do?
[cpg cn=true]


This guy really ...... thought it would be a problem for people.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]


And then some time passed.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_01_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の通う学園＿教室』（昼）******************************************************



I was still my sister for a while.
[cpg]


She and Shizuku switched places, but I remained her.
[cpg]


Naturally, while I was with Koyi, I was still in my sister's body.
[cpg]

We have kissed a few times since then, but I heard that Koyi is not satisfied yet.
[cpg]


She told me that she would tell me if I let her continue this relationship with me for a while longer.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



Today, she told me to leave the school quickly and go on a date with her.
[cpg]


A date between Koyi and a woman. What is wrong with me?
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Kokoro113"]
[OnName num="kokoro"]
Hey, let's go to this store.
[cpg cn=true]


The place he pointed to looked like a store that only sold girls' clothes.
[cpg]


I thought, "I don't have any business here,......," but it wouldn't be out of place if I went in there now.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina426"]
[OnName num="marina(yu)"]
I'm not going to go in there unless I'm dressed like an older sister.
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
Koyi looked at me strangely.
[cpg]


She said that it is normal for men and women to enter together,....... I wondered if that was really true.
[cpg]

[FACE method="bow_2" pos="2/5"]

I don't know what kind of relationship the average man and woman have.
[cpg]


I mean, this is a date first, right?　Does that mean we're in a relationship?
[cpg]



;//ＢＫ
[FADEOUTBGM]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


I wanted to clarify that, so after leaving the restaurant I asked Koyi.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



For example, "Are we dating?" It was not a good way to ask.
[cpg]


It's too delicatessen. That's why I used this way.
[cpg]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Marina427"]
[OnName num="marina(yu)"]
I didn't reply ...... properly, did I? To Koyi."
[cpg cn=true]

[FACE method="change_7" pos="4/5"]
Koyi became silent. Then she stopped walking.
[cpg]


I thought I had said something bad, so I turned around.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina428"]
[OnName num="marina(yu)"]
I said, "I'm sorry. It's nothing, forget about it.
[cpg cn=true]


He says the same thing that Koyi told him one day.
[cpg]


We are both trying to keep this relationship ambiguous.
[cpg]


I wonder what they are ...... doing. I'm sure we're both in love with each other.
[cpg]


But I can't lightly say that I'm me and I like you.
[cpg]


I'm not sure I can love one person if we keep switching places.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[OnName num="yu(marina)"]
Welcome back, sis. You're back late."
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Marina429"]
[OnName num="marina(yu)"]
"Yeah. I had to run some errands. ......
[cpg cn=true]


My mother was there, so I made it up to her.
[cpg]


[OnName num="mother"]
Oh, Koyi-chan. Are you and Marina getting along well these days?"
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]
Yes, well," replies Koyi. You've got to make it add up.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Kokoro114"]
[OnName num="kokoro"]
I'm not talking about Yoo-kun . Yoo-kun, not ......, Marina.
[cpg cn=true]


It's a quick rag. Mom didn't seem to notice, which is good.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿麻莉奈の部屋』（夕方）******************************************************

And then the sister's room. Before I could say anything else, Koyi asked me to kiss her.
[cpg]


She was very aggressive. I wonder if she was holding back during the date.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



I took Koyi home as usual. Mom doesn't suspect anything.
[cpg]


They are both girls, so she probably doesn't think anything strange will happen.
[cpg]


In fact, I think she suspects that we might have switched places.
[cpg]


Whether Shizuku is in my body or in my sister's body, she is acting freely. ......
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈　雫
;//と変更してください
;//----------------------------------------
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



The next morning. I woke up in my body.
[cpg]


I change out of my pajamas, wondering how my sisters are doing.
[cpg]


I have to go to the school today. And I don't always know where my uniform is.
[cpg]


My sisters and Shizuku always put them in different places. ......
[cpg]





[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



But that's not the case, each of them seemed to be in their own body.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marina437"]
[OnName num="marina"]
Good morning, Yoo. You look like you've been sleeping in a very bad way.
[cpg cn=true]


[OnName num="yu"]
I know. ......
[cpg cn=true]


The fact that my sister is speaking in such a natural tone of voice means that she has not been replaced.
[cpg]


I guess I'm most comfortable in this state. It is a familiar scene, or rather, a familiar conversation.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



The three of us were kept back by Grandpa on the way out.
[cpg]


The reason we didn't talk inside the house was probably because my mother was there.
[cpg]


[OnName num="grandfather"]
"Can the three of us go to ......?"
[cpg cn=true]


[OnName num="yu"]
What's up, Grandpa? What is it, Grandpa?
[cpg cn=true]


[OnName num="grandfather"]
You haven't told anyone we've switched places, have you?
[cpg cn=true]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Shizuku432"]
[OnName num="shizuku"]
No one. Hey, big brother.
[cpg cn=true]


I've told ...... Koyi, but I haven't told anyone else. I've told Koyi, but I haven't told anyone else.
[cpg]


[OnName num="yu"]
I haven't talked to her, but what does that matter?
[cpg cn=true]


[OnName num="grandfather"]
No,......, I thought it would become a big deal if anyone found out. I feel responsible for it.
[cpg cn=true]


That's fine, but you don't have the money to build the machine.
[cpg]


No matter how much responsibility you feel, it doesn't really matter. ......
[cpg]

[FACE method="change_1" pos="2/5"]
[FACE method="change_1" pos="4/5"]

[OnName num="yu"]
You said, "It's all right. I don't hold a grudge against my grandfather, not at this point."
[cpg cn=true]


[OnName num="grandfather"]
...... sorry."
[cpg cn=true]


While talking like this, we each headed for the school.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の通う学園＿教室』（昼）******************************************************



After arriving at the school and finishing morning classes.
[cpg]


I was about to have lunch with Koyi when I heard her talking to another girl.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

Koyi seemed to be talking to another girl, so I overheard her at the entrance.
[cpg]


[OnName num="female_student"]
I heard her saying, "...... Koyi, are you all right?　Do you know what you are saying?
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Kokoro123"]
[OnName num="kokoro"]
I know what I'm saying. I know what I'm talking about.
[cpg cn=true]


[OnName num="female_student"]
"Even if......... I wouldn't know the solution to something like that."
[cpg cn=true]


What are you talking about?　You're talking about solutions and stuff.
[cpg]


[OnName num="female_student"]
"A couple of men and a woman switched, like you said?　I don't know how to put them back together."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Kokoro124"]
[OnName num="kokoro"]
Imagine, you might come up with something I haven't: ......
[cpg cn=true]


...... Apparently Koyi was offering a deal when he didn't come up with anything.
[cpg]


So now we're back to square one. ...... No, you could say that nothing had progressed from the beginning.
[cpg]


[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈　雫（由宇）
;//と変更してください
;//----------------------------------------
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（昼）******************************************************



As I was thinking, my vision suddenly changed. Again.
[cpg]


Who is it this time?　It seems to be Shizuku.
[cpg]


It's already a pain in the ass. I want to get back to normal as soon as possible. ......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



On the way home. I was on my way home when Shizuku and Koyi came up to me.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Kokoro125"]
[OnName num="kokoro"]
They say, "Um,...... is that Yu-kun?"
[cpg cn=true]

[FACE method="bow_1" pos="2/5"]

I answer that I am. In Shizuku's voice.
[cpg]


[OnName num="yu(shizuku)"]
I see, only me and my brother switched."
[cpg cn=true]


Shizuku's voice was drinking. I was getting tired of it.
[cpg]


I couldn't keep doing this over and over again.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="4/5" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


Koyi goes straight into the house. I wonder if she is going to ask me for a kiss again today, even though I haven't come up with anything.
[cpg]


[FACE method="shake_6" pos="4/5"]
[VOICE f="sKokoro010"]
[OnName num="kokoro"]
She said, "Well, ...... that, Yu-kun."
[cpg cn=true]


It seems that's the case. The only thing you can do is to respond to it. ......
[cpg]


If we stop here, they might even stop thinking with us.
[cpg]


What a surprise. That's just a pretext, I still want to be with Koyi.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//移植のためシーンをカットしています


After spending some time together, we decided to part ways.
[cpg]


Maybe they have a curfew or something. Good thing we're neighbors, because we'll be together for a long time.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈（雫）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



By dinner time, I was back in my body.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Marina438"]
[OnName num="marina(shizuku)"]
I was happy that food tasted so good again today.
[cpg cn=true]


Instead, my sister and Shizuku switched places.
[cpg]


How could Shizuku be happy in this state?
[cpg]


[OnName num="grandfather"]
Did Marina's way of speaking change recently?"
[cpg cn=true]


Grandpa started to follow up with me.
[cpg]


It must be very unnatural. We're getting used to it, so I don't know.
[cpg]


Mom must think it's suspicious. I couldn't let her find out.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


These days went on for a while, and then we went to ......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Tomorrow night was my day off. I had a date.
[cpg]


Of course, it was with Koyi. I hadn't really decided where we would go and how we would go.
[cpg]


We're both comfortable with each other, so I'm sure things will go well without worrying about that.
[cpg]


Besides, I had some questions I wanted to ask her tomorrow.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2500]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



I decided to leave the house more neatly groomed than usual.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuku443"]
[OnName num="shizuku(marina)"]
I went to ...... and asked her, "What's wrong? What's wrong?"
[cpg cn=true]


So says my sister dressed as a drop of water. Am I always that bad a sleeper?　I thought to myself, "No, I don't think so.
[cpg]


[OnName num="yu"]
I'm going out with Koyi.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]

She made a face as if she understood. What's with that look?
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[FACE method="change_1" pos="2/3"]
[VOICE f="Kokoro133"]
[OnName num="kokoro"]
Sorry to keep you waiting. I'm sorry, I took a while to get out.
[cpg cn=true]


[OnName num="yu"]
No, I'm not waiting. Let's go.
[cpg cn=true]


We had a standard exchange of words as we headed for the shopping mall.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


We went into stores that I wouldn't have gone to if I were alone. We also had dinner together.
[cpg]


We were probably already lovers from every angle, but we were not yet lovers.
[cpg]


The other party must be thinking something similar. He felt awkward about this relationship.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[FACE method="change_7" pos="2/3"]
[VOICE f="Kokoro134"]
[OnName num="kokoro"]
Oh, you know what? Yoo-kun,......, I said I was going to stay at a friend's house today."
[cpg cn=true]


[OnName num="yu"]
...... what?"
[cpg cn=true]


I was puzzled by what he said, which surprised me a little.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Kokoro135"]
[OnName num="kokoro"]
"Oh, when I say friends, I mean girl friends. So its ......"
[cpg cn=true]


What the heck. So that's what it's about.
[cpg]


[OnName num="yu"]
I didn't tell my family. I didn't tell my family I wasn't coming home.
[cpg cn=true]


But if I stayed at home, they'd know. What should I do?
[cpg]


I can't let Koyi's determination go unnoticed. I couldn't just send her home.
[cpg]


[OnName num="yu"]
I said, "Let's go somewhere for supper.
[cpg cn=true]


Saying so, we decided to stop by a family restaurant for the time being.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


And it was completely nighttime.
[cpg]


[OnName num="yu"]
You know, Koromo, you don't really have any idea how to get back to normal, do you? You don't really have any idea how to get back to normal, do you?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Kokoro136"]
[OnName num="kokoro"]
What makes you think that?
[cpg cn=true]


[OnName num="yu"]
I heard about it the other day. I heard you talking to another girl about us.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
Koyi said, "Oh, I see,......," and looked at him without any seriousness.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Kokoro137"]
[OnName num="kokoro"]
I've got an idea. Just one thing.
[cpg cn=true]


[OnName num="yu"]
What?　But, because ......."
[cpg cn=true]


You were talking to a friend or someone. When I pursued this, he said that he was looking for another plan.
[cpg]


[OnName num="yu"]
What, I'm mistaken?
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
;//[VOICE f="Kokoro138"]
[VOICE f="sKokoro011"]
[OnName num="kokoro"]
But it's about time we stopped taking these things hostage."
[cpg cn=true]


Koyi was about to say so, but I stopped her.
[cpg]


[FACE method="shake_5" pos="2/3"]

I stopped her. I put my index finger to my mouth.
[cpg]


[OnName num="yu"]
I want to continue this relationship. I still want to continue this relationship.
[cpg cn=true]


I don't want to stop my days with Koyi in the form of a business deal.
[cpg]


If I told her everything here, we would go back to being childhood friends.
[cpg]


[OnName num="yu"]
Please. Please let me stay like this for a little while longer.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

Koyi nodded. And then we went to the park at night.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]


[VOICE f="sKokoro012"]
[OnName num="kokoro"]
"Ah!
[cpg cn=true]

;//========================================
;//●ＣＧ（夜の公園、しゃがみこむサブヒロイン）ev_42
;//人物１：主人公
;//服装１：私服
;//人物２：サブヒロイン
;//服装２：私服
;//場所　：公園
;//時間　：夜
;//========================================

;**【ＣＧ】 ev_42_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="yu"]
What's wrong?
[cpg cn=true]


[VOICE f="sKokoro013"]
[OnName num="kokoro"]
"No, I dropped something."
[cpg cn=true]


She tries to pick it up, her underwear almost showing a little.
[cpg]

[OnName num="yu"]
She's trying to pick it up, and you can almost see her underwear. ......
[cpg cn=true]


But I can't see it. I've come to understand this kind of girl's gesture.
[cpg]

It's something I have to wear. ......
[cpg]


;//移植のためシーンをカットしています

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



We stayed together for a while after that, it was already late.
[cpg]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



[OnName num="yu"]
She said, "I'm staying ...... here, right?"
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Kokoro151"]
[OnName num="kokoro"]
Yes, I did. I can't go home halfway through the day.
[cpg cn=true]



[OnName num="yu"]
I'll go back to my house. If I sneak out, they won't know and I can stay in your room or Shizuku's room.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Kokoro152"]
[OnName num="kokoro"]
I think I'll do that.
[cpg cn=true]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



[OnName num="yu"]
"......I'm home!
[cpg cn=true]


I say in a small voice. My parents seem to be asleep already, it's going to be tomorrow morning before they get mad at me.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Kokoro153"]
[OnName num="kokoro"]
I'm going to go to Shizuku's room then. See you tomorrow. ......
[cpg cn=true]


[OnName num="yu"]
I'll see you tomorrow. See you tomorrow."
[cpg cn=true]



[window target=false]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



So, I took Koyo to Shizuku's room, though it would be a surprise to her.
[cpg]


She would be sleeping on the floor or somewhere. I don't think she would sneak into bed.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈　雫（由宇）
;//と変更してください
;//----------------------------------------

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_10_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿雫の部屋』（朝）******************************************************

The next morning.
[cpg]


When I woke up, Koyi was sleeping on the floor.
[cpg]


I went to ...... to clear my head. Well, I became a drop.
[cpg]


I'm lucky or something. Now I don't have to be pissed off and ......
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



When I woke up in the morning, my mother was angry at me for taking her place.
[cpg]


[OnName num="yu(shizuku)"]
She said, "Sh, I don't know. ...... It wasn't my decision."
[cpg cn=true]


That's what I'd have to say. That doesn't mean you can't hold me responsible.
[cpg]


[OnName num="mother"]
Oh, Koyori-chan,......, when did you come to visit me?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kokoro154"]
[OnName num="kokoro"]
"Well, uh, well, haha ......."
[cpg cn=true]


I had a hard time deceiving myself in many ways, but I ended up being very suspicious of my mom.
[cpg]


I think that's what happened this time, no matter how I tried to explain it.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[OnName num="yu(shizuku)"]
"I'll ...... hold a grudge against you, big brother."
[cpg cn=true]


Yes, I will. I'm sorry. I won't do it again.
[cpg]


I was flatly apologizing to Shizuku, who was angry in a way that is quite rare.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Shizuku444"]
[OnName num="shizuku(yu)"]
I'm sorry,......, I'll buy you something sweet.
[cpg cn=true]


[OnName num="yu(shizuku)"]
I'll buy you something sweet." "If I buy it now, it's my money, right?
[cpg cn=true]


I'll buy you something sweet. You're so perceptive.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（朝）******************************************************



I can't switch wallets every time.
[cpg]


But there are always expenses. For example, what do you do when you get thirsty outside?
[cpg]


Naturally, I use the wallet in my bag. The three of us are conscious of the fact that we have to save money, so we go to ......
[cpg]


I think we're going to accumulate a lot of money this month. Both of us.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（夕方）******************************************************



At the time I was thinking that, a little incident happened.
[cpg]


[OnName num="female_student"]
She said, "Hey, hey, you had a cousin brother, didn't you, Tokiwa-san?"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuku445"]
[OnName num="shizuku(yu)"]
Yes, I do.
[cpg cn=true]


[OnName num="female_student"]
You were walking together the other day, right? He was so cool.
[cpg cn=true]


I'm sure I'm looking at it wrong. The actuality that you can get a lot of these types of products and services is a good thing.
[cpg]


[OnName num="female_student"]
I'm going to go visit Tokiwa-san's house today, okay?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Shizuku446"]
[OnName num="shizuku(yu)"]
I'll ...... see you next time."
[cpg cn=true]


In these situations, I basically refuse. This is because I don't know what kind of relationship I have with Shizuku.
[cpg]


[OnName num="female_student"]
I'll follow you on my own. I'll follow you on my own.
[cpg cn=true]


At this stage, I didn't think he was serious.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



But the girl was really following me.
[cpg]


She was coming close to my house. If this keeps up, she's really going to come face to face with me. ......
[cpg]


But it's the drops that are in there now. I wonder if they will be able to fool us.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[OnName num="yu(shizuku)"]
Oh, welcome home,......, is that it?
[cpg cn=true]


[OnName num="female_student"]
Hi, I'm sorry to bother you.
[cpg cn=true]


There was me and Koyi. Things got even more complicated.
[cpg]


I hope Koyi doesn't get the wrong idea that I have another girlfriend.
[cpg]


I was thinking, "I hope Koyi doesn't get the wrong impression that I have another girlfriend," but rather than that, the female student looked at Koyi and said
[cpg]


[OnName num="female_student"]
Um, ...... is she your girlfriend, by any chance?
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Shizuku447"]
[OnName num="shizuku(yu)"]
I'm not going to go home. So if you're here for your brother, you might as well go home."
[cpg cn=true]

[FACE method="shock_5" pos="4/5"]

I didn't want to be scratched any more by this girl, so I said so as quickly as I could.
[cpg]

[FACE method="change_6" pos="4/5"]

I don't feel like I'm scratching myself, though.
[cpg]


[OnName num="female_student"]
I see, I see. ......
[cpg cn=true]


The girl left without hesitation. I'm not so sure I'm being honest, or giving up too quickly. ......
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="4/5" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[OnName num="yu(shizuku)"]
What was that?　That's my friend.
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Shizuku448"]
[OnName num="shizuku(yu)"]
He seemed to have a thing for me. But I'm glad I managed to fool him."
[cpg cn=true]


[OnName num="yu(shizuku)"]
I feel like I'm making things even more complicated than they need to be. ......
[cpg cn=true]


Shizuku is right. I feel like I've gone the extra mile.
[cpg]


[OnName num="yu(shizuku)"]
The fact that Koyi and her brother are lovers is ...... well, I guess it's okay.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

What do you mean?　What do you mean?
[cpg]


[OnName num="yu(shizuku)"]
I'm sure you're going to be with me today. I'm not going to let you mess up my room."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]

...... Shizuku knows what I mean. I'm not going to not do it after being told that much.
[cpg]


;//ＢＫ


[FACE method="shake_1" pos="4/5"]
[VOICE f="Kokoro155"]
[OnName num="kokoro"]
I was a little nervous when she said ...... she was my girlfriend. I was almost getting my head mixed up."
[cpg cn=true]


I was told. But what else was I supposed to do at that moment ......?
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


I then took Koyi home before it got dark.
[cpg]


Our relationship was gradually changing. It was changing, or rather, it had to change.
[cpg]


As I said to Shizuku's friend earlier, I can't claim for a moment that we are not lovers now.
[cpg]


Someday, somewhere, we have to get together.
[cpg]


I'm sure Koyi feels the same way.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈（雫）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]

During dinner, Shizuku and I switched places, and then Shizuku and my sister switched places.
[cpg]


I almost spewed out my rice, but it wasn't the first time either.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[OnName num="yu"]
...... I guess it's time to settle the score.
[cpg cn=true]


We can't just keep switching places. We also need to clarify our relationship with Koyi.
[cpg]


It's time to cut to the chase. He asked me to tell him what he could do to get back on track against Koyi.
[cpg]


I can't help but feel that it's finally time.
[cpg]


This half-assed relationship will come to an end. A new step will be taken.
[cpg]


Taking this step means that I have to break off my feelings for my sister.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2500]
[BG f="b_07_1.ui" time=1000]
[WAIT time=2500]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



Thinking about this, I was strangely unable to sleep.
[cpg]


Why is that? It was supposed to be a normal morning, but nothing out of the ordinary.
[cpg]



;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_10_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


I went to Shizuku's room on my way out of the house.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=1000]

[OnName num="yu"]
I went to her room and asked her to help me. I'm thinking of going out with Koyi.
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Shizuku456"]
[OnName num="shizuku(marina)"]
"That's good, isn't it ......?　I'm not against it.
[cpg cn=true]


I could see she was upset. I felt a sense of helplessness.
[cpg]


[OnName num="yu"]
"I'm sorry, but I'm not going to be able to live up to your feelings.
[cpg cn=true]


She turned her head slightly and then looked at me,
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Shizuku457"]
[OnName num="shizuku(marina)"]
"I hope you will be happy.
[cpg cn=true]


She said, "I hope you'll be happy. It was really ...... unbearable.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



Koyi wasn't there when I left the house. She must have gone on ahead of me.
[cpg]


I need to talk to Koyi. Even if I don't, I have to go to the school.
[cpg]


Even if I put aside my confession to Koyi, how do I get back to normal?
[cpg]


I thought I would ask her to tell me just that.
[cpg]



[SE f="se001"]
;//【ＳＥ】『歩く』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の通う学園＿教室』（昼）******************************************************





Then, during lunch break. I started to talk to her.
[cpg]


[OnName num="yu"]
"Hey, Koyi ......, isn't it about time?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

What?　He asks. I go on.
[cpg]


[OnName num="yu"]
You have an idea how to get back to normal, don't you? Tell me."
[cpg cn=true]


This was also an expression of my intention to stop our relationship.
[cpg]


Of course, Koyi understood this. She was perplexed, but she said ......
[cpg]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Kokoro165"]
[OnName num="kokoro"]
I understand. I'll talk about it. ...... It's not good for things to go on like this, is it?"
[cpg cn=true]


It seems that Koye is ready to talk about it.
[cpg]



;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


Koyi's plan was very simple. She suggested that I should talk to my parents about it.
[cpg]


I told her that if she did that, she would inevitably be treated as a guinea pig. ......
[cpg]


Koyi said that he wouldn't do anything that would make his lovely children spend time in the hospital.
[cpg]


She had a point, but it wasn't enough.
[cpg]


[OnName num="yu"]
What else can you tell me about ...... that would support this strategy?"
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]

Koyi spoke further. She said that even if we examine brain waves and other data, we may not be able to prove that the personalities have been switched after all.
[cpg]


He said that the condition must be beyond the capability of current medical science. If that were the case, they would not be the subject of research in the first place.
[cpg]


They're going to try to put the kids back in trouble," Koyi said.
[cpg]


[FO pos="4/7" time=1000]
[WAIT time=1100]


;//【ＢＧ】『主人公の通う学園＿教室』（昼）******************************************************


[OnName num="yu"]
...... sure they are. Somehow they've been working to keep their fathers from finding out about it.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Kokoro166"]
[OnName num="kokoro"]
I can understand why you would do that. I can understand why you would feel that way.
[cpg cn=true]


[OnName num="yu"]
Thanks, I'll give it a try when I get home. I'll give it a try when I get home.
[cpg cn=true]


I had forgotten to tell him something important, so I decided to tell him.
[cpg]


[OnName num="yu"]
I'm going to reply to your confession after we're no longer interchangeable. Please wait until then."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]

Koyi must have guessed what was going on. It's not normal to expect to be rejected at this point.
[cpg]

[FACE method="bow_6" pos="2/3"]

She blushed and nodded.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


I returned home. The time of the battle is near.
[cpg]


If things don't go well, I will spend my adolescence in the hospital.
[cpg]


But that's enough. It was better than if things were to remain deadlocked.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


After the six of us finish eating together, I only have a moment to talk to my father.
[cpg]


He's the kind of person who goes right back to his room. I seize the moment and begin to talk to him.
[cpg]


[OnName num="yu"]
"Hey, Dad. Listen to me.
[cpg cn=true]


[OnName num="father"]
What is it?　What is it? What's wrong?
[cpg cn=true]


[OnName num="yu"]
Don't be surprised. Me, Shizuku and my sister ...... are switching bodies.
[cpg cn=true]


[FACE method="shock_5" pos="2/5"]
[FACE method="shock_5" pos="4/5"]

Shizuku and her sister were surprised. I should have told them about this.
[cpg]


[FACE method="shake_5" pos="2/5"]
[VOICE f="Marina439"]
[OnName num="marina(shizuku)"]
I should have told them!　Why are you telling them?
[cpg cn=true]


[OnName num="father"]
"...... that their bodies have been switched?　I was going to tell you all about it.
[cpg cn=true]

[FACE method="change_4" pos="2/5"]
[FACE method="change_4" pos="4/5"]

I was going to tell you everything. I was going to tell him everything, and I wasn't going to hold back now.
[cpg]


My father took me seriously. My sister joined in the persuasion.
[cpg]


I told her about the inconvenience of being constantly replaced and the lack of money. And the lack of money.
[cpg]


As we talked about it, she seemed to remember that it made sense with what we had been doing and saying, and she began to understand.
[cpg]


[OnName num="father"]
He said, "Well, I'm going to go to the hospital for a full examination. Then we'll talk about it.
[cpg cn=true]


So that's what we're going to talk about. I was prepared for that.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



The next morning. I took the day off from school and headed for the hospital.
[cpg]


My father seemed to have arranged everything. Things went smoothly.
[cpg]


However, a thorough examination is a thorough examination. It was not a time-consuming process.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]

It was almost evening when we were finally released.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku458"]
[OnName num="shizuku(marina)"]
I said, "...... if it turns out that we've been replaced, we'll be ......
[cpg cn=true]


[OnName num="yu"]
Then I'll have to be prepared to be treated as a guinea pig.
[cpg cn=true]


A frightened drop. I tapped her on the shoulder and said, "Don't worry.
[cpg]


[OnName num="yu"]
I'm fine. There is no way in today's medicine to determine your personality or prove that you are someone else.
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Marina440"]
[OnName num="marina(shizuku)"]
I know. ...... I think you're right."
[cpg cn=true]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



And then I got the results. The results of the tests on our bodies.
[cpg]


[OnName num="father"]
"All three of us are fine," he said. That doesn't make us good candidates for research.
[cpg cn=true]

[FACE method="change_2" pos="2/5"]
[FACE method="change_2" pos="4/5"]

[OnName num="yu"]
Then, ...... father, will you help us?
[cpg cn=true]


[OnName num="father"]
Yeah, sure. If it can be paid for, of course.
[cpg cn=true]


Grandpa is relieved. That's a good reaction, I thought.
[cpg]


Finally, the case is settled. It took a long time to get here. ......
[cpg]



[free time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
;//ＢＫ



Grandpa, who had obtained the funds, had begun to build the machine at a rapid pace.
[cpg]


The completion was so fast that I wondered if it was possible to make it that quickly.
[cpg]


It was really just a matter of money. ...... What a staggering story.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="b_sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="b_sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="b_ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="b_ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



Holiday. The day to activate the machine was to be today.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Shizuku459"]
[OnName num="shizuku(marina)"]
'No more unfulfilled desires for someone else's body?　Drop."
[cpg cn=true]


[OnName num="yu"]
I don't want you to tell me that you do now."
[cpg cn=true]


It's not like her to say that. I wondered if she was trying to get back to normal more than anyone else.
[cpg]


[FACE method="shake_2" pos="2/5"]
[VOICE f="Marina441"]
[OnName num="marina(shizuku)"]
'I think I'd like to be in my brother's body again,......, but I think I'm done.'
[cpg cn=true]


Shizuku seems to have given up too. There is nothing wrong with that.
[cpg]


[OnName num="grandfather"]
'Well then, let's get started. All three of you, come over here."
[cpg cn=true]



[free time=1000]
[BG f="b_08_2.ui" time=1000]
[WAIT time=1000]
;//ＢＫ



The laboratory. There was a machine similar to the one we had seen one day.
[cpg]


We went in and did as Grandpa told us.
[cpg]


[OnName num="grandfather"]
Listen to me," he said. Don't have any evil thoughts.
[cpg cn=true]


Would that change anything?　Is that what the soul is like?
[cpg]


But I'm not lost anymore. I'm going back to my body. ......
[cpg]


[OnName num="grandfather"]
I'll fix a soul in each body. Let's go!"
[cpg cn=true]

[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈　雫
;//と変更してください
;//----------------------------------------
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


The machine makes a noise. And a strange sensation envelops my body.
[cpg]


It didn't make sense to me that my soul would be fixed to my body.
[cpg]


But I felt myself settling into my body.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



[FACE method="bow_2" pos="4/5"]
[VOICE f="Shizuku460"]
[OnName num="shizuku"]
I wondered what was going to happen to me, but ...... I was able to get back to normal after all.
[cpg cn=true]


A drop talking while eating. It's bad manners.
[cpg]


But she is definitely acting like one.
[cpg]


My sister is the same way again. My sister is back, calm to all intents and purposes.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina442"]
[OnName num="marina"]
I'm going to have to catch up on my lectures now," she said. Oh, how depressing.
[cpg cn=true]


[OnName num="yu"]
"Don't say that, sis.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[FACE method="change_1" pos="4/5"]

[OnName num="father"]
...... back to normal?"
[cpg cn=true]


[OnName num="mother"]
"Yes, apparently so. That's good.
[cpg cn=true]


[OnName num="grandfather"]
"Mm-hmm. Nothing is impossible for me.
[cpg cn=true]


[FACE method="change_2" pos="2/5"]
[FACE method="change_2" pos="4/5"]

I had been waiting for a long time for a normal dinner table. I was happy.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



But I still have a role to play, or rather, something I have left to do.
[cpg]


About Koyi. Nothing has been settled yet.
[cpg]


I can't let Koyi wait like this. I should take action right away.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



Sunday. Shizuku and her sister seemed to be in a good mood.
[cpg]


There was no need to worry about them suddenly switching places. It was natural for them to be in a good mood.
[cpg]


But I had something to do. With that in mind, I left the house.
[cpg]



[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



I rang the doorbell at Koyi's house.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kokoro167"]
[OnName num="kokoro"]
"Hi, ......, Yu-kun."
[cpg cn=true]


[OnName num="yu"]
I need to talk to you now. Time, okay?"
[cpg cn=true]

[free time=1000]

Koyo says, "Wait a minute," and returns to her house.
[cpg]


I'm sure she had to go tell her parents and get ready for the day.
[cpg]


I waited. I felt like I was waiting for a very long time, and it was getting frustrating.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Shizuku461"]
[OnName num="shizuku"]
"Oh, Kori-chan. Hello!
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]
Koyi bowed her head and said, "Hello, I'm so glad to see you.
[cpg]


Koyi is cute today, too. Even her every gesture is cute.
[cpg]


I have to tell her how I feel. I invite her to my room.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



[FACE method="shake_7" pos="2/3"]
[VOICE f="Kokoro168"]
[OnName num="kokoro"]
Let's see, what's the ...... story. The swapping has been put to rest, right?"
[cpg cn=true]


[OnName num="yu"]
I say, "Yeah. So that means the deal with you is over, right?
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

Koyi's expression darkens a little. I didn't mean to depress her.
[cpg]


[OnName num="yu"]
So I thought I should make a fresh start here.
[cpg cn=true]


[OnName num="yu"]
Koyi, I ...... don't care about you.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Kokoro169"]
[OnName num="kokoro"]
Wait a minute. Let me tell you.
[cpg cn=true]


I was surprised. I was surprised that she wanted to say it from Koyi.
[cpg]


[FACE method="change_1" pos="2/3"]

I was a little surprised because I thought it would be difficult for Koyi to tell me.
[cpg]


[OnName num="yu"]
Well, then, ......, you tell me first.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

Koyi mumbled. See, this is why it's better to start with me.
[cpg]

[FACE method="bow_3" pos="2/3"]

As I was thinking so, Koyi gathered up her courage and said, "I'm going to go out with you.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Kokoro170"]
[OnName num="kokoro"]
Please go out with me. I've always liked you.
[cpg cn=true]


[OnName num="yu"]
I've been in love with you for a long time. ...... me too.
[cpg cn=true]




For some reason, even I became respectful. It was kind of funny and we both laughed.
[cpg]




;//ＢＫ
;//========================================
;//●ＣＧ（ヒロインに迫る主人公）ev_44
;//人物１：主人公
;//服装１：私服
;//人物２：サブヒロイン
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;**【ＣＧ】 ev_44_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="Kokoro171"]
[OnName num="kokoro"]
It's like a dream, really it is. It's like a dream, is it really true?
[cpg cn=true]


[OnName num="yu"]
It's not a dream. I don't know if it's something I should say.
[cpg cn=true]


I'm dreaming, too. But it's not something you should be telling Kohl's.
[cpg]



[VOICE f="Kokoro172"]
[OnName num="kokoro"]
I'll do something that's like a girlfriend,......, Yu-kun.
[cpg cn=true]


[OnName num="yu"]
"......Yeah."
[cpg cn=true]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


The first thing to do is to make sure that you have a good idea of what you want to do.
[cpg]



There was a topic that had been building up until now. How much we love each other.
[cpg]

[FACE method="bow_6" pos="2/3"]

We said things we wanted to say but couldn't, and we were embarrassed to say it to each other.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Kokoro188"]
[OnName num="kokoro"]
Yoo-kun is nicer than me, he's too good for me. ......
[cpg cn=true]


[OnName num="yu"]
No, no, Koyi is more attractive. ......
[cpg cn=true]

[FACE method="change_6" pos="2/3"]

This is roughly what the content of the conversation was about. It's a conversation that really wouldn't be interesting to anyone.
[cpg]


But we ourselves were happy.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





That night, Koyi also decided to have dinner with us.
[cpg]


I suggested that we tell her that we started dating at this time, but she was not prepared to do so. ......
[cpg]



Koyi said she was not ready for that.
[cpg]



[FACE method="bow_2" pos="3/3"]
[VOICE f="Shizuku462"]
[OnName num="shizuku"]
She said, "Yummy!　Another one!"
[cpg cn=true]



A drop is always a drop. She may look a little shady after she was dumped by me, ......
[cpg]

[free time=1000]

I'm sure she'll be back to her old self someday.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kokoro189"]
[OnName num="kokoro"]
I'm so happy for you, Yu.
[cpg cn=true]


[OnName num="yu"]
I'm happy. I'm happy.
[cpg cn=true]


I wonder if it's okay to have this conversation. I feel like I'm going to be found out.
[cpg]


[OnName num="mother"]
What's wrong, you two? You're smiling at me.
[cpg cn=true]


[OnName num="yu"]
"Nothing. Something good happened.
[cpg cn=true]


Something good happened, something life-changing. I didn't say, "I'm going to eat dinner.
[cpg]

[FACE method="change_1" pos="2/3"]

It was Koyi's idea that brought me back to the routine I'd had before. ......
[cpg]


I got the affection from Koyi that I wanted more than the routine I had before.
[cpg]

[FACE method="bow_6" pos="2/3"]

From now on, I have to give the same amount of love to Koyi.
[cpg]


I'm sure I can do it, I had a feeling that I could.
[cpg]

[SCENE id=17]

[jump storage="epend.ks" target="*start"]
;//ＥＮＤ：サブヒロインルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

