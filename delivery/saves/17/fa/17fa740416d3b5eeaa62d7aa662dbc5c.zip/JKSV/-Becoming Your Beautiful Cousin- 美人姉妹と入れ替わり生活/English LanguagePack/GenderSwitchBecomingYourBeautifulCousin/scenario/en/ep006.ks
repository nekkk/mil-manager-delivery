

*start

;//==============================
;//女性化ポイントが０の場合


*root01_1|With my sister

;#################################################
*Ep006|With my sister
;#################################################

[SCENE id=6]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************





[OnName num="yu(marina)"]
...... Really, you're going away."
[cpg cn=true]


My sister followed me on the way. It might be natural.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Marina257"]
[OnName num="marina(yu)"]
I'll take care of your emotional pain. I'll take care of your emotional pain.
[cpg cn=true]


[OnName num="yu(marina)"]
"Well, ......, thank you."
[cpg cn=true]


Laughing softly. It was a gesture that made her look like my sister, even though it was my face.
[cpg]


[OnName num="yu(marina)"]
Don't push yourself too hard. If you get hurt, I'll be in trouble.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Marina258"]
[OnName num="marina(yu)"]
I know, but I don't want to give your heart to someone else. I know, but I don't want to give your heart to someone else.
[cpg cn=true]


She seemed to agree with my words. She stopped there.
[cpg]


[OnName num="yu(marina)"]
She stopped and said, "......Then, have a good day.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
I said, "I'm off," and headed for the city.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



I didn't know who to call out to.
[cpg]


Young people are different, I think. It's better to be older to some extent. ......
[cpg]


Someone who is willing to spend a lot of money in exchange for dating a young girl.
[cpg]


I look for that in my own way and call out to them.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Marina259"]
[OnName num="marina(yu)"]
"Oh, um..."
[cpg cn=true]


[OnName num="man"]
Oh?　What?"
[cpg cn=true]


I was about to scoot up when the guy scowled at me, but I managed to muster up the courage to speak up.
[cpg]


;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

......This is how our mission began.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈（由宇）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------

[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************


[OnName num="yu(shizuku)"]
Good morning. Mugu mugu."
[cpg cn=true]


I'm chewing a piece of bread in my mouth and looking at me. I'm sure it's not your sister, but Shizuku.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marina261"]
[OnName num="marina(yu)"]
"Good morning, ......."
[cpg cn=true]


By the next morning, she and Shizuku had switched places again.
[cpg]


Conveniently, my body is still hers. I might as well skip college today.
[cpg]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Shizuku195"]
[OnName num="shizuku(marina)"]
What's wrong, sis? If you're not feeling well, don't push yourself too hard at college, okay?"
[cpg cn=true]


That's what my sister suggested. I'm sure you should do that.
[cpg]


[OnName num="mother"]
I'm sure you'll be able to find a way to get a good night's sleep. Maybe you should take a break.
[cpg cn=true]


No, that's not a good idea. I can't take a chance and stay at home all day.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Marina262"]
[OnName num="marina(yu)"]
I'm fine. I'm fine. ......
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『街』（昼）******************************************************


We walked around town. I was approaching a man with my sister's body.
[cpg]

I thought it would be better to have one person who seemed to have money to solve the problem instead of calling out to them in the dark.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_03_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



God must have been playing a trick on me, because I spent a lot of time as his sister.
[cpg]


The probability of our replacement is such that I can only assume that God or something is regulating the process.
[cpg]


As time went by, I was able to repair the machine smoothly.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



One day, however, an incident occurred.
[cpg]



;//ＢＫ

When I was with You-Know-Who in my sister's form......
[cpg]


[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈　雫
;//と変更してください
;//----------------------------------------


[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の通う学園＿教室』（昼）******************************************************


I came back into my body.
[cpg]


I thought, "Oh no. Of all the worst times to be back in my body.
[cpg]


It means I changed into either Shizuku or my sister.
[cpg]


[OnName num="yu"]
Damn ......!"
[cpg cn=true]


Luckily, it was my lunch break, so I called her on her cell phone.
[cpg]


From the text messages, it seems that Shizuku's has Shizuku's body in it. In other words, ......
[cpg]


That means my operation has been pointless. I'm putting a lot of pressure on my sister.
[cpg]

I got ...... a tremendous feeling of emptiness.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[VOICE f="Marina264"]
[OnName num="marina"]
...... I'm home."
[cpg cn=true]


She came home with a pale face.
[cpg]


She must have been scared. But there was nothing I could say to her.
[cpg]


I couldn't help but feel sorry for myself. I couldn't protect her.
[cpg]


I knew something like this would happen one day. ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



After nightfall, I thought of a countermeasure.
[cpg]


Trying to tell the guy that I don't know when my schedule will change, or something like that?
[cpg]

But I don't think it would work.
[cpg]


It might even hurt Shizuku's feelings.
[cpg]


Still, I have no choice but to do it. I want to cover as many wounds as possible.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


I switched places with my sister during the night.
[cpg]


I heard she was crying. When I looked in the mirror, I saw the swollen marks from her tears.
[cpg]




[window target=false]
[free time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[BG f="b_03_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


The days go on. If my mom and dad found out about everything, it would be a big deal.
[cpg]

I wonder how much time I spent there, and then ......
[cpg]

He was able to get me the money to fix the machine.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

Noon. Mom and Dad were gone, so we went to Grandpa.
[cpg]


We piled up wads of cash. If he says he can't fix it, we're screwed.
[cpg]


[OnName num="grandfather"]
Where did you get this kind of money, ......?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina265"]
[OnName num="marina(yu)"]
I'm pretty sure that's what you're thinking. Mostly what I did.
[cpg cn=true]


[OnName num="grandfather"]
"......, I see. I'm really sorry about that.
[cpg cn=true]


Grandpa seems to be sorry.
[cpg]


But that was partly no one's fault. We were also thoughtless.
[cpg]


We already know that it's not enough just to be angry with him.
[cpg]


[OnName num="grandfather"]
I understand. Let's rebuild the machine again. We are a little short of funds, but we will sell the machines in the laboratory to make up the difference.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[OnName num="yu(marina)"]
"Thanks to ....... Thank you in advance.
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="hiraki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="hiraki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="hiraki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



A few more days passed.
[cpg]


We didn't tell our parents the truth, and the day came.
[cpg]



[free time=1000]
[BG f="b_08_4.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_op"]
[WAIT time=100]
;//ＢＫ



We were put in another machine, in Grandpa's lab, and he said, "Look, you're living in your own body.
[cpg]


[OnName num="grandfather"]
"Listen to me. Imagine you are living in your own body.
[cpg cn=true]


[OnName num="grandfather"]
You never know what can happen if you let evil thoughts enter your mind. Don't think about another body.
[cpg cn=true]


He explained that the spirit plays a big part in the process because it is the soul.
[cpg]


[OnName num="grandfather"]
It's okay to imagine that you want to go back to your body. Just imagine yourself.
[cpg cn=true]


We nodded. And then the machine started working.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


Looking back, I realize that a lot has happened before I came here.
[cpg]


There were many times when I learned about the true nature of my sister and Shizuku that I didn't need to know, and the same was true for Koyi.
[cpg]


But I think there was a lot I needed to know.
[cpg]


I want to get back into my body. And then, I want to put it all behind me. ......
[cpg]


I strongly wished so. I think my sister would have done the same.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈　雫
;//と変更してください
;//----------------------------------------



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


And then...
[cpg]



[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[OnName num="yu"]
I woke up in my body.
[cpg cn=true]


I woke up in my body. I'm sure you and Shizuku woke up in your own bodies, too.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

[OnName num="mother"]
What?　You're in a great mood today, aren't you, Shizuku?
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Shizuku196"]
[OnName num="shizuku"]
"Heh heh heh. A little bit.
[cpg cn=true]


The always energetic Shizuku is even more energetic than usual.
[cpg]


We are back together. We probably won't be replaced in the future.
[cpg]


However, she still looked gloomy. I think it's only natural.
[cpg]


I am probably the only one who can heal her wounds.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の通う学園＿教室』（昼）******************************************************



[FACE method="bow_2" pos="2/3"]
[VOICE f="Kokoro086"]
[OnName num="kokoro"]
I'm glad you're back in your original body. I'm glad. ......
[cpg cn=true]


At my school, during the lunch break, I had to talk to Koyi.
[cpg]


[OnName num="yu"]
Yeah, well."
[cpg cn=true]


I was worried about my distant look, and Koyi looked concerned.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="sKokoro007"]
[OnName num="kokoro"]
What's wrong?　Come to think of it, that ......"
[cpg cn=true]


[OnName num="yu"]
I'm fine. It's nothing to tell Koyo about.
[cpg cn=true]


Koyi likes me. I already know that.
[cpg]


But I can't respond to that. Because I have found someone I have to love more.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


I was a little depressed going back home.
[cpg]


What should I say to my sister?
[cpg]


I can't see her as a perfect love interest because she's my relative.
[cpg]


No, I may be looking at her, but there's still a part of me that's still stuck in my ...... mind.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[OnName num="yu"]
I'm home."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marina266"]
[OnName num="marina"]
......Welcome home."
[cpg cn=true]


He seems to have sunk into a low state. He's been like this ever since.
[cpg]


I think we need to sort out our relationship with each other now that I'm me again.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

After dinner, I invited her to my room for the night.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina267"]
[OnName num="marina"]
She said, "What, call me up. I'm already sleepy.
[cpg cn=true]


She was back to her old cold self. I started.
[cpg]


[OnName num="yu"]
You said sometime ago that you couldn't see me as family. You said one day that you don't see me as family. You said you saw me as a love interest.
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
She sat down and looked down.
[cpg]


[OnName num="yu"]
I can't give you an answer yet," she says.
[cpg cn=true]


She was asking me to be her boyfriend for a while. The actuality that you can't get a good deal more than this.
[cpg]


The actuality that I have not yet given a proper answer to her is that I haven't. So, I didn't.
[cpg]


[OnName num="yu"]
But if she is hurting, I want to heal her. Wouldn't being with me override that ......?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Marina268"]
[OnName num="marina"]
I'm sure it's not that simple for a ...... girl."
[cpg cn=true]


I felt my sister's face brighten a little as she said that.
[cpg]


We will always be together. We will always be together. I confirmed it again.
[cpg]



;//========================================
;//●ＣＧ（元の姿で、ヒロインにキスをする主人公）ev_21
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_21_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

I approached her.
[cpg]

It was as if I was trying to make up for something I couldn't do before.
[cpg]

[VOICE f="sMarina012"]
[OnName num="marina"]
......"
[cpg cn=true]


When I feel her body warmth, I am somehow soothed.
[cpg]

Even though that's not what it was originally intended to be.
[cpg]



;//ＢＫ

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



And so. My sister and I started dating without telling our families.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Shizuku197"]
[OnName num="shizuku"]
I'm not a big fan of that. You're the only one who gets to keep your brother to yourself.
[cpg cn=true]


I didn't have to think about who was in Shizuku's body anymore.
[cpg]


You're back to coming in on your own where people sleep, aren't you?
[cpg]


[OnName num="yu"]
I'm not going to let you do it again. Your sister will be jealous.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Shizuku198"]
[OnName num="shizuku"]
I know." "Yeah. I'm going to stop now, too.
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



My sister had eaten first.
[cpg]


The most important thing to keep in mind is that you should not be afraid to ask for help from your friends and family.
[cpg]


I'm going to have to work hard too,......, and it's time to start thinking about my career path.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina302"]
[OnName num="marina"]
"...... what, grin."
[cpg cn=true]


I see. Was I smirking?　I'm sure he's happy to be with his sister if that's the case.
[cpg]


I'm sure she'll be with you from now on.
[cpg]


Sometimes I wonder when we will stop being a family.
[cpg]


No, I used to think about it. Now I have an answer for the most part.
[cpg]


We will always be a family.
[cpg]


[OnName num="yu"]
Am I smiling?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Marina303"]
[OnName num="marina"]
Don't you realize it?　I can't help it.
[cpg cn=true]


My sister laughed as she said this.
[cpg]

[SCENE id=13]

[jump storage="epend.ks" target="*start"]
;//ＥＮＤ：ヒロイン１ルート１



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

