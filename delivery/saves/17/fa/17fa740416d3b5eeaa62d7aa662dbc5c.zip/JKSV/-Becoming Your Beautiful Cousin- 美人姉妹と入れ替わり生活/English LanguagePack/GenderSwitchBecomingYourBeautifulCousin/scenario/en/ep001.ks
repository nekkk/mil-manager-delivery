

*start


;#################################################
*Ep001|I've become my sister.
;#################################################

[SCENE id=1]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



Days pass a little from there. Time passes, then a weekend.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=3000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



One holiday evening. We were relaxing as a family, doing nothing in particular.
[cpg]


Then the incident that started it all happened.
[cpg]


[OnName num="grandfather"]
"So, I've finished ......."
[cpg cn=true]


There was an old man who looked ten years older than he was.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Marina010"]
[OnName num="marina"]
Completed? The warp device?　How could you say that, it's ......."
[cpg cn=true]


He said, "I'm so excited," and then he said, "I'd like to be a test subject right now. He was so excited that he wanted to be a test subject right now.
[cpg]


I'm sure Koyi's cooking would be enough for me to be a test subject. ......
[cpg]


[OnName num="grandfather"]
Come on. You'll experience a first for mankind, no, a first for any living creature."
[cpg cn=true]


I don't mind the difference. I mean, I'd rather they try it with at least guinea pigs, though.
[cpg]



;//========================================
;//●ＣＧ非エロ（三人機械の中に入っている。半透明のガラスの中、立っている感じ）ev_02
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//人物３：主人公
;//服装３：私服
;//場所　：主人公の家＿研究室
;//時間　：夕方
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Shizuku019"]
[OnName num="shizuku"]
"Wow,...... it's the world of science fiction, it's amazing, brother."
[cpg cn=true]


[OnName num="yu"]
Don't shake me, ...... it's hard for me to respond."
[cpg cn=true]


The sister is a little taken aback, thinking that warping is impossible, no matter how much grandpa you are.
[cpg]


[OnName num="yu"]
So what are we going to do?
[cpg cn=true]


[OnName num="grandfather"]
"Well, you'll just have to wait and see. We'll get it up and running in no time.
[cpg cn=true]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』


;**【ＣＧ】 ev_02_a ***********************
[CG id=1 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="Marina011"]
[OnName num="marina"]
Hey, hey, hey!　Are you sure you're all right?
[cpg cn=true]


[OnName num="yu"]
It's okay. It'll probably fail. ......
[cpg cn=true]


[OnName num="grandfather"]
Excuse me!　This is a real breakthrough.
[cpg cn=true]


Grandpa said that if all went well, the three of us would be shifted from our respective positions.
[cpg]


I will be in my sister's position, she will be in Shizuku's position, and Shizuku will be in my position.
[cpg]


It was difficult for me to understand why there were three of us instead of two, even though I asked for more details.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』



Then the light subsided. And the mechanical noise stopped.
[cpg]



[VOICE f="Shizuku020"]
[OnName num="shizuku"]
I asked her, "Huh?　Huh?"
[cpg cn=true]


Nothing in particular has changed. Not a speck of dust seems to have moved. ......
[cpg]


[OnName num="yu"]
"Is this a success?"
[cpg cn=true]


I asked Grandpa, but he had collapsed.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="yu"]
"It can't be that successful, can it? ......
[cpg cn=true]


Of course, warps don't exist in reality.
[cpg]


I was reminded of this and felt somewhat empty.
[cpg]


If this means that I'm feeling a little bit sick, or that there's something wrong with my body, then I'm still ......
[cpg]


I really don't see any change in anything. I think it's a little dreamless.
[cpg]


That said, it's always the case that Grandpa's experiments fail.
[cpg]


He has never harmed anyone's body. I'll continue to help him as an experimenter. ......
[cpg]



;//ＢＫ
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


With that thought, I went to sleep.
[cpg]




[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈（由宇）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=2000]
[window target=true]
[WAIT time=100]



In the morning, I felt something strange. The weight of the futon was different from usual.
[cpg]


It is not that there is a drop on top, but it is lighter than usual.
[cpg]


I was slumbering, unable to figure out what was wrong.
[cpg]



[VOICE f="Marina012"]
[OnName num="marina?"]
I heard a yawn, "Ohhhh, ......."
[cpg cn=true]


The yawning voice was already different. It was not a man's voice.
[cpg]


Something is wrong. When I wake up completely, I gradually understand what's going on.
[cpg]


It's my sister's room. Why am I here?
[cpg]



;//========================================
;//●ＣＧ非エロ（姿見を見てびっくりする主人公（ヒロイン１の外見）。自分の顔を触っている）ev_03
;//人物１：主人公（ヒロイン１の外見）
;//服装１：パジャマ
;//場所　：ヒロイン１の部屋
;//時間　：朝
;//========================================


[BGM f="bg_op"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Marina013"]
[OnName num="marina(yu)"]
"Nah... ......... ah... ........."
[cpg cn=true]


A voice came out. To put it simply, "I've become my sister.
[cpg]


Her face was drawn in surprise, her hands were touching her face, and her inarticulate voice was all hers.
[cpg]


I have become my sister. Once again, I ruminated in my mind.
[cpg]


What is the cause? Of course, I knew the cause, the experiment.
[cpg]


The warp had failed, but it could be that something else was going on.
[cpg]


Is it ......?　I don't know. Maybe your sister can tell us something.
[cpg]



[VOICE f="Marina014"]
[OnName num="marina(yu)"]
I've got to go. Who's in my body?"
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア開閉』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


[OnName num="yu(shizuku)"]
"Oh, sis!　I'm so excited, the warp worked!
[cpg cn=true]

[FACE method="change_7" pos="2/3"]

I came into the room just as she finished changing into her regular clothes.
[cpg]

...... this feeling is not my sister. Is this the part where you say I have a drop in my body?
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Marina015"]
[OnName num="marina(yu)"]
That means you've got a sis in your body ......."
[cpg cn=true]


[OnName num="yu(shizuku)"]
Huh?　I'm not your sister?　Oh, I see.
[cpg cn=true]


[OnName num="yu(shizuku)"]
If you were my brother, I would have an extra body .......
[cpg cn=true]


I'm not sure if I'm getting this right or not. I don't understand it well either.
[cpg]


I'm not sure I understand this situation perfectly. I'm not sure how much I can understand.
[cpg]

[SE f="se019"]
;//【ＳＥ】『ドア開閉』

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[WAIT time=2000]

[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku021"]
[OnName num="shizuku(marina)"]
I'm not sure if it's Yoo or Shizuku, but I'm not sure which one is Yoo.　Which one is Shizuku?
[cpg cn=true]


This time, the sister who looked like Shizuku came into the room.
[cpg]


I was at my wits' end. I had no idea what was going on. But I mustn't give up thinking.
[cpg]


I don't know what will happen if I don't do anything. Even if the present moment is good, it will affect my daily life.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************


[OnName num="mother"]
Good morning. Everyone's up early today, aren't they?
[cpg cn=true]

;//[FACE method="change_7" pos="4/5"]
[OnName num="yu(shizuku)"]
"Yes, we are. Yeah, haha. ......"
[cpg cn=true]


We had a meeting and decided not to tell my mom about it.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina016"]
[OnName num="marina(yu)"]
"Oh, hey, Dad.　Dad?
[cpg cn=true]


[OnName num="father"]
"Oh, yeah. It's been a while since I've been home. ...... Marina, have you changed your mood?
[cpg cn=true]

[FACE method="shock_5" pos="2/5"]
I'm not sure if it's a good idea or not. The situation is not good.
[cpg]


If my parents knew, it would make things even worse.
[cpg]


I need to hear the truth from my grandfather sooner rather than later.
[cpg]


[FACE method="shake_2" pos="2/5"]
[VOICE f="Marina017"]
[OnName num="marina(yu)"]
I'm not sure what to say, but I'm sure you'll be able to find out.
[cpg cn=true]


I was not used to using a woman's tone of voice, but I tried to cover up the situation.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="burainndo3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="burainndo3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="burainndo3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="4/5" time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="burainndo3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Then, in the lab. The three of us were questioning Grandpa.
[cpg]


[OnName num="yu(shizuku)"]
I'm going to stay with my brother for as long as I can, right?　Am I going to be your brother forever?
[cpg cn=true]


[OnName num="grandfather"]
He said, "Wait, wait. Give me time to understand.
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]


;//ev_02を再び表示


;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]
[window target=true]



According to Grandpa, the warp had succeeded.
[cpg]


[OnName num="grandfather"]
It's as if we've connected an invisible path to each of our positions. It's still there.
[cpg cn=true]



[VOICE f="Shizuku022"]
[OnName num="shizuku(marina)"]
Too heavy to carry the body, but enough to carry the soul. ......
[cpg cn=true]


[OnName num="grandfather"]
Yes. As I explained, if you use the device again in the opposite direction, it should return. ......
[cpg cn=true]


The old man mumbled something about how it was strange, how he couldn't explain why he didn't move at that very moment.
[cpg]


I wonder if it's okay ...... and then I'm enveloped in light again.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
[window target=true]

And then ......
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="white.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0xffffffff} time=1]
[WAIT time=1000]
[window target=true]


[OnName num="yu(shizuku)"]
Gee, keho. Goho-goho."
[cpg cn=true]


The machine broke down in a cloud of white smoke.
[cpg]





[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



Thank God it was Sunday. We could keep our father and mother in the dark about what was going on.
[cpg]


On a weekday, we wouldn't be able to cover up the fact that we didn't even know where we were going to school.
[cpg]


Grandpa would take care of the machine, and the three of us would have a strategy meeting alone.
[cpg]




[OnName num="yu(shizuku)"]
What are we going to do?　I might be in a bit of trouble if I stay like this all the time. ......"
[cpg cn=true]


That sounds like Shizuku. It's only "tough" for her. She seemed to be quite optimistic about the situation.
[cpg]


[FACE method="shock_3" pos="4/5"]
[VOICE f="Shizuku023"]
[OnName num="shizuku(marina)"]
It's more than "tough,"" she said!　This is a very important time in my life, and I could lose it.
[cpg cn=true]


I felt the same way. And my dad is home today.
[cpg]


If Mom finds out, of course Dad will tell him.
[cpg]


He's my grandfather on my father's side, and he has the mad scientist's blood in his veins, too," he said.
[cpg]


I guess you could say we're carrying on his blood too. ......
[cpg]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Marina018"]
[OnName num="marina(yu)"]
I'm sure if they found out we were switched, they'd do a full workup or something.
[cpg cn=true]


[OnName num="yu(shizuku)"]
'Yeah. I'm sure they would, but what does it matter?"
[cpg cn=true]


I don't think you understand. You don't seem to understand the gravity of the situation. ......
[cpg]


[OnName num="yu(shizuku)"]
Maybe you should talk to your dad.　He's a doctor. He might know something."
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku024"]
[OnName num="shizuku(marina)"]
I'm sorry, but the risk is greater. Do you want to spend your precious school years in a hospital?"
[cpg cn=true]


Yes, I do. If it comes to light that we have been replaced, we could be treated as guinea pigs.
[cpg]


How did we get replaced, how will our bodies be affected after the replacement, and can we reproduce it?
[cpg]


It is quite possible that we will grow up while we are investigating these things.
[cpg]


[OnName num="yu(shizuku)"]
You're saying I should hide ......?"
[cpg cn=true]

[FACE method="bow_7" pos="2/5"]
[FACE method="bow_7" pos="4/5"]
I nodded. My sister nodded, too. Shizuku was a little nervous,
[cpg]


[OnName num="yu(shizuku)"]
I understood. It's a secret between the three of us.
[cpg cn=true]


I was a little nervous, but she said, "Okay, it's just the three of us. I wondered how we would spend the rest of the day.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



[OnName num="mother"]
I asked her, "......, you three seem to be acting differently than usual. What's wrong?
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku025"]
[OnName num="shizuku(marina)"]
What do you mean?　Nothing out of the ordinary.
[cpg cn=true]


She was imitating Shizuku's tone, but she couldn't hide her coolness.
[cpg]


The most important thing to remember is that you can't be too careful with what you say.
[cpg]


[OnName num="father"]
I'm not sure what to say. It's Sunday after a long time since we've been together as a family.
[cpg cn=true]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Marina020"]
[OnName num="marina(yu)"]
"Don't worry!　Don't worry about it.
[cpg cn=true]


I said out loud, "Don't worry about it. But that's why I can't go out somewhere: ......
[cpg]


I'm not sure if I'm going to get ripped off by the conversation in the car or what. I'd rather pretend it's just Sunday.
[cpg]

[FACE method="change_7" pos="2/5"]
[FACE method="change_7" pos="4/5"]

[OnName num="father"]
"Yeah, ......?　Well, fine."
[cpg cn=true]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



We ended up spending most of the day in my room.
[cpg]


When it was better for the three of us to be together, but not face to face with my parents, this naturally happened.
[cpg]


[OnName num="yu(shizuku)"]
'Oh my God, ...... your fathers must be getting suspicious.'
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina021"]
[OnName num="marina(yu)"]
I'm sure they're suspicious of you," she said. You're a good actor, sis. You look rather drop-like.
[cpg cn=true]


Sis sighs with her hands on her head. It feels so strange when she makes that gesture with her drop body.
[cpg]


The first time I saw her, I was looking at her as Shizuku.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（雫）　雫（由宇）
;//と変更してください
;//----------------------------------------

[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[FACE method="shock_5" pos="2/5"]
[FACE method="shock_5" pos="4/5"]

[VOICE f="Shizuku026"]
[OnName num="shizuku(yu)"]
......Hey?"
[cpg cn=true]


At that moment, the scenery changed. It's a funny expression, but there's no other way to put it.
[cpg]


While the thing I was looking at blinked, or rather, without knowing if I blinked or not, it was replaced.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku027"]
[OnName num="shizuku(yu)"]
"This is ......."
[cpg cn=true]


[OnName num="yu(marina)"]
Oh, ......, no."
[cpg cn=true]


Your sister is very quick to understand. I mean, not.
[cpg]


[OnName num="yu(marina)"]
Now you're going the other way around?　Do you mean I'm Yu?
[cpg cn=true]


She clapped her hands, and then she put on a body drop.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Marina022"]
[OnName num="marina(shizuku)"]
I didn't understand for a moment. I didn't understand for a moment.
[cpg cn=true]


Only Shizuku seemed to be enjoying herself. I and my sister were at a loss.
[cpg]


Is there even such a case? I'm not sure if this is even the case, but I hear we're still going to keep switching.
[cpg]


If that was the case, I really wished I could get back to my original body by the time I took a bath.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


Dinner. The six of us sat around the table.
[cpg]


Grandpa didn't talk much, perhaps feeling a little responsible.
[cpg]


[OnName num="father"]
He said, "...... What's the matter, boys? What's troubling you?"
[cpg cn=true]


[OnName num="yu(marina)"]
"...... a little bit. I'm thinking about a lot of things.
[cpg cn=true]


I'm thinking about a lot of things," he said. I mean.
[cpg]


[OnName num="yu(marina)"]
What if...what if...what if...? What would you do if two or more people switched personalities?
[cpg cn=true]


[OnName num="yu(marina)"]
What would you do if such a patient came to you?
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]
[VOICE f="Shizuku028"]
[OnName num="shizuku(yu)"]
Hey, .......
[cpg cn=true]


You're being too aggressive, sister. That's too much.
[cpg]


[OnName num="father"]
That's a funny thing to say. Inspired by your grandfather?
[cpg cn=true]


[OnName num="father"]
"But, yes,...... if I could prove such a thing, I wouldn't let go of the patient.
[cpg cn=true]


[OnName num="yu(marina)"]
'...... I see.'
[cpg cn=true]


[OnName num="father"]
"Because it would be the breakthrough of the century if I could figure out why it happened and what's going on.
[cpg cn=true]


I knew this was a bad idea. You're just like your grandfather.
[cpg]


I nodded, receiving eye contact from my sister about what would happen if I told her everything.
[cpg]



;//ＢＫ

[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


I decided to return to Shizuku's room that day so as not to arouse her suspicions.
[cpg]


The bath was hard work. I had to keep my eyes closed most of the time, and I thought I might slip and fall.
[cpg]


There was very little room in the bathtub, so I took a shower. ......
[cpg]


And as I found out after spending the day switching places.
[cpg]


Getting into a girl's body is harder than you think. You can't help but look at them with an evil eye. And when the other person is a family member.
[cpg]


I don't mean that I can't go back to my body, but I feel like I can't go back to the days when I used to be.
[cpg]


[SE f=se029]
;//【ＳＥ】『衣擦れ』
[WAIT time=1000]


In ...... bed, I got under the covers and smelled the drops.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈　雫
;//と変更してください
;//----------------------------------------


[jump storage="ep002.ks" target="*start"]


;////////////////////////////////////////////////////////////////////////


