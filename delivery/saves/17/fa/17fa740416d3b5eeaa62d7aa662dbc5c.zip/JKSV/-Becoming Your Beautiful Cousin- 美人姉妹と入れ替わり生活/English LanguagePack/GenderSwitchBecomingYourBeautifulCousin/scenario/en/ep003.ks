
*start


;#################################################
*Ep003|Switching bodies
;#################################################

[SCENE id=3]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


The next morning I woke up in my body.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************


[OnName num="mother"]
"Good morning, Yu."
[cpg cn=true]


[OnName num="grandfather"]
Oh, good morning ......"
[cpg cn=true]


Grandpa was also at the table. I guess the story is that as long as there is no money, there is nothing that can be done at the institute.
[cpg]


And my sister said, ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Marina089"]
[OnName num="marina(shizuku)"]
I'm sure you've heard that the morning is all about the toast. Hey, big brother,......, it wasn't Yoo.
[cpg cn=true]


She looked so calm. It was as if there was a drop inside her.
[cpg]

[free time=1000]

The real sister, in other words, is acting like a drop of water.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuku053"]
[OnName num="shizuku(marina)"]
What's wrong?　You look like you're in a deep thought.
[cpg cn=true]


That made me feel a little sad. I couldn't reciprocate her feelings.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



Then we left the house and headed to the school via the station.
[cpg]


[OnName num="yu"]
Then, both of you ...... make sure there are no mistakes.
[cpg cn=true]


[FACE method="bow_2" pos="2/5"]
[FACE method="change_7" pos="4/5"]
[VOICE f="Marina090"]
[OnName num="marina(shizuku)"]
I know, it's okay, it's okay. Ha-ha-ha."
[cpg cn=true]


My sister was silent. I thought about mentioning it, but decided not to.
[cpg]



[SE f="se009"]
;//【ＳＥ】『電車揺れる音』

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の通う学園＿教室』（朝）******************************************************



[OnName num="yu"]
'Hah .......'
[cpg cn=true]


I wanted to sigh. I'm hiding it from my parents in order to have a decent student life, but ......
[cpg]


I think I'm already losing my sanity. I felt like that.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kokoro023"]
[OnName num="kokoro"]
Are you okay?"　Yu-kun...... has been acting strange lately."
[cpg cn=true]


[OnName num="yu"]
Yeah, that might be the case."
[cpg cn=true]


So from Koyi's point of view, it's suddenly becoming brighter or cooler.
[cpg]


And there must be times when you can't keep up with the school's classes.
[cpg]


It's possible enough while Shizuku is inside ......
[cpg]


[OnName num="yu"]
"...... Koyi. You."
[cpg cn=true]


I thought about confiding in Koyi and decided not to.
[cpg]


The more people who know one person, the more likely they are to pass it on to their parents.
[cpg]


I can say that it's just as dangerous, if not more so, to tell a teacher or someone.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

Time passed a little, and it was lunchtime.
[cpg]

;//【ＢＧ】『主人公の通う学園＿教室』（昼）******************************************************



[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

[OnName num="yu"]
"What's wrong, Koyi?
[cpg cn=true]


Koyi came up to me again. What is it this time?
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Kokoro024"]
[OnName num="kokoro"]
"I made lunch for you.
[cpg cn=true]


Ah. Oh, yes, that's what she said.
[cpg]


[OnName num="yu"]
I'm bringing my own lunch.
[cpg cn=true]


I see, I'll see you at ......," Koyi said, and went to put away the lunch box for the both of us.
[cpg]


A little impatiently, I suggested, "I think I can eat half of it.
[cpg]


[OnName num="yu"]
I think I can eat half of it. No, you can eat my lunch anytime you want.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Kokoro025"]
[OnName num="kokoro"]
Really ......?　Are you sure, Yu-kun?
[cpg cn=true]


[OnName num="yu"]
Yeah, sure, of course it's fine.
[cpg cn=true]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈　雫（由宇）
;//と変更してください
;//----------------------------------------



[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（昼）******************************************************



[FACE method="shock_5" pos="2/3"]
[VOICE f="Shizuku054"]
[OnName num="shizuku(yu)"]
......"
[cpg cn=true]


I, or rather Shizuku, was in the middle of walking, it seems.
[cpg]

[FACE method="shake_7" pos="2/3"]

The first thing that comes to my mind is the fact that I am not sure if this is a good idea or not.
[cpg]


I promise I'll eat my lunch for two, but I wonder if they'll swallow the situation ......
[cpg]


I'm sure my sister will make it work, but with Shizuku it's going to be tough.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


I dress as Shizuku and take classes at Shizuku's school. It was yawn-inducingly easy because of the difference in age between the two of us.
[cpg]


I'm going to take the class, thinking this is just another review. ......
[cpg]



[window target=false]
[BG f="b_07_3.ui" time=1000]
[WAIT time=3000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（夕方）******************************************************



[OnName num="male_student"]
I'm going to go to the school and take a class. Tokiwa-san."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuku055"]
[OnName num="shizuku(yu)"]
"...... what?"
[cpg cn=true]


If it were him, I would have said, "What? I replied in the most appropriate way possible.
[cpg]


[OnName num="male_student"]
Tokiwa-san's mood has changed recently. She seems cooler or more melancholy.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Shizuku056"]
[OnName num="shizuku(yu)"]
I don't know. I don't think so.
[cpg cn=true]


Hiding my tiredness, I just shrug it off as appropriate.
[cpg]


I don't want her to befriend a boy without telling Shizuku and then have Shizuku be confused later.
[cpg]


[OnName num="male_student"]
The actuality of the particulars is that you can find a lot of different types of shoes and boots.　I'll walk with you on the way home, right?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Shizuku057"]
[OnName num="shizuku(yu)"]
I'm sorry, I have something to do today. See you later.
[cpg cn=true]


[OnName num="male_student"]
I'll see you later. No, it's okay. See you later.
[cpg cn=true]


Shizuku is popular, too. I mean, just by walking around, you can feel the eyes of men on your chest.
[cpg]


It's kind of demoralizing. I've learned a lot of things about my family that I didn't need to know.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



I walked back to my house. On the way back to my house, I still feel a man's eyes on my chest.
[cpg]


I don't know who they are, but students from another school and even an old man are glued to my chest.
[cpg]


I guess just because we are different genders, it doesn't make a difference. I knew Shizuku was cute.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FACE method="bow_7" pos="2/3"]
[VOICE f="Shizuku058"]
[OnName num="shizuku(yu)"]
I'm home...... has a lot of shoes.
[cpg cn=true]


Whose shoes are these? They're a girl's shoes, so are they a friend of your sister's?
[cpg]


[OnName num="yu(shizuku)"]
The most important thing to remember is that you are not the only one who can do this. Koyi-chan is here.
[cpg cn=true]


What? That means ......
[cpg]

[free time=500]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Kokoro026"]
[OnName num="kokoro"]
"Oh, Shizuku. I'm sorry to bother you.
[cpg cn=true]


I was head-over-heels. Someone in my life is going home with a boy that I refused to go home with.
[cpg]


Is it Shizuku? It must be Shizuku, my sister would never do something so obvious.
[cpg]


[OnName num="yu(shizuku)"]
She said, "Koyi, you have really beautiful skin. How do you take care of it?"
[cpg cn=true]


Oh no, no, no. If it were me, I wouldn't say "Koyi-chan" and I wouldn't talk about it.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Kokoro027"]
[OnName num="kokoro"]
"That's ...... normal, normal. It's not something I would say to a boy."
[cpg cn=true]


The first thing that comes to mind is the fact that the two of you are not the only ones who have been through this. She blushed at the unprecedented approach.
[cpg]


[OnName num="yu(shizuku)"]
Oh, um, Shizuku ......, let's talk about it together, too."
[cpg cn=true]


No, I can't do it. I'm not sure that I won't fall apart, and I can't stand to see Shizuku about to fall apart.
[cpg]


[FACE method="shake_2" pos="2/5"]
[VOICE f="Shizuku059"]
[OnName num="shizuku(yu)"]
I said, "Okay. Take your time, both of you.
[cpg cn=true]


I said something that sounded like what I thought of Shizuku, and headed to her room.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_10_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿雫の部屋』（夕方）******************************************************

I collapsed on the bed. I was too tired.
[cpg]


I was too tired, but I could smell Shizuku's scent on the bed where I fell down.
[cpg]


It's all over. I felt like it was the end of my family.
[cpg]



[SE f="se019"]
;//【ＳＥ】『ドア開く』



Then I hear the door open. Then I hear the door open, and in the distance I hear a voice saying, "I'm home.
[cpg]


My sister has come home. I left the room, wanting to talk to her.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Marina091"]
[OnName num="marina"]
She said, "...... Oh, Koyo's here. Make yourself at home."
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]

Koyi bowed her head and said, "Thanks for coming. She looked a little worn out.
[cpg]

[free time=500]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

[OnName num="yu(shizuku)"]
Koyi-chan, what kind of magazines do you study for fashion?
[cpg cn=true]


She was talking like a woman again. You're talking as if you were a woman, Shizuku.
[cpg]


[OnName num="yu(shizuku)"]
She always looks so cute in her personal clothes. I'm not a reference ...... either, I wonder what it is. Let's see..."
[cpg cn=true]


As if remembering, Shizuku is trying to act like a man. The most important thing to remember is that you should never be afraid to ask for help.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Kokoro028"]
[OnName num="kokoro"]
I'll see you later.
[cpg cn=true]


[OnName num="yu(shizuku)"]
I'll see you later. Bye.
[cpg cn=true]


Finally, Koyi left. I was relieved, because I couldn't stand it if she gave me any more shit.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



Then Mom and Dad came home for dinner.
[cpg]


Grandpa was there too. Me and Shizuku were still swapping places.
[cpg]


[OnName num="yu(shizuku)"]
"Yummy!　More!"
[cpg cn=true]


[FACE method="shock_5" pos="4/5"]

[OnName num="father"]
......?
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[FACE method="change_7" pos="4/5"]
[VOICE f="Marina092"]
[OnName num="marina"]
....... Yu, have you been in a different mood lately?
[cpg cn=true]


Dad is suspicious. My sister followed up with a quip.
[cpg]


[OnName num="yu(shizuku)"]
She said, "What?　Oh, yeah, um, ...... sorry."
[cpg cn=true]


That's not a good reaction either, Shizuku. I'm sorry," he said, "I'm sorry.
[cpg]


[OnName num="grandfather"]
I'm sure it happens sometimes. They are at an impressionable age.
[cpg cn=true]


[OnName num="yu(shizuku)"]
Yes, that's right. It's all right.
[cpg cn=true]


[OnName num="father"]
"Yeah, ......?　Are you three hiding something?
[cpg cn=true]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Shizuku060"]
[OnName num="shizuku(yu)"]
What are you talking about?　What's wrong, brother?
[cpg cn=true]


It's bad to reply "I'm not hiding anything" here on the contrary. It is better to shake Shizuku and then make her say she is not hiding anything from you.
[cpg]


[OnName num="yu(shizuku)"]
I'm not hiding anything. It's okay.
[cpg cn=true]


Oh, my God. I'm really having a hard time with this. ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina093"]
[OnName num="marina"]
"Shizuku, you're not a good actor. You're not a very good actor.
[cpg cn=true]


[OnName num="yu(shizuku)"]
"Uh...... but I can't help it. I've never been a boy before.
[cpg cn=true]


It would be rather strange if I had ever been a boy.
[cpg]


[OnName num="yu(shizuku)"]
Koyi-chan was happy, too, and I think that's good."
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku061"]
[OnName num="shizuku(yu)"]
No, I'm in trouble. It's not good that I don't remember today's conversation.
[cpg cn=true]


[OnName num="yu(shizuku)"]
I see.
[cpg cn=true]


Do you understand or not? The most important thing to remember is that you should never forget your own personal information.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿雫の部屋』（夜）******************************************************

The most important thing to remember is that you can't just go to the store and ask for a discount.
[cpg]


[OnName num="yu(shizuku)"]
She said, "Onii-chan, you're at ......, aren't you?"
[cpg cn=true]


I decided to crawl under the covers as she called out to me.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Shizuku062"]
[OnName num="shizuku(yu)"]
She's not at .......
[cpg cn=true]


[OnName num="yu(shizuku)"]
I knew he was there.
[cpg cn=true]



[SE f="se029"]
;//【ＳＥ】『布団はがす』



I was thinking, "I knew he's here," when he pulled off the futon.
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Shizuku063"]
[OnName num="shizuku(yu)"]
What are you doing?
[cpg cn=true]


[OnName num="yu(shizuku)"]
"Mmm-hmm. Hey, it's my body, so I don't mind, do I?"
[cpg cn=true]


It's crazy. The drops are going crazy.
[cpg]


Usually when I say skinship, she never said so much.
[cpg]

;//移植のためシーンをカットしています

;//========================================
;//●ＣＧ（主人公（ヒロイン２の外見）がベッドに腰掛けて座る）ev_09
;//人物１：主人公（ヒロイン２の外見）
;//服装１：私服
;//人物２：ヒロイン２（主人公の外見）
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています


[VOICE f="sShizuku002"]
[OnName num="shizuku(yu)"]
She said, "Give me a break. I'm already sleepy."
[cpg cn=true]


[OnName num="yu(shizuku)"]
No, you can't sit on my body like that."
[cpg cn=true]


I'm careful, too. I'm careful, too.
[cpg]


[VOICE f="sShizuku003"]
[OnName num="shizuku(yu)"]
Nobody's watching you.
[cpg cn=true]


[OnName num="yu(shizuku)"]
I'm looking at you!"
[cpg cn=true]


[FADEOUTBGM]
[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

The next day, I woke up.
[cpg]


[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈（由宇）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------

[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]

The next day, I woke up in my sister's body.
[cpg]


I was used to waking up in the morning in a girl's body.
[cpg]



[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



As soon as I woke up in the morning, I was summoned to my room.
[cpg]


It was a suggestion from my sister who has the appearance of a drop. They are going to work out a way to spend time together from now on without being discovered.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku101"]
[OnName num="shizuku(marina)"]
I'll have to get Yuu to learn to wear makeup. ......
[cpg cn=true]


[OnName num="yu(shizuku)"]
I see. That might have been a blind spot."
[cpg cn=true]


The most important thing to remember is that you can't just take a look at the pictures and say, "I'm sorry, I'm sorry, I'm sorry, I'm sorry.
[cpg]


[OnName num="yu(shizuku)"]
I'm good at that.
[cpg cn=true]


[FACE method="shake_3" pos="4/5"]
[VOICE f="Shizuku102"]
[OnName num="shizuku(marina)"]
I'm good at it. If you don't wear makeup that looks like me, people will notice.
[cpg cn=true]


[OnName num="yu(shizuku)"]
I see......... but you'll have to remember to put on makeup when you switch with me, right?"
[cpg cn=true]


The most important thing to remember is that you are not the only one who has to remember to wear make-up. I was not sure if it's called natural makeup or not.
[cpg]


I mean, I didn't know I was going to have to put makeup on myself. ...... No, of course that's what I'm going to have to do.
[cpg]


[OnName num="yu(shizuku)"]
I'm not sure if it's natural makeup or not, but I didn't know. Go ahead."
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina095"]
[OnName num="marina(yu)"]
'...... please be gentle with me.'
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


And so I practiced my makeup until just before going to school. I was in danger of waking up to something weird.
[cpg]


I mean, there was no waking up, and now I was a woman. ......
[cpg]


[FACE method="shake_4" pos="2/5"]
[VOICE f="Marina096"]
[OnName num="marina(yu)"]
"Makeup is such a hard thing to do. ...... Is it normal to do it every day?"
[cpg cn=true]


[FACE method="bow_4" pos="2/5"]
[VOICE f="Marina097"]
[OnName num="marina(yu)"]
I don't even have to think about it. It's hard when your face looks different every day."
[cpg cn=true]


[OnName num="yu(shizuku)"]
I've been doing it for a long time," she said. I'm not going to do it every day.
[cpg cn=true]




[window target=false]
[free time=1000]
[BG f="b_03_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



Then I walk to the university where my sister goes to school.
[cpg]


The train was easy to get to without changing trains, but I still felt lost.
[cpg]


[SE f="se009"]
;//【ＳＥ】『電車揺れる音』

;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_07_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


I also learned how to appreciate the women-only carriages.
[cpg]


I was scared for no reason to be on a crowded train with both men and women.
[cpg]


Just a slight bump on my arm made me think I was being molested.
[cpg]


I turned my head and saw that it was a woman's arm. ......
[cpg]


I couldn't stand it and moved to the women-only car on the way.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の通う学園＿教室』（昼）******************************************************



However, even though this is the university my sister attends, I don't know a single person there.
[cpg]


There is a cafeteria, so I didn't need a lunch box, but eating alone was quite difficult.
[cpg]


I was having a hard time eating alone.　There were girls or boys who asked me to eat with them. ......
[cpg]


I knew they must have many friends unlike me.
[cpg]


After refusing all of them, I ate my meal and ...... it didn't fit as much as I thought it would.
[cpg]


I wonder if my sister has a different stomach size or something like that.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina098"]
[OnName num="marina(yu)"]
It's ...... hard."
[cpg cn=true]


Being a stranger is hard, but being a woman is just as hard.
[cpg]


If you get used to it, that may be a problem.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の通う学園＿教室』（夕方）******************************************************


And the time goes by. Before I know it, it is evening.
[cpg]


During lectures, I spend time without thinking. In a university setting, I am not assigned to write on the board.
[cpg]


But that doesn't mean I can keep up with the lecture.
[cpg]


I just copy what is written in my notebook. I can't think of anything, but I can't do nothing either.
[cpg]


And so, when I finish all the lectures, I go to ......
[cpg]


[OnName num="male_student"]
I said to myself, "Oh, you know what? Mr. Tokiwa, can we go after this?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]

A male student approached me. I feel kind of uncomfortable with the way he looks at me. I get the impression that he's licking my body.
[cpg]


Maybe I'm starting to have a sense of crisis as a woman.
[cpg]


There is only me and the boy left in this room. Then, I heard a voice saying, "I've been thinking about Tokiwa-san for a long time,
[cpg]


[OnName num="male_student"]
I've been interested in Tokiwa-san for a while. ......
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

That's what he starts talking about. What should I do?
[cpg]


[OnName num="male_student"]
"Well, I mean. I like you, and I want you to go out with me."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

She confessed her love to me. I wonder if this is an everyday occurrence for my sister.
[cpg]


There aren't many days when I'm her sister, are there?　Is there such a thing as a pinpoint target for me?
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marina099"]
[OnName num="marina(yu)"]
I'm at a loss for a response.
[cpg cn=true]


I'm at a loss for a reply. I don't know who's going to be inside the next time I see her.
[cpg]


I had to make a decision here. So I decided to say no. "I'm sorry, I'm glad you feel that way.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina100"]
[OnName num="marina(yu)"]
"I'm sorry, I appreciate the sentiment, but ......
[cpg cn=true]


[OnName num="male_student"]
"...... haha. I'm sorry, I'm glad you feel that way, but I'm going to refuse.
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
The male student comes one step closer to me. I step back.
[cpg]


And then he grabbed my arm. I instinctively feel fear.
[cpg]


I think it's because I'm a woman. If I were a man, I wouldn't feel this much fear.
[cpg]


[OnName num="male_student"]
I'm like, "Okay, you know what?　I don't care if we're friends or anything.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Marina101"]
[OnName num="marina(yu)"]
"Stop it, let go of me. ......!"
[cpg cn=true]


I'm just trying to get away from him, but he grabs my arm and pulls it away.
[cpg]


I tried to run away, but I couldn't untangle my arms from his grip. At that time ......
[cpg]


[OnName num="female_student"]
The first thing you need to do is to make sure that you have a good understanding of what you're doing.　You don't like it, Tokiwa-san."
[cpg cn=true]


I received an unexpected helping hand. There was a girl passing by in the hallway.
[cpg]


[OnName num="male_student"]
'No, no, this is ......
[cpg cn=true]


I don't know whether to be pushy or not. When you're as pretty as your sister, you're bound to attract all kinds of guys.
[cpg]


The first thing you need to do is to get a good look at the website and see if you can find anything that you like. With tears in my eyes, I ......
[cpg]


[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[FACE method="shake_4" pos="2/3"]
[VOICE f="Marina102"]
[OnName num="marina(yu)"]
'Huh ...... how is your sister coping?'
[cpg cn=true]


Was it wrong of me to suddenly say, "I'm sorry.
[cpg]


I don't know. I don't want to think about it too much.
[cpg]


I didn't think that being a woman was such a scary thing.
[cpg]


I thought that no matter how much male chauvinism disappears, it will never amount to anything.
[cpg]

[free time=800]
At that time, I met an unexpected person on the way home.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Kokoro029"]
[OnName num="kokoro"]
She said, "Oh, Marina-san. You're on your way home from ......, right?"
[cpg cn=true]

[FACE method="bow_7" pos="2/5"]
I replied, "Yes. I can't reveal the secret to Koyi either.
[cpg]


I had to act like a big sister. The first thing that comes to mind is the fact that the first time you see a person in the marketplace, you're going to be surprised.
[cpg]


[FACE method="bow_3" pos="4/5"]
[VOICE f="Kokoro030"]
[OnName num="kokoro"]
I asked her, "Um, ...... I have some advice for Marina-san. May I?"
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[OnName num="yu(shizuku)"]
Oh, welcome back."
[cpg cn=true]


Is this the way you say it, Shizuku? She sounds like a noh.
[cpg]


[FACE method="bow_6" pos="4/5"]
[VOICE f="Kokoro031"]
[OnName num="kokoro"]
I'm sorry to bother you. I'm so glad to see you.
[cpg cn=true]


Koyo's face is a little red. I wondered if she had a fever. ......
[cpg]


At Koyo's request, we decided to head to my room, or in other words, my sister's room. I'm going to go to my room, in other words, my sister's room.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_3"  pos="4/5" time=1]
[BG f="b_09_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿麻莉奈の部屋』（夕方）******************************************************

[FACE method="bow_3" pos="4/5"]
[VOICE f="Kokoro032"]
[OnName num="kokoro"]
I'd like to discuss something with you, Marina-san.
[cpg cn=true]

[FACE method="bow_7" pos="2/5"]
I braced myself, wondering what was going on.
[cpg]


I wondered if she had found out about us, and if she had, she would have told me, the person closest to her.
[cpg]


I was thinking about all sorts of things, like the fact that I have a drop inside me right now.
[cpg]


[FACE method="bow_3" pos="4/5"]
[VOICE f="Kokoro033"]
[OnName num="kokoro"]
I like Marina's cousin, ...... Yuu-kun.
[cpg cn=true]

[FACE method="shock_5" pos="2/5"]

I couldn't believe my ears. I mean, today is the day he often confesses his love to me.
[cpg]


But when I think about it, this time the person I'm confessing to is unquestionably me.
[cpg]


Koyi is telling me everything she's thinking about. She says she can't sleep at night when she thinks about me.
[cpg]


;//俺に処女を貰って欲しいとか、同性同士にしてもちょっとおかしいんじゃないかってくらい踏み込んで話してくる。
;//[cpg]


I didn't even realize that she was thinking about me that much.
[cpg]


[FACE method="shake_4" pos="4/5"]
[VOICE f="sKokoro001"]
[OnName num="kokoro"]
I couldn't help but tell someone that I dream about Yu-kun almost every day.
[cpg cn=true]


I started to feel like I was being invited. Of course, Koye would not know that it was me.
[cpg]


If I revealed everything to Koyi here and now, she would be in trouble. However, ......
[cpg]


[FACE method="shake_4" pos="2/5"]
[VOICE f="Marina103"]
[OnName num="marina(yu)"]
......I'm Yoo, you know. Koyi."
[cpg cn=true]


I couldn't help but say it. Koyi was flinching, but there was nothing I could do.
[cpg]



;//ＢＫ



I decided to tell her everything that day.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_5"  pos="4/5" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[OnName num="yu(shizuku)"]
She said, "Yeah, I'm Shizuku. I am Shizuku, and I think that you are in my body right now.
[cpg cn=true]


She was listening to me with a blank stare.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Kokoro035"]
[OnName num="kokoro"]
She said, "You're kidding, right ......?　You two are teasing each other, aren't you?
[cpg cn=true]


[OnName num="yu(shizuku)"]
She said, "You wouldn't say something like this if it was a lie. There's no reason for it.
[cpg cn=true]


Koyi is getting redder and redder. It's as if she's confessed her feelings to me.
[cpg]


[OnName num="yu(shizuku)"]
The actuality is that the actuality is that you can't get a good deal on the actuality.　Why did you decide to tell me?
[cpg cn=true]


[FACE method="shake_4" pos="2/5"]
[VOICE f="Marina104"]
[OnName num="marina(yu)"]
"That's the thing. ...... No, I can't talk about it.
[cpg cn=true]


I can't tell you. Koyi was going to tell her sister.
[cpg]


And what did Koyi think, he was going to get up from his seat.
[cpg]


[OnName num="yu(shizuku)"]
She said, "Wait, where are you going?"
[cpg cn=true]


Shizuku, who looked like me, tried to hold her back. But Koyo was about to leave the house.
[cpg]


[FACE method="bow_4" pos="4/5"]
[VOICE f="Kokoro036"]
[OnName num="kokoro"]
I'll come back to talk to you again," she said. Then, forget about today, Yoo-kun.
[cpg cn=true]


I was told to forget about it. I'm not so sure about that. ......
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


And a few days pass. The swapping continues and it's a bit of a mess, but the holidays have arrived.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------

[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



For us, holidays are no longer holidays. Rather, it makes us nervous.
[cpg]


Today it was me and my sister switching. Shizuku is still Shizuku.
[cpg]


[OnName num="grandfather"]
"Ah, ohon. As I told you, ...... it's going to cost a lot of money."
[cpg cn=true]


It was about the time after lunch. I was talking to Grandpa and he was talking to me.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marina105"]
[OnName num="marina(yu)"]
"You mean you've run out of ...... money?"
[cpg cn=true]


[OnName num="grandfather"]
That's true, and if we're going to fix the soul, we're going to have to build something completely different.
[cpg cn=true]


[OnName num="grandfather"]
'It can't just be a repair.
[cpg cn=true]


[OnName num="mother"]
What are you talking about, ......?"
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Marina106"]
[OnName num="marina(yu)"]
Whoa!
[cpg cn=true]


Suddenly my mother interrupted. I thought my heart was going to jump out of my chest.
[cpg]


[OnName num="mother"]
Marina, Koyo-chan is here. She said she had something to do.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marina107"]
[OnName num="marina(yu)"]
"You want me to ......?　What is it?
[cpg cn=true]


I know she has something to do with me. But how did she know I was now her sister?
[cpg]


Oh, maybe he thinks the switch is fixed. That makes sense.
[cpg]


I haven't explained the details yet.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿麻莉奈の部屋』（昼）******************************************************

[FACE method="bow_7" pos="4/5"]
[VOICE f="Kokoro037"]
[OnName num="kokoro"]
"Good evening. ......"
[cpg cn=true]


Koyi comes to visit me. Koyi and I are alone in her room, in her sister's clothes.
[cpg]


We remain silent for a while. Koyi is even sitting on her knees.
[cpg]


I am sitting on the bed, but Koyo does not move her legs.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="sKokoro002"]
[OnName num="kokoro"]
I'm sorry, I'm sorry about the other day. I'm sorry, the other day. ......
[cpg cn=true]


It seems that Koyi is trying to mend the situation. She seems to think that what happened the other day was a big mistake.
[cpg]


That may be true for Koyo, but for me, it's ......
[cpg]


I don't know. I feel like it's a good thing, and I also feel like I shouldn't have asked.
[cpg]


[FACE method="shake_4" pos="4/5"]
[VOICE f="Kokoro039"]
[OnName num="kokoro"]
Forget it. Forget about the other day, forget about everything ...... and pretend that the guy I love is also in the other room."
[cpg cn=true]


He's kind of an unrewarding guy, isn't he? I remember that I had to say I liked him.
[cpg]


I remember what he said to me the other day. I remember what he said to me the other day.
[cpg]


I can't do nothing. I can't just let him go.
[cpg]


[FACE method="shake_3" pos="2/5"]
[VOICE f="Marina108"]
[OnName num="marina(yu)"]
"...... Wait, Koyi."
[cpg cn=true]



;//========================================
;//●ＣＧ（サブヒロインに迫る主人公（ヒロイン１の外見）。キスをする）ev_10
;//人物１：主人公（ヒロイン１の外見）
;//服装１：私服
;//人物２：サブヒロイン
;//服装２：私服
;//場所　：ヒロイン１の部屋
;//時間　：昼
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;**【ＣＧ】 ev_10_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]



I wonder what Koyi would think of my current appearance.
[cpg]

I'm sure that if ...... you know it's me inside.
[cpg]

I thought this kind of thing would make sense.
[cpg]


;**【ＣＧ】 ev_10_a ***********************
[CG id=7 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sKokoro003"]
[OnName num="kokoro"]
I'll be back soon. ......"
[cpg cn=true]


The first thing you need to do is to make sure that you have a good understanding of what you're doing.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿麻莉奈の部屋』（昼）******************************************************

Then. Koyi came up with this.
[cpg]


[FACE method="shake_3" pos="4/5"]
[VOICE f="Kokoro063"]
[OnName num="kokoro"]
If you say you like me, think about it carefully before you say it. It may be selfish, but..."
[cpg cn=true]


......Yes, that's true. Maybe that's a good thing.
[cpg]


Koyi would not be convinced by the order that she liked me because I kissed her.
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



Then I explained to Koyi for a while. I explained to her for a while that we keep switching places.
[cpg]


That it would cost a lot of money to get back to the way we were.
[cpg]


She didn't seem to have much interest in those things. ......
[cpg]


No, perhaps he was not interested in them at all.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kokoro064"]
[OnName num="kokoro"]
Well then, good-bye."
[cpg cn=true]



[SE f="se019"]
;//【ＳＥ】『ドア閉まる』
[free time=1000]
[WAIT time=1000]

As it was, he left the house.
[cpg]


[OnName num="yu(marina)"]
He left the house just like that. "...... Yu, what were you doing with Koyochan?"
[cpg cn=true]


The father and mother were not here. The first thing to do is to make sure that you have a good time.
[cpg]


I've been talking with my ...... sister about forgetting about it.
[cpg]


I'm a very unfaithful person, aren't I?　I guess you could say that.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


Then Dad and the kids came home and we had dinner.
[cpg]


I couldn't taste it after what happened. I don't even remember what I ate.
[cpg]



;//ＢＫ


I was thinking, "I'm not going to be able to sleep like this.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈（雫）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------


[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I was in the futon in my room.
[cpg]


I wonder if she was asleep. What would happen if I had fallen completely asleep?
[cpg]


If she was asleep and I was standing up or something, would she just fall down?
[cpg]


At least the opposite is going to happen. Like, if you go into a body that's unconscious and you're awake, you're going to wake up.
[cpg]



[SE f="se026"]
;//【ＳＥ】『ドア叩く』
[WAIT time=1000]


As I was thinking this, I heard a tap on the door.
[cpg]


[VOICE f="Shizuku105"]
[OnName num="shizuku(marina)"]
"Oh, brother?　Can I have a word?"
[cpg cn=true]


[OnName num="yu"]
'...... oh, what's up?'
[cpg cn=true]


There was something a little different about the tone of his voice. The most important thing to remember is that you can't just go to bed and sleep right away.
[cpg]



[SE f="se019"]
;//【ＳＥ】『ドア開く』

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[WAIT time=1000]

[VOICE f="Shizuku106"]
[OnName num="shizuku(marina)"]
I thought I'd sleep on my brother's futon today too."
[cpg cn=true]


It's ...... strange. It's not Shizuku.
[cpg]


The first thing you need to do is to make sure that you have a good idea of what you're doing.
[cpg]


The only thing I can think of is that she is a sister, but if that's the case, her tone of voice is not right.
[cpg]


There is one possible case. She is pretending to be Shizuku for some reason.
[cpg]


[OnName num="yu"]
No, she wouldn't admit it if I told her in advance.
[cpg cn=true]


I replied as if I was a member of her family.
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Shizuku107"]
[OnName num="shizuku(marina)"]
I said, "Yes, you would. Let's see, that's ...... brother.
[cpg cn=true]


She was really pressing me. Then I realized why she was pretending to be Shizuku.
[cpg]


I guess she couldn't press me anymore after I told her to stop and forget about it.
[cpg]


She was trying to get close to me by pretending to be Shizuku.
[cpg]


;//ＢＫ


[FACE method="shake_6" pos="2/3"]
[VOICE f="sShizuku004"]
[OnName num="shizuku(marina)"]
I couldn't sleep. ...... I might be able to sleep with my brother.
[cpg cn=true]


[OnName num="yu"]
......"
[cpg cn=true]


I don't know how he felt about pretending to be a drop of water. I guess she felt like she couldn't hit me head on.
[cpg]



I thought it wasn't like her, but it couldn't have been anyone but her.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



It was then that I heard someone else's voice.
[cpg]


[VOICE f="sMarina007"]
[OnName num="marina(shizuku)"]
"Onii-chan!"
[cpg cn=true]



[SE f="se019"]
;//【ＳＥ】『ドア開く』


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

The door is opened without knocking. And a drop of water appears in the form of an older sister. ......
[cpg]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="4/5" time=800]
[VOICE f="Shizuku126"]
[OnName num="shizuku(marina)"]
"Oh ......, no, no, no, brother. This is, you know."
[cpg cn=true]


I can't pretend to be Shizuku anymore, but she's mending her ways.
[cpg]


I thought it was kind of cute, but now it might be Shura.
[cpg]


[OnName num="yu"]
I see. That was your sister."
[cpg cn=true]


I say in a barbed voice. I'll pretend I just noticed.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina122"]
[OnName num="marina(shizuku)"]
'Sis, did you approach me pretending to be me ......?'
[cpg cn=true]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



Then for a while, Shizuku, who looked like my sister, was getting angry at me, and my sister, who looked like Shizuku, was getting angry at me.
[cpg]


She was shunned. It's not an easy sight to see, no, it's a common one as far as looks go. ......
[cpg]


It was refreshing to see that the angry one's tone was Shizuku's.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



After they left, I decided to go to sleep this time.
[cpg]


As I doze off, I think. Whose body am I most comfortable in?
[cpg]


When I'm in my body, I wonder who I'll switch with when I'm in my body. ......
[cpg]


While I'm in my sister's or Shizuku's body, I feel like I can at least give up.
[cpg]


What would I want to be?　Whose body would I feel most comfortable in?
[cpg]



;//■選択肢
[switch]
[case "My own body"]
	[swap]
	[jump target="*select20_1"]
[case "Marina's body"]
	[swap]
	[jump target="*select20_2"]
[case "Shizuku's body"]
	[swap]
	[jump target="*select20_3"]
[endswitch]

1. My body
2、Marina's body
3, Shizuku's body



;//==============================
;//１、自分の体
*select20_1|Switching bodies




I don't even have to think about ....... No matter how much you don't know when you'll be replaced, your body comes first.
[cpg]



[jump target="*select20_4"]
;//==============================
;//２、麻莉奈の体
*select20_2|Switching bodies

[stflag pi_fi = 1]
;//女性化ポイント増加　+1



...... I feel at home in my sister's body, don't you?
[cpg]


I wonder if it's because she's my cousin whom I've always admired.
[cpg]


[jump target="*select20_4"]
;//==============================
;//３、雫の体
*select20_3|Switching bodies

[stflag pi_fi = 1]
;//女性化ポイント増加　+1



I think I might feel most at home in Shizuku's body. Even if we go to the school, we can be consistent because we have already studied there.
[cpg]


The body of the drop might be the most comfortable. Even if you go to the academy, you can be consistent because that's where you've already studied.
[cpg]



;//==============================
*select20_4|Switching bodies



I fell asleep thinking about this.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（雫）　雫（由宇）
;//と変更してください
;//----------------------------------------


[jump storage="ep004.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////
