
*start


;#################################################
*Ep004|Before you get any unfinished business.
;#################################################

[SCENE id=4]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="mother"]
Well, off you go, all of you.
[cpg cn=true]


[OnName num="yu(marina)"]
Yeah. I'm off, Mom.
[cpg cn=true]

[FACE method="shake_1" pos="2/5"]

Shizuku, who looked like my sister, just waved to my mother. And I said a few words to my mother as well.
[cpg]


;//[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[FACE method="bow_1" pos="4/5"]
[VOICE f="Shizuku127"]
[OnName num="shizuku(yu)"]
I'm off. ......
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[FACE method="change_1" pos="2/5"]
[FACE method="bow_7" pos="4/5"]
[VOICE f="Kokoro065"]
[OnName num="kokoro"]
Oh, good morning. Yoo-kun, I thought you weren't ....... Could it be Marina-san or Shizuku-chan?"
[cpg cn=true]


[OnName num="yu(marina)"]
What?　Hey ...... Yoo, did you say something?
[cpg cn=true]


I did. The most important thing to remember is that you don't have to stare at me with such a scary face.
[cpg]


I explained to my sister. I explained to her that I had explained the situation to Koyi.
[cpg]


She asked me why I had to explain, and I was at a loss to answer,
[cpg]


[FACE method="shake_2" pos="4/5"]
[VOICE f="Kokoro066"]
[OnName num="kokoro"]
It's not a big deal, Marina-san. Marina-san.
[cpg cn=true]


[OnName num="yu(marina)"]
"Really?　I hope so.
[cpg cn=true]


......It seems that for Koyi, what we touched on that day was not a big deal.
[cpg]


Well, maybe it is. There are some places where he would have to think so to do it.
[cpg]




[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（朝）******************************************************



And then we get to the school that Shizuku goes to.
[cpg]


It's PE again today. It's hard to get dressed. ......
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



In the middle of changing clothes, of course, all around me are girls.
[cpg]


The other day, I was the talk of the town because I was so active in P.E.
[cpg]


[OnName num="female_student_A"]
I was the talk of the town. Why did you hide it from me?"
[cpg cn=true]


[OnName num="female_student_B"]
I envy you for having such big breasts.
[cpg cn=true]


;//[FACE method="shock_5" pos="2/3"]
[VOICE f="Shizuku128"]
[OnName num="shizuku(yu)"]
She said, "Hyah!" and touched my breast.
[cpg cn=true]


I was told, "You're so big, I envy you. I was not used to this kind of stimulation and I squealed.
[cpg]


[OnName num="female_student_B"]
I'm sorry. You don't have to make such a sound. ......
[cpg cn=true]


I'm going to leave PE out of it today,......, it's too much trouble if it stands out too much.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（夕方）******************************************************



The first thing you need to do is to get a good idea of what you're looking for. The most important thing to remember is that you can't just go to the store and buy a new one.
[cpg]

[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
;//[free time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



I'm just so tired. ......
[cpg]


I was afraid that one day I would turn into a woman in body and soul. I felt like that.
[cpg]


A bad feeling, which cannot be described as uneasiness, envelops my body.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[VOICE f="Shizuku130"]
[OnName num="shizuku(yu)"]
I'm home. ......
[cpg cn=true]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


The family is having dinner together. The first thing that comes to mind is the fact that the family is now used to each of them acting in their own way.
[cpg]


I'm getting used to it, and that's why I think it's bad.
[cpg]


[OnName num="yu(marina)"]
"Shizuku, what's wrong?　You look pale.
[cpg cn=true]


She is telling me that if I don't look better, she will think I look suspicious.
[cpg]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Marina125"]
[OnName num="marina(shizuku)"]
I'm sure. What's wrong?"
[cpg cn=true]


And Shizuku, as expected, didn't seem to have much of an interest in acting.
[cpg]


Which would be more dependable, the one who has a lot of guts or the one who is always acting? I wondered who would be more reliable.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿雫の部屋』（夜）******************************************************

I went back to Shizuku's room and was left alone to ponder.
[cpg]


My heart is finally becoming a woman. If time continues to pass at this rate, it will be bad.
[cpg]


I might really accept this situation someday.
[cpg]


And after I accept it, when I can go back to my original body, I might still have feelings for my female body.
[cpg]


If that happens, there is nothing I can do. I was in a hurry.
[cpg]


I should talk to my sister or Shizuku. But who should I talk to?
[cpg]


After thinking about it, I came to a conclusion: ......
[cpg]



;//■選択肢
[switch]
[case "Marina"]
	[swap]
	[jump target="*select30_1"]
[case "Shizuku"]
	[swap]
	[jump target="*select30_2"]
[case "Neither"]
	[swap]
	[jump target="*select30_3"]
[endswitch]

1, Marina
2, Shizuku
3, neither



;//ルート分岐。選んだヒロインのルートへと進む


*select30_1|Calm sister
[jump storage="ep005.ks" target="*select30_1"]

*select30_2|Bright Shizuku
[jump storage="ep008.ks" target="*select30_2"]

*select30_3|Consult with Koyi
[jump storage="ep011.ks" target="*select30_3"]

