
*start



;//==============================
;//女性化ポイントが０の場合

*start|To think it was fun.
*root02_1|To think it was fun.


[SCENE id=9]



I, of course, welcomed the moment, wishing to be back in my body.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The machine starts up. And each spirit was anchored to its body.
[cpg]


;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈　雫
;//と変更してください
;//----------------------------------------


;#################################################
*Ep009|I hope you had a good time.
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[OnName num="yu"]
'...... not a dream, y'know?
[cpg cn=true]


Or rather, it was a dream of what had just happened. I wake up in my body.
[cpg]


I am so gutted. I never thought my body was so lovely.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


I went to the school with a happy feeling. My sister called out to me, "You're in a good mood, aren't you?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marina400"]
[OnName num="marina"]
You're in a good mood. Are you so happy to be back?
[cpg cn=true]


[OnName num="yu"]
She said, "Of course I am. You know what I mean.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
I know," she said, smiling at me.
[cpg]


......Yes. You didn't end up living up to your sister's sentiments.
[cpg]


I have to talk to Shizuku about that too.
[cpg]


I need to talk to Shizuku about our future. This is not the goal.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[BG f="b_07_3.ui" time=1000]
[WAIT time=2000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


And then we finished the school and went back home.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuku345"]
[OnName num="shizuku"]
It's nice to have a body of your own. ...... I guess it's called natural happiness.
[cpg cn=true]


[OnName num="yu"]
I'm sure it is. I was feeling that way too.
[cpg cn=true]


The first thing to do is to make sure that you have a good idea of what you want to do.
[cpg]


[OnName num="yu"]
I'm going to ask, "Hey, ......, what are we going to do now?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Shizuku346"]
[OnName num="shizuku"]
What do you mean?　Can't we just keep liking each other?
[cpg cn=true]


[OnName num="yu"]
I'm not sure I'm going to be able to do that. But if we go all the way to marriage or something like that. ......"
[cpg cn=true]


[OnName num="yu"]
I'm sure my parents would be against it. I'm sure my parents will be very opposed to it.
[cpg cn=true]


I sink down and I'm speechless.
[cpg]


What do you want to do?　I should want to be with Shizuku.
[cpg]


Why am I feeling so weak?
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Shizuku347"]
[OnName num="shizuku"]
I think it's fine.　Until we're old enough to get married, we'll just be three good friends."
[cpg cn=true]


[OnName num="yu"]
"...... three people?"
[cpg cn=true]


I asked again. I could understand if it was two good friends.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Shizuku348"]
[OnName num="shizuku"]
I'm sure you already know that your sister likes your brother, don't you?
[cpg cn=true]


[OnName num="yu"]
I asked her again, "Yes, of course. But why do you mention my sister?
[cpg cn=true]


He stares at me, saying, "Why?
[cpg]


[OnName num="yu"]
I'm not going to let you be the only one who's left out of the mix, are you?
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Shizuku349"]
[OnName num="shizuku"]
She's a real big sister to me. I think it's only natural.
[cpg cn=true]


I'm just waiting for you to get married.　Shizuku adds.
[cpg]


I don't know if it's good for ....... I don't know.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


My father returned in the evening. It's been a while since the six of us had dinner together.
[cpg]


I have nothing to be guilty of anymore. I had nothing to be ashamed of, and I had an appetite.
[cpg]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Shizuku365"]
[OnName num="shizuku"]
Another one!
[cpg cn=true]


[OnName num="mother"]
You're always eating too much, Shizuku.
[cpg cn=true]


And it was the same with Shizuku.
[cpg]


I was so happy to see her.
[cpg]


I was a little sad to see her. I was sure I couldn't leave her out of the loop.
[cpg]


;//ＢＫ
[free time=1000]
[BG f="b_07_4.ui" time=1000]
[WAIT time=2000]

;//移植のためシーンをカットしています

That day, the three of us talked until late at night.
[cpg]

I've been talking about the hard times I've been through, and I've been talking about Noh for a long time: ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[FACE method="bow_2" pos="4/5"]
[VOICE f="sShizuku016"]
[OnName num="shizuku"]
We talked about how much fun we had yesterday. Let's talk again, hey bro.
[cpg cn=true]


[OnName num="yu"]
"Yeah, well......
[cpg cn=true]


I can't reply positively. The most important thing to remember is that you can't just go out and buy a new car.
[cpg]


But I'm not going to let ...... sister's feelings go.
[cpg]


[FACE method="shake_1" pos="2/5"]
[VOICE f="Marina411"]
[OnName num="marina"]
I'm not going to let her feelings get in the way. I have to go now, or I'll be late."
[cpg cn=true]


[OnName num="yu"]
I'll be late. Let's hurry.
[cpg cn=true]

[free time=1000]

The night is over for the three of us. From now on, I see only a bright future.
[cpg]


Even if one day we will be separated. Even if there is a future where the three of us can't be together.
[cpg]


I want to be able to look back on this moment and remember how much fun we had.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuku377"]
[OnName num="shizuku"]
Hey, hey, big brother.
[cpg cn=true]


[OnName num="yu"]
What is it?　I told you I had to go.
[cpg cn=true]


Shizuku whispered in my ear. What she whispered were these words.
[cpg]

[free time=1500]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Shizuku378"]
[OnName num="shizuku"]
I love you. I love you all the time.
[cpg cn=true]

[SCENE id=15]

[jump storage="epend.ks" target="*start"]
;//ＥＮＤ：ヒロイン２ルート１



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


