
*start

;//==============================
;//１、麻莉奈

*start|Calm sister

;#################################################
*Ep005|Calm sister
;#################################################


[FADEOUTBGM]


[BGM f="bg_pi"]
[WAIT time=100]


*select30_1|Calm sister


[SCENE id=5]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="yu(marina)"]
"...... what?　What do you want?"
[cpg cn=true]


I went to my room to talk to my sister. There she was, looking very unhappy.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Shizuku131"]
[OnName num="shizuku(yu)"]
"Sis, why are you mad at me?
[cpg cn=true]


[OnName num="yu(marina)"]
She said, "I'm not mad. I'm not angry, I'm not grumpy.
[cpg cn=true]


She just said ...... and kept talking.
[cpg]


[OnName num="yu(marina)"]
I'm sorry. I'm sorry I pretended to be a drop and did that.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Shizuku132"]
[OnName num="shizuku(yu)"]
I'm not mad at you. That's not what I came here to talk about.
[cpg cn=true]


[OnName num="yu(marina)"]
No, let me talk to you. I still love you.
[cpg cn=true]


[OnName num="yu(marina)"]
The more I feel like I have to stop, the more I like you.
[cpg cn=true]


Did he have that much on his mind? No, if he didn't have that much on his mind, he wouldn't have acted like that, would he?
[cpg]


[OnName num="yu(marina)"]
I'm excited just by the fact that I'm in Yu's body right now. It must be disgusting.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Shizuku133"]
[OnName num="shizuku(yu)"]
I don't feel bad. I'm just like you.
[cpg cn=true]


These words might only be a comfort to my sister, but even so, I said them. But still, I said it.
[cpg]


[OnName num="yu(marina)"]
I said to her, "So, ......, what do you want?　What do you want?"
[cpg cn=true]


Oh, that's right. I almost forgot I was here on my own business.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Shizuku134"]
[OnName num="shizuku(yu)"]
I said, "I want to go back to my ...... body. The only way to do that is to make money.
[cpg cn=true]


[OnName num="yu(marina)"]
I know. I'm not thinking about it.
[cpg cn=true]


[OnName num="yu(marina)"]
I'm going to find someone to pay for it.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sShizuku005"]
[OnName num="shizuku(yu)"]
Someone who's willing to pay me. ......
[cpg cn=true]


[OnName num="yu(marina)"]
I'm not going to play games with you. I'm going to ask a man who looks like he has money.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]

The words came out of my sister's mouth in a rush.
[cpg]


[OnName num="yu(marina)"]
'While I'm in my body, of course. I can't involve Shizuku in this.'
[cpg cn=true]


Oh no. But it's the most efficient way for us to get back together.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Shizuku135"]
[OnName num="shizuku(yu)"]
You don't want to do that, do you? Don't try to sacrifice yourself.
[cpg cn=true]


[OnName num="yu(marina)"]
No, I don't want to. So give me the memories.
[cpg cn=true]


She continued to say these words. I didn't understand what she meant, so I kept silent.
[cpg]


[OnName num="yu(marina)"]
I didn't understand what she meant, so I kept my mouth shut. After that, I think I can do anything.
[cpg cn=true]


......It was finally a formal confession. It's up to me whether I accept it or not.
[cpg]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Shizuku136"]
[OnName num="shizuku(yu)"]
I'll go out with you. I'll go out with you.
[cpg cn=true]


There was no hesitation. I couldn't let her suffer alone.
[cpg]


[OnName num="yu(marina)"]
You feel sorry for me, don't you? Thank you."
[cpg cn=true]


I didn't feel that way. But no matter how many times I explained it to her, it wouldn't be enough.
[cpg]


From now on, I must show it with my attitude. So I kissed my sister without hesitation.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Shizuku137"]
[OnName num="shizuku(yu)"]
I kissed her without hesitation.
[cpg cn=true]


When I pulled my lips away from hers, she looked dazed.
[cpg]


[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈　雫
;//と変更してください
;//----------------------------------------


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


When I woke up in the morning, I looked at my hand and saw a craggy hand.
[cpg]

It seems she woke up with my body.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Marina126"]
[OnName num="marina"]
Good morning, Yu."
[cpg cn=true]


She was apparently my older sister. Shizuku would have said it a little more cheerfully.
[cpg]


[OnName num="grandfather"]
Oh, good morning. ......
[cpg cn=true]


[OnName num="yu"]
"Hey, Grandpa, I've got the money you asked for. I've got the money I was telling you about. You should get it ready.
[cpg cn=true]


[OnName num="grandfather"]
Marina ...... said the same thing. What are you up to?
[cpg cn=true]


I don't have to tell you what I'm up to. It all started with Grandpa's research.
[cpg]


Well, if it weren't for this, I might never have known about my sister's feelings.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kokoro067"]
[OnName num="kokoro"]
Good morning. Yoo-kun, right?
[cpg cn=true]


[OnName num="yu"]
"Yes, that's me. I'm glad you recognized me.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
Koyi says that she might be able to tell by her posture.
[cpg]


If it's true, it's amazing. It's a good thing that she really loves me.
[cpg]


But I can't respond to Koyi's feelings. I'm sorry, but I have to go to my sister first.
[cpg]


No, it might not be right to think that she comes first.
[cpg]


I might have to think about which one of them I'm going to get married with, my sister or Koyi.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の通う学園＿教室』（昼）******************************************************



And the class goes on. It's a little hard to keep up because my body wasn't taking the classes I was supposed to be taking.
[cpg]


But that goes for you and Shizuku too. For the sake of our lives, we need to get back to normal as soon as possible.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の通う学園＿教室』（夕方）******************************************************



After school, I decided to rush home.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kokoro068"]
[OnName num="kokoro"]
Why are you in such a hurry?　Let's go home together.
[cpg cn=true]


[OnName num="yu"]
I said, "I'm sorry. I can't take my time.
[cpg cn=true]


We're all in our own bodies now. This is the only time to do it.
[cpg]


;//姉さんを抱くなら、今日だ。もうためらってる暇はない。
If you're going to do something that's like making love, today's the day. There was no time to hesitate.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


;//[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

But she came home late. What was she thinking?
[cpg]


How could she not know what I was thinking? She's been waiting for this for a long time.
[cpg]


[OnName num="yu"]
...... is late, sis.
[cpg cn=true]



[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


She was late for dinner after all.
[cpg]


;//ＢＫ

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

I've been feeling like I can't find a sense of distance between us since we became lovers.
[cpg]

The most important thing to remember is that you should never be afraid to ask for help.
[cpg]


;//========================================
;//●ＣＧ（主人公に迫るヒロイン）ev_13
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;**【ＣＧ】 ev_13_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]

But when ...... we are alone, this happens.
[cpg]

[VOICE f="sMarina008"]
[OnName num="marina"]
I'm glad we didn't switch today."
[cpg cn=true]


As they say this, they kiss while still in their respective bodies.
[cpg]

Just spending time like this makes me happy.
[cpg]

Now if only we could manage to ...... swap.
[cpg]


;//移植のためシーンをカットしています



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[OnName num="yu"]
"Well,......, you know, sis."
[cpg cn=true]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Marina145"]
[OnName num="marina(yu)"]
What?
[cpg cn=true]


At that moment, the scenery was swapped.
[cpg]

I can't stop thinking about it. My sister who was with me a while ago is there.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


The next morning. Today I have to go to my sister's university.
[cpg]


I don't want to attend that lecture because it's like a preparation for the far future. ......
[cpg]

[free time=1000]

As I was thinking that, Koyi came to me on the road on the way.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Kokoro069"]
[OnName num="kokoro"]
'Good morning,...... er, Marina-san?
[cpg cn=true]


[OnName num="yu(marina)"]
'Correct. You know very well.
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Kokoro070"]
[OnName num="kokoro"]
I'm used to seeing them."
[cpg cn=true]



A conversation without any other conversation. The most important thing to remember is that the best way to get the most out of your money is to be optimistic.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=2000]

[FACE method="shake_7" pos="2/5"]

......It's still not good. I think the future of all of us will be closed.
[cpg]


It's ok now because I'm a student, but when I get a job, I won't be able to explain it anymore.
[cpg]


What if I get married in the future?　What if we have children?　The more I think about it, the darker the future becomes.
[cpg]

[FACE method="bow_3" pos="2/5"]
We have to go back to our respective bodies.
[cpg]

[FACE method="shake_7" pos="2/5"]
But is it really a good thing to sacrifice my sister as a result ......?
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の通う学園＿教室』（昼）******************************************************



I arrive at my sister's university.
[cpg]


Of course, I can't talk to anyone about this. I don't know anyone at this university.
[cpg]


They may know me, but they only know my sister.
[cpg]


I am lonely. At least if I didn't get replaced, I could talk to Koyi or someone like that. ......
[cpg]


No, if I don't get replaced, my sister will have no reason to make money available itself.
[cpg]


I'm not even sure what I'm thinking anymore. It's not good.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の通う学園＿教室』（夕方）******************************************************



[OnName num="female_student"]
"Ms. Tokiwa, are you alright ......?　It seems like you've been feeling overwhelmed.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Marina146"]
[OnName num="marina(yu)"]
Oh, yeah, ...... I'm fine.
[cpg cn=true]


I can't talk to anyone about it. I've been wanting to cling to the straw for a long time now.
[cpg]


The most important thing to remember is that you can't just go to the doctor and ask for help. I know that much. ......
[cpg]


But I feel like I'm going to accidentally say something. I'm not her sister now.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se001"]
;//【ＳＥ】『歩く』



I managed to finish the lecture while holding back these feelings.
[cpg]


I'm not sure anymore, my thoughts are swirling around in circles.
[cpg]


[OnName num="yu(marina)"]
I'm not sure what to think anymore. "...... Yu. You look like you're having a hard time.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina147"]
[OnName num="marina(yu)"]
I'm sure it's even worse for you.
[cpg cn=true]


[OnName num="yu(marina)"]
I'd be lying if I said it wasn't.
[cpg cn=true]


She looks at me with a distant look in her eyes. I want to protect her, but I don't know what to do.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





Dinner was more awkward than ever.
[cpg]


I'm in a deep thought. My sister is also feeling sorry for me.
[cpg]


Shizuku was eating her dinner without knowing what was going on. I could see her smile.
[cpg]


[FACE method="shock_2" pos="4/5"]
[VOICE f="Shizuku140"]
[OnName num="shizuku"]
"Another one!"
[cpg cn=true]


[OnName num="father"]
I'm going to go to ...... and see what's going on, Yoo. And Marina."
[cpg cn=true]


[OnName num="yu(marina)"]
I'm fine," she said. It's nothing.
[cpg cn=true]


She's acting like me, but it's really dark.
[cpg]


I think she's imagining what's going to happen.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Then we gathered in my room.
[cpg]


;//========================================
;//●ＣＧ（入れ替わった状態の二人）ev_14
;//人物１：主人公（ヒロイン１の外見）
;//服装１：私服
;//人物２：ヒロイン１（主人公の外見）
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================


;**【ＣＧ】 ev_14_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


All she can see from me is me.
[cpg]

But I can still see her as someone I love just because she's my sister inside.
[cpg]

I'm sure she feels the same way.
[cpg]

[VOICE f="sMarina009"]
[OnName num="marina"]
...... sister, you're not going to do anything."
[cpg cn=true]


I shook my head and then kissed her for I don't know how many times.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************




[VOICE f="Marina166"]
[OnName num="marina(yu)"]
'Good morning,...... where's Shizuku?
[cpg cn=true]


[OnName num="yu(marina)"]
'You're still sleeping. Leave her alone."
[cpg cn=true]


We acted like it in front of Mom and Grandpa.
[cpg]


[OnName num="grandfather"]
"...... are you okay, you two?"
[cpg cn=true]


Grandpa says that in a very white tone of voice.
[cpg]


It was his fault to begin with. But I couldn't say anything about it.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈（雫）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------


[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************



On the way to school. I was on my way to school when the scenery suddenly changed.
[cpg]


I stopped suddenly at a crosswalk. I almost ran into a red light.
[cpg]


It seemed that I had become me. What about my sisters?
[cpg]


I don't know, but at least I'm back in my body now.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の通う学園＿教室』（昼）******************************************************



[FACE method="bow_1" pos="2/3"]
[VOICE f="Kokoro071"]
[OnName num="kokoro"]
I see. So today you're Yu-kun being Yu-kun.
[cpg cn=true]


[OnName num="yu"]
Yeah, well ......
[cpg cn=true]


I heard that Koyi was following me while I had a different person inside me.
[cpg]


They would take me to the infirmary if I felt like I was going to get ragged, or they would tell me if I looked sick.
[cpg]


[OnName num="yu"]
I can't thank Koyi enough, really. ......
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Kokoro072"]
[OnName num="kokoro"]
'That's fine. I'm not bothered by it, and I can do it if I think it's for Yoo-kun's sake."
[cpg cn=true]


The words again pierce my heart. The most important thing to remember is that you can't just go out and buy a new pair of shoes.
[cpg]


The most important thing to remember is that you can't just say, "I'm not going to do it for you," or "I'm not going to do it for you.
[cpg]


[OnName num="yu"]
"...... Hey, Koromo. I have an urgent matter to discuss with you.
[cpg cn=true]


Koyi's face became serious. She listened to what I had to say.
[cpg]


[OnName num="yu"]
I need a lot of money to build a machine to restore the body to its original state. It's more than a student can afford.
[cpg cn=true]


[OnName num="yu"]
To earn that money, she's going to do something she doesn't want to ...... do.
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="sKokoro004"]
[OnName num="kokoro"]
What do you not want to do?
[cpg cn=true]


[OnName num="yu"]
She said, "I'm going to ask ...... some guy with money to do it for me."
[cpg cn=true]


Of course, it would be more than just asking for a favor. It was about something like a quid pro quo for going out with him.
[cpg]


Koyi flinched. I wonder if he was wondering if he was willing to go that far.
[cpg]


I don't think so. I am sure that she knows that there is no other way, but she is still surprised at her sister's determination.
[cpg]


[OnName num="yu"]
I want to stop it somehow, but there is no other way. But there is no other way.
[cpg cn=true]


[OnName num="yu"]
I don't want to hurt my sister's feelings.
[cpg cn=true]


I'm not going to talk to Koyi about this. The most important thing to remember is that you should not be afraid to ask for help.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Kokoro074"]
[OnName num="kokoro"]
"...... sorry. I'm sorry, I can't answer any of your questions.
[cpg cn=true]


I knew it. I knew she would react like that. I knew it too.
[cpg]


But then Koyi continued, "But maybe we can come up with a plan.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Kokoro075"]
[OnName num="kokoro"]
But I might be able to come up with a plan. If it's okay with me, I'll consult with you.
[cpg cn=true]


Those were encouraging words. It seems I'm not alone yet.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se001"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


After class, I headed home. On the way, I met Shizuku.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Shizuku141"]
[OnName num="shizuku(marina)"]
She said, "Oh, ......, are you home now too, big brother?"
[cpg cn=true]


Which is this? It's either sissy or drop-like.
[cpg]

[FACE method="shake_2" pos="4/5"]

I was thinking that, when Koyi said, "You don't have to hide it anymore. I was wondering which was which, and Koye said, "You don't have to hide it anymore.
[cpg]


I thought, "I don't have to hide it any more. Koyi already knows everything.
[cpg]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Shizuku142"]
[OnName num="shizuku(marina)"]
I was tired of being in Shizuku's tension. It's exhausting to be in Shizuku's mood.
[cpg cn=true]


I'm sure she'd be a bit angry if she were here. I'm sure she's really tired.
[cpg]


[OnName num="yu"]
But then again, how did Koyi know she was my sister?
[cpg cn=true]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Kokoro076"]
[OnName num="kokoro"]
I'm just guessing. I'm just guessing.
[cpg cn=true]


Indeed. I can't even spot the sister who is acting as a drop in the ocean.
[cpg]


But I think I can spot the opposite. ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



Before dinner, I was alone in my room thinking about it.
[cpg]


Koyi said she would think about it with me, but, however,......
[cpg]


I wonder if I can come up with any good ideas. At least I can't come up with any solution.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿雫の部屋』（夜）******************************************************

Then I flirted with my sister, who was in the form of Shizuku, until it was dinner time.
[cpg]

[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------

[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_09_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿麻莉奈の部屋』（夜）******************************************************

[FACE method="shock_5" pos="2/3"]
[VOICE f="Marina167"]
[OnName num="marina(yu)"]
...... Huh?"
[cpg cn=true]


But then the scenery changed. It was my sister's room.
[cpg]


I sort it out. If I'm in my sister's body, then it's definitely me or Shizuku in her body.
[cpg]


And my body and Shizuku's body are now flirting with each other. This is not good, I realized.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



[FACE method="shake_4" pos="2/3"]
[VOICE f="Shizuku161"]
[OnName num="shizuku"]
I can't believe it's really ...... someone else's body.
[cpg cn=true]


[OnName num="yu(marina)"]
I'm ...... sorry."
[cpg cn=true]


Shizuku talks about such things in front of her family. She seems to be very angry.
[cpg]


[OnName num="grandfather"]
What's wrong with you?　What's wrong?
[cpg cn=true]


[OnName num="yu(marina)"]
Nothing," he said. It's just a little quarrel.
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Shizuku162"]
[OnName num="shizuku"]
"Hmm. Nothing.
[cpg cn=true]


[OnName num="yu(marina)"]
I'm sorry. ......
[cpg cn=true]


She continues to apologize while pretending to be me.
[cpg]


I guess the reason why Shizuku doesn't pursue me is because she sees that I didn't initiate it.
[cpg]


Whatever it was, Mom was looking at me suspiciously.
[cpg]


If you keep changing places for too long, you will be exposed in places like this.
[cpg]


If just one drop is in a bad mood, everything can be exposed. ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I can't be too reckless with Shizuku's body. That's what I was thinking.
[cpg]


[OnName num="yu(marina)"]
You're in the ...... wrong room, Yoo. Yoo."
[cpg cn=true]


She came in and pointed it out to me. That's right.
[cpg]


I'm her now, right? I should be in my sister's room. ......
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

;//ＢＫ



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈（雫）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Next morning. I woke up in my room. This means that there is a possibility that Shizuku and my sister have switched again.
[cpg]


[window target=false]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Shizuku163"]
[OnName num="shizuku(marina)"]
'Sis, maybe it's time you got a haircut.'
[cpg cn=true]


She is saying subtle things with Shizuku's body.
[cpg]


She might be saying that to act normal, but that's not good.
[cpg]


[FACE method="bow_7" pos="2/5"]
[VOICE f="Marina209"]
[OnName num="marina(shizuku)"]
I think I'll do that. Can I go ahead and use my judgment?"
[cpg cn=true]


See, that's what I'm talking about. I'm sure she'd be in trouble.
[cpg]


I'm sure you're not happy about this conversation, because it's only going to make Mom and Dad suspicious.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku164"]
[OnName num="shizuku(marina)"]
"I take back what I said at ....... Don't do it.
[cpg cn=true]


[OnName num="mother"]
"......?"
[cpg cn=true]


Mom is obviously suspicious. It's a strange conversation, if you think about it.
[cpg]


She wanted to cut her hair with her own will, but she was stopped by her sister.
[cpg]

[FACE method="change_1" pos="2/5"]
[FACE method="change_1" pos="4/5"]

[OnName num="grandfather"]
"Uh-oh," he said, "how are the three of you doing at the school? How's the academy, all three of you?"
[cpg cn=true]


[OnName num="yu"]
"Yeah, I'm fine. I'm fine, but I've been feeling a little under the weather lately.
[cpg cn=true]


[OnName num="mother"]
Oh, really?　Do you think you have a cold or something?
[cpg cn=true]


I deceive myself appropriately. I lied about not feeling well, but it was just a convenient way to get around.
[cpg]



;//ＢＫ
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then I headed to the school as usual.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;/[BGM f="bg_d2"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の通う学園＿教室』（夕方）******************************************************



How to rescue your sister? The time is now late in the evening, after school, with no particular answer.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sKokoro005"]
[OnName num="kokoro"]
I've been thinking a lot about it since .......
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Kokoro080"]
[OnName num="kokoro"]
I think I've come up with something great. ......
[cpg cn=true]


[OnName num="yu"]
Really?　What kind of strategy?
[cpg cn=true]


Koyi says she has come up with a great idea, but she is puzzled.
[cpg]


He seems to be torn there, whether to say it or not.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Kokoro081"]
[OnName num="kokoro"]
I'll tell you after I get my thoughts in order. I'll tell you after I get my thoughts in order, then.
[cpg cn=true]


What the heck, don't waste your time ......, I think as I head home.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_03_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


I think about it as I walk alone through the city.
[cpg]


Somehow a way to keep the sister from getting hurt.
[cpg]


Koyi seems to have an idea, but I can't come up with anything.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuku165"]
[OnName num="shizuku(marina)"]
"Welcome home, Yoo. Yoo."
[cpg cn=true]


When I returned home, she was the only one there. I went back to the house and found her alone there.
[cpg]


[OnName num="yu"]
"I guess Shizuku hasn't come home yet," she said.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Shizuku166"]
[OnName num="shizuku(marina)"]
"Yes, she hasn't come home yet. I'd like to go to your room.
[cpg cn=true]


I know I've already been invited to ....... I'm not going to not take advantage of it.
[cpg]


But I have a concern. The situation is the same as the other day.
[cpg]


[OnName num="yu"]
You've been replaced by a ...... drop.
[cpg cn=true]

He looks awkward, or maybe he still looks like he wants to be with me. It can't be helped.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

We stayed alone until it was time for dinner.
[cpg]


[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈　雫
;//と変更してください
;//----------------------------------------


[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





Then night. We were each back in our own bodies.
[cpg]


We all had dinner in a relieved mood.
[cpg]

[FACE method="change_3" pos="2/3"]
And my sister looked as if she had made up her mind.
[cpg]


I know, I know. ...... I'm back in my own body.
[cpg]


I guess it's time to run out of time. Our relationship.
[cpg]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Shizuku187"]
[OnName num="shizuku"]
'What's wrong?　You both seem a little off."
[cpg cn=true]


I've been hearing this kind of thing a lot lately. I've gotten used to it.
[cpg]


But the reason I'm acting strange this time is not because we've switched.
[cpg]


Rather, it's because we haven't switched.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



And that night, my sister visited my room.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marina210"]
[OnName num="marina"]
She said, "......I thought I should tell Yuu. It would be bad to go without saying anything."
[cpg cn=true]


I spat.
[cpg]


[OnName num="yu"]
'I knew that would be ......
[cpg cn=true]


She nodded.
[cpg]


[OnName num="yu"]
I nodded, "That ...... still doesn't matter. We're lovers, aren't we?
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Marina211"]
[OnName num="marina"]
I know, but we need to get back into our bodies so we can be proper lovers.
[cpg cn=true]


That's right. That's right,......, my words are no match for your good arguments.
[cpg]


You are a much smarter person than I am.
[cpg]


I have nothing more to say. All I had to do was to send her off.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


[VOICE f="Marina213"]
[OnName num="marina"]
"Okay, I'm going to go to .......
[cpg cn=true]


[OnName num="yu"]
"Oh."
[cpg cn=true]


I think my voice was shaking. I don't feel frustrated, I don't feel like I'm losing my girlfriend.
[cpg]


It's a strange feeling. The emptiness of not being able to save my sister is probably the closest thing to it.
[cpg]


She looked like she was in a lot of pain.
[cpg]



[SE f="se019"]
;//【ＳＥ】『ドア閉まる』

[free time=1000]
[WAIT time=1000]
;//ＢＫ



I went back to my room and tried to force myself to go to sleep.
[cpg]


......There was no way I could sleep like this.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


[FACE method="shock_5" pos="2/3"]
[VOICE f="Marina214"]
[OnName num="marina(yu)"]
......What?"
[cpg cn=true]


I thought, but before my sister could execute her plan, we switched again.
[cpg]

I don't know if I should be relieved or not,...... but I decided to go back home for now.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

And just like that, the next holiday......
[cpg]

[window target=false]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



We switched several times, but it never happened that my sister entered her body during the night.
[cpg]


I can't play with someone with my body, and I can't do it with Shizuku's body either.
[cpg]

It was not in her nature to do so. So we were in the middle of putting it off.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="4/5" time=800]

[VOICE f="Kokoro082"]
[OnName num="kokoro"]
I've come up with an idea," she said, "and I want you to hear it. I'd like you to listen to me.
[cpg cn=true]


Dad, Mom, and Shizuku were out of the house. It was just me, my sister, and Koyi.
[cpg]


[OnName num="yu(marina)"]
What do you mean, you've come up with an idea? Yoo, did you ask me to do something?
[cpg cn=true]


[FACE method="bow_7" pos="2/5"]
[VOICE f="sMarina010"]
[OnName num="marina(yu)"]
"Oh, you know, to make sure that my ...... sister doesn't do anything reckless.
[cpg cn=true]


[OnName num="yu(marina)"]
I'm sure you did,......, but I don't care. I've already made up my mind, you know?
[cpg cn=true]


That said, I can still remember the look on my sister's face at the moment she left.
[cpg]


She looked so pained. I knew I couldn't let her go through that.
[cpg]


[OnName num="yu(marina)"]
So what's the idea?　What do you have in mind?
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="sKokoro006"]
[OnName num="kokoro"]
I'm not sure if that's a good idea or not. I was thinking that it would be good to do it when ...... Yuu-kun is inside Marina-san."
[cpg cn=true]


[FACE method="change_5" pos="2/5"]
For a moment, I was so confused that I didn't understand what was going on.
[cpg]


But I understand. I see, it may indeed be a good idea.
[cpg]


[OnName num="yu(marina)"]
So ...... that's what I'm talking about. You're talking about protecting my spirit at least, right?"
[cpg cn=true]


Yes, the fact remains that my sister is going to be held. But....
[cpg]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Kokoro084"]
[OnName num="kokoro"]
The actuality is that you can't get a lot of these things. The fact remains that the fact remains that Marina is going to be held by her sister.
[cpg cn=true]


The problem is my sister. The most important thing to remember is that you can't just go to the store and ask for a discount.
[cpg]


[OnName num="yu(marina)"]
I'd be grateful if you'd do that for me too,....... I'm still scared."
[cpg cn=true]


[OnName num="yu(marina)"]
But ...... would you be okay with that, Yu?　You're going to be scared.
[cpg cn=true]


[FACE method="bow_1" pos="2/5"]
[VOICE f="Marina216"]
[OnName num="marina(yu)"]
I'll do whatever it takes to protect my sister," he said. Don't worry."
[cpg cn=true]


She blushed a little.
[cpg]


[OnName num="yu(marina)"]
Thank you, Koyo. I would never have thought of that.
[cpg cn=true]


[FACE method="shake_1" pos="4/5"]
[VOICE f="Kokoro085"]
[OnName num="kokoro"]
No, I didn't. I didn't want to see Yu-kun depressed. I didn't want to see Yu-kun depressed. ......
[cpg cn=true]


This feeling, Koyi hasn't given up on me yet.
[cpg]


The most important thing to remember is that you can't just take a look at the pictures. The most important thing is to get back to your normal body first.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



And at night. We finished dinner and went to ......
[cpg]



[window target=false]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


As expected, I was summoned to my sister's room, my room.
[cpg]


;//========================================
;//●ＣＧ（ヒロインの見た目の主人公に、主人公の見た目のヒロインが迫る）ev_19
;//人物１：主人公（ヒロイン１の外見）
;//服装１：私服
;//人物２：ヒロイン１（主人公の外見）
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

She looks at me, who looks like my sister, and says.
[cpg]

[OnName num="yu"]
'Thank you, Yuu.......'
[cpg cn=true]


[VOICE f="sMarina011"]
[OnName num="marina"]
What the heck,......," she says, "I'm sorry.
[cpg cn=true]


[OnName num="yu"]
You should be scared too."
[cpg cn=true]


Saying this, she hugged me from behind.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]


[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（雫）　雫（由宇）
;//と変更してください
;//----------------------------------------

[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



When I woke up in the morning, it was Shizuku's body.
[cpg]


When I went to the dining table, my family was gathered there, so I acted like Shizuku.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuku189"]
[OnName num="shizuku(yu)"]
"Good morning," she said, "what's for breakfast today? What's for breakfast today?
[cpg cn=true]


[OnName num="mother"]
Scrambled eggs. You liked it, didn't you?
[cpg cn=true]


I don't know. I think she liked it.
[cpg]


[OnName num="yu(marina)"]
Well, it's hard to find someone who doesn't like it. ......
[cpg cn=true]


And I'm acting like me. So that means ......
[cpg]

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Marina233"]
[OnName num="marina(shizuku)"]
'I love scrambled eggs!　Oh, but what about people with allergies and such?"
[cpg cn=true]

[FACE method="shake_7" pos="4/5"]

A drop is always a drop, no matter how long it's been there. I mean, it was a topic that drops like to talk about, so I wanted to warn you about it.
[cpg]



[OnName num="yu(marina)"]
Sis, you're so high-strung. I get like this sometimes lately."
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina234"]
[OnName num="marina(shizuku)"]
I'm sorry, I'm sorry, I'm sorry. It's nothing.
[cpg cn=true]


I was used to this. Mom might finally talk to Dad about it.
[cpg]


I need to get the money as soon as possible. But I'm in a drop body right now. ......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[OnName num="yu(marina)"]
Mom is getting suspicious. She said she talked to grandpa the other day."
[cpg cn=true]


Then the three of us get together. It's a strategy meeting.
[cpg]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina235"]
[OnName num="marina(shizuku)"]
"Eh, that was ...... just barely safe, if it had been your father, you would have been out.
[cpg cn=true]


[OnName num="yu(marina)"]
That's what I meant. That's what I mean. You have to be more careful than ever.
[cpg cn=true]


The first thing to do is to make sure that you are not going to be the only one who is going to be in trouble.
[cpg]


[OnName num="yu(marina)"]
So, Yu should probably tell him, right?　About that."
[cpg cn=true]


I'm sure you're right, she didn't want to let you know about it. I'm sure that you need to let Shizuku know about it.
[cpg]


If there's an emergency and she switches places, it would be a surprise to her.
[cpg]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Shizuku190"]
[OnName num="shizuku(yu)"]
Why don't you tell her?　It was her idea.
[cpg cn=true]


[OnName num="yu(marina)"]
...... I see. Well, let me tell you something.
[cpg cn=true]


[OnName num="yu(marina)"]
I, Marina Tokiwa, have been trying to make money by deceiving ...... men.
[cpg cn=true]


The woman flinched more than she should have.
[cpg]


[FACE method="shock_5" pos="2/5"]
[VOICE f="Marina236"]
[OnName num="marina(shizuku)"]
What?　Is that serious ......?"
[cpg cn=true]


[OnName num="yu(marina)"]
I'm serious. No, I was serious. But Yoo came up with a different plan.
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku191"]
[OnName num="shizuku(yu)"]
"It was Koyi who came up with that idea, not me. It was Koye who came up with the idea, not me.
[cpg cn=true]


Shizuku was still confused. I'll have to explain it to her.
[cpg]


[OnName num="yu(marina)"]
Yes, you did. ...... So I decided to have Yoo do it when she was in my body, not me."
[cpg cn=true]


Shizuku becomes even more confused. Well, it's usually a bit confusing when you hear about it, isn't it?
[cpg]


[OnName num="yu(marina)"]
She asked, "Are you okay?　Do you understand?"
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[VOICE f="Marina237"]
[OnName num="marina(shizuku)"]
Maybe it's subtle. My sister's body, I mean my body now, not my sister's ......, brother?"
[cpg cn=true]


[OnName num="yu(marina)"]
Yeah, that kind of thing.
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="sShizuku006"]
[OnName num="shizuku(yu)"]
The more I think about it, the more I realize it's a great idea. I'm talking about the mind is my burden.
[cpg cn=true]

[FACE method="bow_7" pos="2/5"]
I see. ......?　and nodded his head with a question mark. You don't understand.
[cpg]


[OnName num="yu(marina)"]
I don't think you understand. You'll understand later.
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



After the strategy meeting, we were in the middle of lunch. The incident occurred.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[FACE method="shock_5" pos="2/3"]
[VOICE f="sShizuku007"]
[OnName num="shizuku"]
Oh, my God!
[cpg cn=true]


[OnName num="grandfather"]
Are you okay?　What's wrong, Shizuku?
[cpg cn=true]


We switched while we were eating. While I was chewing something in her body, she was back in her original body after finishing her meal.
[cpg]


This kind of thing even happens. Someday, I'm going to get blamed for it.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Shizuku194"]
[OnName num="shizuku"]
I'm fine. ...... don't worry about it.
[cpg cn=true]


[OnName num="yu(marina)"]
What's wrong, Shizuku? Are you okay?"
[cpg cn=true]


And not the sister who suddenly switched with me,......, but the sister who was originally in my body and showed her concern.
[cpg]


It's unnatural if you don't react like this. Mom is right there in front of me too.
[cpg]


[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="4/5" time=800]
[VOICE f="Marina238"]
[OnName num="marina(yu)"]
She's always been restless, she probably ate too much in a hurry.
[cpg cn=true]


[OnName num="grandfather"]
I see. Yes, that's right.
[cpg cn=true]


And Grandpa was also on the same page. But then...
[cpg]


[OnName num="mother"]
"......, are you hiding something from me?"
[cpg cn=true]


[OnName num="yu(marina)"]
Hiding what?　Test results?
[cpg cn=true]


My sister tried to dodge. Mom didn't pursue it any further.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



We were running out of time. I was her sister now, just in time.
[cpg]


It was now or never. So I decided to go out.
[cpg]


;//移植のためシーンをカットしています


;//※ルート分岐。ここまでの女性化ポイントによって決まる


[if exp={getFlagValue("pi_fi") == 1 }]
[jump target=*tag_01]
[endif]

[if exp={getFlagValue("pi_fi") == 2 }]
[jump target=*tag_01]
[endif]


[jump storage="ep006.ks" target="*root01_1"]

*tag_01|I want to spend time in my sister's body.
[jump storage="ep007.ks" target="*tag_01"]
