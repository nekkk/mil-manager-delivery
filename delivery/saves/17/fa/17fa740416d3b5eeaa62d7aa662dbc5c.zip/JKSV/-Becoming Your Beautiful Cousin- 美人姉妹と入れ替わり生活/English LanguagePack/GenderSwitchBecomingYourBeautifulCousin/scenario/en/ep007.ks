
*start


;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------


;//==============================
;//女性化ポイントが１以上の場合
*tag_01|I want to spend time with my sister's body


*root01_2|I want to spend time with my sister's body

;#################################################
*Ep007|I want to spend time with my sister's body
;#################################################

[SCENE id=7]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



She tried to follow me halfway, but I stopped her.
[cpg]


I wanted to be alone as soon as possible.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marina304"]
[OnName num="marina(yu)"]
Excuse me.
[cpg cn=true]


[OnName num="man"]
What's ......?"
[cpg cn=true]



;//ＢＫ

I called out to someone who looked like he had a lot of money.
[cpg]

Everything went smoothly from there.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


After that, I met him many times.
[cpg]

I would skip lectures at the university and meet up with him during the day.
[cpg]

I was relieved when he promised to help me raise the money.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[OnName num="yu(marina)"]
I asked him, "Are you all right?　Are you tired, Yu......?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Marina334"]
[OnName num="marina(yu)"]
I'm not tired. I'm fine.
[cpg cn=true]


I'm not tired.
[cpg]


If it happens, it's like sis and drops switch places or something. I'm still in my sister's body.
[cpg]



[OnName num="yu(marina)"]
If it's okay with you, it's fine. ......
[cpg cn=true]


[OnName num="yu(marina)"]
But you've been pushing yourself too hard lately, haven't you?　Are you sure you're okay with it?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Marina335"]
[OnName num="marina(yu)"]
I'm fine. You're so skeptical.
[cpg cn=true]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

The truth was that he was not fine. I was becoming more and more familiar with the female body.
[cpg]


And they are being taken in by the feminine spirit.
[cpg]

I was afraid I might end up like this. I was okay with that.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[FADEOUTBGM]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



Time passed. And on the day the machine was fixed, ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[OnName num="grandfather"]
I told her, "Listen, you've got one shot at the real thing. Visualize your body strongly.
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[VOICE f="Shizuku199"]
[OnName num="shizuku"]
I know, I know. I know, I'll be fine.
[cpg cn=true]


Shizuku would be fine. But the problem is me and my sister.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ＢＫ



Each of the three of us will be placed inside the machine.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』



Once we're in place, there's no going back. And yet, I wanted to.
[cpg]


I wanted to spend time in my sister's body. ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Shizuku200"]
[OnName num="shizuku"]
I wonder how it all came to this.
[cpg cn=true]


Shizuku is puzzled. Grandpa was puzzled too, but now it was just the three of us gathered together.
[cpg]

[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[OnName num="yu(marina)"]
'What are you going to do, Yu ......?　Are you going to live like this forever!"
[cpg cn=true]


I was fine with that. I thought it was fine, but my sister didn't seem to think so.
[cpg]


No, I'm sure deep down she thinks so too.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[VOICE f="Marina337"]
[OnName num="marina(yu)"]
"...... didn't you think anything of it?　Living in my body.
[cpg cn=true]


[OnName num="yu(marina)"]
What do you mean? It was an inconvenience.
[cpg cn=true]


Really?　It seemed to me that she was enjoying being a man, too.
[cpg]


[OnName num="yu(marina)"]
"Hey, put that back on!　I can't go on like this. I, I, I..."
[cpg cn=true]


I decided to push her back. I mean,
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Marina338"]
[OnName num="marina(yu)"]
"You seemed to be having fun when you were a guy. I think you're going to make it."
[cpg cn=true]


[OnName num="yu(marina)"]
"......What's that?"
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



My argument was this. I was not a fan of the idea.
[cpg]


But I suggested that we try living like this for a while.
[cpg]


;//ＢＫ

;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

More days passed. I didn't graduate from college as her sister.
[cpg]


That's right, because time is missing in the first place.
[cpg]


From my point of view, she was older than me, so she didn't have enough time to study.
[cpg]


On the other hand, she was living her college life as me without any discomfort.
[cpg]


[OnName num="yu(marina)"]
;//「……姉さんとするのも、飽きてきたんだよな。最近」
I was getting tired of being with my sister. Lately.
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Marina355"]
[OnName num="marina(yu)"]
I think so, too. I feel the same way."
[cpg cn=true]


Me and my sister,......, no, Yoo and I have come to not change our tone of voice even when we are alone.
[cpg]


I, for one, naturally adopt a woman's tone even when I am alone with her.
[cpg]


What about Yoo? I think she is already planning to live her life as a man.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



And then more time passed and ...... Yoo made another girlfriend and brought her home the other day.
[cpg]


I will treat her normally as my cousin. I don't feel any different. I am me and I have a boyfriend.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[VOICE f="Shizuku201"]
[OnName num="shizuku"]
I wonder if ...... this was the right thing to do."
[cpg cn=true]


[OnName num="yu(marina)"]
What?"
[cpg cn=true]


Shizuku shakes her head when asked. The only one who had not changed at all was the one who looked the most complicated.
[cpg]


[OnName num="yu(marina)"]
I'm sure you've heard me say some strange things.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[VOICE f="Marina356"]
[OnName num="marina(yu)"]
I know. But I'm sure it's for the best.
[cpg cn=true]


[OnName num="yu(marina)"]
What's wrong with you too, ......?
[cpg cn=true]


What the heck, Yoo doesn't feel any more uncomfortable in her own body than I do.
[cpg]


I'm glad this is the case. I'm sure that's probably it.
[cpg]

[SCENE id=14]

[jump storage="epend.ks" target="*start"]
;//ＥＮＤ：ヒロイン１ルート２



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

