
*start


;#################################################
*Ep002|Strategy meeting
;#################################################

[SCENE id=2]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************



Early morning. I woke up in my room.
[cpg]


Good, I'm not positive enough to think I'm back to normal .......
[cpg]



[SE f="se019"]
;//【ＳＥ】『ドア開く』

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=500]

[VOICE f="Marina023"]
[OnName num="marina"]
Are you awake?　Yu...... no, maybe a drop?
[cpg cn=true]


[OnName num="yu"]
"I'm awake,....... I see you haven't been replaced either."
[cpg cn=true]


So a drop should be a drop too. I want to have a strategy meeting while we are at it.
[cpg]

[SE f="se019"]
;//【ＳＥ】『ドア開閉』

[free time=500]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]
[WAIT time=1000]

The first thing you need to do is to make sure that you have a good idea of what you want to do.
[cpg]



[FACE method="shake_7" pos="4/5"]
[VOICE f="Shizuku029"]
[OnName num="shizuku"]
She said, "Well, you're my brother and I'm your sister, right? Which one is it?"
[cpg cn=true]


[OnName num="yu"]
Don't worry, I'm the one.
[cpg cn=true]


It's complicated. I'm back to my normal body, but it's hard enough just to confirm it.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[FACE method="bow_1" pos="2/5"]
[VOICE f="Marina024"]
[OnName num="marina"]
So, we'll call each other if we get lost.
[cpg cn=true]


[OnName num="yu"]
What do you mean, "If you get lost," ......?
[cpg cn=true]


She shook her head. She shook her head, as if she didn't understand.
[cpg]


I thought for a moment. I thought for a moment, and then it hit me.
[cpg]


[OnName num="yu"]
What if we switch places in the middle of the road?
[cpg cn=true]


[FACE method="bow_7" pos="4/5"]
[VOICE f="Shizuku030"]
[OnName num="shizuku"]
I see......... But what about the school?　What if I can't even attend classes?
[cpg cn=true]


Yes, there is that problem, too. Especially the youngest drops will not be able to keep up with the classes that my sister and I are taking.
[cpg]


[OnName num="yu"]
You should go to the infirmary or somewhere else to rest then. Don't worry, we'll find a way to get back soon.
[cpg cn=true]


There is no basis for this. I have to say that or else I wouldn't be able to do it.
[cpg]


[SE f="se001"]
;//【ＳＥ】『歩く』

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の通う学園＿教室』（朝）******************************************************



[FACE method="bow_7" pos="2/3"]
[VOICE f="Kokoro018"]
[OnName num="kokoro"]
Good morning, Yu-kun. ...... What's wrong?　You look pale."
[cpg cn=true]


[OnName num="yu"]
Yeah, well, ...... I've been having a bit of a hard time."
[cpg cn=true]


I mean, I should especially nail Koyo.
[cpg]


[OnName num="yu"]
...... if I get sick or go to the infirmary, will you not worry too much about me?"
[cpg cn=true]


It's a bit of a stretch to get her to agree to that,
[cpg]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Kokoro019"]
[OnName num="kokoro"]
"Uh, yeah, but why? But why?"
[cpg cn=true]


Koyi nodded her head for the time being.
[cpg]


[OnName num="yu"]
Okay, then.
[cpg cn=true]


[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------


[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の通う学園＿教室』（朝）******************************************************




[VOICE f="Marina025"]
[OnName num="marina(yu)"]
Leave me alone ......."
[cpg cn=true]


Instantly, the scenery changed. Again. There was no one in front of me, so I was talking to myself.
[cpg]

[FACE method="shock_5" pos="2/3"]
Oh no. I was just now talking to Koyi.
[cpg]


If I switched with my sister, she might be able to fool me, but if it was Shizuku, I might be exposed.
[cpg]


The feeling of this view, everyone around me is in plain clothes. Shizuku's school is in uniform, which means I'm switching places with her sister right now.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

I continued to attend the lectures, which I didn't understand.
[cpg]


I knew that my sister went to a good university and her lectures sounded like incantations.
[cpg]


;//========================================
;//●ＣＧ（トイレで一人落ち込むヒロイン＝主人公）ev_04
;//人物１：主人公（ヒロイン１の外見）
;//服装１：私服
;//場所　：学園＿女子トイレ
;//時間　：昼
;//========================================


;**【ＣＧ】 ev_04_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMarina001"]
[OnName num="marina(yu)"]
"...... huh."
[cpg cn=true]


I sighed alone in the bathroom.
[cpg]

The first thing to do is to make sure that you have a good idea of what you are getting into.
[cpg]

And I guess there are still more ordeals that await me in the future. ......
[cpg]


;**【ＣＧ】 ev_04_a ***********************
[CG id=3 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sMarina002"]
[OnName num="marina(yu)"]
I still can't get used to my unreliable underwear either. ......
[cpg cn=true]


I shook my head, thinking, "No, no, I can't talk to myself like this.
[cpg]


;//移植のためシーンをカットしています

[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈　雫
;//と変更してください
;//----------------------------------------


;//ＢＫ
[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

And the next moment. I was in the men's restroom.
[cpg]

Or rather, I am me.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の通う学園＿教室』（昼）******************************************************



It seems to be lunch break now. I ask Koyi what's going on.
[cpg]

[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="yu"]
She says, "...... You know, Koyoi. Wasn't there something wrong with me?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Kokoro020"]
[OnName num="kokoro"]
What?　Why ......?　I was acting normal.
[cpg cn=true]


I wasn't acting strange. So, there was a big possibility that she and my sister had switched.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se001"]
;//【ＳＥ】『歩く』



[OnName num="yu"]
"Well, it's hard to see my sister at ......."
[cpg cn=true]


I headed home. Naturally, I would see my sister when I returned home.
[cpg]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d2"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[OnName num="yu"]
"I'm back at .......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sMarina003"]
[OnName num="marina"]
"......, welcome home."
[cpg cn=true]


It's easy to understand. She's my sister now.
[cpg]


She's a no-brainer. But I've lost track of the law of switching.
[cpg]


So far, it's only been one shift for each of us, but it's possible to switch just between the two of us.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』

[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（雫）　麻莉奈　雫（由宇）
;//と変更してください
;//----------------------------------------



And at night. We eat dinner like it's nothing, but I'm keeping a big secret from my mom.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Shizuku032"]
[OnName num="shizuku(yu)"]
She says, "......Oh, I'd like another one."
[cpg cn=true]


I'm the one who's acting like a drop of water. And I'm next to him, acting somewhat like Shizuku.
[cpg]


This time, the only thing that switched was me and Shizuku.
[cpg]


It would be a big problem if we switched while we were eating. I'm afraid I'll choke on something.
[cpg]


[FACE method="shake_7" pos="2/3"]

[VOICE f="Shizuku933"]
[OnName num="shizuku(yu)"]
I can't even ride a bike.
[cpg cn=true]



[OnName num="mother"]
What?　What are you talking about?
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Shizuku033"]
[OnName num="shizuku(yu)"]
Nothing, nothing.
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_10_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の家＿雫の部屋』（夜）******************************************************

Then he went back to Shizuku's room, but ......
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Shizuku034"]
[OnName num="shizuku(yu)"]
I went back to Shizuku's room. I have my own cell phone.
[cpg cn=true]


I don't have the hobby of playing with drops' phones without permission. That said, if I did, the room would be devoid of any entertainment.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sShizuku001"]
[OnName num="shizuku(yu)"]
I'm going to read some shoujo manga.
[cpg cn=true]



;//移植のためシーンをカットしています


I thought to myself as I was about to fall asleep. I wondered what would happen to me if I continued to be a woman.
[cpg]


I asked myself what I wanted to become.
[cpg]



;//■選択肢
[switch]
[case "Being a woman is exhausting."]
	[swap]
	[jump target="*select10_1"]
[case "A woman's life is not so bad"]
	[swap]
	[jump target="*select10_2"]
[endswitch]

1. Being a woman is tiring.
2, Living as a woman is not so bad.



;//==============================
;//１、女でいることは疲れる
*select10_1|Strategy meeting




Being a woman is tiring. You have to deal with a lot of unnecessary hassles and ......
[cpg]


It can break up family ties. If I could, I would go back to my original body.
[cpg]


[jump target="*select10_3"]
;//==============================
;//２、女の暮らしも悪くない
*select10_2|Strategy meeting
[stflag pi_fi = 1]

;//女性化ポイント増加　+1



I was beginning to think that being a woman was not so bad.
[cpg]


At least I'm experiencing things that normal men can't.
[cpg]


Even if I eventually go back to the way I was, I thought that the time I have now might be valuable.
[cpg]



;//==============================
*select10_3|Strategy meeting




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Shizuku051"]
[OnName num="shizuku(yu)"]
Good morning, Shizuku. ......
[cpg cn=true]


When I greeted him as a test, he replied, "Good morning," which was still a no-nonsense response.
[cpg]

It's not good to continue living a life where I have to worry about this kind of thing.
[cpg]

So I decided to go to my grandfather's place.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_08_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



Grandpa had been struggling with the machine since this morning.
[cpg]


[OnName num="grandfather"]
He said, "We don't have the money to make a machine that will fix the ...... original body."
[cpg cn=true]


[OnName num="yu(shizuku)"]
Is that so,......?"
[cpg cn=true]


[FACE method="shake_7" pos="2/5"]
[FACE method="change_7" pos="4/5"]
[VOICE f="Marina046"]
[OnName num="marina"]
I can't afford it. I don't want to throw away my school life.
[cpg cn=true]


[OnName num="grandfather"]
I'm in trouble, too.
[cpg cn=true]


Grandpa was really at a loss. When we asked him how much it was, he said that it was really too much for us to afford.
[cpg]


I might be able to get by by asking my father, but I would have to tell him everything in order to get him to do it.
[cpg]


If we did, we would not be able to go back to the way we were before. He might use me as a guinea pig.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[SE f="se001"]
;//【ＳＥ】『歩く』



[VOICE f="Kokoro021"]
[OnName num="kokoro"]
"Have you changed your mood a little, Yu-kun?
[cpg cn=true]


[OnName num="yu(shizuku)"]
I haven't changed at all. I'm totally normal.
[cpg cn=true]


The first thing you need to do is to make sure that you have a good understanding of what is going on in your life.
[cpg]


And I'm headed to the school of drops: ...... It's not complicated anymore.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン２の通う学園＿廊下』（朝）******************************************************




And there was also some trouble at the school where we arrived.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_5"  pos="2/3" time=800]


[OnName num="female_student_A"]
You were very active in gymnastics just now, weren't you? You were very active in gymnastics just now.
[cpg cn=true]


[OnName num="female_student_B"]
Yes, yes, you've become a bit more manly ......?　Maybe.
[cpg cn=true]


I became a woman, but I still moved my body as if I were a man, and I was very active in physical education.
[cpg]


Instead, he seems to have moved his body beyond its limits, and his whole body is creaking.
[cpg]


A girl's muscle strength is weaker than you think. ......
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Shizuku052"]
[OnName num="shizuku(yu)"]
I'm sorry ...... if you could leave me alone for a minute.
[cpg cn=true]


I'll have sore muscles tomorrow. I'm sorry if you're going to be in charge of the drops.
[cpg]



[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇（麻莉奈）　麻莉奈（由宇）　雫
;//と変更してください
;//----------------------------------------




[window target=false]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="boya1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="boya1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の通う学園＿教室』（昼）******************************************************



[VOICE f="Marina047"]
[OnName num="marina(yu)"]
Yikes!"
[cpg cn=true]


And it's your sister, or rather me, who screams the loudest during college lectures.
[cpg]


We switched in class. I don't like this kind of thing, I was just a little slumbering ......
[cpg]


And the physical sluggishness that was present in gymnastics earlier has been removed. I am also perplexed by this.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=1]
[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



Ah, I really can't do it anymore. I was on my way home thinking that.
[cpg]


[OnName num="yu(marina)"]
"Oh, sis. Are you home now?"
[cpg cn=true]


[FACE method="shock_5" pos="2/5"]
[VOICE f="Marina048"]
[OnName num="marina(yu)"]
"Yeah?　Yeah, no, yeah. ......
[cpg cn=true]


There was Koyi and I. I was acting so perfectly like me that I must be her inside.
[cpg]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Kokoro022"]
[OnName num="kokoro"]
What's wrong, Marina? You don't look well.
[cpg cn=true]

[FACE method="change_7" pos="2/5"]

How should I respond? ...... I might try to look a little grumpy.
[cpg]


[OnName num="yu(marina)"]
I'll get the medicine chest out when I get home. Shall I take out your medicine chest when I get back?"
[cpg cn=true]


My sister followed up. She was signaling that I should act like I wasn't feeling well.
[cpg]


[FACE method="bow_2" pos="2/5"]
[VOICE f="Marina049"]
[OnName num="marina(yu)"]
Yeah, I'm kind of in a ...... pickle," she said.
[cpg cn=true]


It's a gay tone in normal speech, but in my sister's voice, it fits perfectly.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]

And then the dinner table as usual. Dad and Grandpa were there today, but ......
[cpg]


With Grandpa's help, I was able to fool my father.
[cpg]


But it was only a deception. It was not a fundamental solution.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[OnName num="yu(marina)"]
"Hey, your room is not here."
[cpg cn=true]



Oh, I see. I was now the older sister, right? I thought, and tried to turn back,
[cpg]


[OnName num="yu(marina)"]
"......Well, wait a minute. I know you have something you want to tell me."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina050"]
[OnName num="marina(yu)"]
I don't have anything to say. Unless you have something to say to me.
[cpg cn=true]


[OnName num="yu(marina)"]
I know. I'm sorry, I didn't mean it in a roundabout way.
[cpg cn=true]


The way I look, the way I sound, the way I apologize, it's definitely my sister's. It's weird. It's creepy.
[cpg]


[OnName num="yu(marina)"]
I'm sorry," she said. "Yoo doesn't think anything of it," I said, "after switching so many times.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sMarina004"]
[OnName num="marina(yu)"]
What are you talking about?"
[cpg cn=true]


[OnName num="yu(marina)"]
"...... I'm thinking. I feel weird in your body.
[cpg cn=true]


I thought it was a mutual thing, and then my sister came up to me in my form.
[cpg]


[OnName num="yu(marina)"]
I've been hiding it for a long time, but ...... I'm looking at you that way.
[cpg cn=true]


That's the way I look at you.　You mean she was looking at you with the eyes of a lover?
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Marina052"]
[OnName num="marina(yu)"]
I said, "Don't do that. You're kidding, right, sis?
[cpg cn=true]


[OnName num="yu(marina)"]
"I know. I wish it was a joke.
[cpg cn=true]


The mood is getting strange. And I'm right in front of her. My head is spinning.
[cpg]


[OnName num="yu(marina)"]
I'm sorry ...... for suddenly saying such a thing, but there's nothing I can do about it.
[cpg cn=true]


I couldn't let it go and I pushed her away. I couldn't leave her alone, so I pushed her down.
[cpg]

[SE f=se029]
;//【ＳＥ】『衣擦れ』

;//========================================
;//●ＣＧ（覆いかぶさってキスする主人公）ev_06
;//人物１：主人公（ヒロイン１の外見）
;//服装１：私服
;//人物２：ヒロイン１（主人公の外見）
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]

[OnName num="yu(marina)"]
......"
[cpg cn=true]

The first thing to do is to make sure that you have a good time with your friends and family.
[cpg]


[VOICE f="sMarina005"]
[OnName num="marina(yu)"]
......
[cpg cn=true]

How can we not do anything when we have come this far? What do you think?
[cpg]

While I was wondering, she looked like she was waiting for me.
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_pi"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


My sister's old story began. It was a story about the past.
[cpg]


[OnName num="yu(marina)"]
She said, "Once upon a time, you came home holding hands with Koyi-chan. When I saw that, I got impatient.
[cpg cn=true]


[OnName num="yu(marina)"]
I thought my Yu would be taken away from me. That's when I realized I was in love with you.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Marina068"]
[OnName num="marina(yu)"]
I'm in love with you, that's an exaggeration. And apart from Koyi, there is ......
[cpg cn=true]


[OnName num="yu(marina)"]
I'm not exaggerating. I really like you.
[cpg cn=true]


Even if you say something like this out of the blue. As for me, I'm at a loss for reaction.
[cpg]


I think it's probably not a good idea to insist that we still want to be a normal family.
[cpg]


She really seems to be thinking about me.
[cpg]


[OnName num="yu(marina)"]
I wondered what was wrong with me. Then I started acting cold toward you, too.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Marina069"]
[OnName num="marina(yu)"]
I didn't realize that. To hide the fact that you like me. ......?
[cpg cn=true]


[OnName num="yu(marina)"]
I was cold to you more than I should have been. I think I was cold to you more than I should have been. I'm sorry.
[cpg cn=true]


I'm sorry," she apologizes. I don't like it when people apologize, or ...... don't like it when people apologize.
[cpg]


[OnName num="yu(marina)"]
I don't know what I should do. What am I going to do now that Yu has found out I'm a pervert like this? ......
[cpg cn=true]


You look serious. I don't think it's something to think about that much.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Marina070"]
[OnName num="marina(yu)"]
I'm going to do what I want to do. I'll do what I want, and I'll love who I want.
[cpg cn=true]


[OnName num="yu(marina)"]
......Yes, you're right.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Marina071"]
[OnName num="marina(yu)"]
But that's normal, isn't it?　It doesn't matter if they're family or not.
[cpg cn=true]


If you love someone else, you'll probably dump them. If not, we love each other.
[cpg]


We may not get married, but ...... that's fine.
[cpg]


I think she got that part of it from my sister.
[cpg]


[OnName num="yu(marina)"]
She said, "......That's right. I'm sorry, that was a weird thing to say.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Marina072"]
[OnName num="marina(yu)"]
I'm sorry, I didn't mean to sound weird. I'm sorry I said something weird.
[cpg cn=true]


I tried to make him forget about today, but it had the opposite effect.
[cpg]


[OnName num="yu(marina)"]
I was trying to get him to forget about today, but it was having the opposite effect.
[cpg cn=true]



;//========================================
;//●ＣＧ（ヒロイン１（主人公の外見）に横から胸を揉まれつつまんこを愛撫される主人公（ヒロイン１の外見）。ベッドに二人座っている）ev_07
;//人物１：主人公（ヒロイン１の外見）
;//服装１：私服
;//人物２：ヒロイン１（主人公の外見）
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="yu(marina)"]
Don't move."
[cpg cn=true]


She sounded very serious as she said this.
[cpg]

But it was my voice, so it sounded strange.
[cpg]



[VOICE f="sMarina006"]
[OnName num="marina(yu)"]
“……”
[cpg cn=true]


But I think that human beings may not be as much about their faces as we might think.
[cpg]

Or does she like her face?　I don't know.
[cpg]


;//移植のためシーンをカットしています

;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



[OnName num="yu(marina)"]
Well, then. We'll see each other tomorrow, and we'll go on as before.
[cpg cn=true]


I left her there and went back to my sister's room.
[cpg]


[SE f="se038"]
;//【ＳＥ】『機械音　キュイイイイン』
;//----------------------------------------
;//ここから各キャラの名前欄を
;//由宇　麻莉奈（雫）　雫（麻莉奈）
;//と変更してください
;//----------------------------------------


[jump storage="ep003.ks" target="*start"]


;////////////////////////////////////////////////////////////////////////

