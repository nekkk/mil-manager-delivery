*start

;###################################################################
*Ep016|A Strange Condition, the Changing, and the Unchanging
;###################################################################
;//４、アーシャ

[SCENE id=13]


[window target=false]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out" pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out" pos="3/5"]


[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]

[window target=true]


I found myself thinking of Asha.
[cpg]


She was the first person to help me, the first person to recognize my ability to transform.
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy489"]
[OnName num="dorothy"]
Say something. Why are you silent?"
[cpg cn=true]


[OnName num="renzi"]
“It’s just...”
[cpg cn=true]


I realized how I felt. I like Asha.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



Then it became a little difficult to live a peaceful life.
[cpg]


Asha is a cook, which means I see her whenever I go to the mess hall.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha233"]
[OnName num="asha"]
What can I get for you?"
[cpg cn=true]


[OnName num="renzi"]
“Oh, uh..., hmm.”
[cpg cn=true]


I could no longer look straight at Asha.
[cpg]


I've heard that Asha is also easy to fall in love with, but ...... that's different.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





I wanted to do something to Asha.
[cpg]


I wanted to disguise myself as something familiar to her so I could eavesdrop on what she thought of me.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





I sneak into Asha's room. I have the ability to shapeshift, so if I hear Asha's footsteps, I can turn into something else.
[cpg]


I look around the room, wondering what I should turn into...
[cpg]



[SE f=se009]
;//【ＳＥ】『歩く』



And then I heard someone's footsteps. And I also hear a soliloquy.
[cpg]


[VOICE f="Arsha234"]
[OnName num="asha"]
'Whew, that was some good hot water today.
[cpg cn=true]


Asha just got out of the bath and is trying to get back in here.
[cpg]


I panicked and turned into what was there. Namely ......
[cpg]


[SE f=se023]
;//【ＳＥ】『ドア閉まる・開く』



[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sArsha019"]
[OnName num="asha"]
I'm at ....... What's that?　Two identical books?"
[cpg cn=true]

;**【ＣＧ】ci_23_0 ***********************
;//カットイン
[CUTIN f="ci_23_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

Have I done something stupid to turn into a book? It is easy to be found out if you have two identical ones.
[cpg]


[CUTIN f="ci_23_0.ui" show={false} method="feadout"]
[WAIT time=1500]

[FACE method="change_7"  pos="2/3"]
[VOICE f="sArsha020"]
[OnName num="asha"]
Did I buy two books by mistake?"
[cpg cn=true]

But Asha doesn’t doubt me any further.
[cpg]


Two copies of the same book seems to be a thing in other worlds ......
[cpg]


[SE f=se012]
;//【ＳＥ】『衣擦れ』
[FO pos="2/3" time=1000]


Then Asha laid down and fell asleep right away.
[cpg]


I made sure she was falling asleep, then she transformed back and left the room.
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I went back to my room and was thinking about what I would do to hook up with Asha.
[cpg]


She is a pretty easy person to fall in love with. I guess if I were to go out with her, that would include .......
[cpg]


[window target=false]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Arsha261"]
[OnName num="asha"]
'Good morning. What can I get you?"
[cpg cn=true]


[OnName num="renzi"]
He said, "Oh, good morning. Uh, yeah. ......"
[cpg cn=true]


Asha is smiling like nothing happened. I think it must be hard for her.
[cpg]


[FO pos="2/3" time=1000]


We sit down and I'm having breakfast.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy490"]
[OnName num="dorothy"]
Good morning, Renji."
[cpg cn=true]


Dorothy sat down next to me. I know she adores me too.
[cpg]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Dorothy491"]
[OnName num="dorothy"]
“So what are you up to next? If you can capture Clara than that means you’re gonna do something even more amazing right?”
[cpg cn=true]


They were expecting me to do so, but I had something completely different in mind.
[cpg]


How to get along with Asha. That was all.
[cpg]


[OnName num="renzi"]
“Yeah, well... I'm thinking about a lot of things.”
[cpg cn=true]


Still fooling around, I'll keep talking about that.
[cpg]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Dorothy492"]
[OnName num="dorothy"]
'Hmmm?　Whatever it is, I look forward to it."
[cpg cn=true]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


We go about our days casually. I would call out to Asha at a moment's notice.
[cpg]


[OnName num="renzi"]
'Asha, where are you going?
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha262"]
[OnName num="asha"]
What?　I'm taking a break, so I'm going back to my room."
[cpg cn=true]


[OnName num="renzi"]
Can I follow you on the way?"
[cpg cn=true]


It was a step of courage for me, disguised as a casual remark.
[cpg]



[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha263"]
[OnName num="asha"]
"Sure... If you want, you can come to my room.”
[cpg cn=true]


Asha responded as if she didn't mind. I decided to go along with it.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FACE method="feadin_up" pos="4/7"]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Arsha264"]
[OnName num="asha"]
Renji is amazing, isn't he? I'm only good at cooking.
[cpg cn=true]


[OnName num="renzi"]
Cooking is the greatest thing of all. No matter how strong or great you are, you can't live without Asha's cooking.
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha265"]
[OnName num="asha"]
Heh. I'm glad to hear you say that.
[cpg cn=true]


Asha looked a little embarrassed.
[cpg]


[FACE method="change_6"  pos="2/3"]
[VOICE f="Arsha266"]
[OnName num="asha"]
“Hey, Renji... I need to talk to you about something.”
[cpg cn=true]


[OnName num="renzi"]
What is it?"　Anything."
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Arsha267"]
[OnName num="asha"]
I'm telling you this because I have a certain amount of trust in Renji, and you should know that. Don't tell anyone."
[cpg cn=true]


Asha prefaced the conversation by telling me this.
[cpg]


[FACE method="change_6"  pos="2/3"]
[VOICE f="sArsha021"]
[OnName num="asha"]
I fall in love easily. You already know that, I'm a beast of a rabbit tribe, you know.
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Arsha269"]
[OnName num="asha"]
“It has been particularly bad lately... I can't even think about anything at work."
[cpg cn=true]


Asha was embarrassed, but she said it in an earnest tone.
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="sArsha022"]
[OnName num="asha"]
So, Renji. Will you turn into something and calm my feelings?"
[cpg cn=true]


[OnName num="renzi"]
That's what you said about me ......."
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha271"]
[OnName num="asha"]
I'm sorry. It sounds like a confession, but it's not."
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha272"]
[OnName num="asha"]
“I think you’re cool Renji. You captured Clara and I knew I could count on you from the start.”
[cpg cn=true]


[FACE method="change_6"  pos="2/3"]
[VOICE f="sArsha023"]
[OnName num="asha"]
“But... There’s nothing more than that. I just want to change this condition that I have to live with.”
[cpg cn=true]


You have to read her mind. It doesn't look like we'll be in love anytime soon, but it's still a step in the right direction.
[cpg]


I don't think I would have asked her if I didn't want to. I was ready.
[cpg]


[OnName num="renzi"]
How long is the break?
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha274"]
[OnName num="asha"]
One hour to go. I don't have much time.
[cpg cn=true]


[OnName num="renzi"]
I understand. I'll take care of it."
[cpg cn=true]


[FO pos="2/3" time=1000]

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
[FACE method="out" pos="4/7"]


[STOPBGM]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[BG f="white.ui" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



;//========================================
;//●ＣＧ（座って、催眠状態にあるヒロイン。うつろな表情）ev_52
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公はインキュバスに化けています
;//=======================================

;//*Scene050


[BGM f="10"]
;**【ＣＧ】 ev_52_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1500]




I was disguised as a male dreamer called an incubus.
[cpg]



[VOICE f="sArsha024"]
[OnName num="asha"]
“Are you an incubus...? Can you use magic to control the mind?”
[cpg cn=true]


[OnName num="renzi"]
I wonder. That's what I thought when I transformed."
[cpg cn=true]


[OnName num="renzi"]
I don't know if I can use it. But I'm going to try."
[cpg cn=true]


I'm going to think about it, and I'm going to remind myself of it. But ......
[cpg]


I don't even know if I can use magic just by thinking about it.
[cpg]


If not, I don't know how magic can be used even more.
[cpg]


I keep thinking about it and keep on thinking about it.
[cpg]


[OnName num="renzi"]
How's it going? Is there any change in your body?
[cpg cn=true]

;**【ＣＧ】 ev_52_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sArsha025"]
[OnName num="asha"]
"......."
[cpg cn=true]

He looks a little depressed. I feel like it's working.
[cpg]


I can only mimic the basic movements of the demon I copied, but ......
[cpg]


I guess this means that this is part of the basic behavior for incubus.
[cpg]


[OnName num="renzi"]
'Slowly the eyelids get heavier ...... and you fall asleep.'
[cpg cn=true]


I try to do something hypnotic to see what it looks like, but I don't know where this is going.
[cpg]

;**【ＣＧ】 ev_52_b ***********************
[CG id=2 index=2 time=1000]
;***************************************
[WAIT time=1500]

[OnName num="renzi"]
Let's see......... I'm falling in love easily, but I'm slowly losing it."
[cpg cn=true]


[OnName num="renzi"]
“There will only be one person who you truly love..."
[cpg cn=true]


What an embarrassing thing to say.
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



And so, from that day on, Asha's condition was to be changed.
[cpg]


Asha said she felt a little lighter.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sArsha026"]
[OnName num="asha"]
'I'm ...... fine. Maybe this will help me do my job normally."
[cpg cn=true]


He said that, but I couldn't help but feel that he was lying.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





Then the next day I headed to the mess hall and find Dorothy and Asha chatting amongst each other.
[cpg]


I wondered what kind of relationship they had.
[cpg]


Dorothy and Janice obviously have an unusual feeling about them, but ......
[cpg]


I wonder if he is doing anything with Asha. What an evil thought came to my mind.
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





That night, I disguised myself as Dorothy and headed for Asha's room.
[cpg]


What if. If Dorothy had done nothing to Asha, that would be fine.
[cpg]


On the other hand, if something had happened, I might be able to get a deeper story out of her.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



;//ここからしばらく、ドロシーのセリフ名前欄を「ドロシー（蓮司）」と置き換えてください



[FG f="CHA02_p4_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Dorothy493"]
[OnName num="renzi_to_dorothy"]
'Good evening. Do you have a minute?"
[cpg cn=true]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Arsha298"]
[OnName num="asha"]
Yeah. ...... what's up, Dorothy?"
[cpg cn=true]


[FACE method="change_1"  pos="1/2"]
[VOICE f="Dorothy494"]
[OnName num="renzi_to_dorothy"]
I thought you and Renji have been getting along well lately. Something happened."
[cpg cn=true]


It's not a very thought out approach, but I still ask. Then...
[cpg]


[FACE method="change_4"  pos="2/2"]
[VOICE f="sArsha027"]
[OnName num="asha"]
"I wanted to change my...condition. I asked him to transform into an incubus and try to entrance me."
[cpg cn=true]


[FACE method="change_1"  pos="2/2"]
[VOICE f="sArsha028"]
[OnName num="asha"]
And ...... I wanted to tell someone about this story, will you listen?"
[cpg cn=true]


[FACE method="change_2"  pos="1/2"]
[VOICE f="Dorothy495"]
[OnName num="renzi_to_dorothy"]
I'll listen to whatever you have to say, as long as it's okay with me.
[cpg cn=true]


[FACE method="change_4"  pos="2/2"]
[VOICE f="Arsha301"]
[OnName num="asha"]
I like Renji, I like him, but ......
[cpg cn=true]


[FACE method="change_1"  pos="2/2"]
[VOICE f="sArsha029"]
[OnName num="asha"]
Even when he's not around, I find myself flirting with other people.
[cpg cn=true]


I have heard that he has a hard-on for someone who isn't me, and he also has a hard-on for women.
[cpg]


[FACE method="change_6"  pos="2/2"]
[VOICE f="sArsha030"]
[OnName num="asha"]
“What do you think I should do? I really want a love life that has nothing to do with this condition."
[cpg cn=true]


[FACE method="change_1"  pos="1/2"]
[VOICE f="Dorothy496"]
[OnName num="renzi_to_dorothy"]
'Don't worry about ....... Asha will be Asha."
[cpg cn=true]


I'm in a situation where I could confess right now and we could go out. But I wanted to solve her problems first.
[cpg]


[FACE method="change_3"  pos="1/2"]
[VOICE f="sDorothy016"]
[OnName num="renzi_to_dorothy"]
Asha. I know you're still in pain. Shall I turn into an incubus one more time?"
[cpg cn=true]


[FACE method="change_5"  pos="2/2"]
[VOICE f="Arsha304"]
[OnName num="asha"]
What?"　The way you talk ...... maybe, Renji?"
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Dorothy598"]
[OnName num="renzi_to_dorothy"]
Oh. Sorry for the deceptive manner."
[cpg cn=true]



[FACE method="change_6"  pos="2/2"]
[VOICE f="Arsha305"]
[OnName num="asha"]
“It's terrible... I thought you were Dorothy, and said those things.”
[cpg cn=true]


Having said that, Asha seemed to feel better for having said all that.
[cpg]



[FACE method="change_1"  pos="2/2"]
[VOICE f="Arsha316"]
[OnName num="asha"]
She was dressed as Dorothy, but the way Renji speaks seems strange.
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Dorothy508"]
[OnName num="renzi_to_dorothy"]
I don't think so. Should I imitate Dorothy?"
[cpg cn=true]


We both smile at each other. But the immediate problem is still unsolved.
[cpg]


I wanted to help Asha at all costs.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


;//ここからドロシーのセリフ名前欄を元に戻してください


I was thinking about the future.
[cpg]


Aphrodisiacs are probably a thing in this world. It should be somewhat easy to make.
[cpg]


But the opposite would be difficult.
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_04_5_up.ui" time=1000]
[FACE method="feadin_up" pos="4/7"]
[WAIT time=1500]


[OnName num="renzi"]
I wondered if it was the same for all the beasts of the rabbit tribe.
[cpg cn=true]


I had gone to someone for advice. That person was...
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Clara535"]
[OnName num="clara"]
“Why... are you asking me for advice on such a matter?"
[cpg cn=true]


Clara. She is also no ordinary human.
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="sClara014"]
[OnName num="clara"]
“Well, I've heard that...rabbits fall in love easily."
[cpg cn=true]


[OnName num="renzi"]
I knew it. Is there anything you can do about it?
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Clara537"]
[OnName num="clara"]
I don't know, but somewhere in the ...... wide world, there must be a cure."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





My conversation with Clara ended with what seemed to be a clue.
[cpg]


I couldn't think about it alone, so I went and talked to Janice as well.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice463"]
[OnName num="janice"]
If you're going to go out with that guy, you're going to have to include that in your relationship."
[cpg cn=true]


[OnName num="renzi"]
I'm aware of that," he said. I'm not saying that, I'm saying Asha is in trouble and I want to help her solve it.'
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice464"]
[OnName num="janice"]
"Wel.."
[cpg cn=true]


Janice is no stranger to Asha. She seemed to be thinking about something, but couldn't seem to come up with a plan for this.
[cpg]


;//移植前シーンカット

;//移植前シーンカット



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************




I stayed by Asha's side day in and day out. I was there, to soothe her loneliness and to change her condition.
[cpg]


But the relationship between us was somewhat awkward. I thought it was different from a normal lover.
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト

[BG f="b_04_5_up.ui" time=1000]
[FACE method="feadin_up" pos="4/7"]
[WAIT time=1500]




[OnName num="renzi"]
There was this thing called
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

[VOICE f="Clara538"]
[OnName num="clara"]
It sure sounds like a lot of work, but why are you coming to me about it?
[cpg cn=true]


I consult Clara again. I was running out of people to talk to in the dungeon.
[cpg]


[FACE method="change_1"  pos="2/3"]

[VOICE f="Clara539"]
[OnName num="clara"]
But you kept asking me about it, and I remembered. I told her about the tree people.
[cpg cn=true]


[OnName num="renzi"]
The tree people?　What are tree people?
[cpg cn=true]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Clara540"]
[OnName num="clara"]
I've heard that the fruits of the tree people can cure all kinds of incurable diseases, depending on the right combination.
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Clara541"]
[OnName num="clara"]
I don't know if you can get it, though, because I hear it's very valuable.
[cpg cn=true]


[OnName num="renzi"]
"Hmm..."
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy520"]
[OnName num="dorothy"]
"Jyuto?　Why are we suddenly talking about this?"
[cpg cn=true]


[OnName num="renzi"]
"It's for Asha. I thought it might help her."
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy521"]
[OnName num="dorothy"]
I don't know about ....... I wonder if that can be called a disease.
[cpg cn=true]


Surely it's more of a condition than a disease? It's a tough call.
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy522"]
[OnName num="dorothy"]
But tree people don't stay in dungeons. They can't live in places where there is no light.
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy523"]
[OnName num="dorothy"]
They're demons, but they don't like conflict, and I wonder where ...... they live."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





Dorothy told me what she knew, and I made a simple map.
[cpg]


The forest of the tree people. It seemed to be located further from the ogre tribe's village.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************




[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

Asha and I talked about it, hugging each other day after day.
[cpg]


[OnName num="renzi"]
I told her that I was going to go to the forest. If there was a medicine that could change your constitution, would you want it?
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="sArsha031"]
[OnName num="asha"]
I want it so bad I could choke on it," he said. Renji doesn't like me like this, does he?
[cpg cn=true]


[OnName num="renzi"]
I don't hate you, but ...... you still want it."
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Arsha376"]
[OnName num="asha"]
Yes. I want to love only Renji. I want to love only the person I love.
[cpg cn=true]


It's kind of a funny word to cut out, but it seemed to express Asha's feelings well.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]
;//ブラックアウト



Then came the day of departure.
[cpg]




[window target=false]

[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************





[OnName num="renzi"]
“It’s so bright...”
[cpg cn=true]


Whenever I leave a dungeon after a long time, the sunlight always seems to blind me.
[cpg]


I headed into the forest where the tree people lived.
[cpg]


First, I had to get to the village of the ogre tribe. I started walking.
[cpg]


[SE f=se020]
;//【ＳＥ】『草原歩く』



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（夕方）******************************************************



[OnName num="demon"]
Wait. What do humans want?
[cpg cn=true]


I was in human form to make it easier to walk.
[cpg]


[OnName num="renzi"]
No, no, no, I'm a demon.
[cpg cn=true]


We went through the gate and asked for Satsuki's place.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ヒロイン５の家＿室内』（夕方）******************************************************





[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki104"]
[OnName num="satsuki"]
It's been a long time. What brings you here this time?
[cpg cn=true]


I wanted to hear what was going on to some extent before negotiating with the tree people. Without hesitation, I talked to Satsuki.
[cpg]


[OnName num="renzi"]
I want the fruit of the tribe. They are deep in this village, aren't they?
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Satuki105"]
[OnName num="satsuki"]
“They're picky, you know... It must be difficult to get them to cooperate.”
[cpg cn=true]


Satsuki's expression clouded a little. Is it really that difficult?
[cpg]


[OnName num="renzi"]
I'm not giving up. It's for the person I love.
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Satuki106"]
[OnName num="satsuki"]
I wonder if he has a girlfriend. Is he suffering from some incurable disease?"
[cpg cn=true]


Satsuki smiled a little and asked me that. I answered openly, as there was no need to hide it.
[cpg]


[OnName num="renzi"]
I answered proudly, "Oh, yes. My girlfriend wants the fruit of the tree people.
[cpg cn=true]


I felt prepared to say the words. No matter how difficult the negotiations would be, I would do something about it.
[cpg]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





That day, I was to stay at Satsuki's house for the day and then leave.
[cpg]






[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『鬼の集落』（朝）******************************************************





[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki107"]
[OnName num="satsuki"]
I said, "Have a good trip," and he said, "I'll see you later. Take care.
[cpg cn=true]


[OnName num="renzi"]
Oh. You're not a violent race, I'll come back safely.
[cpg cn=true]


With these words, I left the village of the ogre tribe.
[cpg]



[SE f=se009]
;//【ＳＥ】『歩く』


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************



[SE f=se020]
;//【ＳＥ】『草原歩く』




After walking for about half a day, the area gradually became forest-like with more and more trees.
[cpg]


Then we arrived at the forest where the tribe of tree people lived.
[cpg]


I did not feel very welcome. Rather, they treated me as if I were a foreigner who had entered their territory.
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_09_2_up.ui" time=1500]
[FACE method="feadin_up" pos="4/7"]
[WAIT time=2000]


[OnName num="treant"]
......"
[cpg cn=true]


The tree people really looked like trees and did not speak a word.
[cpg]


[OnName num="renzi"]
“Excuse me. I'm here to look for the fruit of the tree people.”
[cpg cn=true]


The tree people said nothing to me. However, in spite of the fact that they would not talk to me, I understood something.
[cpg]


The tree people were demons, living creatures, albeit close to plants.
[cpg]


And it seemed that they were not willing to give me their fruits.
[cpg]


To take the fruit from them would be an invasion, and as Satsuki said, they also seemed to have a difficult personality.
[cpg]


It would be difficult to gain their cooperation. Understanding this, I suddenly came up with a plan.
[cpg]


[OnName num="renzi"]
Let me smell the berries. I won't take them away.
[cpg cn=true]


[OnName num="treant"]
......"
[cpg cn=true]


On this, they did not refuse. The berries had little smell, but a slight scent of fruit.
[cpg]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『平原』（夜）******************************************************





I head out to the plains once more and continue walking, passing by the village of the Ogre Tribe.
[cpg]


It was hard work, but I had a harvest. Namely, I was able to turn into a tree person with fruits.
[cpg]


[SE f=se020]
;//【ＳＥ】『草原歩く』



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（昼）******************************************************





Then I returned to the dungeon for the first time in a long time. I was greeted by Asha.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha377"]
[OnName num="asha"]
Welcome back, Renji. I thought you might not come back.
[cpg cn=true]


[OnName num="renzi"]
No way. Nothing dangerous happened. I have good news.
[cpg cn=true]


[OnName num="renzi"]
I got the fruit of the tree people. It may be able to cure Asha's condition."
[cpg cn=true]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





I told Asha up to this point. However, I kept the rest of the story from her.
[cpg]


I instinctively sensed that it was a dangerous thing to do, and I consulted Dorothy and Janice about it.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Dorothy524"]
[OnName num="dorothy"]
I was afraid to think about it, even if I had the same power.
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Janice465"]
[OnName num="janice"]
'Yes,' he said. Do you know what it means ...... to share your fruit with others?"
[cpg cn=true]


I didn't nod. I think I know, but I'm not ready.
[cpg]


[FACE method="change_3"  pos="1/2"]
[VOICE f="Janice466"]
[OnName num="janice"]
'Undoubtedly you will lose your body. The next time you disguise yourself in a human body or a demon body, you may not be able to return to your full form."
[cpg cn=true]


Janice makes her words clear. In essence, she was saying that it might be similar to losing an arm or a leg.
[cpg]


I almost hesitated, but quickly reconsidered.
[cpg]


If Asha could live in peace, she could at least have an arm. That's what I thought.
[cpg]


[OnName num="renzi"]
I don't care. I'm not afraid of losing anything for Asha.
[cpg cn=true]


[FACE method="change_3"  pos="2/2"]
[VOICE f="Dorothy525"]
[OnName num="dorothy"]
You sound like you're serious about ....... I get it."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


;**【ＣＧ】ci_24_0 ***********************
;//カットイン
[CUTIN f="ci_24_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

If I was ready, I was already ready. I decided to disguise myself as a tree man with berries and ask Dorothy to get them for me.
[cpg]

[CUTIN f="ci_24_0.ui" show={false} method="slideout"]
[WAIT time=1000]

I thought to myself, "I can't let Asha be present at this scene. ......
[cpg]




[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Dorothy526"]
[OnName num="dorothy"]
I'm going." Renji."
[cpg cn=true]


It was a moment of tension, but nothing like pain.
[cpg]


[FACE method="feadin" pos="4/7"]
[BG f="b_04_5.ui" time=1500]
[WAIT time=2000]
;//ブラックアウト



The fear was there the whole time. But if I didn't overcome it, Asha's constitution would never be cured.
[cpg]

Thinking that, I felt strangely stable.
[cpg]


As it turned out, nothing happened that Dorothy or Janice were worried about.
[cpg]


When I transformed from one tree person to another, my arms and legs were not missing.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





I couldn't make the concoction using the berries, so I left it to another demon to do it for me.
[cpg]


The fruit of the tree people seems to be really precious, and he asked me how I got it.
[cpg]


I told him how I got them and what they were for, and the potion was successfully created...
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sArsha032"]
[OnName num="asha"]
"You're telling me that if I take this, I can change my...condition?"
[cpg cn=true]


[OnName num="renzi"]
Oh," he said. In theory, it should."
[cpg cn=true]


Asha is right to be skeptical. How did they create such a panacea? Is it safe to drink?
[cpg]


I knew I shouldn't have been concerned about that, but I wasn't.
[cpg]


[OnName num="renzi"]
Oh, hey ......."
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha379"]
[OnName num="asha"]
'Fuzzy. It's sweet, this medicine."
[cpg cn=true]


Asha swallowed it all in one gulp. She seemed to trust me a lot.
[cpg]






[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





From that day on, Asha's condition had improved.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Arsha380"]
[OnName num="asha"]
Good morning!　Renji, let's have another good day."
[cpg cn=true]


[OnName num="renzi"]
Oh, yeah. I don't have a mission to work hard for, though."
[cpg cn=true]


Asha was always a jovial person, but I think she's become more jovial in a roundabout way.
[cpg]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





Asha somehow seemed to have noticed what I had done, too.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Arsha381"]
[OnName num="asha"]
She said, "It was ...... good. I did that."
[cpg cn=true]


[OnName num="renzi"]
What do you mean by that?"
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha382"]
[OnName num="asha"]
Did it ever occur to you that you might not be able to get back into your original form?"
[cpg cn=true]


[OnName num="renzi"]
You heard from ...... Dorothy? You're a chatty one."
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Arsha383"]
[OnName num="asha"]
No, it's not. It's my imagination. But it sounds like it really was. Weren't you scared?
[cpg cn=true]


[OnName num="renzi"]
“I wasn't afraid of that. If it’s for you Asha, there is nothing to be afraid of."
[cpg cn=true]


Asha smiled and took my hand.
[cpg]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha384"]
[OnName num="asha"]
Thank you," she said. I love you, Renji.
[cpg cn=true]


Come to think of it, I haven't formally confessed. But I don't need that anymore.
[cpg]


I'm sure I don't need any more words.
[cpg]

;//移植前シーンカット



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


That night, Asha and I talked for a while. Then this topic came up.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha407"]
[OnName num="asha"]
Renji," she said. You can turn into a tree person, right?
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha408"]
[OnName num="asha"]
If that's the case, can't you grow fruit as many times as you want?　It sounds like you could make an unlimited number of elixirs."
[cpg cn=true]


[OnName num="renzi"]
“Indeed... Something might happen to my body though.”
[cpg cn=true]


But if we could do that, we could solve the problem of disease spreading in the dungeon.
[cpg]

;//移植前シーンカット




;//その夜、俺はアーシャとベッドで話し込んでいた。
;//[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Arsha429"]
[OnName num="asha"]
I think it would be better to turn into a tree man and make medicine. It would probably be very profitable.
[cpg cn=true]


[OnName num="renzi"]
'That's true, but don't you have plenty of money to loot from the ...... humans?　It doesn't make much sense to make money in the dungeon.
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Arsha430"]
[OnName num="asha"]
Yes!　The humans won't be able to touch us."
[cpg cn=true]



I noticed that you said that, but it's true. I feel that there is something to be said for being able to build friendships.
[cpg]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





From there we went on to make and sell elixirs to the humans and the demon tribe.
[cpg]


The dungeon became rich without us having to do anything.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice467"]
[OnName num="janice"]
It was an unexpected byproduct. I never thought it would come to this.
[cpg cn=true]


[OnName num="renzi"]
Yeah," he said. I never imagined it either.
[cpg cn=true]


There was no longer any need to loot from the invading adventurers, and there was no longer any reason to invade us.
[cpg]


As a result, even the battle between humans and demons was calmed down.
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice468"]
[OnName num="janice"]
“There is a movement to liberate Clara as well. If there is no more reason to fight, it would be awful to have a prisoner of war.”
[cpg cn=true]


[OnName num="renzi"]
"Maybe so. As long as Clara is here, they might try to come to her aid.”
[cpg cn=true]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





As a result, Clara was released and there was true peace in the dungeon.
[cpg]


All thanks to me, you may say, but it doesn't ring a bell.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha431"]
[OnName num="asha"]
It's thanks to Renji. You should be more confident.
[cpg cn=true]


[OnName num="renzi"]
I don't know what to say."
[cpg cn=true]


I had recently started to transformed into a beastman to match Asha.
[cpg]


However, I don't think it would be appropriate for a man to wear rabbit ears, so I'm a canine beastman.
[cpg]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Arsha432"]
[OnName num="asha"]
I'm a canine beastman," he said, "and those ears look good on you. Renji is good looking no matter what he looks like.
[cpg cn=true]


Asha was even more in love with me than before.
[cpg]


Regardless of my physical condition, she thinks she likes me.
[cpg]






[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





And we hung around together every evening.
;//＠→そして、夜になると毎日というくらいに二人愛し合った。
[cpg]



;//========================================
;//●ＣＧ（二人寄り添っている。ベッドに二人で腰掛けている感じ）ev_61
;//人物１：ヒロイン４　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公は犬っぽい獣人に化けています
;//=======================================


[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_61_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1500]

[SE f=se012]
;//【ＳＥ】『衣擦れ』

You never know what might be useful in this world. I could not have done this without Asha's tendency to go into heat, not to mention my ability to transform.
[cpg]



[VOICE f="Arsha433"]
[OnName num="asha"]
Renji ...... and I were destined to meet, weren't we?
[cpg cn=true]

;**【ＣＧ】 ev_61_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Arsha434"]
[OnName num="asha"]
It's like everything was connected for this moment. Ever since our first meeting.
[cpg cn=true]


Of course, I feel like it's my destiny, too. It's as if it was inevitable that we would make love together now.
[cpg]


[OnName num="renzi"]
“I feel that way, too. Your previous physical condition and everything else must have existed for this moment.”
[cpg cn=true]

;**【ＣＧ】 ev_61_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sArsha033"]
[OnName num="asha"]
I've always hated myself. I'm the petty one who falls in love with everyone.
[cpg cn=true]



[VOICE f="Arsha436"]
[OnName num="asha"]
But now I feel I can like myself. Of course, I love Renji the most.
[cpg cn=true]


Her smile as she said this felt different from the first smile I saw.
[cpg]

[SCENE id=14]


;//ＥＮＤ　ヒロイン４ルート

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="epend.ks" target="*start"]


;//==============================
