
*start

;###################################################################
*Ep008|You can't stop shapeshifting even if you're pissed off
;###################################################################


[SCENE id=8]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]
[BG f="black.ui"  time=1000]
[WAIT time=100]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





[OnName num="goblins"]
Hey, that shapeshifter ......
[cpg cn=true]


[OnName num="kobold"]
Oh, I thought it was going to be the trump card that would change the game. I thought it would be the trump card that would change the war situation,......."
[cpg cn=true]


I'm not saying you're rushing me, but you're discouraging me.
[cpg]

;//＠
 It's the same for me, but as expected, my conscience hurt a little.
[cpg]


I'm just sitting on my ability to get a meal and a room.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha128"]
[OnName num="asha"]
"Are you worried about the rumors?　Renji.
[cpg cn=true]


[OnName num="renzi"]
"Yeah, well, I'm not sure if it's ...... or not.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha129"]
[OnName num="asha"]
I don't have much to say about it, but it seems that the Demon Lord is thinking about how you're being treated.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Arsha130"]
[OnName num="asha"]
If you want your own private bedroom, you might at least go scouting.
[cpg cn=true]


Against the stupid me, even Asha pushed my back.
[cpg]


I'm going to have to sleep in the big room again, apparently.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



;//ここからしばらく、ドロシーのセリフ名前欄を「ドロシー（蓮司）」と置き換えてください

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[WAIT time=1000]
[FG f="CHA02_p4_01_a.ui" method="change_1"  pos="2/3" time=1]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

[VOICE f="Dorothy082"]
[OnName num="renzi_to_dorothy"]
'...... as always, a perfect makeover.'
[cpg cn=true]


But I had one thing on my mind.
[cpg]


I think it's so refreshing to me. I guess it's my nature to be here after all.
[cpg]


Today I had transformed into Dorothy. Compared to Janice, she is much shorter.
[cpg]


I think about something similar to the other day. If the transformation is so perfect, I can live my life pretending to be someone else.
[cpg]


I should really pretend to be Dorothy and live for a day.
[cpg]


It might not be a bad feeling to be praised as a princess by everyone. ......
[cpg]

;//移植前シーンカット


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


[SE f=se019]
;//【ＳＥ】『ノック』

[WAIT time=1000]


Then I hear a knock at my door. I answered in a hurry.
[cpg]


[FG f="CHA02_p4_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Dorothy103"]
[OnName num="renzi_to_dorothy"]
"What ......, wait a minute."
[cpg cn=true]



[VOICE f="Janice109"]
[OnName num="janice"]
"......?　It sounded like the voice of the princess.
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_12_0 ***********************
;//カットイン
[CUTIN f="ci_12_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

I immediately transformed. I transformed into the form of a canine beastman and opened the door.
[cpg]



;//ここからドロシーのセリフ、名前欄を元に戻してください


[CUTIN f="ci_12_0.ui" show={false} method="slideout"]

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Janice110"]
[OnName num="janice"]
Was I disguised as the princess?
[cpg cn=true]


[OnName num="renzi"]
No, ......, I think you heard wrong.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Janice111"]
[OnName num="janice"]
'In moderation.'
[cpg cn=true]


' said Janice, who seemed quite angry.
[cpg]


[OnName num="renzi"]
So, you have something for me?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Janice112"]
[OnName num="janice"]
I know you have something to do with me. The princess wants to see you.
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]

I was escorted to the king's room, where Dorothy was sitting on the throne.
[cpg]


[OnName num="renzi"]
Where is the Demon King?
[cpg cn=true]


I could have asked, "Where's the Demon King?　I could have asked, but since Janice and Dorothy were there, I put on a "sama.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy104"]
[OnName num="dorothy"]
He's busy adjusting the magic that flows through the dungeon.
[cpg cn=true]


[OnName num="renzi"]
Can I sit on the throne ......?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy105"]
[OnName num="dorothy"]
I don't mind. If all goes well, I'll be the next Demon King.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Dorothy106"]
[OnName num="dorothy"]
But more importantly, I want you to do me a favor.
[cpg cn=true]


[OnName num="renzi"]
I'll do it if I can. If I can, I will.
[cpg cn=true]


[FO pos="2/3" time=1000]
[FO pos="1/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト

[FACE method="feadin" pos="4/7"]

[BG f="b_04_5.ui" time=1000]

[WAIT time=1000]


According to him, there are some problems in the dungeon where demons live.
[cpg]


It is said that adventurers sometimes appear in the dungeon and are returned to the dungeon. ......
[cpg]



They were stripping those adventurers of their money and belongings. If we didn't, they would attack us again.
[cpg]


But they had no use for it in the dungeon.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FACE method="out" pos="4/7"]


[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]


[OnName num="renzi"]
Surely, it's not good to just have money.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy107"]
[OnName num="dorothy"]
Yes, it is. Adventurers are supposed to invade for adventurers' money.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy108"]
[OnName num="dorothy"]
So, ......, why don't you go to a human town and buy some magic equipment?　You can disguise yourself as a human, can't you?
[cpg cn=true]


[OnName num="renzi"]
"Maybe I can, but ...... what's a magic tool?"
[cpg cn=true]


[FACE method="change_1" pos="1/3"]

[VOICE f="Janice113"]
[OnName num="janice"]
Literally, magic tools. What I need you to buy this time is something that will accelerate the growth of vegetables.
[cpg cn=true]


I see. I had heard of such a thing.
[cpg]


I had wondered how vegetables could grow in such a cave-like place.
[cpg]


[OnName num="renzi"]
"That's true," he said. I'll give it a try.
[cpg cn=true]


It was a lighter mission than reconnaissance. And I wanted to play a trick on the humans, too.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Dorothy109"]
[OnName num="dorothy"]
Really?　I'm glad you have a job I can assign you.
[cpg cn=true]


[OnName num="renzi"]
What kind of ...... is that?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy110"]
[OnName num="dorothy"]
I was worried when your father said he was going to take the room away from Renji.
[cpg cn=true]


[OnName num="renzi"]
I was worried because your father said he was going to take away Renji's room. ......
[cpg cn=true]


I see. The actuality that you can get a lot of these things is that they're not really that expensive.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FO pos="1/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





I'm not sure what I'm going to do now that I've been set up this far.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha131"]
[OnName num="asha"]
What do you think?　Do you think you can turn into him?
[cpg cn=true]


An adventurer who had come to defeat the Demon King and had been beaten back, and who was unconscious. I approached him and sniffed him.
[cpg]


It's not a very pleasant thing to smell a man's scent, but ......
[cpg]


[OnName num="renzi"]
I can do it. As long as you know what you smell.
[cpg cn=true]



;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[FO pos="2/3" time=1]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_13_0 ***********************
;//カットイン
[CUTIN f="ci_13_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

I was able to become a human easily. A young man who looked like a swordsman.
[cpg]


And the real one, or rather the copy, was to be held captive in the dungeon for a while.
[cpg]


This way, there would never be two people with the same appearance.
[cpg]

[CUTIN f="ci_13_0.ui" show={false} method="feadout"]

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep009.ks" target="*start"]
