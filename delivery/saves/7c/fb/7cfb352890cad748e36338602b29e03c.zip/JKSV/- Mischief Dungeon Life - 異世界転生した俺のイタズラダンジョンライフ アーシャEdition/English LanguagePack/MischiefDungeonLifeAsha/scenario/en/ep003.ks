

*start

;###################################################################
*Ep003|This is how we use transformation.
;###################################################################


[SCENE id=3]

[window target=false]



;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]



[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[WAIT time=100]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



[window target=true]


After that, I lived my life without staying in one form because I could take on many different forms.
[cpg]


When I was in the mess hall, I heard various stories from the demons.
[cpg]


[OnName num="goblins_A"]
"Master Janice, is really cool. Is it true what they say about her not having a partner?"
[cpg cn=true]


[OnName num="goblins_B"]
Come on, ......, I think you're right."
[cpg cn=true]


I hear something a little disturbing and I stay there pretending to be slime.
[cpg]


Janice is sitting far away eating. The goblins were glancing at her.
[cpg]


[OnName num="goblins_A"]
I was thinking, "Since she's so brave, it's not easy to find a man who can match her.
[cpg cn=true]

[OnName num="goblins_B"]
“Well. She is the perfect warrior..."
[cpg cn=true]


[OnName num="goblins_B"]
But I hear Master Janice isn't very good with ghosts."
[cpg cn=true]


Oops. That's the first I've heard of that.
[cpg]


[OnName num="goblins_A"]
Oh, I've certainly heard that before. I think the ghosts were lamenting about it.
[cpg cn=true]







[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[window target=true]

There is a group of ghosts that is called the "Ghost Tribe”.
[cpg]


Or, were they not a race at all, but originally a different kind of demon?
[cpg]


Either way, they were there. And I could probably transform into one of them as well.
[cpg]


They were probably not inorganic. I guess that principle couldn't be applied here after all.
[cpg]


There were other kinds of undead, but they couldn't turn into zombies.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[window target=true]


;**【ＣＧ】ci_08_0 ***********************
;//カットイン
[CUTIN f="ci_08_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

I went back to the mess hall in ghost form.
[cpg]

[CUTIN f="ci_08_0.ui" show={false} method="slideout"]
[WAIT time=1000]

[OnName num="renzi"]
"Where's Janice?"
[cpg cn=true]


[OnName num="goblins"]
Hmm?　Yeah, it looks like they're getting some rest now. I think he went back to his room.
[cpg cn=true]


Janice has been assigned a room as well. With that thought, I made my way to the corridor leading to the private room.
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』


;//ブラックアウト



I didn't know where Janice's room was, but I saw her ahead of me in the corridor.
[cpg]


I followed her from behind. When she's alone, I'll try to surprise her.
[cpg]


If she really doesn't like ghosts, she'll be surprised...
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice014"]
[OnName num="janice"]
"Wind: ......"
[cpg cn=true]


On her way back to her room alone, I heard her sigh.
[cpg]


She must be in a position like a chief of staff, so she must be going through a lot of hardships.
[cpg]


I felt a little sorry to frighten her.
[cpg]


[SE f=se012]
;//【ＳＥ】『衣擦れ』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice015"]
[OnName num="janice"]
I was like, "Nn......?"
[cpg cn=true]


When we went back to my room, I sneaked in with him. Then Janice turns around.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Janice016"]
[OnName num="janice"]
Whoa!"
[cpg cn=true]


When Janice saw me, she fell into a heap, as if her back had buckled.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Janice017"]
[OnName num="janice"]
Why, here's a ...... ghost."
[cpg cn=true]


He is making a shaky voice and is scared to death of me.
[cpg]


[OnName num="renzi"]
......"
[cpg cn=true]


It's okay that I scared him, but what do I do now?
[cpg]


;//＠シナリオカット用テキスト
Janice paled, and right then and there. I slumped down.
[cpg]

;//ジャニスは青ざめて、このまま何もしないのはもったいないと思えるくらいだった。
;//[cpg]
;//
;//
;//ゴーストって、人に触れるんだろうか？　それも、試してみたいな。
;//[cpg]
;//
;//
;//
;//;//========================================
;//;//●ＣＧ（へたりこんで、怯えきっているヒロイン）ev_07
;//;//人物１：ヒロイン３　服装１：私服
;//;//人物ex：主人公　　　服装ex：無し
;//;//場所　：ダンジョン＿寝室
;//;//時間　：暗い
;//;//備考　：主人公は幽霊に変身しています　半透明で青白く、人型です
;//;//========================================
;//
;//;//*Scene002
;//
;//[STOPBGM]
;//[FO pos="2/3" time=1000]
;//[BG f="black.ui"  time=1000]
;//[WAIT time=1000]
;//[BGM f="10"]
;//;**【ＣＧ】 ev_07_0 ***********************
;//[CG id=1 index=0 time=1000]
;//;***************************************
;//[WAIT time=1500]
;//
;//
;//
;//
;//[VOICE f="Janice018"]
;//[OnName num="janice"]
;//「く、来るな！　あっちへ行けっ」
;//[cpg cn=true]
;//
;//
;//ジャニスはずっと表情が変わらない人だったから、こうして見るとギャップがあるな。
;//[cpg]
;//
;//
;//俺はそんなことを思いながら、彼女にさらに近づく。
;//[cpg]
;//
;//
;//今の俺はゴーストとはいえ、喋ることはできるだろう。
;//[cpg]
;//
;//
;//ただ、喋ってしまえば彼女は怯えなくなるかもしれない。
;//[cpg]
;//
;//
;//お化けというのは、そういうものだろうと想像しながら、近づいた。
;//[cpg]
;//
;//;**【ＣＧ】 ev_07_a ***********************
;//[CG id=1 index=1 time=1000]
;//;***************************************
;//[WAIT time=1500]
;//
;//[VOICE f="Janice019"]
;//[OnName num="janice"]
;//「やめて……っ、あぁっ、許して……」
;//[cpg cn=true]
;//
;//
;//普段の彼女からは想像つかないほど弱々しい声だ。
;//[cpg]
;//
;//
;//それもなんだかいじらしくて、俺は余計虐めたくなる。
;//[cpg]
;//
;//
;//今の彼女に触ったらどうなるだろう。というか、俺に触れられたらどう感じるんだろう？
;//[cpg]
;//
;//;**【ＣＧ】 ev_07_0 ***********************
;//[CG id=1 index=0 time=1000]
;//;***************************************
;//[WAIT time=1500]
;//
;//[VOICE f="Janice020"]
;//[OnName num="janice"]
;//「ひいっ！　触るなあぁ」
;//[cpg cn=true]
;//
;//
;//彼女の肌に触れてみると、俺からは熱く感じられた。
;//[cpg]
;//
;//
;//ということはこっちの体温が下がってるはずだけど、スケスケのこの体で触覚があるのも不思議な話だ。
;//[cpg]
;//
;//
;//;**【ＣＧ】 ev_07_b ***********************
;//[CG id=1 index=2 time=1000]
;//;***************************************
;//[WAIT time=1500]
;//
;//[VOICE f="sJanice001"]
;//[OnName num="janice"]
;//;//「あっ、ああっ、冷たいっ……もう、やめてくれ」
;//「冷たいっ……も、もう、何もしないでくれ」
;//[cpg cn=true]
;//
;//そしてジャニスからするとやっぱり冷たいらしい。
;//[cpg]
;//
;//
;//俺は正体がばれないのをいいことに、暫く彼女を脅かし続けていた。
;//[cpg]
;//
;//
;//;//移植前シーンカット
;//
;//

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト


Janice calmed down a little and was about to get up.
[cpg]


[VOICE f="Janice039"]
[OnName num="janice"]
You know what happens to ...... when you do this."
[cpg cn=true]




Oh no, I think, and I try to back away a little.
[cpg]



[VOICE f="Janice040"]
[OnName num="janice"]
"Wait, wait!"
[cpg cn=true]

[SE f=se010]
;//【ＳＥ】『走る』

[window target=false]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


I hurried back to the aisle and then disguised myself as a gargoyle where she couldn't see me.
[cpg]


I thought she would follow me right away, but I guessed she was changing clothes and it took her a long time.
[cpg]


Then she came looking for me, but passed me by.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[OnName num="renzi"]
Maybe this is the most powerful ......?"
[cpg cn=true]


Back in my room, I mutter to myself.
[cpg]


I can't say it's the strongest. But it helps me achieve my goal.
[cpg]


I've wanted to get close to pretty girls for a long time.[cpg]


I don't have much in my repertoire of disguises right now, but I feel like I can do a wider variety of things.
[cpg]


And I knew that a little mischief would not be enough to punish me.
[cpg]


After all, I am the future of the demon tribe. I felt that even if I did something reckless, it would be okay.
[cpg]



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="ep004.ks" target="*start"]

