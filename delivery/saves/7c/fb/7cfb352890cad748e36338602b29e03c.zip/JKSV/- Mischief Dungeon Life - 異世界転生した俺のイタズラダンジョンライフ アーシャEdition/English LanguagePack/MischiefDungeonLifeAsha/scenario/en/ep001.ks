

*start


;###################################################################
*Ep001|Clues to Transformation
;###################################################################

[window target=false]


[SCENE id=1]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]

[stflag Jumpflg = 0]


[if exp={getFlagValue("Jumpflg") == 0 }]
[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 0]
[stflag Cha4flg = 0]
[stflag Cha5flg = 0]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]
[endif]

[BG f="black.ui"  time=1000]
[WAIT time=1000]


[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************

[SE f="se008"]
;//【ＳＥ】『喧噪』

[window target=true]


[OnName num="kobold_A"]
“Things are getting pretty crazy in the Iguna Region."
[cpg cn=true]


[OnName num="kobold_B"]
It's the same everywhere. Humans and demons are incompatible.
[cpg cn=true]


As I spent more time in the world, it gradually became clear to me about this world.
[cpg]


This is a world called “Roa", and it seems that this dungeon is located in a place called the "Iguna Region”.
[cpg]


The dungeon itself is simply called a dungeon, which itself also refers to the land of demons.
[cpg]


And demons talk more than I imagined.
[cpg]


What was the difference? I tried hard to disguise myself, but I can’t remember how I did it in the beginning at all.
[cpg]


And even though they are demons, they are well controlled, just like humans.
[cpg]


The guards take turns watching over the demons, and the resting demons sleep and eat.
[cpg]


It's just like humans guarding a castle or something.
[cpg]


[SE f="se009"]
;//【ＳＥ】『歩く』

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]

[WAIT time=1500]


[OnName num="kobold_A"]
Oh, Janice.
[cpg cn=true]


[VOICE f="Janice001"]
[OnName num="janice"]
"......"
[cpg cn=true]


Then a girl I had never seen before appeared.
[cpg]


No, she is not a girl, but she has style. She was a dragoness, or perhaps something in between a lizardman and a human.
[cpg]

[FO pos="2/3" time=800]

[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="4/5" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/5" time=1000]
[VOICE f="Janice002"]
[OnName num="janice"]
Is that you, the shapeshifter?
[cpg cn=true]


I was eating and dressed as Asha at the time.
[cpg]



;//下記セリフ名前欄を「アーシャ（蓮司）」と置き換えてください


[FACE method="change_7" pos="4/5"]

[VOICE f="Arsha010"]
[OnName num="renzi_to_asha"]
"Uh...I guess...”, I reply.
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Janice003"]
[OnName num="janice"]
“You guess...?"
[cpg cn=true]


I guess I shouldn't have said it that way. I explain myself anyway.
[cpg]


When I told him that I didn't really feel like I was born a shapeshifter, he gave me a dubious look.
[cpg]


[FACE method="change_3" pos="2/5"]
[VOICE f="Janice004"]
[OnName num="janice"]
“Anyway, the Demon King wants to see you.”
[cpg cn=true]


The Demon King. I only know that he is the master of the dungeon.
[cpg]


It looks like I will finally have to face the Demon King.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]

[FO pos="2/5" time=1]
[FO pos="4/5" time=1]


[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************


[window target=true]



[OnName num="devil"]
...... really looks just like Asha, doesn't he?
[cpg cn=true]

;**【ＣＧ】ci_18_0 ***********************
;//カットイン
[CUTIN f="ci_18_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

The Demon King was a rather human-like figure, although his skin color seemed unhealthy.
[cpg]


He is muscular and intimidating looking.
[cpg]


It is a common belief that higher demons are more human-like in appearance, but perhaps that is just how it is.
[cpg]

[CUTIN f="ci_18_0.ui" show={false} method="feadout"]
[WAIT time=1000]

;//下記セリフ名前欄を「魔王の娘？」に置き換えてください





[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Dorothy001"]
[OnName num="devils_daughter"]
......"
[cpg cn=true]


There was also something that looked like his daughter with him.
[cpg]


The girl Janice is standing with her, making her seem like one of the Demon King's advisors.
[cpg]


[FO pos="4/5" time=1000]

[OnName num="devil"]
What's your name?"
[cpg cn=true]



;//しばらくアーシャのセリフ名前欄を「アーシャ（蓮司）」と置き換えてください





[FG f="CHA04_p4_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha011"]
[OnName num="renzi_to_asha"]
I am Renji. Renji Hanamura ......"
[cpg cn=true]


I wondered for a moment if the concept of kanji existed in this world.
[cpg]


I wondered for a moment if there is a concept of Kanji in this world. But their names seem to be written in yokoji characters.
[cpg]


[OnName num="devil"]
I heard they are shapeshifters. Prove its power."
[cpg cn=true]


While I was thinking what a surprise, that's what I was told.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Arsha012"]
[OnName num="renzi_to_asha"]
“Yes...”
[cpg cn=true]


I nodded and went along with it. From Asha's form, I transformed into a golem.
[cpg]



[SE f=se001]
;//【ＳＥ】『変身音』


[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_02_0 ***********************
;//カットイン
[CUTIN f="ci_02_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]


I don't know what the process is, it doesn't look good to me.
[cpg]


But it seemed to be enough to surprise the Demon King, his daughter, and Janice.
[cpg]

[CUTIN f="ci_02_0.ui" show={false} method="feadout"]
[WAIT time=1000]

[OnName num="devil"]
"You really are a shapeshifter..., aren't you?"
[cpg cn=true]


The daughter-like girl seemed more surprised than the Demon King himself.
[cpg]



;//下記セリフ名前欄を「魔王の娘？」に置き換えてください





[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Dorothy002"]
[OnName num="devils_daughter"]
She was more surprised than the Demon Lord, who seemed to be his daughter.　Let me try to be one of them.
[cpg cn=true]


I looked down at her as she said this.
[cpg]



;//ここからドロシーの名前欄をそのまま表示してください





[FACE method="change_2" pos="2/3"]
[VOICE f="Dorothy003"]
[OnName num="dorothy"]
My name is Dorothy," she said. You can be my father."
[cpg cn=true]


She looks at the Demon King and calls him father. She must be his daughter after all.
[cpg]


She looks at me with dull eyes, and I want to live up to her expectations, but ......
[cpg]


[OnName num="renzi"]
......"
[cpg cn=true]


I couldn't transform. I shake my head.
[cpg]


[OnName num="devil"]
I heard that shapeshifters have certain conditions when they transform. Maybe there's something to it.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy004"]
[OnName num="dorothy"]
I see. Too bad."
[cpg cn=true]


Her name was Dorothy, and she looked really disappointed. I feel somewhat sorry.
[cpg]

[FO pos="2/3" time=1000]


[OnName num="rudolf"]
I'm sorry I missed your name. My name is Rudolph. My name is Rudolph Townsend. I'm the master of this dungeon.
[cpg cn=true]


I wanted to say, "Thank you very politely," but I had no mouth to say it.
[cpg]


[OnName num="rudolf"]
"Would you be willing to do some information gathering on the humans? You could also try deceiving and taking their champion captive."
[cpg cn=true]


What the hell, what are you talking about all of a sudden?
[cpg]


I can't take on such a heavy mission. I want to say, "I'll turn into Asha again.
[cpg]



[SE f=se001]
;//【ＳＥ】『変身音』

[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]



[WAIT time=1000]
[FG f="CHA04_p4_01_a.ui" method="change_7"  pos="2/3" time=1]

[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



When I was dressed as her once again, I could smell the vanilla and soap combined smell.
[cpg]


I was impressed with myself that I had really copied even the smell of her body.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Arsha013"]
[OnName num="renzi_to_asha"]
I can't do it," she said. I just got the ability to transform.
[cpg cn=true]


[OnName num="rudolf"]
What do you mean?"　I thought you were born a shapeshifter."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Arsha014"]
[OnName num="renzi_to_asha"]
That's ...... something I don't really understand either, but I'm new to the world."
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="5/3" time=1]


I decided to tell them everything. I can't go on talking while hiding it.
[cpg]



[move from="2/3" to="2/5" ease="easeInOutSine" time=1000]
[move from="5/3" to="4/5" ease="easeInOutSine" time=1000]

[VOICE f="Dorothy005"]
[OnName num="dorothy"]
You mean you're from another world?　Tell me more."
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Arsha015"]
[OnName num="renzi_to_asha"]
I think I died once.
[cpg cn=true]


When I told the story of how it happened, both the Demon King and Dorothy listened with interest.
[cpg]


Janice was the only one who remained Buddhist, but still nodded her head from time to time.
[cpg]


[FACE method="change_5" pos="4/5"]
[VOICE f="Dorothy006"]
[OnName num="dorothy"]
'So that means you reincarnated and came here!　Did it still hurt when you died?"
[cpg cn=true]


[FACE method="change_4" pos="2/5"]
[VOICE f="Arsha016"]
[OnName num="renzi_to_asha"]
I don't remember. ......
[cpg cn=true]


[OnName num="rudolf"]
Anyway, it's extraordinarily interesting. If he lived in a world we don't know, he might be able to come up with some wacky strategies."
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[FO pos="2/5" time=1]
[FO pos="4/5" time=1]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



[window target=true]


From there, the treatment changed considerably.
[cpg]


I was given a private room instead of the large room I had been given.
[cpg]

[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[VOICE f="Janice005"]
[OnName num="janice"]
This is your room from now on. You can use it freely.
[cpg cn=true]


[FACE method="change_2" pos="2/5"]
[VOICE f="Arsha017"]
[OnName num="renzi_to_asha"]
Thank you."
[cpg cn=true]


[FACE method="change_7" pos="4/5"]

Janice looks at me seriously. I guess she is still not satisfied with my transformation.
[cpg]


[FACE method="change_1" pos="4/5"]
[VOICE f="Janice006"]
[OnName num="janice"]
“I haven't seen the Demon King’s or the Princess’ faces light up like that in a long time. They must be expecting a lot from you.”
[cpg cn=true]


[FACE method="change_7" pos="2/5"]
[VOICE f="Arsha018"]
[OnName num="renzi_to_asha"]
Thank you for ......."
[cpg cn=true]


I had to repeat the same words. Even with such expectations.
[cpg]


[FACE method="change_2" pos="4/5"]
[VOICE f="Janice007"]
[OnName num="janice"]
I'm counting on you, too. Good luck."
[cpg cn=true]

[SE f="se009"]
;//【ＳＥ】『歩く』

[move from="4/5" to="5/3" ease="easeInOutSine" time=2000]
[WAIT time=1100]


After saying that, Janice left. ......
[cpg]

[SE f="se001"]
;//【ＳＥ】『変身音』

[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]
[FO pos="2/5" time=1]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


[FACE method="feadin_up" pos="4/7"]



I release my transformation once and for all. I return to my initial, serpentine form.
[cpg]


Somehow it felt strange to be transformed into someone else, and I thought that if I reverted back to my original form, that feeling would go away...
[cpg]


It wasn't much like that. To begin with, I wasn't a shapeshifter, just a human being.
[cpg]

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

But still, you said a lot of things about being able to take wacky strategies and expectations .......
[cpg]


I was thinking about something completely different from the expectations I was receiving.
[cpg]


There are cute girls in the dungeon, even if they are demon girls.
[cpg]


I was thinking that I could do something naughty to them.
[cpg]


For some reason, I don't have a large repertoire of transformations at the moment, but if I could increase this ......
[cpg]

;//＠俺は一人考えていると、邪な欲望が高まってきた。
I was alone with my thoughts, and my desire was growing.
[cpg]


And now I wonder if I can disguise myself as a girl. If you ask me if I'm not interested, I am.
[cpg]

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

I look around. I don't think there is anything to watch in this room.
[cpg]


I try again to turn into Asha. But I couldn't do it right away, as if I was missing some condition.
[cpg]


[OnName num="renzi"]
What is it?
[cpg cn=true]


I tried this and that, wondering why. I had been able to transform just a moment ago.
[cpg]


Am I forgetting something?　I try to remember about Asha, thinking.
[cpg]


I try to remember her form vividly and try to transform her again, but I can't do it.
[cpg]


I thought some more and remembered other information about her. For example, the smell ......
[cpg]


A woman's smell can be compared to a variety of good smells by men.
[cpg]

For example, vanilla, fruits, flowers. Or mint, perfume, soap.
[cpg]

I think Asha's smell was a combination of two of these smells.
[cpg]

If I could recreate the scent in my mind, I could transform myself...
[cpg]

On the other hand, if I got one of them wrong, I wouldn't be able to say I remembered correctly.
[cpg]

With that in mind, I tried to recall her scent.
[cpg]


;//ゲーム要素のある変身システムをここに挿入します
;//以降、単に変身システムと表記します



;//今作は主人公がヒロインの匂いを覚えていないと変身できないという設定ですので
;//それを利用しつつ選択肢を用いたシステムとなっています



;//例えば今回はヒロイン４へと変身するＨシーンがありますが
;//そのシーン以前に本編で
;//「バニラと石けんを足したような匂い」
;//というようにヒロインの匂いを本編で表記しています



;//そこから暫くして変身するシーンの直前ですが



;//「バニラ」　　「ミント」
;//「果物」　×　「香水」
;//「花」　　　　「石けん」



;//という風に、三つあるいは四つぐらいの選択肢を二つ掛け合わせたものを用意します
;//左から一つ、右から一つというように選びます
;//三つの選択肢であるので、組み合わせは九種類になり、うち正答は一つです
;//二つの選択肢を両方を正しく選ぶことで、変身が成功しＨシーンに進む、という形です
;//失敗した場合はＨシーンに進みません



;//そのＨシーンを通っているかどうかで、後のルート分岐に影響します



;////////////////////////
;////////////////////////
;//一度目の変身システム//
;////////////////////////
;////////////////////////



;//選択肢用フラグ
[stflag IseSel01flg = 0]

I'm sure the first smell was something like...
[cpg]


[switch]
[case "vanilla"]
	[swap]
	[stflag IseSel01flg = 1]
	[jump target="*hen11"]
[case "Fruits"]
	[swap]
	[jump target="*hen11"]
[case "flowers"]
	[swap]
	[jump target="*hen11"]
[endswitch]


*hen11|A clue to her transformation.


The second smell was...
[cpg]



[switch]
[case "mint"]
	[swap]
	[jump target="*hen12"]
[case "Perfume"]
	[swap]
	[jump target="*hen12"]
[case "soap"]
	[swap]
	[stflag IseSel01flg = 1]
	[jump target="*hen12"]
[endswitch]

*hen12|Transformation Clues


[window target=true]

[WAIT time=100]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FACE method="out" pos="4/7"]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="04"]


[window target=true]

[if exp={getFlagValue("IseSel01flg") == 2 }]
[jump target="*select01_2"]
[endif]


[jump target="*select01_1"]

;//■選択肢Ａ
1. vanilla
2. fruit
3. flowers

;//■選択肢Ｂ
4. mint
5. Perfume
6. soap





;//==============================
;//１、バニラ　６、石けん　を選んでいた場合
*select01_2|Clues for transformation

;//【ＢＧ】『ダンジョン＿寝室』（暗い）


As I vividly recalled her smell, I was able to transform naturally.
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/3" time=1]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



[FACE method="feadin_up" pos="4/7"]


[BG f="b_03_5_up.ui" time=1000]

[WAIT time=1000]


Maybe it has something to do with the smell, not the shape.
[cpg]


I look down at my figure. I am really a girl, in every way.
[cpg]


I was curious to see how far they had gone in recreating her.
[cpg]


Of course, Asha's privacy was at stake. I wondered what to do about it and then I went to ......
[cpg]


[FO pos="2/3" time=1000]
[FACE method="feadout_up" pos="4/7"]
[BG f="black.ui"  time=1000]
[WAIT time=1500]

;//========================================
;//●ＣＧ（鏡の前で自分の姿を確かめるヒロイン＝主人公）ev_17
;//人物１：ヒロイン４　服装１：着衣
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公はヒロイン４の姿に変身しています
;//========================================

;**【ＣＧ】 ev_17_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1500]

;//ここからしばらく、アーシャのセリフ名前欄を「アーシャ（蓮司）」と置き換えてください

I stood in front of the mirror as she was.
[cpg]


I'm already convinced that I've gone this far. The excuse that I was just testing her is not acceptable.
[cpg]

;**【ＣＧ】 ev_17_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sArsha001"]
[OnName num="renzi_to_asha"]
She's got a pretty big...chest...
[cpg cn=true]

What a soliloquy, Asha's voice comes out.
[cpg]


I felt funny, but I suppressed the urge.
[cpg]


No more. Really, I shouldn't do anything.
[cpg]


Although..., I've transformed myself, so it would be a waste to not to.
[cpg]

;**【ＣＧ】 ev_17_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="sArsha002"]
[OnName num="renzi_to_asha"]
It really looks just like her. Even his voice is ......."
[cpg cn=true]

I was deeply moved for a while, mumbling to myself.
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

;//[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


[window target=true]

I decided to go to sleep in Asha's form.
[cpg]


I could have slept as a golem, but I wanted to be surrounded by a good smell.
[cpg]


Smell...smell? I think I'm on to something...
[cpg]



;//ヒロイン４ルートの可能性が残る

[jump target="*select01_3"]

;//==============================
;//１、バニラ　６、石けん　のいずれかを外した場合

*select01_1|Transformation Clues



I tried many times to transform myself into Asha, but something seemed to be missing and I couldn't quite transform myself.
[cpg]


I felt like I was draining my energy as I tried repeatedly to transform myself in a desperate attempt.
[cpg]


What was I missing?　I transformed without understanding.
[cpg]


As I continue, trying to remember every detail about her ......
[cpg]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[FG f="CHA04_p4_01_a.ui" method="change_1"  pos="2/3" time=1]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


At one point, I was suddenly transformed into Asha.
[cpg]


I finally achieved my goal, but I didn't have enough energy left to motivate myself to do something because I was transformed.
[cpg]



;//ヒロイン４ルートの可能性がなくなる

[stflag Cha4flg = -1]

;//==============================

*select01_3|Transformation Clues



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]


[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse


[jump storage="ep002.ks" target="*start"]
