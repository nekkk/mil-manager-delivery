
*start

;###################################################################
*Ep003|I'm almost at my limit.
;###################################################################


[SCENE id=3]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（朝）******************************************************





It's still okay while walking around town. But to be honest even that was hard.
[cpg]


Maybe not enough to make me exhausted since I'm getting used to it too.
[cpg]


Next time, I will be with Suzune. Excited for that, I keep walking
[cpg]


Without that kind of a short-term goal, or a roadmap, I can’t keep up my spirits.
[cpg]


I feel helpless when I think of it as something that goes on forever. ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（朝）******************************************************


[SE f="se002"]
;//【ＳＥ】『喧噪』


I arrive at school. I think I have calmed down somewhat since the first day of Heart Pounding Management.
[cpg]


[OnName num="male_student"]
“You seemed to be in a bad shape a while ago, but you've been looking better lately. That's a relief."
[cpg cn=true]


[OnName num="gorou"]
“I guess so. ...... Yeah, I guess it's been rather good lately."
[cpg cn=true]


I figured people around me thought it was weird.
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************



As the class progressed and noon came, it was getting hard for me.
[cpg]


I wanted to head over to Suzune before eating lunch, but then there was a chance that Suzune would be eating.
[cpg]


Eventually, late in the lunch break, I finally head over to Suzune .
[cpg]


I don't have much time to spare, but I have to do something.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune021"]
[OnName num="suzune"]
“..... sounds like you're having a hard time.”

[cpg cn=true]


[OnName num="gorou"]
“Suzune ...... I think I'm going to die."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune084"]
[OnName num="suzune"]
“I agree. I was told that there was a risk of getting another disease.”
[cpg cn=true]


Suzune pulled my hand away, speaking calmly as she did so.
[cpg]


I was worried that people might see, but she took me to the Student Guidance Office.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_03_2_up.ui" time=1000]
[WAIT time=2000]


If this kind of thing would repeat often, it was bound to escalate.
[cpg]


If that's the case, I wonder if I will ever kiss her.
[cpg]


I wonder what she thought of me.
[cpg]


I don't want to do something she doesn't want to do.
[cpg]


Or ...... Will she still feel sad that I'm going to die?
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



I walk out of the Student Advisor's Office, making sure no one was watching.
[cpg]


If anyone saw me, the rumors would start again.
[cpg]


I can't keep doing this kind of thing over and over again.
[cpg]


I need to get a little more creative ...... but I don't know how.
[cpg]


I can't hold back the whole time I'm on campus.
[cpg]



[window target=false]

[WAIT time=2000]

[BG f="b_03_3.ui" time=1500]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



Meanwhile, school has ended.
[cpg]


I try to go home. I'm still holding on…
[cpg]


[OnName num="male_student_A"]
"Hey, Kosaka. Wanna go home for a while and have some fun?”
[cpg cn=true]


[OnName num="male_student_B"]
“You haven't been hanging out as much lately? Is something wrong?”
[cpg cn=true]


[OnName num="gorou"]
“I'm sorry. Please, let me go home. ......"
[cpg cn=true]


[OnName num="male_student_A"]
“Why? Let's go to the arcade."
[cpg cn=true]


He was a good friend to begin with. I can't neglect him.
[cpg]


But,...... the later I get home, the harder it gets.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夜）******************************************************



There are only boys surrounding me. Or rather, I was hanging out with a group of boys.
[cpg]


But I was looking for someone to make my heart beat.
[cpg]


People around me didn't seem to understand what was going on and thought I had a cold or something.
[cpg]


So I was released somewhat early,...... but it was already midnight.
[cpg]


[OnName num="gorou"]
"Oh ...... this is bad, this is ...... bad."
[cpg cn=true]



My mom’s face comes to my mind and I wonder if Dad has returned yet.
[cpg]


If I'm going to get something done, I'd better do it soon I thought to myself.
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa080"]
[OnName num="sawa"]
"Welcome home. You're back late."
[cpg cn=true]


[OnName num="gorou"]
“Sorry ......, sorry ......."
[cpg cn=true]


[OnName num="father"]
“Where were you? It's almost dinner time.”
[cpg cn=true]


[OnName num="gorou"]
"Yeah, ......, that's ......."
[cpg cn=true]


It's not hard to lie about where I was.
[cpg]


But that's not the worst part. Dad is back.
[cpg]


I’ll have to hold out while we eat.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


My guess was right. There is no way I can get Mom to do anything when Dad is back, for the most part.
[cpg]


I was filled with bitterness, which Himari found amusing.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari091"]
[OnName num="himari"]
“Goro you’re so cute. Mom It's not fair.”
[cpg cn=true]


[OnName num="father"]
“......?”
[cpg cn=true]


Dad apparently has no idea what she’s talking about.
[cpg]


That's fine, but I was in such a tight spot that I couldn't make a proper decision.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



In such a last minute situation, I was told by mom .
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa081"]
[OnName num="sawa"]
“I'll be waiting for you in my room. You can come over anytime."
[cpg cn=true]


I want to go right now, but I can't lead dad on to any suspicion.
[cpg]



;//ブラックアウト


Far beyond the limits of my patience, I gradually become more nervous.
[cpg]


I go to Mom.
[cpg]


I felt like I couldn't stand it any longer. ......
[cpg]


;//========================================
;//●ＣＧ（主人公に胸を押しつけるヒロイン。主人公の体に少し触れている感じ）ev_14
;//人物１：ヒロイン３
;//服装１：パジャマ
;//人物２：主人公
;//服装２：パジャマ
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa017"]
[OnName num="sawa"]
“I know you've had a hard day. Let me help you."
[cpg cn=true]


[OnName num="gorou"]
"...... Mom.”
[cpg cn=true]


[VOICE f="sSawa018"]
[OnName num="sawa"]
“I'm sorry you had to go through that. It's all right now."
[cpg cn=true]


[OnName num="gorou"]
“Oh, ah......."
[cpg cn=true]


I am so relieved that I can't help but let out a funny noise.
[cpg]


[VOICE f="sSawa019"]
[OnName num="sawa"]
She giggles. “It must have been so hard for you."
[cpg cn=true]


Just by touching her, I can feel a release in my brain.
[cpg]


I can't help but know that it must be something I need right now.
[cpg]


I'm thrilled, yet relieved. I was so wrapped up in this strange sensation that I couldn't help but relax.
[cpg]


;**【ＣＧ】 ev_14_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa020"]
[OnName num="sawa"]
“How can I make you excited?"
[cpg cn=true]


She touches my body a little while saying so. I feel like I can't be patient anymore.
[cpg]


[OnName num="gorou"]
“I'm already excited enough.”
[cpg cn=true]


[VOICE f="sSawa021"]
[OnName num="sawa"]
“Then that’s good.”
[cpg cn=true]


I felt like I wanted to hug her, but I held back.
[cpg]


[VOICE f="sSawa022"]
[OnName num="sawa"]
“Her pulse is very fast. I can feel it.”
[cpg cn=true]


It's natural to be nervous. To be approached by such a beautiful person......
[cpg]


But there is also the nervousness that comes from a place of wondering what would happen if dad were to find out.
[cpg]


I know it is a problem just to have such a feeling.
[cpg]


I know it's immoral of me, and I know it's a problem just to have such feelings, but I can't suppress them.
[cpg]


;**【ＣＧ】 ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa023"]
[OnName num="sawa"]
"Do you want to sleep by my side again today?"
[cpg cn=true]


Mom was quite bold.
[cpg]


[OnName num="gorou"]
“Well, I think that's ...... a bad idea.”
[cpg cn=true]


[VOICE f="sSawa024"]
[OnName num="sawa"]
“I'm good. As long as it's okay with you Goro.”
[cpg cn=true]


When she said that to me, I was tempted to do so, but I ...... held back.
[cpg]


If Dad found out, it would be bad.
[cpg]


Dad is very blunt in some ways, but it still would be bad ......
[cpg]


[OnName num="gorou"]
"...... I still can't do it. I'm going back today."
[cpg cn=true]


[VOICE f="sSawa025"]
[OnName num="sawa"]
“Yeah? You know you’re always welcome here."
[cpg cn=true]


When she says something like that, it almost makes me reconsider it.
[cpg]


Unlike with Suzune and Himari, it felt wrong.
[cpg]



;//ブラックアウト

With a sense of regret, I left her room.
[cpg]


Even though she is only a stepmom, she is an irreplaceable person to me, and I wonder if this is the right thing to do.
[cpg]


It can't be good…… but I can't stop.
[cpg]






;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』



After that, I went back to my room.
[cpg]


No matter how much I felt like I was being tossed around, I couldn’t do anything about it by my own will…….
[cpg]


It's mostly my condition. But ......
[cpg]


I wonder if mom thought something of me. Or maybe she also has some kind of disease that makes her heart need to beat like mine.
[cpg]


And then there was this…
[cpg]



;//■選択肢
[switch]
[case "I feel bad for my dad."]
	[swap]
	[jump target="*select02_1"]
[case "If she has feelings towards me, I want to return her feelings."]
	[swap]
	[jump target="*select02_2"]
[endswitch]

1. I feel bad for my dad.
2. If she has feelings towards me, I want to return her feelings.



;//==============================
;//１、父に申し訳ない
*select02_1|I'm almost at my limit.




I feel sorry for my dad. Mom and I are strangers, but dad and mom are a couple.
[cpg]


We're not blood related, ...... but I still think we're doing things that aren't good.
[cpg]


That doesn’t mean that I don't feel anything for Himari and Suzune.
[cpg]

[jump target="*select02_3"]


;//==============================
;//２、何か思ってくれてるなら応えたい

*select02_2|I'm almost at my limit.



If mom really had feelings for me, then I want to return her feelings.
[cpg]


Even if the relationship is strange, it's impossible to suddenly break it off. Maybe both of us feel like that. ......
[cpg]



[stflag Cha3flg = 1]

;//ヒロイン３が候補に



;//==============================

*select02_3|I'm almost at my limit.


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]



[jump storage="ep004.ks" target="*start"]


;/////////////////////////////////////////////////////////////////////
