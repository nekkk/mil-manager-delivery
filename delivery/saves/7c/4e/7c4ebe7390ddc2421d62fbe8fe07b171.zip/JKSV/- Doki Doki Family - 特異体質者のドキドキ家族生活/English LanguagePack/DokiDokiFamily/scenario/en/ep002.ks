
*start

;###################################################################
*Ep002|The pain of being managed.
;###################################################################

[SCENE id=2]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





Suzune was already headed to the workplace, or rather, to the school.
[cpg]


She is a busy person too, so I don't blame her.
[cpg]


She has to go earlier than the students arrive, of course.
[cpg]


When I think about it, I feel very grateful: ......
[cpg]


Unlike me, she was a working person after all.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************




[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa055"]
[OnName num="sawa"]
“Off you go Goro. Make sure not to take detours on your way back home.”
[cpg cn=true]


She didn’t need to tell me that, I won't take detours because I'm sure I'll be suffering in the evening again.
[cpg]


With that in mind, I said goodbye to my mom.
[cpg]


[OnName num="gorou"]
“I'm heading out..."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari067"]
[OnName num="himari"]
“I'm heading out!"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************


Morning class. It was hard for me during classes.
[cpg]


In the classroom, you are supposed to concentrate on your studies.
[cpg]


But when the teacher is a woman, there is nothing I can do. Even if she is not that young.
[cpg]


And if the teacher is a man, my attention is drawn to my female classmates.
[cpg]


Just the feeling of wanting to be thrilled makes it so much harder.
[cpg]


I'm already in so much pain that I had to ask Suzune for help pretty early on.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（朝）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune059"]
[OnName num="suzune"]
“...... wait until lunchtime. You’re a boy, you'll have to be a little more patient."
[cpg cn=true]


[OnName num="gorou"]
“I’m in trouble because I am a boy. ……"
[cpg cn=true]


“That’s true.” Suzune muttered. But it doesn't matter.
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



From there I managed to hang on until lunchtime, and this time I convinced Suzune .
[cpg]


I would not miss it again. If I miss this timing, I'm really going to die.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune008"]
[OnName num="suzune"]
“Then, let's go to an empty classroom somewhere this time.”
[cpg cn=true]


[OnName num="gorou"]
“What, not the ...... Student Advisor's Office?"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune061"]
[OnName num="suzune"]
“We will seem suspicious if we use it too much."
[cpg cn=true]


She's right, but if we use an empty classroom, someone will see us. ......
[cpg]



;//ブラックアウト


[VOICE f="sSuzune009"]
[OnName num="suzune"]
“Now what shall we do? Hey…..!”
[cpg cn=true]


Despite my many concerns, I could not contain myself.
[cpg]


;//========================================
;//●ＣＧ（ヒロインに背後から抱きつく主人公。衝動を必死にこらえる）ev_10
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]





[OnName num="gorou"]
"Suzune ……!"
[cpg cn=true]


I hug her from behind. I smell the good smell and feel my pulse quicken.
[cpg]


Thinking back, I have not been able to do this since I was a child, even if I wanted to.
[cpg]


But now, I can be pampered without hesitation.
[cpg]


In that sense, I partly owed it to my current condition. ......
[cpg]


[VOICE f="sSuzune010"]
[OnName num="suzune"]
"...... That was too abrupt. You startled me."
[cpg cn=true]


I thought that she was blushing a little too.
[cpg]


Maybe she had thoughts about what I was doing.
[cpg]


[OnName num="gorou"]
“I'm sorry, I just couldn't take it anymore.”
[cpg cn=true]


;**【ＣＧ】 ev_10_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune011"]
[OnName num="suzune"]
“You're such a ...... helpless boy"
[cpg cn=true]


Suzune looked disappointed, but also embarrassed.
[cpg]


[VOICE f="sSuzune012"]
[OnName num="suzune"]
“Well, you're cute in that way, too.”
[cpg cn=true]


When she tells me that I’m cute my heart starts pounding again.
[cpg]


I want to be ...... thrilled, which is also an emotion that comes from my condition.
[cpg]


But I also wanted to feel my heart pounding even without that.
[cpg]


I want to be seduced by my sister. I want to be bewitched by her, all the time. ......
[cpg]


[VOICE f="sSuzune013"]
[OnName num="suzune"]
“I feel like your body temperature is getting higher Goro.”
[cpg cn=true]


[OnName num="gorou"]
"Yeah, I guess so."
[cpg cn=true]


When I'm told that and become aware of it, I'm likely to become even more so due to embarrassment.
[cpg]


[VOICE f="sSuzune014"]
[OnName num="suzune"]
“Yes, you are. I don't think it's just my imagination."
[cpg cn=true]


But I think Suzune who says so is also feeling a little hot.
[cpg]


;**【ＣＧ】 ev_10_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune015"]
[OnName num="suzune"]
“I think it's time for me to go. Have you calmed down?"
[cpg cn=true]


I shake my head. It's not enough.
[cpg]


A feeling welled up in me like I wanted her to hug me tighter, and I struggle to suppress it.
[cpg]


[VOICE f="sSuzune016"]
[OnName num="suzune"]
“Truly, a helpless child.”
[cpg cn=true]


She did not say it in a harsh way, but in a gentle and warm way.
[cpg]


I felt a different kind of motherly love compered to my stepmom.
[cpg]


[VOICE f="sSuzune017"]
[OnName num="suzune"]
“You are so spoiled,……I’ll be here a little longer.'
[cpg cn=true]


Suzune is saying that and allowing me to do what I want.
[cpg]


I feel like I can't hold back any longer if she's this nice to me. ......
[cpg]


But still, I held back to do nothing more.
[cpg]


[OnName num="gorou"]
“Thank you ......."
[cpg cn=true]


[VOICE f="sSuzune018"]
[OnName num="suzune"]
“You're welcome. Seeing my brother in trouble is something I can't leave alone."
[cpg cn=true]


That said, Suzune seemed to be holding something back as well.
[cpg]


I wondered if maybe she was thinking something about me ….…
[cpg]


[OnName num="gorou"]
“You smell...... good."
[cpg cn=true]


;**【ＣＧ】 ev_10_b ***********************
[CG id=4 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune019"]
[OnName num="suzune"]
“Don't sniff. And don't say embarrassing things."
[cpg cn=true]


She was less embarrassed but seemed to be scolding me.
[cpg]


But I wondered if she could smell me too.
[cpg]


I hoped that she would think about me. ......The lunch break will soon be over.
[cpg]



;//ブラックアウト

Happy times inevitably pass by quickly.
[cpg]


The more you want it to go on, the sooner it will be over.
[cpg]


And the painful time was about to start again.
[cpg]


I want to be thrilled. I could go on all day. ......
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



Afterwards. Rumors spread quickly, or maybe that guy saw it firsthand.
[cpg]


[OnName num="male_student_A"]
"I saw it. You walked into the classroom with Ms. Kosaka during lunchtime."
[cpg cn=true]


[OnName num="male_student_B"]
“What were you doing? What went on?”
[cpg cn=true]


Damn it, I think, but I go on to answer.
[cpg]


[OnName num="gorou"]
“No, it's ...... you know me and my teacher have the same last name?"
[cpg cn=true]


[OnName num="male_student_A"]
“Kosaka Goro, right? Do your names have the same kanji?"
[cpg cn=true]


[OnName num="gorou"]
“Yes. Our teacher is my stepsister.”
[cpg cn=true]


[OnName num="male_student_B"]
“Seriously? I envy you ......!"
[cpg cn=true]


[OnName num="gorou"]
“That's why I was there to talk about family problems and stuff like that."
[cpg cn=true]


I'm not lying. But I can't tell the real truth.
[cpg]


[OnName num="male_student_A"]
“It's still not right to go to an empty classroom.”
[cpg cn=true]


[OnName num="gorou"]
“If you’re talking about the kind of things you don't want others to hear."
[cpg cn=true]


This problem is becoming a burden. ...... But it's not just my fault.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園教室』（夕方）******************************************************





Afternoon class. As I was taking them, mom 's face was flickering in my head.
[cpg]


After all, I can't live without the three of them. That's what I'm reminded of.
[cpg]


It's imprinted in me that I can't go against them anymore. ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





By the end of school, I am already exhausted. My classmates are worried about me.
[cpg]


[OnName num="female_student_A"]
"Are you okay? Kosaka?”
[cpg cn=true]


[OnName num="female_student_B"]
“Hey, hey, is it true that you and Ms. Kosaka are related as stepsister and stepbrother?"
[cpg cn=true]


How quickly rumors spreads, I think as I reply to the minimum questions as possible.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa056"]
[OnName num="sawa"]
“Welcome home. Are you in pain already? How is it?”
[cpg cn=true]


[OnName num="gorou"]
“I'm having a hard time ...... help me mom."
[cpg cn=true]


I say what I think, but Mom smiles and and tells me
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa057"]
[OnName num="sawa"]
“Cute face. Hey Goro, how about holding out a little longer today?"
[cpg cn=true]


I can't help but say,
[cpg]


[OnName num="gorou"]
“I'm going to die. ……!"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





I had been told that I shouldn't have my heart beat too few times a day.
[cpg]


But if the goal is three times a day, then I guess I won't die even if it changes to twice a day.
[cpg]


In fact, they may have said three times in order to set the limit.
[cpg]


It would probably be a problem to get used to the pounding.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari068"]
[OnName num="himari"]
“Goro, it looks painful. I hope your body heals soon."
[cpg cn=true]


I finish my meal and get up unsteadily from my chair.
[cpg]

[free time=1000]

I can't do anything. I mean, I can't look at attractive women like Himari, Suzune and Mom .
[cpg]


It's best to sleep alone. I walk back to my room.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I wonder how long I'll have to wait. Mom is probably already asleep.
[cpg]


As I was thinking that, I started to lose consciousness.
[cpg]


I really could be getting another disease. In the midst of all this.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[WAIT time=1100]



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa058"]
[OnName num="sawa"]
"Sorry to keep you waiting. Please come to my room.”
[cpg cn=true]


[OnName num="gorou"]
"Are you ...... sure ......?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa059"]
[OnName num="sawa"]
“I'm surprised you can afford to say that. I don't know what to do."
[cpg cn=true]


[OnName num="gorou"]
“Uh-uh! Please, I'm at my limit."
[cpg cn=true]


If mom even says so I have no choice.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//移植前シーンカット


That night I slept with Mom stroking my head.
[cpg]


I didn't run or hide, I let my heart pound.
[cpg]


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa016"]
[OnName num="sawa"]
“You're so cute. You look so relieved."
[cpg cn=true]

I was actually relieved. I was thrilled, but relieved.
[cpg]


And after that, exhausted, I went straight to sleep with mom ......
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





Then the next day, before mom woke up, I went back to my room.
[cpg]


It was not long before the pounding management started. That's where I noticed it.
[cpg]


I was wondering if I would become too dependent on being given a heart pound on a regular basis.
[cpg]


On the other hand, if I didn't, I would have a hard time breathing. ......
[cpg]


I wonder what I should do, but I also know I can't let this go on.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari012"]
[OnName num="himari"]
“Goro. Don’t you want to have fun with your cute sister again today?"
[cpg cn=true]


Himari says. She calls herself cute……
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari070"]
[OnName num="himari"]
"Father has already left, so ...... We can do anything.”
[cpg cn=true]


What does she mean by "anything"?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Suzune079"]
[OnName num="suzune"]
“Stop it. Do it when I'm not looking."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari071"]
[OnName num="himari"]
“Why! It's fine as long as Suzune doesn't see it"
[cpg cn=true]



Suzune’s response was natural, but Himari seemed to anticipate that as well.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





I awkwardly go back to my room, which is a bad idea when I think about it.
[cpg]


I would not be able to be thrilled in the morning, and I might not last until noon.
[cpg]


Should I do what Himari wants, even if it's a little embarrassing?
[cpg]


No, no, no, I can't do it in front of Mom and Suzune after all. ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



My conflict didn't last long.
[cpg]


I knew I couldn't do nothing. I felt like I lost against Himari……
[cpg]


I decided to follow Himari. Mom doesn’t mind but Suzune gives me a cold stare.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari072"]
[OnName num="himari"]
“Why didn't you just do as I told you from the beginning? You're so stubborn."
[cpg cn=true]


I decided to follow Himari. Mom doesn’t mind but Suzune gives me a cold stare.
[cpg]



;//========================================
;//●ＣＧ（倒れ込んでいる主人公にキスをしようとするヒロイン。寸止めでキスはしない）ev_12
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の家＿リビング
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari013"]
[OnName num="himari"]
“Hey, let's kiss. It's the most exciting thing you can do."
[cpg cn=true]


And now we're in this situation. Himari is going a step too far.
[cpg]


It seems she's not only enjoying watching me fall down and get all giddy, but
[cpg]


[OnName num="gorou"]
"Are you serious when you say kiss,......?"
[cpg cn=true]


Himari looks serious. And she is also the type who does it when she says she will.
[cpg]


;**【ＣＧ】 ev_12_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari014"]
[OnName num="himari"]
“I'm serious. You want me to do it too, don't you Goro?”
[cpg cn=true]


I think it is certainly the most exciting thing. But.
[cpg]


[OnName num="gorou"]
“If I do that, I might not be thrilled by anything other than ...... kissing."
[cpg cn=true]


[VOICE f="sHimari015"]
[OnName num="himari"]
“What do you mean ......?"
[cpg cn=true]


[OnName num="gorou"]
“It's not good to do something like that out of the blue, what if I get used to it.”
[cpg cn=true]


;**【ＣＧ】 ev_12_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari016"]
[OnName num="himari"]
"Hmm. So that's what bothers you.”
[cpg cn=true]


Himari is talking about it like it's someone else's business, but it's a serious problem for me.
[cpg]


[OnName num="gorou"]
“Of course! If I can't get my heart to pound anymore, I'm going to die."
[cpg cn=true]


[VOICE f="sHimari017"]
[OnName num="himari"]
“You should consider it. I'm not going to let you go.”
[cpg cn=true]


Himari seems to be serious. If she doesn't intend to let me escape, then maybe I can't escape.
[cpg]


[OnName num="gorou"]
“Wait, wait. ……"
[cpg cn=true]


Himari was more forceful than me and I was softer compared to Himari .
[cpg]


;**【ＣＧ】 ev_12_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari018"]
[OnName num="himari"]
“I can't wait. Come on, turn your face this way.”
[cpg cn=true]


Saying this, Himari brings her face closer.
[cpg]


Her soft lips also come closer at the same time. They almost touch.
[cpg]


I can smell the good smell. I close my eyes. Himari is right next to me.
[cpg]


As I wait I get mentally ready.
[cpg]


I wait, wait, wait for her lips to touch .......
[cpg]


[OnName num="gorou"]
"...... Huh?"
[cpg cn=true]


I didn't feel any ...... lips against mine as I waited.
[cpg]


Then, just in time, she pulled her face away.
[cpg]


;**【ＣＧ】 ev_12_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari019"]
[OnName num="himari"]
“Heh. Did you feel excited?”
[cpg cn=true]


So that’s what she had meant. I was being lead on.
[cpg]


[OnName num="gorou"]
"Uh-huh..."
[cpg cn=true]


She is indeed like this from the start. I shouldn’t take the things she says too seriously. ......
[cpg]


[VOICE f="sHimari020"]
[OnName num="himari"]
“Then you've achieved your goal.”
[cpg cn=true]


Himari may be a surprisingly cunning person.
[cpg]


Is she simply messing with me? Or is she doing what she wants to do?
[cpg]


I can’t tell, but the heart pounding that I just got was pretty good, so I can't complain......
[cpg]


;**【ＣＧ】 ev_12_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari021"]
[OnName num="himari"]
“Well then, have a good day. Goro, I'm in pain when you're in pain.”
[cpg cn=true]


[OnName num="gorou"]
“Thank you. ......"
[cpg cn=true]


I don't know if "Thank you" is the right response, but I didn't know what else to say.
[cpg]



;//ブラックアウト

But still, I wonder if it's okay to do this in front of Suzune.
[cpg]


Himari doesn’t seem to care, but I was curious.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************


And after doing such a thing with Himari, I was waiting for a cold word from Suzune .
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="sSuzune020"]
[OnName num="suzune"]
“That's really disgusting. Don’t you have any sense of embarrassment?"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari089"]
[OnName num="himari"]
“Heh heh heh. I don't think I have any."
[cpg cn=true]


Actually I did. So I feel like I can't say anything because I'm sorry and embarrassed.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune082"]
[OnName num="suzune"]
"Oh, well, that's okay. I'm leaving now."
[cpg cn=true]


[OnName num="gorou"]
"Have a good day……."
[cpg cn=true]



Suzune always leaves early. We leave after that.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************





And a while later, me and Himari also heading off.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa079"]
[OnName num="sawa"]
“Bye. Off you go.”
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari090"]
[OnName num="himari"]
“See you later!”
[cpg cn=true]


Himari responds cheerfully. I was in no mood to do so.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep003.ks" target="*start"]



;/////////////////////////////////////////////////////////////////////
