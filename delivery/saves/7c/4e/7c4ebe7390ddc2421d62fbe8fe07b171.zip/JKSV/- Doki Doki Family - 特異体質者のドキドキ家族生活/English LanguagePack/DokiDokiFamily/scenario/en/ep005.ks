
*start

;###################################################################
*Ep005|My feelings for Suzune.
;###################################################################


;//１、寿々音
*select04_1|My feelings for Suzune.


[SCENE id=5]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


I guess ...... It’s Suzune .
[cpg]


I think she is the most reliable person. She can be a little aloof sometimes but she is totally different from Himari and Mom .
[cpg]


Himari is the least reliable, and mom is somewhat dreamy.
[cpg]


But that's no reason to fall in love.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



I woke up early and it was just Suzune and I.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune107"]
[OnName num="suzune"]
“Good morning. You're up early today.”
[cpg cn=true]


[OnName num="gorou"]
"Yeah,......, I need to talk to you about something."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune108"]
[OnName num="suzune"]
“What is it? Is it about your condition?”
[cpg cn=true]


I nod and go on to talking.
[cpg]


[OnName num="gorou"]
"I was thinking ...... that if I were to fall in love with someone, you’d be the one……."
[cpg cn=true]


[OnName num="gorou"]
"But if we did that, we'd be married within the family, wouldn't we? So……”
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
I go on and on about what I think. And finally.
[cpg]


[OnName num="gorou"]
“…… what am I supposed to do?"
[cpg cn=true]


I concluded. But Suzune didn't give me a dumbfounded look.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune109"]
[OnName num="suzune"]
“First of all, you have to be with someone you like. It's not good to choose me just because I would accept it.”
[cpg cn=true]


[OnName num="gorou"]
“I guess ...... Yeah, I can see that."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune110"]
[OnName num="suzune"]
“Then you'd better think about who you like. Then we can talk."
[cpg cn=true]


...... I couldn't say anything.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




;//＠
Then I go to Himari to get my heart rate up and I headed off to school.
[cpg]


Somehow, I was getting to the point where I couldn't focus when I was with Himari .
[cpg]


I kept thinking about Suzune .
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************





After some time had passed at the school, it was time to go to Suzune.
[cpg]


Unlike with Himari I was so nervous to see her.
[cpg]



;//ブラックアウト


[window target=false]



[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『学園教室』（昼）******************************************************





An empty classroom. We meet with some kind of awkwardness in the atmosphere.
[cpg]

;//ブラックアウト

;//========================================
;//●ＣＧ（主人公と密着するヒロイン。胸が当たっている）ev_16
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]





Suzune comes close to me. We're in the middle of a school and doing this.
[cpg]


It can't be helped because of my condition. But no matter how much I think about it…..
[cpg]


I don't know that others who see this scene will agree.
[cpg]


And that fact got my heart rate up.
[cpg]


[VOICE f="sSuzune022"]
[OnName num="suzune"]
“Does this make you excited?"
[cpg cn=true]


I'm just very close to her. I'm getting excited because she's very important to me.
[cpg]


It means a lot to me to be able to touch each other and not just have this feeling.
[cpg]


[OnName num="gorou"]
“……"
[cpg cn=true]


I was speechless. Seeing this, Suzune is worried.
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune023"]
[OnName num="suzune"]
“You need to say something to me, I'm getting worried.”
[cpg cn=true]


I finally respond.
[cpg]


[OnName num="gorou"]
“Yes. It’s feels very ...... good."
[cpg cn=true]


;**【ＣＧ】 ev_16_b ***********************
[CG id=7 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune024"]
[OnName num="suzune"]
“Don't tell me it's good. Otherwise I'll be conscious of it.”
[cpg cn=true]


Suzune was cold, but I could tell she was a little embarrassed.
[cpg]


If she is embarrassed, it means that she has feelings towards me.
[cpg]


That made me happy, too. In addition to being happy, I said to her;
[cpg]


[OnName num="gorou"]
“You're blushing.”
[cpg cn=true]


;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune025"]
[OnName num="suzune"]
“You say that, but so are you."
[cpg cn=true]


I've always wanted to be by her side.
[cpg]


I don't need anything else ...... as long as she is here. I feel a little bad for Himari.
[cpg]


Even so, Suzune was irreplaceable for me.
[cpg]


I couldn’t even compare her to anyone else.
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune026"]
[OnName num="suzune"]
“Your body is getting hot. I’m getting nervous too.”
[cpg cn=true]


I couldn't get over the subtle distance between the two of us.
[cpg]


Of course, now I'm getting awfully close physically, but not emotionally.
[cpg]


[OnName num="gorou"]
“I think ...... You’re excited, too Suzune.”
[cpg cn=true]


I noticed that her pulse was quickening.
[cpg]


;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune027"]
[OnName num="suzune"]
“Really? I think it's just you being like that."
[cpg cn=true]


[OnName num="gorou"]
“I don't think so. ...... or is it just my imagination?”
[cpg cn=true]


[VOICE f="sSuzune028"]
[OnName num="suzune"]
“It's just your imagination."
[cpg cn=true]


Did my words mean something to her? That's what I thought as we were together ......
[cpg]


It's just the two of us in this world, or so the saying goes, but this is a school.
[cpg]


I can hear the voices of other students just outside. There was something about the fact that we weren't alone that made it exciting.
[cpg]


Suzune who made me feel this way is irreplaceable.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


It is during the daytime that Suzune and I touch each other.
[cpg]


In the evening, it's mom. In the morning, it's Himari . Such days had been going on for a long time, and it would not change for a while.
[cpg]


[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





The next morning. I walk to the school and meet up with a girl on the way.
[cpg]


[OnName num="female_student"]
"Good morning, Kosaka ."
[cpg cn=true]


[OnName num="gorou"]
“Oh, good morning. ……"
[cpg cn=true]


[OnName num="female_student"]
“I've noticed you seem a little different lately. I don't know how to explain it, but it’s like a melancholy ......"
[cpg cn=true]


[OnName num="gorou"]
"What, ……? What are you talking about?"
[cpg cn=true]


[OnName num="female_student"]
“Oh, nothing! See you then."
[cpg cn=true]


...... She left quickly leaving me to think that she probably has a thing for me too.
[cpg]


I have such feelings for a girl as well.
[cpg]


But it's not the same when I think about spending the rest of my life with her.
[cpg]


Looking back, I've been going after Suzune for a long time.
[cpg]


I've always admired her. I was reminded of that.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


Then it was noon again, and my time with Suzune arrived.
[cpg]

[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[OnName num="gorou"]
"......Please. It's already hard for me. ......"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune130"]
[OnName num="suzune"]
“It must be hard for you. It would be hard for me, too, if I were in your shoes."
[cpg cn=true]


...... That sounded strange. If she were in my shoes?
[cpg]


[OnName num="gorou"]
“What do you mean ......?"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune029"]
[OnName num="suzune"]
“It's nothing. More importantly, what should we do today?"
[cpg cn=true]


She changes the subject. I'm still having a hard time breathing.
[cpg]



I can't think of things that are unimportant. Hmmm.
[cpg]


[OnName num="gorou"]
“Okay then.……"
[cpg cn=true]


;//========================================
;//●ＣＧ（座っているヒロインのことを見つめる主人公）ev_17
;//人物１：ヒロイン１
;//服装１：スーツ（はだけ）
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


I had come up with something that wasn't the same as before, and I decided to give it a shot.
[cpg]


Suzune seems a little uninterested, but I like her facial expression.
[cpg]


[VOICE f="Suzune134"]
[OnName num="suzune"]
“……, you come up with the strangest things."
[cpg cn=true]


Today, I'm not going to have Suzune touch me or get close to me.
[cpg]


I want to watch her. I had asked her if I could do that.
[cpg]


[OnName num="gorou"]
“It's not strange. I want to watch you at all times.”
[cpg cn=true]


My words seem to confuse Suzune a bit.
[cpg]


;**【ＣＧ】 ev_17_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune030"]
[OnName num="suzune"]
“I mean, is that really what you want to do, just watch?"
[cpg cn=true]


[VOICE f="sSuzune031"]
[OnName num="suzune"]
“I think you need to ...... touch or get close to me or something."
[cpg cn=true]


I can be excited enough without that. The current me probably can.
[cpg]


[OnName num="gorou"]
“…… yeah."
[cpg cn=true]


Looking at her, she is everything I need.
[cpg]


I'm too embarrassed to say that, but I think it’s okay to think that.
[cpg]


;**【ＣＧ】 ev_17_b ***********************
[CG id=8 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune032"]
[OnName num="suzune"]
“The way you look at me Goro, is kind of dirty.”
[cpg cn=true]


[OnName num="gorou"]
"Yeah, I guess so."
[cpg cn=true]


Suzune is puzzled and embarrassed at the same time.
[cpg]


Maybe being stared at provokes a certain feeling.
[cpg]


[OnName num="gorou"]
“Suzune ...... You’re really, really beautiful."
[cpg cn=true]


Suzune was looking at me, but now she is looking away.
[cpg]


;**【ＣＧ】 ev_17_c ***********************
[CG id=8 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune033"]
[OnName num="suzune"]
“How can you say that?”
[cpg cn=true]


[OnName num="gorou"]
“I'm not lying. I mean it.”
[cpg cn=true]


She seems to shake a little hearing my words.
[cpg]


[VOICE f="sSuzune034"]
[OnName num="suzune"]
“You’re not even touching me. This is strange, I'm feeling nervous too.”
[cpg cn=true]


Suzune says, and her face reddens.
[cpg]


I couldn't just look at her like that.
[cpg]


[OnName num="gorou"]
“I want to keep staring at you, Suzune”
[cpg cn=true]


Suzune, still embarrassed says;
[cpg]


;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune035"]
[OnName num="suzune"]
“It's as if ...... You words are touching me.”
[cpg cn=true]


She probably meant what she said.
[cpg]


As proof, Suzune's ears turned red.
[cpg]


I wanted to observe everything. That’s how I felt.
[cpg]


Suzune accepts everything I say and do.
[cpg]


I felt there was something maternal about her.
[cpg]


[OnName num="gorou"]
“I'm just looking at you, but I'm happy."
[cpg cn=true]


;**【ＣＧ】 ev_17_c ***********************
[CG id=8 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune036"]
[OnName num="suzune"]
“Don't say that. I feel embarrassed although I'm flattered."
[cpg cn=true]


Suzune certainly looked both shy and happy.
[cpg]


Just by looking at her reactions I feel happy.
[cpg]


[FG f="ci_lbox.ui" method="feadin_up"  pos="4/7"]

[WAIT time=1000]
;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】『学園のチャイム』


Some time passes. We can't be with each other forever.
[cpg]


After lunch break, both Suzune and I have to go to class.
[cpg]


This time was more frustrating than ever.
[cpg]





[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


And then afternoon classes were over and school ended.
[cpg]


[window target=false]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



School at the evening. I leave the classroom and decide to go back home.
[cpg]


I had a thought.
[cpg]


......Three times a day, I have time to get my heart to pound.
[cpg]


I had come to want to spend all of it with Suzune.
[cpg]


I'd have to talk to mom first.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************





When I got home, mom was the only one there.
[cpg]


[OnName num="gorou"]
"Oh, you know, ...... Mom ."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa101"]
[OnName num="sawa"]
“What is it? It's a little early for you, isn't it?”
[cpg cn=true]


[OnName num="gorou"]
“Umm... I was hoping you could replace the night shifts with Suzune."
[cpg cn=true]


I explained everything. Except for the part that I was fond of her.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa102"]
[OnName num="sawa"]
"......, yes. I see.”
[cpg cn=true]


But Mom seemed to have it all figured out. In the end she’s my Mom so ......
[cpg]




;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[WAIT time=1000]

[SE f="se012"]
;//【ＳＥ】『ノック』


[WAIT time=1500]

[window target=true]


;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune151"]
[OnName num="suzune"]
"I'm coming in, Goro ."
[cpg cn=true]


[OnName num="gorou"]
“Uh, yeah, come on in ......."
[cpg cn=true]


[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune037"]
[OnName num="suzune"]
“I heard from mom that you want me instead of mom at night?”
[cpg cn=true]


[OnName num="gorou"]
“Do you think it’s wrong…… I want it to be this way.”
[cpg cn=true]


Somehow, I had a feeling that she would not say no.
[cpg]


Then Suzune sighed a little and said;
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune153"]
[OnName num="suzune"]
“Do you think I could say no if you told me that? Really, you’re my sweet little brother."
[cpg cn=true]



;//========================================
;//●ＣＧ（密着する二人。ヒロインが体を前に倒している状態。ヒロインの髪が主人公の体に当たっている）ev_18
;//人物１：ヒロイン１
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：主人公の部屋
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]


[SE f="se004"]
;//【ＳＥ】『衣擦れ』


[BGM f="bg_h1"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune038"]
[OnName num="suzune"]
“Maybe ...... I've gone crazy too."
[cpg cn=true]


She says this with a slightly clouded expression, or rather, a melancholy look in her eyes.
[cpg]


[OnName num="gorou"]
“What do you mean by that?"
[cpg cn=true]


Suzune is choosing her words carefully. I felt like she is thinking of what to say.
[cpg]


[VOICE f="sSuzune039"]
[OnName num="suzune"]
“Without you, I feel as if my heart is in pain.”
[cpg cn=true]


...... How should I respond to that?
[cpg]


It seemed like she really meant what she said.
[cpg]


Of course I'm suffering from my condition, but I couldn’t imagine that Suzune would be affected by that.
[cpg]


[VOICE f="sSuzune040"]
[OnName num="suzune"]
“I just want to be closer to you. I don't know why.”
[cpg cn=true]


Suzune’s long hair is hitting my body. I feel frustrated.
[cpg]


[OnName num="gorou"]
“Suzune. Your hair tickles me.”
[cpg cn=true]


I dared to say it, though I'm sure she didn't even notice. Then.
[cpg]


;**【ＣＧ】 ev_18_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune041"]
[OnName num="suzune"]
“Really? You don't like it?"
[cpg cn=true]


She says something that makes it even harder for me to escape.
[cpg]


[OnName num="gorou"]
“...... I don't hate it.”
[cpg cn=true]


[VOICE f="sSuzune042"]
[OnName num="suzune"]
“Then that’s fine. Let me stay like this a little longer."
[cpg cn=true]


Suzune is being aggressive. I don't feel like she is trying to make me feel nervous.
[cpg]


At first everything was for my health’s sake, but this has nothing to do with the condition.
[cpg]


I feel like we've come to a point where we shouldn't have.
[cpg]


But even so, I don't hate it.
[cpg]


[OnName num="gorou"]
“Yeah. We can stay here as long as you want to."
[cpg cn=true]


;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune043"]
[OnName num="suzune"]
“That's doesn’t seem right. I'm doing this for your condition.”
[cpg cn=true]


But I feel like that's an excuse, or our common escape route.
[cpg]


What will we do when this condition is cured?
[cpg]


[VOICE f="sSuzune044"]
[OnName num="suzune"]
“You smell nice Goro."
[cpg cn=true]


The reverse is also true. We’re that close.
[cpg]


It's as if not only our bodies but also our minds have become closer.
[cpg]


;**【ＣＧ】 ev_18_b ***********************
[CG id=9 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune045"]
[OnName num="suzune"]
“It's strange. We are always together, but you seem like a different person.”
[cpg cn=true]


As she says this, she moves closer. Her breath hits me.
[cpg]


I wish time would stop. I feel relaxed with my heart pounding like this......
[cpg]


It sounds contradictory to say "relaxed by my heart pounding," but it seemed to be the right expression.
[cpg]


I'm sure it's something that a couple of half-hearted lovers wouldn't be able to feel.
[cpg]


;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune046"]
[OnName num="suzune"]
“I want to be with you more. But I'm worried about you, too.”
[cpg cn=true]


Even though Suzune and I are not blood related, we are also siblings.
[cpg]


I'm sure that's part of the reason of why I felt safe with her.
[cpg]


[VOICE f="sSuzune047"]
[OnName num="suzune"]
“If doing this would make me feel any better, I would ...... do it all the time.”
[cpg cn=true]


Suzune was coming close to me as she said this.
[cpg]


[OnName num="gorou"]
“I’m happy, Suzune "
[cpg cn=true]


Her words seem too precious for me, but that doesn't mean I would want to give them to someone else.
[cpg]


I want Suzune to be mine.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]



[OnName num="gorou"]
“Thank you. I'm fine now.”
[cpg cn=true]


Breathing is not painful at all anymore. But my heart was suffering a little.
[cpg]


It's as if my body and mind are at odds with each other.
[cpg]


[VOICE f="sSuzune048"]
[OnName num="suzune"]
"Is that so? You should take it easy."
[cpg cn=true]


I really wish I could go to bed with her, but if I did, I might get used to the heart pound.
[cpg]



[window target=false]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




I didn't feel like I was going to wake up with the usual, strange dreams.
[cpg]


Maybe it was the feeling of fulfillment that I was given by her.
[cpg]


I didn't feel lonely, even in a room by myself. ......
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



It is morning. Now I have to talk to Himari .
[cpg]


I thought I should have done that yesterday, but…
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari026"]
[OnName num="himari"]
“Good morning. I'm going to make you excited again today."
[cpg cn=true]


Himari comes up to me.
[cpg]


She has her big breasts pressed up against me, but I didn't let them distract me.
[cpg]


[OnName num="gorou"]
"You know, ...... I'm sorry that you always have to do this for me but,……”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari117"]
[OnName num="himari"]
“What? Are you saying you want me to switch places with my sister?"
[cpg cn=true]


[OnName num="gorou"]
“Huh ……"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Himari118"]
[OnName num="himari"]
“I've heard most of it from mother. You really like my sister that much, don't you?"
[cpg cn=true]


Himari looks a little sad.
[cpg]


That......moved me.
[cpg]


This is not good. Being half-hearted would hurt Himari.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune170"]
[OnName num="suzune"]
“...... Should I do it in the morning too? I’ll be helping you three times a day.”
[cpg cn=true]


[OnName num="gorou"]
“Is that bad?”
[cpg cn=true]


Suzune laughs a little. I must have looked like an idiot.
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune049"]
[OnName num="suzune"]
“No. Then ......."
[cpg cn=true]


;//ブラックアウト

;//========================================
;//●ＣＧ（主人公に寄り添うヒロイン。朝出かける前）ev_19
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



Words were not needed in this situation but I felt like it was wrong if I didn’t say anything.
[cpg]


[OnName num="gorou"]
“It's warm, Suzune "
[cpg cn=true]


Suzanne looks at me. Then she asks me this.
[cpg]


[VOICE f="sSuzune050"]
[OnName num="suzune"]
"...... you don’t feel excited from only being around me anymore?"
[cpg cn=true]


[OnName num="gorou"]
“No, that’s not true.”
[cpg cn=true]


[VOICE f="sSuzune051"]
[OnName num="suzune"]
“Are you sure you're not just saying that to please me?”
[cpg cn=true]


[OnName num="gorou"]
“It's true. Please don’t make that painful expression.”
[cpg cn=true]


[VOICE f="sSuzune052"]
[OnName num="suzune"]
“Are you sure? I hope it’s true.”
[cpg cn=true]


Suzune leans in close to me as she says this.
[cpg]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[VOICE f="sSuzune053"]
[OnName num="suzune"]
“I’m interested in nothing else but you...... Goro.” she says. “I'm sorry I accused you.”
[cpg cn=true]


Her soft touch. With only that my heart is pounding.
[cpg]


I wanted to be closer to her. My desire didn't stop there.
[cpg]


I wanted to be……her lover.
[cpg]


[OnName num="gorou"]
“Sis. Um, well..."
[cpg cn=true]


I was about to say something but Suzune had thoughts of her own.
[cpg]


;**【ＣＧ】 ev_19_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune054"]
[OnName num="suzune"]
“I'm also very nervous, ...... Can you sense it?”
[cpg cn=true]


[OnName num="gorou"]
“Yes. I can feel it.”
[cpg cn=true]


The less aggressive I am, the closer Suzune seems to get.
[cpg]


The relationship is somehow reassuring in a way that is different from the pounding of the heart.
[cpg]


;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune055"]
[OnName num="suzune"]
“Huh, this is kind of embarrassing."
[cpg cn=true]


We talk about such things as we spend time together.
[cpg]


[OnName num="gorou"]
“This might be embarrassing but……I want to stay by your side."
[cpg cn=true]


[VOICE f="sSuzune056"]
[OnName num="suzune"]
“Yes. Same for me."
[cpg cn=true]


Suzune is closer to me than anyone else, but I still felt frustrated.
[cpg]


[VOICE f="sSuzune057"]
[OnName num="suzune"]
“Goro ......"
[cpg cn=true]


Suzune strokes my head, whispering.
[cpg]


She is stroking my hair. Her face gets closer.
[cpg]


And her lips are getting close. I quickly close my eyes.
[cpg]


There is almost no distance between us. Everything moves quickly, I don’t know what to do.
[cpg]


;**【ＣＧ】 ev_19_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune058"]
[OnName num="suzune"]
“Mwah."
[cpg cn=true]


Our lips touch each other. She takes a step toward me.
[cpg]


I love her so much that I feel like I'm going crazy. Words cannot explain how much I love her.
[cpg]


I don't know anyone that I can love this much. I feel like I want to hug her right now.
[cpg]


It’s hard to stop, but we can't stay like this forever.
[cpg]


;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune059"]
[OnName num="suzune"]
“It’s time. I have to go."
[cpg cn=true]


Suzune says while I’m still somewhat paralyzed.
[cpg]


I cursed myself for my helplessness, but I was glad she kissed me.
[cpg]


[OnName num="gorou"]
“Have a good day.”
[cpg cn=true]


I don't think I will forget the feeling of her lips for a while.
[cpg]


Maybe not for a while, but probably never.
[cpg]


;//ブラックアウト



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


Then, Suzune leaves the house before me.
[cpg]


It was the usual thing, but the loneliness felt different than usual.
[cpg]


I will see her when I go to the school, but I miss her so much.
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa103"]
[OnName num="sawa"]
“Bye. Be careful.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah. I'm heading out"
[cpg cn=true]


Himari and I leave the house. I had a secret in my heart.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************



I am going to confess my feelings to Suzune. I want to be with her.
[cpg]


She is an irreplaceable sister, but I still want to be with her.
[cpg]


I want to kiss Suzune and hug her.
[cpg]


Even if this condition was cured.
[cpg]


I’d still want to be with Suzune .
[cpg]


I can say that I owe Himari in that sense. If she hadn't told me, I might have never realized it.
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

During the day, as usual, I ask Suzune to get my heart rate up. But then ...... after school.
[cpg]

[WAIT time=1000]

[STOPBGM]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（夕方）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune190"]
[OnName num="suzune"]
“Now what ……? We already did that during lunch.”
[cpg cn=true]


[OnName num="gorou"]
“...... Suzune, you said I should be with someone I like.”
[cpg cn=true]


Suzune hardens her expression a little. Maybe she is imagining what I am going to say.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune191"]
[OnName num="suzune"]
“...... what about it?”
[cpg cn=true]


I still have to say it. I can't let her guess what I'm thinking.
[cpg]


If I'm spoiled with such a thing, I'll really be spoiled for the rest of my life.
[cpg]


[OnName num="gorou"]
"Oh, I ...... am, that ……"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune192"]
[OnName num="suzune"]
“I know. You like me, don't you?"
[cpg cn=true]


Oh no. This might spoil me for the rest of my life.
[cpg]


But I can't help it now. I've said my piece.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune193"]
[OnName num="suzune"]
“Don't worry, I like you too. Not as a brother, but as a lover.”
[cpg cn=true]




;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



Me and Suzune are leaving separately. We have different jobs and schoolwork, and different hours that we devote to them.
[cpg]


However, I felt that I wanted to go home with her at least for today.
[cpg]


In the end, Suzune told me to go home on my own,…… Making me long for her even more.
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





There was nothing unusual at the dinner table that day.
[cpg]


I was the same as usual. Suzune was the same as usual.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari119"]
[OnName num="himari"]
“I’d like another portion of rice. Maybe a little more than half of the rice bowl!”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune194"]
[OnName num="suzune"]
“You'll get fat."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Himari120"]
[OnName num="himari"]
“Unlike you sister, I use up calories quite easily.”
[cpg cn=true]


Suzune is quite skinny yet Himari says such things.
[cpg]


But Suzune doesn’t seem to care. Or rather, she seemed like she was deep in thought……
[cpg]


I wonder if she's thinking about me……
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





At night, Suzune came to my room.
[cpg]


[OnName num="gorou"]
“Uh, uh, ...... How are you?”
[cpg cn=true]


One of the three times a day I raise my heart rate. And yet, I feel awfully nervous.
[cpg]


In the midst of all this, my sister said to me;
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune060"]
[OnName num="suzune"]
“I have to tell you, I've never had a boyfriend.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah, ......."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune061"]
[OnName num="suzune"]
“I mean you're the first one."
[cpg cn=true]


With that said, Suzune moved closer.
[cpg]


;//移植前シーンカット
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]



[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

When I am with her, I feel a sense of deeper fulfillment.
[cpg]


This is probably something inherent, rather than connected with my condition.
[cpg]


I am excited. Even after Suzune left I couldn’t sleep.
[cpg]


I want her to stay with me forever. But Suzune left the room.
[cpg]


It can't be helped. It would be bad if Dad saw her coming out of my room.
[cpg]


I have no choice but to wait for tomorrow.
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



Tomorrow came and I felt awkward.
[cpg]


I never thought I would feel like this. I couldn’t believe that Suzune and I had developed a relationship.
[cpg]


It feels like she’s a different person now, or maybe I'm the one who has changed.
[cpg]


Thinking this, I see Suzune off.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune213"]
[OnName num="suzune"]
“I'm going to go now Goro and Himari.”
[cpg cn=true]


[OnName num="gorou"]
“Yes. Be careful."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari121"]
[OnName num="himari"]
“Have a good day."
[cpg cn=true]

[free time=1000]
Dad also left the house. Only three of us were left. Himari, mom and me.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Sawa104"]
[OnName num="sawa"]
“So what are you going to do? Are you going to go out with Suzune?”
[cpg cn=true]


[OnName num="gorou"]
"Yeah. ......umm. That's the plan.”
[cpg cn=true]


For a moment I was puzzled, but I was able to answer.
[cpg]


I couldn't hide it any longer.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Himari122"]
[OnName num="himari"]
“You seem happy. I liked you too.”
[cpg cn=true]


[OnName num="gorou"]
“...... yea.”
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』





An empty classroom .
[cpg]


I have trouble breathing and I feel wobbly, but I was face to face with Suzune .
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune214"]
[OnName num="suzune"]
“...... I didn't want to do it just because of your condition."
[cpg cn=true]


She tells me this as she approaches me.
[cpg]


I guess she was worried because she was thinking of me. I can sort of imagine that.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune215"]
[OnName num="suzune"]
“Besides, I couldn't help but feel jealous while Himari and mom were dealing with you."
[cpg cn=true]


[OnName num="gorou"]
“...... Oh I didn’t know.”
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune062"]
[OnName num="suzune"]
“It doesn’t matter now. I'll fulfill everything for you."
[cpg cn=true]


Yes. Everything was up to me now.
[cpg]


I felt rather comfortable with that.
[cpg]


;//移植前シーンカット



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

From now on, I can stay with her forever. Just thinking that made me feel relieved.
[cpg]


[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************



At the same time that I was relieved, my desire for my heart pounding was getting stronger.
[cpg]


It was really just a small time gap, but I couldn't take it anymore.
[cpg]


I couldn't stand it anymore. But Suzune said it was night and left.
[cpg]


To begin with, the change from Mom to Suzune meant that I wouldn't be able to see anyone as soon as I got home.
[cpg]


I was walking while carrying this unbearable feeling......
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





Dinner time. The situation is that only Dad doesn’t know about the relationship between Suzune and I.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari123"]
[OnName num="himari"]
“So how far did you go with my sister Goro?”
[cpg cn=true]


In the midst of dinner, Himari asks. I almost spit out what I was eating.
[cpg]


[free time=1000]

[OnName num="father"]
“What are you talking about?"
[cpg cn=true]


[OnName num="gorou"]
Nothing. Nothing much.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]

With that said, Suzune seemed a bit grumpy.
[cpg]


Yeah, I'll have to explain that to Dad sometime.
[cpg]


He’s not a strict and stubborn father by any means, but ......
[cpg]


It made me nervous. I felt somewhat anxious when I thought about having to tell dad.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





And night after night. Before I would reach my limit, Suzune came to my room.
[cpg]



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune063"]
[OnName num="suzune"]
“You look so happy.”
[cpg cn=true]


[OnName num="gorou"]
“...... Is it that obvious?”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune064"]
[OnName num="suzune"]
“Of course. But you're cute in that way, too."
[cpg cn=true]


I was embarrassed, but waited to see what Suzune would do.
[cpg]


I don't know, but we've been doing this a lot. I feel like I should be the one to take the lead.
[cpg]

;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I watch Suzune go back to her room again, and although in agony I manage to fall asleep.
[cpg]


Tomorrow, we will still be lovers. I'm happy. ......
[cpg]


Although I should be happy, my body condition makes me feel somewhat constricted.
[cpg]


I have to do something about it. I guess I need to be more do things that lovers would do.
[cpg]


It seems like ……a tunnel without an end, but I'll have to explain it to Dad .
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


And the day came surprisingly quickly.
[cpg]

[window target=false]

[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************





[OnName num="gorou"]
“I can’t! I'm not ready."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune253"]
[OnName num="suzune"]
“He’s in a good mood today. Not that he’s always in a bad mood."
[cpg cn=true]


;//＠
One Sunday. I was approached with the idea.
[cpg]


I’m going to say to Dad; “Please give me your daughter!”
[cpg]


;//ブラックアウト


[window target=false]

[STOPBGM]

[free time=1000]

[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



Himari and Mom are not here. It's dad, Suzune and me.
[cpg]


[OnName num="father"]
“……”
[cpg cn=true]


[OnName num="gorou"]
“……”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune254"]
[OnName num="suzune"]
“So umm...... Can you start Goro?”
[cpg cn=true]

Dad did not have a stern face, but his expression was close to expressionless and somewhat scary.
[cpg]


[OnName num="gorou"]
"Mmm, please give your daughter to ...... me."
[cpg cn=true]


[OnName num="father"]
“……"
[cpg cn=true]


The moment I said that, I thought I saw a smile on the corner of dad 's mouth.
[cpg]


[OnName num="gorou"]
“Well, I want to go out with Suzune ...... or rather, we are going out."
[cpg cn=true]


[OnName num="father"]
“Pfft, ha ha ha! Oh well, I knew this day would come."
[cpg cn=true]


[OnName num="gorou"]
“What? ......?"
[cpg cn=true]


Dad’s reaction was surprising. I had expected that they would be confused as well.
[cpg]


[OnName num="father"]
“In that case I want you to take care of Suzune. Goro I'm sure you’re the right one."
[cpg cn=true]


He smiles and congratulates us.
[cpg]


What a great Dad I thought, and of course I was ...... grateful, so...
[cpg]


[OnName num="gorou"]
“Oh, thank you very much ......."
[cpg cn=true]


I say. I had never used polite language with dad.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[OnName num="gorou"]
"...... that went well."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune255"]
[OnName num="suzune"]
“I guess so. I thought he sort of already knew.”
[cpg cn=true]


They were indeed father and daughter.
[cpg]


I don't understand all of Dad 's feelings, but Suzune seemed to understand.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune256"]
[OnName num="suzune"]
“It's almost time to go. It's hard, isn't it?”
[cpg cn=true]


[OnName num="gorou"]
“Yeah ...... it's hard."
[cpg cn=true]


My condition is still not cured. I'm pretty sure I'm in love, but it will take a little longer for it to cure my condition.”
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune065"]
[OnName num="suzune"]
“Come. This time I want you to make me excited."
[cpg cn=true]


[OnName num="gorou"]
"I'll try ......."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune258"]
[OnName num="suzune"]
She giggles. “You've grown up enough to say that."
[cpg cn=true]


She pats me on the head. I feel embarrassed.
[cpg]

;//移植前シーンカット

;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************




Days passed. It's summer vacation, which is good.
[cpg]


There were rumors going around school that Suzune and I were in love.
[cpg]


Summer vacation ended while the rumors were still going on.
[cpg]


It became a big news in the school. Countless boys were shocked by it, as well as some of the girls ......
[cpg]



[window target=false]

[STOPBGM]

[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]


[window target=true]


;//【ＢＧ】『街』（夜）******************************************************



Still, the days flow by. I wanted to appear as someone worthy of being Suzune’s lover.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune066"]
[OnName num="suzune"]
“...... Is it still hard sometimes?”
[cpg cn=true]


[OnName num="gorou"]
“No, it’s much easier now.”
[cpg cn=true]


Since then, my condition has calmed down as if nothing had happened.
[cpg]


I thought what the doctor had suggested was a joke, but it was absolutely true.
[cpg]


I wondered if I could categorize it as merely a “condition”, but me and Suzune didn't have to get closer than we already were.
[cpg]


That doesn't change the fact that we still want each other, though.
[cpg]


[OnName num="gorou"]
“Those days seem like far in the past.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune278"]
[OnName num="suzune"]
“I agree. Those days were fun, but..."
[cpg cn=true]


[OnName num="gorou"]
“Is it you now that can’t stand it sister?”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune279"]
[OnName num="suzune"]
“I'm really hoping you'll stop calling me ‘sister’."
[cpg cn=true]


[OnName num="gorou"]
“Well, that's ......."
[cpg cn=true]


Surely, it's about time I fixed that.
[cpg]


[OnName num="gorou"]
But what can you do about something that's become so entrenched?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune067"]
[OnName num="suzune"]
“What if we have a child? Are you still going to refer to me as ‘sister’?"
[cpg cn=true]


[OnName num="gorou"]
“I'll call you mother then."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune281"]
[OnName num="suzune"]
“You're getting cheekier with your responses…….”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune068"]
[OnName num="suzune"]
“I wish I could stay with you all day. We don't have to hide it from anyone anymore."
[cpg cn=true]


[OnName num="gorou"]
“Yeah……wait."
[cpg cn=true]


Suzune started stroking my hair. I wriggle because it felt ticklish.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune069"]
[OnName num="suzune"]
“What?"
[cpg cn=true]


[OnName num="gorou"]
“That tickles. Ha-ha-ha-ha.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune070"]
[OnName num="suzune"]
“I wonder if you have a weakness for being tickled? Shall I tickle you more?”
[cpg cn=true]


We were flirting.


[window target=false]

[SE f="se000"]
;//【ＳＥ】『ノック』

[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




In the midst of all this, there was a knock on the door of my room.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari124"]
[OnName num="himari"]
"Hey brother, are my comic books here?”
[cpg cn=true]


[OnName num="gorou"]
“Oh, Himari ……? I don't know.”
[cpg cn=true]


It is quite late at night. At this hour, talking about comic books?
[cpg]


I guessed. She was implying that we were being too loud.
[cpg]


[OnName num="gorou"]
"...... Were we loud?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari125"]
[OnName num="himari"]
“What? More importantly, what about the comic books?"
[cpg cn=true]


[OnName num="gorou"]
“Oh, um, I don't think I borrowed them.……"
[cpg cn=true]


Suzune reads the room and stays quiet. But
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari126"]
[OnName num="himari"]
“Hmmm. Well, I wish you all the best then."
[cpg cn=true]

[free time=1000]

Himari says. I guess we were still too loud.
[cpg]


[OnName num="gorou"]
"...... what should we do, Suzune?”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune299"]
[OnName num="suzune"]
“Don't worry about it. She said ‘I wish you all the best’.”
[cpg cn=true]


That's true, but I think it's ...... sarcasm.
[cpg]


;//＠なんて思いつつ、俺達はもう一度交わることにした。




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


More time passes. My condition has calmed down completely and I no longer have to go to the hospital.
[cpg]


They asked me to explain what had happened, but I was just embarrassed.
[cpg]


I wish I could have had Suzune beside me. I thought.
[cpg]


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************



Time passes. One holiday, I was walking with Suzune .
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune316"]
[OnName num="suzune"]
"It's convenient that we can live in the same house after we get married.”
[cpg cn=true]


[OnName num="gorou"]
“Oh, that's for sure. There's nothing to think about, is there?"
[cpg cn=true]


What a conversation, our relationship was a little different again.
[cpg]


Suzune was pregnant with a baby. Apparently it's a girl, and we've already thought of a name.
[cpg]


[OnName num="gorou"]
"Well, ...... I don't know what I'm going to do about it. I'm still trying to decide if I want to go on to higher education."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune317"]
[OnName num="suzune"]
“I told you before. Keep going to school.”
[cpg cn=true]


[OnName num="gorou"]
“But it’ll be hard for you. I’d better hurry up and get a job."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune318"]
[OnName num="suzune"]
“You should prioritize what you want to do. It's not like you're being spoiled, you can count on me."
[cpg cn=true]


I decided to accept her support.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_01_2_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune071"]
[OnName num="suzune"]
“Anyway, do you remember what day it is today?”
[cpg cn=true]


[OnName num="gorou"]
“Let's see, ...... what was it? ……"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune072"]
[OnName num="suzune"]
“You don't remember? It’s when we started dating.”
[cpg cn=true]


[OnName num="gorou"]
“I don't remember the day we started dating..……it was never really clear to me.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune073"]
[OnName num="suzune"]
“I know it's a little fuzzy, but I still want to celebrate.”
[cpg cn=true]


[OnName num="gorou"]
“I don't know if that's how it works.”
[cpg cn=true]



[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune074"]
[OnName num="suzune"]
“You're so dull like that, Goro ."
[cpg cn=true]


[OnName num="gorou"]
“I mean, the date's a little fuzzy, but I've always wanted to celebrate, too."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune075"]
[OnName num="suzune"]
“What?”
[cpg cn=true]


[OnName num="gorou"]
“I have a present for you. Shall we open it when we get home?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune076"]
[OnName num="suzune"]
“Thank you ......."
[cpg cn=true]



[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


After the baby was born, we were really busy.
[cpg]


I'm a student, but I'm also a househusband, and I had to raise the baby.
[cpg]


But I don't think it's hard work. It didn’t feel forced.
[cpg]


That's how fast-paced and lovely the days passed next to Suzune.
[cpg]



Time flies. Three years passed.
[cpg]




;//========================================
;//●ＣＧ（街を三人で歩く。幸せそうなヒロインと娘の笑顔が正面から見えるアングル）ev_26
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//人物３：主人公の娘
;//服装３：私服
;//場所　：街
;//時間　：昼
;//備考　：娘の年齢は三歳くらいです。また、本編から三年の時間が経過しています
;//========================================




[BGM f="bg_h1"]
;**【ＣＧ】 ev_26_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]




We became a happy couple, I think.
[cpg]


We didn't fight even once with each other. We don't have that kind of a relationship.
[cpg]


People around us envy us, but this was natural.
[cpg]


I don't want to fight now. We've been together longer than most couples.
[cpg]


We knew each other better than any couple who have known each other since childhood.
[cpg]


[VOICE f="Suzune319"]
[OnName num="suzune"]
"Hey, Goro ."
[cpg cn=true]


Suzune turns to me and smiles.
[cpg]


[OnName num="gorou"]
"What's up, Suzune?"
[cpg cn=true]


[VOICE f="Suzune320"]
[OnName num="suzune"]
“I'm so happy. I still can't believe I can live this happy life as your wife"
[cpg cn=true]


...... That's because she’s been a sister for longer. It can't be helped.
[cpg]


But now we'll be spending more time together as a married couple.
[cpg]


I'll have to outgrow being her brother soon. Somewhere I still think of Suzune as a big sister.
[cpg]


;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

And by the time I graduate from being Suzune's brother, my daughter might have a sister or a brother.
[cpg]


With that thought in mind, we began our journey together.
[cpg]



[SCENE id=9]

[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン１ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

