

*start

;###################################################################
*Ep001|The Start of the Heart Pounding Management
;###################################################################

;//ブラックアウト
[SCENE id=1]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]

[SE f="se002"]
;//【ＳＥ】『喧噪』

[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="female_student_A"]
“Something about him….. Kosaka, feels different."
[cpg cn=true]


[OnName num="female_student_B"]
“Yes. He used to be just a introvert, but now he's...... melancholic."
[cpg cn=true]


I can hear you, is what I thought as I was listening to the whispers.
[cpg]


It felt good that people weren’t saying anything bad about me. But...
[cpg]


If it's because of my condition, then I don't know what to say.
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************




By noon, it gets harder. My head is filled with the need to pound.
[cpg]



I can't focus in the last class of the morning.
[cpg]


I'm having trouble breathing and I can't think of anything else.
[cpg]


I'm going crazy, I could really die of Dokidoki Dependence.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune038"]
[OnName num="suzune"]
“It's around the time, when you're feeling the pain, right?”
[cpg cn=true]


[OnName num="gorou"]
“Oh, please. I can't stand it anymore, I can't ......"
[cpg cn=true]


Weak words come out of my mouth. But I can't help it.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune039"]
[OnName num="suzune"]
“It's okay. Come here.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植前シーンカット

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_03_2_up.ui" time=1000]
[WAIT time=1000]

I follow her to the Student Guidance Office.
[cpg]


I wonder what she would do to me this time.
[cpg]


In the end… it was just the same thing that happened the other day, but that was okay.
[cpg]


I understood Suzune's concern for not overstimulating me.
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



Heart Pounding Management. Three times a day to get my heart rate up ......
[cpg]


It's a pretty bizarre situation, but that's the kind of situation I was in.
[cpg]


Three times a day is not enough. I'd like it to be twice as much.
[cpg]


But we can't just touch each other endlessly. We might cross the line.
[cpg]


Is there such a thing? There is a person extremely attractive and approaching me.
[cpg]


I can't do what I want. They are managing me wherever I go.
[cpg]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（夕方）******************************************************





[OnName num="male_student_A"]
"I heard that he went into the Student Guidance Office with Ms. Kosaka.”
[cpg cn=true]


[OnName num="male_student_B"]
“What happened? And what did you do?"
[cpg cn=true]


It is natural to be questioned like that.
[cpg]


But I can't answer anything.
[cpg]


[OnName num="gorou"]
"It's career advice. ...... It's nothing to worry about."
[cpg cn=true]


[OnName num="male_student_A"]
“Stop lying……there’s talk that you came out of the room flustered."
[cpg cn=true]


That's how far the rumors got. I'll have to be careful when I leave next time.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夕方）******************************************************





Ah. I can't wait to go home.
[cpg]


Now it's Mom's turn. I can't stand it anymore…
[cpg]


I suffer so much.
[cpg]


I can't take classes properly, of course, and I can't even converse with my classmates.
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』


[OnName num="gorou"]
“I'm home. ……"
[cpg cn=true]




[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa003"]
[OnName num="sawa"]
“Welcome back. Are you having a hard time?"
[cpg cn=true]


[OnName num="gorou"]
“What? No, well, it's ......"
[cpg cn=true]


I didn't answer right away, suppressing the feeling that I really wanted her to do something right now.
[cpg]


Somehow, I didn't want to say I understood. That said, I don't know if it's a good idea to let Mom say it. ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa004"]
[OnName num="sawa"]
"You don't have to do this”, she said. “You look so pale."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSawa005"]
[OnName num="sawa"]
“What shall we do today? Do you want to take a bath with me?"
[cpg cn=true]


She saw through me, and I felt embarrassed.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_04_3_up.ui" time=1000]
[WAIT time=1000]


But that didn't mean I could refuse her just because I was embarrassed.
[cpg]

[VOICE f="sSawa006"]
[OnName num="sawa"]
“Alright, here's your swimsuit. With this, you won't be embarrassed."
[cpg cn=true]

[OnName num="gorou"]
“But, but ...... Is it fine with you?”
[cpg cn=true]


[VOICE f="sSawa007"]
[OnName num="sawa"]
“I'm fine. I don't want to see your suffering face anymore.”
[cpg cn=true]


I did as mom asked and head for the bathtub.
[cpg]


Hoping ...... that no one would find out.
[cpg]


;//========================================
;//●ＣＧエロ（石けんで洗いながら手コキ。ヒロインは背後から片手で主人公の乳首も弄りながらしごく）ev_08
;//人物１：ヒロイン３
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：主人公の家＿風呂
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


I couldn't say that I had no problem because I was wearing a swimsuit……
[cpg]


I don't know if it's okay to do this with a family member, even if they are not blood related.
[cpg]


[VOICE f="sSawa008"]
[OnName num="sawa"]
"While you're taking a bath, would you like me to wash your body for you?"
[cpg cn=true]


Mom asks me naturally.
[cpg]


[OnName num="gorou"]
“Ummm. I'll do it myself."
[cpg cn=true]



I, on the other hand, felt nervous.
[cpg]


;**【ＣＧ】 ev_08_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sawa038"]
[OnName num="sawa"]
"You say that, but you really want to be spoiled, don't you?"
[cpg cn=true]


I have a desire to be pampered. But I can't say it out loud.
[cpg]


Mom approaches me knowing that too.
[cpg]


[OnName num="gorou"]
“It's really fine. ……"
[cpg cn=true]


[VOICE f="sSawa009"]
[OnName num="sawa"]
“Don't be shy. You have a excuse since we need to get your heart pounding."
[cpg cn=true]



[OnName num="gorou"]
“When you call it an excuse, it's even more embarrassing."
[cpg cn=true]


Mom laughs and gathers soap with a sponge.
[cpg]


;**【ＣＧ】 ev_08_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa010"]
[OnName num="sawa"]
“Then I'll wash you.”
[cpg cn=true]

The sponge touches me. Already that's enough to get my heart rate up. ......
[cpg]


[VOICE f="sSawa011"]
[OnName num="sawa"]
“I can feel your pulse quickening.”, she giggles.
[cpg cn=true]


Her fingers glide over the foam. The tickling sensation is deceptive. ......
[cpg]


Little by little, my breathing becomes less labored. This in itself was one thing that was comforting.
[cpg]


Add to that the fact that I am in close contact with such a beautiful person.
[cpg]


It was a time that could be called bliss. Maybe this condition is not all bad.
[cpg]


[VOICE f="sSawa012"]
[OnName num="sawa"]
“I wonder if I've washed most of it. Is there anything else you want me to wash?”
[cpg cn=true]


What did she mean ...... what more was she going to do?
[cpg]



[OnName num="gorou"]
“What are you trying to make me say?"
[cpg cn=true]


I say that as a bit of resistance, but mom brushed it off.
[cpg]


;**【ＣＧ】 ev_08_b ***********************
[CG id=3 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa013"]
[OnName num="sawa"]
“What is it? I can't think of anything.”
[cpg cn=true]


Mom is a bit mean-spirited, I realized.
[cpg]



[OnName num="gorou"]
“...... if you can't think of anything, don't say it.”
[cpg cn=true]

[VOICE f="sSawa014"]
[OnName num="sawa"]
She laughs, “I'll wash you off then."
[cpg cn=true]


The feeling of warm water. I think my pulse is not only quickening, but my body temperature is also rising.
[cpg]


Perhaps it was the same for Mom ......?
[cpg]


[VOICE f="sSawa015"]
[OnName num="sawa"]
“What’s that face. Did you want me to wash you more?"
[cpg cn=true]


[OnName num="gorou"]
“No. It's nothing.”
[cpg cn=true]


The hot water washes away the bubbles. Indeed, it seems a bit of a reminder.
[cpg]


This was more than enough to make my heart pound ......, and this is not something you can do with your family any more.
[cpg]






[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


By the time the pounding subsided, I realized that my breathing was back to normal again.
[cpg]


It was a reminder to me that I really need my heart to pound or my life is in danger.......
[cpg]

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





After all that, we sat around the dinner table looking like nothing happened.
[cpg]


I am questioning all the things that had happened.
[cpg]



[SE f="se011"]
;//【ＳＥ】『食器の音』




[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune058"]
[OnName num="suzune"]
"...... Goro. Aren’t you hungry?”
[cpg cn=true]


[OnName num="gorou"]
“No, I’m just thinking ......"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari039"]
[OnName num="himari"]
“Thinking? I've been doing a lot of thinking as well lately.”
[cpg cn=true]


Mostly thinking about how to mess with me, I thought.
[cpg]


[OnName num="father"]
"What's wrong? Are you thinking about your condition?”
[cpg cn=true]


Well, that was true. I was also thinking how dad was the only one in the dark.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I go back to my room. Every time I remember what happened today, I feel embarrassed.
[cpg]


What should I do? I guess I'll just have to get over my condition.
[cpg]


But I can't do anything if I don't know how to fix it. ......
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


[SE f="se004"]
;//【ＳＥ】『衣擦れ』

As I fall asleep with these thoughts in mind, I was awakened by a strange sensation.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari040"]
[OnName num="himari"]
"Good morning, Goro."
[cpg cn=true]


[OnName num="gorou"]
“…… what are you doing?”
[cpg cn=true]


Himari was stroking my head. I wonder if this was also about my condition.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari006"]
[OnName num="himari"]
“Your head was made to stroke.”
[cpg cn=true]


...... I didn’t think so. She was just trying to tease me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari007"]
[OnName num="himari"]
“How's it going? Are you thrilled?"
[cpg cn=true]


[OnName num="gorou"]
“...... Um I guess.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari008"]
[OnName num="himari"]
“You guess? You’re getting rather honest lately.“
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
Himari says and brings my face close to mine.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari009"]
[OnName num="himari"]
“Look. I might just kiss you like this."
[cpg cn=true]


[OnName num="gorou"]
"S… Sorry......."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari010"]
[OnName num="himari"]
“I guess you understand what I mean.”
[cpg cn=true]


;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************




[OnName num="gorou"]
“……Himari, you're being mean."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari011"]
[OnName num="himari"]
“What are you talking about? There’s no sister this nice."
[cpg cn=true]


……She’s right, if you ask me. She was a touchy sister to begin with, but now she seems to really enjoy it.
[cpg]


And I think to myself.
[cpg]



;//■選択肢
[switch]
[case "I'm happy that she's so attached to me."]
	[swap]
	[jump target="*select01_1"]
[case "I can't wait to cure this condition."]
	[swap]
	[jump target="*select01_2"]
[endswitch]

1. I'm happy that she's so attached to me.
2. I can't wait to cure this condition.



;//==============================
;//１、こんなに尽くしてくれて幸せだ
*select01_1|The Start of the Heart Pounding Management




Himari is so happy to have done so much for me.
[cpg]


I am sure there is something like the reverse side of love.
[cpg]


When I think about it, Himari seems like a lovely person.
[cpg]

[stflag Cha2flg = 1]

;//ヒロイン２が候補に

[jump target="*select01_3"]

;//==============================
;//２、早くこの体質を治したい

*select01_2|The Start of the Heart Pounding Management



I still don't want to keep doing this for too long.
[cpg]

If possible, I want to fix my condition right now and get back to a worry-free life. ......
[cpg]


But I'm sure that will be a little further down the road.
[cpg]



;//==============================

*select01_3|The Start of the Heart Pounding Management

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep002.ks" target="*start"]



;/////////////////////////////////////////////////////////////////////
