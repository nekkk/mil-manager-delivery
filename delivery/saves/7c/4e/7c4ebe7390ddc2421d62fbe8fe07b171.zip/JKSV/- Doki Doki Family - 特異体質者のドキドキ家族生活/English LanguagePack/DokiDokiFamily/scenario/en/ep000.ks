
*start
;//あねいもままの射精管理　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//寿々音　裸　私服　スーツ
;//ひまり　裸　私服　制服
;//砂羽　　裸　私服

;//以下音声なし
;//吾郎 父親 男子学生Ａ 男子学生Ｂ
;//医者 女子学生 女子学生Ａ 女子学生Ｂ 男子学生
;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//寿々音　一人称「私」　ひまり呼び「ひまり」　砂羽呼び「お母さん」　吾郎呼び「吾郎」
;//ひまり　一人称「私」　寿々音呼び「お姉ちゃん」　砂羽呼び「お母さん」　吾郎呼び「お兄ちゃん」
;//砂羽　一人称「私」　寿々音呼び「寿々音」　ひまり呼び「ひまり」　吾郎呼び「吾郎」
;//吾郎　一人称「俺」　寿々音呼び「姉さん」　ひまり呼び「ひまり」　砂羽呼び「母さん」


;###################################################################
*Ep000|A mysterious body condition.
;###################################################################

[SCENE id=0]


[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[stflag jump_scene=1]


;///////////////////////////ここからが本編です///////////////////////////



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_me"]
;//ブラックアウト





When I was still very young.
[cpg]


My Mom and Dad died in an accident. I was a kid so I couldn’t understand what was going on.
[cpg]


I remember being scared because everyone around me was crying, so I cried too.
[cpg]


I think the real grief of losing my parents developed further down the road.
[cpg]


A distant relative of mine, Sawa Kosaka was at the funeral. She is now my mother stepmom.
[cpg]


I think I also met my step sister Suzune for the first time here.
[cpg]



;//下記寿々音のセリフは子供の頃の声です






[VOICE f="Suzune001"]
[OnName num="suzune"]
She told me, "...... don't cry. If you cry your Father and Mother in heaven will cry too.”
[cpg cn=true]


I don't think I understood much of what she meant by that at the time.
[cpg]


I think Suzune was trying to be kind.
[cpg]


She was holding back her tears, too.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



My family consisted of my mom and dad, my older sister Suzune , and my younger sister Himari . Then there’s me who is adopted, so we are a family of five.
[cpg]


None of us are related by blood. I guess we are slightly related, but Himari and Suzune are more distant from me than my cousins.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari001"]
[OnName num="himari"]
“I don't want to go to school. ...... This is May depression, isn't it?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune002"]
[OnName num="suzune"]
“It's already June. Don't be silly."
[cpg cn=true]


That's what Himari and Suzune were talking about. Somehow I kind of felt sluggish as well.
[cpg]


[OnName num="gorou"]
“It’s probably the drop in the barometric pressure……”
[cpg cn=true]

[free time=1000]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa001"]
[OnName num="sawa"]
She giggles. “But they say low pressure is good for you!"
[cpg cn=true]


[OnName num="gorou"]
“Really……? I've never heard of it.”
[cpg cn=true]


[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune003"]
[OnName num="suzune"]
“I've heard that too. People who live in places with a low atmospheric pressure live longer.”
[cpg cn=true]


I didn't know that. My body feels kind of dull though.
[cpg]


[OnName num="gorou"]
"Does feeling lazy increase your life expectancy......?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari002"]
[OnName num="himari"]
“Then I'll live longer because I'm tired every day. I don't want to go.”
[cpg cn=true]


Our dad is already at work, and we are here having a pointless conversation.
[cpg]


There's nothing to be gained except for some trivial knowledge…
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************





Suzune is a teacher at my school.
[cpg]


So, of course, she leaves home earlier than I do. The problem is Himari and me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Himari003"]
[OnName num="himari"]
“Do you think June Depression exists? I think I have it."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa002"]
[OnName num="sawa"]
“I don't know. Even if there were, I don’t think you have it Himari.”
[cpg cn=true]


[OnName num="gorou"]
“I'm sure you're right. It's too chronic for it to be a disease."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Himari004"]
[OnName num="himari"]
“I wonder if it's a body condition. ……"
[cpg cn=true]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]

[window target=true]


Body condition. Yes, this is a story about body condition.
[cpg]


I was, and still am, suffering from a certain body condition.
[cpg]




;//ブラックアウト


[window target=false]




[BG f="b_01_1.ui" time=1000]
[WAIT time=1500]


[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





I think about it as I walk a different path from Himari.
[cpg]


There are many meanings to "body condition". It can be a condition that makes it hard to get up in the morning, susceptible to alcohol, or prone to anger.
[cpg]


In my case, I have a “Dokidoki Dependence” or in other words “Heart Pound Addiction”.
[cpg]


My favorite manga genre is romantic comedy. My favorite anime genre is also a romantic comedy. My favorite music are love songs sung by idols.
[cpg]


It's embarrassing, but I can't live without such things. ......
[cpg]


I was hungry for something called “Doki-Doki". I don't even know how it became like this.
[cpg]


[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[WAIT time=2000]

;//========================================
;//●ＣＧ非エロ（授業をするヒロイン１。黒板に背を向けて本を手に持っている）ev_01
;//人物１：ヒロイン１
;//服装１：スーツ
;//場所　：学園教室
;//時間　：昼
;//========================================


[WAIT time=1000]
[BGM f="bg_d2"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]






[VOICE f="Suzune004"]
[OnName num="suzune"]
"Well, it's easy to misunderstand this part ...... But it can be seen like this ......."
[cpg cn=true]


The last class of the morning was Suzune’s class.
[cpg]

She has an interesting and intelligent aura as she faces the blackboard.
[cpg]


She is quite popular with the boys, to say the least.
[cpg]


[OnName num="male_student_A"]
“...... Ms. Kosaka is pretty, isn't she?”
[cpg cn=true]


[OnName num="male_student_B"]
“Yeah…… She has the perfect body figure.”
[cpg cn=true]


Even though she is my sister-in-law, I feel a little bad when people call out a family member like that.
[cpg]


I have the same last name, Kosaka, so people ask me all kinds of questions, but I pretend that I’m not related.
[cpg]


If they found out that she is my sister, I would be in big trouble.
[cpg]


I can see that I would be plagued by unwanted jealousy and strange approaches, so I don't tell people......
[cpg]


[OnName num="male_student_A"]
“Those breasts are like a deadly weapon. I wonder what she ate to grow them like that. ......"
[cpg cn=true]


I know, but I don't say it.
[cpg]


;**【ＣＧ】 ev_01_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Suzune005"]
[OnName num="suzune"]
"Hey, there. Be quiet.”
[cpg cn=true]


[OnName num="male_student_A"]
"......"
[cpg cn=true]

She told us to be quiet but she may have noticed that we were talking about her.


Still, I think it's amazing that she seems uninterested.
[cpg]


If you only saw her now, you would see her as a reliable person. ......
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[window target=true]


Yes. Suzune acts like a reliable person at school, but only I know that she can be the opposite.
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『学園教室』（昼）******************************************************





She forgets things rather often. She only makes few mistakes when she is teaching, but at home when she is relaxed she is quite careless.
[cpg]


She would help out with cooking, but would then mistake salt with sugar.
[cpg]


I came to this school because it was the only place left that I could get into.
[cpg]


It was awkward for me to be in the same school as Suzune, but there was nothing I could do.
[cpg]


I couldn't afford to waste my time to get into a different school and so…… I'm here.
[cpg]


On that topic, Himari is a bit smarter. She is the type of person who looks like she's out of it, but is surprisingly capable.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************





I was in a crisis, completely unrelated to these circumstances.
[cpg]


Even at school my "Heart Pound Addiction" couldn’t be stopped.
[cpg]


However, I can't open a manga at school, so I listen to music on my phone.
[cpg]


A love song that was too sweet and sour. Even though it's an idol song, it's something that students don't listen to nowadays.
[cpg]


I wonder how I ended up like this ......, but it's not like I can do anything about the fact that I'm crazy.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************





School ended and I went back home.
[cpg]


I didn't meet up with Himari on the way. We go to school that are in opposite directions.
[cpg]


[SE f="se003"]
;//【ＳＥ】『ドア開く』

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[OnName num="gorou"]
“I'm home.”
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（主人公に笑顔で抱きつくヒロイン。胸を腕に押し当てている）ev_02
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の家＿玄関
;//時間　：夕方
;//========================================


[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


As soon as I return home, Himari approaches me.
[cpg]


[VOICE f="Himari005"]
[OnName num="himari"]
"Welcome home brother!”
[cpg cn=true]

;//＠
;//彼女は私服に着替えていて、もうとっくに家に戻っていたようだった。


She comes flapping to the door and hugs me.
[cpg]


[OnName num="gorou"]
“You’re so close…they are hitting me…….”
[cpg cn=true]


;//;**【ＣＧ】 ev_02_a ***********************
;//[CG id=1 index=1 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="Himari006"]
[OnName num="himari"]
“You are so naughty. How can you look at your sister in that way?"
[cpg cn=true]


[OnName num="gorou"]
“I’m not……”
[cpg cn=true]


I was thrilled, which was a feeling that was hard to fake.
[cpg]


[OnName num="gorou"]
“Himari, I thought you had May depression. You seem fine already."
[cpg cn=true]


;//;**【ＣＧ】 ev_02_0 ***********************
;//[CG id=1 index=0 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="Himari007"]
[OnName num="himari"]
“I feel better in the evenings. I wonder why."
[cpg cn=true]


Himari is pretending that she doesn't understand, but I think she simply has a weakness towards mornings.
[cpg]


I was almost about to say it, but I didn't.
[cpg]


[OnName num="gorou"]
"Could you leave me alone for a second? ...... I need to change my clothes."
[cpg cn=true]



[VOICE f="Himari008"]
[OnName num="himari"]
“I don’t want to so I guess I'll watch you change."
[cpg cn=true]


What was she talking about? What's the fun in watching her brother get changed?
[cpg]


[OnName num="gorou"]
“I don't think it's any fun to see me naked. ……I have a weak looking body anyways.”
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]

I push Himari aside who is trying to enter my room and I get dressed.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





I want to relax in my room. It had become difficult for me to do so.
[cpg]


It's also not good that Himari put her chest against me. I get nervous at such things.
[cpg]


I think my heart is suffering from some kind of disease. Or is it my head?
[cpg]



[window target=false]



[BG f="b_06_4.ui" time=1500]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





Then I looked this and that up on the internet. The forbidden things, or rather, the things I had been avoiding for a long time.
[cpg]


Whether there is such a thing as love dependency, I'm not so much dependent on love as compared to the thrill of love......
[cpg]


These things exist, apparently. But they say it's more common in women who are already in a relationship with someone.
[cpg]


I don't have a girlfriend, I'm a guy, and ...... lately I even feel like I have a hard time breathing if my heart is not pounding.
[cpg]


Maybe I should go to the hospital quietly. I guess I'll do that.
[cpg]


[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ非エロ（ヒロインが料理をしている。手伝う主人公。主人公が横にいてヒロインは味見してる感じ）ev_03
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の家＿ダイニングキッチン
;//時間　：夜
;//========================================

[WAIT time=1000]

[SE f="se006"]
;//【ＳＥ】『料理』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]




When I went to the kitchen, my mom was preparing dinner.
[cpg]

[OnName num="gorou"]
"You want me to help you out mom?”
[cpg cn=true]


[VOICE f="Sawa003"]
[OnName num="sawa"]
“Oh, would you? That would be wonderful!”
[cpg cn=true]



Sometimes Suzune helps with the cooking, but I don't see her today.
[cpg]


[OnName num="gorou"]
“Where's Suzune?"
[cpg cn=true]



[VOICE f="Sawa004"]
[OnName num="sawa"]
“She’s resting in her room. I think she had a tough day.”
[cpg cn=true]


I guess she was right. Whenever she slacks off, she slacks off to the limit.
[cpg]


From that perspective, it's hard to say she's a reliable person.
[cpg]


;**【ＣＧ】 ev_03_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Himari009"]
[OnName num="himari"]
“Good luck, you two.”
[cpg cn=true]


I hear Himari say from behind me.
[cpg]


She could help with the housework too, but she doesn't.
[cpg]


She is similar to Suzune in the fact that they’re both lazy.
[cpg]


Himari is the type that has a hard time switching back once she gets in to the lazy mode.
[cpg]


...... So, is mom the most reliable one? Well, I guess that's a no-brainer.
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





Now we are all here. Of course, dad is also at the table for dinner.
[cpg]


[OnName num="father"]
"......,what's wrong, Goro? Is something troubling you?"
[cpg cn=true]


[OnName num="gorou"]
“Nothing. I'm fine.”
[cpg cn=true]


Did I look gloomy? Well I guess I did.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Sawa005"]
[OnName num="sawa"]
“I'm worried too. Lately, you've been acting so timid.”
[cpg cn=true]


I'm always trying to be careful not to be seen as timid. ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune006"]
[OnName num="suzune"]
“Goro always seems timid. Even more so on campus."
[cpg cn=true]


Is that how they see me? I was in a bit of shock.
[cpg]




;//ブラックアウト


[window target=false]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[STOPBGM]
[WAIT time=1000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************





The next day. I am on my way to the hospital.
[cpg]


I always knew I'd have that feeling of wanting to have a pounding heart. I guess it's just my body condition......
[cpg]


For that matter, I want to know what's going on with my body.
[cpg]


;//ブラックアウト


[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]


[SE f="se003"]
;//【ＳＥ】『ドア開く』

[WAIT time=1000]


So I had it checked out at a small hospital. ......
[cpg]


[OnName num="doctor"]
“...... what's going on here. I don't understand……"
[cpg cn=true]


Something strange is going on with my body, apparently.
[cpg]


They referred me to a larger hospital and I had to confide in my family.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿玄関』（昼）******************************************************





[OnName num="gorou"]
“I'm home. ……"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa006"]
[OnName num="sawa"]
“Welcome back. What's wrong, I thought you went out shopping."
[cpg cn=true]


[OnName num="gorou"]
“What I wanted was sold out……."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa007"]
[OnName num="sawa"]
“Oh, yeah. That's too bad. ...... What's that?"
[cpg cn=true]


[OnName num="gorou"]
“Ah!”
[cpg cn=true]


A letter of introduction fell out of the bag. I freeze for a moment.
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[OnName num="father"]
“...... sick, huh? It must be pretty serious for you to go and consult alone."
[cpg cn=true]


[OnName num="gorou"]
“No, I mean, haha ......"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune007"]
[OnName num="suzune"]
“I'm curious too. What symptoms do you have?"
[cpg cn=true]


[OnName num="gorou"]
“I’m not sure. ...... I just feel a bit like I have a cold."
[cpg cn=true]


Suffering. I am suffering, even though it will all become clear in time.
[cpg]


Himari and even mom look concerned. I felt sorry that I'm making Himari worry.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夕方）******************************************************





So soon I was on my way to the hospital where I was referred. My family came with me.
[cpg]


From there, it was all very difficult. I was told that I needed to undergo a thorough examination.
[cpg]


It is said to be a rare disease that affects only one in a million of people, or even less.
[cpg]


I was puzzled, but did as I was told, as it was explained to me that there was a risk of falling into a serious condition.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





Dinner that night was awkward.
[cpg]


It was still fine during dinner, but afterwards we had a family meeting ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa008"]
[OnName num="sawa"]
"...... It must have been difficult huh. So you had to go to the hospital alone."
[cpg cn=true]


I'm starting to think that I should have consulted with dad or someone at this point.
[cpg]


To paraphrase, he has a body condition that makes it difficult for him to breathe unless his heart rate is regularly increased. This has manifested itself with age.
[cpg]


In my case, if I don't get my heart pounding, at worst it could trigger another disease.
[cpg]


I got a headache when they told me about the risk of falling into a critical condition. My family probably felt similar.
[cpg]

[free time=800]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sSuzune001"]
[OnName num="suzune"]
"Why don't you...... read a romance comic book or something. That would solve the problem."
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="sHimari001"]
[OnName num="himari"]
“No! If that doesn't get his heart pounding, he’s going to die."
[cpg cn=true]


Dying is an exaggeration, but it is not a lie.
[cpg]


After all, it is an unknown disease, so anything can happen.
[cpg]


[OnName num="father"]
“Well, well. I'm sure Goro will be able to manage on his own; it's not good to worry too much.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari011"]
[OnName num="himari"]
“I don't know... ...... I'm anxious."
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（昼）******************************************************





Once the conversation was over, we agreed to leave it to my own judgment for the time being.
[cpg]


The days went by. I wondered if it was the right thing to do, but I had nothing else to do.
[cpg]


......In the midst of all this.
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



One morning. After my dad had left for work, we had a family meeting.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune002"]
[OnName num="suzune"]
“Don't you have a crush on one of us?"
[cpg cn=true]



[OnName num="gorou"]
“What are you talking about?”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune003"]
[OnName num="suzune"]
“You have to have your heart pound in order to survive right? We aren't blood related."
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSawa001"]
[OnName num="sawa"]
“Yea. That goes for me too.”
[cpg cn=true]


Even mom involves herself in this topic. I don’t mind though.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSuzune004"]
[OnName num="suzune"]
“Fortunately, you go to school with me during the day, too. ……"
[cpg cn=true]


[VOICE f="sSuzune005"]
[OnName num="suzune"]
“If you ever have a hard time getting your heart pounding, you can rely on us if you have to.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="3/3" time=800]
[VOICE f="sHimari002"]
[OnName num="himari"]
“It’s not something for him to rely on. We should actively help him get his heart pounding."
[cpg cn=true]


Himari says so, but it’s no joke.
[cpg]

[OnName num="gorou"]
“I don't want to! I refuse to! I absolutely don’t want that.”
[cpg cn=true]

[SE f=se010]
;//【ＳＥ】『走る』
[free time=1000]
[WAIT time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Suzune013"]
[OnName num="suzune"]
“Himari ! Don't let him get away. Hold him down."
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Himari013"]
[OnName num="himari"]
“I know! Goro you can't just run away from us.”
[cpg cn=true]




[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[WAIT time=2000]
;//ブラックアウト



And so.
[cpg]


I was subjected to a “Heart Pounding Management" by my older sister, younger sister, and mother. ......
[cpg]



[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（朝）******************************************************



After I learned about my body condition, I became extraordinarily eager to be thrilled.
[cpg]


I want to be thrilled. If I don't have a crush, I will die. What a difficult condition.
[cpg]


I couldn't listen to music during class, and after the morning class, I would feel light-headed.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************


As I was losing consciousness, Suzune came to my rescue.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune014"]
[OnName num="suzune"]
“What should we do. I guess you should go to the Student Advisor's Office. ......
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune015"]
[OnName num="suzune"]
“But it's not good to use that room too much. What do you think?"
[cpg cn=true]


I can only answer that I don't know. But in the end, I was taken to the Student Advisor's Office.
[cpg]


I was already having a hard time breathing, and I couldn't take it anymore.
[cpg]


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

;//ブラックアウト


Finally, I was alone with Suzune in a secret room where no one could see me.
[cpg]


[VOICE f="sSuzune006"]
[OnName num="suzune"]
"Don't get me wrong, I can't do that much for you.”
[cpg cn=true]


Saying this, Suzune puts her hand on my chest.
[cpg]


[OnName num="gorou"]
“Ugh ......."
[cpg cn=true]


It’s not that I have never been conscious of the fact that she is a woman.
[cpg]


My heart won’t stop pounding with her so close to me.
[cpg]


It was an indescribably comfortable time. My heart was beating so quickly, yet I could feel at ease during this strange time.
[cpg]

;//移植前シーンカット


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



[OnName num="gorou"]
“...... do we keep doing this every day?”
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune033"]
[OnName num="suzune"]
“I'm sure it's not my fault. It's more your fault.”
[cpg cn=true]


We left the Student Guidance Office saying such things.
[cpg]


In general, this is a pretty bad scene.
[cpg]


The students may not know it, but the teachers know that Suzune and I are a family.
[cpg]




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（夕方）******************************************************


Time goes by with all this going on.
[cpg]


Not much time has passed since noon, but I was already close to my limit.
[cpg]


If I don't get my heart pounding, I'll get another disease, I think.......
[cpg]


Before that, I was having a hard time breathing as if I was going crazy.
[cpg]


[OnName num="female_student"]
"What's wrong? Kosaka, are you okay?”
[cpg cn=true]


[OnName num="gorou"]
“I'm fine. It's nothing."
[cpg cn=true]


It couldn't be nothing, but I decided to answer like that.
[cpg]


I can't stand it anymore. It's even harder when I look at the girls' faces.
[cpg]


It's a pain that comes from my condition, which is clearly different from that of normal boys.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





I decided to head home.
[cpg]


I couldn't help but find all the women on the street attractive. This is not normal.
[cpg]


I can't control my feelings on my own.
[cpg]


Being managed is a lukewarm word. I was being tortured rather than having my condition managed.
[cpg]


With this feeling, I return home. ......
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[SE f="se003"]
;//【ＳＥ】『ドア開く』
[WAIT time=1000]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa010"]
[OnName num="sawa"]
“Welcome back. You look like you're in pain Goro.”
[cpg cn=true]


It was before dad came home.
[cpg]


I wanted to do something about it, I was going to get down on my knees and ask mom to help me.
[cpg]


That's what I really want to do. I can't stand this.
[cpg]


I don't want to endure it. I cling onto Mom .
[cpg]


[OnName num="gorou"]
“I'm having a hard time. ...... you know my condition, right?”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa011"]
[OnName num="sawa"]
She giggles. I can't just do nothing if you look at me like that."
[cpg cn=true]


Dad is still not back. I expect her to do something.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト



[BG f="b_04_3_up.ui" time=1000]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7" time=1000]
[WAIT time=2000]


Mom takes me to her room.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa002"]
[OnName num="sawa"]
“I'm going to give you a hug.”
[cpg cn=true]


[OnName num="gorou"]
“Are you sure ......?"
[cpg cn=true]




[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa013"]
[OnName num="sawa"]
“It's okay. It pains me to see my son in pain."
[cpg cn=true]


With those words, I was ......
[cpg]

;//移植前シーンカット

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]


on the verge of tears in the arms of my mom.
[cpg]


It is a little different from the feeling of being thrilled.
[cpg]


But in terms of relief, I probably felt more relieved than when I was in Suzune 's arms.
[cpg]


Mom wrapped up everything even my anxiety.
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[OnName num="father"]
“……"
[cpg cn=true]


[OnName num="gorou"]
"......"
[cpg cn=true]


At dinner, me and Dad were silent. I think there are things that men can somehow understand about each other.
[cpg]


It's embarrassing that I'm a man and I'm in love with love, but ......
[cpg]


Perhaps he can understand that feeling of embarrassment somewhat.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="Himari014"]
[OnName num="himari"]
“Mom, could you pass the soy sauce?”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa032"]
[OnName num="sawa"]
“Okay, here you go.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune034"]
[OnName num="suzune"]
“You're right next to it. Get it yourself, Himari."
[cpg cn=true]


The women are having such a conversation. They seem at ease.
[cpg]


Or perhaps, they even seem to be excited. Will I be taken care of by Himari tomorrow……?
[cpg]


I still understand with my mother and sister. But Himari is my younger sister.
[cpg]


It's not normal to be nervous about your younger sister.
[cpg]


I felt something dangerous there, but I couldn't say anything.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I took off my clothes and changed into my pajamas.
[cpg]


My symptoms didn't get any worse while I was sleeping, but it also didn't feel any better.......
[cpg]


I sighed deeply and worried about the future.
[cpg]


Really, what's going to happen to me ......?
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』朝チュン


[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



Even though I wonder what will happen to me, the morning will come normally.
[cpg]


So far I've been fine in my sleep, but today I dreamed that I had a cute girlfriend.
[cpg]


It's the kind of dream that even a normal man would have a hard time waking up from.
[cpg]


I wanted to ask someone for help, so I go to Suzune.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[BG f="b_04_1_up.ui" time=1000]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[WAIT time=2000]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune007"]
[OnName num="suzune"]
“What? I'm not in charge in the mornings."
[cpg cn=true]


What the heck, there seemed to be a rotation system in place.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune036"]
[OnName num="suzune"]
“I leave the mornings to Himari . So go to her."
[cpg cn=true]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari015"]
[OnName num="himari"]
“Good morning, Goro. You don't look well.”
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
I don’t feel well. I have a strange condition to begin with.
[cpg]


[OnName num="gorou"]
"...... Hi, Himari ...... about my condition."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari003"]
[OnName num="himari"]
“I know. So? What do you want me to do?"
[cpg cn=true]


She's trying to get me to say it with a smirk on her face.
[cpg]


Looks like Dad is already out of the house. That's probably why Himari would say something like this, but ......
[cpg]


It’s still not an unreserved way to put it. Himari, Suzune, mom and I are the only people who know what we're doing.
[cpg]


Dad is the only one that doesn't know. As long as dad is not here it doesn’t matter what we say.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari004"]
[OnName num="himari"]
“Have you ever held hands with a girl?”
[cpg cn=true]


[OnName num="gorou"]
“No, I haven’t.”
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari005"]
[OnName num="himari"]
“Hmmm. Then, would you be thrilled if someone did this to you?"
[cpg cn=true]

As she says this, Himari takes my hand.
[cpg]


And then we intertwine our fingers ...... in what is called a lover's knot.
[cpg]


I get nervous. And the bitterness disappears.
[cpg]


[OnName num="gorou"]
“Thank you,……."
[cpg cn=true]

[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari036"]
[OnName num="himari"]
“Now you’re mine Goro ……”,she laughs.
[cpg cn=true]


Himari seems pleased.
[cpg]


I guess that means she might be possessive, too.
[cpg]


I don't know, but that’s what I felt ......
[cpg]

;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



Then we have breakfast. Suzune looks at us surprised.
[cpg]


But she knows why this is happening.
[cpg]


In the morning, I go to Himari. In the afternoon, or rather at school, Suzune helps me. In the evening, I have mom…….That seemed to be the routine.
[cpg]


I found this out between yesterday and today. It is a routine of three comfort times a day.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari037"]
[OnName num="himari"]
“It's delicious. Scrambled eggs seem like they’re easy to make but they’re not.”
[cpg cn=true]


Is there such a thing as not being able to make scrambled eggs? As I was thinking that, Suzune poked at her.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune037"]
[OnName num="suzune"]
“You just don't want to make them.……"
[cpg cn=true]


Himari does not seem like when she was holding hands with me just a moment ago.
[cpg]


It's like she's switched back, or something.
[cpg]


But I wonder if she was like that when she was alone with me.
[cpg]


I don't know. I don't know, but so was mom ......
[cpg]


Suzune would sometimes seem nervous, but Himari and mom not so much.
[cpg]




;//ブラックアウト


[window target=false]

[STOPBGM]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



A while after Suzune left, and we head to school.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Himari038"]
[OnName num="himari"]
“I'm heading off. Bye, Goro."
[cpg cn=true]


[OnName num="gorou"]
“Ummm, yes. Well, I'll head off then too.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa033"]
[OnName num="sawa"]
"Hehe, have a good day."
[cpg cn=true]


What does that smile mean? Mom can probably see through everything.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（朝）******************************************************





[OnName num="gorou"]
"Oh ......, what's going to happen now ......?"
[cpg cn=true]


I finally said to myself out loud what I've thought several times.
[cpg]


I don't know what's going to happen if I don't.
[cpg]


Even though they are not my real family, I'm still living a life that makes my heart pound.
[cpg]


Then again, I can't see Mom, Suzune or Himari as just family.
[cpg]


I head to school in agony.
[cpg]





[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="ep001.ks" target="*start"]


;/////////////////////////////////////////////////////////////////////
