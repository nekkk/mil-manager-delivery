
*start

;###################################################################
*Ep006|Caring for Himari.
;###################################################################

;//==============================
;//２、ひまり
*select04_2|Caring for Himari.


[SCENE id=6]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


I think ……it’s Himari. Although she’s definitely not reliable.
[cpg]


But if you ask me who I like, I like Himari .
[cpg]


She is like a child, but also motherly.
[cpg]


There's a part of her that is just playing with me, but I've grown to like her.
[cpg]


To like someone like her, maybe says that I somewhat enjoy being bullied.
[cpg]


I don't hate it when I’m dealing with Himari ......
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[WAIT time=1000]



[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari127"]
[OnName num="himari"]
"Brother. It's morning fun time!”
[cpg cn=true]


While I was thinking about this, Himari comes along.
[cpg]


[OnName num="gorou"]
“Oh, yeah. Yeah. ......."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari128"]
[OnName num="himari"]
“What's wrong? You don't look well."
[cpg cn=true]


[OnName num="gorou"]
“I'm fine, it's just that ...... I need to talk to you about something."
[cpg cn=true]


I look at her in the eyes and I begin to talk.
[cpg]


[OnName num="gorou"]
“You know how they told me that my condition would settle down if I fall in love with someone?”
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari129"]
[OnName num="himari"]
“I know. The doctor said so.”
[cpg cn=true]


[OnName num="gorou"]
“So what do you think...... Himari?"
[cpg cn=true]


I asked quite discreetly. But Himari seemed to have guessed.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari027"]
[OnName num="himari"]
“I guess. I'm totally fine with having you as a partner. I'd be happy......."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari028"]
[OnName num="himari"]
“What are you going to do if we get together and the condition doesn't go away?"
[cpg cn=true]


[OnName num="gorou"]
“What do you mean? ...... Well, that's certainly troubling, but..."
[cpg cn=true]


I was thinking of myself, but Himari seemed to be thinking a little differently.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Himari132"]
[OnName num="himari"]
“You might cheat on me with someone else. With a condition like that."
[cpg cn=true]


So that’s what she's worried about…
[cpg]


[OnName num="gorou"]
“I won't. I can assure you.”
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari133"]
[OnName num="himari"]
“I can't believe it. I can be pretty skeptical and jealous."
[cpg cn=true]


She says as she comes on to me.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari029"]
[OnName num="himari"]
“For now I'll give you a little excitement. What shall we do?"
[cpg cn=true]


[OnName num="gorou"]
"......Oh, please ......"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin_up"  pos="4/7"]

[BG f="b_06_1_up.ui" time=10]
[WAIT time=200]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari030"]
[OnName num="himari"]
“Well, what shall we do? I'm tired of touching it with my hand.”
[cpg cn=true]


[OnName num="gorou"]
“If you say you're tired of it...... then what are you going to do?”
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari031"]
[OnName num="himari"]
“Yes......,how about something like this today?"
[cpg cn=true]


Having said that, Himari did something different.
[cpg]


;//========================================
;//●ＣＧ（ヒロインに足蹴にされる主人公。からかうような表情のヒロイン）ev_27
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]



She put her feet, not her hands, close to my body.
[cpg]


I thought that she was crazy, but I couldn't say no because if I didn't like it, it would end without any result.
[cpg]


[VOICE f="sHimari032"]
[OnName num="himari"]
"I don't know. I thought this kind of thing makes you excited, doesn't it?"
[cpg cn=true]


I can't act like I'm happy here, but I can’t look unhappy either.
[cpg]


[OnName num="gorou"]
“…… Yeah"
[cpg cn=true]


[VOICE f="sHimari033"]
[OnName num="himari"]
“You look unsatisfied, but I know you're actually happy."
[cpg cn=true]


[OnName num="gorou"]
“I'm not happy. ...... what kind of personality do you think I have?"
[cpg cn=true]


But it was true. I was feeling excited.
[cpg]


;**【ＣＧ】 ev_27_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari034"]
[OnName num="himari"]
”If this is the spot then I want you to say so. Although its cute that you’re trying to play tough.”
[cpg cn=true]


[OnName num="gorou"]
“It's not what I like.”
[cpg cn=true]


Oh? She looks at my reaction as she says so.
[cpg]


[VOICE f="sHimari035"]
[OnName num="himari"]
“I think the nervousness comes from this unusual circumstance.”
[cpg cn=true]


For that matter, I don't know how Himari comes up with these things.
[cpg]


[OnName num="gorou"]
“Himari...... Do you think of these things all the time?”
[cpg cn=true]


;**【ＣＧ】 ev_27_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari036"]
[OnName num="himari"]
“Hmm? All the time?”
[cpg cn=true]


[OnName num="gorou"]
“Even when you're not seeing me.”
[cpg cn=true]


[VOICE f="sHimari037"]
[OnName num="himari"]
“I don't know. I guess I just come up with it on the spot.”
[cpg cn=true]


Himari then starts to rub my breastplate with her foot.
[cpg]


It's not ticklish or anything. But I feel a strange sense of rebellion.
[cpg]


I didn't do anything lewd, though. ......
[cpg]


[VOICE f="sHimari038"]
[OnName num="himari"]
“Goro, if you have the option between hands or feet, which do you like better?"
[cpg cn=true]


[OnName num="gorou"]
"What's with that question?"
[cpg cn=true]


She asked me something so weird that I couldn't keep my cool.
[cpg]


I couldn't look straight back at her. And Himari saw right through it.
[cpg]


;**【ＣＧ】 ev_27_b ***********************
[CG id=12 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari039"]
[OnName num="himari"]
“Don’t pretend you didn’t hear me. I’m trying to think of what to do next.”
[cpg cn=true]


[OnName num="gorou"]
“……"
[cpg cn=true]


I couldn't even respond to what she had said.
[cpg]


If I said "feet," she would do something to me, but if I said "hands," she would stop what she was doing.
[cpg]


[VOICE f="sHimari040"]
[OnName num="himari"]
“Well, it doesn't matter. From now on, I'll make you feel excited in the evening, too.”
[cpg cn=true]


As I was thinking about this, Himari said something even more surprising.
[cpg]


She is very aggressive. It's not like I asked her to do it.
[cpg]


[OnName num="gorou"]
“What, are you sure……?”
[cpg cn=true]


[VOICE f="sHimari041"]
[OnName num="himari"]
“I mean, I'd like to have you to myself. I’m sure mother will be alright with it.”
[cpg cn=true]


It’s like she was treating me like an object.
[cpg]


But I was happy about that, and I felt that Himari was showing her love to me.
[cpg]




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


After touching each other, the painful time comes back.
[cpg]


But I will get to see Suzune at noon, and Himari she told me she would be there in the evening ......
[cpg]


Believing this, I just had to endure for now.
[cpg]


[window target=false]


[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』





I walk through the streets. All the way to school.
[cpg]


It's still not so painful during that time. But the hardest time is when the morning classes are ending.
[cpg]


Just until the lunch break, but… no matter what I have to be prepared.
[cpg]




[window target=false]


[STOPBGM]

[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="male_student"]
"Hey, Kosaka. I heard you were walking with a girl the other day."
[cpg cn=true]


[OnName num="gorou"]
“What? Isn’t that normal……"
[cpg cn=true]


[OnName num="male_student"]
“Don't play dumb with me! They say you were arm-in-arm with a girl and she was all over you.”
[cpg cn=true]


[OnName num="gorou"]
“What are you talking about? I've never been that close to a girl. ......"
[cpg cn=true]


Oh, but it could be her. Himari. Maybe someone saw us when we were leaving the house or something.
[cpg]


But if so, it would be obvious that she's my sister.
[cpg]


[OnName num="gorou"]
"That's my sister. Her name is Himari Kosaka.”
[cpg cn=true]


[OnName num="male_student"]
"Oh...... your sister. So she's not your girlfriend or anything."
[cpg cn=true]


[OnName num="gorou"]
“Yeah. Not a girlfriend."
[cpg cn=true]


...... Generally speaking, a sister cannot be a girlfriend.
[cpg]


I might be crazy. I had to be reminded of that.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



;//その後、昼休みになって姉さんに抜いてもらった。
;//＠
Later, at lunchtime, I asked Suzune to get my heart rate up.
[cpg]


After that. Suzune said something like this.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune321"]
[OnName num="suzune"]
“Hey. Do you like Himari? Did you perhaps tell her how you felt?”
[cpg cn=true]


[OnName num="gorou"]
“......Can you tell?”
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune322"]
[OnName num="suzune"]
“Of course. She seemed serious when she left your room in the morning."
[cpg cn=true]


That's what she was looking at. She must be very discerning, or very sisterly.
[cpg]


[OnName num="gorou"]
“I guess I did tell her how I felt ......?
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune323"]
[OnName num="suzune"]
”What do you mean I guess? You have to take responsibility.”
[cpg cn=true]


;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



Suzune lectured me which made me feel somewhat uneasy.
[cpg]


I like Himari. No doubt.
[cpg]


But when I think about whether I had told Himari properly, I can't say for sure.
[cpg]


She was afraid of me cheating. I think it's only natural, considering my condition.
[cpg]

;//＠妊娠しても体質が治らなかったらと考えるのは、当然かもしれない。
That could happen if I fall in love, but my condition is not cured.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************



[OnName num="gorou"]
“I'm home. ……"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari153"]
[OnName num="himari"]
“Welcome back Goro . Let's do this."
[cpg cn=true]


[OnName num="gorou"]
“Isn’t it a little too soon ......?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari042"]
[OnName num="himari"]
“You should be considerate of my mood Goro. You have no right to choose.”
[cpg cn=true]


Like that, she forced my hand and dragged me along.
[cpg]


She takes me to her room......
[cpg]



;//========================================
;//●ＣＧ（主人公に顔を近づけるヒロイン。キスをする）ev_28
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]



She is very close to me. I couldn't look straight at her.
[cpg]


But when I look away, Himari points it out.
[cpg]


[VOICE f="sHimari043"]
[OnName num="himari"]
“Don't look away. Look at me more closely.”
[cpg cn=true]


When someone says something like that, it just makes me nervous.
[cpg]


[OnName num="gorou"]
"...... Alright"
[cpg cn=true]


I have no choice but to nod now. I don't have the guts to refuse.
[cpg]


On the other hand, I don't have the guts to accept it either.
[cpg]


;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari044"]
[OnName num="himari"]
“You're blushing. You're always so naive.”
[cpg cn=true]


Himari is as usual, or rather, she touches me more than usual.
[cpg]


If I was as easygoing as she is, maybe I wouldn't have this condition. ......
[cpg]


[OnName num="gorou"]
“You can't help it. ...... If you stop being excited, thhen we have a problem."
[cpg cn=true]



I was excited by the fact that Himari was closer than usual.
[cpg]


[VOICE f="sHimari045"]
[OnName num="himari"]
“Since then, I've wondered what makes you most excited.”
[cpg cn=true]


Himari looks at me and gives me a scheming smile.
[cpg]


It's exciting to have such a pretty girl at such a distance from me.
[cpg]


But Himari still looked like she wanted to do something.
[cpg]


[OnName num="gorou"]
“Y.. You're really close”
[cpg cn=true]


;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari046"]
[OnName num="himari"]
“Isn't it too late for that? You've done so many things before, and you're afraid to just kiss me?"
[cpg cn=true]


I dared not say the thing, but Himari said it.
[cpg]


I knew she was going to kiss me.
[cpg]


[OnName num="gorou"]
“...... Please be gentle.”
[cpg cn=true]


[VOICE f="sHimari047"]
[OnName num="himari"]
“You sound like a girl, but it's kind of cute.”
[cpg cn=true]


I guess I'll just have prepare myself. With that in mind, I close my eyes and ......
[cpg]


;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari048"]
[OnName num="himari"]
“Heh. Nice face."
[cpg cn=true]


and she didn't kiss me.
[cpg]


I slightly open my eyes and look at Himari .
[cpg]


[VOICE f="sHimari049"]
[OnName num="himari"]
"I think I'll take a picture of your kissing face with my phone."
[cpg cn=true]


[OnName num="gorou"]
“What do you mean?”
[cpg cn=true]


[VOICE f="sHimari050"]
[OnName num="himari"]
“Did you want me to kiss you? If that's the case, I wish you'd say so."
[cpg cn=true]


[OnName num="gorou"]
"Sometimes ...... You look like the devil."
[cpg cn=true]


[VOICE f="sHimari051"]
[OnName num="himari"]
“You mean a little demon? That’s a compliment.”
[cpg cn=true]


Himari chuckles. But being controlled by her, that definitely looks like the devil to me.
[cpg]


[VOICE f="sHimari052"]
[OnName num="himari"]
“So? Do you want me to kiss you?”
[cpg cn=true]


[OnName num="gorou"]
“That's ......."
[cpg cn=true]


While I was stuttering, she gave me an irresistible look and brought her lips to mine.
[cpg]


;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト


;**【ＣＧ】 ev_28_b ***********************
[CG id=13 index=2 time=1000]
;***************************************
[WAIT time=1000]

Our lips touch each other. It was a light kiss, but I felt like we had finally crossed the line.
[cpg]



;//ＣＧ再び表示

;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]

And then she pulls away. We were no longer just brother and sister.
[cpg]


[VOICE f="sHimari053"]
[OnName num="himari"]
“…… Goro , you're really cute."
[cpg cn=true]


I could feel my face getting hotter as she said this to me.
[cpg]


I never thought I would be so thrilled to be told I was cute and ......
[cpg]


I didn't expect the kiss itself to feel this way either.
[cpg]


[VOICE f="sHimari054"]
[OnName num="himari"]
“Well then. I'll put off kissing for a while. I don't want you to be unable to get excited by our usual meetings.”
[cpg cn=true]


I think my face is getting red. I think it's even more so because Himari is also blushing.
[cpg]


I wonder what kind of relationship we are going to have…….
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


I fell asleep with that thought in mind.
[cpg]


I felt like I couldn't sleep, but I was happy.
[cpg]


I wondered if she was in a similar frame of mind......, but I couldn't be sure.
[cpg]


A little while later, on Saturday.
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の家＿玄関』（昼）******************************************************



I had just returned from the hospital.
[cpg]


Mom and I went to see the doctor, and he told me something ...... shocking.
[cpg]




;//ブラックアウト


[window target=false]


[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Himari173"]
[OnName num="himari"]
"Welcome back. How was it?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Sawa105"]
[OnName num="sawa"]
“It’s…… kinda, kinda a big deal."
[cpg cn=true]


I'll have to tell them the details. It's not something mom should say for me.
[cpg]


[OnName num="gorou"]
“I heard there's a medicine that can cure ...... my condition. But..."
[cpg cn=true]


[OnName num="gorou"]
“Instead of curing the condition, he said, I would lose interest in love.”
[cpg cn=true]


In short, I was talking about the loss of the very desire to fall in love.
[cpg]


I will no longer want to fall in love with anyone, and that's a ...... life changing decision.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
The expression on Himari’s and Suzune’s faces get clouded.”
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune324"]
[OnName num="suzune"]
“The doctor is saying scary things,......it makes me even more anxious."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

Yes, that's right. But Himari was thinking about something else or she just kept silent.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

I was now alone in a room with Himari .
[cpg]


Himari had come barging into my room.
[cpg]


She says she has something to tell me, or rather I have something to tell her.
[cpg]


[OnName num="gorou"]
"...... What do you think? About curing my condition.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari055"]
[OnName num="himari"]
“I think it’s good. I think it's fine if you do it."
[cpg cn=true]


[OnName num="gorou"]
“Seriously? Because ...... if I take the pills, I won’t think anything of you.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari175"]
[OnName num="himari"]
“I'd be fine with that as long as you don’t cheat on me. But ......."
[cpg cn=true]


Then she looks a little embarrassed and says......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari056"]
[OnName num="himari"]
“I also hope that our relationship will stay the same, only with your condition being cured.”
[cpg cn=true]


...... I see. So that’s what she thought.
[cpg]


As the doctor said I should get together with her and let my condition settle down.
[cpg]


That is the best outcome. But if the condition doesn't settle down, then ......
[cpg]


I will have to lose the ability to love.
[cpg]


I was willing to go out with Himari even if I had to make that resolution.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari057"]
[OnName num="himari"]
“You know... Goro I'm sure you're ready for that too, right?"
[cpg cn=true]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト



[window target=true]


Himari comes closer. She tries to kiss me. ......
[cpg]


I was a little impatient. I knew I wanted to be in love with Himari too.
[cpg]


[window target=false]

[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





Time went by, and soon it would be time for dinner.
[cpg]



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari058"]
[OnName num="himari"]
“It’s time for dinner. Should we go?”
[cpg cn=true]


[OnName num="gorou"]
“……"
[cpg cn=true]



I feel like I should be with Himari and see if my condition settles down.
[cpg]


But if I'm too hasty, will Himari pull away and our love itself will be fruitless?
[cpg]


After thinking about what to do, I come up with an answer.
[cpg]


;//■選択肢
[switch]
[case "I'm going to approach Himari even if I have to rush things a little bit."]
	[swap]
	[jump target="*select05_1"]
[case "I will take my time."]
	[swap]
	[jump target="*select05_2"]
[endswitch]

1. I'm going to approach Himari even if I have to rush things a little bit.
2. I will take my time.



;//==============================
;//１、多少無理してもひまりに近づく
*select05_1|Caring for Himari.




[OnName num="gorou"]
“Let's stay together a little longer, Himari "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sHimari059"]
[OnName num="himari"]
“But dinner ……"
[cpg cn=true]


[OnName num="gorou"]
“It doesn’t matter. Otherwise my condition won’t change."
[cpg cn=true]



[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari060"]
[OnName num="himari"]
“If you say so.”
[cpg cn=true]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ブラックアウト


[window target=true]

And so the days with Himari continued. But behind the scenes, discomfort was also accumulating.
[cpg]


I wonder how she felt about me rushing.
[cpg]


It would be bad if I scared her or made her feel uncomfortable even a little.
[cpg]


Even those feelings turned into impatience again.
[cpg]


;//移植前シーンカット


[window target=false]
[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari061"]
[OnName num="himari"]
“Hey, Goro. Wouldn’t it be better if you got that treatment?"
[cpg cn=true]


[OnName num="gorou"]
“Why ...... But I like Himari so much?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari062"]
[OnName num="himari"]
“Yes, but maybe it's also your condition that makes you think you like me.”
[cpg cn=true]


[VOICE f="sHimari063"]
[OnName num="himari"]
“I know you have a hard time breathing if your heart isn't pounding. You must like me because you want to be excited to feel better.”
[cpg cn=true]


In response to my impatience, Himari began to question whether I was really in love with her.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（昼）******************************************************





Then Himari started to get colder.
[cpg]


But my condition hasn’t changed, so I'm bitter and approach Himari .
[cpg]


[OnName num="gorou"]
“I'm in pain ...... Himari ."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari064"]
[OnName num="himari"]
“I don't know what to do. I'm not in the mood."
[cpg cn=true]



[window target=false]

[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『街』（夜）******************************************************



Ironically, Himari was showing interest in my suffering.
[cpg]


Maybe she had that personality trait to begin with.
[cpg]



I can only imagine, but ...... I had a feeling that was the case.
[cpg]


[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト


Himari was not interested in me anymore. I'm still in pain because I can't get my heart pounding anymore.
[cpg]


It was so painful that one night when I couldn't sleep ......
[cpg]


;//========================================
;//●ＣＧ（寝ている主人公に寄り添うヒロイン。サディスティックな感じ）ev_30
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="gorou"]
"H… H ..., Himari ?"
[cpg cn=true]


She came to my room. I had been waiting for her for a long time and wanted to hug her right now.
[cpg]


But I couldn't breathe and couldn't get up.
[cpg]


Whether she knew I was in such a situation or not I don’t know, but she said this.
[cpg]


[VOICE f="sHimari065"]
[OnName num="himari"]
“I might want to keep looking at you Goro ...... While you’re in pain.
[cpg cn=true]


She smiles while saying such cruel things.
[cpg]


I can't breathe, and I'm really going to die if I don’t get any skinship.
[cpg]


[OnName num="gorou"]
"Himari ...... please, come near me."
[cpg cn=true]


;**【ＣＧ】 ev_30_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari066"]
[OnName num="himari"]
“I wonder what I should do. Now Goro, you might be a little too desperate to get close."
[cpg cn=true]


She calmly and in her usual tone of voice shushes me.
[cpg]


[OnName num="gorou"]
“So you don’t care how I end up?”
[cpg cn=true]


[VOICE f="sHimari067"]
[OnName num="himari"]
"...... It must be so hard for you Goro . You've become so dependent on the pounding of the heart.”
[cpg cn=true]


I was more dependent on Himari than on the pounding of my heart. I called her name.
[cpg]


[OnName num="gorou"]
“Himari ......, ah, Himari , Himari.”
[cpg cn=true]


[VOICE f="sHimari068"]
[OnName num="himari"]
“What's wrong? What do you want from me, calling me like that?”
[cpg cn=true]


What do I want? It was decided.
[cpg]


[OnName num="gorou"]
“Please ...... make me excited. If you don't, my condition……
[cpg cn=true]


[VOICE f="sHimari069"]
[OnName num="himari"]
“The condition huh? Right."
[cpg cn=true]


;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari070"]
[OnName num="himari"]
“Hey. I actually brought the medicine to cure the condition."
[cpg cn=true]


[OnName num="gorou"]
“What?"
[cpg cn=true]


For a moment, I had no idea what Himari was talking about.
[cpg]


But little by little, my dim brain began to comprehend.
[cpg]


[VOICE f="sHimari071"]
[OnName num="himari"]
“I didn’t think that you would want to drink it on your own. But now that you're in pain, you might want to drink it.”
[cpg cn=true]


[OnName num="gorou"]
“What ...... If you come to my side, that would be enough to cure my breathing."
[cpg cn=true]


I think I'm being selfish. But I had to say it.
[cpg]


That's how painful it was. Not only my breathing, but also my heart.
[cpg]


;**【ＣＧ】 ev_30_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari072"]
[OnName num="himari"]
“The feeling is only temporary, right? It's not healthy that you have to stay with me all the time.”
[cpg cn=true]


[OnName num="gorou"]
“But!”
[cpg cn=true]


Himari had been making a somewhat disappointed face for a while.
[cpg]


The more desperate I get, the opposite of what I want happens. Even though I knew this, I couldn't help but feel impatient.
[cpg]


[VOICE f="sHimari073"]
[OnName num="himari"]
“I wonder what’s in this medicine. Does it reduce testosterone?"
[cpg cn=true]


[VOICE f="sHimari074"]
[OnName num="himari"]
“Then it would make sense that I would lose interest in love. I guess it would also explain why I would be okay with not having my heart pounding."
[cpg cn=true]


Himari says scary things. Do I really have to let go of this love?
[cpg]


Just imagining that makes it harder to let go. But it was even more difficult to breathe.
[cpg]


[OnName num="gorou"]
“Ahh...... I’m suffering, Himari , help me!"
[cpg cn=true]


Though seeing me in agony, Himari seemed to be in no hurry.
[cpg]


[OnName num="gorou"]
“What should I do……did I do something unpleasant?”
[cpg cn=true]


;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari075"]
[OnName num="himari"]
“I'm fine. I don't hate you. I'll still like you even if you become indifferent to love.”
[cpg cn=true]


She says scary things in a calm, gentle tone.
[cpg]


[VOICE f="sHimari076"]
[OnName num="himari"]
“Maybe then I'll play with you like a dress-up doll?”
[cpg cn=true]


[OnName num="gorou"]
“That, uh, ......, ah."
[cpg cn=true]


This love that had become strange. Himari was somewhat enjoying herself.
[cpg]


And I, on the other hand, had no time to enjoy it.
[cpg]


I didn't think ...... that it would end up like this.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



How did I ...... end up in such a situation?
[cpg]


Even if I regret it, my breathing was still painful.
[cpg]


To escape the pain, I took the pills.
[cpg]


[OnName num="gorou"]
“Ahhh ......, Himari ."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari077"]
[OnName num="himari"]
“That's all right. You were too desperate Goro. I was scared."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari078"]
[OnName num="himari"]
“Now Goro you are mine alone ......."
[cpg cn=true]


Then Himari pats my head. I was no longer excited by that.
[cpg]


[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ブラックアウト



My pounding was in a sense controlled by Himari .
[cpg]


My heart has been locked away ......
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*back_title"]
;//ＥＮＤ：バッドエンドルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================
;//２、ゆっくり慣らしていこう
*select05_2|Caring about Himari.




[OnName num="gorou"]
“I guess…….”
[cpg cn=true]




Himari is also a difficult person. I don't want to seem too impatient.
[cpg]


I was more interested in taking care of ...... Himari .
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



After that, Himari came to my room right after dinner.
[cpg]


She says she doesn't want to see me suffer.
[cpg]


By not asking too much of her, she began to come closer to me again ......
[cpg]



[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari079"]
[OnName num="himari"]
"...... I wish I could do something about it. The doctor said that falling in love would cure you, right?"
[cpg cn=true]


[OnName num="gorou"]
“Well, that's pretty much what it looked like."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari080"]
[OnName num="himari"]
“That’s so vague, isn't it? How does love work?”
[cpg cn=true]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_h1"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



For example. I guess it’s not about simply getting married or something like that.
[cpg]

Even if it were, I don't want to rush it. I didn't want to make it too difficult for her.
[cpg]


[window target=false]


[STOPBGM]

[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



But it seems that Himari made up her mind before I did.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari229"]
[OnName num="himari"]
"...... you know what? If we continue like this, it will never end, will it?”
[cpg cn=true]


[OnName num="gorou"]
“We don’t have to hurry. Let's take it slow ...... Himari.”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari081"]
[OnName num="himari"]
“I'll do something even more amazing. Goro, I'll do it even if you don't want me to.”
[cpg cn=true]


[OnName num="gorou"]
"...... Please be easy on me."
[cpg cn=true]



I didn't mind. But I don't think it would have happened if I had asked for it.
[cpg]


I really thought that love is a mysterious thing.
[cpg]


;//ブラックアウト

;//移植前シーンカット


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



Me and Himari spent the day flirting.
[cpg]


We even went to the dining room for dinner. ......
[cpg]




;//ブラックアウト


[window target=false]



[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari247"]
[OnName num="himari"]
“Thanks for the food. Well, Goro, let's go back to our room."
[cpg cn=true]


[OnName num="gorou"]
“It's too obvious. ……"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari248"]
[OnName num="himari"]
“Time is a finite thing. We can't waste it.”
[cpg cn=true]

[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa106"]
[OnName num="sawa"]
“You guys are really close it’s sweet.”
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



Then we go back to our room and have an intimate time.

[cpg]


While we were doing that, we even talked about sleeping on the futon together. ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari249"]
[OnName num="himari"]
“I think it’s not a problem. Everyone probably already knows."
[cpg cn=true]


[OnName num="gorou"]
“I guess. ...... then it’s okay?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari250"]
[OnName num="himari"]
“Finally Goro, I get to go to bed with you.
[cpg cn=true]


This is the kind of thing that makes me think that she is my sister after all.
[cpg]


I really want to be a lover. I guess we will inevitably end up in the middle.
[cpg]


She is my sister, but she is also my lover.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=1000]

And then we both cuddled up and went to sleep......
[cpg]


I am excited, yet relieved. The word comes to mind again, as I have thought it many times.
[cpg]


I think it was a happy time. It felt like a confirmation of the love between me and Himari .
[cpg]


If I had been in a hurry at that time, the feeling towards Himari might have cooled down.
[cpg]


Of course, there would have been a different future than now.
[cpg]


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari251"]
[OnName num="himari"]
"Mmmm ...... sleepy ......"
[cpg cn=true]


Himari wakes up first and shakes me.
[cpg]


Is it a weekday already? I have to go to school…
[cpg]


It is quite early. What should we do?
[cpg]


[OnName num="gorou"]
“Isn't it early ……? If you're sleepy, why don't you just go back to bed?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari082"]
[OnName num="himari"]
“No. You have to cure your condition.”
[cpg cn=true]


[OnName num="gorou"]
"......, you are right."
[cpg cn=true]


If I don't spend a little time with you, my condition won't settle down.
[cpg]


Even if that were the case, I don't think it would have to be this early in the morning. ......
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_06_1_up.ui" time=1000]
[WAIT time=2000]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sHimari083"]
[OnName num="himari"]
“Hey, let's kiss. Although I haven't brushed my teeth."
[cpg cn=true]


[OnName num="gorou"]
“It's not very hygenic……"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari084"]
[OnName num="himari"]
“If you think about your body, you'd suffer more if you didn't kiss.”
[cpg cn=true]


...... She's right.
[cpg]



;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



Happy times pass quickly and now I have to go to school.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari085"]
[OnName num="himari"]
“...... I wish my mornings were longer."
[cpg cn=true]


[OnName num="gorou"]
“I guess we’ll just have to get up earlier."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari086"]
[OnName num="himari"]
“That would make the nights shorter, wouldn't it?"
[cpg cn=true]



;//ブラックアウト



It was getting harder and harder for me to spend time without Himari.
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『学園教室』（昼）******************************************************





And by the time noon came around, I was feeling woozy.
[cpg]


I think about going to Suzune’s place, but I managed to endure it.
[cpg]


Generally speaking, if I keep repeating days like this, my condition will settle down sooner or later.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************





Time passed. Specifically ......
[cpg]


Enough time passed that even if my heart wasn't pounding, I didn't have troubles breathing.
[cpg]


The relationship with Himari is already completely exposed in the household.
[cpg]


It took a lot of explaining with dad, but he finally accepted it.
[cpg]



;//ブラックアウト


[window target=false]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari087"]
[OnName num="himari"]
"Goro is going to be your husband, isn't he?"
[cpg cn=true]


[OnName num="gorou"]
“If you put it that way, then you’re a wife Himari.”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari088"]
[OnName num="himari"]
“Heh heh heh. I like that.”
[cpg cn=true]



Until recently, she was just my sister. But now my dizzying days were going to begin......
[cpg]



;//ブラックアウト


[window target=false]

[STOPBGM]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I've already found a job and will start working in the spring.
[cpg]


Himari wanted to get married soon, so I didn't have time to study for school.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari272"]
[OnName num="himari"]
“I'm coming in, Goro”
[cpg cn=true]


[OnName num="gorou"]
"Oh, Himari ...... what's up?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari089"]
[OnName num="himari"]
"Your condition has settled down recently. That's why ...... I missed you."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari090"]
[OnName num="himari"]
“I don't know but......, I want to be with you.”
[cpg cn=true]


[OnName num="gorou"]
“Yea. I do too. It has nothing to do with my condition.”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari091"]
[OnName num="himari"]
“I like that about you Goro ….… You take me seriously."
[cpg cn=true]


[OnName num="gorou"]
“You think so? I thought I’m quite frivolous."
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari092"]
[OnName num="himari"]
“But not as frivolous as I am, right brother?”
[cpg cn=true]




...... Himari calls me brother.
[cpg]


I want her to stop doing that, but ...... it's hard to get Himari to change.
[cpg]



[OnName num="gorou"]
“You know what? If we're going to get married, you might as well change the way you call me."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari293"]
[OnName num="himari"]
“But you call Suzune sister.”
[cpg cn=true]


That is totally irrelevant. Because we don’t have an intimate relationship.
[cpg]



[OnName num="gorou"]
“It doesn’t matter……. That doesn't work."
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari294"]
[OnName num="himari"]
“I guess. I won't be able to say it soon, so just for now I'm going to say brother.”
[cpg cn=true]



Okay, so that's what she meant. Why couldn’t she just say so.
[cpg]

;//ブラックアウト
;//移植前シーンカット
;//移植前シーンカット

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



And so the days of Himari and me spending time continue.
[cpg]


It was dizzying. And then, when the time came to get married, ......
[cpg]


;//========================================
;//●ＣＧ（椅子に座って、編み物をするヒロイン。おなかは膨らんでいない形にしてください）ev_35
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：主人公の家＿リビング
;//時間　：朝
;//備考　：元のＣＧと違って、おなかは膨らんでいない形にしてください
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


Himari is knitting in the living room.
[cpg]


I don't think she was good with her hands, and I didn't know that she had such a hobby.
[cpg]


[OnName num="gorou"]
“I don't remember you ever knitting……”
[cpg cn=true]



Himari shakes her head. I knew it. I've never seen her knit before.
[cpg]


[OnName num="gorou"]
[OnName num="gorou"]
“I can't do it, but I want to.”
[cpg cn=true]


[VOICE f="Himari315"]
[OnName num="himari"]
“I want to be able to do it, because there will be days when I’ll be bored."
[cpg cn=true]


She says. Maybe she is talking about when she has a baby.
[cpg]


I didn't need to ask anymore. And on this day, I got to hear the words I had been waiting to hear.
[cpg]


;//;**【ＣＧ】 ev_35_a ***********************
;//[CG id=15 index=1 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="sHimari093"]
[OnName num="himari"]
"Stay by my side from now on, Goro."
[cpg cn=true]


She called me Goro. I felt my heart skip a beat.
[cpg]


At this moment, I had outgrown being called brother.
[cpg]


It was not fair. Himari can seduce me like that when I can’t.
[cpg]


[OnName num="gorou"]
"...... yeah I will Himari ."
[cpg cn=true]


I can only call her Himari. But one day I will call her ‘mother’.
[cpg]


The time she will call me Goro will be quite short.
[cpg]


But that's okay. That's how happy I am……
[cpg]


The day I will become a father is approaching before our eyes.
[cpg]


I felt the happiness.
[cpg]



;//ブラックアウト

Not as her brother, but as her lover.
[cpg]


It's not every day that you get to be both a brother and a lover.
[cpg]


I had a feeling that I would continue to be excited, and one day I hope to make Himari feel the same way.
[cpg]


It may be difficult for me to do something about it, because of her strong character, but I'd like to ......
[cpg]


I want to be excited and I want to make her excited as well. I had the desires of a normal lover.
[cpg]





;//ブラックアウト

[SCENE id=10]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン２ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


