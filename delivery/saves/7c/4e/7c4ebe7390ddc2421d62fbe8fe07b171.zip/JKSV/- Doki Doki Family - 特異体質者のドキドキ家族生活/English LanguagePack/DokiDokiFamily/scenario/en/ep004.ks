
*start

;###################################################################
*Ep004|Where do my thoughts lie?
;###################################################################

[SCENE id=4]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[transition target={false} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





It is morning. I wake up from a bad dream.
[cpg]


I dreamt that I was surrounded by Mom, Suzune and Himari in a place that I didn’t recognize.
[cpg]


I think it's ok to dream about someone else. But it's a little crazy that it doesn't happen.
[cpg]


With this thought in my mind, I go to the dining room with a helpless feeling.
[cpg]



;//ブラックアウト


[window target=false]



[BG f="b_04_1_up.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="gorou"]
“Where’s Himari……?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Sawa099"]
[OnName num="sawa"]
“I don't know. Maybe she's still in her room."
[cpg cn=true]


I'm in trouble. ...... Having to go to her feels like I'm losing.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Suzune102"]
[OnName num="suzune"]
“I'm headed out now. I’ll see you later.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se000"]
;//【ＳＥ】『ノック』



I’m in front of Himari’s room. I knock on the door.
[cpg]


[VOICE f="Himari092"]
[OnName num="himari"]
“Come in. Is that you Goro?"
[cpg cn=true]


[OnName num="gorou"]
"...... yeah."
[cpg cn=true]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_04_1_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari093"]
[OnName num="himari"]
“I've always wanted to try that situation where you come to my room.”
[cpg cn=true]


Himari is being carefree. My life is on the line.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari022"]
[OnName num="himari"]
“You look like you're in pain. You can't live without me, can you?”
[cpg cn=true]


[OnName num="gorou"]
“You're not wrong. I'm sick."
[cpg cn=true]


When I said I was sick, Himari was not happy.
[cpg]


[VOICE f="sHimari023"]
[OnName num="himari"]
“Well, I don't care if it's because of your sickness. As long as you are by my side."
[cpg cn=true]



Then she opens her arms. I can't refuse the invitation.
[cpg]


;//移植前シーンカット



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（昼）******************************************************





The days would pass little like that.
[cpg]


It seemed like an endless amount of time to me, but apparently only about a week had passed.
[cpg]


I go to the hospital again. This is what I found out: ......
[cpg]


[window target=false]


[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



After all, it is an unknown condition, which was something I had known for some time, but there was a silver lining.
[cpg]


At the same time, that ray of light was something that I wish I had not seen.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Sawa100"]
[OnName num="sawa"]
"...... The doctor said some great things!"
[cpg cn=true]


[OnName num="gorou"]
“Well, yeah. ...... I guess I don't want to think about it too much."
[cpg cn=true]


The doctor said that this condition is a state of an overactive instinct to fall in love with someone.
[cpg]


He explained that, by falling in love with someone, the condition will calm down.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari113"]
[OnName num="himari"]
“It's like when you catch a cold from someone and it goes away."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune103"]
[OnName num="suzune"]
“I don’t think that’s the right way to phrase it……"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





Back home, back in my room, I was troubled.
[cpg]


Falling in love with someone? That's a big deal.
[cpg]


I don't have a girlfriend. If I did, it wouldn't be like this.
[cpg]


How about ...... Himari or Suzune ? I've never heard of them ever having had a boyfriend.
[cpg]


I'm going to have to investigate. It's a matter of my future.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



So I ask Suzune and Himari .
[cpg]


[OnName num="gorou"]
"Do you two ...... have boyfriends?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune104"]
[OnName num="suzune"]
“What's wrong with you all of a sudden……I guess it's tempting for you to think about that sort of thing.”
[cpg cn=true]


She seems to have guessed what I'm talking about, and her face turns red.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune105"]
[OnName num="suzune"]
“I don’t have a boyfriend. I'm sure you don’t either Himari.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari024"]
[OnName num="himari"]
“Yes. You’re right, I don’t.”
[cpg cn=true]



Himari smiles as she says so. It looks like she’s inviting me to be her boyfriend......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune106"]
[OnName num="suzune"]
“I wouldn’t mind. If it’s for your sake Goro.”
[cpg cn=true]


Suzune took it a step further. What does she mean by that?
[cpg]


[OnName num="gorou"]
“I think I misheard ......, it sounds like you don’t mind.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sHimari025"]
[OnName num="himari"]
“It’s not fair Suzune. I feel the same way.”
[cpg cn=true]


I was in dilemma.
[cpg]


The girls say it's fine if it’s for the sake of my health. Even if they have to fall in love ......
[cpg]



;//■選択肢
[switch]
[case "I can't do that."]
	[swap]
	[jump target="*select03_1"]
[case "But I may have to."]
	[swap]
	[jump target="*select03_2"]
[endswitch]
1. I can't do that.
2. I may have to.



;//==============================
;//１、そんなことはできない
*select03_1|Where do my thoughts lie?




I can't do it. No, I can't…
[cpg]


Suzune and Himari of course, but with mom it’s even more of a taboo.
[cpg]


I go back to my room with those thoughts in my mind.
[cpg]


[jump target="*select03_3"]

;//==============================
;//２、そうするしかないかもしれない

*select03_2|Where do my thoughts lie?



But I can't keep living like this forever, can I?
[cpg]


Maybe someday I'll be with someone else. ......
[cpg]


With these thoughts in mind, I left.
[cpg]

[stflag Cha1flg = 1]

;//後の選択肢で選択肢４が候補に



;//==============================

*select03_3|Where do my thoughts lie?


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





Days passed. Before I know it, it's another weekday.
[cpg]




[window target=false]

[STOPBGM]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





I had to regularly raise my heart rate.
[cpg]


The days were so painful that as a result I began to think about curing my condition.
[cpg]


However, I could not think of anyone to fall in love with.
[cpg]


There are girls in my class that I get along with, but when I think about whether I like them or not, I can't think of anyone to fall in love with. ......
[cpg]


Leaving aside whether I was going to fall in love with someone or not......
[cpg]


I had to at least talk to someone about it.
[cpg]


And I wondered, if I were to fall in love, really, hypothetically, who would it be?
[cpg]



[if exp={getFlagValue("Cha1flg") == 0 }]
[endif]

[if exp={getFlagValue("Cha2flg") == 0 }]
[endif]

[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*select04_1"]
[endif]
//////////////////////////////////////////

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*C2"]
[endif]

[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*Out2C3"]
[endif]


[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "I can't choose."]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]


[jump target="*select04_1"]
//////////////////////////////////////////
*Out2C3|Who is in your thoughts?

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Sawa"]
	[swap]
	[jump target="*select04_3"]
[case "I can't choose."]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Sawa"]
	[swap]
	[jump target="*select04_3"]
[endswitch]

//////////////////////////////////////////
*C2|Who is in your thoughts?
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*C2C3"]
[endif]

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Himari"]
	[swap]
	[jump target="*select04_2"]
[case "I can't choose."]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Himari"]
	[swap]
	[jump target="*select04_2"]
[endswitch]

//////////////////////////////////////////
*C2C3|Who is in your thoughts?

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Himari"]
	[swap]
	[jump target="*select04_2"]
[case "Sawa"]
	[swap]
	[jump target="*select04_3"]
[case "I can't choose."]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Himari"]
	[swap]
	[jump target="*select04_2"]
[case "Sawa"]
	[swap]
	[jump target="*select04_3"]
[endswitch]








;//■選択肢
[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Himari"]
	[swap]
	[jump target="*select04_2"]
[case "Sawa"]
	[swap]
	[jump target="*select04_3"]
[case "I can't choose."]
	[swap]
	[jump target="*select04_4"]
[endswitch]

1. Suzune
2. Himari
3. Sawa
4. I can't choose.



;//ここまでの選択で候補になっている選択肢から選択
;//ただし、候補がヒロイン１のみの場合選択肢は発生せずそのまま進行


*select04_1|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[jump storage="ep005.ks" target="*start"]


*select04_2|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[jump storage="ep006.ks" target="*start"]



*select04_3|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[jump storage="ep007.ks" target="*start"]


*select04_4|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[jump storage="ep008.ks" target="*start"]


;//==============================
