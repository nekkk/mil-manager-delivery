
*start
;//あねいもままの射精管理　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//寿々音　裸　私服　スーツ
;//ひまり　裸　私服　制服
;//砂羽　　裸　私服

;//以下音声なし
;//吾郎 父親 男子学生Ａ 男子学生Ｂ
;//医者 女子学生 女子学生Ａ 女子学生Ｂ 男子学生
;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//寿々音　一人称「私」　ひまり呼び「ひまり」　砂羽呼び「お母さん」　吾郎呼び「吾郎」
;//ひまり　一人称「私」　寿々音呼び「お姉ちゃん」　砂羽呼び「お母さん」　吾郎呼び「お兄ちゃん」
;//砂羽　一人称「私」　寿々音呼び「寿々音」　ひまり呼び「ひまり」　吾郎呼び「吾郎」
;//吾郎　一人称「俺」　寿々音呼び「姉さん」　ひまり呼び「ひまり」　砂羽呼び「母さん」


;###################################################################
*Ep000|A mysterious body condition.
;###################################################################

[SCENE id=0]


[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[stflag jump_scene=1]


;///////////////////////////ここからが本編です///////////////////////////



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_me"]
;//ブラックアウト





When I was still very young.
[cpg]


My Mom and Dad died in an accident. I was a kid so I couldn’t understand what was going on.
[cpg]


I remember being scared because everyone around me was crying, so I cried too.
[cpg]


I think the real grief of losing my parents developed further down the road.
[cpg]


A distant relative of mine, Sawa Kosaka was at the funeral. She is now my mother stepmom.
[cpg]


I think I also met my step sister Suzune for the first time here.
[cpg]



;//下記寿々音のセリフは子供の頃の声です






[VOICE f="Suzune001"]
[OnName num="suzune"]
She told me, "...... don't cry. If you cry your Father and Mother in heaven will cry too.”
[cpg cn=true]


I don't think I understood much of what she meant by that at the time.
[cpg]


I think Suzune was trying to be kind.
[cpg]


She was holding back her tears, too.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



My family consisted of my mom and dad, my older sister Suzune , and my younger sister Himari . Then there’s me who is adopted, so we are a family of five.
[cpg]


None of us are related by blood. I guess we are slightly related, but Himari and Suzune are more distant from me than my cousins.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari001"]
[OnName num="himari"]
“I don't want to go to school. ...... This is May depression, isn't it?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune002"]
[OnName num="suzune"]
“It's already June. Don't be silly."
[cpg cn=true]


That's what Himari and Suzune were talking about. Somehow I kind of felt sluggish as well.
[cpg]


[OnName num="gorou"]
“It’s probably the drop in the barometric pressure……”
[cpg cn=true]

[free time=1000]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa001"]
[OnName num="sawa"]
She giggles. “But they say low pressure is good for you!"
[cpg cn=true]


[OnName num="gorou"]
“Really……? I've never heard of it.”
[cpg cn=true]


[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune003"]
[OnName num="suzune"]
“I've heard that too. People who live in places with a low atmospheric pressure live longer.”
[cpg cn=true]


I didn't know that. My body feels kind of dull though.
[cpg]


[OnName num="gorou"]
"Does feeling lazy increase your life expectancy......?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari002"]
[OnName num="himari"]
“Then I'll live longer because I'm tired every day. I don't want to go.”
[cpg cn=true]


Our dad is already at work, and we are here having a pointless conversation.
[cpg]


There's nothing to be gained except for some trivial knowledge…
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************





Suzune is a teacher at my school.
[cpg]


So, of course, she leaves home earlier than I do. The problem is Himari and me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Himari003"]
[OnName num="himari"]
“Do you think June Depression exists? I think I have it."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa002"]
[OnName num="sawa"]
“I don't know. Even if there were, I don’t think you have it Himari.”
[cpg cn=true]


[OnName num="gorou"]
“I'm sure you're right. It's too chronic for it to be a disease."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Himari004"]
[OnName num="himari"]
“I wonder if it's a body condition. ……"
[cpg cn=true]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]

[window target=true]


Body condition. Yes, this is a story about body condition.
[cpg]


I was, and still am, suffering from a certain body condition.
[cpg]




;//ブラックアウト


[window target=false]




[BG f="b_01_1.ui" time=1000]
[WAIT time=1500]


[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





I think about it as I walk a different path from Himari.
[cpg]


There are many meanings to "body condition". It can be a condition that makes it hard to get up in the morning, susceptible to alcohol, or prone to anger.
[cpg]


In my case, I have a “Dokidoki Dependence” or in other words “Heart Pound Addiction”.
[cpg]


My favorite manga genre is romantic comedy. My favorite anime genre is also a romantic comedy. My favorite music are love songs sung by idols.
[cpg]


It's embarrassing, but I can't live without such things. ......
[cpg]


I was hungry for something called “Doki-Doki". I don't even know how it became like this.
[cpg]


[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

[WAIT time=2000]

;//========================================
;//●ＣＧ非エロ（授業をするヒロイン１。黒板に背を向けて本を手に持っている）ev_01
;//人物１：ヒロイン１
;//服装１：スーツ
;//場所　：学園教室
;//時間　：昼
;//========================================


[WAIT time=1000]
[BGM f="bg_d2"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]






[VOICE f="Suzune004"]
[OnName num="suzune"]
"Well, it's easy to misunderstand this part ...... But it can be seen like this ......."
[cpg cn=true]


The last class of the morning was Suzune’s class.
[cpg]

She has an interesting and intelligent aura as she faces the blackboard.
[cpg]


She is quite popular with the boys, to say the least.
[cpg]


[OnName num="male_student_A"]
“...... Ms. Kosaka is pretty, isn't she?”
[cpg cn=true]


[OnName num="male_student_B"]
“Yeah…… She has the perfect body figure.”
[cpg cn=true]


Even though she is my sister-in-law, I feel a little bad when people call out a family member like that.
[cpg]


I have the same last name, Kosaka, so people ask me all kinds of questions, but I pretend that I’m not related.
[cpg]


If they found out that she is my sister, I would be in big trouble.
[cpg]


I can see that I would be plagued by unwanted jealousy and strange approaches, so I don't tell people......
[cpg]


[OnName num="male_student_A"]
“Those breasts are like a deadly weapon. I wonder what she ate to grow them like that. ......"
[cpg cn=true]


I know, but I don't say it.
[cpg]


;**【ＣＧ】 ev_01_a ***********************
[CG id=0 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Suzune005"]
[OnName num="suzune"]
"Hey, there. Be quiet.”
[cpg cn=true]


[OnName num="male_student_A"]
"......"
[cpg cn=true]

She told us to be quiet but she may have noticed that we were talking about her.


Still, I think it's amazing that she seems uninterested.
[cpg]


If you only saw her now, you would see her as a reliable person. ......
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[window target=true]


Yes. Suzune acts like a reliable person at school, but only I know that she can be the opposite.
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『学園教室』（昼）******************************************************





She forgets things rather often. She only makes few mistakes when she is teaching, but at home when she is relaxed she is quite careless.
[cpg]


She would help out with cooking, but would then mistake salt with sugar.
[cpg]


I came to this school because it was the only place left that I could get into.
[cpg]


It was awkward for me to be in the same school as Suzune, but there was nothing I could do.
[cpg]


I couldn't afford to waste my time to get into a different school and so…… I'm here.
[cpg]


On that topic, Himari is a bit smarter. She is the type of person who looks like she's out of it, but is surprisingly capable.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************





I was in a crisis, completely unrelated to these circumstances.
[cpg]


Even at school my "Heart Pound Addiction" couldn’t be stopped.
[cpg]


However, I can't open a manga at school, so I listen to music on my phone.
[cpg]


A love song that was too sweet and sour. Even though it's an idol song, it's something that students don't listen to nowadays.
[cpg]


I wonder how I ended up like this ......, but it's not like I can do anything about the fact that I'm crazy.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************





School ended and I went back home.
[cpg]


I didn't meet up with Himari on the way. We go to school that are in opposite directions.
[cpg]


[SE f="se003"]
;//【ＳＥ】『ドア開く』

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[OnName num="gorou"]
“I'm home.”
[cpg cn=true]



;//========================================
;//●ＣＧ非エロ（主人公に笑顔で抱きつくヒロイン。胸を腕に押し当てている）ev_02
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の家＿玄関
;//時間　：夕方
;//========================================


[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


As soon as I return home, Himari approaches me.
[cpg]


[VOICE f="Himari005"]
[OnName num="himari"]
"Welcome home brother!”
[cpg cn=true]

;//＠
;//彼女は私服に着替えていて、もうとっくに家に戻っていたようだった。


She comes flapping to the door and hugs me.
[cpg]


[OnName num="gorou"]
“You’re so close…they are hitting me…….”
[cpg cn=true]


;//;**【ＣＧ】 ev_02_a ***********************
;//[CG id=1 index=1 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="Himari006"]
[OnName num="himari"]
“You are so naughty. How can you look at your sister in that way?"
[cpg cn=true]


[OnName num="gorou"]
“I’m not……”
[cpg cn=true]


I was thrilled, which was a feeling that was hard to fake.
[cpg]


[OnName num="gorou"]
“Himari, I thought you had May depression. You seem fine already."
[cpg cn=true]


;//;**【ＣＧ】 ev_02_0 ***********************
;//[CG id=1 index=0 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="Himari007"]
[OnName num="himari"]
“I feel better in the evenings. I wonder why."
[cpg cn=true]


Himari is pretending that she doesn't understand, but I think she simply has a weakness towards mornings.
[cpg]


I was almost about to say it, but I didn't.
[cpg]


[OnName num="gorou"]
"Could you leave me alone for a second? ...... I need to change my clothes."
[cpg cn=true]



[VOICE f="Himari008"]
[OnName num="himari"]
“I don’t want to so I guess I'll watch you change."
[cpg cn=true]


What was she talking about? What's the fun in watching her brother get changed?
[cpg]


[OnName num="gorou"]
“I don't think it's any fun to see me naked. ……I have a weak looking body anyways.”
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]

I push Himari aside who is trying to enter my room and I get dressed.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





I want to relax in my room. It had become difficult for me to do so.
[cpg]


It's also not good that Himari put her chest against me. I get nervous at such things.
[cpg]


I think my heart is suffering from some kind of disease. Or is it my head?
[cpg]



[window target=false]



[BG f="b_06_4.ui" time=1500]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





Then I looked this and that up on the internet. The forbidden things, or rather, the things I had been avoiding for a long time.
[cpg]


Whether there is such a thing as love dependency, I'm not so much dependent on love as compared to the thrill of love......
[cpg]


These things exist, apparently. But they say it's more common in women who are already in a relationship with someone.
[cpg]


I don't have a girlfriend, I'm a guy, and ...... lately I even feel like I have a hard time breathing if my heart is not pounding.
[cpg]


Maybe I should go to the hospital quietly. I guess I'll do that.
[cpg]


[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ非エロ（ヒロインが料理をしている。手伝う主人公。主人公が横にいてヒロインは味見してる感じ）ev_03
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の家＿ダイニングキッチン
;//時間　：夜
;//========================================

[WAIT time=1000]

[SE f="se006"]
;//【ＳＥ】『料理』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]




When I went to the kitchen, my mom was preparing dinner.
[cpg]

[OnName num="gorou"]
"You want me to help you out mom?”
[cpg cn=true]


[VOICE f="Sawa003"]
[OnName num="sawa"]
“Oh, would you? That would be wonderful!”
[cpg cn=true]



Sometimes Suzune helps with the cooking, but I don't see her today.
[cpg]


[OnName num="gorou"]
“Where's Suzune?"
[cpg cn=true]



[VOICE f="Sawa004"]
[OnName num="sawa"]
“She’s resting in her room. I think she had a tough day.”
[cpg cn=true]


I guess she was right. Whenever she slacks off, she slacks off to the limit.
[cpg]


From that perspective, it's hard to say she's a reliable person.
[cpg]


;**【ＣＧ】 ev_03_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Himari009"]
[OnName num="himari"]
“Good luck, you two.”
[cpg cn=true]


I hear Himari say from behind me.
[cpg]


She could help with the housework too, but she doesn't.
[cpg]


She is similar to Suzune in the fact that they’re both lazy.
[cpg]


Himari is the type that has a hard time switching back once she gets in to the lazy mode.
[cpg]


...... So, is mom the most reliable one? Well, I guess that's a no-brainer.
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[stopse g=2]
;//通常se
[stopse g=6]
;//ループse

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





Now we are all here. Of course, dad is also at the table for dinner.
[cpg]


[OnName num="father"]
"......,what's wrong, Goro? Is something troubling you?"
[cpg cn=true]


[OnName num="gorou"]
“Nothing. I'm fine.”
[cpg cn=true]


Did I look gloomy? Well I guess I did.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Sawa005"]
[OnName num="sawa"]
“I'm worried too. Lately, you've been acting so timid.”
[cpg cn=true]


I'm always trying to be careful not to be seen as timid. ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune006"]
[OnName num="suzune"]
“Goro always seems timid. Even more so on campus."
[cpg cn=true]


Is that how they see me? I was in a bit of shock.
[cpg]




;//ブラックアウト


[window target=false]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[STOPBGM]
[WAIT time=1000]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************





The next day. I am on my way to the hospital.
[cpg]


I always knew I'd have that feeling of wanting to have a pounding heart. I guess it's just my body condition......
[cpg]


For that matter, I want to know what's going on with my body.
[cpg]


;//ブラックアウト


[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]


[SE f="se003"]
;//【ＳＥ】『ドア開く』

[WAIT time=1000]


So I had it checked out at a small hospital. ......
[cpg]


[OnName num="doctor"]
“...... what's going on here. I don't understand……"
[cpg cn=true]


Something strange is going on with my body, apparently.
[cpg]


They referred me to a larger hospital and I had to confide in my family.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿玄関』（昼）******************************************************





[OnName num="gorou"]
“I'm home. ……"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa006"]
[OnName num="sawa"]
“Welcome back. What's wrong, I thought you went out shopping."
[cpg cn=true]


[OnName num="gorou"]
“What I wanted was sold out……."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa007"]
[OnName num="sawa"]
“Oh, yeah. That's too bad. ...... What's that?"
[cpg cn=true]


[OnName num="gorou"]
“Ah!”
[cpg cn=true]


A letter of introduction fell out of the bag. I freeze for a moment.
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************




[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[OnName num="father"]
“...... sick, huh? It must be pretty serious for you to go and consult alone."
[cpg cn=true]


[OnName num="gorou"]
“No, I mean, haha ......"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune007"]
[OnName num="suzune"]
“I'm curious too. What symptoms do you have?"
[cpg cn=true]


[OnName num="gorou"]
“I’m not sure. ...... I just feel a bit like I have a cold."
[cpg cn=true]


Suffering. I am suffering, even though it will all become clear in time.
[cpg]


Himari and even mom look concerned. I felt sorry that I'm making Himari worry.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夕方）******************************************************





So soon I was on my way to the hospital where I was referred. My family came with me.
[cpg]


From there, it was all very difficult. I was told that I needed to undergo a thorough examination.
[cpg]


It is said to be a rare disease that affects only one in a million of people, or even less.
[cpg]


I was puzzled, but did as I was told, as it was explained to me that there was a risk of falling into a serious condition.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





Dinner that night was awkward.
[cpg]


It was still fine during dinner, but afterwards we had a family meeting ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa008"]
[OnName num="sawa"]
"...... It must have been difficult huh. So you had to go to the hospital alone."
[cpg cn=true]


I'm starting to think that I should have consulted with dad or someone at this point.
[cpg]


To paraphrase, he has a body condition that makes it difficult for him to breathe unless his heart rate is regularly increased. This has manifested itself with age.
[cpg]


In my case, if I don't get my heart pounding, at worst it could trigger another disease.
[cpg]


I got a headache when they told me about the risk of falling into a critical condition. My family probably felt similar.
[cpg]

[free time=800]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sSuzune001"]
[OnName num="suzune"]
"Why don't you...... read a romance comic book or something. That would solve the problem."
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="sHimari001"]
[OnName num="himari"]
“No! If that doesn't get his heart pounding, he’s going to die."
[cpg cn=true]


Dying is an exaggeration, but it is not a lie.
[cpg]


After all, it is an unknown disease, so anything can happen.
[cpg]


[OnName num="father"]
“Well, well. I'm sure Goro will be able to manage on his own; it's not good to worry too much.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari011"]
[OnName num="himari"]
“I don't know... ...... I'm anxious."
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（昼）******************************************************





Once the conversation was over, we agreed to leave it to my own judgment for the time being.
[cpg]


The days went by. I wondered if it was the right thing to do, but I had nothing else to do.
[cpg]


......In the midst of all this.
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



One morning. After my dad had left for work, we had a family meeting.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune002"]
[OnName num="suzune"]
“Don't you have a crush on one of us?"
[cpg cn=true]



[OnName num="gorou"]
“What are you talking about?”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune003"]
[OnName num="suzune"]
“You have to have your heart pound in order to survive right? We aren't blood related."
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSawa001"]
[OnName num="sawa"]
“Yea. That goes for me too.”
[cpg cn=true]


Even mom involves herself in this topic. I don’t mind though.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSuzune004"]
[OnName num="suzune"]
“Fortunately, you go to school with me during the day, too. ……"
[cpg cn=true]


[VOICE f="sSuzune005"]
[OnName num="suzune"]
“If you ever have a hard time getting your heart pounding, you can rely on us if you have to.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="3/3" time=800]
[VOICE f="sHimari002"]
[OnName num="himari"]
“It’s not something for him to rely on. We should actively help him get his heart pounding."
[cpg cn=true]


Himari says so, but it’s no joke.
[cpg]

[OnName num="gorou"]
“I don't want to! I refuse to! I absolutely don’t want that.”
[cpg cn=true]

[SE f=se010]
;//【ＳＥ】『走る』
[free time=1000]
[WAIT time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Suzune013"]
[OnName num="suzune"]
“Himari ! Don't let him get away. Hold him down."
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Himari013"]
[OnName num="himari"]
“I know! Goro you can't just run away from us.”
[cpg cn=true]




[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[WAIT time=2000]
;//ブラックアウト



And so.
[cpg]


I was subjected to a “Heart Pounding Management" by my older sister, younger sister, and mother. ......
[cpg]



[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（朝）******************************************************



After I learned about my body condition, I became extraordinarily eager to be thrilled.
[cpg]


I want to be thrilled. If I don't have a crush, I will die. What a difficult condition.
[cpg]


I couldn't listen to music during class, and after the morning class, I would feel light-headed.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************


As I was losing consciousness, Suzune came to my rescue.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune014"]
[OnName num="suzune"]
“What should we do. I guess you should go to the Student Advisor's Office. ......
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune015"]
[OnName num="suzune"]
“But it's not good to use that room too much. What do you think?"
[cpg cn=true]


I can only answer that I don't know. But in the end, I was taken to the Student Advisor's Office.
[cpg]


I was already having a hard time breathing, and I couldn't take it anymore.
[cpg]


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

;//ブラックアウト


Finally, I was alone with Suzune in a secret room where no one could see me.
[cpg]


[VOICE f="sSuzune006"]
[OnName num="suzune"]
"Don't get me wrong, I can't do that much for you.”
[cpg cn=true]


Saying this, Suzune puts her hand on my chest.
[cpg]


[OnName num="gorou"]
“Ugh ......."
[cpg cn=true]


It’s not that I have never been conscious of the fact that she is a woman.
[cpg]


My heart won’t stop pounding with her so close to me.
[cpg]


It was an indescribably comfortable time. My heart was beating so quickly, yet I could feel at ease during this strange time.
[cpg]

;//移植前シーンカット


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



[OnName num="gorou"]
“...... do we keep doing this every day?”
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune033"]
[OnName num="suzune"]
“I'm sure it's not my fault. It's more your fault.”
[cpg cn=true]


We left the Student Guidance Office saying such things.
[cpg]


In general, this is a pretty bad scene.
[cpg]


The students may not know it, but the teachers know that Suzune and I are a family.
[cpg]




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（夕方）******************************************************


Time goes by with all this going on.
[cpg]


Not much time has passed since noon, but I was already close to my limit.
[cpg]


If I don't get my heart pounding, I'll get another disease, I think.......
[cpg]


Before that, I was having a hard time breathing as if I was going crazy.
[cpg]


[OnName num="female_student"]
"What's wrong? Kosaka, are you okay?”
[cpg cn=true]


[OnName num="gorou"]
“I'm fine. It's nothing."
[cpg cn=true]


It couldn't be nothing, but I decided to answer like that.
[cpg]


I can't stand it anymore. It's even harder when I look at the girls' faces.
[cpg]


It's a pain that comes from my condition, which is clearly different from that of normal boys.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





I decided to head home.
[cpg]


I couldn't help but find all the women on the street attractive. This is not normal.
[cpg]


I can't control my feelings on my own.
[cpg]


Being managed is a lukewarm word. I was being tortured rather than having my condition managed.
[cpg]


With this feeling, I return home. ......
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[SE f="se003"]
;//【ＳＥ】『ドア開く』
[WAIT time=1000]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa010"]
[OnName num="sawa"]
“Welcome back. You look like you're in pain Goro.”
[cpg cn=true]


It was before dad came home.
[cpg]


I wanted to do something about it, I was going to get down on my knees and ask mom to help me.
[cpg]


That's what I really want to do. I can't stand this.
[cpg]


I don't want to endure it. I cling onto Mom .
[cpg]


[OnName num="gorou"]
“I'm having a hard time. ...... you know my condition, right?”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa011"]
[OnName num="sawa"]
She giggles. I can't just do nothing if you look at me like that."
[cpg cn=true]


Dad is still not back. I expect her to do something.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト



[BG f="b_04_3_up.ui" time=1000]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7" time=1000]
[WAIT time=2000]


Mom takes me to her room.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa002"]
[OnName num="sawa"]
“I'm going to give you a hug.”
[cpg cn=true]


[OnName num="gorou"]
“Are you sure ......?"
[cpg cn=true]




[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa013"]
[OnName num="sawa"]
“It's okay. It pains me to see my son in pain."
[cpg cn=true]


With those words, I was ......
[cpg]

;//移植前シーンカット

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]


on the verge of tears in the arms of my mom.
[cpg]


It is a little different from the feeling of being thrilled.
[cpg]


But in terms of relief, I probably felt more relieved than when I was in Suzune 's arms.
[cpg]


Mom wrapped up everything even my anxiety.
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[OnName num="father"]
“……"
[cpg cn=true]


[OnName num="gorou"]
"......"
[cpg cn=true]


At dinner, me and Dad were silent. I think there are things that men can somehow understand about each other.
[cpg]


It's embarrassing that I'm a man and I'm in love with love, but ......
[cpg]


Perhaps he can understand that feeling of embarrassment somewhat.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="Himari014"]
[OnName num="himari"]
“Mom, could you pass the soy sauce?”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa032"]
[OnName num="sawa"]
“Okay, here you go.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune034"]
[OnName num="suzune"]
“You're right next to it. Get it yourself, Himari."
[cpg cn=true]


The women are having such a conversation. They seem at ease.
[cpg]


Or perhaps, they even seem to be excited. Will I be taken care of by Himari tomorrow……?
[cpg]


I still understand with my mother and sister. But Himari is my younger sister.
[cpg]


It's not normal to be nervous about your younger sister.
[cpg]


I felt something dangerous there, but I couldn't say anything.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I took off my clothes and changed into my pajamas.
[cpg]


My symptoms didn't get any worse while I was sleeping, but it also didn't feel any better.......
[cpg]


I sighed deeply and worried about the future.
[cpg]


Really, what's going to happen to me ......?
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』朝チュン


[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



Even though I wonder what will happen to me, the morning will come normally.
[cpg]


So far I've been fine in my sleep, but today I dreamed that I had a cute girlfriend.
[cpg]


It's the kind of dream that even a normal man would have a hard time waking up from.
[cpg]


I wanted to ask someone for help, so I go to Suzune.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト


[BG f="b_04_1_up.ui" time=1000]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[WAIT time=2000]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune007"]
[OnName num="suzune"]
“What? I'm not in charge in the mornings."
[cpg cn=true]


What the heck, there seemed to be a rotation system in place.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune036"]
[OnName num="suzune"]
“I leave the mornings to Himari . So go to her."
[cpg cn=true]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari015"]
[OnName num="himari"]
“Good morning, Goro. You don't look well.”
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
I don’t feel well. I have a strange condition to begin with.
[cpg]


[OnName num="gorou"]
"...... Hi, Himari ...... about my condition."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari003"]
[OnName num="himari"]
“I know. So? What do you want me to do?"
[cpg cn=true]


She's trying to get me to say it with a smirk on her face.
[cpg]


Looks like Dad is already out of the house. That's probably why Himari would say something like this, but ......
[cpg]


It’s still not an unreserved way to put it. Himari, Suzune, mom and I are the only people who know what we're doing.
[cpg]


Dad is the only one that doesn't know. As long as dad is not here it doesn’t matter what we say.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari004"]
[OnName num="himari"]
“Have you ever held hands with a girl?”
[cpg cn=true]


[OnName num="gorou"]
“No, I haven’t.”
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari005"]
[OnName num="himari"]
“Hmmm. Then, would you be thrilled if someone did this to you?"
[cpg cn=true]

As she says this, Himari takes my hand.
[cpg]


And then we intertwine our fingers ...... in what is called a lover's knot.
[cpg]


I get nervous. And the bitterness disappears.
[cpg]


[OnName num="gorou"]
“Thank you,……."
[cpg cn=true]

[FG f="CHA02_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari036"]
[OnName num="himari"]
“Now you’re mine Goro ……”,she laughs.
[cpg cn=true]


Himari seems pleased.
[cpg]


I guess that means she might be possessive, too.
[cpg]


I don't know, but that’s what I felt ......
[cpg]

;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



Then we have breakfast. Suzune looks at us surprised.
[cpg]


But she knows why this is happening.
[cpg]


In the morning, I go to Himari. In the afternoon, or rather at school, Suzune helps me. In the evening, I have mom…….That seemed to be the routine.
[cpg]


I found this out between yesterday and today. It is a routine of three comfort times a day.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari037"]
[OnName num="himari"]
“It's delicious. Scrambled eggs seem like they’re easy to make but they’re not.”
[cpg cn=true]


Is there such a thing as not being able to make scrambled eggs? As I was thinking that, Suzune poked at her.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune037"]
[OnName num="suzune"]
“You just don't want to make them.……"
[cpg cn=true]


Himari does not seem like when she was holding hands with me just a moment ago.
[cpg]


It's like she's switched back, or something.
[cpg]


But I wonder if she was like that when she was alone with me.
[cpg]


I don't know. I don't know, but so was mom ......
[cpg]


Suzune would sometimes seem nervous, but Himari and mom not so much.
[cpg]




;//ブラックアウト


[window target=false]

[STOPBGM]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



A while after Suzune left, and we head to school.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Himari038"]
[OnName num="himari"]
“I'm heading off. Bye, Goro."
[cpg cn=true]


[OnName num="gorou"]
“Ummm, yes. Well, I'll head off then too.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa033"]
[OnName num="sawa"]
"Hehe, have a good day."
[cpg cn=true]


What does that smile mean? Mom can probably see through everything.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（朝）******************************************************





[OnName num="gorou"]
"Oh ......, what's going to happen now ......?"
[cpg cn=true]


I finally said to myself out loud what I've thought several times.
[cpg]


I don't know what's going to happen if I don't.
[cpg]


Even though they are not my real family, I'm still living a life that makes my heart pound.
[cpg]


Then again, I can't see Mom, Suzune or Himari as just family.
[cpg]


I head to school in agony.
[cpg]





[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

;//[jump storage="ep001.ks" target="*start"]


;/////////////////////////////////////////////////////////////////////


*start

;###################################################################
*Ep001|The Start of the Heart Pounding Management
;###################################################################

;//ブラックアウト
[SCENE id=1]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]

[SE f="se002"]
;//【ＳＥ】『喧噪』

[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="female_student_A"]
“Something about him….. Kosaka, feels different."
[cpg cn=true]


[OnName num="female_student_B"]
“Yes. He used to be just a introvert, but now he's...... melancholic."
[cpg cn=true]


I can hear you, is what I thought as I was listening to the whispers.
[cpg]


It felt good that people weren’t saying anything bad about me. But...
[cpg]


If it's because of my condition, then I don't know what to say.
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************




By noon, it gets harder. My head is filled with the need to pound.
[cpg]



I can't focus in the last class of the morning.
[cpg]


I'm having trouble breathing and I can't think of anything else.
[cpg]


I'm going crazy, I could really die of Dokidoki Dependence.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune038"]
[OnName num="suzune"]
“It's around the time, when you're feeling the pain, right?”
[cpg cn=true]


[OnName num="gorou"]
“Oh, please. I can't stand it anymore, I can't ......"
[cpg cn=true]


Weak words come out of my mouth. But I can't help it.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune039"]
[OnName num="suzune"]
“It's okay. Come here.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植前シーンカット

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_03_2_up.ui" time=1000]
[WAIT time=1000]

I follow her to the Student Guidance Office.
[cpg]


I wonder what she would do to me this time.
[cpg]


In the end… it was just the same thing that happened the other day, but that was okay.
[cpg]


I understood Suzune's concern for not overstimulating me.
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



Heart Pounding Management. Three times a day to get my heart rate up ......
[cpg]


It's a pretty bizarre situation, but that's the kind of situation I was in.
[cpg]


Three times a day is not enough. I'd like it to be twice as much.
[cpg]


But we can't just touch each other endlessly. We might cross the line.
[cpg]


Is there such a thing? There is a person extremely attractive and approaching me.
[cpg]


I can't do what I want. They are managing me wherever I go.
[cpg]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（夕方）******************************************************





[OnName num="male_student_A"]
"I heard that he went into the Student Guidance Office with Ms. Kosaka.”
[cpg cn=true]


[OnName num="male_student_B"]
“What happened? And what did you do?"
[cpg cn=true]


It is natural to be questioned like that.
[cpg]


But I can't answer anything.
[cpg]


[OnName num="gorou"]
"It's career advice. ...... It's nothing to worry about."
[cpg cn=true]


[OnName num="male_student_A"]
“Stop lying……there’s talk that you came out of the room flustered."
[cpg cn=true]


That's how far the rumors got. I'll have to be careful when I leave next time.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夕方）******************************************************





Ah. I can't wait to go home.
[cpg]


Now it's Mom's turn. I can't stand it anymore…
[cpg]


I suffer so much.
[cpg]


I can't take classes properly, of course, and I can't even converse with my classmates.
[cpg]


[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』


[OnName num="gorou"]
“I'm home. ……"
[cpg cn=true]




[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa003"]
[OnName num="sawa"]
“Welcome back. Are you having a hard time?"
[cpg cn=true]


[OnName num="gorou"]
“What? No, well, it's ......"
[cpg cn=true]


I didn't answer right away, suppressing the feeling that I really wanted her to do something right now.
[cpg]


Somehow, I didn't want to say I understood. That said, I don't know if it's a good idea to let Mom say it. ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa004"]
[OnName num="sawa"]
"You don't have to do this”, she said. “You look so pale."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSawa005"]
[OnName num="sawa"]
“What shall we do today? Do you want to take a bath with me?"
[cpg cn=true]


She saw through me, and I felt embarrassed.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_04_3_up.ui" time=1000]
[WAIT time=1000]


But that didn't mean I could refuse her just because I was embarrassed.
[cpg]

[VOICE f="sSawa006"]
[OnName num="sawa"]
“Alright, here's your swimsuit. With this, you won't be embarrassed."
[cpg cn=true]

[OnName num="gorou"]
“But, but ...... Is it fine with you?”
[cpg cn=true]


[VOICE f="sSawa007"]
[OnName num="sawa"]
“I'm fine. I don't want to see your suffering face anymore.”
[cpg cn=true]


I did as mom asked and head for the bathtub.
[cpg]


Hoping ...... that no one would find out.
[cpg]


;//========================================
;//●ＣＧエロ（石けんで洗いながら手コキ。ヒロインは背後から片手で主人公の乳首も弄りながらしごく）ev_08
;//人物１：ヒロイン３
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：主人公の家＿風呂
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_08_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


I couldn't say that I had no problem because I was wearing a swimsuit……
[cpg]


I don't know if it's okay to do this with a family member, even if they are not blood related.
[cpg]


[VOICE f="sSawa008"]
[OnName num="sawa"]
"While you're taking a bath, would you like me to wash your body for you?"
[cpg cn=true]


Mom asks me naturally.
[cpg]


[OnName num="gorou"]
“Ummm. I'll do it myself."
[cpg cn=true]



I, on the other hand, felt nervous.
[cpg]


;**【ＣＧ】 ev_08_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sawa038"]
[OnName num="sawa"]
"You say that, but you really want to be spoiled, don't you?"
[cpg cn=true]


I have a desire to be pampered. But I can't say it out loud.
[cpg]


Mom approaches me knowing that too.
[cpg]


[OnName num="gorou"]
“It's really fine. ……"
[cpg cn=true]


[VOICE f="sSawa009"]
[OnName num="sawa"]
“Don't be shy. You have a excuse since we need to get your heart pounding."
[cpg cn=true]



[OnName num="gorou"]
“When you call it an excuse, it's even more embarrassing."
[cpg cn=true]


Mom laughs and gathers soap with a sponge.
[cpg]


;**【ＣＧ】 ev_08_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa010"]
[OnName num="sawa"]
“Then I'll wash you.”
[cpg cn=true]

The sponge touches me. Already that's enough to get my heart rate up. ......
[cpg]


[VOICE f="sSawa011"]
[OnName num="sawa"]
“I can feel your pulse quickening.”, she giggles.
[cpg cn=true]


Her fingers glide over the foam. The tickling sensation is deceptive. ......
[cpg]


Little by little, my breathing becomes less labored. This in itself was one thing that was comforting.
[cpg]


Add to that the fact that I am in close contact with such a beautiful person.
[cpg]


It was a time that could be called bliss. Maybe this condition is not all bad.
[cpg]


[VOICE f="sSawa012"]
[OnName num="sawa"]
“I wonder if I've washed most of it. Is there anything else you want me to wash?”
[cpg cn=true]


What did she mean ...... what more was she going to do?
[cpg]



[OnName num="gorou"]
“What are you trying to make me say?"
[cpg cn=true]


I say that as a bit of resistance, but mom brushed it off.
[cpg]


;**【ＣＧ】 ev_08_b ***********************
[CG id=3 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa013"]
[OnName num="sawa"]
“What is it? I can't think of anything.”
[cpg cn=true]


Mom is a bit mean-spirited, I realized.
[cpg]



[OnName num="gorou"]
“...... if you can't think of anything, don't say it.”
[cpg cn=true]

[VOICE f="sSawa014"]
[OnName num="sawa"]
She laughs, “I'll wash you off then."
[cpg cn=true]


The feeling of warm water. I think my pulse is not only quickening, but my body temperature is also rising.
[cpg]


Perhaps it was the same for Mom ......?
[cpg]


[VOICE f="sSawa015"]
[OnName num="sawa"]
“What’s that face. Did you want me to wash you more?"
[cpg cn=true]


[OnName num="gorou"]
“No. It's nothing.”
[cpg cn=true]


The hot water washes away the bubbles. Indeed, it seems a bit of a reminder.
[cpg]


This was more than enough to make my heart pound ......, and this is not something you can do with your family any more.
[cpg]






[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


By the time the pounding subsided, I realized that my breathing was back to normal again.
[cpg]


It was a reminder to me that I really need my heart to pound or my life is in danger.......
[cpg]

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





After all that, we sat around the dinner table looking like nothing happened.
[cpg]


I am questioning all the things that had happened.
[cpg]



[SE f="se011"]
;//【ＳＥ】『食器の音』




[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune058"]
[OnName num="suzune"]
"...... Goro. Aren’t you hungry?”
[cpg cn=true]


[OnName num="gorou"]
“No, I’m just thinking ......"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari039"]
[OnName num="himari"]
“Thinking? I've been doing a lot of thinking as well lately.”
[cpg cn=true]


Mostly thinking about how to mess with me, I thought.
[cpg]


[OnName num="father"]
"What's wrong? Are you thinking about your condition?”
[cpg cn=true]


Well, that was true. I was also thinking how dad was the only one in the dark.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I go back to my room. Every time I remember what happened today, I feel embarrassed.
[cpg]


What should I do? I guess I'll just have to get over my condition.
[cpg]


But I can't do anything if I don't know how to fix it. ......
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


[SE f="se004"]
;//【ＳＥ】『衣擦れ』

As I fall asleep with these thoughts in mind, I was awakened by a strange sensation.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari040"]
[OnName num="himari"]
"Good morning, Goro."
[cpg cn=true]


[OnName num="gorou"]
“…… what are you doing?”
[cpg cn=true]


Himari was stroking my head. I wonder if this was also about my condition.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari006"]
[OnName num="himari"]
“Your head was made to stroke.”
[cpg cn=true]


...... I didn’t think so. She was just trying to tease me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari007"]
[OnName num="himari"]
“How's it going? Are you thrilled?"
[cpg cn=true]


[OnName num="gorou"]
“...... Um I guess.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari008"]
[OnName num="himari"]
“You guess? You’re getting rather honest lately.“
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
Himari says and brings my face close to mine.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari009"]
[OnName num="himari"]
“Look. I might just kiss you like this."
[cpg cn=true]


[OnName num="gorou"]
"S… Sorry......."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari010"]
[OnName num="himari"]
“I guess you understand what I mean.”
[cpg cn=true]


;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************




[OnName num="gorou"]
“……Himari, you're being mean."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari011"]
[OnName num="himari"]
“What are you talking about? There’s no sister this nice."
[cpg cn=true]


……She’s right, if you ask me. She was a touchy sister to begin with, but now she seems to really enjoy it.
[cpg]


And I think to myself.
[cpg]



;//■選択肢
[switch]
[case "I'm happy that she's so attached to me."]
	[swap]
	[jump target="*select01_1"]
[case "I can't wait to cure this condition."]
	[swap]
	[jump target="*select01_2"]
[endswitch]

1. I'm happy that she's so attached to me.
2. I can't wait to cure this condition.



;//==============================
;//１、こんなに尽くしてくれて幸せだ
*select01_1|The Start of the Heart Pounding Management




Himari is so happy to have done so much for me.
[cpg]


I am sure there is something like the reverse side of love.
[cpg]


When I think about it, Himari seems like a lovely person.
[cpg]

[stflag Cha2flg = 1]

;//ヒロイン２が候補に

[jump target="*select01_3"]

;//==============================
;//２、早くこの体質を治したい

*select01_2|The Start of the Heart Pounding Management



I still don't want to keep doing this for too long.
[cpg]

If possible, I want to fix my condition right now and get back to a worry-free life. ......
[cpg]


But I'm sure that will be a little further down the road.
[cpg]



;//==============================

*select01_3|The Start of the Heart Pounding Management

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


;//[jump storage="ep002.ks" target="*start"]



;/////////////////////////////////////////////////////////////////////

*start

;###################################################################
*Ep002|The pain of being managed.
;###################################################################

[SCENE id=2]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





Suzune was already headed to the workplace, or rather, to the school.
[cpg]


She is a busy person too, so I don't blame her.
[cpg]


She has to go earlier than the students arrive, of course.
[cpg]


When I think about it, I feel very grateful: ......
[cpg]


Unlike me, she was a working person after all.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************




[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa055"]
[OnName num="sawa"]
“Off you go Goro. Make sure not to take detours on your way back home.”
[cpg cn=true]


She didn’t need to tell me that, I won't take detours because I'm sure I'll be suffering in the evening again.
[cpg]


With that in mind, I said goodbye to my mom.
[cpg]


[OnName num="gorou"]
“I'm heading out..."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari067"]
[OnName num="himari"]
“I'm heading out!"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************


Morning class. It was hard for me during classes.
[cpg]


In the classroom, you are supposed to concentrate on your studies.
[cpg]


But when the teacher is a woman, there is nothing I can do. Even if she is not that young.
[cpg]


And if the teacher is a man, my attention is drawn to my female classmates.
[cpg]


Just the feeling of wanting to be thrilled makes it so much harder.
[cpg]


I'm already in so much pain that I had to ask Suzune for help pretty early on.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（朝）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune059"]
[OnName num="suzune"]
“...... wait until lunchtime. You’re a boy, you'll have to be a little more patient."
[cpg cn=true]


[OnName num="gorou"]
“I’m in trouble because I am a boy. ……"
[cpg cn=true]


“That’s true.” Suzune muttered. But it doesn't matter.
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



From there I managed to hang on until lunchtime, and this time I convinced Suzune .
[cpg]


I would not miss it again. If I miss this timing, I'm really going to die.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune008"]
[OnName num="suzune"]
“Then, let's go to an empty classroom somewhere this time.”
[cpg cn=true]


[OnName num="gorou"]
“What, not the ...... Student Advisor's Office?"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune061"]
[OnName num="suzune"]
“We will seem suspicious if we use it too much."
[cpg cn=true]


She's right, but if we use an empty classroom, someone will see us. ......
[cpg]



;//ブラックアウト


[VOICE f="sSuzune009"]
[OnName num="suzune"]
“Now what shall we do? Hey…..!”
[cpg cn=true]


Despite my many concerns, I could not contain myself.
[cpg]


;//========================================
;//●ＣＧ（ヒロインに背後から抱きつく主人公。衝動を必死にこらえる）ev_10
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]





[OnName num="gorou"]
"Suzune ……!"
[cpg cn=true]


I hug her from behind. I smell the good smell and feel my pulse quicken.
[cpg]


Thinking back, I have not been able to do this since I was a child, even if I wanted to.
[cpg]


But now, I can be pampered without hesitation.
[cpg]


In that sense, I partly owed it to my current condition. ......
[cpg]


[VOICE f="sSuzune010"]
[OnName num="suzune"]
"...... That was too abrupt. You startled me."
[cpg cn=true]


I thought that she was blushing a little too.
[cpg]


Maybe she had thoughts about what I was doing.
[cpg]


[OnName num="gorou"]
“I'm sorry, I just couldn't take it anymore.”
[cpg cn=true]


;**【ＣＧ】 ev_10_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune011"]
[OnName num="suzune"]
“You're such a ...... helpless boy"
[cpg cn=true]


Suzune looked disappointed, but also embarrassed.
[cpg]


[VOICE f="sSuzune012"]
[OnName num="suzune"]
“Well, you're cute in that way, too.”
[cpg cn=true]


When she tells me that I’m cute my heart starts pounding again.
[cpg]


I want to be ...... thrilled, which is also an emotion that comes from my condition.
[cpg]


But I also wanted to feel my heart pounding even without that.
[cpg]


I want to be seduced by my sister. I want to be bewitched by her, all the time. ......
[cpg]


[VOICE f="sSuzune013"]
[OnName num="suzune"]
“I feel like your body temperature is getting higher Goro.”
[cpg cn=true]


[OnName num="gorou"]
"Yeah, I guess so."
[cpg cn=true]


When I'm told that and become aware of it, I'm likely to become even more so due to embarrassment.
[cpg]


[VOICE f="sSuzune014"]
[OnName num="suzune"]
“Yes, you are. I don't think it's just my imagination."
[cpg cn=true]


But I think Suzune who says so is also feeling a little hot.
[cpg]


;**【ＣＧ】 ev_10_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune015"]
[OnName num="suzune"]
“I think it's time for me to go. Have you calmed down?"
[cpg cn=true]


I shake my head. It's not enough.
[cpg]


A feeling welled up in me like I wanted her to hug me tighter, and I struggle to suppress it.
[cpg]


[VOICE f="sSuzune016"]
[OnName num="suzune"]
“Truly, a helpless child.”
[cpg cn=true]


She did not say it in a harsh way, but in a gentle and warm way.
[cpg]


I felt a different kind of motherly love compered to my stepmom.
[cpg]


[VOICE f="sSuzune017"]
[OnName num="suzune"]
“You are so spoiled,……I’ll be here a little longer.'
[cpg cn=true]


Suzune is saying that and allowing me to do what I want.
[cpg]


I feel like I can't hold back any longer if she's this nice to me. ......
[cpg]


But still, I held back to do nothing more.
[cpg]


[OnName num="gorou"]
“Thank you ......."
[cpg cn=true]


[VOICE f="sSuzune018"]
[OnName num="suzune"]
“You're welcome. Seeing my brother in trouble is something I can't leave alone."
[cpg cn=true]


That said, Suzune seemed to be holding something back as well.
[cpg]


I wondered if maybe she was thinking something about me ….…
[cpg]


[OnName num="gorou"]
“You smell...... good."
[cpg cn=true]


;**【ＣＧ】 ev_10_b ***********************
[CG id=4 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune019"]
[OnName num="suzune"]
“Don't sniff. And don't say embarrassing things."
[cpg cn=true]


She was less embarrassed but seemed to be scolding me.
[cpg]


But I wondered if she could smell me too.
[cpg]


I hoped that she would think about me. ......The lunch break will soon be over.
[cpg]



;//ブラックアウト

Happy times inevitably pass by quickly.
[cpg]


The more you want it to go on, the sooner it will be over.
[cpg]


And the painful time was about to start again.
[cpg]


I want to be thrilled. I could go on all day. ......
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



Afterwards. Rumors spread quickly, or maybe that guy saw it firsthand.
[cpg]


[OnName num="male_student_A"]
"I saw it. You walked into the classroom with Ms. Kosaka during lunchtime."
[cpg cn=true]


[OnName num="male_student_B"]
“What were you doing? What went on?”
[cpg cn=true]


Damn it, I think, but I go on to answer.
[cpg]


[OnName num="gorou"]
“No, it's ...... you know me and my teacher have the same last name?"
[cpg cn=true]


[OnName num="male_student_A"]
“Kosaka Goro, right? Do your names have the same kanji?"
[cpg cn=true]


[OnName num="gorou"]
“Yes. Our teacher is my stepsister.”
[cpg cn=true]


[OnName num="male_student_B"]
“Seriously? I envy you ......!"
[cpg cn=true]


[OnName num="gorou"]
“That's why I was there to talk about family problems and stuff like that."
[cpg cn=true]


I'm not lying. But I can't tell the real truth.
[cpg]


[OnName num="male_student_A"]
“It's still not right to go to an empty classroom.”
[cpg cn=true]


[OnName num="gorou"]
“If you’re talking about the kind of things you don't want others to hear."
[cpg cn=true]


This problem is becoming a burden. ...... But it's not just my fault.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園教室』（夕方）******************************************************





Afternoon class. As I was taking them, mom 's face was flickering in my head.
[cpg]


After all, I can't live without the three of them. That's what I'm reminded of.
[cpg]


It's imprinted in me that I can't go against them anymore. ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





By the end of school, I am already exhausted. My classmates are worried about me.
[cpg]


[OnName num="female_student_A"]
"Are you okay? Kosaka?”
[cpg cn=true]


[OnName num="female_student_B"]
“Hey, hey, is it true that you and Ms. Kosaka are related as stepsister and stepbrother?"
[cpg cn=true]


How quickly rumors spreads, I think as I reply to the minimum questions as possible.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa056"]
[OnName num="sawa"]
“Welcome home. Are you in pain already? How is it?”
[cpg cn=true]


[OnName num="gorou"]
“I'm having a hard time ...... help me mom."
[cpg cn=true]


I say what I think, but Mom smiles and and tells me
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa057"]
[OnName num="sawa"]
“Cute face. Hey Goro, how about holding out a little longer today?"
[cpg cn=true]


I can't help but say,
[cpg]


[OnName num="gorou"]
“I'm going to die. ……!"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





I had been told that I shouldn't have my heart beat too few times a day.
[cpg]


But if the goal is three times a day, then I guess I won't die even if it changes to twice a day.
[cpg]


In fact, they may have said three times in order to set the limit.
[cpg]


It would probably be a problem to get used to the pounding.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari068"]
[OnName num="himari"]
“Goro, it looks painful. I hope your body heals soon."
[cpg cn=true]


I finish my meal and get up unsteadily from my chair.
[cpg]

[free time=1000]

I can't do anything. I mean, I can't look at attractive women like Himari, Suzune and Mom .
[cpg]


It's best to sleep alone. I walk back to my room.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I wonder how long I'll have to wait. Mom is probably already asleep.
[cpg]


As I was thinking that, I started to lose consciousness.
[cpg]


I really could be getting another disease. In the midst of all this.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[WAIT time=1100]



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa058"]
[OnName num="sawa"]
"Sorry to keep you waiting. Please come to my room.”
[cpg cn=true]


[OnName num="gorou"]
"Are you ...... sure ......?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa059"]
[OnName num="sawa"]
“I'm surprised you can afford to say that. I don't know what to do."
[cpg cn=true]


[OnName num="gorou"]
“Uh-uh! Please, I'm at my limit."
[cpg cn=true]


If mom even says so I have no choice.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//移植前シーンカット


That night I slept with Mom stroking my head.
[cpg]


I didn't run or hide, I let my heart pound.
[cpg]


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa016"]
[OnName num="sawa"]
“You're so cute. You look so relieved."
[cpg cn=true]

I was actually relieved. I was thrilled, but relieved.
[cpg]


And after that, exhausted, I went straight to sleep with mom ......
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





Then the next day, before mom woke up, I went back to my room.
[cpg]


It was not long before the pounding management started. That's where I noticed it.
[cpg]


I was wondering if I would become too dependent on being given a heart pound on a regular basis.
[cpg]


On the other hand, if I didn't, I would have a hard time breathing. ......
[cpg]


I wonder what I should do, but I also know I can't let this go on.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari012"]
[OnName num="himari"]
“Goro. Don’t you want to have fun with your cute sister again today?"
[cpg cn=true]


Himari says. She calls herself cute……
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari070"]
[OnName num="himari"]
"Father has already left, so ...... We can do anything.”
[cpg cn=true]


What does she mean by "anything"?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Suzune079"]
[OnName num="suzune"]
“Stop it. Do it when I'm not looking."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari071"]
[OnName num="himari"]
“Why! It's fine as long as Suzune doesn't see it"
[cpg cn=true]



Suzune’s response was natural, but Himari seemed to anticipate that as well.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





I awkwardly go back to my room, which is a bad idea when I think about it.
[cpg]


I would not be able to be thrilled in the morning, and I might not last until noon.
[cpg]


Should I do what Himari wants, even if it's a little embarrassing?
[cpg]


No, no, no, I can't do it in front of Mom and Suzune after all. ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



My conflict didn't last long.
[cpg]


I knew I couldn't do nothing. I felt like I lost against Himari……
[cpg]


I decided to follow Himari. Mom doesn’t mind but Suzune gives me a cold stare.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari072"]
[OnName num="himari"]
“Why didn't you just do as I told you from the beginning? You're so stubborn."
[cpg cn=true]


I decided to follow Himari. Mom doesn’t mind but Suzune gives me a cold stare.
[cpg]



;//========================================
;//●ＣＧ（倒れ込んでいる主人公にキスをしようとするヒロイン。寸止めでキスはしない）ev_12
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の家＿リビング
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari013"]
[OnName num="himari"]
“Hey, let's kiss. It's the most exciting thing you can do."
[cpg cn=true]


And now we're in this situation. Himari is going a step too far.
[cpg]


It seems she's not only enjoying watching me fall down and get all giddy, but
[cpg]


[OnName num="gorou"]
"Are you serious when you say kiss,......?"
[cpg cn=true]


Himari looks serious. And she is also the type who does it when she says she will.
[cpg]


;**【ＣＧ】 ev_12_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari014"]
[OnName num="himari"]
“I'm serious. You want me to do it too, don't you Goro?”
[cpg cn=true]


I think it is certainly the most exciting thing. But.
[cpg]


[OnName num="gorou"]
“If I do that, I might not be thrilled by anything other than ...... kissing."
[cpg cn=true]


[VOICE f="sHimari015"]
[OnName num="himari"]
“What do you mean ......?"
[cpg cn=true]


[OnName num="gorou"]
“It's not good to do something like that out of the blue, what if I get used to it.”
[cpg cn=true]


;**【ＣＧ】 ev_12_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari016"]
[OnName num="himari"]
"Hmm. So that's what bothers you.”
[cpg cn=true]


Himari is talking about it like it's someone else's business, but it's a serious problem for me.
[cpg]


[OnName num="gorou"]
“Of course! If I can't get my heart to pound anymore, I'm going to die."
[cpg cn=true]


[VOICE f="sHimari017"]
[OnName num="himari"]
“You should consider it. I'm not going to let you go.”
[cpg cn=true]


Himari seems to be serious. If she doesn't intend to let me escape, then maybe I can't escape.
[cpg]


[OnName num="gorou"]
“Wait, wait. ……"
[cpg cn=true]


Himari was more forceful than me and I was softer compared to Himari .
[cpg]


;**【ＣＧ】 ev_12_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari018"]
[OnName num="himari"]
“I can't wait. Come on, turn your face this way.”
[cpg cn=true]


Saying this, Himari brings her face closer.
[cpg]


Her soft lips also come closer at the same time. They almost touch.
[cpg]


I can smell the good smell. I close my eyes. Himari is right next to me.
[cpg]


As I wait I get mentally ready.
[cpg]


I wait, wait, wait for her lips to touch .......
[cpg]


[OnName num="gorou"]
"...... Huh?"
[cpg cn=true]


I didn't feel any ...... lips against mine as I waited.
[cpg]


Then, just in time, she pulled her face away.
[cpg]


;**【ＣＧ】 ev_12_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari019"]
[OnName num="himari"]
“Heh. Did you feel excited?”
[cpg cn=true]


So that’s what she had meant. I was being lead on.
[cpg]


[OnName num="gorou"]
"Uh-huh..."
[cpg cn=true]


She is indeed like this from the start. I shouldn’t take the things she says too seriously. ......
[cpg]


[VOICE f="sHimari020"]
[OnName num="himari"]
“Then you've achieved your goal.”
[cpg cn=true]


Himari may be a surprisingly cunning person.
[cpg]


Is she simply messing with me? Or is she doing what she wants to do?
[cpg]


I can’t tell, but the heart pounding that I just got was pretty good, so I can't complain......
[cpg]


;**【ＣＧ】 ev_12_b ***********************
[CG id=5 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari021"]
[OnName num="himari"]
“Well then, have a good day. Goro, I'm in pain when you're in pain.”
[cpg cn=true]


[OnName num="gorou"]
“Thank you. ......"
[cpg cn=true]


I don't know if "Thank you" is the right response, but I didn't know what else to say.
[cpg]



;//ブラックアウト

But still, I wonder if it's okay to do this in front of Suzune.
[cpg]


Himari doesn’t seem to care, but I was curious.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************


And after doing such a thing with Himari, I was waiting for a cold word from Suzune .
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="sSuzune020"]
[OnName num="suzune"]
“That's really disgusting. Don’t you have any sense of embarrassment?"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari089"]
[OnName num="himari"]
“Heh heh heh. I don't think I have any."
[cpg cn=true]


Actually I did. So I feel like I can't say anything because I'm sorry and embarrassed.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune082"]
[OnName num="suzune"]
"Oh, well, that's okay. I'm leaving now."
[cpg cn=true]


[OnName num="gorou"]
"Have a good day……."
[cpg cn=true]



Suzune always leaves early. We leave after that.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************





And a while later, me and Himari also heading off.
[cpg]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa079"]
[OnName num="sawa"]
“Bye. Off you go.”
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari090"]
[OnName num="himari"]
“See you later!”
[cpg cn=true]


Himari responds cheerfully. I was in no mood to do so.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


;//[jump storage="ep003.ks" target="*start"]



;/////////////////////////////////////////////////////////////////////

*start

;###################################################################
*Ep003|I'm almost at my limit.
;###################################################################


[SCENE id=3]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（朝）******************************************************





It's still okay while walking around town. But to be honest even that was hard.
[cpg]


Maybe not enough to make me exhausted since I'm getting used to it too.
[cpg]


Next time, I will be with Suzune. Excited for that, I keep walking
[cpg]


Without that kind of a short-term goal, or a roadmap, I can’t keep up my spirits.
[cpg]


I feel helpless when I think of it as something that goes on forever. ......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（朝）******************************************************


[SE f="se002"]
;//【ＳＥ】『喧噪』


I arrive at school. I think I have calmed down somewhat since the first day of Heart Pounding Management.
[cpg]


[OnName num="male_student"]
“You seemed to be in a bad shape a while ago, but you've been looking better lately. That's a relief."
[cpg cn=true]


[OnName num="gorou"]
“I guess so. ...... Yeah, I guess it's been rather good lately."
[cpg cn=true]


I figured people around me thought it was weird.
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園廊下』（昼）******************************************************



As the class progressed and noon came, it was getting hard for me.
[cpg]


I wanted to head over to Suzune before eating lunch, but then there was a chance that Suzune would be eating.
[cpg]


Eventually, late in the lunch break, I finally head over to Suzune .
[cpg]


I don't have much time to spare, but I have to do something.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune021"]
[OnName num="suzune"]
“..... sounds like you're having a hard time.”

[cpg cn=true]


[OnName num="gorou"]
“Suzune ...... I think I'm going to die."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune084"]
[OnName num="suzune"]
“I agree. I was told that there was a risk of getting another disease.”
[cpg cn=true]


Suzune pulled my hand away, speaking calmly as she did so.
[cpg]


I was worried that people might see, but she took me to the Student Guidance Office.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_03_2_up.ui" time=1000]
[WAIT time=2000]


If this kind of thing would repeat often, it was bound to escalate.
[cpg]


If that's the case, I wonder if I will ever kiss her.
[cpg]


I wonder what she thought of me.
[cpg]


I don't want to do something she doesn't want to do.
[cpg]


Or ...... Will she still feel sad that I'm going to die?
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



I walk out of the Student Advisor's Office, making sure no one was watching.
[cpg]


If anyone saw me, the rumors would start again.
[cpg]


I can't keep doing this kind of thing over and over again.
[cpg]


I need to get a little more creative ...... but I don't know how.
[cpg]


I can't hold back the whole time I'm on campus.
[cpg]



[window target=false]

[WAIT time=2000]

[BG f="b_03_3.ui" time=1500]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



Meanwhile, school has ended.
[cpg]


I try to go home. I'm still holding on…
[cpg]


[OnName num="male_student_A"]
"Hey, Kosaka. Wanna go home for a while and have some fun?”
[cpg cn=true]


[OnName num="male_student_B"]
“You haven't been hanging out as much lately? Is something wrong?”
[cpg cn=true]


[OnName num="gorou"]
“I'm sorry. Please, let me go home. ......"
[cpg cn=true]


[OnName num="male_student_A"]
“Why? Let's go to the arcade."
[cpg cn=true]


He was a good friend to begin with. I can't neglect him.
[cpg]


But,...... the later I get home, the harder it gets.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（夜）******************************************************



There are only boys surrounding me. Or rather, I was hanging out with a group of boys.
[cpg]


But I was looking for someone to make my heart beat.
[cpg]


People around me didn't seem to understand what was going on and thought I had a cold or something.
[cpg]


So I was released somewhat early,...... but it was already midnight.
[cpg]


[OnName num="gorou"]
"Oh ...... this is bad, this is ...... bad."
[cpg cn=true]



My mom’s face comes to my mind and I wonder if Dad has returned yet.
[cpg]


If I'm going to get something done, I'd better do it soon I thought to myself.
[cpg]




[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa080"]
[OnName num="sawa"]
"Welcome home. You're back late."
[cpg cn=true]


[OnName num="gorou"]
“Sorry ......, sorry ......."
[cpg cn=true]


[OnName num="father"]
“Where were you? It's almost dinner time.”
[cpg cn=true]


[OnName num="gorou"]
"Yeah, ......, that's ......."
[cpg cn=true]


It's not hard to lie about where I was.
[cpg]


But that's not the worst part. Dad is back.
[cpg]


I’ll have to hold out while we eat.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


My guess was right. There is no way I can get Mom to do anything when Dad is back, for the most part.
[cpg]


I was filled with bitterness, which Himari found amusing.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari091"]
[OnName num="himari"]
“Goro you’re so cute. Mom It's not fair.”
[cpg cn=true]


[OnName num="father"]
“......?”
[cpg cn=true]


Dad apparently has no idea what she’s talking about.
[cpg]


That's fine, but I was in such a tight spot that I couldn't make a proper decision.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



In such a last minute situation, I was told by mom .
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa081"]
[OnName num="sawa"]
“I'll be waiting for you in my room. You can come over anytime."
[cpg cn=true]


I want to go right now, but I can't lead dad on to any suspicion.
[cpg]



;//ブラックアウト


Far beyond the limits of my patience, I gradually become more nervous.
[cpg]


I go to Mom.
[cpg]


I felt like I couldn't stand it any longer. ......
[cpg]


;//========================================
;//●ＣＧ（主人公に胸を押しつけるヒロイン。主人公の体に少し触れている感じ）ev_14
;//人物１：ヒロイン３
;//服装１：パジャマ
;//人物２：主人公
;//服装２：パジャマ
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa017"]
[OnName num="sawa"]
“I know you've had a hard day. Let me help you."
[cpg cn=true]


[OnName num="gorou"]
"...... Mom.”
[cpg cn=true]


[VOICE f="sSawa018"]
[OnName num="sawa"]
“I'm sorry you had to go through that. It's all right now."
[cpg cn=true]


[OnName num="gorou"]
“Oh, ah......."
[cpg cn=true]


I am so relieved that I can't help but let out a funny noise.
[cpg]


[VOICE f="sSawa019"]
[OnName num="sawa"]
She giggles. “It must have been so hard for you."
[cpg cn=true]


Just by touching her, I can feel a release in my brain.
[cpg]


I can't help but know that it must be something I need right now.
[cpg]


I'm thrilled, yet relieved. I was so wrapped up in this strange sensation that I couldn't help but relax.
[cpg]


;**【ＣＧ】 ev_14_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa020"]
[OnName num="sawa"]
“How can I make you excited?"
[cpg cn=true]


She touches my body a little while saying so. I feel like I can't be patient anymore.
[cpg]


[OnName num="gorou"]
“I'm already excited enough.”
[cpg cn=true]


[VOICE f="sSawa021"]
[OnName num="sawa"]
“Then that’s good.”
[cpg cn=true]


I felt like I wanted to hug her, but I held back.
[cpg]


[VOICE f="sSawa022"]
[OnName num="sawa"]
“Her pulse is very fast. I can feel it.”
[cpg cn=true]


It's natural to be nervous. To be approached by such a beautiful person......
[cpg]


But there is also the nervousness that comes from a place of wondering what would happen if dad were to find out.
[cpg]


I know it is a problem just to have such a feeling.
[cpg]


I know it's immoral of me, and I know it's a problem just to have such feelings, but I can't suppress them.
[cpg]


;**【ＣＧ】 ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa023"]
[OnName num="sawa"]
"Do you want to sleep by my side again today?"
[cpg cn=true]


Mom was quite bold.
[cpg]


[OnName num="gorou"]
“Well, I think that's ...... a bad idea.”
[cpg cn=true]


[VOICE f="sSawa024"]
[OnName num="sawa"]
“I'm good. As long as it's okay with you Goro.”
[cpg cn=true]


When she said that to me, I was tempted to do so, but I ...... held back.
[cpg]


If Dad found out, it would be bad.
[cpg]


Dad is very blunt in some ways, but it still would be bad ......
[cpg]


[OnName num="gorou"]
"...... I still can't do it. I'm going back today."
[cpg cn=true]


[VOICE f="sSawa025"]
[OnName num="sawa"]
“Yeah? You know you’re always welcome here."
[cpg cn=true]


When she says something like that, it almost makes me reconsider it.
[cpg]


Unlike with Suzune and Himari, it felt wrong.
[cpg]



;//ブラックアウト

With a sense of regret, I left her room.
[cpg]


Even though she is only a stepmom, she is an irreplaceable person to me, and I wonder if this is the right thing to do.
[cpg]


It can't be good…… but I can't stop.
[cpg]






;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』



After that, I went back to my room.
[cpg]


No matter how much I felt like I was being tossed around, I couldn’t do anything about it by my own will…….
[cpg]


It's mostly my condition. But ......
[cpg]


I wonder if mom thought something of me. Or maybe she also has some kind of disease that makes her heart need to beat like mine.
[cpg]


And then there was this…
[cpg]



;//■選択肢
[switch]
[case "I feel bad for my dad."]
	[swap]
	[jump target="*select02_1"]
[case "If she has feelings towards me, I want to return her feelings."]
	[swap]
	[jump target="*select02_2"]
[endswitch]

1. I feel bad for my dad.
2. If she has feelings towards me, I want to return her feelings.



;//==============================
;//１、父に申し訳ない
*select02_1|I'm almost at my limit.




I feel sorry for my dad. Mom and I are strangers, but dad and mom are a couple.
[cpg]


We're not blood related, ...... but I still think we're doing things that aren't good.
[cpg]


That doesn’t mean that I don't feel anything for Himari and Suzune.
[cpg]

[jump target="*select02_3"]


;//==============================
;//２、何か思ってくれてるなら応えたい

*select02_2|I'm almost at my limit.



If mom really had feelings for me, then I want to return her feelings.
[cpg]


Even if the relationship is strange, it's impossible to suddenly break it off. Maybe both of us feel like that. ......
[cpg]



[stflag Cha3flg = 1]

;//ヒロイン３が候補に



;//==============================

*select02_3|I'm almost at my limit.


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]



;//[jump storage="ep004.ks" target="*start"]


;/////////////////////////////////////////////////////////////////////

*start

;###################################################################
*Ep004|Where do my thoughts lie?
;###################################################################

[SCENE id=4]


[stflag jump_scene=0]

[if exp={getFlagValue("jump_scene") == 0 }]
[stflag jump_scene=1]
;//ep000で発生	ジャンプしてきた場合寿々音ルートで固定
[stflag Cha1flg = 1]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]
[endif]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="morble1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[transition target={false} rule="morble1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





It is morning. I wake up from a bad dream.
[cpg]


I dreamt that I was surrounded by Mom, Suzune and Himari in a place that I didn’t recognize.
[cpg]


I think it's ok to dream about someone else. But it's a little crazy that it doesn't happen.
[cpg]


With this thought in my mind, I go to the dining room with a helpless feeling.
[cpg]



;//ブラックアウト


[window target=false]



[BG f="b_04_1_up.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="gorou"]
“Where’s Himari……?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Sawa099"]
[OnName num="sawa"]
“I don't know. Maybe she's still in her room."
[cpg cn=true]


I'm in trouble. ...... Having to go to her feels like I'm losing.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Suzune102"]
[OnName num="suzune"]
“I'm headed out now. I’ll see you later.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se000"]
;//【ＳＥ】『ノック』



I’m in front of Himari’s room. I knock on the door.
[cpg]


[VOICE f="Himari092"]
[OnName num="himari"]
“Come in. Is that you Goro?"
[cpg cn=true]


[OnName num="gorou"]
"...... yeah."
[cpg cn=true]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_04_1_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari093"]
[OnName num="himari"]
“I've always wanted to try that situation where you come to my room.”
[cpg cn=true]


Himari is being carefree. My life is on the line.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari022"]
[OnName num="himari"]
“You look like you're in pain. You can't live without me, can you?”
[cpg cn=true]


[OnName num="gorou"]
“You're not wrong. I'm sick."
[cpg cn=true]


When I said I was sick, Himari was not happy.
[cpg]


[VOICE f="sHimari023"]
[OnName num="himari"]
“Well, I don't care if it's because of your sickness. As long as you are by my side."
[cpg cn=true]



Then she opens her arms. I can't refuse the invitation.
[cpg]


;//移植前シーンカット



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（昼）******************************************************





The days would pass little like that.
[cpg]


It seemed like an endless amount of time to me, but apparently only about a week had passed.
[cpg]


I go to the hospital again. This is what I found out: ......
[cpg]


[window target=false]


[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



After all, it is an unknown condition, which was something I had known for some time, but there was a silver lining.
[cpg]


At the same time, that ray of light was something that I wish I had not seen.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Sawa100"]
[OnName num="sawa"]
"...... The doctor said some great things!"
[cpg cn=true]


[OnName num="gorou"]
“Well, yeah. ...... I guess I don't want to think about it too much."
[cpg cn=true]


The doctor said that this condition is a state of an overactive instinct to fall in love with someone.
[cpg]


He explained that, by falling in love with someone, the condition will calm down.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari113"]
[OnName num="himari"]
“It's like when you catch a cold from someone and it goes away."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune103"]
[OnName num="suzune"]
“I don’t think that’s the right way to phrase it……"
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





Back home, back in my room, I was troubled.
[cpg]


Falling in love with someone? That's a big deal.
[cpg]


I don't have a girlfriend. If I did, it wouldn't be like this.
[cpg]


How about ...... Himari or Suzune ? I've never heard of them ever having had a boyfriend.
[cpg]


I'm going to have to investigate. It's a matter of my future.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



So I ask Suzune and Himari .
[cpg]


[OnName num="gorou"]
"Do you two ...... have boyfriends?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune104"]
[OnName num="suzune"]
“What's wrong with you all of a sudden……I guess it's tempting for you to think about that sort of thing.”
[cpg cn=true]


She seems to have guessed what I'm talking about, and her face turns red.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune105"]
[OnName num="suzune"]
“I don’t have a boyfriend. I'm sure you don’t either Himari.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari024"]
[OnName num="himari"]
“Yes. You’re right, I don’t.”
[cpg cn=true]



Himari smiles as she says so. It looks like she’s inviting me to be her boyfriend......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune106"]
[OnName num="suzune"]
“I wouldn’t mind. If it’s for your sake Goro.”
[cpg cn=true]


Suzune took it a step further. What does she mean by that?
[cpg]


[OnName num="gorou"]
“I think I misheard ......, it sounds like you don’t mind.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sHimari025"]
[OnName num="himari"]
“It’s not fair Suzune. I feel the same way.”
[cpg cn=true]


I was in dilemma.
[cpg]


The girls say it's fine if it’s for the sake of my health. Even if they have to fall in love ......
[cpg]



;//■選択肢
[switch]
[case "I can't do that."]
	[swap]
	[jump target="*select03_1"]
[case "But I may have to."]
	[swap]
	[jump target="*select03_2"]
[endswitch]
1. I can't do that.
2. I may have to.



;//==============================
;//１、そんなことはできない
*select03_1|Where do my thoughts lie?




I can't do it. No, I can't…
[cpg]


Suzune and Himari of course, but with mom it’s even more of a taboo.
[cpg]


I go back to my room with those thoughts in my mind.
[cpg]


[jump target="*select03_3"]

;//==============================
;//２、そうするしかないかもしれない

*select03_2|Where do my thoughts lie?



But I can't keep living like this forever, can I?
[cpg]


Maybe someday I'll be with someone else. ......
[cpg]


With these thoughts in mind, I left.
[cpg]

[stflag Cha1flg = 1]

;//後の選択肢で選択肢４が候補に



;//==============================

*select03_3|Where do my thoughts lie?


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





Days passed. Before I know it, it's another weekday.
[cpg]




[window target=false]

[STOPBGM]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





I had to regularly raise my heart rate.
[cpg]


The days were so painful that as a result I began to think about curing my condition.
[cpg]


However, I could not think of anyone to fall in love with.
[cpg]


There are girls in my class that I get along with, but when I think about whether I like them or not, I can't think of anyone to fall in love with. ......
[cpg]


Leaving aside whether I was going to fall in love with someone or not......
[cpg]


I had to at least talk to someone about it.
[cpg]


And I wondered, if I were to fall in love, really, hypothetically, who would it be?
[cpg]



[if exp={getFlagValue("Cha1flg") == 0 }]
[endif]

[if exp={getFlagValue("Cha2flg") == 0 }]
[endif]

[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*select04_1"]
[endif]
//////////////////////////////////////////

[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*C2"]
[endif]

[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*Out2C3"]
[endif]


[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "I can't choose."]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]


[jump target="*select04_1"]
//////////////////////////////////////////
*Out2C3|Who is in your thoughts?

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Sawa"]
	[swap]
	[jump target="*select04_3"]
[case "I can't choose."]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Sawa"]
	[swap]
	[jump target="*select04_3"]
[endswitch]

//////////////////////////////////////////
*C2|Who is in your thoughts?
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*C2C3"]
[endif]

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Himari"]
	[swap]
	[jump target="*select04_2"]
[case "I can't choose."]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Himari"]
	[swap]
	[jump target="*select04_2"]
[endswitch]

//////////////////////////////////////////
*C2C3|Who is in your thoughts?

[if exp={getFlagValue("Cha1flg") == 1 }]
[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Himari"]
	[swap]
	[jump target="*select04_2"]
[case "Sawa"]
	[swap]
	[jump target="*select04_3"]
[case "I can't choose."]
	[swap]
	[jump target="*select04_4"]
[endswitch]
[endif]

[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Himari"]
	[swap]
	[jump target="*select04_2"]
[case "Sawa"]
	[swap]
	[jump target="*select04_3"]
[endswitch]








;//■選択肢
[switch]
[case "Suzune"]
	[swap]
	[jump target="*select04_1"]
[case "Himari"]
	[swap]
	[jump target="*select04_2"]
[case "Sawa"]
	[swap]
	[jump target="*select04_3"]
[case "I can't choose."]
	[swap]
	[jump target="*select04_4"]
[endswitch]

1. Suzune
2. Himari
3. Sawa
4. I can't choose.



;//ここまでの選択で候補になっている選択肢から選択
;//ただし、候補がヒロイン１のみの場合選択肢は発生せずそのまま進行


;//*select04_1|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[jump storage="ep005.ks" target="*start"]


;//*select04_2|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[jump storage="ep006.ks" target="*start"]



;//*select04_3|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[jump storage="ep007.ks" target="*start"]


;//*select04_4|

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[jump storage="ep008.ks" target="*start"]


;//==============================

*start

;###################################################################
*Ep005|My feelings for Suzune.
;###################################################################


;//１、寿々音
*select04_1|My feelings for Suzune.


[SCENE id=5]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


I guess ...... It’s Suzune .
[cpg]


I think she is the most reliable person. She can be a little aloof sometimes but she is totally different from Himari and Mom .
[cpg]


Himari is the least reliable, and mom is somewhat dreamy.
[cpg]


But that's no reason to fall in love.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



I woke up early and it was just Suzune and I.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune107"]
[OnName num="suzune"]
“Good morning. You're up early today.”
[cpg cn=true]


[OnName num="gorou"]
"Yeah,......, I need to talk to you about something."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune108"]
[OnName num="suzune"]
“What is it? Is it about your condition?”
[cpg cn=true]


I nod and go on to talking.
[cpg]


[OnName num="gorou"]
"I was thinking ...... that if I were to fall in love with someone, you’d be the one……."
[cpg cn=true]


[OnName num="gorou"]
"But if we did that, we'd be married within the family, wouldn't we? So……”
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
I go on and on about what I think. And finally.
[cpg]


[OnName num="gorou"]
“…… what am I supposed to do?"
[cpg cn=true]


I concluded. But Suzune didn't give me a dumbfounded look.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune109"]
[OnName num="suzune"]
“First of all, you have to be with someone you like. It's not good to choose me just because I would accept it.”
[cpg cn=true]


[OnName num="gorou"]
“I guess ...... Yeah, I can see that."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune110"]
[OnName num="suzune"]
“Then you'd better think about who you like. Then we can talk."
[cpg cn=true]


...... I couldn't say anything.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




;//＠
Then I go to Himari to get my heart rate up and I headed off to school.
[cpg]


Somehow, I was getting to the point where I couldn't focus when I was with Himari .
[cpg]


I kept thinking about Suzune .
[cpg]




[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************





After some time had passed at the school, it was time to go to Suzune.
[cpg]


Unlike with Himari I was so nervous to see her.
[cpg]



;//ブラックアウト


[window target=false]



[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『学園教室』（昼）******************************************************





An empty classroom. We meet with some kind of awkwardness in the atmosphere.
[cpg]

;//ブラックアウト

;//========================================
;//●ＣＧ（主人公と密着するヒロイン。胸が当たっている）ev_16
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]





Suzune comes close to me. We're in the middle of a school and doing this.
[cpg]


It can't be helped because of my condition. But no matter how much I think about it…..
[cpg]


I don't know that others who see this scene will agree.
[cpg]


And that fact got my heart rate up.
[cpg]


[VOICE f="sSuzune022"]
[OnName num="suzune"]
“Does this make you excited?"
[cpg cn=true]


I'm just very close to her. I'm getting excited because she's very important to me.
[cpg]


It means a lot to me to be able to touch each other and not just have this feeling.
[cpg]


[OnName num="gorou"]
“……"
[cpg cn=true]


I was speechless. Seeing this, Suzune is worried.
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune023"]
[OnName num="suzune"]
“You need to say something to me, I'm getting worried.”
[cpg cn=true]


I finally respond.
[cpg]


[OnName num="gorou"]
“Yes. It’s feels very ...... good."
[cpg cn=true]


;**【ＣＧ】 ev_16_b ***********************
[CG id=7 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune024"]
[OnName num="suzune"]
“Don't tell me it's good. Otherwise I'll be conscious of it.”
[cpg cn=true]


Suzune was cold, but I could tell she was a little embarrassed.
[cpg]


If she is embarrassed, it means that she has feelings towards me.
[cpg]


That made me happy, too. In addition to being happy, I said to her;
[cpg]


[OnName num="gorou"]
“You're blushing.”
[cpg cn=true]


;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune025"]
[OnName num="suzune"]
“You say that, but so are you."
[cpg cn=true]


I've always wanted to be by her side.
[cpg]


I don't need anything else ...... as long as she is here. I feel a little bad for Himari.
[cpg]


Even so, Suzune was irreplaceable for me.
[cpg]


I couldn’t even compare her to anyone else.
[cpg]


;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune026"]
[OnName num="suzune"]
“Your body is getting hot. I’m getting nervous too.”
[cpg cn=true]


I couldn't get over the subtle distance between the two of us.
[cpg]


Of course, now I'm getting awfully close physically, but not emotionally.
[cpg]


[OnName num="gorou"]
“I think ...... You’re excited, too Suzune.”
[cpg cn=true]


I noticed that her pulse was quickening.
[cpg]


;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune027"]
[OnName num="suzune"]
“Really? I think it's just you being like that."
[cpg cn=true]


[OnName num="gorou"]
“I don't think so. ...... or is it just my imagination?”
[cpg cn=true]


[VOICE f="sSuzune028"]
[OnName num="suzune"]
“It's just your imagination."
[cpg cn=true]


Did my words mean something to her? That's what I thought as we were together ......
[cpg]


It's just the two of us in this world, or so the saying goes, but this is a school.
[cpg]


I can hear the voices of other students just outside. There was something about the fact that we weren't alone that made it exciting.
[cpg]


Suzune who made me feel this way is irreplaceable.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


It is during the daytime that Suzune and I touch each other.
[cpg]


In the evening, it's mom. In the morning, it's Himari . Such days had been going on for a long time, and it would not change for a while.
[cpg]


[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





The next morning. I walk to the school and meet up with a girl on the way.
[cpg]


[OnName num="female_student"]
"Good morning, Kosaka ."
[cpg cn=true]


[OnName num="gorou"]
“Oh, good morning. ……"
[cpg cn=true]


[OnName num="female_student"]
“I've noticed you seem a little different lately. I don't know how to explain it, but it’s like a melancholy ......"
[cpg cn=true]


[OnName num="gorou"]
"What, ……? What are you talking about?"
[cpg cn=true]


[OnName num="female_student"]
“Oh, nothing! See you then."
[cpg cn=true]


...... She left quickly leaving me to think that she probably has a thing for me too.
[cpg]


I have such feelings for a girl as well.
[cpg]


But it's not the same when I think about spending the rest of my life with her.
[cpg]


Looking back, I've been going after Suzune for a long time.
[cpg]


I've always admired her. I was reminded of that.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


Then it was noon again, and my time with Suzune arrived.
[cpg]

[window target=false]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[OnName num="gorou"]
"......Please. It's already hard for me. ......"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune130"]
[OnName num="suzune"]
“It must be hard for you. It would be hard for me, too, if I were in your shoes."
[cpg cn=true]


...... That sounded strange. If she were in my shoes?
[cpg]


[OnName num="gorou"]
“What do you mean ......?"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune029"]
[OnName num="suzune"]
“It's nothing. More importantly, what should we do today?"
[cpg cn=true]


She changes the subject. I'm still having a hard time breathing.
[cpg]



I can't think of things that are unimportant. Hmmm.
[cpg]


[OnName num="gorou"]
“Okay then.……"
[cpg cn=true]


;//========================================
;//●ＣＧ（座っているヒロインのことを見つめる主人公）ev_17
;//人物１：ヒロイン１
;//服装１：スーツ（はだけ）
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


I had come up with something that wasn't the same as before, and I decided to give it a shot.
[cpg]


Suzune seems a little uninterested, but I like her facial expression.
[cpg]


[VOICE f="Suzune134"]
[OnName num="suzune"]
“……, you come up with the strangest things."
[cpg cn=true]


Today, I'm not going to have Suzune touch me or get close to me.
[cpg]


I want to watch her. I had asked her if I could do that.
[cpg]


[OnName num="gorou"]
“It's not strange. I want to watch you at all times.”
[cpg cn=true]


My words seem to confuse Suzune a bit.
[cpg]


;**【ＣＧ】 ev_17_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune030"]
[OnName num="suzune"]
“I mean, is that really what you want to do, just watch?"
[cpg cn=true]


[VOICE f="sSuzune031"]
[OnName num="suzune"]
“I think you need to ...... touch or get close to me or something."
[cpg cn=true]


I can be excited enough without that. The current me probably can.
[cpg]


[OnName num="gorou"]
“…… yeah."
[cpg cn=true]


Looking at her, she is everything I need.
[cpg]


I'm too embarrassed to say that, but I think it’s okay to think that.
[cpg]


;**【ＣＧ】 ev_17_b ***********************
[CG id=8 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune032"]
[OnName num="suzune"]
“The way you look at me Goro, is kind of dirty.”
[cpg cn=true]


[OnName num="gorou"]
"Yeah, I guess so."
[cpg cn=true]


Suzune is puzzled and embarrassed at the same time.
[cpg]


Maybe being stared at provokes a certain feeling.
[cpg]


[OnName num="gorou"]
“Suzune ...... You’re really, really beautiful."
[cpg cn=true]


Suzune was looking at me, but now she is looking away.
[cpg]


;**【ＣＧ】 ev_17_c ***********************
[CG id=8 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune033"]
[OnName num="suzune"]
“How can you say that?”
[cpg cn=true]


[OnName num="gorou"]
“I'm not lying. I mean it.”
[cpg cn=true]


She seems to shake a little hearing my words.
[cpg]


[VOICE f="sSuzune034"]
[OnName num="suzune"]
“You’re not even touching me. This is strange, I'm feeling nervous too.”
[cpg cn=true]


Suzune says, and her face reddens.
[cpg]


I couldn't just look at her like that.
[cpg]


[OnName num="gorou"]
“I want to keep staring at you, Suzune”
[cpg cn=true]


Suzune, still embarrassed says;
[cpg]


;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune035"]
[OnName num="suzune"]
“It's as if ...... You words are touching me.”
[cpg cn=true]


She probably meant what she said.
[cpg]


As proof, Suzune's ears turned red.
[cpg]


I wanted to observe everything. That’s how I felt.
[cpg]


Suzune accepts everything I say and do.
[cpg]


I felt there was something maternal about her.
[cpg]


[OnName num="gorou"]
“I'm just looking at you, but I'm happy."
[cpg cn=true]


;**【ＣＧ】 ev_17_c ***********************
[CG id=8 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune036"]
[OnName num="suzune"]
“Don't say that. I feel embarrassed although I'm flattered."
[cpg cn=true]


Suzune certainly looked both shy and happy.
[cpg]


Just by looking at her reactions I feel happy.
[cpg]


[FG f="ci_lbox.ui" method="feadin_up"  pos="4/7"]

[WAIT time=1000]
;//ブラックアウト


[SE f="se001"]
;//【ＳＥ】『学園のチャイム』


Some time passes. We can't be with each other forever.
[cpg]


After lunch break, both Suzune and I have to go to class.
[cpg]


This time was more frustrating than ever.
[cpg]





[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]


[window target=true]


And then afternoon classes were over and school ended.
[cpg]


[window target=false]


[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



School at the evening. I leave the classroom and decide to go back home.
[cpg]


I had a thought.
[cpg]


......Three times a day, I have time to get my heart to pound.
[cpg]


I had come to want to spend all of it with Suzune.
[cpg]


I'd have to talk to mom first.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************





When I got home, mom was the only one there.
[cpg]


[OnName num="gorou"]
"Oh, you know, ...... Mom ."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa101"]
[OnName num="sawa"]
“What is it? It's a little early for you, isn't it?”
[cpg cn=true]


[OnName num="gorou"]
“Umm... I was hoping you could replace the night shifts with Suzune."
[cpg cn=true]


I explained everything. Except for the part that I was fond of her.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa102"]
[OnName num="sawa"]
"......, yes. I see.”
[cpg cn=true]


But Mom seemed to have it all figured out. In the end she’s my Mom so ......
[cpg]




;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[WAIT time=1000]

[SE f="se012"]
;//【ＳＥ】『ノック』


[WAIT time=1500]

[window target=true]


;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune151"]
[OnName num="suzune"]
"I'm coming in, Goro ."
[cpg cn=true]


[OnName num="gorou"]
“Uh, yeah, come on in ......."
[cpg cn=true]


[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune037"]
[OnName num="suzune"]
“I heard from mom that you want me instead of mom at night?”
[cpg cn=true]


[OnName num="gorou"]
“Do you think it’s wrong…… I want it to be this way.”
[cpg cn=true]


Somehow, I had a feeling that she would not say no.
[cpg]


Then Suzune sighed a little and said;
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune153"]
[OnName num="suzune"]
“Do you think I could say no if you told me that? Really, you’re my sweet little brother."
[cpg cn=true]



;//========================================
;//●ＣＧ（密着する二人。ヒロインが体を前に倒している状態。ヒロインの髪が主人公の体に当たっている）ev_18
;//人物１：ヒロイン１
;//服装１：着衣
;//人物２：主人公
;//服装２：着衣
;//場所　：主人公の部屋
;//時間　：夜
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]


[SE f="se004"]
;//【ＳＥ】『衣擦れ』


[BGM f="bg_h1"]
;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune038"]
[OnName num="suzune"]
“Maybe ...... I've gone crazy too."
[cpg cn=true]


She says this with a slightly clouded expression, or rather, a melancholy look in her eyes.
[cpg]


[OnName num="gorou"]
“What do you mean by that?"
[cpg cn=true]


Suzune is choosing her words carefully. I felt like she is thinking of what to say.
[cpg]


[VOICE f="sSuzune039"]
[OnName num="suzune"]
“Without you, I feel as if my heart is in pain.”
[cpg cn=true]


...... How should I respond to that?
[cpg]


It seemed like she really meant what she said.
[cpg]


Of course I'm suffering from my condition, but I couldn’t imagine that Suzune would be affected by that.
[cpg]


[VOICE f="sSuzune040"]
[OnName num="suzune"]
“I just want to be closer to you. I don't know why.”
[cpg cn=true]


Suzune’s long hair is hitting my body. I feel frustrated.
[cpg]


[OnName num="gorou"]
“Suzune. Your hair tickles me.”
[cpg cn=true]


I dared to say it, though I'm sure she didn't even notice. Then.
[cpg]


;**【ＣＧ】 ev_18_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune041"]
[OnName num="suzune"]
“Really? You don't like it?"
[cpg cn=true]


She says something that makes it even harder for me to escape.
[cpg]


[OnName num="gorou"]
“...... I don't hate it.”
[cpg cn=true]


[VOICE f="sSuzune042"]
[OnName num="suzune"]
“Then that’s fine. Let me stay like this a little longer."
[cpg cn=true]


Suzune is being aggressive. I don't feel like she is trying to make me feel nervous.
[cpg]


At first everything was for my health’s sake, but this has nothing to do with the condition.
[cpg]


I feel like we've come to a point where we shouldn't have.
[cpg]


But even so, I don't hate it.
[cpg]


[OnName num="gorou"]
“Yeah. We can stay here as long as you want to."
[cpg cn=true]


;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune043"]
[OnName num="suzune"]
“That's doesn’t seem right. I'm doing this for your condition.”
[cpg cn=true]


But I feel like that's an excuse, or our common escape route.
[cpg]


What will we do when this condition is cured?
[cpg]


[VOICE f="sSuzune044"]
[OnName num="suzune"]
“You smell nice Goro."
[cpg cn=true]


The reverse is also true. We’re that close.
[cpg]


It's as if not only our bodies but also our minds have become closer.
[cpg]


;**【ＣＧ】 ev_18_b ***********************
[CG id=9 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune045"]
[OnName num="suzune"]
“It's strange. We are always together, but you seem like a different person.”
[cpg cn=true]


As she says this, she moves closer. Her breath hits me.
[cpg]


I wish time would stop. I feel relaxed with my heart pounding like this......
[cpg]


It sounds contradictory to say "relaxed by my heart pounding," but it seemed to be the right expression.
[cpg]


I'm sure it's something that a couple of half-hearted lovers wouldn't be able to feel.
[cpg]


;**【ＣＧ】 ev_18_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSuzune046"]
[OnName num="suzune"]
“I want to be with you more. But I'm worried about you, too.”
[cpg cn=true]


Even though Suzune and I are not blood related, we are also siblings.
[cpg]


I'm sure that's part of the reason of why I felt safe with her.
[cpg]


[VOICE f="sSuzune047"]
[OnName num="suzune"]
“If doing this would make me feel any better, I would ...... do it all the time.”
[cpg cn=true]


Suzune was coming close to me as she said this.
[cpg]


[OnName num="gorou"]
“I’m happy, Suzune "
[cpg cn=true]


Her words seem too precious for me, but that doesn't mean I would want to give them to someone else.
[cpg]


I want Suzune to be mine.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]



[OnName num="gorou"]
“Thank you. I'm fine now.”
[cpg cn=true]


Breathing is not painful at all anymore. But my heart was suffering a little.
[cpg]


It's as if my body and mind are at odds with each other.
[cpg]


[VOICE f="sSuzune048"]
[OnName num="suzune"]
"Is that so? You should take it easy."
[cpg cn=true]


I really wish I could go to bed with her, but if I did, I might get used to the heart pound.
[cpg]



[window target=false]


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




I didn't feel like I was going to wake up with the usual, strange dreams.
[cpg]


Maybe it was the feeling of fulfillment that I was given by her.
[cpg]


I didn't feel lonely, even in a room by myself. ......
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



It is morning. Now I have to talk to Himari .
[cpg]


I thought I should have done that yesterday, but…
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari026"]
[OnName num="himari"]
“Good morning. I'm going to make you excited again today."
[cpg cn=true]


Himari comes up to me.
[cpg]


She has her big breasts pressed up against me, but I didn't let them distract me.
[cpg]


[OnName num="gorou"]
"You know, ...... I'm sorry that you always have to do this for me but,……”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari117"]
[OnName num="himari"]
“What? Are you saying you want me to switch places with my sister?"
[cpg cn=true]


[OnName num="gorou"]
“Huh ……"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Himari118"]
[OnName num="himari"]
“I've heard most of it from mother. You really like my sister that much, don't you?"
[cpg cn=true]


Himari looks a little sad.
[cpg]


That......moved me.
[cpg]


This is not good. Being half-hearted would hurt Himari.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune170"]
[OnName num="suzune"]
“...... Should I do it in the morning too? I’ll be helping you three times a day.”
[cpg cn=true]


[OnName num="gorou"]
“Is that bad?”
[cpg cn=true]


Suzune laughs a little. I must have looked like an idiot.
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune049"]
[OnName num="suzune"]
“No. Then ......."
[cpg cn=true]


;//ブラックアウト

;//========================================
;//●ＣＧ（主人公に寄り添うヒロイン。朝出かける前）ev_19
;//人物１：ヒロイン１
;//服装１：スーツ
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h1"]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



Words were not needed in this situation but I felt like it was wrong if I didn’t say anything.
[cpg]


[OnName num="gorou"]
“It's warm, Suzune "
[cpg cn=true]


Suzanne looks at me. Then she asks me this.
[cpg]


[VOICE f="sSuzune050"]
[OnName num="suzune"]
"...... you don’t feel excited from only being around me anymore?"
[cpg cn=true]


[OnName num="gorou"]
“No, that’s not true.”
[cpg cn=true]


[VOICE f="sSuzune051"]
[OnName num="suzune"]
“Are you sure you're not just saying that to please me?”
[cpg cn=true]


[OnName num="gorou"]
“It's true. Please don’t make that painful expression.”
[cpg cn=true]


[VOICE f="sSuzune052"]
[OnName num="suzune"]
“Are you sure? I hope it’s true.”
[cpg cn=true]


Suzune leans in close to me as she says this.
[cpg]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[VOICE f="sSuzune053"]
[OnName num="suzune"]
“I’m interested in nothing else but you...... Goro.” she says. “I'm sorry I accused you.”
[cpg cn=true]


Her soft touch. With only that my heart is pounding.
[cpg]


I wanted to be closer to her. My desire didn't stop there.
[cpg]


I wanted to be……her lover.
[cpg]


[OnName num="gorou"]
“Sis. Um, well..."
[cpg cn=true]


I was about to say something but Suzune had thoughts of her own.
[cpg]


;**【ＣＧ】 ev_19_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune054"]
[OnName num="suzune"]
“I'm also very nervous, ...... Can you sense it?”
[cpg cn=true]


[OnName num="gorou"]
“Yes. I can feel it.”
[cpg cn=true]


The less aggressive I am, the closer Suzune seems to get.
[cpg]


The relationship is somehow reassuring in a way that is different from the pounding of the heart.
[cpg]


;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune055"]
[OnName num="suzune"]
“Huh, this is kind of embarrassing."
[cpg cn=true]


We talk about such things as we spend time together.
[cpg]


[OnName num="gorou"]
“This might be embarrassing but……I want to stay by your side."
[cpg cn=true]


[VOICE f="sSuzune056"]
[OnName num="suzune"]
“Yes. Same for me."
[cpg cn=true]


Suzune is closer to me than anyone else, but I still felt frustrated.
[cpg]


[VOICE f="sSuzune057"]
[OnName num="suzune"]
“Goro ......"
[cpg cn=true]


Suzune strokes my head, whispering.
[cpg]


She is stroking my hair. Her face gets closer.
[cpg]


And her lips are getting close. I quickly close my eyes.
[cpg]


There is almost no distance between us. Everything moves quickly, I don’t know what to do.
[cpg]


;**【ＣＧ】 ev_19_a ***********************
[CG id=10 index=1 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune058"]
[OnName num="suzune"]
“Mwah."
[cpg cn=true]


Our lips touch each other. She takes a step toward me.
[cpg]


I love her so much that I feel like I'm going crazy. Words cannot explain how much I love her.
[cpg]


I don't know anyone that I can love this much. I feel like I want to hug her right now.
[cpg]


It’s hard to stop, but we can't stay like this forever.
[cpg]


;**【ＣＧ】 ev_19_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSuzune059"]
[OnName num="suzune"]
“It’s time. I have to go."
[cpg cn=true]


Suzune says while I’m still somewhat paralyzed.
[cpg]


I cursed myself for my helplessness, but I was glad she kissed me.
[cpg]


[OnName num="gorou"]
“Have a good day.”
[cpg cn=true]


I don't think I will forget the feeling of her lips for a while.
[cpg]


Maybe not for a while, but probably never.
[cpg]


;//ブラックアウト



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


Then, Suzune leaves the house before me.
[cpg]


It was the usual thing, but the loneliness felt different than usual.
[cpg]


I will see her when I go to the school, but I miss her so much.
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa103"]
[OnName num="sawa"]
“Bye. Be careful.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah. I'm heading out"
[cpg cn=true]


Himari and I leave the house. I had a secret in my heart.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************



I am going to confess my feelings to Suzune. I want to be with her.
[cpg]


She is an irreplaceable sister, but I still want to be with her.
[cpg]


I want to kiss Suzune and hug her.
[cpg]


Even if this condition was cured.
[cpg]


I’d still want to be with Suzune .
[cpg]


I can say that I owe Himari in that sense. If she hadn't told me, I might have never realized it.
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

During the day, as usual, I ask Suzune to get my heart rate up. But then ...... after school.
[cpg]

[WAIT time=1000]

[STOPBGM]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（夕方）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune190"]
[OnName num="suzune"]
“Now what ……? We already did that during lunch.”
[cpg cn=true]


[OnName num="gorou"]
“...... Suzune, you said I should be with someone I like.”
[cpg cn=true]


Suzune hardens her expression a little. Maybe she is imagining what I am going to say.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune191"]
[OnName num="suzune"]
“...... what about it?”
[cpg cn=true]


I still have to say it. I can't let her guess what I'm thinking.
[cpg]


If I'm spoiled with such a thing, I'll really be spoiled for the rest of my life.
[cpg]


[OnName num="gorou"]
"Oh, I ...... am, that ……"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune192"]
[OnName num="suzune"]
“I know. You like me, don't you?"
[cpg cn=true]


Oh no. This might spoil me for the rest of my life.
[cpg]


But I can't help it now. I've said my piece.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune193"]
[OnName num="suzune"]
“Don't worry, I like you too. Not as a brother, but as a lover.”
[cpg cn=true]




;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



Me and Suzune are leaving separately. We have different jobs and schoolwork, and different hours that we devote to them.
[cpg]


However, I felt that I wanted to go home with her at least for today.
[cpg]


In the end, Suzune told me to go home on my own,…… Making me long for her even more.
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





There was nothing unusual at the dinner table that day.
[cpg]


I was the same as usual. Suzune was the same as usual.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari119"]
[OnName num="himari"]
“I’d like another portion of rice. Maybe a little more than half of the rice bowl!”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune194"]
[OnName num="suzune"]
“You'll get fat."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Himari120"]
[OnName num="himari"]
“Unlike you sister, I use up calories quite easily.”
[cpg cn=true]


Suzune is quite skinny yet Himari says such things.
[cpg]


But Suzune doesn’t seem to care. Or rather, she seemed like she was deep in thought……
[cpg]


I wonder if she's thinking about me……
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





At night, Suzune came to my room.
[cpg]


[OnName num="gorou"]
“Uh, uh, ...... How are you?”
[cpg cn=true]


One of the three times a day I raise my heart rate. And yet, I feel awfully nervous.
[cpg]


In the midst of all this, my sister said to me;
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune060"]
[OnName num="suzune"]
“I have to tell you, I've never had a boyfriend.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah, ......."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune061"]
[OnName num="suzune"]
“I mean you're the first one."
[cpg cn=true]


With that said, Suzune moved closer.
[cpg]


;//移植前シーンカット
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]

;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]



[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

When I am with her, I feel a sense of deeper fulfillment.
[cpg]


This is probably something inherent, rather than connected with my condition.
[cpg]


I am excited. Even after Suzune left I couldn’t sleep.
[cpg]


I want her to stay with me forever. But Suzune left the room.
[cpg]


It can't be helped. It would be bad if Dad saw her coming out of my room.
[cpg]


I have no choice but to wait for tomorrow.
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



Tomorrow came and I felt awkward.
[cpg]


I never thought I would feel like this. I couldn’t believe that Suzune and I had developed a relationship.
[cpg]


It feels like she’s a different person now, or maybe I'm the one who has changed.
[cpg]


Thinking this, I see Suzune off.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune213"]
[OnName num="suzune"]
“I'm going to go now Goro and Himari.”
[cpg cn=true]


[OnName num="gorou"]
“Yes. Be careful."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari121"]
[OnName num="himari"]
“Have a good day."
[cpg cn=true]

[free time=1000]
Dad also left the house. Only three of us were left. Himari, mom and me.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Sawa104"]
[OnName num="sawa"]
“So what are you going to do? Are you going to go out with Suzune?”
[cpg cn=true]


[OnName num="gorou"]
"Yeah. ......umm. That's the plan.”
[cpg cn=true]


For a moment I was puzzled, but I was able to answer.
[cpg]


I couldn't hide it any longer.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Himari122"]
[OnName num="himari"]
“You seem happy. I liked you too.”
[cpg cn=true]


[OnName num="gorou"]
“...... yea.”
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[SE f="se003"]
;//【ＳＥ】『ドア閉まる』





An empty classroom .
[cpg]


I have trouble breathing and I feel wobbly, but I was face to face with Suzune .
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune214"]
[OnName num="suzune"]
“...... I didn't want to do it just because of your condition."
[cpg cn=true]


She tells me this as she approaches me.
[cpg]


I guess she was worried because she was thinking of me. I can sort of imagine that.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune215"]
[OnName num="suzune"]
“Besides, I couldn't help but feel jealous while Himari and mom were dealing with you."
[cpg cn=true]


[OnName num="gorou"]
“...... Oh I didn’t know.”
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune062"]
[OnName num="suzune"]
“It doesn’t matter now. I'll fulfill everything for you."
[cpg cn=true]


Yes. Everything was up to me now.
[cpg]


I felt rather comfortable with that.
[cpg]


;//移植前シーンカット



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


[SE f="se001"]
;//【ＳＥ】『学園のチャイム』

From now on, I can stay with her forever. Just thinking that made me feel relieved.
[cpg]


[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************



At the same time that I was relieved, my desire for my heart pounding was getting stronger.
[cpg]


It was really just a small time gap, but I couldn't take it anymore.
[cpg]


I couldn't stand it anymore. But Suzune said it was night and left.
[cpg]


To begin with, the change from Mom to Suzune meant that I wouldn't be able to see anyone as soon as I got home.
[cpg]


I was walking while carrying this unbearable feeling......
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





Dinner time. The situation is that only Dad doesn’t know about the relationship between Suzune and I.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari123"]
[OnName num="himari"]
“So how far did you go with my sister Goro?”
[cpg cn=true]


In the midst of dinner, Himari asks. I almost spit out what I was eating.
[cpg]


[free time=1000]

[OnName num="father"]
“What are you talking about?"
[cpg cn=true]


[OnName num="gorou"]
Nothing. Nothing much.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]

With that said, Suzune seemed a bit grumpy.
[cpg]


Yeah, I'll have to explain that to Dad sometime.
[cpg]


He’s not a strict and stubborn father by any means, but ......
[cpg]


It made me nervous. I felt somewhat anxious when I thought about having to tell dad.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





And night after night. Before I would reach my limit, Suzune came to my room.
[cpg]



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune063"]
[OnName num="suzune"]
“You look so happy.”
[cpg cn=true]


[OnName num="gorou"]
“...... Is it that obvious?”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune064"]
[OnName num="suzune"]
“Of course. But you're cute in that way, too."
[cpg cn=true]


I was embarrassed, but waited to see what Suzune would do.
[cpg]


I don't know, but we've been doing this a lot. I feel like I should be the one to take the lead.
[cpg]

;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I watch Suzune go back to her room again, and although in agony I manage to fall asleep.
[cpg]


Tomorrow, we will still be lovers. I'm happy. ......
[cpg]


Although I should be happy, my body condition makes me feel somewhat constricted.
[cpg]


I have to do something about it. I guess I need to be more do things that lovers would do.
[cpg]


It seems like ……a tunnel without an end, but I'll have to explain it to Dad .
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


And the day came surprisingly quickly.
[cpg]

[window target=false]

[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************





[OnName num="gorou"]
“I can’t! I'm not ready."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune253"]
[OnName num="suzune"]
“He’s in a good mood today. Not that he’s always in a bad mood."
[cpg cn=true]


;//＠
One Sunday. I was approached with the idea.
[cpg]


I’m going to say to Dad; “Please give me your daughter!”
[cpg]


;//ブラックアウト


[window target=false]

[STOPBGM]

[free time=1000]

[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************



Himari and Mom are not here. It's dad, Suzune and me.
[cpg]


[OnName num="father"]
“……”
[cpg cn=true]


[OnName num="gorou"]
“……”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune254"]
[OnName num="suzune"]
“So umm...... Can you start Goro?”
[cpg cn=true]

Dad did not have a stern face, but his expression was close to expressionless and somewhat scary.
[cpg]


[OnName num="gorou"]
"Mmm, please give your daughter to ...... me."
[cpg cn=true]


[OnName num="father"]
“……"
[cpg cn=true]


The moment I said that, I thought I saw a smile on the corner of dad 's mouth.
[cpg]


[OnName num="gorou"]
“Well, I want to go out with Suzune ...... or rather, we are going out."
[cpg cn=true]


[OnName num="father"]
“Pfft, ha ha ha! Oh well, I knew this day would come."
[cpg cn=true]


[OnName num="gorou"]
“What? ......?"
[cpg cn=true]


Dad’s reaction was surprising. I had expected that they would be confused as well.
[cpg]


[OnName num="father"]
“In that case I want you to take care of Suzune. Goro I'm sure you’re the right one."
[cpg cn=true]


He smiles and congratulates us.
[cpg]


What a great Dad I thought, and of course I was ...... grateful, so...
[cpg]


[OnName num="gorou"]
“Oh, thank you very much ......."
[cpg cn=true]


I say. I had never used polite language with dad.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[OnName num="gorou"]
"...... that went well."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune255"]
[OnName num="suzune"]
“I guess so. I thought he sort of already knew.”
[cpg cn=true]


They were indeed father and daughter.
[cpg]


I don't understand all of Dad 's feelings, but Suzune seemed to understand.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune256"]
[OnName num="suzune"]
“It's almost time to go. It's hard, isn't it?”
[cpg cn=true]


[OnName num="gorou"]
“Yeah ...... it's hard."
[cpg cn=true]


My condition is still not cured. I'm pretty sure I'm in love, but it will take a little longer for it to cure my condition.”
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune065"]
[OnName num="suzune"]
“Come. This time I want you to make me excited."
[cpg cn=true]


[OnName num="gorou"]
"I'll try ......."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune258"]
[OnName num="suzune"]
She giggles. “You've grown up enough to say that."
[cpg cn=true]


She pats me on the head. I feel embarrassed.
[cpg]

;//移植前シーンカット

;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************




Days passed. It's summer vacation, which is good.
[cpg]


There were rumors going around school that Suzune and I were in love.
[cpg]


Summer vacation ended while the rumors were still going on.
[cpg]


It became a big news in the school. Countless boys were shocked by it, as well as some of the girls ......
[cpg]



[window target=false]

[STOPBGM]

[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]


[window target=true]


;//【ＢＧ】『街』（夜）******************************************************



Still, the days flow by. I wanted to appear as someone worthy of being Suzune’s lover.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune066"]
[OnName num="suzune"]
“...... Is it still hard sometimes?”
[cpg cn=true]


[OnName num="gorou"]
“No, it’s much easier now.”
[cpg cn=true]


Since then, my condition has calmed down as if nothing had happened.
[cpg]


I thought what the doctor had suggested was a joke, but it was absolutely true.
[cpg]


I wondered if I could categorize it as merely a “condition”, but me and Suzune didn't have to get closer than we already were.
[cpg]


That doesn't change the fact that we still want each other, though.
[cpg]


[OnName num="gorou"]
“Those days seem like far in the past.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune278"]
[OnName num="suzune"]
“I agree. Those days were fun, but..."
[cpg cn=true]


[OnName num="gorou"]
“Is it you now that can’t stand it sister?”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune279"]
[OnName num="suzune"]
“I'm really hoping you'll stop calling me ‘sister’."
[cpg cn=true]


[OnName num="gorou"]
“Well, that's ......."
[cpg cn=true]


Surely, it's about time I fixed that.
[cpg]


[OnName num="gorou"]
But what can you do about something that's become so entrenched?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune067"]
[OnName num="suzune"]
“What if we have a child? Are you still going to refer to me as ‘sister’?"
[cpg cn=true]


[OnName num="gorou"]
“I'll call you mother then."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune281"]
[OnName num="suzune"]
“You're getting cheekier with your responses…….”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune068"]
[OnName num="suzune"]
“I wish I could stay with you all day. We don't have to hide it from anyone anymore."
[cpg cn=true]


[OnName num="gorou"]
“Yeah……wait."
[cpg cn=true]


Suzune started stroking my hair. I wriggle because it felt ticklish.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune069"]
[OnName num="suzune"]
“What?"
[cpg cn=true]


[OnName num="gorou"]
“That tickles. Ha-ha-ha-ha.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune070"]
[OnName num="suzune"]
“I wonder if you have a weakness for being tickled? Shall I tickle you more?”
[cpg cn=true]


We were flirting.


[window target=false]

[SE f="se000"]
;//【ＳＥ】『ノック』

[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************




In the midst of all this, there was a knock on the door of my room.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari124"]
[OnName num="himari"]
"Hey brother, are my comic books here?”
[cpg cn=true]


[OnName num="gorou"]
“Oh, Himari ……? I don't know.”
[cpg cn=true]


It is quite late at night. At this hour, talking about comic books?
[cpg]


I guessed. She was implying that we were being too loud.
[cpg]


[OnName num="gorou"]
"...... Were we loud?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari125"]
[OnName num="himari"]
“What? More importantly, what about the comic books?"
[cpg cn=true]


[OnName num="gorou"]
“Oh, um, I don't think I borrowed them.……"
[cpg cn=true]


Suzune reads the room and stays quiet. But
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari126"]
[OnName num="himari"]
“Hmmm. Well, I wish you all the best then."
[cpg cn=true]

[free time=1000]

Himari says. I guess we were still too loud.
[cpg]


[OnName num="gorou"]
"...... what should we do, Suzune?”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune299"]
[OnName num="suzune"]
“Don't worry about it. She said ‘I wish you all the best’.”
[cpg cn=true]


That's true, but I think it's ...... sarcasm.
[cpg]


;//＠なんて思いつつ、俺達はもう一度交わることにした。




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


More time passes. My condition has calmed down completely and I no longer have to go to the hospital.
[cpg]


They asked me to explain what had happened, but I was just embarrassed.
[cpg]


I wish I could have had Suzune beside me. I thought.
[cpg]


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（昼）******************************************************



Time passes. One holiday, I was walking with Suzune .
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune316"]
[OnName num="suzune"]
"It's convenient that we can live in the same house after we get married.”
[cpg cn=true]


[OnName num="gorou"]
“Oh, that's for sure. There's nothing to think about, is there?"
[cpg cn=true]


What a conversation, our relationship was a little different again.
[cpg]


Suzune was pregnant with a baby. Apparently it's a girl, and we've already thought of a name.
[cpg]


[OnName num="gorou"]
"Well, ...... I don't know what I'm going to do about it. I'm still trying to decide if I want to go on to higher education."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune317"]
[OnName num="suzune"]
“I told you before. Keep going to school.”
[cpg cn=true]


[OnName num="gorou"]
“But it’ll be hard for you. I’d better hurry up and get a job."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Suzune318"]
[OnName num="suzune"]
“You should prioritize what you want to do. It's not like you're being spoiled, you can count on me."
[cpg cn=true]


I decided to accept her support.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_01_2_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune071"]
[OnName num="suzune"]
“Anyway, do you remember what day it is today?”
[cpg cn=true]


[OnName num="gorou"]
“Let's see, ...... what was it? ……"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune072"]
[OnName num="suzune"]
“You don't remember? It’s when we started dating.”
[cpg cn=true]


[OnName num="gorou"]
“I don't remember the day we started dating..……it was never really clear to me.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune073"]
[OnName num="suzune"]
“I know it's a little fuzzy, but I still want to celebrate.”
[cpg cn=true]


[OnName num="gorou"]
“I don't know if that's how it works.”
[cpg cn=true]



[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune074"]
[OnName num="suzune"]
“You're so dull like that, Goro ."
[cpg cn=true]


[OnName num="gorou"]
“I mean, the date's a little fuzzy, but I've always wanted to celebrate, too."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sSuzune075"]
[OnName num="suzune"]
“What?”
[cpg cn=true]


[OnName num="gorou"]
“I have a present for you. Shall we open it when we get home?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune076"]
[OnName num="suzune"]
“Thank you ......."
[cpg cn=true]



[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


After the baby was born, we were really busy.
[cpg]


I'm a student, but I'm also a househusband, and I had to raise the baby.
[cpg]


But I don't think it's hard work. It didn’t feel forced.
[cpg]


That's how fast-paced and lovely the days passed next to Suzune.
[cpg]



Time flies. Three years passed.
[cpg]




;//========================================
;//●ＣＧ（街を三人で歩く。幸せそうなヒロインと娘の笑顔が正面から見えるアングル）ev_26
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//人物３：主人公の娘
;//服装３：私服
;//場所　：街
;//時間　：昼
;//備考　：娘の年齢は三歳くらいです。また、本編から三年の時間が経過しています
;//========================================




[BGM f="bg_h1"]
;**【ＣＧ】 ev_26_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]




We became a happy couple, I think.
[cpg]


We didn't fight even once with each other. We don't have that kind of a relationship.
[cpg]


People around us envy us, but this was natural.
[cpg]


I don't want to fight now. We've been together longer than most couples.
[cpg]


We knew each other better than any couple who have known each other since childhood.
[cpg]


[VOICE f="Suzune319"]
[OnName num="suzune"]
"Hey, Goro ."
[cpg cn=true]


Suzune turns to me and smiles.
[cpg]


[OnName num="gorou"]
"What's up, Suzune?"
[cpg cn=true]


[VOICE f="Suzune320"]
[OnName num="suzune"]
“I'm so happy. I still can't believe I can live this happy life as your wife"
[cpg cn=true]


...... That's because she’s been a sister for longer. It can't be helped.
[cpg]


But now we'll be spending more time together as a married couple.
[cpg]


I'll have to outgrow being her brother soon. Somewhere I still think of Suzune as a big sister.
[cpg]


;//ブラックアウト

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

And by the time I graduate from being Suzune's brother, my daughter might have a sister or a brother.
[cpg]


With that thought in mind, we began our journey together.
[cpg]



[SCENE id=9]

[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン１ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

*start

;###################################################################
*Ep006|Caring for Himari.
;###################################################################

;//==============================
;//２、ひまり
*select04_2|Caring for Himari.


[SCENE id=6]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


I think ……it’s Himari. Although she’s definitely not reliable.
[cpg]


But if you ask me who I like, I like Himari .
[cpg]


She is like a child, but also motherly.
[cpg]


There's a part of her that is just playing with me, but I've grown to like her.
[cpg]


To like someone like her, maybe says that I somewhat enjoy being bullied.
[cpg]


I don't hate it when I’m dealing with Himari ......
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[WAIT time=1000]



[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari127"]
[OnName num="himari"]
"Brother. It's morning fun time!”
[cpg cn=true]


While I was thinking about this, Himari comes along.
[cpg]


[OnName num="gorou"]
“Oh, yeah. Yeah. ......."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari128"]
[OnName num="himari"]
“What's wrong? You don't look well."
[cpg cn=true]


[OnName num="gorou"]
“I'm fine, it's just that ...... I need to talk to you about something."
[cpg cn=true]


I look at her in the eyes and I begin to talk.
[cpg]


[OnName num="gorou"]
“You know how they told me that my condition would settle down if I fall in love with someone?”
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari129"]
[OnName num="himari"]
“I know. The doctor said so.”
[cpg cn=true]


[OnName num="gorou"]
“So what do you think...... Himari?"
[cpg cn=true]


I asked quite discreetly. But Himari seemed to have guessed.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari027"]
[OnName num="himari"]
“I guess. I'm totally fine with having you as a partner. I'd be happy......."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari028"]
[OnName num="himari"]
“What are you going to do if we get together and the condition doesn't go away?"
[cpg cn=true]


[OnName num="gorou"]
“What do you mean? ...... Well, that's certainly troubling, but..."
[cpg cn=true]


I was thinking of myself, but Himari seemed to be thinking a little differently.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Himari132"]
[OnName num="himari"]
“You might cheat on me with someone else. With a condition like that."
[cpg cn=true]


So that’s what she's worried about…
[cpg]


[OnName num="gorou"]
“I won't. I can assure you.”
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari133"]
[OnName num="himari"]
“I can't believe it. I can be pretty skeptical and jealous."
[cpg cn=true]


She says as she comes on to me.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari029"]
[OnName num="himari"]
“For now I'll give you a little excitement. What shall we do?"
[cpg cn=true]


[OnName num="gorou"]
"......Oh, please ......"
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin_up"  pos="4/7"]

[BG f="b_06_1_up.ui" time=10]
[WAIT time=200]


[FG f="CHA02_p3_02_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari030"]
[OnName num="himari"]
“Well, what shall we do? I'm tired of touching it with my hand.”
[cpg cn=true]


[OnName num="gorou"]
“If you say you're tired of it...... then what are you going to do?”
[cpg cn=true]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari031"]
[OnName num="himari"]
“Yes......,how about something like this today?"
[cpg cn=true]


Having said that, Himari did something different.
[cpg]


;//========================================
;//●ＣＧ（ヒロインに足蹴にされる主人公。からかうような表情のヒロイン）ev_27
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：朝
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]



She put her feet, not her hands, close to my body.
[cpg]


I thought that she was crazy, but I couldn't say no because if I didn't like it, it would end without any result.
[cpg]


[VOICE f="sHimari032"]
[OnName num="himari"]
"I don't know. I thought this kind of thing makes you excited, doesn't it?"
[cpg cn=true]


I can't act like I'm happy here, but I can’t look unhappy either.
[cpg]


[OnName num="gorou"]
“…… Yeah"
[cpg cn=true]


[VOICE f="sHimari033"]
[OnName num="himari"]
“You look unsatisfied, but I know you're actually happy."
[cpg cn=true]


[OnName num="gorou"]
“I'm not happy. ...... what kind of personality do you think I have?"
[cpg cn=true]


But it was true. I was feeling excited.
[cpg]


;**【ＣＧ】 ev_27_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari034"]
[OnName num="himari"]
”If this is the spot then I want you to say so. Although its cute that you’re trying to play tough.”
[cpg cn=true]


[OnName num="gorou"]
“It's not what I like.”
[cpg cn=true]


Oh? She looks at my reaction as she says so.
[cpg]


[VOICE f="sHimari035"]
[OnName num="himari"]
“I think the nervousness comes from this unusual circumstance.”
[cpg cn=true]


For that matter, I don't know how Himari comes up with these things.
[cpg]


[OnName num="gorou"]
“Himari...... Do you think of these things all the time?”
[cpg cn=true]


;**【ＣＧ】 ev_27_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari036"]
[OnName num="himari"]
“Hmm? All the time?”
[cpg cn=true]


[OnName num="gorou"]
“Even when you're not seeing me.”
[cpg cn=true]


[VOICE f="sHimari037"]
[OnName num="himari"]
“I don't know. I guess I just come up with it on the spot.”
[cpg cn=true]


Himari then starts to rub my breastplate with her foot.
[cpg]


It's not ticklish or anything. But I feel a strange sense of rebellion.
[cpg]


I didn't do anything lewd, though. ......
[cpg]


[VOICE f="sHimari038"]
[OnName num="himari"]
“Goro, if you have the option between hands or feet, which do you like better?"
[cpg cn=true]


[OnName num="gorou"]
"What's with that question?"
[cpg cn=true]


She asked me something so weird that I couldn't keep my cool.
[cpg]


I couldn't look straight back at her. And Himari saw right through it.
[cpg]


;**【ＣＧ】 ev_27_b ***********************
[CG id=12 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari039"]
[OnName num="himari"]
“Don’t pretend you didn’t hear me. I’m trying to think of what to do next.”
[cpg cn=true]


[OnName num="gorou"]
“……"
[cpg cn=true]


I couldn't even respond to what she had said.
[cpg]


If I said "feet," she would do something to me, but if I said "hands," she would stop what she was doing.
[cpg]


[VOICE f="sHimari040"]
[OnName num="himari"]
“Well, it doesn't matter. From now on, I'll make you feel excited in the evening, too.”
[cpg cn=true]


As I was thinking about this, Himari said something even more surprising.
[cpg]


She is very aggressive. It's not like I asked her to do it.
[cpg]


[OnName num="gorou"]
“What, are you sure……?”
[cpg cn=true]


[VOICE f="sHimari041"]
[OnName num="himari"]
“I mean, I'd like to have you to myself. I’m sure mother will be alright with it.”
[cpg cn=true]


It’s like she was treating me like an object.
[cpg]


But I was happy about that, and I felt that Himari was showing her love to me.
[cpg]




[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


After touching each other, the painful time comes back.
[cpg]


But I will get to see Suzune at noon, and Himari she told me she would be there in the evening ......
[cpg]


Believing this, I just had to endure for now.
[cpg]


[window target=false]


[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************



[SE f="se000"]
;//【ＳＥ】『歩く』





I walk through the streets. All the way to school.
[cpg]


It's still not so painful during that time. But the hardest time is when the morning classes are ending.
[cpg]


Just until the lunch break, but… no matter what I have to be prepared.
[cpg]




[window target=false]


[STOPBGM]

[BG f="b_02_1.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="male_student"]
"Hey, Kosaka. I heard you were walking with a girl the other day."
[cpg cn=true]


[OnName num="gorou"]
“What? Isn’t that normal……"
[cpg cn=true]


[OnName num="male_student"]
“Don't play dumb with me! They say you were arm-in-arm with a girl and she was all over you.”
[cpg cn=true]


[OnName num="gorou"]
“What are you talking about? I've never been that close to a girl. ......"
[cpg cn=true]


Oh, but it could be her. Himari. Maybe someone saw us when we were leaving the house or something.
[cpg]


But if so, it would be obvious that she's my sister.
[cpg]


[OnName num="gorou"]
"That's my sister. Her name is Himari Kosaka.”
[cpg cn=true]


[OnName num="male_student"]
"Oh...... your sister. So she's not your girlfriend or anything."
[cpg cn=true]


[OnName num="gorou"]
“Yeah. Not a girlfriend."
[cpg cn=true]


...... Generally speaking, a sister cannot be a girlfriend.
[cpg]


I might be crazy. I had to be reminded of that.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園廊下』（昼）******************************************************



;//その後、昼休みになって姉さんに抜いてもらった。
;//＠
Later, at lunchtime, I asked Suzune to get my heart rate up.
[cpg]


After that. Suzune said something like this.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune321"]
[OnName num="suzune"]
“Hey. Do you like Himari? Did you perhaps tell her how you felt?”
[cpg cn=true]


[OnName num="gorou"]
“......Can you tell?”
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune322"]
[OnName num="suzune"]
“Of course. She seemed serious when she left your room in the morning."
[cpg cn=true]


That's what she was looking at. She must be very discerning, or very sisterly.
[cpg]


[OnName num="gorou"]
“I guess I did tell her how I felt ......?
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune323"]
[OnName num="suzune"]
”What do you mean I guess? You have to take responsibility.”
[cpg cn=true]


;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]


[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



Suzune lectured me which made me feel somewhat uneasy.
[cpg]


I like Himari. No doubt.
[cpg]


But when I think about whether I had told Himari properly, I can't say for sure.
[cpg]


She was afraid of me cheating. I think it's only natural, considering my condition.
[cpg]

;//＠妊娠しても体質が治らなかったらと考えるのは、当然かもしれない。
That could happen if I fall in love, but my condition is not cured.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（夕方）******************************************************



[OnName num="gorou"]
“I'm home. ……"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari153"]
[OnName num="himari"]
“Welcome back Goro . Let's do this."
[cpg cn=true]


[OnName num="gorou"]
“Isn’t it a little too soon ......?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari042"]
[OnName num="himari"]
“You should be considerate of my mood Goro. You have no right to choose.”
[cpg cn=true]


Like that, she forced my hand and dragged me along.
[cpg]


She takes me to her room......
[cpg]



;//========================================
;//●ＣＧ（主人公に顔を近づけるヒロイン。キスをする）ev_28
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]



She is very close to me. I couldn't look straight at her.
[cpg]


But when I look away, Himari points it out.
[cpg]


[VOICE f="sHimari043"]
[OnName num="himari"]
“Don't look away. Look at me more closely.”
[cpg cn=true]


When someone says something like that, it just makes me nervous.
[cpg]


[OnName num="gorou"]
"...... Alright"
[cpg cn=true]


I have no choice but to nod now. I don't have the guts to refuse.
[cpg]


On the other hand, I don't have the guts to accept it either.
[cpg]


;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari044"]
[OnName num="himari"]
“You're blushing. You're always so naive.”
[cpg cn=true]


Himari is as usual, or rather, she touches me more than usual.
[cpg]


If I was as easygoing as she is, maybe I wouldn't have this condition. ......
[cpg]


[OnName num="gorou"]
“You can't help it. ...... If you stop being excited, thhen we have a problem."
[cpg cn=true]



I was excited by the fact that Himari was closer than usual.
[cpg]


[VOICE f="sHimari045"]
[OnName num="himari"]
“Since then, I've wondered what makes you most excited.”
[cpg cn=true]


Himari looks at me and gives me a scheming smile.
[cpg]


It's exciting to have such a pretty girl at such a distance from me.
[cpg]


But Himari still looked like she wanted to do something.
[cpg]


[OnName num="gorou"]
“Y.. You're really close”
[cpg cn=true]


;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari046"]
[OnName num="himari"]
“Isn't it too late for that? You've done so many things before, and you're afraid to just kiss me?"
[cpg cn=true]


I dared not say the thing, but Himari said it.
[cpg]


I knew she was going to kiss me.
[cpg]


[OnName num="gorou"]
“...... Please be gentle.”
[cpg cn=true]


[VOICE f="sHimari047"]
[OnName num="himari"]
“You sound like a girl, but it's kind of cute.”
[cpg cn=true]


I guess I'll just have prepare myself. With that in mind, I close my eyes and ......
[cpg]


;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari048"]
[OnName num="himari"]
“Heh. Nice face."
[cpg cn=true]


and she didn't kiss me.
[cpg]


I slightly open my eyes and look at Himari .
[cpg]


[VOICE f="sHimari049"]
[OnName num="himari"]
"I think I'll take a picture of your kissing face with my phone."
[cpg cn=true]


[OnName num="gorou"]
“What do you mean?”
[cpg cn=true]


[VOICE f="sHimari050"]
[OnName num="himari"]
“Did you want me to kiss you? If that's the case, I wish you'd say so."
[cpg cn=true]


[OnName num="gorou"]
"Sometimes ...... You look like the devil."
[cpg cn=true]


[VOICE f="sHimari051"]
[OnName num="himari"]
“You mean a little demon? That’s a compliment.”
[cpg cn=true]


Himari chuckles. But being controlled by her, that definitely looks like the devil to me.
[cpg]


[VOICE f="sHimari052"]
[OnName num="himari"]
“So? Do you want me to kiss you?”
[cpg cn=true]


[OnName num="gorou"]
“That's ......."
[cpg cn=true]


While I was stuttering, she gave me an irresistible look and brought her lips to mine.
[cpg]


;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト


;**【ＣＧ】 ev_28_b ***********************
[CG id=13 index=2 time=1000]
;***************************************
[WAIT time=1000]

Our lips touch each other. It was a light kiss, but I felt like we had finally crossed the line.
[cpg]



;//ＣＧ再び表示

;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]

And then she pulls away. We were no longer just brother and sister.
[cpg]


[VOICE f="sHimari053"]
[OnName num="himari"]
“…… Goro , you're really cute."
[cpg cn=true]


I could feel my face getting hotter as she said this to me.
[cpg]


I never thought I would be so thrilled to be told I was cute and ......
[cpg]


I didn't expect the kiss itself to feel this way either.
[cpg]


[VOICE f="sHimari054"]
[OnName num="himari"]
“Well then. I'll put off kissing for a while. I don't want you to be unable to get excited by our usual meetings.”
[cpg cn=true]


I think my face is getting red. I think it's even more so because Himari is also blushing.
[cpg]


I wonder what kind of relationship we are going to have…….
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[window target=true]


I fell asleep with that thought in mind.
[cpg]


I felt like I couldn't sleep, but I was happy.
[cpg]


I wondered if she was in a similar frame of mind......, but I couldn't be sure.
[cpg]


A little while later, on Saturday.
[cpg]

[window target=false]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の家＿玄関』（昼）******************************************************



I had just returned from the hospital.
[cpg]


Mom and I went to see the doctor, and he told me something ...... shocking.
[cpg]




;//ブラックアウト


[window target=false]


[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Himari173"]
[OnName num="himari"]
"Welcome back. How was it?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="Sawa105"]
[OnName num="sawa"]
“It’s…… kinda, kinda a big deal."
[cpg cn=true]


I'll have to tell them the details. It's not something mom should say for me.
[cpg]


[OnName num="gorou"]
“I heard there's a medicine that can cure ...... my condition. But..."
[cpg cn=true]


[OnName num="gorou"]
“Instead of curing the condition, he said, I would lose interest in love.”
[cpg cn=true]


In short, I was talking about the loss of the very desire to fall in love.
[cpg]


I will no longer want to fall in love with anyone, and that's a ...... life changing decision.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
The expression on Himari’s and Suzune’s faces get clouded.”
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Suzune324"]
[OnName num="suzune"]
“The doctor is saying scary things,......it makes me even more anxious."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]

Yes, that's right. But Himari was thinking about something else or she just kept silent.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

I was now alone in a room with Himari .
[cpg]


Himari had come barging into my room.
[cpg]


She says she has something to tell me, or rather I have something to tell her.
[cpg]


[OnName num="gorou"]
"...... What do you think? About curing my condition.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari055"]
[OnName num="himari"]
“I think it’s good. I think it's fine if you do it."
[cpg cn=true]


[OnName num="gorou"]
“Seriously? Because ...... if I take the pills, I won’t think anything of you.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari175"]
[OnName num="himari"]
“I'd be fine with that as long as you don’t cheat on me. But ......."
[cpg cn=true]


Then she looks a little embarrassed and says......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari056"]
[OnName num="himari"]
“I also hope that our relationship will stay the same, only with your condition being cured.”
[cpg cn=true]


...... I see. So that’s what she thought.
[cpg]


As the doctor said I should get together with her and let my condition settle down.
[cpg]


That is the best outcome. But if the condition doesn't settle down, then ......
[cpg]


I will have to lose the ability to love.
[cpg]


I was willing to go out with Himari even if I had to make that resolution.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari057"]
[OnName num="himari"]
“You know... Goro I'm sure you're ready for that too, right?"
[cpg cn=true]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト



[window target=true]


Himari comes closer. She tries to kiss me. ......
[cpg]


I was a little impatient. I knew I wanted to be in love with Himari too.
[cpg]


[window target=false]

[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





Time went by, and soon it would be time for dinner.
[cpg]



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari058"]
[OnName num="himari"]
“It’s time for dinner. Should we go?”
[cpg cn=true]


[OnName num="gorou"]
“……"
[cpg cn=true]



I feel like I should be with Himari and see if my condition settles down.
[cpg]


But if I'm too hasty, will Himari pull away and our love itself will be fruitless?
[cpg]


After thinking about what to do, I come up with an answer.
[cpg]


;//■選択肢
[switch]
[case "I'm going to approach Himari even if I have to rush things a little bit."]
	[swap]
	[jump target="*select05_1"]
[case "I will take my time."]
	[swap]
	[jump target="*select05_2"]
[endswitch]

1. I'm going to approach Himari even if I have to rush things a little bit.
2. I will take my time.



;//==============================
;//１、多少無理してもひまりに近づく
*select05_1|Caring for Himari.




[OnName num="gorou"]
“Let's stay together a little longer, Himari "
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sHimari059"]
[OnName num="himari"]
“But dinner ……"
[cpg cn=true]


[OnName num="gorou"]
“It doesn’t matter. Otherwise my condition won’t change."
[cpg cn=true]



[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari060"]
[OnName num="himari"]
“If you say so.”
[cpg cn=true]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ブラックアウト


[window target=true]

And so the days with Himari continued. But behind the scenes, discomfort was also accumulating.
[cpg]


I wonder how she felt about me rushing.
[cpg]


It would be bad if I scared her or made her feel uncomfortable even a little.
[cpg]


Even those feelings turned into impatience again.
[cpg]


;//移植前シーンカット


[window target=false]
[WAIT time=1000]

[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari061"]
[OnName num="himari"]
“Hey, Goro. Wouldn’t it be better if you got that treatment?"
[cpg cn=true]


[OnName num="gorou"]
“Why ...... But I like Himari so much?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari062"]
[OnName num="himari"]
“Yes, but maybe it's also your condition that makes you think you like me.”
[cpg cn=true]


[VOICE f="sHimari063"]
[OnName num="himari"]
“I know you have a hard time breathing if your heart isn't pounding. You must like me because you want to be excited to feel better.”
[cpg cn=true]


In response to my impatience, Himari began to question whether I was really in love with her.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『街』（昼）******************************************************





Then Himari started to get colder.
[cpg]


But my condition hasn’t changed, so I'm bitter and approach Himari .
[cpg]


[OnName num="gorou"]
“I'm in pain ...... Himari ."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari064"]
[OnName num="himari"]
“I don't know what to do. I'm not in the mood."
[cpg cn=true]



[window target=false]

[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『街』（夜）******************************************************



Ironically, Himari was showing interest in my suffering.
[cpg]


Maybe she had that personality trait to begin with.
[cpg]



I can only imagine, but ...... I had a feeling that was the case.
[cpg]


[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト


Himari was not interested in me anymore. I'm still in pain because I can't get my heart pounding anymore.
[cpg]


It was so painful that one night when I couldn't sleep ......
[cpg]


;//========================================
;//●ＣＧ（寝ている主人公に寄り添うヒロイン。サディスティックな感じ）ev_30
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================

[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="gorou"]
"H… H ..., Himari ?"
[cpg cn=true]


She came to my room. I had been waiting for her for a long time and wanted to hug her right now.
[cpg]


But I couldn't breathe and couldn't get up.
[cpg]


Whether she knew I was in such a situation or not I don’t know, but she said this.
[cpg]


[VOICE f="sHimari065"]
[OnName num="himari"]
“I might want to keep looking at you Goro ...... While you’re in pain.
[cpg cn=true]


She smiles while saying such cruel things.
[cpg]


I can't breathe, and I'm really going to die if I don’t get any skinship.
[cpg]


[OnName num="gorou"]
"Himari ...... please, come near me."
[cpg cn=true]


;**【ＣＧ】 ev_30_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari066"]
[OnName num="himari"]
“I wonder what I should do. Now Goro, you might be a little too desperate to get close."
[cpg cn=true]


She calmly and in her usual tone of voice shushes me.
[cpg]


[OnName num="gorou"]
“So you don’t care how I end up?”
[cpg cn=true]


[VOICE f="sHimari067"]
[OnName num="himari"]
"...... It must be so hard for you Goro . You've become so dependent on the pounding of the heart.”
[cpg cn=true]


I was more dependent on Himari than on the pounding of my heart. I called her name.
[cpg]


[OnName num="gorou"]
“Himari ......, ah, Himari , Himari.”
[cpg cn=true]


[VOICE f="sHimari068"]
[OnName num="himari"]
“What's wrong? What do you want from me, calling me like that?”
[cpg cn=true]


What do I want? It was decided.
[cpg]


[OnName num="gorou"]
“Please ...... make me excited. If you don't, my condition……
[cpg cn=true]


[VOICE f="sHimari069"]
[OnName num="himari"]
“The condition huh? Right."
[cpg cn=true]


;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari070"]
[OnName num="himari"]
“Hey. I actually brought the medicine to cure the condition."
[cpg cn=true]


[OnName num="gorou"]
“What?"
[cpg cn=true]


For a moment, I had no idea what Himari was talking about.
[cpg]


But little by little, my dim brain began to comprehend.
[cpg]


[VOICE f="sHimari071"]
[OnName num="himari"]
“I didn’t think that you would want to drink it on your own. But now that you're in pain, you might want to drink it.”
[cpg cn=true]


[OnName num="gorou"]
“What ...... If you come to my side, that would be enough to cure my breathing."
[cpg cn=true]


I think I'm being selfish. But I had to say it.
[cpg]


That's how painful it was. Not only my breathing, but also my heart.
[cpg]


;**【ＣＧ】 ev_30_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari072"]
[OnName num="himari"]
“The feeling is only temporary, right? It's not healthy that you have to stay with me all the time.”
[cpg cn=true]


[OnName num="gorou"]
“But!”
[cpg cn=true]


Himari had been making a somewhat disappointed face for a while.
[cpg]


The more desperate I get, the opposite of what I want happens. Even though I knew this, I couldn't help but feel impatient.
[cpg]


[VOICE f="sHimari073"]
[OnName num="himari"]
“I wonder what’s in this medicine. Does it reduce testosterone?"
[cpg cn=true]


[VOICE f="sHimari074"]
[OnName num="himari"]
“Then it would make sense that I would lose interest in love. I guess it would also explain why I would be okay with not having my heart pounding."
[cpg cn=true]


Himari says scary things. Do I really have to let go of this love?
[cpg]


Just imagining that makes it harder to let go. But it was even more difficult to breathe.
[cpg]


[OnName num="gorou"]
“Ahh...... I’m suffering, Himari , help me!"
[cpg cn=true]


Though seeing me in agony, Himari seemed to be in no hurry.
[cpg]


[OnName num="gorou"]
“What should I do……did I do something unpleasant?”
[cpg cn=true]


;**【ＣＧ】 ev_30_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sHimari075"]
[OnName num="himari"]
“I'm fine. I don't hate you. I'll still like you even if you become indifferent to love.”
[cpg cn=true]


She says scary things in a calm, gentle tone.
[cpg]


[VOICE f="sHimari076"]
[OnName num="himari"]
“Maybe then I'll play with you like a dress-up doll?”
[cpg cn=true]


[OnName num="gorou"]
“That, uh, ......, ah."
[cpg cn=true]


This love that had become strange. Himari was somewhat enjoying herself.
[cpg]


And I, on the other hand, had no time to enjoy it.
[cpg]


I didn't think ...... that it would end up like this.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



How did I ...... end up in such a situation?
[cpg]


Even if I regret it, my breathing was still painful.
[cpg]


To escape the pain, I took the pills.
[cpg]


[OnName num="gorou"]
“Ahhh ......, Himari ."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari077"]
[OnName num="himari"]
“That's all right. You were too desperate Goro. I was scared."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari078"]
[OnName num="himari"]
“Now Goro you are mine alone ......."
[cpg cn=true]


Then Himari pats my head. I was no longer excited by that.
[cpg]


[transition target={true} rule="amamori2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="amamori2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
;//ブラックアウト



My pounding was in a sense controlled by Himari .
[cpg]


My heart has been locked away ......
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*back_title"]
;//ＥＮＤ：バッドエンドルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================
;//２、ゆっくり慣らしていこう
*select05_2|Caring about Himari.




[OnName num="gorou"]
“I guess…….”
[cpg cn=true]




Himari is also a difficult person. I don't want to seem too impatient.
[cpg]


I was more interested in taking care of ...... Himari .
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



After that, Himari came to my room right after dinner.
[cpg]


She says she doesn't want to see me suffer.
[cpg]


By not asking too much of her, she began to come closer to me again ......
[cpg]



[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari079"]
[OnName num="himari"]
"...... I wish I could do something about it. The doctor said that falling in love would cure you, right?"
[cpg cn=true]


[OnName num="gorou"]
“Well, that's pretty much what it looked like."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari080"]
[OnName num="himari"]
“That’s so vague, isn't it? How does love work?”
[cpg cn=true]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_h1"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



For example. I guess it’s not about simply getting married or something like that.
[cpg]

Even if it were, I don't want to rush it. I didn't want to make it too difficult for her.
[cpg]


[window target=false]


[STOPBGM]

[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



But it seems that Himari made up her mind before I did.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari229"]
[OnName num="himari"]
"...... you know what? If we continue like this, it will never end, will it?”
[cpg cn=true]


[OnName num="gorou"]
“We don’t have to hurry. Let's take it slow ...... Himari.”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari081"]
[OnName num="himari"]
“I'll do something even more amazing. Goro, I'll do it even if you don't want me to.”
[cpg cn=true]


[OnName num="gorou"]
"...... Please be easy on me."
[cpg cn=true]



I didn't mind. But I don't think it would have happened if I had asked for it.
[cpg]


I really thought that love is a mysterious thing.
[cpg]


;//ブラックアウト

;//移植前シーンカット


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



Me and Himari spent the day flirting.
[cpg]


We even went to the dining room for dinner. ......
[cpg]




;//ブラックアウト


[window target=false]



[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari247"]
[OnName num="himari"]
“Thanks for the food. Well, Goro, let's go back to our room."
[cpg cn=true]


[OnName num="gorou"]
“It's too obvious. ……"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari248"]
[OnName num="himari"]
“Time is a finite thing. We can't waste it.”
[cpg cn=true]

[free time=1000]
[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa106"]
[OnName num="sawa"]
“You guys are really close it’s sweet.”
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



Then we go back to our room and have an intimate time.

[cpg]


While we were doing that, we even talked about sleeping on the futon together. ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari249"]
[OnName num="himari"]
“I think it’s not a problem. Everyone probably already knows."
[cpg cn=true]


[OnName num="gorou"]
“I guess. ...... then it’s okay?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari250"]
[OnName num="himari"]
“Finally Goro, I get to go to bed with you.
[cpg cn=true]


This is the kind of thing that makes me think that she is my sister after all.
[cpg]


I really want to be a lover. I guess we will inevitably end up in the middle.
[cpg]


She is my sister, but she is also my lover.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[BG f="b_06_4_up.ui" time=1000]
[WAIT time=2000]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=1000]

And then we both cuddled up and went to sleep......
[cpg]


I am excited, yet relieved. The word comes to mind again, as I have thought it many times.
[cpg]


I think it was a happy time. It felt like a confirmation of the love between me and Himari .
[cpg]


If I had been in a hurry at that time, the feeling towards Himari might have cooled down.
[cpg]


Of course, there would have been a different future than now.
[cpg]


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari251"]
[OnName num="himari"]
"Mmmm ...... sleepy ......"
[cpg cn=true]


Himari wakes up first and shakes me.
[cpg]


Is it a weekday already? I have to go to school…
[cpg]


It is quite early. What should we do?
[cpg]


[OnName num="gorou"]
“Isn't it early ……? If you're sleepy, why don't you just go back to bed?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari082"]
[OnName num="himari"]
“No. You have to cure your condition.”
[cpg cn=true]


[OnName num="gorou"]
"......, you are right."
[cpg cn=true]


If I don't spend a little time with you, my condition won't settle down.
[cpg]


Even if that were the case, I don't think it would have to be this early in the morning. ......
[cpg]





[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_06_1_up.ui" time=1000]
[WAIT time=2000]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sHimari083"]
[OnName num="himari"]
“Hey, let's kiss. Although I haven't brushed my teeth."
[cpg cn=true]


[OnName num="gorou"]
“It's not very hygenic……"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sHimari084"]
[OnName num="himari"]
“If you think about your body, you'd suffer more if you didn't kiss.”
[cpg cn=true]


...... She's right.
[cpg]



;//移植前シーンカット


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



Happy times pass quickly and now I have to go to school.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari085"]
[OnName num="himari"]
“...... I wish my mornings were longer."
[cpg cn=true]


[OnName num="gorou"]
“I guess we’ll just have to get up earlier."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari086"]
[OnName num="himari"]
“That would make the nights shorter, wouldn't it?"
[cpg cn=true]



;//ブラックアウト



It was getting harder and harder for me to spend time without Himari.
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『学園教室』（昼）******************************************************





And by the time noon came around, I was feeling woozy.
[cpg]


I think about going to Suzune’s place, but I managed to endure it.
[cpg]


Generally speaking, if I keep repeating days like this, my condition will settle down sooner or later.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************





Time passed. Specifically ......
[cpg]


Enough time passed that even if my heart wasn't pounding, I didn't have troubles breathing.
[cpg]


The relationship with Himari is already completely exposed in the household.
[cpg]


It took a lot of explaining with dad, but he finally accepted it.
[cpg]



;//ブラックアウト


[window target=false]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari087"]
[OnName num="himari"]
"Goro is going to be your husband, isn't he?"
[cpg cn=true]


[OnName num="gorou"]
“If you put it that way, then you’re a wife Himari.”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari088"]
[OnName num="himari"]
“Heh heh heh. I like that.”
[cpg cn=true]



Until recently, she was just my sister. But now my dizzying days were going to begin......
[cpg]



;//ブラックアウト


[window target=false]

[STOPBGM]
[free time=1000]
[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I've already found a job and will start working in the spring.
[cpg]


Himari wanted to get married soon, so I didn't have time to study for school.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari272"]
[OnName num="himari"]
“I'm coming in, Goro”
[cpg cn=true]


[OnName num="gorou"]
"Oh, Himari ...... what's up?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari089"]
[OnName num="himari"]
"Your condition has settled down recently. That's why ...... I missed you."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari090"]
[OnName num="himari"]
“I don't know but......, I want to be with you.”
[cpg cn=true]


[OnName num="gorou"]
“Yea. I do too. It has nothing to do with my condition.”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari091"]
[OnName num="himari"]
“I like that about you Goro ….… You take me seriously."
[cpg cn=true]


[OnName num="gorou"]
“You think so? I thought I’m quite frivolous."
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari092"]
[OnName num="himari"]
“But not as frivolous as I am, right brother?”
[cpg cn=true]




...... Himari calls me brother.
[cpg]


I want her to stop doing that, but ...... it's hard to get Himari to change.
[cpg]



[OnName num="gorou"]
“You know what? If we're going to get married, you might as well change the way you call me."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari293"]
[OnName num="himari"]
“But you call Suzune sister.”
[cpg cn=true]


That is totally irrelevant. Because we don’t have an intimate relationship.
[cpg]



[OnName num="gorou"]
“It doesn’t matter……. That doesn't work."
[cpg cn=true]



[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Himari294"]
[OnName num="himari"]
“I guess. I won't be able to say it soon, so just for now I'm going to say brother.”
[cpg cn=true]



Okay, so that's what she meant. Why couldn’t she just say so.
[cpg]

;//ブラックアウト
;//移植前シーンカット
;//移植前シーンカット

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



And so the days of Himari and me spending time continue.
[cpg]


It was dizzying. And then, when the time came to get married, ......
[cpg]


;//========================================
;//●ＣＧ（椅子に座って、編み物をするヒロイン。おなかは膨らんでいない形にしてください）ev_35
;//人物１：ヒロイン２
;//服装１：私服
;//場所　：主人公の家＿リビング
;//時間　：朝
;//備考　：元のＣＧと違って、おなかは膨らんでいない形にしてください
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


Himari is knitting in the living room.
[cpg]


I don't think she was good with her hands, and I didn't know that she had such a hobby.
[cpg]


[OnName num="gorou"]
“I don't remember you ever knitting……”
[cpg cn=true]



Himari shakes her head. I knew it. I've never seen her knit before.
[cpg]


[OnName num="gorou"]
[OnName num="gorou"]
“I can't do it, but I want to.”
[cpg cn=true]


[VOICE f="Himari315"]
[OnName num="himari"]
“I want to be able to do it, because there will be days when I’ll be bored."
[cpg cn=true]


She says. Maybe she is talking about when she has a baby.
[cpg]


I didn't need to ask anymore. And on this day, I got to hear the words I had been waiting to hear.
[cpg]


;//;**【ＣＧ】 ev_35_a ***********************
;//[CG id=15 index=1 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="sHimari093"]
[OnName num="himari"]
"Stay by my side from now on, Goro."
[cpg cn=true]


She called me Goro. I felt my heart skip a beat.
[cpg]


At this moment, I had outgrown being called brother.
[cpg]


It was not fair. Himari can seduce me like that when I can’t.
[cpg]


[OnName num="gorou"]
"...... yeah I will Himari ."
[cpg cn=true]


I can only call her Himari. But one day I will call her ‘mother’.
[cpg]


The time she will call me Goro will be quite short.
[cpg]


But that's okay. That's how happy I am……
[cpg]


The day I will become a father is approaching before our eyes.
[cpg]


I felt the happiness.
[cpg]



;//ブラックアウト

Not as her brother, but as her lover.
[cpg]


It's not every day that you get to be both a brother and a lover.
[cpg]


I had a feeling that I would continue to be excited, and one day I hope to make Himari feel the same way.
[cpg]


It may be difficult for me to do something about it, because of her strong character, but I'd like to ......
[cpg]


I want to be excited and I want to make her excited as well. I had the desires of a normal lover.
[cpg]





;//ブラックアウト

[SCENE id=10]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン２ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================

*start

;###################################################################
*Ep007|Taboo thought towards Sawa
;###################################################################


;//３、砂羽
*select04_3|

[SCENE id=7]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


Mom’s face comes to my mind. Even though I can't believe it, it can't be helped.
[cpg]


If it were Suzune or Himari it would have been okay. They are my stepsisters and we are close in age.
[cpg]


But with mom, there is a significant age difference. That’s not the only thing ......
[cpg]


She's married. She has dad.
[cpg]


And dad is still a dad for me and ...... The more I think about it the more impossible it seems.
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[window target=true]

It's Himari that helps me get my heart pound in the morning. She comes to my room and ......
[cpg]


But after that I was hesitant to leave the house.
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari317"]
[OnName num="himari"]
“Goro, aren't you going already? You’re going to be late."
[cpg cn=true]


[OnName num="gorou"]
“Yeah, I'll catch up with you later ...... go ahead first.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari318"]
[OnName num="himari"]
“Hmmm. I guess you wanted to talk to me?"
[cpg cn=true]


She saw right through me. It was inevitable. ......
[cpg]


[free time=1000]

[SE f="se003"]
;//【ＳＥ】『ドア閉まる』


Himari left and it was just mom and I.
[cpg]


Suzune and Dad went to work. Himari went to school.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa108"]
[OnName num="sawa"]
“You wanted to talk to me? Whats wrong?”
[cpg cn=true]


She asks me calmly.
[cpg]


She can probably tell that I have something serious on my mind. But mom tries not to notice.
[cpg]


[OnName num="gorou"]
“...... Mom...... I want to ...... umm..."
[cpg cn=true]


I am at a loss for words. I don't know what to say.
[cpg]


I feel like if I say it, it's the end of the world. And then…
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa109"]
[OnName num="sawa"]
“I think I know what you’re trying to say. I guess we got a bit too close.”
[cpg cn=true]


She said that she could tell. And she told me that I got too close ......
[cpg]


[OnName num="gorou"]
“Uh, well, uh, ...... that’s..."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa026"]
[OnName num="sawa"]
“I guess it can’t be helped. If you say you like me."
[cpg cn=true]


She accepted the situation quite….. easily. No, that's not good.
[cpg]


[OnName num="gorou"]
“Hey, wait a minute, wait a minute! I'm serious."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa027"]
[OnName num="sawa"]
“Anyway, I'll see you this evening. If you don't go soon, you'll be late for school.”
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





So I head to school.
[cpg]


But my head is in the clouds. Even if I see Suzune in the afternoon ......
[cpg]


Even with that in mind, I can't stay calm. When I think that mom could have done it for me.
[cpg]


This alone makes me painfully excited. I have never had a crush like this before.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************



And in the evening after school, I was feeling lightheaded.
[cpg]


Mom said that it was inevitable, but was that true?
[cpg]


I was somewhat unaware of what I was really feeling. Naturally, I would have to talk to her before dad came home.
[cpg]


Since their rooms are separated, there is a chance that we wouldn't run into each other.
[cpg]




;//ブラックアウト


[window target=false]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



While I was thinking about this, I arrived home.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Himari319"]
[OnName num="himari"]
"Welcome home. Your face……”
[cpg cn=true]


I wonder what color it is. Red or blue? It doesn't matter.
[cpg]

[free time=1000]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa028"]
[OnName num="sawa"]
"Hmmm. You look like you're having a hard time. Are you okay?”
[cpg cn=true]


With a pat on the head, she takes me to her room.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




I was excited just being by her side and holding my hand.
[cpg]


I couldn't help but feel that my heart was controlling me.
[cpg]



;//========================================
;//●ＣＧ（ヒロインが寝ている主人公に近づく。穏やかに微笑んでいる→心配そうな表情に）ev_36
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================



[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSawa029"]
[OnName num="sawa"]
“I wonder if just being near me...... Makes you feel excited.”
[cpg cn=true]


I'm excited. I nod and replied.
[cpg]


[OnName num="gorou"]
“Yes,...... it's very, very calming.”
[cpg cn=true]


Mom seemed stunned for a moment and then laughed a little.
[cpg]


[VOICE f="sSawa030"]
[OnName num="sawa"]
“Heh. Is it enough to feel calm? Shouldn't you be excited?"
[cpg cn=true]


But that was all I could say.
[cpg]


Maybe I don't want to feel excited after all, I just want to calm down.
[cpg]


Maybe the reason that I have trouble breathing to begin with might be because I can't get a crush and I'm anxious .......
[cpg]


If that's the case, my condition may be cured just by doing this.
[cpg]


Just being around Mom made me feel satisfied.
[cpg]


;**【ＣＧ】 ev_36_a ***********************
[CG id=16 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa031"]
[OnName num="sawa"]
“Anyway. I want to do what you want me to do.”
[cpg cn=true]


[OnName num="gorou"]
“Thank you. Mom "
[cpg cn=true]


[VOICE f="sSawa032"]
[OnName num="sawa"]
“…… I'm really worried about you. Goro I think of you as my child, too."
[cpg cn=true]


And suddenly, she looked worried.
[cpg]


;**【ＣＧ】 ev_36_b ***********************
[CG id=16 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa033"]
[OnName num="sawa"]
“I figure if you could feel excited with me, that's okay too.”
[cpg cn=true]


[VOICE f="sSawa034"]
[OnName num="sawa"]
“I would do anything to make you suffer less."
[cpg cn=true]


I didn't know she thought that much of me. I was kind of taken aback because she gives the impression of being a calm person.
[cpg]


[OnName num="gorou"]
“That makes me happy. Thank you so much.”
[cpg cn=true]


I knew it was a dumb thing to say, but I had to let her know how much I appreciated it.
[cpg]


I tried to keep my face and voice as serious as possible. I tried to convey my feelings, but ......
[cpg]


But mom looks extra troubled.
[cpg]


For some reason, she seems even more distressed.
[cpg]


[VOICE f="sSawa035"]
[OnName num="sawa"]
“If you like me Goro, I think that's fine too. That's not a lie."
[cpg cn=true]


Mom chooses her words carefully and gradually tells me how she feels about me.
[cpg]


;**【ＣＧ】 ev_36_c ***********************
[CG id=16 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa036"]
[OnName num="sawa"]
“I don't know what to do. You’re definitely my child, but I also like you.”
[cpg cn=true]


Well ...... I didn't know I was making her think that.
[cpg]


[OnName num="gorou"]
“ ......"
[cpg cn=true]


Was I being too insensitive? Although I’m her stepson, I’m still her son.
[cpg]


I'm pushing Mom too hard. I realized that.
[cpg]


I think I may have acted too selfishly, but I still can't stop ...... this feeling.
[cpg]


[OnName num="gorou"]
“I'm sorry. But I can't stop this feeling.”
[cpg cn=true]


What should I do? If I express that anxiety out loud, will I annoy Mom even more?
[cpg]


If so, I think it would be better to say what I want to do.
[cpg]


[OnName num="gorou"]
“I want to kiss you.”
[cpg cn=true]


I said that to cover up the tension in the atmosphere. And she nodded.
[cpg]


I watch her close her eyes and I move closer. ......
[cpg]


This step is probably a step that no sane person would take. But I was going crazy.
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

...... then.
[cpg]


I kissed her on the lips. Obviously, I had crossed a line that I shouldn’t have crossed.
[cpg]


[OnName num="gorou"]
“……"


;//ＣＧ
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSawa037"]
[OnName num="sawa"]
She giggles. “Don't make that face."
[cpg cn=true]


What did I look like? Did I look like I regretted it?
[cpg]


[VOICE f="sSawa038"]
[OnName num="sawa"]
“Did you get a good heart pound?"
[cpg cn=true]


If you put it that way, I'd be lying if I said I wasn't excited. But.
[cpg]


[OnName num="gorou"]
“Just one more time. ……"
[cpg cn=true]


[VOICE f="sSawa039"]
[OnName num="sawa"]
“No. That’s it for today. It won’t be good for you to get used to this.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah, I know, but…"
[cpg cn=true]


[VOICE f="Sawa132"]
[OnName num="sawa"]
“Look. If you persist too long, the girls won't like you.”
[cpg cn=true]


Did “girls" include mom ?
[cpg]


It was rude to ask that, so I silently withdrew.
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I didn't want to be disliked by her. So I decided not to push my luck.
[cpg]


I was conflicted, not knowing if we were in a bad place.
[cpg]

[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[SE f="se009"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





In the morning, I couldn't look mom in the face properly.
[cpg]


Seeing this, Suzune and Himari seemed to have sensed something.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Himari320"]
[OnName num="himari"]
"You crossed some kind of line, didn't you, Goro?”
[cpg cn=true]


[OnName num="gorou"]
“...... umm.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune325"]
[OnName num="suzune"]
“…… I won't say anything. You two can work this out between yourselves."
[cpg cn=true]


That's like she’s implying that the situation is disgusting.”
[cpg]


But I can't help it. I like mom.
[cpg]


[free time=1000]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa133"]
[OnName num="sawa"]
“Don't be too hard on Goro. I'm the one who let him on to the idea.”
[cpg cn=true]


She pats my shoulder. If dad were here we’d be in a lot of trouble.
[cpg]


I’m glad that dad is a person who leaves the house early...... I thought while finishing my breakfast.
[cpg]


;//ブラックアウト

[window target=false]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************


[OnName num="gorou"]
“I'm off. ……"
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa134"]
[OnName num="sawa"]
“Yeah. Have a good day."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari321"]
[OnName num="himari"]
“I'm off.”
[cpg cn=true]


I feel ...... uneasy. I want to stay with mom.
[cpg]


But that’s probably going to be a wish unfulfilled.
[cpg]


At the end of the day we are mother and son. Also I have to go to school in the first place.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[window target=false]

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[window target=true]


I head to school with my head in the clouds.
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="male_student"]
“Hey Kosaka! Don’t you think I look different today?”
[cpg cn=true]


[OnName num="gorou"]
“I don't know..., and I don't think ……"
[cpg cn=true]


[OnName num="male_student"]
“I have a girlfriend now! Spring has come for me too, ha ha ha."
[cpg cn=true]


[OnName num="gorou"]
“Oh. That’s great."
[cpg cn=true]


[OnName num="male_student"]
“What's with the lack of response? I haven’t kissed her yet."
[cpg cn=true]


...... I kissed someone I'm not even dating. On top of that it’s my mom.
[cpg]


I can't say that. In the meantime, Suzune is waiting for me.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_03_2_up.ui" time=1000]
[WAIT time=2000]

And lunch. When we were alone, Suzune told me this.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Suzune326"]
[OnName num="suzune"]
"...... Mom is our real mother. So ......."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Suzune327"]
[OnName num="suzune"]
“Please don't destroy our home with your frivolity.”
[cpg cn=true]


She said. Those were pretty harsh words.
[cpg]


The way she said "our real mother " also has a prickly edge to it. But I guess it can't be helped.
[cpg]


I'm like an outsider.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





I have to fall in love with someone to cure my condition.
[cpg]


I think Suzune and Himari were also possible partners.
[cpg]


But I didn't want that. The person I love is Mom.
[cpg]


I couldn't think of anything else. I like Mom.
[cpg]


Now that I've said it, I understand why Suzune told me not to break up the family.
[cpg]


Suzune’s words are echoing in my head.
[cpg]


;//ブラックアウト


[window target=false]

[STOPBGM]

[BG f="b_04_3_up.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa135"]
[OnName num="sawa"]
“Welcome back. How are you doing, are you having a hard time already?"
[cpg cn=true]


It's hard. I was in no condition to lie.
[cpg]


[OnName num="gorou"]
"...... yeah. Mom I want to be with you. Would that be okay?”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa136"]
[OnName num="sawa"]
“Of course. I'm the one who decided to take on the evening.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



Then she took me to her room.
[cpg]


I felt ...... such a sense of relief just by being there.
[cpg]


;//========================================
;//●ＣＧ（寝ているヒロインに迫る主人公。抱きしめ合う感じ）ev_37
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================


[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h2"]
;**【ＣＧ】 ev_37_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSawa040"]
[OnName num="sawa"]
“Come on, I'll give you a hug."
[cpg cn=true]


I was about to cry when I saw her spread her arms.
[cpg]


I wanted to confide in her with all of my feelings right now.
[cpg]


But I can't say it, and I'm still on the verge of tears.
[cpg]


I don't know what to do. I don't even know if I should go through with this love.
[cpg]


There is no doubt in my mind that I love mom .
[cpg]


And more than that, I didn't want to be a burden to mom .
[cpg]


[OnName num="gorou"]
“…..I still like you.”
[cpg cn=true]


The words came out in a voice so small that even I was surprised. I know I shouldn't say that much.
[cpg]


If I say that I want to be her boyfriend, it will be the end.
[cpg]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa041"]
[OnName num="sawa"]
“I know. I know. You don't have to say everything.”
[cpg cn=true]


That was a big relief.
[cpg]


[OnName num="gorou"]
“…… yeah."
[cpg cn=true]


[VOICE f="sSawa042"]
[OnName num="sawa"]
“I know you've had a hard day. It's okay to lean on me.”
[cpg cn=true]


I think there are some words that if you say them, there is no turning back. I was glad that mom sealed them.
[cpg]


Without saying anything, I hugged Mom.
[cpg]


[OnName num="gorou"]
“I like your smell.”
[cpg cn=true]


She does not become shy when I say this. This is definitely not the case with Himari or Suzune.
[cpg]


Mom doesn't think I'm coming any closer than I have to.
[cpg]


;**【ＣＧ】 ev_37_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa043"]
[OnName num="sawa"]
"Okay, ...... Goro, you'll always be my spoiled little boy.”
[cpg cn=true]


The gentle voice makes me unable to suppress what I had been hiding and pushing down.
[cpg]


I want Mom all to myself. It's easy to say that.
[cpg]


But I don't know if ...... I can really do that.
[cpg]


Not only do I not know, but mom may not know either.
[cpg]


If that's the case, the words I've said won’t take us any further.
[cpg]


[VOICE f="sSawa044"]
[OnName num="sawa"]
“What's wrong? You look like you're about to cry."
[cpg cn=true]


Now mom is not my just my mom . I couldn't help but think that.
[cpg]


It also makes me look like I'm about to cry. I've seriously fallen in love with Mom .
[cpg]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa045"]
[OnName num="sawa"]
“Did something sad happen?”
[cpg cn=true]


It's not sad, it's just hopeless. My current situation is hopeless.
[cpg]


It's not good any more. I know that. And that's why I can't stop.
[cpg]


[OnName num="gorou"]
“I've already made up my mind. Mom ……"
[cpg cn=true]


Mom looks a little worried.
[cpg]


Maybe she somehow knew what she is going to be told.
[cpg]


;**【ＣＧ】 ev_37_b ***********************
[CG id=17 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa046"]
[OnName num="sawa"]
“What do you mean, you've made up your mind?”
[cpg cn=true]


[OnName num="gorou"]
“You remember what they said about me? That my condition won't settle down unless I fall in love."
[cpg cn=true]


Mom apparently knows everything. Still, she listened to me talk.
[cpg]


[VOICE f="sSawa047"]
[OnName num="sawa"]
“Yeah. What about it?”
[cpg cn=true]


Once I say this, there is no going back. I have thought about it many times.
[cpg]


[OnName num="gorou"]
“I like you...... mom."
[cpg cn=true]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa048"]
[OnName num="sawa"]
“Yeah. I know.”
[cpg cn=true]


[OnName num="gorou"]
“No. Mom you don't.”
[cpg cn=true]


[OnName num="gorou"]
“When I say I like you, I mean I’m in love with you.”
[cpg cn=true]


;//移植前シーンカット

;//ブラックアウト



I finally say it. The word "like" has a different meaning from now on.
[cpg]


There was a short silence. Then, mom asks.
[cpg]


;**【ＣＧ】 ev_37_b ***********************
[CG id=17 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sawa153"]
[OnName num="sawa"]
“Are you serious? You know what happens when you say that right?”
[cpg cn=true]


I know. At least I think I do. ......
[cpg]


[VOICE f="Sawa154"]
[OnName num="sawa"]
“We might be separated. Are you prepared for that?"
[cpg cn=true]


I know. It's something that could destroy a family.
[cpg]


I wonder what Suzune and Himari would think of it. Still the biggest problem is Dad .
[cpg]


I have to choose.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



Dad is usually back by dinner.
[cpg]


[OnName num="father"]
“Suzune. How's work these days?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune328"]
[OnName num="suzune"]
“Well, ...... there are still a lot of areas where I'm not capable enough.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari322"]
[OnName num="himari"]
“You're not an incapable person. Although you sometimes can be forgetful about things.”
[cpg cn=true]


They are talking about such things. It’s an ordinary family conversation.
[cpg]


But I ...... was feeling kind of alienated.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



Later, I invite Himari and Suzune into my room.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari323"]
[OnName num="himari"]
“...... what's wrong? You look so strange.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah, well.……"
[cpg cn=true]


As I was trying to figure out how to start the conversation, Himari says to me,
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Himari324"]
[OnName num="himari"]
“Is it about mother? Am I right?”
[cpg cn=true]


[OnName num="gorou"]
“How did you know? Anyway, I’m not happy with the way things are right now.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune329"]
[OnName num="suzune"]
“What do you mean? Why are you unhappy?”
[cpg cn=true]


[OnName num="gorou"]
“I want to cure this condition. And in order to do that I want to fall in love with mom."
[cpg cn=true]


Suzune naturally flinched. She did try to flirt with me once.
[cpg]


But Himari was easygoing.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari325"]
[OnName num="himari"]
“I kind of knew this was going to happen. So it’s true.”
[cpg cn=true]


Suzune is still perplexed. But I continue to speak.
[cpg]


[OnName num="gorou"]
“I'm sorry Suzune ...... I’m glad to have you Himari and Suzune, but it doesn't solve anything."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune330"]
[OnName num="suzune"]
“...... Oh … I see …"
[cpg cn=true]


Did they accept it? I don't even feel like they fully understand it yet. ……
[cpg]


But this is something that takes time to understand.
[cpg]


After all, Suzune and Himari are mom’s real daughters.
[cpg]


It's a very complicated relationship, but I've fallen in love with mom. I can't help it.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト








By the end of the night, Suzune was convinced.
[cpg]


In the end, she seemed to support me.
[cpg]

[BG f="b_06_4.ui" time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]

[WAIT time=2000]

[VOICE f="Suzune331"]
[OnName num="suzune"]
"...... Don't be too reckless. I really care about my family."
[cpg cn=true]


After hearing what she thought, we each went back to our own rooms and went to sleep.
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[OnName num="gorou"]
"...... Oh, what? Mom? "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa049"]
[OnName num="sawa"]
“Himari told me. Why don't I make your heart pound in the morning, too?"
[cpg cn=true]


[OnName num="gorou"]
“I'm ...... happy, but, um..."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSawa050"]
[OnName num="sawa"]
“You'll miss school.”
[cpg cn=true]


As I was reconsidering, mom was getting closer.
[cpg]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト
;//移植前シーンカット

[window target=true]


She just stroked my head and hugged me. No kissing.
[cpg]


Still, it was more than enough to make me excited. Because she is my favorite person.
[cpg]



[window target=false]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************


Then I had to leave the house right away, so I skipped breakfast.
[cpg]


[OnName num="gorou"]
“I'm heading out now"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa174"]
[OnName num="sawa"]
“Have a good day. I’ll see you…… in the evening too."
[cpg cn=true]


I was excited. With that in mind, I left the house.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_01_1.ui" time=1000]
[WAIT time=1000]


I walk along the road to the school. Nothing special, just a normal day.
[cpg]


But there was something I had to think about.
[cpg]


I might destroy my family. I wondered if I was prepared to do so.
[cpg]


Maybe there is a way to prevent that from happening. But there are going to be consequences.
[cpg]


I have to think about it. I also can't stay in the same body condition.
[cpg]




[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune332"]
[OnName num="suzune"]
"...... Can't it be me?"
[cpg cn=true]

;//＠昼に空き教室で抜いてもらってから、姉さんにそう言われた。


[OnName num="gorou"]
"No, it has to be ...... mom ."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Suzune333"]
[OnName num="suzune"]
“What if I told you that I like you, too?”
[cpg cn=true]


[OnName num="gorou"]
“……"
[cpg cn=true]


She had a serious expression on her face. Is she serious? Or is it ......
[cpg]


Is she forcing herself to say so in order to protect his family? I couldn't come to a conclusion.
[cpg]


[OnName num="gorou"]
“I couldn't help it. I love mom ......."
[cpg cn=true]

I chose to use strong words. Suzune looks frustrated.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune334"]
[OnName num="suzune"]
“I see that ...... there's nothing I can do to stop you.”
[cpg cn=true]


She said she would support me, but I guess she still has something unresolved within her.
[cpg]


I don't know how she feels.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************


I'm don’t really know how I feel either. I often wonder if I'm doing the right thing.
[cpg]


I also didn't consider the fact that there is an age gap between us.
[cpg]


The more important fact is that she is my foster parent.
[cpg]


And Dad is still my dad…..
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_04_3.ui" time=1000]
[WAIT time=1000]


I could be making a terrible mistake. That’s what I think.
[cpg]


But mom wraps me up gently.
[cpg]


;//移植前シーンカット

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa051"]
[OnName num="sawa"]
“Welcome back, Goro . You're still in pain, aren't you?"
[cpg cn=true]



[OnName num="gorou"]
“Yeah……."
[cpg cn=true]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


I'm still hiding it from dad. I know I can't hide it forever.
[cpg]


Suzune and Himari are staying quiet about it. ...... but I guess I can't keep it up forever.
[cpg]


[window target=false]


[STOPBGM]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


After dinner, I go back to my room.
[cpg]


I ask mom to come to my room to talk……
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa052"]
[OnName num="sawa"]
“What’s wrong. Are you in pain because you want your heart to pound again?"
[cpg cn=true]


Mom seems to be brushing off the serious atmosphere.
[cpg]


But I had a serious look on my face. I hope she can see that.
[cpg]


[OnName num="gorou"]
“I still love you mom. The word ‘love’ is not enough to express my feelings for you.”
[cpg cn=true]


I want to be as direct as possible. Without being pretentious.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sawa193"]
[OnName num="sawa"]
“Don't ....... What if father finds out?"
[cpg cn=true]


[OnName num="gorou"]
“I'll make sure he doesn’t find out. I promise."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sawa194"]
[OnName num="sawa"]
“I know. ...... Goro I know you're serious about this.”
[cpg cn=true]


Mom reacted as if she understood something.
[cpg]


She then goes on to say.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa195"]
[OnName num="sawa"]
“You really mean it, don't you? We can't get married by any means."
[cpg cn=true]



[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSawa053"]
[OnName num="sawa"]
“I think it’s me, but you’re the one that will be bound by your feelings. Is that okay with you?"
[cpg cn=true]


I nod. I'm already done with that area of conflict.
[cpg]


Then Mom looks a little conflicted and says.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSawa054"]
[OnName num="sawa"]
“Okay.”
[cpg cn=true]


;//ブラックアウト

I'm sure mom likes me, too. Although I don't know if it's in a romantic way.
[cpg]


But I was fine with that. That's not what I should be worried about.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSawa055"]
[OnName num="sawa"]
“All that’s left to say is that I'm not going to end up with you…… Goro.”
[cpg cn=true]


Yes. If only I could accept that part of the story.
[cpg]


I've already accepted that. I already know it's a forbidden love.
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





The next morning. The morning shifts are now with mom .
[cpg]


We decided to do things a little differently now.
[cpg]


I told her ...... that I wanted to kiss her.
[cpg]


[OnName num="gorou"]
“...... I’m nervous, just like I expected.’
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa199"]
[OnName num="sawa"]
“I think I might be more nervous than you Goro "
[cpg cn=true]


Then she laughs. She doesn’t seem nervous to me.
[cpg]



;//移植前シーンカット

;//ブラックアウト

[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

We are getting closer. The distance disappears.
[cpg]


Our lips touch each other. The feeling of the first kiss was like a rush of immorality.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『街』（昼）******************************************************



Time passed. I stayed with Mom as long as I could.
[cpg]



[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d2"]

;//【ＢＧ】『街』（夜）******************************************************


And ...... it was worth it, because my condition gradually calmed down.
[cpg]


;//ブラックアウト

[window target=false]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


I'm convinced. I can't get married no matter how hard I try.
[cpg]


We can't even act like normal lovers. But that's okay.
[cpg]


We can only love each other in secret, no matter how far we go.
[cpg]


And the most important person for mom is inevitably dad .
[cpg]


I thought so when I saw Mom smiling as if nothing had happened.
[cpg]


It is a love that will never come to fruition no matter what. But I think we were able to achieve something else.
[cpg]


;//ブラックアウト


[window target=false]


[STOPBGM]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Over time, my condition continued to improve.
[cpg]


I no longer had to go to the hospital.
[cpg]


But the problem started here.
[cpg]


I guess I have to continue my love affair with mom. Otherwise, my condition might relapse.
[cpg]


It'll be like this forever unless I fall in love with someone else.
[cpg]


And I don't think I will fall in love with someone else now.
[cpg]


In other words, I'm tying myself up…… just like mom said I would.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』

[WAIT time=1500]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa217"]
[OnName num="sawa"]
“Goro. May I have a word with you …..?"
[cpg cn=true]


[OnName num="gorou"]
“What's wrong? Are you lonely?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa056"]
[OnName num="sawa"]
She giggles. “You’ve gotten so cheeky.”
[cpg cn=true]


Even though my condition has calmed down and I no longer need to be excited, mom is trying to touch me.
[cpg]


It's my fault. I couldn't say no, so I complied.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植前シーンカット

I feel relieved when I'm with her.
[cpg]


In that sense, I can't reject her either.
[cpg]


;//ブラックアウト


[window target=false]


[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="gorou"]
"...... Can't we do this some other time tomorrow? If you stay until too late, people might suspect us.”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa235"]
[OnName num="sawa"]
“Yes, but ...... fine. I'll be patient."
[cpg cn=true]


Saying this, mom seems to really like me.
[cpg]


I was embarrassed, happy, and ……I felt sorry, but I couldn't look her in the eye.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



[OnName num="gorou"]
“Well, I'm heading out then."
[cpg cn=true]


I leave the house with Himari, greeting my mom .
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari327"]
[OnName num="himari"]
"...... hey, Goro. What's going to happen to our relationship?”
[cpg cn=true]


[OnName num="gorou"]
“What do you mean?”
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari094"]
[OnName num="himari"]
“You're going to be mom’s lover right? I wonder if I should call you father.”
[cpg cn=true]


I think she's joking. But she was being the usual innocent Himari .
[cpg]



[OnName num="gorou"]
“Hey, don't ever call me that ……."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『歩く』



After the conversation, we walked together down the street.
[cpg]


We headed to school. I didn’t need Suzune to do anything for me anymore.
[cpg]




[window target=false]


[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="male_student"]
“So, I finally kissed my girlfriend the other day.”
[cpg cn=true]


[OnName num="gorou"]
“…… yeah."
[cpg cn=true]


This is the guy who, a long time ago, was making a big deal about having a girlfriend.
[cpg]


I couldn’t tell him that I'm about to be called ‘father’ by my sister.
[cpg]




[window target=false]


[STOPBGM]

[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（夕方）******************************************************


And another time. I was called out by a female classmate with whom I’ve never had any contact.
[cpg]



[OnName num="female_student"]
"...... Kosaka, do you have a girlfriend?"
[cpg cn=true]


[OnName num="gorou"]
“Why? ......, uh, ......."
[cpg cn=true]


She is a girl who probably has a thing for me. Of course I'm single-minded towards mom.
[cpg]


But I can't even say I have a girlfriend. She's not my wife either.
[cpg]


[OnName num="gorou"]
“There might be someone that I like……."
[cpg cn=true]


[OnName num="female_student"]
“I see. Right."
[cpg cn=true]


Eventually, I rejected her in that way. It's not that I didn't want to go out with this girl.
[cpg]


But I only had Mom. I chose her instead of Suzune or Himari .
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『歩く』



I walked home again, had dinner, and soon it was night.
[cpg]


It sounds tasteless when I say it like that, but there is one thing that has changed a lot.
[cpg]



[window target=false]


[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


That is that mom comes at night.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSawa057"]
[OnName num="sawa"]
“……Goro"
[cpg cn=true]


I was happy just the same, even though the way I called her was the same as before.
[cpg]


I want to be closer to her. That’s what I think.
[cpg]


;//＠それから何度か交わった後、俺達は別れた。



And every morning that comes.
[cpg]


[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



I'm sure there's only mom for me, but I wonder how she feels.
[cpg]


Maybe she likes me as well, since she comes here despite being married to dad.
[cpg]


But it's a love that can't be fulfilled in any way. We can't be lovers. ......
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）

[BG f="b_01_1.ui" time=1000]
[WAIT time=1000]

I eat breakfast and go out the front door. Himari and I head in the opposite direction from the house.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari329"]
[OnName num="himari"]
"See you later, Goro."
[cpg cn=true]


[OnName num="gorou"]
“See you.”
[cpg cn=true]

[free time=1000]

;//【ＢＧ】『街』（朝）


I was spending my days in a kind of dumbfounded state.
[cpg]


I don’t have a girlfriend or a lover, but I definitely love someone.
[cpg]


This is the happiest I've ever been, but it’s an unusual happiness.
[cpg]



[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_02_1.ui" time=1000]

[WAIT time=2000]

[BG f="b_02_2.ui" time=1000]

[WAIT time=2000]


[BGM f="bg_d2"]
[BG f="b_02_3.ui" time=1000]

[WAIT time=1000]


I head to the school, take classes, and after school.
[cpg]

;//【ＢＧ】『学園教室』（夕方）


[OnName num="female_student"]
"...... Kosaka. Oh, you know, ......."
[cpg cn=true]


[OnName num="gorou"]
“…… What?"
[cpg cn=true]


It was my female classmate. This is the girl who asked me if I liked someone.
[cpg]


[OnName num="female_student"]
“I like you Kosaka. Would you want to go out with me……?"
[cpg cn=true]


I was in trouble. Maybe I can make a decent life shift here.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



In the end, I left with my answer pending.
[cpg]


I can't give her an answer right away. I can't go out with her until I break off my relationship with mom.
[cpg]


With these thoughts in mind, I walk back to my house......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="gorou"]
"….. That's what happened to me. Mom."
[cpg cn=true]


I told her the story as it was. Then Mom said
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa252"]
[OnName num="sawa"]
“I think you should date her. I won't stop you."
[cpg cn=true]


[OnName num="gorou"]
“Why ...... I like you mom.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa253"]
[OnName num="sawa"]
“I know that. But I can never be your girlfriend."
[cpg cn=true]


...... that may indeed be the case.
[cpg]


I don't know what would happen with dad if that were to happen.
[cpg]


Mom loves dad too.
[cpg]


[OnName num="gorou"]
“...... Okay. I'll think about it."
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************


Then I held off on responding to the girl who confessed her feelings to me at school.
[cpg]


We decided to start as friends, so we are less than lovers.
[cpg]


She seemed to really like me and seemed to be frustrated.
[cpg]


But I was me, and I never lost my love for mom .
[cpg]


I didn't feel like I could properly love the girl who just confessed her love to me.
[cpg]



;//ブラックアウト



;//========================================
;//●ＣＧ（主人公に膝枕するヒロイン）ev_44
;//人物１：ヒロイン３
;//服装１：私服
;//場所　：主人公の家＿リビング
;//時間　：昼
;//備考　：妊娠していない状態に変えてください
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』


[BGM f="bg_h1"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]



I was happy despite spending such ambiguous days.
[cpg]


No matter what kind of life I lead, mom will support me.
[cpg]


I felt like that was all I needed. I am satisfied
[cpg]


[VOICE f="sSawa058"]
[OnName num="sawa"]
“Do you regret it......? Goro "
[cpg cn=true]


But I guess I looked a little lost. Mom is worried.
[cpg]


[OnName num="gorou"]
“No way. No……”
[cpg cn=true]


The words came naturally. I guess it's because I really meant it.
[cpg]


It wasn't just talk. I had absolutely no regrets.
[cpg]


;**【ＣＧ】 ev_44_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa059"]
[OnName num="sawa"]
“I don't care who you fall in love with. You fell in love with me to calm your condition, and that's all that matters.”
[cpg cn=true]


She said something that makes me a little sad. I can't go back now.
[cpg]


[OnName num="gorou"]
“No that’s not the case. I've really fallen in love with you, and my condition has settled down.”
[cpg cn=true]


The fact that my condition had settled proved that I liked mom.
[cpg]


After making sure that neither Suzune nor Himari nor dad were there, I said.
[cpg]


[OnName num="gorou"]
"...... l love you. Sawa "
[cpg cn=true]


I called her by her name abruptly, but Mom was not dismayed.
[cpg]


;//;**【ＣＧ】 ev_44_b ***********************
;//[CG id=18 index=2 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="sSawa060"]
[OnName num="sawa"]
“Me too."
[cpg cn=true]


I had longed for this kind of a relationship. I want to be next to her all the time.
[cpg]



;//ブラックアウト

I wish it could last forever, but I don't know if that will ever happen.
[cpg]


Maybe my position will change with time, and if I become a working adult, I will want to start a family.
[cpg]


But ...... right now, I'm not ready for that. Because I want to remain mom’s child.
[cpg]


[SCENE id=11]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン３ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================

*start


;###################################################################
*Ep008|Happy indecision
;###################################################################

;//４、選ぶことができない

*select04_4|Happy Indecision

[SCENE id=8]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


...... No. I can't choose.
[cpg]


Even if I am told that I need to be in love, it's not that easy to decide.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="gorou"]
“I'm sorry, I ... can't choose."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[VOICE f="Suzune337"]
[OnName num="suzune"]
"Goro ..."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari331"]
[OnName num="himari"]
"Goro ..."
[cpg cn=true]


I was so lost that I couldn’t choose from anyone.
[cpg]


As a result I tell them that I can't choose between all three of them.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa273"]
[OnName num="sawa"]
"I know what you're thinking Goro. Then you don't have to choose."
[cpg cn=true]


[OnName num="gorou"]
“What?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari095"]
[OnName num="himari"]
“That means the three of us will keep taking turns to get your heart to pound."
[cpg cn=true]


No, but that's not...
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/3" time=800]
[VOICE f="Suzune338"]
[OnName num="suzune"]
“It's okay. It's something we talked about and decided."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="3/3" time=800]
[VOICE f="sSawa061"]
[OnName num="sawa"]
“If love can cure your condition, the more people, the better."
[cpg cn=true]


Well, I guess ……Will it triple the chances of being cured?
[cpg]


[OnName num="gorou"]
“……"
[cpg cn=true]


Even if that were the case, is it okay to be spoiled by a family that is so kind to me like this?
[cpg]


But I'm still afraid ...... That I will have a hard time breathing.
[cpg]


[OnName num="gorou"]
“Please ...... take care of me, please."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="Suzune339"]
[OnName num="suzune"]
“I'll do my best Goro ."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari333"]
[OnName num="himari"]
“We'll take care of it.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa275"]
[OnName num="sawa"]
“Let your mother spoil you!"
[cpg cn=true]


I was perplexed, but decided to comply, thinking that if the three of them said so, then so be it.
[cpg]





;//ブラックアウト

[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]


A few days after that happened.
[cpg]


The three of them were still coming on to me. Of course, we haven't kissed yet......
[cpg]


But then the day came where I crossed the line to cure this condition.
[cpg]


[window target=false]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





When I wake up I find my sister having crawled into bed with me.
[cpg]


[OnName num="gorou"]
“Hmmm..."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari334"]
[OnName num="himari"]
“Oh, you're awake. Goro Good morning."
[cpg cn=true]


[OnName num="gorou"]
“Good morning. Why are you so close?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari096"]
[OnName num="himari"]
“Why, to kiss you, of course.”
[cpg cn=true]


[OnName num="gorou"]
“Oh……."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari336"]
[OnName num="himari"]
“Otherwise, you'll never get better. Are you sure you want to stay this way?"
[cpg cn=true]


[OnName num="gorou"]
“I don't ……"
[cpg cn=true]


It is a perk, or perhaps a perfect environment, to have everyone getting me excited in this way.
[cpg]


But I still have to cure this condition that restricts my life.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari097"]
[OnName num="himari"]
“Let’s kiss. If it's with you Goro …I don’t mind.”
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


Then she brings her lips to mine.
[cpg]


I haven't even brushed my teeth ......, but I'm just thinking about something that doesn't matter right now.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_h1"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


Himari looks happy as she pulls her lips apart. When she makes a face like that, my heart pounds harder.
[cpg]



[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari098"]
[OnName num="himari"]
“This isn't enough for you, is it? Let me make your heart pound some more”
[cpg cn=true]


[OnName num="gorou"]
“What, you're still going to do it?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari099"]
[OnName num="himari"]
“I don't care how many times I have to do it. You have to fall in love to cure your condition.”
[cpg cn=true]


[OnName num="gorou"]
“But is it okay…?"
[cpg cn=true]




[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari100"]
[OnName num="himari"]
“It's fine. What do you care?"
[cpg cn=true]


[OnName num="gorou"]
“Because I don't want you two to feel left out.”
[cpg cn=true]


I think there was a rule that everyone was equal.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari363"]
[OnName num="himari"]
“It's okay, it's my time in charge now. The other two will probably do the same thing..."
[cpg cn=true]


She's a really energetic sister. Suzune and especially mom would not do that.
[cpg]


I think that as we spend a full amount of time together.
[cpg]



[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[window target=true]


And then it was time to switch.
[cpg]


There was not an exact time planned but ...... Suzune came to pull us apart.
[cpg]

[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune077"]
[OnName num="suzune"]
“Hey. How long are you going to stick around, Himari?"
[cpg cn=true]


Himari stayed with us after lunch, and Suzune seemed a bit angry.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari101"]
[OnName num="himari"]
"…Oh. Sis."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune341"]
[OnName num="suzune"]
“It's time. You should go now.”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari365"]
[OnName num="himari"]
"Tsk."
[cpg cn=true]

[free time=1000]

She reluctantly leaves the room. It's not like Himari to do what she’s told right away, but I guess she feels bad that she had been with me for so long.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune342"]
[OnName num="suzune"]
“Are you okay? Himari, that girl……”
[cpg cn=true]


[OnName num="gorou"]
“Umm, yeah... I’m a little tired after having my heart pound for so long..….”
[cpg cn=true]


It seemed that Suzune was a bit concerned about what I said.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune343"]
[OnName num="suzune"]
"...... what should we do? Maybe we should leave it for today..…”
[cpg cn=true]


[OnName num="gorou"]
“No, it's okay. I don’t want to leave you out.”
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune344"]
[OnName num="suzune"]
“Thank you, Goro. I'm glad. But... don't be so unprincipled.”
[cpg cn=true]


[OnName num="gorou"]
“I'll try to be better.”
[cpg cn=true]


Now I’m with Suzune . It can be difficult not to be unprincipled.
[cpg]


We had to move to a different location and head to Suzune's room.
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

;//移植前シーンカット

We haven’t kissed yet, but I felt like she knew exactly what to do to make me nervous.
[cpg]


She could see that I liked her a lot, even if we didn’t spend so much time together.
[cpg]



;//ブラックアウト

[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



More time passed, and then ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa276"]
[OnName num="sawa"]
“Goro. Now it's your mothers turn!"
[cpg cn=true]


[OnName num="gorou"]
“Um... please let me take a break..."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa277"]
[OnName num="sawa"]
“Umm. I won’t let you ♪”
[cpg cn=true]


[OnName num="gorou"]
"Fine…..."
[cpg cn=true]


I move rooms again, this time with mom.
[cpg]


I thought my room wouldn't work, but mom didn't like that.
[cpg]


Maybe there's something instinctive...... Although maybe I'm wrong.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_04_2_up.ui" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[WAIT time=2000]

;//移植前シーンカット

Mom was the most unforgiving of the three of them.
[cpg]


You could say she was also the most worried about me. I'd have a hard time breathing if I didn't get excited.
[cpg]


I go to Himari in the morning, Suzune at noon, and mom at night. With each of them I had an exciting time.
[cpg]


It was one of those days where you could say I was lucky to be born a man.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



As I continued such a treatment, my condition settled down.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="sHimari102"]
[OnName num="himari"]
“It's so strange! You can actually be cured by falling in love!"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSuzune078"]
[OnName num="suzune"]
“…… as far as I'm concerned, though, I'm curious who you're in love with."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]

[VOICE f="sSawa062"]
[OnName num="sawa"]
“I don't care who it is. He belongs to us all.”
[cpg cn=true]


Mom said something questionable. But Suzune did too.
[cpg]


I myself don't know if I’m in love with the three of them.
[cpg]


But there's really no turning back now.
[cpg]


The fact that my condition has settled down is proof that I am in love with one of the three of them.
[cpg]



;//ブラックアウト

;//移植前シーンカット

Here's hoping it’s worth it to say who I love.
[cpg]


Unfortunately, I was the guy who couldn't pick someone at the crucial moment.
[cpg]


I'm sure everyone finds that frustrating. But I liked them all equally.
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************

;//ブラックアウト

[OnName num="father"]
“You guys seem to be getting along pretty well lately."
[cpg cn=true]


And dad has indeed said something that he had noticed.
[cpg]


Maybe he noticed it much earlier. It's just that he's just now saying it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="sSuzune079"]
[OnName num="suzune"]
“What? No, no, that's not what ......"
[cpg cn=true]


Suzune is getting nervous. Even though they are family.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari103"]
[OnName num="himari"]
“Yea. We’ve always been this close.”
[cpg cn=true]


[OnName num="father"]
“Was that so?”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSawa063"]
[OnName num="sawa"]
“Yea. He's at an age where he wants to be pampered, I guess."
[cpg cn=true]


[OnName num="father"]
“...... I see.”
[cpg cn=true]


Dad seems uneasy.
[cpg]


Of course, Suzune doesn't flirt in front of dad.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari104"]
[OnName num="himari"]
"Dad, don't be jealous. Goro is mine.”
[cpg cn=true]


But Himari is not afraid to touch me even in front of Dad .
[cpg]


It seems hard for Suzune. Seeing her in pain makes me feel uneasy.
[cpg]

;//移植前シーンカット


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『街』（昼）******************************************************


In the end, the three of us, remained the same distance from each other.
[cpg]


Or maybe I just didn't notice because I was so close to all of them.
[cpg]


The weekend came while I wondered if this kind of relationship was good.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]


[VOICE f="sHimari105"]
[OnName num="himari"]
“It's been a long time since the four of us went out together.”
[cpg cn=true]


We left the house around the time that dad had to run an errand.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="sSawa064"]
[OnName num="sawa"]
"You're right. I always thought Suzune was especially shy."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune080"]
[OnName num="suzune"]
“...... there's nothing to be shy about now.”
[cpg cn=true]


She was right. If she was going to be shy, it would have been earlier in the process......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="sHimari106"]
[OnName num="himari"]
“So, where shall we go? Do you have a date plan mom?”
[cpg cn=true]


Asking mother for a date plan sounds ...... strange, but it's not wrong.
[cpg]


;//背景と違う場所です。上下に黒帯を入れるなどの演出を入れてください

[FACE method="feadin" pos="4/7"]
[BG f="b_01_2_up.ui" time=1000]
[WAIT time=1000]


We ended up going to the shopping mall. I remember going there often as a kid.
[cpg]


Of course I'm too embarrassed to go out with her now.
[cpg]


It was a very emotional experience for me.
[cpg]


It was like the three of them recognized me for my strange condition. ......
[cpg]


More importantly, I felt like they accepted my feelings.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="sSawa065"]
[OnName num="sawa"]
“It has changed a lot, hasn’t it? All I see are clothing stores."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSuzune081"]
[OnName num="suzune"]
“Well, ...... maybe that's just the way it is."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]

[VOICE f="sHimari107"]
[OnName num="himari"]
“Do people want to buy clothes all the time? I’d rather eat a nice meal.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah, I think it's time for dinner.”
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]

[VOICE f="sSuzune082"]
[OnName num="suzune"]
“I'm surprised that you're in charge.”
[cpg cn=true]


[OnName num="gorou"]
“No, no, I don't think I'm in charge.”
[cpg cn=true]


The four of us were enjoying our time being together.
[cpg]


In this way, we felt more like a family rather than lovers.
[cpg]


It is as if we have become closer as a family. ......
[cpg]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="sHimari108"]
[OnName num="himari"]
“That was fun. Plus Goro bought me clothes."
[cpg cn=true]


[OnName num="gorou"]
“You were the one complaining about all of the clothing shops though……"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari109"]
[OnName num="himari"]
“It's okay. Don't take what I say so seriously."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSuzune083"]
[OnName num="suzune"]
“You guys are still the same.”
[cpg cn=true]


Mom watches our conversation smiling.
[cpg]


Come to think of it, maybe this is what I've always wanted.
[cpg]


After losing my parents in an accident, I wanted the warmth of family.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="sSawa066"]
[OnName num="sawa"]
“Did you have a good time Goro ?”
[cpg cn=true]


[OnName num="gorou"]
“Yes. Of course, it was a lot of fun."
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]


......I like this way of spending time. I'm sure it's better than the time I would spend with a girlfriend. ......
[cpg]


I don't want to break up a family relationship to be with one person.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


The more our family ties grow, the worse I feel that dad is somewhat of an outsider.
[cpg]


[OnName num="father"]
"...... what is it? You wanted to talk to me."
[cpg cn=true]


[OnName num="gorou"]
“Umm. It's just that we went out without you again today.”
[cpg cn=true]


[OnName num="father"]
“Don't worry about it. I know you guys get along great."
[cpg cn=true]


I feel sorry for him, but ...... there was one more thing on my mind.
[cpg]


[OnName num="gorou"]
"Thank you ....... For letting me into your home."
[cpg cn=true]


[OnName num="father"]
“What’s going on? That’s so out of the blue.”
[cpg cn=true]


[OnName num="gorou"]
“No. I just felt like I hadn't said it enough.”
[cpg cn=true]


[OnName num="father"]
“Don't worry about it. I couldn't leave you alone."
[cpg cn=true]


Dad looks like he is embarrassed.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSawa067"]
[OnName num="sawa"]
“What's wrong? You two seem to be talking a lot.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah. I'm just happy to be in this house.”
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sSawa068"]
[OnName num="sawa"]
“Well. That's rare."
[cpg cn=true]


Rare. I haven't said anything like this in the past.
[cpg]


[OnName num="gorou"]
“I'm sorry for not being able to make you guys happy.”
[cpg cn=true]


[OnName num="father"]
“It’s okay. You're not old enough to be worried about that."
[cpg cn=true]


Dad repeats the phrase "Don't worry about it”. I was grateful for that.
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]


I am still guilty though. For letting Suzune, Himari and mom get me excited.
[cpg]


I know he didn't say “don't worry about that” for that specific situation, ...... but it still made me feel better.
[cpg]


[window target=false]


[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

After finishing dinner, I was relaxing in my room when Himari came in.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari110"]
[OnName num="himari"]
“Hey, are you sure you're not going to pick anyone?”
[cpg cn=true]


[OnName num="gorou"]
“Yeah. I've been thinking since then. ......"
[cpg cn=true]


[OnName num="gorou"]
“It’s not that I like you all equally, it’s more that I have a reason that I can't pick just one person."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sHimari111"]
[OnName num="himari"]
“What do you mean?”
[cpg cn=true]


[OnName num="gorou"]
“I ...... like this house.”
[cpg cn=true]


[OnName num="gorou"]
“I don't want to ruin this relationship. After what happened today, I feel that deeply.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari112"]
[OnName num="himari"]
"...... That's probably a hard thing to say for you right? From our perspective, you are one person."
[cpg cn=true]


[OnName num="gorou"]
“Sorry. ……"
[cpg cn=true]


Himari seemed a little angry, but also forgiving.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari113"]
[OnName num="himari"]
“Well, it's not the first time Goro has been indecisive, so I've given up.”
[cpg cn=true]


[OnName num="gorou"]
“I'm so sorry.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari114"]
[OnName num="himari"]
“No need to apologize. You've made up your mind. Despite being so indecisive."
[cpg cn=true]


I was kind of sorry and couldn't say anything.
[cpg]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]
;//【ＢＧ】『街』（朝）******************************************************

My condition had calmed down a lot. Even though I wasn’t really in love with anyone.
[cpg]


Nothing had changed so far concerning the relationship, but everything was about to come full circle.
[cpg]


It was at this time that I decided.
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『学園教室』（昼）******************************************************

[OnName num="gorou"]
“Suzune, what's wrong?”
[cpg cn=true]


I was in an empty classroom when Suzune called me.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune084"]
[OnName num="suzune"]
“I’m…… sorry. I didn't mean to call you out of the blue.
[cpg cn=true]


[OnName num="gorou"]
“That's fine, but what's wrong?”
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune085"]
[OnName num="suzune"]
“I mean, it's not that something just happened, it's more about ......, something that had been going on for a while.”
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune086"]
[OnName num="suzune"]
“Goro. Do you like me?"
[cpg cn=true]


[OnName num="gorou"]
“Yes. I like you."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune087"]
[OnName num="suzune"]
“I'm bad at asking questions. Do you love me?”
[cpg cn=true]


[OnName num="gorou"]
“I’ve ...... already decided that I'm not going to choose anyone."
[cpg cn=true]


That seemed to pain Suzune .
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune088"]
[OnName num="suzune"]
“I like you so much I want to be your lover."
[cpg cn=true]


...... I hadn't considered this possibility until just now.
[cpg]


It wasn't up to me to choose someone.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune089"]
[OnName num="suzune"]
The four of us together is fun, but it's also hard.
[cpg cn=true]


Suzune was apparently in love with me to this extent.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune090"]
[OnName num="suzune"]
“I am ready to be yours only.”
[cpg cn=true]


Those words seemed to suggest that she wanted me to only be with her as well.
[cpg]


[OnName num="gorou"]
“……"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune091"]
[OnName num="suzune"]
“I'm not going to hide it. I want to marry you."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune092"]
[OnName num="suzune"]
“If you say you won't choose anyone then ...... I would like to keep my distance from you. It is painful for me to be near you when I can't be with you.”
[cpg cn=true]


My heart was tightening. All I want is to be with my family.
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『学園廊下』（夕方）******************************************************

[OnName num="male_student_A"]
“So, your future huh?”
[cpg cn=true]


[OnName num="male_student_B"]
“Why are you so worried? You said you wanted to get a job right after graduation."
[cpg cn=true]


[OnName num="male_student_A"]
“I'm trying, but I don't think my parents will let me.”
[cpg cn=true]


[OnName num="male_student_A"]
“My siblings are also being very vocal about it ...... I don't know what to do.”
[cpg cn=true]


[OnName num="male_student_B"]
“You have to be yourself. You can't stay with your family forever no matter how much you care for them.”
[cpg cn=true]


From a distance....., I hear a conversation between two people.
[cpg]


Families can't stay together forever. That might indeed be true.
[cpg]


[window target=false]



[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************


With Suzune I can either have a non-family relationship or distance myself from the family. Does it have to be one or the other?
[cpg]


I, for one, want to keep our relationship the way it is.
[cpg]


[window target=false]

[STOPBGM]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


At the dinner table that day, Suzune and I had a tense moment.
[cpg]


Of course, Himari seemed to notice something and was concerned.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sSawa069"]
[OnName num="sawa"]
“What's wrong? You're not eating anymore."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSuzune093"]
[OnName num="suzune"]
“Yeah, ...... I don't have much of an appetite."
[cpg cn=true]


What should I do with Suzune. I felt like I had more to explain to her.
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="gorou"]
“......I knew this was the only way.”
[cpg cn=true]


I think. After much thought, I came to one conclusion.
[cpg]


I will not choose between Himari and Suzune. I found the only way to continue our current relationship.
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

The next morning. Before I left, I call Suzune .
[cpg]


[OnName num="gorou"]
"I'm sorry to bother you while you’re busy."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune094"]
[OnName num="suzune"]
“It’s okay. Have you thought about it?”
[cpg cn=true]


[OnName num="gorou"]
"Yeah. I've come up with my own conclusion.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sHimari115"]
[OnName num="himari"]
“What conclusion?”
[cpg cn=true]


Himari is also here. I really needed her to be.
[cpg]


Because if Suzune and I were to get married, Himari would still want to be by my side.
[cpg]


I don't even need to ask that anymore, it's too selfish and rude to even ask.
[cpg]


With mom it’s different of course. She would not do that.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sSuzune095"]
[OnName num="suzune"]
“… I don't see the point in hiding it from Himari. I told Goro that I love him so much I want to marry him.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="sHimari116"]
[OnName num="himari"]
“Wow. That's bold."
[cpg cn=true]


Himari doesn't seem upset at all. I guess she thinks that I can't muster up the courage to do so.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune096"]
[OnName num="suzune"]
“I told him that if I ...... can't get married, it's hard for me to be around him.”
[cpg cn=true]


[OnName num="gorou"]
“Yes. I want you to be with me. But I also want Himari to be with me."
[cpg cn=true]


[OnName num="gorou"]
I was wondering if such a convenient thing was possible.
[cpg cn=true]


Suzune holds her breath, waiting for me to say something.
[cpg]


[OnName num="gorou"]
“I think ...... that the three of us should get married.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="sHimari117"]
[OnName num="himari"]
“Huh?"
[cpg cn=true]


[OnName num="gorou"]
“Not right now, of course. Because I like us as a family."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="sSuzune097"]
[OnName num="suzune"]
“Do you know what you're talking about? Polygamy is not allowed in Japan.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah, well, ...... We’re not going to make it official of course.”
[cpg cn=true]


[OnName num="gorou"]
“But if we can do it overseas, and if you’re both interested, then I guess that's fine too."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune098"]
[OnName num="suzune"]
“Oh, you know, ...... it's not a matter of law, it's a matter of the heart."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune099"]
[OnName num="suzune"]
“Are you thinking about it when we move in together, or have kids?"
[cpg cn=true]


[OnName num="gorou"]
“I'm thinking about it. I'm seriously thinking about marrying you both."
[cpg cn=true]


[OnName num="gorou"]
“I’ve decided not to choose. I don't think it's a good idea to do things halfway."
[cpg cn=true]


A strange silence passes. In the midst of it all, Himari starts laughing.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari118"]
[OnName num="himari"]
“...... pfft, ha ha ha ha.”
[cpg cn=true]


[OnName num="gorou"]
“Himari?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari119"]
[OnName num="himari"]
“I didn’t know you were thinking that. You should have told me."
[cpg cn=true]


After she finished laughing, Himari said.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari120"]
[OnName num="himari"]
“You don't have to marry the both of us, or go overseas, or anything.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari121"]
[OnName num="himari"]
“Because I could still be with you even if you and Suzune get married.”
[cpg cn=true]


[OnName num="gorou"]
“What?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune100"]
[OnName num="suzune"]
“But ...... Then I'll have Goro all to myself.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSuzune101"]
[OnName num="suzune"]
“If you like Goro as much as I do, you can't allow that to happen."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="sHimari122"]
[OnName num="himari"]
“You both think too much. We don't know what the future holds."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari123"]
[OnName num="himari"]
“First of all, why do you want to get married? What’s the border line of being monogamous? I'm totally fine with being Goro’s second favorite."
[cpg cn=true]


Himari was someone who could leave things ambiguous.
[cpg]


She is trying to untangle us from our thoughts.
[cpg]


Maybe she's trying to help us out of this situation, even if it's a little overwhelming.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune102"]
[OnName num="suzune"]
“Himari, aren’t you jealous?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari124"]
[OnName num="himari"]
“I am. But if it’s my sister, then I don’t mind.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari125"]
[OnName num="himari"]
“You both think too seriously. It's not like the world is going to end when this day comes, so why don't we just leave things the way they are?"
[cpg cn=true]


Suzune and I look at each other.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari126"]
[OnName num="himari"]
“Are you okay with the time? I'm used to being late."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="sSuzune103"]
[OnName num="suzune"]
“Ah!"
[cpg cn=true]


;//ブラックアウト

[window target=false]

[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（朝）******************************************************

We were talking for too long. I hurry up and get ready and head to the academy, but Suzune would probably be late.
[cpg]


Himari said that we shouldn’t act so abruptly, which made me feel a little better.
[cpg]


Maybe what I decided to do is what Himari proposed.
[cpg]


I want to stay as close as I can for as long as possible.
[cpg]


Himari probably saw through that and tried to calm Suzune down.
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『学園教室』（昼）******************************************************


[OnName num="male_student_A"]
“I've made up my mind. I'm going to get a job after all.”
[cpg cn=true]


[OnName num="male_student_B"]
“Well, that's good. It would be foolish to go to school for the sake of the family.”
[cpg cn=true]


[OnName num="male_student_A"]
“Yea. I figured if I'm going to think about what's best for my family, I might as well do what I want to do."
[cpg cn=true]


[OnName num="male_student_A"]
“Also if I fret, it will be bad atmosphere to bring to the family."
[cpg cn=true]


[OnName num="male_student_A"]
“If I work on myself it will be good for the family.”
[cpg cn=true]


Someday I will become a couple with someone. Looks like I’ve made a bit of progress.
[cpg]


I can't be indecisive either. I can’t keep the state of not being able to choose who I'm going to be with.
[cpg]


I thought to myself that I just have to push forward once I've decided.
[cpg]


[window target=false]

[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『学園教室』（夕方）******************************************************

This is a way of thinking, but I also wonder if everything has to be decided.
[cpg]


Himari’s way of thinking could solve everything.
[cpg]


Even if it doesn't solve everything, the current situation might be the best situation at least for now.
[cpg]


It seems that I can't even realize such an obvious thing without being told by my sister.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune104"]
[OnName num="suzune"]
"So ...... the solution here is ......"
[cpg cn=true]


Suzune is acting so calmly that I almost forgot that I made her unpunctual.
[cpg]


It's the same when I'm in the same classroom. I'm sure it's thanks to the presence of Himari that I can stay calm like this.
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************



[OnName num="female_student"]
“What an unexpected ending.”
[cpg cn=true]


[OnName num="male_student"]
“Unexpected? Like in a manga?”
[cpg cn=true]


[OnName num="female_student"]
“Yea. Like when you feel surprised by the unexpected outcome of people falling in love.”
[cpg cn=true]


[OnName num="male_student"]
“Oh. I'd rather have a harem than some weird outcome.”
[cpg cn=true]


Reality is not a manga. I’m not worried about such an outcome.
[cpg]


I thought that while listening to some couple's story.
[cpg]


[OnName num="female_student"]
“What! What do you mean a harem. Are you cheating on me?"
[cpg cn=true]


[OnName num="male_student"]
“No, no. ...... how can that be?"
[cpg cn=true]


...... I wouldn’t mind with being a couple with either of the two girls.
[cpg]


But again, reality is not a manga.
[cpg]


I don't live my life to be seen, or to put on a show for someone.
[cpg]


If that's the case, the way to pursue happiness, even if it's ambiguous, is definitely the way to go.
[cpg]




;//ブラックアウト


[window target=false]



[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="sSuzune105"]
[OnName num="suzune"]
“Himari, could you stop flirting in front of dad.”
[cpg cn=true]


[VOICE f="sHimari127"]
[OnName num="himari"]
“You just want to flirt to Suzune.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune106"]
[OnName num="suzune"]
“No! That would be chaotic.”
[cpg cn=true]


[OnName num="gorou"]
“It hurts me when you reject me....."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune107"]
[OnName num="suzune"]
“Oh, no, that's not what I meant.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]

Mom is chuckling.
[cpg]


At first I thought it was strange that I would not chose anyone, but maybe having this kind of a lifestyle might not be that bad.
[cpg]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[window target=true]


Then a while later, ......
[cpg]


;//========================================
;//●ＣＧ（ベッドに三人寝転がっている。おなかは膨らんでない）ev_50
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//人物３：ヒロイン３
;//服装３：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================


[STOPBGM]
[WAIT time=1000]
[BGM f="bg_op"]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sHimari128"]
[OnName num="himari"]
“Heh heh heh. We're all together, it's kind of like a trip."
[cpg cn=true]


[VOICE f="sSawa070"]
[OnName num="sawa"]
“That’s true. We haven't taken a family vacation in a while."
[cpg cn=true]


[VOICE f="sSuzune108"]
[OnName num="suzune"]
"......, yeah, right."
[cpg cn=true]


Today, at Himari 's request, the four of us will spend time together.
[cpg]


It's not for me since my condition has settled down.
[cpg]


I guess it's my destiny, as I didn't choose anyone.
[cpg]


[VOICE f="sHimari129"]
[OnName num="himari"]
"Come on, Goro. You get to choose who you pick today. I’m sure you'll be excited a lot.”
[cpg cn=true]


[VOICE f="sSuzune109"]
[OnName num="suzune"]
“You're out of your ...... mind. This is crazy."
[cpg cn=true]


[VOICE f="sHimari130"]
[OnName num="himari"]
“Well, I'm having fun. I wish we could be together all the time."
[cpg cn=true]


I was feeling indescribable, yet excited.
[cpg]


[VOICE f="sSawa071"]
[OnName num="sawa"]
"Heh. Himari you’re so innocent.”
[cpg cn=true]


Mom smiles innocently as well.
[cpg]


I don't know what the three of them really think. But they seemed to be happy.
[cpg]




[VOICE f="Suzune385"]
[OnName num="suzune"]
“I'm going to get angry if you don't love all three of us.”
[cpg cn=true]


[VOICE f="sHimari131"]
[OnName num="himari"]
“I’m so glad you’re here Goro. You might become a dad soon.”
[cpg cn=true]


[OnName num="gorou"]
“I don't know.”
[cpg cn=true]


[VOICE f="Sawa315"]
[OnName num="sawa"]
“Don't leave anyone out.”
[cpg cn=true]




[OnName num="gorou"]
"...... I know. I know.”
[cpg cn=true]


Is there such a thing as a harem? There should be.
[cpg]



;//ブラックアウト

A family. Lovers. Relationships that cannot be defined by such words.
[cpg]


I was certainly happy while keeping things ambiguous.
[cpg]


......Suzune, Himari, and mom probably feel the same way.
[cpg]

[SCENE id=12]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]
;//ＥＮＤ：ハーレムルート






;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





