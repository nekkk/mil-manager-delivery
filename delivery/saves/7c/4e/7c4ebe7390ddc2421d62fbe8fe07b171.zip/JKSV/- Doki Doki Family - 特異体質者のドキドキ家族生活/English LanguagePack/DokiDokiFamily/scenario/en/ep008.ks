
*start


;###################################################################
*Ep008|Happy indecision
;###################################################################

;//４、選ぶことができない

*select04_4|Happy Indecision

[SCENE id=8]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


...... No. I can't choose.
[cpg]


Even if I am told that I need to be in love, it's not that easy to decide.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[OnName num="gorou"]
“I'm sorry, I ... can't choose."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]

[VOICE f="Suzune337"]
[OnName num="suzune"]
"Goro ..."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari331"]
[OnName num="himari"]
"Goro ..."
[cpg cn=true]


I was so lost that I couldn’t choose from anyone.
[cpg]


As a result I tell them that I can't choose between all three of them.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa273"]
[OnName num="sawa"]
"I know what you're thinking Goro. Then you don't have to choose."
[cpg cn=true]


[OnName num="gorou"]
“What?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari095"]
[OnName num="himari"]
“That means the three of us will keep taking turns to get your heart to pound."
[cpg cn=true]


No, but that's not...
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/3" time=800]
[VOICE f="Suzune338"]
[OnName num="suzune"]
“It's okay. It's something we talked about and decided."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="3/3" time=800]
[VOICE f="sSawa061"]
[OnName num="sawa"]
“If love can cure your condition, the more people, the better."
[cpg cn=true]


Well, I guess ……Will it triple the chances of being cured?
[cpg]


[OnName num="gorou"]
“……"
[cpg cn=true]


Even if that were the case, is it okay to be spoiled by a family that is so kind to me like this?
[cpg]


But I'm still afraid ...... That I will have a hard time breathing.
[cpg]


[OnName num="gorou"]
“Please ...... take care of me, please."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="Suzune339"]
[OnName num="suzune"]
“I'll do my best Goro ."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari333"]
[OnName num="himari"]
“We'll take care of it.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Sawa275"]
[OnName num="sawa"]
“Let your mother spoil you!"
[cpg cn=true]


I was perplexed, but decided to comply, thinking that if the three of them said so, then so be it.
[cpg]





;//ブラックアウト

[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]


A few days after that happened.
[cpg]


The three of them were still coming on to me. Of course, we haven't kissed yet......
[cpg]


But then the day came where I crossed the line to cure this condition.
[cpg]


[window target=false]

[SE f=se009]
;//【ＳＥ】『鳥の鳴き声』

[STOPBGM]
[transition target={true} rule="uzumaki2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





When I wake up I find my sister having crawled into bed with me.
[cpg]


[OnName num="gorou"]
“Hmmm..."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Himari334"]
[OnName num="himari"]
“Oh, you're awake. Goro Good morning."
[cpg cn=true]


[OnName num="gorou"]
“Good morning. Why are you so close?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari096"]
[OnName num="himari"]
“Why, to kiss you, of course.”
[cpg cn=true]


[OnName num="gorou"]
“Oh……."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari336"]
[OnName num="himari"]
“Otherwise, you'll never get better. Are you sure you want to stay this way?"
[cpg cn=true]


[OnName num="gorou"]
“I don't ……"
[cpg cn=true]


It is a perk, or perhaps a perfect environment, to have everyone getting me excited in this way.
[cpg]


But I still have to cure this condition that restricts my life.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sHimari097"]
[OnName num="himari"]
“Let’s kiss. If it's with you Goro …I don’t mind.”
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


Then she brings her lips to mine.
[cpg]


I haven't even brushed my teeth ......, but I'm just thinking about something that doesn't matter right now.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_h1"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************


Himari looks happy as she pulls her lips apart. When she makes a face like that, my heart pounds harder.
[cpg]



[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari098"]
[OnName num="himari"]
“This isn't enough for you, is it? Let me make your heart pound some more”
[cpg cn=true]


[OnName num="gorou"]
“What, you're still going to do it?"
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sHimari099"]
[OnName num="himari"]
“I don't care how many times I have to do it. You have to fall in love to cure your condition.”
[cpg cn=true]


[OnName num="gorou"]
“But is it okay…?"
[cpg cn=true]




[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari100"]
[OnName num="himari"]
“It's fine. What do you care?"
[cpg cn=true]


[OnName num="gorou"]
“Because I don't want you two to feel left out.”
[cpg cn=true]


I think there was a rule that everyone was equal.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari363"]
[OnName num="himari"]
“It's okay, it's my time in charge now. The other two will probably do the same thing..."
[cpg cn=true]


She's a really energetic sister. Suzune and especially mom would not do that.
[cpg]


I think that as we spend a full amount of time together.
[cpg]



[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[window target=true]


And then it was time to switch.
[cpg]


There was not an exact time planned but ...... Suzune came to pull us apart.
[cpg]

[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune077"]
[OnName num="suzune"]
“Hey. How long are you going to stick around, Himari?"
[cpg cn=true]


Himari stayed with us after lunch, and Suzune seemed a bit angry.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari101"]
[OnName num="himari"]
"…Oh. Sis."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune341"]
[OnName num="suzune"]
“It's time. You should go now.”
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari365"]
[OnName num="himari"]
"Tsk."
[cpg cn=true]

[free time=1000]

She reluctantly leaves the room. It's not like Himari to do what she’s told right away, but I guess she feels bad that she had been with me for so long.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune342"]
[OnName num="suzune"]
“Are you okay? Himari, that girl……”
[cpg cn=true]


[OnName num="gorou"]
“Umm, yeah... I’m a little tired after having my heart pound for so long..….”
[cpg cn=true]


It seemed that Suzune was a bit concerned about what I said.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune343"]
[OnName num="suzune"]
"...... what should we do? Maybe we should leave it for today..…”
[cpg cn=true]


[OnName num="gorou"]
“No, it's okay. I don’t want to leave you out.”
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Suzune344"]
[OnName num="suzune"]
“Thank you, Goro. I'm glad. But... don't be so unprincipled.”
[cpg cn=true]


[OnName num="gorou"]
“I'll try to be better.”
[cpg cn=true]


Now I’m with Suzune . It can be difficult not to be unprincipled.
[cpg]


We had to move to a different location and head to Suzune's room.
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]

;//移植前シーンカット

We haven’t kissed yet, but I felt like she knew exactly what to do to make me nervous.
[cpg]


She could see that I liked her a lot, even if we didn’t spend so much time together.
[cpg]



;//ブラックアウト

[window target=false]


[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************



More time passed, and then ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa276"]
[OnName num="sawa"]
“Goro. Now it's your mothers turn!"
[cpg cn=true]


[OnName num="gorou"]
“Um... please let me take a break..."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa277"]
[OnName num="sawa"]
“Umm. I won’t let you ♪”
[cpg cn=true]


[OnName num="gorou"]
"Fine…..."
[cpg cn=true]


I move rooms again, this time with mom.
[cpg]


I thought my room wouldn't work, but mom didn't like that.
[cpg]


Maybe there's something instinctive...... Although maybe I'm wrong.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_04_2_up.ui" time=1000]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=1000]
[WAIT time=2000]

;//移植前シーンカット

Mom was the most unforgiving of the three of them.
[cpg]


You could say she was also the most worried about me. I'd have a hard time breathing if I didn't get excited.
[cpg]


I go to Himari in the morning, Suzune at noon, and mom at night. With each of them I had an exciting time.
[cpg]


It was one of those days where you could say I was lucky to be born a man.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



As I continued such a treatment, my condition settled down.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="sHimari102"]
[OnName num="himari"]
“It's so strange! You can actually be cured by falling in love!"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSuzune078"]
[OnName num="suzune"]
“…… as far as I'm concerned, though, I'm curious who you're in love with."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]

[VOICE f="sSawa062"]
[OnName num="sawa"]
“I don't care who it is. He belongs to us all.”
[cpg cn=true]


Mom said something questionable. But Suzune did too.
[cpg]


I myself don't know if I’m in love with the three of them.
[cpg]


But there's really no turning back now.
[cpg]


The fact that my condition has settled down is proof that I am in love with one of the three of them.
[cpg]



;//ブラックアウト

;//移植前シーンカット

Here's hoping it’s worth it to say who I love.
[cpg]


Unfortunately, I was the guy who couldn't pick someone at the crucial moment.
[cpg]


I'm sure everyone finds that frustrating. But I liked them all equally.
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]


;//【ＢＧ】『主人公の家＿ダイニングキッチン』（昼）******************************************************

;//ブラックアウト

[OnName num="father"]
“You guys seem to be getting along pretty well lately."
[cpg cn=true]


And dad has indeed said something that he had noticed.
[cpg]


Maybe he noticed it much earlier. It's just that he's just now saying it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="sSuzune079"]
[OnName num="suzune"]
“What? No, no, that's not what ......"
[cpg cn=true]


Suzune is getting nervous. Even though they are family.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari103"]
[OnName num="himari"]
“Yea. We’ve always been this close.”
[cpg cn=true]


[OnName num="father"]
“Was that so?”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSawa063"]
[OnName num="sawa"]
“Yea. He's at an age where he wants to be pampered, I guess."
[cpg cn=true]


[OnName num="father"]
“...... I see.”
[cpg cn=true]


Dad seems uneasy.
[cpg]


Of course, Suzune doesn't flirt in front of dad.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari104"]
[OnName num="himari"]
"Dad, don't be jealous. Goro is mine.”
[cpg cn=true]


But Himari is not afraid to touch me even in front of Dad .
[cpg]


It seems hard for Suzune. Seeing her in pain makes me feel uneasy.
[cpg]

;//移植前シーンカット


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『街』（昼）******************************************************


In the end, the three of us, remained the same distance from each other.
[cpg]


Or maybe I just didn't notice because I was so close to all of them.
[cpg]


The weekend came while I wondered if this kind of relationship was good.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]


[VOICE f="sHimari105"]
[OnName num="himari"]
“It's been a long time since the four of us went out together.”
[cpg cn=true]


We left the house around the time that dad had to run an errand.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="sSawa064"]
[OnName num="sawa"]
"You're right. I always thought Suzune was especially shy."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune080"]
[OnName num="suzune"]
“...... there's nothing to be shy about now.”
[cpg cn=true]


She was right. If she was going to be shy, it would have been earlier in the process......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="sHimari106"]
[OnName num="himari"]
“So, where shall we go? Do you have a date plan mom?”
[cpg cn=true]


Asking mother for a date plan sounds ...... strange, but it's not wrong.
[cpg]


;//背景と違う場所です。上下に黒帯を入れるなどの演出を入れてください

[FACE method="feadin" pos="4/7"]
[BG f="b_01_2_up.ui" time=1000]
[WAIT time=1000]


We ended up going to the shopping mall. I remember going there often as a kid.
[cpg]


Of course I'm too embarrassed to go out with her now.
[cpg]


It was a very emotional experience for me.
[cpg]


It was like the three of them recognized me for my strange condition. ......
[cpg]


More importantly, I felt like they accepted my feelings.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[VOICE f="sSawa065"]
[OnName num="sawa"]
“It has changed a lot, hasn’t it? All I see are clothing stores."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSuzune081"]
[OnName num="suzune"]
“Well, ...... maybe that's just the way it is."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]

[VOICE f="sHimari107"]
[OnName num="himari"]
“Do people want to buy clothes all the time? I’d rather eat a nice meal.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah, I think it's time for dinner.”
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]

[VOICE f="sSuzune082"]
[OnName num="suzune"]
“I'm surprised that you're in charge.”
[cpg cn=true]


[OnName num="gorou"]
“No, no, I don't think I'm in charge.”
[cpg cn=true]


The four of us were enjoying our time being together.
[cpg]


In this way, we felt more like a family rather than lovers.
[cpg]


It is as if we have become closer as a family. ......
[cpg]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="sHimari108"]
[OnName num="himari"]
“That was fun. Plus Goro bought me clothes."
[cpg cn=true]


[OnName num="gorou"]
“You were the one complaining about all of the clothing shops though……"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari109"]
[OnName num="himari"]
“It's okay. Don't take what I say so seriously."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="sSuzune083"]
[OnName num="suzune"]
“You guys are still the same.”
[cpg cn=true]


Mom watches our conversation smiling.
[cpg]


Come to think of it, maybe this is what I've always wanted.
[cpg]


After losing my parents in an accident, I wanted the warmth of family.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="sSawa066"]
[OnName num="sawa"]
“Did you have a good time Goro ?”
[cpg cn=true]


[OnName num="gorou"]
“Yes. Of course, it was a lot of fun."
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]


......I like this way of spending time. I'm sure it's better than the time I would spend with a girlfriend. ......
[cpg]


I don't want to break up a family relationship to be with one person.
[cpg]



;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


The more our family ties grow, the worse I feel that dad is somewhat of an outsider.
[cpg]


[OnName num="father"]
"...... what is it? You wanted to talk to me."
[cpg cn=true]


[OnName num="gorou"]
“Umm. It's just that we went out without you again today.”
[cpg cn=true]


[OnName num="father"]
“Don't worry about it. I know you guys get along great."
[cpg cn=true]


I feel sorry for him, but ...... there was one more thing on my mind.
[cpg]


[OnName num="gorou"]
"Thank you ....... For letting me into your home."
[cpg cn=true]


[OnName num="father"]
“What’s going on? That’s so out of the blue.”
[cpg cn=true]


[OnName num="gorou"]
“No. I just felt like I hadn't said it enough.”
[cpg cn=true]


[OnName num="father"]
“Don't worry about it. I couldn't leave you alone."
[cpg cn=true]


Dad looks like he is embarrassed.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]

[VOICE f="sSawa067"]
[OnName num="sawa"]
“What's wrong? You two seem to be talking a lot.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah. I'm just happy to be in this house.”
[cpg cn=true]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]

[VOICE f="sSawa068"]
[OnName num="sawa"]
“Well. That's rare."
[cpg cn=true]


Rare. I haven't said anything like this in the past.
[cpg]


[OnName num="gorou"]
“I'm sorry for not being able to make you guys happy.”
[cpg cn=true]


[OnName num="father"]
“It’s okay. You're not old enough to be worried about that."
[cpg cn=true]


Dad repeats the phrase "Don't worry about it”. I was grateful for that.
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[window target=true]


I am still guilty though. For letting Suzune, Himari and mom get me excited.
[cpg]


I know he didn't say “don't worry about that” for that specific situation, ...... but it still made me feel better.
[cpg]


[window target=false]


[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

After finishing dinner, I was relaxing in my room when Himari came in.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sHimari110"]
[OnName num="himari"]
“Hey, are you sure you're not going to pick anyone?”
[cpg cn=true]


[OnName num="gorou"]
“Yeah. I've been thinking since then. ......"
[cpg cn=true]


[OnName num="gorou"]
“It’s not that I like you all equally, it’s more that I have a reason that I can't pick just one person."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="sHimari111"]
[OnName num="himari"]
“What do you mean?”
[cpg cn=true]


[OnName num="gorou"]
“I ...... like this house.”
[cpg cn=true]


[OnName num="gorou"]
“I don't want to ruin this relationship. After what happened today, I feel that deeply.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari112"]
[OnName num="himari"]
"...... That's probably a hard thing to say for you right? From our perspective, you are one person."
[cpg cn=true]


[OnName num="gorou"]
“Sorry. ……"
[cpg cn=true]


Himari seemed a little angry, but also forgiving.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sHimari113"]
[OnName num="himari"]
“Well, it's not the first time Goro has been indecisive, so I've given up.”
[cpg cn=true]


[OnName num="gorou"]
“I'm so sorry.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sHimari114"]
[OnName num="himari"]
“No need to apologize. You've made up your mind. Despite being so indecisive."
[cpg cn=true]


I was kind of sorry and couldn't say anything.
[cpg]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]
;//【ＢＧ】『街』（朝）******************************************************

My condition had calmed down a lot. Even though I wasn’t really in love with anyone.
[cpg]


Nothing had changed so far concerning the relationship, but everything was about to come full circle.
[cpg]


It was at this time that I decided.
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『学園教室』（昼）******************************************************

[OnName num="gorou"]
“Suzune, what's wrong?”
[cpg cn=true]


I was in an empty classroom when Suzune called me.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sSuzune084"]
[OnName num="suzune"]
“I’m…… sorry. I didn't mean to call you out of the blue.
[cpg cn=true]


[OnName num="gorou"]
“That's fine, but what's wrong?”
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune085"]
[OnName num="suzune"]
“I mean, it's not that something just happened, it's more about ......, something that had been going on for a while.”
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune086"]
[OnName num="suzune"]
“Goro. Do you like me?"
[cpg cn=true]


[OnName num="gorou"]
“Yes. I like you."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSuzune087"]
[OnName num="suzune"]
“I'm bad at asking questions. Do you love me?”
[cpg cn=true]


[OnName num="gorou"]
“I’ve ...... already decided that I'm not going to choose anyone."
[cpg cn=true]


That seemed to pain Suzune .
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSuzune088"]
[OnName num="suzune"]
“I like you so much I want to be your lover."
[cpg cn=true]


...... I hadn't considered this possibility until just now.
[cpg]


It wasn't up to me to choose someone.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune089"]
[OnName num="suzune"]
The four of us together is fun, but it's also hard.
[cpg cn=true]


Suzune was apparently in love with me to this extent.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune090"]
[OnName num="suzune"]
“I am ready to be yours only.”
[cpg cn=true]


Those words seemed to suggest that she wanted me to only be with her as well.
[cpg]


[OnName num="gorou"]
“……"
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune091"]
[OnName num="suzune"]
“I'm not going to hide it. I want to marry you."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune092"]
[OnName num="suzune"]
“If you say you won't choose anyone then ...... I would like to keep my distance from you. It is painful for me to be near you when I can't be with you.”
[cpg cn=true]


My heart was tightening. All I want is to be with my family.
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『学園廊下』（夕方）******************************************************

[OnName num="male_student_A"]
“So, your future huh?”
[cpg cn=true]


[OnName num="male_student_B"]
“Why are you so worried? You said you wanted to get a job right after graduation."
[cpg cn=true]


[OnName num="male_student_A"]
“I'm trying, but I don't think my parents will let me.”
[cpg cn=true]


[OnName num="male_student_A"]
“My siblings are also being very vocal about it ...... I don't know what to do.”
[cpg cn=true]


[OnName num="male_student_B"]
“You have to be yourself. You can't stay with your family forever no matter how much you care for them.”
[cpg cn=true]


From a distance....., I hear a conversation between two people.
[cpg]


Families can't stay together forever. That might indeed be true.
[cpg]


[window target=false]



[BG f="b_01_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************


With Suzune I can either have a non-family relationship or distance myself from the family. Does it have to be one or the other?
[cpg]


I, for one, want to keep our relationship the way it is.
[cpg]


[window target=false]

[STOPBGM]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


At the dinner table that day, Suzune and I had a tense moment.
[cpg]


Of course, Himari seemed to notice something and was concerned.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sSawa069"]
[OnName num="sawa"]
“What's wrong? You're not eating anymore."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSuzune093"]
[OnName num="suzune"]
“Yeah, ...... I don't have much of an appetite."
[cpg cn=true]


What should I do with Suzune. I felt like I had more to explain to her.
[cpg]


[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="gorou"]
“......I knew this was the only way.”
[cpg cn=true]


I think. After much thought, I came to one conclusion.
[cpg]


I will not choose between Himari and Suzune. I found the only way to continue our current relationship.
[cpg]



;//ブラックアウト
[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

The next morning. Before I left, I call Suzune .
[cpg]


[OnName num="gorou"]
"I'm sorry to bother you while you’re busy."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune094"]
[OnName num="suzune"]
“It’s okay. Have you thought about it?”
[cpg cn=true]


[OnName num="gorou"]
"Yeah. I've come up with my own conclusion.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sHimari115"]
[OnName num="himari"]
“What conclusion?”
[cpg cn=true]


Himari is also here. I really needed her to be.
[cpg]


Because if Suzune and I were to get married, Himari would still want to be by my side.
[cpg]


I don't even need to ask that anymore, it's too selfish and rude to even ask.
[cpg]


With mom it’s different of course. She would not do that.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="sSuzune095"]
[OnName num="suzune"]
“… I don't see the point in hiding it from Himari. I told Goro that I love him so much I want to marry him.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="sHimari116"]
[OnName num="himari"]
“Wow. That's bold."
[cpg cn=true]


Himari doesn't seem upset at all. I guess she thinks that I can't muster up the courage to do so.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune096"]
[OnName num="suzune"]
“I told him that if I ...... can't get married, it's hard for me to be around him.”
[cpg cn=true]


[OnName num="gorou"]
“Yes. I want you to be with me. But I also want Himari to be with me."
[cpg cn=true]


[OnName num="gorou"]
I was wondering if such a convenient thing was possible.
[cpg cn=true]


Suzune holds her breath, waiting for me to say something.
[cpg]


[OnName num="gorou"]
“I think ...... that the three of us should get married.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="sHimari117"]
[OnName num="himari"]
“Huh?"
[cpg cn=true]


[OnName num="gorou"]
“Not right now, of course. Because I like us as a family."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="sSuzune097"]
[OnName num="suzune"]
“Do you know what you're talking about? Polygamy is not allowed in Japan.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah, well, ...... We’re not going to make it official of course.”
[cpg cn=true]


[OnName num="gorou"]
“But if we can do it overseas, and if you’re both interested, then I guess that's fine too."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune098"]
[OnName num="suzune"]
“Oh, you know, ...... it's not a matter of law, it's a matter of the heart."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune099"]
[OnName num="suzune"]
“Are you thinking about it when we move in together, or have kids?"
[cpg cn=true]


[OnName num="gorou"]
“I'm thinking about it. I'm seriously thinking about marrying you both."
[cpg cn=true]


[OnName num="gorou"]
“I’ve decided not to choose. I don't think it's a good idea to do things halfway."
[cpg cn=true]


A strange silence passes. In the midst of it all, Himari starts laughing.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari118"]
[OnName num="himari"]
“...... pfft, ha ha ha ha.”
[cpg cn=true]


[OnName num="gorou"]
“Himari?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari119"]
[OnName num="himari"]
“I didn’t know you were thinking that. You should have told me."
[cpg cn=true]


After she finished laughing, Himari said.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari120"]
[OnName num="himari"]
“You don't have to marry the both of us, or go overseas, or anything.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari121"]
[OnName num="himari"]
“Because I could still be with you even if you and Suzune get married.”
[cpg cn=true]


[OnName num="gorou"]
“What?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sSuzune100"]
[OnName num="suzune"]
“But ...... Then I'll have Goro all to myself.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sSuzune101"]
[OnName num="suzune"]
“If you like Goro as much as I do, you can't allow that to happen."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="sHimari122"]
[OnName num="himari"]
“You both think too much. We don't know what the future holds."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari123"]
[OnName num="himari"]
“First of all, why do you want to get married? What’s the border line of being monogamous? I'm totally fine with being Goro’s second favorite."
[cpg cn=true]


Himari was someone who could leave things ambiguous.
[cpg]


She is trying to untangle us from our thoughts.
[cpg]


Maybe she's trying to help us out of this situation, even if it's a little overwhelming.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="sSuzune102"]
[OnName num="suzune"]
“Himari, aren’t you jealous?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari124"]
[OnName num="himari"]
“I am. But if it’s my sister, then I don’t mind.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="sHimari125"]
[OnName num="himari"]
“You both think too seriously. It's not like the world is going to end when this day comes, so why don't we just leave things the way they are?"
[cpg cn=true]


Suzune and I look at each other.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sHimari126"]
[OnName num="himari"]
“Are you okay with the time? I'm used to being late."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="sSuzune103"]
[OnName num="suzune"]
“Ah!"
[cpg cn=true]


;//ブラックアウト

[window target=false]

[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（朝）******************************************************

We were talking for too long. I hurry up and get ready and head to the academy, but Suzune would probably be late.
[cpg]


Himari said that we shouldn’t act so abruptly, which made me feel a little better.
[cpg]


Maybe what I decided to do is what Himari proposed.
[cpg]


I want to stay as close as I can for as long as possible.
[cpg]


Himari probably saw through that and tried to calm Suzune down.
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『学園教室』（昼）******************************************************


[OnName num="male_student_A"]
“I've made up my mind. I'm going to get a job after all.”
[cpg cn=true]


[OnName num="male_student_B"]
“Well, that's good. It would be foolish to go to school for the sake of the family.”
[cpg cn=true]


[OnName num="male_student_A"]
“Yea. I figured if I'm going to think about what's best for my family, I might as well do what I want to do."
[cpg cn=true]


[OnName num="male_student_A"]
“Also if I fret, it will be bad atmosphere to bring to the family."
[cpg cn=true]


[OnName num="male_student_A"]
“If I work on myself it will be good for the family.”
[cpg cn=true]


Someday I will become a couple with someone. Looks like I’ve made a bit of progress.
[cpg]


I can't be indecisive either. I can’t keep the state of not being able to choose who I'm going to be with.
[cpg]


I thought to myself that I just have to push forward once I've decided.
[cpg]


[window target=false]

[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]
;//【ＢＧ】『学園教室』（夕方）******************************************************

This is a way of thinking, but I also wonder if everything has to be decided.
[cpg]


Himari’s way of thinking could solve everything.
[cpg]


Even if it doesn't solve everything, the current situation might be the best situation at least for now.
[cpg]


It seems that I can't even realize such an obvious thing without being told by my sister.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSuzune104"]
[OnName num="suzune"]
"So ...... the solution here is ......"
[cpg cn=true]


Suzune is acting so calmly that I almost forgot that I made her unpunctual.
[cpg]


It's the same when I'm in the same classroom. I'm sure it's thanks to the presence of Himari that I can stay calm like this.
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
;//【ＢＧ】『街』（夕方）******************************************************



[OnName num="female_student"]
“What an unexpected ending.”
[cpg cn=true]


[OnName num="male_student"]
“Unexpected? Like in a manga?”
[cpg cn=true]


[OnName num="female_student"]
“Yea. Like when you feel surprised by the unexpected outcome of people falling in love.”
[cpg cn=true]


[OnName num="male_student"]
“Oh. I'd rather have a harem than some weird outcome.”
[cpg cn=true]


Reality is not a manga. I’m not worried about such an outcome.
[cpg]


I thought that while listening to some couple's story.
[cpg]


[OnName num="female_student"]
“What! What do you mean a harem. Are you cheating on me?"
[cpg cn=true]


[OnName num="male_student"]
“No, no. ...... how can that be?"
[cpg cn=true]


...... I wouldn’t mind with being a couple with either of the two girls.
[cpg]


But again, reality is not a manga.
[cpg]


I don't live my life to be seen, or to put on a show for someone.
[cpg]


If that's the case, the way to pursue happiness, even if it's ambiguous, is definitely the way to go.
[cpg]




;//ブラックアウト


[window target=false]



[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="sSuzune105"]
[OnName num="suzune"]
“Himari, could you stop flirting in front of dad.”
[cpg cn=true]


[VOICE f="sHimari127"]
[OnName num="himari"]
“You just want to flirt to Suzune.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSuzune106"]
[OnName num="suzune"]
“No! That would be chaotic.”
[cpg cn=true]


[OnName num="gorou"]
“It hurts me when you reject me....."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSuzune107"]
[OnName num="suzune"]
“Oh, no, that's not what I meant.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]

Mom is chuckling.
[cpg]


At first I thought it was strange that I would not chose anyone, but maybe having this kind of a lifestyle might not be that bad.
[cpg]


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[window target=true]


Then a while later, ......
[cpg]


;//========================================
;//●ＣＧ（ベッドに三人寝転がっている。おなかは膨らんでない）ev_50
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：ヒロイン２
;//服装２：私服
;//人物３：ヒロイン３
;//服装３：私服
;//場所　：主人公の部屋
;//時間　：夜
;//========================================


[STOPBGM]
[WAIT time=1000]
[BGM f="bg_op"]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sHimari128"]
[OnName num="himari"]
“Heh heh heh. We're all together, it's kind of like a trip."
[cpg cn=true]


[VOICE f="sSawa070"]
[OnName num="sawa"]
“That’s true. We haven't taken a family vacation in a while."
[cpg cn=true]


[VOICE f="sSuzune108"]
[OnName num="suzune"]
"......, yeah, right."
[cpg cn=true]


Today, at Himari 's request, the four of us will spend time together.
[cpg]


It's not for me since my condition has settled down.
[cpg]


I guess it's my destiny, as I didn't choose anyone.
[cpg]


[VOICE f="sHimari129"]
[OnName num="himari"]
"Come on, Goro. You get to choose who you pick today. I’m sure you'll be excited a lot.”
[cpg cn=true]


[VOICE f="sSuzune109"]
[OnName num="suzune"]
“You're out of your ...... mind. This is crazy."
[cpg cn=true]


[VOICE f="sHimari130"]
[OnName num="himari"]
“Well, I'm having fun. I wish we could be together all the time."
[cpg cn=true]


I was feeling indescribable, yet excited.
[cpg]


[VOICE f="sSawa071"]
[OnName num="sawa"]
"Heh. Himari you’re so innocent.”
[cpg cn=true]


Mom smiles innocently as well.
[cpg]


I don't know what the three of them really think. But they seemed to be happy.
[cpg]




[VOICE f="Suzune385"]
[OnName num="suzune"]
“I'm going to get angry if you don't love all three of us.”
[cpg cn=true]


[VOICE f="sHimari131"]
[OnName num="himari"]
“I’m so glad you’re here Goro. You might become a dad soon.”
[cpg cn=true]


[OnName num="gorou"]
“I don't know.”
[cpg cn=true]


[VOICE f="Sawa315"]
[OnName num="sawa"]
“Don't leave anyone out.”
[cpg cn=true]




[OnName num="gorou"]
"...... I know. I know.”
[cpg cn=true]


Is there such a thing as a harem? There should be.
[cpg]



;//ブラックアウト

A family. Lovers. Relationships that cannot be defined by such words.
[cpg]


I was certainly happy while keeping things ambiguous.
[cpg]


......Suzune, Himari, and mom probably feel the same way.
[cpg]

[SCENE id=12]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]
;//ＥＮＤ：ハーレムルート






;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





