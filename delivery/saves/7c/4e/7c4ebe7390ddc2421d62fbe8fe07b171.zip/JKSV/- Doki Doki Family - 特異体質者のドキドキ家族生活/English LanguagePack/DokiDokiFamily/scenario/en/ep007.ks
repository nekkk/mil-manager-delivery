
*start

;###################################################################
*Ep007|Taboo thought towards Sawa
;###################################################################


;//３、砂羽
*select04_3|

[SCENE id=7]


[window target=false]

[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]

[window target=true]


Mom’s face comes to my mind. Even though I can't believe it, it can't be helped.
[cpg]


If it were Suzune or Himari it would have been okay. They are my stepsisters and we are close in age.
[cpg]


But with mom, there is a significant age difference. That’s not the only thing ......
[cpg]


She's married. She has dad.
[cpg]


And dad is still a dad for me and ...... The more I think about it the more impossible it seems.
[cpg]


;//ブラックアウト

[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[window target=true]

It's Himari that helps me get my heart pound in the morning. She comes to my room and ......
[cpg]


But after that I was hesitant to leave the house.
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari317"]
[OnName num="himari"]
“Goro, aren't you going already? You’re going to be late."
[cpg cn=true]


[OnName num="gorou"]
“Yeah, I'll catch up with you later ...... go ahead first.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari318"]
[OnName num="himari"]
“Hmmm. I guess you wanted to talk to me?"
[cpg cn=true]


She saw right through me. It was inevitable. ......
[cpg]


[free time=1000]

[SE f="se003"]
;//【ＳＥ】『ドア閉まる』


Himari left and it was just mom and I.
[cpg]


Suzune and Dad went to work. Himari went to school.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa108"]
[OnName num="sawa"]
“You wanted to talk to me? Whats wrong?”
[cpg cn=true]


She asks me calmly.
[cpg]


She can probably tell that I have something serious on my mind. But mom tries not to notice.
[cpg]


[OnName num="gorou"]
“...... Mom...... I want to ...... umm..."
[cpg cn=true]


I am at a loss for words. I don't know what to say.
[cpg]


I feel like if I say it, it's the end of the world. And then…
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa109"]
[OnName num="sawa"]
“I think I know what you’re trying to say. I guess we got a bit too close.”
[cpg cn=true]


She said that she could tell. And she told me that I got too close ......
[cpg]


[OnName num="gorou"]
“Uh, well, uh, ...... that’s..."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa026"]
[OnName num="sawa"]
“I guess it can’t be helped. If you say you like me."
[cpg cn=true]


She accepted the situation quite….. easily. No, that's not good.
[cpg]


[OnName num="gorou"]
“Hey, wait a minute, wait a minute! I'm serious."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa027"]
[OnName num="sawa"]
“Anyway, I'll see you this evening. If you don't go soon, you'll be late for school.”
[cpg cn=true]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************





So I head to school.
[cpg]


But my head is in the clouds. Even if I see Suzune in the afternoon ......
[cpg]


Even with that in mind, I can't stay calm. When I think that mom could have done it for me.
[cpg]


This alone makes me painfully excited. I have never had a crush like this before.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************



And in the evening after school, I was feeling lightheaded.
[cpg]


Mom said that it was inevitable, but was that true?
[cpg]


I was somewhat unaware of what I was really feeling. Naturally, I would have to talk to her before dad came home.
[cpg]


Since their rooms are separated, there is a chance that we wouldn't run into each other.
[cpg]




;//ブラックアウト


[window target=false]

[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************



While I was thinking about this, I arrived home.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Himari319"]
[OnName num="himari"]
"Welcome home. Your face……”
[cpg cn=true]


I wonder what color it is. Red or blue? It doesn't matter.
[cpg]

[free time=1000]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa028"]
[OnName num="sawa"]
"Hmmm. You look like you're having a hard time. Are you okay?”
[cpg cn=true]


With a pat on the head, she takes me to her room.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト




I was excited just being by her side and holding my hand.
[cpg]


I couldn't help but feel that my heart was controlling me.
[cpg]



;//========================================
;//●ＣＧ（ヒロインが寝ている主人公に近づく。穏やかに微笑んでいる→心配そうな表情に）ev_36
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================



[STOPBGM]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSawa029"]
[OnName num="sawa"]
“I wonder if just being near me...... Makes you feel excited.”
[cpg cn=true]


I'm excited. I nod and replied.
[cpg]


[OnName num="gorou"]
“Yes,...... it's very, very calming.”
[cpg cn=true]


Mom seemed stunned for a moment and then laughed a little.
[cpg]


[VOICE f="sSawa030"]
[OnName num="sawa"]
“Heh. Is it enough to feel calm? Shouldn't you be excited?"
[cpg cn=true]


But that was all I could say.
[cpg]


Maybe I don't want to feel excited after all, I just want to calm down.
[cpg]


Maybe the reason that I have trouble breathing to begin with might be because I can't get a crush and I'm anxious .......
[cpg]


If that's the case, my condition may be cured just by doing this.
[cpg]


Just being around Mom made me feel satisfied.
[cpg]


;**【ＣＧ】 ev_36_a ***********************
[CG id=16 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa031"]
[OnName num="sawa"]
“Anyway. I want to do what you want me to do.”
[cpg cn=true]


[OnName num="gorou"]
“Thank you. Mom "
[cpg cn=true]


[VOICE f="sSawa032"]
[OnName num="sawa"]
“…… I'm really worried about you. Goro I think of you as my child, too."
[cpg cn=true]


And suddenly, she looked worried.
[cpg]


;**【ＣＧ】 ev_36_b ***********************
[CG id=16 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa033"]
[OnName num="sawa"]
“I figure if you could feel excited with me, that's okay too.”
[cpg cn=true]


[VOICE f="sSawa034"]
[OnName num="sawa"]
“I would do anything to make you suffer less."
[cpg cn=true]


I didn't know she thought that much of me. I was kind of taken aback because she gives the impression of being a calm person.
[cpg]


[OnName num="gorou"]
“That makes me happy. Thank you so much.”
[cpg cn=true]


I knew it was a dumb thing to say, but I had to let her know how much I appreciated it.
[cpg]


I tried to keep my face and voice as serious as possible. I tried to convey my feelings, but ......
[cpg]


But mom looks extra troubled.
[cpg]


For some reason, she seems even more distressed.
[cpg]


[VOICE f="sSawa035"]
[OnName num="sawa"]
“If you like me Goro, I think that's fine too. That's not a lie."
[cpg cn=true]


Mom chooses her words carefully and gradually tells me how she feels about me.
[cpg]


;**【ＣＧ】 ev_36_c ***********************
[CG id=16 index=3 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa036"]
[OnName num="sawa"]
“I don't know what to do. You’re definitely my child, but I also like you.”
[cpg cn=true]


Well ...... I didn't know I was making her think that.
[cpg]


[OnName num="gorou"]
“ ......"
[cpg cn=true]


Was I being too insensitive? Although I’m her stepson, I’m still her son.
[cpg]


I'm pushing Mom too hard. I realized that.
[cpg]


I think I may have acted too selfishly, but I still can't stop ...... this feeling.
[cpg]


[OnName num="gorou"]
“I'm sorry. But I can't stop this feeling.”
[cpg cn=true]


What should I do? If I express that anxiety out loud, will I annoy Mom even more?
[cpg]


If so, I think it would be better to say what I want to do.
[cpg]


[OnName num="gorou"]
“I want to kiss you.”
[cpg cn=true]


I said that to cover up the tension in the atmosphere. And she nodded.
[cpg]


I watch her close her eyes and I move closer. ......
[cpg]


This step is probably a step that no sane person would take. But I was going crazy.
[cpg]


[BG f="black.ui" time=1000]
[WAIT time=2000]
;//ブラックアウト

...... then.
[cpg]


I kissed her on the lips. Obviously, I had crossed a line that I shouldn’t have crossed.
[cpg]


[OnName num="gorou"]
“……"


;//ＣＧ
;**【ＣＧ】 ev_36_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sSawa037"]
[OnName num="sawa"]
She giggles. “Don't make that face."
[cpg cn=true]


What did I look like? Did I look like I regretted it?
[cpg]


[VOICE f="sSawa038"]
[OnName num="sawa"]
“Did you get a good heart pound?"
[cpg cn=true]


If you put it that way, I'd be lying if I said I wasn't excited. But.
[cpg]


[OnName num="gorou"]
“Just one more time. ……"
[cpg cn=true]


[VOICE f="sSawa039"]
[OnName num="sawa"]
“No. That’s it for today. It won’t be good for you to get used to this.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah, I know, but…"
[cpg cn=true]


[VOICE f="Sawa132"]
[OnName num="sawa"]
“Look. If you persist too long, the girls won't like you.”
[cpg cn=true]


Did “girls" include mom ?
[cpg]


It was rude to ask that, so I silently withdrew.
[cpg]



[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I didn't want to be disliked by her. So I decided not to push my luck.
[cpg]


I was conflicted, not knowing if we were in a bad place.
[cpg]

[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト

[SE f="se009"]
;//【ＳＥ】『鳥の鳴き声』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************





In the morning, I couldn't look mom in the face properly.
[cpg]


Seeing this, Suzune and Himari seemed to have sensed something.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Himari320"]
[OnName num="himari"]
"You crossed some kind of line, didn't you, Goro?”
[cpg cn=true]


[OnName num="gorou"]
“...... umm.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune325"]
[OnName num="suzune"]
“…… I won't say anything. You two can work this out between yourselves."
[cpg cn=true]


That's like she’s implying that the situation is disgusting.”
[cpg]


But I can't help it. I like mom.
[cpg]


[free time=1000]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa133"]
[OnName num="sawa"]
“Don't be too hard on Goro. I'm the one who let him on to the idea.”
[cpg cn=true]


She pats my shoulder. If dad were here we’d be in a lot of trouble.
[cpg]


I’m glad that dad is a person who leaves the house early...... I thought while finishing my breakfast.
[cpg]


;//ブラックアウト

[window target=false]

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************


[OnName num="gorou"]
“I'm off. ……"
[cpg cn=true]

[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Sawa134"]
[OnName num="sawa"]
“Yeah. Have a good day."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Himari321"]
[OnName num="himari"]
“I'm off.”
[cpg cn=true]


I feel ...... uneasy. I want to stay with mom.
[cpg]


But that’s probably going to be a wish unfulfilled.
[cpg]


At the end of the day we are mother and son. Also I have to go to school in the first place.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[window target=false]

[STOPBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

[window target=true]


I head to school with my head in the clouds.
[cpg]

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="male_student"]
“Hey Kosaka! Don’t you think I look different today?”
[cpg cn=true]


[OnName num="gorou"]
“I don't know..., and I don't think ……"
[cpg cn=true]


[OnName num="male_student"]
“I have a girlfriend now! Spring has come for me too, ha ha ha."
[cpg cn=true]


[OnName num="gorou"]
“Oh. That’s great."
[cpg cn=true]


[OnName num="male_student"]
“What's with the lack of response? I haven’t kissed her yet."
[cpg cn=true]


...... I kissed someone I'm not even dating. On top of that it’s my mom.
[cpg]


I can't say that. In the meantime, Suzune is waiting for me.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[FG f="ci_lbox.ui" method="feadin"  pos="4/7"]

[BG f="b_03_2_up.ui" time=1000]
[WAIT time=2000]

And lunch. When we were alone, Suzune told me this.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune326"]
[OnName num="suzune"]
"...... Mom is our real mother. So ......."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Suzune327"]
[OnName num="suzune"]
“Please don't destroy our home with your frivolity.”
[cpg cn=true]


She said. Those were pretty harsh words.
[cpg]


The way she said "our real mother " also has a prickly edge to it. But I guess it can't be helped.
[cpg]


I'm like an outsider.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************





I have to fall in love with someone to cure my condition.
[cpg]


I think Suzune and Himari were also possible partners.
[cpg]


But I didn't want that. The person I love is Mom.
[cpg]


I couldn't think of anything else. I like Mom.
[cpg]


Now that I've said it, I understand why Suzune told me not to break up the family.
[cpg]


Suzune’s words are echoing in my head.
[cpg]


;//ブラックアウト


[window target=false]

[STOPBGM]

[BG f="b_04_3_up.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_da"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夕方）******************************************************


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa135"]
[OnName num="sawa"]
“Welcome back. How are you doing, are you having a hard time already?"
[cpg cn=true]


It's hard. I was in no condition to lie.
[cpg]


[OnName num="gorou"]
"...... yeah. Mom I want to be with you. Would that be okay?”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa136"]
[OnName num="sawa"]
“Of course. I'm the one who decided to take on the evening.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



Then she took me to her room.
[cpg]


I felt ...... such a sense of relief just by being there.
[cpg]


;//========================================
;//●ＣＧ（寝ているヒロインに迫る主人公。抱きしめ合う感じ）ev_37
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================


[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[BGM f="bg_h2"]
;**【ＣＧ】 ev_37_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sSawa040"]
[OnName num="sawa"]
“Come on, I'll give you a hug."
[cpg cn=true]


I was about to cry when I saw her spread her arms.
[cpg]


I wanted to confide in her with all of my feelings right now.
[cpg]


But I can't say it, and I'm still on the verge of tears.
[cpg]


I don't know what to do. I don't even know if I should go through with this love.
[cpg]


There is no doubt in my mind that I love mom .
[cpg]


And more than that, I didn't want to be a burden to mom .
[cpg]


[OnName num="gorou"]
“…..I still like you.”
[cpg cn=true]


The words came out in a voice so small that even I was surprised. I know I shouldn't say that much.
[cpg]


If I say that I want to be her boyfriend, it will be the end.
[cpg]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa041"]
[OnName num="sawa"]
“I know. I know. You don't have to say everything.”
[cpg cn=true]


That was a big relief.
[cpg]


[OnName num="gorou"]
“…… yeah."
[cpg cn=true]


[VOICE f="sSawa042"]
[OnName num="sawa"]
“I know you've had a hard day. It's okay to lean on me.”
[cpg cn=true]


I think there are some words that if you say them, there is no turning back. I was glad that mom sealed them.
[cpg]


Without saying anything, I hugged Mom.
[cpg]


[OnName num="gorou"]
“I like your smell.”
[cpg cn=true]


She does not become shy when I say this. This is definitely not the case with Himari or Suzune.
[cpg]


Mom doesn't think I'm coming any closer than I have to.
[cpg]


;**【ＣＧ】 ev_37_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa043"]
[OnName num="sawa"]
"Okay, ...... Goro, you'll always be my spoiled little boy.”
[cpg cn=true]


The gentle voice makes me unable to suppress what I had been hiding and pushing down.
[cpg]


I want Mom all to myself. It's easy to say that.
[cpg]


But I don't know if ...... I can really do that.
[cpg]


Not only do I not know, but mom may not know either.
[cpg]


If that's the case, the words I've said won’t take us any further.
[cpg]


[VOICE f="sSawa044"]
[OnName num="sawa"]
“What's wrong? You look like you're about to cry."
[cpg cn=true]


Now mom is not my just my mom . I couldn't help but think that.
[cpg]


It also makes me look like I'm about to cry. I've seriously fallen in love with Mom .
[cpg]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa045"]
[OnName num="sawa"]
“Did something sad happen?”
[cpg cn=true]


It's not sad, it's just hopeless. My current situation is hopeless.
[cpg]


It's not good any more. I know that. And that's why I can't stop.
[cpg]


[OnName num="gorou"]
“I've already made up my mind. Mom ……"
[cpg cn=true]


Mom looks a little worried.
[cpg]


Maybe she somehow knew what she is going to be told.
[cpg]


;**【ＣＧ】 ev_37_b ***********************
[CG id=17 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa046"]
[OnName num="sawa"]
“What do you mean, you've made up your mind?”
[cpg cn=true]


[OnName num="gorou"]
“You remember what they said about me? That my condition won't settle down unless I fall in love."
[cpg cn=true]


Mom apparently knows everything. Still, she listened to me talk.
[cpg]


[VOICE f="sSawa047"]
[OnName num="sawa"]
“Yeah. What about it?”
[cpg cn=true]


Once I say this, there is no going back. I have thought about it many times.
[cpg]


[OnName num="gorou"]
“I like you...... mom."
[cpg cn=true]


;**【ＣＧ】 ev_37_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa048"]
[OnName num="sawa"]
“Yeah. I know.”
[cpg cn=true]


[OnName num="gorou"]
“No. Mom you don't.”
[cpg cn=true]


[OnName num="gorou"]
“When I say I like you, I mean I’m in love with you.”
[cpg cn=true]


;//移植前シーンカット

;//ブラックアウト



I finally say it. The word "like" has a different meaning from now on.
[cpg]


There was a short silence. Then, mom asks.
[cpg]


;**【ＣＧ】 ev_37_b ***********************
[CG id=17 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="Sawa153"]
[OnName num="sawa"]
“Are you serious? You know what happens when you say that right?”
[cpg cn=true]


I know. At least I think I do. ......
[cpg]


[VOICE f="Sawa154"]
[OnName num="sawa"]
“We might be separated. Are you prepared for that?"
[cpg cn=true]


I know. It's something that could destroy a family.
[cpg]


I wonder what Suzune and Himari would think of it. Still the biggest problem is Dad .
[cpg]


I have to choose.
[cpg]




[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************



Dad is usually back by dinner.
[cpg]


[OnName num="father"]
“Suzune. How's work these days?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Suzune328"]
[OnName num="suzune"]
“Well, ...... there are still a lot of areas where I'm not capable enough.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari322"]
[OnName num="himari"]
“You're not an incapable person. Although you sometimes can be forgetful about things.”
[cpg cn=true]


They are talking about such things. It’s an ordinary family conversation.
[cpg]


But I ...... was feeling kind of alienated.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************



Later, I invite Himari and Suzune into my room.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Himari323"]
[OnName num="himari"]
“...... what's wrong? You look so strange.”
[cpg cn=true]


[OnName num="gorou"]
“Yeah, well.……"
[cpg cn=true]


As I was trying to figure out how to start the conversation, Himari says to me,
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Himari324"]
[OnName num="himari"]
“Is it about mother? Am I right?”
[cpg cn=true]


[OnName num="gorou"]
“How did you know? Anyway, I’m not happy with the way things are right now.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Suzune329"]
[OnName num="suzune"]
“What do you mean? Why are you unhappy?”
[cpg cn=true]


[OnName num="gorou"]
“I want to cure this condition. And in order to do that I want to fall in love with mom."
[cpg cn=true]


Suzune naturally flinched. She did try to flirt with me once.
[cpg]


But Himari was easygoing.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Himari325"]
[OnName num="himari"]
“I kind of knew this was going to happen. So it’s true.”
[cpg cn=true]


Suzune is still perplexed. But I continue to speak.
[cpg]


[OnName num="gorou"]
“I'm sorry Suzune ...... I’m glad to have you Himari and Suzune, but it doesn't solve anything."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Suzune330"]
[OnName num="suzune"]
“...... Oh … I see …"
[cpg cn=true]


Did they accept it? I don't even feel like they fully understand it yet. ……
[cpg]


But this is something that takes time to understand.
[cpg]


After all, Suzune and Himari are mom’s real daughters.
[cpg]


It's a very complicated relationship, but I've fallen in love with mom. I can't help it.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト








By the end of the night, Suzune was convinced.
[cpg]


In the end, she seemed to support me.
[cpg]

[BG f="b_06_4.ui" time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1000]

[WAIT time=2000]

[VOICE f="Suzune331"]
[OnName num="suzune"]
"...... Don't be too reckless. I really care about my family."
[cpg cn=true]


After hearing what she thought, we each went back to our own rooms and went to sleep.
[cpg]




[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************



[OnName num="gorou"]
"...... Oh, what? Mom? "
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa049"]
[OnName num="sawa"]
“Himari told me. Why don't I make your heart pound in the morning, too?"
[cpg cn=true]


[OnName num="gorou"]
“I'm ...... happy, but, um..."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSawa050"]
[OnName num="sawa"]
“You'll miss school.”
[cpg cn=true]


As I was reconsidering, mom was getting closer.
[cpg]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』

[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
;//ブラックアウト
;//移植前シーンカット

[window target=true]


She just stroked my head and hugged me. No kissing.
[cpg]


Still, it was more than enough to make me excited. Because she is my favorite person.
[cpg]



[window target=false]


[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************


Then I had to leave the house right away, so I skipped breakfast.
[cpg]


[OnName num="gorou"]
“I'm heading out now"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa174"]
[OnName num="sawa"]
“Have a good day. I’ll see you…… in the evening too."
[cpg cn=true]


I was excited. With that in mind, I left the house.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_01_1.ui" time=1000]
[WAIT time=1000]


I walk along the road to the school. Nothing special, just a normal day.
[cpg]


But there was something I had to think about.
[cpg]


I might destroy my family. I wondered if I was prepared to do so.
[cpg]


Maybe there is a way to prevent that from happening. But there are going to be consequences.
[cpg]


I have to think about it. I also can't stay in the same body condition.
[cpg]




[window target=false]

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『学園教室』（昼）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune332"]
[OnName num="suzune"]
"...... Can't it be me?"
[cpg cn=true]

;//＠昼に空き教室で抜いてもらってから、姉さんにそう言われた。


[OnName num="gorou"]
"No, it has to be ...... mom ."
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Suzune333"]
[OnName num="suzune"]
“What if I told you that I like you, too?”
[cpg cn=true]


[OnName num="gorou"]
“……"
[cpg cn=true]


She had a serious expression on her face. Is she serious? Or is it ......
[cpg]


Is she forcing herself to say so in order to protect his family? I couldn't come to a conclusion.
[cpg]


[OnName num="gorou"]
“I couldn't help it. I love mom ......."
[cpg cn=true]

I chose to use strong words. Suzune looks frustrated.
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Suzune334"]
[OnName num="suzune"]
“I see that ...... there's nothing I can do to stop you.”
[cpg cn=true]


She said she would support me, but I guess she still has something unresolved within her.
[cpg]


I don't know how she feels.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『街』（夕方）******************************************************


I'm don’t really know how I feel either. I often wonder if I'm doing the right thing.
[cpg]


I also didn't consider the fact that there is an age gap between us.
[cpg]


The more important fact is that she is my foster parent.
[cpg]


And Dad is still my dad…..
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_04_3.ui" time=1000]
[WAIT time=1000]


I could be making a terrible mistake. That’s what I think.
[cpg]


But mom wraps me up gently.
[cpg]


;//移植前シーンカット

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa051"]
[OnName num="sawa"]
“Welcome back, Goro . You're still in pain, aren't you?"
[cpg cn=true]



[OnName num="gorou"]
“Yeah……."
[cpg cn=true]



[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]
;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


I'm still hiding it from dad. I know I can't hide it forever.
[cpg]


Suzune and Himari are staying quiet about it. ...... but I guess I can't keep it up forever.
[cpg]


[window target=false]


[STOPBGM]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


After dinner, I go back to my room.
[cpg]


I ask mom to come to my room to talk……
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sSawa052"]
[OnName num="sawa"]
“What’s wrong. Are you in pain because you want your heart to pound again?"
[cpg cn=true]


Mom seems to be brushing off the serious atmosphere.
[cpg]


But I had a serious look on my face. I hope she can see that.
[cpg]


[OnName num="gorou"]
“I still love you mom. The word ‘love’ is not enough to express my feelings for you.”
[cpg cn=true]


I want to be as direct as possible. Without being pretentious.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Sawa193"]
[OnName num="sawa"]
“Don't ....... What if father finds out?"
[cpg cn=true]


[OnName num="gorou"]
“I'll make sure he doesn’t find out. I promise."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Sawa194"]
[OnName num="sawa"]
“I know. ...... Goro I know you're serious about this.”
[cpg cn=true]


Mom reacted as if she understood something.
[cpg]


She then goes on to say.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa195"]
[OnName num="sawa"]
“You really mean it, don't you? We can't get married by any means."
[cpg cn=true]



[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sSawa053"]
[OnName num="sawa"]
“I think it’s me, but you’re the one that will be bound by your feelings. Is that okay with you?"
[cpg cn=true]


I nod. I'm already done with that area of conflict.
[cpg]


Then Mom looks a little conflicted and says.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSawa054"]
[OnName num="sawa"]
“Okay.”
[cpg cn=true]


;//ブラックアウト

I'm sure mom likes me, too. Although I don't know if it's in a romantic way.
[cpg]


But I was fine with that. That's not what I should be worried about.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sSawa055"]
[OnName num="sawa"]
“All that’s left to say is that I'm not going to end up with you…… Goro.”
[cpg cn=true]


Yes. If only I could accept that part of the story.
[cpg]


I've already accepted that. I already know it's a forbidden love.
[cpg]


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の部屋』（朝）******************************************************





The next morning. The morning shifts are now with mom .
[cpg]


We decided to do things a little differently now.
[cpg]


I told her ...... that I wanted to kiss her.
[cpg]


[OnName num="gorou"]
“...... I’m nervous, just like I expected.’
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Sawa199"]
[OnName num="sawa"]
“I think I might be more nervous than you Goro "
[cpg cn=true]


Then she laughs. She doesn’t seem nervous to me.
[cpg]



;//移植前シーンカット

;//ブラックアウト

[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]

We are getting closer. The distance disappears.
[cpg]


Our lips touch each other. The feeling of the first kiss was like a rush of immorality.
[cpg]


;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[STOPBGM]

;//【ＢＧ】『街』（昼）******************************************************



Time passed. I stayed with Mom as long as I could.
[cpg]



[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]

[BGM f="bg_d2"]

;//【ＢＧ】『街』（夜）******************************************************


And ...... it was worth it, because my condition gradually calmed down.
[cpg]


;//ブラックアウト

[window target=false]

[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]

[window target=true]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（夜）******************************************************


I'm convinced. I can't get married no matter how hard I try.
[cpg]


We can't even act like normal lovers. But that's okay.
[cpg]


We can only love each other in secret, no matter how far we go.
[cpg]


And the most important person for mom is inevitably dad .
[cpg]


I thought so when I saw Mom smiling as if nothing had happened.
[cpg]


It is a love that will never come to fruition no matter what. But I think we were able to achieve something else.
[cpg]


;//ブラックアウト


[window target=false]


[STOPBGM]

[BG f="b_06_4.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Over time, my condition continued to improve.
[cpg]


I no longer had to go to the hospital.
[cpg]


But the problem started here.
[cpg]


I guess I have to continue my love affair with mom. Otherwise, my condition might relapse.
[cpg]


It'll be like this forever unless I fall in love with someone else.
[cpg]


And I don't think I will fall in love with someone else now.
[cpg]


In other words, I'm tying myself up…… just like mom said I would.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ドア開く』

[WAIT time=1500]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Sawa217"]
[OnName num="sawa"]
“Goro. May I have a word with you …..?"
[cpg cn=true]


[OnName num="gorou"]
“What's wrong? Are you lonely?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sSawa056"]
[OnName num="sawa"]
She giggles. “You’ve gotten so cheeky.”
[cpg cn=true]


Even though my condition has calmed down and I no longer need to be excited, mom is trying to touch me.
[cpg]


It's my fault. I couldn't say no, so I complied.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植前シーンカット

I feel relieved when I'm with her.
[cpg]


In that sense, I can't reject her either.
[cpg]


;//ブラックアウト


[window target=false]


[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="gorou"]
"...... Can't we do this some other time tomorrow? If you stay until too late, people might suspect us.”
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa235"]
[OnName num="sawa"]
“Yes, but ...... fine. I'll be patient."
[cpg cn=true]


Saying this, mom seems to really like me.
[cpg]


I was embarrassed, happy, and ……I felt sorry, but I couldn't look her in the eye.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『主人公の家＿玄関』（朝）******************************************************



[OnName num="gorou"]
“Well, I'm heading out then."
[cpg cn=true]


I leave the house with Himari, greeting my mom .
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Himari327"]
[OnName num="himari"]
"...... hey, Goro. What's going to happen to our relationship?”
[cpg cn=true]


[OnName num="gorou"]
“What do you mean?”
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sHimari094"]
[OnName num="himari"]
“You're going to be mom’s lover right? I wonder if I should call you father.”
[cpg cn=true]


I think she's joking. But she was being the usual innocent Himari .
[cpg]



[OnName num="gorou"]
“Hey, don't ever call me that ……."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『歩く』



After the conversation, we walked together down the street.
[cpg]


We headed to school. I didn’t need Suzune to do anything for me anymore.
[cpg]




[window target=false]


[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="male_student"]
“So, I finally kissed my girlfriend the other day.”
[cpg cn=true]


[OnName num="gorou"]
“…… yeah."
[cpg cn=true]


This is the guy who, a long time ago, was making a big deal about having a girlfriend.
[cpg]


I couldn’t tell him that I'm about to be called ‘father’ by my sister.
[cpg]




[window target=false]


[STOPBGM]

[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]

[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『学園教室』（夕方）******************************************************


And another time. I was called out by a female classmate with whom I’ve never had any contact.
[cpg]



[OnName num="female_student"]
"...... Kosaka, do you have a girlfriend?"
[cpg cn=true]


[OnName num="gorou"]
“Why? ......, uh, ......."
[cpg cn=true]


She is a girl who probably has a thing for me. Of course I'm single-minded towards mom.
[cpg]


But I can't even say I have a girlfriend. She's not my wife either.
[cpg]


[OnName num="gorou"]
“There might be someone that I like……."
[cpg cn=true]


[OnName num="female_student"]
“I see. Right."
[cpg cn=true]


Eventually, I rejected her in that way. It's not that I didn't want to go out with this girl.
[cpg]


But I only had Mom. I chose her instead of Suzune or Himari .
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se013"]
;//【ＳＥ】『歩く』



I walked home again, had dinner, and soon it was night.
[cpg]


It sounds tasteless when I say it like that, but there is one thing that has changed a lot.
[cpg]



[window target=false]


[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


That is that mom comes at night.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sSawa057"]
[OnName num="sawa"]
“……Goro"
[cpg cn=true]


I was happy just the same, even though the way I called her was the same as before.
[cpg]


I want to be closer to her. That’s what I think.
[cpg]


;//＠それから何度か交わった後、俺達は別れた。



And every morning that comes.
[cpg]


[window target=false]

[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d2"]

;//【ＢＧ】『主人公の家＿ダイニングキッチン』（朝）******************************************************



I'm sure there's only mom for me, but I wonder how she feels.
[cpg]


Maybe she likes me as well, since she comes here despite being married to dad.
[cpg]


But it's a love that can't be fulfilled in any way. We can't be lovers. ......
[cpg]


;//ブラックアウト
[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）

[BG f="b_01_1.ui" time=1000]
[WAIT time=1000]

I eat breakfast and go out the front door. Himari and I head in the opposite direction from the house.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Himari329"]
[OnName num="himari"]
"See you later, Goro."
[cpg cn=true]


[OnName num="gorou"]
“See you.”
[cpg cn=true]

[free time=1000]

;//【ＢＧ】『街』（朝）


I was spending my days in a kind of dumbfounded state.
[cpg]


I don’t have a girlfriend or a lover, but I definitely love someone.
[cpg]


This is the happiest I've ever been, but it’s an unusual happiness.
[cpg]



[STOPBGM]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


[BG f="b_02_1.ui" time=1000]

[WAIT time=2000]

[BG f="b_02_2.ui" time=1000]

[WAIT time=2000]


[BGM f="bg_d2"]
[BG f="b_02_3.ui" time=1000]

[WAIT time=1000]


I head to the school, take classes, and after school.
[cpg]

;//【ＢＧ】『学園教室』（夕方）


[OnName num="female_student"]
"...... Kosaka. Oh, you know, ......."
[cpg cn=true]


[OnName num="gorou"]
“…… What?"
[cpg cn=true]


It was my female classmate. This is the girl who asked me if I liked someone.
[cpg]


[OnName num="female_student"]
“I like you Kosaka. Would you want to go out with me……?"
[cpg cn=true]


I was in trouble. Maybe I can make a decent life shift here.
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『街』（夕方）******************************************************



In the end, I left with my answer pending.
[cpg]


I can't give her an answer right away. I can't go out with her until I break off my relationship with mom.
[cpg]


With these thoughts in mind, I walk back to my house......
[cpg]




;//ブラックアウト


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_me"]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************





[OnName num="gorou"]
"….. That's what happened to me. Mom."
[cpg cn=true]


I told her the story as it was. Then Mom said
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Sawa252"]
[OnName num="sawa"]
“I think you should date her. I won't stop you."
[cpg cn=true]


[OnName num="gorou"]
“Why ...... I like you mom.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Sawa253"]
[OnName num="sawa"]
“I know that. But I can never be your girlfriend."
[cpg cn=true]


...... that may indeed be the case.
[cpg]


I don't know what would happen with dad if that were to happen.
[cpg]


Mom loves dad too.
[cpg]


[OnName num="gorou"]
“...... Okay. I'll think about it."
[cpg cn=true]



;//ブラックアウト

;//移植前シーンカット


[window target=false]

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[BGM f="bg_d1"]

;//【ＢＧ】『街』（朝）******************************************************


Then I held off on responding to the girl who confessed her feelings to me at school.
[cpg]


We decided to start as friends, so we are less than lovers.
[cpg]


She seemed to really like me and seemed to be frustrated.
[cpg]


But I was me, and I never lost my love for mom .
[cpg]


I didn't feel like I could properly love the girl who just confessed her love to me.
[cpg]



;//ブラックアウト



;//========================================
;//●ＣＧ（主人公に膝枕するヒロイン）ev_44
;//人物１：ヒロイン３
;//服装１：私服
;//場所　：主人公の家＿リビング
;//時間　：昼
;//備考　：妊娠していない状態に変えてください
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[STOPBGM]
[WAIT time=1000]

[SE f="se004"]
;//【ＳＥ】『衣擦れ』


[BGM f="bg_h1"]
;**【ＣＧ】 ev_44_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]



I was happy despite spending such ambiguous days.
[cpg]


No matter what kind of life I lead, mom will support me.
[cpg]


I felt like that was all I needed. I am satisfied
[cpg]


[VOICE f="sSawa058"]
[OnName num="sawa"]
“Do you regret it......? Goro "
[cpg cn=true]


But I guess I looked a little lost. Mom is worried.
[cpg]


[OnName num="gorou"]
“No way. No……”
[cpg cn=true]


The words came naturally. I guess it's because I really meant it.
[cpg]


It wasn't just talk. I had absolutely no regrets.
[cpg]


;**【ＣＧ】 ev_44_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sSawa059"]
[OnName num="sawa"]
“I don't care who you fall in love with. You fell in love with me to calm your condition, and that's all that matters.”
[cpg cn=true]


She said something that makes me a little sad. I can't go back now.
[cpg]


[OnName num="gorou"]
“No that’s not the case. I've really fallen in love with you, and my condition has settled down.”
[cpg cn=true]


The fact that my condition had settled proved that I liked mom.
[cpg]


After making sure that neither Suzune nor Himari nor dad were there, I said.
[cpg]


[OnName num="gorou"]
"...... l love you. Sawa "
[cpg cn=true]


I called her by her name abruptly, but Mom was not dismayed.
[cpg]


;//;**【ＣＧ】 ev_44_b ***********************
;//[CG id=18 index=2 time=1000]
;//;***************************************
;//[WAIT time=1000]


[VOICE f="sSawa060"]
[OnName num="sawa"]
“Me too."
[cpg cn=true]


I had longed for this kind of a relationship. I want to be next to her all the time.
[cpg]



;//ブラックアウト

I wish it could last forever, but I don't know if that will ever happen.
[cpg]


Maybe my position will change with time, and if I become a working adult, I will want to start a family.
[cpg]


But ...... right now, I'm not ready for that. Because I want to remain mom’s child.
[cpg]


[SCENE id=11]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=800]
[WAIT time=800]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：ヒロイン３ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================
