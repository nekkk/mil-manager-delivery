
;//１、ギャルのままで良い

*start


;#################################################
*Ep004|Accepting Things as They Are
;#################################################


[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]

*select05_1|Accepting Things as They Are

[SCENE id=4]


[OnName num="youta"]
”Just be……a gal. Sorry, for asking a weird question."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
Michi looked relieved. Then.
[cpg]

[FACE method="change_2" pos="2/3"]
“I see," she said and laughed. She was relieved.
[cpg]


The way she looked was her own choice. I have to accept it as it is.
[cpg]


It's not that I don't like it either.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





On the way home, I ran into Mayuki. 
[cpg]


It's not that I didn't want to see her.......
[cpg]


I had a feeling she might say something. We were still holding arms.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Mayuki251"]
[OnName num="mayuki"]
"Oh, you guys are such a cliche couple. You look happy."
[cpg cn=true]


I guess it was her way of congratulating me. I could understand that.
[cpg]


[OnName num="youta"]
“We shouldn’t be called a couple, even though we are...... A couple.”
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
Michi looked a little embarrassed when she heard that.
[cpg]


And then Mayuki says ……
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mayuki252"]
[OnName num="mayuki"]
“That's nice. You’re both so cute and fresh.”
[cpg cn=true]


Cute? Is there such a thing?
[cpg]


We were troubled for being called cute.
[cpg]


Is Mayuki a master of romance? That seems likely. ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Mayuki253"]
[OnName num="mayuki"]
“So, Michi is still a gal. Maybe that's a little surprising.”
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
We were just talking about that right now.
[cpg]


[OnName num="youta"]
"Oh, if that's what you mean ...... no."
[cpg cn=true]


But I didn't say so. I told Mayuki that we would remain as we are.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mayuki254"]
[OnName num="mayuki"]
“Well, I wish you all the best.”
[cpg cn=true]


Mayuki left, waving her hand.
[cpg]


She's a girl of her own pace. She just kept on stirring up our hearts.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』





The next morning. I head to school.
[cpg]


I can see Michi again today. Soaking in that happiness. ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





Michi's caring nature is as usual.
[cpg]


These days she rarely brings me lunch anymore.
[cpg]


I also wonder what the rest of it is. ...... I've been relying on Michi more and more about my studies.
[cpg]


She was more than happy to be depended on.
[cpg]


She also helps me with my studies more often. Today, too, we were talking about having a study session in Michi's room.
[cpg]


[OnName num="youta"]
“I'll see you soon.”
[cpg cn=true]


I said and turned to Michi when I saw that girl behind her.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Natuko232"]
[OnName num="natuko"]
"You two look like you are getting along so well. Both of you."
[cpg cn=true]


Natsuko. I can't say she has nothing to do with us.
[cpg]


[OnName num="youta"]
“Oh, Natsuko,......."
[cpg cn=true]


I turn to face her, feeling a little awkward.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Michi309"]
[OnName num="michi"]
“I'm sorry, but I can't give you my Yota. Haha.”
[cpg cn=true]


She said, and Natsuko laughed as well.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="Natuko233"]
[OnName num="natuko"]
I know, I know. I've given up.
[cpg cn=true]


Her smile was a little sad. But it can’t be helped.
[cpg]


There was no future for me here with Natsuko.
[cpg]


I never imagined that I would break up with Michi or anything like that.
[cpg]


Come to think of it, I haven't been to the library for a long time, which was a like a home to Natsuko.
[cpg]


I was feeling a little sorry for her, thinking that I no longer had any reason to go there,.......
[cpg]


[OnName num="youta"]
"...... I'm sorry, Natsuko"
[cpg cn=true]

[FACE method="change_7" pos="2/2"]
I said so, but she only replied, "What are you talking about?”.
[cpg]


That's right. Natsuko had already given up.
[cpg]


I will love Michi single-mindedly. That's what I've decided, so I can't help it.
[cpg]


And even more than that, Michi loves me single-mindedly.
[cpg]


I want to be loved by the caring Michi forever.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『メインヒロインの部屋』（夕方）******************************************************



[SE f="se011"]
;//【ＳＥ】『ドア開く』





We came to Michi's room for a study session. We are about the same in terms of our study skills.
[cpg]


However, this study session was meaningful.
[cpg]


I am weak in memorization. She was weak in logical thinking.
[cpg]


So even though our grades were about the same, we had something to compensate for.
[cpg]




;//移植のためシーンをカットしています

;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『メインヒロインの部屋』（夕方）******************************************************




[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
Our study group continued after that, but we had already changed the nature of the group.
[cpg]

It was more of a love study. I don't think my grades in health and physical education are going to improve.
[cpg]

I ask Michi, who comes closer to me than necessary.
[cpg]


[OnName num="youta"]
“..... this makes it hard for me to concentrate on my studies.”
[cpg cn=true]

[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
Michi says, "That's right," while smiling.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sMichi039"]
[OnName num="michi"]
"I'm sorry, I just couldn't resist.……"
[cpg cn=true]

Michi apologized honestly. It was a somewhat surprising response.
[cpg]

I'm not too pushy by any means. My image of the gal is changing.
[cpg]

I had a feeling that Michi was still Michi after all.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





We decided to end the session before the sun went down. 
[cpg]


Even though it was a study group, I don't think it was very efficient to slack off too much.
[cpg]


Although, we were barely studying.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi341"]
[OnName num="michi"]
“Anyways. I’ll see you tomorrow."
[cpg cn=true]


I waved my hand as Michi said that.
[cpg]


[OnName num="youta"]
“See you tomorrow".
[cpg cn=true]


After exchanging such conversation, I returned to my house.
[cpg]


I was happy. I know that she loves me, and I know that I love her.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





She's a very predatory gal, but she's devoted to me and she takes care of me.
[cpg]


There is a gap. Usually, girls like this are unfaithful.
[cpg]


Before that, I thought she would grow up to be more innocent.
[cpg]


But somehow, I was getting used to her being like this. Or rather, I was beginning to think that she was the prettiest girl I had ever seen.
[cpg]


It was probably not a good idea for me to force her to change.
[cpg]


At that time, I was glad I didn't ask her to stop being a gal.
[cpg]


I'd rather love her for who she is, than to make her into someone I want her to be
[cpg]


What a surprise. I thought about it, it's not good that I'm a normal guy.
[cpg]


Because we don't fit together as a couple. ......
[cpg]


I'm not a flirt at all. That's what I was thinking.
[cpg]


I don't intend to be a punk type of guy, but I do want to be a man who can match up to Michi.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





In the meantime, morning came again.
[cpg]


I thought I had just gone to bed, but it was already morning.
[cpg]


The days are so fast-paced that I feel like I'm going to lose control.
[cpg]


It is said that happy times pass quickly. I guess that's what it means.
[cpg]


And I thought, "Summer will soon be here. ......
[cpg]


[OnName num="youta"]
"Well, what are we going to do ......?"
[cpg cn=true]


The first thing that comes to my mind is that I want to be a man who will compliment her exterior.
[cpg]


I headed to the school while thinking about that.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayuki255"]
[OnName num="mayuki"]
“Hmmm. I didn't know you cared about that.”
[cpg cn=true]


I asked Mayuki about it, but she responded in a rather random way.
[cpg]


[OnName num="youta"]
“You are barely listening……it’s a serious concern."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayuki256"]
[OnName num="mayuki"]
“I don't think you need to worry about it. If you want to change, you will change, otherwise you will stay the same.”
[cpg cn=true]


But apparently that reply was not appropriate.
[cpg]


I was surprised by Mayuki saying something quite honest.
[cpg]


If I think it's surprising, I shouldn’t be talking to her about it in the first place……
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki257"]
[OnName num="mayuki"]
“I'm sure Michi will say she likes you no matter what you look like.”
[cpg cn=true]


She has a point. But is that okay?
[cpg]


[OnName num="youta"]
“But ……what if I become the reason for Michi being made fun of by her gal pals and such.”
[cpg cn=true]


It's a really silly concern. She is not the type of person to brag about her boyfriend.
[cpg]


I knew it was impossible, but I was worried about it.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayuki258"]
[OnName num="mayuki"]
“Hmm. I think that for you to accept the gal Michi, made you reach your goal.”
[cpg cn=true]


For a moment, I didn't understand what Mayuki was talking about.
[cpg]


But after thinking about it for a while, I understood. I was imagining a neat and tidy Michi.
[cpg]


[OnName num="youta"]
“….. is that so?”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki259"]
[OnName num="mayuki"]
“Yea. There's a possibility that you'll be shocked and fall out of love with her.”
[cpg cn=true]


Maybe. Then, my current worries might be trivial.
[cpg]


My love didn't cool down. That may be all that matters.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



During the lunch break, Michi pulled me to a place where there were no people around.
[cpg]


[OnName num="youta"]
"Hey, don't pull me."
[cpg cn=true]


"It's okay.” She says and she leads me away.
[cpg]


[OnName num="youta"]
"It hurts. ...... at least just pull on my clothes.”
[cpg cn=true]


I thought she was as forceful as ever,......but I didn't mind being pushed around.
[cpg]


;//移植のためシーンをカットしています



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************



[OnName num="youta"]
“You’re pretty bold Michi.”
[cpg cn=true]


Is that so? Michi replies. She doesn't seem to be aware of it.
[cpg]


I think she's got a lot of guts, and I'm the one who's in on it.
[cpg]


And then I check the situation again.
[cpg]


An empty classroom. But that doesn't mean I can do anything.
[cpg]


[OnName num="youta"]
“There's no guarantee that no one will come ......."
[cpg cn=true]


I reminded Michi.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sMichi040"]
[OnName num="michi"]
"It's okay. It's okay if we just want to kiss.”
[cpg cn=true]


She responded. If she says so, well, it's fine......
[cpg]


[OnName num="youta"]
“I guess, only a little though……."
[cpg cn=true]


Michi says yes and smiles.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています


Michi is insatiably greedy for love.
[cpg]


I was skipping class while being with her.
[cpg]


[OnName num="youta"]
"......I think it's time for you to go to class."
[cpg cn=true]


Michi nodded. We went back to the classroom.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





And after school, Mayuki was messing with us.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/2" time=800]

Although, it was more like she was just coming up to talk to us.
[cpg]


[VOICE f="Mayuki260"]
[OnName num="mayuki"]
“The two of you, what are you doing? Well, I don't have to ask, do I?”
[cpg cn=true]


[OnName num="youta"]
“Whatever."
[cpg cn=true]


I was a little embarrassed, but it seems that Michi had something completely different in mind.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="sMichi041"]
[OnName num="michi"]
“Hey Yota, I have a little proposition for you.”
[cpg cn=true]


I wondered what she was going to say, so I asked,
[cpg]


[OnName num="youta"]
“Are you up to something?”
[cpg cn=true]


She looked like she was planning something. I didn't need to ask her, but I did.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="sMichi042"]
[OnName num="michi"]
“Mayuki, would you like to go on a date with us?”
[cpg cn=true]


For a moment, I didn't understand what she was saying.
[cpg]


I struggled to understand it after that. Was she really, really, really serious?
[cpg]


[OnName num="youta"]
“No,......, it would be bad for Mayuki.”
[cpg cn=true]


Mayuki crossed her arms while saying that.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Mayuki261"]
[OnName num="mayuki"]
”Only if Yota is okay with it. You're in the mood for it, aren't you, Michi?"
[cpg cn=true]


Michi nods. I didn’t think that she would answer so quickly.
[cpg]


I was lost. Is it right to do such a thing?
[cpg]


I mean, she's my girlfriend. We are not friends or anything.
[cpg]


I have already accepted that Michi is a gal.
[cpg]


So, if I want to accept this proposal, I can .....
[cpg]


[OnName num="youta"]
“No, wait, ...... let me think about it for a minute."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/2" time=800]
[VOICE f="sMayuki032"]
[OnName num="mayuki"]
“I'll tell you what, if you call it a date, I'll be up for it too. You just have to understand that."
[cpg cn=true]


I couldn't help but say nothing as I received Michi's expectant look.
[cpg]


She really wants for the three of us to go out.
[cpg]


This is not cheating. I think...... maybe.
[cpg]


[OnName num="youta"]
“I'm fine with it too,......as long as it's good enough for Michi and Mayuki."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Michi375"]
[OnName num="michi"]
“Then, it's decided. On our next day off, the three of us will go karaoke together.”
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



So, on a holiday, we went to karaoke.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『カラオケ店個室内』（昼）******************************************************





[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="sMayuki033"]
[OnName num="mayuki"]
“The three of us being together is kind of weird.”
[cpg cn=true]


When we arrived at the karaoke bar, Mayuki said something like that.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="sMichi043"]
[OnName num="michi"]
“Really? I feel more at ease than usual.”
[cpg cn=true]


Michi was saying something strange as well. These two, after all, are ......
[cpg]

[FACE method="change_6" pos="2/2"]
[VOICE f="sMayuki034"]
[OnName num="mayuki"]
“I think you’re cute too Michi.”
[cpg cn=true]


Listening to the exchange made me wonder if these two are just friends...
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

The three of us went on a karaoke date. The date is a healthy one, and this seems to cause no problems.
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『カラオケ店個室内』（昼）******************************************************

[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

And while we were singing, Michi started flirting with Mayuki rather than me.
[cpg]

Mayuki seemed to be quite into it. I wonder if they were dating after all. ......
[cpg]

[OnName num="youta"]
“…… I'm curious."
[cpg cn=true]


“What?”, Michi asks. What a blunt reply.
[cpg]


Are the two of you just friends? It seems like you’ve known each other for quite a while.
[cpg]


It's not surprising if they've done that kind of thing before this time...... I'm getting a nosebleed when I imagine it.
[cpg]


[OnName num="youta"]
"Were you guys dating or something?"
[cpg cn=true]


I asked boldly. The two looked at each other.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="sMayuki035"]
[OnName num="mayuki"]
“We're best friends, but ...... what do you think about that, Michi?"
[cpg cn=true]

Michi only laughed. But even so, it doesn't mean that she loves Mayuki more than me.
[cpg]


If so, it may only be a minor issue.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ（サブヒロインの背後からくすぐるメインヒロイン）ev_36
;//人物１：メインヒロイン
;//服装１：私服
;//人物２：サブヒロイン１
;//服装２：私服
;//人物３：主人公
;//服装３：制服
;//場所　：カラオケ店個室内
;//時間　：昼
;//========================================


[BGM f="bg_h2"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sMichi044"]
[OnName num="michi"]
“I love you so much that I'm going to do this to you.”
[cpg cn=true]


Then, Michi moves behind Mayuki.
[cpg]

I was wondering what she was going to do, and I was hoping that she wouldn’t do anything crazy.
[cpg]

[VOICE f="sMayuki036"]
[OnName num="mayuki"]
"Hey, stop ...... tickling me!"
[cpg cn=true]


She started tickling Mayuki. Michi has a devilish look on her face.
[cpg]

It's as if I can’t look at her directly.
[cpg]

I was thinking that this was part of the role, but I didn't say too much.
[cpg]

[VOICE f="sMichi045"]
[OnName num="michi"]
"Here, tickle, tickle, tickle."
[cpg cn=true]


Michi said and continued to tickle her. Mayuki's expression began to fall.
[cpg]


;**【ＣＧ】 ev_36_a ***********************
[CG id=15 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMayuki037"]
[OnName num="mayuki"]
“Don't do that, ha ha ha ……”
[cpg cn=true]


Michi is quite enthusiastic about it. I can see that she is harboring extraordinary feelings.
[cpg]

At the same time I sensed this, I knew she was also receiving jealousy from Mayuki.
[cpg]

So I don't know what to do, but I feel a little sorry.
[cpg]

[VOICE f="sMichi046"]
[OnName num="michi"]
“Mayuki, have you gained some weight?"
[cpg cn=true]


[VOICE f="sMayuki038"]
[OnName num="mayuki"]
“Hey don’t go there ......!"
[cpg cn=true]


Still, I never thought that I, as a man, would be able to witness such a scene.
[cpg]

[VOICE f="sMichi047"]
[OnName num="michi"]
“Look, Yota is watching you.”
[cpg cn=true]


;**【ＣＧ】 ev_36_b ***********************
[CG id=15 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMayuki039"]
[OnName num="mayuki"]
Don't ...... look at me.”
[cpg cn=true]


Mayuki looked embarrassed, but I probably had that same look on my face too.
[cpg]

What is the right reaction to be shown in such a place?
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





;//[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Mayuki289"]
[OnName num="mayuki"]
“Oh ...... I feel terrible.”
[cpg cn=true]


And so we left the karaoke bar.
[cpg]

Thinking I had been shown a good thing, I also wondered where we were headed.
[cpg]


It wasn't a mental thing, but I really don't know which direction we are going.
[cpg]


Me and Mayuki are following Michi, but I don't know where we're going: ......
[cpg]


[OnName num="youta"]
“Michi. Where are we going?”
[cpg cn=true]


I asked her, and finally she answered.
[cpg]


;//[free time=1000]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/2" time=800]
[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="1/2" time=800]

[VOICE f="sMichi048"]
[OnName num="michi"]
“I'm going to my room this time. I think my sister might be there, but unlike karaoke, there are no surveillance cameras.”
[cpg cn=true]


[OnName num="youta"]
"I see."
[cpg cn=true]


I replied vaguely. Rather than the surveillance camera……
[cpg]


I'm more caught up in the "your sister might be there" part.
[cpg]


However, if Michi is sure it will be okay, we have no choice but to go along with it.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『メインヒロインの部屋』（夕方）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayuki290"]
[OnName num="mayuki"]
“Wow. Michi's room looks tidier than before.”
[cpg cn=true]


“Well, it is.”, says Michi. Is that so?
[cpg]


I mean, the room I know of has always been this way.
[cpg]


I know her room has been like this since the first time I visited……
[cpg]


I wonder if she cleaned up her room with me in mind.
[cpg]

[free time=1000]
If so, I'm a little happy. I'm still thinking about it. ......
[cpg]

;//ブラックアウト

;//移植のためシーンをカットしています

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

The date with the three of us continued for a while.
[cpg]


The question of whether I could be a man worthy of Michi, which I had been thinking about a while ago, was still unanswered.
[cpg]


Unsuitable couples remain unsuitable couples. Without any resolution, we continue to date.
[cpg]


I wondered ...... if this was okay, but my taste in clothes and other things seemed to be changing little by little.
[cpg]


The reason is that this person pointed out to me.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（昼）******************************************************




[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Natuko234"]
[OnName num="natuko"]
"Oh, ...... both of you. Hello."
[cpg cn=true]


[OnName num="youta"]
“Oh ...... hello."
[cpg cn=true]


One day on a date. I was walking with Michi, and Natsuko found us.
[cpg]


I don't know if we were doing anything so sinister as to be discovered.
[cpg]


Michi also said hello. Natsuko was not jealous of me.
[cpg]


Anyway, here is what Natsuko said to me: ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Natuko235"]
[OnName num="natuko"]
“......Yota, have you become a bit more flirtatious?"
[cpg cn=true]


I couldn't believe my ears.
[cpg]


[OnName num="youta"]
“Huh?"
[cpg cn=true]


I said unintentionally. Did I become flirtatious?
[cpg]


I'm not even aware of that, I thought ......
[cpg]


On second thought, maybe you're right. While I was dating Michi, I started shopping for clothes with her.
[cpg]


This means that while I was choosing clothes, Michi was around me more often.
[cpg]


This means that it should be natural if I also became more flirtatious.
[cpg]


[OnName num="youta"]
“I didn't notice until you told me. ...... I guess.”
[cpg cn=true]


Natsuko nodded. Then she adds this.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Natuko236"]
[OnName num="natuko"]
“At first I wondered if ...... the serious-looking Yota and the girly-looking Michi would make a good couple.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Natuko237"]
[OnName num="natuko"]
“But now it looks like I don't have to worry anymore. You seem to be a perfect match for each other.”
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_5"  pos="1/2" time=800]
Michi and her well-matched boyfriend. Is it really true?
[cpg]


Am I like that? I thought that was so far from me.
[cpg]


We looked at each other, thinking that it was not like that.
[cpg]


It seems that Michi was not aware of this either.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Natuko238"]
[OnName num="natuko"]
“I wish you good luck. I have some business to attend to at the bookstore.”
[cpg cn=true]


And with that, Natsuko left.
[cpg]


I wanted to ask her a few more questions, but I guess I got the information that I wanted to hear…….
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





And we were off on our karaoke date, as is our custom.
[cpg]


[OnName num="youta"]
“You really like karaoke, don't you?"
[cpg cn=true]


I was beginning to like it, too.
[cpg]



;//========================================
;//●ＣＧ（マイクを持ったままデュエットしようとくっついてくるメインヒロイン）ev_38
;//人物１：メインヒロイン
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：カラオケ店個室内
;//時間　：夕方
;//========================================



[BGM f="bg_op"]
;**【ＣＧ】 ev_38_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]






[VOICE f="Michi399"]
[OnName num="michi"]
“Let's sing, Yota, you know this song, don't you?”
[cpg cn=true]


Michi started to sing a song I didn't know.
[cpg]


I don't know the lyrics of the song. Or maybe I have heard it before……..
[cpg]


I try to match the lyrics in a way that I don't understand.
[cpg]


It still doesn't fit. I can't remember the rest of the song except the chorus.
[cpg]



[VOICE f="Michi400"]
[OnName num="michi"]
"You don't know it. If you're my boyfriend, you should at least know this.”
[cpg cn=true]


[OnName num="youta"]
“I'm sorry. I don't know anything about the latest trends.”
[cpg cn=true]


We had a good time together.
[cpg]


There was nothing to worry about. I felt like our future was open.
[cpg]


Then, in a quiet voice, Michi said,
[cpg]



[VOICE f="Michi401"]
[OnName num="michi"]
“……About what Natsuko said to me earlier..."
[cpg cn=true]


What Natsuko said. It must be about what she said earlier.
[cpg]


[OnName num="youta"]
“Oh. What about it?"
[cpg cn=true]



[VOICE f="Michi402"]
[OnName num="michi"]
“I see that you have changed too. To suit me.”
[cpg cn=true]


[OnName num="youta"]
“It may be an exaggeration to say that I have ...... changed, but..."
[cpg cn=true]


In response to me saying this, Michi continues to speak.
[cpg]


And finally, she concluded.
[cpg]



[VOICE f="Michi403"]
[OnName num="michi"]
“I was about to give up on the idea of us being a good match for each other,……therefore I’m happy.”
[cpg cn=true]


What was she saying……..
[cpg]


I ended up having to hear those words. I think I was blushing with embarrassment.
[cpg]


But that's how couples are, right? You get to know each other and come to terms with what you don't know about each other.
[cpg]


Even if my childhood friend who I haven't seen in a while has changed, I don't think the core will change.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I want her to know more about me and I want to know more about Michi.
[cpg]


[SCENE id=8]

[WAIT time=500]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：メインヒロインルート１



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



;//==============================
