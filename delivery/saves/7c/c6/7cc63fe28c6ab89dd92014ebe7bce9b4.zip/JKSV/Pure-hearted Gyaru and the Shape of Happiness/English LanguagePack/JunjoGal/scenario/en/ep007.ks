
;//２、南都子

*start


;#################################################
*Ep007|Natsuko the Ideal Girl
;#################################################

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=1000]


*select03_2|Natsuko the Ideal Girl

[SCENE id=7]

In my mind, I was picturing Natsuko's face.
[cpg]


She is the ideal of what Michi would have looked like if she had grown up normally.
[cpg]


Of course she is not Michi. But ......
[cpg]


She's ideal. Maybe Natsuko is the image of the woman I was looking for.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』





The next morning, I had made up my mind.
[cpg]


I would end this half-hearted relationship. I would go out with Natsuko, not Mayuki or Michi.
[cpg]


When I made that decision, I felt my vision getting clear.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko077"]
[OnName num="natuko"]
“Good morning, Yota.”
[cpg cn=true]


[OnName num="youta"]
"Oh, good morning."
[cpg cn=true]


I would never confess my feelings at this point.
[cpg]


I will definitely find the right time. I'm sure there's a thing called an atmosphere.
[cpg]


[OnName num="youta"]
“Do you have ...... time after school today?”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuko078"]
[OnName num="natuko"]
"Sure. Shall we do something else?”
[cpg cn=true]


[OnName num="youta"]
“It's not about that. I'm talking about something more important.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Natuko079"]
[OnName num="natuko"]
“Okay....... I'll wait for you.”
[cpg cn=true]


Natsuko's face turns red. She’s anticipating it. And her expectations were correct…..
[cpg]


I'm going to say something that is expected of me, too.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（夕方）******************************************************





In the evening. The classroom after school when no one is there.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko080"]
[OnName num="natuko"]
"So ...... what did you call me here for?"
[cpg cn=true]


[OnName num="youta"]
"...... our relationship isn't really about going out, is it?"
[cpg cn=true]


[OnName num="youta"]
“I don’t want this to be with my foot in only half way. I haven't decided how I'm going take action...... towards Michi or Mayuki.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Natuko081"]
[OnName num="natuko"]
"...... In that case ……"
[cpg cn=true]


[OnName num="youta"]
“Let’s go out. I like you, Natsuko."
[cpg cn=true]


Natsuko looked really happy. And then she says this.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko082"]
[OnName num="natuko"]
“I'm glad we can be even closer from now on”
[cpg cn=true]



;//ここから洋太は南都子を南都子と呼びます



[OnName num="youta"]
“.... You’re right, Natsuko."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//それから少し日々が過ぎて、休日の昼間。
Then a few days passed, after school.
[cpg]


My parents conveniently went out, so I invited Natsuko to my home.
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（昼）
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuko085"]
[OnName num="natuko"]
“I am nervous....... This room smells like you."
[cpg cn=true]


[OnName num="youta"]
"Really ……? I don't smell anything.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko086"]
[OnName num="natuko"]
“So ...... really, are you sure you want to be with me?”
[cpg cn=true]


I guess she was trying to be modest at this point .......
[cpg]


It was a bit of a surprise. She had been so aggressive up until now.
[cpg]


[OnName num="youta"]
;//「南都子が好きだ。何回も言わせるなよ」
“I like you Natsuko. I'll say it as many times as I have to."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ（ベッドに横たわるヒロイン。キスをする）ev_17
;//人物１：サブヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================



[BGM f="bg_h2"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]


I put my lips to hers as I waited for her to kiss me.
[cpg]

[VOICE f="sNatuko010"]
[OnName num="natuko"]
“Hmm……..”
[cpg cn=true]


I feel Natsuko’s presence right next to me. Closer than anyone else. ......
[cpg]

I realized once again that I really like her after all.
[cpg]

The lover I had always envisioned.
[cpg]

Even if the image was originally inspired by Michi, Natsuko was the ideal lover.
[cpg]

I guess it wasn’t the most moral thing to think about this stuff.
[cpg]

But I do like her because she is Natsuko.
[cpg]

I can't put it into words well, but I couldn't suppress my feelings.
[cpg]

[OnName num="youta"]
“You’re beautiful”
[cpg cn=true]


[VOICE f="sNatuko011"]
[OnName num="natuko"]
“……Yota."
[cpg cn=true]


She looked at me and called my name enthusiastically.
[cpg]

Seeing her like that made me love her even more.
[cpg]


;**【ＣＧ】 ev_17_a ***********************
[CG id=11 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNatuko012"]
[OnName num="natuko"]
“I wonder if I’m allowed to be so happy."
[cpg cn=true]


She said so with a happy expression.
[cpg]

[OnName num="youta"]
"Of course, there's no limit to happiness, is there?”
[cpg cn=true]


I was trying my best to contain myself after seeing her pretty face.
[cpg]

I was ready to do anything for Natsuko, but I still held back.
[cpg]

[VOICE f="sNatuko013"]
[OnName num="natuko"]
“I'm happy. I want to know more about you Yota.”
[cpg cn=true]


She says this and closes her eyes again.
[cpg]

I read the intent in her expression and decided to kiss her again.
[cpg]

The calm time continues for a long time. I want to feel this kind of time forever......
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（昼）
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



We stayed in my room and talked for a while.
[cpg]


Since the two of us were together, we couldn’t just keep silent.
[cpg]


And then Natsuko brought up another subject.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuko106"]
[OnName num="natuko"]
“Are you sure about ...... Michi?”
[cpg cn=true]


[OnName num="youta"]
“She has ...... changed.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko107"]
[OnName num="natuko"]
“Then what will you do if Michi goes back to before?”
[cpg cn=true]


[OnName num="youta"]
“That's ......"
[cpg cn=true]


I can't answer that. Natsuko also asks an unfair question.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Natuko108"]
[OnName num="natuko"]
“It's okay. I think that part of you is kind of cute.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko109"]
[OnName num="natuko"]
“I will go with whatever you decide, Yota”
[cpg cn=true]


Natsuko said.
[cpg]


I didn't know what she meant at the time. ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************




;//そして、夕方になる。流石にもう帰らないとという時間になり、俺は南都子を帰すことにした。
And then, as expected, it was time, so I decided to let Natsuko go home.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Natuko110"]
[OnName num="natuko"]
“See you at school."
[cpg cn=true]


There is a sense of betrayal toward Michi. But I was undeniably happy now.
[cpg]


I was no longer lost. Someday I will have to tell Michi everything.
[cpg]


It may take me some time to find the courage to do so, but I still love Natsuko.
[cpg]



;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


The next weekday, Monday, I met Natsuko in the library.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園図書室』（昼）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Natuko111"]
[OnName num="natuko"]
“It’s like we really are lovers.”, she chuckled.
[cpg cn=true]


The library was almost empty. It was as if we were having a secret meeting.
[cpg]


[OnName num="youta"]
“That’s because we are.”
[cpg cn=true]


I told her. Natsuko smiled.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Natuko112"]
[OnName num="natuko"]
“Then it's natural for us to do this, isn't it?”
[cpg cn=true]



Natsuko then held my hand.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="sNatuko014"]
[OnName num="natuko"]
She chuckled again.
[cpg cn=true]


Natsuko is after all, bold by nature.
[cpg]


Despite her neat and tidy appearance, she also has another side of her......
[cpg]


Or am I too naive.
[cpg]


;//移植のためシーンをカットしています



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（夕方）******************************************************



The next morning, back at school. I feel a little reluctant to go.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki243"]
[OnName num="mayuki"]
"I've heard that you and Natsuko have been getting along well lately. Are you two dating?”
[cpg cn=true]


Mayuki asked. Michi and Natsuko were not in the room.
[cpg]


So I decided to answer honestly.
[cpg]


[OnName num="youta"]
“Yea….I’m going out with Natsuko.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayuki244"]
[OnName num="mayuki"]
“I see. I thought I might have a chance too, but alas.”
[cpg cn=true]


[OnName num="youta"]
“I'm sorry ....... For leading you on.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki245"]
[OnName num="mayuki"]
“It’s okay. What would Michi think of that?"
[cpg cn=true]


That's the part I dared not to worry about.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[STOPBGM]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





I've decided who I like. Or rather, I know who I like.
[cpg]


So I think it will turn out the way it will. Is this idea too optimistic?
[cpg]


I'm sure I'm not in a state that I can't even face Michi. ......
[cpg]




[window target=false]
[BG f="b_03_1.ui" time=1500]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（朝）******************************************************





The next morning, at school again. I walked briskly.
[cpg]


I was genuinely happy to see Natsuko.
[cpg]


There are still some unresolved things with Michi, but that is that.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi159"]
[OnName num="michi"]
“......We don't have much time to talk alone these days, do we?”
[cpg cn=true]


[OnName num="youta"]
“I guess so. I often have to run some errands......."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi160"]
[OnName num="michi"]
"You seem to go to the library a lot, are you meeting someone ......?"
[cpg cn=true]


It is not like her mind is sharp or anything. It is natural to think so.
[cpg]


[OnName num="youta"]
“There is nothing to worry about. If you're interested, you can come.”
[cpg cn=true]


I took a little gamble. But Michi didn't take me up on it.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=1000]
;//【ＢＧ】『学園図書室』（昼）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko133"]
[OnName num="natuko"]
“Oh. Yota”
[cpg cn=true]


[OnName num="youta"]
“You're always reading books. Do you like it that much?”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Natuko134"]
[OnName num="natuko"]
“I don't like it as much as I like you. If you tell me to stop, I will stop.”
[cpg cn=true]


[OnName num="youta"]
“I didn't say that……"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko135"]
[OnName num="natuko"]
“I'm just saying that I'm not like Michi. If someone told me to stop dressing like a gal, I would stop."
[cpg cn=true]


...... Come to think of it, I never told Michi to stop.
[cpg]


I wonder if I could have said it once,......but it's too late now.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//移植のためシーンをカットしています

;//ブラックアウト

In the corner of the library, she asked me to kiss her again.
[cpg]

[OnName num="youta"]
“What if someone ...... finds out?"
[cpg cn=true]



[VOICE f="Natuko155"]
[OnName num="natuko"]
“Once is the same as twice. Please, let's kiss……”
[cpg cn=true]


I can't seem to turn her down. I don't have a choice. ......
[cpg]


[OnName num="youta"]
"...... Okay.”
[cpg cn=true]


Natsuko's eyes are shining. It's already time for class.
[cpg]


Natsuko isn't always serious.
[cpg]


I've learned a lot about her already, but she's quite interested in romance.
[cpg]


I think she's cute like that, ...... but then again, isn't she too interested perhaps
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


As we left the library.
[cpg]

I was looking around. Making sure no one was there, and I figured if anyone had seen me, they would have left the place.
[cpg]



That was true, but it didn't turn out too well.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMichi014"]
[OnName num="michi"]
"......You know, Yota, about the library….…”
[cpg cn=true]


When she said that to me, I got nervous. I thought that she had seen us.
[cpg]


[OnName num="youta"]
"Were you watching me, ......?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMichi015"]
[OnName num="michi"]
“Yea, I saw it. Her name is Natsuko right?…….”
[cpg cn=true]


I had nothing to say in my defense. It's true that I betrayed Michi. ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Michi163"]
[OnName num="michi"]
"...... Do you not like me because I am a gal? Natsuko seems so innocent."
[cpg cn=true]


Michi said so in a tearful voice. I couldn't reply anything.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（朝）******************************************************





Days passed. Michi seemed to be in a state of depression.
[cpg]


I can't feel guilty about this. I have to be happy with Natsuko.
[cpg]


I would feel bad for Natsuko if I was dragged down by Michi's feelings.
[cpg]


So, I won't say anything ...... and keep dating her.
[cpg]




[STOPBGM]
[window target=false]
[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（夕方）******************************************************





Natsuko is a kind girl. She seemed to know everything that was going on in my mind.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuko177"]
[OnName num="natuko"]
“Are you concerned about ...... Michi?”
[cpg cn=true]


[OnName num="youta"]
“I can't ...... say that."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Natuko178"]
[OnName num="natuko"]
“I don’t mind. I don't like it when people hide things from me.”
[cpg cn=true]


[OnName num="youta"]
"...... I see."
[cpg cn=true]


It's useless to hide it. But….
[cpg]


[OnName num="youta"]
“I'm interested in Michi, but I like you Natsuko.”
[cpg cn=true]


I answered. There was no hesitation in that feeling.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（朝）******************************************************





Then one Monday, the first day of the week.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Mayuki246"]
[OnName num="mayuki"]
"What happened? Did you hit your head somewhere, Michi?”
[cpg cn=true]



;//ここから美智の立ち絵を切り替えてください
;//[free time=800]

;//[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="1/2" time=800]
[WAIT time=500]
[VOICE f="Michi164"]
[OnName num="michi"]
"I didn't hit my head  ....... But, I think I hit my pinky toe the other day.”
[cpg cn=true]


As is her nature, Michi commuted to school in neat and tidy attire.
[cpg]


She’s stopped dressing like a gal. It's as if she’s like Natsuko……
[cpg]


I was heartbroken. It's my fault that she's in this mess.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園図書室』（昼）******************************************************





Michi is thinking about me and stopped being a gal.
[cpg]


I was still concerned about her.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko179"]
[OnName num="natuko"]
"Michi has changed, hasn't she? She's like me."
[cpg cn=true]


[OnName num="youta"]
"Do you think so too, Natsuko......?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuko180"]
[OnName num="natuko"]
“Yota, it's not like you don't think anything of it, right?”
[cpg cn=true]


[OnName num="youta"]
“It's that ……"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko181"]
[OnName num="natuko"]
“It’s fine. I think it will be better if you tell me everything.”
[cpg cn=true]


I was at a loss for a response. But it's certainly not a good idea to hide things from your lover.
[cpg]


When it comes to girls……
[cpg]


There is a possibility that both Natsuko and Michi are going to be disappointed in me. But that's okay.
[cpg]


I decided not to hide my indecision.
[cpg]


[OnName num="youta"]
"...... I still care about Michi. She stopped being a gal because of me."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuko182"]
[OnName num="natuko"]
“You’re right. I feel sorry for Michi if things continue as they are."
[cpg cn=true]


The response was unexpected. How am I supposed to take this?
[cpg]


I was at a loss and fell silent.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko183"]
[OnName num="natuko"]
“Do you want to date Michi too?”
[cpg cn=true]


[OnName num="youta"]
“There's no way I can reply to that.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Natuko184"]
[OnName num="natuko"]
"That's okay. Please tell me what you really think.”
[cpg cn=true]


[OnName num="youta"]
“……"
[cpg cn=true]


That's right. I don't have a choice. I said I love Natsuko, but I'm also interested in Michi.
[cpg]


I can't choose. Am I sure if I want to say it out loud ......?
[cpg]


[OnName num="youta"]
"......I can't choose...... Sorry, Natsuko."
[cpg cn=true]


Then Natsuko smiled gently.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Natuko185"]
[OnName num="natuko"]
“It's okay. I don't want to control you or anything.”
[cpg cn=true]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園図書室』（夕方）******************************************************



[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

Then, at the library after school. Michi was there, too, and it seemed that Natsuko had called her.
[cpg]


Of course, I was there too. The three of us were extremely awkward.
[cpg]


In fact, Michi was looking quite uncomfortable. She was looking at me and Natsukoiko alternately.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Natuko186"]
[OnName num="natuko"]
“Michi, I’ve been asked for advice from Yota.”
[cpg cn=true]


I guess she was going to tell her. All of it. Is that okay?
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Natuko187"]
[OnName num="natuko"]
“Yota says he can't choose between me and you. That's why ......"
[cpg cn=true]


[FG f="CHA01_p1_04_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Michi165"]
[OnName num="michi"]
"Look. I don't want to hear anymore of this. Yota and I can't be together anyway.”
[cpg cn=true]


Michi tries to get away from the situation, but Natsuko forces herself to say it all.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Natuko188"]
[OnName num="natuko"]
“So, why don't the three of us date together? I think it would be good for both of us to love Yota together.”
[cpg cn=true]


...... How would Michi react?
[cpg]


There was a good chance that she would be upset. I wondered if she could afford to accept this proposal.
[cpg]


I was thinking, ...... but it seems that Michi also has an unfathomable kindness.
[cpg]


[FG f="CHA01_p1_04_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Michi166"]
[OnName num="michi"]
"......I know that kind of characteristic about Yota too. Yeah......."
[cpg cn=true]


After saying that, she took my hand and kissed me on the cheek.
[cpg]



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


From that day on, I had two lovers.
[cpg]


It's easy to put it into words, but it's a hell of a thing ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『カラオケ店個室内』（夕方）******************************************************



One day we were at karaoke.
;//ある休日、俺たちはカラオケに来ていた。
[cpg]


Although it was awkward at first for the three of us to date together......  but we settled down in a rather natural way.
[cpg]


[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Natuko189"]
[OnName num="natuko"]
"Karaoke makes your throat sore...... Do you come here often Michi?”
[cpg cn=true]


[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Michi167"]
[OnName num="michi"]
“Yea. I’m guessing that you don’t.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Natuko190"]
[OnName num="natuko"]
“Yea......but it might be a good way to relieve some stress.”
[cpg cn=true]


Natsuko and Michi had become good friends. Even though I don't fully understand how they feel.
[cpg]


But at least it's enough since they seem happy.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************



[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

When I was walking with both girls, one on each side of me, pedestrians look at me suspiciously.
[cpg]

Sometimes they would have a perplexed look. But all of these things are inevitable.
[cpg]


Of course, it was not normal. In some cases, the two of them would hold my arm.
[cpg]


[FG f="CHA01_p1_04_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Michi175"]
[OnName num="michi"]
“I feel like such a fool for worrying about it all this time. I can't believe it's so easy to solve.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Natuko204"]
[OnName num="natuko"]
“Yota, I'm so happy for you.”, they chuckled.
[cpg cn=true]


[OnName num="youta"]
“Yeah…..”
[cpg cn=true]


I think it was good. The only other way for everyone to be happy was to do this.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************





The next day at school. I was blatantly making the boys jealous.
[cpg]


[OnName num="male_student_A"]
“Why is Yota so popular…….? It’s not like he is good-looking.”
[cpg cn=true]


[OnName num="male_student_B"]
“Him and Haneda have known each other since they were kids. That I understand but involving Harukawa as well…..”
[cpg cn=true]


[OnName num="male_student_A"]
“Yea. It is not fair. Even having one girlfriend for that guy is too many.”
[cpg cn=true]


[OnName num="male_student_B"]
“That's a bit rude……”
[cpg cn=true]


That’s what people would say. I was well aware of that.
[cpg]


[OnName num="youta"]
"...... Hey, Michi. Natsuko.”
[cpg cn=true]


[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Natuko205"]
[OnName num="natuko"]
“What is it?"
[cpg cn=true]


It's lunchtime. The girls take turns to make lunch for me every day.
[cpg]


Sometimes they forget the order and both bring lunch on the same day, but there is never a day when neither one of them don't make lunch.
[cpg]


[OnName num="youta"]
“I wonder what's going to happen to us now.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Natuko206"]
[OnName num="natuko"]
“What a waste of thought. It'll turn out the way it's going to turn out.”
[cpg cn=true]


Michi nodded. Yes, we'll make it work out. ......
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





[OnName num="youta"]
“...... but what will we do when we’re old enough to get married?”
[cpg cn=true]


[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Natuko207"]
[OnName num="natuko"]
“We can think about it then. It won't have anything to do with enjoying the present."
[cpg cn=true]


[OnName num="youta"]
“Maybe so, but if we don't ...... think about it, a lot of things will go wrong.”
[cpg cn=true]


[FG f="CHA01_p1_04_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Michi176"]
[OnName num="michi"]
“I mean, you’re considering to marry us. That is so sweet.”
[cpg cn=true]


The two of them are talking about such things in a casual manner.
[cpg]


I guess this is okay. ......
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



Then, Michi and Natsuko came up to my room because my parents were coming home late today.
[cpg]


[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
It feels like I don’t deserve this so I get a little spooked out by the situation.
[cpg]


...... was this the right thing to do? I was about to say that out loud.
[cpg]


[VOICE f="sNatuko015"]
[OnName num="natuko"]
“I'm happy. How about you?”
[cpg cn=true]


She asked and I couldn't help but nod.
[cpg]


;//移植のためシーンをカットしています

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


I think we were destined to be together like this.
[cpg]


If I had time to worry about it, I should have told Natsuko how I really felt and gone out with Michi as well.
[cpg]


Such a harem would be possible. No matter how many people deny it, I will not let go of these girls.
[cpg]



Today, too, I'm being harassed by the boys, and the girls are creeped out.
[cpg]



[VOICE f="Natuko221"]
[OnName num="natuko"]
"Oh, you've got rice on you. Let me take it off.”
[cpg cn=true]



[VOICE f="Michi185"]
[OnName num="michi"]
"Hey, that's not fair! I'll take it off.”
[cpg cn=true]


The two of them are fighting over me. This relationship is likely to continue for a while.
[cpg]


And if this relationship is destroyed for some reason, it does not mean that this time has not existed.
[cpg]


No, I will not let anything destroy this relationship. I quietly vowed to myself.
[cpg]


;//ブラックアウト

[SCENE id=11]


[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：サブヒロイン２ルート



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

