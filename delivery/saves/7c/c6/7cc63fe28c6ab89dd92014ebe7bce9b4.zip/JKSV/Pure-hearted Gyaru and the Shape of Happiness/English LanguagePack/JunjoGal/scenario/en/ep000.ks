
*start


;//ギャル嫁もの　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//美智　　裸　私服　制服　裸（清楚）　私服（清楚）　制服（清楚）
;//真雪　　裸　私服　制服
;//南都子　裸　私服　制服
;//以下音声なし
;//洋太　洋太の母　ギャルＡ　ギャルＢ
;//男子学生Ａ　男子学生Ｂ　女子学生Ａ　女子学生Ｂ　女子学生　洋太の父



;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//美智　　一人称「私」　真雪呼び「真雪」　南都子呼び「南都子」　洋太呼び「洋太」
;//真雪　　一人称「私」　美智呼び「美智」　南都子呼び「南都子」　洋太呼び「洋太」
;//南都子　一人称「私」　美智呼び「美智さん」　真雪呼び「真雪さん」　洋太呼び「洋太さん」
;//洋太　　一人称「俺」　美智呼び「美智」　真雪呼び「真雪」　南都子呼び「南都子さんor南都子」


;///////////////////////////ここからが本編です///////////////////////////


;#################################################
*Ep000|A Childhood Friend who Became a Gal.
;#################################################

[SCENE id=0]


[stflag Cha1flg = 0]
[stflag Cha2flg = 0]



;//回想ですのでセピア調にしてください



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_0.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『街』（朝）******************************************************





A long time ago. Adults would say that it wasn’t so long, but for me it feels like ages.
[cpg]


I, Yota Kawahara, as a child, made a promise.
[cpg]



;//下記セリフのみ名前を？？？と隠してください





;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi001"]
[OnName num="unknown"]
“It's a promise! I’m going to be your wife someday!”
[cpg cn=true]


A young girl name Michi Haneda. A girl I have known since childhood.
[cpg]


We were really good friends. I think we were together wherever we went.
[cpg]


And from that time, we were talking about getting married, being husband and wife and so on.
[cpg]


But we were torn apart. Maybe that was love, even though we were very young.
[cpg]


[OnName num="youta"]
“I'm moving to a town far away. Even if I come back, I'm sure you’ll forget about me.”
[cpg cn=true]


I think I said something like that. I remember it quite vividly.
[cpg]


In response, Michi said something like this.
[cpg]


;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi002"]
[OnName num="michi"]
“I'll never forget you, Yota, no matter how much things change, I'll always remember!”
[cpg cn=true]


No matter how much things change, I'll always remember’. I thought I would be the only one to feel that way.
[cpg]


But I was glad that Michi thought so too.
[cpg]


At that time, when we were really close to moving out, Michi would be crying and in a bad mood.
[cpg]


I might have cried too. I don't remember that part well.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



No matter how much things change, I will always remember. Those words have stuck with me ever since.
[cpg]


A lot of time has passed since then, and I think my character has developed as well.
[cpg]


I guess I could say that I have turned from a child into a young man.
[cpg]


Even though there are traces of her, it would be difficult to recognize her at first glance.
[cpg]


Still, I thought to myself; no matter how much Michi has changed, I will remember.
[cpg]



;//ここから色調を戻してください

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（朝）******************************************************


And after several spring seasons passed by, it was spring again.
[cpg]


I came back. To this town. The time has come for me to fulfill that promise which had only been a memory.
[cpg]


Shio Gakuen, the school I'm going to, is a pretty good school, but I managed to pass the entrance exam and I'm a freshman this year.
[cpg]


Maybe Michi is coming to this school, too. Even if not, she probably lives near here.
[cpg]


...... but if……if would be in the same class as her or something, it would be a miracle.
[cpg]


[OnName num="youta"]
“Huh ...... I really came back ......."
[cpg cn=true]


I can't help but mutter to myself. Rather than thinking about the view of the city I was thinking about encountering Michi.
[cpg]


I still remember Michi. I wonder if she still remembers me.
[cpg]


[OnName num="youta"]
"...... wait for me, Michi."
[cpg cn=true]


I started walking, calling out the name of my childhood friend, who I wasn't sure if she was waiting for me or not.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Michi was a neat and tidy girl. And yet honest.
[cpg]


She was probably a proper schoolgirl now, with long black hair.
[cpg]


She always had the qualities of a beautiful woman, and I'm sure she'll grow up to be that way……
[cpg]


[OnName num="youta"]
“……"
[cpg cn=true]


The entrance ceremony. I try to find the silhouette of her but I couldn’t.
[cpg]


But I guess the entrance ceremony is not the right place to look.
[cpg]


I guess it can't be helped since everyone is looking forward.
[cpg]


What was surprising, however, was that even though it was a preparatory school, I saw some people who were the party type.
[cpg]


There are is a certain percentage of both male and female students who are like that. It must be because of the age.
[cpg]


There were also girls who were called “gal".
[cpg]


There may be some unexpectedly smart gals, too. ……I guess it’s rude to think of them as unexpectedly smart.
[cpg]


Whether you are educated or not is not related to the way you look or what your hobbies are.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





I was thinking about this as I headed to the classroom where I would be studying for at least a year.
[cpg]


There, I meet about 30 other schoolmates of the same generation, all dressed in school uniforms.
[cpg]


I couldn't help but look around. It's not that I want to be friends with anyone in particular. ......
[cpg]


I wondered if Michi was there. I was only concerned about that.
[cpg]


But ...... when I thought about her not being here…..
[cpg]


;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi003"]
[OnName num="michi"]
“Is that you Yota? You haven't changed at all. Wait, you know who I am, don't you?”
[cpg cn=true]


I heard the voice I wanted to hear.
[cpg]


And when I turned around, there she was.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ非エロ（主人公の手を握るヒロイン。目を輝かせている、制服は着崩している）ev_01
;//人物１：メインヒロイン
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================


[BGM f="bg_gy"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]




But I froze for a moment.
[cpg]


Michi, is it her?
[cpg]


She grabs my hand firmly. But, who is this?
[cpg]


[OnName num="youta"]
“Oh, hi. ......"
[cpg cn=true]


The words that come out of my mouth, seem somewhat out of place.
[cpg]


I remember those words. “No matter how much things changes, I’ll always remember!”
[cpg cn=true]


She must be Michi. But still.
[cpg]


...... Hasn’t she changed a little too much? Because this is ......
[cpg]


It's a figure that can only be described as a gal. Was Michi the kind of girl who dresses like this?
[cpg]


No, a young child would never dress like that.
[cpg]


She could have grown up like this. But even so, it's an amazing transformation.
[cpg]


She looks like the old her. Her voice also had a certain atmosphere.
[cpg]


But I didn't want to admit it.
[cpg]


I didn't want to admit it, so I asked, expecting to hear someone else's name.
[cpg]


[OnName num="youta"]
"...... Michi, is it?"
[cpg cn=true]


I was not able to say, “It’s you, isn't it, Michi?” or "It's been a long time.”
[cpg]


More to the point, I was quite amused because I was expecting an emotional reunion.
[cpg]


On the contrary, she seemed to think that we were having a very emotional reunion.
[cpg]



[VOICE f="Michi004"]
[OnName num="michi"]
“Yes so you remember. I knew you would remember! I’ve changed a lot haven’t I?”
[cpg cn=true]


Michi says that she’s changed a lot. She is aware of it.I could feel my mouth forming a forced smile.
[cpg]


Then, as if I suddenly remembered, I said what I couldn't say before.
[cpg]


[OnName num="youta"]
“Umm......, it's been a while.”
[cpg cn=true]


It's been a while. I think those were the right words. Seeing her nod, she was definitely Michi.
[cpg]


However, her appearance is quite different. Her saying that she had changed was definitely not an understatement.
[cpg]



[VOICE f="Michi005"]
[OnName num="michi"]
“It's been a long time! You haven't changed at all....... Maybe you’ve lost a little weight."
[cpg cn=true]


From her I had not changed at all. I don't even remember changing.
[cpg]


And what does she mean by losing weight compared to how I was when I was a kid.....
[cpg]




;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I don't know if I can say that this is our first encounter ....... Of course, we have met in the past.
[cpg]


For me, this is the first time I met Michi after her transformation. I think I can call it a first encounter.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi006"]
[OnName num="michi"]
"I can't believe you’re back. You should have said something to me."
[cpg cn=true]


After class. I was on my way home with Michi.
[cpg]


This was something we had done many times before. We always went home together after school.
[cpg]


But this time it felt different.
[cpg]


I felt like I was walking with a complete stranger.
[cpg]


The tone of her voice hasn't changed much. If I had to say one thing that changed, it would be that she become brighter.
[cpg]


No, I think she was bright since...... I wonder if this happens when that goes too far.
[cpg]


But, just because one is bright doesn't mean that one becomes a gal.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Michi007"]
[OnName num="michi"]
“Are you listening? I’ve been waiting for you for a long time."
[cpg cn=true]


As I was thinking something like that, Michi spoke to me.
[cpg]


What were we talking about? I was thinking too many things and didn't hear anything.
[cpg]


[OnName num="youta"]
"Oh, no no, I’m listening.”
[cpg cn=true]


I replied, relieved that Michi did not trace back to what we were talking about.
[cpg]


But I never thought it would come to this. Gals are not my favorite kind of people.
[cpg]


At least, almost none of my friends and even acquaintances are gal.
[cpg]


I've been trying to avoid talking to these kind of people as much as possible. ......
[cpg]


But if this is what has happened to Michi, then it's a different story.
[cpg]


I never thought my childhood friend would turn out like this.
[cpg]


Of course, I don't think that she isn't pretty now.
[cpg]


She is, but not in the way I had expected.....
[cpg]


I had imagined a more innocent and gorgeous Michi.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi008"]
[OnName num="michi"]
“Oh, my house is this way. You know that, right?”
[cpg cn=true]


[OnName num="youta"]
“…… I see.”
[cpg cn=true]


She laughs when she says that. That smile is also ......
[cpg]


I've seen it before somehow. But it's been overwritten by makeup.
[cpg]


People do change with makeup.
[cpg]


I'm sure if she had a more natural makeup on, I could smile and wave.
[cpg]


But, I still had to, so I decided to wave goodbye.
[cpg]


[OnName num="youta"]
"Well, I'll see you later......."
[cpg cn=true]


I'm worried that my smile might seem forced, but there's no use being worried about it......
[cpg]


Besides, I was sure it was forced.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


[SE f="se011"]
;//【ＳＥ】『ドア開く』


[OnName num="youta"]
“I’m home.……"
[cpg cn=true]


I was tired and exhausted in many ways.
[cpg]


I come back to my house. But my heart was restless.
[cpg]


I would never see the Michi I knew again.
[cpg]


[OnName num="youta_mother"]
"Welcome home. Did you see Michi?"
[cpg cn=true]


My mom asks me.
[cpg]


[OnName num="youta"]
"You knew, Mom......"
[cpg cn=true]


So I thought she knew that Michi had become a gal, too.
[cpg]


[OnName num="youta_mother"]
“I wanted to surprise you. Why do you look like that?"
[cpg cn=true]


But apparently not. She doesn't know why I look like this.
[cpg]


Maybe she only communicates with Michi and her family on the phone. ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



Although not completely I was still pretty shocked.
[cpg]


It was not like the end of the world, but I did feel a jolt in my body.
[cpg]


I was caught off guard. I really didn't know anything about it.
[cpg]


From Michi's point of view, she probably became a gal while I was gone. ......
[cpg]


I haven't changed at all, and her image also.
[cpg]


If only I could see how she changed….. But that's pointless to think about.
[cpg]


It wouldn't make my shock go away if I could see what had happened along the way.
[cpg]


In any case, the long, dark-haired, graceful girl I had envisioned seemed to have vanished somewhere.
[cpg]


I was under too many illusions. The promise I had made to her when I was a child had grown too big inside of me.
[cpg]


I guess it can't be helped. She said she was really going to be my wife.
[cpg]


I imagined that she would be expecting something of me..…
[cpg]


I believed that she would be thinking of me all the time.
[cpg]


I just thought that she would be happy when I came back to her. ...... No, is that what I assumed.
[cpg]


So the situation is not that far out of my imagination......
[cpg]


I can't say. I've never experienced in my life an emotion that I can neither rejoice nor grieve over.
[cpg]


I was just bewildered. I was quite shocked and quite taken aback and perplexed ......
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************



After a week, a sort of gal group had already been formed, even though we were in a prep school.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
At lunchtime, they are talking about their boyfriends. I wonder if maybe Michi has a boyfriend.
[cpg]


But, if she did, she wouldn't be talking to me in the way that she did .......
[cpg]


[OnName num="gal_A"]
“Really? Why are you dating someone like that?”
[cpg cn=true]


[OnName num="gal_B"]
“Inertia, I guess. It's just ...... I got used to it. I don't even like him that much anymore.”
[cpg cn=true]


I realize again that even though it's a prep school, there are a lot of gals.
[cpg]


Is there a certain number of them in any school? The imagination is endless.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi009"]
[OnName num="michi"]
“I don't have a boyfriend, so I don't get it.”
[cpg cn=true]


She doesn't have a boyfriend? I am glad to hear that. ...... and I am somewhat relieved.
[cpg]


I was thinking that, but I still felt a little uncomfortable about Michi being in the conversation with the other gals.
[cpg]


I thought she was the type of girl who wouldn't talk to this type of person.
[cpg]


[free time=1000]


[OnName num="gal_A"]
“What about you, Mayuki? We don't hear much about that from you."
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
During the course of their conversation, the girl called Mayuki was the typical gal.
[cpg]


She was very different from Michi and other gals.
[cpg]


She had too much makeup, and her school uniform was much more formal than others.
[cpg]


And her skin is very tanned. In this season.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki001"]
[OnName num="mayuki"]
“Hmm? Me? If you have time to worry about it, do something about your own boyfriend.”
[cpg cn=true]


The girl, Mayuki, replied to another gal with a comment that sounded very confident.
[cpg]


[OnName num="gal_B"]
“I guess……."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayuki002"]
[OnName num="mayuki"]
“You should get a boyfriend, too, Michi. You're so cute."
[cpg cn=true]


There we go. That conversation. I listened to what Michi would say in response.
[cpg]


She might mention my name here.
[cpg]


[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]


[VOICE f="Michi010"]
[OnName num="michi"]
"Heh heh. I already know who’s gonna be my boyfriend.”
[cpg cn=true]


See, I knew it. I knew she would say something like that.
[cpg]


I have a bad feeling about this. With that thought in mind, I fearfully approached the group of gals.
[cpg]


I wanted to talk to Michi about the situation.
[cpg]


[OnName num="youta"]
"Michi, can I have a word with you?......"
[cpg cn=true]


As I approached her……
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Michi011"]
[OnName num="michi"]
“Ah! Yota, great timing!”
[cpg cn=true]


Michi stood up and pulled my hand.
[cpg]


I had never been this close to a girl and I was nervous.
[cpg]


And in the midst of my excitement, she said,
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Michi012"]
[OnName num="michi"]
“This guy is my fiancée! I hope you know that he is taken already.”
[cpg cn=true]


I looked around in surprise.
[cpg]


[OnName num="youta"]
"Hey, your voice is too loud ......!"
[cpg cn=true]


"It's okay, it's okay.”, Michi says.
[cpg]


What's okay about it? I'm giving them the wrong impression.
[cpg]


Not only the group of gals but also the people around me are looking at me and wondering what's going on.
[cpg]


And the gals are saying ......
[cpg]


[OnName num="gal_A"]
“Really? You're engaged? That means you’re marrying a rich boy?”
[cpg cn=true]


No, that's not true. The word "fiancée" must have just come out.
[cpg]


[OnName num="gal_B"]
"No, it's the other way around, Michi is the rich girl?"
[cpg cn=true]


That's not true. I have never heard of Michi being a lady rich.
[cpg]


And then, the girl, Mayuki, laughed and said,
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mayuki003"]
[OnName num="mayuki"]
“I see. If you have a husband already, I don't have any complaints."
[cpg cn=true]


She said something like this. It was as if everyone around me approved.
[cpg]


I couldn't shake her off saying, "Are you kidding me?”
[cpg]


Somewhere, I couldn't help but feel happy. ......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





Then, after school. This time, I was surrounded by boys.
[cpg]


It seems that Michi already has a certain number of fans. She's cute, isn't she?
[cpg]


[OnName num="male_student_A"]
“I heard that you're dating Haneda.”
[cpg cn=true]


[OnName num="youta"]
“That's ...... a little different.”
[cpg cn=true]


[OnName num="male_student_B"]
“No, they're not. He's her fiancee."
[cpg cn=true]


This topic is getting bigger than it seems. It's getting out of hand.
[cpg]


[OnName num="youta"]
“No, it's more like ……”, I try to laugh it off.
[cpg cn=true]


A dry laugh breaks out. I had no choice but to explain.
[cpg]


I'll explain step by step. I explained that Michi and I had known each other since childhood.
[cpg]


And that we made a little promise when we were kids.
[cpg]


[OnName num="youta"]
“We were childhood friends, you know kids talk about becoming wives and other stuff.”
[cpg cn=true]


The boys were convinced.
[cpg]


[OnName num="male_student_A"]
"Oh, that kind of thing,...... but Haneda seems to be serious.”
[cpg cn=true]


[OnName num="male_student_B"]
“Yea. You have to be serious in order to be able to say something like that.”
[cpg cn=true]


[OnName num="youta"]
“Well, you're right……."
[cpg cn=true]


[OnName num="male_student_B"]
“I've been actually eyeing that girl since she's cute.”
[cpg cn=true]


The misunderstanding may be cleared up, but it is not a fundamental solution.
[cpg]


But what is the fundamental solution? Is it a solution if Michi no longer likes me?
[cpg]


Is it a solution if Michi is no longer a gal ……? Probably not.
[cpg]


I was at a loss as to what to do.
[cpg]


I had no idea what I wanted to do in the first place.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園図書室』（夕方）******************************************************



I felt like I couldn't stay in the classroom any longer, so I tried to leave as soon as possible.
[cpg]


But on the way there, I saw a cute girl in the library.
[cpg]


;//下記セリフのみ名前を？？？と隠してください


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko001"]
[OnName num="unknown"]
“……”
[cpg cn=true]


A pure and mature-looking girl. The Michi in me was like this, too......
[cpg]


But I can’t force my ideals onto her. I didn't talk to her or anything and time passed away.
[cpg]


It wasn't that I wanted to be friends with her.
[cpg]


I was even told by Michi that I was her fiancée. ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************





After declaring to everyone around me that I was her fiancée, it seemed that Michi was having a hard time backing down.
[cpg]


Or perhaps she had no intention of backing down in the first place.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi013"]
[OnName num="michi"]
“Here's your lunch! I made more for you Yota."
[cpg cn=true]


She made me a bento, even though I brought my own, too.
[cpg]


I wonder if the fact that she made more for me was because I'm a guy.
[cpg]


Either way, our lunches overlap.
[cpg]


I was wondering if this was a situation of eating my portion of lunch for dinner......
[cpg]


I also had a bad feeling. I don't have a good image of a bento made by a gal.
[cpg]


[OnName num="youta"]
“Thanks ......."
[cpg cn=true]


Michi smiles with a giggle. And she watches me while she waits for me to eat it.
[cpg]


[OnName num="female_student_A"]
“Those two are really in love.”
[cpg cn=true]


I don't think we are in love, but that's the way they look at us.
[cpg]


[OnName num="female_student_B"]
"I don't know, bento is risky, ...... even a hundred years of love might cool off."
[cpg cn=true]


[OnName num="youta"]
“Well, thank you for the bento.”
[cpg cn=true]


I take a bite from the egg roll as the others watch us.
[cpg]


I was prepared to spit it out if it was bad.
[cpg]


And the taste is ......
[cpg]


[OnName num="youta"]
“……Uh, it's good."
[cpg cn=true]


Not only was it beyond my imagination, it was probably beyond my mother's skill.
[cpg]


[OnName num="youta"]
"Michi, you're quite the chef……, it's delicious."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi014"]
[OnName num="michi"]
“I know. I've been working hard on my cooking for today.”
[cpg cn=true]


For today...... A lot of years have passed by until today.
[cpg]


However, the bento she made was delicious even though it was cold.
[cpg]


I munched away at it and ate it up in no time.
[cpg]


Michi was looking at me happily......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





After that, she took care of me in every way. I wondered if she was always this type of person.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
For example, if I forgot my textbook, she would lend me her textbook even though we were in the same class.
[cpg]


I asked her what she was going to do with it.
[cpg]



;//1221　音声に合わせて修正
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Michi015"]
[OnName num="michi"]
“I’ll just ask someone else to share with me.”
[cpg cn=true]






[OnName num="youta"]
“I think you are forgetting what’s important.”
[cpg cn=true]


I say.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi016"]
[OnName num="michi"]
"No, it's not like that. This way it is easier for you to read.”
[cpg cn=true]


I feel the old Michi's caring nature.
[cpg]


She is always single-minded about me. On the contrary, this made me puzzled.
[cpg]


If I had become a totally different person, she could still blow it off.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi017"]
[OnName num="michi"]
“I'm sorry,......, I forgot about your lunch.”
[cpg cn=true]


I had brought my own lunch box on my way home.
[cpg]


But she didn't have to worry about that.
[cpg]


[OnName num="youta"]
“Don’t worry, it was delicious. You've practiced a lot, Michi.”
[cpg cn=true]


I praised her. It was a dish that made me want to praise her.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi018"]
[OnName num="michi"]
“I didn't just learn it from my mother. I read cooking books and stuff.”
[cpg cn=true]


[OnName num="youta"]
"Cooking books.……"
[cpg cn=true]


A cooking book doesn’t really match the image of a gal……..or so I thought.
[cpg]


I remind myself that after all, Michi is still Michi. She has done a lot of hard work to become my wife.
[cpg]


She wasn't just waiting for me. I realized that.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi019"]
[OnName num="michi"]
“I worked hard in my studies as well. Even as a child, you were good at studying and sports, weren’t you Yota?”
[cpg cn=true]


[OnName num="youta"]
“Yeah, well, that's probably true.”
[cpg cn=true]


I can't deny that. I was good at studying.
[cpg]


It's not that I was skilled at it, and when being told I've been like that since I was a child, my memory is vague.
[cpg]


I was not studying at the time when I was in this town, but I was still a smart kid.
[cpg]


That's why I was able to get into Shio Academy, which was a rather high-level school…..
[cpg]


[OnName num="youta"]
“But yeah,......as for sports……."
[cpg cn=true]


I look at my skinny body and think back a little.
[cpg]


[OnName num="youta"]
“Sports have been a bit rare for me lately,......."
[cpg cn=true]


I said this to Michi and she nodded.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi020"]
[OnName num="michi"]
“I know. You seem to lose some weight.”
[cpg cn=true]


Come to think of it, she said the other day as well. That I had lost weight.
[cpg]


I can't lose weight from when I was a child, but ......
[cpg]


I guess she means that I was thinner than what she had expected.
[cpg]


One mystery solved, but that doesn't really matter.
[cpg]


[OnName num="youta"]
“Michi….., why are you……?”
[cpg cn=true]


As I say, I stopped. She questioned what I was going to say but I decided not to say.
[cpg]


What I wanted to say was, "Why did you become a gal?”
[cpg]


Someone's influence must definitely be there. I don't know who that someone is.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





When I returned home and told my mother about the lunch situation, and she smiled at me.
[cpg]


She genuinely congratulated me. But ......
[cpg]


She definitely doesn't know what Michi looks like.
[cpg]


But if she looks like a gal, then of course she must be like that on the inside too.
[cpg]


Most of her personality hasn’t changed.
[cpg]


If she acts like a gal, she will probably hang out with other gals.
[cpg]


Maybe they go to the arcade or karaoke and have chitchat.
[cpg]


Is my image of a gal old-fashioned……? Anyway.
[cpg]


Michi was the Michi I knew. She had not become a different person.
[cpg]


Michi is still Michi. There is no doubt about that.
[cpg]


Somewhere along the way, the gal element came into her and merged with her original personality and commitments.
[cpg]


So I thought......
[cpg]



;//■選択肢
[switch]
[case "I still like Michi."]
	[swap]
	[jump target="*select01_1"]
[case "It's a shame that she's transformed."]
	[swap]
	[jump target="*select01_2"]
[endswitch]

1. I still like Michi.
2. It's a shame that she's transformed.



;//==============================
;//１、美智のことがやっぱり好きだ
*select01_1|My childhood friend who became a gal


[stflag Cha1flg = 1]


After all, Michi is still Michi. She hasn’t completely changed.
[cpg]


No matter how much makeup she wears or how much she dyes her hair.
[cpg]


My feelings for her have never wavered that much.
[cpg]


I still like her, and that feeling will never change.
[cpg]



;//次の選択肢が１で固定される

[jump target="*select01_3"]

;//==============================
;//２、変貌してしまったことが残念だ
*select01_2|My childhood friend who became a gal





I can't help but feel disappointed by her transformation.
[cpg]


The person I love has changed in a way they pleased. Nothing could be more regrettable.
[cpg]


It was even more frustrating to see that she had retained some resemblance of her former image.
[cpg]


I couldn't completely hate her...... It was that sort of feeling.
[cpg]



;//==============================

*select01_3

[jump storage="ep001.ks" target="*start"]

