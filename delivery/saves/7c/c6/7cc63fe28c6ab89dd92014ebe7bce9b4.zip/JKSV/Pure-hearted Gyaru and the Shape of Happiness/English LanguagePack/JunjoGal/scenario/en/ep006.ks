
;//１、真雪

*start



;#################################################
*Ep006|The Jolly Mayuki
;#################################################

[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=1000]


*select03_1|The Jolly Mayuki


[SCENE id=6]


I was picturing Mayuki's face.
[cpg]


A cheerful gal. Not just aggressive, but very bright.
[cpg]


[OnName num="youta"]
"...... No, that’s a wrong......"
[cpg cn=true]


I'm disappointed in Michi for becoming a gal.
[cpg]


If that is the case, there is no reason to be disappointed in Michi if I date Mayuki.
[cpg]


Though, I found myself being attracted to bright Mayuki. 
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』





Next morning. I was walking to school.
[cpg]


What if Mayuki seduces me again? I don't think I can refuse.
[cpg]


That's how much I became attracted to her.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





During class, Mayuki seemed uninterested in the subject.
[cpg]


On the other hand, Michi is rather serious. But in a gal's appearance.
[cpg]


I found myself no longer being bothered by a gal.
[cpg]


Both Michi and Mayuki seemed cute. Then again, that's something that bothers me.
[cpg]


I started to think that Mayuki was cuter than Michi, who was more of a gal.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（夕方）******************************************************





After school, I was being pulled by Mayuki.
[cpg]


[OnName num="youta"]
"Hey, wait....., where are you taking me?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayuki101"]
[OnName num="mayuki"]
“That doesn't matter. Just come!”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





The place she took me to was the back of the school.
[cpg]



;//========================================
;//●ＣＧ（主人公のすぐ前に居るヒロイン）ev_14
;//人物１：サブヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園裏
;//時間　：夕方
;//========================================


[BGM f="bg_h1"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]



It was empty. But that doesn't mean no one will find us.
[cpg]

[VOICE f="sMayuki015"]
[OnName num="mayuki"]
"Here we can flirt without hesitation, right?”
[cpg cn=true]


[OnName num="youta"]
"......, but if Michi sees us…..”
[cpg cn=true]


Even if it wasn't her, what if someone else found out and told her?
[cpg]

When I was thinking about that, Mayuki laughed a little.
[cpg]

[VOICE f="sMayuki016"]
[OnName num="mayuki"]
“You’re still concerned about it. It’s not good to play both sides.”
[cpg cn=true]


Saying this, Mayuki leans her back against me.
[cpg]

[VOICE f="sMayuki017"]
[OnName num="mayuki"]
“See? If I do this... don't you want to hold me tight?"
[cpg cn=true]


I have that feeling. But I can't let that happen.
[cpg]

Once I get on board with her seduction, I will not be able to stop.
[cpg]

[OnName num="youta"]
“I can’t …….”
[cpg cn=true]


I shake my head. She replies in a disappointed voice,
[cpg]

[VOICE f="sMayuki018"]
[OnName num="mayuki"]
“Just because Michi might be watching? If that's the case.”
[cpg cn=true]


She pauses for a moment and then looks at me.
[cpg]


;**【ＣＧ】 ev_14_a ***********************
[CG id=8 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMayuki019"]
[OnName num="mayuki"]
“Why don't you come over to my place?"
[cpg cn=true]


Mayuki's suggestion took me by surprise......
[cpg]

[VOICE f="sMayuki020"]
[OnName num="mayuki"]
“So, what do you think? Well, If you turn me down half-assed, I'm taking you with me.”
[cpg cn=true]


As she says, I was easily swayed.
[cpg]

[OnName num="youta"]
"Let's go then……”
[cpg cn=true]


[VOICE f="sMayuki021"]
[OnName num="mayuki"]
“Whoa, you're on board. To be honest, I didn't expect that answer.”
[cpg cn=true]


I felt a little regret after hearing Mayuki's words, but I couldn't hold myself.
[cpg]

Maybe I was going crazy. No…..
[cpg]

I was already crazy from before. I've been bizarrely indecisive.
[cpg]

[VOICE f="sMayuki022"]
[OnName num="mayuki"]
“Then it's decided.”
[cpg cn=true]


Seeing Mayuki happy, I knew I couldn't deny her any time soon.
[cpg]


;//移植のためシーンをカットしています


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


Still, it was a sudden invitation. Apparently her mother was out of town.
[cpg]


So, I end up following her as I couldn't deny her.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





[OnName num="youta"]
“I can't imagine your room.……"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayuki119"]
[OnName num="mayuki"]
“Maybe it's a little messy. But that's okay, right?”
[cpg cn=true]


I can imagine that. But, I can't imagine what kind of family she grew up in.
[cpg]


[OnName num="youta"]
“How did you grow up to be this much of a gal?”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki120"]
[OnName num="mayuki"]
"Well, I guess. My family is quite rich, and they are very strict about behavior.”
[cpg cn=true]


[OnName num="youta"]
"Is that so? Then aren't you supposed to become an opposite of a gal?”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayuki121"]
[OnName num="mayuki"]
“It's like a reaction, you know? When you're told to stop, you want to do it.”
[cpg cn=true]


I don't get it. But her house was a big mansion.
[cpg]


There were no servants, but the house made me think that there might be.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I was invited to her room. It was indeed a bit messy.
[cpg]


;//[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki122"]
[OnName num="mayuki"]
"Well…… since you followed me here, you must be ready for this, right?”
[cpg cn=true]


[OnName num="youta"]
“What are you talking about?”
[cpg cn=true]


;//[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mayuki123"]
[OnName num="mayuki"]
"Maybe you've really fallen in love with me? Isn't it.”
[cpg cn=true]


I can't deny it. I think she's attractive.
[cpg]

But I was still hesitant to confess my feelings to her.
[cpg]

;//[FACE method="change_1" pos="2/3"]
[VOICE f="sMayuki023"]
[OnName num="mayuki"]
“You can't say you like me yet?"
[cpg cn=true]


[OnName num="youta"]
"That's ……"
[cpg cn=true]


;//[FACE method="change_2" pos="2/3"]
[VOICE f="sMayuki024"]
[OnName num="mayuki"]
“You're cute in that sense, too.”
[cpg cn=true]


Then she comes even closer to me.
[cpg]

Somehow, I was convinced that she doesn't do this to anyone.
[cpg]

Her lips come closer......
[cpg]


;//移植のためシーンをカットしています



;//ブラックアウト

And we kissed, even though we weren't dating.
[cpg]


I don't know how to face Michi.....she would never allow such a thing.
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『街』（夜）******************************************************





Walking in the city after the sun has set. I'm now struggling ...... with how I should face Michi.
[cpg]


Maybe I'm not qualified to face her.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I have to do something about this three-time situation.
[cpg]


If I'm going to date Mayuki, I have to tell the other two.
[cpg]


But I couldn't find the courage to do so.
[cpg]


I guess you can't really call this courage.
[cpg]


I couldn't do what I have to, even though it was something I can and had to do.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（朝）******************************************************





While I was worrying about such things, it was morning.
[cpg]


I head to school. I was going to meet both Michi and Mayuki.
[cpg]


I don't know how to face them, really.......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi109"]
[OnName num="michi"]
“Good morning. Are you...... a little depressed? Or is it my imagination?"
[cpg cn=true]


[OnName num="youta"]
“Don’t worry. I'm not depressed.”
[cpg cn=true]


I had no choice but to answer that way and show her the bright side.
[cpg]


By doing so, I would be able to see the cheerful Michi.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayuki145"]
[OnName num="mayuki"]
“Hey, Yota. May I have a word?”
[cpg cn=true]


[OnName num="youta"]
“...... What is it?"
[cpg cn=true]


I thought that Mayuki was thinking of something stupid again.
[cpg]


And I was apparently right......
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]




She brought me to the back of the school. Class is about to begin in a minute.
[cpg]


[OnName num="youta"]
"...... class is about to start. What are you going to do?”
[cpg cn=true]


;//[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mayuki146"]
[OnName num="mayuki"]
"I know what I'm going to do.”
[cpg cn=true]


Saying that, she kisses me. There is no longer any hesitation.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sMayuki025"]
[OnName num="mayuki"]
"I'm glad you're not resisting anymore.”
[cpg cn=true]


It is easy to be carried away by Mayuki's words.
[cpg]


But is that really what I want?
[cpg]


I don't know. I don't even know what Mayuki is thinking...
[cpg]


;//移植のためシーンをカットしています



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************





I continue to do these with Mayuki, even though I have to sort things out with Michi.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi110"]
[OnName num="michi"]
“Good morning, Yota. It's a beautiful day again, isn't it?”
[cpg cn=true]


[OnName num="youta"]
“Yeah..."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi111"]
[OnName num="michi"]
“What's wrong?”
[cpg cn=true]


[OnName num="youta"]
“It’s nothing."
[cpg cn=true]


Michi talks to me without any awareness. That's why it makes me feel distressed.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Michi112"]
[OnName num="michi"]
“I made lunch for you, do you want to have lunch with me?”
[cpg cn=true]


[OnName num="youta"]
"Yeah..."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi113"]
[OnName num="michi"]
“Great. Where should we eat? A quiet place would be better.”
[cpg cn=true]


Seeing her enjoying made my heart ache even more.
[cpg]


It's my fault for being indecisive.
[cpg]







;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki166"]
[OnName num="mayuki"]
“What's wrong? Yota. You seem to be in a daze..."
[cpg cn=true]


[OnName num="youta"]
"No..."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayuki167"]
[OnName num="mayuki"]
“You don't feel very well?”
[cpg cn=true]


[OnName num="youta"]
“I'm kind of thinking what to say…."
[cpg cn=true]

No, "thinking" is an irresponsible word.
[cpg]

I have to make a decision now. I had plenty of time to think about it.
[cpg]


;//移植のためシーンをカットしています

[FACE method="change_2" pos="2/3"]
[VOICE f="sMayuki026"]
[OnName num="mayuki"]
“Anyway is good with me. Since I like your indecisiveness.”
[cpg cn=true]


[OnName num="youta"]
"Oh......."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMayuki027"]
[OnName num="mayuki"]
"Oh, don't worry about it, I'm good at being open and honest."
[cpg cn=true]



Seeing her smile, I thought more and more that this was a bad idea.
[cpg]


I am attracted to Mayuki. There was no doubt about it.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************





[OnName num="youta"]
"Mayuki, I need to talk to you about something…..”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayuki189"]
[OnName num="mayuki"]
“What's wrong?”
[cpg cn=true]


[OnName num="youta"]
“Is there any way to fix what's going on right now?”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Mayuki190"]
[OnName num="mayuki"]
“Why are you asking me that?”
[cpg cn=true]


[OnName num="youta"]
“I mean,…..I don't know what to do……”
[cpg cn=true]


I know I have to fix my mistake myself, but I don’t know what to do.
[cpg]


As miserable as I am, I’m crying out to Mayuki.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayuki191"]
[OnName num="mayuki"]
“Just choose either one.”
[cpg cn=true]



;//1221　音声に合わせて修正
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Mayuki192"]
[OnName num="mayuki"]
“I'm just kidding. If you could do that, we wouldn't be in this situation.”
[cpg cn=true]








She’s only half-joking.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki193"]
[OnName num="mayuki"]
“Well, it's not impossible. But since it's Michi... it'll probably be a piece of cake, right?”
[cpg cn=true]


[OnName num="youta"]
“What do you mean?”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayuki194"]
[OnName num="mayuki"]
“It's easy. If you can't choose one or the other, we can all be together.”
[cpg cn=true]


[OnName num="youta"]
“What?”
[cpg cn=true]


I decided to listen to her proposal, not really understanding.
[cpg]







;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『メインヒロインの部屋』（昼）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]



[VOICE f="Mayuki195"]
[OnName num="mayuki"]
“....... So from now on, why don't the three of us date together?”
[cpg cn=true]


[OnName num="youta"]
“……”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Michi114"]
[OnName num="michi"]
“Wait a minute...I'm trying to wrap my head around this.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Michi115"]
[OnName num="michi"]
“In common sense, that kind of relationship isn't right…"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Mayuki196"]
[OnName num="mayuki"]
“But you're not going to back down, are you?”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Michi116"]
[OnName num="michi"]
“Of course not!”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Mayuki197"]
[OnName num="mayuki"]
“I agree with you there. Then it's up to Yota to choose.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Michi117"]
[OnName num="michi"]
“Yota always been indecisive.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Mayuki198"]
[OnName num="mayuki"]
“Or we'll have to fight and one of us will get him.…”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Michi118"]
[OnName num="michi"]
“I don't want to do that. I want us to be friends.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mayuki199"]
[OnName num="mayuki"]
“Right? We are greedy. So, this is the best solution.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Michi119"]
[OnName num="michi"]
"........."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/2" time=800]
[VOICE f="Michi120"]
[OnName num="michi"]
“Okay. I’m fine with that. The three of us.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mayuki200"]
[OnName num="mayuki"]
“Yay. Now we have permission.”
[cpg cn=true]


[OnName num="youta"]
“Oh, really?”
[cpg cn=true]


[OnName num="youta"]
“Are you sure?”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Michi121"]
[OnName num="michi"]
“If you're going to ask that, I'd like you to pick one of us.”
[cpg cn=true]


[OnName num="youta"]
“I'm sorry.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mayuki201"]
[OnName num="mayuki"]
“Well, I guess we can celebrate.”
[cpg cn=true]


I started dating both of them at the same time.
[cpg]


The three of us went everywhere together, and a strange love triangle was formed.
[cpg]


It was like I was in a two-timer situation, and I felt uncomfortable.
[cpg]


But...if they both say it's okay ......, then I guess it's okay for now.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

;//ブラックアウト

That's how this ended up as the result of indecisiveness.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ（エプロン姿の二人。お尻を突き出している）ev_49
;//人物１：サブヒロイン１
;//服装１：エプロン
;//人物２：メインヒロイン
;//服装２：エプロン
;//人物３：主人公
;//服装３：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================


;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_49_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMichi008"]
[OnName num="michi"]
“......It's weird, I knew it was weird.”
[cpg cn=true]


[VOICE f="sMayuki028"]
[OnName num="mayuki"]
“Really? I'm used to it.”
[cpg cn=true]


[VOICE f="sMichi009"]
[OnName num="michi"]
"That's not fair. Now I have to say that I am used to it too.”
[cpg cn=true]


The three of us do everything together. Even when we are flirting.
[cpg]

 Today we are doing a cooking showdown, and we are all wearing an apron.
[cpg]

Of course Michi was the best cook.
[cpg]

But I still can’t choose between the two of them.
[cpg]

[VOICE f="sMayuki029"]
[OnName num="mayuki"]
“This kind of situation is a man's dream, right?”
[cpg cn=true]


[OnName num="youta"]
“…… Well.….”
[cpg cn=true]


;**【ＣＧ】 ev_49_a ***********************
[CG id=9 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMichi010"]
[OnName num="michi"]
“Don’t be so coy. Trying to act cool……This is all your fault.”
[cpg cn=true]


Michi was coming at me, but it didn’t seem like she was actually angry.
[cpg]

[VOICE f="sMichi011"]
[OnName num="michi"]
"I'll never forgive you if you don't love me seriously.”
[cpg cn=true]


[OnName num="youta"]
“I'm sure of it. I promise.”
[cpg cn=true]


[VOICE f="sMayuki030"]
[OnName num="mayuki"]
''That's very manly of you.''
[cpg cn=true]


Mayuki says this in a teasing way.
[cpg]

Even if they were actually teasing me, it was all because of my past actions.
[cpg]

Since I had been withholding my answer for a long time.
[cpg]


;**【ＣＧ】 ev_49_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMichi012"]
[OnName num="michi"]
“…… Mayuki, you're in a groove."
[cpg cn=true]


[VOICE f="sMayuki031"]
[OnName num="mayuki"]
“Because you’re my partner, Michi. If it was someone else, I wouldn't like this.”
[cpg cn=true]


I guess Mayuki has something to think about in her own way. There must be something in each other that they allow because they are best friends.
[cpg]

[VOICE f="sMichi013"]
[OnName num="michi"]
“I think it's ....... a little more complicated for me.”
[cpg cn=true]


And Michi seems to have her own thoughts on the matter. I felt sorry for her......
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト


Our daily life goes on with such conversations.
[cpg]

The three of us do everything together, and it's a strange day-to-day life.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『街』（昼）******************************************************





[OnName num="youta"]
“I'm sorry, I'm late. Thanks for waiting.”
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Michi154"]
[OnName num="michi"]
“You're late!”
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mayuki238"]
[OnName num="mayuki"]
"You get a penalty for being late. Maybe you could buy us something?”
[cpg cn=true]


We leave the house separately and meet at the appointed place.
[cpg]


Even when we are together, we do this when we are on a date. It's more date-like that way.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Michi155"]
[OnName num="michi"]
"How about matching accessories?”
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Mayuki239"]
[OnName num="mayuki"]
"Oh, that's good. Yota, let’s buy that one.”
[cpg cn=true]


They grabbed my arms as they say.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ（三人手を繋いでデート）ev_50
;//人物１：サブヒロイン１
;//服装１：私服
;//人物２：メインヒロイン
;//服装２：私服
;//人物３：主人公
;//服装３：私服
;//場所　：街
;//時間　：昼
;//========================================



[BGM f="bg_op"]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]





I was carrying a flower in each of my arms. But the stares from the people around me were a bit painful.
[cpg]


Two women in one man's arms. Of course, they'll think what kind of relationship this is?
[cpg]


[OnName num="youta"]
“……”
[cpg cn=true]



[VOICE f="Michi156"]
[OnName num="michi"]
"Don't worry about the stares."
[cpg cn=true]



[VOICE f="Mayuki240"]
[OnName num="mayuki"]
"Yeah. We're fine this way, I'm sure.”
[cpg cn=true]


What will happen to us? In Japan, it is not possible to have two wives.
[cpg]


I wonder if one day I will be able to choose one of them.
[cpg]


[OnName num="youta"]
“Yes. Someday..."
[cpg cn=true]



[VOICE f="Michi157"]
[OnName num="michi"]
“Well, someday….. I guess.”
[cpg cn=true]



[VOICE f="Mayuki241"]
[OnName num="mayuki"]
“But... it doesn't have to be now. Because... right now we’re having fun.”
[cpg cn=true]



[VOICE f="Michi158"]
[OnName num="michi"]
“Yes.”
[cpg cn=true]



[VOICE f="Mayuki242"]
[OnName num="mayuki"]
“You’re right!”
[cpg cn=true]


Then they both talk about how it's good, at least for now.
[cpg]


Like a couple of gals, I was caught on their idea of enjoying the moment.
[cpg]


[SCENE id=10]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：サブヒロイン１ルート



