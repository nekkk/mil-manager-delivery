;//２、清楚な格好になって欲しい

*start



;#################################################
*Ep005|I'll never forget the way she looked.
;#################################################

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]

*select05_2|I'll never forget the way she looked.

[SCENE id=5]


[OnName num="youta"]
“I was imagining what kind of a girl ...... Michi was going to be."
[cpg cn=true]


I've already made up my mind. I decided to say it.
[cpg]


Of course, I choose my words. I was thinking about what to say and what not to say.
[cpg]


[OnName num="youta"]
“I was expecting a more innocent girl, a girl who didn't play around, so I was ...... surprised.”
[cpg cn=true]


I was surprised. I won't say I didn't like it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi404"]
[OnName num="michi"]
“I see."
[cpg cn=true]


In fact, I even thought that my memories were shattered.
[cpg]


I'm not going to say anything about it though. I only said what I wanted to say.
[cpg]


[OnName num="youta"]
“Michi, did you become a gal because you wanted to?”
[cpg cn=true]


If she answered without hesitation, there was no problem.
[cpg]


But she didn't.
[cpg]


She didn't answer right away.
[cpg]


It was possible that she was lost in her own mind. Or rather, she was.
[cpg]


She might be thinking about how she wanted to be.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I might have said something I shouldn't have.
[cpg]


From then, it felt like our relation became more distant.
[cpg]


Of course we greeted each other at the school, but our smiles were a little forced.
[cpg]


We were in fact forcing a smile..
[cpg]


The relationship itself hasn't changed.
[cpg]

[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=1000]



;//========================================
;//●ＣＧ（ヒロイン仰向けで、主人公が迫る）ev_39
;//人物１：メインヒロイン
;//服装１：制服（はだけ）
;//人物２：主人公
;//服装２：制服
;//場所　：学園空き教室
;//時間　：夕方
;//========================================

[BGM f="bg_yu"]
;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_39_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]


Still, I felt a little uncomfortable.
[cpg]

When we were flirting like this, she sometimes looked a little pained.
[cpg]

[OnName num="youta"]
"Michi. Is something wrong?"
[cpg cn=true]


She looked away a little and replied.
[cpg]

[VOICE f="sMichi049"]
[OnName num="michi"]
“It's nothing…….”
[cpg cn=true]


I know why she would reply that way.
[cpg]

The first thing that I said was the start of it,......, and when I think about it, I too feel pain in my chest.
[cpg]

Still, to erase it, I say this.
[cpg]

[OnName num="youta"]
“I love you, Michi.”
[cpg cn=true]


I regret saying it, since it did sound a little forced.
[cpg]

I'm not lying about what I'm thinking, but there's no need to say it now.
[cpg]


;**【ＣＧ】 ev_39_a ***********************
[CG id=17 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMichi050"]
[OnName num="michi"]
"I'm sorry. I feel like I'm making you say it.”
[cpg cn=true]


[OnName num="youta"]
“Not at all. I really like you.”
[cpg cn=true]


We are not lying to each other. However, there is a slight miscommunication.
[cpg]

And in the midst of all this, there was silence once again.
[cpg]

It was Michi who broke the silence.
[cpg]

[VOICE f="sMichi051"]
[OnName num="michi"]
“Yota, do you dislike me as a gal? Do you think you're going to hate me?"
[cpg cn=true]


Michi asked with a slightly anxious look on her face.
[cpg]

It was an earnest question. But the answer to such a question was obvious.
[cpg]


;//移植のためシーンをカットしています



[window target=false]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_yu"]
;//[WAIT time=1000]
;//【ＢＧ】『学園教室』（夕方）******************************************************




[OnName num="youta"]
“I don't hate you.”
[cpg cn=true]


I said in a rather strong tone.
[cpg]


But Michi didn't seem convinced.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Michi420"]
[OnName num="michi"]
"Are you sure ……? I'll stop being a gal if you want me to change.”
[cpg cn=true]


Will Michi stop being a gal? 
[cpg]


The thought of it shook me up too. I couldn't answer right away.
[cpg]


[OnName num="youta"]
"...... it's ......"
[cpg cn=true]


If Michi would stop being a gal, that would make me happy.
[cpg]


If she can get closer to the Michi I envisioned.
[cpg]


But for her, becoming a gal is not something that happened yesterday or today.
[cpg]


I'm not going to be able to tell her to stop right away.
[cpg]


[OnName num="youta"]
“I don't have to give you an answer now, do I?”
[cpg cn=true]


;//考えた。考えたあげく……もう一度、美智を抱くことにした。
;//[cpg]


Michi doesn't even nod at my words. She's still waiting for me to say something.
[cpg]


I thought about it. After thinking about it, I decided to hug her again.
[cpg]


It was a half-hearted escape. Maybe Michi can see right through me. ......
[cpg]



;//ブラックアウト

;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


In the end I couldn't answer. Time passed as it did.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（朝）******************************************************





[OnName num="youta"]
“...... good morning.”
[cpg cn=true]


I read a look of determination on her face when I called out to her.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi436"]
[OnName num="michi"]
“Good morning. You know, Yota...... I've been thinking about it since then.”
[cpg cn=true]


I'm sure she will come up with some kind of answer here.
[cpg]


I listened to Michi with that thought in mind.
[cpg]


I listened with a serious expression on my face. Or rather, it came naturally. ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi437"]
[OnName num="michi"]
“I became a gal because I wanted to. I was also influenced by Mayuki."
[cpg cn=true]


She wanted to. So does that mean she doesn’t want to change?
[cpg]


Somewhere, I found myself thinking, "I knew it.”
[cpg]


I knew it. Then I'll just have to accept her as she is now. ......
[cpg]


[OnName num="youta"]
"All right. Then, that's fine.……"
[cpg cn=true]


Is this a bad way to put it? I continued.
[cpg]


[OnName num="youta"]
“I like you Michi just the way you are. That's why."
[cpg cn=true]


In the middle of these words, Michi continued to speak.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi438"]
[OnName num="michi"]
“But, if you want me to stop being a gal, I will stop. I'm prepared to do that."
[cpg cn=true]


[OnName num="youta"]
“Is that so……?”
[cpg cn=true]


Michi wanted to be a gal, so she became one. But She’s also prepared to stop because of me.
[cpg]


...... I see. I don't know how I'm supposed to answer that......
[cpg]


I can't even ask her to just stop being who she is in a light way.
[cpg]


[OnName num="youta"]
"...... I'm ......"
[cpg cn=true]


I can't continue. What do I want to do?
[cpg]


What words do I want to say to Michi?
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



After much hesitation, I decided to wait until after school to answer.
[cpg]


I thought about it for a while. No matter how many times I thought about it, I arrived at the same conclusion.
[cpg]


There is no more hesitation on my part. So, it's all right.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（夕方）******************************************************



[SE f="se014"]
;//【ＳＥ】『学園のチャイム』



Then, after school, I told Michi, 
[cpg]


[OnName num="youta"]
“You know what. I had a different ideal of you after all."
[cpg cn=true]


I start out with words like that. This might not get the message across.
[cpg]


In fact, it might give a bad impression. But I told her honestly.
[cpg]


[OnName num="youta"]
"I'm fine with it...... as long as you don't overdo it."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi439"]
[OnName num="michi"]
"Yeah, I understand. You don't have to tell me everything......We can go shopping for clothes when we don’t have school. My clothes."
[cpg cn=true]


Michi seemed to understand before I said everything.
[cpg]


She said she was ready for it. So I guess it's good.
[cpg]


I had mixed feelings. I wonder if this is okay. ......
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（昼）******************************************************



The day when we didn’t have school. We went to look at clothes.
[cpg]


[OnName num="youta"]
"...... Are you sure about this, Michi?”
[cpg cn=true]


I asked Michi again and again. She told me that I was being too annoying.
[cpg]


Still, I felt guilty.
[cpg]



;//店内ですので上下に黒帯をつけてください



We arrived at the store. I chose the clothes I wanted Michi to wear.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Michi440"]
[OnName num="michi"]
“I’m going to wear this?”
[cpg cn=true]


[OnName num="youta"]
“No?"
[cpg cn=true]


I had never picked out clothes for a girl before, and I think Michi was disappointed by my poor taste.
[cpg]


However, even though she was dismayed, I did not let it get the better of me.
[cpg]


It seems that Michi understood my intentions.
[cpg]


She took my intentions into account and chose clothes that were also in line with her own sense of style.
[cpg]



;//ここから黒帯を外してください


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Then we left the store.
[cpg]


She couldn't just change there. So we headed to Michi's room.
[cpg]


After changing her makeup and other things, she puts on the clothes. ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『メインヒロインの部屋』（昼）******************************************************



;//ここから美智の立ち絵を切り替えてください





[FG f="CHA01_p1_05_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Michi441"]
[OnName num="michi"]
“I don't know. Is it weird?”
[cpg cn=true]


[OnName num="youta"]
"It's ...... not weird.
[cpg cn=true]


It's not weird. In fact, I was struck by the way she looked.
[cpg]


I think this is what it really means to be lovestruck.
[cpg]


The childhood friend I had always envisioned was there.
[cpg]


If she had been dressed like this from the beginning, I might have confessed my feelings to her from the start.
[cpg]


[OnName num="youta"]
“You're so beautiful, Michi."
[cpg cn=true]


I said this to Michi with a bit of a stammer.
[cpg]


Michi seems to be uncomfortable with her outfit. That was also good.
[cpg]


[FG f="CHA01_p1_05_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi442"]
[OnName num="michi"]
“I don't know,......, it's kind of weird. Hey!”
[cpg cn=true]


[SE f=se004]
;//【ＳＥ】『衣擦れ』


[FG f="CHA01_p3_05_a.ui" method="change_5"  pos="2/3" time=800]
I couldn’t help myself but hold her tight.
[cpg]

;//移植のためシーンをカットしています

[FACE method="change_6" pos="2/3"]
[VOICE f="sMichi052"]
[OnName num="michi"]
“This may be the first time you have come on to me like this.”
[cpg cn=true]


[OnName num="youta"]
“I'm sorry ......."
[cpg cn=true]

I was apologizing, but I was happy that Michi had changed.
[cpg]


[FG f="CHA01_p1_05_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi458"]
[OnName num="michi"]
“I don't mind. It's worth the change.”
[cpg cn=true]


A beaming Michi. Then she scratches my cheek with her fingers.
[cpg]


I was happy that she felt that way.
[cpg]


In fact, I was crazy about her. I've always liked Michi, but ......
[cpg]


I love her now more than ever. I guess it's important to feel that she changed for me.
[cpg]

[FG f="CHA01_p1_05_a.ui" method="change_1"  pos="2/3" time=800]
I didn't know that clothes and makeup could change so much.
[cpg]


I never imagined it and I'm really fascinated......
[cpg]


[OnName num="youta"]
“You look really good ....... Michi."
[cpg cn=true]

[FG f="CHA01_p1_05_a.ui" method="change_6"  pos="2/3" time=800]
Michi is still shy. Maybe it's the feeling of being dressed in clothes.
[cpg]


But Michi doesn't have a silly way of talking or anything like that to begin with.
[cpg]


That's why she looks good in her current outfit. I felt like I could truly love her now.
[cpg]


Of course, I would have loved her with all my heart even in her original outfit. ......
[cpg]


Still, it was different. Men are simple creatures.
[cpg]


[OnName num="youta"]
“Can I kiss you, ......?"
[cpg cn=true]


The first thing to do is to make sure that you have a good time.
[cpg]


She must be surprised that I'm more aggressive than usual.
[cpg]


But I was about to become aggressive as well. ......
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ（キスをする二人。ヒロインに対して前のめりな感じの主人公）ev_42
;//人物１：メインヒロイン
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：メインヒロインの部屋
;//時間　：昼
;//備考　：メインヒロインの服装などは清楚になっています
;//========================================



[BGM f="bg_h2"]
;**【ＣＧ】 ev_42_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

[FACE method="change_1" pos="2/3"]
[VOICE f="sMichi053"]
[OnName num="michi"]
“I really feel like you’ve changed Yota.”
[cpg cn=true]


[OnName num="youta"]
"Maybe."
[cpg cn=true]


I said this and put my lips on hers.
[cpg]

From now on, I can stay with Michi forever. That idea hasn't changed.
[cpg]

I was feeling it even more because of the change in Michi.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMichi054"]
[OnName num="michi"]
“Hm......?”
[cpg cn=true]


I parted my lips and looked at her.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMichi055"]
[OnName num="michi"]
“You've gotten better at kissing.”
[cpg cn=true]


[OnName num="youta"]
“I don't know. I'm not aware of it.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMichi056"]
[OnName num="michi"]
“I think you've become more aggressive. I'm glad.”
[cpg cn=true]


Seeing Michi smiling like that makes me happy too.
[cpg]

I want to stay with her forever. I want her to stay close to me for as long as possible.
[cpg]

With this in mind, I kissed her again.
[cpg]

I don't think touching each other is the only way to fall in love. ......
[cpg]

The distance between us was undeniably closer.
[cpg]


;**【ＣＧ】 ev_42_a ***********************
[CG id=18 index=1 time=1000]
;***************************************
[WAIT time=1000]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMichi057"]
[OnName num="michi"]
“……Yota, I love you."
[cpg cn=true]


She looked at me and said this while looking embarrassed.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMichi058"]
[OnName num="michi"]
“I'd do anything you want.”
[cpg cn=true]


[OnName num="youta"]
“Yea.”
[cpg cn=true]


I nodded, accepting the favor.
[cpg]

She had changed for me. I want to be the kind of guy that Michi likes too.
[cpg]

If possible, I want to be a man worthy of her.
[cpg]

Well, that may be difficult, since Michi is too cute for me.
[cpg]

I wanted to be as manly as possible.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



And then... After that, Michi's appearance changed, and he stopped wearing her school uniform in a sloppy way.
[cpg]


People around her were in an uproar. Various rumors were flying around.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（朝）******************************************************




[FG f="CHA01_p1_04_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/2" time=800]
[VOICE f="Natuko239"]
[OnName num="natuko"]
“What's wrong? Is something wrong, Michi?”
[cpg cn=true]


Michi only laughed, but she was embarrassed.
[cpg]


I could hear the conversation, but I pretended not to be there.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Natuko240"]
[OnName num="natuko"]
"Did Yota say something to you......?"
[cpg cn=true]


I was listening to the conversation, thinking that was almost the right answer.
[cpg]


Michi seems to like her current outfit to some extent and ......
[cpg]


It seemed that she didn't feel bad about attracting the attention of those around her.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Natuko241"]
[OnName num="natuko"]
But even then, she was completely different. She no longer looked a gal.
[cpg cn=true]


At that time, Michi also seemed to be a little bit bewildered. But.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（夕方）******************************************************





After school, Mayuki went to Michi.
[cpg]


This time, too, Michi and Mayuki were talking one-on-one, and I was standing in a position where I could barely hear the conversation.
[cpg]


[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]

[VOICE f="Mayuki300"]
[OnName num="mayuki"]
"You're not a gal anymore?"
[cpg cn=true]


Mayuki was getting pretty fierce with Michi.
[cpg]


[FG f="CHA01_p1_04_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Michi474"]
[OnName num="michi"]
“I guess so."
[cpg cn=true]


The first thing that comes to mind is that Mayuki is not angry that Michi has stopped being a gal.
[cpg]


Simply, she is anxious about the future of Michi. And that's that.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/2" time=800]
[VOICE f="Mayuki301"]
[OnName num="mayuki"]
“Maybe you should think seriously about it. If you don't, you might end up being pushed around by Yota for the rest of your life.”
[cpg cn=true]


Mayuki says this, knowing that I am listening.
[cpg]


It was probably not malicious. Still, it was enough to annoy me and Michi.
[cpg]


I'm sure I'm just pushing Michi around.
[cpg]


I'm asking her to change, and she's changing, but I'm just holding her goodwill hostage.
[cpg]


Maybe this was a bad idea. I had no choice but to think about it seriously.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





[FG f="CHA01_p1_04_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi475"]
[OnName num="michi"]
“It’s hard to suddenly change.”
[cpg cn=true]


Michi took Mayuki's words pretty much head-on. So did I.
[cpg]


[OnName num="youta"]
“I like the current Michi. Is that not good enough for you, ......?"
[cpg cn=true]


I then asked.
[cpg]


But Michi didn't seem to be satisfied. It's not enough.
[cpg]


[OnName num="youta"]
“If we both have a mutual intention and want things to be this way, then we'll say so.”
[cpg cn=true]


“You’re right”,she says…… yet she still seems somewhat unconvinced.
[cpg]


Michi’s response seemed like she was not accepting the whole situation.
[cpg]


[OnName num="youta"]
“Isn’t it normal to change into the person the other expects to be?”
[cpg cn=true]


Am I being selfish? I wonder.......
[cpg]


I don't know. Maybe Michi didn't like me.
[cpg]


I thought so, but then Michi said something different from what I had imagined.
[cpg]


[FG f="CHA01_p1_04_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Michi476"]
[OnName num="michi"]
“Okay, I’ll tell you...... I thought your body would be much bigger and stronger.”
[cpg cn=true]


What was she talking about all of a sudden? I think while nodding.
[cpg]


[OnName num="youta"]
“I guess you mentioned that sometime ago.”
[cpg cn=true]


I was athletic, but that was when I was a kid.
[cpg]


Now I am not like that at all. My body has lost a lot of weight.
[cpg]


I can't say I have a good physique.
[cpg]


[FG f="CHA01_p1_04_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi477"]
[OnName num="michi"]
"Yota, don't you play sports anymore? I like men with a good physique.”
[cpg cn=true]


After hearing that much, I understood what Michi was trying to say.
[cpg]


...... I guess so. I had to force myself on Michi to change my figure.
[cpg]


I might have to change too, even if I have to force myself a little.
[cpg]


[OnName num="youta"]
“I understand. Leave it to me."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





From that point on, there was no hesitation.
[cpg]


I decided to join the track team. There was no deep reason why I chose track and field.
[cpg]


I didn't care what it was. I still have no interest in the sport itself.
[cpg]


When I thought about what kind of sports I was interested in, I thought maybe this one was it.
[cpg]


I wondered if I could build upper body muscles ......but there are no track and field athletes who are thin only at the upper body.
[cpg]


Thinking like that, I decided to change.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko242"]
[OnName num="natuko"]
“I heard that you joined the track team.”
[cpg cn=true]


Natsuko said. Rumors are quick to spread.
[cpg]


[OnName num="youta"]
"Yeah, I guess……”
[cpg cn=true]


Natsuko looked a little uneasy.
[cpg]


There are rumors about us. There are rumors about why I joined the track team.
[cpg]


One of them is that it must have happened because Michi wanted it to.
[cpg]


That's almost always the right answer. Natsuko said that she had heard that, too.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sNatuko016"]
[OnName num="natuko"]
“Michi is quite strange as well…….and it's not fun to try to fit in with your lover, is it?"
[cpg cn=true]


[OnName num="youta"]
“Well, it is fun.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
Natsuko was puzzled. I'm sure she'll never know about this until she falls in love.
[cpg]


With that in mind, I headed over to Michi, who waved her hand.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi478"]
[OnName num="michi"]
“You’re a little bigger now. Yes, I think you look good.”
[cpg cn=true]


She touches my body to check me out.
[cpg]


[OnName num="youta"]
“You’ll have to pay me back for changing you."
[cpg cn=true]



[SE f=se004]
;//【ＳＥ】『衣擦れ』
[FG f="CHA01_p3_04_a.ui" method="change_2"  pos="2/3" time=800]


While saying this, Michi hugs me.
[cpg]


[FG f="CHA01_p3_04_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi479"]
[OnName num="michi"]
“Ha…..this kind of thing is kind of nice.”
[cpg cn=true]


[OnName num="youta"]
“Yeah, you’re right.”
[cpg cn=true]


I don't know if Michi and I are thinking the exact same thing.
[cpg]


[OnName num="youta"]
“It's great to become ideal in the eyes of the person you love”
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
So she was thinking a similar thing.
[cpg]


[FACE method="change_6" pos="2/3"]
Maybe I went a little overboard. Michi blushed.
[cpg]

;//移植のためシーンをカットしています


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//【ＢＧ】『学園教室』（夜）

Some days passed from there.
[cpg]

Time passed and ...... it was sports festival season.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************


I was still on the track team and apparently had some talent.
[cpg]

I think I became so muscular that even I could tell. Michi liked me that way.
[cpg]

[FG f="CHA01_p1_04_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="sMichi059"]
[OnName num="michi"]
“Mayuki, you’re still not cutting your hair. Are you growing it out?”
[cpg cn=true]


[FACE method="change_6" pos="2/2"]
[VOICE f="sMayuki040"]
[OnName num="mayuki"]
“Well, sort of.”
[cpg cn=true]


Mayuki looked a little embarrassed when she said that, and I guessed that she might have found someone she liked.
[cpg]

Even someone as strong as Mayuki may change for the sake of someone she loves.
[cpg]

[FACE method="change_2" pos="1/2"]
[VOICE f="sMichi060"]
[OnName num="michi"]
“Do you have a lover? Is it your lovers preference?”
[cpg cn=true]


[FACE method="change_5" pos="2/2"]
[VOICE f="sMayuki041"]
[OnName num="mayuki"]
“No, you idiots! Don't say that!!”
[cpg cn=true]


Mayuki overreacts. The two of them are as close as ever.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園図書室』（昼）******************************************************

I was also interacting with Natsuko as usual.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sNatuko017"]
[OnName num="natuko"]
“You’ve been doing track and field for a while now, haven't you?”
[cpg cn=true]


[OnName num="youta"]
“It’s almost sports festival soon, so I guess I'll be showing off my skills.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sNatuko018"]
[OnName num="natuko"]
“Yea I guess we will see those talented legs of yours.”
[cpg cn=true]


While talking about such things, Natsuko also has some differences from before.
[cpg]

[OnName num="youta"]
"I see you've started reading ...... manga.”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sNatuko019"]
[OnName num="natuko"]
“Yes, well, ……"
[cpg cn=true]


I don't think she would have read them before. So, Natsuko also......
[cpg]

[OnName num="youta"]
“Did you start reading them because of someone else's influence?”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sNatuko020"]
[OnName num="natuko"]
“How can you tell? It was my brother's influence.”
[cpg cn=true]


Her older brother. I didn't know she had an older brother.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="sNatuko021"]
[OnName num="natuko"]
“It's been less than a year, but everyone has changed. ...... I seem to be the only one left behind.”
[cpg cn=true]


[OnName num="youta"]
"I wonder if that's true. I haven't changed much, have I?”
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sNatuko022"]
[OnName num="natuko"]
"You've changed. You’re better looking than before.”
[cpg cn=true]


There seems to be a deeper meaning in the way she says that....... I guess there are some things that haven't changed.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（夕方）******************************************************

[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMichi061"]
[OnName num="michi"]
“The sports festival is coming up soon. Are you going to participate in the relay?”
[cpg cn=true]


[OnName num="youta"]
"Yea. As a track team member, I can't lose.”
[cpg cn=true]


Relay. The relay is a relay between the sport clubs, and each division has its own handicap.
[cpg]

Of course, the track and field club is a specialized club, so the handicap is the toughest. ......
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="sMichi062"]
[OnName num="michi"]
“Good luck. I'll be cheering for you.”
[cpg cn=true]


[OnName num="youta"]
“What are you going to compete in, Michi?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMichi063"]
[OnName num="michi"]
"Uh, scavenger hunt race? I think.”
[cpg cn=true]


[OnName num="youta"]
“That is very you.”
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sMichi064"]
[OnName num="michi"]
“What if the paper says ‘your lover’”
[cpg cn=true]


[OnName num="youta"]
“Would someone really write something that risky?”
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The day of the festival was approaching as we talked about what we were going to do.
[cpg]

I felt it was a little childish when Michi made me a good luck charm so that I wouldn't get hurt. ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

The day before the sports festival, I was sorting through old photos.
[cpg]

I was thinking that if both Michi and I had changed, it would be good to see if that was really the case……
[cpg]

Among it, there was a picture of Michi and me. ...... I couldn't help but stare at it.
[cpg]

There were pictures of her being a gal and of her being properly dressed. But I still think that the current Michi is the most beautiful.
[cpg]

Well, thinking she's beautiful in her childhood pictures, is a little inappropriate……
[cpg]

But still, the fact that the two of us are in the picture means that Michi probably has this picture too.
[cpg]

I wonder if she still treasures this.
[cpg]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[BGM f="bg_gy"]

And then, the day of the sports festival.
[cpg]

Our track team came in second in the relay race. Because ......
[cpg]

;//[FG f="CHA01_p1_04_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sMichi065"]
[OnName num="michi"]
“Thats unfair. Of course there will be people that are faster in the other team if you include the guys who don’t participate in a school club.”
[cpg cn=true]


This year, the people who are not part of a club were to compete as one team.
[cpg]

I wasn't sure how to give them a handicap, and I ended up winning.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="sMichi066"]
[OnName num="michi"]
“But I'm going to get revenge. In the scavenger hunt race.”
[cpg cn=true]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（夕方）******************************************************

And then the festival ended.
[cpg]

As she had declared, Michi had won first place in the scavenger hunt race……
[cpg]

[OnName num="youta"]
“What did the paper say?”
[cpg cn=true]


[FG f="CHA01_p1_04_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMichi067"]
[OnName num="michi"]
“‘A picture’. I guess no one has a paper photograph.”
[cpg cn=true]


[OnName num="youta"]
“You do?”
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sMichi068"]
[OnName num="michi"]
“Just in case. You know, as a good luck charm?”
[cpg cn=true]


[OnName num="youta"]
"Oh, the one you gave me the other day?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMichi069"]
[OnName num="michi"]
"That ...... I actually made one for myself too.”
[cpg cn=true]


She pulled out the good luck charm from her bag.
[cpg]

When I opened the seal, I found ...... a folded photograph.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="sMichi070"]
[OnName num="michi"]
"I had a bunch of them, so I thought I might as well fold a couple of them."
[cpg cn=true]


It was the same photo I had been sorting through sometime ago.
[cpg]

I thought it was a coincidence that she was organizing the photos with a similar thought in mind.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMichi071"]
[OnName num="michi"]
“I think you and I have both grown up……"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sMichi072"]
[OnName num="michi"]
“Changing is not a bad thing, right?”
[cpg cn=true]


[OnName num="youta"]
“I agree."
[cpg cn=true]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


The gymnastics festival was somewhat of a symbolic event. I wondered if it would have been different if I could have changed more.
[cpg]

I want to be more of an ideal lover for Michi. I thought so.
[cpg]


[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_d1"]
[WAIT time=1000]

;//========================================
;//●ＣＧ（腕を組んで歩く二人。互いに笑顔で、ヒロインは主人公に寄り添っている）ev_45
;//人物１：メインヒロイン
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：街
;//時間　：昼
;//備考　：メインヒロインの服装などは清楚になっています
;//========================================


;**【ＣＧ】 ev_45_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]


From that day on we spent our time together as compatible lovers.
[cpg]


I love Michi. Michi loves me.
[cpg]


I will change for her. She will change for me.
[cpg]


I didn't see that as pain at all.
[cpg]


[VOICE f="Michi511"]
[OnName num="michi"]
“ When I'm with you Yota, everything is fun.”
[cpg cn=true]


She said, but I felt the same way.
[cpg]


It's fun no matter what we do. No matter what we look like. There is no doubt about that.
[cpg]


Maybe it would have been fine if Michi had remained a gal.
[cpg]


But if there is something I want her to change, I have to tell her.
[cpg]


It takes courage to do so, but I felt that if I didn't say so, we would become strangers.
[cpg]


Becoming a stranger might be an overstatement,...... but I don't want to become a cold lover.
[cpg]


[OnName num="youta"]
“I'm having fun too."
[cpg cn=true]


We walk together, arm in arm, cuddling.
[cpg]


I'm sure we'll continue to change into whatever shape we want the other person to be.
[cpg]


They say that couples look alike. That's the reason, isn't it?
[cpg]



[VOICE f="Michi512"]
[OnName num="michi"]
“I want to be a better girlfriend. And one day a better wife.”
[cpg cn=true]


Michi says something that makes me startle. It's a surprise, and it's not fair.
[cpg]


I decided to return the favor by saying,
[cpg]


[OnName num="youta"]
"Me too. I need to be a better husband, too.”
[cpg cn=true]



[VOICE f="Michi513"]
[OnName num="michi"]
“Hmmm…..you're right. We’ll be together forever Yota.”
[cpg cn=true]


[SCENE id=9]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[jump storage="epend.ks" target="*start"]

;//ＥＮＤ：メインヒロインルート２



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


