
;//２、考えさせて欲しい

*start


;#################################################
*Ep003|I can't accept Michi for the way she is.
;#################################################


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]


*select02_2|I can't accept Michi for the way she is.

[SCENE id=3]

[OnName num="youta"]
“Let me think about it. I still need time."
[cpg cn=true]


I couldn't give her an answer right away.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi097"]
[OnName num="michi"]
"I see. I can wait as long as you want. I've been waiting a long time."
[cpg cn=true]


I feel sorry, but I can't answer right away.
[cpg]


And I feel sorry for Michi. But I couldn't say anything else.
[cpg]


[OnName num="youta"]
“Sorry ......, but I ……."
[cpg cn=true]


I'm at a loss for words. I can't say anything.
[cpg]


I am still in shock that she became a gal.
[cpg]


There was also the fact that Michi was the one who approached me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi098"]
[OnName num="michi"]
“I know I forced you. I know, I know......"
[cpg cn=true]


Michi looked in pain. It would be good if I could hug her here.
[cpg]


But I couldn't do that. It's not something that should be done lightly.
[cpg]


It's something I should do only after I've fallen in love with her.
[cpg]


Right now, I couldn't say that I really liked her.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************





Everyone seemed to know that there was an awkward distance between us.
[cpg]


It wasn't about where it was said or who said it. The fact is, we are at an awkward distance.
[cpg]


I guess that's what people around us already know.
[cpg]


It means it didn't spread in the form of rumors or anything like that. ......
[cpg]


[OnName num="youta"]
“……Is Michi, taking the day off?"
[cpg cn=true]


Her seat is empty. No one is there.
[cpg]


Did she catch a cold? Or maybe she was shocked by what I said to her.
[cpg]


I may have said something terrible to Michi.
[cpg]


Maybe I had stepped on her past feelings.
[cpg]


Either way, I can't change my attitude toward Michi.
[cpg]


It can't be helped, I thought to myself. Although it felt like I was trying to justify myself.
[cpg]


But one day I should be able to give an answer.
[cpg]


While I was thinking that, that girl from before talked to me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayuki009"]
[OnName num="mayuki"]
“Hey. I heard you and Michi kind of awkward right now?"
[cpg cn=true]


A carefree smile. It wasn't a sarcastic remark towards me.
[cpg]


It's too straightforward to be sarcastic, and I don't think that was her intention in the first place.
[cpg]


[OnName num="youta"]
“You seem very positive today as usual Mayuki.”
[cpg cn=true]


I was sarcastic on the contrary. I didn’t want anyone to carelessly get into my business.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki010"]
[OnName num="mayuki"]
“Well, you know. That’s my only strength.”
[cpg cn=true]


However, Mayuki did not seem to mind.
[cpg]


It's not like she had anything else to offer. She came to such a progressive school.
[cpg]


Mayuki must be pretty smart too. I guess that's why she says things like that to me.
[cpg]


[OnName num="youta"]
“So what's up? What do you want?”
[cpg cn=true]


I ask Mayuki what she wants. Then, she said something unexpected.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayuki011"]
[OnName num="mayuki"]
“Look. If you're not going out with Michi, then how about going out with me?”
[cpg cn=true]


[OnName num="youta"]
"Huh ......?"
[cpg cn=true]


I had no idea what she was talking about. I couldn't help but make a crazy noise.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki012"]
[OnName num="mayuki"]
“It was love at first sight. I’m serious.”
[cpg cn=true]


Love at first sight. How could I trust such a word? That’s what I thought.
[cpg]


[OnName num="youta"]
"Are you serious......?"
[cpg cn=true]


I asked as Mayuki nodded.
[cpg]


[OnName num="youta"]
“If you're serious, I can't answer you. I have Michi ......."
[cpg cn=true]


Do I have Michi? I'm not even dating her yet.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayuki013"]
[OnName num="mayuki"]
“There is no way that you can’t answer. I guess I tried.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


Mayuki was more forceful than I had imagined.
[cpg]


;//移植のためシーンをカットしています

[VOICE f="sMayuki001"]
[OnName num="mayuki"]
"You are rather muscular.”
[cpg cn=true]


She said that and her fingers touched my body.
[cpg]

Even if Michi was gone, it would be bad if someone found out about this……
[cpg]


;//ブラックアウト


[SE f=se008]
;//【ＳＥ】『走る』


[VOICE f="sMayuki002"]
[OnName num="mayuki"]
“Hey, wait!"
[cpg cn=true]



;//ブラックアウト

I thought of Michi and ran away.
[cpg]


Really, this is no good. I haven't given a proper answer to Michi.
[cpg]


It wasn't even cheating yet. But still, I knew I shouldn't have done it.
[cpg]


With that feeling, I ran away...
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園図書室』（夕方）******************************************************





Somehow I couldn't stay in the same classroom with Mayuki.
[cpg]


No, there is no such thing as somehow. There is a good reason.
[cpg]


I was forced to be with her. I wanted to pretend that I was.
[cpg]


That's why I couldn't stay with Mayuki. After school, I went to the library right away. Then I saw ......
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
I saw someone who was following me. It was Natsuko.
[cpg]


I wasn't sure if I should talk to her or not, but ......
[cpg]


I wanted to talk to someone about it. I'm sure Natsuko would understand how a girl feels.
[cpg]


[OnName num="youta"]
"...... Do you like the library?”
[cpg cn=true]


I start the conversation with a casual question.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuko008"]
[OnName num="natuko"]
“Umm…..yea….”
[cpg cn=true]


Natsuko looks uncomfortable. She's probably already heard about Michi and I.
[cpg]


I thought she was the right person to talk to. I thought she was the only person I could talk to.
[cpg]


And then, I started to talk to her.
[cpg]


[OnName num="youta"]
“I need some advice.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko009"]
[OnName num="natuko"]
"You mean about ...... Michi?”
[cpg cn=true]


Natsuko seemed to have some idea of what I was talking about.
[cpg]


It is about Michi…….but also not really.
[cpg]


[OnName num="youta"]
"Oh, no. I mean something more simple than that, something about how girls feel."
[cpg cn=true]


Natsuko was silently listening to what I had to say.
[cpg]


I took advantage of this and continued to speak.
[cpg]


[OnName num="youta"]
“I like girls who are sophisticated like you, But ......"
[cpg cn=true]


When I said that, Natsuko's face turned red.
[cpg]


Did I say something unnecessary or ……? Was I being thought-provoking?
[cpg]


Was it too much to say that? I don't think so.
[cpg]


Thinking so, I talk to Natsuko.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[OnName num="youta"]
“......Michi is a gal. I wonder if it was something she did to get me to like her."
[cpg cn=true]


I said my main concerns all at once. Then Natsuko said.
[cpg]



[VOICE f="Natuko010"]
[OnName num="natuko"]
“I don't know, but if she’s been thinking about you for a long time, then I guess so......"
[cpg cn=true]


She replied, but she doesn’t look me in the eye.
[cpg]


When our eyes met, her face turned red. I guess I said this the wrong way. ......
[cpg]


I wasn't that popular, but how did this happen?
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





The next day. It was Saturday, so I went out at random.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Michi099"]
[OnName num="michi"]
“Oh.”
[cpg cn=true]


[OnName num="youta"]
“Oh."
[cpg cn=true]


And even though we were going out at random, we seemed to be heading to a similar place.
[cpg]


Michi and I ended up seeing each other. It was awkward.
[cpg]


[OnName num="youta"]
"...... How is your cold?”
[cpg cn=true]


It might not be a cold. But I still asked her.
[cpg]


If it was not a cold, I wanted to give her a way out.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi100"]
[OnName num="michi"]
"Ummm, yes. Well, they say that idiots don't catch colds.”
[cpg cn=true]


She’s not stupid. Rather the opposite.
[cpg]


[OnName num="youta"]
"You're smart, aren't you?……You are studious.”
[cpg cn=true]


If she weren't, she wouldn't have gotten into this school.
[cpg]


I wanted to say something like that, but Michi said,
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi101"]
[OnName num="michi"]
“That’s not true. I’m an idiot, I am."
[cpg cn=true]


She said it in a very implicit way.
[cpg]


I wanted to say something, but I couldn't go any further.
[cpg]


An awkward silence fell. Then, Michi began to talk.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi102"]
[OnName num="michi"]
“Hey, wanna go karaoke?”
[cpg cn=true]


[OnName num="youta"]
"Oh, yeah, let's go......"
[cpg cn=true]


It was awkward to stand there and talk any longer, so I decided to go along with the conversation.
[cpg]


I felt that not saying anything would make the situation worse. So, it was just perfect.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





So, karaoke. I felt like it had been quite a while since I had been here.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『カラオケ店個室内』（昼）******************************************************





Michi was a good singer. I guess she likes karaoke, she seemed to be used to it.
[cpg]


No kidding, I think she sang better than most people.
[cpg]


I applauded and Michi looked embarrassed.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi103"]
[OnName num="michi"]
"...... I'm sorry about the other night. I forced myself on you."
[cpg cn=true]


And then Michi apologized. I was caught off guard and immediately responded.
[cpg]


[OnName num="youta"]
“It’s okay. I'm sorry too.”
[cpg cn=true]


I was indecisive, too. If I couldn't do it, I should have said so.
[cpg]


But I still think I'm caught in the middle of my own feelings.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi104"]
[OnName num="michi"]
“Just think about it. After that, if you like me, I'd be happy if you told me so.”
[cpg cn=true]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





And then I say goodbye to Michi. It's kind of frustrating. ......
[cpg]


I wonder if this distance will continue forever. If so, it's hell.
[cpg]


Of course it's easy for me to try to close the distance.
[cpg]


I accept her confession. That's really all I need to do.
[cpg]


But that means I had to accept her as a gal.
[cpg]


It means accepting the parts of her I don't like...
[cpg]


I could tell her directly to dress more neatly.
[cpg]


But I don't have the courage to do that ....... I'm afraid she won't like me.
[cpg]


I guess I'm a loser to any extent.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（朝）******************************************************





The next day, Sunday, I wandered out again.
[cpg]


I don't think Michi would come to the same kind of place twice. She might try to avoid meeting me.
[cpg]


Just when I thought I would not meet with Michi this time.
[cpg]


I met someone else ..... someone I didn't really want to meet.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki031"]
[OnName num="mayuki"]
“Hey there, if it isn’t Yota.”
[cpg cn=true]


Mayuki greeted me lightly. She is not a person with whom I had nothing to do.
[cpg]


I was a little nervous just talking to her, or rather, I remembered that time.
[cpg]


[OnName num="youta"]
“Good morning ....... You're an early bird.”
[cpg cn=true]


I greeted her with that, and Mayuki said.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayuki032"]
[OnName num="mayuki"]
“Gals wake up early. Or so I think.”
[cpg cn=true]


I don't know about that.
[cpg]


I think she wakes up rather late. I have the impression that she wakes up around noon.
[cpg]


But I'm sure that's not the case with Michi……..I think.......
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki033"]
[OnName num="mayuki"]
“Are you busy right now? If not, let's go somewhere together”
[cpg cn=true]


I don't have anything special to do. But……
[cpg]


[OnName num="youta"]
“I don't see any reason to go out with you...”
[cpg cn=true]


[OnName num="youta"]
“I'm not even your lover to begin with, and besides..."
[cpg cn=true]


As I was about to finish my sentence, Mayuki sighed.
[cpg]


Mayuki put her hand on her waist and made an exasperated face.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sMayuki003"]
[OnName num="mayuki"]
“You are so hard to get. You're not dating Michi, are you?"
[cpg cn=true]


[OnName num="youta"]
“…… that's ……."
[cpg cn=true]


It's hard to deny that... but I have to tell her properly.
[cpg]


[OnName num="youta"]
“But still……."
[cpg cn=true]


Hearing that, Mayuki grinned and came closer to my ear,
[cpg]


[FG f="CHA02_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sMayuki004"]
[OnName num="mayuki"]
“You’re not that bad. How about I tell Michi for you?”
[cpg cn=true]


She whispers in my ear. How could I turn her down…..?
[cpg]


She is sly to the core. But I thought it might be true that she was in love with me.
[cpg]


Otherwise, there would be no reason for her to go this far.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『カラオケ店個室内』（昼）******************************************************


And then, oddly enough, she took me to a karaoke bar.
[cpg]

[OnName num="youta"]
“...... Are you jealous of Michi?"
[cpg cn=true]


I ask her. Mayuki doesn't seem to be offended.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki054"]
[OnName num="mayuki"]
“Well, I guess that's about it. I really like you Yota, you know?
[cpg cn=true]


She answers. I wonder if she doesn't feel any guilt toward Michi.
[cpg]


[OnName num="youta"]
“When did you fall in love with me? You don’t even really know me.”
[cpg cn=true]


[OnName num="youta"]
“It's crazy to fall in love with someone when you don’t even know their personality.”
[cpg cn=true]


Mayuki shakes her head. Then.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mayuki055"]
[OnName num="mayuki"]
“I told you it was love at first sight.”
[cpg cn=true]


She says so again. But still, that doesn't explain everything.
[cpg]


Objectively speaking, I don't have a very good looking face.
[cpg]


I'm just average. Maybe worse than average.
[cpg]


[OnName num="youta"]
“Is that really all there is to it? I've never been told that someone liked the way I look.”
[cpg cn=true]


Mayuki puts her finger under her chin and says, “Hmmm". And then she says what she really means.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayuki056"]
[OnName num="mayuki"]
“And, you know, Michi told me she's been waiting for someone shes liked for a long time.”
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayuki057"]
[OnName num="mayuki"]
“I had been wondering about you too this whole time.”
[cpg cn=true]


The situation was not something I could exactly comprehend. But isn't it strange?
[cpg]


How is that possible? I couldn’t believe that she became interested in me just by hearing Michi’s stories.
[cpg]


Mayuki is a friend of Michi's, right? I wonder if she had thought about that.
[cpg]


Is she really a friend of Michi's? There is a part of me that doubts it.
[cpg]


But ...... there's no point in doubting that, is there?
[cpg]


There was no way to be sure. It’s not like Michi was here now.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sMayuki005"]
[OnName num="mayuki"]
“I guess you’re more of a late bloomer. Am I not that attractive to you?”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



Saying that….
[cpg]




;//========================================
;//●ＣＧ（お尻を突き出して振り返っているヒロイン）ev_09
;//人物１：サブヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：カラオケ店個室内
;//時間　：昼
;//========================================

[BGM f="bg_h1"]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]



She turned her back to me and twisted her head and face towards me.
[cpg]

I asked her, not understanding her intention in being in that position.
[cpg]

[OnName num="youta"]
“What do you mean ......?"
[cpg cn=true]


In response to my question, Mayuki looked a little taken aback.
[cpg]

[VOICE f="sMayuki006"]
[OnName num="mayuki"]
“I've just told you. I was just trying to look a little sexy.”
[cpg cn=true]


I thought she was not only sexy, but also very attractive. But I don’t do anything.
[cpg]

I think she's playing a joke on me. But since I know what she's trying to do, I'm not fooled.
[cpg]

[OnName num="youta"]
“You shouldn't do that to anyone."
[cpg cn=true]


I said this as a warning to her, and she replies,
[cpg]

[VOICE f="sMayuki007"]
[OnName num="mayuki"]
“I told you that I don't do that to anyone.”
[cpg cn=true]


Mayuki says so, but I don't know.
[cpg]

Love at first sight is something you can say about anyone...
[cpg]

After all, it's something that doesn't need a reason.
[cpg]


;**【ＣＧ】 ev_09_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMayuki008"]
[OnName num="mayuki"]
“Well, if you don't feel like it, that's okay too.”
[cpg cn=true]


[OnName num="youta"]
“It's not about mood or anything like that.”
[cpg cn=true]


[VOICE f="sMayuki009"]
[OnName num="mayuki"]
“I don't want to force you or anything like that.”
[cpg cn=true]


I don't know if that's true or not.
[cpg]

I thought if I hesitated to respond, it would happen one day.
[cpg]

If I'm going to decide on my relationship status with Michi, I need to do it soon……
[cpg]


;//移植のためシーンをカットしています



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayuki077"]
[OnName num="mayuki"]
“Anyways I’ll see you around. I'll keep quiet to Michi, okay?"
[cpg cn=true]


...... Yes. The most important thing is the story of Michi.
[cpg]


Whatever happened with Mayuki is like a detour.
[cpg]


What will I say to Michi? Or rather, how do I feel about Michi?
[cpg]


I had to think about it a little more.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（朝）******************************************************





The next day, I headed back to the school.
[cpg]


Shall I talk to Michi directly? Rather...
[cpg]


I had another idea. There was no one I could talk to about it.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=1000]
;//【ＢＧ】『学園図書室』（昼）******************************************************





[OnName num="youta"]
”Natsuko... The other day... a girl named Mayuki was coming on to me.”
[cpg cn=true]


She did not ask who Mayuki was.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuko011"]
[OnName num="natuko"]
"Oh, I see... so what happened?"
[cpg cn=true]


I decided to be honest. I wanted to at least tell her what was going on and talk to her about it.
[cpg]


[OnName num="youta"]
“I couldn't refuse. Even though I have Michi......."
[cpg cn=true]


These words too, seemed somewhat superficial. It’s not like I'm in a relationship with Michi.
[cpg]


[OnName num="youta"]
“I feel like I'm having an affair with someone when I'm not even dating yet."
[cpg cn=true]


And so I came to this conclusion.
[cpg]


As we continued to discuss things, little by little, Natsuko and I grew closer.
[cpg]


Of course, only as a friend.
[cpg]


If I got into a strange relationship with her, I would not be able to go back to how things are now.
[cpg]


Of course, there is a possibility of that, but ......
[cpg]


There was no one else to ask about a girl's feelings.
[cpg]


[OnName num="youta"]
“I don't know what Mayuki is thinking.”
[cpg cn=true]


As a matter of fact, I still can't be sure if Mayuki really likes me or not.
[cpg]


I mean, I still don't even know how Michi became a gal...
[cpg]


[OnName num="youta"]
“No, neither do I know that about Michi. ...... I don't know how girls feel."
[cpg cn=true]


I said and looked down. Then Natsuko says
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Natuko012"]
[OnName num="natuko"]
“I'm sure you don't...... Including how I feel.”
[cpg cn=true]


She says something that really struck me. I look up.
[cpg]


[OnName num="youta"]
“What?"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko013"]
[OnName num="natuko"]
“..... it's nothing. Well then, lunch break is over, so I'll see you around……."
[cpg cn=true]


After saying that, Natsuko left the place.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（夕方）******************************************************





Natsuko had a strange attitude. It's not like she even has a thing for me, right?
[cpg]


Is there a possibility ......?
[cpg]


No, no, I don't have a good face. It shouldn't be love at first sight.
[cpg]


I can't think of a timing where she would have began to like me. Is there?
[cpg]


I also said I liked girls like Natsuko. That might not have been a good idea.
[cpg]


It wasn't love at first sight, but I may have given the impression that I had feelings for her.
[cpg]


Maybe I shouldn't talk to Natsuko anymore. That's what I thought.
[cpg]


I have no one else to talk to. At the very least, I need to let her know that I don't want to go out with her.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（朝）******************************************************





The next day, I thought about it again.
[cpg]


It was the morning. Michi came to the school as usual.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi105"]
[OnName num="michi"]
"Good morning, Yota...... have you thought about your answer?"
[cpg cn=true]


I didn't have an answer. But I wanted to let her know I was thinking about it.
[cpg]


[OnName num="youta"]
"......Yes, I'm thinking about it.”
[cpg cn=true]


I answered. I was afraid that Michi would get angry with me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi106"]
[OnName num="michi"]
"I see, that's all right then.”
[cpg cn=true]


Michi replied gently. Michi is acting cheerful.
[cpg]


And I am also acting cheerful.
[cpg]


But behind that, we are both holding something frustrating in our hearts.
[cpg]


I wondered if it was okay for us to continue going out. I was thinking about it.
[cpg]


Michi wants to go out with me. It's natural to feel frustrated...
[cpg]


And I didn't want this situation to continue for too long either.
[cpg]


It's frustrating. If I’m going to push her away, I might as well just push away completely.
[cpg]


And yet, we can't do anything about it. ......We're stuck with each other.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園図書室』（昼）******************************************************





I was on my way to the library, as is my routine.
[cpg]


I knew there was something strange in the air, but I knew I wasn’t making a mistake.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuko014"]
[OnName num="natuko"]
"...... how girls feel, right? I don't know either.”
[cpg cn=true]


Natsuko replied, as we continued my consultation from the other day.
[cpg]


[OnName num="youta"]
“What do you mean you don't know either? You mean you don't know how you feel?”
[cpg cn=true]


I talked with Natsuko. As we get deeper into conversation, the atmosphere became strange.
[cpg]


She had a strange tint on her cheeks. I didn't really understand what she was thinking about me at the time.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Natuko015"]
[OnName num="natuko"]
“I can't ...... sort out my feelings. My feelings for you, Yota.”
[cpg cn=true]


But when she told me, I knew that my hunch was right.
[cpg]


I am puzzled, even though it was expected.
[cpg]


The reality is that there was a good possibility of this. I said something suggestive, too.
[cpg]


[OnName num="youta"]
I"I'm sorry, ……, but I'm ......."
[cpg cn=true]


I wanted to continue with my refusal. But before I could do that.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko016"]
[OnName num="natuko"]
"...... Yota. Please come over here."
[cpg cn=true]


Natsuko stood up and said to me.
[cpg]


[OnName num="youta"]
"What is it?”
[cpg cn=true]


I stood up too. I was wondering what she was going to do to me.
[cpg]


Natsuko kissed me on the cheek.
[cpg]


[OnName num="youta"]
“……!"
[cpg cn=true]


This is not good. This is also the same as with Mayuki.
[cpg]


This is the only condition that must be avoided.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Natuko017"]
[OnName num="natuko"]
“I ...... can't take it anymore. There is nothing more painful than being asked for relationship advice by someone you love.”
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





And then I was almost taken by the hand and brought to the back of the school.
[cpg]

[OnName num="youta"]
"Hey,......let go of my hand."
[cpg cn=true]


I verbally refused, thinking she was more aggressive than I had imagined.
[cpg]

But she didn't shake my hand off.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[VOICE f="sNatuko001"]
[OnName num="natuko"]
“No one will come in here, right?"
[cpg cn=true]


We come to the back of the school and she faces me again.
[cpg]

She looks like she wants to say something. But I couldn't just wait.
[cpg]



[OnName num="youta"]
“...... lunch break is over, Natsuko."
[cpg cn=true]


Natsuko shook her head. As if to say that she doesn’t care.
[cpg]



[VOICE f="Natuko037"]
[OnName num="natuko"]
“It's okay, I was getting tired of being such a ...... serious honor student."
[cpg cn=true]


She apparently has been that way for a long time.
[cpg]


[OnName num="youta"]
“I see......."
[cpg cn=true]


Natsuko seemed to be quite frustrated as well.
[cpg]


I guess she became like this after I asked her for advice many times.
[cpg]


It was my fault. I've been doing unnecessary things all along.
[cpg]


Everything I did seemed to be backfiring.
[cpg]




;//========================================
;//●ＣＧ（主人公のすぐ前に居るヒロイン。すこし振り返っている。背景が変わってます）ev_11
;//人物１：サブヒロイン２
;//服装１：制服（はだけ）
;//人物２：主人公
;//服装２：制服
;//場所　：学園裏
;//時間　：昼
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_11_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


And then Natsuko turned her back on me.
[cpg]

I thought she was done with me, but she didn't seem to be.
[cpg]

[VOICE f="sNatuko002"]
[OnName num="natuko"]
"...... please. Can you give me a hug?"
[cpg cn=true]


Natsuko looked pained as she said that
[cpg]

[VOICE f="sNatuko003"]
[OnName num="natuko"]
“That will make it bearable. I'm sure."
[cpg cn=true]


I was lost, but I knew what would happen if I didn’t do anything.
[cpg]

But at the same time, I also have the feeling that if Michi and Mayuki see me in such a place, they will .......
[cpg]

I am lost. If only I had a little more decisiveness.
[cpg]

[OnName num="youta"]
“……”
[cpg cn=true]


Cursing my indecision, I stretched my arms around her body.
[cpg]

I feel her body heat. I could feel it getting hotter.
[cpg]

[VOICE f="sNatuko004"]
[OnName num="natuko"]
"......Yes, just keep holding me.”
[cpg cn=true]


I had touched her body, just a little.
[cpg]

I wouldn’t call it a hug, and then,
[cpg]


[SE f=se000]
;//【ＳＥ】『学園のチャイム』

The bell for the start of class rang. I thought I was saved.
[cpg]

[OnName num="youta"]
"......, let's get out of here. It's time to go.”
[cpg cn=true]


I said so to Natsuko, but she shook her head.
[cpg]


;**【ＣＧ】 ev_11_a ***********************
[CG id=5 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNatuko005"]
[OnName num="natuko"]
“Who cares about that.”
[cpg cn=true]


She says so, but we were not in the position to be saying that.
[cpg]

[OnName num="youta"]
“You’re an honor student. It would be bad for you if you are late.”
[cpg cn=true]


[VOICE f="sNatuko006"]
[OnName num="natuko"]
“No, it's not like that. There is nothing more important than being with you Yota.”
[cpg cn=true]


I even let her say that.
[cpg]

I'm kind of embarrassed, I feel like I can't take it anymore.
[cpg]


;//移植のためシーンをカットしています



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


I shook off Natsuko who was insisting that it wasn't enough, and decided to return to the classroom.
[cpg]


I was afraid that if I went back with her, I might give her a bad impression, but I had no choice.
[cpg]


[OnName num="youta"]
"...... let's not go any further. Natsuko"
[cpg cn=true]


I try to persuade her. But Natsuko shook her head.
[cpg]


She was right. I'm not going to be able to end it like this if I were her.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（夕方）******************************************************





It's a hell of a situation.
[cpg]


Three girls like me. And I am not dating any one of them.
[cpg]


Maybe it's the youthful situation that every man dreams of. But I don't want that.
[cpg]


At the very least, this is something that can only be happily approached in a fiction story.
[cpg]


I have to think about Michi's feelings, and I have to think about Natsuko's feelings too, not to mention Mayuki's.
[cpg]


This is a three-way affair. It was an undeniable fact.
[cpg]


Rather than worrying about it, I was just stunned.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi107"]
[OnName num="michi"]
“What's wrong ......? You look tired.”
[cpg cn=true]


[OnName num="youta"]
“Yeah, well ……"
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



I had received confessions of love from two girls without Michi's knowledge.
[cpg]

The situation is something that I don’t really deserve. I don't have the capacity to love three people at the same time.
[cpg]

Or ...... is that dishonest?
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





Too many things have happened since I entered school.
[cpg]


There is no doubt that I have to choose one of them.
[cpg]


But Michi has undergone changes that I never imagined. It's as if I dumped her once.
[cpg]


I don't think that I have really accepted her confession.
[cpg]


That said, would I be able to truly love Mayuki or Natsuko ......?
[cpg]


……This is bad. My thoughts are getting darker. I guess I need to be able to think that I can handle it.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（昼）
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


;//そう思っていたある休日、真雪が俺の部屋に訪ねてきていた。
One day after school when I was thinking that, Mayuki was visiting me in my room.
[cpg]


My parents had just gone out on another errand. However, ......
[cpg]


;//[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sMayuki010"]
[OnName num="mayuki"]
“What should we do today? I'll do anything for you."
[cpg cn=true]


[OnName num="youta"]
"...... I'm not dating you yet, Mayuki…….”
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Mayuki079"]
[OnName num="mayuki"]
“So we can’t do it if we’re not dating? I don’t think that theory would work for a gal.
[cpg cn=true]


Okay. She may be right. And Mayuki has a trump card...
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Mayuki080"]
[OnName num="mayuki"]
“I'll tell Michi. Although she’ll know even if I don’t.”
[cpg cn=true]


This girl may genuinely like me, but her strategy is sly.
[cpg]


;//ブラックアウト

She didn't seem nervous at the stranger's house.
[cpg]

On the contrary, she let her guard down already.
[cpg]


;//========================================
;//●ＣＧ（足を上げて寝転がっているヒロイン。誘惑する感じ）ev_12
;//人物１：サブヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_12_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sMayuki011"]
[OnName num="mayuki"]
"...... look at me more. Don’t look away."
[cpg cn=true]


She is trying to seduce me in an improper manner.
[cpg]

I'm glad I'm the type who doesn't go berserk seeing her like this.
[cpg]

[OnName num="youta"]
“You should be ashamed. The way you look.”
[cpg cn=true]


She looks like she is challenging me.
[cpg]

[VOICE f="sMayuki012"]
[OnName num="mayuki"]
“I'm showing it only to you Yota. You don't understand, do you?”
[cpg cn=true]


No, I know that. I'm just pretending that I don't.
[cpg]

But on the other hand, she might be able to see right through me.
[cpg]

[VOICE f="sMayuki013"]
[OnName num="mayuki"]
“I wonder how long I can stay out of it. I might be looking forward to it.”
[cpg cn=true]


Mayuki said that to me as if she was proud of her victory.
[cpg]

No matter what I was told, I wasn't going to accept the invitation.
[cpg]

I wonder how long ...... I can endure this kind of thing.
[cpg]

And there is one more problem.
[cpg]


;**【ＣＧ】 ev_12_a ***********************
[CG id=6 index=1 time=1000]
;***************************************
[WAIT time=1000]


;//ブラックアウト
;//[STOPBGM]
;//[window target=false]
;//[BG f="b_06_2.ui" time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//
;//[BGM f="bg_d1"]
;//[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



;//[FACE method="change_7" pos="2/3"]
[VOICE f="Mayuki099"]
[OnName num="mayuki"]
“So, what are you going to do? Are you going to go out with Michi?”
[cpg cn=true]


[OnName num="youta"]
“……”
[cpg cn=true]


That was the last thing I wanted to hear right now.
[cpg]


What am I going to do? It's not good if even Mayuki is talking about it.
[cpg]


;//[FACE method="change_2" pos="2/3"]
[VOICE f="Mayuki100"]
[OnName num="mayuki"]
“Oh well. If you want to go out with me, you'll have to call me next time.”
[cpg cn=true]


[OnName num="youta"]
“That's ……."
[cpg cn=true]


;//[FACE method="change_3" pos="2/3"]
[VOICE f="sMayuki014"]
[OnName num="mayuki"]
“That's what? Are you trying to say you don't want to go out with me?”
[cpg cn=true]


I couldn't respond again.
[cpg]

I know this isn't good for me, but I can't change it.
[cpg]

And Mayuki seems to know that she can manipulate because of this.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

After a while, Mayuki left. ......
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I still didn't know what I wanted to do.
[cpg]


However, there is nothing good about being too serious.
[cpg]


It's one thing to be focused, and it's another to be serious.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（朝）******************************************************





The next morning. I was at the school.
[cpg]


It's not just Mayuki that's a problem. Natsuko is too.
[cpg]


She was also a rather aggressive girl. She didn't seem like that, but I had been wrong about her.
[cpg]


The reason I came to school early today was because I had an appointment with her.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko058"]
[OnName num="natuko"]
"You came... Yota"
[cpg cn=true]


[OnName num="youta"]
“…… Yea.”
[cpg cn=true]


The reason why I kept my promise to her. It's partly because I pity her, but also because ......
[cpg]


That would also mean that I didn't pity Michi.
[cpg]


But it seemed like quite a sin to have asked Natsuko for advice about Michi while she was still in love with me.
[cpg]


I couldn't push her away, either.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





There was always a certain place where we would do things. That place.
[cpg]



;//========================================
;//●ＣＧ（ヒロインを抱きしめる主人公。背景が変わってます）ev_13
;//人物１：サブヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園裏
;//時間　：朝
;//========================================


[BGM f="bg_h1"]
;**【ＣＧ】 ev_13_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]

We moved to a secluded place. The back of the school, where I had received a confession of her feelings one day.
[cpg]

It's a secluded place, but someone might see us.
[cpg]

But there are not many places in the school where no one can see you.
[cpg]

[VOICE f="sNatuko007"]
[OnName num="natuko"]
“…..Yota your arms are warm.”
[cpg cn=true]


[OnName num="youta"]
"Is it?”
[cpg cn=true]


Natsuko said those words in a passionate tone.
[cpg]

I can't keep quiet, or rather, I feel like I can't do anything.
[cpg]

But if I act on it, I will not be able to go back.
[cpg]

It may be that I am tormenting myself and Natsuko at the same time.
[cpg]

Still, I couldn't stop right now……
[cpg]

I was sick and tired of my own weakness, but I still spent my days in ambiguity.
[cpg]


;**【ＣＧ】 ev_13_a ***********************
[CG id=7 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNatuko008"]
[OnName num="natuko"]
“I want you to hold me tighter.”
[cpg cn=true]


I did as she asked and felt her heat on me.
[cpg]

When I hug her a little tighter, I also feel her presence more strongly.
[cpg]


;**【ＣＧ】 ev_13_b ***********************
[CG id=7 index=2 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sNatuko009"]
[OnName num="natuko"]
“...... I’m happy.”
[cpg cn=true]


She says in a breathy voice that sounds like she must be really happy.
[cpg]

I can't say that there's nothing more to be said for being seen in such a place.
[cpg]

I really don't know what to do.
[cpg]


;//移植のためシーンをカットしています



;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi108"]
[OnName num="michi"]
“I made lunch again today, Yota. Today's side dish is ......."
[cpg cn=true]


Michi happily explained to me.
[cpg]


I don't feel as awkward as I did when I told her I couldn't go out with her.
[cpg]


But there was a one-sided awkwardness on my part.
[cpg]


She doesn't know that I'm seeing two other people on the side. I couldn't help but wonder if I should confide in her or not.
[cpg]


Still, while wondering, time was passing rapidly.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_se"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





On the way home, I was thinking. The Michi I once loved had transformed.
[cpg]


Instead of loving her, I could choose to go out with another girl.
[cpg]


That made me think of Mayuki and Natsuko.
[cpg]


I think both of them are pretty girls. If I were to go out with either of them, which one would it be? ......
[cpg]



;//■選択肢
[switch]
[case "Mayuki"]
	[swap]
	[jump target="*select03_1"]
[case "Natsuko"]
	[swap]
	[jump target="*select03_2"]
[endswitch]


1. Mayuki
2. Natsuko



*select03_1
[jump storage="ep006.ks" target="*select03_1"]

*select03_2
[jump storage="ep007.ks" target="*select03_2"]


