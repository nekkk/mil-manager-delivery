
*start

*select01_3

;#################################################
*Ep001|Why Michi Became a Gal
;#################################################

[SCENE id=1]


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（朝）******************************************************



In the morning. As I was getting used to my new school, I finally decided to find out.
[cpg]


The reason why Michi became like this.
[cpg]


Who did this to her? If someone from the previous academy had done it, there's no way to find out.......
[cpg]


And more to the point, I can't blame the person even if I find out who did it.
[cpg]


Still, I wanted to know the process. How did she become this way?
[cpg]


That's why I ask a lot of questions to both male and female students. Most of them come up empty.
[cpg]


If it was someone who knew Michi, it had to be someone from the previous school.
[cpg]


And if she was a gal, it might be difficult for her to get into this school.
[cpg]


Because gals have an image of stupidity….or so I thought.
[cpg]


Apparently, my guess was wrong. The gal who influenced Michi is still at this school.
[cpg]


[OnName num="female_student"]
“Oh, about Haneda? If so, it's probably Itoi.”
[cpg cn=true]


Itoi. I thought it was the first time I had heard the name, but it wasn't. Although, it was the first time I had heard her last name. 
[cpg]


[OnName num="youta"]
“Who is that ……?"
[cpg cn=true]


[OnName num="female_student"]
“Mayuki. Don't you know?"
[cpg cn=true]


It seems to be the last name of that girl who was called Mayuki.
[cpg]


I see, I could imagine her being an influence on Michi.
[cpg]


[OnName num="female_student"]
“Oh, about Haneda? If so, it's probably Itoi.”
[cpg cn=true]


......I have to check it out. So I think and get closer to the gal called Mayuki.
[cpg]



;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ非エロ（椅子に座ったままスマホをいじりつつ、主人公の話を聞くヒロイン）ev_02
;//人物１：サブヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：朝
;//========================================


[BGM f="bg_gy"]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="Mayuki004"]
[OnName num="mayuki"]
“What is it? What do you want?”
[cpg cn=true]


The girl was looking at her phone and didn't even look in my direction.
[cpg]


I wondered why she still sensed my presence.
[cpg]


I wondered if girls these days could sense other peoples presence while looking at their phones.
[cpg]


[OnName num="youta"]
“Oh aren’t you the girl who changed Michi into a gal.”
[cpg cn=true]


She defended herself while I was asking her the question.
[cpg]



[VOICE f="Mayuki005"]
[OnName num="mayuki"]
“I didn't turn her into a gal. I did have to, I think she would have become a gal either way.”
[cpg cn=true]


Is that so? Did she have those qualities?
[cpg]


It's hard to believe.
[cpg]


[OnName num="youta"]
“But she wasn't like that. Mayuki you must have done something to her.”
[cpg cn=true]


I spoke to her politely just incase. But she said
[cpg]



[VOICE f="Mayuki006"]
[OnName num="mayuki"]
“You don't have to be so polite"
[cpg cn=true]


She said I could call her that. I was puzzled, but I did.
[cpg]


[OnName num="youta"]
“...... Mayuki, you must have done something to her. I can't believe that Michi would turn into a gal on her own."
[cpg cn=true]


I say so, but Mayuki still doesn't even look at me.
[cpg]


She seems to be busy with her smartphone games.
[cpg]



[VOICE f="Mayuki007"]
[OnName num="mayuki"]
“What you say to me won’t make her any less of a gal, and it's a waste of time, isn't it?”
[cpg cn=true]


It seemed like she could read my thoughts.
[cpg]


I was perplexed that she could see through me......
[cpg]


I was puzzled, I didn't know what to say.
[cpg]


Sure, even if I wanted to make Michi look less like a gal, I can't blame Mayuki for that.
[cpg]


If so, what should I do?
[cpg]


In the first place, I wouldn't be able to make Michi look like her original form, or rather, like a proper person.......
[cpg]


Even if I did, it would be meaningless if she didn't want it.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************





Lunch break. Today too, Michi had made lunch.
[cpg]


The bento she made today was also delicious. But ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi021"]
[OnName num="michi"]
“What's wrong, you seem troubled."
[cpg cn=true]


I can't help but make a cloudy face.
[cpg]


[OnName num="youta"]
“Uh,...... yeah, kinda."
[cpg cn=true]


I couldn't reply properly.
[cpg]


[OnName num="youta"]
"It's just this small matter......don't worry about it."
[cpg cn=true]


Like that, I fake it. And Michi just”I see””I see”.
[cpg]


Then, as we were finishing lunch, Michi was talking to another girl.
[cpg]


[free time=1000]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Michi022"]
[OnName num="michi"]
"Hey, you’re Natsuko, right? What are you reading?"
[cpg cn=true]


This girl seemed out of place being in the same room as Michi.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Natuko002"]
[OnName num="natuko"]
"Um ...... nothing ...... Umm…..”
[cpg cn=true]


The girl called Natsuko was the girl I had seen in the library before.
[cpg]


 She's a modest girl. Looking graceful and is close to the Michi I imagined.
[cpg]


Of course, her face and other features are quite different......but I'm talking about her clothes and hair.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[VOICE f="Michi023"]
[OnName num="michi"]
“Wow those are small letters. I could never read that.”
[cpg cn=true]


But, I guess Michi is still curious about a plain looking girl.
[cpg]


Was she that type? I wonder if she's changed somewhat by becoming a gal.
[cpg]


I couldn't even tell her to stop. There was nothing I could do but watch.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************





Then, after school, Natsuko went to the library.
[cpg]


Michi might have caused her some trouble. I should say something to Natsuko, but it would be strange for me to do so. ......
[cpg]


Thinking that, I headed for the library too.
[cpg]


Somehow, I was curious about Natsuko.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『学園図書室』（夕方）******************************************************





She was there at the seat in the corner of the library.
[cpg]


It was as if she was telling me not to talk to her.
[cpg]


It took a little courage for me to talk to her, but I did.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ非エロ（本を手に持ちながら、主人公の方を見上げているヒロイン）ev_03
;//人物１：サブヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園図書室
;//時間　：夕方
;//========================================


;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]





[OnName num="youta"]
"Can I talk to you for a minute?"
[cpg cn=true]


Natsuko looked up when she heard my words.
[cpg]



[VOICE f="Natuko003"]
[OnName num="natuko"]
"Oh, um, ...... what is it?"
[cpg cn=true]


[OnName num="youta"]
“Oh, uhh ……I saw Michi forcefully talking to you. I'm sorry."
[cpg cn=true]


I know it's not something I should be apologizing for, but I did nonetheless.
[cpg]



[VOICE f="Natuko004"]
[OnName num="natuko"]
"Oh, no, no worries ......."
[cpg cn=true]


I apologized on behalf of Michi, who had forced a conversation with her.
[cpg]


I should be, but I'm probably forcing myself to talk to her at the moment. It's a bit of a downfall.
[cpg]



[VOICE f="Natuko005"]
[OnName num="natuko"]
“I don't mind at all”
[cpg cn=true]


I wish that were the case, but she probably does care.
[cpg]


I don't think there are many girls who like to be talked to by gals.
[cpg]


From my point of view, it looked like she didn't like it very much.
[cpg]


That said, I don't know if there's anything in particular I can do about it.......
[cpg]


Even now, she might not like me talking to her.
[cpg]


I thought I'd still support Michi.
[cpg]


[OnName num="youta"]
“......Michi wasn't like that at first.”
[cpg cn=true]


In response to my words, Natsuko replied in a way that surprised me.
[cpg]



[VOICE f="Natuko006"]
[OnName num="natuko"]
“I heard that she was.”
[cpg cn=true]


So she knew.  Who might she have heard it from? I guess anyone could have told her.
[cpg]


If Mayuki knew about it then I guess there will be rumors.
[cpg]


I don't know, but I don't have anything more to say.
[cpg]


[OnName num="youta"]
“In that case, I guess…..I’m sorry.”
[cpg cn=true]


I say, as I was about to leave her on her own.
[cpg]



[VOICE f="Natuko007"]
[OnName num="natuko"]
“No, it's okay. ……"
[cpg cn=true]


I made her say, "It's okay”. I felt sorry.
[cpg]


We had a conversation that didn't yield much. But this is all I had to say.
[cpg]


But Natsuko is still very graceful, and she is very close to how I imagined Michi to be.
[cpg]


I thought so again. Although, that thought won’t help me much.
[cpg]


I wish she was Michi….…I couldn’t help but think such an unrealistic thought.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Then one day. It was a weekday, and my parents were coming home late.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Michi024"]
[OnName num="michi"]
"Oh, really? That's an opportunity, isn't it?"
[cpg cn=true]


“Opportunity,” is what Michi said. I didn't know what she was talking about for a moment, but ......
[cpg]


[OnName num="youta"]
“..... what?”
[cpg cn=true]


I said something about my parents coming home late, but I guess I shouldn't have.
[cpg]


I might have made her associate it with an unusual thought. If so, it's my fault.
[cpg]


Or perhaps she is thinking of doing something perverted?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi025"]
[OnName num="michi"]
“I'm going to your house then! Okay?"
[cpg cn=true]


If you're just coming over, you could just come when my parents are there.
[cpg]


[OnName num="youta"]
“……"
[cpg cn=true]


I was at a loss for words. Hmm, I cannot go against the situation ......
[cpg]


If I refused, she would be depressed and would need a reason.
[cpg]


I thought about what I should do ...... but I let her come over.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi026"]
[OnName num="michi"]
“I'm looking forward to it. It's been a while since I've hung out with you.”
[cpg cn=true]


She was right. I didn't even need to think about why .......
[cpg]


[OnName num="youta"]
“Of course. It's been a long time since we've seen each other.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi027"]
[OnName num="michi"]
"I've been looking forward to it for a long time. To hang out with you as an adult.”
[cpg cn=true]


Adult...... I guess she meant that we were just more mature than that time.
[cpg]


We are still children.
[cpg]


Even though I think so, Michi's determined feelings grasp my heart.
[cpg]


I'm not going to let anything go to waste.
[cpg]



[SE f="se011"]
;//【ＳＥ】『ドア開く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



;//[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi028"]
[OnName num="michi"]
“Thanks for inviting me! But yeah, nobody's here, right?”
[cpg cn=true]

;//[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="youta"]
"Yeah,......that's right."
[cpg cn=true]


Michi was so excited. I also feel a little strange.
[cpg]


Even though she’s now a gal, the girl I said I was going to marry a long time ago comes to my room.
[cpg]


I couldn't help but think about it. Maybe something might start, I think.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi029"]
[OnName num="michi"]
"Wow. It's a typical guys room."
[cpg cn=true]


That’s a very orthodox thought. But I think it's just a plain room.
[cpg]


[OnName num="youta"]
"...... What's with that impression? It's like you've never been in a guys room.”
[cpg cn=true]


I said so to figure out if she ever did before.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi030"]
[OnName num="michi"]
"I never have. I don’t really like other boys.”
[cpg cn=true]


What ……? Is there such a gal who doesn't like guys?
[cpg]


The way she said "other boys" also bothered me. I assume she meant “other guys” besides me.
[cpg]


Does that mean she hasn't hung out with any boys before? Is that possible?
[cpg]


Maybe there is. It's possible that she's been a gal, but she's kept her promise to me.
[cpg]


[OnName num="youta"]
“So what should we do? Even if you say you're going to hang out in my room, the only thing we can do is play games ......."
[cpg cn=true]


So I said, and then I looked around for things to do. It was hard to find anything that Michi and I could play.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi031"]
[OnName num="michi"]
“You play games? Wow, that's surprising.”
[cpg cn=true]


I guess so. She has an image of myself in her mind, too.
[cpg]


But what does it mean that she doesn't have the impression that I play games?
[cpg]


Well, I was supposed to be a sports youth in Michi's mind. ......
[cpg]


[OnName num="youta"]
“Do you want to read some comic books. I wonder if there were any ...... that girls might find interesting to read."
[cpg cn=true]


I was trying to be thoughtful, but Michi didn't seem to care much.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi032"]
[OnName num="michi"]
“Don’t worry about me. I'll just relax.”
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************





So, each of us was spending our time ourselves......
[cpg]


I didn’t really see the meaning in us hanging out.
[cpg]


Besides, there was nothing to do, so…….
[cpg]


It came to the point where the two of us were talking face to face. It was kind of embarrassing.
[cpg]


We started out talking about really trivial things, but gradually we began to reminisce.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi033"]
[OnName num="michi"]
“Do you remember? You went to get a balloon that was stuck in a tree.”
[cpg cn=true]


[OnName num="youta"]
“There was a balloon in the tree ..……?"
[cpg cn=true]


I couldn’t exactly remember. Either way.
[cpg]


[OnName num="youta"]
“Did I do something cliche like that?"
[cpg cn=true]


“You did”, said Michi, laughing. It's fun just talking.
[cpg]


We reminisce like this.
[cpg]


And as we talk about me, or rather, memories of me, she seemed to be getting into the mood. ......
[cpg]


She looks up at me with her cheeks tinted.
[cpg]


[OnName num="youta"]
“What's wrong? ...... Michi, do you have a fever?”
[cpg cn=true]


I tried to distract her from the situation.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Michi034"]
[OnName num="michi"]
"......You know, Yota. I still like you.”
[cpg cn=true]


I was sure she did. I think so, listening to the conversation.
[cpg]


No matter how Michi's appearance may have changed, her heart has not.
[cpg]


[OnName num="youta"]
“I see.……"
[cpg cn=true]


I'm still puzzled by Michi as a gal. But before I was going to mention that.
[cpg]


Michi is coming on to me. She's getting closer.
[cpg]


I have no tolerance for girls, so I was taken aback.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Michi035"]
[OnName num="michi"]
“I was about to lose my mind with waiting so long. All I could think about was you.”
[cpg cn=true]


She came even closer. So close that I could feel her breath on me.
[cpg]


[OnName num="youta"]
"Umm, you're so close."
[cpg cn=true]


I backed away from her as I sat down. And then, Michi comes closer to me sitting down.
[cpg]



;//========================================
;//●ＣＧ（主人公に胸を当てて密着するヒロイン）ev_04
;//人物１：メインヒロイン
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_04_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]

So close. Not only I can touch her, but I could even hug her.
[cpg]

[VOICE f="sMichi001"]
[OnName num="michi"]
“We are so close.”
[cpg cn=true]


I can smell her scent. I couldn’t believe that we were so close.
[cpg]

[VOICE f="sMichi002"]
[OnName num="michi"]
“Your smell is so soothing.”
[cpg cn=true]


Michi is thinking the same thing as me.
[cpg]

Her face was red as she said, "It calms me down.”
[cpg]

And I am far from calm.
[cpg]

[OnName num="youta"]
“Please can we keep a distance? I’m not ready for this.”
[cpg cn=true]


[VOICE f="sMichi003"]
[OnName num="michi"]
“What do you mean you're not ready? We haven’t done anything yet.”
[cpg cn=true]


“Yet" says Michi. That means she would want to do something.
[cpg]

When I imagine what is about to happen, I can't say anything.
[cpg]


;**【ＣＧ】 ev_04_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMichi004"]
[OnName num="michi"]
“I ...... want to be around you more.”
[cpg cn=true]


Michi comes so close to me that her breasts are against my body.
[cpg]

[OnName num="youta"]
“You can't get any closer.”
[cpg cn=true]


I said, and she shook her head.
[cpg]

[VOICE f="sMichi005"]
[OnName num="michi"]
“I don't mean that, I mean I want to stay here for a long time.”
[cpg cn=true]


She gives me a heated look, her cheeks still tinted.
[cpg]

I'm afraid this is going to be a bad idea. ......
[cpg]

At least I'm not going to kiss her. I'm not that kind of guy who is easily swept away.
[cpg]

So I think and I try to hang on.
[cpg]

[VOICE f="sMichi006"]
[OnName num="michi"]
“...... maybe I was born for this moment.”
[cpg cn=true]


Michi even says such things.
[cpg]

I was moved in my heart but didn’t move my body.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
;//移植のためシーンをカットしています

;//ブラックアウト

We stayed together for a while. The fun time passed quickly, and night fell.
[cpg]

It was time for her to go home. But Michi seemed happy.
[cpg]


;//ブラックアウト

[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『街』（夜）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Michi074"]
[OnName num="michi"]
“See you around……Yota."
[cpg cn=true]


Michi has a feverish look on her face as she says so.
[cpg]


[OnName num="youta"]
“Yeah,...... see you around.”
[cpg cn=true]


We said goodbye for now.
[cpg]


I can't just stay with her all day.
[cpg]


It’s not like we both have our own apartment.
[cpg]


My parents will be back soon. It was that time of night. ......
[cpg]


[OnName num="youta"]
“I'll see you soon. Don't look at me like that."
[cpg cn=true]


Michi nodded at these words.
[cpg]


On the other hand, I am still unable to sort out my feelings.
[cpg]


Maybe, or almost certainly, I do like Michi.
[cpg]


But I still can't make a decision about the part of her becoming a gal. I don't know what to think.
[cpg]


I don't know if I can love Michi as she is now.
[cpg]



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』





And the next day. I go to school again.
[cpg]


I was still holding on to something that didn't make sense to me, and I was still unable to sort out what I wanted to do.
[cpg]


What kind of a relationship do I want with Michi? I kept thinking about it.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************





Then, during lunch break. The gals were talking, and Michi was joining them.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

It felt strange. To see Michi talking with these girls.
[cpg]


[OnName num="gal_A"]
"I hate studying....., I shouldn't have come to such an advanced school."
[cpg cn=true]


And the fact that she blends in without any discomfort is also ...... strange.
[cpg]


[OnName num="gal_B"]
“It's true. I came here because my parents wanted me to go, but honestly, it's hard.”
[cpg cn=true]


The gals are having a casual conversations. Or rather, sloppy conversation.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Michi075"]
[OnName num="michi"]
“I don't know about that. I quite like studying.”
[cpg cn=true]


In response, Michi says something a little offhanded.
[cpg]


I wondered if she was doing well as a gal.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mayuki008"]
[OnName num="mayuki"]
“That’s a talent Michi. I could never do that.”
[cpg cn=true]


In any case, it was Michi who was having a good time conversing with such people.
[cpg]


I feel uncomfortable no matter how many times I see it,....... I wonder if this is also something that Michi wants to do.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7"]
[BG f="b_07_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園中庭』（夕方）

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

And after school. Michi brought me to the back of the school campus.
[cpg]


I was perplexed and checked to see what Michi was going to do to me.
[cpg]


[OnName num="youta"]
“What’s going on?”
[cpg cn=true]


There is no need to be sure. There is only one thing to do in a place like this.
[cpg]


I was waiting to see what she was going to do.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sMichi007"]
[OnName num="michi"]
“What do you mean ...... if we’re at my house or your house, we might get caught.”
[cpg cn=true]


But it didn't seem like a good idea to just wait.
[cpg]


[OnName num="youta"]
“I'm sure it would be even worse if we’re alone in a place like this……."
[cpg cn=true]


I said, but I felt like I couldn't refuse her.
[cpg]

She was in a distance where we can almost kiss, and her face flushed.
[cpg]


;//移植のためシーンをカットしています

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



After that, I left the place a way that no one would notice.
[cpg]

[OnName num="youta"]
“I can't!”
[cpg cn=true]


I refused to kiss her, not wanting to be swept away.
[cpg]

Rather than being disappointed, Michi looked frustrated.......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』



Then it happened on the way home.
[cpg]


I finally had to make a decision. Because ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi095"]
[OnName num="michi"]
“Hey, Yota. I want to hear your answer.……"
[cpg cn=true]


Michi asked me for an answer.
[cpg]


I had never said anything to her before.
[cpg]


[OnName num="youta"]
“Answer as in…….?”
[cpg cn=true]


I wanted to check, but she replied,
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Michi096"]
[OnName num="michi"]
“You know what I mean, don't you? I have told you many times that I like you, haven't I?”
[cpg cn=true]


Right. I have to make up my mind about my attitude towards Michi.
[cpg]


Do I love her or not? I have to consider whether or not I love Michi as she is now.
[cpg]


Some of my feelings haven't changed since our agreement of all those years ago.
[cpg]


But some things have changed. Michi's appearance has also changed.
[cpg]


[OnName num="youta"]
“I…….”
[cpg cn=true]


I have to think about it and answer properly.
[cpg]


But all along, I had only one thought. That's what I felt, and I gave her an answer.
[cpg]


[if exp={getFlagValue("Cha1flg") == 1}]
[jump target="*select02_1"]
[endif]


;//■選択肢
[switch]
[case "Let's go out."]
	[swap]
	[jump target="*select02_1"]
[case "Let me think about it."]
	[swap]
	[jump target="*select02_2"]
[endswitch]


1. Let’s go out.
2. Let me think about it.


*select02_1
[jump storage="ep002.ks" target="*select02_1"]

*select02_2
[jump storage="ep003.ks" target="*select02_2"]

;//==============================

