
*start

;//ここから洋太は南都子のことを「南都子さん」と呼びます



;//==============================
;//１、付き合おう

*start


;#################################################
*Ep002|The Promise We Made
;#################################################


[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]


*select02_1|The Promise We Made


[SCENE id=2]



[OnName num="youta"]
"...... I guess we should go out.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Michi186"]
[OnName num="michi"]
"Really ……?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[OnName num="youta"]
“Of course, why would I be joking…..What’s wrong?”
[cpg cn=true]


Michi began to cry raggedly. This is not good, in public like this.
[cpg]


[OnName num="youta"]
“Don't cry. You just scared me.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi187"]
[OnName num="michi"]
“I can't believe I'll really be your girlfriend”
[cpg cn=true]


She seemed to be happy from the bottom of her heart. I was flattered but...... can one cry because of too much joy?
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Before I knew it, our days as lovers began.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi188"]
[OnName num="michi"]
“Here you go, open your mouth.”
[cpg cn=true]


[OnName num="youta"]
“Ahhh....."
[cpg cn=true]


I was going along with what Michi was doing, even though I was worried about the stares of the people around me.
[cpg]


[OnName num="male_student_A"]
“It's not fair,……that Yota guy.”
[cpg cn=true]


[OnName num="male_student_B"]
“Yea. I was secretly in love with Haneda too..."
[cpg cn=true]


[OnName num="male_student_A"]
“Then why don't you go and assault him?"
[cpg cn=true]


[OnName num="male_student_B"]
"I can't ...... I don't have the guts to go in there.”
[cpg cn=true]


[OnName num="male_student_A"]
“Then I'll go. I'm not satisfied with the way things are going.”
[cpg cn=true]


I heard some disturbing conversation, and one of the boys came over to me.
[cpg]


[OnName num="male_student_A"]
“Haneda! Can I join your lunch?”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Michi189"]
[OnName num="michi"]
“What? Oh, that's ......."
[cpg cn=true]


As I watched, I noticed something: Michi has a pretty low tolerance for men.
[cpg]


I'm the only one who excessively receives her attention. She's so single-minded about me that she wouldn’t touch other guys.”
[cpg]


[OnName num="male_student_A"]
“I'm not trying to get in your way! I just want to have lunch with you.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Michi190"]
[OnName num="michi"]
“What should I do, Yota?”
[cpg cn=true]


[OnName num="youta"]
“I'm sorry, but you'll have to find someone else."
[cpg cn=true]


It felt awkward to say that, but I ended up getting rid of him.
[cpg]


[OnName num="male_student_A"]
“Da... damn it! You better watch it, Yota!”
[cpg cn=true]


"Why is he talking to me?…… Why couldn’t he just say Haneda or something?”
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


And one more thing. I've known this for a long time, but Michi is very interested in love itself, or rather, skinship.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

;//========================================
;//●ＣＧ（ヒロインに近づく主人公。ヒロインは主人公に腕を伸ばしている）ev_25
;//人物１：メインヒロイン
;//服装１：制服（はだけ）
;//人物２：主人公
;//服装２：制服
;//場所　：学園裏
;//時間　：昼
;//========================================


;//[BGM f="bg_h2"]
;**【ＣＧ】 ev_25_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sMichi016"]
[OnName num="michi"]
“Have you grown taller?”
[cpg cn=true]


[OnName num="youta"]
“…..There is no way I could get taller in a day or two.”
[cpg cn=true]


[VOICE f="sMichi017"]
[OnName num="michi"]
“I don't mean that. The Yota I remember was much smaller.”
[cpg cn=true]


A simple conversation. It's a healthy relationship.
[cpg]

But even that felt like she was wasting her happiness on me.
[cpg]

[VOICE f="sMichi018"]
[OnName num="michi"]
“I think your hair has grown a little longer, too.”
[cpg cn=true]


[OnName num="youta"]
“I told you, it won't grow that fast.”
[cpg cn=true]


;**【ＣＧ】 ev_25_a ***********************
[CG id=12 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMichi019"]
[OnName num="michi"]
"Hehe. I'm just kidding.”
[cpg cn=true]


We were confirming each other's existence while saying such things.
[cpg]

I can smell her. Likewise, she can probably smell me too.
[cpg]

It's kind of embarrassing, it's also kind of nice, it's a strange feeling.
[cpg]

I could never get used to this, no matter how many times I tried.
[cpg]

[VOICE f="sMichi020"]
[OnName num="michi"]
”Yota, you've always had really dark hair, haven't you?”
[cpg cn=true]


[OnName num="youta"]
”I'm often told that. I can't dye it while I'm still a student.”
[cpg cn=true]


No, wait. It's strange to say this to Michi.
[cpg]


;**【ＣＧ】 ev_25_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMichi021"]
[OnName num="michi"]
”Hmmm, what about me? I've been dyeing my hair for quite a long time.”
[cpg cn=true]


Michi giggles. And then.
[cpg]

[VOICE f="sMichi022"]
[OnName num="michi"]
"But I think you would look good in anything.”,
[cpg cn=true]


I wonder if she is imagining me dyeing my hair.
[cpg]

I can't imagine me doing that, but I don't even know what she likes.
[cpg]

But I wonder if one day I will look like a suitable boyfriend for Michi.
[cpg]


;//移植のためシーンをカットしています

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



We were about to return to the classroom when we realized that someone had seen us.
[cpg]



[VOICE f="Mayuki247"]
[OnName num="mayuki"]
"Oops, ...... you guys. Did you have a good time?"
[cpg cn=true]


Maybe Mayuki was also trying to skip class, but we met on the way back.
[cpg]


[OnName num="youta"]
“...... Is that a bad thing?”
[cpg cn=true]


Michi seemed embarassed, so I said that.
[cpg]



[VOICE f="Mayuki248"]
[OnName num="mayuki"]
“I didn't say it was bad, I hope you guys are happy.”
[cpg cn=true]


It was an honest blessing. I felt strangely embarrassed. ......
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





After school that day, it was just Michi, Mayuki and I, the three of us going home.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Mayuki249"]
[OnName num="mayuki"]
“But anyways, I guess Michi, you’ve finally found the courage to do it.”
[cpg cn=true]


Not really. She had always had courage.
[cpg]


I just couldn't keep up with her.
[cpg]


I felt sorry for Michi about the misunderstanding, so I followed up.
[cpg]


[OnName num="youta"]
“I couldn't accept it. I was the one who couldn’t muster the courage."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Michi222"]
[OnName num="michi"]
“Yota……you don’t have to do this.”
[cpg cn=true]


She blushed as she said so. Whatever we say, it sounds like we are in love.
[cpg]


[OnName num="youta"]
“Sorry, for being so showy.”
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mayuki250"]
[OnName num="mayuki"]
“It's okay. I asked because that's what I wanted to hear.”
[cpg cn=true]


Mayuki grinned. It's just embarrassing. ......
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





I went home and thought about it. I'm certainly happy with the days I have right now.
[cpg]


But when I saw Michi talking with Mayuki,......I had a thought.
[cpg]


After all, Michi is a gal. It's not what's on the inside, but her appearance has transformed.
[cpg]


I wonder if she will ever go back to her old self. I can't help but think so.
[cpg]


At the same time, I also felt that it would be fine if I could just enjoy the present.
[cpg]


I thought about it. Then, I came up with an answer.
[cpg]



;//■選択肢
[switch]
[case "As long as the present is good, that's all that matters."]
	[swap]
	[jump target="*select04_1"]
[case "I can't help but keep remembering how she was in the past."]
	[swap]
	[jump target="*select04_2"]
[endswitch]


1. As long as the present is good, that's all that matters.
2. I can't help but keep remembering how she was in the past.



;//==============================
;//１、今が良ければそれでいい
*select04_1|The Promise We Made

;//次の選択肢が１で固定される
[stflag Cha2flg = 1]





It's all right as long as the present is good. I'm happy with Michi, so that's all that matters.
[cpg]


With that in mind, I went to sleep feeling satisfied.
[cpg]



[jump target="*select04_3"]

;//==============================
;//２、どうしても過去の姿を思い出してしまう
*select04_2|The Promise We Made




I can't help but think of the Michi I knew when she was young.
[cpg]


If she had grown up like that, I think she would have had a different appearance.......
[cpg]


I sleep with something indescribable.
[cpg]



;//==============================

*select04_3|The Promise We Made



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Days pass for a while, and it is a holiday.
[cpg]


When I told her that my parents were out, Michi would come to my room.
[cpg]


;//移植のためシーンをカットしています



[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************





[OnName num="youta"]
“...... My parents, you never know when they'll be back.”
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi238"]
[OnName num="michi"]
"That's okay. When they come back, we'll handle it.”
[cpg cn=true]


I'll have no choice but to introduce her as my girlfriend. I wonder how my father and mother would react.
[cpg]


But I guess that is also something that Michi would want.
[cpg]


She must have confidence in herself, including the fact that she has become a gal.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sMichi023"]
[OnName num="michi"]
“What do you want me to do? I'll do anything for you.”
[cpg cn=true]


Michi smiles wryly. But not to the extent where she looks like predator who has found its prey .......
[cpg]


Still, she had the face of a very aggressive girl.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I can't let her stay in the lead forever. So I pressed a little closer to her.
[cpg]

[SE f=se004]
;//【ＳＥ】『衣擦れ』



;//========================================
;//●ＣＧ（ヒロインに迫る主人公。ヒロインは背中を向けている）ev_27
;//人物１：メインヒロイン
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================


[BGM f="bg_h2"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sMichi024"]
[OnName num="michi"]
"Hey,.....hey!"
[cpg cn=true]


[OnName num="youta"]
“…… sorry."
[cpg cn=true]


Then our bodies collided and she fell on the bed. 
[cpg]

Her body was in an unusual position. I was at a loss for words because it was indeed awkward.
[cpg]

[VOICE f="sMichi025"]
[OnName num="michi"]
“It's still a little early for us, don't you think?”
[cpg cn=true]


Michi was trying to play it off. I thought it was cute, but I couldn't do anything more.
[cpg]

I couldn't even give her a kiss.
[cpg]

I realized that my indecisiveness had not changed, but I wondered if one day she would take the first step.
[cpg]

[VOICE f="sMichi026"]
[OnName num="michi"]
"......"
[cpg cn=true]


Still, looking at Michi in her current posture, ......
[cpg]

I feel as if I can't hold back.
[cpg]

No, I still have to hold back. I wonder if Michi can see through my dilemma too.
[cpg]


;**【ＣＧ】 ev_27_a ***********************
[CG id=13 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMichi027"]
[OnName num="michi"]
"Hey, Yota.”
[cpg cn=true]


[OnName num="youta"]
“What?"
[cpg cn=true]


[VOICE f="sMichi028"]
[OnName num="michi"]
"Are you not going to do anything, forever?”
[cpg cn=true]


[OnName num="youta"]
“……"
[cpg cn=true]


It's hard to answer such a question.
[cpg]

[OnName num="youta"]
"Right now, I won't."
[cpg cn=true]


She seemed to agree with me when I said that.
[cpg]


;**【ＣＧ】 ev_27_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMichi029"]
[OnName num="michi"]
“It's okay, I can wait."
[cpg cn=true]


She smiled at me.
[cpg]

I wasn’t being indecisive when I said I wouldn't do anything now.
[cpg]

It meant that I would take it seriously and be responsible for it.
[cpg]

[VOICE f="sMichi030"]
[OnName num="michi"]
“There is still have a lot of time before the sun sets. We have a lot to talk about."
[cpg cn=true]


I nodded and walked away from her as if I was still waiting for something.
[cpg]


;//移植のためシーンをカットしています
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************



It was getting late in the evening, and it was getting to the point where I didn't know when my parents would be back.
[cpg]


But Michi did not want to leave. She was going to introduce herself as my girlfriend.
[cpg]


I wondered if my parents would recognize her ......?
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト






[VOICE f="Michi255"]
[OnName num="michi"]
"Good evening, Yota's father and mother!"
[cpg cn=true]


[OnName num="youta_father"]
“Oh, ah ...... Who are you?”
[cpg cn=true]


It was a reaction I expected, or rather, a reaction that I thought was normal.
[cpg]


We all had dinner afterwards, but my dad and mom remained somewhat awkward.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************





She also told them that she ended up being my girlfriend.
[cpg]


My dad and mom seemed to congratulate her, but at the same time they were not convinced.
[cpg]


I was about to say "I'm sorry," but I felt terrible trying to hold back.
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************





Morning came again. I was feeling the daily rush of life.
[cpg]


I felt that since I had a girlfriend, my days had become more fulfilling, and time was passing very quickly.
[cpg]




[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko222"]
[OnName num="natuko"]
“Good morning, Yota”
[cpg cn=true]


[OnName num="youta"]
"Ah, good morning, Natsuko..."
[cpg cn=true]


I'm completely estranged from this person, or rather, I don't talk to her about my problems anymore.
[cpg]


I've already started a relationship. If there is any consultation I can do now, it would be something like whether or not to keep Michi as a gal.
[cpg]


But it's no use talking to Natsuko about that.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuko223"]
[OnName num="natuko"]
“She seems happy. Michi."
[cpg cn=true]


Natsuko looks a little sad.
[cpg]


[OnName num="youta"]
"Well,...... I guess it's the fulfillment of a long-cherished wish.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Natuko224"]
[OnName num="natuko"]
“I was a little bit in love with you, Yota"
[cpg cn=true]


[OnName num="youta"]
"...... What?”
[cpg cn=true]


That was the only reaction I could give. I had no idea.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko225"]
[OnName num="natuko"]
“But that's okay. It’s not important now.”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Natuko226"]
[OnName num="natuko"]
“I'm rooting for you. Please be happy.”
[cpg cn=true]


This was a lot of pressure ... I thought, so I ended the conversation.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





Classes were finally over for the day.
[cpg]


I ended up going to go to Michi's house.
[cpg]


[OnName num="youta"]
“Are you sure? If I go, you probably won't be able to resist.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi256"]
[OnName num="michi"]
"No, it's fine. My sister is there, but I'm sure she'll understand and leave us alone.”
[cpg cn=true]


She has a sister? That would be awkward...
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『メインヒロインの部屋』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi257"]
[OnName num="michi"]
“Ta-da! This is my room.”
[cpg cn=true]


I had no particular opinion when she said that.
[cpg]


I was still trying to wrap my head around the fact that I had really become Michi's boyfriend.
[cpg]


Rather than my feelings, Michi was more excited that I was physically there at her house.
[cpg]


We didn't have anything important to talk about, but we still talked about what we wanted to talk about.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi273"]
[OnName num="michi"]
“Yota, you really have lost weight.”
[cpg cn=true]


I don’t know what to say…..I was never the chubby type and the last time we met I was a child.
[cpg]


[OnName num="youta"]
“It's just your imagination. I was playing sports, but that was a long time ago.”
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Michi274"]
[OnName num="michi"]
“Really? My image of you was more thin and macho..."
[cpg cn=true]


If you say that, the gap between your childhood image and now is even bigger.
[cpg]


In the end, time went by without mentioning it.
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『街』（夕方）******************************************************





I returned home without being able to say anything about Michi turning into a gal.
[cpg]


I wonder if there will come a time to say it.
[cpg]


And when that time comes, will she ever go back to the way she was? ......
[cpg]


I'm still attached to the current gal-like Michi.
[cpg]


I also wonder what would happen if the girly Michi were to dress neatly. ......
[cpg]




;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（朝）******************************************************





Days go by. Michi was cute today, and I guess she thinks I'm cool, too.
[cpg]


I don't think there's anything cool about me, but now that we've become lovers, there's nothing I can do about it.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko227"]
[OnName num="natuko"]
“......You said someday, right Yota?”
[cpg cn=true]


[OnName num="youta"]
“What? What are you talking about?”
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuko228"]
[OnName num="natuko"]
“You said that you liked my type. But that's not who the current Michi is...”
[cpg cn=true]


Oh it was about that topic...... I don’t have the answer yet either.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko229"]
[OnName num="natuko"]
“I've given up. Which is fine, but ......"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Natuko230"]
[OnName num="natuko"]
“I don't know, it just doesn't add up. Yota, are you sure you want Michi to stay like that?”
[cpg cn=true]


[OnName num="youta"]
“That's ……"
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Natuko231"]
[OnName num="natuko"]
“Since you dumped me. I wouldn’t want for you to have any regrets.”
[cpg cn=true]


It was a pushy comment for Natsuko’s character.
[cpg]


And then Michi came up to me as I was conversing with Natsuko, so I told her it was nothing.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se014"]
;//【ＳＥ】『学園のチャイム』





In the meantime, class started and I went to my desk.
[cpg]


But really……. What do I want to do?
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************





On the way home, I talked with Michi about going to karaoke.
[cpg]


I thought it was a gal-ish hobby, but then I remembered that she had always liked singing.
[cpg]


Has that changed or not?
[cpg]




[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『カラオケ店個室内』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi275"]
[OnName num="michi"]
“I'm thirsty. Let's check out the fountain drinks.”
[cpg cn=true]


[OnName num="youta"]
“Sounds good"
[cpg cn=true]


Naturally, I follow Michi's lead. And then ......
[cpg]

On the way home, she said something like this.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sMichi031"]
[OnName num="michi"]
“A karaoke box is a place where no one can see you. You can flirt as much as you want."
[cpg cn=true]


[OnName num="youta"]
"I think there are surveillance cameras or something.”
[cpg cn=true]



[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sMichi032"]
[OnName num="michi"]
“Then let's show them."
[cpg cn=true]


I thought, "Which is it?……", but I didn't refuse.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//========================================
;//●ＣＧ（キスをする二人。隣り合っている）ev_29
;//人物１：メインヒロイン
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：カラオケ店個室内
;//時間　：昼
;//========================================


[BGM f="bg_h1"]
;**【ＣＧ】 ev_29_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[SE f=sMichi933]
;//【ＳＥ】『衣擦れ』


Michi kisses me. She was aggressive, but I wanted to reciprocate.
[cpg]

I wanted to be a worthy man to her. ......
[cpg]

[VOICE f="sMichi033"]
[OnName num="michi"]
“Oops, I kissed you, in public."
[cpg cn=true]


[OnName num="youta"]
“.....yea."
[cpg cn=true]


I responded. Of course, I don't mind doing this.
[cpg]

I'm inclined to do whatever she wants.
[cpg]


;**【ＣＧ】 ev_29_a ***********************
[CG id=14 index=1 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMichi034"]
[OnName num="michi"]
“Yota, I want to do more of this....... Come on.”
[cpg cn=true]


She gives me an impatient look.
[cpg]

I responded and decided to kiss her this time.
[cpg]

As we checked each other's passion, I felt my heart fill up.
[cpg]

I love this time where no one can interfere.
[cpg]


[VOICE f="sMichi035"]
[OnName num="michi"]
“I might want to do it even more, now that know that an employee might be watching us.”
[cpg cn=true]


When Michi says this, she sounds like a true gal.
[cpg]

I guess she really is, but it's something that I still have a hard time accepting.
[cpg]

I was feeling strange, but I was still happy.
[cpg]

[OnName num="youta"]
“……I'm a little more nervous than usual.”
[cpg cn=true]


;**【ＣＧ】 ev_29_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMichi036"]
[OnName num="michi"]
“Wow, you are such a goody two shoes.”
[cpg cn=true]


After saying this, Michi continued.
[cpg]

[VOICE f="sMichi037"]
[OnName num="michi"]
“I like that about you, but it might not be enough for me.”
[cpg cn=true]


I wondered where she had learned these words.
[cpg]

Or is she just improvising and getting to my heart?
[cpg]

[VOICE f="sMichi038"]
[OnName num="michi"]
“What's wrong? You've got a strange look.”
[cpg cn=true]


[OnName num="youta"]
“No, it's nothing. It's nothing.”
[cpg cn=true]



;//移植のためシーンをカットしています


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_gy"]
[WAIT time=1000]
;//【ＢＧ】『カラオケ店個室内』（夕方）******************************************************





[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Michi292"]
[OnName num="michi"]
"Hmm. What should I do ......? Do you still want to sing?"
[cpg cn=true]


She says, seeming a little unsatisfied.
[cpg]


Still I guess she wasn’t really in the mood for singing. So I think and reply,
[cpg]


[OnName num="youta"]
“...... I'm fine with singing.”
[cpg cn=true]


“See?” said Michi, who is trying to come on to me again.
[cpg]


It was obvious what she wanted when she refused to sing even though we had all this time left.
[cpg]


I couldn't refuse her. If Michi was frustrated, it was probably because of me.
[cpg]


There is no doubt that Michi is frustrated. She wants it all the time.
[cpg]


But it's not like I'm doing anything to her.
[cpg]


It's not like I'm seducing her or anything.
[cpg]


Even so, I'm sure it's not good enough for her. For Michi.
[cpg]


Being in a private room with me is a source of frustration for her.
[cpg]


It's not like this is the only thing that happens when I come to karaoke. ......
[cpg]


I thought so, and decided to comply with her coming against me.
[cpg]


I can't just do nothing, can I? That's what I thought.
[cpg]


[OnName num="youta"]
“Well then, what do you want me to do?”
[cpg cn=true]


I asked, but Michi's answer was...
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Michi293"]
[OnName num="michi"]
“I don't care what you do. I'm already expecting a lot from you.”
[cpg cn=true]


But there's only so much I can do. With that in mind, I responded to Michi.
[cpg]


I can't do anything too crazy in a private room like this. ......
[cpg]

;//移植のためシーンをカットしています


;//ブラックアウト
[STOPBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_yu"]
[WAIT time=1000]
;//【ＢＧ】『カラオケ店個室内』（夕方）******************************************************


I look at Michi, who is right next to me.
[cpg]

Her uniform is out of order and her hair is dyed. I've known this for a long time, but I realize it again.
[cpg]

It's at times like this that a thought comes to me.
[cpg]


[OnName num="youta"]
“……”
[cpg cn=true]


I've been thinking about this for a long time. I mean ......
[cpg]


How long will Michi stay a gal?
[cpg]


Of course, she will stop one day as she gets older.
[cpg]


But I think I can say that now is her time to be youthful. My girlfriend is a gal at this critical time.
[cpg]


It's not that I don't like it.
[cpg]


I don't even know if it's okay to ask.
[cpg]


Maybe it's forbidden. Maybe the moment I say it, it's the end of us.
[cpg]


But somehow I thought it was the right time to ask. I don't have any particular reason, but ......
[cpg]


It suddenly occurred to me. It's not that she doesn't care about her appearance.
[cpg]


She cares about her appearance, and that's why she's like this. That’s why she is trying to be a gal.
[cpg]


She's trying to be a gal, and I can't just not say anything to her.
[cpg]


Did she really want to be dressed like this from the beginning?
[cpg]


I was curious about that, so I finally said something.
[cpg]


[OnName num="youta"]
“Hey, Michi ......."
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
“What is it?”, she asks me as I call out her name.
[cpg]


[OnName num="youta"]
“..... Have you ever think of quitting being a gal?"
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
Was it right to say that? Was it okay for me to say this?
[cpg]


I don't know. Without knowing, I said it.
[cpg]


And then, Michi was surprised at what I had said.
[cpg]


That's what happens, doesn't it? I guess there must be a strong meaning in what I said.
[cpg]


She must be wondering if I don't like the way she looks right now.
[cpg]


Michi replied, with a surprised look on her face.
[cpg]



[VOICE f="Michi308"]
[OnName num="michi"]
"I'll be the way you want me to be. I'm your girlfriend."
[cpg cn=true]


Right. What I want to do is more important.
[cpg]


It's not about why she is the way she is.
[cpg]


I think about it. What I say here is very important.
[cpg]


[OnName num="youta"]
"I ......."
[cpg cn=true]


I think and I gave my answer.
[cpg]



[if exp={getFlagValue("Cha2flg") == 1}]
[jump target="*select05_1"]
[endif]


;//■選択肢
[switch]
[case "I want her to stay a gal."]
	[swap]
	[jump target="*select05_1"]
[case "I want her to dress proper."]
	[swap]
	[jump target="*select05_2"]
[endswitch]


1. I want her to stay a gal.
2. I want her to dress proper.


*select05_1
[jump storage="ep004.ks" target="*select05_1"]

*select05_2
[jump storage="ep005.ks" target="*select05_2"]



;//==============================
