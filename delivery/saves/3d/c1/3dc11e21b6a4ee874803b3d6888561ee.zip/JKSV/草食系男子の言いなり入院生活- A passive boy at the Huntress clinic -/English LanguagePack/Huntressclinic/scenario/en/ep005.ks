
*start


;//==============================
;//２、麻友さん

;#################################################
*Ep005|Mayu smiling softly
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************

*select04_2|Mayu smiling softly

[SCENE id=5]

[OnName num="sho"]
Mayu, wait a minute.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayu124"]
[OnName num="mayu"]
...... what is it?"
[cpg cn=true]


Mayu smiling softly. I was fascinated by her.
[cpg]


I like Mayu. I just realized it.
[cpg]



The longing that had been building up until now was about to explode all at once, but ......
[cpg]


[OnName num="sho"]
......Nothing, nothing."
[cpg cn=true]


But I couldn't say anything. The difference in age makes it difficult to find the courage to say anything.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu125"]
[OnName num="mayu"]
Heh. Weird Sho."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



The injury is almost healed. The rehabilitation is now in its final stages.
[cpg]


The reason for being in the hospital is becoming meaningless. That's why I'm so impatient.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



I was in love with Mayu. I can't sleep at night when I think about her.
[cpg]


But I'm not sure if I should confess my feelings to her or not.
[cpg]


Considering our age difference, it would be difficult to just go out with her.
[cpg]


But I even wanted to marry her.
[cpg]


If I told her that, it would be the end. I feel that way.
[cpg]


What if she refuses? ......
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu126"]
[OnName num="mayu"]
Good morning, Sho. Sho."
[cpg cn=true]


[OnName num="sho"]
Oh, good morning. ......
[cpg cn=true]


I fell asleep for quite a long time. I couldn't sleep at night.
[cpg]


I offer this to Mayu.
[cpg]


[OnName num="sho"]
'Oh, um, ...... you don't want me to do anything?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu127"]
[OnName num="mayu"]
Do you want me to do something for you?　You're so honest.
[cpg cn=true]



[FACE method="change_1" pos="2/3"]
[VOICE f="sMayu010"]
[OnName num="mayu"]
But you can move your body by yourself now. There is not much for me to do anymore.
[cpg cn=true]


Mayu said that and tried to leave.
[cpg]


;//移植のためシーンをカットしています



[OnName num="sho"]
"Oh, um, ...... please wait."
[cpg cn=true]


I stopped her. I did so without thinking.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayu146"]
[OnName num="mayu"]
What is it?　Do you still have something to do?
[cpg cn=true]


[OnName num="sho"]
I'm at that ........."
[cpg cn=true]


I'm lost. I'm still wondering.
[cpg]


Whether to say it or not. I thought it would be better if I didn't say anything.
[cpg]


I'm not sure if I'm going to be able to do anything about it if I don't say anything.
[cpg]


[OnName num="sho"]
I like you, Mayu-san. ......
[cpg cn=true]


But when I said it, I was surprised that I could say it.
[cpg]


[OnName num="sho"]
I want to go out with you, I want to marry you, I want to ...... work with you as a nurse in the same place as you someday.
[cpg cn=true]


He said it all at once. Mayu looked at me with a puzzled look on her face.
[cpg]


But soon, she smiled. She smiled.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu147"]
[OnName num="mayu"]
She said, "I see. I see.
[cpg cn=true]


Mayu-san is smiling. What kind of smile?
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu148"]
[OnName num="mayu"]
'I think it's a good dream. But I don't know if it will come true.
[cpg cn=true]


......I see. Mayu-san doesn't take it seriously.
[cpg]

;//移植のためシーンをカットしています


[OnName num="sho"]
"Oh, I'm ...... serious about you, Mayu-san. ......
[cpg cn=true]



My feelings haven't been conveyed yet. I try to convey that somehow.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayu168"]
[OnName num="mayu"]
"You still say ....... We're quite a bit older than you, aren't we?"
[cpg cn=true]


[OnName num="sho"]
'I don't care about that.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu169"]
[OnName num="mayu"]
I can't ask you to give up, though. It's impossible.
[cpg cn=true]


[OnName num="sho"]
"...... such a thing."
[cpg cn=true]


Impossible, or ...... so? I was devastated and couldn't say anything.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu170"]
[OnName num="mayu"]
Well then, I'll be back. Sho."
[cpg cn=true]


On top of that, Mayu says she will be back.
[cpg]


I have never felt such pain.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（昼）******************************************************



As I wandered around, I got lost in the hospital.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misora105"]
[OnName num="misora"]
I wondered, "...... why are you here?　It's quite far from the hospital room.
[cpg cn=true]


I meet Ms. Misora. Well, she is a nurse too, so there is a possibility that we might meet.
[cpg]


[OnName num="sho"]
"Well, I don't ...... know if that's so.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misora106"]
[OnName num="misora"]
She looks as if she's been dumped. What happened?"
[cpg cn=true]


That is exactly the right answer. I'm not sure if it's ......
[cpg]


[OnName num="sho"]
"I want to go out with ...... Mayu. And she turned me down."
[cpg cn=true]


I wonder if I should be so honest as to tell you this.
[cpg]


I was in such a dire situation that I had to say it even so.
[cpg]


Misora crossed her arms and groaned.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misora107"]
[OnName num="misora"]
Mayu is ...... keeping romance away from herself in some ways, you know."
[cpg cn=true]


[OnName num="sho"]
'...... Is that so?'
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misora108"]
[OnName num="misora"]
'It's not a simple matter. Are you prepared?"
[cpg cn=true]


I'm ready. But I'm not sure.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



It will be night in no time. I don't feel like playing games or studying.
[cpg]


What do I want to ...... do?
[cpg]


I know what I want to do. I want to be with Mayu.
[cpg]


But will I be able to ......? That's something I can't answer yet.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu171"]
[OnName num="mayu"]
I'm not sure if I can be with Mayu or not. You look even more serious than yesterday."
[cpg cn=true]


And I had another chance to be alone with Mayu.
[cpg]


I'm going to tell her how I feel this time. That's how I felt.
[cpg]


[OnName num="sho"]
"Mayu-san, I still want to go out with you. After all, I want to go out with you.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayu172"]
[OnName num="mayu"]
"You're talking about that again, ......?
[cpg cn=true]


What's the point of getting through to you? I'm not going to change my mind no matter what it takes to get through to you.
[cpg]


[OnName num="sho"]
I'm not going to give up on you no matter what you think.
[cpg cn=true]


A little silence. And then...
[cpg]


[OnName num="sho"]
......I love you that much."
[cpg cn=true]


For some reason, I began to cry. I don't know if I'm thinking to myself that it's a love that will never come true.
[cpg]


And seeing those tears, she comes to my side.
[cpg]

;//========================================
;//●ＣＧエロ（主人公に迫るヒロイン。微笑んでいる）ev_27
;//人物１：ヒロイン２
;//服装１：ナース服
;//人物２：主人公
;//服装２：病衣
;//場所　：病院＿主人公の個室
;//時間　：昼
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMayu011"]
[OnName num="mayu"]
She said, "......The only thing I can give you is memories."
[cpg cn=true]


She says this and comes so close to me that her lips almost touch mine.
[cpg]

I feel like I'm trying to say something, but I can't. Maybe it's the same thing for Mayu. I'm not sure if it's the same for Mayu.
[cpg]

And while I was closing my eyes ...... touch.
[cpg]

[VOICE f="sMayu012"]
[OnName num="mayu"]
Chuu......"
[cpg cn=true]


It should be a happy thing. Still, it was not balanced by the sadness of being rejected.
[cpg]

I feel like I'm going to cry, but yet I feel happy at the same time.
[cpg]

I was ...... feeling so overwhelmed with my feelings that I didn't know what to do.
[cpg]

I never thought this would happen.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



I watched Mayu leave in a daze.
[cpg]


I wondered if she and I had tied the knot. No, I didn't. She just gave me a memory.
[cpg]


She just gave me memories. That must be it. ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko274"]
[OnName num="rinko"]
"You're empty on ....... I'm almost completely cured.
[cpg cn=true]


The doctor said so. I was surprised.
[cpg]


[OnName num="sho"]
Is that so?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko275"]
[OnName num="rinko"]
Yes, that's right. Normally, I would be more pleased if my injury was going to be healed.
[cpg cn=true]


[OnName num="sho"]
"I guess you're right. ......
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（夕方）******************************************************



I somehow couldn't stay and go, so I was out in the hallway.
[cpg]


That doesn't mean there is something to distract you.
[cpg]


If I may say so, there are places where patients gather to socialize, but they are all grandparents.
[cpg]


It's no use for me to go there.
[cpg]


No, more to the point, ...... I didn't care about anyone but Mayu-san.
[cpg]


Mayu. Without her, I'm going to be lost.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

Then, the day before I left the hospital.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



[OnName num="sho"]
"...... Mayu-san, can I have your cell phone number?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu193"]
[OnName num="mayu"]
"Hmmm. No. We are not lovers, are we?
[cpg cn=true]


[OnName num="sho"]
Yes, we are."
[cpg cn=true]


I feel kind of unmotivated.
[cpg]


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

No matter how far we go, we are still strangers.
[cpg]

;//========================================
;//●ＣＧエロ（寝ている主人公に近づくヒロイン。主人公の体に片手を当てている）ev_28
;//人物１：ヒロイン２
;//服装１：ナース服（はだけ）
;//人物２：主人公
;//服装２：病衣
;//場所　：病院＿主人公の個室
;//時間　：夕方
;//========================================




[BGM f="bg_h1"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sMayu013"]
[OnName num="mayu"]
Don't make that face."
[cpg cn=true]


[OnName num="sho"]
"......"
[cpg cn=true]


Even though she said that, I was still feeling sad.
[cpg]

I think I have that look on my face, and I'm sure she's aware of it.
[cpg]

Only now, she is approaching me. What does she mean by that?
[cpg]

Even this, I don't know if it's because she likes me in the first place.
[cpg]

Even that is wishful thinking. He can't possibly like me because he's rejected me.
[cpg]


;//;**【ＣＧ】 ev_28_a ***********************
;//[CG id=14 index=1 time=1]
;//;***************************************
;//[WAIT time=1]


[VOICE f="sMayu014"]
[OnName num="mayu"]
I can tell you're thrilled."
[cpg cn=true]


I'm not sure if it's a good idea, but it's a good idea.
[cpg]

I feel like ...... I really can't help it.
[cpg]

I am disgusted with my simplicity, but I can't stop it.
[cpg]

I can't stop my feelings. I knew that.
[cpg]


;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_hu"]
;//[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************


And then came the end of those days.
[cpg]

I couldn't postpone it no matter how hard I tried.
[cpg]


;//ブラックアウト

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『病院＿ロビー』（昼）******************************************************



The day I was discharged from the hospital. Everyone congratulated me and seemed happy, but ...... I was the only one feeling down.
[cpg]


I was not sure if I would be able to see Mayu again. No, I can't give up now.
[cpg]


I want to work at the same place as Mayu. I definitely had that feeling.
[cpg]


Even if I didn't, I was still going to pursue her. ......
[cpg]


I couldn't give up at a place like this.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



Then... I went to college to study nursing.
[cpg]


It's not as hard as becoming a doctor. It wasn't impossible if I wanted to do it.
[cpg]


I wanted to follow in Mayu's footsteps.
[cpg]


Along the way, for example, I was confessed by another classmate to graduate from the previous school. ......
[cpg]


But I didn't care about that.
[cpg]


I didn't care about other girls at all. This is true.
[cpg]


For now, I decided not to see Mayu until I became independent and started studying.
[cpg]


I dreamed of living with Mayu ......
[cpg]


;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Quite a lot of time passed. Years and months pass.
[cpg]


It felt like a flash of time. That's how dense the time I spent with Mayu was.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



I then searched for the hospital where Mayu-san worked.
[cpg]


The hospital where Dr. Misora and Misora used to work was no longer there.
[cpg]


So, when I applied for a job, I wanted to work at the hospital where Mayu-san is now.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



Then, at ...... after work.
[cpg]


I grabbed her in plain clothes, not a nurse's uniform, and asked to speak with her.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayu233"]
[OnName num="mayu"]
She said, "......You really followed me here, didn't you?"
[cpg cn=true]


[OnName num="sho"]
'That's good, now that you mention it. I'd like to say it one more time.
[cpg cn=true]


[OnName num="sho"]
I like you."
[cpg cn=true]


I approached Mayu with a serious gaze. Then, Mayu said.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMayu015"]
[OnName num="mayu"]
Even if I am married?　Would you still be okay with that?
[cpg cn=true]


[OnName num="sho"]
She said something that made me feel bitter.
[cpg cn=true]


She said something that made me feel bitter. But I couldn't back down.
[cpg]


[OnName num="sho"]
I don't care what kind of person I am to you. I don't care what kind of presence I have for you, Mayu, I want to be by your side."
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayu235"]
[OnName num="mayu"]
I said, "......, you are a person who has no choice."
[cpg cn=true]




;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


This is adultery. The first thing to do is to make sure that you have a good relationship with your partner.
[cpg]


But I couldn't give up my current happiness.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



...... and a few more days pass.
[cpg]


I was still keeping my distance from Mayu.
[cpg]


It was then that I was surprised.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sMayu016"]
[OnName num="mayu"]
"I'm single. Didn't I tell you that?"
[cpg cn=true]


[OnName num="sho"]
"What?　But I just asked her if she liked me even if she was married.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMayu017"]
[OnName num="mayu"]
I just asked her if she liked me even though she was married. I didn't say I was really married.
[cpg cn=true]


I was taken aback. I was surprised, but little by little, I began to feel happy.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu254"]
[OnName num="mayu"]
What should we do when we get home today?
[cpg cn=true]


Mayu-san was going to quit her job as a nurse soon.
[cpg]


I would have to support her. I can't even imagine what that's like. ......
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu255"]
[OnName num="mayu"]
'Shall I dress up as a nurse for you at home today?'
[cpg cn=true]


...... I kind of wonder if that's called cosplay.
[cpg]



;//========================================
;//●ＣＧエロ（ナース服で主人公に覆い被さるヒロイン）ev_31
;//人物１：ヒロイン２
;//服装１：ナース服
;//人物２：主人公
;//服装２：私服
;//場所　：ヒロイン２の部屋
;//時間　：夜
;//備考　：本編から四年が経過しています
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_31_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMayu018"]
[OnName num="mayu"]
I don't know if that's called cosplay. This reminds me of when I first met you."
[cpg cn=true]


As she declared, she came at me in a nurse's outfit.
[cpg]

This dreamy time is coming again.
[cpg]

I had nothing more to wish for. ......
[cpg]

I want to stay by her side forever. I'm sure that's what we both think.
[cpg]

There was nothing separating us anymore.
[cpg]

Maybe there never was from the beginning. ......
[cpg]


;//移植のためシーンをカットしています
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



She is not married. She also said she was quitting her job as a nurse.
[cpg]


And I already have a job. ...... We have feelings for each other.
[cpg]


There was nothing separating us anymore.
[cpg]


We became husband and wife.
[cpg]



;//========================================
;//●ＣＧ非エロ（隣り合って歩く二人。主人公の腕にすがるヒロイン、笑顔）ev_32
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：街
;//時間　：昼
;//備考　：本編から四年が経過しています
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_d1"]
;**【ＣＧ】 ev_32_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]



Mayu spoils me as always.
[cpg]


I, on my part, was fine with being spoiled.
[cpg]


But sometimes Mayu would cling to my arm like this.
[cpg]



[VOICE f="Mayu273"]
[OnName num="mayu"]
It's like we've really become husband and wife in this way.
[cpg cn=true]


We really are, though. Well, never mind.
[cpg]


Since then, Mayu-san sometimes dresses up as a nurse.
[cpg]


I guess we will continue to live our lives remembering how we met.
[cpg]


It all started with an unfortunate accident, but you never know what life has in store for you.
[cpg]


So I could feel that whatever misfortunes we may have in the future, they will turn out to be good.
[cpg]


In a way, we are invincible now.
[cpg]



;//ＥＮＤ：ヒロイン２ルート

[SCENE id=10]

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


