
*start

;#################################################
*Ep003|Those who have left unfinished business.
;#################################################

[SCENE id=3]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************


;//0415修正
I'm back in my room today after another hard day of rehab.
[cpg]

It's harder than I thought it would be ......, no, much harder. This might have been better if I hadn't gotten the cast off.
[cpg]



[OnName num="sho"]
"Oh, I feel terrible......."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu071"]
[OnName num="mayu"]
'Thanks for the help. Sho."
[cpg cn=true]


Really, Mayu is a healer. Without her, my heart might have been broken.
[cpg]




;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



I can't eat rice by myself yet. I can't move my arms freely.
[cpg]


Today, Misora made me eat lunch.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misora058"]
[OnName num="misora"]
Dararu ...... kattaru."
[cpg cn=true]


What Misora-san says is always similar.
[cpg]


It's good that I'm a guy, but it would be tough if I were in charge of a woman.
[cpg]


I rather imagine ...... that they would take that into account when they are in charge.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



While I was doing that, it was already nighttime.
[cpg]


Time passes quickly or slowly,......, it's hard to say.
[cpg]


The same is true when I was a student at the academy.
[cpg]


But thanks to the three of us, there are of course times when it's not boring.
[cpg]


They do things for me that I haven't experienced in my entire life.
[cpg]


When I leave this hospital, all of ...... will be over.
[cpg]


Part of me feels like I'm going to miss it, and part of me wants to heal my injury as soon as possible.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿リハビリ室』（朝）******************************************************



[OnName num="sho"]
'Ouch, I tell you it hurts!　It's tearing, it's breaking my bones..."
[cpg cn=true]


This is how I feel every time I go through rehabilitation. Maybe I'm more sensitive to pain than others.
[cpg]


But still, I can't believe it's so painful. ...... I wonder how everyone endures it.
[cpg]


I'm not sure if I'm just not saying it out loud, but I wonder if everyone else is in a lot of pain.
[cpg]


[OnName num="sho"]
I'm not going to get better, I'm going to stop.
[cpg cn=true]


Either way, I couldn't help but say it out loud.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



I limped back to the hospital room. Misora was waiting for me there.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misora059"]
[OnName num="misora"]
She said I was late.
[cpg cn=true]


[OnName num="sho"]
She's not late, she's always on time.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misora060"]
[OnName num="misora"]
The first thing you need to do is to get a good look at the pictures. I'm not going to be able to do that.
[cpg cn=true]


That's a terrible thing to say. But from Mr. Misora's point of view, that's probably how it is.
[cpg]


[OnName num="sho"]
I'm not sure if it's a good idea to have a meal with them.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misora061"]
[OnName num="misora"]
I know."
[cpg cn=true]


Misora says that and feeds me my food.
[cpg]


I think she is basically just doing her duties as a nurse and not being nice.
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



Then one day, another classmate came to visit me.
[cpg]


[OnName num="female_student"]
Iwaguchi-kun,...... well, here."
[cpg cn=true]


He brought me a notebook so that I wouldn't fall behind in my studies.
[cpg]


[OnName num="sho"]
'...... good?　Won't it bother you?"
[cpg cn=true]


[OnName num="female_student"]
I'm fine with it. I'll go to ...... if it's for Iwaguchi-kun.
[cpg cn=true]


[OnName num="sho"]
For ......?
[cpg cn=true]


[OnName num="female_student"]
"No, nothing!　See you later."
[cpg cn=true]



[SE f="se006"]
;//【ＳＥ】『ドア閉まる』



The girl who had just left closed the door and walked out with a panicked look on her face.
[cpg]


The actual "I'm not a fan of the way you do it," he said, "but I'm not a fan of the way you do it.
[cpg]


I knew what it meant, but I pretended I didn't know.
[cpg]


But I can't seem to get into it.
[cpg]


I'm good at studying, but I don't like it.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



The next morning. I had to go to rehab again today.
[cpg]


Although I was feeling a bit uncomfortable, the parts of my body that I can move are steadily increasing.
[cpg]


For example, I can move my hands. I asked him to bring the game console from home.
[cpg]


[OnName num="sho_mother"]
I'm not sure if there's anything you want, Xiang.　Something to bring or ......?"
[cpg cn=true]


Mom asked me that, and I decided to say so without hesitation.
[cpg]


[OnName num="sho"]
I'd like you to bring me a game console then."
[cpg cn=true]


I have zero interest in studying. But I think she knows what kind of guy I am.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（朝）******************************************************



I'm getting better to the point where I can walk with crutches.
[cpg]


I can even walk to rehab.
[cpg]


The question is, how long will I need crutches? ......
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



After the rehabilitation, I go back to the hospital room.
[cpg]


I'm exhausted, even though I'm used to it by now.
[cpg]


I was exhausted, but the doctor was waiting for me in the hospital room.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko061"]
[OnName num="rinko"]
He said, "Thanks for your hard work. Is rehabilitation hard?
[cpg cn=true]


[OnName num="sho"]
"Well, yes, it's ...... hard, if you say it's hard, but, you know, it's ......"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sRinko015"]
[OnName num="rinko"]
Yes, it is. Yes, you need to take a break once in a while.
[cpg cn=true]


The teacher said that and came closer to me.
[cpg]

I can't move my body freely, but that's a good thing. ......
[cpg]

I'm not sure if it's the fact that I can't refuse them or if it's the fact that it burns me up.
[cpg]


;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



A while later, it was time for no one to be around again.
[cpg]

I can't help but be bored, but oh well. They'll probably bring a game console one of these days, and I'll just play with it.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



And the next morning. Mom had brought the console.
[cpg]


[OnName num="sho"]
"Thanks, Mom.
[cpg cn=true]


[OnName num="sho_mother"]
"You're a good student, but I don't know why you're like this.
[cpg cn=true]


[OnName num="sho"]
"It can't be helped, you're not motivated. ......
[cpg cn=true]


I know that. I know that.
[cpg]


So I decided to play the game without hesitation.
[cpg]


I usually can't play games all day long, but I'm going to play all the games I can.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿リハビリ室』（朝）******************************************************



Of course, I'm going to do it while I'm going through a rehabilitation process that's killing me. ......
[cpg]


But once I get back to the hospital room, my time will be waiting for me.
[cpg]


I could manage to do so.
[cpg]


[OnName num="sho"]
"It hurts!　I think it's still broken!"
[cpg cn=true]


Even though I'm saying this: ......
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



Then, noon. The doctor came to check my progress.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko080"]
[OnName num="rinko"]
He said, "You seem to be doing well. If things continue as they are, you should be on the road to recovery.
[cpg cn=true]


[OnName num="sho"]
"Well, uh,...... well, aren't you going to do anything for me today?"
[cpg cn=true]


I said frankly. The doctor doesn't even laugh.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko082"]
[OnName num="rinko"]
He said, "If you say something too seductive, I won't be able to stop you.
[cpg cn=true]


It was really a cold gaze. But I'm like.
[cpg]


[OnName num="sho"]
I had no choice but to reply, "I'm fine with ......."
[cpg cn=true]


I had no choice but to reply. And then ......
[cpg]




;//ブラックアウト

;//========================================
;//●ＣＧエロ（寝ている主人公に顔を近づけるヒロイン）ev_13
;//人物１：ヒロイン１
;//服装１：白衣
;//人物２：主人公
;//服装２：裸
;//場所　：病院＿主人公の個室
;//時間　：昼
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_13_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sRinko016"]
[OnName num="rinko"]
She's a lovely person, isn't she?
[cpg cn=true]


And then she comes closer to me.
[cpg]

I don't know what the teacher is really thinking. I can't be sure how serious he is.
[cpg]

I don't know if she really thinks ...... he's cute or not.
[cpg]

That's how unreadable his facial expressions are and how unfathomable his personality is.
[cpg]

[OnName num="sho"]
I'm at .......
[cpg cn=true]


What's wrong?　says the teacher.
[cpg]

I can't say, "Thanks, I'm not ......," but I try to look nonchalant.
[cpg]

He comes close enough to me that my breath hits him. Still, I don't kiss him or anything.
[cpg]

It's like a raw kill, but it was also good.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

The teacher is just the coldest, and there is a gap between the usual.
[cpg]

He is so charming that I wonder if everything is calculated.
[cpg]

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



I was enjoying this distance more than anything else.
[cpg]


I was even looking forward to seeing what she would do in the future.
[cpg]


I had been friends with other girls in my class, but this was the first time I had ever felt this way.
[cpg]


I'm sure it's someone like her that really drives me .......
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（夕方）******************************************************



Aside from that, I was able to move around as long as I had crutches.
[cpg]


So I was able to look around the hospital.
[cpg]


What can I say, it's a big hospital. It's hard to move with crutches, but even with that, it's hard to walk around.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿ロビー』（夕方）******************************************************



And I found myself at the lobby.
[cpg]


I couldn't go any further. I thought so and tried to go back.
[cpg]


However, I recovered unthinkably from the first time.
[cpg]


I guess a broken bone heals pretty quickly.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（夕方）******************************************************



And in the hallway on the way home. I saw a private room with the door slightly ajar.
[cpg]


[OnName num="sho"]
I heard Misora's voice, "...... what is it?"
[cpg cn=true]


I thought I heard Misora's voice, and I peeked through the crack in the door.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


There, ...... Misora was with a patient who was not me.
[cpg]

;//ブラックアウト

The relationship was not just nurse and patient.
[cpg]

It was more like ...... awfully close. Just like she was doing to me .......
[cpg]

She apparently doesn't know I'm watching her.
[cpg]


I should walk away soon. Still, I couldn't move.
[cpg]

;//ブラックアウト

;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（夕方）******************************************************



I saw the whole thing.
[cpg]


And Misora-san comes this way. I tried to leave right away, but I couldn't walk well on crutches.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misora096"]
[OnName num="misora"]
She said, "...... what?　Were you watching?"
[cpg cn=true]


[OnName num="sho"]
That's ......."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misora097"]
[OnName num="misora"]
"It's okay, I don't care if you're watching. It doesn't make it any worse.
[cpg cn=true]

[free time=1000]

And then he left. He didn't seem to feel sorry for me. ......
[cpg]



;//■選択肢
[switch]
[case "I guess that's the kind of person he is."]
	[swap]
	[jump target="*select03_1"]
[case "I'm shocked because I thought he would only do it for me."]
	[swap]
	[jump target="*select03_2"]
[endswitch]



1, I guess that's the kind of person he is.
2. I'm shocked because I thought he would only do it for me.



;//==============================
;//１、そういう人なのだろう
*select03_1|Those who have left unfinished business.

[stflag Cha3flg = 1]
[system sysCha3flg=true]

Maybe that's the kind of person Mr. Misora is.
[cpg]


I am sure he is not satisfied with me alone. I had somehow guessed that in part.
[cpg]


Although I think that there is nothing to be depressed about now ......, I still feel a little depressed.
[cpg]



;//この選択肢を選んだ場合ヒロイン３が候補に

[jump target="*select03_3"]

;//==============================
;//２、自分だけにしてくれると思っていたのにショックだ

*select03_2|Those who have left unfinished business.
[system sysCha3flg=false]

Misora-san didn't care about me.
[cpg]


I thought she would only do it for me. I'm shocked. ......
[cpg]


But I guess it's no use saying that.
[cpg]



;//==============================

*select03_3|Those who have left unfinished business.

;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



Then I went back to my private room and thought.
[cpg]


I haven't had Mayu do me lately. Even though we see each other, ......
[cpg]


I guess I should be the one to tell her. Time passed as I thought that.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



The next morning. Mayu came to my place.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu093"]
[OnName num="mayu"]
She asked me, "Are you having any inconvenience?　She seemed to be having a good time.
[cpg cn=true]


I was just playing a game, so Mayu-san laughed.
[cpg]


But I was tired of playing games. I'm about to do some studying to pass the time.
[cpg]


[OnName num="sho"]
I'm on the road to recovery.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayu094"]
[OnName num="mayu"]
Yes, I'm a little disappointed. It's a pity.
[cpg cn=true]


[OnName num="sho"]
"Too bad?　What do you mean?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu095"]
[OnName num="mayu"]
I didn't say ....... You must have misheard me.
[cpg cn=true]


No, you just said it. You're not fooling yourself.
[cpg]


It's not just that she misses me leaving the hospital.
[cpg]


Mayu misses me too. If I'm not mistaken, I'm sure ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sMayu007"]
[OnName num="mayu"]
I'm sure she missed me more than that."
[cpg cn=true]


He says this in a tone of voice that doesn't sound arrogant.
[cpg]

If she said this to me, there was no way I could say no.
[cpg]



;//ブラックアウト

;//========================================
;//●ＣＧエロ（胸を強調しつつ、服を着ているヒロイン）ev_15
;//人物１：ヒロイン２
;//服装１：ナース服
;//人物２：主人公
;//服装２：病衣
;//場所　：病院＿主人公の個室
;//時間　：朝
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_15_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]



As she gets closer, I can sense her scent.
[cpg]

I wonder if Mayu can also smell me.
[cpg]

[VOICE f="sMayu008"]
[OnName num="mayu"]
You have a high body temperature, don't you?
[cpg cn=true]


I have never paid attention to such things.
[cpg]

And when our hands touch, Mayu's body temperature also feels high.
[cpg]

[OnName num="sho"]
'...... I wonder if that's so.'
[cpg cn=true]


Mayu-san moves her body closer to mine. She seems to have no hesitation.
[cpg]

The first thing to do is to make sure that you have a good idea of what you're doing.
[cpg]

She is a person who is aggressive, but never overreacting. ......
[cpg]

I can't be too dismayed. I can't show him my embarrassment.
[cpg]

Even though I was at the mercy of him, I tried to remain as calm as possible.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sMayu009"]
[OnName num="mayu"]
I said, "......See you then. Let's stay together until the day you get out of the hospital."
[cpg cn=true]


Discharge. That word sounds pretty heavy.
[cpg]

[free time=1000]
The time that I thought would last forever is gradually coming to an end.
[cpg]


I still have lingering feelings for them. But who do I love in the end?
[cpg]


I think of a woman's face.
[cpg]



[if exp={getFlagValue("Cha1flg") == 0 }]
[if exp={getFlagValue("Cha2flg") == 0 }]
[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*select04_5"]
[endif]
[endif]
[endif]


[if exp={getFlagValue("Cha1flg") == 1 }]
[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*s_all"]
[endif]
[endif]
[endif]



[if exp={getFlagValue("Cha1flg") == 1 }]
[if exp={getFlagValue("Cha2flg") == 0 }]
[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*select04_1"]
[endif]
[endif]
[endif]

[if exp={getFlagValue("Cha1flg") == 0 }]
[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 0 }]
[jump target="*select04_2"]
[endif]
[endif]
[endif]

[if exp={getFlagValue("Cha1flg") == 0 }]
[if exp={getFlagValue("Cha2flg") == 0 }]
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*select04_3"]
[endif]
[endif]
[endif]


[if exp={getFlagValue("Cha1flg") == 0 }]
[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 1 }]

[switch]
[case "Mayu."]
	[swap]
	[jump target="*select04_2"]
[case "Misora"]
	[swap]
	[jump target="*select04_3"]
[endswitch]

[endif]
[endif]
[endif]

[if exp={getFlagValue("Cha1flg") == 1 }]
[if exp={getFlagValue("Cha2flg") == 0 }]
[if exp={getFlagValue("Cha3flg") == 1 }]

[switch]
[case "Teacher"]
	[swap]
	[jump target="*select04_1"]
[case "Ms. Misora"]
	[swap]
	[jump target="*select04_3"]
[endswitch]

[endif]
[endif]
[endif]

[if exp={getFlagValue("Cha1flg") == 1 }]
[if exp={getFlagValue("Cha2flg") == 1 }]
[if exp={getFlagValue("Cha3flg") == 0 }]

[switch]
[case "Teacher"]
	[swap]
	[jump target="*select04_1"]
[case "Mayu."]
	[swap]
	[jump target="*select04_2"]
[endswitch]

[endif]
[endif]
[endif]

*s_all|Those who have left unfinished business.

;//■選択肢
[switch]
[case "Teacher"]
	[swap]
	[jump target="*select04_1"]
[case "Mayu."]
	[swap]
	[jump target="*select04_2"]
[case "Misora"]
	[swap]
	[jump target="*select04_3"]
[case "I love you all."]
	[swap]
	[jump target="*select04_4"]
[endswitch]



1, Teacher
2, Mayu
3, Misora
4. I love you all.



;//※候補となっているヒロインから選択
;//※ルート分岐。選んだヒロインのルートへと進む
;//※選択肢４は全員が候補になっていて、他の全てのルートを通っている場合発生
;//※誰も候補になっていない場合、最下の【候補が居ない場合】ルートへ



*select04_1
[jump storage="ep004.ks" target="*select04_1"]

*select04_2
[jump storage="ep005.ks" target="*select04_2"]

*select04_3
[jump storage="ep006.ks" target="*select04_3"]

*select04_4
[jump storage="ep008.ks" target="*select04_4"]

*select04_5
[jump storage="ep007.ks" target="*select04_5"]
