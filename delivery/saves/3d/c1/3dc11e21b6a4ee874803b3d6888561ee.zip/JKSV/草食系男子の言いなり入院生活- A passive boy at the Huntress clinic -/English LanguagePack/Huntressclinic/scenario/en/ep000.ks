
*start

;//入淫病棟　シナリオ
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//凛子　　裸　白衣　私服
;//麻友　　裸　ナース服　私服
;//美空　　裸　ナース服　私服
;//台本用で仕上げるため、主にＨシーンを短く書いておりました
;//現在は追加済みです
;//以下音声なし
;//翔 男子学生 翔の母 翔の父 女子学生 男

;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//凛子　一人称「私」　麻友呼び「麻友さん」　美空呼び「美空さん」　翔呼び「翔さん」
;//麻友　一人称「私」　凛子呼び「先生」　美空呼び「美空さん」　翔呼び「翔くん」
;//美空　一人称「私」　凛子呼び「先生」　麻友呼び「麻友」　翔呼び「翔」
;//翔　　一人称「俺」　凛子呼び「先生」　麻友呼び「麻友さん」　美空呼び「美空さん」

;//以下、残したＣＧを列挙いたします
;//凛子 ev_01 ev_04 ev_13 ev_16 ev_17 ev_19 ev_24
;//麻友 ev_02 ev_07 ev_15 ev_27 ev_28 ev_31 ev_32
;//美空 ev_03 ev_06 ev_09 ev_35 ev_36 ev_38

;///////////////////////////ここから本編です///////////////////////////


;#################################################
*Ep000|After school I'll never forget.
;#################################################

[SCENE id=0]

[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



It may have been the most important event in my life.
[cpg]


I'll never forget it. It happened on the way home after school.
[cpg]


[OnName num="sho"]
I was thinking, "Oh, by the way, it's almost time for the test.
[cpg cn=true]


I can study, but I have no motivation. I was that lazy honor student, Sho Iwaguchi.
[cpg]


[OnName num="male_student"]
"Oh, a test... ...... is so lazy.
[cpg cn=true]


[OnName num="sho"]
I wonder if I'm lazy. I've never thought of it as lazy.
[cpg cn=true]


A good friend of mine, a boy, looks at me with a sour look in his eyes.
[cpg]


[OnName num="male_student"]
I'm sure a diligent student like Iwaguchi can do well.
[cpg cn=true]


[OnName num="sho"]
I don't study much, you know that if you listen to ...... the class.
[cpg cn=true]


[OnName num="male_student"]
I don't get it. I don't know. Smart guys are always on top of everything.
[cpg cn=true]


[OnName num="sho"]
"So ......?　I guess I'm a smart guy. ......
[cpg cn=true]


We were crossing the street, talking nonsense.
[cpg]


I think the light was green. But I was like.
[cpg]


[OnName num="male_student"]
I looked back and heard a voice at the end saying, "Watch out!
[cpg cn=true]



[FADEOUTBGM]


I heard a voice at the end and turned around.
[cpg]



[SE f="se001"]
;//【ＳＥ】『車のブレーキ』



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I am an unremarkable male student.
[cpg]


I was on my way home from school today. I was walking to school because it was close to the school.
[cpg]


I was enjoying my school life, a life without any particular inconvenience. ......
[cpg]


[free time=1000]
[BG f="white.ui" time=1000]
[WAIT time=1000]
;//ホワイトアウト



Time flew away. It wasn't like going to sleep and waking up, time really flew by.
[cpg]


It was the first time in my life that I experienced this and I was bewildered.
[cpg]


When I came to, I was really surprised to find myself in the hospital.
[cpg]


Surrounded by doctors and family. And I couldn't move even if I wanted to.
[cpg]


Seeing my family crying and rejoicing over my safety, I realized that I had indeed suffered a serious injury.
[cpg]


No, you're not okay. ......, I thought vaguely, I'm in a lot of trouble.
[cpg]



;//========================================
;//●ＣＧ非エロ（主人公を冷たく見下ろしながらカルテを手に取っているヒロイン）ev_01
;//人物１：ヒロイン１
;//服装１：白衣
;//人物２：主人公
;//服装２：病衣
;//場所　：病室
;//時間　：夜
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_me"]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]



;//しばらく凛子の名前を『女医』と隠してください


The doctor said I was injured in a car accident.
[cpg]

I could understand that somehow. I knew that since I had a cast on, I must have broken it or something.
[cpg]


[VOICE f="Rinko002"]
[OnName num="female_doctor"]
I'm going to be in rehab for quite a while.
[cpg cn=true]


;//0414修正
I heard that the cast will come off rather soon.
[cpg]

But even after the cast is removed, rehabilitation is necessary, and that takes time, he said.
[cpg]

The person who explained this to me, who looked a little scary, was apparently a female doctor.
[cpg]


I was still unsure of what had happened, but I was gradually getting a grasp of what was going on.
[cpg]


I realized that I had been involved in a really terrible accident.
[cpg]



[VOICE f="Rinko003"]
[OnName num="female_doctor"]
"Are you listening to me?　You were really close to death."
[cpg cn=true]


I was just a little hazy, but that's what the doctor said to me.
[cpg]


[OnName num="sho"]
She said, "Yes, I'm listening to ......."
[cpg cn=true]


I sigh. I don't have a bad attitude, but she seems to be kind of cold.
[cpg]


The person who gave me a scary impression is a female doctor named Rinko Yamamura, I was told later.
[cpg]



;//ここから凛子の名前を隠さないでください



I have an image of a gentle female doctor, but apparently my doctor was different.
[cpg]


Is she really gentle ......?　I'll have to live here from now on to find out.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



I guess it's going to be like this for a while, rather than just a night ...... at the hospital that day.
[cpg]


I couldn't sleep at all because the situation was somehow so different from usual.
[cpg]


I couldn't move my legs. I can't move my hands either. So, there are only a few things I can do.
[cpg]


I am right-handed, so it was difficult at first, but I managed to learn to operate the phone with my left hand.
[cpg]


It wasn't so much that I learned to do it, but rather it was something I had to do because I had to.
[cpg]


I keep in touch with my friends on social networking sites. I wanted to send them a "Oh my God, it's nothing." ......
[cpg]


I can't move, even though I don't feel much pain.
[cpg]


I think that if I move it, it probably won't hurt as much as it should.
[cpg]


I wonder if "it's no big deal" is the right response.
[cpg]


I wondered if it was nothing at all, and wondered how to respond.
[cpg]


In the end, I sent a curt response that it would get better in time, but I didn't know how to respond to .......
[cpg]


Of course it will get better in time, but how will I live until then?
[cpg]


I won't be able to eat. Will I be put on a drip?
[cpg]


I don't like ...... eating time, though I like it a lot. ......
[cpg]


Still, you say hospital food doesn't taste very good.
[cpg]




;//ブラックアウト



[SE f="se006"]
;//【ＳＥ】『ドア開く』


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



As I was thinking this, someone who looked like a nurse came to me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu001"]
[OnName num="mayu"]
It's nice to meet you," she said. My name is Mayu Sasaki.
[cpg cn=true]


Apparently, she was my nurse. She was so beautiful that I was about to get a nosebleed.
[cpg]


I didn't know where to put my eyes. She is that beautiful.
[cpg]


[OnName num="sho"]
She said, "Nice to meet you, I'm ...... Iwaguchi."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu002"]
[OnName num="mayu"]
I know who you are. I know who you are, Sho-kun.
[cpg cn=true]


I didn't need to say my name, but I did.
[cpg]


I'm not sure if it's necessary for me to say my name. Also, I wonder if this is what it is like to be a ...... nurse who is called in a strange way.
[cpg]


I don't know, but I think not. There are more other ways to call them. ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu003"]
[OnName num="mayu"]
I'm going to go to the kitchen and have some dinner. Well then, I'll help you."
[cpg cn=true]


[OnName num="sho"]
"What do you mean by 'help' ......?
[cpg cn=true]



;//ブラックアウト



;//========================================
;//●ＣＧ非エロ（ご飯をスプーンで口元に運ぶヒロイン。優しい笑顔）ev_02
;//人物１：ヒロイン２
;//服装１：ナース服
;//人物２：主人公
;//服装２：病衣
;//場所　：病院＿主人公の個室
;//時間　：朝
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]




[VOICE f="Mayu004"]
[OnName num="mayu"]
"Yes, uh-uh."
[cpg cn=true]


[OnName num="sho"]
"...... uh-uh."
[cpg cn=true]


I'm embarrassed. It's like a lover. No, I mustn't think of anything else.
[cpg]


No matter how kind this person is to me, he is someone I will never meet once I leave this hospital.
[cpg]


I held back the urge to fall in love with him.
[cpg]



[VOICE f="Mayu005"]
[OnName num="mayu"]
If you don't need me anymore, please let me know.
[cpg cn=true]


Is this normal?　I think hospitals are more like this .......
[cpg]


I was strangely conscious of this, and I was embarrassed.
[cpg]


[OnName num="sho"]
"Yes,...... I want to eat some more.
[cpg cn=true]



[VOICE f="Mayu006"]
[OnName num="mayu"]
I'm not sure what to do with the rest of it. You are a lovely person,...... then, a little more."
[cpg cn=true]


With such conversation, I was in a state of bliss.
[cpg]


I'm sure she's older than she should be,......, but she's a cute nurse.
[cpg]


But she is also a beautiful woman. Of course, the doctor in charge of my case would be the same type of beautiful woman.
[cpg]


But I don't think there is anyone who would look at Mayu and say she is not beautiful. She has a great style, and she probably has a lot of fans.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



Then I would be free for a while. Her parents both work and she is a busy person, so she won't be able to come to my place so easily.
[cpg]


But still, I have a lot of free time. If there is no nurse or female doctor, then ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko004"]
[OnName num="rinko"]
How have you been since then, Sho?
[cpg cn=true]


[OnName num="sho"]
"Eh,...... ah, yes,...... well, normal."
[cpg cn=true]


I was in a daze again. I answered very randomly.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Rinko005"]
[OnName num="rinko"]
I answered in a very vague way again, "It can't be normal, can it? I can't move my body.
[cpg cn=true]


The doctor said something that sounded like a "sure thing" to me.
[cpg]


[OnName num="sho"]
He said, "...... Yes, there are a lot of inconveniences.
[cpg cn=true]


This time, I thought about it and responded.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko006"]
[OnName num="rinko"]
I replied, thinking properly this time. There is only so much we can do, but we will do our best.
[cpg cn=true]


It's rare for a doctor to say that there's only so much he can do. I thought to myself, "I'm going to go to ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko007"]
[OnName num="rinko"]
I'll come back periodically to check on your progress. If you have any inconvenience, please tell the nurse.
[cpg cn=true]


At first I thought it sounded scary, but what the heck. You seem like a serious person. ......
[cpg]


Maybe there is a point that serious people look scary.
[cpg]


[free time=1000]

While I was thinking that, the teacher leaves the room. I'm alone again.
[cpg]


Without my phone, I would have died of boredom, but there were enough things in the room for me to be able to charge my phone by myself, for example.
[cpg]


Who took care of me?　I guess it was Mayu-san.
[cpg]


Or the teacher ......?　A tsundere thing ......?　But I don't think that place has anything to do with medical care.
[cpg]


I wonder if the doctor would consider that as medical care too. I don't know.
[cpg]


[OnName num="sho"]
"...... hmmm."
[cpg cn=true]


I think about it a lot. When I start to have strange thoughts, the best thing to do is to move my body.
[cpg]


But I couldn't move my body right now.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
After that, every time I felt hungry, Mayu-san came to me.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu007"]
[OnName num="mayu"]
"Aaan.
[cpg cn=true]


[OnName num="sho"]
......
[cpg cn=true]


It is an indescribable feeling to be fed by such a beautiful woman.
[cpg]

Thinking dirty thoughts, I was fed by her.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



In this way, the first day passed. I really can't leave this room even once.
[cpg]


It's more than inconvenient, it's crippling,...... but it can't be helped.
[cpg]


I was injured. It was an irrational incident, but it wasn't like the school was absurdly fun or anything.
[cpg]


I didn't hate studying, but I didn't like it either. If I had to say whether I could do it or not, I'd say I was pretty good at it.
[cpg]


However, I didn't want to go to a very smart school with a high deviation score.
[cpg]


I was spending my days in a kind of daze.
[cpg]


Maybe God gave me a punishment like that, like I shouldn't go on like this.
[cpg]


If so, I have no choice but to accept it.
[cpg]


I've been lazy for a long time now. Maybe even a hospital stay won't change that.
[cpg]


I was thinking this as the day was drawing to a close.
[cpg]



;//========================================
;//●ＣＧ非エロ（だるそうな感じで病室の入り口に立っているヒロイン）ev_03
;//人物１：ヒロイン３
;//服装１：ナース服
;//人物２：主人公
;//服装２：病衣
;//場所　：病院＿主人公の個室
;//時間　：夕方
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]



;//下記のセリフのみ名前を？？？と隠してください




[VOICE f="Misora001"]
[OnName num="unknown"]
"Ha, that's so frustrating ......."
[cpg cn=true]


Someone dressed like a nurse appeared.
[cpg]


No, is this person a nurse too?　She dyed her hair and tanned her skin.
[cpg]


She's not a nurse, is she? If she wasn't a nurse, she couldn't be dressed like this in this place, right?
[cpg]


I asked her, thinking, "What's going on in this hospital .......
[cpg]


[OnName num="sho"]
"Well, um, ......, who are you ......?"
[cpg cn=true]



[VOICE f="Misora002"]
[OnName num="misora"]
Me?"　My name is Misora Abe. I'm not sure if this is a good idea or not.
[cpg cn=true]


He seems so sluggish. I wonder if he doesn't consider what he's doing now to be his duties.
[cpg]


So you're not a nurse after all?　No, you're a nurse. ...... The same thought goes around and around again.
[cpg]



[VOICE f="Misora003"]
[OnName num="misora"]
'Uh, food, right?　You're breaking my hand, aren't you?"
[cpg cn=true]


Saying that, she comes up to me. Don't tell me this guy is going to feed me dinner or something?
[cpg]


I'm a little scared. I even thought about eating it myself.
[cpg]


[OnName num="sho"]
I said, "No, thank you. My left hand is not broken.
[cpg cn=true]



[VOICE f="Misora004"]
[OnName num="misora"]
"Which hand do you use?　Normally, it's your right hand.
[cpg cn=true]


...... is right. Most people are right-handed. I'm right-handed myself.
[cpg]


[OnName num="sho"]
"......Hi, I'm left-handed. ......"
[cpg cn=true]


I got scared for some reason and lied.
[cpg]



[VOICE f="Misora005"]
[OnName num="misora"]
"Oh yeah. Well, I just do what I'm told.
[cpg cn=true]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



Saying so, Misora forcibly feeds me rice.
[cpg]


She was not at all friendly, and the way she was feeding me was also messy.
[cpg]


I can't eat rice all the time if you don't put more side dishes in between.
[cpg]


[OnName num="sho"]
Oh, um, ...... side dish too."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misora006"]
[OnName num="misora"]
"Oh, that's a hassle. ......
[cpg cn=true]


He was so lazy. How could you hire someone like this?
[cpg]


I've heard that there is a labor shortage in the medical field, or in places like this, but I don't think you need to hire someone like this.
[cpg]


But no matter how much I think or think about such things, it's not worth it. ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



And after all is said and done, it's finally time to go to bed.
[cpg]


I'm not doing anything, just sleeping and playing with my phone, but I'm rapidly tired.
[cpg]


It wasn't until late when my mom and dad came over.
[cpg]


[OnName num="sho_mother"]
"I'm sorry, I just couldn't take time off work.
[cpg cn=true]


[OnName num="sho_father"]
I wish I could stay with you more. ......
[cpg cn=true]


My family is like this. They look concerned, but I don't think they really care.
[cpg]


......No, I know. We're both busy people.
[cpg]


It's not that I don't love them. I know that.
[cpg]


I know you worry about me. So whatever it is, I hope you get your cast off as soon as possible. ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



A few days pass. I heard that there are two nurses in charge of me.
[cpg]


Mayu and Misora. And my doctor is Rinko-san.
[cpg]


In any case, I couldn't do anything, so I kept playing a smartphone game that I could do with one hand.
[cpg]


I was getting bored fast. I would try to study, but I couldn't hold a pen in the first place.
[cpg]


I had no choice but to ask my parents to bring my textbooks and study on my own.
[cpg]


I learned that even without so-called "school classes," I can still study pretty well on my own.
[cpg]


I am aware that I am fairly smart, but this doesn't make going to the school worthwhile.
[cpg]


I thought, "Maybe I should stay in the hospital all the time. ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misora007"]
[OnName num="misora"]
"Here. Eat quickly."
[cpg cn=true]


When Misora san treats me with a languid look, I change my mind a bit.
[cpg]


[OnName num="sho"]
Yes. .......
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misora008"]
[OnName num="misora"]
I'm so tired.
[cpg cn=true]


She yawns and looks sluggish. I wondered if it was okay for the nurses to have such different attitudes.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



The lights go out at night. I can't do anything anymore.
[cpg]


I can only play with my phone. It seems that a big visit to the hospital is being planned among my classmates.
[cpg]


I declined because I was embarrassed, but they might come. ......
[cpg]



[jump storage="ep001.ks" target="*start"]

