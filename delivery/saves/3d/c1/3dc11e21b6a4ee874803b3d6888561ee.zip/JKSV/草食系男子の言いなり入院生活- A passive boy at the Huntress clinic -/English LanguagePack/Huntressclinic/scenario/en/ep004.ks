
*start


;//==============================
;//１、先生
;#################################################
*Ep004|Strong Impressions by Dr. Rinko
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************


*select04_1|Strong Impressions by Dr. Rinko

[SCENE id=4]


[free time=1000]

......I still like my teacher. She is the one who fulfilled my feelings the most.
[cpg]

She is the coldest, but she makes the strongest impression on me.
[cpg]


Should I confess my feelings to her?　But she's pretty old. ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko100"]
[OnName num="rinko"]
She said, "Things are going well. It's so good that I don't even have to examine you anymore, but just in case."
[cpg cn=true]


The doctor says something like that. I still want to be with the doctor.
[cpg]


I wonder if she would say that to my face.
[cpg]


I think she is married, considering her age. It is not surprising if she has a child.
[cpg]


If she did, she would be taking them away from her husband.
[cpg]


It would destroy the family. I don't have the courage to do that.
[cpg]


But ...... if I didn't tell her how I felt, it was going to be out of control.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misora098"]
[OnName num="misora"]
"Confessing to ...... sensei?　By teacher, you mean Yamamura-sensei, right?"
[cpg cn=true]


I was talking to Misora, who had come that evening.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Misora099"]
[OnName num="misora"]
She said, "Why don't you do it? What's there to hesitate about?"
[cpg cn=true]


[OnName num="sho"]
'But ...... I think you probably have a child, and ......
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misora100"]
[OnName num="misora"]
If you can stop because of that, why don't you?"
[cpg cn=true]


Misora-san says something plausible. It's a good argument to no end.
[cpg]


But I couldn't accept that good argument. ......
[cpg]


[free time=1000]

No, I had to accept it. As I was thinking that, even Mayu came over to me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Mayu115"]
[OnName num="mayu"]
What is it?"　You two look so serious."
[cpg cn=true]


[OnName num="sho"]
'No, I mean, it's nothing.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Misora101"]
[OnName num="misora"]
She wants to confess her feelings to the teacher. It's like a child to be troubled there, isn't it?
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Mayu116"]
[OnName num="mayu"]
I see. If you are going to leave the person you love, you have to tell him or leave him as he is.
[cpg cn=true]


I see, depending on how you look at it, it's like the graduation ceremony at the school.
[cpg]


If you don't confess now, there is nothing you can do.
[cpg]


I can't wait for him to get hurt again, or the doctor might go to another hospital.
[cpg]


I'll have to make up my mind to go to .......
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿ロビー』（夕方）******************************************************



But that doesn't mean I'll be able to see the doctor when I want to.
[cpg]


I was kind of idling away in the lobby.
[cpg]


Then, by some coincidence,......, Sensei walked up to me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko101"]
[OnName num="rinko"]
He said, "Oh, ...... Sho-san. What's wrong?"
[cpg cn=true]


I was staring at the teacher with a serious face to the extent that he asked me what was wrong.
[cpg]


There were no people around. But no one would be able to hear our conversation.
[cpg]


[OnName num="sho"]
I was looking at the teacher with a serious expression on my face. I'm in love with you.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko102"]
[OnName num="rinko"]
"......, yeah."
[cpg cn=true]


[OnName num="sho"]
I don't want to ...... see you again when I get out of the hospital.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko103"]
[OnName num="rinko"]
I can't talk about it here. I'll head back to the hospital room tomorrow.
[cpg cn=true]


With that, the doctor left.
[cpg]


The fact that he didn't respond to my words left a prick in my heart.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



I wait for the teacher to come now or later.
[cpg]


I want him to put this helpless feeling away as soon as possible.
[cpg]


If not, I want him to say so. And yet ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko104"]
[OnName num="rinko"]
'......I have a husband, and I have a daughter.'
[cpg cn=true]


[OnName num="sho"]
Then ......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko105"]
[OnName num="rinko"]
'But you can still extend this life for a little while.
[cpg cn=true]


The doctor gave me a curt reply.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Rinko106"]
[OnName num="rinko"]
I can rewrite your chart a little and make it look like you need medical care.
[cpg cn=true]


[OnName num="sho"]
Is that something you're willing to do, ......?"
[cpg cn=true]

There was no way I could do that. But the doctor just laughed at me.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="sRinko017"]
[OnName num="rinko"]
You should not hesitate," he said. Or ......?
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sRinko018"]
[OnName num="rinko"]
I'll make it so you can't even think about it."
[cpg cn=true]

Saying that, she ......
[cpg]



;//========================================
;//●ＣＧエロ（主人公にのしかかるヒロイン）ev_16
;//人物１：ヒロイン１
;//服装１：白衣
;//人物２：主人公
;//服装２：病衣
;//場所　：病院＿主人公の個室
;//時間　：朝
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]


Also, she comes right up to me. I mean, this is ......
[cpg]

[OnName num="sho"]
'Hey, hey!'
[cpg cn=true]


[VOICE f="sRinko019"]
[OnName num="rinko"]
'What are you refusing to do?　You like me, don't you?"
[cpg cn=true]


It's true. But my face turns red because of the suddenness.
[cpg]

[OnName num="sho"]
'It's close, ...... sir.'
[cpg cn=true]


She acts as if she didn't hear my words.
[cpg]

And ...... we are close to each other and about to touch.
[cpg]

No, if we touch, that's kissing. You can't do that, you can't do that. ......
[cpg]

What a thought, but I couldn't do anything about it.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

She rolls her upper body over and brings her face close to mine.
[cpg]

Then she kissed me .......
[cpg]


[VOICE f="sRinko020"]
[OnName num="rinko"]
......"
[cpg cn=true]


It was just a touchy kiss, but I was so nervous I couldn't move.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



After a few stunned moments, I calmed down.
[cpg]


Then a little promise was made between me and the teacher.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Rinko123"]
[OnName num="rinko"]
He said, "If you say you love me, you must keep this one thing."
[cpg cn=true]


[OnName num="sho"]
What is it, ......?　Is this like a promise?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Rinko124"]
[OnName num="rinko"]
Yes. Yes. No matter what you do to me, you won't run away. Promise me that.
[cpg cn=true]


The teacher smiled thoughtfully.
[cpg]


But that's just what I wanted. I knew what kind of person he was.
[cpg]


[OnName num="sho"]
I know what he's like. I'm ready for it.
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



After that, the two nurses stopped doing anything when they came to me.
[cpg]


Maybe the doctor said something to them.
[cpg]


It's quite possible. I mean, it's more natural that way. ......
[cpg]


It's natural that the teacher confessed to me and tried to keep it to himself.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayu117"]
[OnName num="mayu"]
'But it's sad, isn't it? You won't choose me?"
[cpg cn=true]


[OnName num="sho"]
'Well, I think that ...... Mayu-san is cute too, but...'
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu118"]
[OnName num="mayu"]
'Pfft. I'm just kidding, I like to embarrass boys."
[cpg cn=true]


But Mayu looked a little sad.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（夕方）******************************************************



Pretending to pass the time, I walk down the hallway to clear my head.
[cpg]


My stay in the hospital was extended. It's not that the doctor doesn't care about me.
[cpg]


But the day of separation is surely coming. I feel so sad.
[cpg]


What should I do? The doctor is doing what he can.
[cpg]


But this is the best I can do. There is no way for me to see the doctor after I get out of the hospital.
[cpg]


Maybe there is, but I don't think he'll see me.
[cpg]


I don't think he'll take time out of his personal life to see me. ......
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



And then the hospital room at night.
[cpg]



[SE f="se006"]
;//【ＳＥ】『ドア開く』



I woke up to the presence of someone.
[cpg]


[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko125"]
[OnName num="rinko"]
'Good evening. How are you feeling?"
[cpg cn=true]


She was in plain clothes. She was not wearing her usual white coat.
[cpg]


[OnName num="sho"]
She was wearing her usual white lab coat.
[cpg cn=true]


[FG f="CHA01_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Rinko126"]
[OnName num="rinko"]
I've finished my shift. I'm here.
[cpg cn=true]


Maybe ...... Sensei is more into me than I thought.
[cpg]


Then the teacher came to sit on the bed where I was sleeping.
[cpg]



;//========================================
;//●ＣＧエロ（座っているヒロイン。足を伸ばしている）ev_17
;//人物１：ヒロイン１
;//服装１：私服
;//人物２：主人公
;//服装２：病衣
;//場所　：病院＿主人公の個室
;//時間　：夜
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="sRinko021"]
[OnName num="rinko"]
He said, "I can't believe ...... I'm doing this to you."
[cpg cn=true]


I guess he's saying that he's even using his vacation time to come see me.
[cpg]

I can't go see him on my end. That's why I appreciated it more.
[cpg]

I want you to be by my side more. I spent time thinking about that.
[cpg]

Just spending time like this made me so happy.
[cpg]

I wonder how the teacher feels about it.
[cpg]

If she didn't feel anything for me, she wouldn't spend time like this.
[cpg]

As I stared at her thinking like that, she said, "You have something to say.
[cpg]

Certainly there are many things I want to say. But I can't say it.
[cpg]

I can't say anything, even though I call myself a coward.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Of course, I have enough feelings to think that it's okay.
[cpg]

Happiness. I felt as if I was willing to give up everything for him.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



But that's not enough. Even if I gave up everything for him, it still wasn't enough.
[cpg]


I wonder if her husband is a doctor. If so, I don't stand a chance.
[cpg]


I mean, she already has a daughter, right? At that point, is there no chance for me to take advantage of her?
[cpg]


I feel kind of pathetic. I feel as if I made a mistake when I wished to be liked by the doctor.
[cpg]


I was starting to feel that way. ......
[cpg]


My body is almost working as before. I finished rehabilitation.
[cpg]


But I am still in the hospital. The doctor is explaining to my parents. ......
[cpg]


The doctor is lying for me. I feel more sorry.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



I miss this life that is ending. What if it was a love affair that I shouldn't have had in the first place?
[cpg]


It would be such a sad thing, wouldn't it? But I don't want to think so.
[cpg]


I wanted to think that it was good that I fell in love with my teacher.
[cpg]


That's why I stayed smiling in front of them. ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu119"]
[OnName num="mayu"]
I heard. The doctor is prolonging my stay in the hospital, right?"
[cpg cn=true]


[OnName num="sho"]
...... I know."
[cpg cn=true]


It's pathetic, but it's the truth.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayu120"]
[OnName num="mayu"]
She smiled and said, "Your smile is unnatural, Sho. If you don't smile more naturally, you won't impress the doctor.
[cpg cn=true]


[OnName num="sho"]
Is that so?"
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu121"]
[OnName num="mayu"]
Yes, it is. It's totally obvious that you're forcing yourself to smile.
[cpg cn=true]


I see. That's right.
[cpg]


I've been in the hospital a little longer. Maybe I should be feeling more cheerful.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（昼）******************************************************



Feeling a little better, I went for a walk down the hallway.
[cpg]


Then, I find the doctor. The doctor also found me and walked toward me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sRinko022"]
[OnName num="rinko"]
He walks toward me and says, "Hello. How are your injuries?
[cpg cn=true]


This is the kind of conversation we don't need to have. But she talks to me.
[cpg]

[OnName num="sho"]
She says, "...... yes. It's getting better."
[cpg cn=true]


I feel a little sad to answer her this way.
[cpg]



;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



Then we go back to my hospital room. Before the doctor, Misora had arrived.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMisora009"]
[OnName num="misora"]
She said, "...... you seriously fell in love with the doctor?"
[cpg cn=true]


[OnName num="sho"]
What ......?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sMisora010"]
[OnName num="misora"]
I thought maybe you were being pushed around by that guy.
[cpg cn=true]


[OnName num="sho"]
I'm fine. I'm not.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Misora104"]
[OnName num="misora"]
"...... be careful not to be converted by that man."
[cpg cn=true]


[free time=1000]


After saying that, Ms. Misora left.
[cpg]



[SE f="se006"]
;//【ＳＥ】『ドア閉まる』



After that, the teacher came.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko164"]
[OnName num="rinko"]
I saw Misora-san just now. ......What did you two talk about?"
[cpg cn=true]


[OnName num="sho"]
"Nothing ......."
[cpg cn=true]



;//ブラックアウト

;//========================================
;//●ＣＧエロ（前のめりでキスをするヒロイン）ev_19
;//人物１：ヒロイン１
;//服装１：白衣
;//人物２：主人公
;//服装２：病衣
;//場所　：病院＿主人公の個室
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_19_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sRinko023"]
[OnName num="rinko"]
'I want you to ...... look only at me.
[cpg cn=true]


He is a married man, but he says such things.
[cpg]

I let him tell me. He brings his face close to mine, and I close my eyes.
[cpg]


;**【ＣＧ】 ev_19_a ***********************
[CG id=11 index=1 time=1]
;***************************************
[WAIT time=1]


Then our lips touch......
[cpg]

It's not my first kiss. But I was so nervous.
[cpg]

I think she could see that, too.
[cpg]

I was so nervous that I thought I was going to be the first one to kiss her. ......The truth is, there's nothing to be nervous about. I'm not going to let a few mistakes ruin our relationship.
[cpg]

So there is nothing to be afraid of.
[cpg]

I felt her lips parting, frustratingly ......
[cpg]

But the distance was enough to make me feel good about it.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sRinko024"]
[OnName num="rinko"]
'...... Sho, you're a lovely person.'
[cpg cn=true]


[OnName num="sho"]
......"
[cpg cn=true]


She smiled at me when I kept quiet.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Rinko185"]
[OnName num="rinko"]
I'll be back. I'll do whatever you want.
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



I wonder what she will do to me this time. The act seems to be escalating.
[cpg]


I wondered how far they would go and what would happen to me.
[cpg]


I was genuinely interested. I wondered how far he would go in his fascination with me.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



[OnName num="female_student"]
I wondered if you were bored, Sho.
[cpg cn=true]


[OnName num="sho"]
I'm not bored. I'm not bored.
[cpg cn=true]


[OnName num="female_student"]
"I'm not bored. The hospital is not boring, is it?"
[cpg cn=true]


I no longer think anything of my classmates when they come to visit me on holidays.
[cpg]


What makes my heart beat? I realized that the only person who can move my feelings is the doctor.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（昼）******************************************************



My body is already moving perfectly. I am back on track.
[cpg]


I wonder how the doctor rewrote the chart.
[cpg]


I wonder if I need to recuperate just in case, or something like that.
[cpg]


Should I act like I'm temporarily ill, or like my body can't move?
[cpg]


But it's too late for that, right? With that thought in mind, I ......
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



I decided to go back to the hospital room and study. It's not that I have no intention.
[cpg]


I have to get out of this hospital. But I want to come back.
[cpg]


It's not about being sick or injured again.
[cpg]


I wanted to be a doctor.
[cpg]


I know it takes a lot of study. I know it takes a lot of study, but I have a talent for studying.
[cpg]


It's not too late to start. The school I go to is a pretty good school.
[cpg]


There is no way I can avoid taking advantage of this situation.
[cpg]



[SE f="se006"]
;//【ＳＥ】『ドア開く』



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

[WAIT time=1100]

[VOICE f="Rinko186"]
[OnName num="rinko"]
Studying? It's good that you study so hard.
[cpg cn=true]


[OnName num="sho"]
"It's for ...... teacher's sake. All of it.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko187"]
[OnName num="rinko"]
What do you mean?　You are missing the point.
[cpg cn=true]


I thought he knew what I was talking about, but I didn't dare to tell him about the determination I kept in my heart.
[cpg]


;//移植のためシーンをカットしています


[OnName num="sho"]
I know that you know what I'm talking about, but I didn't dare to tell you my secret decision.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko207"]
[OnName num="rinko"]
Yes, I know. It is strange, isn't it, that I have a husband and a daughter?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Rinko208"]
[OnName num="rinko"]
I can't do it. When I see a pretty girl like you.
[cpg cn=true]


I guess so. There is some truth to what she is saying.
[cpg]


I know that something is off the limit for her.
[cpg]


[OnName num="sho"]
"...... I don't want to leave this hospital after all."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko209"]
[OnName num="rinko"]
I'm sure you do. But there are limits to what I can do.
[cpg cn=true]


Soon we will say goodbye. It's a future that can no longer be changed.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko210"]
[OnName num="rinko"]
I don't miss you either.
[cpg cn=true]


[OnName num="sho"]
I see.
[cpg cn=true]


I replied, not knowing what to say.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



I continue to study further. There is a limit to what one can do alone.
[cpg]


But it is definitely better than doing nothing.
[cpg]


I couldn't wait to say goodbye to my teacher without doing anything.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿ロビー』（朝）******************************************************



Early in the morning. I take a walk in the hospital.
[cpg]


Sometimes I wish I could walk around the outside of the hospital. ......
[cpg]


I feel like if I do that, I'll finally have to leave this hospital.
[cpg]


I would be separated from the doctor. I don't want to do that.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（朝）******************************************************



On my way back to my room, I run into Mayu-san.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu122"]
[OnName num="mayu"]
How are things going?　Are things going well with the doctor?
[cpg cn=true]


[OnName num="sho"]
She said, "It's nothing to get along with. I'm going to be discharged someday.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayu123"]
[OnName num="mayu"]
Then we'll have to think about what happens next.
[cpg cn=true]


Mayu-san smiles gently. The tone of voice is the same polite as the doctor's, but it is strange.
[cpg]


It is not cold like her teacher's. And that is what attracted me to her. And I am not attracted to her because of that.
[cpg]


What I am attracted to is his coldness.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



And today, he came to see me again.
[cpg]


She must be busy with her work, but she comes every day.
[cpg]

This kind of time is coming to an end. ......
[cpg]



;//ブラックアウト
;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



What the teacher is doing is not a pseudo-romance or something half-hearted like that.
[cpg]


I'm me, and I'm not doing it for fun.
[cpg]


It's what we're doing to have the relationship we both want. ......
[cpg]


It's too sad that this is the end.
[cpg]


But when she gets out of the hospital, the distance between me and her will be drastically reduced.
[cpg]


I wonder how much private time she will have.
[cpg]


I don't think she will use it for me.
[cpg]


It's not that the relationship is still weak or anything. ......
[cpg]


I am sure she uses her private time for her family.
[cpg]


I didn't even want to intrude on that.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



Another night comes. During the night, I worked on my studies.
[cpg]


I wanted to get as close to my teacher as possible. I just studied, thinking it was a step toward that goal.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



In the morning, I wondered when the teacher would come.
[cpg]


I couldn't be out in the hallway. I couldn't be out in the hallway, and I didn't want to cross paths with the teacher.
[cpg]


While I'm waiting like that, she comes ......
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko229"]
[OnName num="rinko"]
"You look so ...... anticipatory. Were you that excited?"
[cpg cn=true]


[OnName num="sho"]
Yes," she said. I can't live without my teacher. ......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko230"]
[OnName num="rinko"]
I'm exaggerating. But ...... I have some bad news.
[cpg cn=true]


The teacher looks a little sad saying that.
[cpg]


Oh, finally. I thought.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko231"]
[OnName num="rinko"]
I can't prolong it any longer. We can't postpone it any longer.
[cpg cn=true]


[OnName num="sho"]
I see.
[cpg cn=true]



[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sRinko025"]
[OnName num="rinko"]
I wish I had met Sho ...... in a different way."
[cpg cn=true]


[OnName num="sho"]
"Me too,...... but maybe this is fate.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko255"]
[OnName num="rinko"]
It's ten years too early to talk about fate."
[cpg cn=true]


The teacher was cold until the end. But this is all right.
[cpg]


Everything, this is good. ......
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sRinko026"]
[OnName num="rinko"]
"......Then goodbye, my dear. I don't think you and I will ever speak again.
[cpg cn=true]


I said to the doctor as he was leaving.
[cpg]


[OnName num="sho"]
......I'm going to become a doctor. Someday, I would like to work at the same place ...... as you.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko273"]
[OnName num="rinko"]
I hope I can do it," he said. But I don't think that's possible.
[cpg cn=true]


The doctor was cold to the core. The last conversation we had was like that.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


A little time passes. I was discharged from the hospital and returned to the school.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



I was studying day and night. To become a doctor.
[cpg]


It may not be something that can be achieved by hard work.
[cpg]


It's not like I was educated to be a gifted child.
[cpg]


It might be too late for me. However, I was ready to go to any lengths.
[cpg]


I couldn't find a doctor in any of my relatives, but I was ready to go to any school. ......
[cpg]


Still, I didn't give up. I followed him.
[cpg]


The more time passed, the more I felt he was getting further and further away from me. Impatiently, I continued my studies.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



Three years passed before my efforts bore fruit. From there, the road to becoming a doctor was even more difficult.
[cpg]


Naturally, it is not possible to become a doctor after completing the entrance exam.
[cpg]


It was rather difficult from there, and I felt like giving up many times.
[cpg]


The distance between me and the doctor was getting further and further apart. Gradually, even my dream of working in the same office as my teacher faded away.
[cpg]


But of course, I could not give up. My love has been the same since the beginning.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



And then I became the doctor I had always wanted to be. ......The first patient I met as a doctor was a girl who had the look of a doctor. ......
[cpg]



;//========================================
;//●ＣＧ非エロ（ベッドに眠るヒロイン１の娘。見下ろす主人公）ev_24
;//人物１：ヒロイン１の娘
;//服装１：病衣
;//人物２：主人公
;//服装２：白衣
;//場所　：病院＿個室
;//時間　：昼
;//備考　：本編から九年が経過しています
;//========================================



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_24_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]



I met a girl who had the look of a doctor. I didn't think it was possible, but she said her last name was Yamamura.
[cpg]


It was her daughter. I knew intuitively that it was her daughter.
[cpg]


She had been in an accident. When I heard the story, I was certain that it was the teacher's daughter.
[cpg]


Even so, I couldn't help but think that there is such a thing as karma.
[cpg]


I followed the teacher's shadow and came this far,...... and I no longer have any desire to be with her.
[cpg]


[OnName num="sho"]
"It's ...... good to think of it as fate,......."
[cpg cn=true]


But I was happy just to be of use to the teacher.
[cpg]



;//ＥＮＤ：ヒロイン１ルート

[SCENE id=9]
[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


