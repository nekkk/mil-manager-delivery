
;//==============================
;//候補が居ない場合

;#################################################
*Ep007|I want a normal love life.
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************


*select04_5|I want a normal love life.

[SCENE id=7]

[free time=1000]

I thought of ...... like that, but I couldn't picture anyone's face.
[cpg]


The teacher, Mayu and Misora are all somewhat S-ish.
[cpg]

I thought to myself, "I'm not sure if I'm M or not.
[cpg]

More to the point, I wanted a more normal kind of love.
[cpg]

Then that's something I can do after I leave this hospital. ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



I think about this as the evening goes on.
[cpg]


There is nothing in particular to think about. My body starts to move little by little, and I somehow feel a sense of unfulfillment.
[cpg]


Is it for this hospital that I am feeling regret? While thinking about such things, I still feel ......
[cpg]


But I don't at all want to go back to the days when I couldn't move .......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

And the next day. The doctor was pressing me.
[cpg]


And by "looming," I mean exactly what it sounds like.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Rinko280"]
[OnName num="rinko"]
"You are recovering well. I think you will be discharged soon.
[cpg cn=true]


[OnName num="sho"]
I see.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sRinko028"]
[OnName num="rinko"]
You look lonely, don't you?
[cpg cn=true]


I am indeed lonely. If you ask me if I'm not sad or not, I am.
[cpg]

I was hoping to continue these days a little longer.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

What if I don't get a girlfriend or something after I get out of the hospital?
[cpg]

It might be the only time I'm surrounded by women like this. That was something I was going to miss.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko299"]
[OnName num="rinko"]
'Well then, I'll see you at ....... We may not get to see each other much anymore."
[cpg cn=true]


And then the teacher said something like that.
[cpg]


Yes, we won't be able to see each other too many more times.
[cpg]


Once I get better, that's it, right?
[cpg]


So, I guess I won't have much of a chance to talk to her anymore.
[cpg]


Thinking this, I was immersed in a strange sentimentality.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（夕方）******************************************************



I wondered if I would be able to meet Mayu and Misora if I just walked around the hallways. With this in mind, I took a random walk.
[cpg]


Then I heard a voice from somewhere......
[cpg]


[OnName num="sho"]
"Is this voice ...... Ms. Misora?"
[cpg cn=true]


I walk toward the voice, although I don't understand.
[cpg]


I wouldn't be surprised if she was meeting and talking to someone else personally. I'm sure that's the way she is.
[cpg]


;//移植のためシーンをカットしています

But I guess she's not just my Misora. Is it natural?
[cpg]

In any case, she's someone who will soon be irrelevant to me. ......
[cpg]

It was when I thought that that I realized. I realized why I wouldn't be disappointed if she was pursuing someone else.
[cpg]


I know that Ms. Misora won't be mine.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And I'm going back to my hospital room.
[cpg]


These boring but pleasant days are almost over.
[cpg]


I am so bored that I can't even sleep.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



The next morning. Mayu-san comes to my place.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayu274"]
[OnName num="mayu"]
She said, "......, what's wrong?　You don't look well."
[cpg cn=true]


Mayu-san looked worried. I wondered what there was to worry about.
[cpg]


[OnName num="sho"]
"Is it so ......?　I'm the same as usual.
[cpg cn=true]


I answered. Mayu seemed unconvinced.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu275"]
[OnName num="mayu"]
I said, "That's all right then. Or do you want me to do something for you?"
[cpg cn=true]


I don't know. I ruminate to myself, but I'm not really in the mood.
[cpg]


[OnName num="sho"]
I said, "It's not ...... anything like that. I'm fine on my own now."
[cpg cn=true]


I said something like that, trying it out.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Mayu276"]
[OnName num="mayu"]
"Yeah,......."
[cpg cn=true]


Mayu flinched a little. I wanted to see that kind of reaction.
[cpg]


I had no resistance to saying such a thing.
[cpg]

I was going to be a stranger to her anyway. That's how I felt.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



The happy time was fleeting. The days went by quickly.
[cpg]


It passed surprisingly quickly. And then ......
[cpg]


The day of discharge from the hospital came in the blink of an eye.
[cpg]


I was half sad to see him go, and the other half thought, "This is it.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿ロビー』（昼）******************************************************



Everyone congratulated me, but I was not happy.
[cpg]


I wondered if these days, these happy times in the hospital, had been an illusion.
[cpg]


It's a strange feeling that even makes me feel that way.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



And then I went back to the school. I was back to being an unencumbered student.
[cpg]


I was a little behind in my studies, but I was able to catch up quickly.
[cpg]


I'm not proud of it, but I can study pretty well.
[cpg]


So I didn't need much help from others.
[cpg]


However, I did feel the repercussions of losing my teachers, Mayu and Misora.
[cpg]


Not long after that, I started dating a classmate who was a good friend of mine.
[cpg]


I wondered if this was the right thing to do, but I also thought that those days were like an illusion.
[cpg]


My youth passed as it was.
[cpg]


;//ブラックアウト



;//ＥＮＤ：ノーマルルート
[SCENE id=12]

[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
