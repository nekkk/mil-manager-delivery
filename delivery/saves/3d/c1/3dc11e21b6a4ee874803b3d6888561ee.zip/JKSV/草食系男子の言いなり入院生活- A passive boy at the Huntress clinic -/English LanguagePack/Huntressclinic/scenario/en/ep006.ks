
*start


;//==============================
;//３、美空さん

;#################################################
*Ep006|Free-spirited Misora
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************


*select04_3|Free-spirited Misora

[SCENE id=6]

[free time=1000]

I still like Misora.
[cpg]


She's not just lazy. I was attracted to her, who is uninhibited to no end.
[cpg]


I had no choice but to confess before leaving the hospital. I had already made up my mind.
[cpg]


You may think that my confession is something a child would do,......, but still.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misora109"]
[OnName num="misora"]
So, what shall we do today?　I'll do anything you want.
[cpg cn=true]


[OnName num="sho"]
I'll do anything you want. ......
[cpg cn=true]


I have made up my mind. I should have been.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misora110"]
[OnName num="misora"]
"...... aren't you well?　What's wrong?"
[cpg cn=true]


[OnName num="sho"]
I'm fine. I'm fine. ......
[cpg cn=true]


But at the very last moment, I couldn't muster up the courage.
[cpg]


For example, if I were to confess my feelings to my teacher, it would be difficult. She might be married.
[cpg]


Mayu might at least have a ...... boyfriend.
[cpg]


But Ms. Misora is different. Despite her lighthearted personality, she's also approached other men.
[cpg]


I'm sure she's used to getting confessions, and I can imagine she has several boyfriends.
[cpg]


If that's the case, I might be able to be one of them.
[cpg]


I couldn't say anything, even though I was thinking about it.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト

I was just fascinated by Ms. Misora.
[cpg]


I want to talk more. That feeling is growing, but ......
[cpg]


I still didn't have the courage to confess my feelings to Ms. Misora.
[cpg]


I really wonder how far I can go halfway before I feel satisfied.
[cpg]


[free time=1000]

I was thinking about this, and as Misora left, I said to her, "Well, I'll see you later.
[cpg]


[OnName num="sho"]
"Well, see you again at ......."
[cpg cn=true]


I just said to Ms. Misora as she left.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



I was disgusted because I was too much of a coward. Then the doctor came to check on me.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko276"]
[OnName num="rinko"]
He said, "You look gloomy even though you are on the way to ...... recovery."
[cpg cn=true]


[OnName num="sho"]
That's, well,...... you can feel that way too.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko277"]
[OnName num="rinko"]
Is it about Misora?"
[cpg cn=true]


Why? How do you know?　How do you know?
[cpg]


The doctor seems to be able to see through it. He might have heard something from Ms. Misora.
[cpg]


[OnName num="sho"]
"How do you know? ......
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sRinko027"]
[OnName num="rinko"]
Because I saw you and Ms. Misora talking happily. I changed my mind because I didn't feel comfortable coming in.
[cpg cn=true]


I didn't know that. Certainly, there may be an expression on her face that she doesn't show to the teacher or Mayu-san.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko279"]
[OnName num="rinko"]
She's quite the flirt. If you're going to confess, you might want to think about that too."
[cpg cn=true]


It's ......, right? I know. I know.
[cpg]


[OnName num="sho"]
"I know. ...... I'm ready."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I've said out loud that I'm ready, but I'm still stuck somewhere.
[cpg]


It takes a lot of courage to begin with, but can't you just keep her to yourself when you fall in love?
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]



[OnName num="sho"]
......Misora, I need to talk to you."
[cpg cn=true]


I said in a serious voice. Misora-san...
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misora131"]
[OnName num="misora"]
What, are you going to confess to me? Are you going to confess?"
[cpg cn=true]


She replied. The women here are all very perceptive ......, but I had no choice but to say it.
[cpg]


[OnName num="sho"]
I love you, Misora. I don't like the idea that I won't see you again after I leave here. ......
[cpg cn=true]


I don't want to see you again after I leave here. I hadn't thought about how I would confess.
[cpg]


[OnName num="sho"]
I was wondering if we could at least exchange SNS or cell phone numbers?
[cpg cn=true]


After a few moments of pondering, Misora laughed.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misora132"]
[OnName num="misora"]
What a child! What's a cell phone number? I'll give it to you.
[cpg cn=true]


I did as she asked and put the number into my phone.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Misora133"]
[OnName num="misora"]
When you leave this hospital, if you ever want to see me again, call me, okay? Okay?"
[cpg cn=true]


With that, Misora-san pressed me again.
[cpg]


She seems to be the type of person who acts first, rather than confessing what she's going to do. ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

In the end what we do is the same as always. But I also felt like it was endearing.
[cpg]


I said what I was going to say. That was a big step for me.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_hu"]
;//[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************

Even after that, Misora-san came to my hospital room.
[cpg]

It's just the same as before. But ......
[cpg]

;//========================================
;//●ＣＧエロ（主人公を見下ろすヒロイン）ev_35
;//人物１：ヒロイン３
;//服装１：ナース服
;//人物２：主人公
;//服装２：病衣
;//場所　：病院＿主人公の個室
;//時間　：朝
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_35_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMisora011"]
[OnName num="misora"]
What?　You look like you're getting your hopes up.
[cpg cn=true]


[OnName num="sho"]
No, no. ......
[cpg cn=true]


I feel she is behaving differently now. Specifically, she started to tease me more.
[cpg]

Even now, she is looking down at me from a very close distance.
[cpg]


;**【ＣＧ】 ev_35_a ***********************
[CG id=17 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sMisora012"]
[OnName num="misora"]
I'll tell you what, don't think you can confess to me and get away with nothing.
[cpg cn=true]


I felt somewhat pleased to hear him say that.
[cpg]

It's like I want to congratulate myself that I really could confess.
[cpg]

And that it didn't end up being a total failure. I felt relieved at the same time.
[cpg]

I was ...... happy just for this.
[cpg]

[OnName num="sho"]
"...... Misora-san."
[cpg cn=true]


I called her name and she smiled back.
[cpg]

I felt that Misora's attitude was a little different from her previous ones.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



I still haven't heard her reply to my confession. I had been waiting for a long time.
[cpg]

Misora must have sensed this, because one day she said to me, "Let's start with a friend.
[cpg]



[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMisora013"]
[OnName num="misora"]
I'll start off as a friend. Is that okay?
[cpg cn=true]



[OnName num="sho"]
Yes, yes!
[cpg cn=true]


That was enough for me. I didn't want to lose touch with her.
[cpg]


So, this was enough for me. ...... I didn't care if I couldn't become a girlfriend with her.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（昼）******************************************************



In the meantime, the day of my discharge from the hospital was approaching.
[cpg]


I was kind of wandering around the hospital with nothing to do.
[cpg]


Then ...... I saw something that was a little predictable, but it was just like before.
[cpg]


[OnName num="sho"]
"...... this voice ......."
[cpg cn=true]


Misora's voice comes from somewhere.
[cpg]


I stopped in front of the door of one of the hospital rooms.
[cpg]


The door was closed, but I opened it a little and looked inside.
[cpg]


I shouldn't do this. I knew it, but I did it.
[cpg]



;//========================================
;//●ＣＧエロ（別の患者に迫るヒロイン）ev_36
;//人物１：ヒロイン３
;//服装１：裸
;//人物２：患者
;//服装２：裸
;//場所　：病院＿個室
;//時間　：昼
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_36_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]



I was in someone's hospital room, someone I didn't know. She was getting close to that person, too.
[cpg]

She was not just treating him like a patient, but rather, she was getting close to him.
[cpg]

[VOICE f="sMisora014"]
[OnName num="misora"]
She said, "Hey, now that you've met me, let's make ...... some memories."
[cpg cn=true]


It sounded like she was saying it in a sweeter voice than to me.
[cpg]

I couldn't stay there.
[cpg]

I wish I hadn't seen this scene, but I feel like I would have seen it at some point.
[cpg]

So this was inevitable.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I could have said something to him.
[cpg]

But I didn't have the courage to do so.
[cpg]

Even if I had, I wouldn't have known what to say.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（昼）******************************************************


And then I left the hospital room of someone I didn't know.
[cpg]


I really don't know him. But I am not a stranger to Misora.
[cpg]


I guess this is how Misora-san talks to various people.
[cpg]

It's not just me. To her, I'm just like that.
[cpg]


It's okay if you go to ....... I don't expect her to be my only girlfriend.
[cpg]


I don't have that kind of hope.
[cpg]


I shouldn't have that kind of hope. ...... It only makes me bitter.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


More time passed. I had seen Ms. Misora several times during that time.
[cpg]


I could say it was a happy time, but it was also a lonely time that was about to end.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿ロビー』（昼）******************************************************



Then came the day of his discharge from the hospital. Everyone was celebrating.
[cpg]


I didn't even have a face ...... to be cheerful.
[cpg]


It was not that I would not be able to see Misora soon.
[cpg]


So I was fine. I had no choice but to think that I was fine.
[cpg]


[OnName num="sho"]
......"
[cpg cn=true]


I made eye contact with Misora-san for the last time and left the hospital.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I was so happy to be discharged from the hospital.
[cpg]


Even though I was told that I was back to my normal body, I couldn't really feel it.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



Still, everyday life comes. I was a little behind in my studies, but I could catch up.
[cpg]


Just the boring normal days would return.
[cpg]


Just going to the school and coming back, a day would pass.
[cpg]


Every day goes by so fast ...... that it's really, really scary.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



Time goes by so fast. I think the days in the hospital might have been the same.
[cpg]


But at least I was able to touch Misora.
[cpg]


I guess we don't even have that now. No. ......
[cpg]


I can still get in touch with her if I want to.
[cpg]


I've decided to step up to the plate. I'll try to get in touch with her.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************



[SE f="se003"]
;//【ＳＥ】『携帯電話の発信音』



I immediately called the number that Misora gave me.
[cpg]


It must be Misora's cell phone number. She must not be at work right now.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se


[OnName num="sho"]
"Oh, hello, is this ...... Ms. Misora?"
[cpg cn=true]


I thought so and said Ms. Misora's name.
[cpg]


[OnName num="man"]
"...... who is this?　Where did you hear that name?"
[cpg cn=true]


Then I heard another voice, totally different.
[cpg]


I was surprised because I had believed that Ms. Misora would answer.
[cpg]


[OnName num="sho"]
'Oh ...... no, um, .......'
[cpg cn=true]


Quite a powerful tone of voice. I thought to myself, "Oh no!
[cpg]


I thought I might have been deceived by Ms. Misora. Could this voice possibly be Misora's true love?
[cpg]


[OnName num="man"]
Say something. Who gave you this number?"
[cpg cn=true]


I was pretty freaked out. I thought about quitting here.
[cpg]


But I couldn't just go to ....... I couldn't hang up the phone.
[cpg]


If I hung up, I would have no more contact with Misora.
[cpg]


[OnName num="sho"]
I heard from ...... Ms. Misora herself. Is she around?"
[cpg cn=true]


I said this to her. Then I said.
[cpg]


[OnName num="man"]
"Misora?　Why ...... no, you can switch, but ......"
[cpg cn=true]


After a moment of silence, I heard Misora's voice.
[cpg]



[VOICE f="Misora207"]
[OnName num="misora"]
'You've got guts, Sho. I was about to hang up on you.
[cpg cn=true]


It was Misora. I was relieved to hear her familiar voice.
[cpg]


[OnName num="sho"]
I was relieved to hear her familiar voice.
[cpg cn=true]



[VOICE f="Misora208"]
[OnName num="misora"]
My dad. He sounds scary, doesn't he?　I thought I'd test Sho a little."
[cpg cn=true]


What, what ...... is that?
[cpg]


I can't believe she would pull such a stupid prank. It's very typical of her, though.
[cpg]



[VOICE f="sMisora015"]
[OnName num="misora"]
I'm sure you've heard that I'm going to be your friend, right? Where should we meet up?"
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



......The next day off after that conversation, I decided to meet up with Misora.
[cpg]


I was going to meet up with Misora. I was to meet her who was not a nurse.
[cpg]


I wonder what kind of personal clothes she will be wearing. I'm looking forward to it. ...... I left the house thinking.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I walked for a while. I went to the place where I was going to meet her.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misora210"]
[OnName num="misora"]
I said, "Sorry to keep you waiting. I mean, aren't you waiting for me?"
[cpg cn=true]


Misora was there earlier than I had imagined. Fifteen minutes before the meeting time.
[cpg]


Of course I came earlier than that. ......
[cpg]


I wonder if she was hoping to see me too.
[cpg]


[OnName num="sho"]
"Yeah, I'm not waiting for you. ......
[cpg cn=true]


[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Misora211"]
[OnName num="misora"]
Let's go, then."
[cpg cn=true]


[OnName num="sho"]
"Oh, ......, hey!"
[cpg cn=true]



;//ブラックアウト

;//========================================
;//●ＣＧ非エロ（主人公の手を引いて、連れて行こうとするヒロイン。屈託のない笑顔）ev_38
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：街
;//時間　：夕方
;//========================================


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_38_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]



[OnName num="sho"]
Don't pull my arm, ......!
[cpg cn=true]


I'm not in a hurry, but I'm in a hurry. I was not in a hurry, but I was in a hurry.
[cpg]



[VOICE f="sMisora016"]
[OnName num="misora"]
I'm not in a hurry," he said. You made me wait, didn't you?
[cpg cn=true]


I'm glad and embarrassed to hear that, but I'm not. I was both happy and embarrassed. ......
[cpg]


[OnName num="sho"]
I understand, please let go of me."
[cpg cn=true]


But I've really become friends with her.
[cpg]

At least we are not strangers now. I wish we could be lovers.
[cpg]


It may be impossible, but I have a little hope.
[cpg]



[VOICE f="Misora213"]
[OnName num="misora"]
I said to her, "You're wasting your time. It's already late in the evening.
[cpg cn=true]


That's true. Maybe so.
[cpg]


[OnName num="sho"]
Maybe so, but there's no need to drag it out.
[cpg cn=true]



[VOICE f="Misora214"]
[OnName num="misora"]
"Oh, God. If you complain, I'll leave you.
[cpg cn=true]


I don't want to be left behind. I went along with Misora.
[cpg]


It was a time when I felt happy.
[cpg]




;//ブラックアウト
;//移植のためシーンをカットしています
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I already know Misora's personality. I like her all in all.
[cpg]

Now that I've realized that about myself, I don't have to worry about anything anymore.
[cpg]

I'm happy to be pulled along by her.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



Days go by even more. I think the distance between me and Misora is still the same.
[cpg]


But then we started to meet almost every holiday.
[cpg]


[OnName num="sho"]
I'm sorry for making you go to ...... every time.
[cpg cn=true]


Misora says, "It's okay. And then.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sMisora017"]
[OnName num="misora"]
I'm sorry for making you go out with me every time we go on holiday.
[cpg cn=true]


[OnName num="sho"]
I don't know if that's true,.......　I'm not aware of it.
[cpg cn=true]


I'm not aware of it at all. I'm not aware of it at all.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misora236"]
[OnName num="misora"]
I'm sure that's what I'm talking about. I'm the one who says it, so there's no doubt about it."
[cpg cn=true]


......I wonder what kind of person Misora likes.
[cpg]

I wonder if I can be her boyfriend someday instead of her friend.
[cpg]


If he becomes her boyfriend, he doesn't seem to have the personality to marry her. ......
[cpg]


But I hope someday I can be truly connected with Misora.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



I think our relationship will continue for a while yet.
[cpg]


It's a little warped, but this kind of relationship is possible, isn't it......?
[cpg]



;//ＥＮＤ：ヒロイン３ルート

[SCENE id=11]

[jump storage="epend.ks" target="*start"]


;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


