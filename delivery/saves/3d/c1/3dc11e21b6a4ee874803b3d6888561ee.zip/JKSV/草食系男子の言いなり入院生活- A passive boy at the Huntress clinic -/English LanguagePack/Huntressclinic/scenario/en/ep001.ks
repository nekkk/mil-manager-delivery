
*start

;#################################################
*Ep001|The day I had been waiting for.
;#################################################

[SCENE id=1]


;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//0415修正
Then began the tedious days of being stuck.
[cpg]

Not being able to move is... really boring. I wish the cast would come off soon.
[cpg]

And then... those painful days ended rather easily.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



;//0415修正
The day I had been waiting for came.
[cpg]

Just as the doctor had said, both of my casts were removed rather quickly.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko059"]
[OnName num="rinko"]
I was told, "...... not to force yourself to move them."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko060"]
[OnName num="rinko"]
I'm sure you'll be in so much pain that you won't even want to move them, so let's take our time with the rehabilitation."
[cpg cn=true]


I couldn't move my body right away just because the casts were removed.
[cpg]

[free time=1000]

It seems like it's just ...... removed. Well, maybe it's better that it's not there because it's in the way.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Mayu067"]
[OnName num="mayu"]
So you're saying you're going to be needing our help for a while.
[cpg cn=true]



Of course I was disappointed, but I was also a little happy.
[cpg]


I'll still have them to take care of me for a while.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Mayu068"]
[OnName num="mayu"]
I'm sure we'll be together for a while. Sho-kun.
[cpg cn=true]


That's a comment that I would consider as a nurse. I responded, "I'm happy to stay with Mayu.
[cpg]



;//■選択肢
[switch]
[case "I'm happy to be with you, Mayu."]
	[swap]
	[jump target="*select02_1"]
[case "I can't wait to get out of the hospital."]
	[swap]
	[jump target="*select02_2"]
[endswitch]

1, I'm happy to be with Mayu.
2. I can't wait to get out of the hospital.



;//==============================
;//１、麻友さんと一緒に居られて嬉しい

*select02_1|The day I had been waiting for.

[stflag Cha2flg = 1]
[system sysCha2flg=true]


[OnName num="sho"]
I'm glad to be with Mayu-san. I'm glad to be with you, Mayu-san."
[cpg cn=true]


;//[free time=1000]

[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="1/2" time=800]
[VOICE f="Mayu069"]
[OnName num="mayu"]
"I see. I see."
[cpg cn=true]


Mayu-san looked happy too. I felt like everything was fine now.
[cpg]



;//この選択肢を選んだ場合ヒロイン２が候補に

[jump target="*select02_3"]

;//==============================
;//２、早く退院したい

*select02_2|The day I had been waiting for.

[system sysCha2flg=false]

[OnName num="sho"]
No, I can't wait to get out of the hospital.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Mayu070"]
[OnName num="mayu"]
I'm sure that's what you really want, too. But I won't let you go."
[cpg cn=true]


Mayu-san smiled, but I caught a glimpse of desire behind her eyes.
[cpg]



;//==============================

*select02_3|The day I had been waiting for.

;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（夕方）******************************************************



Aside from that, just because the cast is removed doesn't mean I can walk out right away.
[cpg]


I still don't know how this hospital is structured.
[cpg]


I had a feeling that I wanted to at least take one step out of my room.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿リハビリ室』（朝）******************************************************



And then rehabilitation begins.
[cpg]


[OnName num="sho"]
I'm like, "Ouch, ouch, ouch!　Hold on, hold on."
[cpg cn=true]


I went on with the rehabilitation, but this was just more pain.
[cpg]


;//0415修正
And the person in charge of rehabilitation was neither Mayu nor Misora.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



...... and as each day passes, I think about many things.
[cpg]


The doctor is beautiful. Mayu-san is cute, and Misora-san is ...... a little too much of a jerk to me.
[cpg]


But they are all attractive. While I was surrounded by such people, I began to feel indescribable.
[cpg]


In other words, I felt like it would be a shame to leave .......
[cpg]


I was missing them.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sRinko001"]
[OnName num="rinko"]
I was feeling ...... awfully fast pulse.
[cpg cn=true]


It was while I was having my pulse checked.
[cpg]

I turned my head away and said nothing.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="sRinko002"]
[OnName num="rinko"]
I said, "This kind of thing happens sometimes, doesn't it? Is it my fault?"
[cpg cn=true]


[OnName num="sho"]
'No, no, ...... sir did nothing wrong .......'
[cpg cn=true]


I was about to say, "I'm sorry," when she suddenly approached me.
[cpg]

;//========================================
;//●ＣＧエロ（寝ている主人公に近づくヒロイン）ev_04
;//人物１：ヒロイン１
;//服装１：白衣
;//人物２：主人公
;//服装２：病衣
;//場所　：病院＿主人公の個室
;//時間　：昼
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_04_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]

[VOICE f="sRinko003"]
[OnName num="rinko"]
Or is it boredom in the hospital that makes you like this?
[cpg cn=true]


The doctor comes closer to me.
[cpg]

I smelled something sweet and I looked away.
[cpg]

[OnName num="sho"]
It's close to .......
[cpg cn=true]


[VOICE f="sRinko004"]
[OnName num="rinko"]
"Is it?　You wanted me to get closer.
[cpg cn=true]


I couldn't say anything and kept looking away.
[cpg]

But when the teacher is by my side,...... I feel strange again.
[cpg]


;**【ＣＧ】 ev_04_a ***********************
[CG id=3 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="sRinko005"]
[OnName num="rinko"]
Blush. So you mean you're a boy, too, Sho."
[cpg cn=true]


They say it's obvious. Too obvious to deny.
[cpg]

I can't push her away.
[cpg]

And then she gets even closer to me. ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I wondered if she was, but then she started to move away from me.
[cpg]

Somewhat relieved, I was out of it.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sRinko006"]
[OnName num="rinko"]
I was somewhat relieved, but I was out of sorts.
[cpg cn=true]


[OnName num="sho"]
That's true, but ......
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="sRinko007"]
[OnName num="rinko"]
And since you seem to have an infatuated personality, ......
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="sRinko008"]
[OnName num="rinko"]
I'll have to tell the nurses about this.
[cpg cn=true]

Nurse?　Does that mean to Mayu and Misora as well?
[cpg]


[OnName num="sho"]
Wait a minute!
[cpg cn=true]


That's doubly bad. I don't want Mayu-san to know about that kind of thing.
[cpg]


And I don't know what Misora-san would do if she knew that. ......
[cpg]


I once refused, but the teacher says this.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sRinko009"]
[OnName num="rinko"]
I think you want Mayu-san and the others to know about it."
[cpg cn=true]


[OnName num="sho"]
I said, "......"
[cpg cn=true]


I said, "Yes, indeed. I want to get close to her too.
[cpg]

[free time=1000]

But is it okay to take her up on this invitation ......?
[cpg]



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/2" time=800]


[VOICE f="Mayu010"]
[OnName num="mayu"]
Oh, sir. Are you in the middle of ......?
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[VOICE f="Rinko031"]
[OnName num="rinko"]
No, I'm not. You should also keep an eye out for him, Mayu.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Mayu011"]
[OnName num="mayu"]
"I understand. ......."
[cpg cn=true]


I think Mayu-san laughed when she said that. Seriously,......?
[cpg]


You never know what's going to happen from here. What's really going to happen to me?
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



That day, Mayu did not immediately come on to me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu012"]
[OnName num="mayu"]
She said, "Please ahhh, Sho."
[cpg cn=true]


[OnName num="sho"]
Aaan."
[cpg cn=true]


As before, Mayu-san brought the food to my mouth in place of my dominant hand, which I could not use properly.
[cpg]


When I finished eating, I said to Mayu, "Oh, um.
[cpg]


[OnName num="sho"]
Oh, um, about what ......-sensei said.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMayu001"]
[OnName num="mayu"]
Oh," she said, "I'm sorry. Then don't worry about it.
[cpg cn=true]


You don't mind ...... that, it's kind of a help and a shame.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu014"]
[OnName num="mayu"]
I love pampering men. Leave it to me."
[cpg cn=true]


Really?　I was about to say, "Yes," but there was some kind of spirit in me that didn't allow me to say so.
[cpg]


[OnName num="sho"]
I said, "...... yes."
[cpg cn=true]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



From that day on, I was in agony.
[cpg]

Would I be able to get close to Mayu as well?　From Misora-san, too, maybe ......
[cpg]

No, more than that. I'm even wondering about my relationship with my teacher.
[cpg]

What happened the other day is too much in my memory.
[cpg]


But there's nothing like privacy to do something like this. ......
[cpg]


I thought of my teacher's behavior this way.
[cpg]



;//■選択肢
[switch]
[case "It's annoying."]
	[swap]
	[jump target="*select01_1"]
[case "I wish I hadn't."]
	[swap]
	[jump target="*select01_2"]
[endswitch]

One, it's annoying.
Two, I wish I hadn't.



;//==============================
;//１、迷惑だ
*select01_1|The day I had been waiting for.

[system sysCha1flg=false]

I knew there's a part of me that's happy, but there's also a part that's annoyed.
[cpg]


He also said I'm a sucker for him, and that's just an assumption.
[cpg]

[jump target="*select01_3"]

;//==============================
;//２、願ってもない話だ
*select01_2|The day I had been waiting for.

[stflag Cha1flg = 1]
[system sysCha1flg=true]

Really, I'm not wishing for it. The three of us are of a high caliber, to say the least.
[cpg]


I think the teacher has a particularly pretty face.
[cpg]


;//この選択肢を選んだ場合ヒロイン１が候補に



;//==============================

*select01_3|The day I had been waiting for.





[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



My mom came over this morning.
[cpg]


I wonder if she took the day off work. I'm so grateful, but what can I say ......
[cpg]


I can't be honestly happy that she came, considering what happened the other day.
[cpg]


[OnName num="sho_mother"]
She said, "What's wrong?　Your face is red.
[cpg cn=true]


[OnName num="sho"]
'...... it's nothing.'
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



Then, at noon, Mayu came to see me.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu015"]
[OnName num="mayu"]
Oh, it's Sho-kun's mother. Hello."
[cpg cn=true]


I had to run into my mother. I can't ask Mom to leave.
[cpg]


But if only Mom wasn't here, Mayu might be able to do it for me.
[cpg]


[OnName num="sho"]
Oh, you know, Mom, ...... you don't have to worry about me anymore."
[cpg cn=true]


[OnName num="sho_mother"]
I don't think so. How can I not worry about you?
[cpg cn=true]


[OnName num="sho"]
"Forget it!　Just go home."
[cpg cn=true]


I was getting angry. Mom was overwhelmed.
[cpg]


[OnName num="sho_mother"]
"Yeah, yeah,...... okay, but just remember,...... that I'm worried about you," she said.
[cpg cn=true]


[OnName num="sho"]
Umm, yeah...... sorry, I was out of line too."
[cpg cn=true]


Before I could say a word, Mom left the hospital room.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Mayu016"]
[OnName num="mayu"]
"It's not like that, ....... Besides, it's Mayu's fault."
[cpg cn=true]


[OnName num="sho"]
I'm not like that,....... It's because of you, Mayu.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu017"]
[OnName num="mayu"]
What are you talking about?"
[cpg cn=true]


Mayu-san blurted out. I'm sure the doctor has been talking to her.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
And in the empty hospital room, she pressed on.
[cpg]


[OnName num="sho"]
'......I knew it was going to be like this.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu018"]
[OnName num="mayu"]
Heh. Well, yes. That's what the doctor told me to do. ...... And."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sMayu002"]
[OnName num="mayu"]
I genuinely enjoy pampering a pretty girl like Sho-kun."
[cpg cn=true]



;//ブラックアウト
;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Mayu is kind to a fault.
[cpg]


I wish she would stay by my side all the time.
[cpg]


But it doesn't work that way. It's shifts.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************

;//[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu038"]
[OnName num="mayu"]
I'm going back then.
[cpg cn=true]


[OnName num="sho"]
Oh, um, ......
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mayu039"]
[OnName num="mayu"]
What is it?　You want me to stay with you more?
[cpg cn=true]


He sees right through me. No good, I'm ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



Then, around dinner time, Misora came over.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sMisora001"]
[OnName num="misora"]
She said, "I heard. I heard that you see me as a woman.
[cpg cn=true]


It's a very perverted story. Maybe there was a message game until it was passed on to Ms. Misora.
[cpg]


[OnName num="sho"]
"Goh, it's a misunderstanding. ...... I didn't say anything like that."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sMisora002"]
[OnName num="misora"]
Well, whatever."
[cpg cn=true]


Saying that, Ms. Misora was coming on to me.
[cpg]


[OnName num="sho"]
He said, "Hey, you're being too abrupt.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misora011"]
[OnName num="misora"]
Oh, yeah. Then I don't care.
[cpg cn=true]


Oh, I didn't think you'd back down here. I didn't think she would back down here.
[cpg]


[OnName num="sho"]
"Anyway, just let me eat ...... dinner. ......"
[cpg cn=true]


After I rejected him, I said something I didn't want to say, and he fed me.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misora012"]
[OnName num="misora"]
Huh. What a pain in the ass....... Eat it yourself."
[cpg cn=true]


Misora said something similar to before.
[cpg]


[OnName num="sho"]
'My hand was broken,......?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Misora013"]
[OnName num="misora"]
She said she could manage with her guts."
[cpg cn=true]


I finish my ...... meal thinking it's not that kind of problem.
[cpg]



;//ブラックアウト


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『病院＿廊下』（夜）******************************************************



It's a room with no ...... alternatives. I can't even go out into the hallway.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿ロビー』（夜）******************************************************



If I could walk more, I'd do a lot of things. ......
[cpg]


If I don't, I'll go crazy to the point where I'm not even injured.
[cpg]



[jump storage="ep002.ks" target="*start"]
