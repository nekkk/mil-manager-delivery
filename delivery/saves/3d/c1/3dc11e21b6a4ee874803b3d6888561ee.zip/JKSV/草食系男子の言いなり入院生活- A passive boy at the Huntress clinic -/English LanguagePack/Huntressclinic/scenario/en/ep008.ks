

*start

;//４、皆のことが好きだ
;//ハーレムルート

;#################################################
*Ep008|You can't choose who you are.
;#################################################



*select04_4|You can't choose who you are.


[SCENE id=8]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



I love you all. If I was asked to choose someone...I can't.
[cpg]


I should just say, "I can't choose anyone. I felt it was the best thing to do.
[cpg]


I love the teachers. I love both Mayu and Misora.
[cpg]


I wish this situation would last forever.
[cpg]


But once my injury is healed, there will be no reason for me to stay in the hospital.
[cpg]


One day, the sad day of discharge from the hospital will come.
[cpg]


What will I ...... do then?
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko319"]
[OnName num="rinko"]
What?"
[cpg cn=true]


[OnName num="sho"]
'So, you know...I don't really have a choice.'
[cpg cn=true]


I was talking to the doctor. I didn't want to say anything.
[cpg]


[OnName num="sho"]
I just kind of wanted to stay here forever.
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko320"]
[OnName num="rinko"]
I think that's fine.
[cpg cn=true]


I told the teacher about it, but he didn't say anything in particular.
[cpg]


It's like I said with you that I like the teacher, but it's a cold reaction.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko321"]
[OnName num="rinko"]
'But I don't agree with the idea of you staying here forever.
[cpg cn=true]


[OnName num="sho"]
'Eh, ......'
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko322"]
[OnName num="rinko"]
'As a doctor, I want my patients to get well as soon as possible.
[cpg cn=true]


Was I the only one who was enjoying this situation and thinking that if I could just stay here forever...?
[cpg]


It's kind of sad.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Rinko323"]
[OnName num="rinko"]
I was a little sad. You'll be discharged from the hospital soon.
[cpg cn=true]


[OnName num="sho"]
I understand. But, um, ......."
[cpg cn=true]


Seeing me trying to say something, the teacher giggles.
[cpg]


;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I am. The first thing you need to do is to find a good place to live.
[cpg]


I wanted to hear one word, that I wanted to be needed by someone or that I didn't want ...... to be discharged from the hospital.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



But it's hard to get such a word out of him. It would be strange if I could.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Mayu295"]
[OnName num="mayu"]
I was still lost. Right, Misora?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Misora254"]
[OnName num="misora"]
That's right. It's true that I'd like to leave something behind, but I'd be more than happy if you got well.
[cpg cn=true]


[OnName num="sho"]
I see.
[cpg cn=true]


The two of them reacted in the same way as the teacher.
[cpg]


I'm not going to stay in the hospital all the time. I couldn't stay in the hospital forever.
[cpg]


No matter what happens, they are doctors and nurses.
[cpg]


There was no way they would have thought it was okay for a sick person to stay in the hospital.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Misora255"]
[OnName num="misora"]
What are you looking so gloomy?
[cpg cn=true]


[OnName num="sho"]
"Well, do I look like that ......?"
[cpg cn=true]


I think I did. But I played it off.
[cpg]



;//ブラックアウト
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



After all, the girls were the same as before.
[cpg]

I don't want things to be different from before, but I'm still sad.
[cpg]

I was feeling indescribable when I thought that these days would soon come to an end.
[cpg]


I wondered if the day would come when I would be separated from them.
[cpg]


While I was thinking like this, time was passing.
[cpg]


Time cannot be stopped. If it did, of course, I would not be able to be in contact with them.
[cpg]


The day of my release from the hospital was drawing nearer and nearer. I couldn't do anything about it.
[cpg]


My classmates and family were happy, but I was the only one feeling down.
[cpg]


My classmates and family were also wondering why I was so happy.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************

I could feel that the end was near.
[cpg]

The passing of time itself was somewhat painful. ......
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_hu"]
;//[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu316"]
[OnName num="mayu"]
Then Sho-kun, see you tomorrow."
[cpg cn=true]


Mayu-san says something that makes me startle. Because tomorrow, she says.
[cpg]


[OnName num="sho"]
"...See you tomorrow. Yes, sir. ......"
[cpg cn=true]


Tomorrow. That was the day I would finally leave this hospital.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I hate it. I think it's safe to say that I hate it.
[cpg]


I don't want to. I want to continue this life. And yet.
[cpg]


It's not like tomorrow never came. ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Rinko339"]
[OnName num="rinko"]
"Congratulations on your discharge."
[cpg cn=true]


The doctor sent me on my way with a smile. The other two were the same.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Misora277"]
[OnName num="misora"]
"Congratulations!
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu317"]
[OnName num="mayu"]
Congratulations! That's great!
[cpg cn=true]


The three of them were congratulating me. They don't mean anything else.
[cpg]


They don't think that they won't see me again or anything like that.
[cpg]


[OnName num="sho"]
They are not thinking that they will never see me again. Thank you for your help.
[cpg cn=true]


Mayu nodded at my words. And then.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu318"]
[OnName num="mayu"]
"Take care, Sho-kun.
[cpg cn=true]


She replied, "I'm fine. If you were well, you wouldn't be here anymore.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[VOICE f="Rinko340"]
[OnName num="rinko"]
Be careful not to get hurt that badly again."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="Misora278"]
[OnName num="misora"]
He said, "Yes, yes. It's not easy to take care of them.
[cpg cn=true]


You'll never come to ...... again? That's right. This must never happen again.
[cpg]


[OnName num="sho"]
"......
[cpg cn=true]


The three of them were really happy to see me out of the hospital.
[cpg]


But I still wanted to stay here a little longer.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************



And then I left the hospital, and my old life came back.
[cpg]


It was wonderful to be back in my old life without any inconvenience.
[cpg]


There were places I had wanted to go but couldn't. ......
[cpg]


It was also great to be back in school life. I think it's something irreplaceable for me.
[cpg]


When I first came back, I was filled with a sense of freedom and fun.
[cpg]


But...as each day passes, I remember more and more.
[cpg]


I couldn't forget the days in the hospital.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



No matter what I do, I can't stop thinking about them.
[cpg]


I'm out of my mind. I can't believe I'm thinking like this.
[cpg]


If I get the same injury again, I wonder if I will be taken to the same hospital again.
[cpg]


What am I really out of my mind?
[cpg]


I'm ...... really out of my mind.
[cpg]


[OnName num="sho"]
What a stupid thing to do..."
[cpg cn=true]


It's rude to them if I think like that.
[cpg]


I can say that they are the ones who healed my injury.
[cpg]


They worked so hard to take care of me, and they took care of me in rehabilitation and ......... well, they did a lot of things to me.
[cpg]

[FADEOUTBGM]

So don't think that way. ............
[cpg]



[SE f="se005"]
;//【ＳＥ】『クラクション』



[OnName num="sho"]
What?"
[cpg cn=true]



[SE f="se012"]
;//【ＳＥ】『事故』




;//ブラックアウト
[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

Oh, I see.
[cpg]


I'm an idiot.
[cpg]


It must be dangerous to walk around with such thoughts in your mind.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_me"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Rinko341"]
[OnName num="rinko"]
I'm glad you're awake. You're awake.
[cpg cn=true]


And ...... I woke up in the hospital room again.
[cpg]


[OnName num="sho"]
"Hey, doctor,......, what's this place?
[cpg cn=true]


[free time=1000]
I'm back. I could tell that, but I also had the feeling that I was back.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

[VOICE f="Mayu319"]
[OnName num="mayu"]
Sho! Thank God you're alive! You're alive!
[cpg cn=true]


Mayu seemed to be happy that I was alive.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/2" time=800]
[VOICE f="Misora279"]
[OnName num="misora"]
No, of course not. You're alive!
[cpg cn=true]


I fully woke up. The familiar landscape was spread out before me.
[cpg]


Apparently, while I was thinking, I had crossed the street at a red light.
[cpg]


Things are different from before. I was really distracted.
[cpg]

[free time=1000]

As a result, I was hit by a car... and they carried me back to this hospital.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="3/3" time=800]

By the way, the three of them were really pissed at me.
[cpg]


They said, "Of course, what were you thinking?
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="1/3" time=800]
[VOICE f="Rinko342"]
[OnName num="rinko"]
I'm a person who can't help it.
[cpg cn=true]


[OnName num="sho"]
'I'm really sorry ...... um, I was just thinking ......
[cpg cn=true]


He wouldn't be convinced if I told him how I got hurt.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Mayu320"]
[OnName num="mayu"]
You have to be careful, Sho! You have to be sorry!"
[cpg cn=true]


[OnName num="sho"]
Yes...I'm sorry. I'm sorry."
[cpg cn=true]


I apologized to them. In time, the tone of their words began to change.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[VOICE f="Rinko343"]
[OnName num="rinko"]
I said, "Well, but...what you came back to, you can't help."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="3/3" time=800]
[VOICE f="Misora281"]
[OnName num="misora"]
Do you like living here so much? Hahaha.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu321"]
[OnName num="mayu"]
She didn't seem to want to leave the hospital.
[cpg cn=true]


[OnName num="sho"]
I didn't do it on purpose, I really didn't.
[cpg cn=true]


I didn't do it on purpose. If I had done it badly, I would have died.
[cpg]


There is absolutely nothing wrong with that.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="1/3" time=800]
[VOICE f="Rinko344"]
[OnName num="rinko"]
I understand. Well, I'll be looking forward to seeing you again in a while.
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Mayu322"]
[OnName num="mayu"]
Yes, that's right. I'm looking forward to working with you again.
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="Misora282"]
[OnName num="misora"]
You should be happy that you'll be taken care of by such a beautiful woman again.
[cpg cn=true]


[OnName num="sho"]
"...... Yes, please take care of me!"
[cpg cn=true]


The doctor was angry with me, saying, "Don't say it so cheerfully.
[cpg]


I was so excited that I couldn't help but relax.
[cpg]


The old days were back again.
[cpg]


However, I had caused my parents a great deal of worry once again.
[cpg]


The money would be nothing to sneeze at. Not only that, but it would be a lot of work.
[cpg]


So there would be no next time. But to be honest, I'm glad to be back here.
[cpg]




;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Well, I can't say I'm just happy, because my immobility has gone up a level.
[cpg]

But I was happy. I hope this time I can get out of the hospital with no regrets: ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



Today, as usual, the three of them come to my room.
[cpg]


What will they do to me today? With such expectations.
[cpg]


I let them do their thing.
[cpg]


I was always waiting for them to come to my room. ......
[cpg]




;//ブラックアウト
;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



In a way, I guess you could say that this hospital gave me a new disease.
[cpg]


After two accidents, I realized that there was no way out of this place. I knew I would never get out of this place.
[cpg]


I really have to become a nurse or something.
[cpg]


I want to stay here, no matter what it takes.
[cpg]


I'd like to stay as a patient if I could, but that's not possible.
[cpg]


So I thought I'd at least be there for them.
[cpg]


;//ブラックアウト

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="3/3" time=800]
[VOICE f="Rinko357"]
[OnName num="rinko"]
Good morning. Sho. It's time for your checkup.
[cpg cn=true]


[OnName num="sho"]
I was a little frightened.
[cpg cn=true]


I replied, a little apprehensive, but hopeful.
[cpg]



[FACE method="change_1" pos="1/3"]
[VOICE f="Mayu334"]
[OnName num="mayu"]
I'll start with a temperature check.
[cpg cn=true]



[FACE method="change_2" pos="2/3"]
[VOICE f="sRinko029"]
[OnName num="rinko"]
I'll be by your side again for a while,.......
[cpg cn=true]



When it comes to the teacher, he has assured me that he will be entertained.
[cpg]


[FACE method="change_2" pos="1/3"]
[VOICE f="Mayu335"]
[OnName num="mayu"]
I'm looking forward to working with you.
[cpg cn=true]



[FACE method="change_2" pos="3/3"]
[VOICE f="Misora294"]
[OnName num="misora"]
"Nice to meet you..."
[cpg cn=true]


[OnName num="sho"]
Yes. ......
[cpg cn=true]



I am happy to be here.
[cpg]


If I could, I wouldn't even want to leave this place anymore.
[cpg]


But since that's not possible...I'm going to enjoy the time until I get out of the hospital.
[cpg]



;//ＥＮＤ：ハーレムルート

[SCENE id=13]

[jump storage="epend.ks" target="*start"]



