

*start


;#################################################
*Ep002|How long until I can walk the streets?
;#################################################

[SCENE id=2]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



I wonder how long it will take before I can walk the streets: ......
[cpg]


I was thinking about that, and then the next morning.
[cpg]





;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sMisora003"]
[OnName num="misora"]
"You're bored, aren't you? Don't you want my attention?"
[cpg cn=true]


[OnName num="sho"]
Well, that's ......
[cpg cn=true]


I could no longer deny it. After I had rejected her once, I was even more curious about her.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Misora015"]
[OnName num="misora"]
I'll wake you up, bed."
[cpg cn=true]


Saying that, Misora helped me up on the bed.
[cpg]


I was in a sitting position.
[cpg]


I'm in a sitting position, but I don't feel like I'm sitting on my own.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Misora016"]
[OnName num="misora"]
"If you don't do this, I can't kiss you,...... then I'll do it."
[cpg cn=true]


[OnName num="sho"]
"......What?"
[cpg cn=true]


;//========================================
;//●ＣＧエロ（ベットで上体を起こしている主人公。ヒロインとキス寸前までいく）ev_06
;//人物１：ヒロイン３
;//服装１：ナース服
;//人物２：主人公
;//服装２：病衣
;//場所　：病院＿主人公の個室
;//時間　：朝
;//========================================

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_06_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]


Did you say kiss?　What do you mean?
[cpg]

No. What state is this in anyway?　I'm supposed to be just getting you to relieve my boredom. ......
[cpg]

[VOICE f="sMisora004"]
[OnName num="misora"]
"You're blushing. Is this your first time?"
[cpg cn=true]


Misora-san is acting as if there is nothing wrong with her.
[cpg]

I was so surprised that I was at a loss for words for a while.
[cpg]

But if I remained silent at this point, I really didn't know what they would do to me.
[cpg]

[OnName num="sho"]
I was surprised, but I didn't know what he would do to me if I didn't speak up.
[cpg cn=true]


[VOICE f="sMisora005"]
[OnName num="misora"]
I did it because you said you were free.
[cpg cn=true]


Is that what this is about?　Am I being weird?
[cpg]

[OnName num="sho"]
No, no, no, 
[cpg cn=true]


I still manage to shake her off.
[cpg]

But I'm injured right now, so there's not much I can do.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************


[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="1/2" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]

And while I was ...... in the middle of all this, Mayu-san came in.
[cpg]


[OnName num="sho"]
"Oh, Mayu-san,......, this is different, this is."
[cpg cn=true]


I deny something that I don't have to deny anything.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="1/2" time=800]

[VOICE f="Mayu040"]
[OnName num="mayu"]
"Misora-san,......, it's not fair."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/2" time=800]
[VOICE f="Misora036"]
[OnName num="misora"]
I'm not cheating," she said.　I'm not going to be able to do anything about it.
[cpg cn=true]


I don't know if there is such a thing as time in charge.
[cpg]


I don't know what's going on with the nurses, but ......
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Mayu041"]
[OnName num="mayu"]
I'll just feed you dinner. Is that okay?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Misora037"]
[OnName num="misora"]
I'd like to do it when you say so.
[cpg cn=true]


So I watched them skirmish for a while.
[cpg]


In the end, Misora-san pulled out of it. ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



Then a classmate came to visit.
[cpg]


[OnName num="male_student"]
"I see you're all right, Iwaguchi. ......
[cpg cn=true]


[OnName num="sho"]
"Well, I mean, I guess I'm ...... safe."
[cpg cn=true]


He was the classmate who was closest to me when I was in the car accident.
[cpg]


[OnName num="male_student"]
You should come in, too. Don't be shy."
[cpg cn=true]


[OnName num="female_student"]
"Well, uh, ...... it's been a while. Heh heh heh.
[cpg cn=true]


There was also a girl there who was a good friend of mine at the school.
[cpg]


[OnName num="female_student"]
"You broke your ...... hand and leg, didn't you? You can't do anything, can you ......?"
[cpg cn=true]


[OnName num="male_student"]
'That's right. You must be bored.
[cpg cn=true]


[OnName num="sho"]
Yes, I am."
[cpg cn=true]


But I'm not saying that I have no problems with boredom, but rather that I'm ......
[cpg]

I have no more trouble with boredom than I did before. I can't say that, of course, but the days went by.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Rinko032"]
[OnName num="rinko"]
I heard you have a good friend. I heard he came to visit you the other day.
[cpg cn=true]


[OnName num="sho"]
Well, yes. ......It's not so much a friend, but more of a frenemy.
[cpg cn=true]


Sometimes the doctor comes to diagnose the progress of the patient.
[cpg]


I think that the Teacher's assessment is correct to some extent, or that the treatment is appropriate.
[cpg]


I thought it would be more painful with a broken bone, but it's not.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sRinko010"]
[OnName num="rinko"]
I'll leave it to the nurses to keep you occupied for the rest of the day.
[cpg cn=true]


[OnName num="sho"]
"Well, uh, ......, the doctor is ......."
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Rinko034"]
[OnName num="rinko"]
'Whenever you feel like it. I like pretty boys too."
[cpg cn=true]


I think I was blushing. I didn't expect him to be so frank.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



[SE f="se002"]
;//【ＳＥ】『ノック』



Then, in the hospital room at night. I was startled by a knock at my door.
[cpg]


[OnName num="sho"]
"Yes, yes. ......"
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu042"]
[OnName num="mayu"]
I was surprised to hear a knock at my door, "I'm here. Sho kun."
[cpg cn=true]


Mayu was in plain clothes. It was different from usual.
[cpg]


[OnName num="sho"]
That dress ......
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu043"]
[OnName num="mayu"]
I'm not on the night shift, so I snuck in here.
[cpg cn=true]


[OnName num="sho"]
I'm not on the night shift, so I snuck in here.　What can I say, you have a problem ......
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu044"]
[OnName num="mayu"]
It might be bad if they find out I'm doing this."
[cpg cn=true]


Even as he says this, he is smiling. It's an expression of spare time.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sMayu003"]
[OnName num="mayu"]
I can't stand it any longer, so it can't be helped, can it?
[cpg cn=true]


I don't know what to say. I don't know how to reply.
[cpg]


And as it was, he snuggled up next to me. ......
[cpg]



;//========================================
;//●ＣＧエロ（主人公に寄り添うヒロイン）ev_07
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：病衣
;//場所　：病院＿主人公の個室
;//時間　：夜
;//========================================

*Scene004|How long until I can walk the streets?

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMayu004"]
[OnName num="mayu"]
I feel safe when I'm by his side like this."
[cpg cn=true]


I'm not sure how to respond to that. But.
[cpg]

[OnName num="sho"]
"...... something, I'm sorry for making you say that."
[cpg cn=true]


I'm not forcing myself to be concerned about you.
[cpg]

I am by no means forcing myself to care.
[cpg]

I'm not forcing myself to be concerned about it.
[cpg]

[VOICE f="sMayu005"]
[OnName num="mayu"]
Why?　I won't say what I don't want to say.
[cpg cn=true]


But Mayu replied.
[cpg]


;**【ＣＧ】 ev_07_a ***********************
[CG id=5 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sMayu006"]
[OnName num="mayu"]
I'm not forcing myself on you. It's part of being a nurse.
[cpg cn=true]


No, I've never heard of such a job, and besides, I'm in plain clothes now.
[cpg]

I had never heard of such a job, and now I was wearing plain clothes.
[cpg]

I didn't say anything more, because it was such a healing time that I couldn't say no. I was so happy to have such a beautiful woman by my side.
[cpg]

I was so happy to have such a beautiful woman by my side.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夜）******************************************************



[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]

Mayu stayed in my hospital room for a while after that.
[cpg]


It was after lights out, so it was dark. I couldn't see her well. ......
[cpg]


[OnName num="sho"]
......Does Mayu-san have a girlfriend or something?
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu064"]
[OnName num="mayu"]
I was so happy to see her. Is that a question a patient would ask a nurse?"
[cpg cn=true]


It's true. But if she is as beautiful as Mayu, she must have been asked.
[cpg]


[FG f="CHA02_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Mayu065"]
[OnName num="mayu"]
She's not here. That's why you came to Sho-kun, isn't it?
[cpg cn=true]


Surely you're right. If that's the case, you can just go to your girlfriend's place.
[cpg]


The reason why they don't is because they don't have a girlfriend.
[cpg]


[OnName num="sho"]
...... I feel like if you're as beautiful as Mayu, you're going to be a draw.
[cpg cn=true]


[FG f="CHA02_p1_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Mayu066"]
[OnName num="mayu"]
Thank you. But I can't have that kind of relationship with Sho-kun, can I?
[cpg cn=true]


I've been nailed. I guess I said too much.
[cpg]



;//ブラックアウト



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



The night is passing. Mayu went home.
[cpg]


I've been up for too long too...... I've got to go to bed.
[cpg]


What should I do tomorrow......?　Just waiting for my injuries to heal is a leisurely time.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



And then it's morning.
[cpg]


Just because it's morning doesn't mean the school starts.
[cpg]


I thought that when people lose their duties, they become somewhat ...... spoiled.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（朝）******************************************************



Whether it's a profession or an academic job, there's something you have to devote yourself to on a daily basis so you can get by.
[cpg]


More to the point, it's hard to just let time pass if you don't have a sense of balance in your day-to-day life.
[cpg]


Right now, I'm just waiting for the nurses and the doctor to arrive.
[cpg]


[OnName num="sho"]
"Oh, um, ......, is the doctor not going to do anything anymore?"
[cpg cn=true]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sRinko011"]
[OnName num="rinko"]
What do you mean, nothing?　Do you want me to do something?"
[cpg cn=true]


He asks me the obvious question. It's mean-spirited.
[cpg]


[OnName num="sho"]
I'm not going to do that ...... thing that Mayu-san and the others do ......."
[cpg cn=true]


The teacher sighs. And then.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sRinko012"]
[OnName num="rinko"]
"...... I'm the type of person who wants to bully pretty girls."
[cpg cn=true]


He made a confession that I don't quite understand. Somehow I know without being told.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sRinko013"]
[OnName num="rinko"]
If you know I'm like that, I'll think about it.
[cpg cn=true]


[OnName num="sho"]
I don't care what kind of person ...... Sensei is.
[cpg cn=true]


I guess I was being careless. But I had no choice but to say this. Then ......
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sRinko014"]
[OnName num="rinko"]
I understand.
[cpg cn=true]


She answered immediately. But nothing special happened that day.
[cpg]

;//移植のためシーンをカットしています
;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Then the teacher left.
[cpg]

She looked more like she was trying to get me to understand something, rather than burning with desire.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



And about right after that, my parents came over, and it was already hard to change my attitude.
[cpg]


[OnName num="sho_father"]
They said, "Sorry we couldn't come over, we can only move about ...... holidays."
[cpg cn=true]


[OnName num="sho_mother"]
I wish one of us could stay with you. ...... Sorry, Sho."
[cpg cn=true]


I have to act like I'm okay, but I'm not really okay.
[cpg]


What the teacher did to me in particular has left quite a tail. Still, ......
[cpg]


[OnName num="sho"]
I said, "I'm fine, the ...... doctor says I'll get better, I'll be fine."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（夕方）******************************************************



Then my parents stayed for a while. Talking to someone I hadn't seen in a while was somewhat calming.
[cpg]


But the stimulation at this hospital was considerable.
[cpg]


Even if I calm down at this moment, I know I will soon be plunged back into the extraordinary.
[cpg]


I can't help but wonder what's going to happen to me.
[cpg]


[OnName num="sho_father"]
"What's wrong ...... with you, you're all over the place."
[cpg cn=true]


[OnName num="sho"]
I'm just worried about things like, well, ...... my studies and stuff."
[cpg cn=true]


It's a big lie. I have been studying at random and will continue to do so at random.
[cpg]


I'm confident I can keep up even if I have to take a month or so off.
[cpg]


I'm that much of an honor student. ...... but ......
[cpg]


I wonder if I should study a little. I don't know.
[cpg]


[OnName num="sho_mother"]
Is there anything I should bring?　I've brought most of my textbooks and stuff, right?
[cpg cn=true]


[OnName num="sho"]
I don't want anything in particular. I don't want anything in particular.
[cpg cn=true]


I'd rather have too much of what I want.
[cpg]


There are even things that I've always wanted but for some reason I'm just now getting them. ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hu"]
[WAIT time=100]
;//【ＢＧ】『病院＿ロビー』（夜）******************************************************



And again at night. My parents went back to the stone.
[cpg]


I'm feeling some loneliness, but good.
[cpg]


I'm being healed of it, ...... is more than I can say.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ad"]
[WAIT time=100]
;//【ＢＧ】『病院＿ロビー』（朝）******************************************************



As I was waiting, Misora-san came in.
[cpg]



;//ブラックアウト



[window target=false]
[BG f="b_05_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Misora038"]
[OnName num="misora"]
She said, "Here you go. Hurry up and eat.
[cpg cn=true]


Misora-san puts the next bowl of rice on the spoon faster than I can chew it.
[cpg]


[OnName num="sho"]
I can't eat so quickly.
[cpg cn=true]


Misora-san is basically indifferent when it comes to nursing me.
[cpg]


Then, after I finished my meal.
[cpg]

;//========================================
;//●ＣＧエロ（前のめりで主人公に寄り添うヒロイン）ev_09
;//人物１：ヒロイン３
;//服装１：ナース服
;//人物２：主人公
;//服装２：病衣
;//場所　：病院＿主人公の個室
;//時間　：昼
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sMisora006"]
[OnName num="misora"]
'......you, I've been thinking about you for a while.'
[cpg cn=true]


She comes up to my body and says this.
[cpg]

[VOICE f="sMisora007"]
[OnName num="misora"]
You don't have much hair on your body, do you?
[cpg cn=true]


It's true that I don't have much hair on my shins. I'm the one who's concerned about it.
[cpg]

[OnName num="sho"]
What are you saying?
[cpg cn=true]


;**【ＣＧ】 ev_09_a ***********************
[CG id=6 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sMisora008"]
[OnName num="misora"]
"I'm complimenting you.　I like you more when you're like that.
[cpg cn=true]


I was feeling indescribably embarrassed, but I didn't turn my face away.
[cpg]

I felt like I was going to lose if I looked away.
[cpg]

And then she moved away a little, without doing anything to me.
[cpg]

I might have looked disappointed, she was smiling a little.
[cpg]


;//移植のためシーンをカットしています


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

She often teases me like this.
[cpg]

I think it is described as "S-ish" or something like that.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『病院＿主人公の個室』（昼）******************************************************



I was still feeling embarrassed as I watched Misora leave.
[cpg]

I was still feeling embarrassed as I watched Misora leave. ...... I began to realize that all of the girls had some sort of S-ness about them.
[cpg]

They are all different types. Sensei is cold to the core.
[cpg]

Mayu-san seems to be kind, but she treats me like a child.
[cpg]

And Misora-san seems to be a predatory type.
[cpg]

However, the teacher seems to be married, considering her age.
[cpg]

Mayu-san doesn't have a boyfriend, as I recall. I wonder about Misora-san: ......
[cpg]


[jump storage="ep003.ks" target="*start"]

