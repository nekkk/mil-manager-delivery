

*start


;###################################################################
*Ep012|The Changing Body and the Unchanging One
;###################################################################


[SCENE id=12]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]

[stflag Jumpflg = 0]


[if exp={getFlagValue("Jumpflg") == 0 }]
[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 0]
[stflag Cha4flg = 0]
[stflag Cha5flg = 0]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]
[endif]



[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************

[SE f=se008]
;//【ＳＥ】『喧噪』



[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha192"]
[OnName num="asha"]
Another dark look. What's wrong?"
[cpg cn=true]


[OnName num="renzi"]
I'd better turn into ...... someone who doesn't know how to express himself."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha193"]
[OnName num="asha"]
If you do that, I'll know you're even more depressed.
[cpg cn=true]


[OnName num="renzi"]
I see. ......
[cpg cn=true]


Asha can see right through it. She doesn't just know me, she knows everyone.
[cpg]


I couldn't say anything there, even though I knew I was no match for her.
[cpg]


[OnName num="renzi"]
It's all right. I'm not depressed.
[cpg cn=true]


I hope so," Asha replies.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





The days continue as if at a standstill. Then came an unexpected visitor.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="4/5" time=800]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/5" time=800]

[VOICE f="Satuki086"]
[OnName num="satsuki"]
Nice to meet you. My name is Satsuki Shikano.
[cpg cn=true]


[OnName num="rudolf"]
“You don't have to bow so deeply. Are all ogres like that?”
[cpg cn=true]


[FACE method="change_2" pos="2/5"]
[VOICE f="Dorothy170"]
[OnName num="dorothy"]
I hear that?　The human race also has a different culture.
[cpg cn=true]

[FACE method="change_1" pos="2/5"]
[FACE method="change_3" pos="4/5"]
[VOICE f="Satuki087"]
[OnName num="satsuki"]
I'm here today to deliver a message from a human.
[cpg cn=true]


[OnName num="renzi"]
"From a human...?"
[cpg cn=true]


For some reason, I was also invited to this important table. Even though I'm not in a position to unite people like Janice and the others.
[cpg]


;//[FACE method="change_3" pos="4/5"]
[VOICE f="Satuki088"]
[OnName num="satsuki"]
“They want us to return the female champion we captured.”
[cpg cn=true]


[OnName num="rudolf"]
'I figured you would, but I can't do it without a quid pro quo.
[cpg cn=true]


From there it was all about difficult bargaining. I couldn't follow much of it.
[cpg]


For example, exchanging things for people is difficult.
[cpg]


Once Clara returns to the humans, it is obvious that they will come back to retaliate.
[cpg]


And it's hard to find things that can balance the loss of Kulara. ......
[cpg]


[FACE method="change_4" pos="4/5"]
[VOICE f="Satuki089"]
[OnName num="satsuki"]
“Don't you get it? The entire ogre tribe that stuck in between the human world and yours is getting worried.”
[cpg cn=true]


[OnName num="rudolf"]
I know, but that doesn't mean I have to.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/5" time=800]
[VOICE f="Janice157"]
[OnName num="janice"]
I am totally sure of it. Just asking me to do it for the good of the demon tribe is not a deal breaker."
[cpg cn=true]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





The fact that Satsuki, and not the chief of the ogre tribe, came here alone said it all.
[cpg]


Satsuki personally wants a world where all races can live without division.
[cpg]


Or maybe everyone wants it, but Satsuki didn't have enough cards.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy171"]
[OnName num="dorothy"]
She seemed to know about Renji.
[cpg cn=true]


[OnName num="renzi"]
Really?"　You didn't say that."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy172"]
[OnName num="dorothy"]
He was glancing at Renji. It was like he was waiting for a rescue ship.
[cpg cn=true]


Oh ...... I see. That's what Satsuki was hoping for.
[cpg]


I felt bad. But I couldn't suddenly propose to everyone that we should free Clara.
[cpg]


From the demon tribe's point of view, they are the ones who have been hurting their friends. I can't do anything about it on my own.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





Everyone was kind of at a standstill. It seemed that I was not the only one.
[cpg]


I think Satsuki was trying to put a stop to this. But it wasn't working.
[cpg]


Dorothy and Janice are probably impatient to get anything out of Clara, and Clara will continue to endure.
[cpg]


Even Asha probably wants ...... this kind of fight to be over.
[cpg]


I'm me and I can't keep repeating these shenanigans.
[cpg]


It's like everyone has their own agenda, but can't do anything about it, in a word, it's like a stalemate.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





I can't sit still in my room, so I leave the room.
[cpg]


What people do in such a stalemate is to repeat what they have done before.
[cpg]


I play tricks on everyone.
[cpg]


Gradually, people will start to realize that this is what I do. And that's not the only problem.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Arsha194"]
[OnName num="asha"]
I'll say, "Hey, what's a dog ...... doing in a place like this?"
[cpg cn=true]



He turned into a dog again, this time heading for Asha's place.
[cpg]


Perhaps she will accept me. But ......
[cpg]


The same is true whether you approach the lovesick Asha, the innocent Dorothy, or the surprisingly timid Janice.
[cpg]


[FO pos="2/3" time=1000]
[BG f="black.ui"  time=1000]
[WAIT time=2000]
;//ブラックアウト





Just being naughty doesn't make you in love.
[cpg]


All I ended up thinking was that I wanted someone to love me.
[cpg]


Thinking about this, I headed to Klara's place.
[cpg]

[BG f="b_04_5.ui" time=1000]
[WAIT time=1000]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Clara096"]
[OnName num="clara"]
'No matter how many times I come here, it's always the same. I will never give in to you people."
[cpg cn=true]


It would be quite difficult to be liked by Clara.
[cpg]


We've already antagonized her and have treated her badly.
[cpg]


I can't say I have a friendly relationship with Satsuki, either.
[cpg]


I should have offered her a helping hand at that time.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



It was precisely at times like this that I felt a sense of urgency.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Arsha195"]
[OnName num="asha"]
Renji: "Hey, Renji. What are you going to do now?
[cpg cn=true]


[OnName num="renzi"]
What do you mean, "...... what do we do?"
[cpg cn=true]


My mind was occupied with one thing.
[cpg]


I want someone to love me. With this shape-shifting ability, that might be possible.
[cpg]


For example, I could become the way she wanted to see me...
[cpg]


[FACE method="change_3" pos="2/5"]
[VOICE f="Janice158"]
[OnName num="janice"]
I want to ask you something, too," he said. You were originally human."
[cpg cn=true]


[FACE method="change_1" pos="4/5"]
[VOICE f="Arsha196"]
[OnName num="asha"]
Do you want to live as a demon?　Or do you still want to live as a human?"
[cpg cn=true]


With this power, I might be able to solve some of their problems.
[cpg]


But the basic premise is the question of where to live.
[cpg]


I am a demon now. But I was originally a human being.
[cpg]


Life in a dungeon is fun, but the city where humans live also has its charms.
[cpg]


;//
;//
;//
;//;//■選択肢
;//[switch]
;//[case "ダンジョンの中で暮らしたい"]
;//	[swap]
;//	[jump target="*IseSel06_1"]
;//[case "ダンジョンを出たい"]
;//	[swap]
;//	[jump target="*IseSel06_2"]
;//[endswitch]
;//
;//
;//１、ダンジョンの中で暮らしたい
;//２、ダンジョンを出たい
;//
;//
;//
;//==============================
;//１、ダンジョンの中で暮らしたい
*IseSel06_1|Changing bodies and unchanging things


[OnName num="renzi"]
I'm still attached to this place.
[cpg cn=true]


[FACE method="change_1" pos="2/5"]
[VOICE f="Janice159"]
[OnName num="janice"]
I see. That's a relief."
[cpg cn=true]


There are many people to whom I owe a debt of gratitude, and I have to return the favor.
[cpg]


Even if I were to be married to someone, I did not want to leave the dungeon.
[cpg]



;//※変数+1
[stflag Gameflg = 1]

[jump target="*IseSel06_3"]

;//==============================
;//;//２、ダンジョンを出たい
;//*IseSel06_2|変わる身体と変わらないもの
;//
;//
;//
;//[OnName num="renzi"]
;//「まだ、考え中だよ」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_7" pos="2/5"]
;//[VOICE f="Janice160"]
;//[OnName num="janice"]
;//「そうか。まあ、急いで答えを出すこともない」
;//[cpg cn=true]
;//
;//
;//とジャニスは言うが、本心は伝えられなかった。
;//[cpg]
;//
;//
;//俺は、ダンジョンに固執することはないかもしれないと思っていた。
;//[cpg]
;//
;//
;//人間族や鬼族にも興味が湧いている。
;//[cpg]
;//
;//
;//具体的には、クラーラやサツキのことも気になっていた。
;//[cpg]
;//
;//
;//
;//==============================

*IseSel06_3|The Changing Body and the Unchanging One



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



For some time after that, he spent his days playing pranks on the girls.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Dorothy173"]
[OnName num="dorothy"]
That thing the other day was definitely Renji, wasn't it?"
[cpg cn=true]


[OnName num="renzi"]
What are you talking about?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy174"]
[OnName num="dorothy"]
It felt like the ...... futon was moving.
[cpg cn=true]


[OnName num="renzi"]
I must be dreaming.
[cpg cn=true]


What a way to think, while shrugging it off.
[cpg]


If I were to get hitched, I wondered who it would be.
[cpg]


Janice and Asha have thanked me.
[cpg]


As for Dorothy, I even feel like she is doing me a favor.
[cpg]


Speaking in terms of gratefulness, it would probably be best to get Clara out of here.
[cpg]


I might be able to solve Satsuki's problems, too.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Dorothy175"]
[OnName num="dorothy"]
“Hey Renji,,,, why do you always do such acts of mischief?"
[cpg cn=true]


[OnName num="renzi"]
He said he didn't.
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Dorothy176"]
[OnName num="dorothy"]
Let me ask you something. Do you do it because you like me?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy177"]
[OnName num="dorothy"]
Or do you like someone else and it's really just a prank?
[cpg cn=true]


Dorothy gets to the heart of the matter.
[cpg]




I found myself wondering who I wanted to be loved by.
[cpg]




;//＠CHA03ルート
[jump storage="ep015.ks" target="*start"]


;//;//ゲームフラグを確認、人鬼か、魔王軍か
;//
;//[if exp={getFlagValue("Gameflg") == 3 }]
;//;//魔王軍へ
;//[jump target="*chackgame"]
;//[endif]
;//
;//[if exp={getFlagValue("Gameflg") == 2 }]
;//;//魔王軍へ
;//[jump target="*chackgame"]
;//[endif]
;//
;//
;//;//人鬼
;//;=======================================
;//
;//[if exp={getFlagValue("Cha5flg") == 0 }]
;//;//クラーラルートへ
;//[jump storage="ep013.ks" target="*start"]
;//[endif]
;//
;//
;//[switch]
;//[case "クラーラ"]
;//	[swap]
;//	[jump storage="ep013.ks" target="*start"]
;//[case "サツキ"]
;//	[swap]
;//	[jump storage="ep017.ks" target="*start"]
;//[endswitch]
;//
;//;=======================================
;//
;//
;//*chackgame|変わる身体と変わらないもの
;//
;//
;//*devil|変わる身体と変わらないもの
;//
;//;//魔王軍
;//;=======================================
;//
;//
;//;//ヒロイン３のフラグ
;//[if exp={getFlagValue("Cha3flg") == 1 }]
;//[jump target="*Cha3"]
;//[endif]
;//
;//
;//;//ヒロイン４のフラグ
;//[if exp={getFlagValue("Cha4flg") == 1 }]
;//[jump target="*Cha4"]
;//[endif]
;//
;//
;//
;//;//ドロシールートへ
;//[jump storage="ep014.ks" target="*start"]
;//
;//
;//;-------------------------------------------
;//;//ヒロイン３のフラグだけが立ってたなら
;//*Cha3|変わる身体と変わらないもの
;//
;//;//ヒロイン４のフラグ
;//[if exp={getFlagValue("Cha4flg") == 1 }]
;//[jump target="*ChaAll"]
;//[endif]
;//
;//[switch]
;//[case "ドロシー"]
;//	[swap]
;//	[jump storage="ep014.ks" target="*start"]
;//[case "ジャニス"]
;//	[swap]
;//	[jump storage="ep015.ks" target="*start"]
;//[endswitch]
;//
;//
;//;---------------------------------------------
;//;//ヒロイン４のフラグだけが立ってたなら
;//*Cha4|変わる身体と変わらないもの
;//
;//
;//[switch]
;//[case "ドロシー"]
;//	[swap]
;//	[jump storage="ep014.ks" target="*start"]
;//[case "アーシャ"]
;//	[swap]
;//	[jump storage="ep016.ks" target="*start"]
;//[endswitch]
;//
;//
;//
;//;------------------------------------------------
;//;//３人ののフラグが立ってるなら
;//*ChaAll|変わる身体と変わらないもの
;//
;//[switch]
;//[case "ドロシー"]
;//	[swap]
;//	[jump storage="ep014.ks" target="*start"]
;//[case "ジャニス"]
;//	[swap]
;//	[jump storage="ep015.ks" target="*start"]
;//[case "アーシャ"]
;//	[swap]
;//	[jump storage="ep016.ks" target="*start"]
;//[endswitch]
;//
;//
;//
;//
;//
;//;=======================================
;//
;//
;//
;//
;//;//【転】
;//;//※ここまでの選択肢で、変数が２以上ならばヒロイン１、ヒロイン５は選択肢に出てこない
;//;//変数が１以下ならばヒロイン２、ヒロイン３、ヒロイン４は選択肢に出てこない
;//
;//;//更に、今までの変身システムで正答を選ばなかったヒロインは選択肢に出てこない
;//;//ヒロイン１、ヒロイン２のうちいずれかは必ず選択肢に出てくる
;//;//ヒロイン１、ヒロイン２のうちいずれかしか残っていない場合、選択肢は発生せずそのルートにそのまま進む
;//
;//
;//
;//;//デバッグ用
;//*debug
;//
;//[switch]
;//[case "クラーラ"]
;//	[swap]
;//	[jump storage="ep013.ks" target="*start"]
;//[case "ドロシー"]
;//	[swap]
;//	[jump storage="ep014.ks" target="*start"]
;//[case "ジャニス"]
;//	[swap]
;//	[jump storage="ep015.ks" target="*start"]
;//[case "アーシャ"]
;//	[swap]
;//	[jump storage="ep016.ks" target="*start"]
;//[case "サツキ"]
;//	[swap]
;//	[jump storage="ep017.ks" target="*start"]
;//[endswitch]
;//
;//１、クラーラ
;//２、ドロシー
;//３、ジャニス
;//４、アーシャ
;//５、サツキ
;//
;//
;//
;//;//==============================
