

*start

;###################################################################
*Ep010|Transformation is a Powerful Asset
;###################################################################


[SCENE id=10]

[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]

[stflag Jumpflg = 0]


[if exp={getFlagValue("Jumpflg") == 0 }]
[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 0]
[stflag Cha4flg = 0]
[stflag Cha5flg = 0]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]
[endif]



[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『鬼の集落』（朝）******************************************************





[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Satuki085"]
[OnName num="satsuki"]
Bye. Hope you're safe."
[cpg cn=true]


[OnName num="renzi"]
Thank you." Good bye."
[cpg cn=true]


I decide to leave the village of ogres.
[cpg]


I have regained enough strength. I think I can walk for a while.
[cpg]

[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="06"]
[window target=true]
;//【ＢＧ】『平原』（朝）******************************************************




Once I left the village, I found myself back on the plains as far as the eye could see.
[cpg]


It was a strange world. The scenery was different in each area.
[cpg]


There must be a town that looks different from the dungeon as well as from the Ogre Village.
[cpg]


[BG f="b_09_2.ui" time=1000]
[WAIT time=1000]

[window target=true]
;//【ＢＧ】『平原』（昼）******************************************************



[SE f=se003]
;//【ＳＥ】『平原歩く』




As I approached the town with this thought in mind, more and more people began to pass by on the road.
[cpg]


I wondered if they were going to the dungeon too. As I was thinking that.
[cpg]


[OnName num="man"]
You look like you're on your way back from the dungeon. How was it?"
[cpg cn=true]


[OnName num="renzi"]
No. I just ran back.
[cpg cn=true]


[OnName num="man"]
You're looking nice for that. ...... Well, okay."
[cpg cn=true]


While they are a little suspicious of me, they are not suspicious of the fact that I am human.
[cpg]


My transformation is perfect. I'll be able to walk into town.
[cpg]


And then... Finally...
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="03"]
;//【ＢＧ】『街』（夕方）******************************************************


[SE f=se008]
;//【ＳＥ】『喧噪』


We came to the town where human beings live. The scenery is like a city.
[cpg]


It was so different from the modern city I was in. It is not that I have seen medieval Europe, but it is a little different.
[cpg]


The people on the streets are dressed differently, some dressed like wizards, others like elves.
[cpg]


[OnName num="renzi"]
For the time being, we need a place to stay.
[cpg cn=true]


I have plenty of money. It was taken from a recently arrived adventurer, so it could be used as currency.
[cpg]


I decided to find a place to stay.
[cpg]

[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]

[stopse g=3]
;//通常se

[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]

[window target=true]
;//【ＢＧ】『街』（夜）******************************************************





[OnName num="Shopkeeper"]
I said to myself, "I can't take this much ....... Who are you?
[cpg cn=true]


[OnName num="renzi"]
“What? Uh...ummm.”
[cpg cn=true]


The coins were inscribed with numbers, but I may have misplaced one of the zeros.
[cpg]


Or perhaps there are two different currencies?
[cpg]


[OnName num="Shopkeeper"]
'Well, that's all right. As long as you pay the bill, we'll let you stay.
[cpg cn=true]


[OnName num="renzi"]
Thank you.
[cpg cn=true]


I tried not to talk too much so as not to look suspicious.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="01"]
;//【ＢＧ】『街』（朝）******************************************************





I was nervous about everything I did, but it was not whether I was a demon or not that made them suspicious.
[cpg]


They are suspicious of what kind of person I am. That's okay.
[cpg]


In the morning, I go out to buy the magic tools I had been asked to get. Then...
[cpg]



[VOICE f="Clara003"]
[OnName num="clara"]
'The quality of the products here is always good.'
[cpg cn=true]


I heard a familiar voice in the store and saw a familiar figure.
[cpg]



[FACE method="feadin_up" pos="4/7"]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]

[WAIT time=1500]


[OnName num="salesperson"]
“I'm so glad to hear you say that, Clara. That makes me happy.”
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Clara004"]
[OnName num="clara"]
The arrows are so rare now," he said. I'm glad I can buy them here."
[cpg cn=true]


Clara. Isn't she the champion?
[cpg]


I had been admiring her beauty. When I first met her, I didn't look at her properly because I was in a nervous state.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara005"]
[OnName num="clara"]
Then, I will come back again.
[cpg cn=true]


Makes me want to do something to her... It was that kind of a smile.
[cpg]


Of course, it would be a big deal if I turned into a demon in a town like this.
[cpg]


But now that I am human, I wonder if I can take advantage of that.
[cpg]


To begin with, the role I was asked to play was to scout for humans.
[cpg]


If I could deceive Clara and make her a prisoner, there would be nothing more to say.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="03"]
;//【ＢＧ】『街』（昼）******************************************************


After I made up my mind, I acted quickly.
[cpg]


Although it was an impure motive, I also had a feeling that if I took Clara prisoner, I would be able to do a lot more to her.
[cpg]


First of all, I heard that there was a bar where adventurers hang out, so I started by gathering information there.
[cpg]


[OnName num="adventurer_A"]
“Clara? What do you want from her?”
[cpg cn=true]


[OnName num="renzi"]
No," he said. I just wanted to join her party.
[cpg cn=true]


My strategy was this. I'm going to get into her party somehow, and then betray her at the last minute.
[cpg]


[OnName num="adventurer_B"]
"Ms. Clara is in a completely different league... I doubt she'll hire a new associate so easily."
[cpg cn=true]


[OnName num="adventurer_A"]
“But I heard that one person left Clara's party.”
[cpg cn=true]


[OnName num="renzi"]
Can you tell me more?
[cpg cn=true]


As I listened to the conversation, I learned that a male swordsman who had been cooperating with Kulara had apparently had some kind of falling out.
[cpg]


It was a good thing I was in the right place at the right time. If only I could copy his appearance, I could switch places with him.
[cpg]


Then I could start with a certain degree of trust. The plan was going to work.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_3.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="07"]
;//【ＢＧ】『街』（夕方）******************************************************





[OnName num="swordfighter"]
“You are Clara's messenger? I'm not going to fight with her anymore."
[cpg cn=true]


[OnName num="renzi"]
“That's fine... Uh."
[cpg cn=true]


In order to transform, you have to smell this person.
[cpg]


But if I approach him and sniff him, he will be suspicious of me.
[cpg]


He would be able to identify me as a shapeshifter...
[cpg]


[OnName num="renzi"]
I'd like to buy the sword. I want to buy the sword you used.
[cpg cn=true]


[OnName num="swordfighter"]
Why?　This is a sword with no name.
[cpg cn=true]


Fortunately, we had plenty of money. And the sword would have his scent on it.
[cpg]


I kind of felt like I was a police dog or something, but the deal worked out.
[cpg]



[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト



[BG f="b_07_4.ui" time=1000]
[WAIT time=1500]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



It ended up being a full day's work just to get information on the swordsman, search for him, and transform him.
[cpg]


But the return seems to be worth it.
[cpg]


I also bought a sleeping potion for Clara to sniff in case of emergency.
[cpg]


It was probably something used for demons. It was easy to get...
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="03"]
;//【ＢＧ】『街』（昼）******************************************************





[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Clara006"]
[OnName num="clara"]
I didn't think you would come back.
[cpg cn=true]


[OnName num="renzi"]
......"
[cpg cn=true]


Try not to be as ragged as possible. Better to pretend to be silent.
[cpg]


You should sound like you're in a bad mood because you seem to be in some kind of trouble.
[cpg]


[OnName num="monk"]
Is that okay? If he's back again, there must be a reason."
[cpg cn=true]


A female priestess, who seems to be a companion of Klara's, says to me. She is dressed as if she were a sister.
[cpg]


And I remained as silent as ever.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Clara007"]
[OnName num="clara"]
I don't want to pry too deeply, but I'd like to hear about it sometime.
[cpg cn=true]


Still, up close, she is even more beautiful.
[cpg]


If I can continue to head deeper into the depths and betray her when I'm so worn out that I have no choice but to turn back, I'll ......
[cpg]


I was almost smirking a little, but I looked sullen.
[cpg]


From there, the schedule was set up right away, even before the next dive into the dungeon.
[cpg]


She had something set up in the store and was probably planning to head there right away.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="06"]
;//【ＢＧ】『平原』（昼）******************************************************

[SE f=se020]
;//【ＳＥ】『草原歩く』

There were four of us in the party, including me and Klara.
[cpg]


There were four of us in the group, including me and Clara.
[cpg]


I know there is magic in this world. Or rather, I am also transformed by its power.
[cpg]


The other guy is a warrior type guy like me. However, he seems to handle a spear instead of a sword.
[cpg]


It seems that he was hired to fill in for the missing swordsman.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

And Clara herself is both a magician and a skilled archer.
[cpg]


I can imagine that she is good at long-range fighting, which means that once she is captured, she won’t be able to escape.
[cpg]


[OnName num="warrior"]
“I didn't expect for the four of us to come here... Although I was hired to take your place.”
[cpg cn=true]


[OnName num="renzi"]
So I've heard.
[cpg cn=true]


[OnName num="monk"]
What a windfall to have you back again."
[cpg cn=true]


On the way to the dungeon. I was asked a question, and I had to answer.
[cpg]


[OnName num="renzi"]
What's wrong?　I just came back because I needed money."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Clara008"]
[OnName num="clara"]
I thought you said you were going to take over the ...... family business."
[cpg cn=true]


[OnName num="renzi"]
Well, that's ......
[cpg cn=true]


The stories don't add up.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『平原』（夜）******************************************************





It is a long way to the dungeon. Even if you stop by the ogre village, they won't let humans in.
[cpg]


We were even forced to camp out on the way, but I couldn't answer the questions they asked me.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clara009"]
[OnName num="clara"]
How are the wounds you mentioned since then?
[cpg cn=true]


[OnName num="renzi"]
Oh," he said. It still hurts when it gets cold."
[cpg cn=true]


[OnName num="monk"]
'When it gets cold ......?　What do you mean?
[cpg cn=true]


[OnName num="renzi"]
What?"　That's why the scar."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Clara010"]
[OnName num="clara"]
I thought you said you had a broken heart. Does your heart ache when it gets cold?"
[cpg cn=true]


[OnName num="renzi"]
......
[cpg cn=true]


No, no, no, do you simply call a heartbreak a wound?
[cpg]



They seem to be asking me all kinds of leadng questions because I am being suspicious.
[cpg]


I was skeptical, but managed to fool around.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="07"]
;//【ＢＧ】『平原』（昼）******************************************************


[SE f=se020]
;//【ＳＥ】『草原歩く』


The dungeon approaches. Everyone was very quiet and almost silent as we headed there.
[cpg]


Is this due to nervousness, or were Clara and the others originally like this?
[cpg]


Or are they all wary of me?
[cpg]


If so, I might become a prisoner rather than making Clara a prisoner.
[cpg]


I'm sure they won't get it out of me, but even so, I'm sure they'll get away with it.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************

[SE f=se009]
;//【ＳＥ】『歩く』



Furthermore, I can't actually handle a sword. Even if I could, I wouldn't be able to wield a sword against a fellow demon tribe member.
[cpg]


Everyone asked me what was wrong. I explained that my arm was dull, but I was in pain.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clara011"]
[OnName num="clara"]
......"
[cpg cn=true]


They thought I was slowing them down. Or perhaps they thought I was a demon in my own nature.
[cpg]


[FO pos="2/3" time=1000]

[BG f="black.ui"  time=1000]
[WAIT time=1000]
;//ブラックアウト




But as it turned out, I held on just in time.
[cpg]


I guess it means that they were suspicious of me, but not convinced.
[cpg]



[window target=false]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/5" time=800]
[VOICE f="Janice114"]
[OnName num="janice"]
“There you are. Clara, help me disolve my long-standing grudge."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="4/5" time=800]
[VOICE f="Clara012"]
[OnName num="clara"]
You were a close associate of the Demon King, weren't you? Don't worry, you won't have to hold a grudge anymore.
[cpg cn=true]


Janice is leading the charge, and there are a lot of demons behind her.


The demons and Clara and her group continued to glare at each other at distance.
[cpg]


I decided now was the time to betray them. Now she is defenseless behind me.
[cpg]

[FO pos="2/5" time=500]
[FO pos="4/5" time=500]

[SE f=se012]
;//【ＳＥ】『衣擦れ』

I approach Clara and let her sniff the sleeping potion I had hidden.
[cpg]


[FG f="CHA01_p5_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Clara013"]
[OnName num="clara"]
“What? Ugh, what the...ah!"
[cpg cn=true]



[OnName num="warrior"]
“This guy...!"
[cpg cn=true]



The warrior holds up his spear. He aims at me.
[cpg]


[FACE method="change_4" pos="2/3"]

Clara looks back at me, her eyes vacant.
[cpg]


[FO pos="2/3" time=800]
[SE f=se016]
;//【ＳＥ】『倒れる』

[WAIT time=1500]


The medicine has already taken effect. I decided to run away.
[cpg]


My body is safe from being pierced by the spear...
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

;**【ＣＧ】ci_06_0 ***********************
;//カットイン
[CUTIN f="ci_06_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

After much thought, I disguised myself as a slime.
[cpg]


Then, I quickly made my way to the demon's side.
[cpg]

[CUTIN f="ci_06_0.ui" show={false} method="slideout"]
;//[WAIT time=1000]

[OnName num="monk"]
“I thought something was wrong, I can’t believe that he was a demon..."
[cpg cn=true]

[SE f="se026"]
;//【ＳＥ】『魔法』

The monk is chanting some spell. Light converges on her hands.
[cpg]


Then it becomes a ray of light and is released on me, but Janice stands in front of me.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Janice115"]
[OnName num="janice"]
“Renji! Run!"
[cpg cn=true]


I can't even nod in this form. All the other demons go towards Clara all at once.
[cpg]


What would Kulara's friends make of this? Would they carry Clara and run away?
[cpg]



[OnName num="monk"]
"This is not good... If we don't do anything, Clara will...”
[cpg cn=true]


[OnName num="warrior"]
Let's retreat for a moment. We can't hold them off with just the two of us."
[cpg cn=true]




[window target=false]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="uzumaki3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="uzumaki3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





As a result, the demons seemed to have captured Clara.
[cpg]


I can't take all the credit, either. ......
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/5" time=800]
[VOICE f="Dorothy111"]
[OnName num="dorothy"]
“That was great, Renji! I can't believe you caught their champion."
[cpg cn=true]


[FACE method="change_2" pos="2/5"]
[VOICE f="Janice116"]
[OnName num="janice"]
I'm not at all. I can't believe they could do this to us without us knowing."
[cpg cn=true]


Dorothy and Janice were very complimentary about me.
[cpg]


They seemed pretty sincerely pleased with me, too. I don't feel bad.
[cpg]


[OnName num="rudolf"]
I guess I wasn't mistaken," he said. I knew you'd do your part someday.
[cpg cn=true]


[OnName num="renzi"]
Thank you.
[cpg cn=true]


[FACE method="change_6" pos="4/5"]
[VOICE f="Dorothy112"]
[OnName num="dorothy"]
“Really, that champion gave me a hard time... Renji, thank you so much."
[cpg cn=true]


[OnName num="renzi"]
Oh no. I did what I could do.
[cpg cn=true]

[SE f=se012]
;//【ＳＥ】『衣擦れ』

[FG f="CHA02_p5_01_a.ui" method="change_2"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/5" time=1]
[VOICE f="Dorothy113"]
[OnName num="dorothy"]
I love your humility, too. I love it."
[cpg cn=true]


Dorothy is sticking with me. And the Demon King didn't frown too much when he saw that.
[cpg]

[FACE method="change_1" pos="2/5"]

That's how much I did. But ......
[cpg]


What will happen to Clara now?
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=1]

[OnName num="rudolf"]
I'll have to let you take your reward. Do you have anything you want to say?"
[cpg cn=true]


[OnName num="renzi"]
That's ......
[cpg cn=true]


;//
;//
;//
;//;//■選択肢
;//[switch]
;//[case "役に立てて嬉しい"]
;//	[swap]
;//	[jump target="*IseSel05_1"]
;//[case "クラーラを丁重に扱って欲しい"]
;//	[swap]
;//	[jump target="*IseSel05_2"]
;//[endswitch]
;//
;//
;//１、役に立てて嬉しい
;//２、クラーラを丁重に扱って欲しい
;//
;//
;//
;//==============================
;//１、役に立てて嬉しい
*IseSel05_1|Transformation was still the best.




[OnName num="renzi"]
I was like, "Oh, no, not a reward. I'm happy to be of service."
[cpg cn=true]


I still don't feel bad about the praise.
[cpg]


I decided to do something more for the demon tribe.
[cpg]


I might even do something somewhat deceitful.
[cpg]


[OnName num="rudolf"]
"Yes, that's right... I'll leave it to you to interrogate Clara.”
[cpg cn=true]


[OnName num="renzi"]
What?
[cpg cn=true]


[OnName num="rudolf"]
I want to know what's going on on the human side. There are things we can get out of her."
[cpg cn=true]


[OnName num="rudolf"]
I am willing to use any means necessary. Can you do that for me?"
[cpg cn=true]


[FACE method="change_7" pos="4/5"]

Dorothy is puzzled. She doesn't seem to know what she's talking about, but it's certainly a reward for me as a man.
[cpg]


[OnName num="renzi"]
I understand. I'll take care of it."
[cpg cn=true]




;//※変数+1
[stflag Gameflg = 1]

[jump target="*IseSel05_3"]

;//;//==============================
;//;//２、クラーラを丁重に扱って欲しい
;//*IseSel05_2|変身はやっぱり最強でした
;//
;//
;//
;//
;//[OnName num="renzi"]
;//「……クラーラを、あまり乱暴に扱わないでください」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_5" pos="4/5"]
;//[VOICE f="Dorothy114"]
;//[OnName num="dorothy"]
;//「何言ってるの？　クラーラの肩を持つの」
;//[cpg cn=true]
;//
;//
;//[OnName num="renzi"]
;//「いや。クラーラだって、何か理由があって戦ってるわけだし」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_3" pos="4/5"]
;//[VOICE f="Dorothy115"]
;//[OnName num="dorothy"]
;//「そんな！　あたし、クラーラだけは許せないよ、理由があっても仲間を殺してきた相手だもん」
;//[cpg cn=true]
;//
;//
;//
;//[OnName num="rudolf"]
;//「私も同意見だ。が、お前が乱暴に扱うなと言うなら……」
;//[cpg cn=true]
;//
;//
;//[OnName num="rudolf"]
;//「彼女を尋問するのを、お前に任せようか」
;//[cpg cn=true]
;//
;//
;//
;//[OnName num="renzi"]
;//「それは……」
;//[cpg cn=true]
;//
;//
;//[OnName num="rudolf"]
;//「人間側の情勢を知りたい。しかし、大事に扱いたいというならお前のしたいようにしてみてくれ」
;//[cpg cn=true]
;//
;//
;//[OnName num="renzi"]
;//「……ええ」
;//[cpg cn=true]
;//
;//
;//
;//;//==============================

*IseSel05_3|Transformation was still the most powerful


[OnName num="rudolf"]
Rumor has it she has a weakness for tentacled creatures."
[cpg cn=true]


[OnName num="rudolf"]
I'll leave it to you to decide how you want to use this information. I'm asking you."
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="4/5" time=1]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





And so I was appointed to interrogate Clara.
[cpg]


It was not a heavy burden, but I was surprised at the suddenness of the situation.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Arsha132"]
[OnName num="asha"]
Dorothy, you must have been delighted.
[cpg cn=true]


[OnName num="renzi"]
That's, well...
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha133"]
[OnName num="asha"]
I'm happy for you, too," he said. "I'm happy, too, because I've caught my nemesis.
[cpg cn=true]


[OnName num="renzi"]
“That said... It was done in an unfair way.”
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Arsha134"]
[OnName num="asha"]
Everyone is happy even if it's not fair. "They don't have to be afraid of when the attack will come.
[cpg cn=true]


Surely that's true... Lives are at stake, even for demons.
[cpg]


That may be true for Asha as well.
[cpg]


So, is it necessary to go easy on Kulara to a certain extent?
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************


[SE f=se009]
;//【ＳＥ】『歩く』


And the next day. I was on my way to the place where Kulara was being held.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Clara014"]
[OnName num="clara"]
"You are..."
[cpg cn=true]


I looked like the swordsman I was at the time so that they would know it was me.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara015"]
[OnName num="clara"]
'You tricked me. Pretending to be human."
[cpg cn=true]


[OnName num="renzi"]
Yeah. No hard feelings."
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara016"]
[OnName num="clara"]
Yeah. Because this is my failure."
[cpg cn=true]


You have a pretty graceful personality. But for all that, your body is shaking.
[cpg]


Maybe he's wondering what they will do to him.
[cpg]


[OnName num="renzi"]
What are the humans going to do to us demons?　Are you going to eradicate them?"
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Clara017"]
[OnName num="clara"]
I must warn you, I have nothing to say to you.
[cpg cn=true]


[OnName num="renzi"]
"I see..."
[cpg cn=true]


Well, here we go. How do I get her to talk?
[cpg]

;//＠尋問ということなら、何かいやらしいことをしてやりたい気持ちはある。彼女は、触手が苦手だと言っていたな。
If you mean interrogation, I am inclined to do something erotic for you. You said she is not good with tentacles.
[cpg]


[OnName num="renzi"]
Is it true what she said about not being good with tentacles?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]

[VOICE f="Clara018"]
[OnName num="clara"]
I don't know.
[cpg cn=true]


I don't think he didn't know, but he wasn't going to tell me.
[cpg]


I had a repertoire of tentacled creatures I could turn into for situations like this.
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_15_0 ***********************
;//カットイン
[CUTIN f="ci_15_0.ui" show={true} method="feadin"]
;*****************************************
[WAIT time=1000]

[FACE method="change_5" pos="2/3"]
[VOICE f="Clara019"]
[OnName num="clara"]
Hiccup ......!"
[cpg cn=true]


I turn into a tentacled creature with suction cups. Clara is frightened.
[cpg]

[CUTIN f="ci_15_0.ui" show={false} method="feadout"]
[WAIT time=1000]

Don't take it badly, he muttered to himself in his mind as he pressed closer to her.
[cpg]


;//;//========================================
;//;//●ＣＧ（触手に変身した主人公がヒロインを尋問する。くすぐり責め）ev_14
;//;//人物１：ヒロイン１　服装１：着衣
;//;//人物ex：主人公　　　服装ex：無し
;//;//場所　：ダンジョン＿室内
;//;//時間　：暗い
;//;//備考　：主人公は吸盤のあるような触手生物の姿に変身しています
;//;//========================================
;//
;//;//*Scene012
;//
;//[STOPBGM]
;//[FO pos="2/3" time=1000]
;//[BG f="black.ui"  time=1000]
;//[WAIT time=1000]
;//[BGM f="10"]
;//;**【ＣＧ】 ev_14_0 ***********************
;//[CG id=5 index=0 time=1000]
;//;***************************************
;//[WAIT time=1500]
;//
;//
;//
;//[SE f=se015]
;//;//【ＳＥ】『触手・スライム』
;//
;//
;//[VOICE f="Clara020"]
;//[OnName num="clara"]
;//「放してください……こんなことしても、私は何も喋りませんよ」
;//[cpg cn=true]
;//
;//
;//彼女は気丈そうなところもあるけど、確かに触手生物が苦手なのだろうと思うような反応も見せている。
;//[cpg]
;//
;//;**【ＣＧ】 ev_14_a ***********************
;//[CG id=5 index=1 time=1000]
;//;***************************************
;//[WAIT time=1500]
;//
;//[VOICE f="Clara021"]
;//[OnName num="clara"]
;//「っ……こんな魔物、武器さえあればっ」
;//[cpg cn=true]
;//
;//
;//
;//
;//
;//今まで女の子にいたずらしてきたことは何度かあるけど、今までのどれとも違う。
;//[cpg]
;//
;//
;//彼女は明らかに抵抗するだけ無駄だ。ということは、いくら抵抗してくれてもいい。
;//[cpg]
;//
;//
;//意地悪したくなるというか、そんな姿だ。
;//[cpg]
;//
;//
;//逆に、あまり乱暴はしたくないというか、そんな気分だ。
;//[cpg]
;//
;//;**【ＣＧ】 ev_14_b ***********************
;//[CG id=5 index=2 time=1000]
;//;***************************************
;//[WAIT time=1500]
;//
;//[VOICE f="Clara022"]
;//[OnName num="clara"]
;//「今なら、まだ許しますから……お願いっ、放して」
;//[cpg cn=true]
;//
;//
;//俺を許すとか許さないとか、クラーラの口ぶりはまだ強気だった。
;//[cpg]
;//
;//
;//折りたくなるというほどでなくとも、何かしてやりたいという気持ちにはなる。
;//[cpg]
;//
;//[SE f=se015]
;//;//【ＳＥ】『触手・スライム』
;//
;//
;//[VOICE f="sClara001"]
;//[OnName num="clara"]
;//「触られてるっ、はぁ、はぁ、くすぐったい……っ」
;//[cpg cn=true]
;//
;//
;//クラーラは身をよじりながら逃げ出そうとするが、逃げ出せない。
;//[cpg]
;//
;//;**【ＣＧ】 ev_14_c ***********************
;//[CG id=5 index=3 time=1000]
;//;***************************************
;//[WAIT time=1500]
;//
;//[VOICE f="sClara002"]
;//[OnName num="clara"]
;//「やめて、やめてぇっ、うううぅうっ……」
;//[cpg cn=true]
;//
;//
;//暫くくすぐり続けるけど、彼女は笑うことはなかった。やはり相当苦手らしい。
;//[cpg]
;//
;//
;//;//移植前シーンカット
;//
;//
;//
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





However, it seems that she really doesn't like tentacles. I wonder if there is a reason for this.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Clara044"]
[OnName num="clara"]
"Haa, haa..., ah."
[cpg cn=true]


She has sweat beading on her forehead. I could attack her now...
[cpg]


I was to use my strength on me. Let's take a break.
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]





I disguised myself as a human and told her, "I'm going to take a break.
[cpg]


[OnName num="renzi"]
Please. Tell me everything you know, it's better for both of us.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara045"]
[OnName num="clara"]
“I have nothing to say to..."
[cpg cn=true]


Parallel lines. I turned my back on her for once.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="02"]
;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



Kulara has a lookout. I can't escape so easily.
[cpg]


She will be served some food, too. It would be pointless if she died.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy116"]
[OnName num="dorothy"]
“How's it going? Did you get anything out of Clara?"
[cpg cn=true]


[OnName num="renzi"]
No. Nothing so far.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Dorothy117"]
[OnName num="dorothy"]
I see. Renji seems kind, after all.
[cpg cn=true]


[OnName num="renzi"]
......
[cpg cn=true]


Indeed, there is no denying it. It is one thing to misbehave, it is another to blame in order to get something out of them.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy118"]
[OnName num="dorothy"]
I'll take over for you, shall I?　If it were me, I'd be relentless."
[cpg cn=true]


Dorothy says scary things. Indeed, I think she seems innocent but unrelenting.
[cpg]


There must be some resentment. She's going to keep blaming me even if Clara opens her mouth.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Dorothy119"]
[OnName num="dorothy"]
What's with that face? I'm not that reckless.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Dorothy120"]
[OnName num="dorothy"]
Probably better than leaving it to Janice, though."
[cpg cn=true]


[OnName num="renzi"]
Maybe so, but ...... no, I doubt it."
[cpg cn=true]


Both are scary. I think Janice would take an unobtrusive but sure-fire approach.
[cpg]


Compared to Dorothy, she's more likely to be rational...
[cpg]


I'm still the right person for the job. I reconsidered.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



Once again, I head for Clara's place.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Clara046"]
[OnName num="clara"]
......"
[cpg cn=true]


Clara is glaring in my direction.
[cpg]


I know she would be a hateful opponent for her, but then again, Clara is a hateful opponent for all demons.
[cpg]


[OnName num="renzi"]
“Why would Clara want to fight demons?”
[cpg cn=true]


She remained silent and looked at me.
[cpg]


You're not really going to say anything, are you? Her defiance was rather intriguing.
[cpg]


[OnName num="renzi"]
'Oh well. I'll make her talk, even if I have to force her to."
[cpg cn=true]


[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]

[FACE method="change_5" pos="2/3"]



She freaks out when he turns into a tentacle creature once more.
[cpg]


Seeing her scared makes me want to do something about it. ......
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="sClara003"]
[OnName num="clara"]
“Please..., don't do anything else."
[cpg cn=true]


;//ブラックアウト

I interrogated her all the way through, but she still didn't say anything.
[cpg]


I feel like I'm almost there...
[cpg]


;//移植前シーンカット



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]

I reverted back to human form once more and asked her.
[cpg]


[OnName num="renzi"]
What do you want to do?　If you still want me to, I can do it."
[cpg cn=true]


[OnName num="renzi"]
I can keep you company forever. All night long."
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Clara072"]
[OnName num="clara"]
“No, please..."
[cpg cn=true]


Clara imagines it and screams quietly.
[cpg]


[OnName num="renzi"]
“Hey, Clara. You can't think of the shame of betraying the human beings.”
[cpg cn=true]


[OnName num="renzi"]
I do what I have to do to save myself. Isn't that normal?
[cpg cn=true]


I try to shake him up mentally.
[cpg]


Clara looked lost and then speaks.
[cpg]


[FACE method="change_4" pos="2/3"]
[VOICE f="Clara073"]
[OnName num="clara"]
“I understand... I will tell you what I know.”
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[OnName num="rudolf"]
“Hm. I see..."
[cpg cn=true]


I report this back to the Demon King.”
[cpg]


[OnName num="renzi"]
'Yes, sir. The human side is not looking for a big fight.
[cpg cn=true]


What I was able to get out of Clara was that the human race also did not want conflict.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/5" time=800]
[VOICE f="Janice117"]
[OnName num="janice"]
So there is nothing for us to do.
[cpg cn=true]


[OnName num="rudolf"]
Of course. I don't want to make a mess of things.
[cpg cn=true]


The demons were thinking the same thing, that if there was no conflict, there was nothing more to be done.
[cpg]


[OnName num="rudolf"]
In any case, you did a good job. I'll have to treat you better, too.
[cpg cn=true]


[OnName num="renzi"]
Thank you."
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=2000]
[WAIT time=2100]
[FO pos="2/5" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei2.webp" color={0x000000ff} time=2000]
[WAIT time=2100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


From there, my room became much more livable.
[cpg]


I was never assigned a different room, but the furniture was better.
[cpg]


The bedding is soft. That alone changes my motivation a lot.
[cpg]


There's limited stuff in the dungeon, but they're turning it around for me.
[cpg]


[OnName num="renzi"]
“Hmm..."
[cpg cn=true]


It looks like the peace will continue for a while. Then I had only one thing to think about.
[cpg]


I want to devise further mischief. Just because there is peace does not mean there I can't fill my free time
[cpg]



[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep011.ks" target="*start"]
