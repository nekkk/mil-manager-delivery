*start

;###################################################################
*Ep015|Transforming for You
;###################################################################
;//３、ジャニス

[SCENE id=13]


[window target=false]


;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out" pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out" pos="3/5"]


[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_7" pos="2/3" time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BGM f="05"]


[window target=true]


Janice. I thought of her.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy447"]
[OnName num="dorothy"]
'Don't shut up, say something.
[cpg cn=true]


[OnName num="renzi"]
"......"
[cpg cn=true]


She is someone close to Dorothy. I can't tell her directly.
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy448"]
[OnName num="dorothy"]
I can't say it directly to her. "Your face ...... tells me you're thinking of someone other than me."
[cpg cn=true]


[OnName num="renzi"]
“No, no... I don't know."
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy449"]
[OnName num="dorothy"]
I don't know. You don't have to answer like that, you could just be honest."
[cpg cn=true]


Dorothy looked unhappy, but it didn't change how I felt inside.
[cpg]


[FO pos="2/3" time=1000]

[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Janice. For some reason, she has a weakness for ghosts and the undead.
[cpg]


I haven't figured out why yet, but they are worth scaring.
[cpg]


Other than that, my success in capturing Clara was a big achievement even from Janice's point of view.
[cpg]


I had a feeling that Janice would not refuse strongly, even if I was a little reckless.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





I realized how I felt, and the mischief escalated.
[cpg]


I transform into a mummy and approach Janice while she is sleeping.
[cpg]


How would she react?　It must be something I am not good at.
[cpg]


If he was sleepwalking, he might try to think it was a dream.
[cpg]



[VOICE f="Janice192"]
[OnName num="janice"]
“Zzzz...zzzz...”
[cpg cn=true]


He is still breathing in his sleep. I moved closer to her.
[cpg]



;//========================================
;//●ＣＧ（寝ているヒロインに近づく主人公。ヒロインは包帯で縛られていて、夢だと思い込もうとして目を閉じている）ev_45
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：包帯
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公はミイラに化けています
;//=======================================

;//*Scene039

[STOPBGM]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_45_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1500]



[VOICE f="Janice193"]
[OnName num="janice"]
“Mnn...ugh.”
[cpg cn=true]


The bandages are wrapped around her body. I was able to move her at will to some extent.
[cpg]


I think she must have been a demon like that to begin with. I can't do anything that the original demon couldn't do.
[cpg]


In fact, I can't do some things that the original demon could do.
[cpg]


But the fact that I can move her may be a basic movement.
[cpg]


If I tie him up with this, I'm sure I'll see some interesting reactions when he wakes up.
[cpg]

;**【ＣＧ】 ev_45_a ***********************
[CG id=2 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice194"]
[OnName num="janice"]
"(What is it ...? Is someone trying to wake me up?)"
[cpg cn=true]


I wrapped bandages around her body and tied them off.
[cpg]


She screams a little. She is trying to wake up a little.
[cpg]


Janice was trying to open her eyes a little thinner.
[cpg]


I wait for her to wake up, wondering how she will react.
[cpg]


Moments like this are the most fun I have when I am about to play a trick on her.
[cpg]

;**【ＣＧ】 ev_45_b ***********************
[CG id=2 index=2 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice195"]
[OnName num="janice"]
"What the...?”
[cpg cn=true]

;**【ＣＧ】 ev_45_c ***********************
[CG id=2 index=3 time=1000]
;***************************************
[WAIT time=1500]

Then Janice wakes up. She immediately closes her eyes tightly and tries to sleep again.
[cpg]


She probably thinks it's a dream. Yes, of course it is, of course it is.
[cpg]


She's never been good with ghosts.
[cpg]



[VOICE f="Janice196"]
[OnName num="janice"]
“(Another funny dream... I must be pretty tired.)"
[cpg cn=true]


I can't get the words out. I might be able to, but then they would know it was me.
[cpg]


So I tried to go a little further without saying anything.
[cpg]


;//ブラックアウト


But still, it seems ...... I really don't like ghosts.
[cpg]

;//移植前シーンカット


I think Janice is ...... hiding something in her past that she can't tell me.
[cpg]


Looking at her pained face, I don't think I want to do anything more.
[cpg]



I was thinking of just leaving her.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





I was satisfied for the moment, but I was thinking about my next plan.
[cpg]


She'll probably change her underwear when she wakes up in the morning. Because they're dirty.
[cpg]


Then I thought of something else.
[cpg]



[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





I decided to disguise myself in her clothes. And I slept the night.
[cpg]


When she wakes up in the morning, she would put on her clothes...
[cpg]




[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice212"]
[OnName num="janice"]
Huh. Didn't sleep so well after all."
[cpg cn=true]


Janice comes up to me, rubbing her eyes.
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="sJanice007"]
[OnName num="janice"]
I need to get dressed ......."
[cpg cn=true]


He was trying to put me on as he said that. I stay close to her body.
[cpg]


Now I can stay close to her all the time. As soon as I think that...
[cpg]


I could feel her body heat and smell. That alone made me feel happy.
[cpg]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Janice214"]
[OnName num="janice"]
“Good morning. Your Majesty the Demon King... Princess..."
[cpg cn=true]


[OnName num="rudolf"]
Oh. Good morning."
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/2" time=800]
[VOICE f="Dorothy450"]
[OnName num="dorothy"]
Good morning. You look like you haven't slept well today.
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Janice215"]
[OnName num="janice"]
“Yes... I had the strangest dream.”
[cpg cn=true]


Janice heads for the King's Chamber. Dorothy and the Demon King are already here.
[cpg]


I wonder if I can scare her here. That's what I think as I stay close to her...
[cpg]


;//移植前シーンカット

;//ブラックアウト

[SE f=se012]
;//【ＳＥ】『衣擦れ』

I moved the cloth against my back and tickled it.
[cpg]

[FACE method="change_5"  pos="2/2"]
[VOICE f="sJanice008"]
[OnName num="janice"]
Yikes!"
[cpg cn=true]

[FACE method="change_5"  pos="2/2"]
[VOICE f="sDorothy015"]
[OnName num="dorothy"]
What's wrong?　You sound funny."
[cpg cn=true]

[FACE method="change_4"  pos="2/2"]
[VOICE f="sJanice009"]
[OnName num="janice"]
No, no. It's nothing."
[cpg cn=true]


It was healthy and cute how she tried her best to report on her work while being blamed by me.
[cpg]


I was falling more and more in love with Janice.
[cpg]


After finishing her daytime work, Janice went back to her room.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





She takes off her clothes, or rather me, and talks to me.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Janice231"]
[OnName num="janice"]
'Renji. What do you mean?"
[cpg cn=true]


[OnName num="renzi"]
'.......'
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice232"]
[OnName num="janice"]
Don't even think of doing these things."
[cpg cn=true]


I guess I can't stay in this form any longer.
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



With that thought, I reverted back to human form and bowed my head to Janice.
[cpg]


[OnName num="renzi"]
I'm sorry.
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice233"]
[OnName num="janice"]
I hope you understand. Because if you do any more I'm going to be really pissed off."
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





I was not depressed, but rather wondering what I would do next.
[cpg]


Would she be afraid of zombie things too?　If so, I'd like to try that too.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha225"]
[OnName num="asha"]
You look bad, Renji."
[cpg cn=true]


Asha was coming this way while I was at work.
[cpg]


[OnName num="renzi"]
'I don't think so. Do you understand?"
[cpg cn=true]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Arsha226"]
[OnName num="asha"]
I understand. You've been all into Janice lately."
[cpg cn=true]


[OnName num="renzi"]
...... understand."
[cpg cn=true]


Asha giggled and went back to work.
[cpg]


I wonder if Janice is aware of this. That she is the only one who is specially threatened by ......
[cpg]


If they realize why I'm doing that, they'll know I'm doing them a favor, too.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





Anyway, I was trying to turn into a zombie. Of course, to turn into a zombie, you have to know what it smells like.
[cpg]


I didn't want to smell such a thing..., I decide to turn into a ghost again.
[cpg]


I can transform, so I don't have to be a ghost to begin with. I transformed into something else in the corridor and wait for her to come.
[cpg]


I can shapeshift, so I don't have to be a zombie to begin with. I transformed into a golem or something in the aisle and waited, mimicking her.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Janice234"]
[OnName num="janice"]
"Oh my God!
[cpg cn=true]


Janice has a cute reaction every time. But ...... soon realized it was me and glared at me.
[cpg]

[FACE method="change_4"  pos="2/3"]
[VOICE f="sJanice010"]
[OnName num="janice"]
“Renji, huh...? Enough of this.”
[cpg cn=true]



;//【ＢＧ】『ダンジョン＿通路』（暗い）

[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]



I transform back into my human form. Then I apologized to his face.
[cpg]


[OnName num="renzi"]
“I'm sorry. Please don't tell the Demon King.”
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice255"]
[OnName num="janice"]
'The other day, you just apologized to me. You don't really think I won't do it again, do you?"
[cpg cn=true]


Janice looks angry, but her face is a little red and she doesn't seem to be looking straight at me somehow.
[cpg]


There was a hint that she was feeling uneasy. I don't know why. ......
[cpg]


But then, maybe it's okay to ask.
[cpg]


[OnName num="renzi"]
“I'd like to hear it from you too... Why don’t you have more of a hateful reaction?"
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice256"]
[OnName num="janice"]
“Eh...that’s..."
[cpg cn=true]


Janice was blatantly flustered.
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice257"]
[OnName num="janice"]
“You're the one who captured Clara... Besides, you helped the guys in charge of cultivation."
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice258"]
[OnName num="janice"]
I'm grateful. That's why it's hard for me to refuse."
[cpg cn=true]


The words were said in a way that sounded like a maiden in love, not just grateful.
[cpg]


It wasn't so much the timing as it was that now was the time to confess. But I thought it was okay to at least hint at my feelings.
[cpg]


[OnName num="renzi"]
I'm in love with Janice.
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice259"]
[OnName num="janice"]
Don't say it. I don't want to hear any more."
[cpg cn=true]


But at that moment, Janice's expression turned grim.
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice260"]
[OnName num="janice"]
'I have more important things to take care of than these things.
[cpg cn=true]


[OnName num="renzi"]
“What do you mean...?"
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice261"]
[OnName num="janice"]
'I can't talk about it lightly. I probably won't talk about it with you for the rest of my life."
[cpg cn=true]



[SE f=se009]
;//【ＳＥ】『歩く』

[FO pos="2/3" time=1500]
[WAIT time=1500]
;//ブラックアウト



In the end, not everything was clear at the time.
[cpg]


I am hungry, so I head to the mess hall by myself.
[cpg]

[SE f=se009]
;//【ＳＥ】『歩く』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************




[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="1/2" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/2" time=800]

[VOICE f="Dorothy454"]
[OnName num="dorothy"]
"Ah, Renji. This way, this way."
[cpg cn=true]


Dorothy and Asha are chatting in the mess hall.
[cpg]


[FACE method="change_7"  pos="1/2"]
[VOICE f="Arsha227"]
[OnName num="asha"]
Dorothy and Asha were chatting. "What happened with Janice since then?"
[cpg cn=true]


Asha asked me bluntly, "What do you mean?
[cpg]


[OnName num="renzi"]
I feel as if I've been lightly dumped.
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]

[VOICE f="Arsha228"]
[OnName num="asha"]
I see. I guess Janice is not interested in that after all.
[cpg cn=true]


[FACE method="change_1"  pos="2/2"]
[VOICE f="Dorothy455"]
[OnName num="dorothy"]
What?　Did you confess?　My Janice.
[cpg cn=true]


I was caught up in the "to my Janice" part, but I didn't want to let it get to me.
[cpg]


[OnName num="renzi"]
But I haven't given up. I haven't been properly rejected yet."
[cpg cn=true]


I renewed my resolve. I would not stop playing tricks on her, after all.
[cpg]


[OnName num="renzi"]
If you say you get along with Janice, then you must get along with Dorothy, too."
[cpg cn=true]

[FACE method="change_7"  pos="2/3"]
[VOICE f="Dorothy457"]
[OnName num="dorothy"]
That's just me and Janice," he said. We've done things before Renji.
[cpg cn=true]


[OnName num="renzi"]
"What's ahead?"
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy458"]
[OnName num="dorothy"]
Renji probably hasn't even kissed her yet anyway.
[cpg cn=true]

What does that mean? You're doing it.
[cpg]

No. Are we talking about something that doesn't happen ......?　Dorothy and Janice are close in position, and if they are living together all the time in a dungeon like this.
[cpg]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Dorothy459"]
[OnName num="dorothy"]
Anyway, I won't let Renji have Janice."
[cpg cn=true]


[OnName num="renzi"]
......"
[cpg cn=true]


When I heard that I thought, before I gave up or didn't give up, that I could use this.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************



;//ここからしばらく、ドロシーのセリフ名前欄を「ドロシー（蓮司）」と置き換えてください





I had turned into Dorothy that day.
[cpg]


[FG f="CHA02_p4_01_a.ui" method="change_1"  pos="2/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/2" time=800]

[VOICE f="Dorothy460"]
[OnName num="renzi_to_dorothy"]
"Janice. Are you asleep yet?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="1/2" time=800]
[VOICE f="Janice285"]
[OnName num="janice"]
“No... What do you want this late at night?"
[cpg cn=true]


Janice and Dorothy are good friends. They wouldn't mind if I tried skin-to-skin with her in this state.
[cpg]


[FACE method="change_7"  pos="2/2"]
[VOICE f="Dorothy461"]
[OnName num="renzi_to_dorothy"]
I just thought it was time to see if she missed me.
[cpg cn=true]


I make up a bunch of wild accusations. If I didn't have such a bluff, I would have been found out.
[cpg]


[FACE method="change_6"  pos="1/2"]
[VOICE f="sJanice011"]
[OnName num="janice"]
I'm sure you're right. The last time you were here was ...... half a month ago?
[cpg cn=true]


Half a month. You remember clearly.
[cpg]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy462"]
[OnName num="renzi_to_dorothy"]
I missed you, too. Hey, Janice, come on.
[cpg cn=true]


[FACE method="change_2"  pos="1/2"]
[VOICE f="Janice287"]
[OnName num="janice"]
“Yes... As you wish, Your Highness."
[cpg cn=true]


Janice looks at me with a passionate gaze.
[cpg]

[move from="2/2" to="2/3" ease="easeInOutSine" time=2000]


I wondered what kind of relationship these two had, but I moved closer.
[cpg]

;//移植前シーンカット

I stroked her hair and she didn't mind.
[cpg]


[FACE method="change_1"  pos="2/3"]
[FACE method="change_1"  pos="1/2"]

[VOICE f="Janice300"]
[OnName num="janice"]
“You are very aggressive today, Princess.”
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Dorothy472"]
[OnName num="renzi_to_dorothy"]
“Really? I’m the same as usual."
[cpg cn=true]


If I talked any more, I might reveal my true identity.
[cpg]


I might as well get what I want out of Janice.
[cpg]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Dorothy473"]
[OnName num="renzi_to_dorothy"]
Hey, Janice. What do you think about Renji?"
[cpg cn=true]


[FACE method="change_7"  pos="1/2"]
[VOICE f="Janice301"]
[OnName num="janice"]
What's wrong, suddenly ......"
[cpg cn=true]


Janice blushes a little. Then she looked away.
[cpg]


[FACE method="change_1"  pos="1/2"]
[VOICE f="Janice302"]
[OnName num="janice"]
She said, "I don't dislike him, but ...... I have other things to focus on right now."
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy474"]
[OnName num="renzi_to_dorothy"]
What do you want to focus on?"
[cpg cn=true]


[FACE method="change_3"  pos="1/2"]
[VOICE f="Janice303"]
[OnName num="janice"]
You know that, don't you, Princess? It is revenge against humans."
[cpg cn=true]


Avenging. Well, I'm sure there are plenty of avengers you'd like to avenge.
[cpg]


But even so, his expression was not that of a man who had just had a comrade killed.
[cpg]


It was more of a sad, regretful look.
[cpg]



;//ここからドロシーのセリフ名前欄を元に戻してください



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





Janice said that she did not dislike me after all. It was a suggestive way of saying that she did not dislike me.
[cpg]


She also said she wanted to focus on avenging the human race, but I don't know why she was so obsessed with me.
[cpg]


Even so, Janice's obsession with the human race seemed to be quite strong.
[cpg]


She seemed to think that she would win this battle no matter what it took, and she probably had feelings that could not be cleared up otherwise.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[SE f=se008]
;//【ＳＥ】『喧噪』


The next morning. I go to the mess hall with a somewhat hazy feeling.
[cpg]


I was no longer Dorothy. I was in human form.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Arsha229"]
[OnName num="asha"]
Good morning, Renji.
[cpg cn=true]


[OnName num="renzi"]
Good morning. What do you recommend today?"
[cpg cn=true]


Asha and I exchange greetings. But I'm feeling a bit fuzzy.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="5/3" time=800]


Even as I carry the food to my desk, I can't seem to work up much of an appetite.
[cpg]

[move from="2/3" to="1/2" ease="easeInOutSine" time=2000]
[move from="5/3" to="2/2" ease="easeInOutSine" time=2000]


[VOICE f="Janice304"]
[OnName num="janice"]
You don't look happy.
[cpg cn=true]


[OnName num="renzi"]
Good morning ......, nothing out of the ordinary."
[cpg cn=true]


Then came Janice. Finding her is enough to make my heart skip a beat.
[cpg]


It's not just that I'm happy. It's a strong sense of urgency to do something about it.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





After dinner, I was thinking of ways to get closer to Janice.
[cpg]


She didn't mind so much when I turned into a bath towel. This kind of prank seems like a good idea.
[cpg]


I wondered if she was weak against ghosts and the like, but not against being scared like a surprise box.
[cpg]


I might give it a try. So I decided to turn into a mimic.
[cpg]


[SE f=se009]
;//【ＳＥ】『歩く』



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Janice305"]
[OnName num="janice"]
What's that ......?　In a place like this, a box?"
[cpg cn=true]


Janice is the alert type. If it looked like a normal treasure chest, she might not open it.
[cpg]


As I waited with this thought in mind, Janice approached.
[cpg]


She is staring at me. As long as I'm disguised as a mimic, it's best to scare her when she opens it...
[cpg]


Janice is about to leave the place. It was almost like cheating, but I decide to leave myself open and scare her.
[cpg]

;//移植前シーンカット
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]


Then Janice looks at me stoically.
[cpg]


[BG f="b_04_5.ui" time=1000]
[WAIT time=1500]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sJanice012"]
[OnName num="janice"]
Renji. How many times do you really have to do that?
[cpg cn=true]



[OnName num="renzi"]
I said, "I'm sorry. I won't do it again.
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice328"]
[OnName num="janice"]
He had said so many times before. I suppose that means Renji could attack me anywhere."
[cpg cn=true]


The way Janice stared at me, I had the feeling that she was a quintessential soldier of the past.
[cpg]


Sensing that I was in danger, I ran away.
[cpg]

[SE f=se010]
;//【ＳＥ】『走る』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





Of course, there is a limit to how long I can keep running. I transformed into a goblin and blended in with my surroundings.
[cpg]


[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_3"  pos="2/2" time=800]

[VOICE f="Arsha230"]
[OnName num="asha"]
What's wrong with your blood?　Janice."
[cpg cn=true]


[FACE method="change_1"  pos="2/2"]
[VOICE f="Janice329"]
[OnName num="janice"]
Did anyone come in here just now?
[cpg cn=true]


[FACE method="change_1"  pos="1/2"]
[VOICE f="Arsha231"]
[OnName num="asha"]
"Hmmm. The mess hall entrance is quite chaotic.”
[cpg cn=true]


Janice looks around the mess hall and for some reason heads straight for me.
[cpg]

[FO pos="2/2" time=800]

[FG f="CHA03_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_7"  pos="1/2" time=800]
[VOICE f="Janice330"]
[OnName num="janice"]
Was it you?"
[cpg cn=true]


[OnName num="renzi"]
How the hell do you know!"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice331"]
[OnName num="janice"]
“No empty dishes. You're not too cunning, Renji."
[cpg cn=true]


She grabbed me by the arm and dragged me away.
[cpg]

[SE f=se006]
;//【ＳＥ】『蛇が地面を這いずる』

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





Then she took me to her room.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sJanice013"]
[OnName num="janice"]
'What do I have to do to make you stop?　Tell me what the punishment is."
[cpg cn=true]


[OnName num="renzi"]
Hey, what ......"
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="sJanice014"]
[OnName num="janice"]
I need you to answer me. Otherwise, I will punish you in the way I see fit."
[cpg cn=true]

It was so powerful that I had no choice but to apologize flatly.
[cpg]


;//移植前シーンカット


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sJanice015"]
[OnName num="janice"]
“If you're sorry... Show it by leaving me alone.”
[cpg cn=true]

I was too scared to respond, but...
[cpg]



[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice358"]
[OnName num="janice"]
“What do you have to say for yourself?”
[cpg cn=true]


[OnName num="renzi"]
Yes ...... I won't do it again."
[cpg cn=true]


When he said that, I had no choice but to reply.
[cpg]




;//ブラックアウト

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



And then the next morning happened.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy475"]
[OnName num="dorothy"]
Renji!　Hey, come here."
[cpg cn=true]


[OnName num="renzi"]
What?"
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Dorothy476"]
[OnName num="dorothy"]
Huh?"　No, I'm not!　I forgot what I did."
[cpg cn=true]


Dorothy seemed angry, too. I didn't remember, and I shuddered, remembering even more what had happened yesterday.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



I was taken to the King's room. There was no Demon King there, so it was just me and Dorothy.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Dorothy477"]
[OnName num="dorothy"]
Janice said something funny and I was surprised. She must have been a monster without telling me.
[cpg cn=true]


[OnName num="renzi"]
Oh, oh ......"
[cpg cn=true]


Come to think of it, that's certainly no reason to be angry.
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy478"]
[OnName num="dorothy"]
I don't mind. I don't care how you approach Janice. I'm jealous.
[cpg cn=true]


[OnName num="renzi"]
Sorry."
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Dorothy479"]
[OnName num="dorothy"]
No, that's not what I want you to apologize for. I want you to be more open with Janice."
[cpg cn=true]


I didn't understand what Dorothy was saying, so I asked her back.
[cpg]



[OnName num="renzi"]
What ...... does that mean?"
[cpg cn=true]



[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy480"]
[OnName num="dorothy"]
Renji, do you know why Janice is so bad with ghosts?"
[cpg cn=true]


[OnName num="renzi"]
No, I don't know."
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Dorothy481"]
[OnName num="dorothy"]
'I'm sure it is. I'm sure you haven't heard it directly from me, since you're so close to me in disguise.
[cpg cn=true]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//色調をセピアにしてください



According to. Before I came to this world.
[cpg]




[window target=false]

[STOPBGM]

[FACE method="feadin_up" pos="4/7"]

[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_09_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="06"]

;//【ＢＧ】『平原』（暗い）******************************************************





There was a time when humans and demons were in stronger conflict than now.
[cpg]


There was a big conflict. Janice's brother was killed in battle there.
[cpg]


She says she still dreams about him.
[cpg]



;//色調を戻してください


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="08"]

;//【ＢＧ】『ダンジョン＿王の間』（暗い）******************************************************



[OnName num="renzi"]
“Janice...had a brother?"
[cpg cn=true]


The reason is more serious than I thought. I'm so sorry I've scared you off until now.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Dorothy482"]
[OnName num="dorothy"]
It's something Renji will have to do something about if he wants to make Janice happy."
[cpg cn=true]


[OnName num="renzi"]
“I don’t know if I can..."
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Dorothy483"]
[OnName num="dorothy"]
Oh, God!　If you're going to be so wishy-washy, give me back my Janice."
[cpg cn=true]


Dorothy has a point. I fell in love with Janice, so this is something I have to work out.
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Dorothy484"]
[OnName num="dorothy"]
Anyway, I've said all I have to say. The rest is up to Renji.
[cpg cn=true]


[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





Up to me. I think that's exactly what it will be, how much I can think of her.
[cpg]


I go to Clara's first. She is still a captive of the demon dungeon.
[cpg]

[BG f="b_04_5_up.ui" time=1000]
[FACE method="feadin_up" pos="4/7"]
[WAIT time=1500]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Clara533"]
[OnName num="clara"]
What do you want from me after all this time?"
[cpg cn=true]


[OnName num="renzi"]
I need to confirm something. Has Kulara ever fought against the dragon people?
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Clara534"]
[OnName num="clara"]
“Dragon people? I've heard that they were at the top of the demon tribe, but I don't know anything about them.”
[cpg cn=true]


By “top" I assume that also means Janice. So it was not Clara who killed her brother.
[cpg]


I was a little relieved. If Clara was the one with whom she had bad blood with, Janice would not leave her alone.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************





But when I think about it, I wonder if I should get revenge.
[cpg]


It feels somewhat different. Nothing will come of it just to settle a grudge.
[cpg]


I didn't want Janice to be resented by someone by taking revenge.
[cpg]


If that's the case, I'd better think of a way to heal Janice's wounds...
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Janice359"]
[OnName num="janice"]
What are you mumbling about?"
[cpg cn=true]


[OnName num="renzi"]
“Oh, no... It's nothing."
[cpg cn=true]


When Janice herself showed up, I realized I was talking to myself.
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice360"]
[OnName num="janice"]
'If it's nothing, fine. You haven't done anything to me lately."
[cpg cn=true]


She said this and took a seat facing me.
[cpg]


It's not that she doesn't like me. It's not that she doesn't like what I've done so far, or that she doesn't like me outright.
[cpg]


But if I confess to her now, I wonder what kind of response I would get.
[cpg]


In that sense, I should not make a mistake in the order in which I solve the problem.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





I decided to ask around about the testimonies of my friends who used to fight with Janice.
[cpg]


As I did so, a picture of the kind of person Janice's brother was began to emerge.
[cpg]


[OnName num="dragonewt_A"]
Cecil was too brave. On top of that, he defended Mr. Janice at the end."
[cpg cn=true]


[OnName num="dragonewt_B"]
Well, I couldn't see it at the time, because we were ...... sisters and brothers and we were so close."
[cpg cn=true]


Apparently Janice's brother is named Cecil.
[cpg]


I asked them in detail about their personalities and the way they spoke. And that's just the beginning.
[cpg]


I was thinking of a plan. It was something only I could do.
[cpg]


[OnName num="renzi"]
"Well, do you have any mementos of Cecil? I don't care what it is.
[cpg cn=true]


[OnName num="dragonewt_A"]
I think only Ms. Janice has such a thing.
[cpg cn=true]


[OnName num="dragonewt_B"]
No, I have it. I have an amulet he used to wear.
[cpg cn=true]


[OnName num="renzi"]
If you want, you can lend it to me. I won't ask you to give it to me.
[cpg cn=true]


[OnName num="dragonewt_B"]
But what would you use it for?
[cpg cn=true]


That's obvious. It's to transform into Cecil.
[cpg]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





There was a faint scent of someone else on the amulet.
[cpg]


The more I transformed myself as a shapeshifter, the more flexible the transformation became.
[cpg]


I think I've been able to transform into the exact same person with the faintest of clues...
[cpg]


[OnName num="renzi"]
What do you see?　Is he really Cecil?
[cpg cn=true]


[OnName num="dragonewt_A"]
“Yeah..., exactly the same.”
[cpg cn=true]


[OnName num="dragonewt_B"]
'Shapeshifters come in handy, don't they? Can you shape-shift a deceased person?
[cpg cn=true]


[OnName num="renzi"]
“I didn't know what to expect until I tried it myself..., but it looks like it should work.”
[cpg cn=true]


[FACE method="slidein" pos="4/7"]

[WAIT time=1500]
;//ブラックアウト





The plan is this. I disguise myself as Cecil and approach the sleeping Janice.
[cpg]


I wake her up and pretend to be Cecil to relieve her of her trauma. It cannot be solved in one night.
[cpg]


My concern is that Janice, who is sleeping, may wake up and come after me.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





So I decided to enlist the help of the Ghost Tribe.
[cpg]


[OnName num="renzi"]
I was so grateful for their help," she said. It's a big help.
[cpg cn=true]


[OnName num="ghost"]
No," he said. We've been keeping her away from us for so long, we ...... owe her a lot."
[cpg cn=true]


[OnName num="renzi"]
Can you do that thing where you make Janice immobile?"
[cpg cn=true]


[OnName num="ghost"]
That's a piece of cake.
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FACE method="feadin_up" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5_up.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


The day of the mission...
[cpg]

;**【ＣＧ】ci_20_0 ***********************
;//カットイン
[CUTIN f="ci_20_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

After she falls asleep, I disguise myself as Cecil.
[cpg]



;//[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Janice361"]
[OnName num="janice"]
“Hmmm..."
[cpg cn=true]


I call out to Janice and wake her up.
[cpg]


[OnName num="renzi"]
Janice said, "Sis. Wake up, sis."
[cpg cn=true]


Apparently that’s how Cecil called Janice. I had also investigated that area in particular.
[cpg]

[CUTIN f="ci_20_0.ui" show={false} method="slideout"]
[WAIT time=1000]

[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice362"]
[OnName num="janice"]
“This dream again...?”
[cpg cn=true]


Janice sees me and closes her eyes. From her reaction, she must have dreamed about Cecil many times.
[cpg]


[OnName num="renzi"]
I don't dream anymore. This is the last time."
[cpg cn=true]


Janice does not reply. Her eyes are tightly closed, as if she thinks it is a nightmare.
[cpg]


[OnName num="renzi"]
Thank you, sister, for everything. You fought for me all these years."
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice363"]
[OnName num="janice"]
'Of course ...... you died defending me. You said you'd always hated me."
[cpg cn=true]


I have dreams like that. It seems she has a strong sense of responsibility.
[cpg]


[OnName num="renzi"]
But that's enough. I take back everything I said.
[cpg cn=true]


[OnName num="renzi"]
I was happy enough. You find your own happiness.
[cpg cn=true]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Janice364"]
[OnName num="janice"]
I'm sure ...... you're being awfully nice to me today. I can't believe I'm having this dream."
[cpg cn=true]


I leave the room. Janice didn't follow.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[FACE method="out" pos="4/7"]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





[OnName num="ghost"]
I hope ...... that went well.
[cpg cn=true]


[OnName num="renzi"]
No, I don't know either. I guess we'll just have to keep going on this one until she's convinced."
[cpg cn=true]


I was prepared for the long haul at this point. But the next day.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************


[OnName num="renzi"]
"Good morning, Janice.
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Janice365"]
[OnName num="janice"]
Oh. Renji. Good morning."
[cpg cn=true]


Janice had a different expression than usual. It was almost expressionless, but a little softer.
[cpg]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice366"]
[OnName num="janice"]
I had a dream. A dream about my brother."
[cpg cn=true]


[OnName num="renzi"]
I see. What did you dream about?"
[cpg cn=true]


I listened to her story, trying not to get upset.
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice367"]
[OnName num="janice"]
My dreams have been nightmares ever since my brother died.
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Janice368"]
[OnName num="janice"]
He kept saying things that made me curse. I know I imagined it, but that's how it was. But last night was different.
[cpg cn=true]


Janice looked as if she had lost her way, as she said.
[cpg]


[OnName num="renzi"]
I'm glad to hear that. I don't think Cecil holds a grudge, either."
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice369"]
[OnName num="janice"]
“How do you know his name...?”
[cpg cn=true]


[OnName num="renzi"]
Oh, no, it's nothing.
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************



In the end, Janice never found out the truth.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice370"]
[OnName num="janice"]
"One of the guards has a fever today..., Renji, I need you to take his place. I'll accompany you."
[cpg cn=true]


[OnName num="renzi"]
I'll go with you. Of course.
[cpg cn=true]


I was to work as a lookout for the first time in a long time.
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_22_0 ***********************
;//カットイン
[CUTIN f="ci_22_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

I decided to disguise myself as a troll, a larger monster, to at least look strong on the outside.
[cpg]

[CUTIN f="ci_22_0.ui" show={false} method="slideout"]
[WAIT time=1000]

Then I stood guard for a while in the corridor. I was alone with Janice.
[cpg]



[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice371"]
[OnName num="janice"]
Renji," she said. Why did I have that dream?
[cpg cn=true]


[OnName num="renzi"]
“Who knows... Maybe it really was Cecil's soul that thought that."
[cpg cn=true]


[FACE method="change_7"  pos="2/3"]
[VOICE f="Janice372"]
[OnName num="janice"]
I don't know. I guess dreams are a way of deep psychology. If so, maybe I wanted to forgive me."
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice373"]
[OnName num="janice"]
I was trying to figure out why, and then I remembered ...... you."
[cpg cn=true]


[OnName num="renzi"]
Why?"　It's got nothing to do with me."
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice374"]
[OnName num="janice"]
It does matter. I should pursue my happiness, Cecil said. I want only one kind of happiness right now.
[cpg cn=true]


Janice blushed a little as she said this.
[cpg]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice375"]
[OnName num="janice"]
Hey, Renji. What do you think of me?　How is it that you've been coming on to me so much?"
[cpg cn=true]


He's waiting for me to say something. I understand that.
[cpg]


It's not like I'm going to let Janice tell me. If I'm any more vague than I already am, it could happen.
[cpg]


[OnName num="renzi"]
Because I like Janice."
[cpg cn=true]


[FACE method="change_2"  pos="2/3"]
[VOICE f="Janice376"]
[OnName num="janice"]
'Hmmm......... kind of sounds like I made you say it. Sorry."
[cpg cn=true]


[OnName num="renzi"]
No," he said. I couldn't say it for a long time. Sorry."
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice377"]
[OnName num="janice"]
“I don't know when I started liking you Renji. I started to think of you as a brave man around the time you captured Clara.”
[cpg cn=true]


[FACE method="change_3"  pos="2/3"]
[VOICE f="Janice378"]
[OnName num="janice"]
“You’re similar to Cecil in that way..."
[cpg cn=true]


Janice must have been a bracophile. I kind of understood that.
[cpg]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

;//ブラックアウト



I was still in my troll form, the one I had transformed into when I was on guard duty.
[cpg]


It was time for my shift to change, so I head back with Janice...
[cpg]


Neither of us had initiated it. But we both didn't want to leave each other, didn't want to let go.
[cpg]


[window target=false]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


I found myself in Janice's room.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="sJanice016"]
[OnName num="janice"]
She said, "I want you to stay ...... with me. I want you to hold me."
[cpg cn=true]


I didn’t realize she was this aggressive. I didn't refuse.
[cpg]


Thinking about it, I feel like I've been rushing him for a long time.
[cpg]


;//========================================
;//●ＣＧ（主人公に迫るヒロイン。寝ている主人公）ev_50
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公はトロールに化けています
;//=======================================


[SE f=se012]
;//【ＳＥ】『衣擦れ』

;//*Scene046
[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="10"]
;**【ＣＧ】 ev_50_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1500]






[VOICE f="sJanice017"]
[OnName num="janice"]
“It's embarrassing to be looked at so seriously again...”
[cpg cn=true]


She is a little embarrassed by the close contact. But he doesn't look disgusted.
[cpg]


[OnName num="renzi"]
You look beautiful, Janice. You're the most beautiful woman in the world."
[cpg cn=true]


The words came right out. They are words without any exaggeration.
[cpg]


But Janice looked away.
[cpg]

;**【ＣＧ】 ev_50_a ***********************
[CG id=3 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice381"]
[OnName num="janice"]
'Beautiful, isn't it? I have an appearance complex.'
[cpg cn=true]



[OnName num="renzi"]
Don't feel that way."
[cpg cn=true]



I stroke her hair. I love this distance.
[cpg]

;**【ＣＧ】 ev_50_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice401"]
[OnName num="janice"]
I love it. Renji, please love me more too.
[cpg cn=true]


[OnName num="renzi"]
Oh," he said. Sure."
[cpg cn=true]


When you ask me to love you, I can't not love you.
[cpg]



[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[WAIT time=100]
[STOPBGM]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





That day, we both slept in the same bed.
[cpg]


It was an indescribable feeling of fulfillment to feel her body heat.
[cpg]




[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************




From that day on, Janice's attitude toward me changed considerably.
[cpg]


[FG f="CHA03_p5_01_a.ui" method="change_1"  pos="1/2" time=800]
[VOICE f="Janice426"]
[OnName num="janice"]
Can I sit next to you?"
[cpg cn=true]


[OnName num="renzi"]
Uh-oh.
[cpg cn=true]


Instead of facing each other, they come next to each other. Even though Dorothy was right next to me.
[cpg]


Dorothy's eyes were wide and she looked at me, not at Janice.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_4"  pos="2/2" time=800]
[VOICE f="Dorothy485"]
[OnName num="dorothy"]
She looked at me, not at Janice. I've been robbed.
[cpg cn=true]


[OnName num="renzi"]
Don't talk nonsense to me.
[cpg cn=true]


[FACE method="change_2"  pos="2/2"]
[VOICE f="Dorothy486"]
[OnName num="dorothy"]
I was the only one who had Janice. Well, I hope Janice is okay with it.
[cpg cn=true]


[FACE method="change_4"  pos="1/2"]
[VOICE f="Janice427"]
[OnName num="janice"]
“I'm sorry..."
[cpg cn=true]


[FACE method="change_1"  pos="2/2"]
[VOICE f="Dorothy487"]
[OnName num="dorothy"]
It's true. I was just a game to Janice, wasn't I?
[cpg cn=true]


Dorothy swears, but I had a feeling her words weren't genuine either.
[cpg]


It was like Dorothy's feelings were showing, as if she couldn't congratulate him straight away.
[cpg]


Janice got it, too, and looked embarrassed.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="1/2" time=1]
[FO pos="2/2" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





After a day's work, we slept in the same room more often than not.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Janice428"]
[OnName num="janice"]
“There's a movement going on about Clara, about letting her go."
[cpg cn=true]


[OnName num="renzi"]
I see. You mean you're going to make some kind of deal?"
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice429"]
[OnName num="janice"]
He said, "Yeah. Maybe a truce will be reached. The Demon Lord is urging us to do so.
[cpg cn=true]


[FACE method="change_4"  pos="2/3"]
[VOICE f="Janice430"]
[OnName num="janice"]
I would have hated it," he said. I would have tried to avenge him thoroughly."
[cpg cn=true]


[OnName num="renzi"]
How about now?
[cpg cn=true]


[FACE method="change_1"  pos="2/3"]
[VOICE f="Janice431"]
[OnName num="janice"]
“Strangely enough... I've calmed down. Cecil has never held a grudge against me. I should have known.”
[cpg cn=true]


;//ブラックアウト




Cecil does not hold a grudge against Janice. Janice herself thought so at some point.
[cpg]


Janice seemed to be aware that the memory of not being able to protect her was the only thing that was swelling in her mind.
[cpg]


I thought I might have just given Janice one last push, but I thought it was all right if her doubts were cleared up.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************


And then. Janice and I lived a quiet life together.
[cpg]


Dorothy is still the same, but I think she's starting to give us a little blessing.
[cpg]


And Asha had been rooting for us from the beginning.
[cpg]


As for me, my shapeshifting ability was becoming even more extreme, and I was able to turn into "something that doesn't exist" or "someone who doesn't exist.
[cpg]

;**【ＣＧ】ci_21_0 ***********************
;//カットイン
[CUTIN f="ci_21_0.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]

I could somehow understand the smell of the dragon people, and then I could transform myself into a dragon person who was no one else.
[cpg]


[CUTIN f="ci_21_0.ui" show={false} method="slideout"]
[WAIT time=1000]

Janice was happy to see me in that form. I guess it means that she doesn't feel uncomfortable in our relationship.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Janice434"]
[OnName num="janice"]
“It's already morning..., and it's another day at work."
[cpg cn=true]


[OnName num="renzi"]
Oh," he said. Have a good day."
[cpg cn=true]


[SE f=se009]
;//【ＳＥ】『歩く』

[FO pos="2/3" time=1000]
[WAIT time=1100]

;//ブラックアウト



Janice always seems to be busy, being a member of the Demon King's entourage.
[cpg]


I, on the other hand, am not given very important assignments.
[cpg]


I'm starting to think that I can't do this forever, so I'm starting to ask for work on my own.
[cpg]


I will start out as a watchman, but I hope to be able to support Janice someday.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="02"]

;//【ＢＧ】『ダンジョン＿食堂』（暗い）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="1/3" time=800]
[FG f="CHA04_p3_01_a.ui" method="change_1"  pos="3/3" time=800]

[VOICE f="Janice435"]
[OnName num="janice"]
“The arrangements are in place to release Clara.”
[cpg cn=true]


[FACE method="change_4"  pos="1/3"]
[VOICE f="Dorothy488"]
[OnName num="dorothy"]
I hear so. Your father is sweet.
[cpg cn=true]


[OnName num="renzi"]
But it's a good thing, isn't it? It brings us one step closer to peace, doesn't it?"
[cpg cn=true]


[FACE method="change_4"  pos="3/3"]
[VOICE f="Arsha232"]
[OnName num="asha"]
I think I'm with you. We can't stay at each other's throats forever.
[cpg cn=true]


Everyone seemed to be in agreement on this point.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="3/3" time=1]
[FO pos="2/3" time=1]
[FO pos="1/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="05"]

;//【ＢＧ】『ダンジョン＿通路』（暗い）******************************************************





Janice felt that she no longer held grudges against humans and laughed more often than before.
[cpg]


After work, I would go to Janice's room and she would come to mine more often.
[cpg]


The fact that we were lovers became known to everyone around us.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_5.ui" time=10]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]

[BGM f="04"]

;//【ＢＧ】『ダンジョン＿寝室』（暗い）******************************************************





And today, I am alone with Janice.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Janice436"]
[OnName num="janice"]
"Renji... You look good.”
[cpg cn=true]


[OnName num="renzi"]
Oh," he said. I like it, too."
[cpg cn=true]


For example, the appearance of the dragon man who is no one. To be by her side, but to be told that you are a good fit.
[cpg]

;//移植前シーンカット

;//ブラックアウト


Tomorrow is a holiday for both of us. For that reason, we both snuggled up together and went to sleep.
[cpg]



;//========================================
;//●ＣＧロ（寝ている主人公に膝枕をするヒロイン。ベッドの上）ev_70
;//人物１：ヒロイン３　服装１：着衣
;//人物ex：主人公　　　服装ex：着衣
;//場所　：ダンジョン＿寝室
;//時間　：暗い
;//備考　：主人公は竜人に化けています
;//=======================================

[STOPBGM]
[FO pos="2/3" time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="09"]
;**【ＣＧ】 ev_70_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1500]





And the next time I woke up, this is what happened.
[cpg]



[VOICE f="Janice458"]
[OnName num="janice"]
Good morning. You looked so cute sleeping."
[cpg cn=true]


[OnName num="renzi"]
Oh ...... good morning."
[cpg cn=true]



[VOICE f="Janice459"]
[OnName num="janice"]
I've been sleeping better lately, so I'm getting out of bed faster."
[cpg cn=true]


[OnName num="renzi"]
Cecil doesn't dream anymore?
[cpg cn=true]

;**【ＣＧ】 ev_70_a ***********************
[CG id=4 index=1 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice460"]
[OnName num="janice"]
I don't think so. I always remembered his face when he was dying, but ......"
[cpg cn=true]



[VOICE f="Janice461"]
[OnName num="janice"]
Strangely enough, I can remember your smile now. I wonder why.
[cpg cn=true]


That's the best. All of my work was worth it...
[cpg]


[OnName num="renzi"]
Can I sleep for a while?
[cpg cn=true]

;**【ＣＧ】 ev_70_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1500]

[VOICE f="Janice462"]
[OnName num="janice"]
He's kind of like Cecil in the way he spoils you.
[cpg cn=true]


With the release of Clara, the conflict between demons and humans will stay calm for a while.
[cpg]


Then, Janice and I might be able to spend more time together.
[cpg]


If that doesn't happen, I'll do whatever it takes to make it happen.
[cpg]



;//ブラックアウト

[SCENE id=14]


;//ＥＮＤ　ヒロイン３ルート

[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]

[jump storage="epend.ks" target="*start"]


;//==============================
