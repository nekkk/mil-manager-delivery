

*start

;###################################################################
*Ep009|What would you use that body to change?
;###################################################################


[SCENE id=9]

[window target=false]


[BG f="black.ui"  time=1000]
[WAIT time=100]

;//レターボックス初期召喚
[free time=1000]
[WAIT time=1]
[FG f="ci_lbox.ui" method="out"  pos="4/7"]
[WAIT time=1]
[FG f="line.ui" method="out"  pos="3/5"]

[stflag Jumpflg = 0]


[if exp={getFlagValue("Jumpflg") == 0 }]
[stflag Cha1flg = 1]
[stflag Cha2flg = 1]
[stflag Cha3flg = 0]
[stflag Cha4flg = 0]
[stflag Cha5flg = 0]

[stflag Gameflg = 0]

[stflag Jumpflg = 1]
[endif]


[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_09_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="06"]
;//【ＢＧ】『平原』（昼）******************************************************


[OnName num="renzi"]
Dazzling ......"
[cpg cn=true]


I'll mutter to myself, but I'm just happy to be able to talk to myself as a human being.
[cpg]


It's been a long time since I was dressed as a human. With a somewhat buoyant feeling, I set out for the human town.
[cpg]



[SE f=se020]
;//【ＳＥ】『草原歩く』

[window target=false]

[BG f="b_09_3.ui" time=1000]
[WAIT time=1500]

[window target=true]
;//【ＢＧ】『平原』（夕方）******************************************************





It's not that I lack confidence in my physical strength. I exercise as much as anyone else.
[cpg]


But I wondered if my body would be able to survive in this world after my reincarnation.
[cpg]


In fact, I had no trouble walking, but there was still a subtle sense of discomfort.
[cpg]


After all, that's probably because I used to be a demon.
[cpg]


The sun was setting in no time. I heard that the town is located in a place that cannot be reached in a day, so I walked patiently.
[cpg]


[SE f=se020]
;//【ＳＥ】『草原歩く』


[window target=false]

[BG f="b_09_4.ui" time=1000]
[WAIT time=1500]

[window target=true]
;//【ＢＧ】『平原』（夜）******************************************************





The only things we had to carry were money and food. We did not bring anything for camping.
[cpg]


There was a village of ogres between the dungeon and the human town.
[cpg]


The ogres were more like demons than humans, and according to Janice, they were not to be mistreated.
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="08"]
;//【ＢＧ】『鬼の集落』（夜）******************************************************





[OnName num="renzi"]
“It’s here...”
[cpg cn=true]


I am on the edge of food. I have to stop here to save money...
[cpg]


Still, it looks kind of like old Japan.
[cpg]


It's more relaxing than being in a dungeon. I guess it is important to have a certain amount of sunlight.
[cpg]


[OnName num="demon_A"]
Wait a minute. Who are you?
[cpg cn=true]


Two ogres stood at the entrance of the village. They were gatekeepers.
[cpg]



[OnName num="demon_B"]
What do you humans want? We cannot allow you to enter.
[cpg cn=true]


[OnName num="renzi"]
No, I'm a demon. I'm a shapeshifter, and I'm a ......."
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]


[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


;**【ＣＧ】ci_01_1 ***********************
;//カットイン
[CUTIN f="ci_01_1.ui" show={true} method="slidein"]
;*****************************************
[WAIT time=1000]


I decided to untransform and reveal my first serpentine form.
[cpg]


[CUTIN f="ci_01_1.ui" show={false} method="slideout"]
[WAIT time=1000]

The ogres looked a little surprised, but then became rather relieved.
[cpg]


I guess that was because I was able to prove that I was not human.
[cpg]


[OnName num="demon_A"]
I said to them, "You're a ...... demon tribe. You should not quarrel with humans as much as you do with me."
[cpg cn=true]


That's not a story I'm involved in about that. But ...
[cpg]


[OnName num="renzi"]
"Yeah..."
[cpg cn=true]


What an appropriate reply, I decided to be let into the settlement.
[cpg]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]




I revert back to my human form once more. This form was calmer than the demon form.
[cpg]


By the way, Janice said she wouldn't be rude to me, but I didn't feel very welcome.
[cpg]


Perhaps they'll let me stay, but I have a feeling they'll let me stay. ......
[cpg]


[OnName num="renzi"]
“Excuse me..."
[cpg cn=true]


I call out from in front of the house. It is night, but not yet midnight.
[cpg]


If ogres live in this house, I would think they would be awake, but there was no answer.
[cpg]


I went from house to house. It was just like old Japan, where they were very strict about strangers.
[cpg]


Sometimes the door was opened just a little and then closed.
[cpg]


I was almost discouraged, but I still went around the houses and found ......
[cpg]

[SE f=se009]
;//【ＳＥ】『歩く』

[window target=true]
[WAIT time=100]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_08_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『鬼の集落』（夜）******************************************************


;//暫く、サツキの名前欄を「鬼の娘」と隠してください


[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Satuki001"]
[OnName num="demon_girl"]
"Who are you...? You look human. How did you get in here?"
[cpg cn=true]


Oh, oh ...... right, that's why no one would let me in.
[cpg]


If they were human, they shouldn't have been allowed in the village in the first place.
[cpg]


[OnName num="renzi"]
“I'm a demon. I can just turn into a human... Shall I demonstrate?"
[cpg cn=true]



[SE f="se001"]
;//【ＳＥ】『変身音』

;//変身
[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1100]

[WAIT time=1000]
[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
[WAIT time=1000]


[FACE method="change_5" pos="2/3"]

I showed myself as a goblin, and the ogre was amazed.
[cpg]



[VOICE f="Satuki002"]
[OnName num="demon_girl"]
I was surprised to see such a demon. I've never seen anything like it.
[cpg cn=true]


[OnName num="renzi"]
I don't really know if there are demons like this either.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Satuki003"]
[OnName num="demon_girl"]
What do you mean?"
[cpg cn=true]


[OnName num="renzi"]
I'm new to this world. I know you won't believe me."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki004"]
[OnName num="demon_girl"]
I wonder if you could tell me more about .......
[cpg cn=true]


It's kind of like they're interested in you. Good, I was afraid I wouldn't be allowed in any of the houses.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************



[SE f=se021]
;//【ＳＥ】『扉開く』



;//ここからサツキの名前欄を隠さないでください




[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Satuki005"]
[OnName num="satsuki"]
I'm sorry it took me so long to introduce myself. My name is Satsuki.
[cpg cn=true]


[OnName num="renzi"]
I'm sorry. My name is Renji."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Satuki006"]
[OnName num="satsuki"]
I can't offer you any hospitality, but I can at least let you stay the night. Are you hungry?"
[cpg cn=true]


[OnName num="renzi"]
I am, but I don't know if ...... is a good idea.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Satuki007"]
[OnName num="satsuki"]
I guess so. I don't think a normal demon would go this far.
[cpg cn=true]



[window target=true]
[WAIT time=100]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************



With that, Satsuki left the room once.
[cpg]


Then she brought me a meal. I was almost in tears because I thought that perhaps I would be staying in the field today.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Satuki008"]
[OnName num="satsuki"]
She said, "Thanks for your long journey. Here you go."
[cpg cn=true]


[OnName num="renzi"]
Thank you very much. Bon appétit."
[cpg cn=true]



[SE f=se011]
;//【ＳＥ】『食器の音』



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[FO pos="2/3" time=1]
[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="04"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************





[FG f="CHA05_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Satuki009"]
[OnName num="satsuki"]
“If you're stopping in this village, you must be heading for the human city...”
[cpg cn=true]


[OnName num="renzi"]
Yeah. I had some business to attend to.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki010"]
[OnName num="satsuki"]
Is he going to use his power to trick the humans?
[cpg cn=true]


[OnName num="renzi"]
No, I really just need to do a little shopping.
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Satuki011"]
[OnName num="satsuki"]
I'm at ....... Is that right?　If I had your power, I wouldn't try to use it just for shopping.
[cpg cn=true]


That's for sure. I could end the conflict at will, that's for sure.
[cpg]


But it's also a bit of a burden, to gather information...
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Satuki012"]
[OnName num="satsuki"]
The war between humans and demons has been going on for a long time. You don't know about it, do you?"
[cpg cn=true]


[OnName num="renzi"]
Yes," he said. I'm from a different world than this one.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Satuki013"]
[OnName num="satsuki"]
I don't know how much I believe you, but if it's true, it's a disaster.
[cpg cn=true]


Indeed. But I feel more alive than when I was in the modern world.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki014"]
[OnName num="satsuki"]
If I can change my appearance at will, I can do ...... anything I want.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Satuki015"]
[OnName num="satsuki"]
With your power, perhaps a peaceful, undivided world will come.
[cpg cn=true]


[OnName num="renzi"]
“Do you really think so...?"
[cpg cn=true]


Why are we talking about this? I don't know if it's okay to ask.
[cpg]


[OnName num="renzi"]
You insist on talking about conflict and peace. What's going on?"
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Satuki016"]
[OnName num="satsuki"]
...... it is."
[cpg cn=true]


Clouded expression. I don't have to force myself to ask.
[cpg]


[OnName num="renzi"]
'I'm sorry. I didn't mean to pry.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki017"]
[OnName num="satsuki"]
It's okay. I said some thought-provoking things too.'
[cpg cn=true]


There was silence for a while. Then Satsuki spoke.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="Satuki018"]
[OnName num="satsuki"]
I'm a human being. I'm in love.
[cpg cn=true]


With that one word, I had a pretty good idea what to expect. Humans are not supposed to be allowed in this village.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki019"]
[OnName num="satsuki"]
In this world of constant conflict, it is difficult for people to be united. I would say it is impossible.
[cpg cn=true]


The Ogre Tribe is also forbidden to head for human villages, and we may never see each other again, it seems.
[cpg]


[OnName num="renzi"]
“It's a tough world..."
[cpg cn=true]


I was dazed, but I knew that a situation of conflict between demons and humans was not good.
[cpg]


Not only Satsuki, there would be all kinds of problems all over the world.
[cpg]


I wonder if we have to make peace or one of the races will completely dominate the world ......
[cpg]


As I was thinking this, Satsuki pushed me further.
[cpg]


[FACE method="change_3" pos="2/3"]
[VOICE f="Satuki020"]
[OnName num="satsuki"]
What do you think?　What do you want to use your power for?"
[cpg cn=true]


[OnName num="renzi"]
It's ......"
[cpg cn=true]


;//
;//;//■選択肢
;//
;//[switch]
;//[case "人間族との和平の為に使う"]
;//	[swap]
;//	[jump target="*IseSel03_1"]
;//[case "魔族の繁栄の為に使う"]
;//	[swap]
;//	[jump target="*IseSel03_2"]
;//[endswitch]
;//
;//１、人間族との和平の為に使う
;//２、魔族の繁栄の為に使う
;//


;//==============================
;//１、人間族との和平の為に使う
;//*IseSel03_1|何を変えるためにその身を使うのか
;//
;//
;//
;//
;//[OnName num="renzi"]
;//「やはり、和平のために使いたいです」
;//[cpg cn=true]
;//
;//
;//俺の為でもあるし、ダンジョンに居る皆の為でもあるし、あるいはサツキの為でもある。
;//[cpg]
;//
;//
;//[OnName num="renzi"]
;//「今まで、ちゃんと考えてませんでした。気づかせてくれてありがとうございます」
;//[cpg cn=true]
;//
;//
;//[FACE method="change_1" pos="2/3"]
;//[VOICE f="Satuki021"]
;//[OnName num="satsuki"]
;//「私はなにもしてないわ。平和が来たらいいな、っていう話をしただけ」
;//[cpg cn=true]
;//
;//
;//そう言って笑う彼女はやけに綺麗だった。
;//[cpg]
;//
;//
;//ドロシーやアーシャとはまた違う美貌だ。ジャニスに少し近いかもしれない。
;//[cpg]
;//
;//[jump target="*IseSel03_3"]
;//
;//==============================
;//２、魔族の繁栄の為に使う
*IseSel03_2|What do you want to use it for?




[OnName num="renzi"]
I owe a debt of gratitude to everyone in the demon tribe. I would like to repay them."
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Satuki022"]
[OnName num="satsuki"]
Yes," he said. It may be you who ends this battle."
[cpg cn=true]


I wanted to use my power only for the sake of the demon tribe.
[cpg]


I had not forgotten my debt to Dorothy, Janice, and Asha.
[cpg]


I wanted to protect the dungeon and the demon tribe that lived there. These were words that came from my true heart.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Satuki023"]
[OnName num="satsuki"]
I am sure you are a kind person. I can understand why.
[cpg cn=true]


Satsuki laughed. It was a thrilling smile.
[cpg]



;//※変数+1
[stflag Gameflg = 1]



;//==============================

*IseSel03_3|What would she use her body to change?



;//ブラックアウト


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[FO pos="2/3" time=1]

[BG f="black.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_4.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************



I was asked to stay in the parlor, if you can call it that.
[cpg]


It was late at night. She must have been sleeping.
[cpg]


Somehow, there is no sign of anyone but her in this house...
[cpg]


I wonder if he lives alone for some reason.
[cpg]


;//＠シナリオカット用テキスト
;//それにしても、美人だった。俺は彼女のことが気になっていた。
I fell asleep with that in mind. ......
[cpg]


;//[SE f=se012]
;//;//【ＳＥ】『衣擦れ』
;//
;//[OnName num="renzi"]
;//「ん……？」
;//[cpg cn=true]
;//
;//
;//俺が寝ていると、一匹の猫がこちらに向かってやってきていた。
;//[cpg]
;//
;//
;//すり寄ってくるので、俺は寝たまま頭を撫でてみる。
;//[cpg]
;//
;//
;//しかし、こんな民家に猫が上がってくるなんて。
;//[cpg]
;//
;//
;//[OnName num="renzi"]
;//「ちょっと、気になるな」
;//[cpg cn=true]
;//
;//
;//俺は起き上がって、玄関の方を観に行く。
;//[cpg]
;//
;//
;//すると、扉が開いていた。猫を逃がしてから、閉める。
;//[cpg]
;//
;//
;//
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[BG f="black.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[STOPBGM]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_06_4.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//
;//[window target=true]
;//[BGM f="04"]
;//;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************
;//
;//
;//
;//
;//
;//[OnName num="renzi"]
;//「……そうだな……」
;//[cpg cn=true]
;//
;//
;//猫、猫か。俺は少し思いついたことがあった。
;//[cpg]
;//
;//
;//明日になれば彼女ともお別れだ。そう思うと、何もしないではいられなかった。
;//[cpg]
;//
;//
;//
;//[SE f="se001"]
;//;//【ＳＥ】『変身音』
;//
;//;//変身
;//[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
;//[WAIT time=1100]
;//
;//
;//[WAIT time=1000]
;//[BG f="white.ui" time=1]
;//[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
;//[WAIT time=1000]
;//
;//
;//;//ブラックアウト
;//
;//
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[BG f="black.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_06_4.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//
;//[window target=true]
;//;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************
;//
;//
;//
;//[FG f="CHA05_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
;//[VOICE f="Satuki024"]
;//[OnName num="satsuki"]
;//「シェイプシフター、ね。彼はどこまでやってくれるかしら」
;//[cpg cn=true]
;//
;//;**【ＣＧ】ci_14_0 ***********************
;//;//カットイン
;//[CUTIN f="ci_14_0.ui" show={true} method="slidein"]
;//;*****************************************
;//[WAIT time=1000]
;//
;//
;//彼女の部屋に、猫の姿で忍び込む。
;//[cpg]
;//
;//[CUTIN f="ci_14_0.ui" show={false} method="slideout"]
;//[WAIT time=1000]
;//
;//
;//花のような、石けんのような匂い。サツキの匂いなのだろうと思いながら近づく。
;//[cpg]
;//
;//
;//
;//[FACE method="change_5" pos="2/3"]
;//[VOICE f="Satuki025"]
;//[OnName num="satsuki"]
;//「あれ……？　こんな所に、どうして」
;//[cpg cn=true]
;//
;//
;//俺は猫の姿をして彼女になついたふりをする。
;//[cpg]
;//
;//
;//[FACE method="change_1" pos="2/3"]
;//[VOICE f="Satuki026"]
;//[OnName num="satsuki"]
;//「駄目よ、勝手に家に上がり込んできたら」
;//[cpg cn=true]
;//
;//
;//優しく微笑みながら、そう言ってくる。しかし……
;//[cpg]
;//
;//
;//[FACE method="change_5" pos="2/3"]
;//[VOICE f="Satuki027"]
;//[OnName num="satsuki"]
;//「きゃっ！　な、なに！？」
;//[cpg cn=true]
;//
;//
;//俺は彼女の体に飛びかかった。彼女はびっくりして、倒れ込む。
;//[cpg]
;//
;//
;//
;//;//========================================
;//;//●ＣＧ（猫に変身した主人公。倒れ込んでいるヒロインに近づく）ev_05
;//;//人物１：ヒロイン５　服装１：着衣
;//;//人物ex：主人公　　　服装ex：無し
;//;//場所　：和風の室内
;//;//時間　：夜
;//;//備考　：主人公は猫に変身しています
;//;//========================================
;//
;//;//*Scene010
;//[STOPBGM]
;//[FO pos="2/3" time=1000]
;//[BG f="black.ui"  time=1000]
;//[WAIT time=1000]
;//[BGM f="10"]
;//;**【ＣＧ】 ev_05_0 ***********************
;//[CG id=4 index=0 time=1000]
;//;***************************************
;//[WAIT time=1500]
;//
;//
;//
;//[VOICE f="Satuki028"]
;//[OnName num="satsuki"]
;//「どうしたの……こんな、急にっ」
;//[cpg cn=true]
;//
;//
;//サツキは驚いた様子で、俺の方を見ている。
;//[cpg]
;//
;//
;//俺を無理矢理引き剥がそうとはしない。彼女は俺を猫だと思い込んでいる。
;//[cpg]
;//
;//
;//あまりあらっぽくは扱えないということなんだろう。
;//[cpg]
;//
;//;**【ＣＧ】 ev_05_a ***********************
;//[CG id=4 index=1 time=1000]
;//;***************************************
;//[WAIT time=1500]
;//
;//[VOICE f="sSatuki001"]
;//[OnName num="satsuki"]
;//「もう……構って欲しいの？」
;//[cpg cn=true]
;//
;//彼女の手で撫でられると、甘えたくなるような気持ちになる。
;//[cpg]
;//
;//
;//まさか心まで猫になったということはないだろうけど……
;//[cpg]
;//
;//
;//目に映る景色、というか目の前のサツキは紛れもなく猫を可愛がるサツキだった。
;//[cpg]
;//
;//;**【ＣＧ】 ev_05_0 ***********************
;//[CG id=4 index=0 time=1000]
;//;***************************************
;//[WAIT time=1500]
;//
;//[VOICE f="sSatuki002"]
;//[OnName num="satsuki"]
;//「よしよし。もう私は寝るから、構ってあげられないのよ」
;//[cpg cn=true]
;//
;//
;//しかし……この姿ではいくら甘えても、意味が無いような感じもする。
;//[cpg]
;//
;//
;//例えば、彼女の思い人にしか見せないような表情は、どうやっても見られない。
;//[cpg]
;//
;//
;//なんだかそういう点では、むなしさもあった。
;//[cpg]
;//
;//
;//;//移植前シーンカット
;//
;//
;//
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[BG f="black.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[STOPBGM]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_06_4.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//
;//[window target=true]
;//[BGM f="07"]
;//;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************
;//
;//
;//
;//
;//[FG f="CHA05_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
;//[VOICE f="Satuki055"]
;//[OnName num="satsuki"]
;//「おやすみなさい。猫ちゃん」
;//[cpg cn=true]
;//
;//[FO pos="2/3" time=1000]
;//[SE f=se012]
;//;//【ＳＥ】『衣擦れ』
;//
;//一通り欲望が満たされて、サツキはもう眠るようだった。
;//[cpg]
;//
;//
;//俺は彼女の部屋から出て、さっきまで居た部屋に戻る。
;//[cpg]
;//
;//
;//
;//;//ここからしばらく、サツキのセリフ名前欄を「サツキ（蓮司）」と置き換えてください
;//
;//
;//
;//
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[BG f="black.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[STOPBGM]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_06_4.ui" time=10]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//
;//[window target=true]
;//[BGM f="07"]
;//;//【ＢＧ】『ヒロイン５の家＿室内』（夜）******************************************************
;//
;//
;//
;//
;//しかし、眠ることができない。目がさえた、というより……
;//[cpg]
;//
;//
;//サツキに変身できるかもしれないと思ってしまうと、余計に自分が抑えられない。
;//[cpg]
;//
;//
;//彼女がすぐ側に居たから匂いも嗅いでいたはずだけど、どうかな。
;//[cpg]
;//
;//
;//
;//;////////////////////////
;//;////////////////////////
;//;//三度目の変身システム//
;//;////////////////////////
;//;////////////////////////
;//
;//
;//;//選択肢用フラグ
;//[stflag IseSel04flg = 0]
;//
;//一つ目の匂いは確か……
;//[cpg]
;//
;//
;//[switch]
;//[case "バニラ"]
;//	[swap]
;//	[jump target="*hen41"]
;//[case "果物"]
;//	[swap]
;//	[jump target="*hen41"]
;//[case "花"]
;//	[swap]
;//	[stflag IseSel04flg = 1]
;//	[jump target="*hen41"]
;//[endswitch]
;//
;//
;//*hen41|何を変えるためにその身を使うのか
;//
;//
;//二つ目の匂いは……
;//[cpg]
;//
;//
;//
;//[switch]
;//[case "ミント"]
;//	[swap]
;//	[jump target="*hen42"]
;//[case "香水"]
;//	[swap]
;//	[jump target="*hen42"]
;//[case "石けん"]
;//	[swap]
;//	[stflag IseSel04flg = 1]
;//	[jump target="*hen42"]
;//[endswitch]
;//
;//*hen42|何を変えるためにその身を使うのか
;//
;//
;//[window target=true]
;//
;//[WAIT time=100]
;//[window target=false]
;//[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//
;//[FACE method="out" pos="4/7"]
;//
;//[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1]
;//[WAIT time=1000]
;//[BG f="b_06_4.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[BGM f="04"]
;//
;//
;//[window target=true]
;//
;//
;//[if exp={getFlagValue("IseSel04flg") == 2 }]
;//[jump target="*IseSel04_2"]
;//[endif]
;//
;//
;//[jump target="*IseSel04_1"]
;//
;//;//■選択肢Ａ
;//１、バニラ
;//２、果物
;//３、花
;//
;//;//■選択肢Ｂ
;//４、ミント
;//５、香水
;//６、石けん
;//
;//
;//
;//
;//
;//;//==============================
;//;//３、花　６、石けん　を選んでいた場合
;//*IseSel04_2|何を変えるためにその身を使うのか
;//
;//
;//
;//[SE f="se001"]
;//;//【ＳＥ】『変身音』
;//
;//;//変身
;//[transition target={true} rule="uzumaki1.webp" color={0xffffffff} time=1000]
;//[WAIT time=1100]
;//
;//[WAIT time=1000]
;//[FG f="CHA05_p4_01_a.ui" method="change_1"  pos="2/3" time=1]
;//[transition target={false} rule="uzumaki1.webp" color={0xffffffff} time=1000]
;//[WAIT time=1000]
;//
;//
;//;//【ＢＧ】『ヒロイン５の家＿室内』（夜）
;//
;//
;//そう思っていたけど、杞憂だったようだ。俺はサツキにも変身できた。
;//[cpg]
;//
;//この姿になってみると、やはり自分のことを見たくなる。
;//[cpg]
;//
;//
;//だけどこの部屋に鏡はない。仕方ないので、自分から見える部分を観察するのに留めておいた。
;//[cpg]
;//
;//;//移植前シーンカット
;//
;//
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[FO pos="2/3" time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//
;//;//ヒロイン５ルートの可能性が残る
;//
;//[jump target="*IseSel04_3"]
;//
;//
;//
;//;//==============================
;//;//３、花　６、石けん　のいずれかを外した場合
;//*IseSel04_1|何を変えるためにその身を使うのか
;//
;//
;//
;//やはり、はっきりとは思い出せない。変身するにもしようがない。
;//[cpg]
;//
;//
;//仕方ないので、もやもやを抱えたまま眠りについた。
;//[cpg]
;//
;//
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//
;//;//ヒロイン５ルートの可能性がなくなる
;//
;//[stflag Cha5flg = -1]
;//
;//;//==============================

*IseSel04_3|What will you use that body to change?





[STOPBGM]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=10]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]

[window target=true]
[BGM f="05"]
;//【ＢＧ】『ヒロイン５の家＿室内』（朝）******************************************************



The next morning. I get up from the futon.
[cpg]


[FG f="CHA05_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Satuki083"]
[OnName num="satsuki"]
Good morning. I hope you slept well.
[cpg cn=true]


[OnName num="renzi"]
Yes. Thank you.
[cpg cn=true]


Satsuki had even prepared breakfast for me. Why is she doing this for me?
[cpg]


I wonder why she expects so much from me in terms of peace between demons and humans.
[cpg]


After finishing my meal, I looked around the room and said, "I'm sorry.
[cpg]


[OnName num="renzi"]
You are the only one in this house, aren't you?
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Satuki084"]
[OnName num="satsuki"]
“Yes. My father and mother both died when I was young.”
[cpg cn=true]


[OnName num="renzi"]
"I see..."
[cpg cn=true]


I wondered if it might have a little something to do with being in love with a human being.
[cpg]


I wonder how long I've been living alone, I wonder how long I've been living alone. I feel like there is something there.
[cpg]


[window target=false]

[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1500]

[STOPBGM]

[stopse g=1]
;//ボイス

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[stopse g=5]
;//システム

[stopse g=6]
;//ループse

[window target=true]


[jump storage="ep010.ks" target="*start"]

