
*start

;//==============================
;//ヒロイン３の変数が最も多い場合

;#################################################
*Ep010|Going for the smart akari.
;#################################################

[stflag Cha3flg = 0]


[if exp={getFlagValue("Cha3flg") == 0 }]
[if exp={ isSystemFlagsEnabled( "sysflg2") }]
[stflag Cha2flg = 1]
[endif]
[endif]


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[window target=true]

[BGM f="bg_sa"]
[WAIT time=100]

*root3|Going for the smart akari.

[SCENE id=10]


[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

......The idea was to target Akari.
[cpg]


When I thought about who I wanted to know the most, she came to mind.
[cpg]


I don't know what she thinks the most. Who is she, who is smart enough to skip a grade?
[cpg]


I might be able to ask her about that in depth through hypnosis.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』

[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akari104"]
[OnName num="akari"]
"Ah, Kyoichi. Good morning.
[cpg cn=true]


[OnName num="kyoichi"]
Good morning. Do you have a minute?
[cpg cn=true]


Akari herself is younger than me, but she is in a class above me.
[cpg]


I was trying to call out to Akari, even though I felt a little uncomfortable.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Akari105"]
[OnName num="akari"]
Yeah, I'm fine. What can I do for you?"
[cpg cn=true]


[OnName num="kyoichi"]
"Just a little. I want to show you something.
[cpg cn=true]


I was neither wrong nor lying. I decided to take Akari to an empty classroom.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hy"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

Hypnosis can erase memories.
[cpg]


As long as I knew that, I could do anything I wanted. Now what shall we do ......?
[cpg]


The app now shows these two things. You can choose either one, but I'm sure you will.
[cpg]


You can choose any of them, but let's see. ......
[cpg]


;//■選択肢８
[switch]
[case "Pretend the other person is your lover"]
	[swap]
	[jump target="*select08_1"]
[case "Pretend you are a dog"]
	[swap]
	[jump target="*select08_3"]
[endswitch]


1, Pretend that the other person is your lover
3, Pretend you are a dog



;//この選択肢で増加するのはヒロイン３の変数
;//１を選んだ場合変数は変わらない
;//３を選んだ場合変数が１増える



;//==============================
;//１、相手を恋人だと思い込む
*select08_1|Go for the smartest Akari

[system sysflg8=false]


Well, this is reasonable. With that in mind, I choose one and show her the screen.
[cpg]


[FACE method="shock_8" pos="2/3"]
[VOICE f="Akari106"]
[OnName num="akari"]
"Hmmm. Ugh, fuuuh ...... Kyoichi?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Akari107"]
[OnName num="akari"]
Kyoichi,......, what are you doing, taking me out to a place like this?"
[cpg cn=true]


Is he already hypnotized? Well, whatever.
[cpg]


[OnName num="kyoichi"]
Hey, Akari. Turn your back, please."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="sAkari008"]
[OnName num="akari"]
"What ......?　Why?
[cpg cn=true]


[OnName num="kyoichi"]
It's okay.
[cpg cn=true]




;//ブラックアウト
;//========================================
;//●ＣＧ（背中を向けているヒロイン）ev_39
;//人物１：ヒロイン３
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：学園教室
;//時間　：昼
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_39_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=1000]


Akari obediently follows my words.
[cpg]

 I guess she still thinks of me as her lover.
[cpg]

[VOICE f="sAkari009"]
[OnName num="akari"]
I turned my back, but ...... is this okay?
[cpg cn=true]


[OnName num="kyoichi"]
Yes.
[cpg cn=true]


I hugged her from behind.
[cpg]


;**【ＣＧ】 ev_39_a ***********************
[CG id=16 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sAkari010"]
[OnName num="akari"]
"...... from behind, it's a little perverted.
[cpg cn=true]


But she doesn't really mind saying that.
[cpg]

Akari now thinks of me as her lover.
[cpg]

[OnName num="kyoichi"]
'That's right,.......
[cpg cn=true]


If that's the case, it would be interesting to break the hypnosis right here and now.
[cpg]

The sudden change in perception is one of the most interesting aspects of hypnosis.
[cpg]


;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_8"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


After I had enjoyed myself to some extent, I released the hypnosis.
[cpg]

I did so while she was still holding me. Then ......
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="sAkari011"]
[OnName num="akari"]
Eh......?"
[cpg cn=true]


She was surprised at the sudden change of situation and pushed me away.
[cpg]


[jump target="*select08_4"]

;//==============================
;//３、自分を犬だと思い込む
*select08_3|Going for the smart akari.

[stflag Cha3flg = 1]

[system sysflg8=true]

Okay, let me give you a slightly different experience.
[cpg]


[FACE method="shake_8" pos="2/3"]
[VOICE f="Akari152"]
[OnName num="akari"]
'Nnnn......Ugh, hmmm, wan.......'
[cpg cn=true]


The next thing I knew, Akari couldn't stand and went down on all fours.
[cpg]



;//ブラックアウト
;//========================================
;//●ＣＧ（四つん這いのヒロイン）ev_41
;//人物１：ヒロイン３
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：昼
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_41_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

She looked awfully pretty now. She seemed pleased when I stroked her hair.
[cpg]

I just kept on loving her for a while. Akari's consciousness did not immediately return.
[cpg]

There is a gap between her and her usual self. That filled my heart.
[cpg]

[OnName num="kyoichi"]
Good, good, good girl.
[cpg cn=true]


I wanted to keep staring at her like this. Or I want to pet her, but I don't want to ......
[cpg]

I can't leave it like this forever. It would be a big problem if someone saw me.
[cpg]

I thought so, and released the hypnosis.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_8"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=10]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


[FACE method="bow_4" pos="2/3"]
[VOICE f="sAkari012"]
[OnName num="akari"]
"......, I ...... what ......"
[cpg cn=true]


After regaining consciousness. I went up to her again and stroked her hair.
[cpg]


[FACE method="shock_5" pos="2/3"]
Then Akari was startled and pushed me away.
[cpg]

;//==============================

*select08_4|Go for the smartest Akari

[SE f="se012"]
;//【ＳＥ】『衣擦れ』

[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="sAkari013"]
[OnName num="akari"]
What's wrong ...... with you, suddenly, you're so familiar."
[cpg cn=true]


[OnName num="kyoichi"]
Do you have a little bit of memory left?"
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]
I asked her and she blushed. It seems that some of it is still there.
[cpg]

[FACE method="change_4" pos="2/3"]
[OnName num="kyoichi"]
I was manipulating you with hypnosis.
[cpg cn=true]


I'm sure those words are very persuasive now.
[cpg]


[OnName num="kyoichi"]
I'm not going to erase your memory. Instead, I'm going to ......."
[cpg cn=true]


[OnName num="kyoichi"]
If you show any strange behavior, I will hypnotize you in public.
[cpg cn=true]


[FACE method="change_4" pos="2/3"]
[VOICE f="Akari177"]
[OnName num="akari"]
What do you mean ......?　What does that matter to me?
[cpg cn=true]


[OnName num="kyoichi"]
I mean hypnotize you to, for example, get naked in public or something.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Akari178"]
[OnName num="akari"]
I don't ...... mean that. ......
[cpg cn=true]


You once made a similar threat to Yuna.
[cpg]


Akari trembles with fear. But somewhere ......
[cpg]


Somewhere, I felt like my eyes were moistening, you know?
[cpg]


 Do you really hate this guy?
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



After that, I hypnotized her in various ways at the right time.
[cpg]


;//やらしいこと、そうでないこと、色々とやってみた……
I tried all kinds of embarrassing and not-so-embarrassing things: ......
[cpg]


Today, for example, he hypnotized her to misidentify me as her lover.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="sAkari014"]
[OnName num="akari"]
And don't ever do this ...... kind of thing again."
[cpg cn=true]


She moistened her eyes, somewhat pleased rather than disgusted.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

It's hard for me to make a decision when you show me something like that.
[cpg]

The next day off, while thinking suspiciously.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_02_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[OnName num="kyoichi"]
"Hey, Akari. You're sure you'll come to the rendezvous, Akari.
[cpg cn=true]



[FACE method="shake_4" pos="2/3"]
[VOICE f="Akari180"]
[OnName num="akari"]
...... Kyoichi will threaten me."
[cpg cn=true]


It kind of looks like a tsundere too, doesn't it?
[cpg]


I didn't want to come to the rendezvous!　Or something like that.
[cpg]


[OnName num="kyoichi"]
Then, I'll ask him to take me to your house as promised.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Akari181"]
[OnName num="akari"]
Yeah. I've been threatened, so I had no choice.
[cpg cn=true]


I'm not going to worry too much about the "tsundere" anymore.
[cpg]



;//ブラックアウト

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_hy"]
;//[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************


[OnName num="kyoichi"]
"...... something, a lot of expensive-looking machines ......."
[cpg cn=true]


[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akari182"]
[OnName num="akari"]
I wonder if it's rare to find a girl with a computer nowadays. Audio and other things are my hobbies."
[cpg cn=true]


Akari is rather proactive in explaining herself.
[cpg]


 After all, it seems that he is willing to ride.
[cpg]


[OnName num="kyoichi"]
Now ...... what are we going to do today?"
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Akari183"]
[OnName num="akari"]
If you're going to do it, do it fast. I'm not doing it because I want to."
[cpg cn=true]


It seems like the opposite of goodwill. Well, okay, ......
[cpg]


And I choose which hypnosis I'm going to do.
[cpg]



;//■選択肢９
[switch]
[case "It makes me feel physically immobile."]
	[swap]
	[jump target="*select09_1"]
[case "feel unbearably hot."]
	[swap]
	[jump target="*select09_2"]
[endswitch]


One, I'll be physically immobile.
2, feel unbearable heat



;//この選択肢で増加するのはヒロイン３の変数
;//１を選んだ場合変数は変わらない
;//２を選んだ場合変数が１増える
;//３を選んだ場合変数が２増える



;//==============================
;//１、体を動かせなくなる
*select09_1|Go for the smartest Akari

[system sysflg9=false]


I know it's goofy, but this is the easiest way to see the effect.
[cpg]


[FACE method="shock_8" pos="2/3"]
[VOICE f="sAkari015"]
[OnName num="akari"]
"Ugh ......!"
[cpg cn=true]


[free time=1000]

She gets stuck and collapses in place.
[cpg]

[OnName num="kyoichi"]
"Well, what are we going to do today?"
[cpg cn=true]


She didn't seem to really dislike it when I approached her, saying
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I decided to tickle her today.
[cpg]

;//[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sAkari016"]
[OnName num="akari"]
"Oh no, don't do that, hahaha, hahaha."
[cpg cn=true]


But no matter what I did, she wouldn't move. And on top of that, ......
[cpg]

I don't seriously dislike it, ever.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************

[FG f="CHA03_p1_02_a.ui" method="change_6"  pos="2/3" time=800]

After a few moments, I decide to break the hypnosis.
[cpg]

She even seemed somewhat entranced ......
[cpg]

[jump target="*select09_4"]

;//==============================
;//２、耐えきれないほどの暑さを感じる
*select09_2|Going for the smart akari.

[stflag Cha3flg = 1]

[system sysflg9=true]


[FACE method="shock_8" pos="2/3"]
I decided to try a slightly different kind of hypnosis.
[cpg]


What kind of effect would this have?
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Akari205"]
[OnName num="akari"]
"Huh, huh,...... it's kind of hot,......?　Is it my imagination?"
[cpg cn=true]


Summer has completely passed and we are in the middle of autumn. Akari began to sweat.
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Akari206"]
[OnName num="akari"]
"Oh, it's so hot......!　My body is acting weird.
[cpg cn=true]


There was something visibly wrong. And Akari was about to take off her clothes. However.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akari207"]
[OnName num="akari"]
'Ha, ha, it's too hot......!　Kyoichi, what did you do ......?"
[cpg cn=true]


You can't be in your underwear because of my eyes.
[cpg]

I watched Akari with this conflict for a while, amused.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（昼）******************************************************


[FG f="CHA03_p1_02_a.ui" method="change_4"  pos="2/3" time=800]


I decided to stop at this point because I was afraid I might catch a cold if I let him sweat too much.
[cpg]


Sweaty Akari looked sexier than usual.
[cpg]

I felt like I wanted to leave her behind, but I had to stop.
[cpg]


[jump target="*select09_4"]

;//==============================

*select09_4

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se010"]
;//【ＳＥ】『歩く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



Then I parted from Akari and thought about the application.
[cpg]


The application itself is paranormal. But I can't just dismiss it as paranormal.
[cpg]


It's not like I was in a fantasy world.
[cpg]


Then I suddenly remembered.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[OnName num="kyoichi"]
Oh, hey!　Why is the lock unlocked?
[cpg cn=true]

;//@

;//あかり「こんなのは、私の手にかかれば朝飯前だから」
[FACE method="change_1" pos="2/3"]
[VOICE f="Akari005"]
[OnName num="akari"]
I've got it under control.
[cpg cn=true]


[OnName num="kyoichi"]
Just give it back!
[cpg cn=true]

;//あかり「ちょっ、やめて！　まだ途中なんだからっ」
[FACE method="shock_3" pos="2/3"]
[VOICE f="Akari006"]
[OnName num="akari"]
Hey, stop it!　I'm still working on it!
[cpg cn=true]


[OnName num="kyoichi"]
What the fuck is going on?　You're gonna take all my data off my phone?
[cpg cn=true]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



...... that time?
[cpg]


I remember the time when my phone was stolen from me.
[cpg]


I think they put an app on my phone at that time. I don't know.
[cpg]


If you are a genius like Akari, can you create an app so outrageous that it hypnotizes ...... you?
[cpg]


No, wait, wait, that still doesn't make sense. Then there is no way she would have included herself in the list.
[cpg]


If there is a reason to put yourself on the list, it's because you wanted me to choose .......
[cpg]


That makes sense. It all makes sense.
[cpg]


Akari didn't really dislike what she had done so far.
[cpg]


I was torn between confirming Akari's true intentions and dominating her without caring.
[cpg]


And the answer I came up with was ......
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//今までの全ての選択肢でハードなものを選んでいる（変数が３になっている）かどうかで分岐

[if exp={getFlagValue("Cha3flg") == 3 }]
[jump target="*root3_6"]
[endif]


[jump storage="ep011.ks" target="*root3_5"]


*root3_6
[jump storage="ep012.ks" target="*root3_6"]
