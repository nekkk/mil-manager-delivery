
*start

;#################################################
*Ep003|The Further Power of Hypnosis
;#################################################

[stflag Cha2flg = 0]
[stflag Cha3flg = 0]


[if exp={getFlagValue("Cha2flg") == 0 }]
[if exp={ isSystemFlagsEnabled( "sysflg1") }]
[stflag Cha2flg = 1]
[endif]
[endif]

[if exp={getFlagValue("Cha3flg") == 0 }]
[if exp={ isSystemFlagsEnabled( "sysflg2") }]
[stflag Cha3flg = 1]
[endif]
[endif]


[SCENE id=3]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



With this in mind, I was on holiday.
[cpg]


I had nothing special to do, so I was trying to see if I could hypnotize anyone other than the three of us.
[cpg]


That's because the item now at Kashiwagi-san's place ......
[cpg]


It's called "Flirting in front of others is a normal thing, and people around you can't even notice it".
[cpg]


The effect is no longer just on Kashiwagi-san.
[cpg]


If the people around him can't notice it, does it work on all the people to whom he shows this screen?
[cpg]


No, it is possible to break the hypnosis without showing the screen.
[cpg]


The screen is only to promote the effect, but something else may be happening.
[cpg]


Sound waves or radio waves or ......?　I can't imagine it, but that's probably what's happening.
[cpg]


Come to think of it, sounds like mosquito noises have been around for a while.
[cpg]


Maybe they are causing something in the frequency range that humans can't hear.
[cpg]


That's the kind of thing that can rouse people or put them into a ...... hypnotic state.
[cpg]


I mean, you should show them the screen just in case, but it's not required.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akari073"]
[OnName num="akari"]
Oh, Kyoichi. Good morning."
[cpg cn=true]


[OnName num="kyoichi"]
Oh, good morning. ......."
[cpg cn=true]


One of the items that could be put on Akari right now was "assume she's a dog.
[cpg]


I tried it without showing her the screen. Then ......
[cpg]


[FACE method="shock_8" pos="2/3"]
[VOICE f="Akari074"]
[OnName num="akari"]
'Nnnn...... ugh.'
[cpg cn=true]

[free time=1000]
[SE f="se012"]
;//【ＳＥ】『衣擦れ』
[WAIT time=1100]

She crouched down and came to my feet.
[cpg]


People around me were shocked. This is not good.
[cpg]


But I understood that there was no need to show the screen.
[cpg]

;//[free time=1000]

I once again released the hypnosis without showing the screen.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Akari076"]
[OnName num="akari"]
"Nmmm............oh, that?　What am I ......?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Akari077"]
[OnName num="akari"]
Kyoichi, what was I doing just now?"
[cpg cn=true]


This time, even though I didn't choose to erase my memory, I can't remember.
[cpg]


Is this normal? I was a dog just now, so my memory must not be continuous with the human state.
[cpg]


[OnName num="kyoichi"]
No, nothing ...... sudden wobble, but that's all."
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Akari078"]
[OnName num="akari"]
...... yeah."
[cpg cn=true]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



And time passes. Holidays pass.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************


[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
I decided to hypnotize Kashiwagi-san.
[cpg]


[OnName num="female_student"]
"Huh, the cultural festival, ...... preparation and so on seems to be hard work."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuna008"]
[OnName num="yuna"]
It may be hard work, but it will be a good memory. I'm sure.
[cpg cn=true]


I thought about it, but it was already the festival.
[cpg]


But I had a plan to hypnotize Kashiwagi-san.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Izumi066"]
[OnName num="izumi"]
"Senpai, don't you use that app anymore?"
[cpg cn=true]


[OnName num="kyoichi"]
"Leave it alone. ...... I'll use it when I want to use it."
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Izumi067"]
[OnName num="izumi"]
I want to do it again. If you have something that interesting like that, please use it!
[cpg cn=true]


Izumi is sticking around, but for now, her target is Kashiwagi-san.
[cpg]


In the end, I could not respond to Izumi's words.
[cpg]



[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hy"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



In another classroom after school. I called Kashiwagi-san.
[cpg]



[OnName num="kyoichi"]
"...... Kashiwagi-san."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuna009"]
[OnName num="yuna"]
Huh, what's wrong with you being so nervous?"
[cpg cn=true]


[OnName num="kyoichi"]
No, let me call you ...... Yuna."
[cpg cn=true]



;//ここから恭一は百菜のことを百菜と呼びます



I probably don't even use polite words to this person anymore.
[cpg]


;//表示された項目は二つ。「眠る」「体だけ動かなくなる」の二つ。
The two items displayed were "sleeping" and "body only stops moving.
[cpg]


;//やはり、項目順に酷い行為になっている。この場合の自分からというのは百菜からということだ。
After all, they are terrible acts in the order of the items.
[cpg]


;//眠る、とかそういう項目からしても、百菜がどうなるかが書かれている。
;//[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuna010"]
[OnName num="yuna"]
I don't care that. Call me whatever you want."
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Yuna011"]
[OnName num="yuna"]
'Better yet, ...... what do you want from me?'
[cpg cn=true]


I was ready and decided to press her. But first, I have to decide which one I'm going to choose.
[cpg]



;//■選択肢３
[switch]
[case "Sleep."]
	[swap]
	[jump target="*select03_1"]
[case "Only her body stops moving."]
	[swap]
	[jump target="*select03_2"]
[endswitch]


One, sleep.
2, only the body is immobilized.




;//この選択肢で増加するのはヒロイン１の変数
;//１を選んだ場合変数は変わらない
;//２を選んだ場合変数が１増える



;//==============================
;//１、眠る
*select03_1|Further power of hypnosis

[system sysflg3=false]


[OnName num="kyoichi"]
Look at me, Yuna.
[cpg cn=true]


[FACE method="change_8" pos="2/3"]
[VOICE f="Yuna012"]
[OnName num="yuna"]
"What is it, ......?　What is it, this screen ...... nnnn..."
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



;//[SE f="se004"]
;//【ＳＥ】『床に倒れる』

[SE f="se012"]
;//【ＳＥ】『衣擦れ』



Yuna collapsed on the spot. And then ......
[cpg]



;//========================================
;//●ＣＧ（椅子を並べておいて、眠っているヒロインを見つめる主人公）ev_10
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================

[FADEOUTBGM]
;//[free time=1000]
;//[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

I laid her on the chair and laid her down on it.
[cpg]

I can say that just being able to see her up close as she sleeps is accomplishing my goal, but ......
[cpg]

I wonder if she will notice anything I do now.
[cpg]

[OnName num="kyoichi"]
'...... a little bit, okay?'
[cpg cn=true]


I said to myself.
[cpg]

As I get closer to her, I can hear her breathing in her sleep.
[cpg]

[VOICE f="sYuna001"]
[OnName num="yuna"]
'Soooo, soooo ......
[cpg cn=true]


She is peaceful, and it's like she doesn't expect anything to be done to her from now on.
[cpg]

Or is it impossible for her to think about something since she is sleeping?
[cpg]

Thinking of this, I reached out my hand.
[cpg]


;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And that was the moment.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************




[VOICE f="Yuna029"]
[OnName num="yuna"]
"Hmmm, ......, oh, is that ......?"
[cpg cn=true]


Apparently, the effect of the hypnosis was broken in the middle. I pulled my hand back in a panic.
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuna030"]
[OnName num="yuna"]
What are you doing to me?　What were you doing to me, Kyoichi?
[cpg cn=true]


[OnName num="kyoichi"]
Wait, wait,......, listen to me for a minute.
[cpg cn=true]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Yuna031"]
[OnName num="yuna"]
There's nothing to talk about!　What did you do to me while I was asleep ......?
[cpg cn=true]


[OnName num="kyoichi"]
I was hypnotizing Yuna with a hypnotic technique,....... Even now, I can put her to sleep again."
[cpg cn=true]


Saying that, I try to operate "sleep" again.
[cpg]


[FACE method="shock_8" pos="2/3"]
[VOICE f="Yuna032"]
[OnName num="yuna"]
"Ugh,......, you, what are you doing?"
[cpg cn=true]


And then, I'll deactivate it. Now you are convinced.
[cpg]

[jump target="*select03_4"]

;//==============================
;//２、体だけ動かなくなる
*select03_2|The Further Power of Hypnosis

[stflag Cha1flg = 1]

[system sysflg3=true]


[OnName num="kyoichi"]
"Yuna. Look at this screen.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Yuna033"]
[OnName num="yuna"]
......What's wrong with it?"
[cpg cn=true]


At first she didn't seem to notice anything unusual, but gradually she began to understand.
[cpg]

[FACE method="change_5" pos="2/3"]
[VOICE f="sYuna002"]
[OnName num="yuna"]
Oh, that ...... body is not moving."
[cpg cn=true]



;//移植のためシーンをカットしています

I approached her as she was unable to move.
[cpg]

[OnName num="kyoichi"]
You know what I'm saying?　You can't resist me anymore.
[cpg cn=true]

;//==============================

*select03_4|The Further Power of Hypnosis

...... But it was obvious that I was going to get into trouble if I didn't do something about it.
[cpg]


So I decided to hypnotize Yuna with a hypnosis that would erase her memories of the time she was hypnotized.
[cpg]


Perhaps the parts that were inconvenient for me would disappear.
[cpg]


If it didn't, I would just threaten her again.
[cpg]


[OnName num="kyoichi"]
Look at me. Yuna.
[cpg cn=true]


[FACE method="shock_8" pos="2/3"]
[VOICE f="Yuna075"]
[OnName num="yuna"]
"Nnnn...... what, what, that...... ugh!"
[cpg cn=true]


I wobble with my head in my hands. But Yuna.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuna076"]
[OnName num="yuna"]
'I feel strange,...... but what's wrong with this,......?'
[cpg cn=true]


I didn't feel like my memory was disappearing.
[cpg]


This case is also conceivable enough. A pattern of hypnosis not working properly.
[cpg]


Especially, it is not so easy to tamper with memories, is it?
[cpg]


[OnName num="kyoichi"]
I thought to myself, "...... Well, that's okay. If you ever cross me or tell anyone about me, ......
[cpg cn=true]


[OnName num="kyoichi"]
I'll do whatever I can to get revenge."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Yuna077"]
[OnName num="yuna"]
"What do you mean ......?　Can you do such a thing, Kyoichi?
[cpg cn=true]


[OnName num="kyoichi"]
You can do it. "You can do it," he said, "like taking off your clothes in public. You already know how hypnosis works.
[cpg cn=true]

[FACE method="shock_4" pos="2/3"]
Yuna turned pale. Now you'll listen to me.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



...... is almost working, isn't it? I think it's working.
[cpg]


Izumi didn't resist in the first place. Akari seems to be able to erase memories.
[cpg]


And Yuna gave in to my threats. Everything is fine now.
[cpg]


I can probably use any one of them as a handcuff.
[cpg]


I returned home, feeling like I couldn't hold back my laughter.
[cpg]



;//文化祭です。背景に変化をつけられたらお願いします



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************

[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』

A few days passed, and it was the day of the festival.
[cpg]


My role was to be the receptionist for the haunted house. I made sure that everyone had left and let people in.
[cpg]


I've never had a part-time job before, but this simple task just made me yawn.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（昼）******************************************************



It's midday, and I have some free time.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Yuna078"]
[OnName num="yuna"]
Kyoichi-kun ......?　Excuse me.
[cpg cn=true]


[OnName num="kyoichi"]
What is it?　Yuna, what do you want from me?
[cpg cn=true]


In the middle of this exchange, I hear a whisper.
[cpg]


[OnName num="male_student_A"]
"Did you hear that Kyoichi called Kashiwagi-san Yuna?
[cpg cn=true]


[OnName num="male_student_B"]
I wonder if he had a chance to get close to her, I envy him. ......
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Yuna079"]
[OnName num="yuna"]
"...... Anyway, come here.
[cpg cn=true]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************



[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Yuna080"]
[OnName num="yuna"]
About the other day,...... you wouldn't seriously do something like that, would you?
[cpg cn=true]


[OnName num="kyoichi"]
What's that all about?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuna081"]
[OnName num="yuna"]
"Hypnotize ...... me in front of people, that ......."
[cpg cn=true]


[OnName num="kyoichi"]
If Yuna disobeys me, I will not tolerate it.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuna082"]
[OnName num="yuna"]
Oh, no. ......
[cpg cn=true]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=800]

[VOICE f="Akari079"]
[OnName num="akari"]
Oh, Yuna and Kyoichi. Don't you have anything to do now?"
[cpg cn=true]


We were pretty much at the edge of the academy when Akari came in.
[cpg]


I look at the hypnosis app on my phone. Akari's item was "kiss the person in front of you.
[cpg]


I tried it out.
[cpg]


[OnName num="kyoichi"]
"Hey Akari. Look at this.
[cpg cn=true]


[FACE method="shock_7" pos="4/5"]
[VOICE f="sAkari006"]
[OnName num="akari"]
What?"
[cpg cn=true]


[FACE method="shock_8" pos="4/5"]
Akari stares at the screen while saying that. And the person she saw after that was ......
[cpg]

[FACE method="change_6" pos="4/5"]
It was Yuna. In other words, she should try to kiss her.
[cpg]

[FACE method="change_5" pos="2/5"]
Akari tried to get closer, but Yuna looked at her with a perplexed expression.
[cpg]

[FACE method="shock_5" pos="2/5"]
[VOICE f="sYuna003"]
[OnName num="yuna"]
"Hey, hey, stop!
[cpg cn=true]


I broke the hypnosis before I kissed her, but either way, it had the effect of startling Yuna.
[cpg]

[OnName num="kyoichi"]
I'll see you later."
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]

I waved to Akari. She left.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Yuna083"]
[OnName num="yuna"]
Now ...... that's hypnosis, too?
[cpg cn=true]


[OnName num="kyoichi"]
Oh, yes. I can do something like that to you.
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]
[VOICE f="sYuna004"]
[OnName num="yuna"]
......."
[cpg cn=true]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************
;//【ＢＧ】『学園廊下』（夕方）


Yuna left again with a very pale face.
[cpg]


And now comes Izumi.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Izumi068"]
[OnName num="izumi"]
"Senpai, since it's a cultural festival, why don't we go on a date?"
[cpg cn=true]


[OnName num="kyoichi"]
I'm not your girlfriend or anything. ......
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Izumi069"]
[OnName num="izumi"]
I don't care about the details. Here.
[cpg cn=true]


He said that and pulled me by the arm. And I was to enjoy the festival to the fullest.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************


I went to all the stalls. Izumi was a good eater.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Izumi070"]
[OnName num="izumi"]
"This would be better if I cook it myself.
[cpg cn=true]


She said something to the effect that he was a good cook. She is confident in his cooking.
[cpg]


More than that, Izumi seemed to have a simple liking for me.
[cpg]


He may just be a guy who doesn't care about anyone, but anyway, ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



The school festival was over. I took a break. On my day off, I thought to myself.
[cpg]


Any of the three of us could do as we wished. With the help of a hypnosis app, anything.
[cpg]

It's not just my imagination that's getting the better of me.
[cpg]




[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I'll try to put together a lot of what I found out.
[cpg]

Only three people can be hypnotized by this app.
[cpg]

Yuna, Izumi, and Akari. There seems to be some hypnosis that involves the surroundings, but these three are at the center.
[cpg]

If it is not these three, I myself cannot be hypnotized.
[cpg]

So, there is no other target.
[cpg]

And also, it is not a universal power.
[cpg]

It would be better for the three of them not to find out that I can only use the hypnotism mentioned there.
[cpg]

If you are going to use hypnosis to make them listen to you, it is better that they don't find out about it.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************


[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』


[OnName num="male_student_A"]
Hey, that guy is .......
[cpg cn=true]


[OnName num="male_student_B"]
"Yeah, Kyoichi's changed recently. 
[cpg cn=true]


[OnName num="male_student_A"]
He's been talking to that skipping girl, too. ......
[cpg cn=true]


[OnName num="male_student_B"]
He may be surprisingly good at seducing people.
[cpg cn=true]


It's not so much that they are good at seducing, but that they have the means to do so.
[cpg]

I don't reveal all of it to others.
[cpg]

I've long thought that I shouldn't reveal this power to anyone.
[cpg]

Obviously, it is a power beyond human knowledge. If anyone were to find out about it, it would be analyzed and I would be unable to use it.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************

By the end of the class, I had decided who I would target.
[cpg]

Of course, each has its own merits and demerits.
[cpg]

Yuna would be wary of me. In return, I could use hypnosis on her.
[cpg]

Izumi, on the other hand, doesn't seem to have much of an interest in resisting me.
[cpg]

Akari is the type of person who doesn't know what she is thinking between the two, or .......
[cpg]

[SE f="se010"]
;//【ＳＥ】『歩く』

[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=1000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

I think on top of that. Who do you want to use hypnosis on? And the conclusion I came to is ......
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


;//ルート分岐。変数がもっとも高いヒロインのルートへと進む
;//同値の場合、ヒロイン１が最も優先され、次にヒロイン２、ヒロイン３の順で分岐する
;//選択肢


[if exp={getFlagValue("Cha1flg") == 1 }]
[jump target="*root1"]
[endif]
[if exp={getFlagValue("Cha2flg") == 1 }]
[jump target="*root2"]
[endif]
[if exp={getFlagValue("Cha3flg") == 1 }]
[jump target="*root3"]
[endif]


;//[if exp={getFlagValue("Cha1flg") == 0 }]
;//[jump target="*root1"]


*root1
[jump storage="ep004.ks" target="*root1"]

*root2
[jump storage="ep007.ks" target="*root2"]

*root3
[jump storage="ep010.ks" target="*root3"]
