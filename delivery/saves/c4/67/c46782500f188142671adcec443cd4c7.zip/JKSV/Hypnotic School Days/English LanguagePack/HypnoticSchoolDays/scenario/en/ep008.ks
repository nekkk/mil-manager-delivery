
*start

;//==============================
;//ヒロイン２の変数が２以下である場合

;#################################################
*Ep008|I want Izumi to like me
;#################################################

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_d1"]
[WAIT time=100]

*root2_5|I want Izumi to like me

[SCENE id=8]


[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


;//俺は和泉に好かれたい。そのために別の女の子も巻き込みたいというなら、してやろう。
I want Izumi to like me. If you want to get another girl involved for that purpose, I'll make it happen.
[cpg]



[OnName num="kyoichi"]
;//「分かったよ。そのうちな」
You said the other day that you wanted to use hypnosis on other girls. You can use hypnosis on them if you want.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Izumi231"]
[OnName num="izumi"]
Really?　I did it.
[cpg cn=true]


[OnName num="kyoichi"]
This app works for yuna and Akari. On the contrary, it doesn't work for the others very often."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Izumi232"]
[OnName num="izumi"]
Heh. Kashiwagi-senpai and Akari-chan, right?　It's hard to say which is which.
[cpg cn=true]


The actuality is that you can't get a lot of these things.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sIzumi026"]
[OnName num="izumi"]
But for the time being, I want to be with my senpai.
[cpg cn=true]


[OnName num="kyoichi"]
Well, ......, for now, you wanna come over to my place?"
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Izumi234"]
[OnName num="izumi"]
I like it. Then, let's do that.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



So, me and Izumi came to my room.
[cpg]


I thought about what kind of hypnosis I would give her. ......
[cpg]



;//========================================
;//●ＣＧ（※※※サイトに公開されているシーン、二枚目です※※※）ev_33
;//人物１：ヒロイン２
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：主人公の部屋
;//時間　：昼
;//========================================
[FADEOUTBGM]

[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています

I was going to hypnotize her to like me.
[cpg]

However, this kind of thing may not be necessary.
[cpg]

Because the way Izumi looked at me was already something meaningful.
[cpg]

[VOICE f="sIzumi027"]
[OnName num="izumi"]
'I can't get enough of the fluffy head ...... feeling.'
[cpg cn=true]


Still, she seemed pleased with me.
[cpg]

I approached her in such a state and stroked her hair.
[cpg]

[OnName num="kyoichi"]
「……」
[cpg cn=true]


I feel like saying something to her, but I can't say anything.
[cpg]

The relationship between me and Izumi was such a distance.
[cpg]

It was not so easy to confess. ......
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

And then, on the way home.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


[FACE method="shake_4" pos="2/3"]
[VOICE f="sIzumi028"]
[OnName num="izumi"]
I wanted Kashiwagi-senpai to get involved somehow,......, but couldn't you do it successfully with hypnosis?"
[cpg cn=true]


[OnName num="kyoichi"]
"I'll think about it,...... but it may not be possible right away.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Izumi254"]
[OnName num="izumi"]
I understand. Well then, shall we go home today?
[cpg cn=true]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hy"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


The other day. I'll think about it.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yuna375"]
[OnName num="yuna"]
"What do you want ......?
[cpg cn=true]


A really convenient hypnosis was displayed on the application.
[cpg]


It was called "Izumi will look like a man and you will fall in love with her.
[cpg]


This is a hypnosis that works for Yuna. If I use this, I can create the situation that Izumi wants.
[cpg]


[OnName num="kyoichi"]
"For now, look at this screen.
[cpg cn=true]


[FACE method="shake_8" pos="2/3"]
[VOICE f="Yuna376"]
[OnName num="yuna"]
What is ......?　It makes me dizzy.
[cpg cn=true]


I think I'm just dizzy. Izumi is not here right now.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

After that, I called Izumi and had her meet with me.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="4/5" time=800]

[OnName num="kyoichi"]
He said, "Yuna. I want to introduce you to someone.
[cpg cn=true]


[FACE method="shock_5" pos="2/5"]
[VOICE f="Yuna377"]
[OnName num="yuna"]
"What ......, who ......?　I wonder if there is such a person in this school.
[cpg cn=true]


[FACE method="shake_7" pos="4/5"]
[VOICE f="Izumi255"]
[OnName num="izumi"]
What do you mean ......?　Kashiwagi-senpai, your eyes are watering.
[cpg cn=true]


[OnName num="kyoichi"]
I see you as a man right now. And a good-looking one at that."
[cpg cn=true]

[FACE method="change_2" pos="4/5"]
Izumi smiles with a smile on her face.
[cpg]


[FACE method="bows_2" pos="4/5"]
[VOICE f="Izumi256"]
[OnName num="izumi"]
I see. That sounds like a lot of fun.
[cpg cn=true]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

;//[SE f="se014"]
;//【ＳＥ】『学園のチャイム』


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



After that, the three of us decided to go to my house.
[cpg]


It's not a good idea to head to Izumi's house. It would be to show the woman's room.
[cpg]


[FACE method="change_7" pos="2/5"]
[VOICE f="Yuna378"]
[OnName num="yuna"]
"Oh, um, ......, your name is ......?"
[cpg cn=true]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Izumi257"]
[OnName num="izumi"]
Uh, my name is ...... Izumi.
[cpg cn=true]


Okay. That's a name that even men can go by. With that in mind: ......
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



By the time we got to my house, Yuna seemed to have lost her patience.
[cpg]


[VOICE f="Yuna379"]
[OnName num="yuna"]
"Oh, please,...... Kyoichi, can I have a moment alone with you?"
[cpg cn=true]


[OnName num="kyoichi"]
"I'm not one of your friends,...... well, that's fine."
[cpg cn=true]

;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************

[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』

After all that happened, it was agreed that Akari would be the next target.
[cpg]


[OnName num="kyoichi"]
"All you do is talk about women. ...... You don't like me much, do you?"
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Izumi270"]
[OnName num="izumi"]
What are you talking about? Of all the guys, you're the best.
[cpg cn=true]


Is it true? I'm sure it's true.
[cpg]


But I don't know how to answer that.
[cpg]


What an excuse. I guess I have to give an answer soon.
[cpg]


[OnName num="kyoichi"]
Hey, Izumi, let's go someplace where no one is around.
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Izumi271"]
[OnName num="izumi"]
What?　What is it?
[cpg cn=true]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hy"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



So, we were in an empty classroom. I had something I really wanted to say to her.
[cpg]

[FACE method="change_5" pos="2/3"]
[OnName num="kyoichi"]
I like you. Izumi, let's go out.
[cpg cn=true]


[FACE method="bows_2" pos="2/3"]
[VOICE f="Izumi272"]
[OnName num="izumi"]
She said, "....... It's a little late for that, isn't it?
[cpg cn=true]


[OnName num="kyoichi"]
"Well, so ...... how about it? Are we going to remain friends?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Izumi273"]
[OnName num="izumi"]
I've always loved my senpai. Even after all this time, I still want to go out with you."
[cpg cn=true]


Yes. I knew this answer.
[cpg]


I knew it, but I asked her the question. ......
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hy"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************



But since we had just gotten together, I wanted to be alone with her.
[cpg]


It didn't work out the way I wanted. Because ......
[cpg]


[FACE method="bow_1" pos="4/5"]
[VOICE f="Izumi274"]
[OnName num="izumi"]
Please hypnotize Akari-chan."
[cpg cn=true]


[OnName num="kyoichi"]
I understand. ......
[cpg cn=true]



[FACE method="shake_7" pos="2/5"]
[VOICE f="Akari088"]
[OnName num="akari"]
"Hypnotism?　What are you talking about?
[cpg cn=true]


[FACE method="change_8" pos="4/5"]
I hypnotize Akari, who is staring at me.
[cpg]


It is a hypnosis that "makes you fall in love with Izumi.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************



The place was moved to Izumi's room. I'm supposed to come with her, but ......
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Akari089"]
[OnName num="akari"]
"Hmmm......... Izumi, I like you. We are together all the time, aren't we?"
[cpg cn=true]


[FACE method="bow_2" pos="4/5"]
[VOICE f="Izumi275"]
[OnName num="izumi"]
I'm glad to hear you say so. I had a one-sided love for a long time too.
[cpg cn=true]


The two of them are saying such things while smiling at each other.
[cpg]


It's not quite the same as a smirk. It is a more bewitching smile.
[cpg]


I watched them with an indescribable feeling in my heart.
[cpg]

;//移植のためシーンをカットしています

;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_sa"]
;//[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



And then... Izumi's outburst did not stop.
[cpg]


[OnName num="kyoichi"]
"Is that ......?　I can't find my phone.
[cpg cn=true]


I immediately knew what was going on. Izumi must be using it for something bad.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（昼）******************************************************



So I looked for her, and sure enough, she was wandering around with her smartphone in hand.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Izumi287"]
[OnName num="izumi"]
"Isn't this kind of hypnosis interesting, ......?
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
She said, "Oh," because I took her phone away from her.
[cpg]


[OnName num="kyoichi"]
Hey, you're cheating on me, Izumi.
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Izumi288"]
[OnName num="izumi"]
It's not cheating!　Girls don't count.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Izumi289"]
[OnName num="izumi"]
Rather, the seniors who approached Kashiwagi-senpai and Akari-chan were cheating on them.
[cpg cn=true]


Well, I can't deny ...... that, but ......
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************
;//【ＢＧ】『主人公の部屋』（夕方）

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="3/3" time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="1/3" time=800]

 Our relationship continued.
[cpg]


Since Izumi is in contact with Yuna and Akari, naturally these three, plus me, have been hanging out together more often.
[cpg]



[FACE method="change_7" pos="2/3"]
[VOICE f="sIzumi029"]
[OnName num="izumi"]
Akari doesn't have a boyfriend yet, does she?
[cpg cn=true]



[FACE method="bow_1" pos="1/3"]
[VOICE f="sAkari007"]
[OnName num="akari"]
Yes, that's right. ......
[cpg cn=true]


Akari looks at me as she says.
[cpg]


I don't feel comfortable with everyone asking for so much. I'm not that handsome.
[cpg]


It's not even the power of ...... hypnosis, as good as it is.
[cpg]


The hypnosis is already broken. I'm not hypnotized by anyone at the moment.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sIzumi030"]
[OnName num="izumi"]
I'm sure you'll fall in love with Akari someday, won't you?　Senpai."
[cpg cn=true]


[OnName num="kyoichi"]
Ah, ah ...... yeah.
[cpg cn=true]



[FACE method="shake_2" pos="3/3"]
[VOICE f="sYuna019"]
[OnName num="yuna"]
Well, I'm all about Izumi.
[cpg cn=true]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

The relationship turned out to be quite strange. ......
[cpg]


 Such a harem that originated in Izumi may be possible.
[cpg]


Still, it somehow felt like I was being hypnotized. ......
[cpg]




;//ＥＮＤ：ヒロイン２ルート１（ハーレムルート）
[SCENE id=15]
[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



