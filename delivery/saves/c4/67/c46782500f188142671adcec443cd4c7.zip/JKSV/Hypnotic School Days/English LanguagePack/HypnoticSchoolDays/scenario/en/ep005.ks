
*start

;//==============================
;//ヒロイン１の変数が２以下である場合


;#################################################
*Ep005|Tools for Deepening Love
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[BGM f="bg_da"]
;//[WAIT time=100]

*root1_5|Tools for Deepening Love

[SCENE id=5]

But for me, I didn't need to think about it.
[cpg]


I don't want to violate Momona with hypnosis.
[cpg]


This app brought us closer together.
[cpg]



[FADEOUTBGM]
[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Yuna231"]
[OnName num="yuna"]
......Kyoichi-kun. What shall we do today?"
[cpg cn=true]


[OnName num="kyoichi"]
I don't care what it is. As long as Momona can go wherever she wants, that's all that matters."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuna232"]
[OnName num="yuna"]
So ......?　Then I have a place to go."
[cpg cn=true]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]


We decided to go to a city a little more urban than where we usually live.
[cpg]


On the way there, of course, we would have to take the train. ......
[cpg]


[OnName num="kyoichi"]
I've got a seat. Momona, you want to sit down?
[cpg cn=true]

I usually take the train. But just having her there was something extraordinary.
[cpg]

I loved everything about this kind of time.
[cpg]


;//移植のためシーンをカットしています
[FADEOUTBGM]
[WAIT time=2000]

The train arrived at the station.
[cpg]


[SE f="se028"]
;//【ＳＥ】『電車扉が開く』


The doors opened and we headed to the turnstiles. Then we were in the city for a bit.
[cpg]

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『都会』（昼）******************************************************




It was a city, but it must have been a provincial city.
[cpg]


I guess a real city would be more difficult to walk everywhere.
[cpg]


[OnName num="kyoichi"]
So, what is it you're after?"
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Yuna255"]
[OnName num="yuna"]
Well, ...... there's a stuffed animal that they don't sell anywhere but here.
[cpg cn=true]


[OnName num="kyoichi"]
Well, I'll give it to you."
[cpg cn=true]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]


I wished I hadn't said that so carelessly.
[cpg]


The price was enough to buy a video game console, not video game software. ......
[cpg]


In the end, I couldn't afford that stuffed animal, but I did give him something a little cheaper as a gift.
[cpg]


But then, I guess I would have rather not given it as a gift.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_02_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Yuna256"]
[OnName num="yuna"]
Thank you.
[cpg cn=true]


Yuna's words were not a heartfelt "thank you.
[cpg]


[OnName num="kyoichi"]
No, I'm sorry ...... I didn't think I'd do this."
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



By the time I returned to my usual town, it was evening. I was to invite her to my house.
[cpg]


There was a lot going on, but in the end, she was happy with her gift. This kind of thing doesn't involve the app anymore.
[cpg]

This seemed like the right thing to do. What I wanted was a normal relationship like this.
[cpg]

I wouldn't let anyone get in the way of that. With this in mind, we spent time together.
[cpg]


;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



When the sun was about to set, I decided to see her off.
[cpg]


[FACE method="bow_2" pos="2/3"]
We were getting closer.
[cpg]


Everything was thanks to the person who created the hypnosis application.
[cpg]


But who made it, I wonder ......?　I think it must have been someone close to me, because he knew the three of them.
[cpg]


[FACE method="shake_2" pos="2/3"]
Or is it something that picks up three people on its own from those close to them?
[cpg]


If so, that's beyond modern technology. ...... Or has it ever been?
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Izumi076"]
[OnName num="izumi"]
I see you got together. Congratulations, senpai."
[cpg cn=true]


[OnName num="kyoichi"]
Thank you.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Izumi077"]
[OnName num="izumi"]
I've heard that you like me, so I knew this would happen someday.
[cpg cn=true]


Really?　I thought you didn't tell anyone about Yuna's.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（昼）******************************************************



After receiving a blessing from Izumi, I also passed Akari.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Akari083"]
[OnName num="akari"]
She said, "...... seems like you and Yuna are going out."
[cpg cn=true]


[OnName num="kyoichi"]
Yeah. It's been a while."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Akari084"]
[OnName num="akari"]
I hope you'll be happy. I'll never forgive you if you're not happy.
[cpg cn=true]


Akari has said some strange things. She also looks complicated.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************




[OnName num="kyoichi"]
That's how it is with Akari. She's crazy.
[cpg cn=true]


[FACE method="bow_7" pos="2/3"]
[VOICE f="Yuna279"]
[OnName num="yuna"]
"...... yeah. So that's what that's about. ......"
[cpg cn=true]


Yuna seems to have noticed something. I was curious and asked her.
[cpg]


[OnName num="kyoichi"]
What's up?"　Did you notice something?"
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Yuna280"]
[OnName num="yuna"]
I asked her. Nothing, nothing.
[cpg cn=true]


He won't tell me. What is it?
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』



And then we walk home together.
[cpg]


We are walking in the same direction, even though we are going home in different directions, because we want to be together as much as possible.
[cpg]

She probably feels the same way as I do.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_07_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//俺達を引き合わせた催眠アプリ。
The hypnosis app that brought us together. I never found out why it was on my phone.
[cpg]


[VOICE f="sYuna014"]
[OnName num="yuna"]
Hey, Kyoichi......, you don't use it anymore."
[cpg cn=true]


Yuna asked me to use the app, and I agreed.
[cpg]

I guess hypnosis is something that can be addictive just to be put on.
[cpg]


;//========================================
;//●ＣＧ（うつ伏せで寝ているヒロイン）ev_21
;//人物１：ヒロイン１
;//服装１：制服（はだけ）
;//人物２：主人公
;//服装２：制服
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_21_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=1000]

Now I was hypnotizing myself into thinking I was a dog.
[cpg]

[VOICE f="sYuna015"]
[OnName num="yuna"]
'Woof, woof. ......'
[cpg cn=true]


She is imitating a dog's cry, but I guess it is not an imitation for her.
[cpg]

Seeing her like this, defenseless as she is, makes me want to be nice to her.
[cpg]

It's something I wouldn't have thought of in the past. ......
[cpg]

As I think this, she looks up at me and looks like she's waiting for something.
[cpg]

Maybe she wants to be petted. It's possible if she really is a dog.
[cpg]

[OnName num="kyoichi"]
'All right, all right. You really are a sweetie."
[cpg cn=true]


I pat her head. She looked happy and was definitely like a dog, even though she was Yuna.
[cpg]

I continued to observe her as she was for a while.
[cpg]


;//移植のためシーンをカットしています



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then, when I was satisfied, I released the hypnosis. She remembered what had just happened and looked embarrassed.
[cpg]

After that, we stayed together for a while and then I sent her home.
[cpg]

We can't let them stay over at the stone. I mean, if my parents come back, we can't do anything.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************



Still, we were happy. I wouldn't be surprised if people say that all this now is hypnotized.
[cpg]


Well, I guess it is not such a scary story. I know this is real.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』

In the afternoon, Yuna and I eat dinner together.
[cpg]


I don't think that people around us are scolding us anymore.
[cpg]


Of course, me and Yuna are not a match for each other. Still, the men around me seemed to have given up.
[cpg]


That's what you would think if you saw how much Yuna and I are in love with each other. How self-conscious would I be?
[cpg]


[OnName num="kyoichi"]
What's this ......?
[cpg cn=true]


[FACE method="change_7" pos="2/3"]
[VOICE f="Yuna300"]
[OnName num="yuna"]
What's wrong?　Is this about the hypnosis app?"
[cpg cn=true]


There's a message on the hypnosis app. It says, "I wish you a long and happy life."
[cpg]


...... I knew it was made by someone watching us.
[cpg]


But I have no idea.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Yuna301"]
[OnName num="yuna"]
It says, "......, I wish you many years of happiness. ......."
[cpg cn=true]


[OnName num="kyoichi"]
Don't peek at it.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Yuna302"]
[OnName num="yuna"]
Don't worry about it.　Let's be happy, Kyoichi.
[cpg cn=true]


[OnName num="kyoichi"]
I have no objection to that.
[cpg cn=true]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



[SE f="se014"]
;//【ＳＥ】『学園のチャイム』



After that, we went to an empty classroom.
[cpg]



;//========================================
;//●ＣＧ非エロ（誰も居ない教室の椅子に座り、目の光を失っている。そこから目に光がともって、主人公を見上げて笑う）ev_22
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================





[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_22_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=1000]


After using hypnosis as usual.
[cpg]



[VOICE f="Yuna303"]
[OnName num="yuna"]
'Nn...... Fuuuh, hah.'
[cpg cn=true]


The hypnotism is broken and she looks at me.
[cpg]

She sounds sexy, but I felt fulfilled rather than deceived by it.
[cpg]

Her eyes moisten as she looks up at me.
[cpg]


[OnName num="kyoichi"]
"You're awake. How did it go?"
[cpg cn=true]


Yuna blushes as she remembers what has just happened. However, she does not dislike it.
[cpg]


Normally, hypnosis is a tool to make someone do what you want them to do.
[cpg]


But in our case, it was different. It was a tool to deepen our love for each other.
[cpg]




[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

From now on, we will always be together.
[cpg]

;//ＥＮＤ：ヒロイン１ルート１
[SCENE id=13]
[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


