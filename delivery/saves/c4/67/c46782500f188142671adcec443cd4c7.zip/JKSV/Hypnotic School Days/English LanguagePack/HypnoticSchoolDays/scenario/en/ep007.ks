
*start

;//==============================
;//ヒロイン２の変数が最も多い場合

;#################################################
*Ep007|和泉が一番落としやすそうだ
;#################################################

[stflag Cha2flg = 0]


[if exp={getFlagValue("Cha2flg") == 0 }]
[if exp={ isSystemFlagsEnabled( "sysflg1") }]
[stflag Cha2flg = 1]
[endif]
[endif]


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[window target=true]

[BGM f="bg_sa"]
[WAIT time=100]

*root2|和泉が一番落としやすそうだ

[SCENE id=7]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

......I guess Izumi. I can say that she seems to be the easiest to get rid of and she is a cute girl regardless of that.
[cpg]


It's not going to change whether there's hypnosis or not.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************

[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』

[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Izumi078"]
[OnName num="izumi"]
Hello, senpai."
[cpg cn=true]


She is more lighthearted than flirtatious. Or is that almost equal?
[cpg]


I met her when I went out to the hallway after I finished my lunch.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Izumi079"]
[OnName num="izumi"]
I guess you just ate lunch. Maybe you want dessert.
[cpg cn=true]


[OnName num="kyoichi"]
She said, "I'll get dessert at ......."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sIzumi008"]
[OnName num="izumi"]
She was very aggressive. Have you changed a bit, senpai?
[cpg cn=true]


...... Are you sure this is the right guy?
[cpg]


The first thing to do is to make sure you have a good time. You don't even have to erase his memory.
[cpg]


[OnName num="kyoichi"]
;//「分かった。じゃあ今日の帰り、お前の家まで案内してくれ」
"...... well, on your way home today, take me to your house."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="sIzumi009"]
[OnName num="izumi"]
"My house?　I'll be there. It's not clean.
[cpg cn=true]


;//和泉はもうほぼ告白のようなことを言ってるが、なんというか……
I don't know if I said so myself, but it's kind of ...... easy to invite a man who is not your lover to your house.
[cpg]


I don't think she is aware of it. Maybe he is like this to everyone.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夕方）******************************************************



[SE f="se014"]
;//【ＳＥ】『学園のチャイム』





And then it's after school. I'm being shown around by Izumi.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sIzumi010"]
[OnName num="izumi"]
I was so happy to see him.
[cpg cn=true]


[OnName num="kyoichi"]
"......, you don't care who it is, do you?"
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Izumi083"]
[OnName num="izumi"]
"Senpai is special. It's true.
[cpg cn=true]


 I wonder if that's the case... while thinking.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』





The school route, the school route for her is guided.
[cpg]


The direction is different from my house.
[cpg]


That's why I hadn't seen her on the way to school until now.
[cpg]



;//ブラックアウト

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_hy"]
;//[WAIT time=100]
;//【ＢＧ】『ヒロイン２の部屋』（夕方）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Izumi084"]
[OnName num="izumi"]
This is my room, isn't it? It's like a girl's room, isn't it?
[cpg cn=true]


[OnName num="kyoichi"]
...... like a gal's room.
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Izumi085"]
[OnName num="izumi"]
Even if that's a lie, I'm going to nod my head.
[cpg cn=true]


[FACE method="sbow_1" pos="2/3"]
Saying this, Izumi promptly sat down on the bed.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sIzumi011"]
[OnName num="izumi"]
What should I do?　What are you going to do to me?
[cpg cn=true]


......I'm not going to do anything. There are two hypnotic tricks displayed on the application.
[cpg]

One is "I will fall in love with the person in front of me. One is "your body will become a doll".
[cpg]

[FACE method="change_2" pos="2/3"]

;//■選択肢６
[switch]
[case "Fall in love with the person in front of you"]
	[swap]
	[jump target="*select06_1"]
[case "Your body becomes a doll."]
	[swap]
	[jump target="*select06_2"]
[endswitch]


1. You fall in love with the person in front of you.
2. Your body becomes a doll.


;//この選択肢で増加するのはヒロイン２の変数
;//１を選んだ場合変数は変わらない
;//２を選んだ場合変数が１増える



;//==============================
;//１、目の前の人を好きになる
*select06_1|和泉が一番落としやすそうだ

[system sysflg6=false]

I hypnotized him. But ......
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sIzumi012"]
[OnName num="izumi"]
What kind of hypnosis was this?"
[cpg cn=true]


There is no change in her mind. She really likes me from the beginning.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="sIzumi013"]
[OnName num="izumi"]
If you don't do anything for me, I'll do it for you.
[cpg cn=true]


She approached me, saying, "Hey , I'm dressed like this.
[cpg]



;//ブラックアウト
;//========================================
;//●ＣＧ（主人公にのしかかるヒロイン）ev_27
;//人物１：ヒロイン２
;//服装１：制服（はだけ）
;//人物２：主人公
;//服装２：制服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_27_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

[OnName num="kyoichi"]
I said, "Hey, ......, you shouldn't be dressed like this."
[cpg cn=true]


I said, and she looked into my face teasingly.
[cpg]

I was probably blushing.
[cpg]

[VOICE f="sIzumi014"]
[OnName num="izumi"]
Why?　What are you imagining?"
[cpg cn=true]


I looked away. I couldn't deny or affirm.
[cpg]

If anything, I was more at the mercy of what she was doing.
[cpg]

Izumi looks at me and seems happy. She must really like me.
[cpg]

I can't say this is hypnotically so.
[cpg]

[OnName num="kyoichi"]
"Hey, you're getting too close.
[cpg cn=true]


Izumi presses her body against mine, saying, "That's fine.
[cpg]

For her, this might be called skinship.
[cpg]


;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I was supposed to be hypnotizing Izumi, but I felt as if I was being turned on.
[cpg]

This kind of relationship is also something I love.
[cpg]


[jump target="*select06_4"]

;//==============================
;//２、体が人形化する
*select06_2|和泉が一番落としやすそうだ

[stflag Cha2flg = 1]

[system sysflg6=true]


[OnName num="kyoichi"]
Izumi. Look at me.
[cpg cn=true]


[FACE method="shake_8" pos="2/3"]
[VOICE f="Izumi109"]
[OnName num="izumi"]
"Is that hypnosis?　Uh-uh.
[cpg cn=true]


Izumi's body should now be immobile.
[cpg]



;//========================================
;//●ＣＧ（体が動かない催眠をかけられているヒロイン。ヒロインも受け入れている感じで笑顔）ev_28
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：ヒロイン２の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sIzumi015"]
[OnName num="izumi"]
"I can't ...... move. I can still speak.
[cpg cn=true]


She seemed to be enjoying the situation that would normally frighten her.
[cpg]

I stroked her hair. As I thought, she is not scared.
[cpg]


;**【ＣＧ】 ev_28_a ***********************
[CG id=13 index=1 time=1]
;***************************************
[WAIT time=1]

Then I put my lips to her cheek.
[cpg]

I know this guy wouldn't mind even if I didn't have to make her immobile. ......
[cpg]

Still, it makes sense to hypnotize her. I approached her with that thought in mind.
[cpg]

The moment our lips touched, I think she looked happy.
[cpg]

Of course I can't see their expressions because they are too close, so I can only guess from their voices and other atmospheres.
[cpg]

But she certainly looked happy.
[cpg]


;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
;//ブラックアウト

I was happy to be by her side.
[cpg]

That may have nothing to do with hypnosis.
[cpg]

I have to think about how we are going to be together from now on.
[cpg]

With herself and with hypnosis. ......
[cpg]



;//==============================

*select06_4|和泉が一番落としやすそうだ

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



After all the talking, I left her house.
[cpg]

I am not dating her. She probably thinks of me as a friend or more.
[cpg]


Still, it was good. I would have been happy with anything if I could have played with hypnosis on her: ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************

[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』

Then morning comes again. I went to the school and met Akari.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Akari085"]
[OnName num="akari"]
Kyoichi, it seems you and Izumi are getting along well these days.
[cpg cn=true]


[OnName num="kyoichi"]
'Yeah, well,...... what about it?
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Akari086"]
[OnName num="akari"]
I'm not sure what to expect. It's good that we get along well, but lately,......, the way Izumi looks at me is suspicious.
[cpg cn=true]


[OnName num="kyoichi"]
The actuality that you can't see the whole picture. I can't see the whole picture.
[cpg cn=true]


[FACE method="bow_4" pos="2/3"]
[VOICE f="Akari087"]
[OnName num="akari"]
"I wonder if they would prank me when I was in the locker room for gymnastics or something."
[cpg cn=true]


Do they do such things? Surprisingly,......, it is not.
[cpg]



;//ブラックアウト

;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_hy"]
;//[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



Lunch break. I went to Izumi's classroom.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Izumi155"]
[OnName num="izumi"]
"Can't you use that hypnotism on other girls?"
[cpg cn=true]


Then Izumi said exactly what Akari had said.
[cpg]


I don't know if I should reveal it or not. ...... Well, okay.
[cpg]


[OnName num="kyoichi"]
I used to do it to other guys."
[cpg cn=true]


[FACE method="bows_2" pos="2/3"]
[VOICE f="Izumi156"]
[OnName num="izumi"]
So it doesn't only work on me, does it?
[cpg cn=true]


I guess it does. I was thinking that, when Izumi's eyes lit up.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sIzumi016"]
[OnName num="izumi"]
I'm not interested in other girls?　Senpai."
[cpg cn=true]


[OnName num="kyoichi"]
'No, I'm ......
[cpg cn=true]


I was about to say, "I don't know what to do. Izumi is not normal, so he might want to get other girls involved.
[cpg]

Maybe someday it would be good to get Yuna and Akari involved.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="sIzumi017"]
[OnName num="izumi"]
'Well, I don't want to right now. But more importantly, aren't you going to do anything today?"
[cpg cn=true]



I decided to comply.
[cpg]

There were two options for hypnosis. "I can't speak," and "I'll feel the cold temperature.
[cpg]


I decided to choose. What would I do to Izumi?
[cpg]



;//■選択肢７
[switch]
[case "I would lose the ability to speak."]
	[swap]
	[jump target="*select07_1"]
[case "Feel a lower temperature"]
	[swap]
	[jump target="*select07_2"]
[endswitch]


1, I will lose the ability to speak.
Two, I'll feel the temperature drop.


;//この選択肢で増加するのはヒロイン２の変数
;//１を選んだ場合変数は変わらない
;//２を選んだ場合変数が１増える

;//＠

;//==============================
;//１、言葉が話せなくなる
*select07_1

[system sysflg7=false]


[OnName num="kyoichi"]
"Not now, I'll meet you in an empty classroom after school."
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Izumi159"]
[OnName num="izumi"]
"I don't have a choice. ...... I'll be sure to do it."
[cpg cn=true]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************




And we meet up again.
[cpg]


I put her under hypnosis right away. Then she said, "!
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="sIzumi018"]
[OnName num="izumi"]
"......!"
[cpg cn=true]


She was speechless. Not figuratively, but she was.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト


;//移植のためシーンをカットしています

However, she was only amused by it, not afraid of it.
[cpg]

As for me, it's not like I can do anything about it now. ......
[cpg]

For example, it may be that if I do something, they won't call for help.
[cpg]

But I didn't want to do anything terrible to Izumi.
[cpg]


;//ブラックアウト

[jump target="*select07_4"]

;//==============================
;//２、気温を低く感じる
*select07_2|和泉が一番落としやすそうだ

[stflag Cha2flg = 1]
[system sysflg7=true]

[OnName num="kyoichi"]
I might give ...... a try and pick this one."
[cpg cn=true]


I don't know what will happen. I don't know, but I decided to give it a try.
[cpg]



;//[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[WAIT time=1000]


[FACE method="shock_4" pos="2/3"]
[VOICE f="sIzumi019"]
[OnName num="izumi"]
Ugh,...... it's so cold!
[cpg cn=true]


She started shivering and looked at me.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="sIzumi020"]
[OnName num="izumi"]
I want you to warm me up, senior ......."
[cpg cn=true]


The chime for the beginning of class had already rung, but she approached me without regard to it.
[cpg]

I took her with me because I didn't want to be seen.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//========================================
;//●ＣＧ（主人公に抱きしめられるヒロイン）ev_31
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================
[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_31_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

She felt my body heat and stopped shivering.
[cpg]

I think her expression was a little different from the one that usually rubbed off on me.
[cpg]

[VOICE f="sIzumi021"]
[OnName num="izumi"]
'Senpai-no-body...... is hot.'
[cpg cn=true]


If she felt cold, she might feel my body temperature higher.
[cpg]


;**【ＣＧ】 ev_31_a ***********************
[CG id=14 index=1 time=1]
;***************************************
[WAIT time=1]


I was hugging her and being hugged by her.
[cpg]

I am indescribably happy. It is a little different from just being desired.
[cpg]

It was different from the usual Izumi, and it was a different kind of stimulation.
[cpg]

When she hugs me, that alone makes me nervous.
[cpg]

I wanted to enjoy this time longer, but ......
[cpg]

But I also felt sorry for her that I would not release the hypnotism.
[cpg]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

With that in mind, I decided to release the hypnosis for the time being.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



......It's really possible to do anything with this hypnosis app, isn't it?
[cpg]


It can do terrible things depending on how you use it.
[cpg]


With this in mind, I decided to return home for the day.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

;//[jump target="*select07_4"]
;//==============================

*select07_4|Izumi seems to be the easiest to drop off.

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



A few days passed, and it was the weekend.
[cpg]


I and Izumi met up, although it wasn't a date.
[cpg]



[FACE method="change_2" pos="2/3"]
[VOICE f="sIzumi022"]
[OnName num="izumi"]
Where shall we go, senpai?
[cpg cn=true]


She was holding my hand and looked happy.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="sIzumi023"]
[OnName num="izumi"]
I'll do anything as long as I can be with you, senpai.
[cpg cn=true]


[OnName num="kyoichi"]
Is there anything else you want to do besides being with ...... me?
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="sIzumi024"]
[OnName num="izumi"]
I have many hobbies. I also enjoy cooking.
[cpg cn=true]


Cooking. Come to think of it, that's right. I can't imagine a gal cooking, though.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Izumi227"]
[OnName num="izumi"]
But, you know, there are limits to cooking and eating.
[cpg cn=true]


[OnName num="kyoichi"]
"...... that there's no limit to what you can do with me?
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Izumi228"]
[OnName num="izumi"]
I guess it depends on the senior. I don't know.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="sIzumi025"]
[OnName num="izumi"]
What happened with the other girls?
[cpg cn=true]


[OnName num="kyoichi"]
What happened with the other girls?
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Izumi230"]
[OnName num="izumi"]
Senpai is senpai. Besides, I am me."
[cpg cn=true]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=1000]
[WAIT time=1100]

Having said that, Izumi clearly misses me. Maybe it's thanks to the hypnosis app.
[cpg]


I wonder what I want to do with her. Come to think of it, I haven't officially confessed to her nor has she confessed to me.
[cpg]


Will we remain friends? Will we become lovers?
[cpg]


[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I can do whatever I want, but I have one thought in my mind.
[cpg]



;//今までの全ての選択肢でハードなものを選んでいる（変数が３になっている）かどうかで分岐

[if exp={getFlagValue("Cha2flg") == 3 }]
[jump target="*root2_6"]
[endif]



[jump storage="ep008.ks" target="*root2_5"]


*root2_6
[jump storage="ep009.ks" target="*root2_6"]
