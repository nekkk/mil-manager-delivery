
*start

;//==============================
;//ヒロイン３の変数が２以下である場合

;#################################################
*Ep011|The Truth About Apps
;#################################################


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[BGM f="bg_da"]
[WAIT time=100]

*root3_5|The Truth About Apps

[SCENE id=11]

The idea was to find out the truth about Akari.
[cpg]


I'll have to find out the next time I go to the school.
[cpg]



;//ブラックアウト

[FADEOUTBGM]

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************


[OnName num="kyoichi"]
"Hey, Akari ......, can I talk to you for a minute?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Akari244"]
[OnName num="akari"]
What ......?　Are you going to do something else?
[cpg cn=true]


[OnName num="kyoichi"]
I'm not trying to do something else. Did you make this app?
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Akari245"]
[OnName num="akari"]
......, that's .......
[cpg cn=true]


[FACE method="bow_3" pos="2/3"]
[VOICE f="Akari246"]
[OnName num="akari"]
Kyoichi, come here. 
[cpg cn=true]


I was in public, so I was taken by Akari to an empty classroom.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************


[OnName num="kyoichi"]
So what do you think? If you made it or put it in your phone, what is it ...... for?
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Akari247"]
[OnName num="akari"]
...... it's, you know..."
[cpg cn=true]


[OnName num="kyoichi"]
I want to know what you're feeling."
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Akari248"]
[OnName num="akari"]
I ...... liked Kyoichi. So I wanted to test Kyoichi."
[cpg cn=true]


I knew it. But there are some things that don't add up.
[cpg]


[OnName num="kyoichi"]
Then why did you put Izumi and Yuna on the list?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Akari249"]
[OnName num="akari"]
They are both cute, aren't they? I wanted to see if they would still want me if I put them on the list with these two.
[cpg cn=true]


What a far-fetched confession. But ...... if that's the case, I'll have to respond.
[cpg]


[OnName num="kyoichi"]
You don't have to put it so far-fetched, I've always liked Akari."
[cpg cn=true]


[FACE method="shock_7" pos="2/3"]
[VOICE f="Akari250"]
[OnName num="akari"]
...... Really?
[cpg cn=true]


[OnName num="kyoichi"]
It's true. Though thanks in part to a hypnosis app."
[cpg cn=true]


After a moment of silence, Akari said,
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Akari251"]
[OnName num="akari"]
I'm so happy,......, Kyoichi, I love you.
[cpg cn=true]



;//移植のためシーンをカットしています

;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA03_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



We became lovers. But what we do is not much different.
[cpg]


After that, I continued to use hypnosis on Akari, who had a slight M-ness to her.
[cpg]


I was a little embarrassed and embarrassed, but Akari seemed to be rather pleased with it.
[cpg]



[OnName num="kyoichi"]
Akari said, "Hey Akari. Try telling me you love me.
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Akari272"]
[OnName num="akari"]
I can't say it. ...... I'm ashamed of such a thing.
[cpg cn=true]


Still in the city. Hypnotizing Akari, who is not being honest, by saying, "My true feelings come out of my mouth.
[cpg]


[FACE method="shock_8" pos="2/3"]
[VOICE f="Akari273"]
[OnName num="akari"]
"I'm going to say it one more time.
[cpg cn=true]


[OnName num="kyoichi"]
I'm going to say it one more time. Tell me you love me.
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
[VOICE f="Akari274"]
[OnName num="akari"]
I love you so ...... much."
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="sAkari017"]
[OnName num="akari"]
I always thought you were cool ...... and kind and smart.
[cpg cn=true]


There's a lot of favoritism in there. I'm not smart, and I'm even less kind.
[cpg]


I'll prove it to you. I put her out of her "I can't get my true feelings out of my mouth" trance.
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト

When I released the hypnosis, she turned red and slumped down.
[cpg]


;//========================================
;//●ＣＧ（街中でへたりこむ）ev_46
;//人物１：ヒロイン３
;//服装１：私服
;//人物２：主人公
;//服装２：私服
;//場所　：街
;//時間　：夕方
;//========================================
;//[FADEOUTBGM]

[WAIT time=1000]

;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_46_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=1000]


[OnName num="kyoichi"]
"Hey, are you okay? Are you all right?
[cpg cn=true]


I asked, and Akari shook her head.
[cpg]

I was puzzled because I did not expect such a big reaction.
[cpg]

[VOICE f="sAkari018"]
[OnName num="akari"]
What a hypnotic ......!
[cpg cn=true]


[OnName num="kyoichi"]
I'm sorry, I'm sorry."
[cpg cn=true]


It was the loudest reaction I had ever gotten.
[cpg]

I think I've done worse, but this is the most shocking thing I've ever done.
[cpg]

[OnName num="kyoichi"]
sorry and that he wouldn't do it again.
[cpg cn=true]


[VOICE f="sAkari019"]
[OnName num="akari"]
Are you sure you want to ......?"
[cpg cn=true]


I can't promise anything. But I nodded my head.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Akari seemed angry, but seemed to forgive me anyway.
[cpg]

After all, she doesn't really dislike me.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン３の部屋』（夕方）******************************************************



Our lover days went on with such things.
[cpg]


Thanks to the hypnosis app, I can one-sidedly blame her.
[cpg]


Today, I was in Akari's room again, and I was thinking about what I was going to use ...... to do that.
[cpg]


[FG f="CHA03_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akari290"]
[OnName num="akari"]
'Oh, yes. I need to talk to you today, Kyoichi."
[cpg cn=true]


[OnName num="kyoichi"]
I'll ask you later. But more importantly, let's have some fun."
[cpg cn=true]

[FADEOUTBGM]

The moment I said that, my hands stopped playing with my phone.
[cpg]

[BGM f="bg_hy"]
[WAIT time=100]

[FACE method="change_2" pos="2/3"]
[VOICE f="Akari291"]
[OnName num="akari"]
Of course, I can make an app that will work for Kyoichi, too.
[cpg cn=true]


It seemed that I, too, was being manipulated.
[cpg]


I was horrified, but by the time I was horrified, it was too late. ......
[cpg]


[FG f="CHA03_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akari292"]
[OnName num="akari"]
I'll do it for you, Kyoichi."
[cpg cn=true]


Akari approached me with a devilish smile on her face.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Akari293"]
[OnName num="akari"]
I'm not going to do it to you, I'm going to have you do it to me.
[cpg cn=true]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト
;//移植のためシーンをカットしています

I waited, wondering what she was going to do to me, and then Akari ......
[cpg]


;//========================================
;//●ＣＧ非エロ（主人公を抱きしめるヒロイン。そのままキスをする）ev_48
;//人物１：ヒロイン３
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：ヒロイン３の部屋
;//時間　：夕方
;//========================================



[FADEOUTBGM]
;//[free time=1000]
;//[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_op"]
;**【ＣＧ】 ev_48_0 ***********************
[CG id=19 index=0 time=1000]
;***************************************
[WAIT time=1000]





Akari hugged me.
[cpg]


I wonder what will happen now.
[cpg]


There is a desire to do as Akari wishes, and vice versa.
[cpg]

In other words, I want to be as gentle as possible.
[cpg]


I want to do what Akari wants to do and I want her to do it.
[cpg]


To do that, I will probably still have to use a hypnosis application.
[cpg]


I guess I'll be indebted to her invention for a while.
[cpg]



[VOICE f="sAkari020"]
[OnName num="akari"]
Suki, I love you......"
[cpg cn=true]


Akari kisses me. I responded.
[cpg]


The moment our lips touched, I felt irresistibly happy. ......
[cpg]


[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト



The love that started with a strange confession had come to fruition and was in a precarious balance.
[cpg]


But I think it will be more stable from now on. Because we now knew what we both wanted.
[cpg]


We can be happier through hypnosis.
[cpg]



;//ＥＮＤ：ヒロイン３ルート１
[SCENE id=17]
[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


