
*start

;//==============================
;//ヒロイン３の変数が３である場合

;#################################################
*Ep012|Do as you wish Akari
;#################################################


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[BGM f="bg_da"]
[WAIT time=100]

*root3_6|Do as you wish Akari

[SCENE id=12]

I will mess up Akari. I've made up my mind.
[cpg]


It doesn't matter what Akari thinks about me.
[cpg]


With that in mind, I decided to do whatever I wanted to her.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[WAIT time=1100]

Then, my parents went away for two days on a holiday.
[cpg]


I took the opportunity to break into Akari's house.
[cpg]

However, her parents were at Akari's house.
[cpg]

It would be easy to force her to come over.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hy"]
[WAIT time=100]

[FG f="CHA03_p3_02_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Akari315"]
[OnName num="akari"]
I'm following Kyoichi because I have no choice. Really, because I have no choice."
[cpg cn=true]


I'm in my room. Akari is somewhat unable to hide her fondness for me. But it doesn't matter.
[cpg]

I'm going to make it so that you can't even say that.
[cpg]



;//移植のためシーンをカットしています
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_8"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_hy"]
;//[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************





At first, the change was slight. It came out as an expression after the hypnotism was broken.
[cpg]

The expression became vague, and at some point, she stopped being fully aroused.
[cpg]

Akari still does not defy me.
[cpg]

Or rather, if she's ...... dazed, she can't defy me even more.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_8"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************


And as I performed various hypnotic tricks on her, her attitude gradually changed.
[cpg]

I guess I'm losing consistency between what's actually happening in front of me and hypnosis.
[cpg]


Akari returns to her school life without knowing what was being done to her.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Akari336"]
[OnName num="akari"]
She says, "Ah, Kyoichi ...... good morning. What do you want?"
[cpg cn=true]


She might have forgotten about the hypnosis application.
[cpg]


I didn't know how far her memory had gone.
[cpg]


[OnName num="kyoichi"]
It's nothing."
[cpg cn=true]


Even though she said that, I hypnotized her and made her listen to my commands.
[cpg]



;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
Even with simple hypnosis, I don't want her to remember it.
[cpg]

There was no doubt that erasing her memory over and over again would devour her memory.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_sa"]
;//[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



Akari repeats these days over and over again. Akari's memories were not adding up as they were being falsified.
[cpg]


Eventually, she could no longer remember who she was.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Akari358"]
[OnName num="akari"]
"I can remember ...... who I am. I can remember Kyoichi, but it's weird.
[cpg cn=true]


[OnName num="kyoichi"]
I see. Well, you could be anyone."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
"Maybe so.
[cpg]

She is unable to recognize her own abnormality by herself.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


Akari is absent from the school for some time.
[cpg]

Her family would have noticed her abnormality. They would have sent her to the hospital.
[cpg]

Part of me wondered if I wanted this to happen. ......
[cpg]

I felt a strange sense of fulfillment. At least it was me who changed her.
[cpg]

Whether or not I was in Akari, the realization that I had made a big difference in someone's life was satisfying to me.
[cpg]

[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（夜）******************************************************



Over time, Akari seemed to have lost her memory continuity without any hypnosis.
[cpg]


She stopped coming to school and was now in the hospital.
[cpg]


I thought I had gone a little overboard, but I had decided to set a new goal.
[cpg]


I think it might be ...... Yuna. I'm going to target her next.
[cpg]


My ambition is not over. Even though I destroyed one girl, it didn't change that.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
;//ブラックアウト

There are still only three names in the application.
[cpg]

I can only destroy two more. If that's the case, I'll lose out if I don't enjoy it for a long time.
[cpg]

Yuna turns around when she hears me talking to her.
[cpg]

The feeling I had there was more ...... than a desire to cherish her.
[cpg]

I was more interested in how I could destroy her.
[cpg]



;//ＥＮＤ：ヒロイン３ルート２

[SCENE id=18]
[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


