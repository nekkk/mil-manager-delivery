
*start


;#################################################
*Ep001|Stranger Apps.
;#################################################

[SCENE id=1]
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]

[SE f="se011"]
;//【ＳＥ】『ドア開く』
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



Today begins again. I will be working hard on my studies, not really feeling whether they are useful for the future or not.
[cpg]


I feel as if my life is a long time pass time.
[cpg]


I want a drastic change, but I don't want to go out and grab it myself.
[cpg]


So I would probably stay like this for the rest of my life. Somewhere I imagined that my life would somehow end somehow.
[cpg]




;//ブラックアウト
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[window target=true]


[SE f="se010"]
;//【ＳＥ】『歩く』


;//[window target=false]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_05_1.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************

[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=1000]


It is not that I made a mistake somewhere. It is probably the fault of this modern society.
[cpg]


The world has become a place where young people can't have dreams.
[cpg]


I justified my laziness by shifting the blame.
[cpg]



;//【ＢＧ】『学園教室』（朝）


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


The morning classes were over, and it was now noon.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』

[OnName num="male_student_A"]
Well, it's almost time for the festival."
[cpg cn=true]


[OnName num="male_student_B"]
I know... ...... It's so troublesome."
[cpg cn=true]


The festival. I was willing to boycott the festival.
[cpg]


I have refused every such imposition of youth from others and the school.
[cpg]


Club activities, well, that kind of thing. ......
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
I was thinking, there is a shadow watching me at the entrance of my class.
[cpg]

[FG f="CHA03_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_05_6.ui" time=1000]
[WAIT time=1000]

Akari Shinozaki. I know her, or rather, there is hardly anyone who doesn't know her.
[cpg]


At least, she is a famous person in this school. Because of that.
[cpg]


She skipped a grade. She is one year younger than me, but one grade above me.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_05_2.ui" time=1000]
[WAIT time=1000]

[OnName num="female_student_A"]
Oh, it's Akari. She's so small and cute.
[cpg cn=true]


[OnName num="female_student_B"]
"What's wrong?　What do you want?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="shake_7"  pos="2/3" time=800]
[VOICE f="Akari001"]
[OnName num="akari"]
I'm not cute. ...... I'm your senior.
[cpg cn=true]


The girls are kind of having this conversation. Then I thought, she was short and she was coming toward me.
[cpg]


 While I was wondering what was going on, he came to my side.
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akari002"]
[OnName num="akari"]
"Um, ...... Kyoichi. Can I borrow your phone for a minute?"
[cpg cn=true]


Suddenly. Suddenly calling out. And then he says something I don't understand, asking me to lend him my phone.
[cpg]


[OnName num="kyoichi"]
Can I ask you to call me again, "...... Kyoichi-senpai? And why do you need a phone?"
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="shake_7"  pos="2/3" time=800]
[VOICE f="Akari003"]
[OnName num="akari"]
I'm the senior one. So, as far as the later one's question, I don't know if I can answer it."
[cpg cn=true]


 What the hell is that... or rather, am I calling Akari senpai?
[cpg]


[OnName num="kyoichi"]
"You can lend it to me, but I won't unlock it."
[cpg cn=true]


[FG f="CHA03_p3_01_a.ui" method="bow_2"  pos="2/3" time=800]
[VOICE f="Akari004"]
[OnName num="akari"]
Yeah, that's all right.
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
Then, when I handed Akari the phone, she was operating something with the phone locked.
[cpg]

[FACE method="shake_1" pos="2/3"]
The phone is equipped with a fingerprint authentication system, so it should be impossible for anyone else to operate it.
[cpg]


And yet, she is doing something with it. What is she doing?
[cpg]

[FACE method="shake_1" pos="2/3"]
There are only so many things you can do with a locked screen.
[cpg]


There's no way they can see what's on my phone. ...... No, wait.
[cpg]


[FACE method="bow_2" pos="2/3"]
Akari is smart enough to skip a grade. It's not surprising that she's a bit of a mad scientist.
[cpg]


I get curious and look at the screen: ......
[cpg]


[OnName num="kyoichi"]
"Oh, hey!　Why is the lock unlocked?
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Akari005"]
[OnName num="akari"]
Because this is a piece of cake in my hands."
[cpg cn=true]


No, just because you can do it doesn't mean you should.
[cpg]


 Before that tsukkomi can come out of my mouth, I try to take the smartphone away from Akari.
[cpg]


[OnName num="kyoichi"]
Just give it back!
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Akari006"]
[OnName num="akari"]
Stop it!　We're still in the middle of this!
[cpg cn=true]


[OnName num="kyoichi"]
What do you mean, we're in the middle of something?　Are you trying to steal data from my phone?
[cpg cn=true]



;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_05_2.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
I took the phone back from Akari and asked her.
[cpg]


[OnName num="kyoichi"]
Did you look at ......?
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="shake_2"  pos="2/3" time=800]
[VOICE f="Akari007"]
[OnName num="akari"]
I didn't look at it much. I'm fine.
[cpg cn=true]


Don't say "not much. I'm not worried about it.
[cpg]


[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Akari008"]
[OnName num="akari"]
Well, that's all I have to do.
[cpg cn=true]


;//[t_move pos=C 右消]
[free time=1000]


[OnName num="kyoichi"]
What?　Hey, hey, ......."
[cpg cn=true]



Before I could ask for more information, Akari was gone.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



I fiddled with my phone in between classes, feeling uneasy.
[cpg]


There is no evidence that she was peeping at anything.
[cpg]


Or rather, if there were such traces, I couldn't grasp them.
[cpg]


;//エロいものも全部このスマホに入ってる。まさかと思うけど、後々脅してくるつもりじゃないだろうな。
Everything I don't want other people to see is on this phone. I don't think so, but I hope you're not planning to threaten me later.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


[OnName num="kyoichi"]
Hey, did I put this app in here: ......
[cpg cn=true]


After school. As I touched it, I saw a strange app.
[cpg]


I wondered if Akari had downloaded it on her own. Thinking so, I tried to open it, but ......
[cpg]


I was a little hesitant. I would have been thrilled if it was an app that did something wrong.
[cpg]


But I was curious about the name. It just says "hypnosis app.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Izumi008"]
[OnName num="izumi"]
What are you looking at?　Senpai.
[cpg cn=true]


[OnName num="kyoichi"]
"Whoa!"
[cpg cn=true]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
It seems that Izumi had approached me before I knew it.
[cpg]


I don't know why she likes me so much, but she follows me around a lot.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Izumi009"]
[OnName num="izumi"]
"Hypnosis app ......?　Can't sleep, seniors?"
[cpg cn=true]


No, I don't understand it either. I don't think there is any app that can help you sleep.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



On the way home, I read the description of this hypnosis app.
[cpg]


;//読めば読むほどばかばかしい。人物リストというのがあって、その人物に催眠術をかけてエロいことができるとか。
The more I read, the more ridiculous it got. There is a list of people, and you can hypnotize them and do whatever you want.
[cpg]


How could it be so ridiculous? I scrolled down to ......, thinking, "Who are these people?
[cpg]


[OnName num="kyoichi"]
"...... You're lying, dude."
[cpg cn=true]


It came with a photo. It was also a photo that looked like someone had taken it on their own.
[cpg]


One of them is Mr. Kashiwagi. One is Izumi. And Akari.
[cpg]


Can they really do it? Next to the name, it is written what kind of hypnosis is applied to that person.
[cpg]


For example, "Legs relax" or "Sleep" .......
[cpg]


As a note on the app, it said to show the person the screen of your phone when you choose the effect of the app.
[cpg]


That seems strangely graphic or true.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
Of course, we don't know if it works or not. Still, I saw Kashiwagi-san walking alone in front of me.
[cpg]


[OnName num="kyoichi"]
'Kashiwagi-san,......Good evening.
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yuna003"]
[OnName num="yuna"]
Ah, Kyoich-kun. Good evening, is something wrong?"
[cpg cn=true]


[free time=1000]
I had secretly chosen the "sleep" hypnosis. The phone glowed in rainbow colors and the screen looked distorted and strange.
[cpg]


I look at it and it's nothing. Then there is a strange sound, like a ...... mosquito sound.
[cpg]


This, too, is nothing when I hear it.
[cpg]


Maybe if Kashiwagi-san hears it, it will have an effect?
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
Then I turn the screen of my phone to Mr. Kashiwagi.
[cpg]


[OnName num="kyoichi"]
"Hey, I'd like you to take a look at this."
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Yuna004"]
[OnName num="yuna"]
'......?　It's glowing in rainbow colors, what is this?　Hmmm... ......."
[cpg cn=true]


Yuna's eyes were glazed over. She almost fell backward as it was.
[cpg]

[free time=1000]

[SE f="se012"]
;//【ＳＥ】『衣擦れ』

Thinking it was a bad idea, I stopped showing her the screen and supported her as she was about to fall over.
[cpg]


[OnName num="kyoichi"]
Are you all right?　Kashiwagi-san!"
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Yuna005"]
[OnName num="yuna"]
I was just a little dizzy.
[cpg cn=true]


The actuality of the application is that it is really effective. I was horrified to understand this and at the same time ......
[cpg]


Expectations and desires were growing inside me.
[cpg]


[jump storage="ep002.ks" target="*start"]
