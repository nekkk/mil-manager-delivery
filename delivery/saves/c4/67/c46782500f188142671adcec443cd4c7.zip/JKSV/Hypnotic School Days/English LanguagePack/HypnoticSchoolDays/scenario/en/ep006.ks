
*start

;//==============================
;//ヒロイン１の変数が３である場合


;#################################################
*Ep006|Distorted Shape of Love
;#################################################

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[BGM f="bg_da"]
;//[WAIT time=100]

*root1_6|Distorted Shape of Love

[SCENE id=6]


A throbbing something was boiling inside of ...... me.
[cpg]

Yuna might not hate me if I did more than this.
[cpg]


No ...... she may not like it.
[cpg]


If push comes to shove, I can threaten her with a hypnosis app.
[cpg]


Then I don't have to be merciful to her anymore.
[cpg]


Laughing to myself, I walked on my way home.
[cpg]



[FADEOUTBGM]
[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hy"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



The next day, the school was closed. I invited Yuna to my house.
[cpg]


[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yuna305"]
[OnName num="yuna"]
Hello, Kyoichi-kun. ...... I wonder what she's going to do for me today.
[cpg cn=true]


Yuna still doesn't know what I have in mind for her.
[cpg]

But that's okay. I like her now, defenseless.
[cpg]



[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;//ブラックアウト





The hypnosis I'm going to use today is called "body immobility" hypnosis.
[cpg]


By itself, the effect is weak. But it depends on what I do on top of it.
[cpg]


;//移植のためシーンをカットしています

I treated her like a doll for a while.
[cpg]

For hours, she remained conscious, but unable to move.
[cpg]

When I solved it, it looked painful, but I don't have any problem with it.
[cpg]


I mean, it had to be this way.
[cpg]


Finally, at sunset, I let her go.
[cpg]



;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_da"]
;//[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[FG f="CHA01_p1_02_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Yuna322"]
[OnName num="yuna"]
"Oh, um, ...... Kyoich-kun?"
[cpg cn=true]


[OnName num="kyoichi"]
Yes?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuna323"]
[OnName num="yuna"]
'Hey, that was too much today. ...... I don't care how much, I can't stand it if she does that to me repeatedly.'
[cpg cn=true]


The first thing to do is to make sure that you have a good time.
[cpg]


But this is fine. I will continue until she really can't take it anymore.
[cpg]



;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_hy"]
;//[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



After that, I hypnotized Yuna in various ways.
[cpg]

Whether she accepts or refuses, I continue.
[cpg]


The color of Yuna's face becomes worse and worse. I enjoyed watching that.
[cpg]



[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuna324"]
[OnName num="yuna"]
"......Oh, please ...... don't do it today."
[cpg cn=true]


[OnName num="kyoichi"]
You can't go against me? I'll hypnotize you in public."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuna325"]
[OnName num="yuna"]
"Oh no ...... ah."
[cpg cn=true]




[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『学園教室』（夕方）******************************************************



That's what it comes down to. Whether you are my lover or not.
[cpg]


Whether you are thinking of breaking up with me or not. It's all the same.
[cpg]


That is why I treated him harshly today.


The more you repeat it, the more Yuna will not be able to stand it anymore.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************


[FACE method="change_3" pos="2/3"]
[VOICE f="Yuna326"]
[OnName num="yuna"]
I'm sure that Momoka will be able to endure it.
[cpg cn=true]


[OnName num="kyoichi"]
What is it?　
[cpg cn=true]


The back of the school, in an empty corridor.
[cpg]


I was taken by Yuna.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuna327"]
[OnName num="yuna"]
"......I can't take it anymore. Don't do this anymore."
[cpg cn=true]


[FACE method="change_3" pos="2/3"]
[VOICE f="Yuna328"]
[OnName num="yuna"]
If you won't stop, then we'll have to break up.
[cpg cn=true]


[OnName num="kyoichi"]
"Do you know what you're saying?　You're going to die a social death.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuna329"]
[OnName num="yuna"]
What?
[cpg cn=true]


He is flabbergasted. But it's the same thing, isn't it?
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuna330"]
[OnName num="yuna"]
"I don't care ...... if it continues to be this painful."
[cpg cn=true]


I see. It seems that Yuna is serious.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]


[SE f="se014"]
;//【ＳＥ】『学園のチャイム』


[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hy"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************



During a class at the school. I decided to do it.
[cpg]


I decided to hypnotize her. Hypnotize her to take off her clothes in public.
[cpg]

[FACE method="shake_4" pos="2/3"]
I'm going to make it impossible for her to attend this school. That's what I decided.
[cpg]


And right after I hypnotized her, she was in class.
[cpg]

She was not easily able to follow the hypnosis, but it was only a matter of time before she was able to resist.
[cpg]

[FACE method="shake_4" pos="2/3"]
But I knew it was only a matter of time before she would be able to resist.
[cpg]


[free time=1000]
[WAIT time=1000]
As I watched her thinking this, she left the classroom without saying a word.
[cpg]

I see, if I have to take off my clothes in public, I should go to a place where I am not in public.
[cpg]

If it is not in public, it is thought that the hypnotic effect would be lost.
[cpg]

But how long can we endure in such a way?
[cpg]



;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


It's obvious, but as she repeated the same thing, she couldn't go to class.
[cpg]

A classroom can be said to be a public place all the time because there is always someone else there.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_da"]
;//[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』


[OnName num="male_student_A"]
......Kashiwagi-san, what's going on?
[cpg cn=true]


[OnName num="male_student_B"]
I don't know. I hear rumors that she is going to another school or something like that.
[cpg cn=true]


[OnName num="male_student_A"]
Is that so?　Kyoichi, do you know anything about it?
[cpg cn=true]


[OnName num="kyoichi"]
No, I don't know.
[cpg cn=true]


There is no way he is in another school.
[cpg]

I'm sure Yuna knows what they'll do to her if she tries to run away from me.
[cpg]

[OnName num="male_student_A"]
I'm worried about you. I'm worried about you. I'll go visit you next time.
[cpg cn=true]


[OnName num="male_student_B"]
Well, I've always admired you.
[cpg cn=true]



As rumors flew around, she stopped attending the school.
[cpg]


Now she has become what is called a shut-in. She seems to be stuck at home all the time.
[cpg]

I guess hypnosis won't work on her now. In a way, it's a wise choice.
[cpg]

But that doesn't mean I'm going to give up. I'm sure she knows that.
[cpg]

I had no choice but to go to her myself.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************



Holiday. In front of her house, I asked her to leave a message for me, as someone who looked like her mother came out.
[cpg]


[OnName num="kyoichi"]
"Please tell her I came to apologize. I think that will get the message across.
[cpg cn=true]


That's what I told her. Of course, I didn't mean it.
[cpg]


But I think Yuna will raise me up.
[cpg]


This is the beginning of a further conquest. I'm going to push Yuna so hard that she'll never be able to get up again.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]

[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ヒロイン１の部屋』（昼）******************************************************


[OnName num="kyoichi"]
"Yuna. How are you doing?
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuna348"]
[OnName num="yuna"]
"......, you did it all, didn't you?"
[cpg cn=true]


[FACE method="shock_3" pos="2/3"]
[VOICE f="Yuna349"]
[OnName num="yuna"]
What are you going to apologize ...... for now?
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="sYuna016"]
[OnName num="yuna"]
I can't go to the academy anymore.　I've lost everything. ...... everything.
[cpg cn=true]


[OnName num="kyoichi"]
You haven't lost everything. I'll take more."
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="sYuna017"]
[OnName num="yuna"]
What ......?　Hey, hey, hey!
[cpg cn=true]


[OnName num="kyoichi"]
Now I'm going to hypnotize you again. You'll be happy, won't you?"
[cpg cn=true]



;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


The last hypnosis I put him under was a hypnosis that made him forget what had been done to him.
[cpg]

;//[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="sYuna018"]
[OnName num="yuna"]
What was I doing before?　What was I doing before?
[cpg cn=true]


The look on her face, the words, I knew it wasn't an act.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************



Then I hypnotized her body and made her follow me.
[cpg]


It was the same thing whether I was manipulating her or not.
[cpg]


She was so weak that she could no longer act on her own volition.
[cpg]



;//ブラックアウト


;//========================================
;//●ＣＧ非エロ（ベッドに寝ているヒロイン）ev_26
;//人物１：ヒロイン１
;//服装１：私服（はだけ）
;//場所　：主人公の部屋
;//時間　：夕方
;//========================================



[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_26_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=1000]



It was fun to watch her in her weakened state.
[cpg]

Or perhaps it was more accurate to say that she was cute.
[cpg]

I felt that she was mine alone. It's not just my imagination, it's definitely true.
[cpg]

[OnName num="kyoichi"]
Yuna, do you like me?
[cpg cn=true]


She doesn't reply. There is no reason for her to like me.
[cpg]

She is more attractive than ever, even though she doesn't say anything.
[cpg]

She will always be at my mercy from now on.
[cpg]

With this imagination, I left her room.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
;//ブラックアウト

My wish had come true. I could feel my dark heart being filled.
[cpg]

I was looking forward to seeing her again, knowing that it was all for the best.
[cpg]

Hypnosis had thrown our relationship out of whack ...... No. This is what I had always wanted.
[cpg]

This is what I've always wanted. Everything just turned out right.
[cpg]

Then there's nothing to regret.
[cpg]

I still love Yuna. It can be called a straight love.
[cpg]

I decided to convince myself that this form of love is possible .......
[cpg]


;//ＥＮＤ：ヒロイン１ルート２
[SCENE id=14]
[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

