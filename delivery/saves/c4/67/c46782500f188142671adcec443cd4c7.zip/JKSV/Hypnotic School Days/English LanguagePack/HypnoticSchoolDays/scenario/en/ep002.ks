
*start

;#################################################
*Ep002|Hypnosis App
;#################################################

[SCENE id=2]


;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************

[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』

Next day. At the daytime school, I approached Izumi anyway.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Izumi010"]
[OnName num="izumi"]
It's unusual for a senior to come to me. I'm glad."
[cpg cn=true]


There was only one reason why I approached Izumi.
[cpg]


I was really hypnotized and could erase my memories. This is good.
[cpg]


Hypnosis doesn't work and nothing happens. This is also good.
[cpg]


The worst situation is when the hypnosis works and the memory is not erased after doing something.
[cpg]


Izumi was the only one who didn't seem to complain at this time.
[cpg]


Kashiwagi-san was out of the question, and I was hesitant to go with Akari.
[cpg]


;//一番ビッチな所がある和泉だ。もしものことがあっても大丈夫だろう……
It's Izumi, where he is most comfortable with me. If something were to happen, it would be fine. ......
[cpg]


The two items are "consciousness becomes clouded" and "I like the person in front of me".
[cpg]


Each is a feeling word that doesn't say much. But I know what happens.
[cpg]


[OnName num="kyoichi"]
It's kind of a bad topic for a public place. Let's go somewhere else."
[cpg cn=true]


[FG f="CHA02_p1_01_a.ui" method="bow_2"  pos="2/3" time=800]
[VOICE f="sIzumi001"]
[OnName num="izumi"]
I don't mind. Maybe a confession?
[cpg cn=true]


Izumi was in high spirits. I think it's going to be fine.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_hy"]
;//ブラックアウト




[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

We ended up at the back of the school, and I was alone with Izumi.
[cpg]


And after much deliberation, I chose the hypnosis I wanted to use.
[cpg]



;//■選択肢１
[switch]
[case "My consciousness becomes cloudy."]
	[swap]
	[jump target="*select01_1"]
[case "Fall in love with the person in front of me."]
	[swap]
	[jump target="*select01_2"]
[endswitch]


1, My consciousness becomes cloudy.
2, Fall in love with the person in front of me


;//この選択肢で増加するのはヒロイン２の変数
;//１を選んだ場合変数は変わらない
;//２を選んだ場合変数が１増える



;//==============================
;//１、意識が混濁する
*select01_1|Hypnosis App

[system sysflg1=false]


[OnName num="kyoichi"]
"Look at this screen: ......Izumi."
[cpg cn=true]


[FACE method="shake_8" pos="2/3"]
[VOICE f="Izumi012"]
[OnName num="izumi"]
What is it?　It's a strange screen. ......
[cpg cn=true]


Izumi staggers. When he thought he stumbled, ......
[cpg]


[OnName num="kyoichi"]
Hey, hey!
[cpg cn=true]

[SE f="se012"]
;//【ＳＥ】『衣擦れ』

;//========================================
;//●ＣＧエロ（壁を背にしてスカートをめくった状態で、主人公に手で愛撫を受ける）ev_04
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園裏
;//時間　：昼
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_04_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=1000]


;//移植のためシーンをカットしています
She almost fell on the spot.
[cpg]

I hurriedly held her up, but she was in a strange position .......
[cpg]

[OnName num="kyoichi"]
Oh, hey."
[cpg cn=true]


When I call out to him, he responds as if he can't tell whether he can hear me or not.
[cpg]


;**【ＣＧ】 ev_04_a ***********************
[CG id=1 index=1 time=1]
;***************************************
[WAIT time=1]


[VOICE f="sIzumi002"]
[OnName num="izumi"]
"Nn......."
[cpg cn=true]


Izumi's voice sounded somewhat sexy.
[cpg]

I'm so nervous that I think she can sense it.
[cpg]

But it also said that my consciousness would become clouded.
[cpg]

If that's the case, I wonder if I'll forget what state I'm in or what happened to me.
[cpg]

[OnName num="kyoichi"]
"......No,......."
[cpg cn=true]


I guess no amount of memory can make it go away. I can't do anything about it.
[cpg]

I decided to be patient and let the hypnosis go away.
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I think I hesitated well. If I had taken a step forward here, I might not have been able to get it back.
[cpg]

Or is it that kind of courage I lack?
[cpg]

...... Did you want to take care of Izumi, even if only a little?
[cpg]


[jump target="*select01_4"]

;//==============================
;//２、目の前の人が好きになる
*select01_2|Hypnosis App

[stflag Cha2flg = 1]

[system sysflg1=true]


I don't say anything and show Izumi the screen.
[cpg]


I don't think she will look away. If I turn it to her, she will look at it.
[cpg]


[FACE method="change_8" pos="2/3"]
[VOICE f="Izumi030"]
[OnName num="izumi"]
What is this ......?　Hmmm, something strange. ......
[cpg cn=true]



;//========================================
;//●ＣＧ（かがんでいるヒロイン）ev_05
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園裏
;//時間　：昼
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[BGM f="bg_h1"]
;**【ＣＧ】 ev_05_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sIzumi003"]
[OnName num="izumi"]
I feel ...... like I'm in pain in my chest.
[cpg cn=true]


She comes closer to me while saying that.
[cpg]

It was as if I was truly hypnotized. I looked around in amazement.
[cpg]

It would be terrible if anyone saw us here.
[cpg]

;**【ＣＧ】 ev_05_a ***********************
[CG id=2 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="sIzumi004"]
[OnName num="izumi"]
Ha, ha. ...... always, the scenery looks different."
[cpg cn=true]


[VOICE f="sIzumi005"]
[OnName num="izumi"]
Or is it the seniors who are always different ......?"
[cpg cn=true]


 I feel like it would be a waste to leave her alone when she says such things.
[cpg]

But I didn't want it to get serious. I decided to break the hypnosis.
[cpg]


;//移植のためシーンをカットしています

;//[free time=1000]
;//[BG f="black.ui" time=1000]
;//[WAIT time=1000]
;//ブラックアウト


Of course, I didn't immediately know how to get rid of the hypnosis. ......
[cpg]


;//ブラックアウト
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//[jump target="*select01_4"]

;//==============================

*select01_4|Hypnosis App



[FADEOUTBGM]
[window target=false]
[WAIT time=2000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************


As it turns out, all you have to do to break the hypnosis is tap the rainbow-colored screen again.
[cpg]


It's as simple as it gets, yet very effective.
[cpg]



;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_05_2.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//
;//[BGM f="bg_da"]
;//[WAIT time=100]

[free time=800]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=1000]
;//【ＢＧ】『学園教室』（昼）******************************************************



;//情事を終えて、学園裏から教室に戻る。
After completing the hypnosis application experiment, me and Izumi return to the classroom from the back of the school.
[cpg]


[OnName num="kyoichi"]
"...... you weren't acting, were you?"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Izumi062"]
[OnName num="izumi"]
What's that?　You were controlling me, weren't you?
[cpg cn=true]


 No, isn't there a possibility of acting?
[cpg]


The particulars of the hypnosis and what you are going to be asked to do are not told to Izumi.
[cpg]


The fact that the details are consistent means that the hypnosis is really effective.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="Izumi063"]
[OnName num="izumi"]
But then, what was that just now?
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Izumi064"]
[OnName num="izumi"]
I think I can play with it in various ways.
[cpg cn=true]


And Izumi seemed to forgive me for hypnotizing her.
[cpg]


 Rather than forgive, or do you actively admit it yourself?
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（夕方）******************************************************


[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
;//放課後になってからも、和泉は俺に求めてきた。
After school, Izumi continued to approach me.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Izumi065"]
[OnName num="izumi"]
"Please do that hypnotic thing again!
[cpg cn=true]


[OnName num="kyoichi"]
......I'm busy."
[cpg cn=true]

[free time=1000]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=800]

[VOICE f="Yuna006"]
[OnName num="yuna"]
You two seem to be getting along well.
[cpg cn=true]


[OnName num="kyoichi"]
Oh, ...... Kashiwagi-san."
[cpg cn=true]


I freeze up a bit.
[cpg]


I could hypnotize her if I wanted to.
[cpg]


But I didn't. If I did that.
[cpg]


If you do that and it doesn't work out.
[cpg]


I thought the biggest risk was her. She's also someone I admire.
[cpg]


The next person I would approach would be Akari, who is on my list: ......
[cpg]


For Akari, I would have to hypnotize her to erase her memories.
[cpg]


But if I could do that, I could do anything.
[cpg]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



I couldn't see Akari that day, so I carried on until the next day.
[cpg]


[SE f="se010"]
;//【ＳＥ】『歩く』

;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************



I walked home as usual.
[cpg]


In the midst of all this, I noticed that the hypnosis applied to the girls was changing.
[cpg]


The content is changing this way and that. Basically, there are three choices, but they seem to be changing randomly.
[cpg]


I'm not even sure if this comes conveniently with the hypnosis of memory wipe. ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************



Morning, with that thought in mind.
[cpg]


I was thinking that today was the day I would do something to Akari, but I was also becoming a little afraid of the power of the application.
[cpg]


Izumi is good. He is a guy who is willing to go for it from the beginning. But Akari is different.
[cpg]


If it even works on her like that, anything is possible.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（昼）******************************************************

[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』

During the day, there was a vote on what to put on at the festival.
[cpg]


I settled on a very sticky place, a haunted house, and I was feeling like a pain in the ass. ......
[cpg]


I was going to get close to Akari even if it meant skipping the preparations.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Yuna007"]
[OnName num="yuna"]
"...... what's wrong?　Kyoich-kun, you look kind of bad.
[cpg cn=true]


[OnName num="kyoichi"]
What?　I'm not, it's nothing, Kashiwagi-san."
[cpg cn=true]


Kashiwagi-san, my ultimate goal, told me so.
[cpg]


I wonder if I was behaving in a way that would be noticed. But it's impossible to notice everything, right?
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



Then, after school, we headed to Akari's class. She was younger than me but was headed to the upperclassmen's classroom.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="kyoichi"]
Akari ...... can I talk to you for a minute? I have something to do."
[cpg cn=true]


[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Akari009"]
[OnName num="akari"]
"You wanted to see me?　What do you want?　If your phone is broken or something, I can help you."
[cpg cn=true]


[OnName num="kyoichi"]
"Can you do that? ...... No, I think I can."
[cpg cn=true]


Putting that aside, I decided to head to an empty classroom with no people in it to hypnotize Akari.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hy"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="sAkari001"]
[OnName num="akari"]
'What's really wrong with you, bringing me all the way down here?
[cpg cn=true]



[OnName num="kyoichi"]
'No, it's not a big deal.'
[cpg cn=true]


The app has an indication. Two choices.
[cpg]

I decided to hypnotize her one way or the other.
[cpg]



;//■選択肢２
[switch]
[case "I'm going to love the person in front of me."]
	[swap]
	[jump target="*select02_1"]
[case "Pretend the person in front of you is your lover"]
	[swap]
	[jump target="*select02_2"]
[endswitch]


1. fall in love with the person in front of you
2. Pretend that the person in front of me is my lover.


;//この選択肢で増加するのはヒロイン３の変数
;//１を選んだ場合変数は変わらない
;//２を選んだ場合変数が１増える

;//==============================
;//１、目の前の相手を好きになる
*select02_1|Hypnosis App

[system sysflg2=false]


I operated my phone and switched to the rainbow-colored screen.
[cpg]


As usual, a mosquito sound of a "squeak" is generated.
[cpg]


[OnName num="kyoichi"]
Look at me, Akari.
[cpg cn=true]


[FACE method="shock_8" pos="2/3"]
[VOICE f="Akari011"]
[OnName num="akari"]
What?　This screen .........ugh..."
[cpg cn=true]


And then, she fell into a slump.
[cpg]

[SE f="se012"]
;//【ＳＥ】『衣擦れ』

;//ブラックアウト
;//========================================
;//●ＣＧ（椅子に座っているヒロイン）ev_07
;//人物１：ヒロイン３
;//服装１：制服（はだけ）
;//場所　：学園教室
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=1000]



;//移植のためシーンをカットしています

[VOICE f="sAkari002"]
[OnName num="akari"]
'.......'
[cpg cn=true]


She stopped saying anything and looked at me.
[cpg]

And she was blushing. I wonder if she really likes me.
[cpg]

There's no way to be sure of that. ...... No.
[cpg]

I feel like I don't even need to check anymore. That's the look on my face.
[cpg]

I wonder if she wouldn't refuse me a kiss if I kissed her now. ......
[cpg]

[OnName num="kyoichi"]
"......No,......."
[cpg cn=true]


Akari is still looking like she wants me to do something.
[cpg]

It was as if I could hear her breathing, but I managed to regain my reason.
[cpg]

If I couldn't erase the memory or something, I'd be in big trouble.
[cpg]


;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

I decided to stay on and let the hypnosis go away.
[cpg]

Now, even if I couldn't erase the memory, I could make up for it.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



Then an item appeared in the application that said that the memory of the time he was under hypnosis would be erased.
[cpg]


While I thought it was convenient, I was skeptical that such a thing could really be done.
[cpg]


Then, after selecting that sentence, I showed Akari the screen of my phone again ......
[cpg]


[FACE method="shock_8" pos="2/3"]
[VOICE f="Akari029"]
[OnName num="akari"]
'Nnnn...... ugh!'
[cpg cn=true]


Akari is holding her head. Maybe her memory is muddled.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Akari030"]
[OnName num="akari"]
"What ......?　Oh, what was I doing?"
[cpg cn=true]


But that soon subsided, and she began to act as if she didn't know what she had been doing.
[cpg]

[jump target="*select02_4"]

;//==============================
;//２、目の前の相手を恋人と思い込む
*select02_2|Hypnosis App

[stflag Cha3flg = 1]

[system sysflg2=true]



I operate the phone and make the sound in the example. I show it to Akari.
[cpg]


[FACE method="change_8" pos="2/3"]
Will this make her think that we are lovers? Is there such a thing ......?
[cpg]


I thought to myself, but I decided to just do it.
[cpg]


[OnName num="kyoichi"]
"...... how are you doing?　You okay, Akari?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
Akari's eyes went slack and she smiled as she did.
[cpg]


[FACE method="change_6" pos="2/3"]
[VOICE f="sAkari003"]
[OnName num="akari"]
'Kyoichi,......, what are you doing bringing me to a place like this?
[cpg cn=true]


[OnName num="kyoichi"]
No, I mean, um,......."
[cpg cn=true]


While I was trying to think of the right words to say, she was coming on to me.
[cpg]




;//ブラックアウト
;//========================================
;//●ＣＧエロ（素股。主人公が床に座って、ヒロインが上に乗っているような形。前後に擦る）ev_09
;//人物１：ヒロイン３
;//服装１：制服（はだけ）
;//人物２：主人公
;//服装２：制服
;//場所　：学園教室
;//時間　：夕方
;//========================================


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_09_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=1000]


[VOICE f="sAkari004"]
[OnName num="akari"]
You're indecisive. You brought me to a secluded place, you want to do something about it."
[cpg cn=true]


She says this and comes on to me.
[cpg]

At this rate, they might as well be kissing.
[cpg]

[VOICE f="sAkari005"]
[OnName num="akari"]
What's wrong?　Don't be shy, we're lovers."
[cpg cn=true]


She really seems to think we are lovers.
[cpg]

I was surprised at how versatile hypnosis is, but I was puzzled by the other part.
[cpg]

With Akari so close by, I felt like I couldn't refuse her strongly.
[cpg]

I could have accepted it here, but ...... I stopped just before that.
[cpg]

[OnName num="kyoichi"]
"No, it's useless after all"
[cpg cn=true]


;**【ＣＧ】 ev_09_a ***********************
[CG id=4 index=1 time=1]
;***************************************
[WAIT time=1]


Akari looks at me curiously.
[cpg]

I'm sure that's what made her feel uncomfortable.
[cpg]

There is no need to think of excuses here. Once the hypnosis is broken, the memory will be complemented and won't be a problem.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA03_p3_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



I could have left her in the state of a lover. But, however, ......
[cpg]


The application displays an item that says that the memory of the person while under hypnosis will be erased.
[cpg]


If such a convenient thing was possible, I couldn't help but do it.
[cpg]


I operated the app again and showed the screen to Akari.
[cpg]


[FACE method="shake_8" pos="2/3"]
[VOICE f="Akari071"]
[OnName num="akari"]
"Ugh......... Fuuuh, hah, hah."
[cpg cn=true]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
I could see that her memory was muddled. But then ......
[cpg]


[FG f="CHA03_p3_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Akari072"]
[OnName num="akari"]
"Well, uh,...... what was I doing?"
[cpg cn=true]


Soon, it was back to the original Akari.
[cpg]



;//==============================

*select02_4|Hypnosis App

;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



After finishing various things, Akari went back to her house with her head tilted back.
[cpg]


This app can even erase memories.
[cpg]


Of course, you can't do everything at will. There are random factors.
[cpg]


But I can do most of it by my own will.
[cpg]


[OnName num="kyoichi"]
"Are you sure about this ......"
[cpg cn=true]


I was afraid of my power when I became so close to omnipotent.
[cpg]


My power, or rather the power of the hypnosis application. ......
[cpg]


Can I really use something like this?　Of course, that's partly because of the guilt I feel about manipulating girls.
[cpg]


Another thing is that I am hesitant to use it because I am not sure if it will have any effect on my head, my brain.
[cpg]


And then the face of that person comes to mind. Kashiwagi-san.
[cpg]


If I could make her mine. If I could do it using this app: ......
[cpg]


I can't help thinking about that.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



I thought deeply once again on my way home.
[cpg]


If I use the hypnosis application on Kashiwagi-san, what should I do?
[cpg]


I don't know if it is possible to erase memories during hypnosis in the future. But I think I can threaten her.
[cpg]


;//例えば人前で裸にさせるようなそんな催眠もあると思う。
For example, I think there is such a hypnosis that makes you do embarrassing things in front of others.
[cpg]


Once you manipulate the person with hypnosis, the threat will be more convincing.
[cpg]


[jump storage="ep003.ks" target="*start"]

