
*start

;//発情催眠アプリ　シナリオ
;//台本用で仕上げるため、主にＨシーンを短く書いておりました
;//現在は追加済です
;//セリフを喋るキャラクターと音声のあるなしを表記します
;//また、その隣に使用する服装を並べています
;//以下音声あり
;//百菜　　裸　制服　私服
;//和泉　　裸　制服　私服
;//あかり　裸　制服　私服
;//以下音声なし
;//恭一 男子学生Ａ 男子学生Ｂ 女子学生Ａ 女子学生Ｂ
;//ギャル 女子学生 教師
;//以下、それぞれのキャラクターがそれぞれをどう呼ぶか表記します
;//百菜　　一人称「私」　和泉呼び「和泉さん」　あかり呼び「あかりさん」　恭一呼び「恭一くん」
;//和泉　　一人称「私」　百菜呼び「柏木先輩」　あかり呼び「あかりちゃん」　恭一呼び「先輩」
;//あかり　一人称「私」　百菜呼び「百菜」　和泉呼び「和泉」　恭一呼び「恭一」
;//恭一　　一人称「俺」　百菜呼び「柏木さん→百菜」　和泉呼び「和泉」　あかり呼び「あかり」
;//今作はヒロインごとに変数があります
;//選択によって増減し、全ての変数は０から始まります
;//ルート分岐に変数が影響を及ぼします


[stflag Cha1flg = 0]
[stflag Cha2flg = 0]
[stflag Cha3flg = 0]

;///////////////////////////ここから本編です///////////////////////////

;#################################################
*Ep000|Spring, Summer, Autumn, Winter of Application
;#################################################

[SCENE id=0]



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Autumn of appetite. Autumn of reading. Autumn of sports.
[cpg]


In such an autumn I didn't have much of an appetite, I was out of print, and my muscles, my muscles, were emaciated.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（昼）******************************************************


[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』


It was the fall of the smartphone. It was also the summer of smartphones, the spring and winter of smartphones.
[cpg]


Especially games. Free, I might add, and I'm an expert when it comes to basic free apps.
[cpg]


It was the fall of apps. It was also the summer of apps, the spring and winter of apps.
[cpg]


You may say, "Young people nowadays. I am a young man of today.
[cpg]


My name is Kyoichi Hata.
[cpg]


[OnName num="kyoichi"]
...... you have to pay the bills to win from here on out.'
[cpg cn=true]


I don't charge. I won't do it, no matter how hard I try.
[cpg]


I think if I do, I lose. In this case, I can't win if I don't pay the bill.
[cpg]


[OnName num="male_student_A"]
"Kyoichi, are you playing that game again?"
[cpg cn=true]


[OnName num="kyoichi"]
I'm not sorry. I'm telling you, I'm not busy."
[cpg cn=true]


I told him I was busy, with about as much vigor and confidence as I could muster.
[cpg]


[OnName num="male_student_B"]
It's not something to brag about. ......
[cpg cn=true]


Of course, there are times when I am interested in something other than my phone.
[cpg]


I yearn for love as much as anyone else, but all I do is yearn.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_05_6.ui" time=1000]
[WAIT time=1000]

......Yuna Kashiwagi.
[cpg]


A neat girl with long black hair that suits her well.
[cpg]


She is popular among boys, but not disliked by girls.
[cpg]


[OnName num="female_student_A"]
And that's where things took a sudden turn. ......
[cpg cn=true]


[OnName num="female_student_B"]
But that drama doesn't get good ratings, does it?
[cpg cn=true]


[OnName num="female_student_A"]
"It's good!　I'm the one watching it.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuna001"]
[OnName num="yuna"]
I'm watching it. If it's that interesting, maybe I'll watch it too.
[cpg cn=true]


When she laughed, I almost started to giggle along with her.
[cpg]


I was so excited to see her smile that it made me want to giggle too.
[cpg]


[OnName num="female_student_A"]
I'm longing for that kind of love. ...... Kashiwagi-san doesn't have a favorite person or anything."
[cpg cn=true]


Oops. I was not about to let this topic go.
[cpg]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Yuna002"]
[OnName num="yuna"]
I'm not ready for love yet. I don't have the courage.
[cpg cn=true]


Is that so? ...... I feel relieved, but also disappointed.
[cpg]



;//ブラックアウト
;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_05_2.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//
;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//;//【ＢＧ】『学園教室』（昼）******************************************************


[free time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=1000]


[OnName num="male_student_A"]
Hey, Kyoichi, are you listening?
[cpg cn=true]


[OnName num="kyoichi"]
What?　Oh, yeah. I'm listening.
[cpg cn=true]


[OnName num="male_student_B"]
I'm about to take an exam, and I think I need to change my mindset from the moment I start ...... experiencing entertainment."
[cpg cn=true]


[OnName num="kyoichi"]
What are you talking about, ......?
[cpg cn=true]


[OnName num="male_student_A"]
I knew you weren't listening to me. I'm talking about reading books.
[cpg cn=true]


[OnName num="kyoichi"]
What are you talking about ......, I'm not supposed to read a book.
[cpg cn=true]


If I were to read it, I would read it on my phone screen.
[cpg]


That's how much I don't bother reading books. Likewise, I'm not that interested in comic books and the like.
[cpg]


I was half obsessed with smartphones. It's as if I can't appreciate anything without a smartphone.
[cpg]


I felt that I had become a young man of today, but I didn't regret it.
[cpg]



[stopse g=2]
;//通常se
[stopse g=3]
;//通常se
;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



Classroom after school. I was about to go home.
[cpg]


When I go home, what I do is the same. I just keep playing with my phone.
[cpg]


There are some game consoles, but I don't have much interest in them these days.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="gal"]
Then my parents tell me not to waste money.
[cpg cn=true]


And then, someone who is not good at this kind of thing came from in front of me.
[cpg]

[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_06_7.ui" time=1000]
[WAIT time=1000]


Izumi Nakakaze. She is a gal just like the picture.
[cpg]


;//非処女を公言していて、多分それが真実だろうという感じの女の子。
She is the kind of girl who professes that she often switches boyfriends, and that's probably true.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Izumi001"]
[OnName num="izumi"]
"Ah, senpai. Good evening.
[cpg cn=true]


In a way, I was her senior. But I don't think she thinks I'm her senior.
[cpg]


And she uses polite words, but they seem to be somewhat appropriate.
[cpg]


;//ブラックアウト
;//========================================
;//●ＣＧ非エロ（主人公の腕にくっついて、胸を当てるヒロイン）ev_02
;//人物１：ヒロイン２
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：学園廊下
;//時間　：夕方
;//========================================

;//[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

;//[BGM f="bg_op"]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=1000]



[VOICE f="Izumi002"]
[OnName num="izumi"]
"Oh, you're ignoring my senpai?　Please take care of my cute junior a little bit!"
[cpg cn=true]


[SE f="se034"]
;//【ＳＥ】『胸を押しつける』
[WAIT time=1000]


[OnName num="kyoichi"]
"No, don't do that. ...... don't get attached to me."
[cpg cn=true]



[VOICE f="Izumi003"]
[OnName num="izumi"]
Why?"
[cpg cn=true]



The breasts are hitting each other. She's doing this on purpose, too.
[cpg]


[OnName num="kyoichi"]
"Are you doing this to anyone?"
[cpg cn=true]



[VOICE f="Izumi004"]
[OnName num="izumi"]
It's because you. Hmmm."
[cpg cn=true]


[SE f="se034"]
;//【ＳＥ】『胸を押しつける』
[WAIT time=1000]

Izumi presses her breasts against my arm.
[cpg]


[OnName num="gal"]
It started again. ...... Izumi, if you are so hungry for a man, you should go out with someone.
[cpg cn=true]



[VOICE f="Izumi005"]
[OnName num="izumi"]
You don't date because you're hungry. You don't understand."
[cpg cn=true]


He seems to have a unique sense of values. I was so excited to be involved in this.
[cpg]



;//ブラックアウト
;//[FADEOUTBGM]
;//[window target=false]
;//[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[free time=1]
;//[BG f="black.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
;//[WAIT time=1]
;//[BG f="b_06_3.ui" time=1]
;//[WAIT time=200]
;//[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
;//[WAIT time=1100]
;//[window target=true]
;//[WAIT time=100]
;//
;//[BGM f="bg_da"]
;//[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=1000]

By the time I got her off of me, I was breathing hard.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="shake_2"  pos="2/3" time=800]
[VOICE f="Izumi006"]
[OnName num="izumi"]
You're so embarrassed, it's adorable.
[cpg cn=true]


[OnName num="kyoichi"]
I'm not embarrassed. I mean, don't ever do anything like this again.
[cpg cn=true]


[FG f="CHA02_p3_01_a.ui" method="bow_1"  pos="2/3" time=800]
[VOICE f="Izumi007"]
[OnName num="izumi"]
I'll take good care of it. See you later.
[cpg cn=true]



[free time=1000]


I was walking backwards and waved at her.
[cpg]


I didn't wave back. Rather, I looked away.
[cpg]


I'm not used to girls. I'm not good at these things.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



I left the school and went back to my house.
[cpg]


I don't see any boys or girls walking next to me during that time. I don't have many friends.
[cpg]


But I had a tool to kill time forever.
[cpg]


As long as I had my phone, I thought I could endure my loneliness.
[cpg]


But what is it, this feeling of emptiness, where does it come from ......?
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



[OnName num="kyoichi"]
I'm home."
[cpg cn=true]


When I get home, I don't do things like fiddle with my phone at the dinner table.
[cpg]


Not that my parents are stopping me, but it's the least I can do.
[cpg]


My day is usually like this. On my days off, I have even more time on my hands.
[cpg]


But I have no desire to join club activities or anything like that.
[cpg]


[jump storage="ep001.ks" target="*start"]

