
*start

;//==============================
;//ヒロイン２の変数が３である場合

;#################################################
*Ep009|I want to mess up Izumi
;#################################################

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_d1"]
[WAIT time=100]

*root2_6|I want to mess up Izumi


[SCENE id=9]

[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


I wanted to mess Izumi up.
[cpg]


It's the same with everything I've ever done. I have chosen only the worst things.
[cpg]


Of course, Izumi is not averse to anything.
[cpg]


[OnName num="kyoichi"]
He said, "Let's go to ...... my house. Izumi."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Izumi292"]
[OnName num="izumi"]
"Oh, you're up for it, aren't you?　I'd like that.
[cpg cn=true]

;//＠


;//ブラックアウト
[SE f="se010"]
;//【ＳＥ】『歩く』
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then he comes to my room with Izumi.
[cpg]


I hypnotize her. There was no hesitation anymore.
[cpg]


;//移植のためシーンをカットしています

;//ブラックアウト
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hy"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


After that, I continued to hypnotize Izumi, who did not mind no matter what I did.
[cpg]

If I kept hypnotizing Izumi this many times, she might have a brain disorder.
[cpg]


As I kept repeating "break it and fix it," Izumi's personality began to change.
[cpg]



;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_d1"]
;//[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



Weekday. I was on my way to the school when I heard a whisper.
[cpg]


[OnName num="female_student_A"]
Hey, did you know that ...... Izumi-chan has been acting strangely lately?
[cpg cn=true]


[OnName num="female_student_B"]
Is that so?　I've never heard of her.
[cpg cn=true]


[OnName num="female_student_A"]
No, it's okay if you haven't heard about it. ...... Sorry.
[cpg cn=true]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園教室』（朝）******************************************************

[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』

[FG f="CHA02_p1_01_a.ui" method="change_8"  pos="2/3" time=800]


How funny. It was obvious if you looked at her in her everyday life.
[cpg]


She is mumbling something. The eyes are out of focus, even from a distance.
[cpg]


[FG f="CHA02_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Izumi312"]
[OnName num="izumi"]
"Oh, Senpai!　What are you doing for me today?
[cpg cn=true]


[FACE method="shake_6" pos="2/3"]
[VOICE f="Izumi313"]
[OnName num="izumi"]
It's ...... senpai, isn't it?　I'm not mistaken, am I?
[cpg cn=true]


It's a question that would never come up in a sane state of mind.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Izumi314"]
[OnName num="izumi"]
I've been having trouble distinguishing ...... between people lately," 
[cpg cn=true]


Her brain was clearly under the influence of hypnosis.
[cpg]


The mind is on the verge of a collapse. She got up from her seat and came toward me.
[cpg]


On the way, her legs got tangled and she was about to fall down.
[cpg]


If her head goes crazy, her body will not be able to move properly.
[cpg]


[OnName num="kyoichi"]
Yeah. It's me, and I'm gonna do it again today, so brace yourself."
[cpg cn=true]


[OnName num="kyoichi"]
'Besides, if all the guys look like me, you must be happy, right?
[cpg cn=true]


[FACE method="shock_2" pos="2/3"]
[VOICE f="Izumi315"]
[OnName num="izumi"]
"I'm so happy. ...... happy, senpai. ......
[cpg cn=true]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se



;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

It may not be unbearable for her, but ......
[cpg]


Still, the hypnosis rewrote the perception many times.
[cpg]


Izumi is breaking down. I enjoyed watching it.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_hy"]
;//[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



[FG f="CHA02_p1_01_a.ui" method="change_8"  pos="2/3" time=800]
[VOICE f="Izumi317"]
[OnName num="izumi"]
"Senpai...... senpai, senpai, senpai."
[cpg cn=true]



[SE f="se006"]
;//【ＳＥ】『クラクション』
[WAIT time=1000]


[FACE method="change_5" pos="2/3"]
[VOICE f="Izumi318"]
[OnName num="izumi"]
"...... what?"
[cpg cn=true]



[SE f="se005"]
;//【ＳＥ】『車のブレーキ音』



[window target=false]
[transition target={true} rule="bakuhatu.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="bakuhatu.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



...... her.
[cpg]


The news that Izumi was critically injured in a car accident arrived rather quickly.
[cpg]


I guess because Izumi's family knows about me.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hy"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



I went to visit Izumi.
[cpg]


It was a holiday. Other classmates might be there.
[cpg]


If not, I thought I would ...... do something for them.
[cpg]



;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



Izumi was asleep. He hadn't woken up for a long time.
[cpg]


The parents looked like they were tired of crying, so I put on a somewhat serious face and said this.
[cpg]


[OnName num="kyoichi"]
"...... can you let Izumi and I be alone together?"
[cpg cn=true]


Of course, this was an act. I said that to do what I wanted to do.
[cpg]


The hypnosis app said. I dream that I am dating Kyoichi.
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト
;//ブラックアウト

Using this may be cruel in a way.
[cpg]

Izumi will have a dream that is different from reality while she is unconscious.
[cpg]

In the first place, I don't even know if hypnosis will work on her while she is unconscious.
[cpg]

But ...... there was only one choice I could make.
[cpg]

I wanted to be present in her, even if it was only in a dream.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_sa"]
;//[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************



Time passed without her waking up.
[cpg]


In the beginning, her parents were with her all the time, but gradually they started to take turns.
[cpg]


And then we would be able to have a time when no one else was around. I thought even her not waking up would be material for exclusivity.
[cpg]




[window target=false]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************



The crazy relationship continues. Izumi's brain is being destroyed, and doctors say they can see it even if she never wakes up.
[cpg]


Even when the doctors examine him, they cannot figure out what is causing it. They could only conclude that some unknown force was keeping him dreaming.
[cpg]


Izumi's family is devastated, and her classmates come to visit her one by one.
[cpg]


I was the only one who knew the truth. Even Izumi doesn't know anything about it. ...... Our love affair continues.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
;//ブラックアウト

I know it's crazy. But in a way I can say that I am using hypnosis to its fullest.
[cpg]

Regrettably, the Izumi I see ...... is always asleep.
[cpg]

I wish I could go out with her in my dreams, but I would know it was a dream.
[cpg]

Then, only Izumi was dreaming, and this situation seemed to be the best.
[cpg]


;//ＥＮＤ：ヒロイン２ルート２
[SCENE id=16]
[jump storage="epend.ks" target="*start"]



;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
;//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

