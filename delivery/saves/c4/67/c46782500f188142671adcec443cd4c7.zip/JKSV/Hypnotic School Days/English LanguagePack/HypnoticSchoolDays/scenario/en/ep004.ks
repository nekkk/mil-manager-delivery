
*start

;//==============================
;//ヒロイン１の変数が最も多い場合

;#################################################
*Ep004|I want to use hypnosis on Yuna.
;#################################################

[stflag Cha1flg = 0]


[if exp={getFlagValue("Cha1flg") == 0 }]
[if exp={ isSystemFlagsEnabled( "sysflg3") }]
[stflag Cha1flg = 1]
[endif]
[endif]


[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[window target=true]

[BGM f="bg_sa"]
[WAIT time=100]

*root1|I want to use hypnosis on Yuna.


[SCENE id=4]


[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]

......It's Yuna after all.
[cpg]


The guy I've always wanted to be with. Izumi can do it whenever she wants to.
[cpg]


 Akari is also the same as long as there is a hypnosis app.
[cpg]


The first thing that came to mind when I thought about who I would make my first move on was Yuna's face.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（昼）******************************************************


[OnName num="kyoichi"]
"...... what?"
[cpg cn=true]

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1500]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[WAIT time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="1/3" time=800]
[WAIT time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[WAIT time=800]

Izumi, Akari, and Yuna were gathered around.
[cpg]


I tried to listen to them without Yuna noticing.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuna085"]
[OnName num="yuna"]
......It's true. You may not believe me, but I'm being threatened.
[cpg cn=true]


[FACE method="bow_2" pos="1/3"]
[VOICE f="Izumi071"]
[OnName num="izumi"]
I know. My senior did something similar to me."
[cpg cn=true]


[FACE method="change_1" pos="1/3"]
[VOICE f="sIzumi006"]
[OnName num="izumi"]
But he didn't do anything bad to you, did he?
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="sYuna005"]
[OnName num="yuna"]
Such as at ......, but..."
[cpg cn=true]


[FACE method="shake_1" pos="3/3"]
[VOICE f="Akari082"]
[OnName num="akari"]
I don't know of any such application,......, but I think Yuna should be more honest.
[cpg cn=true]


Even Akari has said that to me. What do you mean by "honestly"?
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



The next day at school, I approach Yuna at the end of class.
[cpg]


[OnName num="kyoichi"]
Yuna, are you free today?"
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuna087"]
[OnName num="yuna"]
'......I'm not free, but I can't go against what you say.
[cpg cn=true]


[OnName num="kyoichi"]
I know. Then, can I go to your house?
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuna088"]
[OnName num="yuna"]
"Yes,......, it's fine. You don't know where my house is, do you?
[cpg cn=true]


I don't know. But Yuna seemed to show me around with some hesitation.
[cpg]




;//ブラックアウト
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



It was as if she was hypnotizing me into her normal self.
[cpg]


She was forcing me to act. That gave me an indescribable sense of control.
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hy"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************



Yuna's room was somewhat girly.
[cpg]


She was knitting something small. It was placed there and some ...... stuffed animals.
[cpg]


[OnName num="kyoichi"]
'Did you knit the stuffed animals yourself too?
[cpg cn=true]


[FG f="CHA01_p3_01_a.ui" method="shake_7"  pos="2/3" time=800]
[VOICE f="Yuna089"]
[OnName num="yuna"]
No,...... such intricate stuffed animals are quirky."
[cpg cn=true]


I look at the hypnosis application situation. There were these words there.
[cpg]



;//■選択肢４
[switch]
[case "lose consciousness."]
	[swap]
	[jump target="*select04_1"]
[case "Can't be able to move your body"]
	[swap]
	[jump target="*select04_2"]
[endswitch]


1, lose consciousness.
2, Can't be able to move my body.



;//この選択肢で増加するのはヒロイン１の変数
;//１を選んだ場合変数は変わらない
;//２を選んだ場合変数が１増える



;//==============================
;//１、意識がなくなる
*select04_1|I want to use hypnosis on Yuna.

[system sysflg4=false]

;//移植のためシーンをカットしています

I decided to hypnotize her.
[cpg]

It's an orthodox one: she loses consciousness.
[cpg]

But it is enough to make her like me.
[cpg]

[OnName num="kyoichi"]
"Look at me. 
[cpg cn=true]


[FACE method="shock_8" pos="2/3"]
[VOICE f="sYuna006"]
[OnName num="yuna"]
Ugh. ......"
[cpg cn=true]

;//ブラックアウト

[SE f="se012"]
;//【ＳＥ】『衣擦れ』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



She immediately went slack-eyed and stopped moving.
[cpg]

But if she is unconscious, what does she remember doing?
[cpg]

I kind of ...... couldn't think of anything to do when I thought of that.
[cpg]


[jump target="*select04_4"]

;//==============================
;//２、体が動かなくなる
*select04_2|I want to use hypnosis on Yuna.

[stflag Cha1flg = 1]

[system sysflg4=true]


I decided to hypnotize her body to stop moving. Just to be sure, I show the screen to Yuna.
[cpg]


[FACE method="change_5" pos="2/3"]
[VOICE f="Yuna109"]
[OnName num="yuna"]
"Ugh ......, I can't move my body, what are you doing?
[cpg cn=true]


[OnName num="kyoichi"]
" "Now you can't resist anything they do to you.
[cpg cn=true]


Yuna is terrified. But I don't care.
[cpg]




;//ブラックアウト
;//========================================
;//●ＣＧ（仰向けで寝ているヒロイン。キスしようと近づく主人公）ev_14
;//人物１：ヒロイン１
;//服装１：制服
;//人物２：主人公
;//服装２：制服
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h2"]
;**【ＣＧ】 ev_14_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

I'm going to kiss her on her back.
[cpg]

She looks like she doesn't want to, but there's no need to stop.
[cpg]

It's up to me to do whatever I want. I guess she can't deny that.
[cpg]

Then, I bring my lips close to hers. They are close enough that my breath hits hers.
[cpg]

If she can speak, can she at least move her mouth?
[cpg]

If so, is it wrong to say that I can't resist anything?
[cpg]

If she bites me or something, I'll be in trouble. ...... No.
[cpg]

Then why don't I kiss her on the lips? I think so and move closer to her cheek.
[cpg]

There was no way Yuna would feel anything, but that was rather nice for me.
[cpg]


;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

Then I kiss her. I can feel her skin on my lips.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sYuna007"]
[OnName num="yuna"]
......"
[cpg cn=true]


Yuna stares at me. I can't say anything to her.
[cpg]


It's rather strange to say something kind here. I'm not her boyfriend.
[cpg]


You can force her to do so, but it doesn't mean she thinks of you the way she does now.
[cpg]




;//ブラックアウト

[jump target="*select04_4"]

;//==============================

*select04_4|I want to use hypnosis on Yuna.

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



I left Yuna's house ...... a little too hastily, I guess.
[cpg]


No, but I did what I could.
[cpg]


I don't even need to think about whether or not it's okay to do such a terrible thing.
[cpg]


I should not have, but my heart ached.
[cpg]



;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_da"]
;//[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



I returned to my house and wandered around the city at night.
[cpg]


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Izumi073"]
[OnName num="izumi"]
"Oh, senpai. We meet by chance, don't we?
[cpg cn=true]


[OnName num="kyoichi"]
"Izumi-ka? ......"
[cpg cn=true]


[FACE method="shake_7" pos="2/3"]
[VOICE f="sIzumi007"]
[OnName num="izumi"]
"Izumi, huh? Are you no longer interested in me?
[cpg cn=true]


;//しない。俺は百菜にターゲットを絞った。
I've targeted Yuna so I don't have to go after Izumi.
[cpg]


But ...... was that really the right thing to do?
[cpg]


Izumi wouldn't have minded doing anything. It would have been better that way.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Izumi075"]
[OnName num="izumi"]
I feel like you're having a hard time. If it's okay with me, I'll listen.
[cpg cn=true]


[OnName num="kyoichi"]
No, it's fine. ......
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************



[SE f="se010"]
;//【ＳＥ】『歩く』



The next day. I'm going to head to the school.
[cpg]


What should I say to Yuna when I see her? I threatened her with hypnosis.
[cpg]


I should apologize to her for that. No, it's not right to apologize.
[cpg]


I decided to do that, so it's not right. ......
[cpg]



;//ブラックアウト
;//[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//[BGM f="bg_da"]
;//[WAIT time=100]
;//【ＢＧ】『学園廊下』（朝）******************************************************

[SE f="se027" loop=true]
;//【ＳＥ】『学園の喧騒』

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Yuna149"]
[OnName num="yuna"]
Good morning, Kyoichi.
[cpg cn=true]


[OnName num="kyoichi"]
"...... Good morning."
[cpg cn=true]


Yuna was forcing herself to smile a little.
[cpg]


[OnName num="kyoichi"]
'...... the other day, you know...'
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Yuna150"]
[OnName num="yuna"]
"It's okay. I'm fine with anything you do to me, Kyoichi."
[cpg cn=true]


Yuna says something unexpected. Yuna turns to me in the hallway of the school, not knowing who is listening.
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Yuna151"]
[OnName num="yuna"]
I've thought about it since then. I couldn't say it for a long time, but when Akari told me ......, I was blown away."
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuna152"]
[OnName num="yuna"]
I love you.
[cpg cn=true]


[OnName num="kyoichi"]
"...... No way. You're lying to keep me from doing terrible things to you.
[cpg cn=true]


[FACE method="shake_1" pos="2/3"]
[VOICE f="Yuna153"]
[OnName num="yuna"]
I don't care how you take it. I just wanted to tell you how I feel.
[cpg cn=true]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『学園廊下』（昼）******************************************************



...... my heart was more or less shaken.
[cpg]


I had to look again at my power. For Yuna, I am hypnotizing her without erasing her memories.
[cpg]


In a way, they are worse than while erasing memories.
[cpg]


Besides,...... am I threatening someone who is thinking about me?
[cpg]


No, I don't even know if that confession is true.
[cpg]


Maybe it's a strategy to get me to relent.
[cpg]


What a thought, but I wasn't sure how I should treat Yuna.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_8"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園廊下』（夕方）******************************************************



After that, I did not stop hypnotizing Yuna.
[cpg]


Today, I decided to hypnotize her again to "fall in love with the person in front of her," that is, to fall in love with me, and leave her alone for the day.
[cpg]


[FACE method="shock_8" pos="2/3"]
[VOICE f="sYuna008"]
[OnName num="yuna"]
"Oh, ......, my head!
[cpg cn=true]


[OnName num="kyoichi"]
I'll see you later. You'll be writhing in agony all day tonight.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuna155"]
[OnName num="yuna"]
Oh, wait, ......!
[cpg cn=true]



I think he really likes me. That's why you don't cross me.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


I kept wondering. How should I answer?
[cpg]


I had never been liked by anyone. I didn't know how to respond.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（朝）******************************************************



The next day, Yuna came to me with a red face.
[cpg]


[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Yuna157"]
[OnName num="yuna"]
Ha, ha ...... Kyoichi, release the hypnosis. Please.
[cpg cn=true]


[OnName num="kyoichi"]
I understand.
[cpg cn=true]


I would release the hypnosis. I couldn't just take her somewhere here and do something.
[cpg]


It's half-assed. Would I continue to be half-assed all the time?
[cpg]


...... That's impossible. It's most unlikely.
[cpg]


Either I push her away or I respond to her feelings. I know it's one or the other.
[cpg]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

[SE f="se014"]
;//【ＳＥ】『学園のチャイム』



After class, in a different classroom from the one where I usually take classes.
[cpg]


I had called Yuna.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『学園教室』（夕方）******************************************************



[VOICE f="Yuna158"]
[OnName num="yuna"]
"...... What is it?　Are you going to hypnotize me again?"
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Yuna159"]
[OnName num="yuna"]
'I'm good. I'll accept it if you do it, Kyoichi.
[cpg cn=true]


I feel like I'm being tested.
[cpg]


 Maybe it's just a stepping stone to prevent him from doing something really cruel.
[cpg]


But I still thought it was good. I'm ......
[cpg]


[OnName num="kyoichi"]
I've always love you, too.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Yuna160"]
[OnName num="yuna"]
What ......?"
[cpg cn=true]


[OnName num="kyoichi"]
If you really like me, and I'm not lying or acting, then go out with me.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[OnName num="kyoichi"]
If you really don't want to, I won't force you anymore, so..."
[cpg cn=true]


The words are cut off there. So, what is it?
[cpg]


It doesn't mean that the past actions will be undone.
[cpg]


I knew that, but I couldn't help but say something.
[cpg]


[FACE method="shake_2" pos="2/3"]
[VOICE f="Yuna161"]
[OnName num="yuna"]
I'm fine with it. If you want to, Kyoichi, you can hypnotize me."
[cpg cn=true]


[OnName num="kyoichi"]
"...... that is..."
[cpg cn=true]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Yuna162"]
[OnName num="yuna"]
I'll go out with you. It's not a lie or an act. I've always loved you.
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
[VOICE f="Yuna163"]
[OnName num="yuna"]
I've always been timid about relationships. I'm so grateful to you for giving me the opportunity."
[cpg cn=true]




;//ブラックアウト
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]



And then... We really became lovers.
[cpg]



[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[OnName num="kyoichi"]
I can't believe I'm going out with Yuna. 
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Yuna164"]
[OnName num="yuna"]
I wanted to be with Kyoichi for a long time. 
[cpg cn=true]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuna165"]
[OnName num="yuna"]
I just ...... haven't forgotten what we did at first or anything, but..."
[cpg cn=true]

[FACE method="bows_2" pos="2/3"]

She says something a little bit spiky. This much can't be helped.
[cpg]


I've done things that I can't help but be told so too.
[cpg]

[FACE method="change_1" pos="2/3"]

On Saturday, we went on a date while walking around town. Her hobby seems to be knitting.
[cpg]


We went to a store that sells knitting supplies, went to buy a stuffed animal, 
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************



While we were doing these things, it was evening.
[cpg]


It was boring to do nothing, so I decided to try a little hypnosis.
[cpg]


She said it was okay for me to use it, too. She didn't really dislike it.
[cpg]


[OnName num="kyoichi"]
"Hey Yuna, look at me. Look at me.
[cpg cn=true]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Yuna166"]
[OnName num="yuna"]
What is it ......?　Ugh..."
[cpg cn=true]

[FACE method="change_8" pos="2/3"]
What I just applied was a hypnosis that "amplifies love".
[cpg]

[FACE method="change_6" pos="2/3"]
Yuna's face turns bright red. You can probably guess what I did.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="sYuna009"]
[OnName num="yuna"]
"Haa, haa...... this, I can't stand ...... this."
[cpg cn=true]


She was cuter than ever when she said that.
[cpg]

I followed her to her room.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_hy"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************



The hypnosis is still working on her. Now, what should I do?
[cpg]


She might not mind whatever I do. It's a matter of degree. ......
[cpg]


I release the hypnosis on her once in order to choose the hypnosis to be applied for the time being.
[cpg]


[FACE method="shock_4" pos="2/3"]
[VOICE f="Yuna169"]
[OnName num="yuna"]
"Ugh,...... and it finally subsides,...... hah, hah."
[cpg cn=true]


The hypnosis that can be selected now are "I will not be able to move my body" and "I will not be able to notice that I am kissing you".
[cpg]

Both are rather light, or rather hypnotic, so that Momona would not have to suffer.
[cpg]

I chose these two with these thoughts in mind.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="sYuna010"]
[OnName num="yuna"]
Ha, ha ...... what are you doing to me, Kyoichi?"
[cpg cn=true]


;//■選択肢５
[switch]
[case "body will stop moving."]
	[swap]
	[jump target="*select05_1"]
[case "You won't be able to notice that you are kissing."]
	[swap]
	[jump target="*select05_2"]
[endswitch]


One, body will stop moving.
2. You will not be able to notice that you are kissing.



;//この選択肢で増加するのはヒロイン１の変数
;//１を選んだ場合変数は変わらない
;//２を選んだ場合変数が１増える




;//==============================
;//１、体が動かなくなる
*select05_1|I want to use hypnosis on Yuna.

[system sysflg5=false]


[OnName num="kyoichi"]
"Then let's do this: ......
[cpg cn=true]


[FACE method="change_5" pos="2/3"]
[VOICE f="Yuna171"]
[OnName num="yuna"]
"Oh!　I can't move my body ......."
[cpg cn=true]


It's no longer a surprise to her, I suppose.
[cpg]

But he is blushing. He seems to have something on his mind.
[cpg]




;//========================================
;//●ＣＧ（座っているヒロイン。動けない）ev_16
;//人物１：ヒロイン１
;//服装１：私服（はだけ）
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_16_0 ***********************
[CG id=7 index=0 time=1000]
;***************************************
[WAIT time=1000]

;//移植のためシーンをカットしています

[VOICE f="sYuna011"]
[OnName num="yuna"]
What are you going to do?
[cpg cn=true]


I thought about what to do when she asked me.
[cpg]

[OnName num="kyoichi"]
I don't want to do anything. I'm just going to watch.
[cpg cn=true]


When I declared this, she turned red with embarrassment.
[cpg]

After all, the act of not doing anything might be stimulating for her.
[cpg]

I kept staring at her motionless for a while.
[cpg]

[OnName num="kyoichi"]
Her face is turning red.
[cpg cn=true]


;**【ＣＧ】 ev_16_a ***********************
[CG id=7 index=1 time=1]
;***************************************
[WAIT time=1]


Even if she didn't want to, she couldn't hide her face or look away.
[cpg]

That's the interesting thing about hypnosis.
[cpg]

I continued to stare at her, enjoying the moment.
[cpg]

[OnName num="kyoichi"]
She's cute.
[cpg cn=true]


She couldn't escape, so I didn't dare to do anything to her.
[cpg]

It was stimulating for both of us.
[cpg]

;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************


[OnName num="kyoichi"]
It's about time to get her out of it. ......
[cpg cn=true]


I decided to break the hypnosis on her.
[cpg]


[FACE method="shake_7" pos="2/3"]
[VOICE f="Yuna190"]
[OnName num="yuna"]
"That's strange, isn't it ......? It's hypnotic, isn't it?"
[cpg cn=true]


[OnName num="kyoichi"]
 "Yeah. You like it?"
[cpg cn=true]


[FACE method="change_6" pos="2/3"]
I asked her and she didn't deny it. I'll do it in the future. ......
[cpg]


[jump target="*select05_4"]

;//==============================
;//２、キスしていることに気づけなくなる
*select05_2|I want to use hypnosis on Yuna.

[stflag Cha1flg = 1]

[system sysflg5=true]


I decided to choose a slightly different kind of hypnosis.
[cpg]


What kind of way would it be?　I wondered if it would mean she wouldn't notice if I did something .......
[cpg]


[FACE method="change_7" pos="2/3"]
[VOICE f="Yuna192"]
[OnName num="yuna"]
"You won't do anything to me ......?　Kyoich-kun."
[cpg cn=true]


Saying that, Yuna tried to cover me.
[cpg]


[OnName num="kyoichi"]
'Yuna,......, what are you doing?'
[cpg cn=true]


I asked her, knowing to some extent what she was going to reply.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Yuna193"]
[OnName num="yuna"]
What do you mean ...... I'm not doing anything?"
[cpg cn=true]


I knew it. She doesn't know what she's doing.
[cpg]




;//ブラックアウト
;//========================================
;//●ＣＧ（主人公に馬乗りになるヒロイン）ev_17
;//人物１：ヒロイン１
;//服装１：裸
;//人物２：主人公
;//服装２：裸
;//場所　：ヒロイン１の部屋
;//時間　：夕方
;//========================================

[FADEOUTBGM]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]

[BGM f="bg_h1"]
;**【ＣＧ】 ev_17_0 ***********************
[CG id=8 index=0 time=1000]
;***************************************
[WAIT time=1000]

It is hypnosis that she is the one who pressured me to kiss her.
[cpg]

But she doesn't realize it.
[cpg]

It's a strange feeling. She looks at me as if nothing is wrong.
[cpg]

[VOICE f="sYuna012"]
[OnName num="yuna"]
What's wrong?
[cpg cn=true]


I involuntarily looked away.
[cpg]

[OnName num="kyoichi"]
No."
[cpg cn=true]


This kind of bizarre situation was good for me.
[cpg]

I waited for the kiss, repeating a reply that would not be recognized.
[cpg]

Her lips touch mine. The moment was indescribable.
[cpg]

I was intoxicated by the strangeness of hypnosis. ......
[cpg]


;//移植のためシーンをカットしています
;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

This would not have been possible without that app.
[cpg]

I don't even know who put it in, or who created it, but I was grateful to that person.
[cpg]

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sa"]
[WAIT time=100]
;//【ＢＧ】『ヒロイン１の部屋』（夕方）******************************************************



We flirted for a while after that.
[cpg]


When I released her hypnosis, she must have regained consciousness and was surprised at her unnoticed approach.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="sYuna013"]
[OnName num="yuna"]
'......Kyoichi-kun is so mean, isn't he?'
[cpg cn=true]


That's true. I don't need to deny it.
[cpg]

I won't even say it isn't true now, and even if I did, it wouldn't be convincing.
[cpg]



[jump target="*select05_4"]

;//==============================

*select05_4|I want to use hypnosis on Yuna.


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

We talked and laughed for a while after that.
[cpg]

Hypnotic, but not forced. We were enjoying the weirdness of the situation.
[cpg]



;//ブラックアウト

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_da"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************



By the time we left her house, it was nighttime.
[cpg]


There was some discussion about whether or not to have dinner, but I decided not to because it was bad and awkward.
[cpg]


......In hindsight, would it have been nice to do something naughty while you were eating ......?
[cpg]


No, I'm going to get angry again. It's a good thing I didn't do that.
[cpg]


[OnName num="kyoichi"]
"...... lover."
[cpg cn=true]


But still, I wonder what will happen to our relationship in the future.
[cpg]


Will they continue to be happy as lovers?
[cpg]


I could do something that would make her lose her affection for me, or I could play tricks on her with hypnosis.
[cpg]


Either way, it's still up to me. ......
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

;//今までの全ての選択肢でハードなものを選んでいる（変数が３になっている）かどうかで分岐


[if exp={getFlagValue("Cha1flg") == 3 }]
[jump target="*root1_6"]
[endif]



[jump storage="ep005.ks" target="*root1_5"]


*root1_6
[jump storage="ep006.ks" target="*root1_6"]

