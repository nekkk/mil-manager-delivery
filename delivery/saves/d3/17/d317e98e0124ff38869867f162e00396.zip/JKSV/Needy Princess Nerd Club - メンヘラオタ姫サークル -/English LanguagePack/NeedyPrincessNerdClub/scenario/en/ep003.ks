
*start|Signs of Disquiet

;#################################################
*Ep003|Signs of Disquiet
;#################################################

[SCENE id=3]

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

And then Saturday. The day of the date.
[cpg]

I brushed my teeth, shaved my beard, and dressed up as much as I could.
[cpg]

I figured that if she was putting in the effort, I should dress to match in my own way.
[cpg]

However, I'm not very good at dressing up in eccentric outfits, so I tried to keep it safe. ......
[cpg]

No, I don't know if this is a safe outfit.　I don't know, I've never bought a fashionable magazine or anything.
[cpg]

Then we had breakfast and left the house much earlier than the time we were supposed to gather.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

;//♪私服きわどい服
[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="natsuki"]
...... You're late, Kaoruko."
[cpg cn=true]

At the meeting place, Kaoruko did not come even though quite a bit of time had passed.
[cpg]

Time passed. When I was getting hungry, I spotted a figure that seemed to be Kaoruko in the distance.
[cpg]

However, the figure was not the same as that of ......
[cpg]

[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kaoruko226"]
[OnName num="kaoruko"]
"Sorry to keep you waiting, Natsuki-kun.
[cpg cn=true]

[OnName num="natsuki"]
Kaoruko ......?　Are you serious in that outfit?"
[cpg cn=true]

The outfit is quite revealing. It looks like she's taking it too far.
[cpg]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko227"]
[OnName num="kaoruko"]
I got molested and had to hand the molester over to the police and that's why I'm a little late.
[cpg cn=true]

I was about to say, "No, of course I'm going to be molested. ......," but I said, "No, no, no, I mustn't say that.
[cpg]

[OnName num="natsuki"]
I'm not going to say that," he said. That's unforgivable, that pervert ......."
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]

This is the correct answer. Kaoruko had dressed up so well.
[cpg]

[FACE method="change_1" pos="2/3"]
But still, it's too conspicuous, no matter how you think about it.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


While we were having lunch outside, I kept glancing at Kaoruko.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kaoruko228"]
[OnName num="kaoruko"]
Her gaze is so lecherous, Natsuki-kun. Hmm."
[cpg cn=true]

[OnName num="natsuki"]
'Sorry, I'm sorry .......'
[cpg cn=true]

Although I apologized, I have no right to apologize. Because everyone around me is also looking at Kaoruko.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kaoruko229"]
[OnName num="kaoruko"]
Maybe I'm a little too flashy with this outfit."
[cpg cn=true]

It's not fancy or anything, it's not flashy, it's just too distinguished.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

After lunch, we were in front of a game arcade near the university.
[cpg]

[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kaoruko230"]
[OnName num="kaoruko"]
I thought, "After all, as geeks, our date should be at the arcade, right?
[cpg cn=true]

[OnName num="natsuki"]
'Yes, that may be true, but ......
[cpg cn=true]

But," I said without thinking. Kaoruko picked up on that.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko231"]
[OnName num="kaoruko"]
But what?"　What's the problem?"
[cpg cn=true]

[OnName num="natsuki"]
Kaoruko picked up on that and said, "No, I'm fine. I'm fine. Let's go to the arcade.
[cpg cn=true]


;//ＢＫ


I think game arcades are basically places where people who are not interested in other people gather.
[cpg]

It's a lot better than walking around the mall. Maybe, just maybe.
[cpg]


;//ゲームセンター内なので、上下に黒帯をつけるなどして別の場所である演出をしてください


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）
;//【ＢＧ】『ゲームセンター』（昼）******************************************************

I thought so, but I was still naive. Kaoruko's desire for self-expression exceeded my expectations by a long shot.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko232"]
[OnName num="kaoruko"]
"Phew, I'm sweating good, this ......."
[cpg cn=true]

I already know that Kaoruko is good at music games. But I chose one of those dance game-like ......
[cpg]

She goes through the game in that outfit. As her boyfriend, I can't just watch.
[cpg]

If I listen carefully to my surroundings, I can hear things I don't want to hear.
[cpg]

I hear things like, "Is that woman asking me out?" or "It's probably okay if I take a video of her."
[cpg]

[OnName num="natsuki"]
No, please don't. Please don't film me, she's my girlfriend."
[cpg cn=true]

[OnName num="man"]
Oh, I'm sorry. ......"
[cpg cn=true]

But I can't follow up. Indeed, she is acting as if she is asking me to take a picture of her.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko233"]
[OnName num="kaoruko"]
"Hey there. How was it?"
[cpg cn=true]

[OnName num="natsuki"]
"Well, even if you ask me how it was,...... I'd say it's a little bit shabby in that outfit,......."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko234"]
[OnName num="kaoruko"]
"I'm not a fan of your work. I did it to show Natsuki-kun."
[cpg cn=true]

Probably a lie. She was going to show it to someone other than me, that's for sure.
[cpg]

Kaoruko chooses only game consoles that require her to move her body. ...... And even after that, Kaoruko chooses only game consoles that require her to move her body.
[cpg]

Air field hockey, games that imitated sports, and so on. She tries to play with me if she can play with both of us.
[cpg]

It seems that she wants me to watch her and her boyfriend who is also upset. I can't say anything if things get this complicated.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kaoruko235"]
[OnName num="kaoruko"]
I'm really sweating," she said.
[cpg cn=true]

I'm really sweating," she says, flapping her clothes. Stop it, really.
[cpg]

[OnName num="natsuki"]
'Let's not even ...... be too public .......'
[cpg cn=true]

There are even people who seem to follow us around a little bit every time we move.
[cpg]

That's how conspicuous we are. It's not good any more.
[cpg]

It's possible that we'll be on the Internet before we know it.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko236"]
[OnName num="kaoruko"]
I don't know. "I wonder if it's okay.
[cpg cn=true]

[OnName num="natsuki"]
That's not true. Be cool, Kaoruko.
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kaoruko237"]
[OnName num="kaoruko"]
"If you're going to go that far, I understand, but ......"
[cpg cn=true]

"I understand, but... I knew I was aware that I was acting abnormally.
[cpg]

[OnName num="natsuki"]
"Look, let's leave the arcade now,...... and we can have a date at home or something today.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko238"]
[OnName num="kaoruko"]
That's so boring. ...... Oh, that's right."
[cpg cn=true]

Kaoruko seemed to have another flash of inspiration. I could imagine that it was probably a bad flash of inspiration for me.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_h2"]

I was taken to a purikura corner. I have never been in a purikura corner in my entire life.
[cpg]

I thought I would never be able to enter such a place because it was usually for boys only, and only boyfriends were allowed there.
[cpg]

But now that I think about it, I wonder if it's OK for me as a boyfriend, as if I'm not a member of the community.
[cpg]

[OnName num="natsuki"]
"...... Kaoruko, have you ever taken purikura or something like that?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kaoruko239"]
[OnName num="kaoruko"]
I'm a geek, I'm not interested. I'm a nerd, I'm not interested.
[cpg cn=true]

[OnName num="natsuki"]
Then why are you here ......?
[cpg cn=true]

Then, I somehow noticed it.
[cpg]

The purikura is like a half-private room. I guess they are hidden by cloths, or maybe to keep the light out.
[cpg]

[FACE method="change_6" pos="2/3"]
[VOICE f="sKaoruko003"]
[OnName num="kaoruko"]
I'm only interested in you.
[cpg cn=true]

;//●ＣＧエロ（ヒロイン・プリクラ機内、際どい服装。背後から胸を揉んだりして愛撫：プリクラ機内）ev_10


[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_10_0 ***********************
[CG id=5 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]


Even on the plane, he was sticking close to me.
[cpg]

[VOICE f="sKaoruko004"]
[OnName num="kaoruko"]
Do you get nervous?
[cpg cn=true]


I'm thrilled, but in a double sense.
[cpg]

Not only because I'm flirting with her .......
[cpg]

This kind of thing is absolutely bizarre to those around us.
[cpg]


;//移植のためシーンをカットしています


;//ＢＫ
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]



And as soon as Kaoruko saw the finished photo, she said,
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="sKaoruko005"]
[OnName num="kaoruko"]
"...... is not a very good picture. It doesn't have enough lovey-dovey feeling.
[cpg cn=true]

I thought it was impossible, and I started to shiver. I was horrified, thinking that there was no way.
[cpg]


[FACE method="change_1" pos="2/3"]
[VOICE f="sKaoruko006"]
[OnName num="kaoruko"]
What do you think, Natsuki?
[cpg cn=true]

[OnName num="natsuki"]
What do you think?
[cpg cn=true]

I decided to resist as much as I could.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="sKaoruko007"]
[OnName num="kaoruko"]
I was so excited that I was shaking my head. I'm embarrassed.
[cpg cn=true]


[OnName num="natsuki"]
I'm so embarrassed."
[cpg cn=true]


She laughed at my dismay and pulled her hand away.
[cpg]

;//●ＣＧエロ（ヒロイン・プリクラ機内、際どい服装。バックの姿勢で挿入。避妊具使用：プリクラ機内）ev_11

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_11_0 ***********************
[CG id=6 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]


[VOICE f="sKaoruko008"]
[OnName num="kaoruko"]
Come on, come closer."
[cpg cn=true]


I can't do what she tells me to do.
[cpg]

Even from the outside, you can see her feet are getting closer.
[cpg]

[VOICE f="sKaoruko009"]
[OnName num="kaoruko"]
'What are you scared of?　No, I'm embarrassed?"
[cpg cn=true]


I never thought I'd do something like this. ......
[cpg]


;//移植のためシーンをカットしています

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="natsuki"]
'...... we're not going to do that kind of thing anymore, are we?'
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kaoruko282"]
[OnName num="kaoruko"]
I'm not sure I want to be a part of that.　I'm not sure how much I can take.
[cpg cn=true]

It's the same crap as sometime. It's true, that's exactly what it is.
[cpg]

[OnName num="natsuki"]
Don't tell me ...... Kaoruko gave you a ride."
[cpg cn=true]

Of course it wasn't time to break up yet when we left the arcade.
[cpg]

I was thinking that I should take her home as soon as possible, Kaoruko dressed like this, I can't expose her to the public eye for a long time .......
[cpg]

[OnName num="natsuki"]
It's about time you came over to my place."
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kaoruko283"]
[OnName num="kaoruko"]
'Umm, I think I'd like to look around a little more at different stores.
[cpg cn=true]

I understand what Kaoruko is trying to say. I know what Kaoruko is trying to say. She probably wants me to look at her outfit more.
[cpg]

I'm sure she also wants to show me that she has me next to her.
[cpg]

[OnName num="natsuki"]
I know what Kaoruko wants to say. "......No, but, you know, that outfit ......
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kaoruko284"]
[OnName num="kaoruko"]
What?　What's wrong with my outfit?"
[cpg cn=true]

Kaoruko was leading me on like this, as if it was funny to mention it.
[cpg]

I was so upset that I had to continue our date with her standing next to me, looking very uncomfortable.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オタクショップ』（昼）******************************************************

We continued on our way to a store that caters to otaku.
[cpg]

Kaoruko was sticking close to me while we were there, and she kept showing off that she was my boyfriend.
[cpg]

Everyone we passed looked at us suspiciously.
[cpg]

It was probably because of the way she was dressed, but it was probably directed at me, too, who was stuck to her.
[cpg]

[OnName num="natsuki"]
"...... Oh, you know what? Can you at least move away from me a little more?"
[cpg cn=true]

[FG f="CHA01_p3_02_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Kaoruko285"]
[OnName num="kaoruko"]
That's a terrible thing to say. You can't tell her to stay away from you. You don't get that line in a love game, do you?
[cpg cn=true]

[OnName num="natsuki"]
Maybe so, but ......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

I walked around in the store. I'd stop and bend over and say I want this, I want that, I want to read this, and I'd stop and bend over. ......
[cpg]

At that moment, you're totally seeing your pants. Other people are looking at me with all their might.
[cpg]

[OnName num="natsuki"]
"It's not good to be so conspicuous,...... more Kaoruko, you know, modesty,......
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Kaoruko286"]
[OnName num="kaoruko"]
Are you trying to say that I have no modesty?
[cpg cn=true]

No, I want to say it. I want to say it, but I think it was a gaffe too.
[cpg]

I'm not sure if I should have said that even if I had thought it. I thought so, and I took it back.
[cpg]

[OnName num="natsuki"]
No, no, it's nothing. ......
[cpg cn=true]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『オタクショップ』（昼）******************************************************


I continued to walk around the store. I saw a shadow that I had seen before.
[cpg]

[OnName num="shinjo"]
I was just looking around the store, and I saw a familiar shadow.
[cpg cn=true]

I'm not sure if I'm going to be able to do this. I'm not sure what to expect. This is pretty bad. I'm sure he hasn't noticed us yet, but if he does, it's the end for us.
[cpg]

From Shinjo-senpai's point of view, she was hiding behind the bookshelf, so I turn around and tell Kaoruko.
[cpg]

[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=800]
[WAIT time=1000]

[OnName num="natsuki"]
"......Shinjo-senpai is here."
[cpg cn=true]

[FACE method="change_5" pos="2/3"]
[VOICE f="Kaoruko287"]
[OnName num="kaoruko"]
"What ......, really?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]

Kaoruko was dismayed and didn't want to be found.
[cpg]

I'm sure Kaoruko doesn't like the fact that she can't stay in that circle either.
[cpg]

[OnName num="natsuki"]
Let's go our separate ways for once, if we act apart, they won't think we're dating."
[cpg cn=true]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kaoruko288"]
[OnName num="kaoruko"]
'Umm, yeah ...... maybe they'll think we met by chance.
[cpg cn=true]

Just when I thought we were going to break up for good, a large shadow stretched out from behind me,
[cpg]

Just when I thought we were going to break up for good, a large shadow stretched out from behind me. I turned around as quickly as I could,
[cpg]

[FACE method="change_5" pos="2/3"]

[OnName num="shinjo"]
......"
[cpg cn=true]

Shinjo-senpai was there. That meant he must have heard what I had been discussing with Kaoruko.
[cpg]

[OnName num="natsuki"]
"......"
[cpg cn=true]

Shinjo-senpai remained silent and said nothing. We didn't say anything either.
[cpg]

Shinjo-senpai then left the place with a straight face. It would not mean that he would keep quiet to everyone in the circle.
[cpg]

[OnName num="natsuki"]
'Do, what should I do ......'
[cpg cn=true]

I turned back to Kaoruko again. Kaoruko's face was pale, but I think it was probably mutual.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko289"]
[OnName num="kaoruko"]
"...... is it my fault or ......?
[cpg cn=true]

[OnName num="natsuki"]
Now is not the time to be thinking about whose fault it is.
[cpg cn=true]

Instead, it's time to think about what will happen in the future. It's time to think about what's going to happen.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="natsuki"]
We may not be able to stay in the circle.
[cpg cn=true]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Kaoruko290"]
[OnName num="kaoruko"]
Oh, no. ......
[cpg cn=true]

[OnName num="natsuki"]
But it's the worst case ...... that I can think of, or rather, the most likely case.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
Is it bad because Kaoruko came dressed fancy? Is it wrong because Kaoruko is sticking to me?
[cpg]

I think about it. Thinking about it, I headed home.
[cpg]

Kaoruko no longer said anything about wanting to walk around town.
[cpg]

[OnName num="natsuki"]
"I'm going back home. ...... is okay, Kaoruko?
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko291"]
[OnName num="kaoruko"]
......Yes."
[cpg cn=true]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

When I returned to my room, Kaoruko sat on her knees and apologized to me.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko292"]
[OnName num="kaoruko"]
I'm sorry ...... that even Natsuki-kun might not be able to stay in the circle because of me.
[cpg cn=true]

[OnName num="natsuki"]
Kaoruko said, "...... No, Kaoruko is not to blame."
[cpg cn=true]

I've been doing a lot of thinking since then. Kaoruko got carried away and dressed like that, which I could have warned her about.
[cpg]

The reason for this is that I was too timid and didn't want to be a part of it. I am a petty person, and I brought this on myself.
[cpg]

[OnName num="natsuki"]
I should have been more careful. ......
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kaoruko293"]
[OnName num="kaoruko"]
But I know myself that I look funny like this.
[cpg cn=true]


[VOICE f="Kaoruko294"]
[OnName num="kaoruko"]
Still, I wanted Natsuki-kun to think I was cute. ......
[cpg cn=true]

Maybe that's a lie. I think the truth is that I just want to show it off to other people.
[cpg]

But I still love Kaoruko. She's my only girlfriend.
[cpg]

[OnName num="natsuki"]
You don't have to tell me anymore. Kaoruko didn't do anything wrong.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
He defended her. Then, Kaoruko started crying.
[cpg]

[OnName num="natsuki"]
Kaoruko!　What's wrong, did I say something weird?
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kaoruko295"]
[OnName num="kaoruko"]
"You're so kind, Natsuki-kun. ...... I'm so happy."
[cpg cn=true]

They said they were tears of joy. She was smiling and spilling tears in a dribble.
[cpg]

It's not normal. It was kind of scary. I instinctively wanted to run away.
[cpg]

I backed away from her while sitting down without thinking, and Kaoruko pushed me even harder.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kaoruko296"]
[OnName num="kaoruko"]
I'm happy to have met Natsuki-kun. I wonder if it's okay for me to be this happy.
[cpg cn=true]

What she said was normal. Or rather, I should be happy with what I'm saying.
[cpg]

But there is a glimpse of madness on his face. It's as if she wants to take me and eat me.
[cpg]

[OnName num="natsuki"]
Kaoruko?　What's wrong with your face?
[cpg cn=true]

I was kissed just like that.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


I was beginning to wonder if I could handle Kaoruko's boyfriend.
[cpg]

I have a lot of emotional ups and downs,...... no, not quite.
[cpg]

I can't think of a good word for it, but I'm sure he's a geek just like me.
[cpg]

If that's the case, I guess that means we're a perfect couple ......?
[cpg]


[SE f="se037"]
;//【ＳＥ】『ドア閉まる』

[window target=false]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

After that, we both went shopping for dinner.
[cpg]

I didn't think it would be right to walk next to Kaoruko dressed like this, but I figured it was better than leaving her alone in my room.
[cpg]

Then I was scared of her, so much so that I thought, "I don't know what I'm going to ...... do.
[cpg]

[OnName num="natsuki"]
I thought to myself, "...... what shall we have for dinner? I cook for myself too, so I can help."
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kaoruko300"]
[OnName num="kaoruko"]
She said, "Well, I don't know. How about a hamburger steak?　It's my specialty.
[cpg cn=true]

She seems like a normal girl now. How did she change so drastically?
[cpg]

I wonder if she flips an emotional switch once in a while and can't control it herself.
[cpg]

That would explain the Purikura incident, though. ......
[cpg]

Thinking about this, I went to the supermarket to buy ingredients for hamburgers.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


The ingredients for hamburgers are something that even someone who has never made hamburgers can imagine.
[cpg]

We agreed on most of the ingredients, and the shopping went smoothly.
[cpg]

Then back to my room again......
[cpg]




[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko301"]
[OnName num="kaoruko"]
I can do it on my own. I can do it on my own."
[cpg cn=true]

[OnName num="natsuki"]
"...... so?　Well then, feel free to ......"
[cpg cn=true]

[free time=1000]
[WAIT time=1000]

But I wondered if I should leave it up to her. I wondered if she would put anything strange in it.
[cpg]

In fact, she didn't, and we had a normal meal, and we finished our meal as normal. ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_02_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

;//裸？私服？

After we both had our fill and showered, Kaoruko's eyes were funny again.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Kaoruko302"]
[OnName num="kaoruko"]
'...... thank you so much for covering for me.'
[cpg cn=true]

[OnName num="natsuki"]
'Hey, what are you talking ...... about?"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko303"]
[OnName num="kaoruko"]
She was so happy to hear that. I was very happy about that.
[cpg cn=true]

I kind of understand that. I know that for her, things like being told that you are not bad, or being praised, are more important than anything else.
[cpg]

But the way she changed was scary. And should I tell her that now?
[cpg]

[OnName num="natsuki"]
"...... You know, Kaoruko..."
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Kaoruko304"]
[OnName num="kaoruko"]
What?　Natsuki-kun,......, I might listen to anything you say right now.
[cpg cn=true]

That being said, I was tempted to say things like, "Don't wear those clothes anymore," or "I'm afraid you'll change into a leopard," but I didn't.
[cpg]

[OnName num="natsuki"]
I like you ......."
[cpg cn=true]

The fact that the two of them are not in the same room together is a good sign that they are not in the same room together.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kaoruko305"]
[OnName num="kaoruko"]
I love you, too. I love you, Natsuki-kun. I love you so much, I feel like I'm going to lose control.
[cpg cn=true]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


That is what happened that night.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Kaoruko fell asleep first, so I was alone with my thoughts.
[cpg]

I wondered what would happen to ...... from now on. Shinjo-senpai totally saw me, right?
[cpg]

I thought about that as I stroked Kaoruko's head as she slept next to me.
[cpg]

It's not good if I don't do anything. ......
[cpg]

[OnName num="natsuki"]
......Ugh."
[cpg cn=true]

I casually picked up my cell phone and saw that I had been called repeatedly in the group chat.
[cpg]

All three of us are calling me. That means Shinjo-senpai has already told the other two by other means.
[cpg]

I was not sure what to do.
[cpg]

[OnName num="natsuki"]
I don't know what to do.
[cpg cn=true]

There's nothing we can do. It's not good if things continue as they are. But there is nothing I can do.
[cpg]

I went to sleep thinking, "I'll go to the clubroom tomorrow and apologize to them.
[cpg]



[jump storage="ep004.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

