;//==============================
;//ルート６
*route6|I'll always be a princess.

*start|I'll always be a princess.

;#################################################
*Ep012|I'll always be a princess.
;#################################################

[SCENE id=12]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

;//♪二人

Since then, the atmosphere in the ...... circle's club room was changing.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="gal_B"]
I was like, "Wow, they sell DVDs in a box these days. I didn't know they sold DVDs in boxes these days."
[cpg cn=true]

[OnName num="kimoto"]
"It's not a DVD, that it is, it's a BD."
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[OnName num="gal_B"]
"BD? What is that?"
[cpg cn=true]

The boys were caged up by Yui and her friends. Gradually, Kaoruko lost her place.
[cpg]

There, Kaoruko made her way to Tokusawa-senpai with a determined look on her face.
[cpg]

[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Kaoruko1281"]
[OnName num="kaoruko"]
Um, ......, can I have a word?
[cpg cn=true]

[OnName num="tokuzawa"]
Oh, yeah. What, you look serious. ......"
[cpg cn=true]

Kaoruko then handed the withdrawal form to Tokusawa-senpai.
[cpg]

[OnName num="tokuzawa"]
"...... withdrawal form ......?"
[cpg cn=true]

[free time=300]

[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[OnName num="gal_A"]
"Ah? I'm going to quit, circle"
[cpg cn=true]

[OnName num="gal_C"]
"Seriously? Well, don't stay here."
[cpg cn=true]

[OnName num="gal_D"]
I'm super sad that we didn't get to know each other better."
[cpg cn=true]

Yui and the others are teasing Kaoruko. But Kaoruko seems to be serious.
[cpg]

[OnName num="shinjo"]
"Ho, do you really quit? I'm lonely, Bufu"
[cpg cn=true]

[OnName num="tokuzawa"]
......I feel the same way, Kaoruko-chan."
[cpg cn=true]

[OnName num="kimoto"]
"I'll ask you again, but are you serious? Kaorukoden"
[cpg cn=true]

[FACE method="bow_4" pos="2/5"]
[VOICE f="Kaoruko1282"]
[OnName num="kaoruko"]
Yeah,...... even now, they don't call me Princess."
[cpg cn=true]

[OnName num="kimoto"]
That's ......."
[cpg cn=true]

[OnName num="tokuzawa"]
"It's just a story that has changed?
[cpg cn=true]

Tokusawa senpai follows up, but somewhat non-seriously.
[cpg]

It doesn't look like they are really trying to stop it.
[cpg]

[FACE method="shake_1" pos="2/5"]
[VOICE f="Kaoruko1283"]
[OnName num="kaoruko"]
"Isn't everyone a princess anymore? So, because I have no place to be."
[cpg cn=true]

Kaoruko is apparently serious. I think if I quit this circle, that would be the end of my place.
[cpg]

[OnName num="shinjo"]
"Oh, I have to be a princess? But I feel like I'm going as a member ..."
[cpg cn=true]

[FACE method="shake_1" pos="2/5"]

Kaoruko shakes her head. And,
[cpg]

[FACE method="change_3" pos="2/5"]
[VOICE f="Kaoruko1284"]
[OnName num="kaoruko"]
I don't have any more regrets. I have no more regrets.
[cpg cn=true]

After declaring, he said something a bit unheard of.
[cpg]

[FACE method="change_2" pos="2/5"]
[VOICE f="Kaoruko1285"]
[OnName num="kaoruko"]
From now on, I ...... will continue to love Natsuki-kun single-mindedly.
[cpg cn=true]

[OnName num="natsuki"]
Eh."
[cpg cn=true]

[OnName num="tokuzawa"]
"... Is that so? Well, is it okay? Sugiura"
[cpg cn=true]

I was taken aback when the topic was suddenly brought up. But, well, that's what we're talking about.
[cpg]

Perhaps the only thing she can be proud of now is that she has a boyfriend.
[cpg]

[OnName num="natsuki"]
"...... yes ......"
[cpg cn=true]

Am I going to take on Kaoruko by myself? I thought it was a bit of a burden.
[cpg]

Because remember, once I was pampered by the boys, will they be satisfied with me alone ......?
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

On the way home at dusk. I ask a question.
[cpg]



[FACE method="change_4" pos="2/3"]
Kaoruko was next to me. She doesn't look as if she's relieved to be out of the circle.
[cpg]

It's a look that is rather unfulfilled.
[cpg]

[OnName num="natsuki"]
......Really, that was the right thing to do?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko1286"]
[OnName num="kaoruko"]
Because it's just not comfortable to stay like that. ......
[cpg cn=true]

[OnName num="natsuki"]
I don't know. People may not have treated me like a princess, but they didn't reject me."
[cpg cn=true]

[OnName num="natsuki"]
I think even Tokusawa-senpai and Shinjo-senpai ...... Kimoto would have been disappointed."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
Kaoruko shakes her head. Then she turns over.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko1287"]
[OnName num="kaoruko"]
You didn't try very hard to hold me back, did you?"
[cpg cn=true]

[OnName num="natsuki"]
That may be true." But ......"
[cpg cn=true]

Kaoruko interrupts me as I continue to speak and starts talking.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko1288"]
[OnName num="kaoruko"]
'Proof that I'm no longer a princess. More importantly, ......"
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kaoruko1289"]
[OnName num="kaoruko"]
"Can I go to Natsuki-kun's house ...... today?"
[cpg cn=true]

I see. You must be so lonely. Kaoruko must be going through a tough time.
[cpg]

It must have been hard for you to have been born with a personality that needs others so much.
[cpg]

[OnName num="natsuki"]
I like ......."
[cpg cn=true]




;//ＢＫ
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『大学教室』（昼）******************************************************

Another day, during a lecture at the university. Kaoruko is next to me.
[cpg]

Kaoruko, of course, is not happy. The reason, of course, is that she has lost three Otasa boys.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko1325"]
[OnName num="kaoruko"]
"......I'll build another geekery from scratch. ......"
[cpg cn=true]

She mumbled something to me. I've come to know most of Kaoruko's personality, so it wasn't something to get so angry about.
[cpg]

[OnName num="natsuki"]
Haha ...... great thing to say, Kaoruko too."
[cpg cn=true]

From Kaoruko's expression, it seems she is serious. So, I responded in earnest, too.
[cpg]

[OnName num="natsuki"]
It's no use. As long as Yui-san and the others see me as an enemy, they'll follow me around, probably."
[cpg cn=true]

I'm not saying anything mean. In fact, I'm just saying what I think will happen.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko1326"]
[OnName num="kaoruko"]
I know, ...... what am I supposed to do ...... I didn't do anything wrong."
[cpg cn=true]

Nothing wrong with that, not bad? I wonder, and I feel a twinge in my words. ......
[cpg]

Our girlfriend relationship continues. Nerd boyfriend and nerd girlfriend, no problems.
[cpg]

Except only for the bottomless loneliness in Kaoruko: ......
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kaoruko1327"]
[OnName num="kaoruko"]
Hey, Natsuki-kun.
[cpg cn=true]

Even though I was in the middle of a lecture, he kept talking to me. I responded in a whisper.
[cpg]

[OnName num="natsuki"]
What ......?"
[cpg cn=true]

He does not look back at Kaoruko, but looks forward and listens to what she has to say.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kaoruko1328"]
[OnName num="kaoruko"]
Suppose," he said, "Suppose, suppose. Suppose Natsuki-kun gets really lonely and I'm not enough for him."
[cpg cn=true]

If, I mean, that's Kaoruko's current state of mind. Just by switching genders.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kaoruko1329"]
[OnName num="kaoruko"]
Then do you go to cabarets and that kind of thing?"
[cpg cn=true]

The topic was so out of the blue that I almost blew it. I hold it in and reply.
[cpg]

[OnName num="natsuki"]
"I guess I'm not that old yet, I'm ......"
[cpg cn=true]

I think I could have given a straight answer. And yet, Kaoruko sounded depressed,
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko1330"]
[OnName num="kaoruko"]
I see. ...... Maybe so."
[cpg cn=true]

Finally, he muttered.
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



I had sensed a bad feeling from this conversation.
[cpg]

I knew that the loneliness was beyond critical for her. There was no way she would do nothing.
[cpg]

And my hunch was right. One day Kaoruko started begging me for money.
[cpg]

And it's a lot of money. It's a little bit more than I can afford.
[cpg]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（夕方）******************************************************

[OnName num="natsuki"]
......What would you spend that much money on?"
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
[VOICE f="Kaoruko1331"]
[OnName num="kaoruko"]
"It's geek stuff, there's some stuff I can't wait to buy. ...... it's true."
[cpg cn=true]

Well. I know geeky hobbies are expensive. But there is a limit.
[cpg]

[OnName num="natsuki"]
I see. ...... that seems like too much forehead for that."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
Kaoruko looked a bit nervous and stayed that way,
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Kaoruko1332"]
[OnName num="kaoruko"]
"Do you doubt me, ......?"
[cpg cn=true]

He said. I guess he meant, "Don't doubt me.
[cpg]

[OnName num="natsuki"]
A little bit, but if you ask me to believe you, I might believe you. But if you ask me to believe you, I might."
[cpg cn=true]

If you had asked me to believe you here, I might have believed you. But...
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko1333"]
[OnName num="kaoruko"]
"...... it's that ......"
[cpg cn=true]

All she did was mumble. She didn't say, "Trust me.
[cpg]

[OnName num="natsuki"]
I understand. I'll lend it to you this time, so take good care of it."
[cpg cn=true]

I decided to follow her around a bit.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

I had a rough idea. You mentioned something about a cabaret club.
[cpg]

I went where she was likely to head.
[cpg]

Then Kaoruko saw him enter the ...... host club after checking his surroundings.
[cpg]

[OnName num="natsuki"]
"...... that's serious ......"
[cpg cn=true]

I knew that's what I was thinking ......, but I thought I'd have to ask Kaoruko about it later.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Now, what should I do? How should I go out with Kaoruko from now on?
[cpg]

Or rather, am I really accompanied by that child for a lifetime? Isn't that pretty difficult?
[cpg]

If she were to grow up with that personality, I think it would be pretty tough.
[cpg]

I know you may think it's rude or something that would be degrading to her, but ......
[cpg]

But you lied to me and cheated me out of my money. This much, I'm willing to think.
[cpg]

[OnName num="natsuki"]
Haaah. ......."
[cpg cn=true]

I'm in a terrible situation. How am I going to tell Kaoruko about this?
[cpg]

Don't push her. I need to make it so that she will apologize to me.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（昼）******************************************************

So, another day. A little time between lectures.
[cpg]

[OnName num="natsuki"]
You know, Kaoruko ...... said Kaoruko only likes me or something, but that's a lie."
[cpg cn=true]

I cut him off like this. I'm not jealous, but I am somewhat angry because he lied to me about how he spent the money.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kaoruko1334"]
[OnName num="kaoruko"]
He said, "E...... that's not true. Really, I only like Natsuki-kun."
[cpg cn=true]

Kaoruko shuts her mouth. Well, maybe she meant what she said. But...
[cpg]

[OnName num="natsuki"]
I saw you walk into a host club the other day.
[cpg cn=true]

[OnName num="natsuki"]
'If you only liked me, I don't think you'd go into a place like that.'
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Kaoruko1335"]
[OnName num="kaoruko"]
"Nah, ......, uh, it's, it's such a ......"
[cpg cn=true]

Kaoruko was extremely upset. I had imagined that she would apologize to me with great vigor afterwards,
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko1336"]
[OnName num="kaoruko"]
'That's terrible ...... why would you lie like that!'
[cpg cn=true]

Quite different from what I imagined. So it was.
[cpg]

Well, it's not unexpected, is it? If it is Kaoruko's usual rush.
[cpg]

[OnName num="natsuki"]
What do you mean, "...... lies?"
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko1337"]
[OnName num="kaoruko"]
I will never fall in love with anyone other than Natsuki-kun.
[cpg cn=true]

That's right. I think that's true. But you even deny that you go to host clubs.
[cpg]

[OnName num="natsuki"]
So I must have been mistaken when I walked into that host club?"
[cpg cn=true]

In the meantime, final confirmation. If you keep lying to me here, I'll think about it.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko1338"]
[OnName num="kaoruko"]
"It's not a mistake, but Natsuki -kun is given up!? I did something wrong!? This is too much."
[cpg cn=true]

[OnName num="natsuki"]
"Did you make that up at ......? If so, I'm a pretty terrible guy."
[cpg cn=true]

Kaoruko is in a hurry and tries desperately to defend her position. Even though she can't help lying to me like this.
[cpg]

I wonder. Can I really continue to have this girl as my girlfriend?
[cpg]

I'm finally starting to grow tired of the love. How can I continue to be a boyfriend to protect this girl's self-esteem?
[cpg]

The two words "...... tide time" flicker in my mind.
[cpg]

[OnName num="natsuki"]
I get it. Then I must have looked at it wrong. Is that all right?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
Kaoruko made an angry expression on her face and said to me.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko1339"]
[OnName num="kaoruko"]
...... of course, right?"
[cpg cn=true]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]

That day was the beginning.
[cpg]

Gradually, I began to cross paths with Kaoruko.
[cpg]

Kaoruko went to a host club. I guess she's getting pampered there, she doesn't need me anymore.
[cpg]

Then I went to my old circle and then to Yui-san. This is also becoming less and less necessary for Kaoruko.
[cpg]

I wonder how Kaoruko continues to go to the host. I wonder if her parents sent her more money.
[cpg]

Whatever the case, they each find another place to fit in, and because of this, they meet less and less often.
[cpg]

We even passed each other in the hallway without even saying hello.
[cpg]



[window target=false]
[free time=1]
[BG f="b_00_1.ui" time=1000]
[WAIT time=2500]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（朝）******************************************************

Months and days pass. Years pass.
[cpg]

It was too easy. This is how close we were.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（夕方）******************************************************

By the time I graduated from college, our relationship had spontaneously dissolved.
[cpg]

As it was, they would become complete strangers after graduation.
[cpg]

I think it is a natural result. It is a result that I brought about, and it is also a result that Kaoruko brought about.
[cpg]

It's not anyone's fault. ...... It's not anyone's loss, so this is fine.
[cpg]



;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


What worries me, however, is what kind of life she will lead in the future.
[cpg]

I hope someone nice will take care of her: ......
[cpg]

No, is it rude to take care? whatever.
[cpg]

Either way, he's no longer relevant to me.
[cpg]


;//薫子に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


I worked for ...... after I graduated from college.
[cpg]

There is only one reason for this. Of course, there's also the fact that it's to eat our daily food.
[cpg]

Mostly, to go to host clubs. To pay tribute.
[cpg]

Almost all of my income disappears into it. I think I'm out of my mind.
[cpg]

It was a general company with good conditions there, but it was still somewhat disconnected from the general population.
[cpg]

Because I'm a nerd. Maybe we're nerds and that's why we eat differently.
[cpg]

I had to realize that geeks like me are a race of people who are all but few and far between.
[cpg]

And nerdiness was not something I could outgrow as an adult.
[cpg]

Time passes. My body was getting older and older, I was getting impatient, and I kept regretting the loss of Natsuki-kun.
[cpg]

I think he was a really cool guy. I think he understood me.
[cpg]

Why did I lie at that time? It's too late for everything now.
[cpg]

I wonder how Natsuki is doing now. I wonder if he will remember me when he sees my face.
[cpg]

Maybe he's also married to a girl named Yui or something: ......
[cpg]

I don't want to. I don't want to imagine it. I don't want to think that I can't go back.
[cpg]

The thought of it gives me goosebumps. Can someone please help me: ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

Months and days pass. Years pass.
[cpg]

Frighteningly, quickly. Time passed at a dizzying pace as I faced the work in front of me.
[cpg]

I remained single and went so far as to be called not just arafi, but arafi.
[cpg]

The freshness of my skin is long gone, and I can't get back to those days in any way.
[cpg]

No one pampers me anymore. I don't have that youth anymore.
[cpg]

I hate people who are getting that young right now.
[cpg]

When he sees the young kids being pampered in the company, he envies them.
[cpg]

I, too, have had times of being adored. Why does time take away everything?
[cpg]

I tried to imitate the young kids, ...... striking poses and using young people's language. And then,
[cpg]

[OnName num="male_employee"]
What's that? What is that? You look like a princess.
[cpg cn=true]

I was thrilled. For a brief moment, my college days came back to me.
[cpg]

I haven't been to ...... in years. She called me a princess.
[cpg]

That's right. I still have to live as a princess. No matter how old I get.
[cpg]

So I lived that way from then on.
[cpg]

Obsessed with cuteness, obsessed with youth, they imitated it and lived with it.
[cpg]

I don't care if it's called bad publicity. I tried to remain a princess forever.
[cpg]

The aging body pretends not to see. I can no longer bear to look directly at it.
[cpg]

[OnName num="female_employee"]
'This is why the princess is so pretty today!
[cpg cn=true]

Today, someone calls me Princess. That's all I needed.
[cpg]

I don't care if it's all sarcasm. I don't care if people look at me like I'm weird.
[cpg]

...... thus.
[cpg]

Thus, I was reborn from the princess of Otasa to the princess of the hot water room. ......
[cpg]

[SCENE id=18]

[jump storage="epend.ks" target="*start"]
;//【ルート６】エンド
