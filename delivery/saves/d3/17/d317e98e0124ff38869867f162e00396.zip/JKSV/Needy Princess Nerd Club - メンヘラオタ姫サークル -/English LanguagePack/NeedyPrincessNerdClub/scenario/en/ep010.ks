;//==============================
;//ルート４
*route4|A New Place to Live

*start|A New Place to Live

;#################################################
*Ep010|A New Place to Live
;#################################################

[SCENE id=10]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（昼）******************************************************

After that, our club room became more and more caged in.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[OnName num="gal_A"]
You guys always look so gloomy. And you're always hunched over.
[cpg cn=true]

[OnName num="natsuki"]
My bad. ...... Isn't that what being a geek is all about?"
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[OnName num="gal_A"]
Yeah, it's okay. That's what's funny and cute."
[cpg cn=true]

[free time=1000]

Yui and her friends began to frequent the place, and the cross-cultural exchange between otaku and gals progressed.
[cpg]

[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[OnName num="gal_B"]
"Oh, that band sings anime songs?"
[cpg cn=true]

[OnName num="kimoto"]
"Don't you know? It's quite famous for geeks."
[cpg cn=true]

[FACE method="bow_1" pos="2/5"]
[OnName num="gal_A"]
"Is that serious? There are fans in a surprising place."
[cpg cn=true]

[FACE method="shake_1" pos="4/5"]
[OnName num="gal_B"]
I'm like, "Oh my god. It's not like we listen to the same music or anything. ......"
[cpg cn=true]

[OnName num="kimoto"]
"What is it, that you don't mind what I ask?"
[cpg cn=true]

[FACE method="bow_2" pos="2/5"]
[OnName num="gal_A"]
"Sure, sure, sure. I'm glad we have a connection."
[cpg cn=true]

[free time=1000]


Yes, there is a connection, an unexpected one.
[cpg]

Nowadays, it seems that not all gals read manga either.
[cpg]

[OnName num="tokuzawa"]
Oh, I've heard of that cartoon: ......"
[cpg cn=true]

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="gal_A"]
I see you know. Your pictures are so cute."
[cpg cn=true]

[OnName num="tokuzawa"]
I didn't know gals read manga. I thought they didn't read at all."
[cpg cn=true]

[OnName num="gal_C"]
I don't know if I'll ever read it. But if I'm asked to read it, I will."
[cpg cn=true]

[OnName num="shinjo"]
Well, then I have a recommendation for you: ......."
[cpg cn=true]

Shinjo-senpai brought up a manga that was quite gruesome and particularly male-oriented among otaku.
[cpg]

[OnName num="shinjo"]
Bwah, hoo, this is hilarious. I have all the volumes, please visit ......"
[cpg cn=true]

[OnName num="gal_C"]
"Ha-ha-ha-ha, nerds are so funny, where does all that enthusiasm really come from?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[OnName num="gal_A"]
I know, right? If I were in the opposite position, I wouldn't recommend it.
[cpg cn=true]

[OnName num="shinjo"]
"Is that so? What do you think of Sugiura?"
[cpg cn=true]

[OnName num="natsuki"]
"...... it's, uh, ......"
[cpg cn=true]

I couldn't answer, "I think it's very congenial.
[cpg]

I wonder what Kaoruko would think if she saw this situation.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

And as I came into contact with Yui and the others, I gradually began to treat Kaoruko in a more and more lenient manner.
[cpg]

Even today, when Kaoruko walks in and says "Hi," I only get a "Hello" in return.
[cpg]

Even though she is treated roughly, she is treated as well as one girl can be treated, but that is not enough for Kaoruko.
[cpg]

[OnName num="kimoto"]
Kaoruko-dono, have you lost weight recently, that you have?"
[cpg cn=true]

For example, Kimoto refers to Kaoruko as Kaoruko-dono. The person he once treated as a princess.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko1094"]
[OnName num="kaoruko"]
Umm, yeah. Well, ...... it does."
[cpg cn=true]

[OnName num="shinjo"]
"Kaoruko -chan, do you eat this sweets? It's delicious."
[cpg cn=true]

Shinjo-senpai is as kind to Kaoruko as ever. However, being kind is not enough for Kaoruko.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko1095"]
[OnName num="kaoruko"]
Oh, yes, I'll take .......
[cpg cn=true]

[OnName num="tokuzawa"]
"Kaoruko, it's an anime from the other day: ......"
[cpg cn=true]

Then Kaoruko finally exploded. At first, it was a quiet explosion.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko1096"]
[OnName num="kaoruko"]
Um, why doesn't everyone ...... call me Princess?"
[cpg cn=true]

Yes, there. That's where things have changed a lot. I guess you could say that everyone's eyes have opened.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko1097"]
[OnName num="kaoruko"]
"Until now, have you called me a princess? I was no longer a princess?"
[cpg cn=true]

Everyone was aghast. In the past, I would have been frightened, but now I just look at them.
[cpg]

[OnName num="tokuzawa"]
I'm not sure why ...... we've become so tolerant of women, you know?"
[cpg cn=true]

[OnName num="kimoto"]
I'm sure you're right. It's not right to call her a princess now, or ......"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Kaoruko1098"]
[OnName num="kaoruko"]
Pssst!"
[cpg cn=true]

It is strange to call her a princess. That line seems to have struck a nerve with Kaoruko.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko1099"]
[OnName num="kaoruko"]
"Why! Why, I should have been everyone's longing."
[cpg cn=true]

Up until now, if Kaoruko had shouted out loud, everyone would have been concerned.
[cpg]

That would have solved everything, and Kaoruko would have thought so too. However.
[cpg]

[OnName num="tokuzawa"]
He said, "I'm scared. Don't yell at me all of a sudden, you didn't say such a horrible thing. ......"
[cpg cn=true]

Tokusawa senpai's response is very familiar to women.
[cpg]

I mean, everyone is probably more attracted to Yui-san and others than Kaoruko, I'm sure. ......
[cpg]



;//ＢＫ
[free time=1000]


Kaoruko left the clubroom without leaving it. As her boyfriend, I couldn't leave her alone and followed her.
[cpg]

[free time=1000]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=2000]

Kaoruko was silent the whole time, or rather, mumbling something, which I couldn't hear.
[cpg]

This is very bad. I don't know what Kaoruko will do now.
[cpg]

I hope I don't do something rude to Yui and the others again. ......, I thought.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

Then, around the time I left the university. Kaoruko asked me for advice.
[cpg]

It was also the kind of advice that you would give to your boyfriend or that advice.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko1100"]
[OnName num="kaoruko"]
I wonder if ...... I'm not a princess anymore."
[cpg cn=true]

[OnName num="natsuki"]
"Do you want to change so much?
[cpg cn=true]

I asked her straightforwardly. Kaoruko answered.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko1101"]
[OnName num="kaoruko"]
'I don't really care what you call ....... But ...... does."
[cpg cn=true]

She wants to say something, but she can't. Kaoruko is like that.
[cpg]

I asked again, since it was a waste of time to just stare at it all the time.
[cpg]

[OnName num="natsuki"]
"I want to be more loved? Do you want to be pampered?"
[cpg cn=true]

Once again, I was straightforward. I asked him frankly.
[cpg]

I thought I was being a little rude asking, but my reply to that was a little more rude.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko1102"]
[OnName num="kaoruko"]
I ...... don't care who you are, I just want you to pamper me."
[cpg cn=true]

As a boyfriend, did you think I wouldn't be shocked, saying something like that?
[cpg]

I mean, there's no shame or shame in it, I'm not sure it has to be me, ......, but I'll listen to what you have to say.
[cpg]

[OnName num="natsuki"]
"Isn't it okay?
[cpg cn=true]

A bit of a killjoy, in case you were wondering. I thought this was going to work for me.
[cpg]

And I thought she would be happy, but Kaoruko has a downcast expression on her face.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko1103"]
[OnName num="kaoruko"]
"Are you happy? I'm happy that Natsuki is a boyfriend."
[cpg cn=true]

But, it goes on. What is it, what is the problem?
[cpg]

[OnName num="natsuki"]
Then that's fine. Am I not enough?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko1104"]
[OnName num="kaoruko"]
"......Yeah, not enough. One is not enough."
[cpg cn=true]

I see. That's a serious topic. It's even more serious when I think of it as something I would say directly to my boyfriend.
[cpg]

Not enough is ...... not enough for a boyfriend, that's like breaking up with him already.
[cpg]

Doesn't Kaoruko consider the possibility of being asked to break up then?
[cpg]

[OnName num="natsuki"]
"...... I see. Not enough for me, sorry."
[cpg cn=true]

Inwardly dismayed and disillusioned, I offered my advice.
[cpg]

[OnName num="natsuki"]
If you really don't care about anyone, why don't you just deal with someone older or something?"
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kaoruko1105"]
[OnName num="kaoruko"]
"Older ......?"
[cpg cn=true]

It just came to me. I didn't think it would be such a big deal for me to say something like this.
[cpg]

[OnName num="natsuki"]
Look, Kaoruko is a college student. Maybe she's attractive from an older person's point of view."
[cpg cn=true]

And then he goes on with his words. I didn't really think they would take it that seriously, and I was talking too.
[cpg]

I was expecting a reaction of "I don't want to be older than you, so I'll hold back after all.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko1106"]
[OnName num="kaoruko"]
"......I see, maybe so. ......"
[cpg cn=true]

Kaoruko's reaction, however, was otherwise.
[cpg]

Kaoruko's expression turned thoughtful.
[cpg]

[OnName num="natsuki"]
I'm just saying, it's an opinion. It's just an opinion, so don't use it as a reference.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
And then Kaoruko starts smiling, looking down at something. Oh no, I shouldn't have said that.
[cpg]

I may have sparked something bad.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


Then a few days passed.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（昼）******************************************************

[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[OnName num="gal_A"]
I read your comic the other day. It was really hard to understand. Seriously."
[cpg cn=true]

[OnName num="shinjo"]
"Bufuh!? Such a masterpiece ..."
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[OnName num="gal_A"]
"No, it was interesting to the translation. Is your Jinkaku -tsu? I saw it."
[cpg cn=true]

[OnName num="shinjo"]
Oh, no. ......."
[cpg cn=true]

[free time=1000]

Cross-cultural exchange is still going on. There is still much we do not know about each other.
[cpg]

Yui and the others remain interested in us. I guess we should be thankful for that.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[OnName num="gal_B"]
Well, your princess hasn't been here lately, has she?"
[cpg cn=true]

[OnName num="gal_C"]
"That's right, what happened? Did you fight?"
[cpg cn=true]

[OnName num="tokuzawa"]
Not that I do, but ......"
[cpg cn=true]

[free time=1000]

Yes, not really. Rather, I just went back to the way things were before.
[cpg]

But that is a big deal for Kaoruko.
[cpg]

[OnName num="kimoto"]
"Oh, by the way, I listened to the CD I borrowed the other day, that I did."
[cpg cn=true]

[OnName num="gal_D"]
"Seriously? It was dangerous, right?
[cpg cn=true]

[OnName num="kimoto"]
...... in a way that I don't understand, that I understand his personality."
[cpg cn=true]

[OnName num="gal_D"]
"Pu, Ahaha! Seriously, is the hurdle too high?"
[cpg cn=true]

We and a group of gals talking congenially.
[cpg]

A lot of things were happening behind the scenes during this time, but I had no way of knowing.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

And after Yui and the others left.
[cpg]

[OnName num="natsuki"]
I wonder if she will come today, too. Kaoruko."
[cpg cn=true]

Kaoruko doesn't come to the club room much anymore.
[cpg]

I know why. If I ran into Yui and the others, I would just feel uncomfortable.
[cpg]

But then, they don't come too often.
[cpg]

[OnName num="natsuki"]
...... Kaoruko, where did she go?"
[cpg cn=true]

I was somewhat worried, but the other boys weren't worried at all.
[cpg]

[OnName num="kimoto"]
"Well. You must have found another kingdom."
[cpg cn=true]

[OnName num="tokuzawa"]
'I guess it must be. You can be a princess, your own country."
[cpg cn=true]

I know it's a horrible thing to say, but I'm the only one who cared: ......
[cpg]

[OnName num="natsuki"]
I hope I'm not involved in something bad.
[cpg cn=true]

[OnName num="kimoto"]
"Is it bad? For example, why?"
[cpg cn=true]

[OnName num="natsuki"]
I guess it's ...... for example."
[cpg cn=true]

If you were really acting as I said you would.
[cpg]

If you're looking for a place that will lower the bar even more than we do and treat you like a princess.
[cpg]

It seems a bit dangerous. I can't imagine what exactly it would be like.
[cpg]


;//薫子に視点切り替わり
;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

I was walking the streets at night. Looking for a place where I could be a princess.
[cpg]

I didn't even have to look for it. If you think about it, it was right next to me.
[cpg]

Still, it took some mental preparation before I took the plunge.
[cpg]

But in the end I have no other action I can take. In the end, no matter how much I think about it, it's all the same.
[cpg]


[FACE method="change_2" pos="2/3"]
[VOICE f="Kaoruko1107"]
[OnName num="kaoruko"]
Am I cute, ......?"
[cpg cn=true]

A dingy man calls out to me from behind and turns back to me.
[cpg]

[OnName num="homeless"]
What the hell, you ......
[cpg cn=true]

Yes, I was headed to a homeless hangout.
[cpg]

I enter their living quarters without hesitation.
[cpg]

A house made of blue sheets, I tried to enter it, but was stopped.
[cpg]

Grabbing my arm, I turn around and ask.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kaoruko1108"]
[OnName num="kaoruko"]
"...... why are you stopping?"
[cpg cn=true]

[OnName num="homeless"]
You should stay away from people like us just out of curiosity."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko1109"]
[OnName num="kaoruko"]
It's not out of curiosity, ...... I don't have anywhere else to go."
[cpg cn=true]

I think it's okay to tell them everything. I want to be thought of as pretty.
[cpg]

;//●ＣＧ（ヒロイン・汚い男性に近づくヒロイン：ブルーシートハウス）ev_46

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_46_0 ***********************
[CG id=17 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]

With that in mind, I approached the person.
[cpg]


[VOICE f="Kaoruko1110"]
[OnName num="kaoruko"]
Please tell me I'm pretty, and I'll do anything for it."
[cpg cn=true]

The homeless man seemed to have some idea of what I was going through when he saw my impassioned expression.
[cpg]

And then he looked gloomy for a moment, I don't know why. I said I would do anything.
[cpg]

[OnName num="homeless"]
"...... such a young girl, it's the end of the world ......"
[cpg cn=true]

;//移植のためシーンをカットしています
;//●ＣＧ（ヒロイン・男を誘うヒロイン：ブルーシートハウス）ev_47
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_47_0 ***********************
[CG id=18 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]

I think I am ...... broken, in every sense of the word.
[cpg]

But I don't know how to get back to normal.
[cpg]

[VOICE f="sKaoruko031"]
[OnName num="kaoruko"]
Tell me she's pretty. ......
[cpg cn=true]


[OnName num="homeless"]
Oh. She's pretty."
[cpg cn=true]


Even with the loss of the person I once was, the current situation seemed much better.
[cpg]


I'm sure ...... is much more ...... now.
[cpg]



;//移植のためシーンをカットしています
;//ＢＫ
;//夏樹に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_00.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『大学教室』（昼）******************************************************

[OnName num="natsuki"]
"...... not coming to this lecture today ......"
[cpg cn=true]

The lecture where Kaoruko would normally sit next to me. Kaoruko is not there.
[cpg]

Kaoruko has stopped showing up at the university, let alone at the circle.
[cpg]

If I don't even attend lectures, I'll end up staying in school.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（昼）******************************************************

I'm worried about you as a quirky boyfriend, but I'm not sure if I should call you: ......
[cpg]

If they were to become naïve and lock themselves in a room by themselves, it could have the opposite effect.
[cpg]

But either way, I couldn't just let it go...when I was wondering .......
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************

[OnName num="natsuki"]
"...... Kaoruko."
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=800]

For the first time in a long time, Kaoruko showed up at the club room of the circle.
[cpg]

His face was sharp, as if he had made up his mind to do something.
[cpg]

[OnName num="kimoto"]
"... What happened to the university? Kaorukoden"
[cpg cn=true]

[OnName num="tokuzawa"]
Yes, Sugiura told me. He said you didn't even show up for your lectures."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kaoruko1145"]
[OnName num="kaoruko"]
Yeah, it's kind of a situation.
[cpg cn=true]

[OnName num="tokuzawa"]
What do you mean by "...... circumstances?" circumstances that require me to take a leave of absence from college?"
[cpg cn=true]

[OnName num="shinjo"]
Yes, I'm a little worried about the stones, Kaoruko-chan.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
Kaoruko sighed one sigh. And,
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko1146"]
[OnName num="kaoruko"]
......I told you that much, but you still won't call me Princess."
[cpg cn=true]

He said. I'm still saying it, about that.
[cpg]

[OnName num="natsuki"]
"You don't have to get hung up on that now ......"
[cpg cn=true]

Even I get stared at when I say that. I don't think I said anything that would make them that angry. ......
[cpg]

[OnName num="shinjo"]
But it's good to have you back, guys.
[cpg cn=true]

Shinjo-senpai says that with air. I don't know how far he really thinks.
[cpg]

[OnName num="tokuzawa"]
Oh, yeah. But are you okay with credits and stuff?"
[cpg cn=true]

Kaoruko then cut to the chase.
[cpg]

[FACE method="change_2" pos="2/3"]
[VOICE f="Kaoruko1147"]
[OnName num="kaoruko"]
I'm fine. I found a new place to live. I came here today to say goodbye."
[cpg cn=true]

[OnName num="natsuki"]
"What do you mean by ...... goodbye?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kaoruko1148"]
[OnName num="kaoruko"]
I am withdrawing from this circle. Thank you very much for your help."
[cpg cn=true]
;//[t_move pos=C 下礼]
Everyone was somewhat surprised. I was surprised to leave this circle where I used to be pampered and admired.
[cpg]

Kaoruko makes her declaration in a brisk tone.
[cpg]

[OnName num="shinjo"]
I'm sorry to hear that. That's too bad."
[cpg cn=true]

[OnName num="tokuzawa"]
Well, ......, yeah, maybe."
[cpg cn=true]

[OnName num="kimoto"]
So, even though you are a smart guy and you say ......, we will meet at the university, that we will?"
[cpg cn=true]

The boys did not hold back much. In fact, there was even an air of relief that the element of anxiety was gone.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko1149"]
[OnName num="kaoruko"]
'You don't even try to keep me back, do you? You're not a princess anymore."
[cpg cn=true]

Kaoruko's expression faded a little. In response, Tokusawa-senpai followed up.
[cpg]

[OnName num="tokuzawa"]
Oh, no, that's not what ......"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko1150"]
[OnName num="kaoruko"]
But I'm fine. I'm okay now. ......"
[cpg cn=true]

[OnName num="tokuzawa"]
I hope you're okay with ......."
[cpg cn=true]

[OnName num="kimoto"]
"Well then, I guess this is goodbye to ......, Kaoruko-dono."
[cpg cn=true]

Why does she seem rather unstable when she repeats that she is fine?
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


Then, Kaoruko and I lost contact with each other, even by cell phone.
[cpg]

It wasn't so much that he didn't answer the phone, it was more like it wasn't turned on.
[cpg]

Or reject incoming call? Do you do that to me?
[cpg]

I'm not really that worried about it, but I did wonder a little bit if something dangerous was going on.
[cpg]



[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

In this way, the circle regained its previous peace.
[cpg]

I think Shinjo-senpai, Tokusawa-senpai, and Kimoto are more lively than when Kaoruko was there .......
[cpg]

The eye of the typhoon, Kaoruko, was gone, and the place was transformed back into a peaceful, manly Otasa.
[cpg]

[OnName num="tokuzawa"]
'Oh no, it's almost release day for that game. Too much fun. ......"
[cpg cn=true]

[OnName num="kimoto"]
It is unusual for Tokusawa-senpai to be playing games.
[cpg cn=true]

[OnName num="shinjo"]
"It's a different, it's a nasty game.
[cpg cn=true]

[OnName num="tokuzawa"]
What the hell, is that bad? ......
[cpg cn=true]

The way it should be. A peaceful circle. That has been restored and no one is worried about Kaoruko anymore.
[cpg]



[SE f="se019"]
;//【ＳＥ】『ドア開く』
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[OnName num="gal_A"]
"What is it? I heard a bad game?"
[cpg cn=true]

[OnName num="tokuzawa"]
"Yeah! Nothing, it's true."
[cpg cn=true]

[FACE method="bow_2" pos="4/5"]
[OnName num="gal_B"]
"Oh, man, you're so nervous."
[cpg cn=true]

[OnName num="kimoto"]
Yes, because there's a real gal right in front of me, that I know."
[cpg cn=true]

[OnName num="tokuzawa"]
What are you talking about?"
[cpg cn=true]

[OnName num="kimoto"]
"But it's also called 'galge,' isn't it?"
[cpg cn=true]

...... I was thinking earlier that the masculine circle has been taken back.
[cpg]

It's not just masculine. Sometimes Yui and her friends come over.
[cpg]

So you could say it's more fulfilling than before: ......
[cpg]

In any case, the circle was becoming more peaceful.
[cpg]

Kaoruko, too, remains unsure if she is now living her days in peace.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



After that, the uneventful days repeated themselves.
[cpg]

Today is the same as yesterday. It is repeated, but Kaoruko is not next to me.
[cpg]

There is no way to go looking for them if the phone is disconnected.
[cpg]

It would probably be useless to ask the university, it would be a matter of privacy.
[cpg]

But you could at least say something to me: ......
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

One day while I was living with such thoughts. I happened to see a dirty Kaoruko in town.
[cpg]

[OnName num="natsuki"]
Kaoruko ......"
[cpg cn=true]

I tried to call out to him, but decided not to.
[cpg]

If you call out to them, that may be the end of the story.
[cpg]

I was more interested in where they have been going lately.
[cpg]

With this in mind, I sneakily followed him and saw him heading toward a hangout for homeless people: ......
[cpg]

[OnName num="natsuki"]
Hey, what are you doing ......?"
[cpg cn=true]

They disappear into a house made of blue sheets. There is no way I can imagine what they are doing so peacefully.
[cpg]

Sneak, sneak, sneak closer to its entrance: ......
[cpg]



;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

There, Kaoruko was indeed treated like a princess.
[cpg]

Kaoruko didn't even seem to notice me anymore: ......
[cpg]

I left the homeless hangout without saying a word.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[OnName num="natsuki"]
"......It's all over now. ......"
[cpg cn=true]

Or rather, it was long over. They must have been going to the homeless even before they submitted their withdrawal papers.
[cpg]

What am I being played with? I'm so happy and sad about a girl like that.
[cpg]

I felt foolish for making so many calls and erased Kaoruko's number from my cell phone.
[cpg]

She's no longer our princess or my girlfriend.
[cpg]

It's a hell of a mess, isn't it? I'm sure my parents would be worried about me, but maybe I'm going to live like that for the four years I'm supposed to be in college.
[cpg]

Maybe every girl yearns to be a princess. But that's not really true.
[cpg]

I guess everyone wakes up from that dream at some point, but Kaoruko could not wake up anytime soon.
[cpg]

[OnName num="natsuki"]
...... Ironic, isn't it?"
[cpg cn=true]

I even wondered if I would have looked better if I had aspired to be a normal girl.
[cpg]

Kaoruko will surely not be able to wake up from her dream anytime soon. ......
[cpg]

[SCENE id=16]

[jump storage="epend.ks" target="*start"]
;//【ルート４】エンド

