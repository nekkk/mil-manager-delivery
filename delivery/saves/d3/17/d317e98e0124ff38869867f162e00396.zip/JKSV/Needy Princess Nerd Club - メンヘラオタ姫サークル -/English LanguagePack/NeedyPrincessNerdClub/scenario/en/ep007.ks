
;//==============================
;//ルート１
*route1|The true nature of a princess

*start|The true nature of a princess

;#################################################
*Ep007|The true nature of a princess
;#################################################

[SCENE id=7]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

In the end, the morning came without any particular ideas.
[cpg]

Breakfast, brushing teeth, washing face. All of these actions are repeated without delay.
[cpg]

When I started college, I could imagine a brighter future, but my mood is kind of heavy. ......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

Then I headed off to the university. In the middle of it all, I got a little phone call.
[cpg]


[SE f="se013"]
;//【ＳＥ】『携帯電話の着信音』
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=3500]


[SE f="se034"]
;//【ＳＥ】『携帯電話のボタン』
[WAIT time=1000]

[VOICE f="Kaoruko716"]
[OnName num="kaoruko"]
Kehoho, kehoho ...... sorry, Natsuki-kun, are you okay now ......?"
[cpg cn=true]

[OnName num="natsuki"]
What's wrong with your voice? Another cold?"
[cpg cn=true]


[VOICE f="Kaoruko717"]
[OnName num="kaoruko"]
'Yeah, I think I got a pretty heavy one, and it's ......, so I can't go to college today.'
[cpg cn=true]

Up to this point, I would have simply worried about Kaoruko. However.
[cpg]


[VOICE f="Kaoruko718"]
[OnName num="kaoruko"]
"Keep an eye on everyone in the circle while I'm gone. ......
[cpg cn=true]

This extra word makes me a little hazy.
[cpg]

[OnName num="natsuki"]
...... Yeah, take care of yourself."
[cpg cn=true]



[SE f="se021"]
;//【ＳＥ】『携帯電話の通話終了音』

[free time=1000]

He hangs up the phone without hesitation.
[cpg]

I'd say I'll keep an eye on them, but if Yui and the others come, I won't be able to do anything about it either.
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（朝）******************************************************

Then, he goes to a lecture at the university. Even in lectures where Kaoruko is supposed to be next to him, Kaoruko is not there.
[cpg]

I find myself a little relieved about that.
[cpg]

This is not a normal lovers' relationship, I thought .......
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]


;//【ＢＧ】『大学教室』（昼）******************************************************

The lecture is in progress, and it is almost lunchtime.
[cpg]

I headed to the club room, not to abide by Kaoruko's words, but to visit with everyone.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


It was an amazing sight there: ......
[cpg]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（昼）******************************************************

;//♪三人


I was in a money bind. Specifically, there were a lot of people in the club room.
[cpg]

Kimoto, seniors, and four others, including Yui and her friends, for a total of seven.
[cpg]

Each gal and circle member was so close together that they were almost hand in hand.
[cpg]

...... I wonder if what happened the other day made Yui and the others very angry.
[cpg]

Rather, it appears that they simply want to just get along with the guys in their circle.
[cpg]

It's not acting-like or insidious enough for retribution.
[cpg]

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[OnName num="gal_B"]
"You know, if you lose weight, you're going to be really good looking, I'm serious, I'm not lying."
[cpg cn=true]

[OnName num="shinjo"]
I don't think so, buh-buh.
[cpg cn=true]

[OnName num="gal_C"]
;//「結構ガタイいーじゃん、こんな腕で抱かれたらって思うと、マジヤバいかも」
I'm really scared when I think of him hugging me with his arms like this.
[cpg cn=true]

[OnName num="kimoto"]
"No, that's not true, that it isn't. ...... is ......."
[cpg cn=true]

Yui's cronies are starting to seduce me, and I'm on the verge of becoming a basket case. Everyone's face turns bright red, and yet, they don't seem to just hate it.
[cpg]

Mostly, we all know that these women are not bad people. It's natural to be happy when they are tempted.
[cpg]

[free time=300]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[OnName num="gal_A"]
"Oh, Natsuki, if you're here, you should tell me. I'll take good care of you."
[cpg cn=true]

[free time=300]
[FG f="CHA02_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

Yui-san walks toward us. Then, she approached me at close range.
[cpg]
[OnName num="natsuki"]
Nah, what's that ......?"
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[OnName num="gal_A"]
"Hey, I don't feel like it here, so let's go somewhere else."
[cpg cn=true]

[OnName num="natsuki"]
Where, you ask, is somewhere?
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[OnName num="gal_A"]
"Anywhere is fine. Just follow me."
[cpg cn=true]

Yui-san has a debt to Kaoruko for what she did wrong. So I couldn't untie her hand, and I was taken as I was.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


Then, even though I still had lectures to attend, I was taken out of the university ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="natsuki"]
Oh, um, I still have a lecture at ......."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[OnName num="gal_A"]
It's good. "Skipping, skipping, skipping. We're going to do something more fun than that today."
[cpg cn=true]

And as we walked, we were taken to ...... this child's house?
[cpg]

[OnName num="natsuki"]
I'm Kaoruko's boyfriend in case you were wondering ...... that."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[OnName num="gal_A"]
You're so hard. Don't say that, it's sad."
[cpg cn=true]

;//ＢＫ


[SE f="se037"]
;//【ＳＥ】『ドア閉まる』
;//移植のためシーンをカットしています


;//●ＣＧ（モブ女子・主人公を誘うモブ女子：マンションの一室　モブ女子の部屋）ev_28

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_28_0 ***********************
[CG id=10 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]

When she was forced to take me up to her room, she started burning some kind of strange aroma.
[cpg]

Come to think of it, that might have been something that worked like a drug.
[cpg]

That's how much I was confused by the strange sexuality.
[cpg]


[OnName num="gal_A"]
Come on, come here.
[cpg cn=true]


[OnName num="natsuki"]
"......"
[cpg cn=true]


;//ＢＫ


While cuddling with me, Yui took pictures of us several times.
[cpg]

I guess that's what he said sometime ago, that he was going to send this to Kaoruko.
[cpg]

Oh, I'm in trouble, I thought, but my ...... head was in a daze.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p3_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

[SE f="se027"]
;//【ＳＥ】『喧騒』

[FACE method="shake_6" pos="2/3"]
[OnName num="gal_A"]
I'll see you later. Let's play again, Natsuki.
[cpg cn=true]

[OnName num="natsuki"]
"......"
[cpg cn=true]


Kaoruko must be down with a cold right now. Things won't move much anytime soon, it shouldn't be ......
[cpg]

Yes, we need to take the photo away from Yui in the first place: ......
[cpg]

But how? Do you rob your smartphone?
[cpg]

[OnName num="natsuki"]
I'm talking about that ...... photo."
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[OnName num="gal_A"]
"What? I sent it, what are you talking about now?"
[cpg cn=true]

It's too late. Too late. If he's not calling me now in anger, he's probably sleeping.
[cpg]

[FACE method="bow_1" pos="2/3"]
[OnName num="gal_A"]
I guess we don't owe her anything now. Well, I guess that's that.
[cpg cn=true]

[free time=1000]

[SE f="se001"]
;//【ＳＥ】『歩く』

Yui-san leaving. I didn't even want to stop her, saying, "Oh my God.
[cpg]

I had a feeling that something like this would happen someday.
[cpg]

I had a feeling that me and Kaoruko couldn't be lovers forever. ......
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se037"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


I am feeling awfully tired today. Part of me doesn't want to think too much about the future.
[cpg]

I collapsed onto the bed, still in my plain clothes.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]

[SE f="se029"]
;//【ＳＥ】『ベッドきしむ』
[WAIT time=1100]

And then, just like that, I fell asleep. ......
[cpg]

But still, I can't believe how troublesome this is.
[cpg]

I wondered for a moment if tomorrow, if the world would be gone.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]

I did not sleep well that night.
[cpg]

Because, at a time of day that could be called early morning, there was a banging on the door several times.
[cpg]

[SE f="se022"]
;//【ＳＥ】『ドア乱暴に叩く』

[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


It's Kaoruko. You don't have to open it anymore to know.
[cpg]

I chose not to open the door here. I will not leave until she gives up.
[cpg]

I'm sure they'll probably come at me with a heart-to-heart talk.
[cpg]

That annoyed me too, so I decided to use earplugs until the banging on the door stopped.
[cpg]


[VOICE f="Kaoruko719"]
[OnName num="kaoruko"]
"You're there!? Natsuki -kun, why do you ignore it!?"
[cpg cn=true]

I hear some shouting, but I don't care. If I do anything too obvious, someone else will call the police.
[cpg]

I imagined that I wouldn't be able to take the morning lecture, and also that the cold must have been very serious if he was getting angry now.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（昼）******************************************************

Then, around noon, the banging on the door stopped.
[cpg]

Don't relax yet. It's Kaoruko, she might be lurking at the door.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


So I look through the door. At least there is no one at the door.
[cpg]


[SE f="se023"]
;//【ＳＥ】『鍵開く』

[FADEOUTBGM]

I unlocked the door and opened it just a little bit.
[cpg]

No, he's not there. Open a little wider and look around. Apparently, he's nowhere to be found: ......
[cpg]


[BGM f="bg_op"]

[FG f="CHA01_p5_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kaoruko720"]
[OnName num="kaoruko"]
...... Natsuki-kun?"
[cpg cn=true]

[OnName num="natsuki"]
Pssst!"
[cpg cn=true]

A horrible chill ran down my back. I could force the door open, great power. ......
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko721"]
[OnName num="kaoruko"]
"Why are you trying to close? Leave me to the room, please."
[cpg cn=true]

He says it quietly and with a smile on his face. And yet, as I try to close the door, he pushes back with tremendous force.
[cpg]

[OnName num="natsuki"]
'Okay, okay, I'll let you in, just take your hands off me.'
[cpg cn=true]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_01_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（昼）******************************************************

My room, the two of us sitting upright, facing each other. Kaoruko had a somewhat unreadable expression on her face.
[cpg]

He looked like he had completely lost his soul.
[cpg]

[OnName num="natsuki"]
Oh, you know, ...... maybe they sent you a picture."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kaoruko722"]
[OnName num="kaoruko"]
"Yeah."
[cpg cn=true]

[OnName num="natsuki"]
"That thing was like that ...... accident, so ......
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kaoruko723"]
[OnName num="kaoruko"]
Accident?
[cpg cn=true]

His expression changed. More and more, it changed into the shape of a demon.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko724"]
[OnName num="kaoruko"]
"Do you want to do something that wasn't? Do you step on my feelings so much?"
[cpg cn=true]

[OnName num="natsuki"]
I don't want to pretend it didn't happen, but rather I want to apologize. It's not that I'm pretending it didn't happen, it's more like I want to apologize.
[cpg cn=true]

Why am I saying things that put her in a good mood?
[cpg]

This isn't because I want them to stay in the relationship anymore. If we don't, they will really kill us.
[cpg]

It was such an uncanny look.
[cpg]

[FACE method="change_3" pos="2/3"]
[VOICE f="Kaoruko725"]
[OnName num="kaoruko"]
You apologize. You apologize because you think you can be forgiven."
[cpg cn=true]

[OnName num="natsuki"]
Yu, you don't have to forgive me, so ......"
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko726"]
[OnName num="kaoruko"]
'Then do yourself a favor and apologize. Either way, you suck. ......!"
[cpg cn=true]

Slowly, Kaoruko starts to creep closer and closer to me. I involuntarily back away.
[cpg]

Behind me was the bed. There was nowhere to run and I was pushed down.
[cpg]

[OnName num="natsuki"]
"Ugh ...... or Kaoruko, I'm sorry, forgive me ......"
[cpg cn=true]

[free time=300]
[FG f="CHA01_p5_03_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="sKaoruko021"]
[OnName num="kaoruko"]
I won't forgive you. I won't forgive Yui, but of course I won't forgive Natsuki-kun either."
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kaoruko728"]
[OnName num="kaoruko"]
I'm angry. You understand, don't you?　Natsuki-kun, you betrayed me, so it can't be helped, right?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[OnName num="natsuki"]
No, no, no!
[cpg cn=true]

[free time=300]
[FG f="CHA01_p1_03_a.ui" method="change_5"  pos="2/3" time=800]
I pushed Kaoruko away from me, who pushed me back.
[cpg]


[FACE method="shake_4" pos="2/3"]
Then he starts to cry, this time raggedly. He is completely emotionally unstable, just scared.
[cpg]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Kaoruko729"]
[OnName num="kaoruko"]
"Why, I loved you so much, why, what's wrong with you?"
[cpg cn=true]

I'm not sure about "single-minded," but if I say that now, they will really kill me.
[cpg]

[OnName num="natsuki"]
"Oh, let's calm down. Hey, Kaoruko ......"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko730"]
[OnName num="kaoruko"]
"...... I'm calm, gus, hiccup ......"
[cpg cn=true]

I'm in a bind. Should I call the police in this situation?
[cpg]

I thought, and picked up my cell phone. But..,
[cpg]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Kaoruko731"]
[OnName num="kaoruko"]
No!
[cpg cn=true]

And then they took it away. After all, are you aware that you are doing something that would cause the police to be called?
[cpg]

[OnName num="natsuki"]
Or return ......"
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko732"]
[OnName num="kaoruko"]
"Yui wants to help the child help you, right, so that's it ...!"
[cpg cn=true]

It wasn't. I'm not completely calm anymore. Why is Yui's name coming up here?
[cpg]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

It would be bad if she resisted forcibly. So I let her do what she wanted to do.
[cpg]

I think she was crying all the time, but she seemed to be calming down a little by being with me.
[cpg]

But it bothered me that he was saying things the whole time: ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

...... that happened, the next day.
[cpg]

He had been out cold for almost half a day. I look around.
[cpg]

Next to the bed, Kaoruko was there. She was hugging me the whole time.
[cpg]

[FG f="CHA01_p5_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kaoruko787"]
[OnName num="kaoruko"]
"Awakening, good morning, Natsuki -kun"
[cpg cn=true]

He was no longer in the form of madness and had a gentle expression on his face.
[cpg]


[FACE method="bow_1" pos="2/3"]
[VOICE f="Kaoruko788"]
[OnName num="kaoruko"]
I'll let you off the hook this one time. I forgive you just this once."
[cpg cn=true]

Before I could say anything, Kaoruko would anticipate me and give me an answer.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko789"]
[OnName num="kaoruko"]
I'm going home today. Don't ever do that again, Natsuki-kun.
[cpg cn=true]

[OnName num="natsuki"]
Uh, yeah. ......."
[cpg cn=true]

It looks as if the case is settled. However, Kaoruko is not an ordinary person.
[cpg]

It left a deep mark on my heart.
[cpg]


...... I can't keep going on and on about this stuff.
[cpg]

I'm sorry Kaoruko, but I don't have the confidence in myself to continue being her lover anymore.
[cpg]

I wonder if I could have gone out with Yui like that.
[cpg]

I bet he's a much more sensible person than Kaoruko. Besides, she was cute. ......
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

On the commute to college, think about it.
[cpg]

Kaoruko only thinks about herself in the end. Even when she told me she liked me, she was probably doing it to gain the status of having a boyfriend.
[cpg]

Even yesterday, if you really wanted to keep me connected, you could have done better.
[cpg]

I'd be happy to discuss the future with you or ...... I'd be remorseful enough to do just that.
[cpg]

I would have felt guilty toward Kaoruko. But now, I feel the opposite.
[cpg]

In the end, Kaoruko is just using me to release the stress she feels, I'm sure.
[cpg]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（朝）******************************************************

The more I think ...... about it, the more I think things I shouldn't think.
[cpg]

Yui-san is so cute by comparison. If Kaoruko hadn't told her so absurdly, she probably would have tried to have a more normal contact with me too.
[cpg]

The only reason she forced me to sleep with her was in retaliation for Kaoruko, and when I think of it that way, Yui-san seems more sane.
[cpg]




[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


During the day, I was sleepy as well as unappetizing, so I decided to take a nap in a suitable empty classroom.
[cpg]




[window target=false]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（夕方）******************************************************

Then I was about to head to my usual club room at ...... after finishing my university lectures.
[cpg]

[OnName num="natsuki"]
"......?"
[cpg cn=true]

I hear something, a noise inside. Then I hear some voices.
[cpg]



[SE f="se019"]
;//【ＳＥ】『ドア開く』

Wondering what it was, I opened the door to the club room. Then, there was ......
[cpg]


;//ＢＫ
;//薫子に視点切り替わり

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=3000]


[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

Did I overdo it yesterday? I was thinking that on the way to school.
[cpg]

But I think Natsuki-kun is bad. The girl named Yui is even worse, though.
[cpg]

So Yui needs another retaliation ...... but that's something you can think about later.
[cpg]



[window target=false]
;//[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（朝）******************************************************

Today, I don't have the same lecture as Natsuki. I am a little disappointed about that.
[cpg]

But if I go to the clubroom, Natsuki-kun will be there.
[cpg]

If he was so frightened about yesterday that he didn't go to the club room, I would call him on the phone.
[cpg]

And if push comes to shove, I can just tell him I'm going to kill myself. That's all you have to do to get me to swing around, and I think you're a kind person.
[cpg]

He is too good for me. I won't give him to anyone. I would never let a gal, the natural enemy of nerds, take him away from me. ......
[cpg]


[window target=false]
;//[free time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（昼）******************************************************

When I went to the school cafeteria during the day, Natsuki was not there. I looked around for him, but he was not there.
[cpg]

I guess I've scared him away from me. If you're avoiding me, that's a problem.
[cpg]

We are only trying to be an amicable couple.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（夕方）******************************************************

Then, when the evening lecture was over and it was time to head to the club room.
[cpg]


;//ＢＫ

;//●ＣＧエロ（モブ女子複数・籠絡されたオタサー男子たち。乱交状態：サークル部室）ev_32

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_32_0 ***********************
[CG id=11 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]

;//移植のためシーンをカットしています

There, the scene was unbelievable.
[cpg]

One day a group of gals were getting into my castle.
[cpg]


[OnName num="gal_A"]
Ah, Princess. Welcome back."
[cpg cn=true]


Natsuki was there too. He was being pressed by Yui.
[cpg]

...... I guessed it all. I knew I couldn't go back to the way things were.
[cpg]

Where did you make a mistake? Am I too selfish? What a ... I can't help thinking.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_5"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************


;//♪演出として音をなくしています。
;//ここの薫子のセリフは録音用に分けてありますが、ゲームにする時は全て合成して一つの長いセリフとして使用して下さい

Everything has gone beyond the critical point. It bursts beyond what is acceptable.
[cpg]

I will overflow, I will overflow. Everything, overflows, and goes away. ......
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Kaoruko798"]
[OnName num="kaoruko"]
"No, no, no, noooooo! Arghhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh!!
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kaoruko799"]
[OnName num="kaoruko"]
"Why don't you get me to me!!
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko800"]
[OnName num="kaoruko"]
"Why do you betrayed, I kept loving it!!
[cpg cn=true]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko801"]
[OnName num="kaoruko"]
'What the hell are you people to begin with? You came into my sanctum sanctorum without permission, eh? Don't you try to take the man! This is my castle! I'm the princess here!
[cpg cn=true]



[FACE method="shock_3" pos="2/3"]
;//[VOICE f="Kaoruko802_1"]
[VOICE f="sKaoruko802_1"]
[OnName num="kaoruko"]
;//「自分の方が可愛いって思ってんだろ、ちくしょぉおお！　人の事見下しやがってええ！　この雌豚ぁ！股開くしか能のない腐れビッチ共がぁぁああ！」
"I think I'm more cute, Chikusho! Look down at people!
[cpg cn=true]

;//[VOICE f="Kaoruko802_2"]
[VOICE f="sKaoruko802_2"]
[OnName num="kaoruko"]
;//「クッサイまんこで男たらしこみやがってぇえ！　私の代わりに姫になろうっての！？　ふざけんなよブス！ブス！ブース！」
"I'm going to be a princess instead of me!?
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
;//[VOICE f="Kaoruko803"]
[VOICE f="sKaoruko803"]
[OnName num="kaoruko"]
;//「お前らは不細工だ！バーカ！　しね！氏ね！　グロまんでブサ男釣って一生ハメてろ！バーカ！」
"You guys are ugly! Barka! Shine! Mr.!"
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kaoruko804"]
[OnName num="kaoruko"]
;//「男子も何なんだよ！私のこと、姫とか、言っといて！ヤらせてくれたら、誰でも姫か！誰でもいいのかよこの短小共！ヤラせてやったでしょ！さんざんヤラせてやっただろ！？」
What's with the boys, too? You keep talking about me like I'm a princess or something!"
[cpg cn=true]

[FACE method="bows_3" pos="2/3"]
[VOICE f="Kaoruko805"]
[OnName num="kaoruko"]
"I'm a princess ...! I'm more important, I'll do it! !!! Ahhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh!"
[cpg cn=true]


;//下記のセリフは声にならない悲鳴です。そのまま読まずに、訳の分からない言葉、奇声という感じでも大丈夫です

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kaoruko806"]
[OnName num="kaoruko"]
"qawsedrftgyhujikolp △●■×*oooooooo ！！！！！"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko807"]
[OnName num="kaoruko"]
Hah, hah, hah... hah ...... hah, hah, hah ........."
[cpg cn=true]


;//本性を出した薫子　静まり返る室内　ドン引きの皆

[FACE method="shock_5" pos="2/3"]
[VOICE f="Kaoruko808"]
[OnName num="kaoruko"]
"........................... ...ah."
[cpg cn=true]

By the time I realized it, it was too late and I would never be a princess again. The cold stares from everyone told me that.
[cpg]

[SCENE id=13]

[jump storage="epend.ks" target="*start"]

;//【ルート１】エンド

