
;//==============================
;//ルート３
*route3|Princesses cost a lot of money.

*start|Princesses cost a lot of money.

[SCENE id=9]

Kaoruko must be feeling quite threatened.
[cpg]

If we did nothing, they would just take it from us. Then I could have done something out of the ordinary.
[cpg]

One day, in the circle club room. She got into the act.
[cpg]


;#################################################
*Ep009|Princesses cost a lot of money.
;#################################################


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（昼）******************************************************

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko948"]
[OnName num="kaoruko"]
"......, can I have a word?"
[cpg cn=true]

[OnName num="shinjo"]
"...... what is it?"
[cpg cn=true]

While the four of us were hanging out in the circle club room, Kaoruko opened the door and looked serious.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko949"]
[OnName num="kaoruko"]
I heard a bad rumor about a girl named Yui.
[cpg cn=true]

[OnName num="tokuzawa"]
"Rumors? But they didn't look like such a bad child."
[cpg cn=true]

[OnName num="kimoto"]
That is true, that I have not heard any bad rumors, that I have not. I have never heard of any bad rumors, that I have not.
[cpg cn=true]

At this point, Kaoruko is frustrated that she is already feeling enthralled.
[cpg]

But Kaoruko managed to hold her nerve and speak in a firm tone.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko950"]
[OnName num="kaoruko"]
There are rumors that there are a number of these girls who are less than boyfriends and that they are paying them off.
[cpg cn=true]

The boys look at each other. I'm no exception.
[cpg]

And I immediately recognized it as a lie. I knew it was a lie to trick Yui and the others.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko951"]
[OnName num="kaoruko"]
I'm told he's also involved in shoplifting, dangerous drugs, ...... and many other things.
[cpg cn=true]

See, it's a bad rumor that seems to have been cobbled together from various sources. It's a lie, of course.
[cpg]

But it doesn't help that it's a lie. It will only drive Kaoruko away.
[cpg]

[OnName num="shinjo"]
"......I wonder if that's, you know, possible. ......Boohoo......"
[cpg cn=true]

[OnName num="tokuzawa"]
But if it's true, that's a little ...... terrible for quicksand."
[cpg cn=true]

[OnName num="kimoto"]
"Let's lie? I can't see such bad children."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko952"]
[OnName num="kaoruko"]
I'm not lying. If we don't do something, our seniors might suffer the same fate."
[cpg cn=true]

Still, I wonder what Kaoruko plans to do.
[cpg]

What's the point of temporarily ripping Yui and the others off by spouting lies that can be easily exposed like this: ......
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]

Quite simply, the lie did not last a day.
[cpg]

While Kaoruko was away, Yui and her friends visited the club room.
[cpg]



;//【ＢＧ】『サークル部室』（夕方）******************************************************

[free time=300]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/5" time=800]

[OnName num="gal_A"]
I knew nerds were good at games. We can't win, can we?
[cpg cn=true]

[OnName num="kimoto"]
"...... is about as normal as it gets, that ......."
[cpg cn=true]

While the group of gals Yui-san had brought with her was in the club room, Tokusawa-senpai cut loose.
[cpg]

[OnName num="tokuzawa"]
Hey, Yui ......
[cpg cn=true]

[FACE method="shake_1" pos="2/5"]
[OnName num="gal_A"]
"Ah? What?"
[cpg cn=true]

[OnName num="tokuzawa"]
Is it ...... true that you have a lot of guys under your roof and you make them pay for it?"
[cpg cn=true]

One of the gals blew out her drink.
[cpg]

[FACE method="shake_7" pos="4/5"]
[OnName num="gal_B"]
What's that ...... what?"
[cpg cn=true]

[FACE method="shake_3" pos="2/5"]
[OnName num="gal_A"]
"That's a ...... lie, that's a lie. There's no way that's happening nowadays, haha. ......"
[cpg cn=true]

[OnName num="tokuzawa"]
Do you do other things like shoplifting, bad drugs, ......?"
[cpg cn=true]

Yui-san is completely taken aback. You would imagine that Kaoruko must have blown the whistle.
[cpg]

[FACE method="bow_7" pos="2/5"]
[OnName num="gal_A"]
"What, that image of you as if you're piecing together your cartoon knowledge can't possibly be ...... there, notice that."
[cpg cn=true]

We don't know which one is telling the truth. By nature, we should not know.
[cpg]

However, if we were asked which we believe, Yui and her colleagues' words or Kaoruko's, I wonder.
[cpg]

Maybe people don't believe Kaoruko.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

Then, I left the university and went home alone.
[cpg]

Kaoruko's position is getting worse and worse without her knowledge, and I wonder if I should let her know this.
[cpg]

I wonder if it would be better to put a cushion between the two than to have them suddenly turn cold tomorrow.
[cpg]

After much thought, I decided to let it go.
[cpg]

Because no matter what I think about this case, Kaoruko is at fault. She deserved it so much, I can't cover for her.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

And the next morning. I had to walk with Kaoruko on the short walk to the university.
[cpg]

[OnName num="natsuki"]
...... Yui and her friends must have been such terrible people."
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko953"]
[OnName num="kaoruko"]
Umm, yeah ...... I don't believe it either, but no, it's just a rumor to begin with."
[cpg cn=true]

To me, they put a little follow-up to themselves.
[cpg]

If I had had even a little bit of that feeling for the other boys, I don't think I would have told them such an easily recognizable lie.
[cpg]

[OnName num="natsuki"]
"... Usa, Kaoruko. What I said yesterday is really true? Isn't it a lie?"
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="Kaoruko954"]
[OnName num="kaoruko"]
I'm not lying,...... Natsuki-kun, are you doubting me?"
[cpg cn=true]

[OnName num="natsuki"]
No, it's okay as long as it's not a lie. It's okay if you're not lying. I'm sorry, that was a weird thing to say."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

Kaoruko was the one saying weird things, but I apologized in passing.
[cpg]

It's finally too late, I'm seriously injured, but ...... I think I did the best I could.
[cpg]

Kaoruko had a chance to say it was a lie here, but she didn't.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

In the evening, the club room of the circle.
[cpg]

Kaoruko's position became worse and she was no longer called princess.
[cpg]

[OnName num="shinjo"]
Oh, Kaoruko, you've been to ......."
[cpg cn=true]

[OnName num="tokuzawa"]
"......"
[cpg cn=true]

[OnName num="kimoto"]
"......"
[cpg cn=true]

For Tokusawa-senpai and Kimoto, there were not even words.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kaoruko955"]
[OnName num="kaoruko"]
"Good evening, Kimoto-kun, Tokusawa-senpai ......"
[cpg cn=true]

No reply. They both look at the TV screen, engrossed in the game, pretending.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko956"]
[OnName num="kaoruko"]
You could at least respond to me: ......!"
[cpg cn=true]

No reply. This time, a perfect rejection.
[cpg]

Kaoruko was astonished. It's a little too late for that, though.
[cpg]

When I look back at what I did, why can't I realize that I deserved it?
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko957"]
[OnName num="kaoruko"]
Why are you ignoring me, you all called me princess!
[cpg cn=true]

[OnName num="tokuzawa"]
If I didn't know ...... true nature, I'd still be calling you."
[cpg cn=true]

[OnName num="shinjo"]
"Women are so scary, boohoo. ......"
[cpg cn=true]

Kaoruko, too, had to realize that the quintessential lie had been exposed.
[cpg]

And at the same time, I had to realize ...... that Yui's words were believed by her own words and by Yui's words.
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Kaoruko958"]
[OnName num="kaoruko"]
Oh no, why ...... what are you doing?"
[cpg cn=true]

I'm as stunned by Kaoruko as she is by me. My love for her has cooled off, but I still have no intention to stop being her boyfriend.
[cpg]

Because he is my boyfriend, I have to tell Kaoruko properly here.
[cpg]

[OnName num="natsuki"]
Lies are not good, Kaoruko. Lies that hurt people are also not good.
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
Hearing this, Kaoruko's face turned bright red and she bit her lip ......
[cpg]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kaoruko959"]
[OnName num="kaoruko"]
"U, noisy! Natsuki -kun, I gave me my boyfriend."
[cpg cn=true]

You've become naïve. I guess my words had the opposite effect.
[cpg]



[SE f="se024"]
;//【ＳＥ】『ドア乱暴に閉まる』

[free time=1000]

Kaoruko runs out of the clubroom. No one is chasing after her.
[cpg]


;//ＢＫ

;//薫子に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=3000]

[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

I was full of wounds.
[cpg]

Because I really thought that if I didn't tell a lie like that, they would take it.
[cpg]

So I don't think I'm bad. It's not bad, it's just bad. ......
[cpg]

I don't know who it is ...... anymore. Is it still my fault?
[cpg]

Once I had discovered the pleasure of being lifted up by boys, I had never been able to quench this feeling.
[cpg]

On the way home from college, the sign for a host club suddenly flickers.
[cpg]

I can definitely be adored there.
[cpg]

......Yes, that's fine. I thought for a moment, and then shook it off.
[cpg]

I don't have the money to go to such a place, nowhere. I am still a student and don't have a part-time job to begin with.
[cpg]



;//ＢＫ
[free time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]

Many times, I tried to shake it off. This desire.
[cpg]

I want to be pampered. I want to be adored. I want to be accepted. ......
[cpg]

But I couldn't shake it. I stepped into a place I had never been before, a host club.
[cpg]




;//夏樹に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_00.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=3000]


[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（昼）******************************************************

Lunch break. We were in the club room of our circle. But Kaoruko was not there.
[cpg]

[OnName num="kimoto"]
...... Kaoruko-dono hasn't been coming here lately."
[cpg cn=true]

[OnName num="tokuzawa"]
I don't want to see her. I don't even want to look at that woman."
[cpg cn=true]

That's a terrible thing to say. But I can't cover for anything.
[cpg]

I felt that even if I covered for him in a strange way here, it would be rather counterproductive.
[cpg]

That's how greatly what Kaoruko did had left scars.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア開く』

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[WAIT time=1500]

[VOICE f="Kaoruko960"]
[OnName num="kaoruko"]
...... Oh, um, I'm sorry."
[cpg cn=true]

[OnName num="natsuki"]
"Oh, Kaoruko ...... sorry, what's wrong?"
[cpg cn=true]

As usual, the boys have largely ignored me.
[cpg]

They just glance at me the moment I enter the room, and I don't take them seriously. However, Kaoruko told me that I had to deal with them.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko961"]
[OnName num="kaoruko"]
Can anyone lend me that ...... money?"
[cpg cn=true]

[OnName num="natsuki"]
Huh. ......?"
[cpg cn=true]

[OnName num="tokuzawa"]
What kind of money is ......"
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko962"]
[OnName num="kaoruko"]
Please ...... I really need the money ......"
[cpg cn=true]

Kaoruko is asking me for money that she doesn't know what to use for, and she is hanging on to me.
[cpg]

[OnName num="natsuki"]
Wait, what do you need the money for? What do you need the money for?"
[cpg cn=true]

[OnName num="natsuki"]
I know that nerdy hobbies cost money, but it's not something I'd borrow from someone ......."
[cpg cn=true]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Kaoruko963"]
[OnName num="kaoruko"]
"It's ...... the goods I really want ...... that..."
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]

After that, she kept hanging on to it, insisting, so I decided to lend her some of it anyway.
[cpg]

That made the situation go away, but the next day, and the next, and the day after that: ......
[cpg]

[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_03_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************

;//♪私服（パンツスタイル）

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko964"]
[OnName num="kaoruko"]
"...... anyone, can you lend me some money, ......?"
[cpg cn=true]

[OnName num="tokuzawa"]
I won't lend it to you. I won't lend it to you."
[cpg cn=true]

The response is chilling. That's as it should be.
[cpg]

[OnName num="tokuzawa"]
I hear you're using the money you borrowed to go to host clubs."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Kaoruko965"]
[OnName num="kaoruko"]
Who told you that!"
[cpg cn=true]

[OnName num="kimoto"]
It is from Yui-dono, that it is. I don't think she would lie, that she wouldn't."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko966"]
[OnName num="kaoruko"]
"Oh, no. ......"
[cpg cn=true]

I can't help it anymore. I can feel Kaoruko's heart breaking.
[cpg]

There is no good enough reason to lend money in the first place. I don't care if she was once a pampered princess. ......
[cpg]

[OnName num="natsuki"]
"...... give it up already, Kaoruko. And don't go to the host any more. ......
[cpg cn=true]

Kaoruko stares at me. Her eyes are moist and she looks like she is about to cry.
[cpg]

I can't have you making that kind of face at me. I can't help you, Kaoruko.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko967"]
[OnName num="kaoruko"]
I ...... sure, I was a princess then."
[cpg cn=true]

[OnName num="shinjo"]
'That was a long time ago. Now we're different."
[cpg cn=true]

[OnName num="tokuzawa"]
Shinjo is right. We don't pamper people anymore."
[cpg cn=true]

[OnName num="tokuzawa"]
I've seen what women are really like. ......
[cpg cn=true]

Tokusawa-senpai is particularly harsh. Once, he must have been fascinated by her, too.
[cpg]

But Kaoruko has done so much that it can't be helped.
[cpg]

[OnName num="tokuzawa"]
If you insist, you must have something to pay for it. You have to give me something in exchange for the money."
[cpg cn=true]

So I knew what Tokusawa-senpai was asking for by implication.
[cpg]

And Kaoruko must have realized it already. Her hands are clenched tightly and she is trembling.
[cpg]


;//●ＣＧ（ヒロイン・辛そうに立って居るヒロイン：サークル部室）ev_39
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_39_0 ***********************
[CG id=15 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]


[VOICE f="sKaoruko027"]
[OnName num="kaoruko"]
Please ...... money, I'm short."
[cpg cn=true]

[OnName num="shinjo"]
I can't lend you what I can't lend you, no matter what you say."
[cpg cn=true]


[VOICE f="Kaoruko970"]
[OnName num="kaoruko"]
Don't say that. ...... I, for one, have no other choice."
[cpg cn=true]

Tokusawa-senpai sighed with a huff. And,
[cpg]

[OnName num="tokuzawa"]
If you insist, then I guess I'll have to do it."
[cpg cn=true]

;//移植のためシーンをカットしています

;//ＢＫ

;//移植のためシーンをカットしています

;//ＢＫ

;//●ＣＧ（ヒロイン・ソファーに寝ているヒロインに男達が群がる：サークル部室）ev_43
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_43_0 ***********************
[CG id=16 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]

And then he pressed Kaoruko. I just watched the scene in silence.
[cpg]

In this crazy situation ...... I was the only one who didn't get mixed up.
[cpg]

I was just trying to see where it was going. ......
[cpg]



Halfway through, I felt sick and left the room.
[cpg]


[VOICE f="sKaoruko028"]
[OnName num="kaoruko"]
...... Natsuki-kun?"
[cpg cn=true]


[OnName num="natsuki"]
I'm sorry. I'm going home."
[cpg cn=true]

[SE f="se019"]
;//【ＳＥ】『ドア開ける』

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

[OnName num="natsuki"]
You can find it at ......."
[cpg cn=true]

As my boyfriend, what is the right thing for me to do?
[cpg]

Should I have stopped her after all? Or is it right to mix it up and hold her?
[cpg]

I was also unsure of my own feelings.
[cpg]

But one thing is for sure: ...... love for Kaoruko has not yet withered.
[cpg]

I still think she is a pretty girl, and if you ask me if I like her, I will say I do.
[cpg]

I have a tendency to lie and have too much of a need to be recognized, but ......
[cpg]

I want to keep my boyfriend. That's what I thought.
[cpg]




;//ＢＫ
;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（昼）******************************************************

Our relationship seemed to be on the verge of being established, but it didn't work out that way.
[cpg]

After all, this can't go on forever.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="sKaoruko029"]
[OnName num="kaoruko"]
Oh, that ...... money ......"
[cpg cn=true]

She looks like a little girl selling matches. Such a sympathetic face. But it is useless to make any kind of face.
[cpg]


[OnName num="tokuzawa"]
"Shut up, I'm telling you I'm already empty!"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="sKaoruko030"]
[OnName num="kaoruko"]
Please ......."
[cpg cn=true]

I had one genuine question.
[cpg]

What is the reason for going to a host club so much, knowing that it costs money?
[cpg]

[OnName num="natsuki"]
......Why do you get so involved in hosting?"
[cpg cn=true]

He looks at me and takes my hand.
[cpg]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kaoruko1038"]
[OnName num="kaoruko"]
"There is no other place to do me anymore! So ...!"
[cpg cn=true]

A place to be pampered. Yes, that's what she should have had once.
[cpg]

I don't know about me, but Kaoruko is a girl too. I wonder if she will understand the attraction of host clubs.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko1039"]
[OnName num="kaoruko"]
"Please! Please, help me."
[cpg cn=true]

They squirm. And then they get down on their knees.
[cpg]


[SE f="se029"]
;//【ＳＥ】『衣擦れ』

[free time=800]

Kaoruko even got down on her knees at the end, but no one finally gave her any money.
[cpg]

[OnName num="shinjo"]
I don't want you to get down on your knees. ...... bfft, look up."
[cpg cn=true]

Shinjo-senpai is a kind-hearted person. He gets down on his knees and is just upset.
[cpg]

[OnName num="tokuzawa"]
They said, "Let them do it. It's none of our business."
[cpg cn=true]

[OnName num="kimoto"]
"Yes, that's right, that it is. It's not our fault ......"
[cpg cn=true]

However, the reaction of the other two was quite harsh.
[cpg]

It is a natural result. But will Kaoruko accept it as a matter of course?
[cpg]



;//ＢＫ
;//移植のためシーンをカットしています
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

Walking on the way to school in the morning. The usual path to school, the usual morning.
[cpg]

The only difference is that Kaoruko is not next door.
[cpg]

That seemed more dangerous than lonely. I wonder where she is now and what she is doing.
[cpg]



;//ＢＫ
[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


Kaoruko's money ran out, our money ran out, that day.
[cpg]

Since that day, Kaoruko completely stopped coming to the university.
[cpg]

I don't know what happened ...... maybe he started working part time.
[cpg]

I speculated a lot about whether he was so into it that he threw himself out of college or something like that. ......
[cpg]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************


Then, in the end, no one knew what happened to Kaoruko.
[cpg]

It's the kind of story that broke all connections in search of a connection.
[cpg]

Peace had returned to our circle, but it was as if there was a hole in it somewhere.
[cpg]

Even now, I feel as if Kaoruko might open the door and walk in.
[cpg]

I answered the knock on the door with this imagination.
[cpg]

[SCENE id=15]

[jump storage="epend.ks" target="*start"]
;//【ルート３】エンド

