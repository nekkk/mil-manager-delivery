
*start|The Fluctuation of a Princess

;#################################################
*Ep006|The Fluctuation of a Princess
;#################################################

[SCENE id=6]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]


The lecture went on, and after lunch, the evening was completely over.
[cpg]

;//【ＢＧ】『サークル部室』（夕方）******************************************************


[OnName num="shinjo"]
We all gathered here," she said, "and I'm looking forward to the party. I'm looking forward to the drinking party.
[cpg cn=true]

Kaoruko and I were the last to arrive at the clubroom.
[cpg]

It seemed that everyone had been waiting for us. The moment I opened the door, everyone turned to me.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kaoruko544"]
[OnName num="kaoruko"]
I'm sorry for making you wait.
[cpg cn=true]

[OnName num="tokuzawa"]
I'm not waiting for you. Hey, Kimoto.
[cpg cn=true]

[OnName num="kimoto"]
That's right. I can wait as long as you want, that I can wait for the princess.
[cpg cn=true]

Kimoto, who had been so calm in the morning, turned out to be like this in front of Kaoruko.
[cpg]

After all, the presence of the princess in Otasa is immense. ......
[cpg]

[OnName num="tokuzawa"]
Let's go, then. Now that the five of us are here.
[cpg cn=true]

[OnName num="natsuki"]
I guess so. Then let's go. ......
[cpg cn=true]

We left the club room, taking a bit of trouble to put away the games and stuff.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

As usual, I walk alone again, a little apart from the others.
[cpg]

The other two are walking side by side so that they can be as close to Kaoruko as possible.
[cpg]

I don't really feel anything when I see this. It's a familiar sight.
[cpg]

I just can't help but feel a little sad that I am the boyfriend. And there is one more harm.
[cpg]

[OnName num="kimoto"]
The other day, I went out of my way and bought a box of them, that I did.
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Kaoruko545"]
[OnName num="kaoruko"]
Really?　Let's have a screening in the clubroom next time.
[cpg cn=true]

[OnName num="tokuzawa"]
I agree with you. I've been curious about it for a long time.
[cpg cn=true]

[OnName num="shinjo"]
I watched it in real time. I don't know what to do. ......
[cpg cn=true]

[OnName num="natsuki"]
Oh, um, me too. ......
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

Even if I wanted to engage in geek talk, I can't mix with them because I'm the only one stepping back.
[cpg]

That's right, I joined the circle because I wanted to talk about otaku stuff.
[cpg]

Since I started dating Kaoruko, I feel like this circle is no longer functioning as a normal otaku circle.
[cpg]

I feel like the conversations between the guys are becoming less and less casual. Without Kaoruko, the princess, there is no conversation.
[cpg]

I thought to myself, "That's a good thing or a bad thing. ...... I followed her, unable to even mention it.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『居酒屋』（夕方）******************************************************

We arrived at the izakaya. We took advantage of the opportunity to talk about otaku with Hime.
[cpg]

I thought, "I can join in the conversation at the pub table. That's what I thought. ......
[cpg]

[OnName num="kimoto"]
......What a coincidence, that it is.
[cpg cn=true]

Kimoto in a whisper. I don't think it's a coincidence, I chose the same restaurant and the same table as before, so here we are.
[cpg]

[OnName num="shinjo"]
Why is that group of gals from the other day here, ......?"
[cpg cn=true]

At the next table, another group of gals were making a lot of noise with high-pitched voices. I think it was someone named Yui and her cronies.
[cpg]

[OnName num="tokuzawa"]
Let's just leave them alone. We don't have anything to do with her anyway.
[cpg cn=true]

[OnName num="tokuzawa"]
It's not that I'm sore loser or anything, I'm just saying that I don't want that girl in my life.
[cpg cn=true]

Also, Tokusawa-senpai speaks out loudly enough to be heard. Then, as if in tune with it,
[cpg]

[OnName num="kimoto"]
That's right. Anyway, a gal like that won't understand our noble taste, that she won't."
[cpg cn=true]

And even Kimoto got on board. He was quite drunk.
[cpg]

[OnName num="tokuzawa"]
Yes, yes. They probably think we are trash or insects.
[cpg cn=true]

They probably think we're trash or insects," he says, and gets into the mood.
[cpg]

[OnName num="shinjo"]
"Compared to that, the princess is a wonderful being. ......
[cpg cn=true]

[OnName num="kimoto"]
"Yes, she's too good for us, that she is."
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kaoruko546"]
[OnName num="kaoruko"]
'Heh, is that so,......?　Am I prettier than those girls?
[cpg cn=true]

[OnName num="tokuzawa"]
"Of course you are. It's not comparable.
[cpg cn=true]

In the beginning, this was fine. Kaoruko could stay in a good mood while talking bad about others.
[cpg]

However, the wind gradually changed.
[cpg]

I was the only one who was calm, so I could tell, but I felt the gals were gradually turning their attention toward me.
[cpg]

And it was these words that triggered it.
[cpg]

[OnName num="tokuzawa"]
In our stoic life, gals like you are rather harmful to us!　Hey, Sugiura.
[cpg cn=true]

[free time=1000]


[OnName num="gal_A"]
We're what?
[cpg cn=true]

[OnName num="shinjo"]
"Hi!"
[cpg cn=true]

Four gals at the next table, one of whom seemed to be the leader of the group, brought a chair over to us and attached it to ours.
[cpg]


;//♪三人

[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="4/5" time=800]

All the other gals were looking at me. As an otaku, this is the worst situation I've ever been in.
[cpg]

Not only Senpai and Kimoto, but even Kaoruko and I didn't like this situation.
[cpg]

[FACE method="shake_3" pos="2/5"]
[OnName num="gal_A"]
;//「害毒とかなんとか、言ってたじゃん？　あんまりじゃね？」
You said something about "toxic," didn't you?　Isn't that awful?"
[cpg cn=true]

Like a frog staring at a snake. Kaoruko was in the same situation.
[cpg]

Her face was pale and her face was scrunched up.
[cpg]

[OnName num="kimoto"]
I don't know if it was a slip of the tongue or not, that I didn't mean it, that I didn't mean it.
[cpg cn=true]



It was Kimoto who was the first to utter an excuse. Hearing this, the gals were laughing.
[cpg]


[FACE method="bow_2" pos="4/5"]
[OnName num="gal_B"]
They said, "That it is, that it is!　I didn't know there were people like that nowadays, ha ha ha ha.
[cpg cn=true]

[OnName num="gal_C"]
"That's really funny, that's too bad, isn't he a natural monument?"
[cpg cn=true]

[OnName num="gal_D"]
"A natural monument!　That's a good idea. We have to protect them.
[cpg cn=true]

[FACE method="bow_3" pos="2/5"]
[OnName num="gal_A"]
"Wait a minute, don't say something that freaks them out. The geeks are freaking out!
[cpg cn=true]

The three gals started laughing at us, and a gal named Yui started defending us. What was she trying to do?
[cpg]

[FACE method="change_1" pos="2/5"]
[OnName num="gal_A"]
"You guys are from a group called Nantoka, aren't you?　Hyundai, Nantoka, the research institute?
[cpg cn=true]

[FACE method="shake_1" pos="4/5"]
[OnName num="gal_B"]
Yui, your memory is so bad. It's the Modern Contents Research Group, I think.
[cpg cn=true]

[FACE method="bow_2" pos="2/5"]
[OnName num="gal_A"]
That's right. And we were in Otasaer, right?
[cpg cn=true]

The suddenness of the event had everyone frozen in place.
[cpg]

The two seniors, Kimoto, myself and Kaoruko. I don't know how Kimoto managed to speak up.
[cpg]

[FACE method="shake_1" pos="2/5"]
[OnName num="gal_A"]
"You don't have to be so nervous," he said. We're not prejudiced against otaku.
[cpg cn=true]

[OnName num="gal_C"]
I don't have any prejudice against otaku. I read manga as much as you do.
[cpg cn=true]

We and a group of gals are not supposed to be water and oil, we are not supposed to cross paths. I felt that it would be very bad if we were to come into contact here.
[cpg]

However, Yui took charge of everything on her own.
[cpg]

[FACE method="bow_2" pos="2/5"]
[OnName num="gal_A"]
She said, "Alright, let's switch seats!　We are, let's see, nine people?　Let's drink with the nine of us.
[cpg cn=true]

[OnName num="gal_D"]
"Come here, you. Don't worry, I'll be nice to you.
[cpg cn=true]

[OnName num="tokuzawa"]
Come on, don't touch me.
[cpg cn=true]

[OnName num="gal_B"]
What are you, a germaphobe?　Is that why you wear gloves?　I mean, what are those gloves?"
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


So, we were drinking in a messy, chaotic situation.
[cpg]


;//【ＢＧ】『居酒屋』（夜）******************************************************

[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[OnName num="gal_B"]
The latest anime is a hot topic, isn't it?　What is it called?　Cool Japan?
[cpg cn=true]

[OnName num="gal_C"]
"Well, to be honest, we don't watch anime at all, so can you teach us?
[cpg cn=true]

[OnName num="kimoto"]
"Yes, that's right, recently, um, um..."
[cpg cn=true]


The very first thing that makes me nervous is the fact that I have to be in contact with women other than Kaoruko.
[cpg]

It was impossible not to be nervous. Kimoto is one of the ones who can hold a conversation with them.
[cpg]

[OnName num="shinjo"]
"Oh, I'm leaving, I'm leaving.
[cpg cn=true]

[OnName num="gal_D"]
"Wait a minute. You haven't had a drink yet, have you?
[cpg cn=true]

Shinjo was about to leave the line of fire by himself.
[cpg]

And I'm no exception, of course. Just because I have a girlfriend doesn't mean I have a tolerance for gals.
[cpg]

;//♪二人

[free time=300]

[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_6"  pos="4/5" time=800]

[OnName num="gal_A"]
She's so shy, she's so cute. Is she your girlfriend?
[cpg cn=true]

[FACE method="bow_3" pos="2/5"]
[VOICE f="Kaoruko547"]
[OnName num="kaoruko"]
"Yes, I'm Natsuki's girlfriend. I am Natsuki-kun's girlfriend. So, please don't be so sticky with me.
[cpg cn=true]

[FACE method="shake_2" pos="4/5"]
[OnName num="gal_A"]
I know, I know. You don't have to make such a scary face.
[cpg cn=true]

Kaoruko is poking me with her finger. She looks very, very scared.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


In the end, the five of us had to leave the pub that day with wounds all over our bodies.
[cpg]

The gals went back in different directions. Or rather, they didn't want to take the same route home, so they took the long way around.
[cpg]

[OnName num="kimoto"]
'You got yourself into a hell of a mess, .......'
[cpg cn=true]

[OnName num="shinjo"]
"......Yes, fuh, fuhuh......."
[cpg cn=true]

[OnName num="tokuzawa"]
'...... but there were a lot of pretty girls, weren't there?'
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]

Kaoruko keeps looking down with a terrible look on her face. Probably, she is angry that she was almost taken away from her followers.
[cpg]

[FACE method="change_3" pos="2/3"]

However, you can't get mad at them to their face. She probably thinks that she can't compete with the otaku girls and the gals.
[cpg]

[OnName num="natsuki"]
Was there such a thing as a cute girl ......?"
[cpg cn=true]

I tried to follow up with Kaoruko, but it had the opposite effect.
[cpg]

[OnName num="kimoto"]
"Yes, indeed, Yui-dono was very pretty."
[cpg cn=true]

[OnName num="shinjo"]
"Maybe so, but ...... umm......?"
[cpg cn=true]

Kaoruko's face is getting scarier and scarier. It's not good.
[cpg]



;//ＢＫ
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1100]

I hoped that today's event would not have a lasting effect. That's all I could hope for.
[cpg]


;//薫子に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=3000]


[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『大学教室』（昼）******************************************************


Kaoruko Mizuki. Sometimes, I am told that my name is like an anime name.
[cpg]

I like anime myself, so I don't mind being called that.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko548"]
[OnName num="kaoruko"]
"......"
[cpg cn=true]

I am the princess of Otasaer. I was aware of and accepted the fact that I was a princess.
[cpg]

My hand gripping the pen becomes tighter as I attend the lecture. My guts boil just remembering what happened yesterday.
[cpg]

I am horrified just to imagine that the faith that I have been building up one by one, that I have allowed to build up, was taken away from me in an instant by those ...... guys.
[cpg]

I am horrified and angry at the same time. I wonder what they meant to talk to us.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（夕方）******************************************************

But it's okay. Lectures are over again today, and everyone welcomes me when I go to the clubroom.
[cpg]

That place is the only place that accepts me. They pamper me. They praise me.
[cpg]

They accept me. They comfort me. They call me goddess, angel, princess.
[cpg]

I can't lose them. It was becoming too important a place for me.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************


It's okay. The faith I have built up is rock solid. It would not collapse so easily.
[cpg]

That's what I believed when I went to ......
[cpg]

[OnName num="kimoto"]
"Oh, Princess. Good evening, that it is.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko549"]
[OnName num="kaoruko"]
Good evening, Kimoto-kun. I'm not sure if you're a good friend of mine or not, but I'm sure I'm a good friend of yours.
[cpg cn=true]

[OnName num="kimoto"]
Sugiura is still at his lecture, isn't he?
[cpg cn=true]

[OnName num="shinjo"]
Yes, he is. Yes, I think this time is already occupied.
[cpg cn=true]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kaoruko550"]
[OnName num="kaoruko"]
Then, Tokusawa-senpai is at .......
[cpg cn=true]

Somehow, they both seemed reluctant to say it. Then, Kimoto-kun said to me.
[cpg]

[OnName num="kimoto"]
He said, "I was taken by a gal sometime, that I was. She came into the club room and forced me to ......"
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]

My blood suddenly drained from my veins. No way, I thought.
[cpg]

[OnName num="shinjo"]
I'm so jealous of you. ......
[cpg cn=true]

Shinjo-senpai's line also caught my attention, but that's not the point now.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko551"]
[OnName num="kaoruko"]
I'm not sure what you mean ...... by "taken away."
[cpg cn=true]

[OnName num="kimoto"]
He said he was going to give me a lecture on otaku culture.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko552"]
[OnName num="kaoruko"]
I'm in a hurry.
[cpg cn=true]


;//ＢＫ


I'm in a hurry. I'm in a hurry. I didn't think this would happen. I thought that everyone was a geek, and that gals weren't even on their radar.
[cpg]

I thought they were all geeks, and I didn't think they had any interest in gals.　And what do you mean you're jealous?
[cpg]



;//夏樹に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_00.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=3000]


[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p5_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

After the lecture, the sun had completely set and it was nighttime.
[cpg]

Today, too, Kaoruko was sticking to me. But the expression on her face when she was sticking close to me didn't look like she was enjoying herself.
[cpg]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kaoruko553"]
[OnName num="kaoruko"]
She said, "...... will be taken away from me, if I don't do something, they will all be taken away from me."
[cpg cn=true]

She was whispering in a voice that was barely audible.
[cpg]

[OnName num="natsuki"]
"...... are you okay?　Kaoruko.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko554"]
[OnName num="kaoruko"]
Kaoruko: "Yeah, I'm fine. I'm fine.
[cpg cn=true]

She says it's okay in that dark tone. She doesn't look very okay.
[cpg]

;//移植のためシーンをカットしています
;//ＢＫ
;//移植のためシーンをカットしています

When we are alone on a date, she seems to be happy, even if it's only once in a while.
[cpg]

Kaoruko seems to have regained some of her mood. That's the best thing, and I should be honestly happy too. ......
[cpg]

The confrontation with the group of gals led by Yui was not over yet.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

The four of us otaku had to hold an emergency meeting.
[cpg]

Tokusawa-senpai was invited by the group of gals to go out for karaoke.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（昼）******************************************************

[OnName num="kimoto"]
What are you going to do, Mr. Tokusawa, are you going to go to ...... by yourself?
[cpg cn=true]

[OnName num="tokuzawa"]
"Don't be silly, there's no way I can do that.
[cpg cn=true]

[OnName num="shinjo"]
"Well, in that case, I'll go with you,......?　I'll go with you, then.
[cpg cn=true]

Shinjo-senpai takes it in stride with ulterior motives.
[cpg]

The actual "I'm not sure how much I'm going to be able to do with it, but I'm sure I'll be able to do it.
[cpg]

[OnName num="kimoto"]
By the way, what's wrong with Hime, that it is?
[cpg cn=true]

[OnName num="natsuki"]
She seems to have caught a cold. I have to go visit her later, too. ......
[cpg cn=true]

[OnName num="tokuzawa"]
I'm sure she won't be too upset if I do. The four of us are not even guilty of being invited to karaoke, are we?
[cpg cn=true]

[OnName num="shinjo"]
That's right. Tokuzawa, we are also invited, right?
[cpg cn=true]

[OnName num="tokuzawa"]
"Yeah. This guy Yui said to bring the rest of them."
[cpg cn=true]

Now what should I do? Should I go too or not?
[cpg]

I'm sure you can go to visit them since karaoke isn't something you can sing for that long. ......
[cpg]

[OnName num="natsuki"]
I understand. I'll go too, Tokusawa-senpai."
[cpg cn=true]

[OnName num="tokuzawa"]
I see. ...... No, having Sugiura there will help."
[cpg cn=true]

[OnName num="natsuki"]
What?　Why?
[cpg cn=true]

[OnName num="tokuzawa"]
He's the only one who has a girlfriend, right? I'm sure he's better with women than we are.
[cpg cn=true]

Oh, that's not ...... true at all.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

;//♪gyarurun三人

[SE f="se027"]
;//【ＳＥ】『喧騒』

I then contacted Yui and the others through Tokusawa-senpai, and we met up with them.
[cpg]

[FACE method="shake_1" pos="2/5"]
[OnName num="gal_A"]
I'm not sure if it's a good idea to go to the same place as the others, but I'm sure it's a good idea.
[cpg cn=true]

[FACE method="bow_1" pos="4/5"]
[OnName num="gal_B"]
"You know, in front of the station, there's a big, stupid place.
[cpg cn=true]

[OnName num="gal_C"]
"Well, it could be anywhere, couldn't it?　I'm probably not used to karaoke.
[cpg cn=true]

One of the gals turns around while saying so.
[cpg]

The four of us looked away. We all turned our heads away.
[cpg]

I wondered if this was going to be a proper karaoke session.
[cpg]

It's possible that the four of us will end up not singing at all. ......
[cpg]

[OnName num="kimoto"]
I guess it was a mistake to come here after all.
[cpg cn=true]

[OnName num="shinjo"]
But it's a rare chance to get to know the girls. ......
[cpg cn=true]

;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


Each of us has our own feelings. I also wished behind the scenes that it would go well.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/5" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="4/5" time=1]
[BG f="b_09_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）
;//【ＢＧ】『カラオケ店内』（昼）******************************************************

;//カラオケ店内なので、上下に黒帯をつけるなどして別の場所である演出をしてください


As for the karaoke, the party was unusually lively.
[cpg]

I was thankful that the gals were good at enlivening the party, or rather, they chose the songs that would make us feel comfortable.
[cpg]

They chose a few nationally known ani-songs, which we could sing along to. .........
[cpg]

[FACE method="shake_1" pos="2/5"]
[OnName num="gal_A"]
He said, "Well, you pick the songs this time. Use your own taste.
[cpg cn=true]

[OnName num="kimoto"]
"Am I right, that I am, ......?"
[cpg cn=true]

Kimoto chose a safe ani-song of a band and put it in, and sang it enthusiastically.
[cpg]

And here, a fact we didn't know was revealed.
[cpg]

[OnName num="tokuzawa"]
Kimoto sang, "...... Kimoto, seriously, ......?"
[cpg cn=true]

Kimoto's singing was so good.
[cpg]

[FACE method="bow_2" pos="4/5"]
[OnName num="gal_B"]
He sang so well!　Do you go to karaoke?　You know..."
[cpg cn=true]

[OnName num="kimoto"]
"Leave it alone, that you should!　Everyone has their own hobbies, that they do.
[cpg cn=true]

[FACE method="shake_2" pos="2/5"]
[OnName num="gal_A"]
"There's no need to be embarrassed. It was really great, I fell in love with it.
[cpg cn=true]

The karaoke session continued from there. Tokusawa-senpai's song selection was also a hit with the gals.
[cpg]

And Shinjo chose a burning tokusatsu (special effects) song from ......, which was also a big hit.
[cpg]

[OnName num="gal_C"]
It was a lot of fun. Cross-cultural exchange?　That's great. My impression of otaku has changed.
[cpg cn=true]

[OnName num="gal_D"]
I thought you'd be more gloomy.
[cpg cn=true]

It wasn't much of a compliment, but still, it wasn't a bad impression.
[cpg]

The girls are more friendly than I expected, and they are not as cold toward nerds as they claim to be.
[cpg]

[OnName num="tokuzawa"]
I'm not sure if they're prettier than the princesses at ......," Tokusawa-senpai spilled out.
[cpg cn=true]

I didn't miss Tokusawa-senpai's comment.
[cpg]

But I don't think that's an unreasonable comment. Because these girls are just gals and they are cute. ......
[cpg]

Of course, I'm Kaoruko's boyfriend, so I can't think that way either.
[cpg]

Kimoto and the older guys seemed to really enjoy interacting with the gals.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]


Later, after the karaoke was over, I went to visit Kaoruko.
[cpg]

But Kaoruko was not at home. I imagine that she must have had a cold, but she forced herself to come to the university .......
[cpg]

When I imagined it, I also imagined a bad situation.
[cpg]

[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************


Another day. A weekday, after lectures.
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kaoruko595"]
[OnName num="kaoruko"]
I asked, "...... why was there no one in the clubroom the other day?"
[cpg cn=true]

The day the five of us gathered in the club room again, Kaoruko asked me this.
[cpg]

[OnName num="shinjo"]
Buch, that's because I went to karaoke with those girls at ......."
[cpg cn=true]

[OnName num="tokuzawa"]
Don't say that, you idiot!
[cpg cn=true]

[FACE method="change_3" pos="2/3"]

Shinjo-senpai's slip of the tongue froze the air in the clubroom.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko596"]
[OnName num="kaoruko"]
'...... you called me a princess, didn't you,......?
[cpg cn=true]

[OnName num="kimoto"]
No, no, I was really taken by force, that is true.
[cpg cn=true]

It is a lie. But if I don't tell such a lie, I can't get rid of it.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko597"]
[OnName num="kaoruko"]
I can't believe you don't like me anymore.　I can't believe you're friends with those girls."
[cpg cn=true]

[FACE method="change_3" pos="2/3"]
[VOICE f="sKaoruko017"]
[OnName num="kaoruko"]
I can't stand those girls with no modesty ......!
[cpg cn=true]

When he said that much, a sense of uneasiness spread among the boys.
[cpg]

That is, I want to be friends with Hime. But I was not amused to hear Yui and the others, with whom I had made friends at the last moment, talk about me like that.
[cpg]

I can understand such feelings of everyone just by looking at them. But don't say it, don't say it, okay?
[cpg]

[OnName num="tokuzawa"]
You're going too far with the whole "...... no modesty" thing."
[cpg cn=true]

He said, "No, you can't say it, you can't say it. ......
[cpg]

[OnName num="kimoto"]
I don't dislike the princess, that I don't dislike her. It is true, that it is.
[cpg cn=true]

Kaoruko is frustrated by the current situation. She bites her lip and you can tell without saying a word that she's frustrated.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア開く』
;//♪三人

[free time=300]
[FG f="CHA01_p1_03_a.ui" method="change_3"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=800]
[OnName num="gal_A"]
Hi, how are you doing?
[cpg cn=true]


[FACE method="shock_5" pos="1/3"]

And then Yui came in. Four people came into the clubroom with their usual cronies.
[cpg]

[FACE method="shake_7" pos="2/3"]
[OnName num="gal_A"]
What's the matter?
[cpg cn=true]

[FACE method="shake_3" pos="1/3"]
[VOICE f="Kaoruko599"]
[OnName num="kaoruko"]
"Or, please don't come in here without permission if you're not a member.
[cpg cn=true]


[FACE method="shake_2" pos="2/3"]
[OnName num="gal_A"]
If they ask us to become members, we will become members. Hey.
[cpg cn=true]

[FACE method="bow_1" pos="3/3"]
[OnName num="gal_B"]
"Mochi. We want to be friends with these girls, seriously.
[cpg cn=true]

Sparks fly between Kaoruko and Yui-san. However, Kaoruko is getting pushed around quite a bit.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_03_a.ui" method="change_3"  pos="1/3" time=1]
[FG f="CHA02_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[FG f="CHA03_p1_01_a.ui" method="change_1"  pos="3/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

To say that nothing special happened that day is an understatement.
[cpg]

The gals and us boys had a conversation, which Kaoruko occasionally tried to stop.
[cpg]

The situation was dangerous, but no one in particular exploded.
[cpg]

And then Yui and the guys left.
[cpg]

;//【ＢＧ】『サークル部室』（夕方）******************************************************

[FACE method="bow_2" pos="2/3"]
[OnName num="gal_A"]
I'll be back again. I'll be back, yoro.
[cpg cn=true]


[free time=1000]
[FG f="CHA01_p1_03_a.ui" method="change_3"  pos="2/3" time=1000]
[WAIT time=1000]


[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko600"]
[OnName num="kaoruko"]
"......."
[cpg cn=true]

Kaoruko stopped saying anything with a drawn-out smile. Then, a while after the gals left.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko601"]
[OnName num="kaoruko"]
"Come here, Natsuki-kun."
[cpg cn=true]

[OnName num="natsuki"]
What?"
[cpg cn=true]

They take me by the hand and force me out of the circle room.
[cpg]

I wonder if Kaoruko realizes that just being seen in this kind of situation does not make a good impression on the remaining three.
[cpg]

;//移植のためシーンをカットしています
;//移植のためシーンをカットしています
;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_03_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（夕方）******************************************************

[OnName num="natsuki"]
"......Why are you in such a hurry?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko638"]
[OnName num="kaoruko"]
That's ......."
[cpg cn=true]

Kaoruko is at a loss for words. I knew almost everything, but I wanted to hear it from Kaoruko's mouth.
[cpg]

[OnName num="natsuki"]
If you don't tell me, I won't understand.
[cpg cn=true]

[OnName num="natsuki"]
If there is something I can help you with, I might be able to help you.
[cpg cn=true]

Hearing these words, Kaoruko started to cry.
[cpg]

This was also so sudden that I flinched and pulled back a little.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko639"]
[OnName num="kaoruko"]
All the boys are going to be taken away from me. ...... by those girls. ......
[cpg cn=true]

She cried and complained. I knew she was bitter about it.
[cpg]

For Kaoruko, that place must have been very comfortable.
[cpg]

That place where you are treated like a princess and everyone is working for you.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko640"]
[OnName num="kaoruko"]
And Natsuki-kun, too, will be taken away someday.
[cpg cn=true]

[OnName num="natsuki"]
I'll be fine. I won't leave Kaoruko's place.
[cpg cn=true]

In a way, he really meant it. But secretly, I thought it was a bit troublesome.
[cpg]

[OnName num="natsuki"]
But if you don't want everyone to be taken, you have to take measures. Kaoruko is the only one who can think of that.
[cpg cn=true]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kaoruko641"]
[OnName num="kaoruko"]
I don't know, I don't know.
[cpg cn=true]

She began to complain like a child.
[cpg]

He even held himself hostage and said something like this.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko642"]
[OnName num="kaoruko"]
If I don't do anything, I might kill myself. ...... If I get hurt badly, Natsuki-kun won't like it either, will he?
[cpg cn=true]


[switch]
[case "You might be right."]
	[swap]
	[jump target="*select03_1"]
[case "Of course."]
	[swap]
	[jump target="*select03_2"]
[endswitch]

;//■選択肢
;//
;//１、そうかもしれない
;//２、勿論だ
;//
;//==============================
;//１、そうかもしれない
*select03_1|The Fluctuation of a Princess

[stflag boolean3 = 1]


[OnName num="natsuki"]
'......You might be right.'
[cpg cn=true]

I couldn't strongly affirm that. That's how troublesome it was.
[cpg]

Whether or not she heard my vague affirmation, Kaoruko continued to cry.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko643"]
[OnName num="kaoruko"]
She kept crying in my chest.
[cpg cn=true]

She continued to cry in my chest. Although I patted her head, Kaoruko was becoming a little estranged from me.
[cpg]

The feeling of love has not completely disappeared. Rather, it continues to be in my heart.
[cpg]

But that doesn't mean that I'm going to hold on to them by saying ...... that I'm going to commit suicide.
[cpg]

I have been feeling a little sick for a while now, but now it's time, I thought.
[cpg]

I thought, "This is troublesome. ......
[cpg]

[jump target=*junction03]
;//==============================
;//２、勿論だ
*select03_2|The Fluctuation of a Princess

[OnName num="natsuki"]
I'm not going to say suicide, of course. You can't talk about suicide that easily."
[cpg cn=true]

I held her back strongly. This was a word that came from the heart.
[cpg]

Although I thought it would be troublesome, I would still be sad if she had suddenly died.
[cpg]

That's how much I love her.
[cpg]

No matter how far I go, she and I will always be lovers. If I deny that, there is nothing more.
[cpg]

I have my troublesome moments, but it doesn't mean that I have lost my love for her.
[cpg]


;//==============================
*junction03|The Fluctuation of a Princess

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_03_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

After that, I returned to the club room with Kaoruko, who was swollen with tears.
[cpg]

[OnName num="kimoto"]
She said, "Are you all right, that you are?　Princess, you were crying, that you were. ......
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko644"]
[OnName num="kaoruko"]
"......"
[cpg cn=true]

Kaoruko said nothing. I know they don't have that much faith in me, because I know it's disappearing.
[cpg]

[OnName num="shinjo"]
If you like, you can use a handkerchief or something?"
[cpg cn=true]

They don't even accept it. As it is, Kaoruko sat down in front of the game console and picked up the controller.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko645"]
[OnName num="kaoruko"]
She said in a dark tone, "...... Natsuki-kun, let's play together."
[cpg cn=true]

She says so in a dark tone, and I follow suit.
[cpg]

The three of them were looking at me with trepidation, but they didn't seem to take it too seriously, only to be horrified.
[cpg]

Because I was no longer the only woman for them. It's natural for this to happen.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_03_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

Later, we walk out of the university.
[cpg]

They are trying to follow me home. Of course, they are in a hurry and must be lonely.
[cpg]

[OnName num="natsuki"]
I told her, "......, you don't have to stick so closely to me, I'm not going anywhere."
[cpg cn=true]

Kaoruko doesn't answer anything. She continued to walk next to me with a blank or darker expression on her face.
[cpg]

I didn't have any words to say to her, so I just kept silent and went on my way home.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se020"]
;//【ＳＥ】『電車に揺られる』

[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]

While we were on the train, we were seated next to each other. Although she was clinging to me like she was trying to show me something, her expression was dark.
[cpg]

In fact, she looked as if she was about to start crying.
[cpg]

I couldn't help but pat Kaoruko on the head.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

And in the end, Kaoruko followed me to my room.
[cpg]

[FG f="CHA01_p1_03_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko646"]
[OnName num="kaoruko"]
......
[cpg cn=true]

I didn't have anything special to offer her. I tried to cook dinner for the two of us, and she helped me without saying a word.
[cpg]

I thought, "......" she does a good job of cooking and so on in spite of her silence.
[cpg]

It was starting to look like an appeal for depression in her own way.
[cpg]

But that doesn't mean I can overlook it. If she's depressed, I should comfort her.
[cpg]

Like she said before, she could really kill herself.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_03_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[OnName num="natsuki"]
"Itadakimasu"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko647"]
[OnName num="kaoruko"]
"......Itadakimasu"
[cpg cn=true]

I made dinner with what I had. Vegetable stir-fry and miso soup. The poor dinner went on in silence.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Days pass.
[cpg]

As the usual lectures went by as usual, Yui and her friends started coming to the circle more frequently.
[cpg]

Kaoruko's place was about to be taken away.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

[OnName num="natsuki"]
"......Yui-san and the others came today too, didn't they?"
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko652"]
[OnName num="kaoruko"]
Yes. ......
[cpg cn=true]

A weak reply. He looked exhausted and despairing.
[cpg]

But I also had a feeling that it would not end as it did.
[cpg]

I had a premonition that it would explode somewhere, that it would never end like this.
[cpg]

[OnName num="natsuki"]
Is she coming to my house again today?　Kaoruko.
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko653"]
[OnName num="kaoruko"]
Yes. ......
[cpg cn=true]

It really seems like a person has changed. The most important thing to remember is that you can't just take a look at your own personal personal information.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

;//移植のためシーンをカットしています
;//移植のためシーンをカットしています

;//ＢＫ

I listened to her as sincerely as possible.
[cpg]

It may sound rude to say it like this, but I comforted her as much as I could.
[cpg]

When we talked for a long time, she would sometimes laugh at me.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

The next morning, Kaoruko was in a rather good mood.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kaoruko692"]
[OnName num="kaoruko"]
Good morning. I took the liberty of using the food in the fridge, but ...... breakfast is ready.
[cpg cn=true]

[OnName num="natsuki"]
Oh, thank you ......."
[cpg cn=true]

I'm not sure what to expect, but I'm sure I'm going to have a great time.
[cpg]

I'm not sure how happy I'd be if I could have a normal relationship with her. ......
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（朝）******************************************************

We came all the way to the university, teasing each other with our arms. Rather, Kaoruko was one-sidedly sticky with me.
[cpg]

For the time being, I was feeling that it was not too much to ask for, and I was wishing that such peace would last.
[cpg]

However, reality is not so sweet. It's not that it's not sweet, it's just that it doesn't go by so peacefully.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（朝）******************************************************

The same lecture as Kaoruko. I didn't notice it before, but Yui was there too.
[cpg]

She is sitting a little far away from me and waves to me. Kaoruko didn't answer and I couldn't respond.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kaoruko693"]
[OnName num="kaoruko"]
She said, "...... You wouldn't flirt with a girl like that, would you?　Natsuki-kun.
[cpg cn=true]

[OnName num="natsuki"]
"Uh-huh."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
Kaoruko looked scared, as if she didn't like that I stuttered a bit in my reply.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


During the lecture, the content of the lecture did not enter my mind much.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko694"]
[OnName num="kaoruko"]
I wish I hadn't been there in the first place, ...... when I, and I alone, was the princess."
[cpg cn=true]

I'm not sure what to do about it, but I'm not sure what to do about it.
[cpg]

For example, she's even talking about how she's going to take care of it.
[cpg]

I was not sure whether to stop her or not, but I let it go.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『大学教室』（朝）******************************************************

Then, at the end of the lecture, Yui approached me.
[cpg]

;//♪二人
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/5" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="4/5" time=800]
[OnName num="gal_A"]
She said, "Hi, Yossu. Is that Natsuki?　You're looking a bit pale today, aren't you?
[cpg cn=true]

[OnName num="natsuki"]
Ho, leave me alone."
[cpg cn=true]

Sparks flew between Kaoruko and him.
[cpg]

[FACE method="shake_1" pos="4/5"]
[OnName num="gal_A"]
Don't be shy, she's pretty good looking to be honest.
[cpg cn=true]

[OnName num="natsuki"]
"You're hot ......?　I'm ......?"
[cpg cn=true]

The girl who has not had much contact with him said that to him, and his face turned red.
[cpg]

And Kaoruko saw it. She looked like a demon.
[cpg]

[FACE method="bow_3" pos="2/5"]
[VOICE f="Kaoruko695"]
[OnName num="kaoruko"]
Yes, he's my boyfriend. It's only natural that he's cool."
[cpg cn=true]

[FACE method="shake_2" pos="4/5"]
[OnName num="gal_A"]
She said, "Don't you have any better clothes or something?　I'll pick something out with you next time.
[cpg cn=true]


[FADEOUTBGM]

Yui took my hand.
[cpg]

I felt the tension in the air explode.
[cpg]


[FACE method="shock_3" pos="2/5"]
[VOICE f="Kaoruko696"]
[OnName num="kaoruko"]
Stop it!
[cpg cn=true]

The few remaining students were all looking at me in surprise.
[cpg]

[FACE method="shake_3" pos="2/5"]
[VOICE f="Kaoruko697"]
[OnName num="kaoruko"]
Don't touch me with your dirty hands, you're my Natsuki-kun!　My, my ......!"
[cpg cn=true]

Yui's hand was unclasped by Yui, and then Kaoruko grabbed my hand this time and took me out of the classroom as it was.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（朝）******************************************************

Kaoruko tells me what's on her mind as she takes me out to the hallway.
[cpg]

[FACE method="shock_3" pos="2/3"]
[VOICE f="Kaoruko698"]
[OnName num="kaoruko"]
Please, don't ever become anyone else's, stay with me and only me, Natsuki-kun.
[cpg cn=true]

[OnName num="natsuki"]
"U-uh, I know, it's obvious. ......
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko699"]
[OnName num="kaoruko"]
Is it really so?　I'm not sure I'm going to be able to do that.　Then why are you blushing?
[cpg cn=true]

[OnName num="natsuki"]
Well, when a girl you don't know that well gets that close to you, it's natural for you to blush. ......
[cpg cn=true]

Kaoruko's eyes are not normal. Something about the way she looks at me like she's going to take me and eat me.
[cpg]

And since they are arguing in the hallway like this, they are quite conspicuous to the other students.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko700"]
[OnName num="kaoruko"]
It's not natural, that's Natsuki-kun's own theory, isn't it?
[cpg cn=true]

That's the line I want to say, but I don't say it.
[cpg]

And then Kaoruko comes even closer to me as we face each other.
[cpg]


[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko701"]
[OnName num="kaoruko"]
She says, "...... kiss me."
[cpg cn=true]

[OnName num="natsuki"]
"Here?　You'll be seen."
[cpg cn=true]

[free time=300]
[FG f="CHA01_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
While I was puzzled, Kaoruko grew taller and brought her lips to mine.
[cpg]


[FACE method="bow_6" pos="2/3"]
[VOICE f="sKaoruko018"]
[OnName num="kaoruko"]
I'm going to be able to get a good look at you.
[cpg cn=true]

She was watching me with all her might. I could neither refuse nor shun her.
[cpg]

After a few dozen seconds had passed, I was left to my own devices. ......
[cpg]

[free time=300]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="sKaoruko019"]
[OnName num="kaoruko"]
......I forgive you for this.
[cpg cn=true]

[OnName num="natsuki"]
I say, "Well, yes, if you forgive me, thank you ......."
[cpg cn=true]

How else can I say it? I can't keep up with this crazy girlfriend.
[cpg]

I understand that she is desperate in her own way, but it's too much.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko704"]
[OnName num="kaoruko"]
But that girl ...... Yui, I won't forgive her.
[cpg cn=true]

[OnName num="natsuki"]
Eh?"
[cpg cn=true]

[free time=1000]

With that, Kaoruko left the place.
[cpg]

I have a bad feeling about this, so I followed her a little bit behind.
[cpg]


;//薫子に視点切り替わり

;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_01.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=3000]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]
[WAIT time=100]


I can't forgive her. I can't forgive them for taking everything from me.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_06_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（朝）******************************************************


They always do. The people who have something I don't have, they take it all away.
[cpg]

I just did the best I could, but they took everything away from me.
[cpg]

It always happens. And for this one time, I couldn't just stand by and watch it happen.
[cpg]

Yui. The natural enemy of us nerds, the so-called "gals.
[cpg]

I know the lectures they attend together. There is a lecture where all the dropout students gather.
[cpg]

I was heading there as fast as I could.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（朝）******************************************************


Before the lecture started. They were hanging out. I went to them with all my might.
[cpg]

;//♪三人

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko705"]
[OnName num="kaoruko"]
"...... Yui, san?"
[cpg cn=true]

[free time=300]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_7"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_7"  pos="3/3" time=800]
[OnName num="gal_A"]
Oh?　What?　Uh, who are you?
[cpg cn=true]


[FACE method="shake_3" pos="3/3"]
[OnName num="gal_B"]
"Uh, that's him. The Princess of Otasa.
[cpg cn=true]

[OnName num="gal_C"]
Oh, yeah. What's a princess doing here?
[cpg cn=true]

She says all kinds of annoying things. But I don't get turned around.
[cpg]

[FACE method="bow_2" pos="1/3"]
[VOICE f="Kaoruko706"]
[OnName num="kaoruko"]
Yes, that's right ......, I'm everyone's princess. You don't have a chance."
[cpg cn=true]

[OnName num="gal_D"]
What?　Chance?　What are you talking about?
[cpg cn=true]

[FACE method="shock_3" pos="1/3"]
[VOICE f="Kaoruko707"]
[OnName num="kaoruko"]
Don't play dumb with me!　You're the ones who screwed up our circle!
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[OnName num="gal_A"]
I didn't make a mess. You know, circles usually don't accept anyone who comes to the circle.
[cpg cn=true]

Oh, it pisses me off to no end. I'm not sure I want to talk to people like you who smell of make-up.
[cpg]

[FACE method="shake_3" pos="1/3"]
[VOICE f="Kaoruko708"]
[OnName num="kaoruko"]
I don't even want to be talking to people who smell of make-up like you .......
[cpg cn=true]

[FACE method="bow_3" pos="3/3"]
[OnName num="gal_B"]
If you don't want to, why don't you just stop?
[cpg cn=true]

[OnName num="gal_C"]
Why are you in such a hurry?　We haven't done anything, have we?
[cpg cn=true]

I hope you're not going to play dumb with me. If I hadn't done anything, I wouldn't be here either.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko709"]
[OnName num="kaoruko"]
Natsuki-kun likes ...... me. So you guys don't stand a chance."
[cpg cn=true]



;//ＢＫ
;//夏樹に視点切り替わり
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="ui_00.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=3000]


[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『大学教室』（朝）******************************************************



I followed Kaoruko stealthily to a place where I found myself in quite a shuraba, or rather, a scene that was not as good as I had imagined it would be.
[cpg]
;//重複ボイス

[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_3"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_3"  pos="3/3" time=800]

;//【繰り返し使用収録不要ボイス】

[VOICE f="Kaoruko708"]
[OnName num="kaoruko"]
I don't want to be talking to people who smell of make-up like you ...... either.
[cpg cn=true]

Kaoruko threw terrible words at Yui and the others, who were not bad people in any sense of the word.
[cpg]

I didn't really want to see this. But I couldn't intervene, so I secretly watched from the shadows.
[cpg]
;//重複ボイス

;//【繰り返し使用収録不要ボイス】
[FACE method="bow_3" pos="1/3"]
[VOICE f="Kaoruko709"]
[OnName num="kaoruko"]
Natsuki-kun likes ...... me. That's why you guys don't have a chance.
[cpg cn=true]

[FACE method="bow_2" pos="1/3"]
[VOICE f="sKaoruko020"]
[OnName num="kaoruko"]
Besides, Natsuki-kun doesn't like girls like you.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[OnName num="gal_A"]
"Ha-ha-ha!　You're not saying much, are you?"
[cpg cn=true]

Yui stood up. Then, she packed up Kaoruko.
[cpg]

I thought, "This is not a good idea. Thinking so, I stopped her.
[cpg]

[OnName num="natsuki"]
"No, don't do that. Kaoruko, you're disgusting.
[cpg cn=true]

[FACE method="shock_5" pos="1/3"]
[VOICE f="Kaoruko711"]
[OnName num="kaoruko"]
What ......?　Natsuki-kun, ......
[cpg cn=true]

[OnName num="natsuki"]
Yui-san, I'm sorry too. My girlfriend did a terrible thing ......."
[cpg cn=true]

[FACE method="shake_3" pos="2/3"]
[OnName num="gal_A"]
I don't mind. It's just that I get mad when people make fun of my companion.
[cpg cn=true]

[OnName num="natsuki"]
I'm sorry .......
[cpg cn=true]

I apologized again. Then I turned to Kaoruko.
[cpg]

[free time=300]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko712"]
[OnName num="kaoruko"]
Natsuki-kun, how long have you been listening to this?
[cpg cn=true]

[OnName num="natsuki"]
I was in the middle of it,......, but you shouldn't say anything too terrible. Kaoruko.
[cpg cn=true]

The hand that held it is shaking, and it's holding the anger that has no place to go.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko713"]
[OnName num="kaoruko"]
I'm not terrible, Natsuki-kun, you belong to me!
[cpg cn=true]

[free time=300]
[FG f="CHA01_p5_01_a.ui" method="change_3"  pos="2/3" time=800]
Saying that, she crowded me and forced me to kiss her.
[cpg]

Yui and the others are looking at me. It's obvious, but they seem to be quite irritated.
[cpg]

I thought, "I can't do anything about it," but I couldn't do anything.
[cpg]


[FACE method="change_6" pos="2/3"]

I just accepted the kiss as it was.
[cpg]

It's not that it's bothersome, or that they don't understand the situation.
[cpg]

Do you want to go that far and show Yui and the others that you own them? ......
[cpg]


;//ＢＫ
[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="1/3" time=800]
[FG f="CHA02_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_4"  pos="3/3" time=800]
[VOICE f="Kaoruko715"]
[OnName num="kaoruko"]
I'll leave you to it. I will never give Natsuki-kun to you.
[cpg cn=true]

After that, Kaoruko pulled me by the arm and walked out of the classroom, leaving me with such a discarded line.
[cpg]

Although it didn't turn into a big fight right then and there, I think Yui and her friends are very antagonistic toward me.
[cpg]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[OnName num="natsuki"]
'...... what should I do?'
[cpg cn=true]

After I finished all my lectures and showed up at the club room, I went home alone.
[cpg]


[SE f="se029"]
;//【ＳＥ】『ベッドきしむ』
[WAIT time=1000]

I sat on my bed and thought. I wondered what would happen to me from now on. ......
[cpg]

I don't feel like I can keep going out with Kaoruko.
[cpg]

But if I say I'm breaking up with her now, she might kill herself. ......
[cpg]

And what will happen now is not just about me and Kaoruko. What will happen to the circle itself?
[cpg]

I wonder if Yui and the others will do anything about it. I can't help thinking about that.
[cpg]

......Well, there will be some kind of progress, I'm sure.
[cpg]

I'm sure there will be some progress. I don't know if it will be good for Kaoruko or not.
[cpg]

It's no use thinking about it too much. Thinking so, I decided to go to sleep.
[cpg]



;//ＢＫ


;//♪分岐場所

;//////////////////Block///////////////////
;//ルート分岐場所

[if exp={getFlagValue("boolean1") == 1 }]
[jump target=*bunki10]
[endif]
[jump target=*bunki11]
;//////////////////////////////////////////
*bunki10|The Fluctuation of the Princess

[if exp={getFlagValue("boolean2") == 1 }]
[jump target=*bunki20]
[endif]
[jump target=*bunki21]
;///////////////////////////////////////////
*bunki11|The Fluctuation of the Princess
[if exp={getFlagValue("boolean2") == 1 }]
[jump target=*bunki30]
[endif]
[jump target=*bunki31]

;///////////////////////////////////////////
*bunki20|The Fluctuation of the Princess
[if exp={getFlagValue("boolean3") == 1 }]
[jump target=*route2]
[endif]
[jump target=*route2]

;///////////////////////////////////////////
*bunki21|The Fluctuation of the Princess
[if exp={getFlagValue("boolean3") == 1 }]
[jump target=*route5]
[endif]
[jump target=*route1]

;///////////////////////////////////////////
*bunki30|The Fluctuation of the Princess
[if exp={getFlagValue("boolean3") == 1 }]
[jump target=*route3]
[endif]
[jump target=*route4]

;///////////////////////////////////////////
*bunki31|The Fluctuation of the Princess
[if exp={getFlagValue("boolean3") == 1 }]
[jump target=*route6]
[endif]
[jump target=*route6]

;///////////////////////////////////////////


*route1|The Fluctuation of the Princess
[jump storage="ep007.ks" target="*route1"]

*route2|The Fluctuation of the Princess
[jump storage="ep008.ks" target="*route2"]

*route3|The Fluctuation of the Princess
[jump storage="ep009.ks" target="*route3"]

*route4|The Fluctuation of the Princess
[jump storage="ep010.ks" target="*route4"]

*route5|The Fluctuation of the Princess
[jump storage="ep011.ks" target="*route5"]

*route6|The Fluctuation of the Princess
[jump storage="ep012.ks" target="*route6"]




;//分岐につきまして、ルートは６つあります
;//二択の選択肢が三つあり、合計八つに分岐していますがうち二つは同じエンディングです
;//以下、選択した順に列挙しています
;//１、その通りだと思う　→１、ヒロインが望むなら別にいい→１、そうかもしれない→『ルート２』へ
;//１、その通りだと思う　→１、ヒロインが望むなら別にいい→２、勿論だ　　　　　→『ルート２』へ
;//１、その通りだと思う　→２、やっぱり嫌だ　　　　　　　→１、そうかもしれない→『ルート５』へ
;//１、その通りだと思う　→２、やっぱり嫌だ　　　　　　　→２、勿論だ　　　　　→『ルート１』へ
;//２、そうでもないと思う→１、ヒロインが望むなら別にいい→１、そうかもしれない→『ルート３』へ
;//２、そうでもないと思う→１、ヒロインが望むなら別にいい→２、勿論だ　　　　　→『ルート４』へ
;//２、そうでもないと思う→２、やっぱり嫌だ　　　　　　　→１、そうかもしれない→『ルート６』へ
;//２、そうでもないと思う→２、やっぱり嫌だ　　　　　　　→２、勿論だ　　　　　→『ルート６』へ

