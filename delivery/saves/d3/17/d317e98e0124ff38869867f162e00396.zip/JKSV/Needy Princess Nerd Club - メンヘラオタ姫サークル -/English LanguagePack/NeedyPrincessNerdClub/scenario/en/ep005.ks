
*start|Cosplay Photo Sessions

;#################################################
*Ep005|Cosplay photo session
;#################################################

[SCENE id=5]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se014"]
;//【ＳＥ】『目覚ましのベル』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


The next day, Kaoruko and I usually woke up at the same time. I don't know which one of us woke her up, I think it was the alarm.
[cpg]

[FG f="CHA01_p5_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kaoruko515"]
[OnName num="kaoruko"]
"Nnnn...... is it morning already?"
[cpg cn=true]

[OnName num="natsuki"]
Yes, it is. I have to go to a lecture at the university.
[cpg cn=true]

I force Kaoruko to wake up, who tries to go back to sleep, saying, "Just a little more, just five more minutes.
[cpg]

[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

When she was grumpy and bloated, I lightly made her a fried egg and ......
[cpg]

She was in kind of a good mood, so I left the house, feeling glad.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

Kaoruko stopped by my house for a while to get her stuff and stuff.
[cpg]

But I decided to go straight to the university and attend a lecture.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（朝）******************************************************

[OnName num="kimoto"]
"Oh, Sugiura-dono. You look a little down today, don't you?
[cpg cn=true]

[OnName num="natsuki"]
"Do I look like that, ......?"
[cpg cn=true]

[OnName num="kimoto"]
"It's always the same, that it is, that you may have that kind of face to begin with, that you do.
[cpg cn=true]

[OnName num="natsuki"]
It's terrible,......."
[cpg cn=true]

On the way to the classroom, I met Kimoto. The topic of conversation was, of course, geeky.
[cpg]

[OnName num="natsuki"]
"Did you hear about that?　The voice actor on "STAPLA" is ......."
[cpg cn=true]

[OnName num="kimoto"]
"I did hear that, that I did!　He's getting married, isn't he?
[cpg cn=true]

From the way they say "marriage," it sounds like they are celebrating. I'm glad.
[cpg]

[OnName num="natsuki"]
Yes, yes. From an otaku's point of view, voice actor marriages are complicated.
[cpg cn=true]

[OnName num="kimoto"]
I don't see anything complicated about it. We can only congratulate them, that we can.
[cpg cn=true]

Kimoto is a nice guy. Such a nice person is captivated by Kaoruko. ......
[cpg]

I'm starting to feel sorry for him. Even though it's not my fault.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



And then I finished the lecture pretty early, and Kimoto and I had some time to kill.
[cpg]

We agreed to drop by the clubroom, and when we let our feet take us there,......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_02_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（昼）******************************************************

[OnName num="shinjo"]
Hey, you two, you're up early today. You're early today."
[cpg cn=true]

Shinjo was there. Tokusawa-senpai wasn't there, but he was alone at the game console.
[cpg]

[OnName num="kimoto"]
The other day, he was playing a video game by himself.
[cpg cn=true]

[OnName num="shinjo"]
I was talking to Tokuzawa the other day.
[cpg cn=true]

Shopping? I'm sure Kaoruko will probably be included in the trip. ......
[cpg]

[OnName num="kimoto"]
"Of course, I would love to go, that I would.
[cpg cn=true]

[OnName num="shinjo"]
I see. When shall we go then?　I'd like to go as soon as it's convenient for me. ......
[cpg cn=true]

I checked each person's availability in the group chat, and it seemed that everyone was free today.
[cpg]

I checked the availability of each person in the group chat and found that everyone seemed to be free today.
[cpg]

[OnName num="shinjo"]
All right, then, let's get going.
[cpg cn=true]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="kimoto"]
"Princess, are you interested in cosplay, that you are?"
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko516"]
[OnName num="kaoruko"]
"Cosplay?　I'm interested, but I have money. ......
[cpg cn=true]

[OnName num="tokuzawa"]
"Oh, we'll pay for it. If it's the princess's cosplay, I want to see it no matter how much it costs.
[cpg cn=true]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kaoruko517"]
[OnName num="kaoruko"]
"Oh, really? ......?"
[cpg cn=true]

[OnName num="shinjo"]
Yes, we'll split it with the guys.
[cpg cn=true]

The five of us were talking about it on the road. The men's group, could it be that I'm in it too ......?
[cpg]

[OnName num="tokuzawa"]
"Sugiura, you'll pay for it too, right?"
[cpg cn=true]

[OnName num="natsuki"]
Oh, yes. ......
[cpg cn=true]

I knew they were including me. Well, it can't be helped.
[cpg]

But more than that, the fact that Kaoruko was going to cosplay was a bit of a bad idea in itself.
[cpg]

Because after that, wouldn't it be a photo session or something, ...... in the circle?
[cpg]

I wonder if Kaoruko would be able to keep her cool.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オタクショップ』（昼）******************************************************

[OnName num="kimoto"]
"How about this, that it is?"
[cpg cn=true]

[OnName num="shinjo"]
"Yes, good!　Okay, Kimoto, that's great!
[cpg cn=true]

Entering the store, we found ourselves in the cosplay corner.
[cpg]

The two recommended a rather racy Chinese outfit.
[cpg]

[OnName num="natsuki"]
"......, no, it's too revealing, isn't it?"
[cpg cn=true]

[OnName num="tokuzawa"]
No, I wouldn't call it too revealing.
[cpg cn=true]

Two people recommended, which turned into three people recommended. If it comes down to a majority vote, you can't win.
[cpg]

And the important thing was Kaoruko,
[cpg]

[OnName num="natsuki"]
"What are you going to do ......?　If you don't like it, you have to refuse it properly.
[cpg cn=true]

;//[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FACE method="change_2" pos="2/3"]
[VOICE f="Kaoruko518"]
[OnName num="kaoruko"]
"No, I'm fine. I'm fine with this level of exposure.
[cpg cn=true]

I mean, there is a way to expose yourself. ......
[cpg]

[OnName num="tokuzawa"]
"Okay, it's decided!　Then we'll have a photo session.
[cpg cn=true]

And then we'll have a photo session, right? I guess that's right. ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="kimoto"]
I'm looking forward to it. The princess in her Chinese dress. ......
[cpg cn=true]

[OnName num="shinjo"]
By the way, that outfit...is it from some anime?
[cpg cn=true]

[OnName num="tokuzawa"]
No, I don't know. ......
[cpg cn=true]

Apparently, everyone chose the outfit based on how revealing it is, rather than on the anime they were drawn to.
[cpg]

[OnName num="natsuki"]
I know what it is. It's an anime with a sexy feel to it. ......
[cpg cn=true]

[OnName num="tokuzawa"]
Sugiura was very enthusiastic. I mean, you know the most about it.
[cpg cn=true]

Oh no. I guess I shouldn't have told him even if I knew. I wasn't really interested in it.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

We went back to the university and changed our clothes.
[cpg]

The four of us lined up in front of the clubroom and stood guard. By "watch," I mean that each of us was watching the other.
[cpg]

No one peeked at us while we were changing.
[cpg]

[OnName num="kimoto"]
I'm looking forward to ...... seeing the princess in such a revealing outfit.
[cpg cn=true]

[OnName num="shinjo"]
I'm more excited than excited.
[cpg cn=true]

[OnName num="tokuzawa"]
I'm not looking forward to it, I'm excited about it. The camera will capture her on film. ......
[cpg cn=true]

Everyone was filled with anticipation.
[cpg]

I would have felt the same way if I were in the same position, but because of my position as a boyfriend, I was worried about the opposite.
[cpg]



[SE f="se003"]
;//【ＳＥ】『ノック』

[WAIT time=1000]


[VOICE f="Kaoruko519"]
[OnName num="kaoruko"]
Sorry to keep you waiting, you may come in.
[cpg cn=true]

Kaoruko came near the door and tapped on it. Taking this as a cue, the four of us entered the clubroom stealthily.
[cpg]

;//●ＣＧエロ（ヒロイン・際どいコスプレ。写真のフラッシュを受けるたびに感じたようになる：サークル部室）ev_20

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_20_0 ***********************
[CG id=9 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]



[VOICE f="Kaoruko520"]
[OnName num="kaoruko"]
I was a little too much like a maniac.
[cpg cn=true]

The four of us, including me, salivated. The actual dress was not that bad.
[cpg]

It was so tight that I wondered how they had it in the store. I mean, is Kaoruko wearing underwear?
[cpg]

[OnName num="natsuki"]
"Kaoruko, that's your underwear ......."
[cpg cn=true]


[VOICE f="Kaoruko521"]
[OnName num="kaoruko"]
"Oh, um, ......, it was completely visible when I was wearing underwear. It was unnatural, so I took it off."
[cpg cn=true]

What is unnatural about it? Even if you could see it completely, you should do it.
[cpg]

I don't know what Kaoruko's values are. But everyone was looking at Kaoruko with bloodshot eyes.
[cpg]

[OnName num="kimoto"]
"Ugh, beautiful ...... is this the angel that descended to the earth, that it is?
[cpg cn=true]

[OnName num="tokuzawa"]
Such a metaphor is cheesy. This is a goddess,.......
[cpg cn=true]

;**【ＣＧ】 ev_20_a ***********************
[CG id=9 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Kaoruko522"]
[OnName num="kaoruko"]
Is it?　Am I that pretty?
[cpg cn=true]

[OnName num="shinjo"]
I am, of course. You are so pretty, you are a goddess!
[cpg cn=true]

Everyone praised her in their own words. I was feeling very uneasy.
[cpg]

This is not a normal circle activity. No matter how much she is a princess of Otasaer, it's too much. ......
[cpg]

While I was thinking this, Kimoto took out her phone.
[cpg]

[OnName num="natsuki"]
Wait a minute!　Kimoto, what are you going to do?
[cpg cn=true]

[OnName num="kimoto"]
What do you mean, a photo session ......?　What are you going to do if you don't take a picture of him, that you don't want me to take a picture of him?
[cpg cn=true]


[VOICE f="Kaoruko523"]
[OnName num="kaoruko"]
"Hehehe, am I so beautiful that I want to leave it in a photograph, ......?
[cpg cn=true]

[OnName num="kimoto"]
"That's a foolish question, that I could die right now, that I could.
[cpg cn=true]

The same exchange was repeated. Kaoruko asks if she is pretty or beautiful, and the boys answer her.
[cpg]


;//移植のためシーンをカットしています


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


After that, the four of us went out into the hallway to change into our normal clothes.
[cpg]

Then, after a while, ......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_02_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（昼）******************************************************


[VOICE f="Kaoruko533"]
[OnName num="kaoruko"]
I was so sorry. I'm sorry I showed you my dirty side.
[cpg cn=true]

[OnName num="tokuzawa"]
I'm sorry, I'm sorry. It's a blessing, a blessing.
[cpg cn=true]

[OnName num="kimoto"]
"Yes, that's right. The princess has no reason to apologize, that she does.
[cpg cn=true]

[OnName num="natsuki"]
"......"
[cpg cn=true]

Me and Kaoruko look at each other. Kaoruko looked like she was trying to see my mood.
[cpg]

I'm not angry with you. I thought so, but I couldn't convey that with just a glance.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko534"]
[OnName num="kaoruko"]
"I'm going to stop having photo sessions like today. ......
[cpg cn=true]

[OnName num="shinjo"]
What do you mean?　Let's do it again. I'll buy you clothes this time, too.
[cpg cn=true]

[OnName num="tokuzawa"]
That's right, we don't think we're slutty.
[cpg cn=true]

Kaoruko glanced at me.
[cpg]

[OnName num="natsuki"]
I think it's okay if something like this happens.
[cpg cn=true]

I replied properly to Kaoruko who was glancing at me.
[cpg]

[FACE method="bow_6" pos="2/3"]

;//ちゃんと返事をしてみると、ほっと安心したような表情になった。
Then she looked relieved and relieved.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]


After that, we played games and had an anime viewing party or something.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

It was already late in the evening. It was now well into the evening, and I asked Kaoruko if it was time for us to go home.
[cpg]

[OnName num="natsuki"]
"Shall we go home soon, Kaoruko?
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko535"]
[OnName num="kaoruko"]
Oh, yes. Yes, I guess so.
[cpg cn=true]

[OnName num="kimoto"]
Are we going home now, that we are, ......?
[cpg cn=true]

[OnName num="shinjo"]
"Buuhuh, I'll miss you. ......
[cpg cn=true]

[OnName num="natsuki"]
Then, would you senpai like to go home with us?
[cpg cn=true]

[OnName num="tokuzawa"]
"Yes. If only you are willing, we'll go with you.
[cpg cn=true]

I was a little happy to hear him say, "If only you were good enough.
[cpg]

I thought, "Quicksilver, you treat me, your boyfriend, differently.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア開ける』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


Kaoruko and I left the club room a little early and it was just the two of us.
[cpg]

It happened while my senpai and Kimoto were packing up their belongings.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko536"]
[OnName num="kaoruko"]
I knew I shouldn't have been a slutty girl. Sorry, I'm sorry."
[cpg cn=true]

[OnName num="natsuki"]
"...... is fine. I didn't stop you. I didn't stop them either.
[cpg cn=true]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

After that, we all walked to the station. Even though the trains we take are different, the nearest station is the same.
[cpg]

During that time, Kaoruko asked me this further.
[cpg]

In a whisper that Kimoto and her senpai could not hear ......
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="sKaoruko016"]
[OnName num="kaoruko"]
'What if, what if. You wouldn't like it if I was with someone else or something, would you ......?"
[cpg cn=true]


[switch]
[case "If Kaoruko wants to, it doesn't matter."]
	[swap]
	[jump target="*select02_1"]
[case "I still don't want to."]
	[swap]
	[jump target="*select02_2"]
[endswitch]
;//■選択肢
;//
;//１、薫子が望むなら別にいい
;//２、やっぱり嫌だ
;//
;//==============================
;//１、薫子が望むなら別にいい
*select02_1|Cosplay photo session

[stflag boolean2 = 1]


[OnName num="natsuki"]
...... If Kaoruko wants, it's fine with me."
[cpg cn=true]

Kaoruko looked amused. I wonder if she didn't expect this answer.
[cpg]


[FACE method="shock_5" pos="2/3"]
[VOICE f="Kaoruko538"]
[OnName num="kaoruko"]
'Oh, really?　I wonder if men are like that.
[cpg cn=true]

[OnName num="natsuki"]
I wonder. Maybe I'm an anomaly.
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
The reason for my reply was simply that I had no desire to monopolize Kaoruko, ......
[cpg]

I didn't have any particular reason beyond that, but I wonder if Kaoruko noticed.
[cpg]

[OnName num="kimoto"]
'What are you two talking about, that you are?
[cpg cn=true]

[OnName num="natsuki"]
Nothing. It's nothing important.
[cpg cn=true]

[OnName num="kimoto"]
"......It's fine then, that it is, but ......
[cpg cn=true]

From Kimoto's point of view, it's a conversation between two lovers. And yet, it's also a conversation between the princess and another man.
[cpg]

It's hard to be at peace with it.
[cpg]

[OnName num="natsuki"]
I'm talking about ...... Kimoto having a chance, too. Simply put..."
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Kaoruko539"]
[OnName num="kaoruko"]
"Wait a minute!　Can I say it?
[cpg cn=true]

Suddenly, Kimoto is perplexed at being told such a thing.
[cpg]

[FACE method="change_4" pos="2/3"]

[OnName num="kimoto"]
What is it, that it is?　What do you mean, that it is?
[cpg cn=true]

[OnName num="natsuki"]
I guess so. It's nothing, Kimoto.
[cpg cn=true]

[jump target=*junction02]
;//==============================
;//２、やっぱり嫌だ
*select02_2|Cosplay photo session

[OnName num="natsuki"]
It's obvious, isn't it? I wonder if there is a man who would answer that it is nothing, when asked that question.
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kaoruko540"]
[OnName num="kaoruko"]
I'm sorry. I'm sorry I got carried away today. ......
[cpg cn=true]

When they apologize honestly, I can't get mad at them either.
[cpg]

[OnName num="natsuki"]
I told him, "I don't care what you did today. I don't care."
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kaoruko541"]
[OnName num="kaoruko"]
I'm really sorry ....... Thank you.
[cpg cn=true]

[OnName num="kimoto"]
What are you two talking about, that you are?
[cpg cn=true]

[OnName num="natsuki"]
"Nothing. It's not a big deal.
[cpg cn=true]

[OnName num="kimoto"]
"......It's okay then, that it is.
[cpg cn=true]

From Kimoto's point of view, it's a conversation between two lovers. And yet, it's also a conversation between the princess and another man.
[cpg]

The actuality of this is that it is not a very easy conversation to have.
[cpg]

[OnName num="natsuki"]
I'm sorry, but I can't give Kaoruko to Kimoto.
[cpg cn=true]

I muttered to myself. Kimoto probably didn't hear me.
[cpg]

[OnName num="kimoto"]
What did you say, that you can't give Kaoruko to Kimoto?　Did you say something, that you did?
[cpg cn=true]

[OnName num="natsuki"]
No, it's nothing. Nothing.
[cpg cn=true]


;//==============================
*junction02|Cosplay photo session


As we walk, the station is approaching.
[cpg]

[OnName num="shinjo"]
"Oh, we're already at the station. ......
[cpg cn=true]

[OnName num="tokuzawa"]
I'll see you tomorrow. You'll be able to see the princess again tomorrow.
[cpg cn=true]

[OnName num="kimoto"]
That's right. Then, let's all say goodbye here, shall we?
[cpg cn=true]

[OnName num="natsuki"]
"Yes. Yes, that's right.
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se020"]
;//【ＳＥ】『電車に揺られる』

[BG f="b_00_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]



Then we got on the train, and it took a few minutes to get on the train.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

On the way home. I was walking alone on the street, having parted from my senpai, Kimoto and Kaoruko.
[cpg]

Kaoruko didn't say anything about coming to my house or anything like that today.
[cpg]

Well, it would have been more difficult to say something that would lift up only me at that place.
[cpg]

Since I'm being pampered so much, I'd like to keep it that way.
[cpg]

It's a feeling I would never understand, even if I were in the opposite position.
[cpg]



[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ

As is my usual habit, I also stop by the supermarket.
[cpg]

Today, there were no good ones on special sale, and I felt a little disappointed.
[cpg]

But that's okay. What's important for me right now is not about saving money or anything like that, but how to get along with Kaoruko.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

Kaoruko. I think she's a cute girl. I can feel that she loves me seriously.
[cpg]

And I know that if I miss out on this, I may never have a girlfriend again.
[cpg]

It would be sad to say that that's why we're dating,......, but there was no small part of that.
[cpg]

It's not once or twice that I pull back because of her unusual behavior. It's not so much that I think about breaking up with her every time it happens. ......
[cpg]

It's something I've thought about many times. There is no way this situation is going to continue.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Then I went back to my room, cooked myself a meal, took a bath, and spent some time surfing the net or playing anime or video games as I saw fit.
[cpg]

There are parts of me that wonder if this is what I want to do with my life, but, well, I'm sure I'll probably just go on as an otaku and get a normal job.
[cpg]

But what about Kaoruko?　Is it rude to imagine that she would be able to get a job with that personality ......?
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Then, a few days passed.
[cpg]


[window target=false]
[BG f="b_00_1.ui" time=1000]
[WAIT time=2500]
[BG f="b_01_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

And then the morning came as usual, and I went about my daily routine as usual.
[cpg]

I ate breakfast, brushed my teeth, washed my face,...... and headed off to college without much proper grooming.
[cpg]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[SE f="se005"]
;//【ＳＥ】『携帯電話の震動音』

On the way to the university, my phone shook on the way.
[cpg]

When I checked it, I found that it was the group chat where we talked about going out for a drink.
[cpg]

The idea was proposed by Tokusawa-senpai, and three others agreed. I responded that I would go, too.
[cpg]

But still, another drinking party? I wonder how everyone has money. Well, I am one of them. ......
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


I took the train, got off at a station near the university, and walked around town again.
[cpg]


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

[OnName num="kimoto"]
I got off the train at the station near the university and walked around the city again. Good morning, that it is.
[cpg cn=true]

[OnName num="natsuki"]
Good morning, that it is. Kimoto.
[cpg cn=true]

[OnName num="kimoto"]
Sugiura-dono is coming to the drinking party, isn't he?　How do you all have so much money? ......
[cpg cn=true]

[OnName num="natsuki"]
"No, you're not the only one who has money."
[cpg cn=true]

Kimoto says what I just thought of.
[cpg]

[OnName num="kimoto"]
"More than that, about the princess, that it is. ......
[cpg cn=true]

[OnName num="natsuki"]
'...... yeah. What's wrong with Kaoruko?
[cpg cn=true]

[OnName num="kimoto"]
"As a boyfriend, that it is okay?　About what happened the other day, that it is.
[cpg cn=true]

[OnName num="natsuki"]
What you mean by "the other day," ...... Oh, you mean the cosplay thing?
[cpg cn=true]

I can't say it's good or bad.
[cpg]

It's what Kaoruko wants, so you could say it's inevitable.
[cpg]

[OnName num="natsuki"]
"It's okay, isn't it?　That's about right."
[cpg cn=true]

[OnName num="kimoto"]
"Oh no, like it's someone else's business ......."
[cpg cn=true]

Apparently, Kimoto is looking out for me.
[cpg]

[OnName num="kimoto"]
And as a boyfriend, that I am, but if I keep doing that, I'm going to ......
[cpg cn=true]

[OnName num="kimoto"]
"The very existence of the circle itself is in jeopardy, that I feel.
[cpg cn=true]

[OnName num="natsuki"]
"...... I think so. They might fight over it.
[cpg cn=true]

[OnName num="natsuki"]
But Kimoto can't stop Kaoruko's outburst either, right?
[cpg cn=true]

[OnName num="kimoto"]
"...... That's right, that it is. I am a man, that I am.
[cpg cn=true]

I can't stop her runaway, that I can't. It is not just that he is defeated by Kaoruko's enthusiasm, but that Kimoto cannot win over his own greed.
[cpg]

I think Kaoruko is well aware of that. She is dancing with him to the end of the line.
[cpg]


[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_06_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（朝）******************************************************

[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kaoruko542"]
[OnName num="kaoruko"]
Good morning, Natsuki-kun. Natsuki-kun.
[cpg cn=true]

[OnName num="natsuki"]
Oh, good morning. Kaoruko ......
[cpg cn=true]

Today's lecture is the same as Kaoruko's from the very beginning.
[cpg]

I enter the classroom, wary that they won't try anything.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（朝）******************************************************

The lecture was going on. Kaoruko did not do anything during the lecture.
[cpg]

I was so relieved that I asked Kaoruko about it.
[cpg]

[OnName num="natsuki"]
She was very quiet today.
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kaoruko543"]
[OnName num="kaoruko"]
I've made up my mind that I'm not going to be a slutty girl anymore.
[cpg cn=true]

I see. I wonder how long I can keep that resolution.
[cpg]



[jump storage="ep006.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

