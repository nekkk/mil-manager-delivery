;//==============================
;//ルート２
*route2|Pamper me.

*start|Pamper me.

;#################################################
*Ep008|Pamper me.
;#################################################

[SCENE id=8]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************

Next day. The morning arrives as usual, and we go about our usual routine.
[cpg]

I wonder what she's going to do about it. ...... Maybe it's not just the princess that's attractive to the circle boys anymore.
[cpg]

I think Kaoruko's presence is just about balanced by Yui and the others.
[cpg]

If so, it should be quite a pinch for Kaoruko. ...... I wonder what she plans to do.
[cpg]

If you can get them to only look at me here, that would be great, but I'm sure that won't happen. ......
[cpg]



[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（昼）******************************************************

Then, he would attend lectures at the university. As I attended the lectures, I sometimes saw Kaoruko in the same lecture.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Kaoruko809"]
[OnName num="kaoruko"]
Hey, Natsuki-kun.
[cpg cn=true]

[OnName num="natsuki"]
"...... what?"
[cpg cn=true]

Kaoruko is trying to ask me something with a rather serious expression on her face.
[cpg]

[FACE method="bow_3" pos="2/3"]
[VOICE f="Kaoruko810"]
[OnName num="kaoruko"]
Who do you think is more attractive, me or this girl Yui ......?"
[cpg cn=true]

That's direct. Your insecurity is directly expressed in your question.
[cpg]

[OnName num="natsuki"]
"Are you so worried? It's okay, don't flutter."
[cpg cn=true]

He looks at me with a scary face. I wonder if something was wrong with this reply.
[cpg]

[FACE method="shake_3" pos="2/3"]
[VOICE f="Kaoruko811"]
[OnName num="kaoruko"]
I'll answer you right. Who is prettier, me or you?"
[cpg cn=true]

[OnName num="natsuki"]
...... Kaoruko is prettier."
[cpg cn=true]

[FACE method="change_2" pos="2/3"]

I responded, but I don't think this is a confirmation.
[cpg]

Anyone would respond like this if she were to stuff me with such a scary face. I wonder if Kaoruko knows that.
[cpg]


[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（夕方）******************************************************

Then, the lecture is over. As usual, I let them go to the club room.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kaoruko812"]
[OnName num="kaoruko"]
"......Yes, I knew it. ......This is the only way."
[cpg cn=true]

Kaoruko is walking next to me, mumbling to herself as she turns her head down.
[cpg]

I originally thought Kaoruko was a bit sick, but this is completely out of the ordinary.
[cpg]

[OnName num="natsuki"]
"Kaoruko? What happened, what's the only thing?"
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko813"]
[OnName num="kaoruko"]
Natsuki-kun, don't worry about it. Don't worry about it, Natsuki-kun."
[cpg cn=true]

If you say I shouldn't care, I don't. But I think you should be aware that you look scary to others. ......
[cpg]

Kaoruko, too, is a nerd, I would think.
[cpg]

Somehow, when we are cornered, this is what happens to us nerds, or rather, our nekkid side comes out.
[cpg]

I might be like this if I were in the opposite situation. So I can't think of anything that would make me abandon them too much.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

[OnName num="kimoto"]
Oh, Princess. And Sugiura-dono."
[cpg cn=true]

[OnName num="shinjo"]
Buch. You look lovely today, Princess."
[cpg cn=true]

But they don't praise him. In other words, the degree of pampering is lower than before.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_3"  pos="2/3" time=800]
[VOICE f="Kaoruko814"]
[OnName num="kaoruko"]
Hey, Kimoto-kun. Besides, senpai ...... have a minute?"
[cpg cn=true]

[OnName num="tokuzawa"]
What's this? Is this serious?"
[cpg cn=true]

Kaoruko answers, "Yes. She says she's going to talk about something serious, so I brace myself for it.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko815"]
[OnName num="kaoruko"]
Who do you think is more attractive, me or these girls named Yui?"
[cpg cn=true]

[OnName num="shinjo"]
"...... eh."
[cpg cn=true]

Yes, it is. It's a serious story for sure. I've already heard this story once.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kaoruko816"]
[OnName num="kaoruko"]
Have you grown to hate me already?"
[cpg cn=true]

[OnName num="kimoto"]
No, no, that's not ...... true, that it isn't."
[cpg cn=true]

[OnName num="tokuzawa"]
Yes, Kaoruko-chan will always be our princess. Hey, everyone, ......"
[cpg cn=true]

The brusqueness of the replies is extremely poor. It's like they look at each other and there is no desperation in the men's faces.
[cpg]

I can tell Kaoruko is frustrated by this, even though she's standing next to me. She bites her lip and looks frustrated.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko817"]
[OnName num="kaoruko"]
I see. Well then, let's have another photo session next time."
[cpg cn=true]

[OnName num="kimoto"]
"...... photo session, that is?"
[cpg cn=true]

[OnName num="tokuzawa"]
But is that ...... again, in that outfit?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
Kaoruko nodded. Then she added this.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kaoruko818"]
[OnName num="kaoruko"]
This time, we may not be able to do more than just shoot. Let's get together for sure.
[cpg cn=true]

Oh. Well, I wonder if it will. I don't know.
[cpg]

She must have thought that if she didn't, the gals would take them away.
[cpg]

There is not much left for Kaoruko to do. The only thing she can do is to use her sex appeal and her body to hold him back.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko819"]
[OnName num="kaoruko"]
"Is it good? Natsuki -kun"
[cpg cn=true]

[OnName num="natsuki"]
Yeah, well. Why don't you do whatever you want with Kaoruko?"
[cpg cn=true]

And I didn't reject it either. I had no desire to monopolize Kaoruko.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ



That outfit in the example belongs to Kaoruko, so Kaoruko keeps it.
[cpg]

I mean, it's not in the club room. So I just said let's do it another day.
[cpg]

I am sure that, for her part, she would have exposed herself in an indecent manner to keep them in line right now.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_04_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『大学教室』（夕方）******************************************************

Then the day of the photo session. In the evening, I was wondering whether or not to go to the ...... club room after I finished my lecture.
[cpg]

Maybe Kimoto and the seniors will definitely be in the club room. There is no way they would not come when they were told that it might not be enough to shoot.
[cpg]

But my steps are heavy. I wonder what she's doing in that room right now that would make me ask another guy out.
[cpg]

Not that I don't want to see it, but I don't want to see it either.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア開く』

[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************


Eventually, I came to the club room to see how far they would eventually go.
[cpg]

[OnName num="natsuki"]
Excuse me. ......."
[cpg cn=true]

Somehow I imagined what was happening inside and I said excuse me.
[cpg]

And there was certainly more going on there than just a photo session.
[cpg]


;//●ＣＧエロ（ヒロイン・際どいコスプレ。自らオナニーしだして絶頂する：サークル部室）ev_33

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_33_0 ***********************
[CG id=12 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]


The costumes are much more outrageous than sometime ago.
[cpg]

They approach, they are in close proximity with their bloodshot eyes.
[cpg]

[VOICE f="sKaoruko022"]
[OnName num="kaoruko"]
Oh, Natsuki-kun,...... ehehe, that's a little embarrassing."
[cpg cn=true]


He doesn't care if I come over. He says he's embarrassed.
[cpg]

I ...... wonder what she wants to do.
[cpg]


;//移植のためシーンをカットしています

[VOICE f="sKaoruko023"]
[OnName num="kaoruko"]
Oh, yeah. The poses have been together for a long time, so ...... good, and ...... good."
[cpg cn=true]


;//●ＣＧ（ヒロイン・際どいコスプレ。主人公ではない男にバックで突かれる：サークル部室）ev_34

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_34_0 ***********************
[CG id=13 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]

[VOICE f="sKaoruko024"]
[OnName num="kaoruko"]
Can you take a prettier picture with this?"
[cpg cn=true]


When I saw her, I thought she would stop, but she became rather bold.
[cpg]

I don't doubt that mindset. I've been with Kaoruko for a long time.
[cpg]

But I felt like I couldn't watch.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

[OnName num="natsuki"]
"...... phew."
[cpg cn=true]

Go outside and close the door.
[cpg]

It's getting outrageous, isn't it? But it's Kaoruko's choice, so I guess it's all right.
[cpg]

I wasn't going to complain about everything anymore.
[cpg]

You can do whatever you want. I still like Kaoruko and think she's cute.
[cpg]

If that lovely Kaoruko chooses to be in this situation, I'm not complaining either.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se013"]
;//【ＳＥ】『携帯電話の着信音』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


Then, night after night. At the hour of truly midnight, I received a phone call from her.
[cpg]


[SE f="se034"]
;//【ＳＥ】『携帯電話のボタン』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[OnName num="natsuki"]
Yes, this is Natsuki, what's up with ......?"
[cpg cn=true]

I wondered if there was any way to say, "What's wrong with you?" after saying it myself.
[cpg]

You've been through a lot. I'm sure you have a lot to say to me.
[cpg]


[VOICE f="Kaoruko869"]
[OnName num="kaoruko"]
Um, that ...... today, sorry ......."
[cpg cn=true]

I still have those feelings of guilt. I thought it would be long gone by now.
[cpg]

[OnName num="natsuki"]
It's okay, you don't have to apologize. If Kaoruko is satisfied with that, I won't say anything either."
[cpg cn=true]


[VOICE f="Kaoruko870"]
[OnName num="kaoruko"]
I'm really sorry, I betrayed you, Natsuki-kun. ......
[cpg cn=true]

[OnName num="natsuki"]
'I don't think that. Don't worry about it, really."
[cpg cn=true]

[OnName num="natsuki"]
He said he was more than happy to have more options in his game. It's true.
[cpg cn=true]

That's really what I thought for a minute.
[cpg]

There are still inevitable limits to what can be done on a one-to-one basis.
[cpg]


[VOICE f="Kaoruko871"]
[OnName num="kaoruko"]
"... Really? Are you really angry?"
[cpg cn=true]

[OnName num="natsuki"]
I'm going to go to sleep then. Well then, I'm sleepy, good night ......"
[cpg cn=true]

And I hung up the phone on me.
[cpg]



[SE f="se035"]
;//【ＳＥ】『携帯電話の通話終了』
[free time=1000]
[WAIT time=1000]

Maybe this confirmation will continue throughout the night unless I hang up the phone.
[cpg]



[SE f="se013"]
;//【ＳＥ】『携帯電話の着信音』
[WAIT time=1000]

But then, sure enough, I got another call.
[cpg]



;//ＢＫ



It was a hassle, so instead of just taking it, I decided to leave it alone: ......
[cpg]


[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

And morning. Morning as usual.
[cpg]

As usual, I get on the train and head to the university as usual.
[cpg]

But there will no longer be the usual circles and that club room.
[cpg]

I think that even if we try to spend time as we did before, it will inevitably be jerky.
[cpg]

Everything is what Kaoruko has destroyed.
[cpg]

To begin with, when the girls joined the circle, it was starting to break down a bit, or perhaps there were some frayed edges.
[cpg]

That doesn't mean I think Kaoruko is wrong. Because it's something that the boys are happy with at this point.
[cpg]

And that includes me. It doesn't bother me that she's there.
[cpg]

Kaoruko is not a bad person. Just a little ...... or quite unusual.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（昼）******************************************************

I attend a lecture at the university. Kimoto, who was supposed to be next to me in this lecture, is not there.
[cpg]

Maybe they go to the club room.
[cpg]

I couldn't even follow it, because I had a lecture to give.
[cpg]

I don't mean to make fun of Kimoto for wanting to miss the lecture to be with Kaoruko. But I wasn't going to miss this lecture either.
[cpg]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（昼）******************************************************

Then, lunch break. I decided to try it out and take a peek in the club room.
[cpg]

Kaoruko is probably still flirting with boys. Since she wants to, that's fine.
[cpg]


;//移植のためシーンをカットしています

[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************

[SE f="se003"]
;//【ＳＥ】『ノック』

And as soon as I entered the club room ...... five people were in this room, there was someone knocking on the door.
[cpg]

[OnName num="gal_A"]
"Is it okay to enter?
[cpg cn=true]



[SE f="se019"]
;//【ＳＥ】『ドア開く』


[FG f="CHA02_p1_01_a.ui" method="change_2"  pos="2/5" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_2"  pos="4/5" time=800]

All eyes were on Yui and her cronies at the entrance.
[cpg]

Now Kaoruko was closing in on Shinjo-senpai. The gals saw the scene: ......
[cpg]

Except for Kaoruko, in short, the four men, including me, froze.
[cpg]

[FACE method="shock_5" pos="2/5"]
[FACE method="change_5" pos="4/5"]
[OnName num="gal_A"]
"What, what, what are you doing? What were you doing? I wasn't a boyfriend."
[cpg cn=true]

[free time=300]
[FG f="CHA02_p1_01_a.ui" method="change_5"  pos="1/3" time=800]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[FG f="CHA03_p1_01_a.ui" method="change_5"  pos="3/3" time=800]
[VOICE f="sKaoruko025"]
[OnName num="kaoruko"]
"...... heh, heh."
[cpg cn=true]

Kaoruko laughed triumphantly.
[cpg]

I wondered how they would respond, but I never imagined this turn of events.
[cpg]


[FACE method="shake_1" pos="2/3"]
[VOICE f="sKaoruko026"]
[OnName num="kaoruko"]
I'm not like you guys anymore because I belong to everyone ......."
[cpg cn=true]


[FACE method="shake_3" pos="3/3"]
[OnName num="gal_B"]
"Seriously ...? How light is this guy?"
[cpg cn=true]

Kaoruko seems to think she has won over the gals in this situation.
[cpg]

For what it's worth, I'm just getting the cold shoulder from the gals. ......
[cpg]


[OnName num="gal_C"]
Yui, it's not good. It's better not to get involved with these guys anymore."
[cpg cn=true]

[FACE method="bow_3" pos="1/3"]
[OnName num="gal_A"]
I don't want to see this. I don't even want to see this."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko890"]
[OnName num="kaoruko"]
"Hmmm...you are a sore loser, aren't you? Are you really that disappointed that you lost everyone?
[cpg cn=true]

[FACE method="shock_4" pos="1/3"]
[OnName num="gal_A"]
Really, seriously, what's wrong with ...... ......?"
[cpg cn=true]

[FO pos="1/3" time=1000]
[FO pos="3/3" time=1000]

[SE f="se037"]
;//【ＳＥ】『ドア閉まる』

Then the door was closed.
[cpg]



;//ＢＫ



I had nothing more to say.
[cpg]

Kaoruko mistakes this situation for a victory, and those of us who can't pursue it are out of our minds: ......
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************

Then, some time passes.
[cpg]

[window target=false]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2500]
[free time=1000]
[BG f="b_04_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（夕方）******************************************************

[OnName num="natsuki"]
"...... what's so important?"
[cpg cn=true]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kaoruko891"]
[OnName num="kaoruko"]
"Well, ...... it's really important. So please listen to me carefully."
[cpg cn=true]

An empty classroom with no one in it.
[cpg]

[OnName num="natsuki"]
"I break up with me ... that kind of story? Did you like someone else?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kaoruko892"]
[OnName num="kaoruko"]
I don't think so. No, it's not, why are we talking about it?"
[cpg cn=true]

I guess not. But lately, me and my seniors and Kimoto are getting to be in the same position.
[cpg]

But the topic that Kaoruko broached was a heavy one, beyond my imagination.
[cpg]

It is also a story that could be described as a tragedy of sorts.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko893"]
[OnName num="kaoruko"]
I'm pregnant. ......"
[cpg cn=true]

[OnName num="natsuki"]
"...... what?"
[cpg cn=true]

No matter how accustomed I was to Kaoruko's abnormal behavior, I was still horrified by the quandary. Could it be my child?
[cpg]

If so, many imaginations pass me by, such as whether I would be a father at my age.
[cpg]

[OnName num="natsuki"]
Is that ...... whose child?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko894"]
[OnName num="kaoruko"]
I don't know about that yet. ......, but it tested positive."
[cpg cn=true]

[OnName num="natsuki"]
I see.""....... Did you tell everyone in your circle about that?"
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]

Kaoruko shakes her head. I was probably pale at the time.
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kaoruko895"]
[OnName num="kaoruko"]
"Hey, what should I do ...? Maybe everyone will accept it, right?"
[cpg cn=true]

[OnName num="natsuki"]
"Well, I don't know if it's ......."
[cpg cn=true]

[OnName num="natsuki"]
People will probably back off when they find out about it. But I think I have to tell them."
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko896"]
[OnName num="kaoruko"]
......, yeah, I guess."
[cpg cn=true]

I think Kaoruko was quite trapped at this time.
[cpg]

I was pregnant with a child that I didn't know whose child it was, and I was having a mental breakdown. On top of that, she was drawn to talk to me about it.
[cpg]

I guess that's why I said this outlandish thing: ......
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko897"]
[OnName num="kaoruko"]
No, I'm fine. Natsuki-kun, I'm sure you'll be fine after all.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kaoruko898"]
[OnName num="kaoruko"]
I'm everyone's princess, right? Yes, I'll be fine.
[cpg cn=true]

[free time=1000]

[OnName num="natsuki"]
"Eh, hey, Kaoruko?"
[cpg cn=true]

They don't have to wait for me to say anything, they just walk off somewhere.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

[OnName num="kimoto"]
Princess ......, what's the matter, you are in a good mood today."
[cpg cn=true]

Kaoruko was headed for the club room of the circle. And as Kimoto said, Kaoruko was smiling.
[cpg]

[OnName num="shinjo"]
Buch, anything good happen?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko899"]
[OnName num="kaoruko"]
Yes, I have a big announcement for everyone, and it's also very good news.
[cpg cn=true]

It's not as serious as it was when he confided in me earlier. He's lost all sense of normal thought process.
[cpg]

I think it was completely and somewhat broken.
[cpg]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kaoruko900"]
[OnName num="kaoruko"]
I'm pregnant. ...... thanks to all of you, thank you."
[cpg cn=true]

[FADEOUTBGM]


[OnName num="tokuzawa"]
"...... what?"
[cpg cn=true]

Kaoruko says with a smile. The reaction was chilling.
[cpg]

No, it's not chilling, it's completely frozen and drawn out.
[cpg]

[BGM f="bg_op"]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kaoruko901"]
[OnName num="kaoruko"]
"What happened? Please be pleased, everyone's princess has become pregnant."
[cpg cn=true]

[OnName num="tokuzawa"]
"What are you going to do about ...... being pregnant, maybe my baby ......?"
[cpg cn=true]

[OnName num="kimoto"]
It's too serious, that it is. I am not involved in this matter, that I am not.
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Kaoruko902"]
[OnName num="kaoruko"]
"...... so and such ......"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
Kaoruko takes Shinjo-senpai's hand. Then, she packed up.
[cpg]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kaoruko903"]
[OnName num="kaoruko"]
Shinjo-senpai is different, isn't he? I'm so happy for you, it could be Shinjo-senpai's child, you know?"
[cpg cn=true]

[OnName num="shinjo"]
Don't touch me.
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
A hand being shaken loose. Then Shinjo-senpai got up and was about to leave the room.
[cpg]


Now it was Kaoruko's turn to turn pale. No one had recognized her child.
[cpg]

[FACE method="shake_5" pos="2/3"]
[VOICE f="Kaoruko904"]
[OnName num="kaoruko"]
Wait a minute, you called me a princess!
[cpg cn=true]

I hang on to him, but he shakes me off. Shinjo-senpai then left the room.
[cpg]


[SE f="se037"]
;//【ＳＥ】『ドア閉まる』

The situation does not end there. Tokusawa-senpai and Kimoto are maintaining an awkward silence.
[cpg]

[OnName num="kimoto"]
"...... I have done nothing, that I have not."
[cpg cn=true]

[OnName num="tokuzawa"]
Yes, I didn't hear this coming either!"
[cpg cn=true]

This time Kaoruko takes Tokusawa-senpai's hand. And with a drawn-out smile,
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko905"]
[OnName num="kaoruko"]
Don't, don't, don't say that. ......
[cpg cn=true]

I try to stall him. But it's useless to say anything else.
[cpg]

[OnName num="tokuzawa"]
"...... I'm leaving. ......"
[cpg cn=true]



[SE f="se037"]
;//【ＳＥ】『ドア閉まる』

Tokusawa-senpai and Kimoto also left the room. Only Kaoruko and I remained there.
[cpg]

[OnName num="natsuki"]
...... was this what Kaoruko wanted to do?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko906"]
[OnName num="kaoruko"]
"Oh no, ......, I didn't do anything wrong. ......!"
[cpg cn=true]

If even I leave here, Kaoruko will really break down.
[cpg]

[OnName num="natsuki"]
I won't stop being Kaoruko's boyfriend. But..."
[cpg cn=true]

[OnName num="natsuki"]
I knew it probably wasn't a good idea to use my body to hold everyone back. ......
[cpg cn=true]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Kaoruko907"]
[OnName num="kaoruko"]
I ...... didn't do anything wrong."
[cpg cn=true]

Kaoruko just repeats the same words. I don't think her head is working properly anymore.
[cpg]

[OnName num="natsuki"]
Let's go home, Kaoruko. It's no use staying here."
[cpg cn=true]



;//ＢＫ
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


In this way, my relationship with Kaoruko was barely maintained.
[cpg]


[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[OnName num="natsuki"]
Where shall we go next, Kaoruko? ...... Kaoruko?"
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko908"]
[OnName num="kaoruko"]
I'm sorry, "Uh, ...... and. What was that?"
[cpg cn=true]

However, Kaoruko was very sick, as if she was in a high place.
[cpg]

I guess there is the shock of losing three men at once. The memory of being pampered by four men will never go away.
[cpg]

Since then, Kaoruko is no longer treated as a princess, and when Kaoruko goes to the club room, the other members walk away.
[cpg]

Shocking, no doubt. But then again, aren't you a little too uptight about it: ......?
[cpg]

[OnName num="natsuki"]
Do you really care that much about ...... the Circle?"
[cpg cn=true]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko909"]
[OnName num="kaoruko"]
"...... sorry ......"
[cpg cn=true]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]

;//薫子に視点切り替わり

Where did I go wrong?
[cpg]

I thought everything was going to be fine. I thought my harem was now built. ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=1]
[BG f="b_06_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]
;//【ＢＧ】『大学廊下』（夕方）******************************************************


[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko910"]
[OnName num="kaoruko"]
No. ...... no more."
[cpg cn=true]

Whenever I remember the good days, I compare them to the current situation.
[cpg]

I don't know how far Natsuki-kun will go with me when I tell him I have a boyfriend.
[cpg]

Sooner or later, Natsuki-kun will leave me, too: ......
[cpg]

[FACE method="shock_4" pos="2/3"]
[VOICE f="Kaoruko911"]
[OnName num="kaoruko"]
"Anybody ...... can pamper ...... anybody they want."
[cpg cn=true]

I walk aimlessly. People I pass look at me with horrified eyes.
[cpg]


In the midst of all this, there was someone who approached me.
[cpg]

[OnName num="man"]
"Do you want to do Chiya?
[cpg cn=true]

Dressed flirtatiously. Dyed hair, dark skin tone. In a way, they may be the kind of race I am looking for the most right now.
[cpg]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko913"]
[OnName num="kaoruko"]
"Yes ...... I, I can't stand to be alone anymore ......"
[cpg cn=true]

[OnName num="man"]
'Hmmm. Whatever, follow me."
[cpg cn=true]


;//ＢＫ


As we walked, I was made to explain my background and what had happened to me.
[cpg]

Being pampered by nerd boys. Being deprived of it.
[cpg]

[OnName num="man"]
"Contemporary content study group? Are you in that place? You are wrong, right?"
[cpg cn=true]

He was taken to a place, saying such things.
[cpg]

It's a well-known club in the university. It's so notorious that even I know about it.
[cpg]

[OnName num="man_B"]
I'll take good care of you. You won't even miss me."
[cpg cn=true]



;//移植のためシーンをカットしています
;//●ＣＧ（ヒロイン・知らない男に迫られるヒロイン：サークル棟の一室）ev_38
[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h2"]
;**【ＣＧ】 ev_38_0 ***********************
[CG id=14 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]

;//移植のためシーンをカットしています

A stranger approaches me. Normally, it would be natural to refuse.
[cpg]

And yet I was happy. That's how much I wanted to connect with people.
[cpg]

This kind of thing may be repeated in the future. Each time this happens, I may lose something one by one.
[cpg]

That's all I needed. I don't need anything else. I don't need anything else as long as you take care of me.
[cpg]

[SCENE id=14]

[jump storage="epend.ks" target="*start"]
;//【ルート２】エンド
