
*start|The Princess and the Secret Relationship

;#################################################
*Ep002|A Secret Relationship with a Princess
;#################################################

[SCENE id=2]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

And so we became lovers.
[cpg]

Yes, my first girlfriend in my life. It was also the first time in both of our lives. We were lovers for the first time in our lives.
[cpg]

We broke the iron rule of the circle and decided to go out with each other, knowing that the other members would shun us.
[cpg]

Of course, I didn't want to be hated by Kimoto and the other members of the circle.
[cpg]

To be honest, both the circle and my girlfriend were important to me, not to say they were equally important, but I didn't want to throw them both away.
[cpg]

[OnName num="natsuki"]
I don't know what I'm going to do."
[cpg cn=true]

What shall I do?" is my plan for today.
[cpg]

Today is a holiday. The first time we started dating was yesterday and today, and I don't have the guts to take Kaoruko out on a date.
[cpg]

If I had the guts to ask her out on a date here, I would have found another girlfriend by now.
[cpg]

That doesn't mean I'm dissatisfied with my current girlfriend at all, I think I'm just too happy for her.
[cpg]

Back to ......, I'm talking about what I'm going to do today. It's a holiday and I can't ask her out on a date, and I don't have anything special to do.
[cpg]

So, I just stroll around the city. I was supposed to be at the peak of happiness, but I couldn't stand the fact that I was losing something important as well.
[cpg]

How would I dodge the questions from everyone in the circle? Would I be able to dodge them?
[cpg]

For example, "Terrible!　You betrayed us!" "You took away our princess, boohoo!" "It's a mortal sin, banishment! I don't want to imagine it too much.
[cpg]

I don't want to imagine that too much. The part where everyone is angry is at ......
[cpg]

I was feeling a little depressed, thinking that I had made friends with them, and now I was going to lose them in a place like this .......
[cpg]

Still, I'm happy that I got to hang out with Kaoruko enough to counteract that. ......
[cpg]



[window target=false]
[free time=1000]
[BG f="b_07_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オタクショップ』（昼）******************************************************

I can't just keep walking around town aimlessly. I walked into an otaku store sometime.
[cpg]

I guess I need to go into a store like this to calm my mind.
[cpg]

The background music in the store, the colors of the store, and the like soothe me without question.
[cpg]

It's an oasis for me. Someday, I will enter a restaurant with five members of my circle, but this time I will enter it alone.
[cpg]

And there, I saw someone I didn't want to see.
[cpg]

[OnName num="kimoto"]
"Oh, Mr. Sugiura. What a coincidence.
[cpg cn=true]

My back straightens involuntarily. Then his voice rises.
[cpg]

[OnName num="natsuki"]
What?　Oh, Kimoto. Indeed, it's a coincidence.
[cpg cn=true]

Kimoto is blatantly suspicious. It's a natural behavior to be suspicious.
[cpg]

[OnName num="kimoto"]
What's wrong, that it is?　What's the matter, that you are acting so suspicious?
[cpg cn=true]

[OnName num="natsuki"]
I don't know, I've always been suspicious of my own behavior, ha ha ha.
[cpg cn=true]

It is a bitter excuse. But I wonder if you can convince me somehow. ......
[cpg]

[OnName num="kimoto"]
......?
[cpg cn=true]

No, I can't do that. I'm sure they're suspicious of me. But I don't think they know it's about Kaoruko.
[cpg]

[OnName num="kimoto"]
Is there something you're not telling me, that you're not telling me?　You seem to be very guilty about something, that you are.
[cpg cn=true]

[OnName num="natsuki"]
Well, then. I have something urgent to do.
[cpg cn=true]

Again, Kimoto tilted his head.
[cpg]

[OnName num="kimoto"]
What suspicious thing did I say this time?
[cpg cn=true]

Oh, that's it. That's the point. Kimoto might have the makings of a detective or something.
[cpg]

I leave the store without answering him.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

My peace of mind is nowhere to be found. It's a little too serious to think about what the hell I'm going to do ......, but ......
[cpg]

But I think it's pretty serious. The kind of place I would head to for healing is ......
[cpg]

I mean, the places in my pattern of behavior are places where my circle members might be.
[cpg]

If I were to go on a date, I might walk there with Kaoruko.
[cpg]

Can I keep that a secret from everyone from now on?
[cpg]

It's depressing. I didn't think I'd have such a frayed spot so soon.
[cpg]

I was already losing confidence in my ability to keep it a secret from everyone. ......
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se037"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************


I decided to cook myself lunch and dinner and then watch anime.
[cpg]

[OnName num="natsuki"]
"......This voice actor's acting is as wide-ranging as ever,.......
[cpg cn=true]

When I'm feeling disturbed, it's anime. And interesting anime at that. This is my ironclad rule, but recently I have been running out of interesting anime.
[cpg]

But I don't really feel like watching recent anime either. I think it's a bad season,
[cpg]

[OnName num="natsuki"]
"I think this season is a bad one, I ......
[cpg cn=true]

None of them are good. I'm not sure why, but I can't get my antennae to catch it.
[cpg]

I wonder if they don't think it's a bad crop, though everyone in my circle is having a lot of fun.
[cpg]

Maybe it's just that my antennae don't catch it and my senses are off.
[cpg]

Or maybe they are enjoying the crop in their own way. That's fine with me, because it's fun.
[cpg]

But I can only do that with my fellow geeks, and I can't do it alone.
[cpg]

Sooner or later, I may not be able to do it. I think if it gets out that I'm dating Kaoruko, I'll be ......
[cpg]

Creepily, bad imaginations are spreading. And then, I can no longer watch anime.
[cpg]

[OnName num="natsuki"]
I can't go to ......
[cpg cn=true]



[SE f="se011"]
;//【ＳＥ】『携帯電話の発信音』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]

I can't even watch anime. I decided to call my only reliable ally.
[cpg]

;//♪


[WAIT time=1000]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[OnName num="natsuki"]
"Hi, this is ...... Sugiura.
[cpg cn=true]


[VOICE f="Kaoruko088"]
[OnName num="kaoruko"]
What's wrong?　What's wrong, Natsuki-kun?
[cpg cn=true]

I was impressed by the change from "Sugiura-kun" to "Natsuki-kun". That's it.
[cpg]

That's not the issue right now. I tried to express the uneasiness I felt today.
[cpg]

[OnName num="natsuki"]
No, no, it's not that it's something... ......
[cpg cn=true]

I try to say it, but it doesn't work.
[cpg]

I pick out the words and string them together. It takes a nerd a long time to do that.
[cpg]

[OnName num="natsuki"]
I'm not sure what I'm supposed to be saying, but I'm trying to put it out there.　about us, you know."
[cpg cn=true]

Kaoruko had a pretty good idea of what I was talking about with words like these.
[cpg]


[VOICE f="Kaoruko089"]
[OnName num="kaoruko"]
"Oh, ......, maybe we should keep it a secret.
[cpg cn=true]

After all, it's nice to be in the same geek circle, isn't it?
[cpg]

Kaoruko is the one who understands the words of such a nerd, which are hard to convey.
[cpg]

[OnName num="natsuki"]
She is the one who understands the words of such a nerd, which are hard to convey. I think so too, yes.
[cpg cn=true]


[VOICE f="Kaoruko090"]
[OnName num="kaoruko"]
But you have to call me Kaoruko. Promise me that.
[cpg cn=true]

[OnName num="natsuki"]
"Eh, ......?　But if you do that...
[cpg cn=true]

You mean I'm the only one who calls Kaoruko by her name?　If you do that,
[cpg]

[OnName num="natsuki"]
"Won't she find out? ......?"
[cpg cn=true]

I was frightened, but Kaoruko said something that pushed me back.
[cpg]


[VOICE f="Kaoruko091"]
[OnName num="kaoruko"]
But, isn't it fun to be on the brink of being found out or not?
[cpg cn=true]

I was a little happy to hear her say that.
[cpg]

It was a bit of a strange thing to say to me.
[cpg]

The fact that it's fun to be on the brink of being found out or not is fun. That in itself is not hard to understand. But.
[cpg]

I'm not sure if he wants to show me off or not. If so, what's the point?　I think about it a little.
[cpg]

I'm sure she doesn't want to get this dull guy and make him her status as her boyfriend, either.
[cpg]

But at that time, I didn't think too much about it,
[cpg]

[OnName num="natsuki"]
I said, "Okay, well, I'll call you Kaoruko ......, but we'll keep it a secret, right?"
[cpg cn=true]

I replied. Now I have no choice but to call Kaoruko Kaoruko in the circle.
[cpg]

I thought to myself, "I'm so easily influenced.
[cpg]


[VOICE f="Kaoruko092"]
[OnName num="kaoruko"]
I said, "Yes, I think that's fine. I think that's fine."
[cpg cn=true]

[OnName num="natsuki"]
"...... Oh, yeah, so about that anime ...... the other day..."
[cpg cn=true]


;//ＢＫ


From there, the conversation was really nothing else.
[cpg]

It might be the kind of conversation where you wouldn't know what was interesting from the side.
[cpg]

It's more like lover talk, or something close to that.
[cpg]

But we are nerds. We are a couple of nerds.
[cpg]

The content of our lovers' talk is interwoven with talk of anime and manga.
[cpg]




[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

[OnName num="natsuki"]
We watched the latest episode of Fast. I wish I could go back and watch the first episode.
[cpg cn=true]

They immediately talked about the anime that Kaoruko had recommended to them the other day. I've been checking it out.
[cpg]


[VOICE f="Kaoruko093"]
[OnName num="kaoruko"]
Really?　I'm glad, I'm also a big fan of ......, we talked about it before.
[cpg cn=true]

Kaoruko giggles. I think she's cute even over the phone.
[cpg]

[OnName num="natsuki"]
I think it's cute even over the phone. But I can hear the same story over and over again from Kaoruko.
[cpg cn=true]

When I said that as a test, she giggled again.
[cpg]


[VOICE f="Kaoruko094"]
[OnName num="kaoruko"]
What's that? What a strange pick-up line.
[cpg cn=true]

When she said that, I suddenly felt embarrassed. Did I just hit on him?
[cpg]

[OnName num="natsuki"]
I didn't mean it that way. ......
[cpg cn=true]

...... is a conversation.
[cpg]

I'm not sure if it's a conversation that would make me want to punch him in the face.
[cpg]

[OnName num="natsuki"]
"Oh yeah, the comic book adaptation of that anime..."
[cpg cn=true]

But I was so happy at this moment.
[cpg]

The conversation went on and on. Kaoruko and I were talking about nothing else.
[cpg]

It is precisely because it is so unimportant that I love it. It is a time I want to cherish.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[BG f="b_01_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夕方）******************************************************

By the time I hung up the phone, I was beginning to feel that it was nothing so much to keep a secret from everyone in the circle as to make them suspicious.
[cpg]

[OnName num="natsuki"]
Well, ...... it's getting pretty late, isn't it?
[cpg cn=true]


[VOICE f="Kaoruko095"]
[OnName num="kaoruko"]
Well, I'm about to eat dinner, so I'm going to go now.
[cpg cn=true]

Kaoruko was talking to me even through her hunger. I'm sorry to hear that.
[cpg]

[OnName num="natsuki"]
I'm sorry for talking for so long. Then, I'm sorry for talking for so long.
[cpg cn=true]

I apologized in advance. Kaoruko's reply was as follows.
[cpg]


[VOICE f="Kaoruko096"]
[OnName num="kaoruko"]
It's okay. If it's Natsuki-kun's long story, I can listen to it as much as I want.
[cpg cn=true]

[OnName num="natsuki"]
"Uu......"
[cpg cn=true]

She imitated me. I'm embarrassed.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]


...... And then, the next day.
[cpg]



[window target=false]
[free time=1000]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


;//【ＢＧ】『街』（朝）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

I'm not sure if I'm going to be able to do it. I can't be at peace at all.
[cpg]

Holiday as a lover. That's still fine. Because I don't have to meet everyone else.
[cpg]

First commute to school as a girlfriend. Even if I don't meet Kaoruko directly at the lecture on the way,......
[cpg]

[OnName num="natsuki"]
"Hah ...... ah, what should I do?"
[cpg cn=true]

If I go to the clubroom, we will definitely meet each other. I wonder if I will be able to maintain my composure then.
[cpg]

Or rather, is it bad if I can't keep a normal mind? Senpai and Kimoto will find out about the relationship.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kaoruko097"]
[OnName num="kaoruko"]
"Good morning, Natsuki-kun.
[cpg cn=true]

[OnName num="natsuki"]
"Wow!"
[cpg cn=true]

I couldn't help but let out a dumb voice. "Wow," I said. Even though my girlfriend greeted me.
[cpg]

I got a pat on the back, and when I turned around, Kaoruko was there. She has a sparkling smile on her face today, too.
[cpg]

But for now, I decided to protest a little about the surprise.
[cpg]

[OnName num="natsuki"]
'Bi, don't startle me. ......
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
After apologizing lightly, Kaoruko started to talk about something else.
[cpg]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko098"]
[OnName num="kaoruko"]
I'm a little sad that we don't have any lectures together today. I'm a little sad.
[cpg cn=true]

I'm a little sad," she said, "but it can't be helped that we didn't have any lectures together.
[cpg]

[OnName num="natsuki"]
I'm lonely too, but ...... we're going to the club room, right?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]

When I asked this, Kaoruko nodded with a smile.
[cpg]

I knew it. I can't not go to them.
[cpg]

I think that no matter how much we have become lovers, our place is still in that clubroom.
[cpg]

[OnName num="natsuki"]
Then, I'll see you in the clubroom.
[cpg cn=true]

I waved goodbye to her, and she came very close to me.
[cpg]

[free time=300]
[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kaoruko099"]
[OnName num="kaoruko"]
I'll see you later, Natsuki-kun," he said. See you later, Natsuki-kun.
[cpg cn=true]

[OnName num="natsuki"]
I'll see you later, Natsuki-kun, chu!　Hey, hey, Kaoruko.
[cpg cn=true]

She kissed me on the cheek. I was kissed in a place where the university was already just in front of me.
[cpg]

[free time=300]
[FG f="CHA01_p3_01_a.ui" method="change_2"  pos="2/3" time=800]
If someone sees me, it could be a big problem. That's it, I might be kicked out of the circle. ......
[cpg]

...... No, the probability is low. If it was not seen by a member of the circle, it might not be a big problem.
[cpg]

Whatever it was, I was surprised, and while I was surprised, Kaoruko left for the university.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（昼）******************************************************

[OnName num="natsuki"]
"......"
[cpg cn=true]

Kaoruko kissed me early in the morning. A kiss, albeit on the cheek.
[cpg]

I was so happy to see her, I was so happy to see her.
[cpg]

[OnName num="natsuki"]
"I'm ...... too happy. ......"
[cpg cn=true]

I can't help but talk to myself in a sickening way. I'm too happy to be a nerd.
[cpg]

I was originally just hoping to have a male geek friend in the first place.
[cpg]

That alone would have made me happy, but then I made a female otaku friend, and she became my girlfriend.
[cpg]

I'm afraid that I've exceeded my capacity for happiness, and that someday, somewhere, it's going to overflow.
[cpg]

If it overflows, that's the end of it.
[cpg]

The moment it overflows, I will lose that guy's otaku friend.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

[OnName num="kimoto"]
"Kaoruko-dono, do you have this portable game console, that you do?"
[cpg cn=true]

Around the entrance of the club room, I stopped and looked at everyone.
[cpg]

[FACE method="shake_7" pos="2/3"]
[VOICE f="Kaoruko100"]
[OnName num="kaoruko"]
What's that?　I've never seen it before, is there a new one?
[cpg cn=true]

Kaoruko and Kimoto were talking to each other. They seem to be talking about a portable game console.
[cpg]

[OnName num="kimoto"]
"It's a minor change, that it is, but the LCD has been cleaned up, that it has.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

[OnName num="tokuzawa"]
Kimoto loves that company, doesn't he? He is a believer, a believer.
[cpg cn=true]

Tokusawa senior was putting a damper on the conversation. He may be a bit oblique.
[cpg]

Of course, I know he is not a bad person, so I don't doubt him on that point.
[cpg]

[OnName num="kimoto"]
It's okay to be a believer, that it's worth believing, that it's worth believing.
[cpg cn=true]

[OnName num="shinjo"]
I mean, I don't like the word "believer," because I feel like it's a word that ...... antis use to make fun of."
[cpg cn=true]

Shinjo-senpai is a good person without a doubt. I don't want to lose this important senpai as a friend.
[cpg]

The actual "I'm not a fan of the word" is a word that is used to describe a person who is not a fan of the word.
[cpg]

[OnName num="kimoto"]
"Oh, Sugiura-dono.
[cpg cn=true]

[OnName num="natsuki"]
Good evening, Kimoto. I bought that.
[cpg cn=true]

[OnName num="tokuzawa"]
"What's up, Sugiura, I didn't know you were here.
[cpg cn=true]

I did as I was told and sat down. So far, they call me Sugiura.
[cpg]

Of course, that's my last name, not that it's wrong. But....
[cpg]

[OnName num="shinjo"]
Sugiura, you want some of this?　It's delicious, bouffant.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko101"]
[OnName num="kaoruko"]
Hello, Natsuki-kun!
[cpg cn=true]

First of all, there was this problem.
[cpg]

Only one of us was called differently. The rest of the three froze at that.
[cpg]

The rest of the three froze up, or rather, froze up visibly, their expressions frozen in place.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kaoruko102"]
[OnName num="kaoruko"]
Look, look, Kimoto-kun has something interesting for you.
[cpg cn=true]

Kimoto, who was told that, was also still frozen.
[cpg]

[OnName num="natsuki"]
I said to him, "Oh, yeah, ...... that's a new video game console, isn't it?"
[cpg cn=true]

I spoke to him and he finally responded. I guess he was that envious of the name-calling.
[cpg]

[OnName num="kimoto"]
"......Yes, that it is, that it is. Kaoruko-dono was also curious about it, that she was.
[cpg cn=true]

[OnName num="natsuki"]
"Oh, Kaoruko-chan didn't know that either.
[cpg cn=true]

[FACE method="shock_5" pos="2/3"]
I dare to call her Kaoruko-chan. In this atmosphere, I can't call her that.
[cpg]

That's what I thought, but Kaoruko-chan didn't seem to forgive me after all. ......
[cpg]

[FACE method="shake_3" pos="2/3"]
Kaoruko shakes her head with her eyes closed. That's right, she won't allow me to call her chan. ......
[cpg]


[free time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


Then Kaoruko remained grumpy for a while.
[cpg]

[OnName num="kimoto"]
"What's wrong, Kaoruko-dono,...... why are you grumpy, that you are?"
[cpg cn=true]

She didn't even reply. Of course, I know the reason.
[cpg]

It was probably because I had called Kaoruko Kaoruko-chan.
[cpg]

I thought this mood would not be resolved until I called her Kaoruko. ......
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************

[OnName num="tokuzawa"]
'Sure, it's a pretty screen. But it's a bit expensive though..."
[cpg cn=true]

The two of us still had that game console on the agenda.
[cpg]

[OnName num="kimoto"]
What, you're making fun of me, that you are!"
[cpg cn=true]

Kimoto and Tokusawa-senpai seem to be having a difference of opinion.
[cpg]

[OnName num="tokuzawa"]
I don't mean to make fun of it, but what do you think about it, Kaoruko-chan?　I still feel like she's just a toy."
[cpg cn=true]

He shakes it at Kaoruko. Shaken, Kaoruko,
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kaoruko103"]
[OnName num="kaoruko"]
I guess so, I'm ......
[cpg cn=true]

Kaoruko turned to me as she said, "I don't know.
[cpg]

I had a bad feeling about this. And of course, that premonition came true.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko104"]
[OnName num="kaoruko"]
I think it's a beautiful screen. What do you think, Natsuki-kun?
[cpg cn=true]

Once again, he called me Natsuki-kun. The other three were still frozen, though not as much as before.
[cpg]

And even the most insensitive of me could tell that he was urging them to call Kaoruko Kaoruko.
[cpg]

Oh, come on, let's call her Kaoruko. If it's enough to say "Kaoruko," then that's fine.
[cpg]

I was prepared to do it, but I also felt that it would be a bad idea to do it in front of everyone. ......
[cpg]

[OnName num="natsuki"]
......I guess I agree with Kaoruko.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
I said as if muttering in a whisper. Kaoruko's satisfied expression and the remaining three who froze.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_op"]
[WAIT time=100]


Naturally, after Kaoruko left, I was pursued. It was more like an interrogation.
[cpg]


;//【ＢＧ】『サークル部室』（夕方）******************************************************

[OnName num="kimoto"]
You haven't forgotten the ironclad code, have you?
[cpg cn=true]

Kimoto's expression was stern than usual. And his tone of voice matched the harshness of his voice.
[cpg]

[OnName num="natsuki"]
I haven't forgotten ......, I swear to God. I swear to God."
[cpg cn=true]

For the moment, I lied to cover my tracks.
[cpg]

[OnName num="tokuzawa"]
The word "God" is a light word for a nerd!
[cpg cn=true]

Hearing this, Kimoto shook his head.
[cpg]

[OnName num="kimoto"]
No, Tokusawa-senpai is an otaku too, I am an otaku too, that I am ...... anyway."
[cpg cn=true]

The three of them look at me. I shrink back in response.
[cpg]

This is what happens, I knew it. Even though I was prepared for it, it's still pretty hard.
[cpg]

If I make a mistake in my choice here, I could end up withdrawing from the circle.
[cpg]

[OnName num="shinjo"]
You called me Kaoruko, right?
[cpg cn=true]

First of all, she started from that side. It was true that I had been calling her Kaoruko ever since I muttered "Kaoruko" to her.
[cpg]

[OnName num="natsuki"]
Since we are classmates, it's fine. ...... It's just like calling Kimoto as Kimoto."
[cpg cn=true]

Shinjo-senpai nodded. Then he put his hand to his chin.
[cpg]

[OnName num="shinjo"]
'Indeed,.......
[cpg cn=true]

Tokusawa-senpai seemed unconvinced. Kimoto also looks similar.
[cpg]

[OnName num="tokuzawa"]
I don't think it's "for sure!　Kaoruko, you called Sugiura Natsuki-kun!
[cpg cn=true]

There, that's for sure, isn't it? Shinjo-senpai is Shinjo-senpai, Tokusawa-senpai is Tokusawa-senpai, and Kimoto is Kimoto-kun, but just me.
[cpg]

[OnName num="natsuki"]
It doesn't matter whether you call me by my name or by my surname, ...... it's all the same."
[cpg cn=true]

I say the exact opposite of what I'm thinking. And then,
[cpg]



[SE f="se007"]
;//【ＳＥ】『机叩く』

[OnName num="tokuzawa"]
We're not the same!"
[cpg cn=true]

Tokusawa-senpai got up and got angry, hitting the desk.
[cpg]

Something like this happened before. When was it? ......
[cpg]

[OnName num="natsuki"]
"Your voice is so loud,...... you'll be surprised.
[cpg cn=true]

[OnName num="tokuzawa"]
I'm saying, I can't allow you to just run away from me.
[cpg cn=true]

[OnName num="shinjo"]
"Well, you don't have to be so hot ...... about it, Tokusawa, do you really like Kaoruko-chan?"
[cpg cn=true]

It's a sore point. If you hit that point, Tokusawa-senpai would not be able to give you an immediate answer.
[cpg]

[OnName num="tokuzawa"]
"That's .......
[cpg cn=true]

[OnName num="shinjo"]
What about Kimoto?　If you don't let him get that part right, it's not right to blame Sugiura. ......
[cpg cn=true]

[OnName num="kimoto"]
"...... I, that ......
[cpg cn=true]

All of us became quiet on this topic. And I took advantage of the opportunity,
[cpg]

[OnName num="natsuki"]
"Well then, I have an anime I want to watch, so I'm going home.
[cpg cn=true]

[OnName num="tokuzawa"]
"Oh, wait!
[cpg cn=true]

I said some excuse peculiar to an otaku, and quickly walked away.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="migi2.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi2.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[SE f="se029"]
;//【ＳＥ】『ベッドきしむ』
[WAIT time=1000]

I collapsed on my back on the bed.
[cpg]

I had been strangely worn out for the day. Surprisingly, Kaoruko has a knot of wanting to show off her boyfriend.
[cpg]

Calling me Natsuki-kun and making me call her Kaoruko are all part of a sequence of events, or rather, her thoughts are transparent.
[cpg]



[SE f="se013"]
;//【ＳＥ】『携帯電話の着信音』

[OnName num="natsuki"]
"Whoops."
[cpg cn=true]

Then, my cell phone rang. The caller was Kaoruko. I hurriedly pressed the call button.
[cpg]


[SE f="se034"]
;//【ＳＥ】『通話ボタン』

[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]

[OnName num="natsuki"]
It's ......, yes, this is Natsuki.
[cpg cn=true]


[VOICE f="Kaoruko105"]
[OnName num="kaoruko"]
"Hmmm. Everyone was funny today.
[cpg cn=true]

[OnName num="natsuki"]
"It's not funny,......, because I broke out in a cold sweat, you know?"
[cpg cn=true]

He chuckles. I'm sure it was very funny.
[cpg]

[OnName num="natsuki"]
"But did you call me to tell me that?"
[cpg cn=true]


[VOICE f="Kaoruko106"]
[OnName num="kaoruko"]
No, I didn't. I just wanted to say that I'm going to go on a date with you this holiday. I'll go on a date with you this holiday, Natsuki-kun.
[cpg cn=true]

For a moment, I thought it would be nice, but then I turned back.
[cpg]

[OnName num="natsuki"]
"......No, but what happens if some of the older guys in the circle find out ......"
[cpg cn=true]

I was frightened, and as if to soothe me, Kaoruko said, "If you go out a little farther, you might happen to meet someone.
[cpg]


[VOICE f="Kaoruko107"]
[OnName num="kaoruko"]
If you go out a little far, you won't run into them by chance.
[cpg cn=true]

She was right. That would solve the problem, but I had a bad feeling about it.
[cpg]

[OnName num="natsuki"]
If I get bound to ......, I won't be able to stay in the Contemporary Contents Research Group, will I?
[cpg cn=true]

I voiced my uneasiness. Then he said, "That may be so,
[cpg]


[VOICE f="Kaoruko108"]
[OnName num="kaoruko"]
I said, "That may be so, but I'm going to miss you if we don't go out on dates after we got together.
[cpg cn=true]

I got a pretty good line in return. It's hard for me to say no when someone says something like that. ......
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


So, in the blink of an eye, we made a promise to go on a date.
[cpg]

I guess it would be more accurate to say that I made a promise and he promised me.
[cpg]

Maybe I'm the type of guy who will get his ass handed to him in the future. ......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_00_2.ui" time=1000]
[WAIT time=2500]
[BG f="b_05_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（昼）******************************************************

[FG f="CHA01_p3_03_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Kaoruko109"]
[OnName num="kaoruko"]
Hey, look, there's a bookstore over there that looks like it's geared toward the core audience.
[cpg cn=true]

[OnName num="natsuki"]
"You're not going to go into ......, are you?　It's probably more for guys, you know, the ......"
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kaoruko110"]
[OnName num="kaoruko"]
"Can't I go in there?　I'm interested in it.
[cpg cn=true]

The day of our date. The day of the date, we were on a date in a town a short distance away from the university.
[cpg]

The first thing to do is to make sure that you have a good time.
[cpg]

I felt a little shameful about it, so I said to her, "You know, I've been to a few bookstores in the past.
[cpg]

[OnName num="natsuki"]
There are more regular bookstores around here. There is a big bookstore around here, I think.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko111"]
[OnName num="kaoruko"]
I wonder if they have a good comic book section. I wonder if they have a good comic book section.
[cpg cn=true]

[OnName num="natsuki"]
I think so. Maybe. Let's go there.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
However, when I took the lead, I found it very difficult.
[cpg]

I had no idea how itchy it would be to take her hand.
[cpg]




;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

And so, being nerds, we followed a nerdy date course.
[cpg]

Then, as the sun was about to set, she said, "Hey, Natsuki-kun.
[cpg]

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="b_00_3.ui" time=1000]
[WAIT time=2500]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************

[FG f="CHA01_p3_03_a.ui" method="change_7"  pos="2/3" time=800]
[VOICE f="Kaoruko112"]
[OnName num="kaoruko"]
I said, "Hey, Natsuki-kun,...... did I tell you that I live alone too?"
[cpg cn=true]

[OnName num="natsuki"]
'...... no, maybe I haven't heard.'
[cpg cn=true]

Kaoruko bluntly asks me out. It's romantic to ask her to take me up to her house, but it's more ......
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko113"]
[OnName num="kaoruko"]
'Shall I cook dinner for you?　At Natsuki-kun's house."
[cpg cn=true]

[OnName num="natsuki"]
"...... yeah."
[cpg cn=true]



[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

I was not in the mood while she was making me dinner.
[cpg]

I had a feeling that we were probably going to ...... have a good time after that.
[cpg]

[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kaoruko114"]
[OnName num="kaoruko"]
I was not sure if it was a good idea or not, but it was. It's ready, Natsuki-kun.
[cpg cn=true]

[OnName num="natsuki"]
"Ummm, yes. Bon appétit.
[cpg cn=true]




;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[BG f="b_01_4.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


To be honest, I couldn't really taste it.
[cpg]

I was too nervous. And too much anticipation for what was to follow.
[cpg]

I didn't know when to eat and when to swallow.
[cpg]

[OnName num="natsuki"]
Thank you for the ...... food."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko115"]
[OnName num="kaoruko"]
Thank you very much.
[cpg cn=true]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

Then, after cleaning up the dishes and relaxing for a while.
[cpg]

I mean, I didn't have time to relax at all, but after a while.
[cpg]

;//●ＣＧ（ヒロイン・ベッドに隣り合って座る二人：主人公の部屋）ev_05


[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_05_0 ***********************
[CG id=3 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]


[VOICE f="sKaoruko001"]
[OnName num="kaoruko"]
Hey, Natsuki-kun, ......."
[cpg cn=true]

Kaoruko was coming on to me. I had no reason to refuse her.
[cpg]

[OnName num="natsuki"]
I didn't say a word back.
[cpg cn=true]


I didn't say a word back, but I accepted her coming on to me.
[cpg]

I am happy again after all. I'm not sure if it's a good idea or not, but it's a good idea.
[cpg]


;//移植のためシーンをカットしています

;//移植のためシーンをカットしています


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_03_a.ui" method="change_2"  pos="2/3" time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[OnName num="natsuki"]
"Hey, Kaoruko,......, can I talk to you for a minute?"
[cpg cn=true]


[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko151"]
[OnName num="kaoruko"]
"...... what?　Natsuki-kun.
[cpg cn=true]

[OnName num="natsuki"]
"I have a lecture tomorrow, too. Do you want to stay over tonight?
[cpg cn=true]


[FACE method="bow_6" pos="2/3"]
Kaoruko nodded her head. I couldn't help but notice her shy expression.
[cpg]



;//ＢＫ
;//●ＣＧエロ（ヒロイン・バックで突かれる。少しずつ互いに慣れていく。避妊具使用：主人公の部屋）ev_07

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_07_0 ***********************
[CG id=4 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]

[OnName num="natsuki"]
She is ...... cute.
[cpg cn=true]


The first thing that comes out of my mouth is that I'm a natural.
[cpg]

When it's just the two of you, you don't have to worry about anyone finding out about it.
[cpg]

[VOICE f="sKaoruko002"]
[OnName num="kaoruko"]
I'm so happy. I love you. I love you."
[cpg cn=true]


She became aggressive and kissed me again.
[cpg]



;//移植のためシーンをカットしています
;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[window target=true]
[WAIT time=100]


It was very late. We went to sleep, but soon the alarm went off.
[cpg]


[SE f="se014"]
;//【ＳＥ】『目覚ましのベル』

[window target=false]
[transition target={true} rule="mezame.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="mezame.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（朝）******************************************************


[OnName num="natsuki"]
"Oh, ......, you're so loud."
[cpg cn=true]

[stopse g=2]
;//通常se
[stopse g=3]
;//通常se

[WAIT time=1000]

[FG f="CHA01_p5_03_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko170"]
[OnName num="kaoruko"]
What are we going to ...... do about college today ......?"
[cpg cn=true]

We both sounded very sleepy and decided to discuss it.
[cpg]

[OnName num="natsuki"]
"...... should I take the day off?"
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kaoruko171"]
[OnName num="kaoruko"]
"Yeah, I'm fine with that."
[cpg cn=true]

I was a little stuck on the word "I" and thought about it.
[cpg]

That's right. If everyone in the circle saw the distance between us and then we both took a break at the same time, that would be suspicious.
[cpg]

[OnName num="natsuki"]
I'm going to go to the university alone after all."
[cpg cn=true]

[FACE method="shake_4" pos="2/3"]
[VOICE f="Kaoruko172"]
[OnName num="kaoruko"]
'Huh ah...... then, me too, let's go.'
[cpg cn=true]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（朝）******************************************************


[SE f="se027"]
;//【ＳＥ】『喧騒』

And so we parted on the spot. Kaoruko said she would go to the university once she headed home.
[cpg]

If I hadn't fallen asleep twice, I would see her again in the club room of the circle. I was looking forward to that, but also sleepy. ......
[cpg]

I headed to the university.
[cpg]



[SE f="se001"]
;//【ＳＥ】『歩く』


[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（昼）******************************************************

And I had a lecture at the university. Sleepy, sleepy, so I sleep most of the time.
[cpg]

After the lecture was over, I was woken up by another student who I didn't know, and I was barely able to ......
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************

;//♪家に帰って着替えてゴスロリ調

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko173"]
[OnName num="kaoruko"]
"Hello, I'm a ...... senior student."
[cpg cn=true]

[OnName num="shinjo"]
"...... bouffant, you look kind of sleepy today.
[cpg cn=true]

[OnName num="natsuki"]
"You've been watching cartoons or something all night, haven't you,......?"
[cpg cn=true]

[OnName num="tokuzawa"]
You also have dark circles under your eyes.
[cpg cn=true]

They are blatantly suspicious of me. It might have been worse than resting, because you'll be interrogated on the spot,.......
[cpg]

[OnName num="tokuzawa"]
What's going on, you two, that's making you sleepy?
[cpg cn=true]

[OnName num="natsuki"]
Nothing, nothing at all.
[cpg cn=true]

[FACE method="bow_5" pos="2/3"]
[VOICE f="Kaoruko174"]
[OnName num="kaoruko"]
Yes, it is. The fact that we are sleepy has nothing to do with it.
[cpg cn=true]


[OnName num="kimoto"]
When you say it's irrelevant, it's even more suspicious. ......
[cpg cn=true]

[FACE method="change_4" pos="2/3"]
So, sleepy as we were, we kept quiet.
[cpg]

I was afraid that I would not be able to stay in this circle because of the ironclad rules of the circle, so I kept it a secret.
[cpg]

Kaoruko probably feels the same way. This circle must be a comfortable place for Kaoruko as well.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[BG f="b_05_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]


By the way, I slept very well that day. I slept so much that I was late the next day with Kaoruko.
[cpg]

It would have been the same even if I had not forced myself to attend the lecture. ......
[cpg]

[window target=false]
[BG f="b_05_1.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

Days go by. The days of me and Kaoruko as lovers, and the days with everyone in the circle in a harmonious atmosphere.
[cpg]

Both are invaluable to me and I didn't want to lose either.
[cpg]

;//移植のためシーンをカットしています

;//移植のためシーンをカットしています

;//ＢＫ

[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（昼）******************************************************

I couldn't get through my university lectures at all.
[cpg]

How would I deal with Kaoruko if she came at me from now on? That was all I could think about.
[cpg]

One day they will find out and it will be me who will be in trouble. Kaoruko wants to show them off, so she may make a move so that they will find out.
[cpg]

But still, I never knew Kaoruko had such a side to her. ......
[cpg]

[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kaoruko221"]
[OnName num="kaoruko"]
"......"
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
Even now, I'm sitting next to him in a lecture. When I look at him, he smiles at me.
[cpg]

And then he draws a deformed cartoon character on the edge of his notebook and sends it to me. ...... How should I respond?
[cpg]

I can't even draw, so I just replied, "Your drawings are good.
[cpg]

Then he showed me a more serious and enthusiastic drawing.
[cpg]

What a nerd. If it's true, I should be more pleased here, but I can't be honestly pleased. ......
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_03_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_t1"]
[WAIT time=100]
;//【ＢＧ】『大学教室』（昼）******************************************************

Then he finished his lecture. As I was about to leave my seat, Kaoruko whispered in my ear.
[cpg]

[free time=300]
[FG f="CHA01_p5_03_a.ui" method="change_6"  pos="2/3" time=800]
[VOICE f="Kaoruko222"]
[OnName num="kaoruko"]
Hey, next time you have a day off, why don't we go out and have fun?
[cpg cn=true]

[OnName num="natsuki"]
Wow!"
[cpg cn=true]

[free time=300]
[FG f="CHA01_p3_03_a.ui" method="change_1"  pos="2/3" time=800]
Suddenly she whispered in my ear and I screamed out loud. I was getting a lot of attention from the people around me.
[cpg]

This was just what Kaoruko wanted. She wants me to talk about our date with her.
[cpg]

[OnName num="natsuki"]
"You're going to ...... for fun, okay, Saturday is fine?"
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko223"]
[OnName num="kaoruko"]
I'll be dressed up as much as I can. I'll be dressed up as much as I can.
[cpg cn=true]

If it were true, this would be something I could honestly be happy about.
[cpg]

I'm not sure if it's her true nature or her personality that makes me a little suspicious.
[cpg]

I can't help but imagine what kind of outfit she means by "full of fashion".
[cpg]

It seems possible that she would walk around near the university in a very conspicuous outfit. Or maybe even sticking close to me. ......
[cpg]

Thinking about it makes my head hurt. If I did this too many times, my seniors and Kimoto would definitely find out.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kaoruko224"]
[OnName num="kaoruko"]
What's wrong?　You look so bitter.
[cpg cn=true]

[OnName num="natsuki"]
"No, I don't think I had that look on my face. ......
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kaoruko225"]
[OnName num="kaoruko"]
"Really?　Anyway, I'll see you next Saturday. I promised, so I'll see you then."
[cpg cn=true]

[OnName num="natsuki"]
"Uh, yeah, see you then. ......
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』
[free time=1000]
[WAIT time=1000]

I'm worried that my smile might be drawn out.
[cpg]

Self-aggrandizement, or whatever that thing is called. ......
[cpg]

I had a feeling that I was probably going to get caught up in it next Saturday, and now I feel somewhere between depressed and expectant.
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

Somehow, I couldn't bring myself to show up at the circle, so I decided to just leave.
[cpg]

Kaoruko was not even next to me. She is probably in the club room right now.
[cpg]

I can imagine that if the five of us got together, she would imply that I was her boyfriend.
[cpg]

I'm in trouble. ...... I want to be friends with everyone in the circle.
[cpg]

With that in mind, I made a trip to the supermarket to buy ingredients for dinner.
[cpg]



[SE f="se001"]
;//【ＳＥ】『歩く』

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

By the time I got back home and finished dinner, it was completely nighttime.
[cpg]

Many otaku may have an unbalanced diet, but I cook for myself.
[cpg]

I was just trying to eat the most cost-effective meals so that I could buy goods while still living off my parents' backs.
[cpg]

I was thinking, "Surprisingly, there are more otaku who cook for themselves. ......
[cpg]

[OnName num="natsuki"]
"...... Wow, that's a sweet line. ......"
[cpg cn=true]

I was watching an anime by Kaoruko Ichi, and the male character said an incredibly sweet line.
[cpg]

I don't think it's possible to confuse me with these things, but ......
[cpg]

But I kept watching, thinking that maybe there was something I wanted in her.
[cpg]


;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************

By the time I finished watching it, I was feeling that love is a good thing after all.
[cpg]

If this is Kaoruko's plan, it's too elaborate for me to say anything. I think it's probably not.
[cpg]

I was able to feel that Kaoruko's personality that she wanted to show off, or whatever it was, was just a tiny thing, and that she was now enjoying her love life instead of worrying about such things.
[cpg]

[OnName num="natsuki"]
Well, and ......."
[cpg cn=true]

After that, I spent the rest of the day surfing the net as usual, and soon fell asleep.
[cpg]

These days are so unproductive. If it weren't for Kaoruko and everyone in the circle, I might have been too sick to go to college.
[cpg]

...... I said I was going to go on a date on Saturday. She said she's going to get dressed up, but I wonder what she's really going to wear.
[cpg]

Kaoruko's fashion sense is a bit off, or it doesn't match her makeup. ......
[cpg]

I don't know because it's an amateur idea, but that's how I feel. I couldn't imagine what she would wear.
[cpg]


[jump storage="ep003.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

