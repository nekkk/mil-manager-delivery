
*start|From Hard to Bonus

;#################################################
*Ep001|From Hard to Bonus
;#################################################

[SCENE id=1]

[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『空』（昼）（;//朝）******************************************************
;//背景差分削除

Days go by. In the group chat for example, we were talking about going shopping in Otaku Town next.
[cpg]

I was thinking that this is exactly what Otakasa is all about ......, but it turned out that we guys were going to be pushed around by Kaoruko-chan.
[cpg]

I mean, it's not that we're being pushed around, it's more like we're being pushed around on our own. ......
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

[OnName num="kimoto"]
"Well, it's a perfect day to be an otaku, isn't it?"
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kaoruko021"]
[OnName num="kaoruko"]
Giggle. What is it?　What do you mean, "a perfect day to be a nerd"?
[cpg cn=true]

[OnName num="tokuzawa"]
"I think he means it's sunny. Let's get out of here.
[cpg cn=true]

[OnName num="shinjo"]
"Buuhuh, Kaoruko, there's an interesting store I'd like to introduce to you. ......
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

Each of them was trying his or her best to make Kaoruko-chan look good in his or her own way.
[cpg]


[OnName num="natsuki"]
......"
[cpg cn=true]

And I, too, want to dress up, but I can't do it well.
[cpg]

I wonder if Kaoruko-chan can see that I'm just dressed to the nines. ......
[cpg]

And as we walk along, the streets start to look like it.
[cpg]

This is the best geek town around here, and there are a lot of stores that I am a regular customer.
[cpg]

The five of us stepped into one of them.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オタクショップ』（昼）******************************************************



[FG f="CHA01_p1_01_a.ui" method="change_5"  pos="2/3" time=800]
[VOICE f="Kaoruko022"]
[OnName num="kaoruko"]
Wow, this ...... is a beautiful store.
[cpg cn=true]

[FACE method="change_2" pos="2/3"]
The inside of the store is a poster, or whatever you want to call it, and if you are two dimensional and have proper sensibilities, you will get the impression that it is more of a mess than beautiful.
[cpg]

But Kaoruko was still a resident of this side. Without a doubt, I said beautiful now.
[cpg]

[OnName num="shinjo"]
I'm glad you like it.
[cpg cn=true]

[OnName num="kimoto"]
Oh, the new book is already out, that it is. I have to get this one. ......
[cpg cn=true]

[OnName num="tokuzawa"]
I'm not so careful, Kimoto. It's been out for a long time.
[cpg cn=true]

We walked around in the store, which was supposed to be a little spacious but somehow felt small.
[cpg]

As we walked around in a tight group, we found ......
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『オタクショップ』（昼）******************************************************

[OnName num="natsuki"]
No, no, no, no!　I protest that this is a bad idea, even for a senior!"
[cpg cn=true]

[OnName num="shinjo"]
'Do, why?　I want Kaoruko-chan to know about this world.
[cpg cn=true]

[OnName num="tokuzawa"]
That's right, it's a path that anyone would take.
[cpg cn=true]

[OnName num="kimoto"]
A path that normal girls don't go down, that it is!
[cpg cn=true]

We were in front of the adult section and were pushing each other around.
[cpg]

In short, we were arguing over whether or not to let Kaoruko-chan pass through the adult section.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kaoruko023"]
[OnName num="kaoruko"]
"I'm interested, though. ......
[cpg cn=true]

[OnName num="tokuzawa"]
Look, Kaoruko-chan is saying this too.
[cpg cn=true]

[OnName num="natsuki"]
No, you can't!　Come on, Kaoruko-chan, let's go."
[cpg cn=true]

[FACE method="change_1" pos="2/3"]
I grabbed her arm and made her leave the place. Then, for a moment, his eyes were on me again.
[cpg]

I'm sure this will be pursued again later,......, but it's better than hurting Kaoruko-chan, I thought as I left the place.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_07_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


[OnName num="kimoto"]
Look, Kaoruko-dono, this manga has a cute design, doesn't it?　Even girls can enjoy it, that they can."
[cpg cn=true]

[OnName num="natsuki"]
No, no, this is more interesting than that.
[cpg cn=true]

[OnName num="tokuzawa"]
"This CD is an arrangement of ani-songs, but it's all EDM. ......
[cpg cn=true]

[OnName num="shinjo"]
"Buuhuh, can I hold your hand too, Kaoruko-chan?"
[cpg cn=true]

After that, we each flirted in our own way,...... and Kaoruko-chan fended it off well each time.
[cpg]

I think I probably grabbed her arm and made her move away from me, unconsciously trying to make her more likable.
[cpg]


[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（昼）******************************************************

After that, we left the otaku store.
[cpg]

[OnName num="kimoto"]
"Phew, we got a lot today, that we did.
[cpg cn=true]

[OnName num="shinjo"]
"It's going to cost you a lot of money, isn't it, Duhuhu?"
[cpg cn=true]

[OnName num="tokuzawa"]
Speaking of spending a lot of money, this place is also expensive, isn't it?
[cpg cn=true]

Tokusawa-senpai pointed to a game center.
[cpg]

[OnName num="natsuki"]
Kaoruko-chan, have you ever been to a game center?
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kaoruko024"]
[OnName num="kaoruko"]
Of course. You know I'm pretty good at games, right?
[cpg cn=true]

[OnName num="kimoto"]
"I see, then there's no way I won't go in there.
[cpg cn=true]

[OnName num="shinjo"]
"Well, I'm not really interested in it. ......
[cpg cn=true]

[OnName num="tokuzawa"]
"Well, come on, let's go in. Come on, come on.
[cpg cn=true]


;//ゲームセンター内なので、上下に黒帯をつけるなどして別の場所である演出をしてください
;//♪

[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_3"  pos="2/3" time=1]
[BG f="b_08_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『ゲームセンター』（昼）******************************************************


In the arcade, Kaoruko was the sole playmaker more than I had imagined.
[cpg]

He didn't seem to be that good at TV games, but apparently he is quite an expert when it comes to arcade games.
[cpg]

[OnName num="kimoto"]
"It's great, that it is,......, I can't see my hand,......."
[cpg cn=true]

The first time I saw him, I thought he was a good player, but he was not.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kaoruko025"]
[OnName num="kaoruko"]
I'm not sure how difficult this song is.
[cpg cn=true]


I don't know how good I am, but I can't tell how good I am. I can't tell how good they are from me, but ......
[cpg]

At least, there were people outside our circle in the gallery. They must be really good.
[cpg]

[OnName num="shinjo"]
It's not only cute, but also cool. Not only cute but also cool, Kaoruko-chan.
[cpg cn=true]

[OnName num="tokuzawa"]
It's true, ......, it's impossible for a girl to be this good at it.
[cpg cn=true]


[FACE method="change_2" pos="2/3"]
The degree of pampering goes up. Kaoruko-chan looks back and sees it, a look of satisfaction on her face.
[cpg]

The expression on his face was something ...... of the same quality as the black smile he had after a drink the other day. ......
[cpg]

It seemed to me that it was something that expressed her true nature.
[cpg]

It's a face that is not like Kaoruko-chan, like she is intoxicated with herself.
[cpg]

Or maybe I just don't know the real Kaoruko-chan?
[cpg]

Anyway, by the time they cleared the next song, there was a round of applause, including from the gallery.
[cpg]

Kaoruko-chan looked more and more ecstatic. I even felt a little scared.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="cube.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="cube.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『街』（夕方）******************************************************


;//[SE f="se027"]
;//【ＳＥ】『喧騒』

And so, it was now completely late in the evening.
[cpg]

[OnName num="shinjo"]
I wondered, "What should we do, should we call it a night?
[cpg cn=true]

[OnName num="kimoto"]
"That's right. I have nothing more to do, that I don't. ......
[cpg cn=true]

[OnName num="tokuzawa"]
But I'd like to talk a little longer with this group.
[cpg cn=true]

I understand how Tokusawa-senpai feels. I mean, I agree, I would like to talk with Kaoruko more, though.
[cpg]

[OnName num="natsuki"]
Well, I'm tired today, so why don't we break up now?
[cpg cn=true]

[OnName num="tokuzawa"]
What the hell, you're not in charge, are you?"
[cpg cn=true]

[OnName num="kimoto"]
But actually, I'm tired from all the walking.
[cpg cn=true]

We glance at Kaoruko-chan. In other words, we are going to decide what we are going to do according to her convenience.
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko026"]
[OnName num="kaoruko"]
I'm sorry, but there's an anime I really want to watch in real time today.
[cpg cn=true]

[OnName num="tokuzawa"]
I see. I see. Well, I guess it can't be helped then.
[cpg cn=true]

[SE f="se001"]
;//【ＳＥ】『歩く』
[free time=1000]
[WAIT time=1100]

The four of us saw Kaoruko-chan off. After that, they went to ......
[cpg]

[OnName num="tokuzawa"]
...... Hey, Sugiura. You were holding hands with Hime, weren't you?
[cpg cn=true]

[OnName num="natsuki"]
Oh, I just wanted to keep her away from that place.
[cpg cn=true]

[OnName num="shinjo"]
I won't allow you to run away from the place. ......
[cpg cn=true]

I was pursued after all. I'm sure they haven't forgotten about me.
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se037"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[OnName num="natsuki"]
"Whew. ......
[cpg cn=true]

I went home and took a break. I listened to the geeky CDs I bought at the geek store and went to the computer.
[cpg]

I don't intend to do anything creative on the computer.
[cpg]

Even if it were a hobby, I don't draw, I don't play music, and I don't do anything productive.
[cpg]

Still, I do have a computer and surfing the net is a hobby.
[cpg]

...... knows me. I know the term "Princess of Otasaer. I think everyone else probably knows it, too.
[cpg]

But I am sure that Kaoruko-chan would say that she is different if I pointed it out to her.
[cpg]

That's how much we believe in her.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="nemuri.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="nemuri.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_1.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（朝）******************************************************

The next morning. It is a weekday, so I head to the station to catch the train to the university.
[cpg]

Today, I have the same lecture as Kaoruko-chan. I was a little excited about that.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_04_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学教室』（昼）******************************************************

Even though I arrive at the classroom before Kaoruko-chan, she sits next to me.
[cpg]

[FG f="CHA01_p3_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko027"]
[OnName num="kaoruko"]
I'm sorry I left before you yesterday. ......
[cpg cn=true]

[OnName num="natsuki"]
She said, "No, I don't mind. I don't mind.
[cpg cn=true]

[FACE method="change_1" pos="2/3"]

We converse congenially until the lecture starts, and after the lecture starts, we ......
[cpg]

They try to talk to each other on the edge of their notebooks. She is not the kind of girl who plays with her cell phone during lectures, but it is cute to see her do this.
[cpg]


[FADEOUTBGM]

On the edge of my notebook, I would write, "Don't you have a girlfriend, Sugiura-kun?" and ......
[cpg]

[OnName num="natsuki"]
Eh."
[cpg cn=true]

[BGM f="bg_ni"]

[FACE method="shake_2" pos="2/3"]
Kaoruko puts her finger in front of her mouth.
[cpg]

It was an unexpected question. Normally, she would have talked to me about anime, manga, and other unimportant things.
[cpg]

I responded on the edge of my notebook. No, I've never had a boyfriend.
[cpg]

[FACE method="change_1" pos="2/3"]

And now she replied, "I've never had a boyfriend either.
[cpg]

I can't help but think, ...... something. And then, I get carried away.
[cpg]

Maybe, just maybe, this is a prelude to a confession of love?
[cpg]

Is it just because I'm a nerd that I'm imagining things like that?
[cpg]

I get to the heart of the matter. Why are you saying that?"
[cpg]

[FACE method="shake_6" pos="2/3"]
And then I looked next to him. Kaoruko-chan is fidgeting and looking embarrassed.
[cpg]

I could tell. But I pretended not to notice.
[cpg]

I want to have fun with everyone in the circle. It's not okay for me to confess my feelings to them.
[cpg]

The words that rose to my throat were swallowed because I was in the middle of a lecture.
[cpg]



[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_06_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（昼）******************************************************

[OnName num="natsuki"]
Hey, Kaoruko, about what happened earlier.
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kaoruko028"]
[OnName num="kaoruko"]
It's nothing. Forget it, it's nothing.
[cpg cn=true]


[free time=1000]

Kaoruko-chan left after saying that. The direction of the direction suggests the direction of the circle building.
[cpg]

I didn't intend to chase after her, I just wanted to see everyone in the circle, so I headed to the club room.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************


[OnName num="kimoto"]
"Oh, I've been waiting for you, that I have. I have been waiting for you, that I have, Sugiura-dono.
[cpg cn=true]

[OnName num="natsuki"]
What are you talking about?
[cpg cn=true]

All the members were there. It seemed that they had been waiting for me for a long time.
[cpg]

[OnName num="shinjo"]
We were talking about having a drink again. How about you, Sugiura?
[cpg cn=true]

[OnName num="natsuki"]
No, of course I'll join ......, but I don't mean I'm waiting for you, I mean you could have sent it to me on ...... SNS or something.
[cpg cn=true]

[OnName num="shinjo"]
No, no, no!　No, no, no! We geeks don't belong on social networking sites!
[cpg cn=true]

Sure, we keep in touch with each other through social networking sites, but we only use them for urgent communication, or when we really need to tell each other.
[cpg]

We geeks are a strange lot, we seem to know more about electronics than anyone else, but we don't.
[cpg]

[OnName num="tokuzawa"]
Once we've decided on that, it's a quick conversation. When is a convenient day for you?
[cpg cn=true]

And when is a convenient day for everyone?
[cpg]

We nerds are a strange lot, we don't have enough money to buy ...... goods, but we don't want to work part-time.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_05_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夕方）******************************************************

So, on the way home after the date for the drinking party was decided.
[cpg]

[OnName num="natsuki"]
"...... everyone, where is the money going to come from for drinking and goods,......?"
[cpg cn=true]

Needless to say. I'm not sure how much I'm going to be able to afford to do this.
[cpg]

I wondered for a moment if Kaoruko-chan was the same way. I wonder if she has some kind of part-time job or something.
[cpg]

Maybe a maid cafe?　Just imagining it makes my nose bleed. ......
[cpg]

Maybe I should ask her next time. With that in mind, I headed home.
[cpg]



;//ＢＫ
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]


Then, on the day of the drinking party.
[cpg]


;//【ＢＧ】『居酒屋』（夜）******************************************************

[OnName num="kimoto"]
"I'm sorry to hear that, ...... seniors."
[cpg cn=true]

[OnName num="natsuki"]
Yes, well,...... I never thought two people could catch a cold at the same time.
[cpg cn=true]

On the day of the party, two seniors were absent, so it ended up being a one-year drinking party.
[cpg]

[OnName num="natsuki"]
I'm sure you've heard that the first time I went to a bar, I was so excited.
[cpg cn=true]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko029"]
[OnName num="kaoruko"]
There was a time when I did, but I quit right away.
[cpg cn=true]

[OnName num="kimoto"]
I was working at  for a while, but I quit soon after that. Even if you are as good a communicator as Kaoruko-dono, that you are not?
[cpg cn=true]

Kimoto says so, but I was somewhat convinced.
[cpg]

I had been thinking that the reason Kaoruko-chan was able to be so confident was because we are geeks.
[cpg]

Like the one at the game center, I think there's a big difference between when you can be confident and when you can't.
[cpg]

When she asked me about our conversation in the notebook, she couldn't have been more unsure of herself.
[cpg]

[FACE method="shock_5" pos="2/3"]
[VOICE f="Kaoruko030"]
[OnName num="kaoruko"]
He said, "I don't ...... think you're a good communicator."
[cpg cn=true]

You see, the expression on his face shades for a moment. Even he probably realizes it.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


The party was not very lively because of the absence of the two seniors.
[cpg]

It continued when Kimoto got up from his seat to use the restroom. ......
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『居酒屋』（夜）******************************************************


[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko031"]
[OnName num="kaoruko"]
"......"
[cpg cn=true]

[OnName num="natsuki"]
"......"
[cpg cn=true]

It's awkward. I'm not sure if it's a good idea to be alone with him after all that happened.
[cpg]

[FACE method="shake_2" pos="2/3"]
[VOICE f="Kaoruko032"]
[OnName num="kaoruko"]
Sugiura, you don't seem like much of a nerd, do you?
[cpg cn=true]

[OnName num="natsuki"]
I don't think so. I'm an otaku, and I've been called creepy before.
[cpg cn=true]

It was a harmless conversation. But then, gradually, the conversation takes a turn for the worse.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kaoruko033"]
[OnName num="kaoruko"]
I don't look like a nerd. It's not that I don't like otaku people, but ...... Sugiura-kun doesn't suddenly become passionate or cold.
[cpg cn=true]

[OnName num="natsuki"]
"That's not true,......, I'm not that good of a person.
[cpg cn=true]

[FACE method="change_6" pos="2/3"]
[VOICE f="Kaoruko034"]
[OnName num="kaoruko"]
"His face is cool,...... and his body is like a boy's,...... and he's always been that,......, I wonder what he's trying to say.
[cpg cn=true]

Kaoruko-chan tries to deceive. In fact, it's not deceptive at all.
[cpg]

It's almost like a confession now, I thought, and then she grabbed both of my hands.
[cpg]



;//●ＣＧ非エロ（ヒロイン・主人公の手を取って告白。切実な顔から返事を聞いて笑顔になる：居酒屋）ev_02

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_02_0 ***********************
[CG id=1 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]



[VOICE f="Kaoruko035"]
[OnName num="kaoruko"]
I'm going to say it, I'm going to say it with courage. So be prepared to listen."
[cpg cn=true]

I was beyond thrilled and my heart was about to jump out of my mouth.
[cpg]

I'm a nerd. I was born immune to girls, and there was nothing I could do about it.
[cpg]

I'm such a nerd, but when a girl this cute grabs me by both hands and tells me to be prepared to listen to her, I'm like ......
[cpg]

[OnName num="natsuki"]
"Is this a flag, ahaha, I'm going the Kaoruko-chan route, ahaha, ahaha ......"
[cpg cn=true]

I was so thrilled that words I didn't understand came out of my mouth.
[cpg]

The other side is looking at me seriously,......, and I have to respond to that seriously.
[cpg]

[OnName num="natsuki"]
I'm in a hard mode in my life, and I don't think it should be this easy to, you know, get into this."
[cpg cn=true]

I was so busy that I couldn't stop myself from speaking. Kaoruko-chan was like that to me,
[cpg]


[VOICE f="Kaoruko036"]
[OnName num="kaoruko"]
I like Natsuki-kun.
[cpg cn=true]

When he called me "Natsuki-kun" instead of "Sugiura-kun," I was taken aback. After that, I began to understand the meaning of the words "I like you, Natsuki-kun.
[cpg]

[OnName num="natsuki"]
I also thought ...... Kaoruko-chan was cute."
[cpg cn=true]

The words came out on their own. I even weighed it against the law, but in the end it was no comparison between the friendship of the four men and Kaoruko-chan's cuteness.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="heart1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="heart1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_6"  pos="2/3" time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『居酒屋』（夜）******************************************************

[OnName num="kimoto"]
What's wrong with you, that it is?　Both of you. Your faces are bright red, that they are."
[cpg cn=true]

After we untied our hands, Kimoto came back. We almost saw the decisive scene, dangerous ......
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kaoruko037"]
[OnName num="kaoruko"]
'It's nothing, I was just talking about anime with Natsuki-kun.
[cpg cn=true]

[OnName num="kimoto"]
"...... I see, that you did."
[cpg cn=true]

I'm glad Kimoto is so insensitive. He doesn't look at our relationship with any suspicion.
[cpg]

[OnName num="kimoto"]
By the way, did Kaoruko-dono call Sugiura-dono Natsuki-kun, that she did?
[cpg cn=true]

Oh no. I wasn't that insensitive.
[cpg]

[OnName num="natsuki"]
Yes, she did, didn't she?　Haha, yes, I'm sure, probably.
[cpg cn=true]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kaoruko038"]
[OnName num="kaoruko"]
Yes, it's just that it's easier to call you. Don't worry about it.
[cpg cn=true]

Kaoruko-chan is dodging it well. I'm too upset, it was really close ......
[cpg]


[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************

[OnName num="kimoto"]
I'm sure it's just easier to call me that. The two of you.
[cpg cn=true]

[OnName num="natsuki"]
"Yeah, goodbye. ......
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko039"]
[OnName num="kaoruko"]
Good night. See you then."
[cpg cn=true]

We each decided to go back in different directions. I'm going to meet up with Kaoruko soon and we'll meet up with her.
[cpg]




;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

I was going to meet up with Kaoruko soon. I was also thinking,
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko040"]
[OnName num="kaoruko"]
Is Natsuki-kun's house near here?
[cpg cn=true]

[OnName num="natsuki"]
Well, it's a little far if you don't take the ...... train.
[cpg cn=true]

Kaoruko-chan had said she would come to my house.
[cpg]

I was in a panic in my head.　I could tell my head was in a state of panic and not moving properly.
[cpg]

[OnName num="natsuki"]
"Haha, uh, well, what's that, ...... you're just coming to my house to play, right?"
[cpg cn=true]

[FACE method="shake_6" pos="2/3"]
[VOICE f="Kaoruko041"]
[OnName num="kaoruko"]
"...... Natsuki-kun, is that what you plan to do?"
[cpg cn=true]

He looks me up and down and says something like that. I'm not going to turn back now that I've come this far.
[cpg]


[OnName num="natsuki"]
"I'm sure you're drunk, Kaoruko-chan, ...... too."
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kaoruko042"]
[OnName num="kaoruko"]
Hey, can you call me Kaoruko ......?　Even in front of everyone, I call you Kaoruko.
[cpg cn=true]

Oh no. My life, which was supposed to be in hard mode, is entering some kind of strange bonus stage.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se008"]
;//【ＳＥ】『電車』

[BG f="b_00_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]



Riding the train, my destination was getting closer and closer.
[cpg]

There was something I couldn't stand. I feel like screaming right now.
[cpg]

Yeah, that was the moment I realized I'm a nerd. I'm sure normal people would be more calm. ......
[cpg]



[window target=false]
[free time=1000]
[BG f="b_01_4.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『主人公の部屋』（夜）******************************************************

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko043"]
[OnName num="kaoruko"]
......It's a little messy, Natsuki-kun's room.
[cpg cn=true]

[OnName num="natsuki"]
'Yes, it is. I'm sorry, Kaoruko-chan. ...... Kaoruko."
[cpg cn=true]

I almost said it once, and in the middle of saying it again. Then Kaoruko smiled like an angel,
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko044"]
[OnName num="kaoruko"]
I'm sorry, Kaoruko-chan. Please call me that, Natsuki-kun.
[cpg cn=true]

She said this to me. I felt like my head was going to explode.
[cpg]

[FACE method="change_1" pos="2/3"]
[VOICE f="Kaoruko045"]
[OnName num="kaoruko"]
Are you okay?　Your face is bright red.
[cpg cn=true]

[OnName num="natsuki"]
"Oh, haha ...... I'm not okay, I feel like I'm going crazy. ......
[cpg cn=true]

[OnName num="natsuki"]
I never thought my life would reach this bonus stage.
[cpg cn=true]

Not good. Bonus stage is a rude word.
[cpg]

[FACE method="change_2" pos="2/3"]
I thought so, but Kaoruko laughed at me.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko046"]
[OnName num="kaoruko"]
That's right, a bonus stage. Maybe it's only in hard mode.
[cpg cn=true]

[free time=300]
[FG f="CHA01_p5_01_a.ui" method="change_6"  pos="2/3" time=800]

;//そういいながら、キスしてきた。唇を割って、舌が入って来る。
Saying that, she kissed me.
[cpg]

It was sweet and soft to the touch. But it was so obvious that Kaoruko-chan was nervous too.
[cpg]

I can feel each other's hearts pulsing so fast it's crazy.
[cpg]


Kaoruko-chan is also desperate in her own way. I sensed that and became a little more calm.
[cpg]

[OnName num="natsuki"]
"Puhaaaah ......, it's my first time kissing ...... you, me."
[cpg cn=true]

[FACE method="bow_6" pos="2/3"]
[VOICE f="Kaoruko048"]
[OnName num="kaoruko"]
"Yes,...... it's my first time, too. We're first kisses, I'm so happy."
[cpg cn=true]

She wasn't a princess from Otasa, she looked like a real princess. She looked like a real princess.
[cpg]


;//●ＣＧエロ（ヒロイン・フェラチオするヒロイン。ぎこちないながらも楽しそう：主人公の部屋）ev_03

[FADEOUTBGM]
[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
[BGM f="bg_h1"]
;**【ＣＧ】 ev_03_0 ***********************
[CG id=2 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]



She was coming closer to me. I had no choice but to prepare myself for this.
[cpg]

[OnName num="natsuki"]
"What should I do? ...... You have another lecture tomorrow, Kaoruko, are you going home ......?"
[cpg cn=true]

Even if I have no choice but to be prepared, I had said this.
[cpg]


[VOICE f="Kaoruko086"]
[OnName num="kaoruko"]
"......If it's okay with Natsuki-kun, maybe I'll stay over."
[cpg cn=true]

[OnName num="natsuki"]
I said, "Sure!　Because, like, with your housemates.
[cpg cn=true]

;**【ＣＧ】 ev_03_a ***********************
[CG id=2 index=1 time=1]
;***************************************
[WAIT time=1]

[VOICE f="Kaoruko087"]
[OnName num="kaoruko"]
I'm sure you'll be fine. Don't worry about it.
[cpg cn=true]


;//ＢＫ

And that day, we slept in the same bed until the morning.
[cpg]

I thought, "I can't sleep with my eyes so bright!　I thought, but sleep came unexpectedly quickly.
[cpg]

[jump storage="ep002.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

