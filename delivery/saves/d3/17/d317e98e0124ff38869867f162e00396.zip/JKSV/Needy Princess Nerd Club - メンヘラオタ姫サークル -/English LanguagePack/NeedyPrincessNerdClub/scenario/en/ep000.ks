
*start|The Princess of Otasaer

;//オタサー姫もの　シナリオ

;//物語の視点が変わる部分があります。ウィンドウ色を変えるなどして、変化をつけてください
;//視点は夏樹視点、薫子視点の計二種類です
;//物語は夏樹視点からスタートし、切り替わる部分では「（キャラ名）に視点切り替わり」と表記してあります

;//主人公　杉浦夏樹（すぎうらなつき）が各キャラへ呼びかける場合
;//新庄先輩　徳沢先輩　木本　薫子ちゃん→薫子
;//ヒロイン　水城薫子（みずしろかおるこ）が各キャラへ呼びかける場合
;//杉浦くん→夏樹くん　新庄先輩　徳沢先輩　木本くん
;//サークル会員　新庄（しんじょう）が各キャラへ呼びかける場合
;//杉浦　徳沢　木本　薫子ちゃんor姫
;//サークル会員　徳沢（とくざわ）が各キャラへ呼びかける場合
;//杉浦　新庄　木本　薫子ちゃんor姫
;//サークル会員　木本（きもと）が各キャラへ呼びかける場合
;//杉浦殿　新庄殿　徳沢殿　薫子殿or姫



;#################################################
*Ep000|The Princess of Otasaer
;#################################################

[SCENE id=0]


[stflag boolean1 = 0]
[stflag boolean2 = 0]
[stflag boolean3 = 0]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[window target=true]
[WAIT time=100]


The circle building of a university. The words being exchanged in the bustling room were like a half-code.
[cpg]


[window target=false]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

What about yesterday's "STAPLA" anime? Who wrote the script and what about it? The drawing was divine, and the god times. The direction, the supervision, the voice acting... ......
[cpg]

Two of my seniors and one of my classmates were talking about such anime.
[cpg]

One of them is Shinjo-senpai. He is a huge man, probably weighing 100 kilograms, and wears a bandana to suit his appearance.
[cpg]

His language is normal, but the words he uses have an otaku-like quality that makes me feel close to him, as I am also an otaku.
[cpg]

[OnName num="shinjo"]
The C part of the show was also great. ......
[cpg cn=true]

In addition, he has a unique way of laughing, which makes me feel like he is one of us. I mean, the way they laugh, I can hear that kind of breathing sound sometimes.
[cpg]

[OnName num="tokuzawa"]
Yeah, it's like the C part, or rather, it merged with the ending."
[cpg cn=true]

And to that, Tokusawa-senpai. He is the exact opposite of Shinjo-senpai, about 50 kilograms or so, and is wearing what might be called a thimble-glove.
[cpg]

Even from a distance, you can guess that the conversation between these two is probably about anime, video games, or manga.
[cpg]

I, Natsuki Sugiura, was listening to their conversation in the background while playing video games.
[cpg]

Unfortunately, I didn't watch last night's StarPlaza, so I didn't think I could keep up with them, but I didn't think their conversation was at all sterile.
[cpg]

In fact, I find it meaningful and want to mingle. But there are reasons why I can't mix with them right now. So be it.
[cpg]

The last one, Kimoto. He is a classmate of mine, in the same year as me. He joined this "Contemporary Contents Research Group" a little earlier than me.
[cpg]

He looks normal. He is a little plain, but he looks like he would be popular if he was properly dressed, so he doesn't look like an otaku,
[cpg]

[OnName num="kimoto"]
Anyway, if things continue as they are, he is sure to dominate this season.
[cpg cn=true]

He has a "gozaru" tone, both to seniors and to me, his classmate. I was happy when I met him, because I wondered if there were people like that nowadays.
[cpg]

I am not so distinctive compared to them, and I don't think they would recognize me as an otaku at a glance.
[cpg]

Maybe it's hubris or modesty, but I'm what's called a "hidden geek" .......
[cpg]

I was comfortable talking with them, and I also loved this chaotic club room itself.
[cpg]

The so-called Otaku Circle. Or Otasaa for short.
[cpg]

If it were just the four of us, I think it would be perfectly fine to call it that. However, there is one reason why that is not the end of the story.
[cpg]

[OnName num="shinjo"]
I wonder what Kaoruko-chan is watching this season.
[cpg cn=true]

[FG f="CHA01_p5_01_a.ui" method="change_1"  pos="2/3" time=800]

Kaoruko-chan. Her full name is Kaoruko Mizuki. A woman's name. And it's the name of the girl next to me who is my opponent in a fighting game.
[cpg]


[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko001"]
[OnName num="kaoruko"]
Sugiura-kun, you're too strong. I can't win like this.
[cpg cn=true]

[OnName num="natsuki"]
I'm sorry. I'm sorry, but it's not right to go easy on her, it's just...how can I put it ......
[cpg cn=true]

The character she owns was defeated by the character I control. The attention is taken away from the screen for a moment,
[cpg]

[FACE method="bow_7" pos="2/3"]
[VOICE f="Kaoruko002"]
[OnName num="kaoruko"]
Oh, uh, ...... what are you watching this season?"
[cpg cn=true]

She turned around, threw the controller away, and got into an anime discussion.
[cpg]

[OnName num="tokuzawa"]
I knew you'd watch something that would be popular with the girls, like ...... "FAST"?
[cpg cn=true]

"FAST". That's the name of this season's anime, which, by the way, is abbreviated Fast, so it's pronounced butt up.
[cpg]


[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko003"]
[OnName num="kaoruko"]
I'm watching it, I'm watching it, I'm watching it!　I'm watching it!" The characters are so well drawn that they are very moe. The blue-haired girl looks like Tokusawa-senpai, doesn't she?
[cpg cn=true]

[OnName num="tokuzawa"]
Is she?　I don't know. ......
[cpg cn=true]

[OnName num="kimoto"]
"I haven't seen it. ...... Is it for women, that it is?"
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kaoruko004"]
[OnName num="kaoruko"]
I'm sure boys will enjoy it too, maybe Kimoto-kun will like it.
[cpg cn=true]

The otaku circle "Contemporary Contents Study Group" has five members in all. There are five members in all. Four are men and one is a woman.
[cpg]

Although the gender balance is out of balance, we are enjoying our circle activities to the fullest today.
[cpg]

For those of us who have no luck with girls, she is irreplaceable.
[cpg]

How did we end up where we are today?
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_00_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『空』（昼）******************************************************

This spring I went to college in my hometown and started living on my own.
[cpg]

I still remember how excited I was to be at the university, which was located a few train stops away from my apartment.
[cpg]

I had one dream when I became a university student. It was to join an otaku club.
[cpg]

I had always wanted a place where I could get together with people who share my interests and talk about them.
[cpg]

I was sure that there would be a club at the university that would suit my needs. With this in mind, I started by choosing a club.
[cpg]


[window target=false]
[free time=1000]
[BG f="b_06_2.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（昼）******************************************************

A few days after I entered the university, I easily found the club I was looking for.
[cpg]

I was surprised to find that there was not only one circle that was involved in otaku-related activities.
[cpg]

There were also manga clubs, ani clubs, and other creative circles ......
[cpg]

But I've just been a quiet otaku in the shadows. I'm not particularly good at drawing, nor do I want to be good at it, so I avoided those places.
[cpg]

I was just enjoying myself as an otaku. I was looking for a place where I could relax.
[cpg]

That's when I found the "Contemporary Contents Study Group. I was instantly attracted by the name, which sounded like something out of the ordinary.
[cpg]

I was fascinated by the name, which had a long history as a circle, and yet was so vague that I couldn't help but think that one of its founders had worked very hard to come up with it.
[cpg]


;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]


[OnName num="natsuki"]
"Excuse me!　I'm, uh, I'm, I'm a, I'm a new student."
[cpg cn=true]

[OnName num="shinjo"]
"Oh, you want to join?　You want to join, duh-huh.
[cpg cn=true]

[OnName num="tokuzawa"]
You shouldn't be so judgmental, Shinjo. Look, you're freaking out."
[cpg cn=true]

[OnName num="kimoto"]
"......"
[cpg cn=true]

There were already three men there. I was surprised at their appearance, and at the same time, I felt a response that I had found my friends.
[cpg]

[OnName num="tokuzawa"]
I'm not going to stand around talking about it. You can sit down, newcomer.
[cpg cn=true]

[OnName num="shinjo"]
I have a hard time just standing up, you know.
[cpg cn=true]

They were all friendly and nice, and I felt very comfortable.
[cpg]

I was excited to be able to enjoy the otaku life in the open.
[cpg]

But then, just then.
[cpg]


[SE f="se003"]
;//【ＳＥ】『ノック』
[WAIT time=1000]

I heard a knock at the door. It hadn't been long since I entered the clubroom.
[cpg]

[OnName num="kimoto"]
"Oops, more prospective members, that I see.
[cpg cn=true]

[OnName num="shinjo"]
There are a lot of first-year students this year, aren't there? I'm so happy. That's great.
[cpg cn=true]

I wonder what kind of people will come to the club. I would hate it if they are just nerdy geeks, or more like yankees. ......
[cpg]

I didn't need to worry about that. Rather, I should have worried about something else.
[cpg]

I didn't expect this pattern either. ......
[cpg]


;//●ＣＧ非エロ（ヒロイン・ヒロイン登場。気合の入った服装。もじもじした仕草：サークル部室）ev_01


[SE f="se019"]
;//【ＳＥ】『ドア開く』

[window target=false]
[free time=1000]
[BG f="black.ui" time=1000]
[WAIT time=1000]
;**【ＣＧ】 ev_01_0 ***********************
[CG id=0 index=0 time=1000]
;***************************************
[WAIT time=2000]
[window target=true]


[VOICE f="Kaoruko005"]
[OnName num="kaoruko"]
I was just thinking, "Oh, ......, I'd like to join!　I'd like to join."
[cpg cn=true]

To my surprise, it was not a guy who opened the door and came in, but a girl. Yes, a girl!
[cpg]

She was a typical geek girl, without any makeup and dressed in Lolita-like clothes.
[cpg]

But she was cute. I think she's cute.
[cpg]

Often, otaku have little chance to meet girls.
[cpg]

We were stunned by the cuteness, as if a baby had eaten a pepper.
[cpg]

If it had been an ugly girl, the reaction would have been different, and we would have been happy to have a girl in the room.
[cpg]


[VOICE f="Kaoruko006"]
[OnName num="kaoruko"]
'Mizuki, I'm Kaoruko, ...... please keep in touch with me, uh, no, uh, .......'
[cpg cn=true]

And the girl, who introduced herself as Kaoruko, joined as a member of this contemporary contents research group.
[cpg]

No one was against it. Or rather, it was as if everyone was in favor of it to the point of excess.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="enn3.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="enn3.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

And so it has been up to the present.
[cpg]

Now she is the object of admiration,...... or not, but I think there is another way to say it.
[cpg]

Anyway, everyone is crazy about her. And I can't deny that, either, to my shame.
[cpg]



[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kaoruko007"]
[OnName num="kaoruko"]
The charm of that work is, without a doubt, the characters. It's full of unlikely characters, but it's not broken.
[cpg cn=true]

When I hear this kind of speech, I think she must be a nerd too, but the guys, including me, have been quietly listening to it.
[cpg]

Maybe we've been inverted from our general values.
[cpg]


For example, a guy who is not a regular nerd might stay away from a nerdy girl.
[cpg]

And vice versa. That's why we don't have any contact with girls.
[cpg]

But I felt that geeky girls are more attractive to geeky guys than non-geek girls.
[cpg]

[FACE method="bow_1" pos="2/3"]
[VOICE f="Kaoruko008"]
[OnName num="kaoruko"]
I guess it's something like that. ...... Sorry, I'm the only one talking.
[cpg cn=true]


I was the only one who could talk. I joined in and gave a small round of applause.
[cpg]

[OnName num="kimoto"]
I will definitely watch it when I get back, that I promise. I promise, that I will.
[cpg cn=true]

[OnName num="shinjo"]
I'll watch it too, I think. ......
[cpg cn=true]

For example, when I recommend anime to the other male members, the percentage of them watching it is not so high. The most important thing to remember is that you can't just go to the store and ask for the best price.
[cpg]



[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


She is like a princess. I wonder if we are ......, we are knights, we are commoners, we might be slaves.
[cpg]

No, no, Kaoruko doesn't treat us like slaves.
[cpg]

Then I guess we are common people who watch over the princess.
[cpg]




[FADEOUTBGM]
[window target=false]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="uzumaki1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_02_3.ui" time=1]
[WAIT time=200]
[transition target={false} rule="uzumaki1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『サークル部室』（夕方）******************************************************

Then, after Kaoruko-chan left the club room a little early, the four of us talked together.
[cpg]

[OnName num="kimoto"]
'Well, the princess was lovely today too. ......
[cpg cn=true]

We call her Hime in Kaoruko-chan's absence.
[cpg]

So my imagination earlier was not just an imagination or something.
[cpg]

[OnName num="shinjo"]
Duh, the word "princess" really is appropriate.
[cpg cn=true]

[OnName num="natsuki"]
'That's right. ...... She was pretty strong in the gaming too, Hime. She was pretty good at making her own combos.
[cpg cn=true]

[OnName num="tokuzawa"]
"Really?　I mean, that controller was touched by Hime just now!
[cpg cn=true]


[SE f="se004"]
;//【ＳＥ】『乱暴に立ち上がる　椅子の音』

Kimoto stood up roughly. The chair rattled.
[cpg]

[OnName num="kimoto"]
What a surprise!　This is a big deal, that it is. ......"
[cpg cn=true]

but no one would touch the controller. We have a tacit understanding or ...... something similar.
[cpg]

We are so intoxicated that we have become strangely collusive, or something like that, and while we were spending time like that, a code was formed.
[cpg]

[OnName num="shinjo"]
No, no, no. No, no, you can't just skip out.
[cpg cn=true]

[OnName num="natsuki"]
'...... that's right. Even though it's only a controller, if you touch it, ......
[cpg cn=true]

[OnName num="tokuzawa"]
Yes, that's enough of a cop out!　For us, even touching the princess is a serious taboo.
[cpg cn=true]

[OnName num="natsuki"]
No, I didn't touch her, though. ......
[cpg cn=true]

The ironclad rule is that you must never run away from Kaoruko-chan, and you must never confess to her from the male side.
[cpg]

That was a rule that should never be broken anyway, even though there was a loophole that said what would happen to a confession from Kaoruko-chan.
[cpg]

[OnName num="natsuki"]
I've been wondering about this for a while...what happens if I break that rule?"
[cpg cn=true]

The three of us were stunned. What do you mean, maybe it hasn't been decided yet?
[cpg]

[OnName num="kimoto"]
"If you break the rule, will you be asked to leave the ...... circle, that is?
[cpg cn=true]

[OnName num="tokuzawa"]
Walk away?　Does that mean you and Kaoruko-chan?
[cpg cn=true]

[OnName num="shinjo"]
Oh no, it's too sad that ...... princess will be gone.
[cpg cn=true]

After all, they haven't solidified. While colluding, the art of retaliation seems to be undecided.
[cpg]

[OnName num="kimoto"]
In any case, we will retaliate with all our might against those who try to run away, that we will."
[cpg cn=true]

I was thinking that I had to decide what the retaliation would be. ......
[cpg]

[OnName num="tokuzawa"]
"Okay, it's decided!　We're going to protect the princess as she is by colluding with each other."
[cpg cn=true]

[OnName num="natsuki"]
'Yes, senpai. I won't tolerate anyone who runs away from me either. I'm a nerd, I don't have two words for you.
[cpg cn=true]

We shared the same feeling. Because Kaoruko-chan is so cute.
[cpg]

[SE f="se019"]
;//【ＳＥ】『ドア開く』

[window target=false]
[free time=1000]
[BG f="b_06_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『大学廊下』（夕方）******************************************************

So I left the club room to go home.
[cpg]

My steps were light as I walked home. I think this is proof that my college life is fulfilling.
[cpg]

I get along well with everyone in the circle, but Kaoruko-chan is a big part of it.
[cpg]

That is why I was feeling lighthearted during this period when I might normally suffer from the gap after entering the university.
[cpg]

I was on my way home, thinking about what to eat today and what was in the fridge .......
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="migi.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="migi.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************


[SE f="se036"]
;//【ＳＥ】『グループチャット通知』
[WAIT time=1000]

And then, on my way home, my cell phone rang.
[cpg]

It was a social networking service, a group chat for circle members only. There, the date of the next drinking party was written.
[cpg]

[OnName num="natsuki"]
It said, "...... everyone likes to have a drink. I'm not that much of an alcoholic.
[cpg cn=true]

I'm not that much of an alcoholic. I had an image that many otaku, including me, are not good at drinking, but apparently not.
[cpg]

Especially two of my seniors drink a lot. They are the kind of guys who double their otaku power when they drink.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1000]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_04_2.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_sl"]
[WAIT time=100]
;//【ＢＧ】『大学教室』（昼）******************************************************

The next day. While attending a noon lecture, I was kind of looking forward to the drinking session.
[cpg]

When Kaoruko-chan gets drunk, she's cute. It's not that her personality changes in any particular way. ......
[cpg]

She blushes a little and becomes girly, or something. That's because she was a girl to begin with, and she is girly, but I was looking forward to that.
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア開く』

[window target=false]
[free time=1000]
[BG f="b_02_3.ui" time=1000]
[WAIT time=2000]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『サークル部室』（夕方）******************************************************


[OnName num="kimoto"]
You are late, that you are, Mr. Sugiura.
[cpg cn=true]

[OnName num="shinjo"]
Really. I'm so hungry, how will you take the responsibility?
[cpg cn=true]

[OnName num="natsuki"]
I'm sorry. I had to postpone my lecture for a while.
[cpg cn=true]

Everyone had already gathered there. No, Kaoruko-chan is not here yet?
[cpg]


[SE f="se019"]
;//【ＳＥ】『ドア開く』

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[WAIT time=2000]

[FACE method="bow_4" pos="2/3"]
[VOICE f="Kaoruko009"]
[OnName num="kaoruko"]
I'm sorry, I'm late!　I'm sorry I'm late, I'm just, I'm on a wild business ......"
[cpg cn=true]

[OnName num="shinjo"]
Never mind, it's fine. Nobody is waiting for me, right?
[cpg cn=true]

[OnName num="tokuzawa"]
Oh, but not waiting doesn't mean I'm not waiting for Kaoruko-chan. ......
[cpg cn=true]

It's the difference in this response. No, it's not senpai's fault. I probably would have reacted the same way.
[cpg]


[FADEOUTBGM]
[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_d1"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

After leaving the university, the five of us walked to the pub.
[cpg]

I think we are an odd group of five. If Kaoruko was not here, I would have been able to lump us all together to some extent.
[cpg]

And when the five of us are walking together, we can't just split into two or three groups or walk side by side.
[cpg]

[OnName num="kimoto"]
I saw Fast, that I did, that I did. ...... No, it was interesting, that it was.
[cpg cn=true]

[OnName num="shinjo"]
'Yes, yes. It's as expected from Kaoruko-chan's point of view.
[cpg cn=true]

But it's almost side by side. That's how much they want to talk with Kaoruko-chan,...... me, too.
[cpg]


[FG f="CHA01_p1_01_a.ui" method="change_2"  pos="2/3" time=800]
[VOICE f="Kaoruko010"]
[OnName num="kaoruko"]
"Hehe, did you find it interesting?　That series, actually, that wasn't the first one. It's interesting if you go back and watch it.
[cpg cn=true]

[OnName num="kimoto"]
"Oh, is that the second season, that it is?"
[cpg cn=true]

[OnName num="tokuzawa"]
No, no. No, no, no. The title is different, but it is a parallel.
[cpg cn=true]

Especially Tokusawa-senpai, who seems to have watched the same anime as Kaoruko, was snickering.
[cpg]

Even at the stage of walking side by side like this, we are a bit unique, or perhaps we are a troublesome bunch from the side. But that's what ......
[cpg]



[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『居酒屋』（夜）******************************************************


[SE f="se001"]
;//【ＳＥ】『居酒屋のガヤガヤ』

[OnName num="kimoto"]
"Ugh, when will that director be back, that he will be back ......?"
[cpg cn=true]

[OnName num="tokuzawa"]
"Bullshit, he's back, isn't he?　What was that thing the other day?　That was fun, wasn't it? That was his comeback.
[cpg cn=true]

[OnName num="natsuki"]
That was not a comeback!　That was not a return! That was not a director's return!
[cpg cn=true]

[OnName num="shinjo"]
Yes, Japanese animation can't spread its wings to the world if we don't do something about it, and for that reason, all otaku must stand together as one.
[cpg cn=true]

Me, Kimoto, and the seniors are finally getting troublesome when we get drunk. Even though it hasn't been that long since we started drinking.
[cpg]

The topic of conversation, which I don't know whether to be extroverted or introverted, simmers down in the spotlight,
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kaoruko011"]
[OnName num="kaoruko"]
He said, "Well, well, well, it looks like he's got another one coming, so let's hope for the best. Let's hope so, Kimoto-kun.
[cpg cn=true]

[OnName num="kimoto"]
"What?　The next one?　I have never heard of it, that I have not.
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko012"]
[OnName num="kaoruko"]
The other day, he was interviewed by the director. He said he has an idea for the next film.
[cpg cn=true]

[OnName num="natsuki"]
But that director has a long way to go from there. ......
[cpg cn=true]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kaoruko013"]
[OnName num="kaoruko"]
But it's good that he has a plan. But it's good that he has a plan, that means we can still wait with anticipation.
[cpg cn=true]

The most troublesome of us, Kaoruko-chan, without saying that it is troublesome, and dealing with one by one.
[cpg]

I honestly thought she was a dedicated girl. I think she is an amazing person ...... because she can be smiling around such unique members.
[cpg]


[FG f="ci_lbox.ui" method="in" layer=20 pos="4/7" time=1000]
[WAIT time=1000]
;//ＢＫ


Come to think of it, I haven't had a girlfriend for a long time and never had one.
[cpg]

If I had a girlfriend like this, she would understand my nerdy hobbies.
[cpg]

If we have the same interests, we won't have the boring conflicts that normal couples do.
[cpg]

I don't know if it was because of my fantasy or not. ......
[cpg]



[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_03_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『居酒屋』（夜）******************************************************




[FG f="CHA01_p3_01_a.ui" method="change_1"  pos="2/3" time=800]
[VOICE f="Kaoruko014"]
[OnName num="kaoruko"]
"...... Hey, Sugiura-kun."
[cpg cn=true]

[OnName num="natsuki"]
What's wrong?　What's wrong?"
[cpg cn=true]

Kaoruko-chan is right next to me. I was nervous about that, but I tried to act as calm as I could.
[cpg]

[FACE method="change_7" pos="2/3"]
[VOICE f="Kaoruko015"]
[OnName num="kaoruko"]
Sugiura-kun, were you involved in any sports or athletic activities?
[cpg cn=true]

[OnName num="natsuki"]
No, I didn't do anything. ...... Why?
[cpg cn=true]

[FACE method="shake_2" pos="2/3"]

He chuckles. I think it's because I'm acting suspiciously, and my face turns red.
[cpg]

[FACE method="shake_1" pos="2/3"]
[VOICE f="Kaoruko016"]
[OnName num="kaoruko"]
I'm not. I just thought your hands are so big.
[cpg cn=true]

And then Kaoruko-chan spreads her hands quickly and unfolds them ......
[cpg]

I was so happy to see her. I can feel the warmth of her body.
[cpg]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko017"]
[OnName num="kaoruko"]
I'm not sure if it's a good idea to have a new hand, but I'm sure it's a good idea to have a new hand. Hehehe.
[cpg cn=true]

[OnName num="natsuki"]
I'm a man, you know. I'm a man, you know. ......
[cpg cn=true]

I was happy. Of course I was happy because we could touch each other's hands.
[cpg]

[free time=300]
[FG f="CHA01_p1_01_a.ui" method="change_1"  pos="2/3" time=800]

But at the same time, I was scared. The men's gazes fell on me, then turned away, and then fell silent.
[cpg]

[OnName num="kimoto"]
I've never been involved in sports, either.
[cpg cn=true]

[OnName num="shinjo"]
I wonder if I would have lost weight by now if I had played sports too, duhuhuhu .......
[cpg cn=true]

Of course, Kaoruko is there, so everyone remains calm on the surface.
[cpg]



[FADEOUTBGM]
[free time=1000]
[WAIT time=1000]
;//ＢＫ


But the moment Kaoruko got up from her seat to use the restroom, the pursuit began.
[cpg]


[BGM f="bg_t1"]

;//【ＢＧ】『居酒屋』（夜）******************************************************


[SE f="se007"]
;//【ＳＥ】『机叩く』

[OnName num="tokuzawa"]
You're a runaway!　You, I won't forgive you!"
[cpg cn=true]

Tokusawa-senpai is banging on the desk, looking like a demon. He is so thin that he doesn't look very scary.
[cpg]

[OnName num="kimoto"]
"Have you forgotten the iron law, that you should not touch hands with the princess!
[cpg cn=true]

[OnName num="shinjo"]
I envy you, I envy you too much, buh, buh.
[cpg cn=true]

[OnName num="natsuki"]
'Huh, it's an irresistible force. I didn't do it myself.
[cpg cn=true]

I thought about what to say to settle the situation. But..,
[cpg]

[FG f="CHA01_p1_01_a.ui" method="change_4"  pos="2/3" time=800]
[VOICE f="Kaoruko018"]
[OnName num="kaoruko"]
What's the matter?　You all look so grim. ......
[cpg cn=true]

[OnName num="kimoto"]
"No, no, it's nothing, haha."
[cpg cn=true]

[OnName num="shinjo"]
Yes, yes. But more importantly, do you have any other anime that you'd like to recommend?
[cpg cn=true]

[OnName num="tokuzawa"]
"Oh, I'd like to know too.
[cpg cn=true]


[FACE method="bow_2" pos="2/3"]
When Kaoruko-chan came back, things quieted down instantly.
[cpg]

I realized that we are, to all intents and purposes, otaku, creatures in common.
[cpg]



[window target=false]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="moya.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="moya.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『街』（夜）******************************************************


;//[SE f="se027"]
;//【ＳＥ】『喧騒』

[OnName num="shinjo"]
I'm going to miss it. ...... I'd like to drink until morning.
[cpg cn=true]

[OnName num="tokuzawa"]
No, that's not a good idea. I have another lecture tomorrow.
[cpg cn=true]

The party ended and we headed home.
[cpg]



;//ＢＫ
[FADEOUTBGM]
[window target=false]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[transition target={true} rule="tokei1.webp" color={0x000000ff} time=1]
[WAIT time=1]
[FG f="CHA01_p3_01_a.ui" method="change_7"  pos="2/3" time=1]
[BG f="b_05_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="tokei1.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

[BGM f="bg_ni"]
[WAIT time=100]
;//【ＢＧ】『街』（夜）******************************************************

I was alone with Kaoruko-chan on the way home.
[cpg]

[FACE method="change_4" pos="2/3"]
[VOICE f="Kaoruko019"]
[OnName num="kaoruko"]
She said, "...... hey, did you maybe get into a fight because I put my hands together?"
[cpg cn=true]



[OnName num="natsuki"]
Eh,...... no, nothing like that."
[cpg cn=true]

[FACE method="bow_2" pos="2/3"]
[VOICE f="Kaoruko020"]
[OnName num="kaoruko"]
I see, that's fine then,......."
[cpg cn=true]

She said, "That's fine then." She was more concerned about the discord in the circle because of her ......
[cpg]

I didn't miss something, a black smile or perhaps a look of satisfaction on her face.
[cpg]



[window target=false]
[transition target={true} rule="sita.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[free time=1]
[BG f="black.ui" time=1]
[WAIT time=200]
[transition target={false} rule="sita.webp" color={0x000000ff} time=1]
[WAIT time=1]

[SE f="se037"]
;//【ＳＥ】『ドア閉まる』

[transition target={true} rule="ue.webp" color={0x000000ff} time=1]
[WAIT time=1]
[BG f="b_01_4.ui" time=1]
[WAIT time=200]
[transition target={false} rule="ue.webp" color={0x000000ff} time=1000]
[WAIT time=1100]
[window target=true]
[WAIT time=100]

;//【ＢＧ】『主人公の部屋』（夜）******************************************************


[OnName num="natsuki"]
'...... Kaoruko-chan, huh?'
[cpg cn=true]

I don't think she's a flip-flopping girl. I'm not sure how to tell the difference yet.
[cpg]

But I'm sure she's a cute girl. I lay on my back on the bed in plain clothes and thought about this and that.
[cpg]

I wondered if it was on purpose that she put her hands together. If so, she must have had something special in mind for me. ......
[cpg]

I thought about it and shook my head. I should not get my hopes up too high.
[cpg]

A girl that pretty is kind of mismatched with me. ...... I knew it.
[cpg]


[jump storage="ep001.ks" target="*start"]
;////////////////////////////////////////////////////////////////////////

